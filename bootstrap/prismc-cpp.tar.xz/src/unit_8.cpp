// The module `Check.Env.Reading`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/env/reading/module.hpp>
#include <check/env/module.hpp>
#include <check/types/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Env.Reading`, from `target/bootstrap/cpp-src/prismc/check/env/reading.prism`.
namespace crate::check::env::reading {

void Cx_::show(Printer& p) const {
    p.record("Cx", {{"g", g}, {"home", home}, {"scope", scope}, {"row_vars", row_vars}, {"unwritten", unwritten}});
}

Pod Cx_::to_pod() const {
    return Pod::record("Cx", {{"g", prism_rtl::to_pod(g)}, {"home", prism_rtl::to_pod(home)}, {"scope", prism_rtl::to_pod(scope)}, {"row_vars", prism_rtl::to_pod(row_vars)}, {"unwritten", prism_rtl::to_pod(unwritten)}});
}

Result<Cx_> Cx_::from_pod(const Pod& whole) {
    return Cx_{.g = TRY(prism_rtl::from_pod<crate::check::env::G>(TRY(crate::prelude::field(whole, "g")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .scope = TRY(prism_rtl::from_pod<crate::check::types::Rw>(TRY(crate::prelude::field(whole, "scope")))), .row_vars = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "row_vars")))), .unwritten = TRY(prism_rtl::from_pod<crate::check::types::Col>(TRY(crate::prelude::field(whole, "unwritten"))))};
}


/// CxOf: fn G, Text -> Cx
Cx_ cx_of(const crate::check::env::G& g_p0, const Text& m_p1) {
    auto info_p2 = or_(crate::prelude::get(g_p0.mods, m_p1), or_(crate::prelude::get(g_p0.mods, Text::lit("")), dummy_mod()));
    return Cx_{.g = g_p0, .home = m_p1, .scope = prism_rtl::deref(info_p2).emit_rw, .row_vars = prism_rtl::deref(info_p2).row_var == Text::lit("")
        ? Array<Text>{}
        : Array(std::vector{prism_rtl::deref(info_p2).row_var}), .unwritten = crate::check::types::Col(crate::check::types::Col::CBound{})};
}


/// let dummyMod
crate::check::env::ModInfo dummy_mod() {
    return crate::check::env::ModInfo{.name = Text::lit(""), .file = Nat(0u), .emit_rw = crate::check::types::empty_row(), .row_var = Text::lit(""), .uses = Array<std::tuple<Text, bool>>{}, .root = false, .tree = crate::check::env::empty_module()};
}


/// ConvType: unbounded fn Cx, St, Type -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::Type& t_p2) {
    auto&& _m = prism_rtl::deref(t_p2.kind);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n_p3 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p4 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        auto [base_p5, st2_p6] = conv_named(cx_p0, st_p1, n_p3, args_p4, t_p2.span);
        return std::tuple{crate::check::types::with_marks(prism_rtl::deref(n_p3).sigils, base_p5, cx_p0.scope), st2_p6};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& sigils_p7 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        auto&& inner_p8 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        auto [i_p9, st2_pa] = conv_type(cx_p0, st_p1, prism_rtl::deref(prism_rtl::deref(inner_p8)));
        return std::tuple{crate::check::types::with_marks(sigils_p7, i_p9, cx_p0.scope), st2_pa};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m)) {
        auto&& e_pb = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        auto [i_pc, st2_pd] = conv_type(cx_p0, st_p1, prism_rtl::deref(prism_rtl::deref(e_pb)));
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(i_pc)}), st2_pd};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts_pe = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        auto [xs_pf, st2_pg] = conv_types(cx_p0, st_p1, ts_pe);
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyTuple{xs_pf}), st2_pg};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_ph = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return conv_type(cx_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_ph)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k_pi = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pj = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        auto [kk_pk, st2_pl] = conv_type(cx_p0, st_p1, prism_rtl::deref(prism_rtl::deref(k_pi)));
        auto [vv_pm, st3_pn] = conv_type(cx_p0, st2_pl, prism_rtl::deref(prism_rtl::deref(v_pj)));
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(kk_pk), prism_rtl::rc(vv_pm)}), st3_pn};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& color_po = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0;
        auto&& ps_pp = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_pq = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        auto [xs_ps, st2_pt] = conv_types(cx_p0, st_p1, ps_pp);
        auto [r_pu, st3_pv] = conv_type(cx_p0, st2_pt, prism_rtl::deref(prism_rtl::deref(res_pq)));
        auto c_pr = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Col> _v;
            if (prism_rtl::is<crate::syntax::Color::Bounded>(color_po)) {
                _v.set(cx_p0.unwritten);
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::Color::Unbounded>(color_po)) {
                _v.set(crate::check::types::Col(crate::check::types::Col::CUnbound{}));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::Color::ColorVar>(color_po)) {
                auto&& v_p10 = prism_rtl::as<crate::syntax::Color::ColorVar>(color_po).a0;
                _v.set(prism_rtl::deref(v_p10).name == Text::lit("bounded")
                    ? crate::check::types::Col(crate::check::types::Col::CBound{})
                    : crate::check::types::Col(crate::check::types::Col::CQ{prism_rtl::deref(v_p10).name}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyFn{c_pr, xs_ps, prism_rtl::rc(r_pu)}), st3_pv};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& ty_p11 = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& row_t_p12 = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        auto [rw_p14, st2_p15] = conv_row(cx_p0, st_p1, prism_rtl::deref(prism_rtl::deref(row_t_p12)));
        auto inner_p13 = ({
            Cx_ this_ = cx_p0;
            this_.scope = rw_p14;
            (std::move(this_));
        });
        return conv_type(inner_p13, st2_p15, prism_rtl::deref(prism_rtl::deref(ty_p11)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TUnit>(_m)) {
        auto&& sigils_p16 = prism_rtl::as<crate::syntax::TypeKind::TUnit>(_m).a0;
        return std::tuple{crate::check::types::with_marks(sigils_p16, crate::check::types::t_unit(), cx_p0.scope), st_p1};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TAny>(_m)) {
        auto&& tr_p17 = prism_rtl::as<crate::syntax::TypeKind::TAny>(_m).a0;
        auto&& _m = crate::check::env::names::resolve_trait(cx_p0.g, cx_p0.home, tr_p17->path_);
        if (prism_rtl::is_some(_m)) {
            auto&& k_p18 = prism_rtl::some_of(_m);
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAny{Array(std::vector{k_p18})}), st_p1};
        }
        if (prism_rtl::is_none(_m)) {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unknown-name"), prism_rtl::deref(tr_p17).span, prism_rtl::cat("no trait `^", crate::check::env::dotted(tr_p17->path_), "`"))};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TAbsent>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), t_p2.span, Text::lit("this checker does not implement sparse tuples"))};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TNonEmpty>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), t_p2.span, Text::lit("this checker does not implement non-empty arrays"))};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::THole>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), t_p2.span, Text::lit("this checker does not implement higher-kinded traits"))};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFamily>(_m)) {
        auto&& q_p19 = prism_rtl::as<crate::syntax::TypeKind::TFamily>(_m).a0;
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("kind"), t_p2.span, prism_rtl::cat("`", crate::check::env::dotted(q_p19->path_), ".*` is a row, not a type"))};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("kind"), t_p2.span, Text::lit("a row is not a type"))};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> ConvType::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p2).kind);
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& n_p3 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p4 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        ({
        auto args_p4_1 = args_p4;
        auto cx_p0_2 = cx_p0;
        auto n_p3_3 = n_p3;
        auto st_p1_4 = st_p1;
        auto t_p2_5 = t_p2;
        call_then(start_conv_named(cx_p0_2, st_p1_4, n_p3_3, args_p4_1, prism_rtl::deref(t_p2_5).span), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_named_1482) {
        return ({
            auto [base_p5, st2_p6] = conv_named_1482;
            (prism_rtl::finished(std::tuple{crate::check::types::with_marks(prism_rtl::deref(n_p3_3).sigils, base_p5, prism_rtl::deref(cx_p0_2).scope), st2_p6}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m) ? ({
        auto&& sigils_p7 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        auto&& inner_p8 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        ({
        auto cx_p0_1 = cx_p0;
        auto inner_p8_2 = prism_rtl::deref(prism_rtl::deref(inner_p8));
        auto sigils_p7_3 = sigils_p7;
        auto st_p1_4 = st_p1;
        call_then(start_conv_type(cx_p0_1, st_p1_4, inner_p8_2), [=, sigils_p7_3 = std::move(sigils_p7_3)](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_1623) {
        return ({
            auto [i_p9, st2_pa] = conv_type_1623;
            (prism_rtl::finished(std::tuple{crate::check::types::with_marks(sigils_p7_3, i_p9, prism_rtl::deref(cx_p0_1).scope), st2_pa}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) ? ({
        auto&& e_pb = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        ({
        auto cx_p0_1 = cx_p0;
        auto e_pb_2 = prism_rtl::deref(prism_rtl::deref(e_pb));
        auto st_p1_3 = st_p1;
        call_then(start_conv_type(cx_p0_1, st_p1_3, e_pb_2), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_1742) {
        return ({
            auto [i_pc, st2_pd] = conv_type_1742;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(i_pc)}), st2_pd}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m) ? ({
        auto&& ts_pe = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        ({
        auto cx_p0_1 = cx_p0;
        auto st_p1_2 = st_p1;
        auto ts_pe_3 = ts_pe;
        call_then(start_conv_types(cx_p0_1, st_p1_2, ts_pe_3), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_1829) {
        return ({
            auto [xs_pf, st2_pg] = conv_types_1829;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyTuple{xs_pf}), st2_pg}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_ph = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvType(cx_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_ph)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TMap>(_m) ? ({
        auto&& k_pi = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pj = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        ({
        auto cx_p0_1 = cx_p0;
        auto k_pi_2 = prism_rtl::deref(prism_rtl::deref(k_pi));
        auto st_p1_3 = st_p1;
        auto v_pj_4 = prism_rtl::deref(prism_rtl::deref(v_pj));
        call_then(start_conv_type(cx_p0_1, st_p1_3, k_pi_2), [=, v_pj_4 = std::move(v_pj_4)](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_1952) {
        return ({
            auto [kk_pk, st2_pl] = conv_type_1952;
            call_then(start_conv_type(cx_p0_1, st2_pl, v_pj_4), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_1997) {
            return ({
                auto [vv_pm, st3_pn] = conv_type_1997;
                (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(kk_pk), prism_rtl::rc(vv_pm)}), st3_pn}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& color_po = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0;
        auto&& ps_pp = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_pq = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto color_po_1 = color_po;
        auto cx_p0_2 = cx_p0;
        auto ps_pp_3 = ps_pp;
        auto res_pq_4 = prism_rtl::deref(prism_rtl::deref(res_pq));
        auto st_p1_5 = st_p1;
        call_then(start_conv_types(cx_p0_2, st_p1_5, ps_pp_3), [=, color_po_1 = std::move(color_po_1), res_pq_4 = std::move(res_pq_4)](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_2099) {
        return ({
            auto [xs_ps, st2_pt] = conv_types_2099;
            call_then(start_conv_type(cx_p0_2, st2_pt, res_pq_4), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_2145) {
            return ({
                auto [r_pu, st3_pv] = conv_type_2145;
                auto c_pr = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::Col> _v;
                    if (prism_rtl::is<crate::syntax::Color::Bounded>(color_po_1)) {
                        _v.set(prism_rtl::deref(cx_p0_2).unwritten);
                        goto _done;
                    }
                    if (prism_rtl::is<crate::syntax::Color::Unbounded>(color_po_1)) {
                        _v.set(crate::check::types::Col(crate::check::types::Col::CUnbound{}));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::syntax::Color::ColorVar>(color_po_1)) {
                        auto&& v_p10 = prism_rtl::as<crate::syntax::Color::ColorVar>(color_po_1).a0;
                        _v.set(prism_rtl::deref(v_p10).name == Text::lit("bounded")
                            ? crate::check::types::Col(crate::check::types::Col::CBound{})
                            : crate::check::types::Col(crate::check::types::Col::CQ{prism_rtl::deref(v_p10).name}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyFn{c_pr, xs_ps, prism_rtl::rc(r_pu)}), st3_pv}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m) ? ({
        auto&& ty_p11 = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& row_t_p12 = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        ({
        auto cx_p0_1 = cx_p0;
        auto row_t_p12_2 = prism_rtl::deref(prism_rtl::deref(row_t_p12));
        auto st_p1_3 = st_p1;
        auto ty_p11_4 = prism_rtl::deref(prism_rtl::deref(ty_p11));
        call_then(start_conv_row(cx_p0_1, st_p1_3, row_t_p12_2), [=, ty_p11_4 = std::move(ty_p11_4)](std::tuple<crate::check::types::Rw, crate::check::types::St> conv_row_2412) {
        return ({
            auto [rw_p14, st2_p15] = conv_row_2412;
            auto inner_p13 = ({
                Cx_ this_ = cx_p0_1;
                this_.scope = rw_p14;
                (std::move(this_));
            });
            (prism_rtl::more(prism_rtl::rc(ConvType(inner_p13, st2_p15, ty_p11_4))));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TUnit>(_m) ? ({
        auto&& sigils_p16 = prism_rtl::as<crate::syntax::TypeKind::TUnit>(_m).a0;
        prism_rtl::finished(std::tuple{crate::check::types::with_marks(sigils_p16, crate::check::types::t_unit(), prism_rtl::deref(cx_p0).scope), st_p1});
    })
        : prism_rtl::is<crate::syntax::TypeKind::TAny>(_m) ? ({
        auto&& tr_p17 = prism_rtl::as<crate::syntax::TypeKind::TAny>(_m).a0;
        ({
        auto&& _m = crate::check::env::names::resolve_trait(prism_rtl::deref(cx_p0).g, prism_rtl::deref(cx_p0).home, tr_p17->path_);
        prism_rtl::is_some(_m) ? ({
        auto&& k_p18 = prism_rtl::some_of(_m);
        prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAny{Array(std::vector{k_p18})}), st_p1});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unknown-name"), prism_rtl::deref(tr_p17).span, prism_rtl::cat("no trait `^", crate::check::env::dotted(tr_p17->path_), "`"))})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TAbsent>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), prism_rtl::deref(t_p2).span, Text::lit("this checker does not implement sparse tuples"))})
        : prism_rtl::is<crate::syntax::TypeKind::TNonEmpty>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), prism_rtl::deref(t_p2).span, Text::lit("this checker does not implement non-empty arrays"))})
        : prism_rtl::is<crate::syntax::TypeKind::THole>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), prism_rtl::deref(t_p2).span, Text::lit("this checker does not implement higher-kinded traits"))})
        : prism_rtl::is<crate::syntax::TypeKind::TFamily>(_m) ? ({
        auto&& q_p19 = prism_rtl::as<crate::syntax::TypeKind::TFamily>(_m).a0;
        prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("kind"), prism_rtl::deref(t_p2).span, prism_rtl::cat("`", crate::check::env::dotted(q_p19->path_), ".*` is a row, not a type"))});
    })
        : prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("kind"), prism_rtl::deref(t_p2).span, Text::lit("a row is not a type"))})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ConvType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_conv_type(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2) {
    return prism_rtl::make_rc<ConvType>(cx_p0, st_p1, t_p2);
}


/// ConvTypes: unbounded fn Cx, St, [Type] -> (([Ty], St))
std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types(const Cx_& cx_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Type>& ts_p2) {
    return run_to_end(fold_job(ts_p2, std::tuple{Array<crate::check::types::Ty>{}, st_p1}, ({
        auto cx_p0_1 = cx_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Type>)>>(prism_rtl::rc([=, cx_p0_1 = std::move(cx_p0_1)](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx_p0_1_2 = cx_p0_1;
            entered(once_job([=, cx_p0_1_2 = std::move(cx_p0_1_2)]() {
            return ({
                auto [acc_p3, s_p4] = p0;
                auto x_p5 = p1;
                call_then(start_conv_type(cx_p0_1_2, s_p4, x_p5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_3422) {
                return ({
                    auto [y_p6, s2_p7] = conv_type_3422;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p3, y_p6), s2_p7}));
                });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> ConvTypes::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& st_p1 = this->st_p1;
    const auto& ts_p2 = this->ts_p2;
    return fold_job(ts_p2, std::tuple{Array<crate::check::types::Ty>{}, st_p1}, ({
        auto cx_p0_1 = cx_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Type>)>>(prism_rtl::rc([=, cx_p0_1 = std::move(cx_p0_1)](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx_p0_1_2 = cx_p0_1;
            entered(once_job([=, cx_p0_1_2 = std::move(cx_p0_1_2)]() {
            return ({
                auto [acc_p3, s_p4] = p0;
                auto x_p5 = p1;
                call_then(start_conv_type(cx_p0_1_2, s_p4, x_p5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_3422) {
                return ({
                    auto [y_p6, s2_p7] = conv_type_3422;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p3, y_p6), s2_p7}));
                });
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start ConvTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> start_conv_types(Cx_ cx_p0, crate::check::types::St st_p1, Array<crate::syntax::Type> ts_p2) {
    return prism_rtl::make_rc<ConvTypes>(cx_p0, st_p1, ts_p2);
}


/// ConvNamed: unbounded fn Cx, St, SName, [Type], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> conv_named(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::SName& n_p2, const Array<crate::syntax::Type>& args_p3, const crate::syntax::Range& span_p4) {
    auto name_p5 = crate::check::env::dotted(n_p2.path_);
    return (len(n_p2.path_) == Nat(1u)) && crate::check::env::is_lower_text(name_p5)
        ? len(args_p3) > Nat(0u)
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), span_p4, Text::lit("this checker does not implement higher-kinded traits"))}
        : std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyQ{name_p5}), st_p1}
        : (name_p5 == Text::lit("Element")) || (name_p5 == Text::lit("Prelude.Element"))
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = len(args_p3);
        {
            auto&& m4019_0 = _m;
            if (m4019_0 == Nat(0u)) {
                _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{cx_p0.scope, prism_rtl::rc(crate::check::types::t_unit())}), st_p1});
                goto _done;
            }
        }
        {
            auto&& m4019_1 = _m;
            if (m4019_1 == Nat(1u)) {
                _v.set(({
                    auto [o_p6, st2_p7] = conv_type(cx_p0, st_p1, or_(index(args_p3, Nat(0u)), dummy_type()));
                    std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{cx_p0.scope, prism_rtl::rc(o_p6)}), st2_p7};
                }));
                goto _done;
            }
        }
        {
            auto&& m4019_2 = _m;
            if (m4019_2 == Nat(2u)) {
                _v.set(({
                    auto [rw_p8, st2_p9] = conv_row(cx_p0, st_p1, or_(index(args_p3, Nat(0u)), dummy_type()));
                    auto [o_pa, st3_pb] = conv_type(cx_p0, st2_p9, or_(index(args_p3, Nat(1u)), dummy_type()));
                    std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{rw_p8, prism_rtl::rc(o_pa)}), st3_pb};
                }));
                goto _done;
            }
        }
        {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("kind"), span_p4, prism_rtl::cat("`Element` takes a row and a type; here it has ", crate::check::errors::count_word(len(args_p3))))});
            goto _done;
        }
    _done:
        _v.take();
    })
        : name_p5 == Text::lit("Elem")
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = len(args_p3);
        {
            auto&& m4588_0 = _m;
            if (m4588_0 == Nat(0u)) {
                _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElemAny{cx_p0.scope}), st_p1});
                goto _done;
            }
        }
        {
            auto&& m4588_1 = _m;
            if (m4588_1 == Nat(1u)) {
                _v.set(({
                    auto [rw_pc, st2_pd] = conv_row(cx_p0, st_p1, or_(index(args_p3, Nat(0u)), dummy_type()));
                    std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElemAny{rw_pc}), st2_pd};
                }));
                goto _done;
            }
        }
        {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("kind"), span_p4, prism_rtl::cat("`Elem` takes a row; here it has ", crate::check::errors::count_word(len(args_p3))))});
            goto _done;
        }
    _done:
        _v.take();
    })
        : (name_p5 == Text::lit("Answer")) || (name_p5 == Text::lit("Wired"))
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{name_p5, Array<crate::check::types::Ty>{}}), st_p1}
        : name_p5 == Text::lit("Instant")
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), span_p4, Text::lit("this checker does not implement `Instant`"))}
        : crate::check::types::has_text(Array(std::vector{Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")}), name_p5)
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), span_p4, Text::lit("this checker does not implement sized integers other than `U8`"))}
        : crate::check::env::is_prim_type(name_p5)
        ? len(args_p3) == Nat(0u)
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{name_p5, Array<crate::check::types::Ty>{}}), st_p1}
        : std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("kind"), span_p4, prism_rtl::cat("`", name_p5, "` takes no type; here it has ", crate::check::errors::count_word(len(args_p3))))}
        : (name_p5 == Text::lit("Buffer")) || (name_p5 == Text::lit("Table"))
        ? ({
        auto want_pe = name_p5 == Text::lit("Buffer") ? Nat(1u) : Nat(2u);
        auto [xs_pf, st2_pg] = conv_types(cx_p0, st_p1, args_p3);
        len(args_p3) == want_pe
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{name_p5, xs_pf}), st2_pg}
        : std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st2_pg, Text::lit("kind"), span_p4, prism_rtl::cat("`", name_p5, "` takes ", crate::check::errors::count_word(want_pe), " types; here it has ", crate::check::errors::count_word(len(args_p3))))};
    })
        : ({
        auto [key_oh, why_pi] = crate::check::env::names::resolve_type(cx_p0.g, cx_p0.home, n_p2.path_);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        if (prism_rtl::is_none(key_oh)) {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unknown-name"), span_p4, prism_rtl::cat("no type `", name_p5, "`"))});
            goto _done;
        }
        if (prism_rtl::is_some(key_oh)) {
            auto&& qk_pj = prism_rtl::some_of(key_oh);
            _v.set(({
                auto ti_pk = or_(crate::prelude::get(prism_rtl::deref(cx_p0.g).types, qk_pj), crate::check::env::names::dummy_ty_info());
                auto st1_pl = why_pi == Text::lit("collision")
                    ? crate::check::types::recording::err_fix(st_p1, Text::lit("collision"), span_p4, prism_rtl::cat("`", name_p5, "` is declared by two modules this file reaches by a bare name"), prism_rtl::cat("write it qualified, `", qk_pj, "`, or rename this file\'s own"))
                    : st_p1;
                auto [xs_pm, st2_pn] = conv_types(cx_p0, st1_pl, args_p3);
                len(xs_pm) != len(prism_rtl::deref(ti_pk).params)
                ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st2_pn, Text::lit("kind"), span_p4, prism_rtl::cat("`", name_p5, "` takes ", crate::check::errors::count_word(len(prism_rtl::deref(ti_pk).params)), " type", len(prism_rtl::deref(ti_pk).params) == Nat(1u)
                ? Text::lit("")
                : Text::lit("s"), "; here it has ", crate::check::errors::count_word(len(xs_pm))))}
                : ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                auto&& _m = prism_rtl::deref(ti_pk).body;
                if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
                    auto&& body_po = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
                    _v.set(std::tuple{crate::check::types::schemes::subst_q(param_inst(prism_rtl::deref(ti_pk).params, xs_pm), body_po), st2_pn});
                    goto _done;
                }
                if (prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m)) {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{qk_pj, xs_pm}), st2_pn});
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{qk_pj, xs_pm}), st2_pn});
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> ConvNamed::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& st_p1 = this->st_p1;
    const auto& n_p2 = this->n_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    auto name_p5 = crate::check::env::dotted(n_p2->path_);
    return (len(n_p2->path_) == Nat(1u)) && crate::check::env::is_lower_text(name_p5)
        ? len(args_p3) > Nat(0u)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), span_p4, Text::lit("this checker does not implement higher-kinded traits"))})
        : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyQ{name_p5}), st_p1})
        : (name_p5 == Text::lit("Element")) || (name_p5 == Text::lit("Prelude.Element"))
        ? ({
        auto&& _m = len(args_p3);
        ({
        auto&& m4019_0 = _m;
        (m4019_0 == Nat(0u));
    }) ? ({
        auto&& m4019_0 = _m;
        prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{prism_rtl::deref(cx_p0).scope, prism_rtl::rc(crate::check::types::t_unit())}), st_p1});
    })
        : ({
        auto&& m4019_1 = _m;
        (m4019_1 == Nat(1u));
    }) ? ({
        auto&& m4019_1 = _m;
        ({
        auto args_p3_1 = args_p3;
        auto cx_p0_2 = cx_p0;
        auto st_p1_3 = st_p1;
        call_then(start_conv_type(cx_p0_2, st_p1_3, or_(index(args_p3_1, Nat(0u)), dummy_type())), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_4131) {
        return ({
            auto [o_p6, st2_p7] = conv_type_4131;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{prism_rtl::deref(cx_p0_2).scope, prism_rtl::rc(o_p6)}), st2_p7}));
        });
    });
    });
    })
        : ({
        auto&& m4019_2 = _m;
        (m4019_2 == Nat(2u));
    }) ? ({
        auto&& m4019_2 = _m;
        ({
        auto args_p3_1 = args_p3;
        auto cx_p0_2 = cx_p0;
        auto st_p1_3 = st_p1;
        call_then(start_conv_row(cx_p0_2, st_p1_3, or_(index(args_p3_1, Nat(0u)), dummy_type())), [=](std::tuple<crate::check::types::Rw, crate::check::types::St> conv_row_4267) {
        return ({
            auto [rw_p8, st2_p9] = conv_row_4267;
            call_then(start_conv_type(cx_p0_2, st2_p9, or_(index(args_p3_1, Nat(1u)), dummy_type())), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_4340) {
            return ({
                auto [o_pa, st3_pb] = conv_type_4340;
                (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{rw_p8, prism_rtl::rc(o_pa)}), st3_pb}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("kind"), span_p4, prism_rtl::cat("`Element` takes a row and a type; here it has ", crate::check::errors::count_word(len(args_p3))))});
    })
        : name_p5 == Text::lit("Elem")
        ? ({
        auto&& _m = len(args_p3);
        ({
        auto&& m4588_0 = _m;
        (m4588_0 == Nat(0u));
    }) ? ({
        auto&& m4588_0 = _m;
        prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElemAny{prism_rtl::deref(cx_p0).scope}), st_p1});
    })
        : ({
        auto&& m4588_1 = _m;
        (m4588_1 == Nat(1u));
    }) ? ({
        auto&& m4588_1 = _m;
        ({
        auto args_p3_1 = args_p3;
        auto cx_p0_2 = cx_p0;
        auto st_p1_3 = st_p1;
        call_then(start_conv_row(cx_p0_2, st_p1_3, or_(index(args_p3_1, Nat(0u)), dummy_type())), [=](std::tuple<crate::check::types::Rw, crate::check::types::St> conv_row_4695) {
        return ({
            auto [rw_pc, st2_pd] = conv_row_4695;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElemAny{rw_pc}), st2_pd}));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("kind"), span_p4, prism_rtl::cat("`Elem` takes a row; here it has ", crate::check::errors::count_word(len(args_p3))))});
    })
        : (name_p5 == Text::lit("Answer")) || (name_p5 == Text::lit("Wired"))
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{name_p5, Array<crate::check::types::Ty>{}}), st_p1})
        : name_p5 == Text::lit("Instant")
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), span_p4, Text::lit("this checker does not implement `Instant`"))})
        : crate::check::types::has_text(Array(std::vector{Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")}), name_p5)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), span_p4, Text::lit("this checker does not implement sized integers other than `U8`"))})
        : crate::check::env::is_prim_type(name_p5)
        ? len(args_p3) == Nat(0u)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{name_p5, Array<crate::check::types::Ty>{}}), st_p1})
        : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("kind"), span_p4, prism_rtl::cat("`", name_p5, "` takes no type; here it has ", crate::check::errors::count_word(len(args_p3))))})
        : (name_p5 == Text::lit("Buffer")) || (name_p5 == Text::lit("Table"))
        ? ({
        auto want_pe = name_p5 == Text::lit("Buffer") ? Nat(1u) : Nat(2u);
        auto args_p3_1 = args_p3;
        auto cx_p0_2 = cx_p0;
        auto span_p4_3 = span_p4;
        auto st_p1_4 = st_p1;
        call_then(start_conv_types(cx_p0_2, st_p1_4, args_p3_1), [=, want_pe = std::move(want_pe), span_p4_3 = std::move(span_p4_3)](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_5630) {
        return ({
            auto [xs_pf, st2_pg] = conv_types_5630;
            len(args_p3_1) == want_pe
            ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{name_p5, xs_pf}), st2_pg})
            : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st2_pg, Text::lit("kind"), span_p4_3, prism_rtl::cat("`", name_p5, "` takes ", crate::check::errors::count_word(want_pe), " types; here it has ", crate::check::errors::count_word(len(args_p3_1))))});
        });
    });
    })
        : ({
        auto [key_oh, why_pi] = crate::check::env::names::resolve_type(prism_rtl::deref(cx_p0).g, prism_rtl::deref(cx_p0).home, n_p2->path_);
        ({
        prism_rtl::is_none(key_oh) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unknown-name"), span_p4, prism_rtl::cat("no type `", name_p5, "`"))})
        : prism_rtl::is_some(key_oh) ? ({
        auto&& qk_pj = prism_rtl::some_of(key_oh);
        ({
        auto ti_pk = or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(cx_p0).g).types, qk_pj), crate::check::env::names::dummy_ty_info());
        auto st1_pl = why_pi == Text::lit("collision")
            ? crate::check::types::recording::err_fix(st_p1, Text::lit("collision"), span_p4, prism_rtl::cat("`", name_p5, "` is declared by two modules this file reaches by a bare name"), prism_rtl::cat("write it qualified, `", qk_pj, "`, or rename this file\'s own"))
            : st_p1;
        auto args_p3_1 = args_p3;
        auto cx_p0_2 = cx_p0;
        auto qk_pj_3 = qk_pj;
        auto span_p4_4 = span_p4;
        call_then(start_conv_types(cx_p0_2, st1_pl, args_p3_1), [=, ti_pk = std::move(ti_pk), qk_pj_3 = std::move(qk_pj_3), span_p4_4 = std::move(span_p4_4)](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_6331) {
        return ({
            auto [xs_pm, st2_pn] = conv_types_6331;
            len(xs_pm) != len(prism_rtl::deref(ti_pk).params)
            ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st2_pn, Text::lit("kind"), span_p4_4, prism_rtl::cat("`", name_p5, "` takes ", crate::check::errors::count_word(len(prism_rtl::deref(ti_pk).params)), " type", len(prism_rtl::deref(ti_pk).params) == Nat(1u)
            ? Text::lit("")
            : Text::lit("s"), "; here it has ", crate::check::errors::count_word(len(xs_pm))))})
            : ({
            auto&& _m = prism_rtl::deref(ti_pk).body;
            prism_rtl::is<crate::check::env::TyBody::BAlias>(_m) ? ({
            auto&& body_po = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
            ({
            auto body_po_5 = body_po;
            call_then(crate::check::types::schemes::start_subst_q(param_inst(prism_rtl::deref(ti_pk).params, xs_pm), body_po_5), [=](crate::check::types::Ty subst_q_6655) { return prism_rtl::finished(std::tuple{subst_q_6655, st2_pn}); });
        });
        })
            : prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{qk_pj_3, xs_pm}), st2_pn})
            : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{qk_pj_3, xs_pm}), st2_pn});
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start ConvNamed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_conv_named(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, Array<crate::syntax::Type> args_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<ConvNamed>(cx_p0, st_p1, n_p2, args_p3, span_p4);
}


/// let dummyType
crate::syntax::Type dummy_type() {
    return crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TAbsent{})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// ParamInst: fn [Text], [Ty] -> Inst
crate::check::types::schemes::Inst param_inst(const Array<Text>& ps_p0, const Array<crate::check::types::Ty>& xs_p1) {
    return crate::check::types::schemes::Inst{.tys = fold(crate::check::errors::range0(len(ps_p0)), Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m_p2, const Nat& i_p3) { return insert(m_p2, or_(index(ps_p0, i_p3), Text::lit("")), or_(index(xs_p1, i_p3), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))); }), .rows = Map<Text, crate::check::types::Tail>{}, .cols = Map<Text, crate::check::types::Col>{}};
}


/// ConvRow: unbounded fn Cx, St, Type -> ((Rw, St))
std::tuple<crate::check::types::Rw, crate::check::types::St> conv_row(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::Type& t_p2) {
    auto [fams_p5, vars_p6, st2_p7] = row_parts(cx_p0, st_p1, t_p2);
    auto st3_p3 = len(vars_p6) > Nat(1u)
        ? crate::check::types::recording::err_fix(st2_p7, Text::lit("row-two-tails"), t_p2.span, prism_rtl::cat("a row has one variable; `", crate::syntax::lexer::chars::join(vars_p6, Text::lit(" | ")), "` names two"), Text::lit("keep one variable"))
        : st2_p7;
    auto tail_p4 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Tail> _v;
        auto&& _m = index(vars_p6, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& v_p8 = prism_rtl::some_of(_m);
            _v.set(crate::check::types::Tail(crate::check::types::Tail::TlQ{v_p8}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::check::types::Tail(crate::check::types::Tail::TlClosed{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return std::tuple{crate::check::types::Rw{.fams = crate::check::types::sort_texts(fams_p5), .minus = Array<Text>{}, .tail = tail_p4}, st3_p3};
}


prism_rtl::Turn<std::tuple<crate::check::types::Rw, crate::check::types::St>> ConvRow::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    auto cx_p0_1 = cx_p0;
    auto st_p1_2 = st_p1;
    auto t_p2_3 = t_p2;
    return call_then(start_row_parts(cx_p0_1, st_p1_2, t_p2_3), [=](std::tuple<Array<Text>, Array<Text>, crate::check::types::St> row_parts_7214) {
        return ({
            auto [fams_p5, vars_p6, st2_p7] = row_parts_7214;
            auto st3_p3 = len(vars_p6) > Nat(1u)
                ? crate::check::types::recording::err_fix(st2_p7, Text::lit("row-two-tails"), prism_rtl::deref(t_p2_3).span, prism_rtl::cat("a row has one variable; `", crate::syntax::lexer::chars::join(vars_p6, Text::lit(" | ")), "` names two"), Text::lit("keep one variable"))
                : st2_p7;
            auto tail_p4 = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::Tail> _v;
                auto&& _m = index(vars_p6, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& v_p8 = prism_rtl::some_of(_m);
                    _v.set(crate::check::types::Tail(crate::check::types::Tail::TlQ{v_p8}));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::check::types::Tail(crate::check::types::Tail::TlClosed{}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(std::tuple{crate::check::types::Rw{.fams = crate::check::types::sort_texts(fams_p5), .minus = Array<Text>{}, .tail = tail_p4}, st3_p3}));
        });
    });
}


/// `Start ConvRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Rw, crate::check::types::St>> start_conv_row(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2) {
    return prism_rtl::make_rc<ConvRow>(cx_p0, st_p1, t_p2);
}


/// RowParts: unbounded fn Cx, St, Type -> (([Text], [Text], St))
std::tuple<Array<Text>, Array<Text>, crate::check::types::St> row_parts(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::Type& t_p2) {
    auto&& _m = prism_rtl::deref(t_p2.kind);
    if (prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m)) {
        auto&& ts_p3 = prism_rtl::as<crate::syntax::TypeKind::TRowUnion>(_m).a0;
        return run_to_end(fold_job(ts_p3, std::tuple{Array<Text>{}, Array<Text>{}, st_p1}, ({
            auto cx_p0_1 = cx_p0;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>>(std::tuple<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>, crate::syntax::Type>)>>(prism_rtl::rc([=, cx_p0_1 = std::move(cx_p0_1)](std::tuple<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx_p0_1_2 = cx_p0_1;
                entered(once_job([=, cx_p0_1_2 = std::move(cx_p0_1_2)]() {
                return ({
                    auto [fs_p4, vs_p5, s_p6] = p0;
                    auto x_p7 = p1;
                    call_then(start_row_parts(cx_p0_1_2, s_p6, x_p7), [=](std::tuple<Array<Text>, Array<Text>, crate::check::types::St> row_parts_7721) {
                    return ({
                        auto [f2_p8, v2_p9, s2_pa] = row_parts_7721;
                        (prism_rtl::finished(std::tuple{append(fs_p4, f2_p8), append(vs_p5, v2_p9), s2_pa}));
                    });
                });
                });
            }));
            });
        }));
        })));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_pb = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return row_parts(cx_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_pb)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFamily>(_m)) {
        auto&& q_pc = prism_rtl::as<crate::syntax::TypeKind::TFamily>(_m).a0;
        return std::tuple{Array(std::vector{crate::check::env::dotted(q_pc->path_)}), Array<Text>{}, crate::check::env::names::check_family(cx_p0.g, st_p1, crate::check::env::dotted(q_pc->path_), prism_rtl::deref(q_pc).span)};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n_pd = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m7611_3_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        if (m7611_3_1.size() == 0u) {
            auto name_pe = crate::check::env::dotted(n_pd->path_);
            return (len(n_pd->path_) == Nat(1u)) && crate::check::env::is_lower_text(name_pe)
                ? std::tuple{Array<Text>{}, Array(std::vector{name_pe}), st_p1}
                : name_pe == Text::lit("Element")
                ? std::tuple{prism_rtl::deref(cx_p0.scope).fams, tail_names(prism_rtl::deref(cx_p0.scope).tail), st_p1}
                : std::tuple{Array<Text>{}, Array<Text>{}, crate::check::types::recording::err_fix(st_p1, Text::lit("row-single-tag"), t_p2.span, prism_rtl::cat("a row names families, not tags: `", name_pe, "`"), prism_rtl::cat("write `", crate::check::env::dotted(take(n_pd->path_, crate::syntax::lexer::chars::dec(len(n_pd->path_)))), ".*`"))};
        }
    }
    {
        return std::tuple{Array<Text>{}, Array<Text>{}, crate::check::types::recording::err(st_p1, Text::lit("kind"), t_p2.span, Text::lit("this is not a row"))};
    }
}


prism_rtl::Turn<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>> RowParts::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p2).kind);
        prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m) ? ({
        auto&& ts_p3 = prism_rtl::as<crate::syntax::TypeKind::TRowUnion>(_m).a0;
        fold_job(ts_p3, std::tuple{Array<Text>{}, Array<Text>{}, st_p1}, ({
        auto cx_p0_1 = cx_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>>(std::tuple<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>, crate::syntax::Type>)>>(prism_rtl::rc([=, cx_p0_1 = std::move(cx_p0_1)](std::tuple<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx_p0_1_2 = cx_p0_1;
            entered(once_job([=, cx_p0_1_2 = std::move(cx_p0_1_2)]() {
            return ({
                auto [fs_p4, vs_p5, s_p6] = p0;
                auto x_p7 = p1;
                call_then(start_row_parts(cx_p0_1_2, s_p6, x_p7), [=](std::tuple<Array<Text>, Array<Text>, crate::check::types::St> row_parts_7721) {
                return ({
                    auto [f2_p8, v2_p9, s2_pa] = row_parts_7721;
                    (prism_rtl::finished(std::tuple{append(fs_p4, f2_p8), append(vs_p5, v2_p9), s2_pa}));
                });
            });
            });
        }));
        });
    }));
    }))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_pb = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RowParts(cx_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_pb)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFamily>(_m) ? ({
        auto&& q_pc = prism_rtl::as<crate::syntax::TypeKind::TFamily>(_m).a0;
        prism_rtl::finished(std::tuple{Array(std::vector{crate::check::env::dotted(q_pc->path_)}), Array<Text>{}, crate::check::env::names::check_family(prism_rtl::deref(cx_p0).g, st_p1, crate::check::env::dotted(q_pc->path_), prism_rtl::deref(q_pc).span)});
    })
        : prism_rtl::is<crate::syntax::TypeKind::TName>(_m) && ({
        auto&& n_pd = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m7611_3_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        (m7611_3_1.size() == 0u);
    }) ? ({
        auto&& n_pd = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m7611_3_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        ({
        auto name_pe = crate::check::env::dotted(n_pd->path_);
        (len(n_pd->path_) == Nat(1u)) && crate::check::env::is_lower_text(name_pe)
        ? prism_rtl::finished(std::tuple{Array<Text>{}, Array(std::vector{name_pe}), st_p1})
        : name_pe == Text::lit("Element")
        ? prism_rtl::finished(std::tuple{prism_rtl::deref(prism_rtl::deref(cx_p0).scope).fams, tail_names(prism_rtl::deref(prism_rtl::deref(cx_p0).scope).tail), st_p1})
        : prism_rtl::finished(std::tuple{Array<Text>{}, Array<Text>{}, crate::check::types::recording::err_fix(st_p1, Text::lit("row-single-tag"), prism_rtl::deref(t_p2).span, prism_rtl::cat("a row names families, not tags: `", name_pe, "`"), prism_rtl::cat("write `", crate::check::env::dotted(take(n_pd->path_, crate::syntax::lexer::chars::dec(len(n_pd->path_)))), ".*`"))});
    });
    })
        : prism_rtl::finished(std::tuple{Array<Text>{}, Array<Text>{}, crate::check::types::recording::err(st_p1, Text::lit("kind"), prism_rtl::deref(t_p2).span, Text::lit("this is not a row"))});
    });
}


/// `Start RowParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>> start_row_parts(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2) {
    return prism_rtl::make_rc<RowParts>(cx_p0, st_p1, t_p2);
}


/// TailNames: fn Tail -> [Text]
Array<Text> tail_names(const crate::check::types::Tail& tail0) {
    if (prism_rtl::is<crate::check::types::Tail::TlQ>(tail0)) {
        auto&& v_p0 = prism_rtl::as<crate::check::types::Tail::TlQ>(tail0).a0;
        return Array(std::vector{v_p0});
    }
    if (prism_rtl::is<crate::check::types::Tail::TlRigid>(tail0)) {
        auto&& v_p1 = prism_rtl::as<crate::check::types::Tail::TlRigid>(tail0).a0;
        return Array(std::vector{v_p1});
    }
    {
        return Array<Text>{};
    }
}


/// SigScheme: unbounded fn Cx, St, Type, [Bound] -> ((Scheme, St))
std::tuple<crate::check::types::Scheme, crate::check::types::St> sig_scheme(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::Type& t_p2, const Array<crate::syntax::decls::Bound>& bounds_p3) {
    auto row_vars_p4 = crate::check::types::union_texts(cx_p0.row_vars, row_vars_of_type(t_p2));
    auto cx2_p5 = ({
        Cx_ this_ = cx_p0;
        this_.row_vars = row_vars_p4;
        this_.unwritten = crate::check::types::Col(crate::check::types::Col::CBound{});
        (std::move(this_));
    });
    auto written_p6 = color_vars_of_type(t_p2);
    auto [ty_pa, defaults_pb, joins_pc, st2_pd] = sig_type(cx2_p5, st_p1, t_p2, written_p6);
    auto tvs_p7 = filter(type_vars_of_type(t_p2), [&](const Text& v_pe) { return !crate::check::types::has_text(row_vars_p4, v_pe); });
    auto cqs_p8 = fold(defaults_pb, written_p6, [&](const Array<Text>& acc_pf, const Text& v_pg) { return crate::check::types::add_text(acc_pf, v_pg); });
    auto [bs_ph, st3_pi] = conv_bounds(cx_p0, st2_pd, bounds_p3);
    auto rows_used_p9 = run_to_end(filter_job(row_vars_p4, ({
        auto t_p2_1 = t_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, t_p2_1 = std::move(t_p2_1)](Text p0) {
        return ({
            auto t_p2_1_2 = t_p2_1;
            entered(once_job([=, t_p2_1_2 = std::move(t_p2_1_2)]() {
            return ({
                auto v_pj = p0;
                call_then(start_row_vars_of_type(t_p2_1_2), [=, v_pj = std::move(v_pj)](Array<Text> row_vars_of_type_9242) { return prism_rtl::finished(crate::check::types::has_text(row_vars_of_type_9242, v_pj) || uses_scope(t_p2_1_2)); });
            });
        }));
        });
    })));
    })));
    return std::tuple{crate::check::types::Scheme{.qs = tvs_p7, .plain_qs = Array<Text>{}, .rqs = rows_used_p9, .cqs = cqs_p8, .cjoins = joins_pc, .bounds = bs_ph, .ty = ty_pa}, st3_pi};
}


prism_rtl::Turn<std::tuple<crate::check::types::Scheme, crate::check::types::St>> SigScheme::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    const auto& bounds_p3 = this->bounds_p3;
    auto bounds_p3_1 = bounds_p3;
    auto cx_p0_2 = cx_p0;
    auto st_p1_3 = st_p1;
    auto t_p2_4 = t_p2;
    return call_then(start_row_vars_of_type(t_p2_4), [=](Array<Text> row_vars_of_type_8803) {
        return ({
            auto row_vars_p4 = crate::check::types::union_texts(prism_rtl::deref(cx_p0_2).row_vars, row_vars_of_type_8803);
            auto cx2_p5 = ({
                Cx_ this_ = cx_p0_2;
                this_.row_vars = row_vars_p4;
                this_.unwritten = crate::check::types::Col(crate::check::types::Col::CBound{});
                (std::move(this_));
            });
            call_then(start_color_vars_of_type(t_p2_4), [=, row_vars_p4 = std::move(row_vars_p4), cx2_p5 = std::move(cx2_p5)](Array<Text> color_vars_of_type_8924) {
            return ({
                auto written_p6 = color_vars_of_type_8924;
                call_then(start_sig_type(cx2_p5, st_p1_3, t_p2_4, written_p6), [=](std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St> sig_type_8981) {
                return ({
                    auto [ty_pa, defaults_pb, joins_pc, st2_pd] = sig_type_8981;
                    call_then(start_type_vars_of_type(t_p2_4), [=](Array<Text> type_vars_of_type_9031) {
                    return ({
                        auto tvs_p7 = filter(type_vars_of_type_9031, [&](const Text& v_pe) { return !crate::check::types::has_text(row_vars_p4, v_pe); });
                        auto cqs_p8 = fold(defaults_pb, written_p6, [&](const Array<Text>& acc_pf, const Text& v_pg) { return crate::check::types::add_text(acc_pf, v_pg); });
                        auto [bs_ph, st3_pi] = conv_bounds(cx_p0_2, st2_pd, bounds_p3_1);
                        call_value(filter_job(row_vars_p4, ({
                        auto t_p2_4_5 = t_p2_4;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, t_p2_4_5 = std::move(t_p2_4_5)](Text p0) {
                        return ({
                            auto t_p2_4_5_5 = t_p2_4_5;
                            entered(once_job([=, t_p2_4_5_5 = std::move(t_p2_4_5_5)]() {
                            return ({
                                auto v_pj = p0;
                                call_then(start_row_vars_of_type(t_p2_4_5_5), [=, v_pj = std::move(v_pj)](Array<Text> row_vars_of_type_9242) { return prism_rtl::finished(crate::check::types::has_text(row_vars_of_type_9242, v_pj) || uses_scope(t_p2_4_5_5)); });
                            });
                        }));
                        });
                    })));
                    })), [=, tvs_p7 = std::move(tvs_p7), cqs_p8 = std::move(cqs_p8)](Array<Text> filter_9211) {
                        return ({
                            auto rows_used_p9 = filter_9211;
                            (prism_rtl::finished(std::tuple{crate::check::types::Scheme{.qs = tvs_p7, .plain_qs = Array<Text>{}, .rqs = rows_used_p9, .cqs = cqs_p8, .cjoins = joins_pc, .bounds = bs_ph, .ty = ty_pa}, st3_pi}));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start SigScheme, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Scheme, crate::check::types::St>> start_sig_scheme(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2, Array<crate::syntax::decls::Bound> bounds_p3) {
    return prism_rtl::make_rc<SigScheme>(cx_p0, st_p1, t_p2, bounds_p3);
}


/// SigType: unbounded fn Cx, St, Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St> sig_type(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::Type& t_p2, const Array<Text>& written_p3) {
    auto&& _m = prism_rtl::deref(t_p2.kind);
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_p4 = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return sig_type(cx_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_p4)), written_p3);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& color_p5 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0;
        auto&& ps_p6 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_p7 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return mentions_time(t_p2) || (!takes_closure(t_p2))
            ? bounded_sig(cx_p0, st_p1, t_p2)
            : closure_sig(cx_p0, st_p1, color_p5, ps_p6, prism_rtl::deref(prism_rtl::deref(res_p7)), written_p3);
    }
    {
        return bounded_sig(cx_p0, st_p1, t_p2);
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> SigType::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    const auto& written_p3 = this->written_p3;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p2).kind);
        prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_p4 = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(SigType(cx_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_p4)), written_p3)));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& color_p5 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0;
        auto&& ps_p6 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_p7 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto color_p5_1 = color_p5;
        auto cx_p0_2 = cx_p0;
        auto ps_p6_3 = ps_p6;
        auto res_p7_4 = prism_rtl::deref(prism_rtl::deref(res_p7));
        auto st_p1_5 = st_p1;
        auto t_p2_6 = t_p2;
        auto written_p3_7 = written_p3;
        call_then(start_mentions_time(t_p2_6), [=, color_p5_1 = std::move(color_p5_1), cx_p0_2 = std::move(cx_p0_2), ps_p6_3 = std::move(ps_p6_3), res_p7_4 = std::move(res_p7_4), st_p1_5 = std::move(st_p1_5), written_p3_7 = std::move(written_p3_7)](bool mentions_time_10384) {
        return mentions_time_10384 || (!takes_closure(t_p2_6))
            ? prism_rtl::more(prism_rtl::rc(BoundedSig(cx_p0_2, st_p1_5, t_p2_6)))
            : prism_rtl::more(prism_rtl::rc(ClosureSig(cx_p0_2, st_p1_5, color_p5_1, ps_p6_3, res_p7_4, written_p3_7)));
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(BoundedSig(cx_p0, st_p1, t_p2)));
    });
}


/// `Start SigType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> start_sig_type(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2, Array<Text> written_p3) {
    return prism_rtl::make_rc<SigType>(cx_p0, st_p1, t_p2, written_p3);
}


/// BoundedSig: unbounded fn Cx, St, Type -> ((Ty, [Text], [((Text, Text))], St))
std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St> bounded_sig(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::Type& t_p2) {
    auto [ty_p3, st2_p4] = conv_type(cx_p0, st_p1, t_p2);
    return std::tuple{ty_p3, Array<Text>{}, Array<std::tuple<Text, Text>>{}, st2_p4};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> BoundedSig::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    auto cx_p0_1 = cx_p0;
    auto st_p1_2 = st_p1;
    auto t_p2_3 = t_p2;
    return call_then(start_conv_type(cx_p0_1, st_p1_2, t_p2_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_10665) {
        return ({
            auto [ty_p3, st2_p4] = conv_type_10665;
            (prism_rtl::finished(std::tuple{ty_p3, Array<Text>{}, Array<std::tuple<Text, Text>>{}, st2_p4}));
        });
    });
}


/// `Start BoundedSig, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> start_bounded_sig(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2) {
    return prism_rtl::make_rc<BoundedSig>(cx_p0, st_p1, t_p2);
}


/// ClosureSig: unbounded fn Cx, St, Color, [Type], Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St> closure_sig(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::Color& color_p2, const Array<crate::syntax::Type>& ps_p3, const crate::syntax::Type& res_p4, const Array<Text>& written_p5) {
    auto [outer_set_ph, outer_w_pi] = written_col(color_p2);
    auto bounded_outer_p6 = outer_set_ph && (outer_w_pi == crate::check::types::Col(crate::check::types::Col::CBound{}));
    auto n_default_p7 = len(run_to_end(filter_job(ps_p3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::syntax::Type)>>(prism_rtl::rc([=](crate::syntax::Type p0) {
        return entered(once_job([=]() {
            return ({
                auto p_pj = p0;
                call_then(start_is_fn_type(p_pj), [=](bool is_fn_type_11003) { return prism_rtl::finished(is_fn_type_11003 && (!writes_col(top_color(p_pj)))); });
            });
        }));
    })))));
    auto names_p8 = fresh_col_names(written_p5, std::move(bounded_outer_p6) ? Nat(0u) : n_default_p7);
    auto&& _pcols_pp = run_to_end(fold_job(ps_p3, std::tuple{Array<std::tuple<bool, crate::check::types::Col>>{}, Nat(0u)}, ({
        auto bounded_outer_p6_1 = std::move(bounded_outer_p6);
        auto names_p8_2 = names_p8;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<bool, crate::check::types::Col>>, Nat>>(std::tuple<std::tuple<Array<std::tuple<bool, crate::check::types::Col>>, Nat>, crate::syntax::Type>)>>(prism_rtl::rc([=, bounded_outer_p6_1 = std::move(bounded_outer_p6_1), names_p8_2 = std::move(names_p8_2)](std::tuple<std::tuple<Array<std::tuple<bool, crate::check::types::Col>>, Nat>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto bounded_outer_p6_1_3 = bounded_outer_p6_1;
            auto names_p8_2_3 = names_p8_2;
            entered(once_job([=, bounded_outer_p6_1_3 = std::move(bounded_outer_p6_1_3), names_p8_2_3 = std::move(names_p8_2_3)]() {
            return ({
                auto [acc_pk, k_pl] = p0;
                auto p_pm = p1;
                call_then(start_is_fn_type(p_pm), [=](bool is_fn_type_11280) {
                return !is_fn_type_11280
                    ? prism_rtl::finished(std::tuple{crate::prelude::push(acc_pk, std::tuple{false, crate::check::types::Col(crate::check::types::Col::CBound{})}), k_pl})
                    : call_then(start_top_color(p_pm), [=](crate::syntax::Color top_color_11385) {
                    return ({
                        auto [set_pn, c_po] = written_col(top_color_11385);
                        set_pn
                        ? prism_rtl::finished(std::tuple{crate::prelude::push(acc_pk, std::tuple{true, c_po}), k_pl})
                        : bounded_outer_p6_1_3
                        ? prism_rtl::finished(std::tuple{crate::prelude::push(acc_pk, std::tuple{true, crate::check::types::Col(crate::check::types::Col::CBound{})}), k_pl})
                        : prism_rtl::finished(std::tuple{crate::prelude::push(acc_pk, std::tuple{true, crate::check::types::Col(crate::check::types::Col::CQ{or_(index(names_p8_2_3, k_pl), Text::lit("u"))})}), k_pl + Nat(1u)});
                    });
                });
            });
            });
        }));
        });
    }));
    })));
    auto&& pcols_pp = std::get<0>(_pcols_pp);
    auto vars_p9 = fold(pcols_pp, Array<Text>{}, [&](const Array<Text>& acc_pq, const std::tuple<bool, crate::check::types::Col>& _p1) {
        auto&& c_pr = std::get<1>(_p1);
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is<crate::check::types::Col::CQ>(c_pr)) {
                auto&& v_ps = prism_rtl::as<crate::check::types::Col::CQ>(c_pr).a0;
                _v.set(crate::check::types::add_text(acc_pq, v_ps));
                goto _done;
            }
            {
                _v.set(acc_pq);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto any_unbounded_pa = fold(pcols_pp, false, [&](const bool& seen_pt, const std::tuple<bool, crate::check::types::Col>& _p1) {
        auto&& c_pu = std::get<1>(_p1);
        return prism_rtl::deref(seen_pt) || (c_pu == crate::check::types::Col(crate::check::types::Col::CUnbound{}));
    });
    auto spare_pb = fresh_col_names(append(written_p5, names_p8), Nat(1u));
    auto outer_name_pc = (outer_set_ph || std::move(any_unbounded_pa)) || (len(vars_p9) < Nat(2u))
        ? Text::lit("")
        : or_(index(spare_pb, Nat(0u)), Text::lit("u"));
    auto outer_pd = outer_set_ph
        ? outer_w_pi
        : std::move(any_unbounded_pa)
        ? crate::check::types::Col(crate::check::types::Col::CUnbound{})
        : len(vars_p9) == Nat(0u)
        ? crate::check::types::Col(crate::check::types::Col::CBound{})
        : len(vars_p9) == Nat(1u)
        ? crate::check::types::Col(crate::check::types::Col::CQ{or_(index(vars_p9, Nat(0u)), Text::lit("u"))})
        : crate::check::types::Col(crate::check::types::Col::CQ{outer_name_pc});
    auto joins_pe = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Text, Text>>> _v;
        if (prism_rtl::is<crate::check::types::Col::CQ>(outer_pd)) {
            auto&& hi_pv = prism_rtl::as<crate::check::types::Col::CQ>(outer_pd).a0;
            _v.set(each(filter(vars_p9, [&](const Text& v_p10) { return v_p10 != hi_pv; }), [&](const Text& v_p11) { return std::tuple{v_p11, hi_pv}; }));
            goto _done;
        }
        {
            _v.set(Array<std::tuple<Text, Text>>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto cx_outer_pf = with_unwritten(cx_p0, outer_pd);
    auto [xs_p1b, st2_p1c] = run_to_end(fold_job(crate::check::errors::range0(len(ps_p3)), std::tuple{Array<crate::check::types::Ty>{}, st_p1}, ({
        auto ps_p3_1 = ps_p3;
        auto res_p4_2 = res_p4;
        auto pcols_pp_3 = pcols_pp;
        auto cx_p0_4 = cx_p0;
        auto cx_outer_pf_5 = cx_outer_pf;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, ps_p3_1 = std::move(ps_p3_1), res_p4_2 = std::move(res_p4_2), pcols_pp_3 = std::move(pcols_pp_3), cx_p0_4 = std::move(cx_p0_4), cx_outer_pf_5 = std::move(cx_outer_pf_5)](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ps_p3_1_6 = ps_p3_1;
            auto res_p4_2_6 = res_p4_2;
            auto pcols_pp_3_6 = pcols_pp_3;
            auto cx_p0_4_6 = cx_p0_4;
            auto cx_outer_pf_5_6 = cx_outer_pf_5;
            entered(once_job([=, ps_p3_1_6 = std::move(ps_p3_1_6), res_p4_2_6 = std::move(res_p4_2_6), pcols_pp_3_6 = std::move(pcols_pp_3_6), cx_p0_4_6 = std::move(cx_p0_4_6), cx_outer_pf_5_6 = std::move(cx_outer_pf_5_6)]() {
            return ({
                auto [acc_p12, s_p13] = p0;
                auto i_p14 = p1;
                ({
                auto p_p15 = or_(index(ps_p3_1_6, i_p14), res_p4_2_6);
                auto [is_fn_p17, c_p18] = or_(index(pcols_pp_3_6, i_p14), std::tuple{false, crate::check::types::Col(crate::check::types::Col::CBound{})});
                auto pcx_p16 = is_fn_p17 ? with_unwritten(cx_p0_4_6, c_p18) : cx_outer_pf_5_6;
                call_then(start_conv_type(pcx_p16, s_p13, p_p15), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_12554) {
                return ({
                    auto [y_p19, s2_p1a] = conv_type_12554;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p12, y_p19), s2_p1a}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto [r_p1d, st3_p1e] = conv_type(cx_outer_pf, st2_p1c, res_p4);
    auto added_pg = outer_name_pc == Text::lit("")
        ? names_p8
        : crate::prelude::push(names_p8, outer_name_pc);
    return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyFn{outer_pd, xs_p1b, prism_rtl::rc(r_p1d)}), added_pg, joins_pe, st3_p1e};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> ClosureSig::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& st_p1 = this->st_p1;
    const auto& color_p2 = this->color_p2;
    const auto& ps_p3 = this->ps_p3;
    const auto& res_p4 = this->res_p4;
    const auto& written_p5 = this->written_p5;
    auto [outer_set_ph, outer_w_pi] = written_col(color_p2);
    auto bounded_outer_p6 = outer_set_ph && (outer_w_pi == crate::check::types::Col(crate::check::types::Col::CBound{}));
    auto color_p2_1 = color_p2;
    auto cx_p0_2 = cx_p0;
    auto ps_p3_3 = ps_p3;
    auto res_p4_4 = res_p4;
    auto st_p1_5 = st_p1;
    auto written_p5_6 = written_p5;
    return call_value(filter_job(ps_p3_3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::syntax::Type)>>(prism_rtl::rc([=](crate::syntax::Type p0) {
        return entered(once_job([=]() {
            return ({
                auto p_pj = p0;
                call_then(start_is_fn_type(p_pj), [=](bool is_fn_type_11003) { return prism_rtl::finished(is_fn_type_11003 && (!writes_col(top_color(p_pj)))); });
            });
        }));
    }))), [=](Array<crate::syntax::Type> filter_10986) {
        return ({
            auto n_default_p7 = len(filter_10986);
            call_then(start_fresh_col_names(written_p5_6, bounded_outer_p6 ? Nat(0u) : n_default_p7), [=](Array<Text> fresh_col_names_11065) {
            return ({
                auto names_p8 = fresh_col_names_11065;
                call_value(fold_job(ps_p3_3, std::tuple{Array<std::tuple<bool, crate::check::types::Col>>{}, Nat(0u)}, ({
                auto bounded_outer_p6_7 = bounded_outer_p6;
                auto names_p8_8 = names_p8;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<bool, crate::check::types::Col>>, Nat>>(std::tuple<std::tuple<Array<std::tuple<bool, crate::check::types::Col>>, Nat>, crate::syntax::Type>)>>(prism_rtl::rc([=, bounded_outer_p6_7 = std::move(bounded_outer_p6_7), names_p8_8 = std::move(names_p8_8)](std::tuple<std::tuple<Array<std::tuple<bool, crate::check::types::Col>>, Nat>, crate::syntax::Type> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto bounded_outer_p6_7_9 = bounded_outer_p6_7;
                    auto names_p8_8_9 = names_p8_8;
                    entered(once_job([=, bounded_outer_p6_7_9 = std::move(bounded_outer_p6_7_9), names_p8_8_9 = std::move(names_p8_8_9)]() {
                    return ({
                        auto [acc_pk, k_pl] = p0;
                        auto p_pm = p1;
                        call_then(start_is_fn_type(p_pm), [=](bool is_fn_type_11280) {
                        return !is_fn_type_11280
                            ? prism_rtl::finished(std::tuple{crate::prelude::push(acc_pk, std::tuple{false, crate::check::types::Col(crate::check::types::Col::CBound{})}), k_pl})
                            : call_then(start_top_color(p_pm), [=](crate::syntax::Color top_color_11385) {
                            return ({
                                auto [set_pn, c_po] = written_col(top_color_11385);
                                set_pn
                                ? prism_rtl::finished(std::tuple{crate::prelude::push(acc_pk, std::tuple{true, c_po}), k_pl})
                                : bounded_outer_p6_7_9
                                ? prism_rtl::finished(std::tuple{crate::prelude::push(acc_pk, std::tuple{true, crate::check::types::Col(crate::check::types::Col::CBound{})}), k_pl})
                                : prism_rtl::finished(std::tuple{crate::prelude::push(acc_pk, std::tuple{true, crate::check::types::Col(crate::check::types::Col::CQ{or_(index(names_p8_8_9, k_pl), Text::lit("u"))})}), k_pl + Nat(1u)});
                            });
                        });
                    });
                    });
                }));
                });
            }));
            })), [=](std::tuple<Array<std::tuple<bool, crate::check::types::Col>>, Nat> fold_11225) {
                return ({
                    auto&& _pcols_pp = fold_11225;
                    auto&& pcols_pp = std::get<0>(_pcols_pp);
                    auto vars_p9 = fold(pcols_pp, Array<Text>{}, [&](const Array<Text>& acc_pq, const std::tuple<bool, crate::check::types::Col>& _p1) {
                        auto&& c_pr = std::get<1>(_p1);
                        return ({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            if (prism_rtl::is<crate::check::types::Col::CQ>(c_pr)) {
                                auto&& v_ps = prism_rtl::as<crate::check::types::Col::CQ>(c_pr).a0;
                                _v.set(crate::check::types::add_text(acc_pq, v_ps));
                                goto _done;
                            }
                            {
                                _v.set(acc_pq);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                    });
                    auto any_unbounded_pa = fold(pcols_pp, false, [&](const bool& seen_pt, const std::tuple<bool, crate::check::types::Col>& _p1) {
                        auto&& c_pu = std::get<1>(_p1);
                        return prism_rtl::deref(seen_pt) || (c_pu == crate::check::types::Col(crate::check::types::Col::CUnbound{}));
                    });
                    call_then(start_fresh_col_names(append(written_p5_6, names_p8), Nat(1u)), [=, vars_p9 = std::move(vars_p9), any_unbounded_pa = std::move(any_unbounded_pa)](Array<Text> fresh_col_names_11813) {
                    return ({
                        auto spare_pb = fresh_col_names_11813;
                        auto outer_name_pc = (outer_set_ph || any_unbounded_pa) || (len(vars_p9) < Nat(2u))
                            ? Text::lit("")
                            : or_(index(spare_pb, Nat(0u)), Text::lit("u"));
                        auto outer_pd = outer_set_ph
                            ? outer_w_pi
                            : any_unbounded_pa
                            ? crate::check::types::Col(crate::check::types::Col::CUnbound{})
                            : len(vars_p9) == Nat(0u)
                            ? crate::check::types::Col(crate::check::types::Col::CBound{})
                            : len(vars_p9) == Nat(1u)
                            ? crate::check::types::Col(crate::check::types::Col::CQ{or_(index(vars_p9, Nat(0u)), Text::lit("u"))})
                            : crate::check::types::Col(crate::check::types::Col::CQ{outer_name_pc});
                        auto joins_pe = ({
                            __label__ _done;
                            prism_rtl::Slot<Array<std::tuple<Text, Text>>> _v;
                            if (prism_rtl::is<crate::check::types::Col::CQ>(outer_pd)) {
                                auto&& hi_pv = prism_rtl::as<crate::check::types::Col::CQ>(outer_pd).a0;
                                _v.set(each(filter(vars_p9, [&](const Text& v_p10) { return v_p10 != hi_pv; }), [&](const Text& v_p11) { return std::tuple{v_p11, hi_pv}; }));
                                goto _done;
                            }
                            {
                                _v.set(Array<std::tuple<Text, Text>>{});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto cx_outer_pf = with_unwritten(cx_p0_2, outer_pd);
                        call_value(fold_job(crate::check::errors::range0(len(ps_p3_3)), std::tuple{Array<crate::check::types::Ty>{}, st_p1_5}, ({
                        auto ps_p3_3_7 = ps_p3_3;
                        auto res_p4_4_7 = res_p4_4;
                        auto pcols_pp_7 = pcols_pp;
                        auto cx_p0_2_8 = cx_p0_2;
                        auto cx_outer_pf_8 = cx_outer_pf;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, ps_p3_3_7 = std::move(ps_p3_3_7), res_p4_4_7 = std::move(res_p4_4_7), pcols_pp_7 = std::move(pcols_pp_7), cx_p0_2_8 = std::move(cx_p0_2_8), cx_outer_pf_8 = std::move(cx_outer_pf_8)](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto ps_p3_3_7_9 = ps_p3_3_7;
                            auto res_p4_4_7_9 = res_p4_4_7;
                            auto pcols_pp_7_9 = pcols_pp_7;
                            auto cx_p0_2_8_9 = cx_p0_2_8;
                            auto cx_outer_pf_8_9 = cx_outer_pf_8;
                            entered(once_job([=, ps_p3_3_7_9 = std::move(ps_p3_3_7_9), res_p4_4_7_9 = std::move(res_p4_4_7_9), pcols_pp_7_9 = std::move(pcols_pp_7_9), cx_p0_2_8_9 = std::move(cx_p0_2_8_9), cx_outer_pf_8_9 = std::move(cx_outer_pf_8_9)]() {
                            return ({
                                auto [acc_p12, s_p13] = p0;
                                auto i_p14 = p1;
                                ({
                                auto p_p15 = or_(index(ps_p3_3_7_9, i_p14), res_p4_4_7_9);
                                auto [is_fn_p17, c_p18] = or_(index(pcols_pp_7_9, i_p14), std::tuple{false, crate::check::types::Col(crate::check::types::Col::CBound{})});
                                auto pcx_p16 = is_fn_p17 ? with_unwritten(cx_p0_2_8_9, c_p18) : cx_outer_pf_8_9;
                                call_then(start_conv_type(pcx_p16, s_p13, p_p15), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_12554) {
                                return ({
                                    auto [y_p19, s2_p1a] = conv_type_12554;
                                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p12, y_p19), s2_p1a}));
                                });
                            });
                            });
                            });
                        }));
                        });
                    }));
                    })), [=, outer_name_pc = std::move(outer_name_pc), outer_pd = std::move(outer_pd), joins_pe = std::move(joins_pe)](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> fold_12327) {
                        return ({
                            auto [xs_p1b, st2_p1c] = fold_12327;
                            call_then(start_conv_type(cx_outer_pf, st2_p1c, res_p4_4), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_12624) {
                            return ({
                                auto [r_p1d, st3_p1e] = conv_type_12624;
                                auto added_pg = outer_name_pc == Text::lit("")
                                    ? names_p8
                                    : crate::prelude::push(names_p8, outer_name_pc);
                                (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyFn{outer_pd, xs_p1b, prism_rtl::rc(r_p1d)}), added_pg, joins_pe, st3_p1e}));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start ClosureSig, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> start_closure_sig(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Color color_p2, Array<crate::syntax::Type> ps_p3, crate::syntax::Type res_p4, Array<Text> written_p5) {
    return prism_rtl::make_rc<ClosureSig>(cx_p0, st_p1, color_p2, ps_p3, res_p4, written_p5);
}


/// WrittenCol: fn Color -> ((Bool, Col))
std::tuple<bool, crate::check::types::Col> written_col(const crate::syntax::Color& color0) {
    if (prism_rtl::is<crate::syntax::Color::Bounded>(color0)) {
        return std::tuple{false, crate::check::types::Col(crate::check::types::Col::CBound{})};
    }
    if (prism_rtl::is<crate::syntax::Color::Unbounded>(color0)) {
        return std::tuple{true, crate::check::types::Col(crate::check::types::Col::CUnbound{})};
    }
    if (prism_rtl::is<crate::syntax::Color::ColorVar>(color0)) {
        auto&& v_p0 = prism_rtl::as<crate::syntax::Color::ColorVar>(color0).a0;
        return prism_rtl::deref(v_p0).name == Text::lit("bounded")
            ? std::tuple{true, crate::check::types::Col(crate::check::types::Col::CBound{})}
            : std::tuple{true, crate::check::types::Col(crate::check::types::Col::CQ{prism_rtl::deref(v_p0).name})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// WithUnwritten: fn Cx, Col -> Cx
Cx_ with_unwritten(const Cx_& cx_p0, const crate::check::types::Col& c_p1) {
    Cx_ this_ = cx_p0;
    this_.unwritten = c_p1;
    return this_;
}


/// WritesCol: fn Color -> Bool
bool writes_col(const crate::syntax::Color& color0) {
    if (prism_rtl::is<crate::syntax::Color::Bounded>(color0)) {
        return false;
    }
    {
        return true;
    }
}


/// TopColor: unbounded fn Type -> Color
crate::syntax::Color top_color(const crate::syntax::Type& t_p0) {
    auto&& _m = prism_rtl::deref(t_p0.kind);
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& c_p1 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0;
        return c_p1;
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_p2 = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return top_color(prism_rtl::deref(prism_rtl::deref(x_p2)));
    }
    {
        return crate::syntax::Color(crate::syntax::Color::Bounded{});
    }
}


prism_rtl::Turn<crate::syntax::Color> TopColor::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p0).kind);
        prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& c_p1 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0;
        prism_rtl::finished(c_p1);
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_p2 = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TopColor(prism_rtl::deref(prism_rtl::deref(x_p2)))));
    })
        : prism_rtl::finished(crate::syntax::Color(crate::syntax::Color::Bounded{}));
    });
}


/// `Start TopColor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::Color> start_top_color(crate::syntax::Type t_p0) {
    return prism_rtl::make_rc<TopColor>(t_p0);
}


/// FreshColNames: unbounded fn [Text], Nat -> [Text]
Array<Text> fresh_col_names(const Array<Text>& taken_p0, const Nat& n_p1) {
    auto&& _names_p5 = run_to_end(fold_job(crate::check::errors::range0(n_p1), std::tuple{Array<Text>{}, Nat(1u)}, ({
        auto taken_p0_1 = taken_p0;
        auto n_p1_2 = n_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Nat>>(std::tuple<std::tuple<Array<Text>, Nat>, Nat>)>>(prism_rtl::rc([=, taken_p0_1 = std::move(taken_p0_1), n_p1_2 = std::move(n_p1_2)](std::tuple<std::tuple<Array<Text>, Nat>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto taken_p0_1_3 = taken_p0_1;
            auto n_p1_2_3 = n_p1_2;
            entered(once_job([=, taken_p0_1_3 = std::move(taken_p0_1_3), n_p1_2_3 = std::move(n_p1_2_3)]() {
            return ({
                auto [acc_p2, k_p3] = p0;
                static_cast<void>(p1);
                ({
                auto k2_p4 = next_free_col(append(taken_p0_1_3, acc_p2), n_p1_2_3 == Nat(1u) ? Nat(0u) : k_p3);
                (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p2, sig_col_name(k2_p4)), k2_p4 + Nat(1u)}));
            });
            });
        }));
        });
    }));
    })));
    auto&& names_p5 = std::get<0>(_names_p5);
    return names_p5;
}


prism_rtl::Turn<Array<Text>> FreshColNames::cycle() const {
    const auto& taken_p0 = this->taken_p0;
    const auto& n_p1 = this->n_p1;
    auto n_p1_1 = n_p1;
    auto taken_p0_2 = taken_p0;
    return call_value(fold_job(crate::check::errors::range0(n_p1_1), std::tuple{Array<Text>{}, Nat(1u)}, ({
        auto taken_p0_2_3 = taken_p0_2;
        auto n_p1_1_3 = n_p1_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Nat>>(std::tuple<std::tuple<Array<Text>, Nat>, Nat>)>>(prism_rtl::rc([=, taken_p0_2_3 = std::move(taken_p0_2_3), n_p1_1_3 = std::move(n_p1_1_3)](std::tuple<std::tuple<Array<Text>, Nat>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto taken_p0_2_3_3 = taken_p0_2_3;
            auto n_p1_1_3_3 = n_p1_1_3;
            entered(once_job([=, taken_p0_2_3_3 = std::move(taken_p0_2_3_3), n_p1_1_3_3 = std::move(n_p1_1_3_3)]() {
            return ({
                auto [acc_p2, k_p3] = p0;
                static_cast<void>(p1);
                ({
                auto k2_p4 = next_free_col(append(taken_p0_2_3_3, acc_p2), n_p1_1_3_3 == Nat(1u) ? Nat(0u) : k_p3);
                (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p2, sig_col_name(k2_p4)), k2_p4 + Nat(1u)}));
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<Text>, Nat> fold_13692) {
        return ({
            auto&& _names_p5 = fold_13692;
            auto&& names_p5 = std::get<0>(_names_p5);
            (prism_rtl::finished(names_p5));
        });
    });
}


/// `Start FreshColNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_fresh_col_names(Array<Text> taken_p0, Nat n_p1) {
    return prism_rtl::make_rc<FreshColNames>(taken_p0, n_p1);
}


/// NextFreeCol: unbounded fn [Text], Nat -> Nat
Nat next_free_col(const Array<Text>& taken_p0, const Nat& k_p1) {
    return crate::check::types::has_text(taken_p0, sig_col_name(k_p1))
        ? next_free_col(taken_p0, k_p1 + Nat(1u))
        : k_p1;
}


/// SigColName: fn Nat -> Text
Text sig_col_name(const Nat& n0) {
    {
        auto&& c0_0 = n0;
        if (c0_0 == Nat(0u)) {
            return Text::lit("u");
        }
    }
    {
        auto&& k_p0 = n0;
        return prism_rtl::cat("u", k_p0);
    }
}


/// ConvBounds: fn Cx, St, [Bound] -> (([((Text, Text))], St))
std::tuple<Array<std::tuple<Text, Text>>, crate::check::types::St> conv_bounds(const Cx_& cx_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::decls::Bound>& bounds_p2) {
    return fold(bounds_p2, std::tuple{Array<std::tuple<Text, Text>>{}, st_p1}, [&](const std::tuple<Array<std::tuple<Text, Text>>, crate::check::types::St>& _p0, const crate::syntax::decls::Bound& b_p5) {
        auto&& acc_p3 = std::get<0>(_p0);
        auto&& s_p4 = std::get<1>(_p0);
        return fold(prism_rtl::deref(b_p5).traits, std::tuple{acc_p3, s_p4}, [&](const std::tuple<Array<std::tuple<Text, Text>>, crate::check::types::St>& _p0, const crate::syntax::TraitRef& tr_p8) {
            auto&& a2_p6 = std::get<0>(_p0);
            auto&& s2_p7 = std::get<1>(_p0);
            return ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<std::tuple<Text, Text>>, crate::check::types::St>> _v;
                auto&& _m = crate::check::env::names::resolve_trait(cx_p0.g, cx_p0.home, tr_p8->path_);
                if (prism_rtl::is_some(_m)) {
                    auto&& k_p9 = prism_rtl::some_of(_m);
                    _v.set(std::tuple{crate::prelude::push(a2_p6, std::tuple{prism_rtl::deref(prism_rtl::deref(b_p5).var).name, k_p9}), s2_p7});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{a2_p6, crate::check::types::recording::err(s2_p7, Text::lit("unknown-name"), prism_rtl::deref(tr_p8).span, prism_rtl::cat("no trait `^", crate::check::env::dotted(tr_p8->path_), "`"))});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    });
}


/// MentionsTime: unbounded fn Type -> Bool
bool mentions_time(const crate::syntax::Type& t_p0) {
    auto&& _m = prism_rtl::deref(t_p0.kind);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p2 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        return ((crate::syntax::lexer::chars::contains(prism_rtl::deref(n_p1).sigils, Text::lit("$")) || crate::syntax::lexer::chars::contains(prism_rtl::deref(n_p1).sigils, Text::lit("!"))) || crate::syntax::lexer::chars::contains(prism_rtl::deref(n_p1).sigils, Text::lit("@"))) || run_to_end(fold_job(args_p2, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen_p3 = p0;
                    auto a_p4 = p1;
                    (prism_rtl::finished(std::move(seen_p3) || mentions_time(a_p4)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& s_p5 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        auto&& i_p6 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        return ((crate::syntax::lexer::chars::contains(s_p5, Text::lit("$")) || crate::syntax::lexer::chars::contains(s_p5, Text::lit("!"))) || crate::syntax::lexer::chars::contains(s_p5, Text::lit("@"))) || mentions_time(prism_rtl::deref(prism_rtl::deref(i_p6)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TUnit>(_m)) {
        auto&& s_p7 = prism_rtl::as<crate::syntax::TypeKind::TUnit>(_m).a0;
        return (crate::syntax::lexer::chars::contains(s_p7, Text::lit("$")) || crate::syntax::lexer::chars::contains(s_p7, Text::lit("!"))) || crate::syntax::lexer::chars::contains(s_p7, Text::lit("@"));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m)) {
        auto&& e_p8 = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        return mentions_time(prism_rtl::deref(prism_rtl::deref(e_p8)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts_p9 = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        return run_to_end(fold_job(ts_p9, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen_pa = p0;
                    auto a_pb = p1;
                    (prism_rtl::finished(std::move(seen_pa) || mentions_time(a_pb)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_pc = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return mentions_time(prism_rtl::deref(prism_rtl::deref(x_pc)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k_pd = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pe = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        return mentions_time(prism_rtl::deref(prism_rtl::deref(k_pd))) || mentions_time(prism_rtl::deref(prism_rtl::deref(v_pe)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& ps_pf = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_pg = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return run_to_end(fold_job(ps_pf, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen_ph = p0;
                    auto a_pi = p1;
                    (prism_rtl::finished(std::move(seen_ph) || mentions_time(a_pi)));
                });
            }));
        })))) || mentions_time(prism_rtl::deref(prism_rtl::deref(res_pg)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& ty_pj = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        return true;
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> MentionsTime::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p0).kind);
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& n_p1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p2 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        prism_rtl::finished(((crate::syntax::lexer::chars::contains(prism_rtl::deref(n_p1).sigils, Text::lit("$")) || crate::syntax::lexer::chars::contains(prism_rtl::deref(n_p1).sigils, Text::lit("!"))) || crate::syntax::lexer::chars::contains(prism_rtl::deref(n_p1).sigils, Text::lit("@"))) || run_to_end(fold_job(args_p2, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen_p3 = p0;
                auto a_p4 = p1;
                (prism_rtl::finished(std::move(seen_p3) || mentions_time(a_p4)));
            });
        }));
    })))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m) ? ({
        auto&& s_p5 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        auto&& i_p6 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        prism_rtl::finished(((crate::syntax::lexer::chars::contains(s_p5, Text::lit("$")) || crate::syntax::lexer::chars::contains(s_p5, Text::lit("!"))) || crate::syntax::lexer::chars::contains(s_p5, Text::lit("@"))) || mentions_time(prism_rtl::deref(prism_rtl::deref(i_p6))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TUnit>(_m) ? ({
        auto&& s_p7 = prism_rtl::as<crate::syntax::TypeKind::TUnit>(_m).a0;
        prism_rtl::finished((crate::syntax::lexer::chars::contains(s_p7, Text::lit("$")) || crate::syntax::lexer::chars::contains(s_p7, Text::lit("!"))) || crate::syntax::lexer::chars::contains(s_p7, Text::lit("@")));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) ? ({
        auto&& e_p8 = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(MentionsTime(prism_rtl::deref(prism_rtl::deref(e_p8)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m) ? ({
        auto&& ts_p9 = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        fold_job(ts_p9, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen_pa = p0;
                auto a_pb = p1;
                (prism_rtl::finished(std::move(seen_pa) || mentions_time(a_pb)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_pc = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(MentionsTime(prism_rtl::deref(prism_rtl::deref(x_pc)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TMap>(_m) ? ({
        auto&& k_pd = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pe = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        ({
        auto k_pd_1 = prism_rtl::deref(prism_rtl::deref(k_pd));
        auto v_pe_2 = prism_rtl::deref(prism_rtl::deref(v_pe));
        call_then(start_mentions_time(k_pd_1), [=, v_pe_2 = std::move(v_pe_2)](bool mentions_time_15072) { return prism_rtl::finished(mentions_time_15072 || mentions_time(v_pe_2)); });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& ps_pf = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_pg = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto ps_pf_1 = ps_pf;
        auto res_pg_2 = prism_rtl::deref(prism_rtl::deref(res_pg));
        call_value(fold_job(ps_pf_1, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen_ph = p0;
                auto a_pi = p1;
                (prism_rtl::finished(std::move(seen_ph) || mentions_time(a_pi)));
            });
        }));
    }))), [=, res_pg_2 = std::move(res_pg_2)](bool fold_15132) { return prism_rtl::finished(fold_15132 || mentions_time(res_pg_2)); });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m) ? ({
        auto&& ty_pj = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        prism_rtl::finished(true);
    })
        : prism_rtl::finished(false);
    });
}


/// `Start MentionsTime, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_mentions_time(crate::syntax::Type t_p0) {
    return prism_rtl::make_rc<MentionsTime>(t_p0);
}


/// TakesClosure: unbounded fn Type -> Bool
bool takes_closure(const crate::syntax::Type& t_p0) {
    auto&& _m = prism_rtl::deref(t_p0.kind);
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& ps_p1 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        return run_to_end(fold_job(ps_p1, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen_p2 = p0;
                    auto p_p3 = p1;
                    (prism_rtl::finished(std::move(seen_p2) || is_fn_type(p_p3)));
                });
            }));
        }))));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> TakesClosure::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p0).kind);
        prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& ps_p1 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        fold_job(ps_p1, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen_p2 = p0;
                auto p_p3 = p1;
                (prism_rtl::finished(std::move(seen_p2) || is_fn_type(p_p3)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::finished(false);
    });
}


/// `Start TakesClosure, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_takes_closure(crate::syntax::Type t_p0) {
    return prism_rtl::make_rc<TakesClosure>(t_p0);
}


/// IsFnType: unbounded fn Type -> Bool
bool is_fn_type(const crate::syntax::Type& t_p0) {
    auto&& _m = prism_rtl::deref(t_p0.kind);
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_p1 = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return is_fn_type(prism_rtl::deref(prism_rtl::deref(x_p1)));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsFnType::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p0).kind);
        prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? prism_rtl::finished(true)
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_p1 = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(IsFnType(prism_rtl::deref(prism_rtl::deref(x_p1)))));
    })
        : prism_rtl::finished(false);
    });
}


/// `Start IsFnType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_fn_type(crate::syntax::Type t_p0) {
    return prism_rtl::make_rc<IsFnType>(t_p0);
}


/// UsesScope: unbounded fn Type -> Bool
bool uses_scope(const crate::syntax::Type& t_p0) {
    auto&& _m = prism_rtl::deref(t_p0.kind);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p2 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        return ((crate::syntax::lexer::chars::contains(prism_rtl::deref(n_p1).sigils, Text::lit("@")) || ((crate::check::env::dotted(n_p1->path_) == Text::lit("Element")) && (len(args_p2) < Nat(2u)))) || ((crate::check::env::dotted(n_p1->path_) == Text::lit("Elem")) && (len(args_p2) == Nat(0u)))) || run_to_end(fold_job(args_p2, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen_p3 = p0;
                    auto a_p4 = p1;
                    (prism_rtl::finished(std::move(seen_p3) || uses_scope(a_p4)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& s_p5 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        auto&& i_p6 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        return crate::syntax::lexer::chars::contains(s_p5, Text::lit("@")) || uses_scope(prism_rtl::deref(prism_rtl::deref(i_p6)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TUnit>(_m)) {
        auto&& s_p7 = prism_rtl::as<crate::syntax::TypeKind::TUnit>(_m).a0;
        return crate::syntax::lexer::chars::contains(s_p7, Text::lit("@"));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m)) {
        auto&& e_p8 = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        return uses_scope(prism_rtl::deref(prism_rtl::deref(e_p8)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts_p9 = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        return run_to_end(fold_job(ts_p9, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen_pa = p0;
                    auto a_pb = p1;
                    (prism_rtl::finished(std::move(seen_pa) || uses_scope(a_pb)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_pc = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return uses_scope(prism_rtl::deref(prism_rtl::deref(x_pc)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k_pd = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pe = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        return uses_scope(prism_rtl::deref(prism_rtl::deref(k_pd))) || uses_scope(prism_rtl::deref(prism_rtl::deref(v_pe)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& ps_pf = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_pg = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return run_to_end(fold_job(ps_pf, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen_ph = p0;
                    auto a_pi = p1;
                    (prism_rtl::finished(std::move(seen_ph) || uses_scope(a_pi)));
                });
            }));
        })))) || uses_scope(prism_rtl::deref(prism_rtl::deref(res_pg)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& ty_pj = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& row_t_pk = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        return uses_scope(prism_rtl::deref(prism_rtl::deref(row_t_pk)));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> UsesScope::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p0).kind);
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& n_p1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p2 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        prism_rtl::finished(((crate::syntax::lexer::chars::contains(prism_rtl::deref(n_p1).sigils, Text::lit("@")) || ((crate::check::env::dotted(n_p1->path_) == Text::lit("Element")) && (len(args_p2) < Nat(2u)))) || ((crate::check::env::dotted(n_p1->path_) == Text::lit("Elem")) && (len(args_p2) == Nat(0u)))) || run_to_end(fold_job(args_p2, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen_p3 = p0;
                auto a_p4 = p1;
                (prism_rtl::finished(std::move(seen_p3) || uses_scope(a_p4)));
            });
        }));
    })))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m) ? ({
        auto&& s_p5 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        auto&& i_p6 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        prism_rtl::finished(crate::syntax::lexer::chars::contains(s_p5, Text::lit("@")) || uses_scope(prism_rtl::deref(prism_rtl::deref(i_p6))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TUnit>(_m) ? ({
        auto&& s_p7 = prism_rtl::as<crate::syntax::TypeKind::TUnit>(_m).a0;
        prism_rtl::finished(crate::syntax::lexer::chars::contains(s_p7, Text::lit("@")));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) ? ({
        auto&& e_p8 = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(UsesScope(prism_rtl::deref(prism_rtl::deref(e_p8)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m) ? ({
        auto&& ts_p9 = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        fold_job(ts_p9, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen_pa = p0;
                auto a_pb = p1;
                (prism_rtl::finished(std::move(seen_pa) || uses_scope(a_pb)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_pc = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(UsesScope(prism_rtl::deref(prism_rtl::deref(x_pc)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TMap>(_m) ? ({
        auto&& k_pd = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pe = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        ({
        auto k_pd_1 = prism_rtl::deref(prism_rtl::deref(k_pd));
        auto v_pe_2 = prism_rtl::deref(prism_rtl::deref(v_pe));
        call_then(start_uses_scope(k_pd_1), [=, v_pe_2 = std::move(v_pe_2)](bool uses_scope_16139) { return prism_rtl::finished(uses_scope_16139 || uses_scope(v_pe_2)); });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& ps_pf = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_pg = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto ps_pf_1 = ps_pf;
        auto res_pg_2 = prism_rtl::deref(prism_rtl::deref(res_pg));
        call_value(fold_job(ps_pf_1, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen_ph = p0;
                auto a_pi = p1;
                (prism_rtl::finished(std::move(seen_ph) || uses_scope(a_pi)));
            });
        }));
    }))), [=, res_pg_2 = std::move(res_pg_2)](bool fold_16193) { return prism_rtl::finished(fold_16193 || uses_scope(res_pg_2)); });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m) ? ({
        auto&& ty_pj = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& row_t_pk = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        prism_rtl::more(prism_rtl::rc(UsesScope(prism_rtl::deref(prism_rtl::deref(row_t_pk)))));
    })
        : prism_rtl::finished(false);
    });
}


/// `Start UsesScope, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_uses_scope(crate::syntax::Type t_p0) {
    return prism_rtl::make_rc<UsesScope>(t_p0);
}


/// RowVarsOfType: unbounded fn Type -> [Text]
Array<Text> row_vars_of_type(const crate::syntax::Type& t_p0) {
    auto&& _m = prism_rtl::deref(t_p0.kind);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p2 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        auto name_p3 = crate::check::env::dotted(n_p1->path_);
        auto own_p4 = ((name_p3 == Text::lit("Element")) && (len(args_p2) == Nat(2u))) || ((name_p3 == Text::lit("Elem")) && (len(args_p2) == Nat(1u)))
            ? row_names_in(or_(index(args_p2, Nat(0u)), dummy_type()))
            : Array<Text>{};
        auto rest_p5 = (name_p3 == Text::lit("Element")) && (len(args_p2) == Nat(2u))
            ? drop(args_p2, Nat(1u))
            : name_p3 == Text::lit("Elem") ? Array<crate::syntax::Type>{} : args_p2;
        return run_to_end(fold_job(rest_p5, own_p4, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p6 = p0;
                    auto a_p7 = p1;
                    call_then(start_row_vars_of_type(a_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> row_vars_of_type_16813) { return prism_rtl::finished(crate::check::types::union_texts(acc_p6, row_vars_of_type_16813)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& i_p8 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        return row_vars_of_type(prism_rtl::deref(prism_rtl::deref(i_p8)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m)) {
        auto&& e_p9 = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        return row_vars_of_type(prism_rtl::deref(prism_rtl::deref(e_p9)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts_pa = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        return run_to_end(fold_job(ts_pa, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_pb = p0;
                    auto a_pc = p1;
                    call_then(start_row_vars_of_type(a_pc), [=, acc_pb = std::move(acc_pb)](Array<Text> row_vars_of_type_16965) { return prism_rtl::finished(crate::check::types::union_texts(acc_pb, row_vars_of_type_16965)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_pd = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return row_vars_of_type(prism_rtl::deref(prism_rtl::deref(x_pd)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k_pe = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pf = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        return crate::check::types::union_texts(row_vars_of_type(prism_rtl::deref(prism_rtl::deref(k_pe))), row_vars_of_type(prism_rtl::deref(prism_rtl::deref(v_pf))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& ps_pg = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_ph = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return run_to_end(fold_job(ps_pg, row_vars_of_type(prism_rtl::deref(prism_rtl::deref(res_ph))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_pi = p0;
                    auto a_pj = p1;
                    call_then(start_row_vars_of_type(a_pj), [=, acc_pi = std::move(acc_pi)](Array<Text> row_vars_of_type_17157) { return prism_rtl::finished(crate::check::types::union_texts(acc_pi, row_vars_of_type_17157)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& ty_pk = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& row_t_pl = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        return crate::check::types::union_texts(row_vars_of_type(prism_rtl::deref(prism_rtl::deref(ty_pk))), row_names_in(prism_rtl::deref(prism_rtl::deref(row_t_pl))));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> RowVarsOfType::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p0).kind);
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& n_p1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p2 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        ({
        auto name_p3 = crate::check::env::dotted(n_p1->path_);
        auto own_p4 = ((name_p3 == Text::lit("Element")) && (len(args_p2) == Nat(2u))) || ((name_p3 == Text::lit("Elem")) && (len(args_p2) == Nat(1u)))
            ? row_names_in(or_(index(args_p2, Nat(0u)), dummy_type()))
            : Array<Text>{};
        auto rest_p5 = (name_p3 == Text::lit("Element")) && (len(args_p2) == Nat(2u))
            ? drop(args_p2, Nat(1u))
            : name_p3 == Text::lit("Elem") ? Array<crate::syntax::Type>{} : args_p2;
        fold_job(rest_p5, own_p4, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p6 = p0;
                auto a_p7 = p1;
                call_then(start_row_vars_of_type(a_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> row_vars_of_type_16813) { return prism_rtl::finished(crate::check::types::union_texts(acc_p6, row_vars_of_type_16813)); });
            });
        }));
    })))->cycle();
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m) ? ({
        auto&& i_p8 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        prism_rtl::more(prism_rtl::rc(RowVarsOfType(prism_rtl::deref(prism_rtl::deref(i_p8)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) ? ({
        auto&& e_p9 = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RowVarsOfType(prism_rtl::deref(prism_rtl::deref(e_p9)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m) ? ({
        auto&& ts_pa = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        fold_job(ts_pa, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_pb = p0;
                auto a_pc = p1;
                call_then(start_row_vars_of_type(a_pc), [=, acc_pb = std::move(acc_pb)](Array<Text> row_vars_of_type_16965) { return prism_rtl::finished(crate::check::types::union_texts(acc_pb, row_vars_of_type_16965)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_pd = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RowVarsOfType(prism_rtl::deref(prism_rtl::deref(x_pd)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TMap>(_m) ? ({
        auto&& k_pe = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pf = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        ({
        auto k_pe_1 = prism_rtl::deref(prism_rtl::deref(k_pe));
        auto v_pf_2 = prism_rtl::deref(prism_rtl::deref(v_pf));
        call_then(start_row_vars_of_type(k_pe_1), [=, v_pf_2 = std::move(v_pf_2)](Array<Text> row_vars_of_type_17039) { return call_then(start_row_vars_of_type(v_pf_2), [=](Array<Text> row_vars_of_type_17058) { return prism_rtl::finished(crate::check::types::union_texts(row_vars_of_type_17039, row_vars_of_type_17058)); }); });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& ps_pg = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_ph = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto ps_pg_1 = ps_pg;
        auto res_ph_2 = prism_rtl::deref(prism_rtl::deref(res_ph));
        call_then(start_row_vars_of_type(res_ph_2), [=, ps_pg_1 = std::move(ps_pg_1)](Array<Text> row_vars_of_type_17110) {
        return fold_job(ps_pg_1, row_vars_of_type_17110, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_pi = p0;
                    auto a_pj = p1;
                    call_then(start_row_vars_of_type(a_pj), [=, acc_pi = std::move(acc_pi)](Array<Text> row_vars_of_type_17157) { return prism_rtl::finished(crate::check::types::union_texts(acc_pi, row_vars_of_type_17157)); });
                });
            }));
        })))->cycle();
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m) ? ({
        auto&& ty_pk = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& row_t_pl = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        ({
        auto row_t_pl_1 = prism_rtl::deref(prism_rtl::deref(row_t_pl));
        auto ty_pk_2 = prism_rtl::deref(prism_rtl::deref(ty_pk));
        call_then(start_row_vars_of_type(ty_pk_2), [=, row_t_pl_1 = std::move(row_t_pl_1)](Array<Text> row_vars_of_type_17206) { return call_then(start_row_names_in(row_t_pl_1), [=](Array<Text> row_names_in_17226) { return prism_rtl::finished(crate::check::types::union_texts(row_vars_of_type_17206, row_names_in_17226)); }); });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start RowVarsOfType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_row_vars_of_type(crate::syntax::Type t_p0) {
    return prism_rtl::make_rc<RowVarsOfType>(t_p0);
}


/// RowNamesIn: unbounded fn Type -> [Text]
Array<Text> row_names_in(const crate::syntax::Type& t_p0) {
    auto&& _m = prism_rtl::deref(t_p0.kind);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m17322_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        if (m17322_0_1.size() == 0u) {
            return (len(n_p1->path_) == Nat(1u)) && crate::check::env::is_lower_text(crate::check::env::dotted(n_p1->path_))
                ? Array(std::vector{crate::check::env::dotted(n_p1->path_)})
                : Array<Text>{};
        }
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m)) {
        auto&& ts_p2 = prism_rtl::as<crate::syntax::TypeKind::TRowUnion>(_m).a0;
        return run_to_end(fold_job(ts_p2, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p3 = p0;
                    auto a_p4 = p1;
                    call_then(start_row_names_in(a_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> row_names_in_17500) { return prism_rtl::finished(crate::check::types::union_texts(acc_p3, row_names_in_17500)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_p5 = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return row_names_in(prism_rtl::deref(prism_rtl::deref(x_p5)));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> RowNamesIn::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p0).kind);
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) && ({
        auto&& n_p1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m17322_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        (m17322_0_1.size() == 0u);
    }) ? ({
        auto&& n_p1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m17322_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        (len(n_p1->path_) == Nat(1u)) && crate::check::env::is_lower_text(crate::check::env::dotted(n_p1->path_))
        ? prism_rtl::finished(Array(std::vector{crate::check::env::dotted(n_p1->path_)}))
        : prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m) ? ({
        auto&& ts_p2 = prism_rtl::as<crate::syntax::TypeKind::TRowUnion>(_m).a0;
        fold_job(ts_p2, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p3 = p0;
                auto a_p4 = p1;
                call_then(start_row_names_in(a_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> row_names_in_17500) { return prism_rtl::finished(crate::check::types::union_texts(acc_p3, row_names_in_17500)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_p5 = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RowNamesIn(prism_rtl::deref(prism_rtl::deref(x_p5)))));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start RowNamesIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_row_names_in(crate::syntax::Type t_p0) {
    return prism_rtl::make_rc<RowNamesIn>(t_p0);
}


/// TypeVarsOfType: unbounded fn Type -> [Text]
Array<Text> type_vars_of_type(const crate::syntax::Type& t_p0) {
    return type_vars_into(Array<Text>{}, t_p0);
}


prism_rtl::Turn<Array<Text>> TypeVarsOfType::cycle() const {
    const auto& t_p0 = this->t_p0;
    return prism_rtl::more(prism_rtl::rc(TypeVarsInto(Array<Text>{}, t_p0)));
}


/// `Start TypeVarsOfType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_type_vars_of_type(crate::syntax::Type t_p0) {
    return prism_rtl::make_rc<TypeVarsOfType>(t_p0);
}


/// TypeVarsInto: unbounded fn [Text], Type -> [Text]
Array<Text> type_vars_into(const Array<Text>& acc_p0, const crate::syntax::Type& t_p1) {
    auto&& _m = prism_rtl::deref(t_p1.kind);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p3 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        auto name_p4 = crate::check::env::dotted(n_p2->path_);
        auto here_p5 = ((len(n_p2->path_) == Nat(1u)) && crate::check::env::is_lower_text(name_p4)) && (len(args_p3) == Nat(0u))
            ? crate::check::types::add_text(acc_p0, name_p4)
            : acc_p0;
        auto rest_p6 = (name_p4 == Text::lit("Element")) && (len(args_p3) == Nat(2u))
            ? drop(args_p3, Nat(1u))
            : name_p4 == Text::lit("Elem") ? Array<crate::syntax::Type>{} : args_p3;
        return run_to_end(fold_job(rest_p6, here_p5, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto a_p7 = p0;
                    auto x_p8 = p1;
                    (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a_p7, x_p8))));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& i_p9 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        return type_vars_into(acc_p0, prism_rtl::deref(prism_rtl::deref(i_p9)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m)) {
        auto&& e_pa = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        return type_vars_into(acc_p0, prism_rtl::deref(prism_rtl::deref(e_pa)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts_pb = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        return run_to_end(fold_job(ts_pb, acc_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto a_pc = p0;
                    auto x_pd = p1;
                    (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a_pc, x_pd))));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_pe = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return type_vars_into(acc_p0, prism_rtl::deref(prism_rtl::deref(x_pe)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k_pf = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pg = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        return type_vars_into(type_vars_into(acc_p0, prism_rtl::deref(prism_rtl::deref(k_pf))), prism_rtl::deref(prism_rtl::deref(v_pg)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& ps_ph = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_pi = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return type_vars_into(run_to_end(fold_job(ps_ph, acc_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto a_pj = p0;
                    auto x_pk = p1;
                    (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a_pj, x_pk))));
                });
            }));
        })))), prism_rtl::deref(prism_rtl::deref(res_pi)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& ty_pl = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        return type_vars_into(acc_p0, prism_rtl::deref(prism_rtl::deref(ty_pl)));
    }
    {
        return acc_p0;
    }
}


prism_rtl::Turn<Array<Text>> TypeVarsInto::cycle() const {
    const auto& acc_p0 = this->acc_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p1).kind);
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& n_p2 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p3 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        ({
        auto name_p4 = crate::check::env::dotted(n_p2->path_);
        auto here_p5 = ((len(n_p2->path_) == Nat(1u)) && crate::check::env::is_lower_text(name_p4)) && (len(args_p3) == Nat(0u))
            ? crate::check::types::add_text(acc_p0, name_p4)
            : acc_p0;
        auto rest_p6 = (name_p4 == Text::lit("Element")) && (len(args_p3) == Nat(2u))
            ? drop(args_p3, Nat(1u))
            : name_p4 == Text::lit("Elem") ? Array<crate::syntax::Type>{} : args_p3;
        fold_job(rest_p6, here_p5, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a_p7 = p0;
                auto x_p8 = p1;
                (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a_p7, x_p8))));
            });
        }));
    })))->cycle();
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m) ? ({
        auto&& i_p9 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        prism_rtl::more(prism_rtl::rc(TypeVarsInto(acc_p0, prism_rtl::deref(prism_rtl::deref(i_p9)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) ? ({
        auto&& e_pa = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TypeVarsInto(acc_p0, prism_rtl::deref(prism_rtl::deref(e_pa)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m) ? ({
        auto&& ts_pb = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        fold_job(ts_pb, acc_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a_pc = p0;
                auto x_pd = p1;
                (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a_pc, x_pd))));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_pe = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TypeVarsInto(acc_p0, prism_rtl::deref(prism_rtl::deref(x_pe)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TMap>(_m) ? ({
        auto&& k_pf = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pg = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        ({
        auto acc_p0_1 = acc_p0;
        auto k_pf_2 = prism_rtl::deref(prism_rtl::deref(k_pf));
        auto v_pg_3 = prism_rtl::deref(prism_rtl::deref(v_pg));
        call_then(start_type_vars_into(acc_p0_1, k_pf_2), [=, v_pg_3 = std::move(v_pg_3)](Array<Text> type_vars_into_18357) { return prism_rtl::more(prism_rtl::rc(TypeVarsInto(type_vars_into_18357, v_pg_3))); });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& ps_ph = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_pi = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto acc_p0_1 = acc_p0;
        auto ps_ph_2 = ps_ph;
        auto res_pi_3 = prism_rtl::deref(prism_rtl::deref(res_pi));
        call_value(fold_job(ps_ph_2, acc_p0_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a_pj = p0;
                auto x_pk = p1;
                (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a_pj, x_pk))));
            });
        }));
    }))), [=, res_pi_3 = std::move(res_pi_3)](Array<Text> fold_18420) { return prism_rtl::more(prism_rtl::rc(TypeVarsInto(fold_18420, res_pi_3))); });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m) ? ({
        auto&& ty_pl = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TypeVarsInto(acc_p0, prism_rtl::deref(prism_rtl::deref(ty_pl)))));
    })
        : prism_rtl::finished(acc_p0);
    });
}


/// `Start TypeVarsInto, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_type_vars_into(Array<Text> acc_p0, crate::syntax::Type t_p1) {
    return prism_rtl::make_rc<TypeVarsInto>(acc_p0, t_p1);
}


/// ColorVarsOfType: unbounded fn Type -> [Text]
Array<Text> color_vars_of_type(const crate::syntax::Type& t_p0) {
    auto&& _m = prism_rtl::deref(t_p0.kind);
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) && prism_rtl::is<crate::syntax::Color::ColorVar>(prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0)) {
        auto&& v_p1 = prism_rtl::as<crate::syntax::Color::ColorVar>(prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0).a0;
        auto&& ps_p2 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_p3 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        auto inner_p4 = run_to_end(fold_job(ps_p2, color_vars_of_type(prism_rtl::deref(prism_rtl::deref(res_p3))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p5 = p0;
                    auto a_p6 = p1;
                    call_then(start_color_vars_of_type(a_p6), [=, acc_p5 = std::move(acc_p5)](Array<Text> color_vars_of_type_18721) { return prism_rtl::finished(crate::check::types::union_texts(acc_p5, color_vars_of_type_18721)); });
                });
            }));
        }))));
        return prism_rtl::deref(v_p1).name == Text::lit("bounded")
            ? inner_p4
            : crate::check::types::add_text(inner_p4, prism_rtl::deref(v_p1).name);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& ps_p7 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_p8 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return run_to_end(fold_job(ps_p7, color_vars_of_type(prism_rtl::deref(prism_rtl::deref(res_p8))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p9 = p0;
                    auto a_pa = p1;
                    call_then(start_color_vars_of_type(a_pa), [=, acc_p9 = std::move(acc_p9)](Array<Text> color_vars_of_type_18890) { return prism_rtl::finished(crate::check::types::union_texts(acc_p9, color_vars_of_type_18890)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& args_pb = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        return run_to_end(fold_job(args_pb, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_pc = p0;
                    auto a_pd = p1;
                    call_then(start_color_vars_of_type(a_pd), [=, acc_pc = std::move(acc_pc)](Array<Text> color_vars_of_type_18977) { return prism_rtl::finished(crate::check::types::union_texts(acc_pc, color_vars_of_type_18977)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& i_pe = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        return color_vars_of_type(prism_rtl::deref(prism_rtl::deref(i_pe)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m)) {
        auto&& e_pf = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        return color_vars_of_type(prism_rtl::deref(prism_rtl::deref(e_pf)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts_pg = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        return run_to_end(fold_job(ts_pg, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_ph = p0;
                    auto a_pi = p1;
                    call_then(start_color_vars_of_type(a_pi), [=, acc_ph = std::move(acc_ph)](Array<Text> color_vars_of_type_19135) { return prism_rtl::finished(crate::check::types::union_texts(acc_ph, color_vars_of_type_19135)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_pj = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return color_vars_of_type(prism_rtl::deref(prism_rtl::deref(x_pj)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k_pk = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pl = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        return crate::check::types::union_texts(color_vars_of_type(prism_rtl::deref(prism_rtl::deref(k_pk))), color_vars_of_type(prism_rtl::deref(prism_rtl::deref(v_pl))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& ty_pm = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        return color_vars_of_type(prism_rtl::deref(prism_rtl::deref(ty_pm)));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> ColorVarsOfType::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p0).kind);
        prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) && prism_rtl::is<crate::syntax::Color::ColorVar>(prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0) ? ({
        auto&& v_p1 = prism_rtl::as<crate::syntax::Color::ColorVar>(prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0).a0;
        auto&& ps_p2 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_p3 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto ps_p2_1 = ps_p2;
        auto res_p3_2 = prism_rtl::deref(prism_rtl::deref(res_p3));
        auto v_p1_3 = v_p1;
        call_then(start_color_vars_of_type(res_p3_2), [=, ps_p2_1 = std::move(ps_p2_1), v_p1_3 = std::move(v_p1_3)](Array<Text> color_vars_of_type_18672) {
        return call_value(fold_job(ps_p2_1, color_vars_of_type_18672, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p5 = p0;
                    auto a_p6 = p1;
                    call_then(start_color_vars_of_type(a_p6), [=, acc_p5 = std::move(acc_p5)](Array<Text> color_vars_of_type_18721) { return prism_rtl::finished(crate::check::types::union_texts(acc_p5, color_vars_of_type_18721)); });
                });
            }));
        }))), [=](Array<Text> fold_18662) {
            return ({
                auto inner_p4 = fold_18662;
                (prism_rtl::deref(v_p1_3).name == Text::lit("bounded")
                ? prism_rtl::finished(inner_p4)
                : prism_rtl::finished(crate::check::types::add_text(inner_p4, prism_rtl::deref(v_p1_3).name)));
            });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& ps_p7 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_p8 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto ps_p7_1 = ps_p7;
        auto res_p8_2 = prism_rtl::deref(prism_rtl::deref(res_p8));
        call_then(start_color_vars_of_type(res_p8_2), [=, ps_p7_1 = std::move(ps_p7_1)](Array<Text> color_vars_of_type_18841) {
        return fold_job(ps_p7_1, color_vars_of_type_18841, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p9 = p0;
                    auto a_pa = p1;
                    call_then(start_color_vars_of_type(a_pa), [=, acc_p9 = std::move(acc_p9)](Array<Text> color_vars_of_type_18890) { return prism_rtl::finished(crate::check::types::union_texts(acc_p9, color_vars_of_type_18890)); });
                });
            }));
        })))->cycle();
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& args_pb = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        fold_job(args_pb, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_pc = p0;
                auto a_pd = p1;
                call_then(start_color_vars_of_type(a_pd), [=, acc_pc = std::move(acc_pc)](Array<Text> color_vars_of_type_18977) { return prism_rtl::finished(crate::check::types::union_texts(acc_pc, color_vars_of_type_18977)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m) ? ({
        auto&& i_pe = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        prism_rtl::more(prism_rtl::rc(ColorVarsOfType(prism_rtl::deref(prism_rtl::deref(i_pe)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) ? ({
        auto&& e_pf = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ColorVarsOfType(prism_rtl::deref(prism_rtl::deref(e_pf)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m) ? ({
        auto&& ts_pg = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        fold_job(ts_pg, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_ph = p0;
                auto a_pi = p1;
                call_then(start_color_vars_of_type(a_pi), [=, acc_ph = std::move(acc_ph)](Array<Text> color_vars_of_type_19135) { return prism_rtl::finished(crate::check::types::union_texts(acc_ph, color_vars_of_type_19135)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_pj = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ColorVarsOfType(prism_rtl::deref(prism_rtl::deref(x_pj)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TMap>(_m) ? ({
        auto&& k_pk = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pl = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        ({
        auto k_pk_1 = prism_rtl::deref(prism_rtl::deref(k_pk));
        auto v_pl_2 = prism_rtl::deref(prism_rtl::deref(v_pl));
        call_then(start_color_vars_of_type(k_pk_1), [=, v_pl_2 = std::move(v_pl_2)](Array<Text> color_vars_of_type_19213) { return call_then(start_color_vars_of_type(v_pl_2), [=](Array<Text> color_vars_of_type_19234) { return prism_rtl::finished(crate::check::types::union_texts(color_vars_of_type_19213, color_vars_of_type_19234)); }); });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m) ? ({
        auto&& ty_pm = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ColorVarsOfType(prism_rtl::deref(prism_rtl::deref(ty_pm)))));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start ColorVarsOfType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_color_vars_of_type(crate::syntax::Type t_p0) {
    return prism_rtl::make_rc<ColorVarsOfType>(t_p0);
}

}  // namespace crate::check::env::reading
