// The module `Check.Env.Decls`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/env/decls/module.hpp>
#include <check/env/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/decls/generic.hpp>
#include <check/env/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Env.Decls`, from `target/bootstrap/cpp-src/prismc/check/env/decls.prism`.
namespace crate::check::env::decls {

/// ConvertTypes: unbounded fn G, St, Text -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> convert_types_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Text& m_p2) {
    auto&& _m = crate::prelude::get(g_p0.mods_p, m_p2);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{g_p0, st_p1};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info_p3 = prism_rtl::some_of(_m);
        auto s0_p4 = ({
            crate::check::types::St this_ = st_p1;
            this_.file_p = prism_rtl::deref(info_p3).file_p;
            (std::move(this_));
        });
        return crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(prism_rtl::deref(info_p3).tree_p).decls_p, std::tuple{g_p0, s0_p4}, ({
            auto info_p3x = info_p3;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=, info_p3x = std::move(info_p3x)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto info_p3xy = info_p3x;
                (crate::prelude::entered(crate::prelude::once_job([=, info_p3xy = std::move(info_p3xy)]() {
                return ({
                    auto [gg_p5, s_p6] = p0;
                    auto d_p7 = p1;
                    (prism_rtl::more(prism_rtl::rc(ConvertTypeDecl(gg_p5, s_p6, info_p3xy, d_p7))));
                });
            })));
            });
        }));
        })));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvertTypes::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& m_p2 = this->m_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).mods_p, m_p2);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g_p0, st_p1})
        : prism_rtl::is_some(_m) ? ({
        auto&& info_p3 = prism_rtl::some_of(_m);
        ({
        auto s0_p4 = ({
            crate::check::types::St this_ = st_p1;
            this_.file_p = prism_rtl::deref(info_p3).file_p;
            (std::move(this_));
        });
        (crate::prelude::fold_job(prism_rtl::deref(prism_rtl::deref(info_p3).tree_p).decls_p, std::tuple{g_p0, s0_p4}, ({
        auto info_p3x = info_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=, info_p3x = std::move(info_p3x)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_p3xy = info_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, info_p3xy = std::move(info_p3xy)]() {
            return ({
                auto [gg_p5, s_p6] = p0;
                auto d_p7 = p1;
                (prism_rtl::more(prism_rtl::rc(ConvertTypeDecl(gg_p5, s_p6, info_p3xy, d_p7))));
            });
        })));
        });
    }));
    }))->cycle());
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ConvertTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_convert_types_f(crate::check::env::G g_p0, crate::check::types::St st_p1, Text m_p2) {
    return prism_rtl::make_rc<ConvertTypes>(g_p0, st_p1, m_p2);
}


/// ConvertDecls: unbounded fn G, St, Text -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> convert_decls_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Text& m_p2) {
    auto&& _m = crate::prelude::get(g_p0.mods_p, m_p2);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{g_p0, st_p1};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info_p3 = prism_rtl::some_of(_m);
        auto s1_p4 = ({
            crate::check::types::St this_ = st_p1;
            this_.file_p = prism_rtl::deref(info_p3).file_p;
            (std::move(this_));
        });
        auto [g2_p9, s2_pa] = crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(prism_rtl::deref(info_p3).tree_p).decls_p, std::tuple{g_p0, s1_p4}, ({
            auto info_p3x = info_p3;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=, info_p3x = std::move(info_p3x)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto info_p3xy = info_p3x;
                (crate::prelude::entered(crate::prelude::once_job([=, info_p3xy = std::move(info_p3xy)]() {
                return ({
                    auto [gg_p6, s_p7] = p0;
                    auto d_p8 = p1;
                    (prism_rtl::more(prism_rtl::rc(ConvertDecl(gg_p6, s_p7, info_p3xy, d_p8))));
                });
            })));
            });
        }));
        })));
        auto s3_p5 = missing_signatures_f(g2_p9, s2_pa, info_p3);
        return std::tuple{g2_p9, s3_p5};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvertDecls::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& m_p2 = this->m_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).mods_p, m_p2);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g_p0, st_p1})
        : prism_rtl::is_some(_m) ? ({
        auto&& info_p3 = prism_rtl::some_of(_m);
        ({
        auto s1_p4 = ({
            crate::check::types::St this_ = st_p1;
            this_.file_p = prism_rtl::deref(info_p3).file_p;
            (std::move(this_));
        });
        auto g_p0x = g_p0;
        (crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(prism_rtl::deref(info_p3).tree_p).decls_p, std::tuple{g_p0x, s1_p4}, ({
        auto info_p3x = info_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=, info_p3x = std::move(info_p3x)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_p3xy = info_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, info_p3xy = std::move(info_p3xy)]() {
            return ({
                auto [gg_p6, s_p7] = p0;
                auto d_p8 = p1;
                (prism_rtl::more(prism_rtl::rc(ConvertDecl(gg_p6, s_p7, info_p3xy, d_p8))));
            });
        })));
        });
    }));
    })), [=](std::tuple<crate::check::env::G, crate::check::types::St> fold_1281) {
        return ({
            auto [g2_p9, s2_pa] = fold_1281;
            auto s3_p5 = missing_signatures_f(g2_p9, s2_pa, info_p3);
            (prism_rtl::finished(std::tuple{g2_p9, s3_p5}));
        });
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ConvertDecls, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_convert_decls_f(crate::check::env::G g_p0, crate::check::types::St st_p1, Text m_p2) {
    return prism_rtl::make_rc<ConvertDecls>(g_p0, st_p1, m_p2);
}


/// ConvertTypeDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> convert_type_decl_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2, const crate::syntax::decls::Decl& d_p3) {
    auto&& _m = d_p3.kind_p;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DType>(_m)) {
        auto&& t_p4 = prism_rtl::as<crate::syntax::decls::DeclKind::DType>(_m).a0;
        auto name_p5 = crate::check::env::qual_key_f(info_p2.name_p, crate::check::env::dotted_f(prism_rtl::deref(prism_rtl::deref(t_p4).name_p).path_p));
        auto ti_p6 = crate::prelude::or_(crate::prelude::get(g_p0.types_p, name_p5), crate::check::env::names::dummy_ty_info_p());
        auto cx_p7 = crate::check::env::reading::cx_of_f(g_p0, info_p2.name_p);
        auto params_p8 = crate::prelude::each(prism_rtl::deref(t_p4).params_p, [&](const crate::syntax::Ident& p_pa) { return prism_rtl::deref(p_pa).name_p; });
        auto self_p9 = crate::check::types::Ty(crate::check::types::Ty::TyCon{name_p5, crate::prelude::each(params_p8, [&](const Text& p_pb) { return crate::check::types::Ty(crate::check::types::Ty::TyQ{p_pb}); })});
        auto&& _m = prism_rtl::deref(t_p4).body_o;
        if (prism_rtl::is_none(_m)) {
            return std::tuple{g_p0, st_p1};
        }
        if (prism_rtl::is_some(_m)) {
            auto&& body_pc = prism_rtl::some_of(_m);
            if (prism_rtl::is<crate::syntax::decls::TypeBody::TbRecord>(body_pc)) {
                auto&& fs_pd = prism_rtl::as<crate::syntax::decls::TypeBody::TbRecord>(body_pc).a0;
                auto [fields_pl, st2_pm] = crate::prelude::run_to_end(crate::prelude::fold_job(fs_pd, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st_p1}, ({
                    auto cx_p7x = cx_p7;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field>)>>(prism_rtl::rc([=, cx_p7x = std::move(cx_p7x)](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto cx_p7xy = cx_p7x;
                        (crate::prelude::entered(crate::prelude::once_job([=, cx_p7xy = std::move(cx_p7xy)]() {
                        return ({
                            auto [acc_pg, s_ph] = p0;
                            auto f_pi = p1;
                            (crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p7xy, s_ph, prism_rtl::deref(f_pi).ty_p), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_2032) {
                            return ({
                                auto [ft_pj, s2_pk] = conv_type_f_2032;
                                (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pg, std::tuple{prism_rtl::deref(prism_rtl::deref(f_pi).name_p).name_p, ft_pj}), s2_pk}));
                            });
                        }));
                        });
                    })));
                    });
                }));
                })));
                auto ctor_pe = crate::check::env::CtorInfo{.name_p = name_p5, .owner_p = name_p5, .params_p = params_p8, .args_p = crate::prelude::each(fields_pl, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                    auto&& ft_pn = std::get<1>(_p0);
                    return ft_pn;
                }), .fields_p = crate::prelude::each(fields_pl, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                    auto&& fname_po = std::get<0>(_p0);
                    return fname_po;
                }), .ty_p = self_p9, .index_p = Nat(0u)};
                auto upd_pf = ({
                    crate::check::env::G this_ = g_p0;
                    this_.types_p = crate::prelude::insert(this_.types_p, name_p5, with_body_f(ti_p6, crate::check::env::TyBody(crate::check::env::TyBody::BRecord{fields_pl})));
                    this_.ctors_p = crate::prelude::insert(this_.ctors_p, name_p5, ctor_pe);
                    (std::move(this_));
                });
                return std::tuple{upd_pf, st2_pm};
            }
            if (prism_rtl::is<crate::syntax::decls::TypeBody::TbChoice>(body_pc)) {
                auto&& cs_pp = prism_rtl::as<crate::syntax::decls::TypeBody::TbChoice>(body_pc).a0;
                return conv_cases_f(g_p0, st_p1, cx_p7, ti_p6, name_p5, params_p8, self_p9, cs_pp);
            }
            if (prism_rtl::is<crate::syntax::decls::TypeBody::TbNewtype>(body_pc)) {
                auto&& c_pq = prism_rtl::as<crate::syntax::decls::TypeBody::TbNewtype>(body_pc).a0;
                return conv_cases_f(g_p0, st_p1, cx_p7, ti_p6, name_p5, params_p8, self_p9, Array(std::vector{c_pq}));
            }
            if (prism_rtl::is<crate::syntax::decls::TypeBody::TbUnit>(body_pc)) {
                auto&& i_pr = prism_rtl::as<crate::syntax::decls::TypeBody::TbUnit>(body_pc).a0;
                auto ctor_ps = crate::check::env::CtorInfo{.name_p = crate::check::env::qual_key_f(info_p2.name_p, prism_rtl::deref(i_pr).name_p), .owner_p = name_p5, .params_p = params_p8, .args_p = Array<crate::check::types::Ty>{}, .fields_p = Array<Text>{}, .ty_p = self_p9, .index_p = Nat(0u)};
                auto upd_pt = ({
                    crate::check::env::G this_ = g_p0;
                    this_.types_p = crate::prelude::insert(this_.types_p, name_p5, with_body_f(ti_p6, crate::check::env::TyBody(crate::check::env::TyBody::BChoice{Array(std::vector{std::tuple{prism_rtl::deref(i_pr).name_p, Array<crate::check::types::Ty>{}}})})));
                    this_.ctors_p = crate::prelude::insert(this_.ctors_p, crate::check::env::qual_key_f(info_p2.name_p, prism_rtl::deref(i_pr).name_p), ctor_ps);
                    (std::move(this_));
                });
                return std::tuple{upd_pt, st_p1};
            }
            if (prism_rtl::is<crate::syntax::decls::TypeBody::TbRow>(body_pc)) {
                auto upd_pu = ({
                    crate::check::env::G this_ = g_p0;
                    this_.types_p = crate::prelude::insert(this_.types_p, name_p5, with_body_f(ti_p6, crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{})));
                    (std::move(this_));
                });
                return std::tuple{upd_pu, st_p1};
            }
            if (prism_rtl::is<crate::syntax::decls::TypeBody::TbAlias>(body_pc)) {
                auto&& a_pv = prism_rtl::as<crate::syntax::decls::TypeBody::TbAlias>(body_pc).a0;
                auto [at_p11, st2_p12] = crate::check::env::reading::conv_type_f(cx_p7, st_p1, a_pv);
                auto upd_p10 = ({
                    crate::check::env::G this_ = g_p0;
                    this_.types_p = crate::prelude::insert(this_.types_p, name_p5, with_body_f(ti_p6, crate::check::env::TyBody(crate::check::env::TyBody::BAlias{at_p11})));
                    (std::move(this_));
                });
                return std::tuple{upd_p10, st2_p12};
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return std::tuple{g_p0, st_p1};
    }
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvertTypeDecl::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& info_p2 = this->info_p2;
    const auto& d_p3 = this->d_p3;
    return ({
        auto&& _m = prism_rtl::deref(d_p3).kind_p;
        prism_rtl::is<crate::syntax::decls::DeclKind::DType>(_m) ? ({
        auto&& t_p4 = prism_rtl::as<crate::syntax::decls::DeclKind::DType>(_m).a0;
        ({
        auto name_p5 = crate::check::env::qual_key_f(prism_rtl::deref(info_p2).name_p, crate::check::env::dotted_f(prism_rtl::deref(prism_rtl::deref(t_p4).name_p).path_p));
        auto ti_p6 = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(g_p0).types_p, name_p5), crate::check::env::names::dummy_ty_info_p());
        auto cx_p7 = crate::check::env::reading::cx_of_f(g_p0, prism_rtl::deref(info_p2).name_p);
        auto params_p8 = crate::prelude::each(prism_rtl::deref(t_p4).params_p, [&](const crate::syntax::Ident& p_pa) { return prism_rtl::deref(p_pa).name_p; });
        auto self_p9 = crate::check::types::Ty(crate::check::types::Ty::TyCon{name_p5, crate::prelude::each(params_p8, [&](const Text& p_pb) { return crate::check::types::Ty(crate::check::types::Ty::TyQ{p_pb}); })});
        ({
        auto&& _m = prism_rtl::deref(t_p4).body_o;
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g_p0, st_p1})
        : prism_rtl::is_some(_m) ? ({
        auto&& body_pc = prism_rtl::some_of(_m);
        ({
        prism_rtl::is<crate::syntax::decls::TypeBody::TbRecord>(body_pc) ? ({
        auto&& fs_pd = prism_rtl::as<crate::syntax::decls::TypeBody::TbRecord>(body_pc).a0;
        ({
        auto fs_pdx = fs_pd;
        auto g_p0x = g_p0;
        auto st_p1x = st_p1;
        (crate::prelude::call_value(crate::prelude::fold_job(fs_pdx, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st_p1x}, ({
        auto cx_p7x = cx_p7;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field>)>>(prism_rtl::rc([=, cx_p7x = std::move(cx_p7x)](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx_p7xy = cx_p7x;
            (crate::prelude::entered(crate::prelude::once_job([=, cx_p7xy = std::move(cx_p7xy)]() {
            return ({
                auto [acc_pg, s_ph] = p0;
                auto f_pi = p1;
                (crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p7xy, s_ph, prism_rtl::deref(f_pi).ty_p), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_2032) {
                return ({
                    auto [ft_pj, s2_pk] = conv_type_f_2032;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pg, std::tuple{prism_rtl::deref(prism_rtl::deref(f_pi).name_p).name_p, ft_pj}), s2_pk}));
                });
            }));
            });
        })));
        });
    }));
    })), [=, g_p0x = std::move(g_p0x)](std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St> fold_1951) {
        return ({
            auto [fields_pl, st2_pm] = fold_1951;
            auto ctor_pe = crate::check::env::CtorInfo{.name_p = name_p5, .owner_p = name_p5, .params_p = params_p8, .args_p = crate::prelude::each(fields_pl, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                auto&& ft_pn = std::get<1>(_p0);
                return ft_pn;
            }), .fields_p = crate::prelude::each(fields_pl, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                auto&& fname_po = std::get<0>(_p0);
                return fname_po;
            }), .ty_p = self_p9, .index_p = Nat(0u)};
            auto upd_pf = ({
                crate::check::env::G this_ = g_p0x;
                this_.types_p = crate::prelude::insert(this_.types_p, name_p5, with_body_f(ti_p6, crate::check::env::TyBody(crate::check::env::TyBody::BRecord{fields_pl})));
                this_.ctors_p = crate::prelude::insert(this_.ctors_p, name_p5, ctor_pe);
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{upd_pf, st2_pm}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::decls::TypeBody::TbChoice>(body_pc) ? ({
        auto&& cs_pp = prism_rtl::as<crate::syntax::decls::TypeBody::TbChoice>(body_pc).a0;
        prism_rtl::more(prism_rtl::rc(ConvCases(g_p0, st_p1, cx_p7, ti_p6, name_p5, params_p8, self_p9, cs_pp)));
    })
        : prism_rtl::is<crate::syntax::decls::TypeBody::TbNewtype>(body_pc) ? ({
        auto&& c_pq = prism_rtl::as<crate::syntax::decls::TypeBody::TbNewtype>(body_pc).a0;
        prism_rtl::more(prism_rtl::rc(ConvCases(g_p0, st_p1, cx_p7, ti_p6, name_p5, params_p8, self_p9, Array(std::vector{c_pq}))));
    })
        : prism_rtl::is<crate::syntax::decls::TypeBody::TbUnit>(body_pc) ? ({
        auto&& i_pr = prism_rtl::as<crate::syntax::decls::TypeBody::TbUnit>(body_pc).a0;
        ({
        auto ctor_ps = crate::check::env::CtorInfo{.name_p = crate::check::env::qual_key_f(prism_rtl::deref(info_p2).name_p, prism_rtl::deref(i_pr).name_p), .owner_p = name_p5, .params_p = params_p8, .args_p = Array<crate::check::types::Ty>{}, .fields_p = Array<Text>{}, .ty_p = self_p9, .index_p = Nat(0u)};
        auto upd_pt = ({
            crate::check::env::G this_ = g_p0;
            this_.types_p = crate::prelude::insert(this_.types_p, name_p5, with_body_f(ti_p6, crate::check::env::TyBody(crate::check::env::TyBody::BChoice{Array(std::vector{std::tuple{prism_rtl::deref(i_pr).name_p, Array<crate::check::types::Ty>{}}})})));
            this_.ctors_p = crate::prelude::insert(this_.ctors_p, crate::check::env::qual_key_f(prism_rtl::deref(info_p2).name_p, prism_rtl::deref(i_pr).name_p), ctor_ps);
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{upd_pt, st_p1}));
    });
    })
        : prism_rtl::is<crate::syntax::decls::TypeBody::TbRow>(body_pc) ? ({
        auto upd_pu = ({
            crate::check::env::G this_ = g_p0;
            this_.types_p = crate::prelude::insert(this_.types_p, name_p5, with_body_f(ti_p6, crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{})));
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{upd_pu, st_p1}));
    })
        : prism_rtl::is<crate::syntax::decls::TypeBody::TbAlias>(body_pc) ? ({
        auto&& a_pv = prism_rtl::as<crate::syntax::decls::TypeBody::TbAlias>(body_pc).a0;
        ({
        auto a_pvx = a_pv;
        auto g_p0x = g_p0;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p7, st_p1x, a_pvx), [=, g_p0x = std::move(g_p0x)](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_3366) {
        return ({
            auto [at_p11, st2_p12] = conv_type_f_3366;
            auto upd_p10 = ({
                crate::check::env::G this_ = g_p0x;
                this_.types_p = crate::prelude::insert(this_.types_p, name_p5, with_body_f(ti_p6, crate::check::env::TyBody(crate::check::env::TyBody::BAlias{at_p11})));
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{upd_p10, st2_p12}));
        });
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::finished(std::tuple{g_p0, st_p1});
    });
}


/// `Start ConvertTypeDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_convert_type_decl_f(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::Decl d_p3) {
    return prism_rtl::make_rc<ConvertTypeDecl>(g_p0, st_p1, info_p2, d_p3);
}


/// WithBody: fn TyInfo, TyBody -> TyInfo
crate::check::env::TyInfo with_body_f(const crate::check::env::TyInfo& ti_p0, const crate::check::env::TyBody& b_p1) {
    crate::check::env::TyInfo this_ = ti_p0;
    this_.body_p = b_p1;
    return this_;
}


/// ConvCases: unbounded fn G, St, Cx, TyInfo, Text, [Text], Ty, [Case] -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> conv_cases_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::reading::Cx_& cx_p2, const crate::check::env::TyInfo& ti_p3, const Text& name_p4, const Array<Text>& params_p5, const crate::check::types::Ty& self_p6, const Array<crate::syntax::decls::Case_>& cs_p7) {
    auto [cases_pg, st2_ph] = crate::prelude::run_to_end(crate::prelude::fold_job(cs_p7, std::tuple{Array<std::tuple<Text, Array<crate::check::types::Ty>>>{}, st_p1}, ({
        auto cx_p2x = cx_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>, crate::syntax::decls::Case_>)>>(prism_rtl::rc([=, cx_p2x = std::move(cx_p2x)](std::tuple<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>, crate::syntax::decls::Case_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx_p2xy = cx_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, cx_p2xy = std::move(cx_p2xy)]() {
            return ({
                auto [acc_pa, s_pb] = p0;
                auto c_pc = p1;
                ({
                auto s1_pd = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    auto&& _m = prism_rtl::deref(c_pc).indexed_o;
                    if (prism_rtl::is_some(_m)) {
                        _v.set(crate::check::types::recording::err_f(s_pb, Text::lit("unsupported"), prism_rtl::deref(c_pc).span_p, Text::lit("this checker does not implement indexed choices for user types")));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s_pb);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (crate::prelude::call_then(crate::check::env::reading::start_conv_types_f(cx_p2xy, s1_pd, prism_rtl::deref(c_pc).args_p), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_f_4053) {
                return ({
                    auto [args_pe, s2_pf] = conv_types_f_4053;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pa, std::tuple{crate::check::env::sname_key_f(prism_rtl::deref(c_pc).name_p), args_pe}), s2_pf}));
                });
            }));
            });
            });
        })));
        });
    }));
    })));
    auto g2_p8 = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(cases_pg)), g_p0, [&](const crate::check::env::G& gg_pi, const Nat& i_pj) {
        return ({
            auto [cn_pl, args_pm] = crate::prelude::or_(crate::prelude::index(cases_pg, i_pj), std::tuple{Text::lit(""), Array<crate::check::types::Ty>{}});
            auto qk_pk = crate::check::env::qual_key_f(ti_p3.home_p, cn_pl);
            ({
            crate::check::env::G this_ = gg_pi;
            this_.ctors_p = crate::prelude::insert(this_.ctors_p, qk_pk, crate::check::env::CtorInfo{.name_p = qk_pk, .owner_p = name_p4, .params_p = params_p5, .args_p = args_pm, .fields_p = Array<Text>{}, .ty_p = self_p6, .index_p = i_pj});
            (std::move(this_));
        });
        });
    });
    auto upd_p9 = ({
        crate::check::env::G this_ = g2_p8;
        this_.types_p = crate::prelude::insert(this_.types_p, name_p4, with_body_f(ti_p3, crate::check::env::TyBody(crate::check::env::TyBody::BChoice{cases_pg})));
        (std::move(this_));
    });
    return std::tuple{upd_p9, st2_ph};
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvCases::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& cx_p2 = this->cx_p2;
    const auto& ti_p3 = this->ti_p3;
    const auto& name_p4 = this->name_p4;
    const auto& params_p5 = this->params_p5;
    const auto& self_p6 = this->self_p6;
    const auto& cs_p7 = this->cs_p7;
    auto cs_p7x = cs_p7;
    auto cx_p2x = cx_p2;
    auto g_p0x = g_p0;
    auto name_p4x = name_p4;
    auto params_p5x = params_p5;
    auto self_p6x = self_p6;
    auto st_p1x = st_p1;
    auto ti_p3x = ti_p3;
    return crate::prelude::call_value(crate::prelude::fold_job(cs_p7x, std::tuple{Array<std::tuple<Text, Array<crate::check::types::Ty>>>{}, st_p1x}, ({
        auto cx_p2xx = cx_p2x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>, crate::syntax::decls::Case_>)>>(prism_rtl::rc([=, cx_p2xx = std::move(cx_p2xx)](std::tuple<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>, crate::syntax::decls::Case_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx_p2xxy = cx_p2xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cx_p2xxy = std::move(cx_p2xxy)]() {
            return ({
                auto [acc_pa, s_pb] = p0;
                auto c_pc = p1;
                ({
                auto s1_pd = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    auto&& _m = prism_rtl::deref(c_pc).indexed_o;
                    if (prism_rtl::is_some(_m)) {
                        _v.set(crate::check::types::recording::err_f(s_pb, Text::lit("unsupported"), prism_rtl::deref(c_pc).span_p, Text::lit("this checker does not implement indexed choices for user types")));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s_pb);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (crate::prelude::call_then(crate::check::env::reading::start_conv_types_f(cx_p2xxy, s1_pd, prism_rtl::deref(c_pc).args_p), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_f_4053) {
                return ({
                    auto [args_pe, s2_pf] = conv_types_f_4053;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pa, std::tuple{crate::check::env::sname_key_f(prism_rtl::deref(c_pc).name_p), args_pe}), s2_pf}));
                });
            }));
            });
            });
        })));
        });
    }));
    })), [=](std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St> fold_3815) {
        return ({
            auto [cases_pg, st2_ph] = fold_3815;
            auto g2_p8 = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(cases_pg)), g_p0x, [&](const crate::check::env::G& gg_pi, const Nat& i_pj) {
                return ({
                    auto [cn_pl, args_pm] = crate::prelude::or_(crate::prelude::index(cases_pg, i_pj), std::tuple{Text::lit(""), Array<crate::check::types::Ty>{}});
                    auto qk_pk = crate::check::env::qual_key_f(prism_rtl::deref(ti_p3x).home_p, cn_pl);
                    ({
                    crate::check::env::G this_ = gg_pi;
                    this_.ctors_p = crate::prelude::insert(this_.ctors_p, qk_pk, crate::check::env::CtorInfo{.name_p = qk_pk, .owner_p = name_p4x, .params_p = params_p5x, .args_p = args_pm, .fields_p = Array<Text>{}, .ty_p = self_p6x, .index_p = i_pj});
                    (std::move(this_));
                });
                });
            });
            auto upd_p9 = ({
                crate::check::env::G this_ = g2_p8;
                this_.types_p = crate::prelude::insert(this_.types_p, name_p4x, with_body_f(ti_p3x, crate::check::env::TyBody(crate::check::env::TyBody::BChoice{cases_pg})));
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{upd_p9, st2_ph}));
        });
    });
}


/// `Start ConvCases, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_conv_cases_f(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::reading::Cx_ cx_p2, crate::check::env::TyInfo ti_p3, Text name_p4, Array<Text> params_p5, crate::check::types::Ty self_p6, Array<crate::syntax::decls::Case_> cs_p7) {
    return prism_rtl::make_rc<ConvCases>(g_p0, st_p1, cx_p2, ti_p3, name_p4, params_p5, self_p6, cs_p7);
}


/// ConvertDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> convert_decl_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2, const crate::syntax::decls::Decl& d_p3) {
    auto&& _m = d_p3.kind_p;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DSignature>(_m)) {
        auto&& s_p4 = prism_rtl::as<crate::syntax::decls::DeclKind::DSignature>(_m).a0;
        auto qk_p5 = crate::check::env::qual_key_f(info_p2.name_p, crate::check::env::def_name_text_f(prism_rtl::deref(s_p4).name_p));
        auto cx_p6 = crate::check::env::reading::cx_of_f(g_p0, info_p2.name_p);
        auto [sc_p9, st1_pa] = crate::check::env::reading::sig_scheme_f(cx_p6, st_p1, prism_rtl::deref(s_p4).ty_p, prism_rtl::deref(s_p4).bounds_p);
        auto st2_p7 = lens_check_f(st1_pa, crate::check::env::def_name_text_f(prism_rtl::deref(s_p4).name_p), prism_rtl::deref(s_p4).ty_p, crate::check::env::def_name_span_f(prism_rtl::deref(s_p4).name_p));
        auto st3_p8 = check_mark_function_f(st2_p7, crate::check::env::def_name_text_f(prism_rtl::deref(s_p4).name_p), prism_rtl::deref(sc_p9).ty_p, crate::check::env::def_name_span_f(prism_rtl::deref(s_p4).name_p));
        return crate::check::env::has_key_f(g_p0.vals_p, qk_p5)
            ? std::tuple{g_p0, crate::check::types::recording::err_f(st3_p8, Text::lit("collision"), d_p3.span_p, prism_rtl::cat("a second signature for `", crate::check::env::def_name_text_f(prism_rtl::deref(s_p4).name_p), "`"))}
            : ({
            auto upd_pb = ({
                crate::check::env::G this_ = g_p0;
                this_.vals_p = crate::prelude::insert(this_.vals_p, qk_p5, crate::check::env::ValInfo{.qk_p = qk_p5, .scheme_p = sc_p9, .sort_p = Text::lit("fn"), .has_sig_p = true, .home_p = info_p2.name_p, .file_p = info_p2.file_p, .span_p = d_p3.span_p});
                (std::move(this_));
            });
            std::tuple{upd_pb, st3_p8};
        });
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DFn>(_m)) {
        auto&& f_pc = prism_rtl::as<crate::syntax::decls::DeclKind::DFn>(_m).a0;
        auto qk_pd = crate::check::env::qual_key_f(info_p2.name_p, crate::check::env::def_name_text_f(prism_rtl::deref(f_pc).name_p));
        return std::tuple{add_clause_f(g_p0, info_p2, qk_pd, crate::check::env::def_name_text_f(prism_rtl::deref(f_pc).name_p), f_pc, d_p3.span_p, st_p1), st_p1};
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DLet>(_m)) {
        auto&& l_pe = prism_rtl::as<crate::syntax::decls::DeclKind::DLet>(_m).a0;
        auto names_pf = crate::check::env::names::pattern_names_f(prism_rtl::deref(l_pe).pattern_p);
        auto qk_pg = crate::check::env::qual_key_f(info_p2.name_p, crate::prelude::or_(crate::prelude::index(names_pf, Nat(0u)), Text::lit("")));
        auto def_ph = crate::check::env::Def{.qk_p = qk_pg, .name_p = crate::prelude::or_(crate::prelude::index(names_pf, Nat(0u)), Text::lit("")), .home_p = info_p2.name_p, .file_p = info_p2.file_p, .span_p = d_p3.span_p, .body_p = crate::check::env::DefBody(crate::check::env::DefBody::DbLet{l_pe})};
        auto upd_pi = ({
            crate::check::env::G this_ = g_p0;
            this_.defs_p = crate::prelude::push(this_.defs_p, def_ph);
            (std::move(this_));
        });
        return std::tuple{upd_pi, st_p1};
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DWidget>(_m)) {
        auto&& w_pj = prism_rtl::as<crate::syntax::decls::DeclKind::DWidget>(_m).a0;
        auto qk_pk = crate::check::env::qual_key_f(info_p2.name_p, crate::check::env::sname_key_f(prism_rtl::deref(w_pj).name_p));
        auto def_pl = crate::check::env::Def{.qk_p = qk_pk, .name_p = crate::check::env::sname_key_f(prism_rtl::deref(w_pj).name_p), .home_p = info_p2.name_p, .file_p = info_p2.file_p, .span_p = d_p3.span_p, .body_p = crate::check::env::DefBody(crate::check::env::DefBody::DbWidget{w_pj})};
        auto upd_pm = ({
            crate::check::env::G this_ = g_p0;
            this_.defs_p = crate::prelude::push(this_.defs_p, def_pl);
            (std::move(this_));
        });
        return std::tuple{upd_pm, st_p1};
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTag>(_m)) {
        auto&& t_pn = prism_rtl::as<crate::syntax::decls::DeclKind::DTag>(_m).a0;
        return conv_tag_f(g_p0, st_p1, info_p2, t_pn, d_p3.span_p);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m)) {
        auto&& t_po = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        return conv_trait_f(g_p0, st_p1, info_p2, t_po, d_p3.span_p);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DImpl>(_m)) {
        auto&& i_pp = prism_rtl::as<crate::syntax::decls::DeclKind::DImpl>(_m).a0;
        return conv_impl_f(g_p0, st_p1, info_p2, i_pp, d_p3.span_p);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DCheck>(_m)) {
        auto&& c_pq = prism_rtl::as<crate::syntax::decls::DeclKind::DCheck>(_m).a0;
        auto upd_pr = ({
            crate::check::env::G this_ = g_p0;
            this_.defs_p = crate::prelude::push(this_.defs_p, crate::check::env::Def{.qk_p = crate::check::env::qual_key_f(info_p2.name_p, prism_rtl::cat("check ", prism_rtl::deref(prism_rtl::deref(c_pq).name_p).name_p)), .name_p = prism_rtl::deref(prism_rtl::deref(c_pq).name_p).name_p, .home_p = info_p2.name_p, .file_p = info_p2.file_p, .span_p = d_p3.span_p, .body_p = crate::check::env::DefBody(crate::check::env::DefBody::DbCheck{c_pq})});
            (std::move(this_));
        });
        return std::tuple{upd_pr, st_p1};
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTest>(_m)) {
        auto&& t_ps = prism_rtl::as<crate::syntax::decls::DeclKind::DTest>(_m).a0;
        auto upd_pt = ({
            crate::check::env::G this_ = g_p0;
            this_.defs_p = crate::prelude::push(this_.defs_p, crate::check::env::Def{.qk_p = crate::check::env::qual_key_f(info_p2.name_p, prism_rtl::cat("test ", prism_rtl::deref(prism_rtl::deref(t_ps).name_p).name_p)), .name_p = prism_rtl::deref(prism_rtl::deref(t_ps).name_p).name_p, .home_p = info_p2.name_p, .file_p = info_p2.file_p, .span_p = d_p3.span_p, .body_p = crate::check::env::DefBody(crate::check::env::DefBody::DbTest{t_ps})});
            (std::move(this_));
        });
        return std::tuple{upd_pt, st_p1};
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DStmt>(_m)) {
        auto&& s_pu = prism_rtl::as<crate::syntax::decls::DeclKind::DStmt>(_m).a0;
        auto&& _m = prism_rtl::deref(s_pu).kind_p;
        if (prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m)) {
            return std::tuple{g_p0, st_p1};
        }
        {
            return std::tuple{g_p0, crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), d_p3.span_p, Text::lit("a statement at the top of a file: nothing at top level is built"))};
        }
    }
    {
        return std::tuple{g_p0, st_p1};
    }
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvertDecl::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& info_p2 = this->info_p2;
    const auto& d_p3 = this->d_p3;
    return ({
        auto&& _m = prism_rtl::deref(d_p3).kind_p;
        prism_rtl::is<crate::syntax::decls::DeclKind::DSignature>(_m) ? ({
        auto&& s_p4 = prism_rtl::as<crate::syntax::decls::DeclKind::DSignature>(_m).a0;
        ({
        auto qk_p5 = crate::check::env::qual_key_f(prism_rtl::deref(info_p2).name_p, crate::check::env::def_name_text_f(prism_rtl::deref(s_p4).name_p));
        auto cx_p6 = crate::check::env::reading::cx_of_f(g_p0, prism_rtl::deref(info_p2).name_p);
        auto d_p3x = d_p3;
        auto g_p0x = g_p0;
        auto info_p2x = info_p2;
        auto s_p4x = s_p4;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::env::reading::start_sig_scheme_f(cx_p6, st_p1x, prism_rtl::deref(s_p4x).ty_p, prism_rtl::deref(s_p4x).bounds_p), [=, qk_p5 = std::move(qk_p5), d_p3x = std::move(d_p3x), g_p0x = std::move(g_p0x), info_p2x = std::move(info_p2x)](std::tuple<crate::check::types::Scheme, crate::check::types::St> sig_scheme_f_4784) {
        return ({
            auto [sc_p9, st1_pa] = sig_scheme_f_4784;
            auto st2_p7 = lens_check_f(st1_pa, crate::check::env::def_name_text_f(prism_rtl::deref(s_p4x).name_p), prism_rtl::deref(s_p4x).ty_p, crate::check::env::def_name_span_f(prism_rtl::deref(s_p4x).name_p));
            (crate::prelude::call_then(start_check_mark_function_f(st2_p7, crate::check::env::def_name_text_f(prism_rtl::deref(s_p4x).name_p), prism_rtl::deref(sc_p9).ty_p, crate::check::env::def_name_span_f(prism_rtl::deref(s_p4x).name_p)), [=](crate::check::types::St check_mark_function_f_4917) {
            return ({
                auto st3_p8 = check_mark_function_f_4917;
                (crate::check::env::has_key_f(prism_rtl::deref(g_p0x).vals_p, qk_p5)
                ? prism_rtl::finished(std::tuple{g_p0x, crate::check::types::recording::err_f(st3_p8, Text::lit("collision"), prism_rtl::deref(d_p3x).span_p, prism_rtl::cat("a second signature for `", crate::check::env::def_name_text_f(prism_rtl::deref(s_p4x).name_p), "`"))})
                : ({
                auto upd_pb = ({
                    crate::check::env::G this_ = g_p0x;
                    this_.vals_p = crate::prelude::insert(this_.vals_p, qk_p5, crate::check::env::ValInfo{.qk_p = qk_p5, .scheme_p = sc_p9, .sort_p = Text::lit("fn"), .has_sig_p = true, .home_p = prism_rtl::deref(info_p2x).name_p, .file_p = prism_rtl::deref(info_p2x).file_p, .span_p = prism_rtl::deref(d_p3x).span_p});
                    (std::move(this_));
                });
                (prism_rtl::finished(std::tuple{upd_pb, st3_p8}));
            }));
            });
        }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DFn>(_m) ? ({
        auto&& f_pc = prism_rtl::as<crate::syntax::decls::DeclKind::DFn>(_m).a0;
        ({
        auto qk_pd = crate::check::env::qual_key_f(prism_rtl::deref(info_p2).name_p, crate::check::env::def_name_text_f(prism_rtl::deref(f_pc).name_p));
        (prism_rtl::finished(std::tuple{add_clause_f(g_p0, info_p2, qk_pd, crate::check::env::def_name_text_f(prism_rtl::deref(f_pc).name_p), f_pc, prism_rtl::deref(d_p3).span_p, st_p1), st_p1}));
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DLet>(_m) ? ({
        auto&& l_pe = prism_rtl::as<crate::syntax::decls::DeclKind::DLet>(_m).a0;
        ({
        auto d_p3x = d_p3;
        auto g_p0x = g_p0;
        auto info_p2x = info_p2;
        auto l_pex = l_pe;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(prism_rtl::deref(l_pex).pattern_p), [=, d_p3x = std::move(d_p3x), g_p0x = std::move(g_p0x), info_p2x = std::move(info_p2x), st_p1x = std::move(st_p1x)](Array<Text> pattern_names_f_5497) {
        return ({
            auto names_pf = pattern_names_f_5497;
            auto qk_pg = crate::check::env::qual_key_f(prism_rtl::deref(info_p2x).name_p, crate::prelude::or_(crate::prelude::index(names_pf, Nat(0u)), Text::lit("")));
            auto def_ph = crate::check::env::Def{.qk_p = qk_pg, .name_p = crate::prelude::or_(crate::prelude::index(names_pf, Nat(0u)), Text::lit("")), .home_p = prism_rtl::deref(info_p2x).name_p, .file_p = prism_rtl::deref(info_p2x).file_p, .span_p = prism_rtl::deref(d_p3x).span_p, .body_p = crate::check::env::DefBody(crate::check::env::DefBody::DbLet{l_pex})};
            auto upd_pi = ({
                crate::check::env::G this_ = g_p0x;
                this_.defs_p = crate::prelude::push(this_.defs_p, def_ph);
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{upd_pi, st_p1x}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DWidget>(_m) ? ({
        auto&& w_pj = prism_rtl::as<crate::syntax::decls::DeclKind::DWidget>(_m).a0;
        ({
        auto qk_pk = crate::check::env::qual_key_f(prism_rtl::deref(info_p2).name_p, crate::check::env::sname_key_f(prism_rtl::deref(w_pj).name_p));
        auto def_pl = crate::check::env::Def{.qk_p = qk_pk, .name_p = crate::check::env::sname_key_f(prism_rtl::deref(w_pj).name_p), .home_p = prism_rtl::deref(info_p2).name_p, .file_p = prism_rtl::deref(info_p2).file_p, .span_p = prism_rtl::deref(d_p3).span_p, .body_p = crate::check::env::DefBody(crate::check::env::DefBody::DbWidget{w_pj})};
        auto upd_pm = ({
            crate::check::env::G this_ = g_p0;
            this_.defs_p = crate::prelude::push(this_.defs_p, def_pl);
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{upd_pm, st_p1}));
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTag>(_m) ? ({
        auto&& t_pn = prism_rtl::as<crate::syntax::decls::DeclKind::DTag>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvTag(g_p0, st_p1, info_p2, t_pn, prism_rtl::deref(d_p3).span_p)));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m) ? ({
        auto&& t_po = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvTrait(g_p0, st_p1, info_p2, t_po, prism_rtl::deref(d_p3).span_p)));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DImpl>(_m) ? ({
        auto&& i_pp = prism_rtl::as<crate::syntax::decls::DeclKind::DImpl>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvImpl(g_p0, st_p1, info_p2, i_pp, prism_rtl::deref(d_p3).span_p)));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DCheck>(_m) ? ({
        auto&& c_pq = prism_rtl::as<crate::syntax::decls::DeclKind::DCheck>(_m).a0;
        ({
        auto upd_pr = ({
            crate::check::env::G this_ = g_p0;
            this_.defs_p = crate::prelude::push(this_.defs_p, crate::check::env::Def{.qk_p = crate::check::env::qual_key_f(prism_rtl::deref(info_p2).name_p, prism_rtl::cat("check ", prism_rtl::deref(prism_rtl::deref(c_pq).name_p).name_p)), .name_p = prism_rtl::deref(prism_rtl::deref(c_pq).name_p).name_p, .home_p = prism_rtl::deref(info_p2).name_p, .file_p = prism_rtl::deref(info_p2).file_p, .span_p = prism_rtl::deref(d_p3).span_p, .body_p = crate::check::env::DefBody(crate::check::env::DefBody::DbCheck{c_pq})});
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{upd_pr, st_p1}));
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTest>(_m) ? ({
        auto&& t_ps = prism_rtl::as<crate::syntax::decls::DeclKind::DTest>(_m).a0;
        ({
        auto upd_pt = ({
            crate::check::env::G this_ = g_p0;
            this_.defs_p = crate::prelude::push(this_.defs_p, crate::check::env::Def{.qk_p = crate::check::env::qual_key_f(prism_rtl::deref(info_p2).name_p, prism_rtl::cat("test ", prism_rtl::deref(prism_rtl::deref(t_ps).name_p).name_p)), .name_p = prism_rtl::deref(prism_rtl::deref(t_ps).name_p).name_p, .home_p = prism_rtl::deref(info_p2).name_p, .file_p = prism_rtl::deref(info_p2).file_p, .span_p = prism_rtl::deref(d_p3).span_p, .body_p = crate::check::env::DefBody(crate::check::env::DefBody::DbTest{t_ps})});
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{upd_pt, st_p1}));
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DStmt>(_m) ? ({
        auto&& s_pu = prism_rtl::as<crate::syntax::decls::DeclKind::DStmt>(_m).a0;
        ({
        auto&& _m = prism_rtl::deref(s_pu).kind_p;
        prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m) ? prism_rtl::finished(std::tuple{g_p0, st_p1})
        : prism_rtl::finished(std::tuple{g_p0, crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), prism_rtl::deref(d_p3).span_p, Text::lit("a statement at the top of a file: nothing at top level is built"))});
    });
    })
        : prism_rtl::finished(std::tuple{g_p0, st_p1});
    });
}


/// `Start ConvertDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_convert_decl_f(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::Decl d_p3) {
    return prism_rtl::make_rc<ConvertDecl>(g_p0, st_p1, info_p2, d_p3);
}


/// AddClause: fn G, ModInfo, Text, Text, FnClause, Range, St -> G
crate::check::env::G add_clause_f(const crate::check::env::G& g_p0, const crate::check::env::ModInfo& info_p1, const Text& qk_p2, const Text& name_p3, const crate::syntax::decls::FnClause& f_p4, const crate::syntax::Range& span_p5, const crate::check::types::St& st_p6) {
    auto&& _m = crate::prelude::get(g_p0.fn_at_p, qk_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& i_p7 = prism_rtl::some_of(_m);
        crate::check::env::G this_ = g_p0;
        this_.defs_p = insert2_f(this_.defs_p, i_p7, add_to_fn_f(crate::prelude::or_(crate::prelude::index(this_.defs_p, i_p7), dummy_def_p()), f_p4));
        return this_;
    }
    if (prism_rtl::is_none(_m)) {
        crate::check::env::G this_ = g_p0;
        this_.fn_at_p = crate::prelude::insert(this_.fn_at_p, qk_p2, crate::prelude::len(this_.defs_p));
        this_.defs_p = crate::prelude::push(this_.defs_p, crate::check::env::Def{.qk_p = qk_p2, .name_p = name_p3, .home_p = info_p1.name_p, .file_p = info_p1.file_p, .span_p = span_p5, .body_p = crate::check::env::DefBody(crate::check::env::DefBody::DbFn{Array(std::vector{f_p4})})});
        return this_;
    }
    prism_rtl::unreachable("no arm matched");
}


/// let dummyDef
crate::check::env::Def dummy_def_p() {
    return crate::check::env::Def{.qk_p = Text::lit(""), .name_p = Text::lit(""), .home_p = Text::lit(""), .file_p = Nat(0u), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}, .body_p = crate::check::env::DefBody(crate::check::env::DefBody::DbFn{Array<crate::syntax::decls::FnClause>{}})};
}


/// IsFnDef: fn Def -> Bool
bool is_fn_def_f(const crate::check::env::Def& d_p0) {
    auto&& _m = d_p0.body_p;
    if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// AddToFn: fn Def, FnClause -> Def
crate::check::env::Def add_to_fn_f(const crate::check::env::Def& d_p0, const crate::syntax::decls::FnClause& f_p1) {
    auto&& _m = d_p0.body_p;
    if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
        auto&& fs_p2 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
        crate::check::env::Def this_ = d_p0;
        this_.body_p = crate::check::env::DefBody(crate::check::env::DefBody::DbFn{crate::prelude::push(fs_p2, f_p1)});
        return this_;
    }
    {
        return d_p0;
    }
}


/// LensCheck: fn St, Text, Type, Range -> St
crate::check::types::St lens_check_f(const crate::check::types::St& st_p0, const Text& name_p1, const crate::syntax::Type& t_p2, const crate::syntax::Range& span_p3) {
    return !crate::syntax::lexer::chars::has_prefix_f(name_p1, Text::lit("&"))
        ? st_p0
        : ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = prism_rtl::deref(t_p2.kind_p);
        if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
            auto&& ps_p4 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
            _v.set(({
                auto refs_p5 = crate::prelude::filter(ps_p4, [&](const crate::syntax::Type& p_p6) { return is_ref_type_f(p_p6); });
                (crate::prelude::len(refs_p5) > Nat(1u)
                ? crate::check::types::recording::err_fix_f(st_p0, Text::lit("lens-arity"), span_p3, Text::lit("a lens takes one reference"), Text::lit("take the second part as a plain value"))
                : crate::check::types::recording::err_f(st_p0, Text::lit("unsupported"), span_p3, Text::lit("this checker does not implement named lenses and `Over`")));
            }));
            goto _done;
        }
        {
            _v.set(st_p0);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// IsRefType: fn Type -> Bool
bool is_ref_type_f(const crate::syntax::Type& t_p0) {
    auto&& _m = prism_rtl::deref(t_p0.kind_p);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(n_p1).sigils_p, Text::lit("&"));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& s_p2 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix_f(s_p2, Text::lit("&"));
    }
    {
        return false;
    }
}


/// CheckMarkFunction: unbounded fn St, Text, Ty, Range -> St
crate::check::types::St check_mark_function_f(const crate::check::types::St& st_p0, const Text& name_p1, const crate::check::types::Ty& t_p2, const crate::syntax::Range& span_p3) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p2)) {
        auto&& res_p4 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a2;
        auto want_p5 = crate::check::types::head_sigil_f(st_p0, prism_rtl::deref(prism_rtl::deref(res_p4)));
        auto marks_p6 = crate::check::types::unify::marks_of_f(name_p1);
        auto shown_p7 = crate::syntax::lexer::chars::head_f(marks_p6);
        auto bare_p8 = crate::syntax::lexer::chars::drop_prefix_f(name_p1, marks_p6);
        return (((shown_p7 == want_p5) || (crate::prelude::len_text(marks_p6) > Nat(1u))) || (bare_p8 == Text::lit(""))) || (!crate::check::env::is_upper_text_f(bare_p8))
            ? st_p0
            : crate::check::types::recording::err_fix_f(st_p0, Text::lit("mark-function"), span_p3, prism_rtl::cat("`", name_p1, "` returns `", crate::check::types::show_ty_f(st_p0, prism_rtl::deref(prism_rtl::deref(res_p4))), "`; name it `", want_p5, bare_p8, "`"), prism_rtl::cat("rename to `", want_p5, bare_p8, "`"));
    }
    {
        return st_p0;
    }
}


prism_rtl::Turn<crate::check::types::St> CheckMarkFunction::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& name_p1 = this->name_p1;
    const auto& t_p2 = this->t_p2;
    const auto& span_p3 = this->span_p3;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFn>(t_p2) ? ({
        auto&& res_p4 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a2;
        ({
        auto name_p1x = name_p1;
        auto res_p4x = prism_rtl::deref(prism_rtl::deref(res_p4));
        auto span_p3x = span_p3;
        auto st_p0x = st_p0;
        (crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p0x, res_p4x), [=, name_p1x = std::move(name_p1x), span_p3x = std::move(span_p3x)](Text head_sigil_f_8937) {
        return ({
            auto want_p5 = head_sigil_f_8937;
            auto marks_p6 = crate::check::types::unify::marks_of_f(name_p1x);
            auto shown_p7 = crate::syntax::lexer::chars::head_f(marks_p6);
            auto bare_p8 = crate::syntax::lexer::chars::drop_prefix_f(name_p1x, marks_p6);
            (((shown_p7 == want_p5) || (crate::prelude::len_text(marks_p6) > Nat(1u))) || (bare_p8 == Text::lit(""))) || (!crate::check::env::is_upper_text_f(bare_p8))
            ? prism_rtl::finished(st_p0x)
            : crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p0x, res_p4x), [=](Text show_ty_f_9217) { return prism_rtl::finished(crate::check::types::recording::err_fix_f(st_p0x, Text::lit("mark-function"), span_p3x, prism_rtl::cat("`", name_p1x, "` returns `", show_ty_f_9217, "`; name it `", want_p5, bare_p8, "`"), prism_rtl::cat("rename to `", want_p5, bare_p8, "`"))); });
        });
    }));
    });
    })
        : prism_rtl::finished(st_p0);
    });
}


/// `Start CheckMarkFunction, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_mark_function_f(crate::check::types::St st_p0, Text name_p1, crate::check::types::Ty t_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<CheckMarkFunction>(st_p0, name_p1, t_p2, span_p3);
}


/// MissingSignatures: fn G, St, ModInfo -> St
crate::check::types::St missing_signatures_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2) {
    return crate::prelude::fold(g_p0.defs_p, st_p1, [&](const crate::check::types::St& s_p3, const crate::check::env::Def& d_p4) {
        return ((prism_rtl::deref(d_p4).home_p == info_p2.name_p) && is_fn_def_f(d_p4)) && (!crate::check::env::has_key_f(g_p0.vals_p, prism_rtl::deref(d_p4).qk_p))
            ? crate::check::types::recording::err_fix_f(s_p3, Text::lit("no-signature"), prism_rtl::deref(d_p4).span_p, prism_rtl::cat("`", prism_rtl::deref(d_p4).name_p, "` has no signature line"), prism_rtl::cat("write `", prism_rtl::deref(d_p4).name_p, ": fn ... -> ...` above it"))
            : s_p3;
    });
}


/// ConvTag: unbounded fn G, St, ModInfo, TagDecl, Range -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> conv_tag_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2, const crate::syntax::decls::TagDecl& t_p3, const crate::syntax::Range& span_p4) {
    auto name_p5 = crate::check::env::dotted_f(prism_rtl::deref(t_p3.name_p).path_p);
    auto family_p6 = crate::check::env::dotted_f(crate::prelude::take(prism_rtl::deref(t_p3.name_p).path_p, crate::syntax::lexer::chars::dec_f(crate::prelude::len(prism_rtl::deref(t_p3.name_p).path_p))));
    auto cx_p7 = crate::check::env::reading::cx_of_f(g_p0, info_p2.name_p);
    auto [kind_pb, out_pc, st2_pd] = tag_kind_f(g_p0, cx_p7, st_p1, t_p3.of_type_p);
    auto [fields_pj, st3_pk] = crate::prelude::run_to_end(crate::prelude::fold_job(t_p3.fields_p, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st2_pd}, ({
        auto cx_p7x = cx_p7;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field>)>>(prism_rtl::rc([=, cx_p7x = std::move(cx_p7x)](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx_p7xy = cx_p7x;
            (crate::prelude::entered(crate::prelude::once_job([=, cx_p7xy = std::move(cx_p7xy)]() {
            return ({
                auto [acc_pe, s_pf] = p0;
                auto f_pg = p1;
                (crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p7xy, s_pf, prism_rtl::deref(f_pg).ty_p), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_10129) {
                return ({
                    auto [ft_ph, s2_pi] = conv_type_f_10129;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pe, std::tuple{prism_rtl::deref(prism_rtl::deref(f_pg).name_p).name_p, ft_ph}), s2_pi}));
                });
            }));
            });
        })));
        });
    }));
    })));
    auto qs_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(t_p3.fields_p, crate::check::env::reading::type_vars_of_type_f(t_p3.of_type_p), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::decls::Field>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::decls::Field> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_pl = p0;
                auto f_pm = p1;
                (crate::prelude::call_then(crate::check::env::reading::start_type_vars_of_type_f(prism_rtl::deref(f_pm).ty_p), [=, acc_pl = std::move(acc_pl)](Array<Text> type_vars_of_type_f_10280) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_pl, type_vars_of_type_f_10280)); }));
            });
        }));
    }))));
    auto [bs_pn, st4_po] = crate::check::env::reading::conv_bounds_f(cx_p7, st3_pk, t_p3.bounds_p);
    auto tg_p9 = crate::check::env::TagInfo{.name_p = name_p5, .family_p = family_p6, .kind_p = kind_pb, .out_p = out_pc, .qs_p = qs_p8, .rqs_p = info_p2.row_var_p == Text::lit("")
        ? Array<Text>{}
        : Array(std::vector{info_p2.row_var_p}), .bounds_p = bs_pn, .fields_p = fields_pj, .home_p = info_p2.name_p, .file_p = info_p2.file_p, .span_p = span_p4};
    auto upd_pa = ({
        crate::check::env::G this_ = g_p0;
        this_.tags_p = crate::prelude::insert(this_.tags_p, name_p5, tg_p9);
        (std::move(this_));
    });
    return std::tuple{upd_pa, st4_po};
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvTag::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& info_p2 = this->info_p2;
    const auto& t_p3 = this->t_p3;
    const auto& span_p4 = this->span_p4;
    auto name_p5 = crate::check::env::dotted_f(prism_rtl::deref(prism_rtl::deref(t_p3).name_p).path_p);
    auto family_p6 = crate::check::env::dotted_f(crate::prelude::take(prism_rtl::deref(prism_rtl::deref(t_p3).name_p).path_p, crate::syntax::lexer::chars::dec_f(crate::prelude::len(prism_rtl::deref(prism_rtl::deref(t_p3).name_p).path_p))));
    auto cx_p7 = crate::check::env::reading::cx_of_f(g_p0, prism_rtl::deref(info_p2).name_p);
    auto g_p0x = g_p0;
    auto info_p2x = info_p2;
    auto span_p4x = span_p4;
    auto st_p1x = st_p1;
    auto t_p3x = t_p3;
    return crate::prelude::call_then(start_tag_kind_f(g_p0x, cx_p7, st_p1x, prism_rtl::deref(t_p3x).of_type_p), [=](std::tuple<Text, crate::check::types::Ty, crate::check::types::St> tag_kind_f_10003) {
        return ({
            auto [kind_pb, out_pc, st2_pd] = tag_kind_f_10003;
            (crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(t_p3x).fields_p, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st2_pd}, ({
            auto cx_p7x = cx_p7;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field>)>>(prism_rtl::rc([=, cx_p7x = std::move(cx_p7x)](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx_p7xy = cx_p7x;
                (crate::prelude::entered(crate::prelude::once_job([=, cx_p7xy = std::move(cx_p7xy)]() {
                return ({
                    auto [acc_pe, s_pf] = p0;
                    auto f_pg = p1;
                    (crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p7xy, s_pf, prism_rtl::deref(f_pg).ty_p), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_10129) {
                    return ({
                        auto [ft_ph, s2_pi] = conv_type_f_10129;
                        (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pe, std::tuple{prism_rtl::deref(prism_rtl::deref(f_pg).name_p).name_p, ft_ph}), s2_pi}));
                    });
                }));
                });
            })));
            });
        }));
        })), [=](std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St> fold_10057) {
            return ({
                auto [fields_pj, st3_pk] = fold_10057;
                (crate::prelude::call_then(crate::check::env::reading::start_type_vars_of_type_f(prism_rtl::deref(t_p3x).of_type_p), [=](Array<Text> type_vars_of_type_f_10227) {
                return crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(t_p3x).fields_p, type_vars_of_type_f_10227, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::decls::Field>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::decls::Field> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return crate::prelude::entered(crate::prelude::once_job([=]() {
                        return ({
                            auto acc_pl = p0;
                            auto f_pm = p1;
                            (crate::prelude::call_then(crate::check::env::reading::start_type_vars_of_type_f(prism_rtl::deref(f_pm).ty_p), [=, acc_pl = std::move(acc_pl)](Array<Text> type_vars_of_type_f_10280) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_pl, type_vars_of_type_f_10280)); }));
                        });
                    }));
                }))), [=](Array<Text> fold_10211) {
                    return ({
                        auto qs_p8 = fold_10211;
                        auto [bs_pn, st4_po] = crate::check::env::reading::conv_bounds_f(cx_p7, st3_pk, prism_rtl::deref(t_p3x).bounds_p);
                        auto tg_p9 = crate::check::env::TagInfo{.name_p = name_p5, .family_p = family_p6, .kind_p = kind_pb, .out_p = out_pc, .qs_p = qs_p8, .rqs_p = prism_rtl::deref(info_p2x).row_var_p == Text::lit("")
                            ? Array<Text>{}
                            : Array(std::vector{prism_rtl::deref(info_p2x).row_var_p}), .bounds_p = bs_pn, .fields_p = fields_pj, .home_p = prism_rtl::deref(info_p2x).name_p, .file_p = prism_rtl::deref(info_p2x).file_p, .span_p = span_p4x};
                        auto upd_pa = ({
                            crate::check::env::G this_ = g_p0x;
                            this_.tags_p = crate::prelude::insert(this_.tags_p, name_p5, tg_p9);
                            (std::move(this_));
                        });
                        (prism_rtl::finished(std::tuple{upd_pa, st4_po}));
                    });
                });
            }));
            });
        }));
        });
    });
}


/// `Start ConvTag, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_conv_tag_f(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::TagDecl t_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<ConvTag>(g_p0, st_p1, info_p2, t_p3, span_p4);
}


/// TagKind: unbounded fn G, Cx, St, Type -> ((Text, Ty, St))
std::tuple<Text, crate::check::types::Ty, crate::check::types::St> tag_kind_f(const crate::check::env::G& g_p0, const crate::check::env::reading::Cx_& cx_p1, const crate::check::types::St& st_p2, const crate::syntax::Type& t_p3) {
    auto&& _m = prism_rtl::deref(t_p3.kind_p);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n_p4 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p5 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        auto name_p6 = crate::check::env::dotted_f(prism_rtl::deref(n_p4).path_p);
        return name_p6 == Text::lit("Element")
            ? ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> _v;
            auto&& _m = crate::prelude::index(args_p5, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& o_p7 = prism_rtl::some_of(_m);
                _v.set(({
                    auto [ot_p8, s2_p9] = crate::check::env::reading::conv_type_f(cx_p1, st_p2, o_p7);
                    std::tuple{Text::lit("Element"), ot_p8, s2_p9};
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::tuple{Text::lit("Element"), crate::check::types::t_unit_p(), st_p2});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        })
            : ({
            auto&& _key_oa = crate::check::env::names::resolve_type_f(g_p0, cx_p1.home_p, prism_rtl::deref(n_p4).path_p);
            auto&& key_oa = std::get<0>(_key_oa);
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> _v;
            if (prism_rtl::is_some(key_oa)) {
                auto&& k_pb = prism_rtl::some_of(key_oa);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> _v;
                    auto&& _m = prism_rtl::deref(crate::prelude::or_(crate::prelude::get(g_p0.types_p, k_pb), crate::check::env::names::dummy_ty_info_p())).body_p;
                    if (prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m)) {
                        _v.set(std::tuple{k_pb, crate::check::types::t_unit_p(), st_p2});
                        goto _done;
                    }
                    {
                        _v.set(std::tuple{k_pb, crate::check::types::t_unit_p(), crate::check::types::recording::err_f(st_p2, Text::lit("kind"), t_p3.span_p, prism_rtl::cat("`", name_p6, "` is not a row kind: a tag joins `Element o`, `Fault` or another `type K = row`"))});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(key_oa)) {
                _v.set(std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p2, Text::lit("unknown-name"), t_p3.span_p, prism_rtl::cat("no row kind `", name_p6, "`"))});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_pc = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return tag_kind_f(g_p0, cx_p1, st_p2, prism_rtl::deref(prism_rtl::deref(x_pc)));
    }
    {
        return std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p2, Text::lit("kind"), t_p3.span_p, Text::lit("a tag joins a row kind"))};
    }
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> TagKind::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& cx_p1 = this->cx_p1;
    const auto& st_p2 = this->st_p2;
    const auto& t_p3 = this->t_p3;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p3).kind_p);
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& n_p4 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p5 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        ({
        auto name_p6 = crate::check::env::dotted_f(prism_rtl::deref(n_p4).path_p);
        name_p6 == Text::lit("Element")
        ? ({
        auto&& _m = crate::prelude::index(args_p5, Nat(0u));
        prism_rtl::is_some(_m) ? ({
        auto&& o_p7 = prism_rtl::some_of(_m);
        ({
        auto cx_p1x = cx_p1;
        auto st_p2x = st_p2;
        (crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p1x, st_p2x, o_p7), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_10990) {
        return ({
            auto [ot_p8, s2_p9] = conv_type_f_10990;
            (prism_rtl::finished(std::tuple{Text::lit("Element"), ot_p8, s2_p9}));
        });
    }));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{Text::lit("Element"), crate::check::types::t_unit_p(), st_p2})
        : throw prism_rtl::Panic("no arm matched");
    })
        : ({
        auto&& _key_oa = crate::check::env::names::resolve_type_f(g_p0, prism_rtl::deref(cx_p1).home_p, prism_rtl::deref(n_p4).path_p);
        auto&& key_oa = std::get<0>(_key_oa);
        ({
        prism_rtl::is_some(key_oa) ? ({
        auto&& k_pb = prism_rtl::some_of(key_oa);
        ({
        auto&& _m = prism_rtl::deref(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(g_p0).types_p, k_pb), crate::check::env::names::dummy_ty_info_p())).body_p;
        prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m) ? prism_rtl::finished(std::tuple{k_pb, crate::check::types::t_unit_p(), st_p2})
        : prism_rtl::finished(std::tuple{k_pb, crate::check::types::t_unit_p(), crate::check::types::recording::err_f(st_p2, Text::lit("kind"), prism_rtl::deref(t_p3).span_p, prism_rtl::cat("`", name_p6, "` is not a row kind: a tag joins `Element o`, `Fault` or another `type K = row`"))});
    });
    })
        : prism_rtl::is_none(key_oa) ? prism_rtl::finished(std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p2, Text::lit("unknown-name"), prism_rtl::deref(t_p3).span_p, prism_rtl::cat("no row kind `", name_p6, "`"))})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_pc = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TagKind(g_p0, cx_p1, st_p2, prism_rtl::deref(prism_rtl::deref(x_pc)))));
    })
        : prism_rtl::finished(std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p2, Text::lit("kind"), prism_rtl::deref(t_p3).span_p, Text::lit("a tag joins a row kind"))});
    });
}


/// `Start TagKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> start_tag_kind_f(crate::check::env::G g_p0, crate::check::env::reading::Cx_ cx_p1, crate::check::types::St st_p2, crate::syntax::Type t_p3) {
    return prism_rtl::make_rc<TagKind>(g_p0, cx_p1, st_p2, t_p3);
}


/// ConvTrait: unbounded fn G, St, ModInfo, TraitDecl, Range -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> conv_trait_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2, const crate::syntax::decls::TraitDecl& t_p3, const crate::syntax::Range& span_p4) {
    auto name_p5 = crate::check::env::qual_key_f(info_p2.name_p, crate::check::env::dotted_f(prism_rtl::deref(t_p3.name_p).path_p));
    auto param_p6 = crate::prelude::or_(crate::prelude::index(crate::prelude::each(t_p3.params_p, [&](const crate::syntax::Ident& p_pb) { return prism_rtl::deref(p_pb).name_p; }), Nat(0u)), Text::lit("a"));
    auto st1_p7 = crate::prelude::len(t_p3.params_p) > Nat(1u)
        ? crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), span_p4, Text::lit("this checker does not implement traits of several types"))
        : st_p1;
    auto cx_p8 = crate::check::env::reading::cx_of_f(g_p0, info_p2.name_p);
    auto [supers_pc, st2_pd] = crate::check::env::reading::conv_bounds_f(cx_p8, st1_p7, t_p3.bounds_p);
    auto [g3_p11, st3_p12, methods_p13, defaults_p14, assocs_p15] = crate::prelude::run_to_end(crate::prelude::fold_job(t_p3.items_p, std::tuple{g_p0, st2_pd, Array<Text>{}, Array<Text>{}, Array<Text>{}}, ({
        auto info_p2x = info_p2;
        auto cx_p8x = cx_p8;
        auto param_p6x = param_p6;
        auto name_p5x = name_p5;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=, info_p2x = std::move(info_p2x), cx_p8x = std::move(cx_p8x), param_p6x = std::move(param_p6x), name_p5x = std::move(name_p5x)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>, crate::syntax::decls::TraitItem> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_p2xy = info_p2x;
            auto cx_p8xy = cx_p8x;
            auto param_p6xy = param_p6x;
            auto name_p5xy = name_p5x;
            (crate::prelude::entered(crate::prelude::once_job([=, info_p2xy = std::move(info_p2xy), cx_p8xy = std::move(cx_p8xy), param_p6xy = std::move(param_p6xy), name_p5xy = std::move(name_p5xy)]() {
            return ({
                auto [gg_pe, s_pf, ms_pg, ds_ph, assoc_acc_pi] = p0;
                auto it_pj = p1;
                ({
                prism_rtl::is<crate::syntax::decls::TraitItem::TiSignature>(it_pj) ? ({
                auto&& sg_pk = prism_rtl::as<crate::syntax::decls::TraitItem::TiSignature>(it_pj).a0;
                ({
                auto mname_pl = crate::check::env::def_name_text_f(prism_rtl::deref(sg_pk).name_p);
                auto qk_pm = crate::check::env::qual_key_f(prism_rtl::deref(info_p2xy).name_p, mname_pl);
                auto sg_pkx = sg_pk;
                (crate::prelude::call_then(crate::check::env::reading::start_sig_scheme_f(cx_p8xy, s_pf, prism_rtl::deref(sg_pkx).ty_p, prism_rtl::deref(sg_pkx).bounds_p), [=, qk_pm = std::move(qk_pm)](std::tuple<crate::check::types::Scheme, crate::check::types::St> sig_scheme_f_12556) {
                return ({
                    auto [sc_pp, s2_pq] = sig_scheme_f_12556;
                    auto sc2_pn = ({
                        crate::check::types::Scheme this_ = sc_pp;
                        this_.qs_p = crate::check::types::has_text_f(this_.qs_p, param_p6xy)
                            ? this_.qs_p
                            : crate::prelude::append(Array(std::vector{param_p6xy}), this_.qs_p);
                        this_.bounds_p = crate::prelude::append(Array(std::vector{std::tuple{param_p6xy, name_p5xy}}), this_.bounds_p);
                        (std::move(this_));
                    });
                    auto upd_po = ({
                        crate::check::env::G this_ = gg_pe;
                        this_.vals_p = crate::prelude::insert(this_.vals_p, qk_pm, crate::check::env::ValInfo{.qk_p = qk_pm, .scheme_p = sc2_pn, .sort_p = Text::lit("method"), .has_sig_p = true, .home_p = prism_rtl::deref(info_p2xy).name_p, .file_p = prism_rtl::deref(info_p2xy).file_p, .span_p = prism_rtl::deref(sg_pkx).span_p});
                        (std::move(this_));
                    });
                    (prism_rtl::finished(std::tuple{upd_po, s2_pq, crate::prelude::push(ms_pg, qk_pm), ds_ph, assoc_acc_pi}));
                });
            }));
            });
            })
                : prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it_pj) ? ({
                auto&& f_pr = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it_pj).a0;
                ({
                auto qk_ps = crate::check::env::qual_key_f(prism_rtl::deref(info_p2xy).name_p, crate::check::env::def_name_text_f(prism_rtl::deref(f_pr).name_p));
                auto def_pt = crate::check::env::Def{.qk_p = qk_ps, .name_p = crate::check::env::def_name_text_f(prism_rtl::deref(f_pr).name_p), .home_p = prism_rtl::deref(info_p2xy).name_p, .file_p = prism_rtl::deref(info_p2xy).file_p, .span_p = prism_rtl::deref(f_pr).span_p, .body_p = crate::check::env::DefBody(crate::check::env::DefBody::DbDefault{Array(std::vector{f_pr}), name_p5xy})};
                auto upd_pu = ({
                    crate::check::env::G this_ = gg_pe;
                    this_.defs_p = crate::prelude::push(this_.defs_p, def_pt);
                    (std::move(this_));
                });
                (prism_rtl::finished(std::tuple{upd_pu, s_pf, ms_pg, crate::prelude::push(ds_ph, qk_ps), assoc_acc_pi}));
            });
            })
                : prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocType>(it_pj) ? ({
                auto&& n_pv = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it_pj).a0;
                prism_rtl::finished(std::tuple{gg_pe, s_pf, ms_pg, ds_ph, crate::prelude::push(assoc_acc_pi, prism_rtl::deref(n_pv).name_p)});
            })
                : prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocRow>(it_pj) ? ({
                auto&& r_p10 = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocRow>(it_pj).a1;
                prism_rtl::finished(std::tuple{gg_pe, crate::check::types::recording::err_f(s_pf, Text::lit("unsupported"), r_p10, Text::lit("this checker does not implement associated rows")), ms_pg, ds_ph, assoc_acc_pi});
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    })));
    auto ti_p9 = crate::check::env::TraitInfo{.name_p = name_p5, .home_p = info_p2.name_p, .param_p = param_p6, .supers_p = crate::prelude::each(supers_pc, [&](const std::tuple<Text, Text>& _p0) {
        auto&& k_p16 = std::get<1>(_p0);
        return k_p16;
    }), .methods_p = methods_p13, .defaults_p = defaults_p14, .assocs_p = assocs_p15, .file_p = info_p2.file_p, .span_p = span_p4};
    auto upd3_pa = ({
        crate::check::env::G this_ = g3_p11;
        this_.traits_p = crate::prelude::insert(this_.traits_p, name_p5, ti_p9);
        (std::move(this_));
    });
    return std::tuple{upd3_pa, st3_p12};
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvTrait::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& info_p2 = this->info_p2;
    const auto& t_p3 = this->t_p3;
    const auto& span_p4 = this->span_p4;
    auto name_p5 = crate::check::env::qual_key_f(prism_rtl::deref(info_p2).name_p, crate::check::env::dotted_f(prism_rtl::deref(prism_rtl::deref(t_p3).name_p).path_p));
    auto param_p6 = crate::prelude::or_(crate::prelude::index(crate::prelude::each(prism_rtl::deref(t_p3).params_p, [&](const crate::syntax::Ident& p_pb) { return prism_rtl::deref(p_pb).name_p; }), Nat(0u)), Text::lit("a"));
    auto st1_p7 = crate::prelude::len(prism_rtl::deref(t_p3).params_p) > Nat(1u)
        ? crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), span_p4, Text::lit("this checker does not implement traits of several types"))
        : st_p1;
    auto cx_p8 = crate::check::env::reading::cx_of_f(g_p0, prism_rtl::deref(info_p2).name_p);
    auto [supers_pc, st2_pd] = crate::check::env::reading::conv_bounds_f(cx_p8, st1_p7, prism_rtl::deref(t_p3).bounds_p);
    auto g_p0x = g_p0;
    auto info_p2x = info_p2;
    auto span_p4x = span_p4;
    auto t_p3x = t_p3;
    return crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(t_p3x).items_p, std::tuple{g_p0x, st2_pd, Array<Text>{}, Array<Text>{}, Array<Text>{}}, ({
        auto info_p2xx = info_p2x;
        auto cx_p8x = cx_p8;
        auto param_p6x = param_p6;
        auto name_p5x = name_p5;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=, info_p2xx = std::move(info_p2xx), cx_p8x = std::move(cx_p8x), param_p6x = std::move(param_p6x), name_p5x = std::move(name_p5x)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>, crate::syntax::decls::TraitItem> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_p2xxy = info_p2xx;
            auto cx_p8xy = cx_p8x;
            auto param_p6xy = param_p6x;
            auto name_p5xy = name_p5x;
            (crate::prelude::entered(crate::prelude::once_job([=, info_p2xxy = std::move(info_p2xxy), cx_p8xy = std::move(cx_p8xy), param_p6xy = std::move(param_p6xy), name_p5xy = std::move(name_p5xy)]() {
            return ({
                auto [gg_pe, s_pf, ms_pg, ds_ph, assoc_acc_pi] = p0;
                auto it_pj = p1;
                ({
                prism_rtl::is<crate::syntax::decls::TraitItem::TiSignature>(it_pj) ? ({
                auto&& sg_pk = prism_rtl::as<crate::syntax::decls::TraitItem::TiSignature>(it_pj).a0;
                ({
                auto mname_pl = crate::check::env::def_name_text_f(prism_rtl::deref(sg_pk).name_p);
                auto qk_pm = crate::check::env::qual_key_f(prism_rtl::deref(info_p2xxy).name_p, mname_pl);
                auto sg_pkx = sg_pk;
                (crate::prelude::call_then(crate::check::env::reading::start_sig_scheme_f(cx_p8xy, s_pf, prism_rtl::deref(sg_pkx).ty_p, prism_rtl::deref(sg_pkx).bounds_p), [=, qk_pm = std::move(qk_pm)](std::tuple<crate::check::types::Scheme, crate::check::types::St> sig_scheme_f_12556) {
                return ({
                    auto [sc_pp, s2_pq] = sig_scheme_f_12556;
                    auto sc2_pn = ({
                        crate::check::types::Scheme this_ = sc_pp;
                        this_.qs_p = crate::check::types::has_text_f(this_.qs_p, param_p6xy)
                            ? this_.qs_p
                            : crate::prelude::append(Array(std::vector{param_p6xy}), this_.qs_p);
                        this_.bounds_p = crate::prelude::append(Array(std::vector{std::tuple{param_p6xy, name_p5xy}}), this_.bounds_p);
                        (std::move(this_));
                    });
                    auto upd_po = ({
                        crate::check::env::G this_ = gg_pe;
                        this_.vals_p = crate::prelude::insert(this_.vals_p, qk_pm, crate::check::env::ValInfo{.qk_p = qk_pm, .scheme_p = sc2_pn, .sort_p = Text::lit("method"), .has_sig_p = true, .home_p = prism_rtl::deref(info_p2xxy).name_p, .file_p = prism_rtl::deref(info_p2xxy).file_p, .span_p = prism_rtl::deref(sg_pkx).span_p});
                        (std::move(this_));
                    });
                    (prism_rtl::finished(std::tuple{upd_po, s2_pq, crate::prelude::push(ms_pg, qk_pm), ds_ph, assoc_acc_pi}));
                });
            }));
            });
            })
                : prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it_pj) ? ({
                auto&& f_pr = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it_pj).a0;
                ({
                auto qk_ps = crate::check::env::qual_key_f(prism_rtl::deref(info_p2xxy).name_p, crate::check::env::def_name_text_f(prism_rtl::deref(f_pr).name_p));
                auto def_pt = crate::check::env::Def{.qk_p = qk_ps, .name_p = crate::check::env::def_name_text_f(prism_rtl::deref(f_pr).name_p), .home_p = prism_rtl::deref(info_p2xxy).name_p, .file_p = prism_rtl::deref(info_p2xxy).file_p, .span_p = prism_rtl::deref(f_pr).span_p, .body_p = crate::check::env::DefBody(crate::check::env::DefBody::DbDefault{Array(std::vector{f_pr}), name_p5xy})};
                auto upd_pu = ({
                    crate::check::env::G this_ = gg_pe;
                    this_.defs_p = crate::prelude::push(this_.defs_p, def_pt);
                    (std::move(this_));
                });
                (prism_rtl::finished(std::tuple{upd_pu, s_pf, ms_pg, crate::prelude::push(ds_ph, qk_ps), assoc_acc_pi}));
            });
            })
                : prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocType>(it_pj) ? ({
                auto&& n_pv = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it_pj).a0;
                prism_rtl::finished(std::tuple{gg_pe, s_pf, ms_pg, ds_ph, crate::prelude::push(assoc_acc_pi, prism_rtl::deref(n_pv).name_p)});
            })
                : prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocRow>(it_pj) ? ({
                auto&& r_p10 = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocRow>(it_pj).a1;
                prism_rtl::finished(std::tuple{gg_pe, crate::check::types::recording::err_f(s_pf, Text::lit("unsupported"), r_p10, Text::lit("this checker does not implement associated rows")), ms_pg, ds_ph, assoc_acc_pi});
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    })), [=](std::tuple<crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>> fold_12324) {
        return ({
            auto [g3_p11, st3_p12, methods_p13, defaults_p14, assocs_p15] = fold_12324;
            auto ti_p9 = crate::check::env::TraitInfo{.name_p = name_p5, .home_p = prism_rtl::deref(info_p2x).name_p, .param_p = param_p6, .supers_p = crate::prelude::each(supers_pc, [&](const std::tuple<Text, Text>& _p0) {
                auto&& k_p16 = std::get<1>(_p0);
                return k_p16;
            }), .methods_p = methods_p13, .defaults_p = defaults_p14, .assocs_p = assocs_p15, .file_p = prism_rtl::deref(info_p2x).file_p, .span_p = span_p4x};
            auto upd3_pa = ({
                crate::check::env::G this_ = g3_p11;
                this_.traits_p = crate::prelude::insert(this_.traits_p, name_p5, ti_p9);
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{upd3_pa, st3_p12}));
        });
    });
}


/// `Start ConvTrait, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_conv_trait_f(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::TraitDecl t_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<ConvTrait>(g_p0, st_p1, info_p2, t_p3, span_p4);
}


/// ConvImpl: unbounded fn G, St, ModInfo, ImplDecl, Range -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> conv_impl_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2, const crate::syntax::decls::ImplDecl& i_p3, const crate::syntax::Range& span_p4) {
    auto&& _m = crate::check::env::names::resolve_trait_o(g_p0, info_p2.name_p, prism_rtl::deref(i_p3.trait_ref_p).path_p);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{g_p0, crate::check::types::recording::err_f(st_p1, Text::lit("unknown-name"), prism_rtl::deref(i_p3.trait_ref_p).span_p, prism_rtl::cat("no trait `^", crate::check::env::dotted_f(prism_rtl::deref(i_p3.trait_ref_p).path_p), "`"))};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& cls_p5 = prism_rtl::some_of(_m);
        auto cx_p6 = crate::check::env::reading::cx_of_f(g_p0, info_p2.name_p);
        auto [head_pb, st2_pc] = crate::check::env::reading::conv_type_f(cx_p6, st_p1, i_p3.ty_p);
        auto [bs_pd, st3_pe] = crate::check::env::reading::conv_bounds_f(cx_p6, st2_pc, i_p3.bounds_p);
        auto [assocs_pm, st4_pn] = crate::prelude::run_to_end(crate::prelude::fold_job(i_p3.items_p, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st3_pe}, ({
            auto cx_p6x = cx_p6;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=, cx_p6x = std::move(cx_p6x)](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::TraitItem> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx_p6xy = cx_p6x;
                (crate::prelude::entered(crate::prelude::once_job([=, cx_p6xy = std::move(cx_p6xy)]() {
                return ({
                    auto [acc_pf, s_pg] = p0;
                    auto it_ph = p1;
                    ({
                    prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocType>(it_ph) && prism_rtl::is_some(prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it_ph).a2) ? ({
                    auto&& n_pi = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it_ph).a0;
                    auto&& v_pj = prism_rtl::some_of(prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it_ph).a2);
                    ({
                    auto n_pix = n_pi;
                    auto v_pjx = v_pj;
                    (crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p6xy, s_pg, v_pjx), [=, n_pix = std::move(n_pix)](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_14573) {
                    return ({
                        auto [vt_pk, s2_pl] = conv_type_f_14573;
                        (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pf, std::tuple{prism_rtl::deref(n_pix).name_p, vt_pk}), s2_pl}));
                    });
                }));
                });
                })
                    : prism_rtl::finished(std::tuple{acc_pf, s_pg});
                });
                });
            })));
            });
        }));
        })));
        auto names_p7 = crate::prelude::fold(i_p3.items_p, Array<Text>{}, [&](const Array<Text>& acc_po, const crate::syntax::decls::TraitItem& it_pp) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                if (prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it_pp)) {
                    auto&& f_pq = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it_pp).a0;
                    _v.set(crate::check::types::add_text_f(acc_po, crate::check::env::def_name_text_f(prism_rtl::deref(f_pq).name_p)));
                    goto _done;
                }
                {
                    _v.set(acc_po);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
        auto im_p8 = crate::check::env::ImplInfo{.cls_p = cls_p5, .head_p = head_pb, .qs_p = crate::check::env::reading::type_vars_of_type_f(i_p3.ty_p), .bounds_p = bs_pd, .home_p = info_p2.name_p, .file_p = info_p2.file_p, .span_p = span_p4, .derived_p = false, .assocs_p = assocs_pm, .methods_p = names_p7};
        auto g2_p9 = ({
            crate::check::env::G this_ = g_p0;
            this_.impls_p = crate::prelude::insert(this_.impls_p, cls_p5, crate::prelude::push(crate::prelude::or_(crate::prelude::get(this_.impls_p, cls_p5), Array<crate::check::env::ImplInfo>{}), im_p8));
            (std::move(this_));
        });
        auto g3_pa = crate::prelude::fold(names_p7, g2_p9, [&](const crate::check::env::G& gg_pr, const Text& mname_ps) {
            return ({
                auto clauses_pt = crate::prelude::fold(i_p3.items_p, Array<crate::syntax::decls::FnClause>{}, [&](const Array<crate::syntax::decls::FnClause>& acc_pu, const crate::syntax::decls::TraitItem& it_pv) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
                        if (prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it_pv)) {
                            auto&& f_p10 = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it_pv).a0;
                            _v.set(crate::check::env::def_name_text_f(prism_rtl::deref(f_p10).name_p) == mname_ps
                                ? crate::prelude::push(acc_pu, f_p10)
                                : acc_pu);
                            goto _done;
                        }
                        {
                            _v.set(acc_pu);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                ({
                crate::check::env::G this_ = gg_pr;
                this_.defs_p = crate::prelude::push(this_.defs_p, crate::check::env::Def{.qk_p = prism_rtl::cat(cls_p5, " impl ", mname_ps), .name_p = mname_ps, .home_p = info_p2.name_p, .file_p = info_p2.file_p, .span_p = span_p4, .body_p = crate::check::env::DefBody(crate::check::env::DefBody::DbMethod{clauses_pt, cls_p5, im_p8})});
                (std::move(this_));
            });
            });
        });
        return std::tuple{g3_pa, st4_pn};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvImpl::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& info_p2 = this->info_p2;
    const auto& i_p3 = this->i_p3;
    const auto& span_p4 = this->span_p4;
    return ({
        auto&& _m = crate::check::env::names::resolve_trait_o(g_p0, prism_rtl::deref(info_p2).name_p, prism_rtl::deref(prism_rtl::deref(i_p3).trait_ref_p).path_p);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g_p0, crate::check::types::recording::err_f(st_p1, Text::lit("unknown-name"), prism_rtl::deref(prism_rtl::deref(i_p3).trait_ref_p).span_p, prism_rtl::cat("no trait `^", crate::check::env::dotted_f(prism_rtl::deref(prism_rtl::deref(i_p3).trait_ref_p).path_p), "`"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& cls_p5 = prism_rtl::some_of(_m);
        ({
        auto cx_p6 = crate::check::env::reading::cx_of_f(g_p0, prism_rtl::deref(info_p2).name_p);
        auto g_p0x = g_p0;
        auto i_p3x = i_p3;
        auto info_p2x = info_p2;
        auto span_p4x = span_p4;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p6, st_p1x, prism_rtl::deref(i_p3x).ty_p), [=, g_p0x = std::move(g_p0x), info_p2x = std::move(info_p2x), span_p4x = std::move(span_p4x)](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_14326) {
        return ({
            auto [head_pb, st2_pc] = conv_type_f_14326;
            auto [bs_pd, st3_pe] = crate::check::env::reading::conv_bounds_f(cx_p6, st2_pc, prism_rtl::deref(i_p3x).bounds_p);
            (crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(i_p3x).items_p, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st3_pe}, ({
            auto cx_p6x = cx_p6;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=, cx_p6x = std::move(cx_p6x)](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::TraitItem> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx_p6xy = cx_p6x;
                (crate::prelude::entered(crate::prelude::once_job([=, cx_p6xy = std::move(cx_p6xy)]() {
                return ({
                    auto [acc_pf, s_pg] = p0;
                    auto it_ph = p1;
                    ({
                    prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocType>(it_ph) && prism_rtl::is_some(prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it_ph).a2) ? ({
                    auto&& n_pi = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it_ph).a0;
                    auto&& v_pj = prism_rtl::some_of(prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it_ph).a2);
                    ({
                    auto n_pix = n_pi;
                    auto v_pjx = v_pj;
                    (crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p6xy, s_pg, v_pjx), [=, n_pix = std::move(n_pix)](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_14573) {
                    return ({
                        auto [vt_pk, s2_pl] = conv_type_f_14573;
                        (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pf, std::tuple{prism_rtl::deref(n_pix).name_p, vt_pk}), s2_pl}));
                    });
                }));
                });
                })
                    : prism_rtl::finished(std::tuple{acc_pf, s_pg});
                });
                });
            })));
            });
        }));
        })), [=](std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St> fold_14433) {
            return ({
                auto [assocs_pm, st4_pn] = fold_14433;
                auto names_p7 = crate::prelude::fold(prism_rtl::deref(i_p3x).items_p, Array<Text>{}, [&](const Array<Text>& acc_po, const crate::syntax::decls::TraitItem& it_pp) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        if (prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it_pp)) {
                            auto&& f_pq = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it_pp).a0;
                            _v.set(crate::check::types::add_text_f(acc_po, crate::check::env::def_name_text_f(prism_rtl::deref(f_pq).name_p)));
                            goto _done;
                        }
                        {
                            _v.set(acc_po);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                (crate::prelude::call_then(crate::check::env::reading::start_type_vars_of_type_f(prism_rtl::deref(i_p3x).ty_p), [=, names_p7 = std::move(names_p7)](Array<Text> type_vars_of_type_f_14868) {
                return ({
                    auto im_p8 = crate::check::env::ImplInfo{.cls_p = cls_p5, .head_p = head_pb, .qs_p = type_vars_of_type_f_14868, .bounds_p = bs_pd, .home_p = prism_rtl::deref(info_p2x).name_p, .file_p = prism_rtl::deref(info_p2x).file_p, .span_p = span_p4x, .derived_p = false, .assocs_p = assocs_pm, .methods_p = names_p7};
                    auto g2_p9 = ({
                        crate::check::env::G this_ = g_p0x;
                        this_.impls_p = crate::prelude::insert(this_.impls_p, cls_p5, crate::prelude::push(crate::prelude::or_(crate::prelude::get(this_.impls_p, cls_p5), Array<crate::check::env::ImplInfo>{}), im_p8));
                        (std::move(this_));
                    });
                    auto g3_pa = crate::prelude::fold(names_p7, g2_p9, [&](const crate::check::env::G& gg_pr, const Text& mname_ps) {
                        return ({
                            auto clauses_pt = crate::prelude::fold(prism_rtl::deref(i_p3x).items_p, Array<crate::syntax::decls::FnClause>{}, [&](const Array<crate::syntax::decls::FnClause>& acc_pu, const crate::syntax::decls::TraitItem& it_pv) {
                                return ({
                                    __label__ _done;
                                    prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
                                    if (prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it_pv)) {
                                        auto&& f_p10 = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it_pv).a0;
                                        _v.set(crate::check::env::def_name_text_f(prism_rtl::deref(f_p10).name_p) == mname_ps
                                            ? crate::prelude::push(acc_pu, f_p10)
                                            : acc_pu);
                                        goto _done;
                                    }
                                    {
                                        _v.set(acc_pu);
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                            });
                            ({
                            crate::check::env::G this_ = gg_pr;
                            this_.defs_p = crate::prelude::push(this_.defs_p, crate::check::env::Def{.qk_p = prism_rtl::cat(cls_p5, " impl ", mname_ps), .name_p = mname_ps, .home_p = prism_rtl::deref(info_p2x).name_p, .file_p = prism_rtl::deref(info_p2x).file_p, .span_p = span_p4x, .body_p = crate::check::env::DefBody(crate::check::env::DefBody::DbMethod{clauses_pt, cls_p5, im_p8})});
                            (std::move(this_));
                        });
                        });
                    });
                    (prism_rtl::finished(std::tuple{g3_pa, st4_pn}));
                });
            }));
            });
        }));
        });
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ConvImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_conv_impl_f(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::ImplDecl i_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<ConvImpl>(g_p0, st_p1, info_p2, i_p3, span_p4);
}

}  // namespace crate::check::env::decls
