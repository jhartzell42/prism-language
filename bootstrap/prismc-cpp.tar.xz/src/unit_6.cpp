// The module `Check.Env.Decls`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/env/decls/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/decls/generic.hpp>
#include <check/env/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Env.Decls`, from `target/bootstrap/cpp-src/prismc/check/env/decls.prism`.
namespace crate::check::env::decls {

/// ConvertTypes: unbounded fn G, St, Text -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> convert_types(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Text& m_p2) {
    auto&& _m = crate::prelude::get(g_p0.mods, m_p2);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{g_p0, st_p1};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info_p3 = prism_rtl::some_of(_m);
        auto s0_p4 = ({
            crate::check::types::St this_ = st_p1;
            this_.file = info_p3->file;
            (std::move(this_));
        });
        return run_to_end(fold_job(prism_rtl::deref(prism_rtl::deref(info_p3).tree).decls, std::tuple{g_p0, s0_p4}, ({
            auto info_p3_1 = info_p3;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=, info_p3_1 = std::move(info_p3_1)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto info_p3_1_2 = info_p3_1;
                entered(once_job([=, info_p3_1_2 = std::move(info_p3_1_2)]() {
                return ({
                    auto [gg_p5, s_p6] = p0;
                    auto d_p7 = p1;
                    (prism_rtl::more(prism_rtl::rc(ConvertTypeDecl(gg_p5, s_p6, info_p3_1_2, d_p7))));
                });
            }));
            });
        }));
        })));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvertTypes::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& m_p2 = this->m_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).mods, m_p2);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g_p0, st_p1})
        : prism_rtl::is_some(_m) ? ({
        auto&& info_p3 = prism_rtl::some_of(_m);
        ({
        auto s0_p4 = ({
            crate::check::types::St this_ = st_p1;
            this_.file = info_p3->file;
            (std::move(this_));
        });
        fold_job(prism_rtl::deref(prism_rtl::deref(info_p3).tree).decls, std::tuple{g_p0, s0_p4}, ({
        auto info_p3_1 = info_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=, info_p3_1 = std::move(info_p3_1)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_p3_1_2 = info_p3_1;
            entered(once_job([=, info_p3_1_2 = std::move(info_p3_1_2)]() {
            return ({
                auto [gg_p5, s_p6] = p0;
                auto d_p7 = p1;
                (prism_rtl::more(prism_rtl::rc(ConvertTypeDecl(gg_p5, s_p6, info_p3_1_2, d_p7))));
            });
        }));
        });
    }));
    }))->cycle();
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ConvertTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_convert_types(crate::check::env::G g_p0, crate::check::types::St st_p1, Text m_p2) {
    return prism_rtl::make_rc<ConvertTypes>(g_p0, st_p1, m_p2);
}


/// ConvertDecls: unbounded fn G, St, Text -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> convert_decls(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Text& m_p2) {
    auto&& _m = crate::prelude::get(g_p0.mods, m_p2);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{g_p0, st_p1};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info_p3 = prism_rtl::some_of(_m);
        auto s1_p4 = ({
            crate::check::types::St this_ = st_p1;
            this_.file = info_p3->file;
            (std::move(this_));
        });
        auto [g2_p9, s2_pa] = run_to_end(fold_job(prism_rtl::deref(prism_rtl::deref(info_p3).tree).decls, std::tuple{g_p0, s1_p4}, ({
            auto info_p3_1 = info_p3;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=, info_p3_1 = std::move(info_p3_1)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto info_p3_1_2 = info_p3_1;
                entered(once_job([=, info_p3_1_2 = std::move(info_p3_1_2)]() {
                return ({
                    auto [gg_p6, s_p7] = p0;
                    auto d_p8 = p1;
                    (prism_rtl::more(prism_rtl::rc(ConvertDecl(gg_p6, s_p7, info_p3_1_2, d_p8))));
                });
            }));
            });
        }));
        })));
        auto s3_p5 = missing_signatures(g2_p9, s2_pa, info_p3);
        return std::tuple{g2_p9, s3_p5};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvertDecls::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& m_p2 = this->m_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).mods, m_p2);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g_p0, st_p1})
        : prism_rtl::is_some(_m) ? ({
        auto&& info_p3 = prism_rtl::some_of(_m);
        ({
        auto s1_p4 = ({
            crate::check::types::St this_ = st_p1;
            this_.file = info_p3->file;
            (std::move(this_));
        });
        auto g_p0_1 = g_p0;
        call_value(fold_job(prism_rtl::deref(prism_rtl::deref(info_p3).tree).decls, std::tuple{g_p0_1, s1_p4}, ({
        auto info_p3_2 = info_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=, info_p3_2 = std::move(info_p3_2)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_p3_2_3 = info_p3_2;
            entered(once_job([=, info_p3_2_3 = std::move(info_p3_2_3)]() {
            return ({
                auto [gg_p6, s_p7] = p0;
                auto d_p8 = p1;
                (prism_rtl::more(prism_rtl::rc(ConvertDecl(gg_p6, s_p7, info_p3_2_3, d_p8))));
            });
        }));
        });
    }));
    })), [=](std::tuple<crate::check::env::G, crate::check::types::St> fold_1281) {
        return ({
            auto [g2_p9, s2_pa] = fold_1281;
            auto s3_p5 = missing_signatures(g2_p9, s2_pa, info_p3);
            (prism_rtl::finished(std::tuple{g2_p9, s3_p5}));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ConvertDecls, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_convert_decls(crate::check::env::G g_p0, crate::check::types::St st_p1, Text m_p2) {
    return prism_rtl::make_rc<ConvertDecls>(g_p0, st_p1, m_p2);
}


/// ConvertTypeDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> convert_type_decl(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2, const crate::syntax::decls::Decl& d_p3) {
    auto&& _m = d_p3.kind;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DType>(_m)) {
        auto&& t_p4 = prism_rtl::as<crate::syntax::decls::DeclKind::DType>(_m).a0;
        auto name_p5 = crate::check::env::qual_key(info_p2.name, crate::check::env::dotted(prism_rtl::deref(t_p4).name->path_));
        auto ti_p6 = or_(crate::prelude::get(g_p0.types, name_p5), crate::check::env::names::dummy_ty_info());
        auto cx_p7 = crate::check::env::reading::cx_of(g_p0, info_p2.name);
        auto params_p8 = each(prism_rtl::deref(t_p4).params, [&](const crate::syntax::Ident& p_pa) { return prism_rtl::deref(p_pa).name; });
        auto self_p9 = crate::check::types::Ty(crate::check::types::Ty::TyCon{name_p5, each(params_p8, [&](const Text& p_pb) { return crate::check::types::Ty(crate::check::types::Ty::TyQ{p_pb}); })});
        auto&& _m = prism_rtl::deref(t_p4).body;
        if (prism_rtl::is_none(_m)) {
            return std::tuple{g_p0, st_p1};
        }
        if (prism_rtl::is_some(_m)) {
            auto&& body_pc = prism_rtl::some_of(_m);
            if (prism_rtl::is<crate::syntax::decls::TypeBody::TbRecord>(body_pc)) {
                auto&& fs_pd = prism_rtl::as<crate::syntax::decls::TypeBody::TbRecord>(body_pc).a0;
                auto [fields_pl, st2_pm] = run_to_end(fold_job(fs_pd, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st_p1}, ({
                    auto cx_p7_1 = cx_p7;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field>)>>(prism_rtl::rc([=, cx_p7_1 = std::move(cx_p7_1)](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto cx_p7_1_2 = cx_p7_1;
                        entered(once_job([=, cx_p7_1_2 = std::move(cx_p7_1_2)]() {
                        return ({
                            auto [acc_pg, s_ph] = p0;
                            auto f_pi = p1;
                            call_then(crate::check::env::reading::start_conv_type(cx_p7_1_2, s_ph, prism_rtl::deref(f_pi).ty), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_2032) {
                            return ({
                                auto [ft_pj, s2_pk] = conv_type_2032;
                                (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pg, std::tuple{prism_rtl::deref(prism_rtl::deref(f_pi).name).name, ft_pj}), s2_pk}));
                            });
                        });
                        });
                    }));
                    });
                }));
                })));
                auto ctor_pe = crate::check::env::CtorInfo{.name = name_p5, .owner = name_p5, .params = params_p8, .args = each(fields_pl, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                    auto&& ft_pn = std::get<1>(_p0);
                    return ft_pn;
                }), .fields = each(fields_pl, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                    auto&& fname_po = std::get<0>(_p0);
                    return fname_po;
                }), .ty = self_p9, .index = Nat(0u)};
                auto upd_pf = ({
                    crate::check::env::G this_ = g_p0;
                    this_.types = insert(this_.types, name_p5, with_body(ti_p6, crate::check::env::TyBody(crate::check::env::TyBody::BRecord{fields_pl})));
                    this_.ctors = insert(this_.ctors, name_p5, ctor_pe);
                    (std::move(this_));
                });
                return std::tuple{upd_pf, st2_pm};
            }
            if (prism_rtl::is<crate::syntax::decls::TypeBody::TbChoice>(body_pc)) {
                auto&& cs_pp = prism_rtl::as<crate::syntax::decls::TypeBody::TbChoice>(body_pc).a0;
                return conv_cases(g_p0, st_p1, cx_p7, ti_p6, name_p5, params_p8, self_p9, cs_pp);
            }
            if (prism_rtl::is<crate::syntax::decls::TypeBody::TbNewtype>(body_pc)) {
                auto&& c_pq = prism_rtl::as<crate::syntax::decls::TypeBody::TbNewtype>(body_pc).a0;
                return conv_cases(g_p0, st_p1, cx_p7, ti_p6, name_p5, params_p8, self_p9, Array(std::vector{c_pq}));
            }
            if (prism_rtl::is<crate::syntax::decls::TypeBody::TbUnit>(body_pc)) {
                auto&& i_pr = prism_rtl::as<crate::syntax::decls::TypeBody::TbUnit>(body_pc).a0;
                auto ctor_ps = crate::check::env::CtorInfo{.name = crate::check::env::qual_key(info_p2.name, prism_rtl::deref(i_pr).name), .owner = name_p5, .params = params_p8, .args = Array<crate::check::types::Ty>{}, .fields = Array<Text>{}, .ty = self_p9, .index = Nat(0u)};
                auto upd_pt = ({
                    crate::check::env::G this_ = g_p0;
                    this_.types = insert(this_.types, name_p5, with_body(ti_p6, crate::check::env::TyBody(crate::check::env::TyBody::BChoice{Array(std::vector{std::tuple{prism_rtl::deref(i_pr).name, Array<crate::check::types::Ty>{}}})})));
                    this_.ctors = insert(this_.ctors, crate::check::env::qual_key(info_p2.name, prism_rtl::deref(i_pr).name), ctor_ps);
                    (std::move(this_));
                });
                return std::tuple{upd_pt, st_p1};
            }
            if (prism_rtl::is<crate::syntax::decls::TypeBody::TbRow>(body_pc)) {
                auto upd_pu = ({
                    crate::check::env::G this_ = g_p0;
                    this_.types = insert(this_.types, name_p5, with_body(ti_p6, crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{})));
                    (std::move(this_));
                });
                return std::tuple{upd_pu, st_p1};
            }
            if (prism_rtl::is<crate::syntax::decls::TypeBody::TbAlias>(body_pc)) {
                auto&& a_pv = prism_rtl::as<crate::syntax::decls::TypeBody::TbAlias>(body_pc).a0;
                auto [at_p11, st2_p12] = crate::check::env::reading::conv_type(cx_p7, st_p1, a_pv);
                auto upd_p10 = ({
                    crate::check::env::G this_ = g_p0;
                    this_.types = insert(this_.types, name_p5, with_body(ti_p6, crate::check::env::TyBody(crate::check::env::TyBody::BAlias{at_p11})));
                    (std::move(this_));
                });
                return std::tuple{upd_p10, st2_p12};
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return std::tuple{g_p0, st_p1};
    }
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvertTypeDecl::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& info_p2 = this->info_p2;
    const auto& d_p3 = this->d_p3;
    return ({
        auto&& _m = prism_rtl::deref(d_p3).kind;
        prism_rtl::is<crate::syntax::decls::DeclKind::DType>(_m) ? ({
        auto&& t_p4 = prism_rtl::as<crate::syntax::decls::DeclKind::DType>(_m).a0;
        ({
        auto name_p5 = crate::check::env::qual_key(prism_rtl::deref(info_p2).name, crate::check::env::dotted(prism_rtl::deref(t_p4).name->path_));
        auto ti_p6 = or_(crate::prelude::get(prism_rtl::deref(g_p0).types, name_p5), crate::check::env::names::dummy_ty_info());
        auto cx_p7 = crate::check::env::reading::cx_of(g_p0, prism_rtl::deref(info_p2).name);
        auto params_p8 = each(prism_rtl::deref(t_p4).params, [&](const crate::syntax::Ident& p_pa) { return prism_rtl::deref(p_pa).name; });
        auto self_p9 = crate::check::types::Ty(crate::check::types::Ty::TyCon{name_p5, each(params_p8, [&](const Text& p_pb) { return crate::check::types::Ty(crate::check::types::Ty::TyQ{p_pb}); })});
        ({
        auto&& _m = prism_rtl::deref(t_p4).body;
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g_p0, st_p1})
        : prism_rtl::is_some(_m) ? ({
        auto&& body_pc = prism_rtl::some_of(_m);
        ({
        prism_rtl::is<crate::syntax::decls::TypeBody::TbRecord>(body_pc) ? ({
        auto&& fs_pd = prism_rtl::as<crate::syntax::decls::TypeBody::TbRecord>(body_pc).a0;
        ({
        auto fs_pd_1 = fs_pd;
        auto g_p0_2 = g_p0;
        auto st_p1_3 = st_p1;
        call_value(fold_job(fs_pd_1, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st_p1_3}, ({
        auto cx_p7_4 = cx_p7;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field>)>>(prism_rtl::rc([=, cx_p7_4 = std::move(cx_p7_4)](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx_p7_4_5 = cx_p7_4;
            entered(once_job([=, cx_p7_4_5 = std::move(cx_p7_4_5)]() {
            return ({
                auto [acc_pg, s_ph] = p0;
                auto f_pi = p1;
                call_then(crate::check::env::reading::start_conv_type(cx_p7_4_5, s_ph, prism_rtl::deref(f_pi).ty), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_2032) {
                return ({
                    auto [ft_pj, s2_pk] = conv_type_2032;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pg, std::tuple{prism_rtl::deref(prism_rtl::deref(f_pi).name).name, ft_pj}), s2_pk}));
                });
            });
            });
        }));
        });
    }));
    })), [=, g_p0_2 = std::move(g_p0_2)](std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St> fold_1951) {
        return ({
            auto [fields_pl, st2_pm] = fold_1951;
            auto ctor_pe = crate::check::env::CtorInfo{.name = name_p5, .owner = name_p5, .params = params_p8, .args = each(fields_pl, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                auto&& ft_pn = std::get<1>(_p0);
                return ft_pn;
            }), .fields = each(fields_pl, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                auto&& fname_po = std::get<0>(_p0);
                return fname_po;
            }), .ty = self_p9, .index = Nat(0u)};
            auto upd_pf = ({
                crate::check::env::G this_ = g_p0_2;
                this_.types = insert(this_.types, name_p5, with_body(ti_p6, crate::check::env::TyBody(crate::check::env::TyBody::BRecord{fields_pl})));
                this_.ctors = insert(this_.ctors, name_p5, ctor_pe);
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{upd_pf, st2_pm}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::decls::TypeBody::TbChoice>(body_pc) ? ({
        auto&& cs_pp = prism_rtl::as<crate::syntax::decls::TypeBody::TbChoice>(body_pc).a0;
        prism_rtl::more(prism_rtl::rc(ConvCases(g_p0, st_p1, cx_p7, ti_p6, name_p5, params_p8, self_p9, cs_pp)));
    })
        : prism_rtl::is<crate::syntax::decls::TypeBody::TbNewtype>(body_pc) ? ({
        auto&& c_pq = prism_rtl::as<crate::syntax::decls::TypeBody::TbNewtype>(body_pc).a0;
        prism_rtl::more(prism_rtl::rc(ConvCases(g_p0, st_p1, cx_p7, ti_p6, name_p5, params_p8, self_p9, Array(std::vector{c_pq}))));
    })
        : prism_rtl::is<crate::syntax::decls::TypeBody::TbUnit>(body_pc) ? ({
        auto&& i_pr = prism_rtl::as<crate::syntax::decls::TypeBody::TbUnit>(body_pc).a0;
        ({
        auto ctor_ps = crate::check::env::CtorInfo{.name = crate::check::env::qual_key(prism_rtl::deref(info_p2).name, prism_rtl::deref(i_pr).name), .owner = name_p5, .params = params_p8, .args = Array<crate::check::types::Ty>{}, .fields = Array<Text>{}, .ty = self_p9, .index = Nat(0u)};
        auto upd_pt = ({
            crate::check::env::G this_ = g_p0;
            this_.types = insert(this_.types, name_p5, with_body(ti_p6, crate::check::env::TyBody(crate::check::env::TyBody::BChoice{Array(std::vector{std::tuple{prism_rtl::deref(i_pr).name, Array<crate::check::types::Ty>{}}})})));
            this_.ctors = insert(this_.ctors, crate::check::env::qual_key(prism_rtl::deref(info_p2).name, prism_rtl::deref(i_pr).name), ctor_ps);
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{upd_pt, st_p1}));
    });
    })
        : prism_rtl::is<crate::syntax::decls::TypeBody::TbRow>(body_pc) ? ({
        auto upd_pu = ({
            crate::check::env::G this_ = g_p0;
            this_.types = insert(this_.types, name_p5, with_body(ti_p6, crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{})));
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{upd_pu, st_p1}));
    })
        : prism_rtl::is<crate::syntax::decls::TypeBody::TbAlias>(body_pc) ? ({
        auto&& a_pv = prism_rtl::as<crate::syntax::decls::TypeBody::TbAlias>(body_pc).a0;
        ({
        auto a_pv_1 = a_pv;
        auto g_p0_2 = g_p0;
        auto st_p1_3 = st_p1;
        call_then(crate::check::env::reading::start_conv_type(cx_p7, st_p1_3, a_pv_1), [=, g_p0_2 = std::move(g_p0_2)](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_3366) {
        return ({
            auto [at_p11, st2_p12] = conv_type_3366;
            auto upd_p10 = ({
                crate::check::env::G this_ = g_p0_2;
                this_.types = insert(this_.types, name_p5, with_body(ti_p6, crate::check::env::TyBody(crate::check::env::TyBody::BAlias{at_p11})));
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{upd_p10, st2_p12}));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::finished(std::tuple{g_p0, st_p1});
    });
}


/// `Start ConvertTypeDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_convert_type_decl(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::Decl d_p3) {
    return prism_rtl::make_rc<ConvertTypeDecl>(g_p0, st_p1, info_p2, d_p3);
}


/// WithBody: fn TyInfo, TyBody -> TyInfo
crate::check::env::TyInfo with_body(const crate::check::env::TyInfo& ti_p0, const crate::check::env::TyBody& b_p1) {
    crate::check::env::TyInfo this_ = ti_p0;
    this_.body = b_p1;
    return this_;
}


/// ConvCases: unbounded fn G, St, Cx, TyInfo, Text, [Text], Ty, [Case] -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> conv_cases(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::reading::Cx_& cx_p2, const crate::check::env::TyInfo& ti_p3, const Text& name_p4, const Array<Text>& params_p5, const crate::check::types::Ty& self_p6, const Array<crate::syntax::decls::Case_>& cs_p7) {
    auto [cases_pg, st2_ph] = run_to_end(fold_job(cs_p7, std::tuple{Array<std::tuple<Text, Array<crate::check::types::Ty>>>{}, st_p1}, ({
        auto cx_p2_1 = cx_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>, crate::syntax::decls::Case_>)>>(prism_rtl::rc([=, cx_p2_1 = std::move(cx_p2_1)](std::tuple<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>, crate::syntax::decls::Case_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx_p2_1_2 = cx_p2_1;
            entered(once_job([=, cx_p2_1_2 = std::move(cx_p2_1_2)]() {
            return ({
                auto [acc_pa, s_pb] = p0;
                auto c_pc = p1;
                ({
                auto s1_pd = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    auto&& _m = prism_rtl::deref(c_pc).indexed;
                    if (prism_rtl::is_some(_m)) {
                        _v.set(crate::check::types::recording::err(s_pb, Text::lit("unsupported"), prism_rtl::deref(c_pc).span, Text::lit("this checker does not implement indexed choices for user types")));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s_pb);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(crate::check::env::reading::start_conv_types(cx_p2_1_2, s1_pd, c_pc->args), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_4053) {
                return ({
                    auto [args_pe, s2_pf] = conv_types_4053;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pa, std::tuple{crate::check::env::sname_key(prism_rtl::deref(c_pc).name), args_pe}), s2_pf}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto g2_p8 = fold(crate::check::errors::range0(len(cases_pg)), g_p0, [&](const crate::check::env::G& gg_pi, const Nat& i_pj) {
        return ({
            auto [cn_pl, args_pm] = or_(index(cases_pg, i_pj), std::tuple{Text::lit(""), Array<crate::check::types::Ty>{}});
            auto qk_pk = crate::check::env::qual_key(ti_p3.home, cn_pl);
            ({
            crate::check::env::G this_ = gg_pi;
            this_.ctors = insert(this_.ctors, qk_pk, crate::check::env::CtorInfo{.name = qk_pk, .owner = name_p4, .params = params_p5, .args = args_pm, .fields = Array<Text>{}, .ty = self_p6, .index = i_pj});
            (std::move(this_));
        });
        });
    });
    auto upd_p9 = ({
        crate::check::env::G this_ = g2_p8;
        this_.types = insert(this_.types, name_p4, with_body(ti_p3, crate::check::env::TyBody(crate::check::env::TyBody::BChoice{cases_pg})));
        (std::move(this_));
    });
    return std::tuple{upd_p9, st2_ph};
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvCases::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& cx_p2 = this->cx_p2;
    const auto& ti_p3 = this->ti_p3;
    const auto& name_p4 = this->name_p4;
    const auto& params_p5 = this->params_p5;
    const auto& self_p6 = this->self_p6;
    const auto& cs_p7 = this->cs_p7;
    auto cs_p7_1 = cs_p7;
    auto cx_p2_2 = cx_p2;
    auto g_p0_3 = g_p0;
    auto name_p4_4 = name_p4;
    auto params_p5_5 = params_p5;
    auto self_p6_6 = self_p6;
    auto st_p1_7 = st_p1;
    auto ti_p3_8 = ti_p3;
    return call_value(fold_job(cs_p7_1, std::tuple{Array<std::tuple<Text, Array<crate::check::types::Ty>>>{}, st_p1_7}, ({
        auto cx_p2_2_9 = cx_p2_2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>, crate::syntax::decls::Case_>)>>(prism_rtl::rc([=, cx_p2_2_9 = std::move(cx_p2_2_9)](std::tuple<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>, crate::syntax::decls::Case_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx_p2_2_9_9 = cx_p2_2_9;
            entered(once_job([=, cx_p2_2_9_9 = std::move(cx_p2_2_9_9)]() {
            return ({
                auto [acc_pa, s_pb] = p0;
                auto c_pc = p1;
                ({
                auto s1_pd = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    auto&& _m = prism_rtl::deref(c_pc).indexed;
                    if (prism_rtl::is_some(_m)) {
                        _v.set(crate::check::types::recording::err(s_pb, Text::lit("unsupported"), prism_rtl::deref(c_pc).span, Text::lit("this checker does not implement indexed choices for user types")));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s_pb);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(crate::check::env::reading::start_conv_types(cx_p2_2_9_9, s1_pd, c_pc->args), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_4053) {
                return ({
                    auto [args_pe, s2_pf] = conv_types_4053;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pa, std::tuple{crate::check::env::sname_key(prism_rtl::deref(c_pc).name), args_pe}), s2_pf}));
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St> fold_3815) {
        return ({
            auto [cases_pg, st2_ph] = fold_3815;
            auto g2_p8 = fold(crate::check::errors::range0(len(cases_pg)), g_p0_3, [&](const crate::check::env::G& gg_pi, const Nat& i_pj) {
                return ({
                    auto [cn_pl, args_pm] = or_(index(cases_pg, i_pj), std::tuple{Text::lit(""), Array<crate::check::types::Ty>{}});
                    auto qk_pk = crate::check::env::qual_key(prism_rtl::deref(ti_p3_8).home, cn_pl);
                    ({
                    crate::check::env::G this_ = gg_pi;
                    this_.ctors = insert(this_.ctors, qk_pk, crate::check::env::CtorInfo{.name = qk_pk, .owner = name_p4_4, .params = params_p5_5, .args = args_pm, .fields = Array<Text>{}, .ty = self_p6_6, .index = i_pj});
                    (std::move(this_));
                });
                });
            });
            auto upd_p9 = ({
                crate::check::env::G this_ = g2_p8;
                this_.types = insert(this_.types, name_p4_4, with_body(ti_p3_8, crate::check::env::TyBody(crate::check::env::TyBody::BChoice{cases_pg})));
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{upd_p9, st2_ph}));
        });
    });
}


/// `Start ConvCases, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_conv_cases(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::reading::Cx_ cx_p2, crate::check::env::TyInfo ti_p3, Text name_p4, Array<Text> params_p5, crate::check::types::Ty self_p6, Array<crate::syntax::decls::Case_> cs_p7) {
    return prism_rtl::make_rc<ConvCases>(g_p0, st_p1, cx_p2, ti_p3, name_p4, params_p5, self_p6, cs_p7);
}


/// ConvertDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> convert_decl(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2, const crate::syntax::decls::Decl& d_p3) {
    auto&& _m = d_p3.kind;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DSignature>(_m)) {
        auto&& s_p4 = prism_rtl::as<crate::syntax::decls::DeclKind::DSignature>(_m).a0;
        auto qk_p5 = crate::check::env::qual_key(info_p2.name, crate::check::env::def_name_text(prism_rtl::deref(s_p4).name));
        auto cx_p6 = crate::check::env::reading::cx_of(g_p0, info_p2.name);
        auto [sc_p9, st1_pa] = crate::check::env::reading::sig_scheme(cx_p6, st_p1, prism_rtl::deref(s_p4).ty, prism_rtl::deref(s_p4).bounds);
        auto st2_p7 = lens_check(st1_pa, crate::check::env::def_name_text(prism_rtl::deref(s_p4).name), prism_rtl::deref(s_p4).ty, crate::check::env::def_name_span(prism_rtl::deref(s_p4).name));
        auto st3_p8 = check_mark_function(st2_p7, crate::check::env::def_name_text(prism_rtl::deref(s_p4).name), prism_rtl::deref(sc_p9).ty, crate::check::env::def_name_span(prism_rtl::deref(s_p4).name));
        return crate::check::env::has_key(g_p0.vals, qk_p5)
            ? std::tuple{g_p0, crate::check::types::recording::err(st3_p8, Text::lit("collision"), d_p3.span, prism_rtl::cat("a second signature for `", crate::check::env::def_name_text(prism_rtl::deref(s_p4).name), "`"))}
            : ({
            auto upd_pb = ({
                crate::check::env::G this_ = g_p0;
                this_.vals = insert(this_.vals, qk_p5, crate::check::env::ValInfo{.qk = qk_p5, .scheme = sc_p9, .sort = Text::lit("fn"), .has_sig = true, .home = info_p2.name, .file = info_p2.file, .span = d_p3.span});
                (std::move(this_));
            });
            std::tuple{upd_pb, st3_p8};
        });
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DFn>(_m)) {
        auto&& f_pc = prism_rtl::as<crate::syntax::decls::DeclKind::DFn>(_m).a0;
        auto qk_pd = crate::check::env::qual_key(info_p2.name, crate::check::env::def_name_text(prism_rtl::deref(f_pc).name));
        return std::tuple{add_clause(g_p0, info_p2, qk_pd, crate::check::env::def_name_text(prism_rtl::deref(f_pc).name), f_pc, d_p3.span, st_p1), st_p1};
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DLet>(_m)) {
        auto&& l_pe = prism_rtl::as<crate::syntax::decls::DeclKind::DLet>(_m).a0;
        auto names_pf = crate::check::env::names::pattern_names(prism_rtl::deref(l_pe).pattern);
        auto qk_pg = crate::check::env::qual_key(info_p2.name, or_(index(names_pf, Nat(0u)), Text::lit("")));
        auto def_ph = crate::check::env::Def{.qk = qk_pg, .name = or_(index(names_pf, Nat(0u)), Text::lit("")), .home = info_p2.name, .file = info_p2.file, .span = d_p3.span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbLet{l_pe})};
        auto upd_pi = ({
            crate::check::env::G this_ = g_p0;
            this_.defs = crate::prelude::push(this_.defs, def_ph);
            (std::move(this_));
        });
        return std::tuple{upd_pi, st_p1};
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DWidget>(_m)) {
        auto&& w_pj = prism_rtl::as<crate::syntax::decls::DeclKind::DWidget>(_m).a0;
        auto qk_pk = crate::check::env::qual_key(info_p2.name, crate::check::env::sname_key(prism_rtl::deref(w_pj).name));
        auto def_pl = crate::check::env::Def{.qk = qk_pk, .name = crate::check::env::sname_key(prism_rtl::deref(w_pj).name), .home = info_p2.name, .file = info_p2.file, .span = d_p3.span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbWidget{w_pj})};
        auto upd_pm = ({
            crate::check::env::G this_ = g_p0;
            this_.defs = crate::prelude::push(this_.defs, def_pl);
            (std::move(this_));
        });
        return std::tuple{upd_pm, st_p1};
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTag>(_m)) {
        auto&& t_pn = prism_rtl::as<crate::syntax::decls::DeclKind::DTag>(_m).a0;
        return conv_tag(g_p0, st_p1, info_p2, t_pn, d_p3.span);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m)) {
        auto&& t_po = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        return conv_trait(g_p0, st_p1, info_p2, t_po, d_p3.span);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DImpl>(_m)) {
        auto&& i_pp = prism_rtl::as<crate::syntax::decls::DeclKind::DImpl>(_m).a0;
        return conv_impl(g_p0, st_p1, info_p2, i_pp, d_p3.span);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DCheck>(_m)) {
        auto&& c_pq = prism_rtl::as<crate::syntax::decls::DeclKind::DCheck>(_m).a0;
        auto upd_pr = ({
            crate::check::env::G this_ = g_p0;
            this_.defs = crate::prelude::push(this_.defs, crate::check::env::Def{.qk = crate::check::env::qual_key(info_p2.name, prism_rtl::cat("check ", prism_rtl::deref(prism_rtl::deref(c_pq).name).name)), .name = prism_rtl::deref(prism_rtl::deref(c_pq).name).name, .home = info_p2.name, .file = info_p2.file, .span = d_p3.span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbCheck{c_pq})});
            (std::move(this_));
        });
        return std::tuple{upd_pr, st_p1};
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTest>(_m)) {
        auto&& t_ps = prism_rtl::as<crate::syntax::decls::DeclKind::DTest>(_m).a0;
        auto upd_pt = ({
            crate::check::env::G this_ = g_p0;
            this_.defs = crate::prelude::push(this_.defs, crate::check::env::Def{.qk = crate::check::env::qual_key(info_p2.name, prism_rtl::cat("test ", prism_rtl::deref(prism_rtl::deref(t_ps).name).name)), .name = prism_rtl::deref(prism_rtl::deref(t_ps).name).name, .home = info_p2.name, .file = info_p2.file, .span = d_p3.span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbTest{t_ps})});
            (std::move(this_));
        });
        return std::tuple{upd_pt, st_p1};
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DStmt>(_m)) {
        auto&& s_pu = prism_rtl::as<crate::syntax::decls::DeclKind::DStmt>(_m).a0;
        auto&& _m = prism_rtl::deref(s_pu).kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m)) {
            return std::tuple{g_p0, st_p1};
        }
        {
            return std::tuple{g_p0, crate::check::types::recording::err(st_p1, Text::lit("unsupported"), d_p3.span, Text::lit("a statement at the top of a file: nothing at top level is built"))};
        }
    }
    {
        return std::tuple{g_p0, st_p1};
    }
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvertDecl::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& info_p2 = this->info_p2;
    const auto& d_p3 = this->d_p3;
    return ({
        auto&& _m = prism_rtl::deref(d_p3).kind;
        prism_rtl::is<crate::syntax::decls::DeclKind::DSignature>(_m) ? ({
        auto&& s_p4 = prism_rtl::as<crate::syntax::decls::DeclKind::DSignature>(_m).a0;
        ({
        auto qk_p5 = crate::check::env::qual_key(prism_rtl::deref(info_p2).name, crate::check::env::def_name_text(prism_rtl::deref(s_p4).name));
        auto cx_p6 = crate::check::env::reading::cx_of(g_p0, prism_rtl::deref(info_p2).name);
        auto d_p3_1 = d_p3;
        auto g_p0_2 = g_p0;
        auto info_p2_3 = info_p2;
        auto s_p4_4 = s_p4;
        auto st_p1_5 = st_p1;
        call_then(crate::check::env::reading::start_sig_scheme(cx_p6, st_p1_5, prism_rtl::deref(s_p4_4).ty, prism_rtl::deref(s_p4_4).bounds), [=, qk_p5 = std::move(qk_p5), d_p3_1 = std::move(d_p3_1), g_p0_2 = std::move(g_p0_2), info_p2_3 = std::move(info_p2_3)](std::tuple<crate::check::types::Scheme, crate::check::types::St> sig_scheme_4784) {
        return ({
            auto [sc_p9, st1_pa] = sig_scheme_4784;
            auto st2_p7 = lens_check(st1_pa, crate::check::env::def_name_text(prism_rtl::deref(s_p4_4).name), prism_rtl::deref(s_p4_4).ty, crate::check::env::def_name_span(prism_rtl::deref(s_p4_4).name));
            call_then(start_check_mark_function(st2_p7, crate::check::env::def_name_text(prism_rtl::deref(s_p4_4).name), prism_rtl::deref(sc_p9).ty, crate::check::env::def_name_span(prism_rtl::deref(s_p4_4).name)), [=](crate::check::types::St check_mark_function_4917) {
            return ({
                auto st3_p8 = check_mark_function_4917;
                (crate::check::env::has_key(prism_rtl::deref(g_p0_2).vals, qk_p5)
                ? prism_rtl::finished(std::tuple{g_p0_2, crate::check::types::recording::err(st3_p8, Text::lit("collision"), prism_rtl::deref(d_p3_1).span, prism_rtl::cat("a second signature for `", crate::check::env::def_name_text(prism_rtl::deref(s_p4_4).name), "`"))})
                : ({
                auto upd_pb = ({
                    crate::check::env::G this_ = g_p0_2;
                    this_.vals = insert(this_.vals, qk_p5, crate::check::env::ValInfo{.qk = qk_p5, .scheme = sc_p9, .sort = Text::lit("fn"), .has_sig = true, .home = prism_rtl::deref(info_p2_3).name, .file = info_p2_3->file, .span = prism_rtl::deref(d_p3_1).span});
                    (std::move(this_));
                });
                (prism_rtl::finished(std::tuple{upd_pb, st3_p8}));
            }));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DFn>(_m) ? ({
        auto&& f_pc = prism_rtl::as<crate::syntax::decls::DeclKind::DFn>(_m).a0;
        ({
        auto qk_pd = crate::check::env::qual_key(prism_rtl::deref(info_p2).name, crate::check::env::def_name_text(prism_rtl::deref(f_pc).name));
        (prism_rtl::finished(std::tuple{add_clause(g_p0, info_p2, qk_pd, crate::check::env::def_name_text(prism_rtl::deref(f_pc).name), f_pc, prism_rtl::deref(d_p3).span, st_p1), st_p1}));
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DLet>(_m) ? ({
        auto&& l_pe = prism_rtl::as<crate::syntax::decls::DeclKind::DLet>(_m).a0;
        ({
        auto d_p3_1 = d_p3;
        auto g_p0_2 = g_p0;
        auto info_p2_3 = info_p2;
        auto l_pe_4 = l_pe;
        auto st_p1_5 = st_p1;
        call_then(crate::check::env::names::start_pattern_names(prism_rtl::deref(l_pe_4).pattern), [=, d_p3_1 = std::move(d_p3_1), g_p0_2 = std::move(g_p0_2), info_p2_3 = std::move(info_p2_3), st_p1_5 = std::move(st_p1_5)](Array<Text> pattern_names_5497) {
        return ({
            auto names_pf = pattern_names_5497;
            auto qk_pg = crate::check::env::qual_key(prism_rtl::deref(info_p2_3).name, or_(index(names_pf, Nat(0u)), Text::lit("")));
            auto def_ph = crate::check::env::Def{.qk = qk_pg, .name = or_(index(names_pf, Nat(0u)), Text::lit("")), .home = prism_rtl::deref(info_p2_3).name, .file = info_p2_3->file, .span = prism_rtl::deref(d_p3_1).span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbLet{l_pe_4})};
            auto upd_pi = ({
                crate::check::env::G this_ = g_p0_2;
                this_.defs = crate::prelude::push(this_.defs, def_ph);
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{upd_pi, st_p1_5}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DWidget>(_m) ? ({
        auto&& w_pj = prism_rtl::as<crate::syntax::decls::DeclKind::DWidget>(_m).a0;
        ({
        auto qk_pk = crate::check::env::qual_key(prism_rtl::deref(info_p2).name, crate::check::env::sname_key(prism_rtl::deref(w_pj).name));
        auto def_pl = crate::check::env::Def{.qk = qk_pk, .name = crate::check::env::sname_key(prism_rtl::deref(w_pj).name), .home = prism_rtl::deref(info_p2).name, .file = info_p2->file, .span = prism_rtl::deref(d_p3).span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbWidget{w_pj})};
        auto upd_pm = ({
            crate::check::env::G this_ = g_p0;
            this_.defs = crate::prelude::push(this_.defs, def_pl);
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{upd_pm, st_p1}));
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTag>(_m) ? ({
        auto&& t_pn = prism_rtl::as<crate::syntax::decls::DeclKind::DTag>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvTag(g_p0, st_p1, info_p2, t_pn, prism_rtl::deref(d_p3).span)));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m) ? ({
        auto&& t_po = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvTrait(g_p0, st_p1, info_p2, t_po, prism_rtl::deref(d_p3).span)));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DImpl>(_m) ? ({
        auto&& i_pp = prism_rtl::as<crate::syntax::decls::DeclKind::DImpl>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvImpl(g_p0, st_p1, info_p2, i_pp, prism_rtl::deref(d_p3).span)));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DCheck>(_m) ? ({
        auto&& c_pq = prism_rtl::as<crate::syntax::decls::DeclKind::DCheck>(_m).a0;
        ({
        auto upd_pr = ({
            crate::check::env::G this_ = g_p0;
            this_.defs = crate::prelude::push(this_.defs, crate::check::env::Def{.qk = crate::check::env::qual_key(prism_rtl::deref(info_p2).name, prism_rtl::cat("check ", prism_rtl::deref(prism_rtl::deref(c_pq).name).name)), .name = prism_rtl::deref(prism_rtl::deref(c_pq).name).name, .home = prism_rtl::deref(info_p2).name, .file = info_p2->file, .span = prism_rtl::deref(d_p3).span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbCheck{c_pq})});
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{upd_pr, st_p1}));
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTest>(_m) ? ({
        auto&& t_ps = prism_rtl::as<crate::syntax::decls::DeclKind::DTest>(_m).a0;
        ({
        auto upd_pt = ({
            crate::check::env::G this_ = g_p0;
            this_.defs = crate::prelude::push(this_.defs, crate::check::env::Def{.qk = crate::check::env::qual_key(prism_rtl::deref(info_p2).name, prism_rtl::cat("test ", prism_rtl::deref(prism_rtl::deref(t_ps).name).name)), .name = prism_rtl::deref(prism_rtl::deref(t_ps).name).name, .home = prism_rtl::deref(info_p2).name, .file = info_p2->file, .span = prism_rtl::deref(d_p3).span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbTest{t_ps})});
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{upd_pt, st_p1}));
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DStmt>(_m) ? ({
        auto&& s_pu = prism_rtl::as<crate::syntax::decls::DeclKind::DStmt>(_m).a0;
        ({
        auto&& _m = prism_rtl::deref(s_pu).kind;
        prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m) ? prism_rtl::finished(std::tuple{g_p0, st_p1})
        : prism_rtl::finished(std::tuple{g_p0, crate::check::types::recording::err(st_p1, Text::lit("unsupported"), prism_rtl::deref(d_p3).span, Text::lit("a statement at the top of a file: nothing at top level is built"))});
    });
    })
        : prism_rtl::finished(std::tuple{g_p0, st_p1});
    });
}


/// `Start ConvertDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_convert_decl(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::Decl d_p3) {
    return prism_rtl::make_rc<ConvertDecl>(g_p0, st_p1, info_p2, d_p3);
}


/// AddClause: fn G, ModInfo, Text, Text, FnClause, Range, St -> G
crate::check::env::G add_clause(const crate::check::env::G& g_p0, const crate::check::env::ModInfo& info_p1, const Text& qk_p2, const Text& name_p3, const crate::syntax::decls::FnClause& f_p4, const crate::syntax::Range& span_p5, const crate::check::types::St& st_p6) {
    auto&& _m = crate::prelude::get(g_p0.fn_at, qk_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& i_p7 = prism_rtl::some_of(_m);
        crate::check::env::G this_ = g_p0;
        this_.defs = insert2(this_.defs, i_p7, add_to_fn(or_(index(this_.defs, i_p7), dummy_def()), f_p4));
        return this_;
    }
    if (prism_rtl::is_none(_m)) {
        crate::check::env::G this_ = g_p0;
        this_.fn_at = insert(this_.fn_at, qk_p2, len(this_.defs));
        this_.defs = crate::prelude::push(this_.defs, crate::check::env::Def{.qk = qk_p2, .name = name_p3, .home = info_p1.name, .file = info_p1.file, .span = span_p5, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbFn{Array(std::vector{f_p4})})});
        return this_;
    }
    prism_rtl::unreachable("no arm matched");
}


/// let dummyDef
crate::check::env::Def dummy_def() {
    return crate::check::env::Def{.qk = Text::lit(""), .name = Text::lit(""), .home = Text::lit(""), .file = Nat(0u), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbFn{Array<crate::syntax::decls::FnClause>{}})};
}


/// IsFnDef: fn Def -> Bool
bool is_fn_def(const crate::check::env::Def& d_p0) {
    auto&& _m = d_p0.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// AddToFn: fn Def, FnClause -> Def
crate::check::env::Def add_to_fn(const crate::check::env::Def& d_p0, const crate::syntax::decls::FnClause& f_p1) {
    auto&& _m = d_p0.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
        auto&& fs_p2 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
        crate::check::env::Def this_ = d_p0;
        this_.body = crate::check::env::DefBody(crate::check::env::DefBody::DbFn{crate::prelude::push(fs_p2, f_p1)});
        return this_;
    }
    {
        return d_p0;
    }
}


/// LensCheck: fn St, Text, Type, Range -> St
crate::check::types::St lens_check(const crate::check::types::St& st_p0, const Text& name_p1, const crate::syntax::Type& t_p2, const crate::syntax::Range& span_p3) {
    return !crate::syntax::lexer::chars::has_prefix(name_p1, Text::lit("&"))
        ? st_p0
        : ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = prism_rtl::deref(t_p2.kind);
        if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
            auto&& ps_p4 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
            _v.set(({
                auto refs_p5 = filter(ps_p4, [&](const crate::syntax::Type& p_p6) { return is_ref_type(p_p6); });
                len(refs_p5) > Nat(1u)
                ? crate::check::types::recording::err_fix(st_p0, Text::lit("lens-arity"), span_p3, Text::lit("a lens takes one reference"), Text::lit("take the second part as a plain value"))
                : crate::check::types::recording::err(st_p0, Text::lit("unsupported"), span_p3, Text::lit("this checker does not implement named lenses and `Over`"));
            }));
            goto _done;
        }
        {
            _v.set(st_p0);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// IsRefType: fn Type -> Bool
bool is_ref_type(const crate::syntax::Type& t_p0) {
    auto&& _m = prism_rtl::deref(t_p0.kind);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n_p1).sigils, Text::lit("&"));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& s_p2 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix(s_p2, Text::lit("&"));
    }
    {
        return false;
    }
}


/// CheckMarkFunction: unbounded fn St, Text, Ty, Range -> St
crate::check::types::St check_mark_function(const crate::check::types::St& st_p0, const Text& name_p1, const crate::check::types::Ty& t_p2, const crate::syntax::Range& span_p3) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p2)) {
        auto&& res_p4 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a2;
        auto want_p5 = crate::check::types::head_sigil(st_p0, prism_rtl::deref(prism_rtl::deref(res_p4)));
        auto marks_p6 = crate::check::types::unify::marks_of(name_p1);
        auto shown_p7 = crate::syntax::lexer::chars::head(marks_p6);
        auto bare_p8 = crate::syntax::lexer::chars::drop_prefix(name_p1, marks_p6);
        return (((shown_p7 == want_p5) || (len_text(marks_p6) > Nat(1u))) || (bare_p8 == Text::lit(""))) || (!crate::check::env::is_upper_text(bare_p8))
            ? st_p0
            : crate::check::types::recording::err_fix(st_p0, Text::lit("mark-function"), span_p3, prism_rtl::cat("`", name_p1, "` returns `", crate::check::types::show_ty(st_p0, prism_rtl::deref(prism_rtl::deref(res_p4))), "`; name it `", want_p5, bare_p8, "`"), prism_rtl::cat("rename to `", want_p5, bare_p8, "`"));
    }
    {
        return st_p0;
    }
}


prism_rtl::Turn<crate::check::types::St> CheckMarkFunction::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& name_p1 = this->name_p1;
    const auto& t_p2 = this->t_p2;
    const auto& span_p3 = this->span_p3;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFn>(t_p2) ? ({
        auto&& res_p4 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a2;
        ({
        auto name_p1_1 = name_p1;
        auto res_p4_2 = prism_rtl::deref(prism_rtl::deref(res_p4));
        auto span_p3_3 = span_p3;
        auto st_p0_4 = st_p0;
        call_then(crate::check::types::start_head_sigil(st_p0_4, res_p4_2), [=, name_p1_1 = std::move(name_p1_1), span_p3_3 = std::move(span_p3_3)](Text head_sigil_8937) {
        return ({
            auto want_p5 = head_sigil_8937;
            auto marks_p6 = crate::check::types::unify::marks_of(name_p1_1);
            auto shown_p7 = crate::syntax::lexer::chars::head(marks_p6);
            auto bare_p8 = crate::syntax::lexer::chars::drop_prefix(name_p1_1, marks_p6);
            (((shown_p7 == want_p5) || (len_text(marks_p6) > Nat(1u))) || (bare_p8 == Text::lit(""))) || (!crate::check::env::is_upper_text(bare_p8))
            ? prism_rtl::finished(st_p0_4)
            : call_then(crate::check::types::start_show_ty(st_p0_4, res_p4_2), [=](Text show_ty_9217) { return prism_rtl::finished(crate::check::types::recording::err_fix(st_p0_4, Text::lit("mark-function"), span_p3_3, prism_rtl::cat("`", name_p1_1, "` returns `", show_ty_9217, "`; name it `", want_p5, bare_p8, "`"), prism_rtl::cat("rename to `", want_p5, bare_p8, "`"))); });
        });
    });
    });
    })
        : prism_rtl::finished(st_p0);
    });
}


/// `Start CheckMarkFunction, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_mark_function(crate::check::types::St st_p0, Text name_p1, crate::check::types::Ty t_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<CheckMarkFunction>(st_p0, name_p1, t_p2, span_p3);
}


/// MissingSignatures: fn G, St, ModInfo -> St
crate::check::types::St missing_signatures(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2) {
    return fold(g_p0.defs, st_p1, [&](const crate::check::types::St& s_p3, const crate::check::env::Def& d_p4) {
        return ((prism_rtl::deref(d_p4).home == info_p2.name) && is_fn_def(d_p4)) && (!crate::check::env::has_key(g_p0.vals, prism_rtl::deref(d_p4).qk))
            ? crate::check::types::recording::err_fix(s_p3, Text::lit("no-signature"), prism_rtl::deref(d_p4).span, prism_rtl::cat("`", prism_rtl::deref(d_p4).name, "` has no signature line"), prism_rtl::cat("write `", prism_rtl::deref(d_p4).name, ": fn ... -> ...` above it"))
            : s_p3;
    });
}


/// ConvTag: unbounded fn G, St, ModInfo, TagDecl, Range -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> conv_tag(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2, const crate::syntax::decls::TagDecl& t_p3, const crate::syntax::Range& span_p4) {
    auto name_p5 = crate::check::env::dotted(t_p3.name->path_);
    auto family_p6 = crate::check::env::dotted(take(t_p3.name->path_, crate::syntax::lexer::chars::dec(len(t_p3.name->path_))));
    auto cx_p7 = crate::check::env::reading::cx_of(g_p0, info_p2.name);
    auto [kind_pb, out_pc, st2_pd] = tag_kind(g_p0, cx_p7, st_p1, t_p3.of_type);
    auto [fields_pj, st3_pk] = run_to_end(fold_job(t_p3.fields, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st2_pd}, ({
        auto cx_p7_1 = cx_p7;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field>)>>(prism_rtl::rc([=, cx_p7_1 = std::move(cx_p7_1)](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx_p7_1_2 = cx_p7_1;
            entered(once_job([=, cx_p7_1_2 = std::move(cx_p7_1_2)]() {
            return ({
                auto [acc_pe, s_pf] = p0;
                auto f_pg = p1;
                call_then(crate::check::env::reading::start_conv_type(cx_p7_1_2, s_pf, prism_rtl::deref(f_pg).ty), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_10129) {
                return ({
                    auto [ft_ph, s2_pi] = conv_type_10129;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pe, std::tuple{prism_rtl::deref(prism_rtl::deref(f_pg).name).name, ft_ph}), s2_pi}));
                });
            });
            });
        }));
        });
    }));
    })));
    auto qs_p8 = run_to_end(fold_job(t_p3.fields, crate::check::env::reading::type_vars_of_type(t_p3.of_type), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::decls::Field>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::decls::Field> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_pl = p0;
                auto f_pm = p1;
                call_then(crate::check::env::reading::start_type_vars_of_type(prism_rtl::deref(f_pm).ty), [=, acc_pl = std::move(acc_pl)](Array<Text> type_vars_of_type_10280) { return prism_rtl::finished(crate::check::types::union_texts(acc_pl, type_vars_of_type_10280)); });
            });
        }));
    }))));
    auto [bs_pn, st4_po] = crate::check::env::reading::conv_bounds(cx_p7, st3_pk, t_p3.bounds);
    auto tg_p9 = crate::check::env::TagInfo{.name = name_p5, .family = family_p6, .kind = kind_pb, .out = out_pc, .qs = qs_p8, .rqs = info_p2.row_var == Text::lit("")
        ? Array<Text>{}
        : Array(std::vector{info_p2.row_var}), .bounds = bs_pn, .fields = fields_pj, .home = info_p2.name, .file = info_p2.file, .span = span_p4};
    auto upd_pa = ({
        crate::check::env::G this_ = g_p0;
        this_.tags = insert(this_.tags, name_p5, tg_p9);
        (std::move(this_));
    });
    return std::tuple{upd_pa, st4_po};
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvTag::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& info_p2 = this->info_p2;
    const auto& t_p3 = this->t_p3;
    const auto& span_p4 = this->span_p4;
    auto name_p5 = crate::check::env::dotted(prism_rtl::deref(t_p3).name->path_);
    auto family_p6 = crate::check::env::dotted(take(prism_rtl::deref(t_p3).name->path_, crate::syntax::lexer::chars::dec(len(prism_rtl::deref(t_p3).name->path_))));
    auto cx_p7 = crate::check::env::reading::cx_of(g_p0, prism_rtl::deref(info_p2).name);
    auto g_p0_1 = g_p0;
    auto info_p2_2 = info_p2;
    auto span_p4_3 = span_p4;
    auto st_p1_4 = st_p1;
    auto t_p3_5 = t_p3;
    return call_then(start_tag_kind(g_p0_1, cx_p7, st_p1_4, prism_rtl::deref(t_p3_5).of_type), [=](std::tuple<Text, crate::check::types::Ty, crate::check::types::St> tag_kind_10003) {
        return ({
            auto [kind_pb, out_pc, st2_pd] = tag_kind_10003;
            call_value(fold_job(prism_rtl::deref(t_p3_5).fields, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st2_pd}, ({
            auto cx_p7_6 = cx_p7;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field>)>>(prism_rtl::rc([=, cx_p7_6 = std::move(cx_p7_6)](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx_p7_6_7 = cx_p7_6;
                entered(once_job([=, cx_p7_6_7 = std::move(cx_p7_6_7)]() {
                return ({
                    auto [acc_pe, s_pf] = p0;
                    auto f_pg = p1;
                    call_then(crate::check::env::reading::start_conv_type(cx_p7_6_7, s_pf, prism_rtl::deref(f_pg).ty), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_10129) {
                    return ({
                        auto [ft_ph, s2_pi] = conv_type_10129;
                        (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pe, std::tuple{prism_rtl::deref(prism_rtl::deref(f_pg).name).name, ft_ph}), s2_pi}));
                    });
                });
                });
            }));
            });
        }));
        })), [=](std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St> fold_10057) {
            return ({
                auto [fields_pj, st3_pk] = fold_10057;
                call_then(crate::check::env::reading::start_type_vars_of_type(prism_rtl::deref(t_p3_5).of_type), [=](Array<Text> type_vars_of_type_10227) {
                return call_value(fold_job(prism_rtl::deref(t_p3_5).fields, type_vars_of_type_10227, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::decls::Field>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::decls::Field> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto acc_pl = p0;
                            auto f_pm = p1;
                            call_then(crate::check::env::reading::start_type_vars_of_type(prism_rtl::deref(f_pm).ty), [=, acc_pl = std::move(acc_pl)](Array<Text> type_vars_of_type_10280) { return prism_rtl::finished(crate::check::types::union_texts(acc_pl, type_vars_of_type_10280)); });
                        });
                    }));
                }))), [=](Array<Text> fold_10211) {
                    return ({
                        auto qs_p8 = fold_10211;
                        auto [bs_pn, st4_po] = crate::check::env::reading::conv_bounds(cx_p7, st3_pk, prism_rtl::deref(t_p3_5).bounds);
                        auto tg_p9 = crate::check::env::TagInfo{.name = name_p5, .family = family_p6, .kind = kind_pb, .out = out_pc, .qs = qs_p8, .rqs = prism_rtl::deref(info_p2_2).row_var == Text::lit("")
                            ? Array<Text>{}
                            : Array(std::vector{prism_rtl::deref(info_p2_2).row_var}), .bounds = bs_pn, .fields = fields_pj, .home = prism_rtl::deref(info_p2_2).name, .file = info_p2_2->file, .span = span_p4_3};
                        auto upd_pa = ({
                            crate::check::env::G this_ = g_p0_1;
                            this_.tags = insert(this_.tags, name_p5, tg_p9);
                            (std::move(this_));
                        });
                        (prism_rtl::finished(std::tuple{upd_pa, st4_po}));
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start ConvTag, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_conv_tag(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::TagDecl t_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<ConvTag>(g_p0, st_p1, info_p2, t_p3, span_p4);
}


/// TagKind: unbounded fn G, Cx, St, Type -> ((Text, Ty, St))
std::tuple<Text, crate::check::types::Ty, crate::check::types::St> tag_kind(const crate::check::env::G& g_p0, const crate::check::env::reading::Cx_& cx_p1, const crate::check::types::St& st_p2, const crate::syntax::Type& t_p3) {
    auto&& _m = prism_rtl::deref(t_p3.kind);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n_p4 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p5 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        auto name_p6 = crate::check::env::dotted(n_p4->path_);
        return name_p6 == Text::lit("Element")
            ? ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> _v;
            auto&& _m = index(args_p5, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& o_p7 = prism_rtl::some_of(_m);
                _v.set(({
                    auto [ot_p8, s2_p9] = crate::check::env::reading::conv_type(cx_p1, st_p2, o_p7);
                    std::tuple{Text::lit("Element"), ot_p8, s2_p9};
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::tuple{Text::lit("Element"), crate::check::types::t_unit(), st_p2});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        })
            : ({
            auto&& _key_oa = crate::check::env::names::resolve_type(g_p0, cx_p1.home, n_p4->path_);
            auto&& key_oa = std::get<0>(_key_oa);
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> _v;
            if (prism_rtl::is_some(key_oa)) {
                auto&& k_pb = prism_rtl::some_of(key_oa);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> _v;
                    auto&& _m = prism_rtl::deref(or_(crate::prelude::get(g_p0.types, k_pb), crate::check::env::names::dummy_ty_info())).body;
                    if (prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m)) {
                        _v.set(std::tuple{k_pb, crate::check::types::t_unit(), st_p2});
                        goto _done;
                    }
                    {
                        _v.set(std::tuple{k_pb, crate::check::types::t_unit(), crate::check::types::recording::err(st_p2, Text::lit("kind"), t_p3.span, prism_rtl::cat("`", name_p6, "` is not a row kind: a tag joins `Element o`, `Fault` or another `type K = row`"))});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(key_oa)) {
                _v.set(std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p2, Text::lit("unknown-name"), t_p3.span, prism_rtl::cat("no row kind `", name_p6, "`"))});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_pc = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return tag_kind(g_p0, cx_p1, st_p2, prism_rtl::deref(prism_rtl::deref(x_pc)));
    }
    {
        return std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p2, Text::lit("kind"), t_p3.span, Text::lit("a tag joins a row kind"))};
    }
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> TagKind::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& cx_p1 = this->cx_p1;
    const auto& st_p2 = this->st_p2;
    const auto& t_p3 = this->t_p3;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p3).kind);
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& n_p4 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p5 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        ({
        auto name_p6 = crate::check::env::dotted(n_p4->path_);
        name_p6 == Text::lit("Element")
        ? ({
        auto&& _m = index(args_p5, Nat(0u));
        prism_rtl::is_some(_m) ? ({
        auto&& o_p7 = prism_rtl::some_of(_m);
        ({
        auto cx_p1_1 = cx_p1;
        auto st_p2_2 = st_p2;
        call_then(crate::check::env::reading::start_conv_type(cx_p1_1, st_p2_2, o_p7), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_10990) {
        return ({
            auto [ot_p8, s2_p9] = conv_type_10990;
            (prism_rtl::finished(std::tuple{Text::lit("Element"), ot_p8, s2_p9}));
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{Text::lit("Element"), crate::check::types::t_unit(), st_p2})
        : throw prism_rtl::Panic("no arm matched");
    })
        : ({
        auto&& _key_oa = crate::check::env::names::resolve_type(g_p0, prism_rtl::deref(cx_p1).home, n_p4->path_);
        auto&& key_oa = std::get<0>(_key_oa);
        ({
        prism_rtl::is_some(key_oa) ? ({
        auto&& k_pb = prism_rtl::some_of(key_oa);
        ({
        auto&& _m = prism_rtl::deref(or_(crate::prelude::get(prism_rtl::deref(g_p0).types, k_pb), crate::check::env::names::dummy_ty_info())).body;
        prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m) ? prism_rtl::finished(std::tuple{k_pb, crate::check::types::t_unit(), st_p2})
        : prism_rtl::finished(std::tuple{k_pb, crate::check::types::t_unit(), crate::check::types::recording::err(st_p2, Text::lit("kind"), prism_rtl::deref(t_p3).span, prism_rtl::cat("`", name_p6, "` is not a row kind: a tag joins `Element o`, `Fault` or another `type K = row`"))});
    });
    })
        : prism_rtl::is_none(key_oa) ? prism_rtl::finished(std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p2, Text::lit("unknown-name"), prism_rtl::deref(t_p3).span, prism_rtl::cat("no row kind `", name_p6, "`"))})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_pc = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TagKind(g_p0, cx_p1, st_p2, prism_rtl::deref(prism_rtl::deref(x_pc)))));
    })
        : prism_rtl::finished(std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p2, Text::lit("kind"), prism_rtl::deref(t_p3).span, Text::lit("a tag joins a row kind"))});
    });
}


/// `Start TagKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> start_tag_kind(crate::check::env::G g_p0, crate::check::env::reading::Cx_ cx_p1, crate::check::types::St st_p2, crate::syntax::Type t_p3) {
    return prism_rtl::make_rc<TagKind>(g_p0, cx_p1, st_p2, t_p3);
}


/// ConvTrait: unbounded fn G, St, ModInfo, TraitDecl, Range -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> conv_trait(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2, const crate::syntax::decls::TraitDecl& t_p3, const crate::syntax::Range& span_p4) {
    auto name_p5 = crate::check::env::qual_key(info_p2.name, crate::check::env::dotted(t_p3.name->path_));
    auto param_p6 = or_(index(each(t_p3.params, [&](const crate::syntax::Ident& p_pb) { return prism_rtl::deref(p_pb).name; }), Nat(0u)), Text::lit("a"));
    auto st1_p7 = len(t_p3.params) > Nat(1u)
        ? crate::check::types::recording::err(st_p1, Text::lit("unsupported"), span_p4, Text::lit("this checker does not implement traits of several types"))
        : st_p1;
    auto cx_p8 = crate::check::env::reading::cx_of(g_p0, info_p2.name);
    auto [supers_pc, st2_pd] = crate::check::env::reading::conv_bounds(cx_p8, st1_p7, t_p3.bounds);
    auto [g3_p11, st3_p12, methods_p13, defaults_p14, assocs_p15] = run_to_end(fold_job(t_p3.items, std::tuple{g_p0, st2_pd, Array<Text>{}, Array<Text>{}, Array<Text>{}}, ({
        auto info_p2_1 = info_p2;
        auto cx_p8_2 = cx_p8;
        auto param_p6_3 = param_p6;
        auto name_p5_4 = name_p5;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=, info_p2_1 = std::move(info_p2_1), cx_p8_2 = std::move(cx_p8_2), param_p6_3 = std::move(param_p6_3), name_p5_4 = std::move(name_p5_4)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>, crate::syntax::decls::TraitItem> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_p2_1_5 = info_p2_1;
            auto cx_p8_2_5 = cx_p8_2;
            auto param_p6_3_5 = param_p6_3;
            auto name_p5_4_5 = name_p5_4;
            entered(once_job([=, info_p2_1_5 = std::move(info_p2_1_5), cx_p8_2_5 = std::move(cx_p8_2_5), param_p6_3_5 = std::move(param_p6_3_5), name_p5_4_5 = std::move(name_p5_4_5)]() {
            return ({
                auto [gg_pe, s_pf, ms_pg, ds_ph, assoc_acc_pi] = p0;
                auto it_pj = p1;
                ({
                prism_rtl::is<crate::syntax::decls::TraitItem::TiSignature>(it_pj) ? ({
                auto&& sg_pk = prism_rtl::as<crate::syntax::decls::TraitItem::TiSignature>(it_pj).a0;
                ({
                auto mname_pl = crate::check::env::def_name_text(prism_rtl::deref(sg_pk).name);
                auto qk_pm = crate::check::env::qual_key(info_p2_1_5.name, mname_pl);
                auto sg_pk_5 = sg_pk;
                call_then(crate::check::env::reading::start_sig_scheme(cx_p8_2_5, s_pf, prism_rtl::deref(sg_pk_5).ty, prism_rtl::deref(sg_pk_5).bounds), [=, qk_pm = std::move(qk_pm)](std::tuple<crate::check::types::Scheme, crate::check::types::St> sig_scheme_12556) {
                return ({
                    auto [sc_pp, s2_pq] = sig_scheme_12556;
                    auto sc2_pn = ({
                        crate::check::types::Scheme this_ = sc_pp;
                        this_.qs = crate::check::types::has_text(this_.qs, param_p6_3_5)
                            ? this_.qs
                            : append(Array(std::vector{param_p6_3_5}), this_.qs);
                        this_.bounds = append(Array(std::vector{std::tuple{param_p6_3_5, name_p5_4_5}}), this_.bounds);
                        (std::move(this_));
                    });
                    auto upd_po = ({
                        crate::check::env::G this_ = gg_pe;
                        this_.vals = insert(this_.vals, qk_pm, crate::check::env::ValInfo{.qk = qk_pm, .scheme = sc2_pn, .sort = Text::lit("method"), .has_sig = true, .home = info_p2_1_5.name, .file = info_p2_1_5.file, .span = prism_rtl::deref(sg_pk_5).span});
                        (std::move(this_));
                    });
                    (prism_rtl::finished(std::tuple{upd_po, s2_pq, crate::prelude::push(ms_pg, qk_pm), ds_ph, assoc_acc_pi}));
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it_pj) ? ({
                auto&& f_pr = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it_pj).a0;
                ({
                auto qk_ps = crate::check::env::qual_key(info_p2_1_5.name, crate::check::env::def_name_text(prism_rtl::deref(f_pr).name));
                auto def_pt = crate::check::env::Def{.qk = qk_ps, .name = crate::check::env::def_name_text(prism_rtl::deref(f_pr).name), .home = info_p2_1_5.name, .file = info_p2_1_5.file, .span = prism_rtl::deref(f_pr).span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbDefault{Array(std::vector{f_pr}), name_p5_4_5})};
                auto upd_pu = ({
                    crate::check::env::G this_ = gg_pe;
                    this_.defs = crate::prelude::push(this_.defs, def_pt);
                    (std::move(this_));
                });
                (prism_rtl::finished(std::tuple{upd_pu, s_pf, ms_pg, crate::prelude::push(ds_ph, qk_ps), assoc_acc_pi}));
            });
            })
                : prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocType>(it_pj) ? ({
                auto&& n_pv = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it_pj).a0;
                prism_rtl::finished(std::tuple{gg_pe, s_pf, ms_pg, ds_ph, crate::prelude::push(assoc_acc_pi, prism_rtl::deref(n_pv).name)});
            })
                : prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocRow>(it_pj) ? ({
                auto&& r_p10 = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocRow>(it_pj).a1;
                prism_rtl::finished(std::tuple{gg_pe, crate::check::types::recording::err(s_pf, Text::lit("unsupported"), r_p10, Text::lit("this checker does not implement associated rows")), ms_pg, ds_ph, assoc_acc_pi});
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
    auto ti_p9 = crate::check::env::TraitInfo{.name = name_p5, .home = info_p2.name, .param = param_p6, .supers = each(supers_pc, [&](const std::tuple<Text, Text>& _p0) {
        auto&& k_p16 = std::get<1>(_p0);
        return k_p16;
    }), .methods = methods_p13, .defaults = defaults_p14, .assocs = assocs_p15, .file = info_p2.file, .span = span_p4};
    auto upd3_pa = ({
        crate::check::env::G this_ = g3_p11;
        this_.traits = insert(this_.traits, name_p5, ti_p9);
        (std::move(this_));
    });
    return std::tuple{upd3_pa, st3_p12};
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvTrait::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& info_p2 = this->info_p2;
    const auto& t_p3 = this->t_p3;
    const auto& span_p4 = this->span_p4;
    auto name_p5 = crate::check::env::qual_key(prism_rtl::deref(info_p2).name, crate::check::env::dotted(prism_rtl::deref(t_p3).name->path_));
    auto param_p6 = or_(index(each(prism_rtl::deref(t_p3).params, [&](const crate::syntax::Ident& p_pb) { return prism_rtl::deref(p_pb).name; }), Nat(0u)), Text::lit("a"));
    auto st1_p7 = len(prism_rtl::deref(t_p3).params) > Nat(1u)
        ? crate::check::types::recording::err(st_p1, Text::lit("unsupported"), span_p4, Text::lit("this checker does not implement traits of several types"))
        : st_p1;
    auto cx_p8 = crate::check::env::reading::cx_of(g_p0, prism_rtl::deref(info_p2).name);
    auto [supers_pc, st2_pd] = crate::check::env::reading::conv_bounds(cx_p8, st1_p7, prism_rtl::deref(t_p3).bounds);
    auto g_p0_1 = g_p0;
    auto info_p2_2 = info_p2;
    auto span_p4_3 = span_p4;
    auto t_p3_4 = t_p3;
    return call_value(fold_job(prism_rtl::deref(t_p3_4).items, std::tuple{g_p0_1, st2_pd, Array<Text>{}, Array<Text>{}, Array<Text>{}}, ({
        auto info_p2_2_5 = info_p2_2;
        auto cx_p8_5 = cx_p8;
        auto param_p6_6 = param_p6;
        auto name_p5_7 = name_p5;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=, info_p2_2_5 = std::move(info_p2_2_5), cx_p8_5 = std::move(cx_p8_5), param_p6_6 = std::move(param_p6_6), name_p5_7 = std::move(name_p5_7)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>, crate::syntax::decls::TraitItem> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_p2_2_5_8 = info_p2_2_5;
            auto cx_p8_5_8 = cx_p8_5;
            auto param_p6_6_8 = param_p6_6;
            auto name_p5_7_8 = name_p5_7;
            entered(once_job([=, info_p2_2_5_8 = std::move(info_p2_2_5_8), cx_p8_5_8 = std::move(cx_p8_5_8), param_p6_6_8 = std::move(param_p6_6_8), name_p5_7_8 = std::move(name_p5_7_8)]() {
            return ({
                auto [gg_pe, s_pf, ms_pg, ds_ph, assoc_acc_pi] = p0;
                auto it_pj = p1;
                ({
                prism_rtl::is<crate::syntax::decls::TraitItem::TiSignature>(it_pj) ? ({
                auto&& sg_pk = prism_rtl::as<crate::syntax::decls::TraitItem::TiSignature>(it_pj).a0;
                ({
                auto mname_pl = crate::check::env::def_name_text(prism_rtl::deref(sg_pk).name);
                auto qk_pm = crate::check::env::qual_key(prism_rtl::deref(info_p2_2_5_8).name, mname_pl);
                auto sg_pk_8 = sg_pk;
                call_then(crate::check::env::reading::start_sig_scheme(cx_p8_5_8, s_pf, prism_rtl::deref(sg_pk_8).ty, prism_rtl::deref(sg_pk_8).bounds), [=, qk_pm = std::move(qk_pm)](std::tuple<crate::check::types::Scheme, crate::check::types::St> sig_scheme_12556) {
                return ({
                    auto [sc_pp, s2_pq] = sig_scheme_12556;
                    auto sc2_pn = ({
                        crate::check::types::Scheme this_ = sc_pp;
                        this_.qs = crate::check::types::has_text(this_.qs, param_p6_6_8)
                            ? this_.qs
                            : append(Array(std::vector{param_p6_6_8}), this_.qs);
                        this_.bounds = append(Array(std::vector{std::tuple{param_p6_6_8, name_p5_7_8}}), this_.bounds);
                        (std::move(this_));
                    });
                    auto upd_po = ({
                        crate::check::env::G this_ = gg_pe;
                        this_.vals = insert(this_.vals, qk_pm, crate::check::env::ValInfo{.qk = qk_pm, .scheme = sc2_pn, .sort = Text::lit("method"), .has_sig = true, .home = prism_rtl::deref(info_p2_2_5_8).name, .file = info_p2_2_5_8->file, .span = prism_rtl::deref(sg_pk_8).span});
                        (std::move(this_));
                    });
                    (prism_rtl::finished(std::tuple{upd_po, s2_pq, crate::prelude::push(ms_pg, qk_pm), ds_ph, assoc_acc_pi}));
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it_pj) ? ({
                auto&& f_pr = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it_pj).a0;
                ({
                auto qk_ps = crate::check::env::qual_key(prism_rtl::deref(info_p2_2_5_8).name, crate::check::env::def_name_text(prism_rtl::deref(f_pr).name));
                auto def_pt = crate::check::env::Def{.qk = qk_ps, .name = crate::check::env::def_name_text(prism_rtl::deref(f_pr).name), .home = prism_rtl::deref(info_p2_2_5_8).name, .file = info_p2_2_5_8->file, .span = prism_rtl::deref(f_pr).span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbDefault{Array(std::vector{f_pr}), name_p5_7_8})};
                auto upd_pu = ({
                    crate::check::env::G this_ = gg_pe;
                    this_.defs = crate::prelude::push(this_.defs, def_pt);
                    (std::move(this_));
                });
                (prism_rtl::finished(std::tuple{upd_pu, s_pf, ms_pg, crate::prelude::push(ds_ph, qk_ps), assoc_acc_pi}));
            });
            })
                : prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocType>(it_pj) ? ({
                auto&& n_pv = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it_pj).a0;
                prism_rtl::finished(std::tuple{gg_pe, s_pf, ms_pg, ds_ph, crate::prelude::push(assoc_acc_pi, prism_rtl::deref(n_pv).name)});
            })
                : prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocRow>(it_pj) ? ({
                auto&& r_p10 = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocRow>(it_pj).a1;
                prism_rtl::finished(std::tuple{gg_pe, crate::check::types::recording::err(s_pf, Text::lit("unsupported"), r_p10, Text::lit("this checker does not implement associated rows")), ms_pg, ds_ph, assoc_acc_pi});
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>> fold_12324) {
        return ({
            auto [g3_p11, st3_p12, methods_p13, defaults_p14, assocs_p15] = fold_12324;
            auto ti_p9 = crate::check::env::TraitInfo{.name = name_p5, .home = prism_rtl::deref(info_p2_2).name, .param = param_p6, .supers = each(supers_pc, [&](const std::tuple<Text, Text>& _p0) {
                auto&& k_p16 = std::get<1>(_p0);
                return k_p16;
            }), .methods = methods_p13, .defaults = defaults_p14, .assocs = assocs_p15, .file = info_p2_2->file, .span = span_p4_3};
            auto upd3_pa = ({
                crate::check::env::G this_ = g3_p11;
                this_.traits = insert(this_.traits, name_p5, ti_p9);
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{upd3_pa, st3_p12}));
        });
    });
}


/// `Start ConvTrait, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_conv_trait(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::TraitDecl t_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<ConvTrait>(g_p0, st_p1, info_p2, t_p3, span_p4);
}


/// ConvImpl: unbounded fn G, St, ModInfo, ImplDecl, Range -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> conv_impl(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2, const crate::syntax::decls::ImplDecl& i_p3, const crate::syntax::Range& span_p4) {
    auto&& _m = crate::check::env::names::resolve_trait(g_p0, info_p2.name, i_p3.trait_ref->path_);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{g_p0, crate::check::types::recording::err(st_p1, Text::lit("unknown-name"), prism_rtl::deref(i_p3.trait_ref).span, prism_rtl::cat("no trait `^", crate::check::env::dotted(i_p3.trait_ref->path_), "`"))};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& cls_p5 = prism_rtl::some_of(_m);
        auto cx_p6 = crate::check::env::reading::cx_of(g_p0, info_p2.name);
        auto [head_pb, st2_pc] = crate::check::env::reading::conv_type(cx_p6, st_p1, i_p3.ty);
        auto [bs_pd, st3_pe] = crate::check::env::reading::conv_bounds(cx_p6, st2_pc, i_p3.bounds);
        auto [assocs_pm, st4_pn] = run_to_end(fold_job(i_p3.items, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st3_pe}, ({
            auto cx_p6_1 = cx_p6;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=, cx_p6_1 = std::move(cx_p6_1)](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::TraitItem> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx_p6_1_2 = cx_p6_1;
                entered(once_job([=, cx_p6_1_2 = std::move(cx_p6_1_2)]() {
                return ({
                    auto [acc_pf, s_pg] = p0;
                    auto it_ph = p1;
                    ({
                    prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocType>(it_ph) && prism_rtl::is_some(prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it_ph).a2) ? ({
                    auto&& n_pi = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it_ph).a0;
                    auto&& v_pj = prism_rtl::some_of(prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it_ph).a2);
                    ({
                    auto n_pi_2 = n_pi;
                    auto v_pj_3 = v_pj;
                    call_then(crate::check::env::reading::start_conv_type(cx_p6_1_2, s_pg, v_pj_3), [=, n_pi_2 = std::move(n_pi_2)](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_14573) {
                    return ({
                        auto [vt_pk, s2_pl] = conv_type_14573;
                        (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pf, std::tuple{prism_rtl::deref(n_pi_2).name, vt_pk}), s2_pl}));
                    });
                });
                });
                })
                    : prism_rtl::finished(std::tuple{acc_pf, s_pg});
                });
                });
            }));
            });
        }));
        })));
        auto names_p7 = fold(i_p3.items, Array<Text>{}, [&](const Array<Text>& acc_po, const crate::syntax::decls::TraitItem& it_pp) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                if (prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it_pp)) {
                    auto&& f_pq = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it_pp).a0;
                    _v.set(crate::check::types::add_text(acc_po, crate::check::env::def_name_text(prism_rtl::deref(f_pq).name)));
                    goto _done;
                }
                {
                    _v.set(acc_po);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
        auto im_p8 = crate::check::env::ImplInfo{.cls = cls_p5, .head = head_pb, .qs = crate::check::env::reading::type_vars_of_type(i_p3.ty), .bounds = bs_pd, .home = info_p2.name, .file = info_p2.file, .span = span_p4, .derived = false, .assocs = assocs_pm, .methods = names_p7};
        auto g2_p9 = ({
            crate::check::env::G this_ = g_p0;
            this_.impls = insert(this_.impls, cls_p5, crate::prelude::push(or_(crate::prelude::get(this_.impls, cls_p5), Array<crate::check::env::ImplInfo>{}), im_p8));
            (std::move(this_));
        });
        auto g3_pa = fold(names_p7, g2_p9, [&](const crate::check::env::G& gg_pr, const Text& mname_ps) {
            return ({
                auto clauses_pt = fold(i_p3.items, Array<crate::syntax::decls::FnClause>{}, [&](const Array<crate::syntax::decls::FnClause>& acc_pu, const crate::syntax::decls::TraitItem& it_pv) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
                        if (prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it_pv)) {
                            auto&& f_p10 = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it_pv).a0;
                            _v.set(crate::check::env::def_name_text(prism_rtl::deref(f_p10).name) == mname_ps
                                ? crate::prelude::push(acc_pu, f_p10)
                                : acc_pu);
                            goto _done;
                        }
                        {
                            _v.set(acc_pu);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                ({
                crate::check::env::G this_ = gg_pr;
                this_.defs = crate::prelude::push(this_.defs, crate::check::env::Def{.qk = prism_rtl::cat(cls_p5, " impl ", mname_ps), .name = mname_ps, .home = info_p2.name, .file = info_p2.file, .span = span_p4, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbMethod{clauses_pt, cls_p5, im_p8})});
                (std::move(this_));
            });
            });
        });
        return std::tuple{g3_pa, st4_pn};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvImpl::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& info_p2 = this->info_p2;
    const auto& i_p3 = this->i_p3;
    const auto& span_p4 = this->span_p4;
    return ({
        auto&& _m = crate::check::env::names::resolve_trait(g_p0, prism_rtl::deref(info_p2).name, prism_rtl::deref(i_p3).trait_ref->path_);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g_p0, crate::check::types::recording::err(st_p1, Text::lit("unknown-name"), prism_rtl::deref(prism_rtl::deref(i_p3).trait_ref).span, prism_rtl::cat("no trait `^", crate::check::env::dotted(prism_rtl::deref(i_p3).trait_ref->path_), "`"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& cls_p5 = prism_rtl::some_of(_m);
        ({
        auto cx_p6 = crate::check::env::reading::cx_of(g_p0, prism_rtl::deref(info_p2).name);
        auto g_p0_1 = g_p0;
        auto i_p3_2 = i_p3;
        auto info_p2_3 = info_p2;
        auto span_p4_4 = span_p4;
        auto st_p1_5 = st_p1;
        call_then(crate::check::env::reading::start_conv_type(cx_p6, st_p1_5, prism_rtl::deref(i_p3_2).ty), [=, g_p0_1 = std::move(g_p0_1), info_p2_3 = std::move(info_p2_3), span_p4_4 = std::move(span_p4_4)](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_14326) {
        return ({
            auto [head_pb, st2_pc] = conv_type_14326;
            auto [bs_pd, st3_pe] = crate::check::env::reading::conv_bounds(cx_p6, st2_pc, prism_rtl::deref(i_p3_2).bounds);
            call_value(fold_job(prism_rtl::deref(i_p3_2).items, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st3_pe}, ({
            auto cx_p6_6 = cx_p6;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=, cx_p6_6 = std::move(cx_p6_6)](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::TraitItem> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx_p6_6_7 = cx_p6_6;
                entered(once_job([=, cx_p6_6_7 = std::move(cx_p6_6_7)]() {
                return ({
                    auto [acc_pf, s_pg] = p0;
                    auto it_ph = p1;
                    ({
                    prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocType>(it_ph) && prism_rtl::is_some(prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it_ph).a2) ? ({
                    auto&& n_pi = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it_ph).a0;
                    auto&& v_pj = prism_rtl::some_of(prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it_ph).a2);
                    ({
                    auto n_pi_7 = n_pi;
                    auto v_pj_8 = v_pj;
                    call_then(crate::check::env::reading::start_conv_type(cx_p6_6_7, s_pg, v_pj_8), [=, n_pi_7 = std::move(n_pi_7)](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_14573) {
                    return ({
                        auto [vt_pk, s2_pl] = conv_type_14573;
                        (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pf, std::tuple{prism_rtl::deref(n_pi_7).name, vt_pk}), s2_pl}));
                    });
                });
                });
                })
                    : prism_rtl::finished(std::tuple{acc_pf, s_pg});
                });
                });
            }));
            });
        }));
        })), [=](std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St> fold_14433) {
            return ({
                auto [assocs_pm, st4_pn] = fold_14433;
                auto names_p7 = fold(prism_rtl::deref(i_p3_2).items, Array<Text>{}, [&](const Array<Text>& acc_po, const crate::syntax::decls::TraitItem& it_pp) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        if (prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it_pp)) {
                            auto&& f_pq = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it_pp).a0;
                            _v.set(crate::check::types::add_text(acc_po, crate::check::env::def_name_text(prism_rtl::deref(f_pq).name)));
                            goto _done;
                        }
                        {
                            _v.set(acc_po);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                call_then(crate::check::env::reading::start_type_vars_of_type(prism_rtl::deref(i_p3_2).ty), [=, names_p7 = std::move(names_p7)](Array<Text> type_vars_of_type_14868) {
                return ({
                    auto im_p8 = crate::check::env::ImplInfo{.cls = cls_p5, .head = head_pb, .qs = type_vars_of_type_14868, .bounds = bs_pd, .home = prism_rtl::deref(info_p2_3).name, .file = info_p2_3->file, .span = span_p4_4, .derived = false, .assocs = assocs_pm, .methods = names_p7};
                    auto g2_p9 = ({
                        crate::check::env::G this_ = g_p0_1;
                        this_.impls = insert(this_.impls, cls_p5, crate::prelude::push(or_(crate::prelude::get(this_.impls, cls_p5), Array<crate::check::env::ImplInfo>{}), im_p8));
                        (std::move(this_));
                    });
                    auto g3_pa = fold(names_p7, g2_p9, [&](const crate::check::env::G& gg_pr, const Text& mname_ps) {
                        return ({
                            auto clauses_pt = fold(prism_rtl::deref(i_p3_2).items, Array<crate::syntax::decls::FnClause>{}, [&](const Array<crate::syntax::decls::FnClause>& acc_pu, const crate::syntax::decls::TraitItem& it_pv) {
                                return ({
                                    __label__ _done;
                                    prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
                                    if (prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it_pv)) {
                                        auto&& f_p10 = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it_pv).a0;
                                        _v.set(crate::check::env::def_name_text(prism_rtl::deref(f_p10).name) == mname_ps
                                            ? crate::prelude::push(acc_pu, f_p10)
                                            : acc_pu);
                                        goto _done;
                                    }
                                    {
                                        _v.set(acc_pu);
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                            });
                            ({
                            crate::check::env::G this_ = gg_pr;
                            this_.defs = crate::prelude::push(this_.defs, crate::check::env::Def{.qk = prism_rtl::cat(cls_p5, " impl ", mname_ps), .name = mname_ps, .home = prism_rtl::deref(info_p2_3).name, .file = info_p2_3->file, .span = span_p4_4, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbMethod{clauses_pt, cls_p5, im_p8})});
                            (std::move(this_));
                        });
                        });
                    });
                    (prism_rtl::finished(std::tuple{g3_pa, st4_pn}));
                });
            });
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ConvImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_conv_impl(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::ImplDecl i_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<ConvImpl>(g_p0, st_p1, info_p2, i_p3, span_p4);
}

}  // namespace crate::check::env::decls
