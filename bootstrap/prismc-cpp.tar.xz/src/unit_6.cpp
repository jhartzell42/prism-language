// The module `Check.Env.Decls`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/env/decls/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/decls/generic.hpp>
#include <check/env/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Env.Decls`, from `target/bootstrap/cpp-src/prismc/check/env/decls.prism`.
namespace crate::check::env::decls {

/// ConvertTypes: unbounded fn G, St, Text -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> convert_types(const crate::check::env::G& g, const crate::check::types::St& st, const Text& m) {
    auto&& _m = crate::prelude::get(g.mods, m);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{g, st};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info = prism_rtl::some_of(_m);
        auto s0 = ({
            crate::check::types::St this_ = st;
            this_.file = info->file;
            (std::move(this_));
        });
        return run_to_end(fold_job(prism_rtl::deref(prism_rtl::deref(info).tree).decls, std::tuple{g, s0}, ({
            auto info_1 = info;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=, info_1 = std::move(info_1)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto info_1_2 = info_1;
                entered(once_job([=, info_1_2 = std::move(info_1_2)]() {
                return ({
                    auto [gg, s] = p0;
                    auto d = p1;
                    (prism_rtl::more(prism_rtl::rc(ConvertTypeDecl(gg, s, info_1_2, d))));
                });
            }));
            });
        }));
        })));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvertTypes::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& m = this->m;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g).mods, m);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g, st})
        : prism_rtl::is_some(_m) ? ({
        auto&& info = prism_rtl::some_of(_m);
        ({
        auto s0 = ({
            crate::check::types::St this_ = st;
            this_.file = info->file;
            (std::move(this_));
        });
        fold_job(prism_rtl::deref(prism_rtl::deref(info).tree).decls, std::tuple{g, s0}, ({
        auto info_1 = info;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=, info_1 = std::move(info_1)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_1_2 = info_1;
            entered(once_job([=, info_1_2 = std::move(info_1_2)]() {
            return ({
                auto [gg, s] = p0;
                auto d = p1;
                (prism_rtl::more(prism_rtl::rc(ConvertTypeDecl(gg, s, info_1_2, d))));
            });
        }));
        });
    }));
    }))->cycle();
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ConvertTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_convert_types(crate::check::env::G g, crate::check::types::St st, Text m) {
    return prism_rtl::make_rc<ConvertTypes>(g, st, m);
}


/// ConvertDecls: unbounded fn G, St, Text -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> convert_decls(const crate::check::env::G& g, const crate::check::types::St& st, const Text& m) {
    auto&& _m = crate::prelude::get(g.mods, m);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{g, st};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info = prism_rtl::some_of(_m);
        auto s1 = ({
            crate::check::types::St this_ = st;
            this_.file = info->file;
            (std::move(this_));
        });
        auto [g2, s2] = run_to_end(fold_job(prism_rtl::deref(prism_rtl::deref(info).tree).decls, std::tuple{g, s1}, ({
            auto info_1 = info;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=, info_1 = std::move(info_1)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto info_1_2 = info_1;
                entered(once_job([=, info_1_2 = std::move(info_1_2)]() {
                return ({
                    auto [gg, s] = p0;
                    auto d = p1;
                    (prism_rtl::more(prism_rtl::rc(ConvertDecl(gg, s, info_1_2, d))));
                });
            }));
            });
        }));
        })));
        auto s3 = missing_signatures(g2, s2, info);
        return std::tuple{g2, s3};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvertDecls::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& m = this->m;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g).mods, m);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g, st})
        : prism_rtl::is_some(_m) ? ({
        auto&& info = prism_rtl::some_of(_m);
        ({
        auto s1 = ({
            crate::check::types::St this_ = st;
            this_.file = info->file;
            (std::move(this_));
        });
        auto g_1 = g;
        call_value(fold_job(prism_rtl::deref(prism_rtl::deref(info).tree).decls, std::tuple{g_1, s1}, ({
        auto info_2 = info;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=, info_2 = std::move(info_2)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::syntax::decls::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_2_3 = info_2;
            entered(once_job([=, info_2_3 = std::move(info_2_3)]() {
            return ({
                auto [gg, s] = p0;
                auto d = p1;
                (prism_rtl::more(prism_rtl::rc(ConvertDecl(gg, s, info_2_3, d))));
            });
        }));
        });
    }));
    })), [=](std::tuple<crate::check::env::G, crate::check::types::St> fold_1281) {
        return ({
            auto [g2, s2] = fold_1281;
            auto s3 = missing_signatures(g2, s2, info);
            (prism_rtl::finished(std::tuple{g2, s3}));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ConvertDecls, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_convert_decls(crate::check::env::G g, crate::check::types::St st, Text m) {
    return prism_rtl::make_rc<ConvertDecls>(g, st, m);
}


/// ConvertTypeDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> convert_type_decl(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::env::ModInfo& info, const crate::syntax::decls::Decl& d) {
    auto&& _m = d.kind;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DType>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DType>(_m).a0;
        auto name = crate::check::env::qual_key(info.name, crate::check::env::dotted(prism_rtl::deref(t).name->path_));
        auto ti = or_(crate::prelude::get(g.types, name), crate::check::env::names::dummy_ty_info());
        auto cx_ = crate::check::env::reading::cx_of(g, info.name);
        auto params = each(prism_rtl::deref(t).params, [&](const crate::syntax::Ident& p_) { return prism_rtl::deref(p_).name; });
        auto self_ = crate::check::types::Ty(crate::check::types::Ty::TyCon{name, each(params, [&](const Text& p_) { return crate::check::types::Ty(crate::check::types::Ty::TyQ{p_}); })});
        auto&& _m = prism_rtl::deref(t).body;
        if (prism_rtl::is_none(_m)) {
            return std::tuple{g, st};
        }
        if (prism_rtl::is_some(_m)) {
            auto&& body = prism_rtl::some_of(_m);
            if (prism_rtl::is<crate::syntax::decls::TypeBody::TbRecord>(body)) {
                auto&& fs = prism_rtl::as<crate::syntax::decls::TypeBody::TbRecord>(body).a0;
                auto [fields, st2] = run_to_end(fold_job(fs, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st}, ({
                    auto cx__1 = cx_;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field>)>>(prism_rtl::rc([=, cx__1 = std::move(cx__1)](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto cx__1_2 = cx__1;
                        entered(once_job([=, cx__1_2 = std::move(cx__1_2)]() {
                        return ({
                            auto [acc, s] = p0;
                            auto f = p1;
                            call_then(crate::check::env::reading::start_conv_type(cx__1_2, s, prism_rtl::deref(f).ty), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_2032) {
                            return ({
                                auto [ft, s2] = conv_type_2032;
                                (prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{prism_rtl::deref(prism_rtl::deref(f).name).name, ft}), s2}));
                            });
                        });
                        });
                    }));
                    });
                }));
                })));
                auto ctor = crate::check::env::CtorInfo{.name = name, .owner = name, .params = params, .args = each(fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                    auto&& ft = std::get<1>(_p0);
                    return ft;
                }), .fields = each(fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                    auto&& fname = std::get<0>(_p0);
                    return fname;
                }), .ty = self_, .index = Nat(0u)};
                auto upd = ({
                    crate::check::env::G this_ = g;
                    this_.types = insert(this_.types, name, with_body(ti, crate::check::env::TyBody(crate::check::env::TyBody::BRecord{fields})));
                    this_.ctors = insert(this_.ctors, name, ctor);
                    (std::move(this_));
                });
                return std::tuple{upd, st2};
            }
            if (prism_rtl::is<crate::syntax::decls::TypeBody::TbChoice>(body)) {
                auto&& cs = prism_rtl::as<crate::syntax::decls::TypeBody::TbChoice>(body).a0;
                return conv_cases(g, st, cx_, ti, name, params, self_, cs);
            }
            if (prism_rtl::is<crate::syntax::decls::TypeBody::TbNewtype>(body)) {
                auto&& c = prism_rtl::as<crate::syntax::decls::TypeBody::TbNewtype>(body).a0;
                return conv_cases(g, st, cx_, ti, name, params, self_, Array(std::vector{c}));
            }
            if (prism_rtl::is<crate::syntax::decls::TypeBody::TbUnit>(body)) {
                auto&& i = prism_rtl::as<crate::syntax::decls::TypeBody::TbUnit>(body).a0;
                auto ctor = crate::check::env::CtorInfo{.name = crate::check::env::qual_key(info.name, prism_rtl::deref(i).name), .owner = name, .params = params, .args = Array<crate::check::types::Ty>{}, .fields = Array<Text>{}, .ty = self_, .index = Nat(0u)};
                auto upd = ({
                    crate::check::env::G this_ = g;
                    this_.types = insert(this_.types, name, with_body(ti, crate::check::env::TyBody(crate::check::env::TyBody::BChoice{Array(std::vector{std::tuple{prism_rtl::deref(i).name, Array<crate::check::types::Ty>{}}})})));
                    this_.ctors = insert(this_.ctors, crate::check::env::qual_key(info.name, prism_rtl::deref(i).name), ctor);
                    (std::move(this_));
                });
                return std::tuple{upd, st};
            }
            if (prism_rtl::is<crate::syntax::decls::TypeBody::TbRow>(body)) {
                auto upd = ({
                    crate::check::env::G this_ = g;
                    this_.types = insert(this_.types, name, with_body(ti, crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{})));
                    (std::move(this_));
                });
                return std::tuple{upd, st};
            }
            if (prism_rtl::is<crate::syntax::decls::TypeBody::TbAlias>(body)) {
                auto&& a = prism_rtl::as<crate::syntax::decls::TypeBody::TbAlias>(body).a0;
                auto [at_, st2] = crate::check::env::reading::conv_type(cx_, st, a);
                auto upd = ({
                    crate::check::env::G this_ = g;
                    this_.types = insert(this_.types, name, with_body(ti, crate::check::env::TyBody(crate::check::env::TyBody::BAlias{at_})));
                    (std::move(this_));
                });
                return std::tuple{upd, st2};
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return std::tuple{g, st};
    }
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvertTypeDecl::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& info = this->info;
    const auto& d = this->d;
    return ({
        auto&& _m = prism_rtl::deref(d).kind;
        prism_rtl::is<crate::syntax::decls::DeclKind::DType>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DType>(_m).a0;
        ({
        auto name = crate::check::env::qual_key(prism_rtl::deref(info).name, crate::check::env::dotted(prism_rtl::deref(t).name->path_));
        auto ti = or_(crate::prelude::get(prism_rtl::deref(g).types, name), crate::check::env::names::dummy_ty_info());
        auto cx_ = crate::check::env::reading::cx_of(g, prism_rtl::deref(info).name);
        auto params = each(prism_rtl::deref(t).params, [&](const crate::syntax::Ident& p_) { return prism_rtl::deref(p_).name; });
        auto self_ = crate::check::types::Ty(crate::check::types::Ty::TyCon{name, each(params, [&](const Text& p_) { return crate::check::types::Ty(crate::check::types::Ty::TyQ{p_}); })});
        ({
        auto&& _m = prism_rtl::deref(t).body;
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g, st})
        : prism_rtl::is_some(_m) ? ({
        auto&& body = prism_rtl::some_of(_m);
        ({
        prism_rtl::is<crate::syntax::decls::TypeBody::TbRecord>(body) ? ({
        auto&& fs = prism_rtl::as<crate::syntax::decls::TypeBody::TbRecord>(body).a0;
        ({
        auto fs_1 = fs;
        auto g_2 = g;
        auto st_3 = st;
        call_value(fold_job(fs_1, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st_3}, ({
        auto cx__4 = cx_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field>)>>(prism_rtl::rc([=, cx__4 = std::move(cx__4)](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__4_5 = cx__4;
            entered(once_job([=, cx__4_5 = std::move(cx__4_5)]() {
            return ({
                auto [acc, s] = p0;
                auto f = p1;
                call_then(crate::check::env::reading::start_conv_type(cx__4_5, s, prism_rtl::deref(f).ty), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_2032) {
                return ({
                    auto [ft, s2] = conv_type_2032;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{prism_rtl::deref(prism_rtl::deref(f).name).name, ft}), s2}));
                });
            });
            });
        }));
        });
    }));
    })), [=, g_2 = std::move(g_2)](std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St> fold_1951) {
        return ({
            auto [fields, st2] = fold_1951;
            auto ctor = crate::check::env::CtorInfo{.name = name, .owner = name, .params = params, .args = each(fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                auto&& ft = std::get<1>(_p0);
                return ft;
            }), .fields = each(fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                auto&& fname = std::get<0>(_p0);
                return fname;
            }), .ty = self_, .index = Nat(0u)};
            auto upd = ({
                crate::check::env::G this_ = g_2;
                this_.types = insert(this_.types, name, with_body(ti, crate::check::env::TyBody(crate::check::env::TyBody::BRecord{fields})));
                this_.ctors = insert(this_.ctors, name, ctor);
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{upd, st2}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::decls::TypeBody::TbChoice>(body) ? ({
        auto&& cs = prism_rtl::as<crate::syntax::decls::TypeBody::TbChoice>(body).a0;
        prism_rtl::more(prism_rtl::rc(ConvCases(g, st, cx_, ti, name, params, self_, cs)));
    })
        : prism_rtl::is<crate::syntax::decls::TypeBody::TbNewtype>(body) ? ({
        auto&& c = prism_rtl::as<crate::syntax::decls::TypeBody::TbNewtype>(body).a0;
        prism_rtl::more(prism_rtl::rc(ConvCases(g, st, cx_, ti, name, params, self_, Array(std::vector{c}))));
    })
        : prism_rtl::is<crate::syntax::decls::TypeBody::TbUnit>(body) ? ({
        auto&& i = prism_rtl::as<crate::syntax::decls::TypeBody::TbUnit>(body).a0;
        ({
        auto ctor = crate::check::env::CtorInfo{.name = crate::check::env::qual_key(prism_rtl::deref(info).name, prism_rtl::deref(i).name), .owner = name, .params = params, .args = Array<crate::check::types::Ty>{}, .fields = Array<Text>{}, .ty = self_, .index = Nat(0u)};
        auto upd = ({
            crate::check::env::G this_ = g;
            this_.types = insert(this_.types, name, with_body(ti, crate::check::env::TyBody(crate::check::env::TyBody::BChoice{Array(std::vector{std::tuple{prism_rtl::deref(i).name, Array<crate::check::types::Ty>{}}})})));
            this_.ctors = insert(this_.ctors, crate::check::env::qual_key(prism_rtl::deref(info).name, prism_rtl::deref(i).name), ctor);
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{upd, st}));
    });
    })
        : prism_rtl::is<crate::syntax::decls::TypeBody::TbRow>(body) ? ({
        auto upd = ({
            crate::check::env::G this_ = g;
            this_.types = insert(this_.types, name, with_body(ti, crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{})));
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{upd, st}));
    })
        : prism_rtl::is<crate::syntax::decls::TypeBody::TbAlias>(body) ? ({
        auto&& a = prism_rtl::as<crate::syntax::decls::TypeBody::TbAlias>(body).a0;
        ({
        auto a_1 = a;
        auto g_2 = g;
        auto st_3 = st;
        call_then(crate::check::env::reading::start_conv_type(cx_, st_3, a_1), [=, g_2 = std::move(g_2)](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_3366) {
        return ({
            auto [at_, st2] = conv_type_3366;
            auto upd = ({
                crate::check::env::G this_ = g_2;
                this_.types = insert(this_.types, name, with_body(ti, crate::check::env::TyBody(crate::check::env::TyBody::BAlias{at_})));
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{upd, st2}));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::finished(std::tuple{g, st});
    });
}


/// `Start ConvertTypeDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_convert_type_decl(crate::check::env::G g, crate::check::types::St st, crate::check::env::ModInfo info, crate::syntax::decls::Decl d) {
    return prism_rtl::make_rc<ConvertTypeDecl>(g, st, info, d);
}


/// WithBody: fn TyInfo, TyBody -> TyInfo
crate::check::env::TyInfo with_body(const crate::check::env::TyInfo& ti, const crate::check::env::TyBody& b) {
    crate::check::env::TyInfo this_ = ti;
    this_.body = b;
    return this_;
}


/// ConvCases: unbounded fn G, St, Cx, TyInfo, Text, [Text], Ty, [Case] -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> conv_cases(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::env::reading::Cx_& cx_, const crate::check::env::TyInfo& ti, const Text& name, const Array<Text>& params, const crate::check::types::Ty& self_, const Array<crate::syntax::decls::Case_>& cs) {
    auto [cases, st2] = run_to_end(fold_job(cs, std::tuple{Array<std::tuple<Text, Array<crate::check::types::Ty>>>{}, st}, ({
        auto cx__1 = cx_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>, crate::syntax::decls::Case_>)>>(prism_rtl::rc([=, cx__1 = std::move(cx__1)](std::tuple<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>, crate::syntax::decls::Case_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=, cx__1_2 = std::move(cx__1_2)]() {
            return ({
                auto [acc, s] = p0;
                auto c = p1;
                ({
                auto s1 = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    auto&& _m = prism_rtl::deref(c).indexed;
                    if (prism_rtl::is_some(_m)) {
                        _v.set(crate::check::types::recording::err(s, Text::lit("unsupported"), prism_rtl::deref(c).span, Text::lit("this checker does not implement indexed choices for user types")));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(crate::check::env::reading::start_conv_types(cx__1_2, s1, c->args), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_4053) {
                return ({
                    auto [args, s2] = conv_types_4053;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{crate::check::env::sname_key(prism_rtl::deref(c).name), args}), s2}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto g2 = fold(crate::check::errors::range0(len(cases)), g, [&](const crate::check::env::G& gg, const Nat& i) {
        return ({
            auto [cn, args] = or_(index(cases, i), std::tuple{Text::lit(""), Array<crate::check::types::Ty>{}});
            auto qk = crate::check::env::qual_key(ti.home, cn);
            ({
            crate::check::env::G this_ = gg;
            this_.ctors = insert(this_.ctors, qk, crate::check::env::CtorInfo{.name = qk, .owner = name, .params = params, .args = args, .fields = Array<Text>{}, .ty = self_, .index = i});
            (std::move(this_));
        });
        });
    });
    auto upd = ({
        crate::check::env::G this_ = g2;
        this_.types = insert(this_.types, name, with_body(ti, crate::check::env::TyBody(crate::check::env::TyBody::BChoice{cases})));
        (std::move(this_));
    });
    return std::tuple{upd, st2};
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvCases::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& cx_ = this->cx_;
    const auto& ti = this->ti;
    const auto& name = this->name;
    const auto& params = this->params;
    const auto& self_ = this->self_;
    const auto& cs = this->cs;
    auto cs_1 = cs;
    auto cx__2 = cx_;
    auto g_3 = g;
    auto name_4 = name;
    auto params_5 = params;
    auto self__6 = self_;
    auto st_7 = st;
    auto ti_8 = ti;
    return call_value(fold_job(cs_1, std::tuple{Array<std::tuple<Text, Array<crate::check::types::Ty>>>{}, st_7}, ({
        auto cx__2_9 = cx__2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>, crate::syntax::decls::Case_>)>>(prism_rtl::rc([=, cx__2_9 = std::move(cx__2_9)](std::tuple<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>, crate::syntax::decls::Case_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__2_9_9 = cx__2_9;
            entered(once_job([=, cx__2_9_9 = std::move(cx__2_9_9)]() {
            return ({
                auto [acc, s] = p0;
                auto c = p1;
                ({
                auto s1 = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    auto&& _m = prism_rtl::deref(c).indexed;
                    if (prism_rtl::is_some(_m)) {
                        _v.set(crate::check::types::recording::err(s, Text::lit("unsupported"), prism_rtl::deref(c).span, Text::lit("this checker does not implement indexed choices for user types")));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(crate::check::env::reading::start_conv_types(cx__2_9_9, s1, c->args), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_4053) {
                return ({
                    auto [args, s2] = conv_types_4053;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{crate::check::env::sname_key(prism_rtl::deref(c).name), args}), s2}));
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St> fold_3815) {
        return ({
            auto [cases, st2] = fold_3815;
            auto g2 = fold(crate::check::errors::range0(len(cases)), g_3, [&](const crate::check::env::G& gg, const Nat& i) {
                return ({
                    auto [cn, args] = or_(index(cases, i), std::tuple{Text::lit(""), Array<crate::check::types::Ty>{}});
                    auto qk = crate::check::env::qual_key(prism_rtl::deref(ti_8).home, cn);
                    ({
                    crate::check::env::G this_ = gg;
                    this_.ctors = insert(this_.ctors, qk, crate::check::env::CtorInfo{.name = qk, .owner = name_4, .params = params_5, .args = args, .fields = Array<Text>{}, .ty = self__6, .index = i});
                    (std::move(this_));
                });
                });
            });
            auto upd = ({
                crate::check::env::G this_ = g2;
                this_.types = insert(this_.types, name_4, with_body(ti_8, crate::check::env::TyBody(crate::check::env::TyBody::BChoice{cases})));
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{upd, st2}));
        });
    });
}


/// `Start ConvCases, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_conv_cases(crate::check::env::G g, crate::check::types::St st, crate::check::env::reading::Cx_ cx_, crate::check::env::TyInfo ti, Text name, Array<Text> params, crate::check::types::Ty self_, Array<crate::syntax::decls::Case_> cs) {
    return prism_rtl::make_rc<ConvCases>(g, st, cx_, ti, name, params, self_, cs);
}


/// ConvertDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> convert_decl(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::env::ModInfo& info, const crate::syntax::decls::Decl& d) {
    auto&& _m = d.kind;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DSignature>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::decls::DeclKind::DSignature>(_m).a0;
        auto qk = crate::check::env::qual_key(info.name, crate::check::env::def_name_text(prism_rtl::deref(s).name));
        auto cx_ = crate::check::env::reading::cx_of(g, info.name);
        auto [sc, st1] = crate::check::env::reading::sig_scheme(cx_, st, prism_rtl::deref(s).ty, prism_rtl::deref(s).bounds);
        auto st2 = lens_check(st1, crate::check::env::def_name_text(prism_rtl::deref(s).name), prism_rtl::deref(s).ty, crate::check::env::def_name_span(prism_rtl::deref(s).name));
        auto st3 = check_mark_function(st2, crate::check::env::def_name_text(prism_rtl::deref(s).name), prism_rtl::deref(sc).ty, crate::check::env::def_name_span(prism_rtl::deref(s).name));
        return crate::check::env::has_key(g.vals, qk)
            ? std::tuple{g, crate::check::types::recording::err(st3, Text::lit("collision"), d.span, prism_rtl::cat("a second signature for `", crate::check::env::def_name_text(prism_rtl::deref(s).name), "`"))}
            : ({
            auto upd = ({
                crate::check::env::G this_ = g;
                this_.vals = insert(this_.vals, qk, crate::check::env::ValInfo{.qk = qk, .scheme = sc, .sort = Text::lit("fn"), .has_sig = true, .home = info.name, .file = info.file, .span = d.span});
                (std::move(this_));
            });
            std::tuple{upd, st3};
        });
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DFn>(_m)) {
        auto&& f = prism_rtl::as<crate::syntax::decls::DeclKind::DFn>(_m).a0;
        auto qk = crate::check::env::qual_key(info.name, crate::check::env::def_name_text(prism_rtl::deref(f).name));
        return std::tuple{add_clause(g, info, qk, crate::check::env::def_name_text(prism_rtl::deref(f).name), f, d.span, st), st};
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DLet>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::decls::DeclKind::DLet>(_m).a0;
        auto names_1 = crate::check::env::names::pattern_names(prism_rtl::deref(l).pattern);
        auto qk = crate::check::env::qual_key(info.name, or_(index(names_1, Nat(0u)), Text::lit("")));
        auto def = crate::check::env::Def{.qk = qk, .name = or_(index(names_1, Nat(0u)), Text::lit("")), .home = info.name, .file = info.file, .span = d.span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbLet{l})};
        auto upd = ({
            crate::check::env::G this_ = g;
            this_.defs = crate::prelude::push(this_.defs, def);
            (std::move(this_));
        });
        return std::tuple{upd, st};
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DWidget>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::decls::DeclKind::DWidget>(_m).a0;
        auto qk = crate::check::env::qual_key(info.name, crate::check::env::sname_key(prism_rtl::deref(w).name));
        auto def = crate::check::env::Def{.qk = qk, .name = crate::check::env::sname_key(prism_rtl::deref(w).name), .home = info.name, .file = info.file, .span = d.span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbWidget{w})};
        auto upd = ({
            crate::check::env::G this_ = g;
            this_.defs = crate::prelude::push(this_.defs, def);
            (std::move(this_));
        });
        return std::tuple{upd, st};
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTag>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DTag>(_m).a0;
        return conv_tag(g, st, info, t, d.span);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        return conv_trait(g, st, info, t, d.span);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DImpl>(_m)) {
        auto&& i = prism_rtl::as<crate::syntax::decls::DeclKind::DImpl>(_m).a0;
        return conv_impl(g, st, info, i, d.span);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DCheck>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::decls::DeclKind::DCheck>(_m).a0;
        auto upd = ({
            crate::check::env::G this_ = g;
            this_.defs = crate::prelude::push(this_.defs, crate::check::env::Def{.qk = crate::check::env::qual_key(info.name, prism_rtl::cat("check ", prism_rtl::deref(prism_rtl::deref(c).name).name)), .name = prism_rtl::deref(prism_rtl::deref(c).name).name, .home = info.name, .file = info.file, .span = d.span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbCheck{c})});
            (std::move(this_));
        });
        return std::tuple{upd, st};
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTest>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DTest>(_m).a0;
        auto upd = ({
            crate::check::env::G this_ = g;
            this_.defs = crate::prelude::push(this_.defs, crate::check::env::Def{.qk = crate::check::env::qual_key(info.name, prism_rtl::cat("test ", prism_rtl::deref(prism_rtl::deref(t).name).name)), .name = prism_rtl::deref(prism_rtl::deref(t).name).name, .home = info.name, .file = info.file, .span = d.span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbTest{t})});
            (std::move(this_));
        });
        return std::tuple{upd, st};
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DStmt>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::decls::DeclKind::DStmt>(_m).a0;
        auto&& _m = prism_rtl::deref(s).kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m)) {
            return std::tuple{g, st};
        }
        {
            return std::tuple{g, crate::check::types::recording::err(st, Text::lit("unsupported"), d.span, Text::lit("a statement at the top of a file: nothing at top level is built"))};
        }
    }
    {
        return std::tuple{g, st};
    }
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvertDecl::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& info = this->info;
    const auto& d = this->d;
    return ({
        auto&& _m = prism_rtl::deref(d).kind;
        prism_rtl::is<crate::syntax::decls::DeclKind::DSignature>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::decls::DeclKind::DSignature>(_m).a0;
        ({
        auto qk = crate::check::env::qual_key(prism_rtl::deref(info).name, crate::check::env::def_name_text(prism_rtl::deref(s).name));
        auto cx_ = crate::check::env::reading::cx_of(g, prism_rtl::deref(info).name);
        auto d_1 = d;
        auto g_2 = g;
        auto info_3 = info;
        auto s_4 = s;
        auto st_5 = st;
        call_then(crate::check::env::reading::start_sig_scheme(cx_, st_5, prism_rtl::deref(s_4).ty, prism_rtl::deref(s_4).bounds), [=, qk = std::move(qk), d_1 = std::move(d_1), g_2 = std::move(g_2), info_3 = std::move(info_3)](std::tuple<crate::check::types::Scheme, crate::check::types::St> sig_scheme_4784) {
        return ({
            auto [sc, st1] = sig_scheme_4784;
            auto st2 = lens_check(st1, crate::check::env::def_name_text(prism_rtl::deref(s_4).name), prism_rtl::deref(s_4).ty, crate::check::env::def_name_span(prism_rtl::deref(s_4).name));
            call_then(start_check_mark_function(st2, crate::check::env::def_name_text(prism_rtl::deref(s_4).name), prism_rtl::deref(sc).ty, crate::check::env::def_name_span(prism_rtl::deref(s_4).name)), [=](crate::check::types::St check_mark_function_4917) {
            return ({
                auto st3 = check_mark_function_4917;
                (crate::check::env::has_key(prism_rtl::deref(g_2).vals, qk)
                ? prism_rtl::finished(std::tuple{g_2, crate::check::types::recording::err(st3, Text::lit("collision"), prism_rtl::deref(d_1).span, prism_rtl::cat("a second signature for `", crate::check::env::def_name_text(prism_rtl::deref(s_4).name), "`"))})
                : ({
                auto upd = ({
                    crate::check::env::G this_ = g_2;
                    this_.vals = insert(this_.vals, qk, crate::check::env::ValInfo{.qk = qk, .scheme = sc, .sort = Text::lit("fn"), .has_sig = true, .home = prism_rtl::deref(info_3).name, .file = info_3->file, .span = prism_rtl::deref(d_1).span});
                    (std::move(this_));
                });
                (prism_rtl::finished(std::tuple{upd, st3}));
            }));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DFn>(_m) ? ({
        auto&& f = prism_rtl::as<crate::syntax::decls::DeclKind::DFn>(_m).a0;
        ({
        auto qk = crate::check::env::qual_key(prism_rtl::deref(info).name, crate::check::env::def_name_text(prism_rtl::deref(f).name));
        (prism_rtl::finished(std::tuple{add_clause(g, info, qk, crate::check::env::def_name_text(prism_rtl::deref(f).name), f, prism_rtl::deref(d).span, st), st}));
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DLet>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::decls::DeclKind::DLet>(_m).a0;
        ({
        auto d_1 = d;
        auto g_2 = g;
        auto info_3 = info;
        auto l_4 = l;
        auto st_5 = st;
        call_then(crate::check::env::names::start_pattern_names(prism_rtl::deref(l_4).pattern), [=, d_1 = std::move(d_1), g_2 = std::move(g_2), info_3 = std::move(info_3), st_5 = std::move(st_5)](Array<Text> pattern_names_5497) {
        return ({
            auto names = pattern_names_5497;
            auto qk = crate::check::env::qual_key(prism_rtl::deref(info_3).name, or_(index(names, Nat(0u)), Text::lit("")));
            auto def = crate::check::env::Def{.qk = qk, .name = or_(index(names, Nat(0u)), Text::lit("")), .home = prism_rtl::deref(info_3).name, .file = info_3->file, .span = prism_rtl::deref(d_1).span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbLet{l_4})};
            auto upd = ({
                crate::check::env::G this_ = g_2;
                this_.defs = crate::prelude::push(this_.defs, def);
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{upd, st_5}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DWidget>(_m) ? ({
        auto&& w = prism_rtl::as<crate::syntax::decls::DeclKind::DWidget>(_m).a0;
        ({
        auto qk = crate::check::env::qual_key(prism_rtl::deref(info).name, crate::check::env::sname_key(prism_rtl::deref(w).name));
        auto def = crate::check::env::Def{.qk = qk, .name = crate::check::env::sname_key(prism_rtl::deref(w).name), .home = prism_rtl::deref(info).name, .file = info->file, .span = prism_rtl::deref(d).span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbWidget{w})};
        auto upd = ({
            crate::check::env::G this_ = g;
            this_.defs = crate::prelude::push(this_.defs, def);
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{upd, st}));
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTag>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DTag>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvTag(g, st, info, t, prism_rtl::deref(d).span)));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvTrait(g, st, info, t, prism_rtl::deref(d).span)));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DImpl>(_m) ? ({
        auto&& i = prism_rtl::as<crate::syntax::decls::DeclKind::DImpl>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvImpl(g, st, info, i, prism_rtl::deref(d).span)));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DCheck>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::decls::DeclKind::DCheck>(_m).a0;
        ({
        auto upd = ({
            crate::check::env::G this_ = g;
            this_.defs = crate::prelude::push(this_.defs, crate::check::env::Def{.qk = crate::check::env::qual_key(prism_rtl::deref(info).name, prism_rtl::cat("check ", prism_rtl::deref(prism_rtl::deref(c).name).name)), .name = prism_rtl::deref(prism_rtl::deref(c).name).name, .home = prism_rtl::deref(info).name, .file = info->file, .span = prism_rtl::deref(d).span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbCheck{c})});
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{upd, st}));
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTest>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DTest>(_m).a0;
        ({
        auto upd = ({
            crate::check::env::G this_ = g;
            this_.defs = crate::prelude::push(this_.defs, crate::check::env::Def{.qk = crate::check::env::qual_key(prism_rtl::deref(info).name, prism_rtl::cat("test ", prism_rtl::deref(prism_rtl::deref(t).name).name)), .name = prism_rtl::deref(prism_rtl::deref(t).name).name, .home = prism_rtl::deref(info).name, .file = info->file, .span = prism_rtl::deref(d).span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbTest{t})});
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{upd, st}));
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DStmt>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::decls::DeclKind::DStmt>(_m).a0;
        ({
        auto&& _m = prism_rtl::deref(s).kind;
        prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m) ? prism_rtl::finished(std::tuple{g, st})
        : prism_rtl::finished(std::tuple{g, crate::check::types::recording::err(st, Text::lit("unsupported"), prism_rtl::deref(d).span, Text::lit("a statement at the top of a file: nothing at top level is built"))});
    });
    })
        : prism_rtl::finished(std::tuple{g, st});
    });
}


/// `Start ConvertDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_convert_decl(crate::check::env::G g, crate::check::types::St st, crate::check::env::ModInfo info, crate::syntax::decls::Decl d) {
    return prism_rtl::make_rc<ConvertDecl>(g, st, info, d);
}


/// AddClause: fn G, ModInfo, Text, Text, FnClause, Range, St -> G
crate::check::env::G add_clause(const crate::check::env::G& g, const crate::check::env::ModInfo& info, const Text& qk, const Text& name, const crate::syntax::decls::FnClause& f, const crate::syntax::Range& span, const crate::check::types::St& st) {
    auto&& _m = crate::prelude::get(g.fn_at, qk);
    if (prism_rtl::is_some(_m)) {
        auto&& i = prism_rtl::some_of(_m);
        crate::check::env::G this_ = g;
        this_.defs = insert2(this_.defs, i, add_to_fn(or_(index(this_.defs, i), dummy_def()), f));
        return this_;
    }
    if (prism_rtl::is_none(_m)) {
        crate::check::env::G this_ = g;
        this_.fn_at = insert(this_.fn_at, qk, len(this_.defs));
        this_.defs = crate::prelude::push(this_.defs, crate::check::env::Def{.qk = qk, .name = name, .home = info.name, .file = info.file, .span = span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbFn{Array(std::vector{f})})});
        return this_;
    }
    prism_rtl::unreachable("no arm matched");
}


/// let dummyDef
crate::check::env::Def dummy_def() {
    return crate::check::env::Def{.qk = Text::lit(""), .name = Text::lit(""), .home = Text::lit(""), .file = Nat(0u), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbFn{Array<crate::syntax::decls::FnClause>{}})};
}


/// IsFnDef: fn Def -> Bool
bool is_fn_def(const crate::check::env::Def& d) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// AddToFn: fn Def, FnClause -> Def
crate::check::env::Def add_to_fn(const crate::check::env::Def& d, const crate::syntax::decls::FnClause& f) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
        auto&& fs = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
        crate::check::env::Def this_ = d;
        this_.body = crate::check::env::DefBody(crate::check::env::DefBody::DbFn{crate::prelude::push(fs, f)});
        return this_;
    }
    {
        return d;
    }
}


/// LensCheck: fn St, Text, Type, Range -> St
crate::check::types::St lens_check(const crate::check::types::St& st, const Text& name, const crate::syntax::Type& t, const crate::syntax::Range& span) {
    return !crate::syntax::lexer::chars::has_prefix(name, Text::lit("&"))
        ? st
        : ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = prism_rtl::deref(t.kind);
        if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
            auto&& ps = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
            _v.set(({
                auto refs = filter(ps, [&](const crate::syntax::Type& p_) { return is_ref_type(p_); });
                len(refs) > Nat(1u)
                ? crate::check::types::recording::err_fix(st, Text::lit("lens-arity"), span, Text::lit("a lens takes one reference"), Text::lit("take the second part as a plain value"))
                : crate::check::types::recording::err(st, Text::lit("unsupported"), span, Text::lit("this checker does not implement named lenses and `Over`"));
            }));
            goto _done;
        }
        {
            _v.set(st);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// IsRefType: fn Type -> Bool
bool is_ref_type(const crate::syntax::Type& t) {
    auto&& _m = prism_rtl::deref(t.kind);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n).sigils, Text::lit("&"));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix(s, Text::lit("&"));
    }
    {
        return false;
    }
}


/// CheckMarkFunction: unbounded fn St, Text, Ty, Range -> St
crate::check::types::St check_mark_function(const crate::check::types::St& st, const Text& name, const crate::check::types::Ty& t, const crate::syntax::Range& span) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        auto want = crate::check::types::head_sigil(st, prism_rtl::deref(prism_rtl::deref(res)));
        auto marks = crate::check::types::unify::marks_of(name);
        auto shown = crate::syntax::lexer::chars::head(marks);
        auto bare = crate::syntax::lexer::chars::drop_prefix(name, marks);
        return (((shown == want) || (len_text(marks) > Nat(1u))) || (bare == Text::lit(""))) || (!crate::check::env::is_upper_text(bare))
            ? st
            : crate::check::types::recording::err_fix(st, Text::lit("mark-function"), span, prism_rtl::cat("`", name, "` returns `", crate::check::types::show_ty(st, prism_rtl::deref(prism_rtl::deref(res))), "`; name it `", want, bare, "`"), prism_rtl::cat("rename to `", want, bare, "`"));
    }
    {
        return st;
    }
}


prism_rtl::Turn<crate::check::types::St> CheckMarkFunction::cycle() const {
    const auto& st = this->st;
    const auto& name = this->name;
    const auto& t = this->t;
    const auto& span = this->span;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? ({
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        ({
        auto name_1 = name;
        auto res_2 = prism_rtl::deref(prism_rtl::deref(res));
        auto span_3 = span;
        auto st_4 = st;
        call_then(crate::check::types::start_head_sigil(st_4, res_2), [=, name_1 = std::move(name_1), span_3 = std::move(span_3)](Text head_sigil_8937) {
        return ({
            auto want = head_sigil_8937;
            auto marks = crate::check::types::unify::marks_of(name_1);
            auto shown = crate::syntax::lexer::chars::head(marks);
            auto bare = crate::syntax::lexer::chars::drop_prefix(name_1, marks);
            (((shown == want) || (len_text(marks) > Nat(1u))) || (bare == Text::lit(""))) || (!crate::check::env::is_upper_text(bare))
            ? prism_rtl::finished(st_4)
            : call_then(crate::check::types::start_show_ty(st_4, res_2), [=](Text show_ty_9217) { return prism_rtl::finished(crate::check::types::recording::err_fix(st_4, Text::lit("mark-function"), span_3, prism_rtl::cat("`", name_1, "` returns `", show_ty_9217, "`; name it `", want, bare, "`"), prism_rtl::cat("rename to `", want, bare, "`"))); });
        });
    });
    });
    })
        : prism_rtl::finished(st);
    });
}


/// `Start CheckMarkFunction, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_mark_function(crate::check::types::St st, Text name, crate::check::types::Ty t, crate::syntax::Range span) {
    return prism_rtl::make_rc<CheckMarkFunction>(st, name, t, span);
}


/// MissingSignatures: fn G, St, ModInfo -> St
crate::check::types::St missing_signatures(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::env::ModInfo& info) {
    return fold(g.defs, st, [&](const crate::check::types::St& s, const crate::check::env::Def& d) {
        return ((prism_rtl::deref(d).home == info.name) && is_fn_def(d)) && (!crate::check::env::has_key(g.vals, prism_rtl::deref(d).qk))
            ? crate::check::types::recording::err_fix(s, Text::lit("no-signature"), prism_rtl::deref(d).span, prism_rtl::cat("`", prism_rtl::deref(d).name, "` has no signature line"), prism_rtl::cat("write `", prism_rtl::deref(d).name, ": fn ... -> ...` above it"))
            : s;
    });
}


/// ConvTag: unbounded fn G, St, ModInfo, TagDecl, Range -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> conv_tag(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::env::ModInfo& info, const crate::syntax::decls::TagDecl& t, const crate::syntax::Range& span) {
    auto name = crate::check::env::dotted(t.name->path_);
    auto family = crate::check::env::dotted(take(t.name->path_, crate::syntax::lexer::chars::dec(len(t.name->path_))));
    auto cx_ = crate::check::env::reading::cx_of(g, info.name);
    auto [kind, out, st2] = tag_kind(g, cx_, st, t.of_type);
    auto [fields, st3] = run_to_end(fold_job(t.fields, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st2}, ({
        auto cx__1 = cx_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field>)>>(prism_rtl::rc([=, cx__1 = std::move(cx__1)](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=, cx__1_2 = std::move(cx__1_2)]() {
            return ({
                auto [acc, s] = p0;
                auto f = p1;
                call_then(crate::check::env::reading::start_conv_type(cx__1_2, s, prism_rtl::deref(f).ty), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_10129) {
                return ({
                    auto [ft, s2] = conv_type_10129;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{prism_rtl::deref(prism_rtl::deref(f).name).name, ft}), s2}));
                });
            });
            });
        }));
        });
    }));
    })));
    auto qs = run_to_end(fold_job(t.fields, crate::check::env::reading::type_vars_of_type(t.of_type), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::decls::Field>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::decls::Field> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto f = p1;
                call_then(crate::check::env::reading::start_type_vars_of_type(prism_rtl::deref(f).ty), [=, acc = std::move(acc)](Array<Text> type_vars_of_type_10280) { return prism_rtl::finished(crate::check::types::union_texts(acc, type_vars_of_type_10280)); });
            });
        }));
    }))));
    auto [bs, st4] = crate::check::env::reading::conv_bounds(cx_, st3, t.bounds);
    auto tg = crate::check::env::TagInfo{.name = name, .family = family, .kind = kind, .out = out, .qs = qs, .rqs = info.row_var == Text::lit("")
        ? Array<Text>{}
        : Array(std::vector{info.row_var}), .bounds = bs, .fields = fields, .home = info.name, .file = info.file, .span = span};
    auto upd = ({
        crate::check::env::G this_ = g;
        this_.tags = insert(this_.tags, name, tg);
        (std::move(this_));
    });
    return std::tuple{upd, st4};
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvTag::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& info = this->info;
    const auto& t = this->t;
    const auto& span = this->span;
    auto name = crate::check::env::dotted(prism_rtl::deref(t).name->path_);
    auto family = crate::check::env::dotted(take(prism_rtl::deref(t).name->path_, crate::syntax::lexer::chars::dec(len(prism_rtl::deref(t).name->path_))));
    auto cx_ = crate::check::env::reading::cx_of(g, prism_rtl::deref(info).name);
    auto g_1 = g;
    auto info_2 = info;
    auto span_3 = span;
    auto st_4 = st;
    auto t_5 = t;
    return call_then(start_tag_kind(g_1, cx_, st_4, prism_rtl::deref(t_5).of_type), [=](std::tuple<Text, crate::check::types::Ty, crate::check::types::St> tag_kind_10003) {
        return ({
            auto [kind, out, st2] = tag_kind_10003;
            call_value(fold_job(prism_rtl::deref(t_5).fields, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st2}, ({
            auto cx__6 = cx_;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field>)>>(prism_rtl::rc([=, cx__6 = std::move(cx__6)](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::Field> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx__6_7 = cx__6;
                entered(once_job([=, cx__6_7 = std::move(cx__6_7)]() {
                return ({
                    auto [acc, s] = p0;
                    auto f = p1;
                    call_then(crate::check::env::reading::start_conv_type(cx__6_7, s, prism_rtl::deref(f).ty), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_10129) {
                    return ({
                        auto [ft, s2] = conv_type_10129;
                        (prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{prism_rtl::deref(prism_rtl::deref(f).name).name, ft}), s2}));
                    });
                });
                });
            }));
            });
        }));
        })), [=](std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St> fold_10057) {
            return ({
                auto [fields, st3] = fold_10057;
                call_then(crate::check::env::reading::start_type_vars_of_type(prism_rtl::deref(t_5).of_type), [=](Array<Text> type_vars_of_type_10227) {
                return call_value(fold_job(prism_rtl::deref(t_5).fields, type_vars_of_type_10227, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::decls::Field>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::decls::Field> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto acc = p0;
                            auto f = p1;
                            call_then(crate::check::env::reading::start_type_vars_of_type(prism_rtl::deref(f).ty), [=, acc = std::move(acc)](Array<Text> type_vars_of_type_10280) { return prism_rtl::finished(crate::check::types::union_texts(acc, type_vars_of_type_10280)); });
                        });
                    }));
                }))), [=](Array<Text> fold_10211) {
                    return ({
                        auto qs = fold_10211;
                        auto [bs, st4] = crate::check::env::reading::conv_bounds(cx_, st3, prism_rtl::deref(t_5).bounds);
                        auto tg = crate::check::env::TagInfo{.name = name, .family = family, .kind = kind, .out = out, .qs = qs, .rqs = prism_rtl::deref(info_2).row_var == Text::lit("")
                            ? Array<Text>{}
                            : Array(std::vector{prism_rtl::deref(info_2).row_var}), .bounds = bs, .fields = fields, .home = prism_rtl::deref(info_2).name, .file = info_2->file, .span = span_3};
                        auto upd = ({
                            crate::check::env::G this_ = g_1;
                            this_.tags = insert(this_.tags, name, tg);
                            (std::move(this_));
                        });
                        (prism_rtl::finished(std::tuple{upd, st4}));
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start ConvTag, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_conv_tag(crate::check::env::G g, crate::check::types::St st, crate::check::env::ModInfo info, crate::syntax::decls::TagDecl t, crate::syntax::Range span) {
    return prism_rtl::make_rc<ConvTag>(g, st, info, t, span);
}


/// TagKind: unbounded fn G, Cx, St, Type -> ((Text, Ty, St))
std::tuple<Text, crate::check::types::Ty, crate::check::types::St> tag_kind(const crate::check::env::G& g, const crate::check::env::reading::Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t) {
    auto&& _m = prism_rtl::deref(t.kind);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        auto name = crate::check::env::dotted(n->path_);
        return name == Text::lit("Element")
            ? ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> _v;
            auto&& _m = index(args, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& o = prism_rtl::some_of(_m);
                _v.set(({
                    auto [ot, s2] = crate::check::env::reading::conv_type(cx_, st, o);
                    std::tuple{Text::lit("Element"), ot, s2};
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::tuple{Text::lit("Element"), crate::check::types::t_unit(), st});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        })
            : ({
            auto&& _key_opt = crate::check::env::names::resolve_type(g, cx_.home, n->path_);
            auto&& key_opt = std::get<0>(_key_opt);
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> _v;
            if (prism_rtl::is_some(key_opt)) {
                auto&& k = prism_rtl::some_of(key_opt);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> _v;
                    auto&& _m = prism_rtl::deref(or_(crate::prelude::get(g.types, k), crate::check::env::names::dummy_ty_info())).body;
                    if (prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m)) {
                        _v.set(std::tuple{k, crate::check::types::t_unit(), st});
                        goto _done;
                    }
                    {
                        _v.set(std::tuple{k, crate::check::types::t_unit(), crate::check::types::recording::err(st, Text::lit("kind"), t.span, prism_rtl::cat("`", name, "` is not a row kind: a tag joins `Element o`, `Fault` or another `type K = row`"))});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(key_opt)) {
                _v.set(std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unknown-name"), t.span, prism_rtl::cat("no row kind `", name, "`"))});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return tag_kind(g, cx_, st, prism_rtl::deref(prism_rtl::deref(x)));
    }
    {
        return std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("kind"), t.span, Text::lit("a tag joins a row kind"))};
    }
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> TagKind::cycle() const {
    const auto& g = this->g;
    const auto& cx_ = this->cx_;
    const auto& st = this->st;
    const auto& t = this->t;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t).kind);
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        ({
        auto name = crate::check::env::dotted(n->path_);
        name == Text::lit("Element")
        ? ({
        auto&& _m = index(args, Nat(0u));
        prism_rtl::is_some(_m) ? ({
        auto&& o = prism_rtl::some_of(_m);
        ({
        auto cx__1 = cx_;
        auto st_2 = st;
        call_then(crate::check::env::reading::start_conv_type(cx__1, st_2, o), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_10990) {
        return ({
            auto [ot, s2] = conv_type_10990;
            (prism_rtl::finished(std::tuple{Text::lit("Element"), ot, s2}));
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{Text::lit("Element"), crate::check::types::t_unit(), st})
        : throw prism_rtl::Panic("no arm matched");
    })
        : ({
        auto&& _key_opt = crate::check::env::names::resolve_type(g, prism_rtl::deref(cx_).home, n->path_);
        auto&& key_opt = std::get<0>(_key_opt);
        ({
        prism_rtl::is_some(key_opt) ? ({
        auto&& k = prism_rtl::some_of(key_opt);
        ({
        auto&& _m = prism_rtl::deref(or_(crate::prelude::get(prism_rtl::deref(g).types, k), crate::check::env::names::dummy_ty_info())).body;
        prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m) ? prism_rtl::finished(std::tuple{k, crate::check::types::t_unit(), st})
        : prism_rtl::finished(std::tuple{k, crate::check::types::t_unit(), crate::check::types::recording::err(st, Text::lit("kind"), prism_rtl::deref(t).span, prism_rtl::cat("`", name, "` is not a row kind: a tag joins `Element o`, `Fault` or another `type K = row`"))});
    });
    })
        : prism_rtl::is_none(key_opt) ? prism_rtl::finished(std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unknown-name"), prism_rtl::deref(t).span, prism_rtl::cat("no row kind `", name, "`"))})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TagKind(g, cx_, st, prism_rtl::deref(prism_rtl::deref(x)))));
    })
        : prism_rtl::finished(std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("kind"), prism_rtl::deref(t).span, Text::lit("a tag joins a row kind"))});
    });
}


/// `Start TagKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> start_tag_kind(crate::check::env::G g, crate::check::env::reading::Cx_ cx_, crate::check::types::St st, crate::syntax::Type t) {
    return prism_rtl::make_rc<TagKind>(g, cx_, st, t);
}


/// ConvTrait: unbounded fn G, St, ModInfo, TraitDecl, Range -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> conv_trait(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::env::ModInfo& info, const crate::syntax::decls::TraitDecl& t, const crate::syntax::Range& span) {
    auto name = crate::check::env::qual_key(info.name, crate::check::env::dotted(t.name->path_));
    auto param = or_(index(each(t.params, [&](const crate::syntax::Ident& p_) { return prism_rtl::deref(p_).name; }), Nat(0u)), Text::lit("a"));
    auto st1 = len(t.params) > Nat(1u)
        ? crate::check::types::recording::err(st, Text::lit("unsupported"), span, Text::lit("this checker does not implement traits of several types"))
        : st;
    auto cx_ = crate::check::env::reading::cx_of(g, info.name);
    auto [supers, st2] = crate::check::env::reading::conv_bounds(cx_, st1, t.bounds);
    auto [g3, st3, methods, defaults, assocs] = run_to_end(fold_job(t.items, std::tuple{g, st2, Array<Text>{}, Array<Text>{}, Array<Text>{}}, ({
        auto info_1 = info;
        auto cx__2 = cx_;
        auto param_3 = param;
        auto name_4 = name;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=, info_1 = std::move(info_1), cx__2 = std::move(cx__2), param_3 = std::move(param_3), name_4 = std::move(name_4)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>, crate::syntax::decls::TraitItem> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_1_5 = info_1;
            auto cx__2_5 = cx__2;
            auto param_3_5 = param_3;
            auto name_4_5 = name_4;
            entered(once_job([=, info_1_5 = std::move(info_1_5), cx__2_5 = std::move(cx__2_5), param_3_5 = std::move(param_3_5), name_4_5 = std::move(name_4_5)]() {
            return ({
                auto [gg, s, ms, ds, assoc_acc] = p0;
                auto it = p1;
                ({
                prism_rtl::is<crate::syntax::decls::TraitItem::TiSignature>(it) ? ({
                auto&& sg = prism_rtl::as<crate::syntax::decls::TraitItem::TiSignature>(it).a0;
                ({
                auto mname = crate::check::env::def_name_text(prism_rtl::deref(sg).name);
                auto qk = crate::check::env::qual_key(info_1_5.name, mname);
                auto sg_5 = sg;
                call_then(crate::check::env::reading::start_sig_scheme(cx__2_5, s, prism_rtl::deref(sg_5).ty, prism_rtl::deref(sg_5).bounds), [=, qk = std::move(qk)](std::tuple<crate::check::types::Scheme, crate::check::types::St> sig_scheme_12556) {
                return ({
                    auto [sc, s2] = sig_scheme_12556;
                    auto sc2 = ({
                        crate::check::types::Scheme this_ = sc;
                        this_.qs = crate::check::types::has_text(this_.qs, param_3_5)
                            ? this_.qs
                            : append(Array(std::vector{param_3_5}), this_.qs);
                        this_.bounds = append(Array(std::vector{std::tuple{param_3_5, name_4_5}}), this_.bounds);
                        (std::move(this_));
                    });
                    auto upd = ({
                        crate::check::env::G this_ = gg;
                        this_.vals = insert(this_.vals, qk, crate::check::env::ValInfo{.qk = qk, .scheme = sc2, .sort = Text::lit("method"), .has_sig = true, .home = info_1_5.name, .file = info_1_5.file, .span = prism_rtl::deref(sg_5).span});
                        (std::move(this_));
                    });
                    (prism_rtl::finished(std::tuple{upd, s2, crate::prelude::push(ms, qk), ds, assoc_acc}));
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it) ? ({
                auto&& f = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it).a0;
                ({
                auto qk = crate::check::env::qual_key(info_1_5.name, crate::check::env::def_name_text(prism_rtl::deref(f).name));
                auto def = crate::check::env::Def{.qk = qk, .name = crate::check::env::def_name_text(prism_rtl::deref(f).name), .home = info_1_5.name, .file = info_1_5.file, .span = prism_rtl::deref(f).span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbDefault{Array(std::vector{f}), name_4_5})};
                auto upd = ({
                    crate::check::env::G this_ = gg;
                    this_.defs = crate::prelude::push(this_.defs, def);
                    (std::move(this_));
                });
                (prism_rtl::finished(std::tuple{upd, s, ms, crate::prelude::push(ds, qk), assoc_acc}));
            });
            })
                : prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocType>(it) ? ({
                auto&& n = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it).a0;
                prism_rtl::finished(std::tuple{gg, s, ms, ds, crate::prelude::push(assoc_acc, prism_rtl::deref(n).name)});
            })
                : prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocRow>(it) ? ({
                auto&& r = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocRow>(it).a1;
                prism_rtl::finished(std::tuple{gg, crate::check::types::recording::err(s, Text::lit("unsupported"), r, Text::lit("this checker does not implement associated rows")), ms, ds, assoc_acc});
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
    auto ti = crate::check::env::TraitInfo{.name = name, .home = info.name, .param = param, .supers = each(supers, [&](const std::tuple<Text, Text>& _p0) {
        auto&& k = std::get<1>(_p0);
        return k;
    }), .methods = methods, .defaults = defaults, .assocs = assocs, .file = info.file, .span = span};
    auto upd3 = ({
        crate::check::env::G this_ = g3;
        this_.traits = insert(this_.traits, name, ti);
        (std::move(this_));
    });
    return std::tuple{upd3, st3};
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvTrait::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& info = this->info;
    const auto& t = this->t;
    const auto& span = this->span;
    auto name = crate::check::env::qual_key(prism_rtl::deref(info).name, crate::check::env::dotted(prism_rtl::deref(t).name->path_));
    auto param = or_(index(each(prism_rtl::deref(t).params, [&](const crate::syntax::Ident& p_) { return prism_rtl::deref(p_).name; }), Nat(0u)), Text::lit("a"));
    auto st1 = len(prism_rtl::deref(t).params) > Nat(1u)
        ? crate::check::types::recording::err(st, Text::lit("unsupported"), span, Text::lit("this checker does not implement traits of several types"))
        : st;
    auto cx_ = crate::check::env::reading::cx_of(g, prism_rtl::deref(info).name);
    auto [supers, st2] = crate::check::env::reading::conv_bounds(cx_, st1, prism_rtl::deref(t).bounds);
    auto g_1 = g;
    auto info_2 = info;
    auto span_3 = span;
    auto t_4 = t;
    return call_value(fold_job(prism_rtl::deref(t_4).items, std::tuple{g_1, st2, Array<Text>{}, Array<Text>{}, Array<Text>{}}, ({
        auto info_2_5 = info_2;
        auto cx__5 = cx_;
        auto param_6 = param;
        auto name_7 = name;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=, info_2_5 = std::move(info_2_5), cx__5 = std::move(cx__5), param_6 = std::move(param_6), name_7 = std::move(name_7)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>, crate::syntax::decls::TraitItem> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_2_5_8 = info_2_5;
            auto cx__5_8 = cx__5;
            auto param_6_8 = param_6;
            auto name_7_8 = name_7;
            entered(once_job([=, info_2_5_8 = std::move(info_2_5_8), cx__5_8 = std::move(cx__5_8), param_6_8 = std::move(param_6_8), name_7_8 = std::move(name_7_8)]() {
            return ({
                auto [gg, s, ms, ds, assoc_acc] = p0;
                auto it = p1;
                ({
                prism_rtl::is<crate::syntax::decls::TraitItem::TiSignature>(it) ? ({
                auto&& sg = prism_rtl::as<crate::syntax::decls::TraitItem::TiSignature>(it).a0;
                ({
                auto mname = crate::check::env::def_name_text(prism_rtl::deref(sg).name);
                auto qk = crate::check::env::qual_key(prism_rtl::deref(info_2_5_8).name, mname);
                auto sg_8 = sg;
                call_then(crate::check::env::reading::start_sig_scheme(cx__5_8, s, prism_rtl::deref(sg_8).ty, prism_rtl::deref(sg_8).bounds), [=, qk = std::move(qk)](std::tuple<crate::check::types::Scheme, crate::check::types::St> sig_scheme_12556) {
                return ({
                    auto [sc, s2] = sig_scheme_12556;
                    auto sc2 = ({
                        crate::check::types::Scheme this_ = sc;
                        this_.qs = crate::check::types::has_text(this_.qs, param_6_8)
                            ? this_.qs
                            : append(Array(std::vector{param_6_8}), this_.qs);
                        this_.bounds = append(Array(std::vector{std::tuple{param_6_8, name_7_8}}), this_.bounds);
                        (std::move(this_));
                    });
                    auto upd = ({
                        crate::check::env::G this_ = gg;
                        this_.vals = insert(this_.vals, qk, crate::check::env::ValInfo{.qk = qk, .scheme = sc2, .sort = Text::lit("method"), .has_sig = true, .home = prism_rtl::deref(info_2_5_8).name, .file = info_2_5_8->file, .span = prism_rtl::deref(sg_8).span});
                        (std::move(this_));
                    });
                    (prism_rtl::finished(std::tuple{upd, s2, crate::prelude::push(ms, qk), ds, assoc_acc}));
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it) ? ({
                auto&& f = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it).a0;
                ({
                auto qk = crate::check::env::qual_key(prism_rtl::deref(info_2_5_8).name, crate::check::env::def_name_text(prism_rtl::deref(f).name));
                auto def = crate::check::env::Def{.qk = qk, .name = crate::check::env::def_name_text(prism_rtl::deref(f).name), .home = prism_rtl::deref(info_2_5_8).name, .file = info_2_5_8->file, .span = prism_rtl::deref(f).span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbDefault{Array(std::vector{f}), name_7_8})};
                auto upd = ({
                    crate::check::env::G this_ = gg;
                    this_.defs = crate::prelude::push(this_.defs, def);
                    (std::move(this_));
                });
                (prism_rtl::finished(std::tuple{upd, s, ms, crate::prelude::push(ds, qk), assoc_acc}));
            });
            })
                : prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocType>(it) ? ({
                auto&& n = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it).a0;
                prism_rtl::finished(std::tuple{gg, s, ms, ds, crate::prelude::push(assoc_acc, prism_rtl::deref(n).name)});
            })
                : prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocRow>(it) ? ({
                auto&& r = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocRow>(it).a1;
                prism_rtl::finished(std::tuple{gg, crate::check::types::recording::err(s, Text::lit("unsupported"), r, Text::lit("this checker does not implement associated rows")), ms, ds, assoc_acc});
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>> fold_12324) {
        return ({
            auto [g3, st3, methods, defaults, assocs] = fold_12324;
            auto ti = crate::check::env::TraitInfo{.name = name, .home = prism_rtl::deref(info_2).name, .param = param, .supers = each(supers, [&](const std::tuple<Text, Text>& _p0) {
                auto&& k = std::get<1>(_p0);
                return k;
            }), .methods = methods, .defaults = defaults, .assocs = assocs, .file = info_2->file, .span = span_3};
            auto upd3 = ({
                crate::check::env::G this_ = g3;
                this_.traits = insert(this_.traits, name, ti);
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{upd3, st3}));
        });
    });
}


/// `Start ConvTrait, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_conv_trait(crate::check::env::G g, crate::check::types::St st, crate::check::env::ModInfo info, crate::syntax::decls::TraitDecl t, crate::syntax::Range span) {
    return prism_rtl::make_rc<ConvTrait>(g, st, info, t, span);
}


/// ConvImpl: unbounded fn G, St, ModInfo, ImplDecl, Range -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> conv_impl(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::env::ModInfo& info, const crate::syntax::decls::ImplDecl& i, const crate::syntax::Range& span) {
    auto&& _m = crate::check::env::names::resolve_trait(g, info.name, i.trait_ref->path_);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{g, crate::check::types::recording::err(st, Text::lit("unknown-name"), prism_rtl::deref(i.trait_ref).span, prism_rtl::cat("no trait `^", crate::check::env::dotted(i.trait_ref->path_), "`"))};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& cls = prism_rtl::some_of(_m);
        auto cx_ = crate::check::env::reading::cx_of(g, info.name);
        auto [head, st2] = crate::check::env::reading::conv_type(cx_, st, i.ty);
        auto [bs, st3] = crate::check::env::reading::conv_bounds(cx_, st2, i.bounds);
        auto [assocs, st4] = run_to_end(fold_job(i.items, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st3}, ({
            auto cx__1 = cx_;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=, cx__1 = std::move(cx__1)](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::TraitItem> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx__1_2 = cx__1;
                entered(once_job([=, cx__1_2 = std::move(cx__1_2)]() {
                return ({
                    auto [acc, s] = p0;
                    auto it = p1;
                    ({
                    prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocType>(it) && prism_rtl::is_some(prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it).a2) ? ({
                    auto&& n = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it).a0;
                    auto&& v_ = prism_rtl::some_of(prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it).a2);
                    ({
                    auto n_2 = n;
                    auto v__3 = v_;
                    call_then(crate::check::env::reading::start_conv_type(cx__1_2, s, v__3), [=, n_2 = std::move(n_2)](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_14573) {
                    return ({
                        auto [vt, s2] = conv_type_14573;
                        (prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{prism_rtl::deref(n_2).name, vt}), s2}));
                    });
                });
                });
                })
                    : prism_rtl::finished(std::tuple{acc, s});
                });
                });
            }));
            });
        }));
        })));
        auto names = fold(i.items, Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::decls::TraitItem& it) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                if (prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it)) {
                    auto&& f = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it).a0;
                    _v.set(crate::check::types::add_text(acc, crate::check::env::def_name_text(prism_rtl::deref(f).name)));
                    goto _done;
                }
                {
                    _v.set(acc);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
        auto im = crate::check::env::ImplInfo{.cls = cls, .head = head, .qs = crate::check::env::reading::type_vars_of_type(i.ty), .bounds = bs, .home = info.name, .file = info.file, .span = span, .derived = false, .assocs = assocs, .methods = names};
        auto g2 = ({
            crate::check::env::G this_ = g;
            this_.impls = insert(this_.impls, cls, crate::prelude::push(or_(crate::prelude::get(this_.impls, cls), Array<crate::check::env::ImplInfo>{}), im));
            (std::move(this_));
        });
        auto g3 = fold(names, g2, [&](const crate::check::env::G& gg, const Text& mname) {
            return ({
                auto clauses = fold(i.items, Array<crate::syntax::decls::FnClause>{}, [&](const Array<crate::syntax::decls::FnClause>& acc, const crate::syntax::decls::TraitItem& it) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
                        if (prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it)) {
                            auto&& f = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it).a0;
                            _v.set(crate::check::env::def_name_text(prism_rtl::deref(f).name) == mname
                                ? crate::prelude::push(acc, f)
                                : acc);
                            goto _done;
                        }
                        {
                            _v.set(acc);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                ({
                crate::check::env::G this_ = gg;
                this_.defs = crate::prelude::push(this_.defs, crate::check::env::Def{.qk = prism_rtl::cat(cls, " impl ", mname), .name = mname, .home = info.name, .file = info.file, .span = span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbMethod{clauses, cls, im})});
                (std::move(this_));
            });
            });
        });
        return std::tuple{g3, st4};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> ConvImpl::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& info = this->info;
    const auto& i = this->i;
    const auto& span = this->span;
    return ({
        auto&& _m = crate::check::env::names::resolve_trait(g, prism_rtl::deref(info).name, prism_rtl::deref(i).trait_ref->path_);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g, crate::check::types::recording::err(st, Text::lit("unknown-name"), prism_rtl::deref(prism_rtl::deref(i).trait_ref).span, prism_rtl::cat("no trait `^", crate::check::env::dotted(prism_rtl::deref(i).trait_ref->path_), "`"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& cls = prism_rtl::some_of(_m);
        ({
        auto cx_ = crate::check::env::reading::cx_of(g, prism_rtl::deref(info).name);
        auto g_1 = g;
        auto i_2 = i;
        auto info_3 = info;
        auto span_4 = span;
        auto st_5 = st;
        call_then(crate::check::env::reading::start_conv_type(cx_, st_5, prism_rtl::deref(i_2).ty), [=, g_1 = std::move(g_1), info_3 = std::move(info_3), span_4 = std::move(span_4)](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_14326) {
        return ({
            auto [head, st2] = conv_type_14326;
            auto [bs, st3] = crate::check::env::reading::conv_bounds(cx_, st2, prism_rtl::deref(i_2).bounds);
            call_value(fold_job(prism_rtl::deref(i_2).items, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st3}, ({
            auto cx__6 = cx_;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=, cx__6 = std::move(cx__6)](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::decls::TraitItem> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx__6_7 = cx__6;
                entered(once_job([=, cx__6_7 = std::move(cx__6_7)]() {
                return ({
                    auto [acc, s] = p0;
                    auto it = p1;
                    ({
                    prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocType>(it) && prism_rtl::is_some(prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it).a2) ? ({
                    auto&& n = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it).a0;
                    auto&& v_ = prism_rtl::some_of(prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(it).a2);
                    ({
                    auto n_7 = n;
                    auto v__8 = v_;
                    call_then(crate::check::env::reading::start_conv_type(cx__6_7, s, v__8), [=, n_7 = std::move(n_7)](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_14573) {
                    return ({
                        auto [vt, s2] = conv_type_14573;
                        (prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{prism_rtl::deref(n_7).name, vt}), s2}));
                    });
                });
                });
                })
                    : prism_rtl::finished(std::tuple{acc, s});
                });
                });
            }));
            });
        }));
        })), [=](std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St> fold_14433) {
            return ({
                auto [assocs, st4] = fold_14433;
                auto names = fold(prism_rtl::deref(i_2).items, Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::decls::TraitItem& it) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        if (prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it)) {
                            auto&& f = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it).a0;
                            _v.set(crate::check::types::add_text(acc, crate::check::env::def_name_text(prism_rtl::deref(f).name)));
                            goto _done;
                        }
                        {
                            _v.set(acc);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                call_then(crate::check::env::reading::start_type_vars_of_type(prism_rtl::deref(i_2).ty), [=, names = std::move(names)](Array<Text> type_vars_of_type_14868) {
                return ({
                    auto im = crate::check::env::ImplInfo{.cls = cls, .head = head, .qs = type_vars_of_type_14868, .bounds = bs, .home = prism_rtl::deref(info_3).name, .file = info_3->file, .span = span_4, .derived = false, .assocs = assocs, .methods = names};
                    auto g2 = ({
                        crate::check::env::G this_ = g_1;
                        this_.impls = insert(this_.impls, cls, crate::prelude::push(or_(crate::prelude::get(this_.impls, cls), Array<crate::check::env::ImplInfo>{}), im));
                        (std::move(this_));
                    });
                    auto g3 = fold(names, g2, [&](const crate::check::env::G& gg, const Text& mname) {
                        return ({
                            auto clauses = fold(prism_rtl::deref(i_2).items, Array<crate::syntax::decls::FnClause>{}, [&](const Array<crate::syntax::decls::FnClause>& acc, const crate::syntax::decls::TraitItem& it) {
                                return ({
                                    __label__ _done;
                                    prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
                                    if (prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it)) {
                                        auto&& f = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it).a0;
                                        _v.set(crate::check::env::def_name_text(prism_rtl::deref(f).name) == mname
                                            ? crate::prelude::push(acc, f)
                                            : acc);
                                        goto _done;
                                    }
                                    {
                                        _v.set(acc);
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                            });
                            ({
                            crate::check::env::G this_ = gg;
                            this_.defs = crate::prelude::push(this_.defs, crate::check::env::Def{.qk = prism_rtl::cat(cls, " impl ", mname), .name = mname, .home = prism_rtl::deref(info_3).name, .file = info_3->file, .span = span_4, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbMethod{clauses, cls, im})});
                            (std::move(this_));
                        });
                        });
                    });
                    (prism_rtl::finished(std::tuple{g3, st4}));
                });
            });
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ConvImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_conv_impl(crate::check::env::G g, crate::check::types::St st, crate::check::env::ModInfo info, crate::syntax::decls::ImplDecl i, crate::syntax::Range span) {
    return prism_rtl::make_rc<ConvImpl>(g, st, info, i, span);
}

}  // namespace crate::check::env::decls
