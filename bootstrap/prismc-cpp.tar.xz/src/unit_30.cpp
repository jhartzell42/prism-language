// The module `Check.Types.Schemes`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/types/schemes/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Types.Schemes`, from `target/bootstrap/cpp-src/prismc/check/types/schemes.prism`.
namespace crate::check::types::schemes {

bool Inst::operator==(const Inst& o) const { return tys == o.tys && rows == o.rows && cols == o.cols; }

void Inst::show(Printer& p) const {
    p.record("Inst", {{"tys", tys}, {"rows", rows}, {"cols", cols}});
}

Pod Inst::to_pod() const {
    return Pod::record("Inst", {{"tys", prism_rtl::to_pod(tys)}, {"rows", prism_rtl::to_pod(rows)}, {"cols", prism_rtl::to_pod(cols)}});
}

Result<Inst> Inst::from_pod(const Pod& whole) {
    return Inst{.tys = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "tys")))), .rows = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Tail>>(TRY(crate::prelude::field(whole, "rows")))), .cols = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Col>>(TRY(crate::prelude::field(whole, "cols"))))};
}


/// Mono: fn Ty -> Scheme
crate::check::types::Scheme mono(const crate::check::types::Ty& t_p0) {
    return crate::check::types::Scheme{.qs = Array<Text>{}, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = t_p0};
}


/// SubstQ: unbounded fn Inst, Ty -> Ty
crate::check::types::Ty subst_q(const Inst& m_p0, const crate::check::types::Ty& t_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t_p1)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyQ>(t_p1).a0;
        return or_(crate::prelude::get(m_p0.tys, n_p2), crate::check::types::Ty(crate::check::types::Ty::TyQ{n_p2}));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& args_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p3, run_to_end(each_job(args_p4, ({
            auto m_p0_1 = m_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0_1 = std::move(m_p0_1)](crate::check::types::Ty p0) {
            return ({
                auto m_p0_1_2 = m_p0_1;
                entered(once_job([=, m_p0_1_2 = std::move(m_p0_1_2)]() {
                return ({
                    auto a_p5 = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstQ(m_p0_1_2, a_p5))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1)) {
        auto&& c_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a0;
        auto&& ps_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& res_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{subst_col(m_p0, c_p6), run_to_end(each_job(ps_p7, ({
            auto m_p0_1 = m_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0_1 = std::move(m_p0_1)](crate::check::types::Ty p0) {
            return ({
                auto m_p0_1_2 = m_p0_1;
                entered(once_job([=, m_p0_1_2 = std::move(m_p0_1_2)]() {
                return ({
                    auto p_p9 = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstQ(m_p0_1_2, p_p9))));
                });
            }));
            });
        })));
        }))), prism_rtl::rc(subst_q(m_p0, prism_rtl::deref(prism_rtl::deref(res_p8))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1)) {
        auto&& ts_pa = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{run_to_end(each_job(ts_pa, ({
            auto m_p0_1 = m_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0_1 = std::move(m_p0_1)](crate::check::types::Ty p0) {
            return ({
                auto m_p0_1_2 = m_p0_1;
                entered(once_job([=, m_p0_1_2 = std::move(m_p0_1_2)]() {
                return ({
                    auto a_pb = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstQ(m_p0_1_2, a_pb))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1)) {
        auto&& e_pc = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(subst_q(m_p0, prism_rtl::deref(prism_rtl::deref(e_pc))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1)) {
        auto&& k_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(subst_q(m_p0, prism_rtl::deref(prism_rtl::deref(k_pd)))), prism_rtl::rc(subst_q(m_p0, prism_rtl::deref(prism_rtl::deref(v_pe))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& s_pf = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s_pf, prism_rtl::rc(subst_q(m_p0, prism_rtl::deref(prism_rtl::deref(i_pg))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1)) {
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a0;
        auto&& rw_pi = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(subst_q(m_p0, prism_rtl::deref(prism_rtl::deref(i_ph)))), subst_row_q(m_p0, rw_pi)});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1)) {
        auto&& rw_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a0;
        auto&& o_pk = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyElem{subst_row_q(m_p0, rw_pj), prism_rtl::rc(subst_q(m_p0, prism_rtl::deref(prism_rtl::deref(o_pk))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p1)) {
        auto&& rw_pl = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t_p1).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyElemAny{subst_row_q(m_p0, rw_pl)});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1)) {
        auto&& n_pm = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a0;
        auto&& a_pn = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n_pm, prism_rtl::rc(subst_q(m_p0, prism_rtl::deref(prism_rtl::deref(a_pn))))});
    }
    {
        auto&& other_po = t_p1;
        return other_po;
    }
}


prism_rtl::Turn<crate::check::types::Ty> SubstQ::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyQ>(t_p1) ? ({
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyQ>(t_p1).a0;
        prism_rtl::finished(or_(crate::prelude::get(prism_rtl::deref(m_p0).tys, n_p2), crate::check::types::Ty(crate::check::types::Ty::TyQ{n_p2})));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) ? ({
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& args_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        ({
        auto args_p4_1 = args_p4;
        auto m_p0_2 = m_p0;
        auto n_p3_3 = n_p3;
        call_value(each_job(args_p4_1, ({
        auto m_p0_2_4 = m_p0_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0_2_4 = std::move(m_p0_2_4)](crate::check::types::Ty p0) {
        return ({
            auto m_p0_2_4_4 = m_p0_2_4;
            entered(once_job([=, m_p0_2_4_4 = std::move(m_p0_2_4_4)]() {
            return ({
                auto a_p5 = p0;
                (prism_rtl::more(prism_rtl::rc(SubstQ(m_p0_2_4_4, a_p5))));
            });
        }));
        });
    })));
    })), [=, n_p3_3 = std::move(n_p3_3)](Array<crate::check::types::Ty> each_1157) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p3_3, each_1157})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1) ? ({
        auto&& c_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a0;
        auto&& ps_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& res_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        ({
        auto c_p6_1 = c_p6;
        auto m_p0_2 = m_p0;
        auto ps_p7_3 = ps_p7;
        auto res_p8_4 = prism_rtl::deref(prism_rtl::deref(res_p8));
        call_value(each_job(ps_p7_3, ({
        auto m_p0_2_5 = m_p0_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0_2_5 = std::move(m_p0_2_5)](crate::check::types::Ty p0) {
        return ({
            auto m_p0_2_5_5 = m_p0_2_5;
            entered(once_job([=, m_p0_2_5_5 = std::move(m_p0_2_5_5)]() {
            return ({
                auto p_p9 = p0;
                (prism_rtl::more(prism_rtl::rc(SubstQ(m_p0_2_5_5, p_p9))));
            });
        }));
        });
    })));
    })), [=, c_p6_1 = std::move(c_p6_1), res_p8_4 = std::move(res_p8_4)](Array<crate::check::types::Ty> each_1230) { return call_then(start_subst_q(m_p0_2, res_p8_4), [=](crate::check::types::Ty subst_q_1259) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{subst_col(m_p0_2, c_p6_1), each_1230, prism_rtl::rc(subst_q_1259)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1) ? ({
        auto&& ts_pa = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        ({
        auto m_p0_1 = m_p0;
        auto ts_pa_2 = ts_pa;
        call_value(each_job(ts_pa_2, ({
        auto m_p0_1_3 = m_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0_1_3 = std::move(m_p0_1_3)](crate::check::types::Ty p0) {
        return ({
            auto m_p0_1_3_3 = m_p0_1_3;
            entered(once_job([=, m_p0_1_3_3 = std::move(m_p0_1_3_3)]() {
            return ({
                auto a_pb = p0;
                (prism_rtl::more(prism_rtl::rc(SubstQ(m_p0_1_3_3, a_pb))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_1299) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyTuple{each_1299})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1) ? ({
        auto&& e_pc = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        ({
        auto e_pc_1 = prism_rtl::deref(prism_rtl::deref(e_pc));
        auto m_p0_2 = m_p0;
        call_then(start_subst_q(m_p0_2, e_pc_1), [=](crate::check::types::Ty subst_q_1350) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(subst_q_1350)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1) ? ({
        auto&& k_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        ({
        auto k_pd_1 = prism_rtl::deref(prism_rtl::deref(k_pd));
        auto m_p0_2 = m_p0;
        auto v_pe_3 = prism_rtl::deref(prism_rtl::deref(v_pe));
        call_then(start_subst_q(m_p0_2, k_pd_1), [=, v_pe_3 = std::move(v_pe_3)](crate::check::types::Ty subst_q_1386) { return call_then(start_subst_q(m_p0_2, v_pe_3), [=](crate::check::types::Ty subst_q_1401) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(subst_q_1386), prism_rtl::rc(subst_q_1401)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p1) ? ({
        auto&& s_pf = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        ({
        auto i_pg_1 = prism_rtl::deref(prism_rtl::deref(i_pg));
        auto m_p0_2 = m_p0;
        auto s_pf_3 = s_pf;
        call_then(start_subst_q(m_p0_2, i_pg_1), [=, s_pf_3 = std::move(s_pf_3)](crate::check::types::Ty subst_q_1440) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{s_pf_3, prism_rtl::rc(subst_q_1440)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1) ? ({
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a0;
        auto&& rw_pi = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a1;
        ({
        auto i_ph_1 = prism_rtl::deref(prism_rtl::deref(i_ph));
        auto m_p0_2 = m_p0;
        auto rw_pi_3 = rw_pi;
        call_then(start_subst_q(m_p0_2, i_ph_1), [=, rw_pi_3 = std::move(rw_pi_3)](crate::check::types::Ty subst_q_1475) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(subst_q_1475), subst_row_q(m_p0_2, rw_pi_3)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1) ? ({
        auto&& rw_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a0;
        auto&& o_pk = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a1;
        ({
        auto m_p0_1 = m_p0;
        auto o_pk_2 = prism_rtl::deref(prism_rtl::deref(o_pk));
        auto rw_pj_3 = rw_pj;
        call_then(start_subst_q(m_p0_1, o_pk_2), [=, rw_pj_3 = std::move(rw_pj_3)](crate::check::types::Ty subst_q_1552) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyElem{subst_row_q(m_p0_1, rw_pj_3), prism_rtl::rc(subst_q_1552)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p1) ? ({
        auto&& rw_pl = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t_p1).a0;
        prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyElemAny{subst_row_q(m_p0, rw_pl)}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1) ? ({
        auto&& n_pm = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a0;
        auto&& a_pn = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        ({
        auto a_pn_1 = prism_rtl::deref(prism_rtl::deref(a_pn));
        auto m_p0_2 = m_p0;
        auto n_pm_3 = n_pm;
        call_then(start_subst_q(m_p0_2, a_pn_1), [=, n_pm_3 = std::move(n_pm_3)](crate::check::types::Ty subst_q_1641) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n_pm_3, prism_rtl::rc(subst_q_1641)})); });
    });
    })
        : ({
        auto&& other_po = t_p1;
        prism_rtl::finished(other_po);
    });
    });
}


/// `Start SubstQ, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_subst_q(Inst m_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<SubstQ>(m_p0, t_p1);
}


/// SubstRowQ: fn Inst, Rw -> Rw
crate::check::types::Rw subst_row_q(const Inst& m_p0, const crate::check::types::Rw& rw_p1) {
    auto&& _m = rw_p1.tail;
    if (prism_rtl::is<crate::check::types::Tail::TlQ>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Tail::TlQ>(_m).a0;
        auto&& _m = crate::prelude::get(m_p0.rows, n_p2);
        if (prism_rtl::is_some(_m)) {
            auto&& t_p3 = prism_rtl::some_of(_m);
            return crate::check::types::Rw{.fams = rw_p1.fams, .minus = rw_p1.minus, .tail = t_p3};
        }
        if (prism_rtl::is_none(_m)) {
            return rw_p1;
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return rw_p1;
    }
}


/// SubstCol: fn Inst, Col -> Col
crate::check::types::Col subst_col(const Inst& m_p0, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CQ>(col1)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Col::CQ>(col1).a0;
        return or_(crate::prelude::get(m_p0.cols, n_p1), crate::check::types::Col(crate::check::types::Col::CQ{n_p1}));
    }
    {
        auto&& c_p3 = col1;
        return c_p3;
    }
}


/// Instantiate: unbounded fn St, Scheme, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate(const crate::check::types::St& st_p0, const crate::check::types::Scheme& sc_p1, const crate::syntax::Range& span_p2) {
    auto&& _t_p3 = instantiate_with(st_p0, sc_p1, span_p2, Array<crate::check::types::Ty>{});
    auto&& t_p3 = std::get<0>(_t_p3);
    auto&& st2_p4 = std::get<1>(_t_p3);
    return std::tuple{t_p3, st2_p4};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> Instantiate::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& sc_p1 = this->sc_p1;
    const auto& span_p2 = this->span_p2;
    auto sc_p1_1 = sc_p1;
    auto span_p2_2 = span_p2;
    auto st_p0_3 = st_p0;
    return call_then(start_instantiate_with(st_p0_3, sc_p1_1, span_p2_2, Array<crate::check::types::Ty>{}), [=](std::tuple<crate::check::types::Ty, crate::check::types::St, Inst> instantiate_with_2231) {
        return ({
            auto&& _t_p3 = instantiate_with_2231;
            auto&& t_p3 = std::get<0>(_t_p3);
            auto&& st2_p4 = std::get<1>(_t_p3);
            (prism_rtl::finished(std::tuple{t_p3, st2_p4}));
        });
    });
}


/// `Start Instantiate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_instantiate(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1, crate::syntax::Range span_p2) {
    return prism_rtl::make_rc<Instantiate>(st_p0, sc_p1, span_p2);
}


/// InstantiateWith: unbounded fn St, Scheme, Range, [Ty] -> ((Ty, St, Inst))
std::tuple<crate::check::types::Ty, crate::check::types::St, Inst> instantiate_with(const crate::check::types::St& st_p0, const crate::check::types::Scheme& sc_p1, const crate::syntax::Range& span_p2, const Array<crate::check::types::Ty>& explicit_p3) {
    auto [tys_pf, st1_pg] = fold(crate::check::errors::range0(len(sc_p1.qs)), std::tuple{Map<Text, crate::check::types::Ty>{}, st_p0}, [&](const std::tuple<Map<Text, crate::check::types::Ty>, crate::check::types::St>& _p0, const Nat& i_pa) {
        auto&& m_p8 = std::get<0>(_p0);
        auto&& s_p9 = std::get<1>(_p0);
        return ({
            auto q_pb = or_(index(sc_p1.qs, i_pa), Text::lit(""));
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Map<Text, crate::check::types::Ty>, crate::check::types::St>> _v;
            auto&& _m = index(explicit_p3, i_pa);
            if (prism_rtl::is_some(_m)) {
                auto&& g_pc = prism_rtl::some_of(_m);
                _v.set(std::tuple{insert(m_p8, q_pb, g_pc), s_p9});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    auto [v_pd, s2_pe] = crate::check::types::fresh_var(s_p9, crate::check::types::has_text(sc_p1.plain_qs, q_pb), Text::lit(""));
                    std::tuple{insert(m_p8, q_pb, v_pd), s2_pe};
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    });
    auto nq_p4 = len(sc_p1.qs);
    auto [rows_pm, st2_pn] = run_to_end(fold_job(sc_p1.rqs, std::tuple{Map<Text, crate::check::types::Tail>{}, st1_pg}, ({
        auto sc_p1_1 = sc_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, crate::check::types::Tail>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, crate::check::types::Tail>, crate::check::types::St>, Text>)>>(prism_rtl::rc([=, sc_p1_1 = std::move(sc_p1_1)](std::tuple<std::tuple<Map<Text, crate::check::types::Tail>, crate::check::types::St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sc_p1_1_2 = sc_p1_1;
            entered(once_job([=, sc_p1_1_2 = std::move(sc_p1_1_2)]() {
            return ({
                auto [m_ph, s_pi] = p0;
                auto q_pj = p1;
                call_then(start_lacks_in(sc_p1_1_2.ty, q_pj), [=](Array<Text> lacks_in_2973) {
                return ({
                    auto [rw_pk, s2_pl] = crate::check::types::recording::fresh_row(s_pi, lacks_in_2973);
                    (prism_rtl::finished(std::tuple{insert(m_ph, q_pj, prism_rtl::deref(rw_pk).tail), crate::check::types::unify::name_row(s2_pl, prism_rtl::deref(rw_pk).tail, q_pj)}));
                });
            });
            });
        }));
        });
    }));
    })));
    auto [cols_pt, st2b_pu] = fold(sc_p1.cqs, std::tuple{Map<Text, crate::check::types::Col>{}, st2_pn}, [&](const std::tuple<Map<Text, crate::check::types::Col>, crate::check::types::St>& _p0, const Text& q_pq) {
        auto&& m_po = std::get<0>(_p0);
        auto&& s_pp = std::get<1>(_p0);
        return ({
            auto [c_pr, s2_ps] = crate::check::types::fresh_col(s_pp);
            std::tuple{insert(m_po, q_pq, c_pr), s2_ps};
        });
    });
    auto inst_p5 = Inst{.tys = tys_pf, .rows = rows_pm, .cols = cols_pt};
    auto st2c_p6 = run_to_end(fold_job(sc_p1.cjoins, st2b_pu, ({
        auto cols_pt_1 = cols_pt;
        auto span_p2_2 = span_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<Text, Text>>)>>(prism_rtl::rc([=, cols_pt_1 = std::move(cols_pt_1), span_p2_2 = std::move(span_p2_2)](std::tuple<crate::check::types::St, std::tuple<Text, Text>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cols_pt_1_3 = cols_pt_1;
            auto span_p2_2_3 = span_p2_2;
            entered(once_job([=, cols_pt_1_3 = std::move(cols_pt_1_3), span_p2_2_3 = std::move(span_p2_2_3)]() {
            return ({
                auto s_pv = p0;
                auto [lo_p10, hi_p11] = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::colors::AddLeq(s_pv, or_(crate::prelude::get(cols_pt_1_3, lo_p10), crate::check::types::Col(crate::check::types::Col::CBound{})), or_(crate::prelude::get(cols_pt_1_3, hi_p11), crate::check::types::Col(crate::check::types::Col::CBound{})), span_p2_2_3, Text::lit("arg"), Text::lit(""), Text::lit("")))));
            });
        }));
        });
    })));
    })));
    auto st3_p7 = fold(sc_p1.bounds, st2c_p6, [&](const crate::check::types::St& s_p12, const std::tuple<Text, Text>& _p1) {
        auto&& v_p13 = std::get<0>(_p1);
        auto&& tr_p14 = std::get<1>(_p1);
        return ({
            crate::check::types::St this_ = s_p12;
            this_.wants = crate::prelude::push(this_.wants, crate::check::types::Want{.cls = tr_p14, .ty = or_(crate::prelude::get(tys_pf, v_p13), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), .file = s_p12->file, .span = span_p2, .level = prism_rtl::deref(s_p12).level});
            (std::move(this_));
        });
    });
    return std::tuple{subst_q(inst_p5, sc_p1.ty), st3_p7, inst_p5};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St, Inst>> InstantiateWith::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& sc_p1 = this->sc_p1;
    const auto& span_p2 = this->span_p2;
    const auto& explicit_p3 = this->explicit_p3;
    auto [tys_pf, st1_pg] = fold(crate::check::errors::range0(len(prism_rtl::deref(sc_p1).qs)), std::tuple{Map<Text, crate::check::types::Ty>{}, st_p0}, [&](const std::tuple<Map<Text, crate::check::types::Ty>, crate::check::types::St>& _p0, const Nat& i_pa) {
        auto&& m_p8 = std::get<0>(_p0);
        auto&& s_p9 = std::get<1>(_p0);
        return ({
            auto q_pb = or_(index(prism_rtl::deref(sc_p1).qs, i_pa), Text::lit(""));
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Map<Text, crate::check::types::Ty>, crate::check::types::St>> _v;
            auto&& _m = index(explicit_p3, i_pa);
            if (prism_rtl::is_some(_m)) {
                auto&& g_pc = prism_rtl::some_of(_m);
                _v.set(std::tuple{insert(m_p8, q_pb, g_pc), s_p9});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    auto [v_pd, s2_pe] = crate::check::types::fresh_var(s_p9, crate::check::types::has_text(prism_rtl::deref(sc_p1).plain_qs, q_pb), Text::lit(""));
                    std::tuple{insert(m_p8, q_pb, v_pd), s2_pe};
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    });
    auto nq_p4 = len(prism_rtl::deref(sc_p1).qs);
    auto sc_p1_1 = sc_p1;
    auto span_p2_2 = span_p2;
    return call_value(fold_job(prism_rtl::deref(sc_p1_1).rqs, std::tuple{Map<Text, crate::check::types::Tail>{}, st1_pg}, ({
        auto sc_p1_1_3 = sc_p1_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, crate::check::types::Tail>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, crate::check::types::Tail>, crate::check::types::St>, Text>)>>(prism_rtl::rc([=, sc_p1_1_3 = std::move(sc_p1_1_3)](std::tuple<std::tuple<Map<Text, crate::check::types::Tail>, crate::check::types::St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sc_p1_1_3_3 = sc_p1_1_3;
            entered(once_job([=, sc_p1_1_3_3 = std::move(sc_p1_1_3_3)]() {
            return ({
                auto [m_ph, s_pi] = p0;
                auto q_pj = p1;
                call_then(start_lacks_in(prism_rtl::deref(sc_p1_1_3_3).ty, q_pj), [=](Array<Text> lacks_in_2973) {
                return ({
                    auto [rw_pk, s2_pl] = crate::check::types::recording::fresh_row(s_pi, lacks_in_2973);
                    (prism_rtl::finished(std::tuple{insert(m_ph, q_pj, prism_rtl::deref(rw_pk).tail), crate::check::types::unify::name_row(s2_pl, prism_rtl::deref(rw_pk).tail, q_pj)}));
                });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Map<Text, crate::check::types::Tail>, crate::check::types::St> fold_2894) {
        return ({
            auto [rows_pm, st2_pn] = fold_2894;
            auto [cols_pt, st2b_pu] = fold(prism_rtl::deref(sc_p1_1).cqs, std::tuple{Map<Text, crate::check::types::Col>{}, st2_pn}, [&](const std::tuple<Map<Text, crate::check::types::Col>, crate::check::types::St>& _p0, const Text& q_pq) {
                auto&& m_po = std::get<0>(_p0);
                auto&& s_pp = std::get<1>(_p0);
                return ({
                    auto [c_pr, s2_ps] = crate::check::types::fresh_col(s_pp);
                    std::tuple{insert(m_po, q_pq, c_pr), s2_ps};
                });
            });
            auto inst_p5 = Inst{.tys = tys_pf, .rows = rows_pm, .cols = cols_pt};
            call_value(fold_job(prism_rtl::deref(sc_p1_1).cjoins, st2b_pu, ({
            auto cols_pt_3 = cols_pt;
            auto span_p2_2_4 = span_p2_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<Text, Text>>)>>(prism_rtl::rc([=, cols_pt_3 = std::move(cols_pt_3), span_p2_2_4 = std::move(span_p2_2_4)](std::tuple<crate::check::types::St, std::tuple<Text, Text>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cols_pt_3_4 = cols_pt_3;
                auto span_p2_2_4_4 = span_p2_2_4;
                entered(once_job([=, cols_pt_3_4 = std::move(cols_pt_3_4), span_p2_2_4_4 = std::move(span_p2_2_4_4)]() {
                return ({
                    auto s_pv = p0;
                    auto [lo_p10, hi_p11] = p1;
                    (prism_rtl::more(prism_rtl::rc(crate::check::types::colors::AddLeq(s_pv, or_(crate::prelude::get(cols_pt_3_4, lo_p10), crate::check::types::Col(crate::check::types::Col::CBound{})), or_(crate::prelude::get(cols_pt_3_4, hi_p11), crate::check::types::Col(crate::check::types::Col::CBound{})), span_p2_2_4_4, Text::lit("arg"), Text::lit(""), Text::lit("")))));
                });
            }));
            });
        })));
        })), [=, inst_p5 = std::move(inst_p5)](crate::check::types::St fold_3252) {
            return ({
                auto st2c_p6 = fold_3252;
                auto st3_p7 = fold(prism_rtl::deref(sc_p1_1).bounds, st2c_p6, [&](const crate::check::types::St& s_p12, const std::tuple<Text, Text>& _p1) {
                    auto&& v_p13 = std::get<0>(_p1);
                    auto&& tr_p14 = std::get<1>(_p1);
                    return ({
                        crate::check::types::St this_ = s_p12;
                        this_.wants = crate::prelude::push(this_.wants, crate::check::types::Want{.cls = tr_p14, .ty = or_(crate::prelude::get(tys_pf, v_p13), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), .file = s_p12->file, .span = span_p2_2, .level = prism_rtl::deref(s_p12).level});
                        (std::move(this_));
                    });
                });
                call_then(start_subst_q(inst_p5, prism_rtl::deref(sc_p1_1).ty), [=, st3_p7 = std::move(st3_p7)](crate::check::types::Ty subst_q_3546) { return prism_rtl::finished(std::tuple{subst_q_3546, st3_p7, inst_p5}); });
            });
        });
        });
    });
}


/// `Start InstantiateWith, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St, Inst>> start_instantiate_with(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1, crate::syntax::Range span_p2, Array<crate::check::types::Ty> explicit_p3) {
    return prism_rtl::make_rc<InstantiateWith>(st_p0, sc_p1, span_p2, explicit_p3);
}


/// LacksIn: unbounded fn Ty, Text -> [Text]
Array<Text> lacks_in(const crate::check::types::Ty& t_p0, const Text& q_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0)) {
        auto&& args_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        return run_to_end(fold_job(args_p2, Array<Text>{}, ({
            auto q_p1_1 = q_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, q_p1_1 = std::move(q_p1_1)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto q_p1_1_2 = q_p1_1;
                entered(once_job([=, q_p1_1_2 = std::move(q_p1_1_2)]() {
                return ({
                    auto acc_p3 = p0;
                    auto a_p4 = p1;
                    call_then(start_lacks_in(a_p4, q_p1_1_2), [=, acc_p3 = std::move(acc_p3)](Array<Text> lacks_in_3833) { return prism_rtl::finished(crate::check::types::union_texts(acc_p3, lacks_in_3833)); });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0)) {
        auto&& ps_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& r_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        return run_to_end(fold_job(ps_p5, lacks_in(prism_rtl::deref(prism_rtl::deref(r_p6)), q_p1), ({
            auto q_p1_1 = q_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, q_p1_1 = std::move(q_p1_1)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto q_p1_1_2 = q_p1_1;
                entered(once_job([=, q_p1_1_2 = std::move(q_p1_1_2)]() {
                return ({
                    auto acc_p7 = p0;
                    auto a_p8 = p1;
                    call_then(start_lacks_in(a_p8, q_p1_1_2), [=, acc_p7 = std::move(acc_p7)](Array<Text> lacks_in_3923) { return prism_rtl::finished(crate::check::types::union_texts(acc_p7, lacks_in_3923)); });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_p9 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return run_to_end(fold_job(ts_p9, Array<Text>{}, ({
            auto q_p1_1 = q_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, q_p1_1 = std::move(q_p1_1)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto q_p1_1_2 = q_p1_1;
                entered(once_job([=, q_p1_1_2 = std::move(q_p1_1_2)]() {
                return ({
                    auto acc_pa = p0;
                    auto a_pb = p1;
                    call_then(start_lacks_in(a_pb, q_p1_1_2), [=, acc_pa = std::move(acc_pa)](Array<Text> lacks_in_3995) { return prism_rtl::finished(crate::check::types::union_texts(acc_pa, lacks_in_3995)); });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0)) {
        auto&& e_pc = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        return lacks_in(prism_rtl::deref(prism_rtl::deref(e_pc)), q_p1);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0)) {
        auto&& k_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        return crate::check::types::union_texts(lacks_in(prism_rtl::deref(prism_rtl::deref(k_pd)), q_p1), lacks_in(prism_rtl::deref(prism_rtl::deref(v_pe)), q_p1));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& i_pf = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return lacks_in(prism_rtl::deref(prism_rtl::deref(i_pf)), q_p1);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0)) {
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        auto&& rw_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a1;
        return crate::check::types::union_texts(lacks_in(prism_rtl::deref(prism_rtl::deref(i_pg)), q_p1), row_lacks(rw_ph, q_p1));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p0)) {
        auto&& rw_pi = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a0;
        auto&& o_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a1;
        return crate::check::types::union_texts(lacks_in(prism_rtl::deref(prism_rtl::deref(o_pj)), q_p1), row_lacks(rw_pi, q_p1));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p0)) {
        auto&& rw_pk = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t_p0).a0;
        return row_lacks(rw_pk, q_p1);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> LacksIn::cycle() const {
    const auto& t_p0 = this->t_p0;
    const auto& q_p1 = this->q_p1;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0) ? ({
        auto&& args_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        fold_job(args_p2, Array<Text>{}, ({
        auto q_p1_1 = q_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, q_p1_1 = std::move(q_p1_1)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto q_p1_1_2 = q_p1_1;
            entered(once_job([=, q_p1_1_2 = std::move(q_p1_1_2)]() {
            return ({
                auto acc_p3 = p0;
                auto a_p4 = p1;
                call_then(start_lacks_in(a_p4, q_p1_1_2), [=, acc_p3 = std::move(acc_p3)](Array<Text> lacks_in_3833) { return prism_rtl::finished(crate::check::types::union_texts(acc_p3, lacks_in_3833)); });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0) ? ({
        auto&& ps_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& r_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        ({
        auto ps_p5_1 = ps_p5;
        auto q_p1_2 = q_p1;
        auto r_p6_3 = prism_rtl::deref(prism_rtl::deref(r_p6));
        call_then(start_lacks_in(r_p6_3, q_p1_2), [=, ps_p5_1 = std::move(ps_p5_1)](Array<Text> lacks_in_3881) {
        return fold_job(ps_p5_1, lacks_in_3881, ({
            auto q_p1_2_4 = q_p1_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, q_p1_2_4 = std::move(q_p1_2_4)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto q_p1_2_4_4 = q_p1_2_4;
                entered(once_job([=, q_p1_2_4_4 = std::move(q_p1_2_4_4)]() {
                return ({
                    auto acc_p7 = p0;
                    auto a_p8 = p1;
                    call_then(start_lacks_in(a_p8, q_p1_2_4_4), [=, acc_p7 = std::move(acc_p7)](Array<Text> lacks_in_3923) { return prism_rtl::finished(crate::check::types::union_texts(acc_p7, lacks_in_3923)); });
                });
            }));
            });
        })));
        }))->cycle();
    });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0) ? ({
        auto&& ts_p9 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        fold_job(ts_p9, Array<Text>{}, ({
        auto q_p1_1 = q_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, q_p1_1 = std::move(q_p1_1)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto q_p1_1_2 = q_p1_1;
            entered(once_job([=, q_p1_1_2 = std::move(q_p1_1_2)]() {
            return ({
                auto acc_pa = p0;
                auto a_pb = p1;
                call_then(start_lacks_in(a_pb, q_p1_1_2), [=, acc_pa = std::move(acc_pa)](Array<Text> lacks_in_3995) { return prism_rtl::finished(crate::check::types::union_texts(acc_pa, lacks_in_3995)); });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0) ? ({
        auto&& e_pc = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(LacksIn(prism_rtl::deref(prism_rtl::deref(e_pc)), q_p1)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0) ? ({
        auto&& k_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        ({
        auto k_pd_1 = prism_rtl::deref(prism_rtl::deref(k_pd));
        auto q_p1_2 = q_p1;
        auto v_pe_3 = prism_rtl::deref(prism_rtl::deref(v_pe));
        call_then(start_lacks_in(k_pd_1, q_p1_2), [=, v_pe_3 = std::move(v_pe_3)](Array<Text> lacks_in_4065) { return call_then(start_lacks_in(v_pe_3, q_p1_2), [=](Array<Text> lacks_in_4081) { return prism_rtl::finished(crate::check::types::union_texts(lacks_in_4065, lacks_in_4081)); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p0) ? ({
        auto&& i_pf = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        prism_rtl::more(prism_rtl::rc(LacksIn(prism_rtl::deref(prism_rtl::deref(i_pf)), q_p1)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0) ? ({
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        auto&& rw_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a1;
        ({
        auto i_pg_1 = prism_rtl::deref(prism_rtl::deref(i_pg));
        auto q_p1_2 = q_p1;
        auto rw_ph_3 = rw_ph;
        call_then(start_lacks_in(i_pg_1, q_p1_2), [=, rw_ph_3 = std::move(rw_ph_3)](Array<Text> lacks_in_4157) { return prism_rtl::finished(crate::check::types::union_texts(lacks_in_4157, row_lacks(rw_ph_3, q_p1_2))); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p0) ? ({
        auto&& rw_pi = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a0;
        auto&& o_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a1;
        ({
        auto o_pj_1 = prism_rtl::deref(prism_rtl::deref(o_pj));
        auto q_p1_2 = q_p1;
        auto rw_pi_3 = rw_pi;
        call_then(start_lacks_in(o_pj_1, q_p1_2), [=, rw_pi_3 = std::move(rw_pi_3)](Array<Text> lacks_in_4219) { return prism_rtl::finished(crate::check::types::union_texts(lacks_in_4219, row_lacks(rw_pi_3, q_p1_2))); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p0) ? ({
        auto&& rw_pk = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t_p0).a0;
        prism_rtl::finished(row_lacks(rw_pk, q_p1));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start LacksIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_lacks_in(crate::check::types::Ty t_p0, Text q_p1) {
    return prism_rtl::make_rc<LacksIn>(t_p0, q_p1);
}


/// RowLacks: fn Rw, Text -> [Text]
Array<Text> row_lacks(const crate::check::types::Rw& rw_p0, const Text& q_p1) {
    return rw_p0.tail == crate::check::types::Tail(crate::check::types::Tail::TlQ{q_p1})
        ? rw_p0.fams
        : Array<Text>{};
}


/// Skolemize: unbounded fn Scheme -> Ty
crate::check::types::Ty skolemize(const crate::check::types::Scheme& sc_p0) {
    auto tys_p1 = fold(sc_p0.qs, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m_p4, const Text& q_p5) { return insert(m_p4, q_p5, crate::check::types::Ty(crate::check::types::Ty::TyRigid{q_p5})); });
    auto rows_p2 = fold(sc_p0.rqs, Map<Text, crate::check::types::Tail>{}, [&](const Map<Text, crate::check::types::Tail>& m_p6, const Text& q_p7) { return insert(m_p6, q_p7, crate::check::types::Tail(crate::check::types::Tail::TlRigid{q_p7})); });
    auto cols_p3 = fold(sc_p0.cqs, Map<Text, crate::check::types::Col>{}, [&](const Map<Text, crate::check::types::Col>& m_p8, const Text& q_p9) { return insert(m_p8, q_p9, crate::check::types::Col(crate::check::types::Col::CRigid{q_p9})); });
    return subst_q(Inst{.tys = tys_p1, .rows = rows_p2, .cols = cols_p3}, sc_p0.ty);
}


prism_rtl::Turn<crate::check::types::Ty> Skolemize::cycle() const {
    const auto& sc_p0 = this->sc_p0;
    auto tys_p1 = fold(prism_rtl::deref(sc_p0).qs, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m_p4, const Text& q_p5) { return insert(m_p4, q_p5, crate::check::types::Ty(crate::check::types::Ty::TyRigid{q_p5})); });
    auto rows_p2 = fold(prism_rtl::deref(sc_p0).rqs, Map<Text, crate::check::types::Tail>{}, [&](const Map<Text, crate::check::types::Tail>& m_p6, const Text& q_p7) { return insert(m_p6, q_p7, crate::check::types::Tail(crate::check::types::Tail::TlRigid{q_p7})); });
    auto cols_p3 = fold(prism_rtl::deref(sc_p0).cqs, Map<Text, crate::check::types::Col>{}, [&](const Map<Text, crate::check::types::Col>& m_p8, const Text& q_p9) { return insert(m_p8, q_p9, crate::check::types::Col(crate::check::types::Col::CRigid{q_p9})); });
    return prism_rtl::more(prism_rtl::rc(SubstQ(Inst{.tys = tys_p1, .rows = rows_p2, .cols = cols_p3}, prism_rtl::deref(sc_p0).ty)));
}


/// `Start Skolemize, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_skolemize(crate::check::types::Scheme sc_p0) {
    return prism_rtl::make_rc<Skolemize>(sc_p0);
}


/// Generalize: unbounded fn St, Ty, [Nat], [((Nat, Text))] -> ((Scheme, St))
std::tuple<crate::check::types::Scheme, crate::check::types::St> generalize(const crate::check::types::St& st0_p0, const crate::check::types::Ty& t_p1, const Array<Nat>& keep_p2, const Array<std::tuple<Nat, Text>>& bounds_p3) {
    auto waiting_p4 = run_to_end(fold_job(st0_p0.field_qs, Array<Nat>{}, ({
        auto st0_p0_1 = st0_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::unify::FieldQ>)>>(prism_rtl::rc([=, st0_p0_1 = std::move(st0_p0_1)](std::tuple<Array<Nat>, crate::check::types::unify::FieldQ> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st0_p0_1_2 = st0_p0_1;
            entered(once_job([=, st0_p0_1_2 = std::move(st0_p0_1_2)]() {
            return ({
                auto acc_pf = p0;
                auto q_pg = p1;
                call_then(crate::check::types::recording::start_free_vars_into(st0_p0_1_2, acc_pf, prism_rtl::deref(q_pg).recv), [=](Array<Nat> free_vars_into_5383) { return prism_rtl::more(prism_rtl::rc(crate::check::types::recording::FreeVarsInto(st0_p0_1_2, free_vars_into_5383, q_pg->result))); });
            });
        }));
        });
    })));
    })));
    auto st_p5 = crate::check::types::colors::generalize_cols(crate::check::types::unify::lower_levels(st0_p0, waiting_p4, st0_p0.level));
    auto z_p6 = crate::check::types::recording::zonk(st_p5, t_p1);
    auto vs_p7 = filter(crate::check::types::recording::free_vars(st_p5, z_p6), [&](const Nat& v_ph) { return (prism_rtl::deref(crate::check::types::recording::info_of(st_p5, v_ph)).level > prism_rtl::deref(st_p5).level) && (!crate::check::types::has_nat(keep_p2, v_ph)); });
    auto cvs_p8 = filter(crate::check::types::colors::free_col_vars(st_p5, z_p6), [&](const Nat& v_pi) { return prism_rtl::deref(crate::check::types::recording::info_of(st_p5, v_pi)).level > prism_rtl::deref(st_p5).level; });
    auto tys_p9 = fold(vs_p7, Map<Nat, crate::check::types::Ty>{}, [&](const Map<Nat, crate::check::types::Ty>& m_pj, const Nat& v_pk) { return insert(m_pj, v_pk, crate::check::types::Ty(crate::check::types::Ty::TyQ{prism_rtl::cat("\'", v_pk)})); });
    auto cols_pa = fold(cvs_p8, Map<Nat, crate::check::types::Col>{}, [&](const Map<Nat, crate::check::types::Col>& m_pl, const Nat& v_pm) { return insert(m_pl, v_pm, crate::check::types::Col(crate::check::types::Col::CQ{prism_rtl::cat("\'c", v_pm)})); });
    auto named_pb = subst_flex(tys_p9, cols_pa, z_p6);
    auto plains_pc = each(filter(vs_p7, [&](const Nat& v_pn) { return prism_rtl::deref(crate::check::types::recording::info_of(st_p5, v_pn)).plain; }), [&](const Nat& v_po) { return prism_rtl::cat("\'", v_po); });
    auto bs_pd = each(filter(bounds_p3, [&](const std::tuple<Nat, Text>& _p0) {
        auto&& v_pp = std::get<0>(_p0);
        return crate::check::types::has_nat(vs_p7, v_pp);
    }), [&](const std::tuple<Nat, Text>& _p0) {
        auto&& v_pq = std::get<0>(_p0);
        auto&& tr_pr = std::get<1>(_p0);
        return std::tuple{prism_rtl::cat("\'", v_pq), tr_pr};
    });
    auto st2_pe = ({
        crate::check::types::St this_ = st_p5;
        this_.col_q = fold(cvs_p8, this_.col_q, [&](const Map<Nat, Text>& m_ps, const Nat& v_pt) { return insert(m_ps, v_pt, prism_rtl::cat("\'c", v_pt)); });
        (std::move(this_));
    });
    return std::tuple{crate::check::types::Scheme{.qs = each(vs_p7, [&](const Nat& v_pu) { return prism_rtl::cat("\'", v_pu); }), .plain_qs = plains_pc, .rqs = Array<Text>{}, .cqs = each(cvs_p8, [&](const Nat& v_pv) { return prism_rtl::cat("\'c", v_pv); }), .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = bs_pd, .ty = named_pb}, st2_pe};
}


prism_rtl::Turn<std::tuple<crate::check::types::Scheme, crate::check::types::St>> Generalize::cycle() const {
    const auto& st0_p0 = this->st0_p0;
    const auto& t_p1 = this->t_p1;
    const auto& keep_p2 = this->keep_p2;
    const auto& bounds_p3 = this->bounds_p3;
    auto bounds_p3_1 = bounds_p3;
    auto keep_p2_2 = keep_p2;
    auto st0_p0_3 = st0_p0;
    auto t_p1_4 = t_p1;
    return call_value(fold_job(prism_rtl::deref(st0_p0_3).field_qs, Array<Nat>{}, ({
        auto st0_p0_3_5 = st0_p0_3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::unify::FieldQ>)>>(prism_rtl::rc([=, st0_p0_3_5 = std::move(st0_p0_3_5)](std::tuple<Array<Nat>, crate::check::types::unify::FieldQ> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st0_p0_3_5_5 = st0_p0_3_5;
            entered(once_job([=, st0_p0_3_5_5 = std::move(st0_p0_3_5_5)]() {
            return ({
                auto acc_pf = p0;
                auto q_pg = p1;
                call_then(crate::check::types::recording::start_free_vars_into(st0_p0_3_5_5, acc_pf, prism_rtl::deref(q_pg).recv), [=](Array<Nat> free_vars_into_5383) { return prism_rtl::more(prism_rtl::rc(crate::check::types::recording::FreeVarsInto(st0_p0_3_5_5, free_vars_into_5383, q_pg->result))); });
            });
        }));
        });
    })));
    })), [=](Array<Nat> fold_5330) {
        return ({
            auto waiting_p4 = fold_5330;
            call_then(crate::check::types::colors::start_generalize_cols(crate::check::types::unify::lower_levels(st0_p0_3, waiting_p4, prism_rtl::deref(st0_p0_3).level)), [=](crate::check::types::St generalize_cols_5437) {
            return ({
                auto st_p5 = generalize_cols_5437;
                call_then(crate::check::types::recording::start_zonk(st_p5, t_p1_4), [=](crate::check::types::Ty zonk_5502) {
                return ({
                    auto z_p6 = zonk_5502;
                    call_then(crate::check::types::recording::start_free_vars(st_p5, z_p6), [=](Array<Nat> free_vars_5534) {
                    return ({
                        auto vs_p7 = filter(free_vars_5534, [&](const Nat& v_ph) { return (prism_rtl::deref(crate::check::types::recording::info_of(st_p5, v_ph)).level > prism_rtl::deref(st_p5).level) && (!crate::check::types::has_nat(keep_p2_2, v_ph)); });
                        call_then(crate::check::types::colors::start_free_col_vars(st_p5, z_p6), [=, vs_p7 = std::move(vs_p7)](Array<Nat> free_col_vars_5635) {
                        return ({
                            auto cvs_p8 = filter(free_col_vars_5635, [&](const Nat& v_pi) { return prism_rtl::deref(crate::check::types::recording::info_of(st_p5, v_pi)).level > prism_rtl::deref(st_p5).level; });
                            auto tys_p9 = fold(vs_p7, Map<Nat, crate::check::types::Ty>{}, [&](const Map<Nat, crate::check::types::Ty>& m_pj, const Nat& v_pk) { return insert(m_pj, v_pk, crate::check::types::Ty(crate::check::types::Ty::TyQ{prism_rtl::cat("\'", v_pk)})); });
                            auto cols_pa = fold(cvs_p8, Map<Nat, crate::check::types::Col>{}, [&](const Map<Nat, crate::check::types::Col>& m_pl, const Nat& v_pm) { return insert(m_pl, v_pm, crate::check::types::Col(crate::check::types::Col::CQ{prism_rtl::cat("\'c", v_pm)})); });
                            call_then(start_subst_flex(tys_p9, cols_pa, z_p6), [=, cvs_p8 = std::move(cvs_p8)](crate::check::types::Ty subst_flex_5832) {
                            return ({
                                auto named_pb = subst_flex_5832;
                                auto plains_pc = each(filter(vs_p7, [&](const Nat& v_pn) { return prism_rtl::deref(crate::check::types::recording::info_of(st_p5, v_pn)).plain; }), [&](const Nat& v_po) { return prism_rtl::cat("\'", v_po); });
                                auto bs_pd = each(filter(bounds_p3_1, [&](const std::tuple<Nat, Text>& _p0) {
                                    auto&& v_pp = std::get<0>(_p0);
                                    return crate::check::types::has_nat(vs_p7, v_pp);
                                }), [&](const std::tuple<Nat, Text>& _p0) {
                                    auto&& v_pq = std::get<0>(_p0);
                                    auto&& tr_pr = std::get<1>(_p0);
                                    return std::tuple{prism_rtl::cat("\'", v_pq), tr_pr};
                                });
                                auto st2_pe = ({
                                    crate::check::types::St this_ = st_p5;
                                    this_.col_q = fold(cvs_p8, this_.col_q, [&](const Map<Nat, Text>& m_ps, const Nat& v_pt) { return insert(m_ps, v_pt, prism_rtl::cat("\'c", v_pt)); });
                                    (std::move(this_));
                                });
                                (prism_rtl::finished(std::tuple{crate::check::types::Scheme{.qs = each(vs_p7, [&](const Nat& v_pu) { return prism_rtl::cat("\'", v_pu); }), .plain_qs = plains_pc, .rqs = Array<Text>{}, .cqs = each(cvs_p8, [&](const Nat& v_pv) { return prism_rtl::cat("\'c", v_pv); }), .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = bs_pd, .ty = named_pb}, st2_pe}));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start Generalize, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Scheme, crate::check::types::St>> start_generalize(crate::check::types::St st0_p0, crate::check::types::Ty t_p1, Array<Nat> keep_p2, Array<std::tuple<Nat, Text>> bounds_p3) {
    return prism_rtl::make_rc<Generalize>(st0_p0, t_p1, keep_p2, bounds_p3);
}


/// SubstFlex: unbounded fn (Nat ==> Ty), (Nat ==> Col), Ty -> Ty
crate::check::types::Ty subst_flex(const Map<Nat, crate::check::types::Ty>& m_p0, const Map<Nat, crate::check::types::Col>& cm_p1, const crate::check::types::Ty& t_p2) {
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(t_p2)) {
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyFlex>(t_p2).a0;
        return or_(crate::prelude::get(m_p0, n_p3), crate::check::types::Ty(crate::check::types::Ty::TyFlex{n_p3}));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2)) {
        auto&& n_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& args_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p4, run_to_end(each_job(args_p5, ({
            auto m_p0_1 = m_p0;
            auto cm_p1_2 = cm_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0_1 = std::move(m_p0_1), cm_p1_2 = std::move(cm_p1_2)](crate::check::types::Ty p0) {
            return ({
                auto m_p0_1_3 = m_p0_1;
                auto cm_p1_2_3 = cm_p1_2;
                entered(once_job([=, m_p0_1_3 = std::move(m_p0_1_3), cm_p1_2_3 = std::move(cm_p1_2_3)]() {
                return ({
                    auto a_p6 = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstFlex(m_p0_1_3, cm_p1_2_3, a_p6))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p2)) {
        auto&& c_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a0;
        auto&& ps_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a1;
        auto&& res_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a2;
        auto c2_pa = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Col> _v;
            if (prism_rtl::is<crate::check::types::Col::CFlex>(c_p7)) {
                auto&& n_pb = prism_rtl::as<crate::check::types::Col::CFlex>(c_p7).a0;
                _v.set(or_(crate::prelude::get(cm_p1, n_pb), c_p7));
                goto _done;
            }
            {
                auto&& other_pc = c_p7;
                _v.set(other_pc);
                goto _done;
            }
        _done:
            _v.take();
        });
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{c2_pa, run_to_end(each_job(ps_p8, ({
            auto m_p0_1 = m_p0;
            auto cm_p1_2 = cm_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0_1 = std::move(m_p0_1), cm_p1_2 = std::move(cm_p1_2)](crate::check::types::Ty p0) {
            return ({
                auto m_p0_1_3 = m_p0_1;
                auto cm_p1_2_3 = cm_p1_2;
                entered(once_job([=, m_p0_1_3 = std::move(m_p0_1_3), cm_p1_2_3 = std::move(cm_p1_2_3)]() {
                return ({
                    auto p_pd = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstFlex(m_p0_1_3, cm_p1_2_3, p_pd))));
                });
            }));
            });
        })));
        }))), prism_rtl::rc(subst_flex(m_p0, cm_p1, prism_rtl::deref(prism_rtl::deref(res_p9))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p2)) {
        auto&& ts_pe = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p2).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{run_to_end(each_job(ts_pe, ({
            auto m_p0_1 = m_p0;
            auto cm_p1_2 = cm_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0_1 = std::move(m_p0_1), cm_p1_2 = std::move(cm_p1_2)](crate::check::types::Ty p0) {
            return ({
                auto m_p0_1_3 = m_p0_1;
                auto cm_p1_2_3 = cm_p1_2;
                entered(once_job([=, m_p0_1_3 = std::move(m_p0_1_3), cm_p1_2_3 = std::move(cm_p1_2_3)]() {
                return ({
                    auto a_pf = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstFlex(m_p0_1_3, cm_p1_2_3, a_pf))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p2)) {
        auto&& e_pg = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p2).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(subst_flex(m_p0, cm_p1, prism_rtl::deref(prism_rtl::deref(e_pg))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p2)) {
        auto&& k_ph = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a0;
        auto&& v_pi = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(subst_flex(m_p0, cm_p1, prism_rtl::deref(prism_rtl::deref(k_ph)))), prism_rtl::rc(subst_flex(m_p0, cm_p1, prism_rtl::deref(prism_rtl::deref(v_pi))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p2)) {
        auto&& s_pj = prism_rtl::as<crate::check::types::Ty::TySig>(t_p2).a0;
        auto&& i_pk = prism_rtl::as<crate::check::types::Ty::TySig>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s_pj, prism_rtl::rc(subst_flex(m_p0, cm_p1, prism_rtl::deref(prism_rtl::deref(i_pk))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p2)) {
        auto&& i_pl = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p2).a0;
        auto&& rw_pm = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(subst_flex(m_p0, cm_p1, prism_rtl::deref(prism_rtl::deref(i_pl)))), rw_pm});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p2)) {
        auto&& rw_pn = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p2).a0;
        auto&& o_po = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyElem{rw_pn, prism_rtl::rc(subst_flex(m_p0, cm_p1, prism_rtl::deref(prism_rtl::deref(o_po))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p2)) {
        auto&& n_pp = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p2).a0;
        auto&& a_pq = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n_pp, prism_rtl::rc(subst_flex(m_p0, cm_p1, prism_rtl::deref(prism_rtl::deref(a_pq))))});
    }
    {
        auto&& other_pr = t_p2;
        return other_pr;
    }
}


prism_rtl::Turn<crate::check::types::Ty> SubstFlex::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& cm_p1 = this->cm_p1;
    const auto& t_p2 = this->t_p2;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFlex>(t_p2) ? ({
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyFlex>(t_p2).a0;
        prism_rtl::finished(or_(crate::prelude::get(m_p0, n_p3), crate::check::types::Ty(crate::check::types::Ty::TyFlex{n_p3})));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2) ? ({
        auto&& n_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& args_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        ({
        auto args_p5_1 = args_p5;
        auto cm_p1_2 = cm_p1;
        auto m_p0_3 = m_p0;
        auto n_p4_4 = n_p4;
        call_value(each_job(args_p5_1, ({
        auto m_p0_3_5 = m_p0_3;
        auto cm_p1_2_5 = cm_p1_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0_3_5 = std::move(m_p0_3_5), cm_p1_2_5 = std::move(cm_p1_2_5)](crate::check::types::Ty p0) {
        return ({
            auto m_p0_3_5_5 = m_p0_3_5;
            auto cm_p1_2_5_5 = cm_p1_2_5;
            entered(once_job([=, m_p0_3_5_5 = std::move(m_p0_3_5_5), cm_p1_2_5_5 = std::move(cm_p1_2_5_5)]() {
            return ({
                auto a_p6 = p0;
                (prism_rtl::more(prism_rtl::rc(SubstFlex(m_p0_3_5_5, cm_p1_2_5_5, a_p6))));
            });
        }));
        });
    })));
    })), [=, n_p4_4 = std::move(n_p4_4)](Array<crate::check::types::Ty> each_6411) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p4_4, each_6411})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p2) ? ({
        auto&& c_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a0;
        auto&& ps_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a1;
        auto&& res_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a2;
        ({
        auto c2_pa = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Col> _v;
            if (prism_rtl::is<crate::check::types::Col::CFlex>(c_p7)) {
                auto&& n_pb = prism_rtl::as<crate::check::types::Col::CFlex>(c_p7).a0;
                _v.set(or_(crate::prelude::get(cm_p1, n_pb), c_p7));
                goto _done;
            }
            {
                auto&& other_pc = c_p7;
                _v.set(other_pc);
                goto _done;
            }
        _done:
            _v.take();
        });
        auto cm_p1_1 = cm_p1;
        auto m_p0_2 = m_p0;
        auto ps_p8_3 = ps_p8;
        auto res_p9_4 = prism_rtl::deref(prism_rtl::deref(res_p9));
        call_value(each_job(ps_p8_3, ({
        auto m_p0_2_5 = m_p0_2;
        auto cm_p1_1_5 = cm_p1_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0_2_5 = std::move(m_p0_2_5), cm_p1_1_5 = std::move(cm_p1_1_5)](crate::check::types::Ty p0) {
        return ({
            auto m_p0_2_5_5 = m_p0_2_5;
            auto cm_p1_1_5_5 = cm_p1_1_5;
            entered(once_job([=, m_p0_2_5_5 = std::move(m_p0_2_5_5), cm_p1_1_5_5 = std::move(cm_p1_1_5_5)]() {
            return ({
                auto p_pd = p0;
                (prism_rtl::more(prism_rtl::rc(SubstFlex(m_p0_2_5_5, cm_p1_1_5_5, p_pd))));
            });
        }));
        });
    })));
    })), [=, c2_pa = std::move(c2_pa), res_p9_4 = std::move(res_p9_4)](Array<crate::check::types::Ty> each_6570) { return call_then(start_subst_flex(m_p0_2, cm_p1_1, res_p9_4), [=](crate::check::types::Ty subst_flex_6606) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{c2_pa, each_6570, prism_rtl::rc(subst_flex_6606)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p2) ? ({
        auto&& ts_pe = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p2).a0;
        ({
        auto cm_p1_1 = cm_p1;
        auto m_p0_2 = m_p0;
        auto ts_pe_3 = ts_pe;
        call_value(each_job(ts_pe_3, ({
        auto m_p0_2_4 = m_p0_2;
        auto cm_p1_1_4 = cm_p1_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0_2_4 = std::move(m_p0_2_4), cm_p1_1_4 = std::move(cm_p1_1_4)](crate::check::types::Ty p0) {
        return ({
            auto m_p0_2_4_4 = m_p0_2_4;
            auto cm_p1_1_4_4 = cm_p1_1_4;
            entered(once_job([=, m_p0_2_4_4 = std::move(m_p0_2_4_4), cm_p1_1_4_4 = std::move(cm_p1_1_4_4)]() {
            return ({
                auto a_pf = p0;
                (prism_rtl::more(prism_rtl::rc(SubstFlex(m_p0_2_4_4, cm_p1_1_4_4, a_pf))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_6653) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyTuple{each_6653})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p2) ? ({
        auto&& e_pg = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p2).a0;
        ({
        auto cm_p1_1 = cm_p1;
        auto e_pg_2 = prism_rtl::deref(prism_rtl::deref(e_pg));
        auto m_p0_3 = m_p0;
        call_then(start_subst_flex(m_p0_3, cm_p1_1, e_pg_2), [=](crate::check::types::Ty subst_flex_6711) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(subst_flex_6711)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p2) ? ({
        auto&& k_ph = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a0;
        auto&& v_pi = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a1;
        ({
        auto cm_p1_1 = cm_p1;
        auto k_ph_2 = prism_rtl::deref(prism_rtl::deref(k_ph));
        auto m_p0_3 = m_p0;
        auto v_pi_4 = prism_rtl::deref(prism_rtl::deref(v_pi));
        call_then(start_subst_flex(m_p0_3, cm_p1_1, k_ph_2), [=, v_pi_4 = std::move(v_pi_4)](crate::check::types::Ty subst_flex_6754) { return call_then(start_subst_flex(m_p0_3, cm_p1_1, v_pi_4), [=](crate::check::types::Ty subst_flex_6776) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(subst_flex_6754), prism_rtl::rc(subst_flex_6776)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p2) ? ({
        auto&& s_pj = prism_rtl::as<crate::check::types::Ty::TySig>(t_p2).a0;
        auto&& i_pk = prism_rtl::as<crate::check::types::Ty::TySig>(t_p2).a1;
        ({
        auto cm_p1_1 = cm_p1;
        auto i_pk_2 = prism_rtl::deref(prism_rtl::deref(i_pk));
        auto m_p0_3 = m_p0;
        auto s_pj_4 = s_pj;
        call_then(start_subst_flex(m_p0_3, cm_p1_1, i_pk_2), [=, s_pj_4 = std::move(s_pj_4)](crate::check::types::Ty subst_flex_6822) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{s_pj_4, prism_rtl::rc(subst_flex_6822)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p2) ? ({
        auto&& i_pl = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p2).a0;
        auto&& rw_pm = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p2).a1;
        ({
        auto cm_p1_1 = cm_p1;
        auto i_pl_2 = prism_rtl::deref(prism_rtl::deref(i_pl));
        auto m_p0_3 = m_p0;
        auto rw_pm_4 = rw_pm;
        call_then(start_subst_flex(m_p0_3, cm_p1_1, i_pl_2), [=, rw_pm_4 = std::move(rw_pm_4)](crate::check::types::Ty subst_flex_6864) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(subst_flex_6864), rw_pm_4})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p2) ? ({
        auto&& rw_pn = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p2).a0;
        auto&& o_po = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p2).a1;
        ({
        auto cm_p1_1 = cm_p1;
        auto m_p0_2 = m_p0;
        auto o_po_3 = prism_rtl::deref(prism_rtl::deref(o_po));
        auto rw_pn_4 = rw_pn;
        call_then(start_subst_flex(m_p0_2, cm_p1_1, o_po_3), [=, rw_pn_4 = std::move(rw_pn_4)](crate::check::types::Ty subst_flex_6918) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyElem{rw_pn_4, prism_rtl::rc(subst_flex_6918)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p2) ? ({
        auto&& n_pp = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p2).a0;
        auto&& a_pq = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p2).a1;
        ({
        auto a_pq_1 = prism_rtl::deref(prism_rtl::deref(a_pq));
        auto cm_p1_2 = cm_p1;
        auto m_p0_3 = m_p0;
        auto n_pp_4 = n_pp;
        call_then(start_subst_flex(m_p0_3, cm_p1_2, a_pq_1), [=, n_pp_4 = std::move(n_pp_4)](crate::check::types::Ty subst_flex_6968) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n_pp_4, prism_rtl::rc(subst_flex_6968)})); });
    });
    })
        : ({
        auto&& other_pr = t_p2;
        prism_rtl::finished(other_pr);
    });
    });
}


/// `Start SubstFlex, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_subst_flex(Map<Nat, crate::check::types::Ty> m_p0, Map<Nat, crate::check::types::Col> cm_p1, crate::check::types::Ty t_p2) {
    return prism_rtl::make_rc<SubstFlex>(m_p0, cm_p1, t_p2);
}


/// HoldsNode: unbounded fn St, Ty -> Bool
bool holds_node(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    auto&& _m = crate::check::types::recording::walk(st_p0, t_p1);
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& s_p2 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i_p3 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return ((s_p2 == Text::lit("$")) || (s_p2 == Text::lit("!"))) || holds_node(st_p0, prism_rtl::deref(i_p3));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts_p4 = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return run_to_end(fold_job(ts_p4, false, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto seen_p5 = p0;
                    auto x_p6 = p1;
                    (prism_rtl::finished(std::move(seen_p5) || holds_node(st_p0_1_2, x_p6)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& e_p7 = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        return holds_node(st_p0, prism_rtl::deref(e_p7));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k_p8 = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_p9 = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return holds_node(st_p0, prism_rtl::deref(k_p8)) || holds_node(st_p0, prism_rtl::deref(v_p9));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& args_pa = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        return run_to_end(fold_job(args_pa, false, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto seen_pb = p0;
                    auto x_pc = p1;
                    (prism_rtl::finished(std::move(seen_pb) || holds_node(st_p0_1_2, x_pc)));
                });
            }));
            });
        })));
        })));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> HoldsNode::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0_1 = st_p0;
    auto t_p1_2 = t_p1;
    return call_then(crate::check::types::recording::start_walk(st_p0_1, t_p1_2), [=](crate::check::types::Ty walk_7202) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TySig>(walk_7202) ? ({
            auto&& s_p2 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_7202).a0;
            auto&& i_p3 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_7202).a1;
            prism_rtl::finished(((s_p2 == Text::lit("$")) || (s_p2 == Text::lit("!"))) || holds_node(st_p0_1, prism_rtl::deref(i_p3)));
        })
            : prism_rtl::is<crate::check::types::Ty::TyTuple>(walk_7202) ? ({
            auto&& ts_p4 = prism_rtl::as<crate::check::types::Ty::TyTuple>(walk_7202).a0;
            fold_job(ts_p4, false, ({
            auto st_p0_1_3 = st_p0_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0_1_3 = std::move(st_p0_1_3)](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0_1_3_3 = st_p0_1_3;
                entered(once_job([=, st_p0_1_3_3 = std::move(st_p0_1_3_3)]() {
                return ({
                    auto seen_p5 = p0;
                    auto x_p6 = p1;
                    (prism_rtl::finished(std::move(seen_p5) || holds_node(st_p0_1_3_3, x_p6)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::types::Ty::TyArray>(walk_7202) ? ({
            auto&& e_p7 = prism_rtl::as<crate::check::types::Ty::TyArray>(walk_7202).a0;
            prism_rtl::more(prism_rtl::rc(HoldsNode(st_p0_1, prism_rtl::deref(e_p7))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyMap>(walk_7202) ? ({
            auto&& k_p8 = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_7202).a0;
            auto&& v_p9 = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_7202).a1;
            call_then(start_holds_node(st_p0_1, prism_rtl::deref(k_p8)), [=](bool holds_node_7385) { return prism_rtl::finished(holds_node_7385 || holds_node(st_p0_1, prism_rtl::deref(v_p9))); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_7202) ? ({
            auto&& args_pa = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_7202).a1;
            fold_job(args_pa, false, ({
            auto st_p0_1_3 = st_p0_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0_1_3 = std::move(st_p0_1_3)](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0_1_3_3 = st_p0_1_3;
                entered(once_job([=, st_p0_1_3_3 = std::move(st_p0_1_3_3)]() {
                return ({
                    auto seen_pb = p0;
                    auto x_pc = p1;
                    (prism_rtl::finished(std::move(seen_pb) || holds_node(st_p0_1_3_3, x_pc)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::finished(false);
        });
    });
}


/// `Start HoldsNode, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_holds_node(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<HoldsNode>(st_p0, t_p1);
}


/// EnterLevel: fn St -> St
crate::check::types::St enter_level(const crate::check::types::St& st_p0) {
    crate::check::types::St this_ = st_p0;
    this_.level = this_.level + Nat(1u);
    return this_;
}


/// LeaveLevel: fn St -> St
crate::check::types::St leave_level(const crate::check::types::St& st_p0) {
    crate::check::types::St this_ = st_p0;
    this_.level = or_(this_.level.checked_sub(Nat(1u)), Nat(0u));
    return this_;
}

}  // namespace crate::check::types::schemes
