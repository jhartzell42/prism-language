// The module `Emit.Cpp.Expr`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/cpp/expr/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Emit.Cpp.Expr`, from `target/bootstrap/cpp-src/prismc/emit/cpp/expr.prism`.
namespace crate::emit::cpp::expr {

/// CppLoose: fn Ex -> Bool
bool cpp_loose(const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x)) {
        auto&& m1173_0_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& inner = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        if (m1173_0_0.size() == 0u) {
            return cpp_loose(prism_rtl::deref(prism_rtl::deref(inner)));
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBin>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnary>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIf>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRef>(x).a0;
        return cpp_loose(prism_rtl::deref(prism_rtl::deref(y)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRefMut>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRefMut>(x).a0;
        return cpp_loose(prism_rtl::deref(prism_rtl::deref(y)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClone>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XClone>(x).a0;
        return cpp_loose(prism_rtl::deref(prism_rtl::deref(y)));
    }
    {
        return false;
    }
}


/// CppTight: unbounded fn Cp, Ex -> Text
Text cpp_tight(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& x) {
    return cpp_loose(x)
        ? prism_rtl::cat("(", cpp_expr(cp, x), ")")
        : starred(cpp_expr(cp, x));
}


prism_rtl::Turn<Text> CppTight::cycle() const {
    const auto& cp = this->cp;
    const auto& x = this->x;
    return cpp_loose(x)
        ? ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_1500) { return prism_rtl::finished(prism_rtl::cat("(", cpp_expr_1500, ")")); });
    })
        : ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_1532) { return prism_rtl::finished(starred(cpp_expr_1532)); });
    });
}


/// `Start CppTight, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_tight(crate::emit::cpp::Cp cp, crate::lower::model::Ex x) {
    return prism_rtl::make_rc<CppTight>(cp, x);
}


/// Starred: fn Text -> Text
Text starred(const Text& t) {
    return crate::syntax::lexer::chars::has_prefix(t, Text::lit("*"))
        ? prism_rtl::cat("(", t, ")")
        : t;
}


/// CppTightPlace: unbounded fn Cp, Ex -> Text
Text cpp_tight_place(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& x) {
    return cpp_loose(x)
        ? prism_rtl::cat("(", cpp_place(cp, x), ")")
        : starred(cpp_place(cp, x));
}


prism_rtl::Turn<Text> CppTightPlace::cycle() const {
    const auto& cp = this->cp;
    const auto& x = this->x;
    return cpp_loose(x)
        ? ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_place(cp_1, x_2), [=](Text cpp_place_1889) { return prism_rtl::finished(prism_rtl::cat("(", cpp_place_1889, ")")); });
    })
        : ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_place(cp_1, x_2), [=](Text cpp_place_1922) { return prism_rtl::finished(starred(cpp_place_1922)); });
    });
}


/// `Start CppTightPlace, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_tight_place(crate::emit::cpp::Cp cp, crate::lower::model::Ex x) {
    return prism_rtl::make_rc<CppTightPlace>(cp, x);
}


/// CppPlace: unbounded fn Cp, Ex -> Text
Text cpp_place(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& ex1) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(ex1)) {
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(ex1).a0;
        return crate::emit::cpp::stmts::var_name(cp, n);
    }
    {
        auto&& x = ex1;
        return cpp_expr(cp, x);
    }
}


prism_rtl::Turn<Text> CppPlace::cycle() const {
    const auto& cp = this->cp;
    const auto& ex1 = this->ex1;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XVar>(ex1) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(ex1).a0;
        prism_rtl::finished(crate::emit::cpp::stmts::var_name(cp, n));
    })
        : ({
        auto&& x = ex1;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, x)));
    });
    });
}


/// `Start CppPlace, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_place(crate::emit::cpp::Cp cp, crate::lower::model::Ex ex1) {
    return prism_rtl::make_rc<CppPlace>(cp, ex1);
}


/// CppVar: fn Cp, Text -> Text
Text cpp_var(const crate::emit::cpp::Cp& cp, const Text& n) {
    return or_(crate::prelude::get(cp.owned, n), false)
        ? prism_rtl::cat("std::move(", crate::emit::cpp::stmts::var_name(cp, n), ")")
        : crate::emit::cpp::stmts::var_name(cp, n);
}


/// CppArgs: unbounded fn Cp, [Ex] -> Text
Text cpp_args(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Ex>& xs) {
    return crate::syntax::lexer::chars::join(cpp_arg_list(cp, xs), Text::lit(", "));
}


prism_rtl::Turn<Text> CppArgs::cycle() const {
    const auto& cp = this->cp;
    const auto& xs = this->xs;
    auto cp_1 = cp;
    auto xs_2 = xs;
    return call_then(start_cpp_arg_list(cp_1, xs_2), [=](Array<Text> cpp_arg_list_2810) { return prism_rtl::finished(crate::syntax::lexer::chars::join(cpp_arg_list_2810, Text::lit(", "))); });
}


/// `Start CppArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_args(crate::emit::cpp::Cp cp, Array<crate::lower::model::Ex> xs) {
    return prism_rtl::make_rc<CppArgs>(cp, xs);
}


/// CppArgList: unbounded fn Cp, [Ex] -> [Text]
Array<Text> cpp_arg_list(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Ex>& xs) {
    auto texts = run_to_end(each_job(xs, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, cp_1 = std::move(cp_1)](crate::lower::model::Ex p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=, cp_1_2 = std::move(cp_1_2)]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(CppExpr(cp_1_2, x))));
            });
        }));
        });
    })));
    })));
    return each(crate::check::errors::range0(len(xs)), [&](const Nat& i) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            auto&& _m = or_(index(xs, i), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(_m)) {
                auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(_m).a0;
                _v.set(fold(crate::check::errors::range0(len(xs)), false, [&](const bool& f, const Nat& j) { return prism_rtl::deref(f) || ((j != i) && crate::emit::cpp::stmts::cpp_mentions(or_(index(texts, j), Text::lit("")), crate::emit::cpp::stmts::var_name(cp, n))); })
                    ? crate::emit::cpp::stmts::var_name(cp, n)
                    : or_(index(texts, i), Text::lit("")));
                goto _done;
            }
            {
                _v.set(or_(index(texts, i), Text::lit("")));
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> CppArgList::cycle() const {
    const auto& cp = this->cp;
    const auto& xs = this->xs;
    auto cp_1 = cp;
    auto xs_2 = xs;
    return call_value(each_job(xs_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, cp_1_3 = std::move(cp_1_3)](crate::lower::model::Ex p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=, cp_1_3_3 = std::move(cp_1_3_3)]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(CppExpr(cp_1_3_3, x))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_2918) {
        return ({
            auto texts = each_2918;
            (prism_rtl::finished(each(crate::check::errors::range0(len(xs_2)), [&](const Nat& i) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = or_(index(xs_2, i), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
                if (prism_rtl::is<crate::lower::model::Ex::XVar>(_m)) {
                    auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(_m).a0;
                    _v.set(fold(crate::check::errors::range0(len(xs_2)), false, [&](const bool& f, const Nat& j) { return prism_rtl::deref(f) || ((j != i) && crate::emit::cpp::stmts::cpp_mentions(or_(index(texts, j), Text::lit("")), crate::emit::cpp::stmts::var_name(cp_1, n))); })
                        ? crate::emit::cpp::stmts::var_name(cp_1, n)
                        : or_(index(texts, i), Text::lit("")));
                    goto _done;
                }
                {
                    _v.set(or_(index(texts, i), Text::lit("")));
                    goto _done;
                }
            _done:
                _v.take();
            });
        })));
        });
    });
}


/// `Start CppArgList, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cpp_arg_list(crate::emit::cpp::Cp cp, Array<crate::lower::model::Ex> xs) {
    return prism_rtl::make_rc<CppArgList>(cp, xs);
}


/// CppExpr: unbounded fn Cp, Ex -> Text
Text cpp_expr(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x)) {
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(x).a0;
        return cpp_var(cp, n);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPath>(x)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XPath>(x).a0;
        return path_value(cp, p_);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XSelf>(x)) {
        return Text::lit("prism_rtl::share(this)");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCx>(x)) {
        return Text::lit("cx");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XConst>(x)) {
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XConst>(x).a0;
        return n;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnit>(x)) {
        return Text::lit("Unit{}");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XNone>(x)) {
        return Text::lit("std::nullopt");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBool>(x)) {
        auto&& b = prism_rtl::as<crate::lower::model::Ex::XBool>(x).a0;
        return prism_rtl::deref(b) ? Text::lit("true") : Text::lit("false");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XNat>(x)) {
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XNat>(x).a0;
        return len_text(d) <= Nat(9u)
            ? prism_rtl::cat("Nat(", d, "u)")
            : prism_rtl::cat("*Nat::from_int(", cpp_expr(cp, crate::lower::model::Ex(crate::lower::model::Ex::XInt{d})), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XInt>(x)) {
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XInt>(x).a0;
        return len_text(crate::syntax::lexer::chars::has_prefix(d, Text::lit("-"))
            ? crate::syntax::lexer::chars::after_first(d)
            : d) <= Nat(18u)
            ? prism_rtl::cat("Int(", d, "ll)")
            : prism_rtl::cat("*Int::parse(\"", d, "\")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XByte>(x)) {
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XByte>(x).a0;
        return prism_rtl::cat("std::uint8_t(", d, ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFloat>(x)) {
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XFloat>(x).a0;
        return prism_rtl::cat("Float{", d, "}");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIndex>(x)) {
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XIndex>(x).a0;
        return prism_rtl::cat(n, "u");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XChar>(x)) {
        auto&& c = prism_rtl::as<crate::lower::model::Ex::XChar>(x).a0;
        return prism_rtl::cat("U\'", cpp_char_escape(c), "\'");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XStr>(x)) {
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XStr>(x).a0;
        return cpp_string(t);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRegex>(x)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XRegex>(x).a0;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XRegex>(x).a1;
        return prism_rtl::cat("([]() -> const Regex& { static const Regex r = Regex::lit(", cpp_string(p_), ", ", cpp_string(f), "); return r; }())");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XReplacement>(x)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x).a0;
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x).a1;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x).a2;
        return prism_rtl::cat("([]() -> const RegexReplacement& { static const RegexReplacement r = RegexReplacement::lit(", cpp_string(p_), ", ", cpp_string(f), ", ", cpp_string(r), "); return r; }())");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRef>(x).a0;
        return cpp_place(cp, prism_rtl::deref(prism_rtl::deref(y)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRefMut>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRefMut>(x).a0;
        return cpp_place(cp, prism_rtl::deref(prism_rtl::deref(y)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDeref>(x).a0;
        auto&& _m = ex_ty(cp, prism_rtl::deref(prism_rtl::deref(y)));
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::model::OutTy::OutRc>(prism_rtl::some_of(_m))) {
            return prism_rtl::cat("*", cpp_tight_place(cp, prism_rtl::deref(prism_rtl::deref(y))));
        }
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::model::OutTy::OutRef>(prism_rtl::some_of(_m))) {
            return cpp_place(cp, prism_rtl::deref(prism_rtl::deref(y)));
        }
        {
            return prism_rtl::cat("prism_rtl::deref(", cpp_place(cp, prism_rtl::deref(prism_rtl::deref(y))), ")");
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTarget>(x).a0;
        return cpp_place(cp, prism_rtl::deref(prism_rtl::deref(y)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClone>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XClone>(x).a0;
        return cpp_place(cp, prism_rtl::deref(prism_rtl::deref(y)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XWeak>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XWeak>(x).a0;
        return prism_rtl::cat("prism_rtl::weaken(", cpp_expr(cp, prism_rtl::deref(prism_rtl::deref(y))), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x).a0;
        return prism_rtl::cat("prism_rtl::upgrade(", cpp_expr(cp, prism_rtl::deref(prism_rtl::deref(y))), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBreak>(x)) {
        auto&& l = prism_rtl::as<crate::lower::model::Ex::XBreak>(x).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XBreak>(x).a1;
        return prism_rtl::cat("(", crate::emit::cpp::patterns::cpp_break(cp, l, prism_rtl::deref(prism_rtl::deref(y))), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(x)) {
        return Text::lit("({ break; })");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XLater>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XLater>(x).a0;
        return prism_rtl::cat("[=](Cx& cx) -> Done { ", cpp_expr(crate::emit::cpp::stmts::captured(cp), prism_rtl::deref(prism_rtl::deref(y))), "; return {}; }");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFormatStr>(x)) {
        auto&& parts = prism_rtl::as<crate::lower::model::Ex::XFormatStr>(x).a0;
        return cpp_format(cp, parts, Text::lit("prism_rtl::str"));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIsCase>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a0;
        auto&& m3254_28_1 = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a1;
        if (m3254_28_1.size() == 0u) {
            return Text::lit("false");
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIsCase>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a0;
        auto&& cs = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a1;
        return prism_rtl::cat("(", crate::syntax::lexer::chars::join(run_to_end(each_job(cs, ({
            auto cp_1 = cp;
            auto y_2 = prism_rtl::deref(prism_rtl::deref(y));
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=, cp_1 = std::move(cp_1), y_2 = std::move(y_2)](Text p0) {
            return ({
                auto cp_1_3 = cp_1;
                auto y_2_3 = y_2;
                entered(once_job([=, cp_1_3 = std::move(cp_1_3), y_2_3 = std::move(y_2_3)]() {
                return ({
                    auto c = p0;
                    call_then(start_cpp_tight_place(cp_1_3, y_2_3), [=, c = std::move(c)](Text cpp_tight_place_5408) { return prism_rtl::finished(case_test(cp_1_3, c, cpp_tight_place_5408)); });
                });
            }));
            });
        })));
        }))), Text::lit(" || ")), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRefusal>(x)) {
        auto&& what = prism_rtl::as<crate::lower::model::Ex::XRefusal>(x).a0;
        return prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), crate::lower::expr::escape(what), "\")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnreachable>(x)) {
        return Text::lit("throw prism_rtl::Panic(\"entered unreachable code\")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCall>(x)) {
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XCall>(x).a0;
        auto&& args = prism_rtl::as<crate::lower::model::Ex::XCall>(x).a1;
        return cpp_call(cp, f, args);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XApply>(x)) {
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XApply>(x).a0;
        auto&& args = prism_rtl::as<crate::lower::model::Ex::XApply>(x).a1;
        return prism_rtl::cat(cpp_tight_place(cp, prism_rtl::deref(prism_rtl::deref(f))), "(", cpp_args(cp, args), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMethod>(x)) {
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a0;
        auto&& m = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a1;
        auto&& args = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a2;
        return cpp_method(cp, prism_rtl::deref(prism_rtl::deref(r)), m, args);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBin>(x)) {
        auto&& op = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a0;
        auto&& l = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a1;
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a2;
        auto [lt, rt] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, Text>> _v;
            auto&& _m = cpp_arg_list(cp, Array(std::vector{prism_rtl::deref(prism_rtl::deref(l)), prism_rtl::deref(prism_rtl::deref(r))}));
            {
                auto&& m5782_0 = _m;
                if (m5782_0.size() == 2u) {
                    {
                        auto&& _c2 = index(m5782_0, Nat(0u));
                        if (prism_rtl::is_some(_c2)) {
                            auto&& a = prism_rtl::some_of(_c2);
                            {
                                auto&& _c1 = index(m5782_0, Nat(1u));
                                if (prism_rtl::is_some(_c1)) {
                                    auto&& b = prism_rtl::some_of(_c1);
                                    _v.set(std::tuple{a, b});
                                    goto _done;
                                }
                            }
                        }
                    }
                }
            }
            {
                _v.set(std::tuple{Text::lit(""), Text::lit("")});
                goto _done;
            }
        _done:
            _v.take();
        });
        return prism_rtl::cat(cpp_loose(prism_rtl::deref(prism_rtl::deref(l)))
            ? prism_rtl::cat("(", lt, ")")
            : lt, " ", op, " ", cpp_loose(prism_rtl::deref(prism_rtl::deref(r)))
            ? prism_rtl::cat("(", rt, ")")
            : rt);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnary>(x)) {
        auto&& op = prism_rtl::as<crate::lower::model::Ex::XUnary>(x).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XUnary>(x).a1;
        return prism_rtl::cat(op, cpp_tight(cp, prism_rtl::deref(prism_rtl::deref(y))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCtor>(x)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a0;
        auto&& args = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a1;
        return cpp_ctor(cp, p_, args);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRecord>(x)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XRecord>(x).a0;
        auto&& fs = prism_rtl::as<crate::lower::model::Ex::XRecord>(x).a1;
        return cpp_record(cp, p_, fs);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTuple>(x)) {
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XTuple>(x).a0;
        return prism_rtl::cat("std::tuple{", cpp_args(cp, xs), "}");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XVec>(x)) {
        auto&& m3254_40_0 = prism_rtl::as<crate::lower::model::Ex::XVec>(x).a0;
        if (m3254_40_0.size() == 0u) {
            return Text::lit("{}");
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XVec>(x)) {
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XVec>(x).a0;
        return prism_rtl::cat("std::vector{", cpp_args(cp, xs), "}");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XText>(x)) {
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XText>(x).a0;
        return prism_rtl::cat("Text::lit(", cpp_string(t), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFormat>(x)) {
        auto&& parts = prism_rtl::as<crate::lower::model::Ex::XFormat>(x).a0;
        return fold(parts, true, [&](const bool& f, const crate::lower::model::Ex& p_) { return prism_rtl::deref(f) && is_text_piece(p_); })
            ? prism_rtl::cat("Text::lit(", cpp_string(concat(each(parts, [&](const crate::lower::model::Ex& p_) { return text_piece(p_); }))), ")")
            : cpp_format(cp, parts, Text::lit("prism_rtl::cat"));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMatch>(x)) {
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a0;
        auto&& arms = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a1;
        auto&& fallback = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a2;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a3;
        return crate::emit::cpp::patterns::cpp_match(cp, prism_rtl::deref(prism_rtl::deref(s)), arms, t);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XChain>(x)) {
        auto&& label = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a0;
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a1;
        auto&& arms = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a2;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a3;
        return crate::emit::cpp::patterns::cpp_match(cp, prism_rtl::deref(prism_rtl::deref(s)), arms, t);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIf>(x)) {
        auto&& c = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a2;
        return cpp_if(cp, prism_rtl::deref(prism_rtl::deref(c)), prism_rtl::deref(prism_rtl::deref(t)), prism_rtl::deref(prism_rtl::deref(e)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x)) {
        auto&& m3254_47_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        if (m3254_47_0.size() == 0u) {
            return cpp_expr(cp, prism_rtl::deref(prism_rtl::deref(e)));
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x)) {
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        auto [st, cp2] = crate::emit::cpp::stmts::cpp_statements_cp(cp, dos);
        return crate::emit::cpp::templates::items::stmt_expr(st, crate::emit::cpp::stmts::unvexed(cpp_expr(with_move_captures(cp2, dos, prism_rtl::deref(prism_rtl::deref(e))), prism_rtl::deref(prism_rtl::deref(e)))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XLabeled>(x)) {
        auto&& label = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a0;
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a2;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a3;
        return crate::emit::cpp::patterns::cpp_labeled(cp, label, dos, prism_rtl::deref(prism_rtl::deref(e)), t);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClosure>(x)) {
        auto&& mv = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a2;
        return cpp_closure(cp, mv, ps, prism_rtl::deref(prism_rtl::deref(body)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTry>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTry>(x).a0;
        return prism_rtl::cat("TRY(", cpp_expr(cp, prism_rtl::deref(prism_rtl::deref(y))), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XField>(x).a1;
        return cpp_field(cp, prism_rtl::deref(prism_rtl::deref(r)), f);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x)) {
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a0;
        auto&& k = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a1;
        return prism_rtl::cat("std::get<", k, ">(", as_value(cp, prism_rtl::deref(prism_rtl::deref(r))), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDecode>(x)) {
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XDecode>(x).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDecode>(x).a1;
        return prism_rtl::cat("TRY(prism_rtl::from_pod<", crate::emit::cpp::cpp_type(cp, t), ">(", cpp_expr(cp, prism_rtl::deref(prism_rtl::deref(y))), "))");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCast>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XCast>(x).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XCast>(x).a1;
        return prism_rtl::cat("static_cast<", crate::emit::cpp::cpp_type(cp, t), ">(", cpp_expr(cp, prism_rtl::deref(prism_rtl::deref(y))), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTyped>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTyped>(x).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XTyped>(x).a1;
        auto e = cpp_expr(cp, prism_rtl::deref(prism_rtl::deref(y)));
        return (e == Text::lit("{}")) || (e == Text::lit("std::nullopt"))
            ? prism_rtl::cat(crate::emit::cpp::cpp_type(cp, t), "{}")
            : is_ctor(prism_rtl::deref(prism_rtl::deref(y)), Text::lit("Ok")) || is_ctor(prism_rtl::deref(prism_rtl::deref(y)), Text::lit("Err"))
            ? prism_rtl::cat(crate::emit::cpp::cpp_type(cp, t), "(", e, ")")
            : e;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> CppExpr::cycle() const {
    const auto& cp = this->cp;
    const auto& x = this->x;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XVar>(x) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(x).a0;
        prism_rtl::finished(cpp_var(cp, n));
    })
        : prism_rtl::is<crate::lower::model::Ex::XPath>(x) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XPath>(x).a0;
        prism_rtl::finished(path_value(cp, p_));
    })
        : prism_rtl::is<crate::lower::model::Ex::XSelf>(x) ? prism_rtl::finished(Text::lit("prism_rtl::share(this)"))
        : prism_rtl::is<crate::lower::model::Ex::XCx>(x) ? prism_rtl::finished(Text::lit("cx"))
        : prism_rtl::is<crate::lower::model::Ex::XConst>(x) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XConst>(x).a0;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<crate::lower::model::Ex::XUnit>(x) ? prism_rtl::finished(Text::lit("Unit{}"))
        : prism_rtl::is<crate::lower::model::Ex::XNone>(x) ? prism_rtl::finished(Text::lit("std::nullopt"))
        : prism_rtl::is<crate::lower::model::Ex::XBool>(x) ? ({
        auto&& b = prism_rtl::as<crate::lower::model::Ex::XBool>(x).a0;
        prism_rtl::deref(b)
        ? prism_rtl::finished(Text::lit("true"))
        : prism_rtl::finished(Text::lit("false"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XNat>(x) ? ({
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XNat>(x).a0;
        len_text(d) <= Nat(9u)
        ? prism_rtl::finished(prism_rtl::cat("Nat(", d, "u)"))
        : ({
        auto cp_1 = cp;
        auto d_2 = d;
        call_then(start_cpp_expr(cp_1, crate::lower::model::Ex(crate::lower::model::Ex::XInt{d_2})), [=](Text cpp_expr_3535) { return prism_rtl::finished(prism_rtl::cat("*Nat::from_int(", cpp_expr_3535, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XInt>(x) ? ({
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XInt>(x).a0;
        len_text(crate::syntax::lexer::chars::has_prefix(d, Text::lit("-"))
        ? crate::syntax::lexer::chars::after_first(d)
        : d) <= Nat(18u)
        ? prism_rtl::finished(prism_rtl::cat("Int(", d, "ll)"))
        : prism_rtl::finished(prism_rtl::cat("*Int::parse(\"", d, "\")"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XByte>(x) ? ({
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XByte>(x).a0;
        prism_rtl::finished(prism_rtl::cat("std::uint8_t(", d, ")"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XFloat>(x) ? ({
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XFloat>(x).a0;
        prism_rtl::finished(prism_rtl::cat("Float{", d, "}"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIndex>(x) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XIndex>(x).a0;
        prism_rtl::finished(prism_rtl::cat(n, "u"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XChar>(x) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Ex::XChar>(x).a0;
        prism_rtl::finished(prism_rtl::cat("U\'", cpp_char_escape(c), "\'"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XStr>(x) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XStr>(x).a0;
        prism_rtl::finished(cpp_string(t));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRegex>(x) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XRegex>(x).a0;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XRegex>(x).a1;
        prism_rtl::finished(prism_rtl::cat("([]() -> const Regex& { static const Regex r = Regex::lit(", cpp_string(p_), ", ", cpp_string(f), "); return r; }())"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XReplacement>(x) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x).a0;
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x).a1;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x).a2;
        prism_rtl::finished(prism_rtl::cat("([]() -> const RegexReplacement& { static const RegexReplacement r = RegexReplacement::lit(", cpp_string(p_), ", ", cpp_string(f), ", ", cpp_string(r), "); return r; }())"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRef>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRef>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppPlace(cp, prism_rtl::deref(prism_rtl::deref(y)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRefMut>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRefMut>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppPlace(cp, prism_rtl::deref(prism_rtl::deref(y)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XDeref>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDeref>(x).a0;
        ({
        auto&& _m = ex_ty(cp, prism_rtl::deref(prism_rtl::deref(y)));
        prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::model::OutTy::OutRc>(prism_rtl::some_of(_m)) ? ({
        auto cp_1 = cp;
        auto y_2 = prism_rtl::deref(prism_rtl::deref(y));
        call_then(start_cpp_tight_place(cp_1, y_2), [=](Text cpp_tight_place_4820) { return prism_rtl::finished(prism_rtl::cat("*", cpp_tight_place_4820)); });
    })
        : prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::model::OutTy::OutRef>(prism_rtl::some_of(_m)) ? prism_rtl::more(prism_rtl::rc(CppPlace(cp, prism_rtl::deref(prism_rtl::deref(y)))))
        : ({
        auto cp_1 = cp;
        auto y_2 = prism_rtl::deref(prism_rtl::deref(y));
        call_then(start_cpp_place(cp_1, y_2), [=](Text cpp_place_4922) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::deref(", cpp_place_4922, ")")); });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTarget>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTarget>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppPlace(cp, prism_rtl::deref(prism_rtl::deref(y)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XClone>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XClone>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppPlace(cp, prism_rtl::deref(prism_rtl::deref(y)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XWeak>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XWeak>(x).a0;
        ({
        auto cp_1 = cp;
        auto y_2 = prism_rtl::deref(prism_rtl::deref(y));
        call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_5032) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::weaken(", cpp_expr_5032, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x).a0;
        ({
        auto cp_1 = cp;
        auto y_2 = prism_rtl::deref(prism_rtl::deref(y));
        call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_5086) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::upgrade(", cpp_expr_5086, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XBreak>(x) ? ({
        auto&& l = prism_rtl::as<crate::lower::model::Ex::XBreak>(x).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XBreak>(x).a1;
        ({
        auto cp_1 = cp;
        auto l_2 = l;
        auto y_3 = prism_rtl::deref(prism_rtl::deref(y));
        call_then(crate::emit::cpp::patterns::start_cpp_break(cp_1, l_2, y_3), [=](Text cpp_break_5123) { return prism_rtl::finished(prism_rtl::cat("(", cpp_break_5123, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(x) ? prism_rtl::finished(Text::lit("({ break; })"))
        : prism_rtl::is<crate::lower::model::Ex::XLater>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XLater>(x).a0;
        ({
        auto cp_1 = cp;
        auto y_2 = prism_rtl::deref(prism_rtl::deref(y));
        call_then(start_cpp_expr(crate::emit::cpp::stmts::captured(cp_1), y_2), [=](Text cpp_expr_5216) { return prism_rtl::finished(prism_rtl::cat("[=](Cx& cx) -> Done { ", cpp_expr_5216, "; return {}; }")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XFormatStr>(x) ? ({
        auto&& parts = prism_rtl::as<crate::lower::model::Ex::XFormatStr>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppFormat(cp, parts, Text::lit("prism_rtl::str"))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIsCase>(x) && ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a0;
        auto&& m3254_28_1 = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a1;
        (m3254_28_1.size() == 0u);
    }) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a0;
        auto&& m3254_28_1 = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a1;
        prism_rtl::finished(Text::lit("false"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIsCase>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a0;
        auto&& cs = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a1;
        ({
        auto cp_1 = cp;
        auto cs_2 = cs;
        auto y_3 = prism_rtl::deref(prism_rtl::deref(y));
        call_value(each_job(cs_2, ({
        auto cp_1_4 = cp_1;
        auto y_3_4 = y_3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=, cp_1_4 = std::move(cp_1_4), y_3_4 = std::move(y_3_4)](Text p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto y_3_4_4 = y_3_4;
            entered(once_job([=, cp_1_4_4 = std::move(cp_1_4_4), y_3_4_4 = std::move(y_3_4_4)]() {
            return ({
                auto c = p0;
                call_then(start_cpp_tight_place(cp_1_4_4, y_3_4_4), [=, c = std::move(c)](Text cpp_tight_place_5408) { return prism_rtl::finished(case_test(cp_1_4_4, c, cpp_tight_place_5408)); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_5377) { return prism_rtl::finished(prism_rtl::cat("(", crate::syntax::lexer::chars::join(each_5377, Text::lit(" || ")), ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XRefusal>(x) ? ({
        auto&& what = prism_rtl::as<crate::lower::model::Ex::XRefusal>(x).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), crate::lower::expr::escape(what), "\")"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XUnreachable>(x) ? prism_rtl::finished(Text::lit("throw prism_rtl::Panic(\"entered unreachable code\")"))
        : prism_rtl::is<crate::lower::model::Ex::XCall>(x) ? ({
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XCall>(x).a0;
        auto&& args = prism_rtl::as<crate::lower::model::Ex::XCall>(x).a1;
        prism_rtl::more(prism_rtl::rc(CppCall(cp, f, args)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XApply>(x) ? ({
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XApply>(x).a0;
        auto&& args = prism_rtl::as<crate::lower::model::Ex::XApply>(x).a1;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        auto f_3 = prism_rtl::deref(prism_rtl::deref(f));
        call_then(start_cpp_tight_place(cp_2, f_3), [=, args_1 = std::move(args_1)](Text cpp_tight_place_5647) { return call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_5669) { return prism_rtl::finished(prism_rtl::cat(cpp_tight_place_5647, "(", cpp_args_5669, ")")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XMethod>(x) ? ({
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a0;
        auto&& m = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a1;
        auto&& args = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a2;
        prism_rtl::more(prism_rtl::rc(CppMethod(cp, prism_rtl::deref(prism_rtl::deref(r)), m, args)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBin>(x) ? ({
        auto&& op = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a0;
        auto&& l = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a1;
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a2;
        ({
        auto cp_1 = cp;
        auto l_2 = prism_rtl::deref(prism_rtl::deref(l));
        auto op_3 = op;
        auto r_4 = prism_rtl::deref(prism_rtl::deref(r));
        call_then(start_cpp_arg_list(cp_1, Array(std::vector{l_2, r_4})), [=, op_3 = std::move(op_3)](Array<Text> cpp_arg_list_5788) {
        return ({
            auto [lt, rt] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Text, Text>> _v;
                {
                    auto&& m5782_0 = cpp_arg_list_5788;
                    if (m5782_0.size() == 2u) {
                        {
                            auto&& _c2 = index(m5782_0, Nat(0u));
                            if (prism_rtl::is_some(_c2)) {
                                auto&& a = prism_rtl::some_of(_c2);
                                {
                                    auto&& _c1 = index(m5782_0, Nat(1u));
                                    if (prism_rtl::is_some(_c1)) {
                                        auto&& b = prism_rtl::some_of(_c1);
                                        _v.set(std::tuple{a, b});
                                        goto _done;
                                    }
                                }
                            }
                        }
                    }
                }
                {
                    _v.set(std::tuple{Text::lit(""), Text::lit("")});
                    goto _done;
                }
            _done:
                _v.take();
            });
            (prism_rtl::finished(prism_rtl::cat(cpp_loose(l_2) ? prism_rtl::cat("(", lt, ")") : lt, " ", op_3, " ", cpp_loose(r_4) ? prism_rtl::cat("(", rt, ")") : rt)));
        });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XUnary>(x) ? ({
        auto&& op = prism_rtl::as<crate::lower::model::Ex::XUnary>(x).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XUnary>(x).a1;
        ({
        auto cp_1 = cp;
        auto op_2 = op;
        auto y_3 = prism_rtl::deref(prism_rtl::deref(y));
        call_then(start_cpp_tight(cp_1, y_3), [=, op_2 = std::move(op_2)](Text cpp_tight_5987) { return prism_rtl::finished(prism_rtl::cat(op_2, cpp_tight_5987)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XCtor>(x) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a0;
        auto&& args = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a1;
        prism_rtl::more(prism_rtl::rc(CppCtor(cp, p_, args)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRecord>(x) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XRecord>(x).a0;
        auto&& fs = prism_rtl::as<crate::lower::model::Ex::XRecord>(x).a1;
        prism_rtl::more(prism_rtl::rc(CppRecord(cp, p_, fs)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XTuple>(x) ? ({
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XTuple>(x).a0;
        ({
        auto cp_1 = cp;
        auto xs_2 = xs;
        call_then(start_cpp_args(cp_1, xs_2), [=](Text cpp_args_6111) { return prism_rtl::finished(prism_rtl::cat("std::tuple{", cpp_args_6111, "}")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XVec>(x) && ({
        auto&& m3254_40_0 = prism_rtl::as<crate::lower::model::Ex::XVec>(x).a0;
        (m3254_40_0.size() == 0u);
    }) ? ({
        auto&& m3254_40_0 = prism_rtl::as<crate::lower::model::Ex::XVec>(x).a0;
        prism_rtl::finished(Text::lit("{}"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XVec>(x) ? ({
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XVec>(x).a0;
        ({
        auto cp_1 = cp;
        auto xs_2 = xs;
        call_then(start_cpp_args(cp_1, xs_2), [=](Text cpp_args_6180) { return prism_rtl::finished(prism_rtl::cat("std::vector{", cpp_args_6180, "}")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XText>(x) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XText>(x).a0;
        prism_rtl::finished(prism_rtl::cat("Text::lit(", cpp_string(t), ")"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XFormat>(x) ? ({
        auto&& parts = prism_rtl::as<crate::lower::model::Ex::XFormat>(x).a0;
        fold(parts, true, [&](const bool& f, const crate::lower::model::Ex& p_) { return prism_rtl::deref(f) && is_text_piece(p_); })
        ? prism_rtl::finished(prism_rtl::cat("Text::lit(", cpp_string(concat(each(parts, [&](const crate::lower::model::Ex& p_) { return text_piece(p_); }))), ")"))
        : prism_rtl::more(prism_rtl::rc(CppFormat(cp, parts, Text::lit("prism_rtl::cat"))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XMatch>(x) ? ({
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a0;
        auto&& arms = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a1;
        auto&& fallback = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a2;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a3;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::patterns::CppMatch(cp, prism_rtl::deref(prism_rtl::deref(s)), arms, t)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XChain>(x) ? ({
        auto&& label = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a0;
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a1;
        auto&& arms = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a2;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a3;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::patterns::CppMatch(cp, prism_rtl::deref(prism_rtl::deref(s)), arms, t)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIf>(x) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a2;
        prism_rtl::more(prism_rtl::rc(CppIf(cp, prism_rtl::deref(prism_rtl::deref(c)), prism_rtl::deref(prism_rtl::deref(t)), prism_rtl::deref(prism_rtl::deref(e)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBlock>(x) && ({
        auto&& m3254_47_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        (m3254_47_0.size() == 0u);
    }) ? ({
        auto&& m3254_47_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, prism_rtl::deref(prism_rtl::deref(e)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBlock>(x) ? ({
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        ({
        auto cp_1 = cp;
        auto dos_2 = dos;
        auto e_3 = prism_rtl::deref(prism_rtl::deref(e));
        call_then(crate::emit::cpp::stmts::start_cpp_statements_cp(cp_1, dos_2), [=, e_3 = std::move(e_3)](std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp_6642) {
        return ({
            auto [st, cp2] = cpp_statements_cp_6642;
            call_then(start_with_move_captures(cp2, dos_2, e_3), [=](crate::emit::cpp::Cp with_move_captures_6706) { return call_then(start_cpp_expr(with_move_captures_6706, e_3), [=](Text cpp_expr_6697) { return prism_rtl::finished(crate::emit::cpp::templates::items::stmt_expr(st, crate::emit::cpp::stmts::unvexed(cpp_expr_6697))); }); });
        });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XLabeled>(x) ? ({
        auto&& label = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a0;
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a2;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a3;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::patterns::CppLabeled(cp, label, dos, prism_rtl::deref(prism_rtl::deref(e)), t)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XClosure>(x) ? ({
        auto&& mv = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a2;
        prism_rtl::more(prism_rtl::rc(CppClosure(cp, prism_rtl::deref(mv), ps, prism_rtl::deref(prism_rtl::deref(body)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XTry>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTry>(x).a0;
        ({
        auto cp_1 = cp;
        auto y_2 = prism_rtl::deref(prism_rtl::deref(y));
        call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_6877) { return prism_rtl::finished(prism_rtl::cat("TRY(", cpp_expr_6877, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XField>(x) ? ({
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XField>(x).a1;
        prism_rtl::more(prism_rtl::rc(CppField(cp, prism_rtl::deref(prism_rtl::deref(r)), f)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XPart>(x) ? ({
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a0;
        auto&& k = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a1;
        ({
        auto cp_1 = cp;
        auto k_2 = k;
        auto r_3 = prism_rtl::deref(prism_rtl::deref(r));
        call_then(start_as_value(cp_1, r_3), [=, k_2 = std::move(k_2)](Text as_value_6961) { return prism_rtl::finished(prism_rtl::cat("std::get<", k_2, ">(", as_value_6961, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XDecode>(x) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XDecode>(x).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDecode>(x).a1;
        ({
        auto cp_1 = cp;
        auto t_2 = t;
        auto y_3 = prism_rtl::deref(prism_rtl::deref(y));
        call_then(crate::emit::cpp::start_cpp_type(cp_1, t_2), [=, y_3 = std::move(y_3)](Text cpp_type_7022) { return call_then(start_cpp_expr(cp_1, y_3), [=](Text cpp_expr_7039) { return prism_rtl::finished(prism_rtl::cat("TRY(prism_rtl::from_pod<", cpp_type_7022, ">(", cpp_expr_7039, "))")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XCast>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XCast>(x).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XCast>(x).a1;
        ({
        auto cp_1 = cp;
        auto t_2 = t;
        auto y_3 = prism_rtl::deref(prism_rtl::deref(y));
        call_then(crate::emit::cpp::start_cpp_type(cp_1, t_2), [=, y_3 = std::move(y_3)](Text cpp_type_7087) { return call_then(start_cpp_expr(cp_1, y_3), [=](Text cpp_expr_7104) { return prism_rtl::finished(prism_rtl::cat("static_cast<", cpp_type_7087, ">(", cpp_expr_7104, ")")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTyped>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTyped>(x).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XTyped>(x).a1;
        ({
        auto cp_1 = cp;
        auto t_2 = t;
        auto y_3 = prism_rtl::deref(prism_rtl::deref(y));
        call_then(start_cpp_expr(cp_1, y_3), [=, t_2 = std::move(t_2)](Text cpp_expr_7154) {
        return ({
            auto e = cpp_expr_7154;
            (e == Text::lit("{}")) || (e == Text::lit("std::nullopt"))
            ? call_then(crate::emit::cpp::start_cpp_type(cp_1, t_2), [=](Text cpp_type_7217) { return prism_rtl::finished(prism_rtl::cat(cpp_type_7217, "{}")); })
            : is_ctor(y_3, Text::lit("Ok")) || is_ctor(y_3, Text::lit("Err"))
            ? call_then(crate::emit::cpp::start_cpp_type(cp_1, t_2), [=](Text cpp_type_7293) { return prism_rtl::finished(prism_rtl::cat(cpp_type_7293, "(", e, ")")); })
            : prism_rtl::finished(e);
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CppExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_expr(crate::emit::cpp::Cp cp, crate::lower::model::Ex x) {
    return prism_rtl::make_rc<CppExpr>(cp, x);
}


/// CppString: fn Text -> Text
Text cpp_string(const Text& t) {
    return crate::syntax::lexer::chars::contains(t, Text::lit("\000"sv))
        ? prism_rtl::cat("\"", cpp_escape(t), "\"sv")
        : prism_rtl::cat("\"", cpp_escape(t), "\"");
}


/// CppEscape: fn Text -> Text
Text cpp_escape(const Text& t) {
    return crate::syntax::lexer::chars::map_chars(t, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return once_job([=]() {
            return ({
                auto c = p0;
                c == Text::lit("\000"sv)
                ? prism_rtl::finished(Text::lit("\\000"))
                : prism_rtl::finished(crate::lower::expr::char_escape(c));
            });
        });
    })));
}


/// IsTextPiece: fn Ex -> Bool
bool is_text_piece(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XText>(ex0)) {
        return true;
    }
    {
        auto&& other = ex0;
        return false;
    }
}


/// TextPiece: fn Ex -> Text
Text text_piece(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XText>(ex0)) {
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XText>(ex0).a0;
        return t;
    }
    {
        auto&& other = ex0;
        return Text::lit("");
    }
}


/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
Text cpp_format(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Ex>& parts, const Text& how) {
    return prism_rtl::cat(how, "(", crate::syntax::lexer::chars::join(cpp_arg_list(cp, each(parts, [&](const crate::lower::model::Ex& p_) { return format_arg(p_); })), Text::lit(", ")), ")");
}


prism_rtl::Turn<Text> CppFormat::cycle() const {
    const auto& cp = this->cp;
    const auto& parts = this->parts;
    const auto& how = this->how;
    auto cp_1 = cp;
    auto how_2 = how;
    auto parts_3 = parts;
    return call_then(start_cpp_arg_list(cp_1, each(parts_3, [&](const crate::lower::model::Ex& p_) { return format_arg(p_); })), [=](Array<Text> cpp_arg_list_8085) { return prism_rtl::finished(prism_rtl::cat(how_2, "(", crate::syntax::lexer::chars::join(cpp_arg_list_8085, Text::lit(", ")), ")")); });
}


/// `Start CppFormat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_format(crate::emit::cpp::Cp cp, Array<crate::lower::model::Ex> parts, Text how) {
    return prism_rtl::make_rc<CppFormat>(cp, parts, how);
}


/// FormatArg: fn Ex -> Ex
crate::lower::model::Ex format_arg(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XText>(ex0)) {
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XText>(ex0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XStr{t});
    }
    {
        auto&& x = ex0;
        return x;
    }
}


/// CppCharEscape: fn Text -> Text
Text cpp_char_escape(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("\'")) {
            return Text::lit("\\\'");
        }
    }
    {
        auto&& c = text0;
        return crate::lower::expr::char_escape(c);
    }
}


/// PathValue: fn Cp, Text -> Text
Text path_value(const crate::emit::cpp::Cp& cp, const Text& p_) {
    return is_node_method(cp, p_)
        ? prism_rtl::cat("&", crate::emit::cpp::type_path(crate::emit::cpp::parent_path(p_)), "::", node_method_name(cp, crate::emit::cpp::last_segment(p_)))
        : ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::emit::cpp::case_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& ty = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(crate::emit::cpp::type_path(ty), "(", crate::emit::cpp::type_path(p_), "{})"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = crate::emit::cpp::type_of(cp, p_);
                if (prism_rtl::is_some(_m)) {
                    auto&& info = prism_rtl::some_of(_m);
                    _v.set(prism_rtl::deref(info).kind == Text::lit("unit")
                        ? prism_rtl::cat(crate::emit::cpp::type_path(p_), "{}")
                        : crate::emit::cpp::type_path(p_));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::emit::cpp::type_path(p_));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// IsNodeMethod: fn Cp, Text -> Bool
bool is_node_method(const crate::emit::cpp::Cp& cp, const Text& p_) {
    auto named_ = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::prelude::get(cp.methods, crate::emit::cpp::last_segment(p_));
        if (prism_rtl::is_some(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return std::move(named_) && is_node_type(cp, crate::emit::cpp::parent_path(p_));
}


/// IsNodeType: fn Cp, Text -> Bool
bool is_node_type(const crate::emit::cpp::Cp& cp, const Text& p_) {
    auto&& _m = crate::emit::cpp::type_of(cp, p_);
    if (prism_rtl::is_some(_m)) {
        auto&& info = prism_rtl::some_of(_m);
        return prism_rtl::deref(info).kind == Text::lit("node");
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CppField: unbounded fn Cp, Ex, Text -> Text
Text cpp_field(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& ex1, const Text& f) {
    if (prism_rtl::is<crate::lower::model::Ex::XSelf>(ex1)) {
        return prism_rtl::cat("this->", crate::emit::cpp::field_id(f));
    }
    {
        auto&& r = ex1;
        auto name = is_digits(f) ? prism_rtl::cat("a", f) : crate::emit::cpp::field_id(f);
        auto&& _m = pointer(cp, r);
        if (prism_rtl::is_some(_m)) {
            auto&& b = prism_rtl::some_of(_m);
            return prism_rtl::cat(cpp_tight_place(cp, r), b ? Text::lit("->") : Text::lit("."), name);
        }
        if (prism_rtl::is_none(_m)) {
            auto&& _m = crate::prelude::get(cp.members, f);
            if (prism_rtl::is_some(_m)) {
                return prism_rtl::cat(cpp_tight_place(cp, r), "->", name);
            }
            if (prism_rtl::is_none(_m)) {
                return prism_rtl::cat(as_value(cp, r), ".", name);
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<Text> CppField::cycle() const {
    const auto& cp = this->cp;
    const auto& ex1 = this->ex1;
    const auto& f = this->f;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XSelf>(ex1) ? prism_rtl::finished(prism_rtl::cat("this->", crate::emit::cpp::field_id(f)))
        : ({
        auto&& r = ex1;
        ({
        auto name = is_digits(f) ? prism_rtl::cat("a", f) : crate::emit::cpp::field_id(f);
        ({
        auto&& _m = pointer(cp, r);
        prism_rtl::is_some(_m) ? ({
        auto&& b = prism_rtl::some_of(_m);
        ({
        auto cp_1 = cp;
        auto r_2 = r;
        call_then(start_cpp_tight_place(cp_1, r_2), [=](Text cpp_tight_place_9818) { return prism_rtl::finished(prism_rtl::cat(cpp_tight_place_9818, b ? Text::lit("->") : Text::lit("."), name)); });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(cp).members, f);
        prism_rtl::is_some(_m) ? ({
        auto cp_1 = cp;
        auto r_2 = r;
        call_then(start_cpp_tight_place(cp_1, r_2), [=](Text cpp_tight_place_9926) { return prism_rtl::finished(prism_rtl::cat(cpp_tight_place_9926, "->", name)); });
    })
        : prism_rtl::is_none(_m) ? ({
        auto cp_1 = cp;
        auto r_2 = r;
        call_then(start_as_value(cp_1, r_2), [=](Text as_value_9975) { return prism_rtl::finished(prism_rtl::cat(as_value_9975, ".", name)); });
    })
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    });
    });
}


/// `Start CppField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_field(crate::emit::cpp::Cp cp, crate::lower::model::Ex ex1, Text f) {
    return prism_rtl::make_rc<CppField>(cp, ex1, f);
}


/// AsValue: unbounded fn Cp, Ex -> Text
Text as_value(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& r) {
    auto&& _m = pointer(cp, r);
    if (prism_rtl::is_some(_m) && !prism_rtl::some_of(_m)) {
        return cpp_tight_place(cp, r);
    }
    {
        return prism_rtl::cat("prism_rtl::deref(", cpp_place(cp, r), ")");
    }
}


prism_rtl::Turn<Text> AsValue::cycle() const {
    const auto& cp = this->cp;
    const auto& r = this->r;
    return ({
        auto&& _m = pointer(cp, r);
        prism_rtl::is_some(_m) && !prism_rtl::some_of(_m) ? prism_rtl::more(prism_rtl::rc(CppTightPlace(cp, r)))
        : ({
        auto cp_1 = cp;
        auto r_2 = r;
        call_then(start_cpp_place(cp_1, r_2), [=](Text cpp_place_10258) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::deref(", cpp_place_10258, ")")); });
    });
    });
}


/// `Start AsValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_as_value(crate::emit::cpp::Cp cp, crate::lower::model::Ex r) {
    return prism_rtl::make_rc<AsValue>(cp, r);
}


/// ?ExTy: fn Cp, Ex -> ?OutTy
std::optional<crate::lower::model::OutTy> ex_ty(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x)) {
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(x).a0;
        return crate::prelude::get(cp.local_types, n);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        auto&& m10495_1_0 = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XField>(x).a1;
        if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m10495_1_0)))) {
            return crate::prelude::get(cp.fields, f);
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        auto&& m10495_2_0 = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XField>(x).a1;
        if (prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m10495_2_0)))) {
            auto&& m10495_2_0_r_0 = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m10495_2_0))).a0;
            if (m10495_2_0_r_0 == Text::lit("node")) {
                return crate::prelude::get(cp.fields, f);
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRef>(x).a0;
        auto&& _m = ex_ty(cp, prism_rtl::deref(prism_rtl::deref(y)));
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            return std::optional(crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(t)}));
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::lower::model::OutTy>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDeref>(x).a0;
        auto&& _m = ex_ty(cp, prism_rtl::deref(prism_rtl::deref(y)));
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::model::OutTy::OutRef>(prism_rtl::some_of(_m))) {
            auto&& t = prism_rtl::as<crate::lower::model::OutTy::OutRef>(prism_rtl::some_of(_m)).a0;
            return std::optional(prism_rtl::deref(t));
        }
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::model::OutTy::OutRc>(prism_rtl::some_of(_m))) {
            auto&& t = prism_rtl::as<crate::lower::model::OutTy::OutRc>(prism_rtl::some_of(_m)).a0;
            return std::optional(prism_rtl::deref(t));
        }
        {
            return std::optional<crate::lower::model::OutTy>{};
        }
    }
    {
        return std::optional<crate::lower::model::OutTy>{};
    }
}


/// IsDigits: fn Text -> Bool
bool is_digits(const Text& t) {
    return (t != Text::lit("")) && crate::syntax::lexer::chars::fold_chars(t, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=](std::tuple<bool, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto ok_ = p0;
                auto c = p1;
                (prism_rtl::finished(std::move(ok_) && crate::syntax::lexer::chars::contains(Text::lit("0123456789"), c)));
            });
        });
    })));
}


/// CppCtor: unbounded fn Cp, Text, [Ex] -> Text
Text cpp_ctor(const crate::emit::cpp::Cp& cp, const Text& p_, const Array<crate::lower::model::Ex>& args) {
    {
        auto&& m11127_0 = p_;
        if (m11127_0 == Text::lit("Some")) {
            return prism_rtl::cat("std::optional(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m11127_1 = p_;
        if (m11127_1 == Text::lit("Ok")) {
            return args == Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})
                ? Text::lit("prism_rtl::ok()")
                : cpp_args(cp, args);
        }
    }
    {
        auto&& m11127_2 = p_;
        if (m11127_2 == Text::lit("Err")) {
            return prism_rtl::cat("unexpected(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m11127_3 = p_;
        if (m11127_3 == Text::lit("prism_rtl::Turn::More")) {
            return prism_rtl::cat("prism_rtl::more(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m11127_4 = p_;
        if (m11127_4 == Text::lit("prism_rtl::Turn::Finished")) {
            return prism_rtl::cat("prism_rtl::finished(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m11127_5 = p_;
        if (m11127_5 == Text::lit("Outcome::Fired")) {
            return prism_rtl::cat("Outcome::fired(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m11127_6 = p_;
        if (m11127_6 == Text::lit("Outcome::Value")) {
            return prism_rtl::cat("Outcome::value(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m11127_7 = p_;
        if (m11127_7 == Text::lit("Segment::Pos")) {
            return prism_rtl::cat("Segment::pos(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m11127_8 = p_;
        if (m11127_8 == Text::lit("Segment::Gen")) {
            return prism_rtl::cat("Segment::gen(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m11127_9 = p_;
        if (m11127_9 == Text::lit("Segment::Key")) {
            return prism_rtl::cat("Segment::key(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& _m = crate::emit::cpp::case_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& ty = prism_rtl::some_of(_m);
            return prism_rtl::cat(crate::emit::cpp::type_path(ty), "(", crate::emit::cpp::type_path(p_), "{", cpp_args(cp, args), "})");
        }
        if (prism_rtl::is_none(_m)) {
            return prism_rtl::cat(crate::emit::cpp::type_path(p_), "{", cpp_args(cp, args), "}");
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<Text> CppCtor::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& args = this->args;
    return ({
        ({
        auto&& m11127_0 = p_;
        (m11127_0 == Text::lit("Some"));
    }) ? ({
        auto&& m11127_0 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_11164) { return prism_rtl::finished(prism_rtl::cat("std::optional(", cpp_args_11164, ")")); });
    });
    })
        : ({
        auto&& m11127_1 = p_;
        (m11127_1 == Text::lit("Ok"));
    }) ? ({
        auto&& m11127_1 = p_;
        args == Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})
        ? prism_rtl::finished(Text::lit("prism_rtl::ok()"))
        : prism_rtl::more(prism_rtl::rc(CppArgs(cp, args)));
    })
        : ({
        auto&& m11127_2 = p_;
        (m11127_2 == Text::lit("Err"));
    }) ? ({
        auto&& m11127_2 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_11281) { return prism_rtl::finished(prism_rtl::cat("unexpected(", cpp_args_11281, ")")); });
    });
    })
        : ({
        auto&& m11127_3 = p_;
        (m11127_3 == Text::lit("prism_rtl::Turn::More"));
    }) ? ({
        auto&& m11127_3 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_11348) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::more(", cpp_args_11348, ")")); });
    });
    })
        : ({
        auto&& m11127_4 = p_;
        (m11127_4 == Text::lit("prism_rtl::Turn::Finished"));
    }) ? ({
        auto&& m11127_4 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_11423) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::finished(", cpp_args_11423, ")")); });
    });
    })
        : ({
        auto&& m11127_5 = p_;
        (m11127_5 == Text::lit("Outcome::Fired"));
    }) ? ({
        auto&& m11127_5 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_11482) { return prism_rtl::finished(prism_rtl::cat("Outcome::fired(", cpp_args_11482, ")")); });
    });
    })
        : ({
        auto&& m11127_6 = p_;
        (m11127_6 == Text::lit("Outcome::Value"));
    }) ? ({
        auto&& m11127_6 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_11541) { return prism_rtl::finished(prism_rtl::cat("Outcome::value(", cpp_args_11541, ")")); });
    });
    })
        : ({
        auto&& m11127_7 = p_;
        (m11127_7 == Text::lit("Segment::Pos"));
    }) ? ({
        auto&& m11127_7 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_11596) { return prism_rtl::finished(prism_rtl::cat("Segment::pos(", cpp_args_11596, ")")); });
    });
    })
        : ({
        auto&& m11127_8 = p_;
        (m11127_8 == Text::lit("Segment::Gen"));
    }) ? ({
        auto&& m11127_8 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_11651) { return prism_rtl::finished(prism_rtl::cat("Segment::gen(", cpp_args_11651, ")")); });
    });
    })
        : ({
        auto&& m11127_9 = p_;
        (m11127_9 == Text::lit("Segment::Key"));
    }) ? ({
        auto&& m11127_9 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_11706) { return prism_rtl::finished(prism_rtl::cat("Segment::key(", cpp_args_11706, ")")); });
    });
    })
        : ({
        auto&& _m = crate::emit::cpp::case_of(cp, p_);
        prism_rtl::is_some(_m) ? ({
        auto&& ty = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        auto p__3 = p_;
        call_then(start_cpp_args(cp_2, args_1), [=, p__3 = std::move(p__3)](Text cpp_args_11806) { return prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::type_path(ty), "(", crate::emit::cpp::type_path(p__3), "{", cpp_args_11806, "})")); });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto args_1 = args;
        auto cp_2 = cp;
        auto p__3 = p_;
        call_then(start_cpp_args(cp_2, args_1), [=, p__3 = std::move(p__3)](Text cpp_args_11857) { return prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::type_path(p__3), "{", cpp_args_11857, "}")); });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start CppCtor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_ctor(crate::emit::cpp::Cp cp, Text p_, Array<crate::lower::model::Ex> args) {
    return prism_rtl::make_rc<CppCtor>(cp, p_, args);
}


/// CppRecord: unbounded fn Cp, Text, [((Text, Ex))] -> Text
Text cpp_record(const crate::emit::cpp::Cp& cp, const Text& p_, const Array<std::tuple<Text, crate::lower::model::Ex>>& fs) {
    auto ordered = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
        auto&& _m = crate::emit::cpp::type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(each(prism_rtl::deref(info).fields, [&](const Text& f) {
                return or_(fold(fs, std::optional<crate::lower::model::Ex>{}, [&](const std::optional<crate::lower::model::Ex>& found_opt, const std::tuple<Text, crate::lower::model::Ex>& _p1) {
                    auto&& g = std::get<0>(_p1);
                    auto&& v_ = std::get<1>(_p1);
                    return g == f ? std::optional(v_) : found_opt;
                }), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(each(fs, [&](const std::tuple<Text, crate::lower::model::Ex>& _p0) {
                auto&& v_ = std::get<1>(_p0);
                return v_;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto names = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = crate::emit::cpp::type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(info).fields);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(each(fs, [&](const std::tuple<Text, crate::lower::model::Ex>& _p0) {
                auto&& g = std::get<0>(_p0);
                return g;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto kind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::emit::cpp::type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(info).kind);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto values_ = cpp_arg_list(cp, ordered);
    return kind == Text::lit("job")
        ? prism_rtl::cat(crate::emit::cpp::type_path(p_), "(", crate::syntax::lexer::chars::join(values_, Text::lit(", ")), ")")
        : prism_rtl::cat(crate::emit::cpp::type_path(p_), "{", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(len(names)), [&](const Nat& i) { return prism_rtl::cat(".", crate::emit::cpp::field_id(or_(index(names, i), Text::lit(""))), " = ", or_(index(values_, i), Text::lit(""))); }), Text::lit(", ")), "}");
}


prism_rtl::Turn<Text> CppRecord::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& fs = this->fs;
    auto ordered = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
        auto&& _m = crate::emit::cpp::type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(each(prism_rtl::deref(info).fields, [&](const Text& f) {
                return or_(fold(fs, std::optional<crate::lower::model::Ex>{}, [&](const std::optional<crate::lower::model::Ex>& found_opt, const std::tuple<Text, crate::lower::model::Ex>& _p1) {
                    auto&& g = std::get<0>(_p1);
                    auto&& v_ = std::get<1>(_p1);
                    return g == f ? std::optional(v_) : found_opt;
                }), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(each(fs, [&](const std::tuple<Text, crate::lower::model::Ex>& _p0) {
                auto&& v_ = std::get<1>(_p0);
                return v_;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto names = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = crate::emit::cpp::type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(info).fields);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(each(fs, [&](const std::tuple<Text, crate::lower::model::Ex>& _p0) {
                auto&& g = std::get<0>(_p0);
                return g;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto kind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::emit::cpp::type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(info).kind);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cp_1 = cp;
    auto p__2 = p_;
    return call_then(start_cpp_arg_list(cp_1, ordered), [=](Array<Text> cpp_arg_list_12456) {
        return ({
            auto values_ = cpp_arg_list_12456;
            kind == Text::lit("job")
            ? prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::type_path(p__2), "(", crate::syntax::lexer::chars::join(values_, Text::lit(", ")), ")"))
            : prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::type_path(p__2), "{", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(len(names)), [&](const Nat& i) { return prism_rtl::cat(".", crate::emit::cpp::field_id(or_(index(names, i), Text::lit(""))), " = ", or_(index(values_, i), Text::lit(""))); }), Text::lit(", ")), "}"));
        });
    });
}


/// `Start CppRecord, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_record(crate::emit::cpp::Cp cp, Text p_, Array<std::tuple<Text, crate::lower::model::Ex>> fs) {
    return prism_rtl::make_rc<CppRecord>(cp, p_, fs);
}


/// CppCall: unbounded fn Cp, Text, [Ex] -> Text
Text cpp_call(const crate::emit::cpp::Cp& cp, const Text& f, const Array<crate::lower::model::Ex>& args) {
    auto a = cpp_args(cp, args);
    {
        auto&& m12901_0 = f;
        if (m12901_0 == Text::lit("Rc::new")) {
            return a == Text::lit("{}")
                ? Text::lit("prism_rtl::make_new()")
                : prism_rtl::cat("prism_rtl::rc(", a, ")");
        }
    }
    {
        auto&& m12901_1 = f;
        if (m12901_1 == Text::lit("is_some")) {
            return prism_rtl::cat("prism_rtl::is_some(", a, ")");
        }
    }
    {
        auto&& m12901_2 = f;
        if (m12901_2 == Text::lit("is_none")) {
            return prism_rtl::cat("prism_rtl::is_none(", a, ")");
        }
    }
    {
        auto&& m12901_3 = f;
        if (m12901_3 == Text::lit("RefCell::new")) {
            return a;
        }
    }
    {
        auto&& m12901_4 = f;
        if (m12901_4 == Text::lit("Cell::new")) {
            return a;
        }
    }
    {
        auto&& m12901_5 = f;
        if (m12901_5 == Text::lit("Hold::new")) {
            return prism_rtl::cat("{", a, "}");
        }
    }
    {
        auto&& m12901_6 = f;
        if (m12901_6 == Text::lit("Snapshot::new")) {
            return prism_rtl::cat("snapshot(", a, ")");
        }
    }
    {
        auto&& m12901_7 = f;
        if (m12901_7 == Text::lit("Path::root")) {
            return Text::lit("Path::root()");
        }
    }
    {
        auto&& m12901_8 = f;
        if (m12901_8 == Text::lit("Fault::answer")) {
            return prism_rtl::cat("Fault::answer(", a, ")");
        }
    }
    {
        auto&& m12901_9 = f;
        if (m12901_9 == Text::lit("Fault::too_deep")) {
            return prism_rtl::cat("Fault::too_deep(", a, ")");
        }
    }
    {
        auto&& m12901_10 = f;
        if (m12901_10 == Text::lit("Error::new")) {
            return prism_rtl::cat("Error(", a, ")");
        }
    }
    {
        auto&& m12901_11 = f;
        if (m12901_11 == Text::lit("Text::from")) {
            return prism_rtl::cat("Text(", a, ")");
        }
    }
    {
        auto&& m12901_12 = f;
        if (m12901_12 == Text::lit("String::new")) {
            return Text::lit("std::string()");
        }
    }
    {
        auto&& m12901_13 = f;
        if (m12901_13 == Text::lit("Array::from")) {
            return prism_rtl::cat("Array(", a, ")");
        }
    }
    {
        auto&& m12901_14 = f;
        if (m12901_14 == Text::lit("prism_rtl::Dynamic::of")) {
            return prism_rtl::cat("dynamic_of(", a, ")");
        }
    }
    {
        auto&& m12901_15 = f;
        if (m12901_15 == Text::lit("Dynamic::of")) {
            return prism_rtl::cat("dynamic_of(", a, ")");
        }
    }
    {
        auto&& m12901_16 = f;
        if (m12901_16 == Text::lit("prism_rtl::Event::of")) {
            return prism_rtl::cat("event_of(", a, ")");
        }
    }
    {
        auto&& m12901_17 = f;
        if (m12901_17 == Text::lit("prism_rtl::Host::new")) {
            return prism_rtl::cat("host_new(", a, ")");
        }
    }
    {
        auto&& m12901_18 = f;
        if (m12901_18 == Text::lit("prism_rtl::Entry::new")) {
            return prism_rtl::cat("entry_new(", a, ")");
        }
    }
    {
        auto&& m12901_19 = f;
        if (m12901_19 == Text::lit("prism_rtl::forward_on_none")) {
            return prism_rtl::cat("prism_rtl::forward_on_none<crate::Elem, crate::Answer>(", a, ")");
        }
    }
    {
        auto&& m12901_20 = f;
        if (m12901_20 == Text::lit("Event::never")) {
            return Text::lit("never_event()");
        }
    }
    {
        return is_fresh(f)
            ? Text::lit("{}")
            : prism_rtl::cat(free_call_path(cp, f), "(", a, ")");
    }
}


prism_rtl::Turn<Text> CppCall::cycle() const {
    const auto& cp = this->cp;
    const auto& f = this->f;
    const auto& args = this->args;
    auto args_1 = args;
    auto cp_2 = cp;
    auto f_3 = f;
    return call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_12880) {
        return ({
            auto a = cpp_args_12880;
            ({
            ({
            auto&& m12901_0 = f_3;
            (m12901_0 == Text::lit("Rc::new"));
        }) ? ({
            auto&& m12901_0 = f_3;
            a == Text::lit("{}")
            ? prism_rtl::finished(Text::lit("prism_rtl::make_new()"))
            : prism_rtl::finished(prism_rtl::cat("prism_rtl::rc(", a, ")"));
        })
            : ({
            auto&& m12901_1 = f_3;
            (m12901_1 == Text::lit("is_some"));
        }) ? ({
            auto&& m12901_1 = f_3;
            prism_rtl::finished(prism_rtl::cat("prism_rtl::is_some(", a, ")"));
        })
            : ({
            auto&& m12901_2 = f_3;
            (m12901_2 == Text::lit("is_none"));
        }) ? ({
            auto&& m12901_2 = f_3;
            prism_rtl::finished(prism_rtl::cat("prism_rtl::is_none(", a, ")"));
        })
            : ({
            auto&& m12901_3 = f_3;
            (m12901_3 == Text::lit("RefCell::new"));
        }) ? ({
            auto&& m12901_3 = f_3;
            prism_rtl::finished(a);
        })
            : ({
            auto&& m12901_4 = f_3;
            (m12901_4 == Text::lit("Cell::new"));
        }) ? ({
            auto&& m12901_4 = f_3;
            prism_rtl::finished(a);
        })
            : ({
            auto&& m12901_5 = f_3;
            (m12901_5 == Text::lit("Hold::new"));
        }) ? ({
            auto&& m12901_5 = f_3;
            prism_rtl::finished(prism_rtl::cat("{", a, "}"));
        })
            : ({
            auto&& m12901_6 = f_3;
            (m12901_6 == Text::lit("Snapshot::new"));
        }) ? ({
            auto&& m12901_6 = f_3;
            prism_rtl::finished(prism_rtl::cat("snapshot(", a, ")"));
        })
            : ({
            auto&& m12901_7 = f_3;
            (m12901_7 == Text::lit("Path::root"));
        }) ? ({
            auto&& m12901_7 = f_3;
            prism_rtl::finished(Text::lit("Path::root()"));
        })
            : ({
            auto&& m12901_8 = f_3;
            (m12901_8 == Text::lit("Fault::answer"));
        }) ? ({
            auto&& m12901_8 = f_3;
            prism_rtl::finished(prism_rtl::cat("Fault::answer(", a, ")"));
        })
            : ({
            auto&& m12901_9 = f_3;
            (m12901_9 == Text::lit("Fault::too_deep"));
        }) ? ({
            auto&& m12901_9 = f_3;
            prism_rtl::finished(prism_rtl::cat("Fault::too_deep(", a, ")"));
        })
            : ({
            auto&& m12901_10 = f_3;
            (m12901_10 == Text::lit("Error::new"));
        }) ? ({
            auto&& m12901_10 = f_3;
            prism_rtl::finished(prism_rtl::cat("Error(", a, ")"));
        })
            : ({
            auto&& m12901_11 = f_3;
            (m12901_11 == Text::lit("Text::from"));
        }) ? ({
            auto&& m12901_11 = f_3;
            prism_rtl::finished(prism_rtl::cat("Text(", a, ")"));
        })
            : ({
            auto&& m12901_12 = f_3;
            (m12901_12 == Text::lit("String::new"));
        }) ? ({
            auto&& m12901_12 = f_3;
            prism_rtl::finished(Text::lit("std::string()"));
        })
            : ({
            auto&& m12901_13 = f_3;
            (m12901_13 == Text::lit("Array::from"));
        }) ? ({
            auto&& m12901_13 = f_3;
            prism_rtl::finished(prism_rtl::cat("Array(", a, ")"));
        })
            : ({
            auto&& m12901_14 = f_3;
            (m12901_14 == Text::lit("prism_rtl::Dynamic::of"));
        }) ? ({
            auto&& m12901_14 = f_3;
            prism_rtl::finished(prism_rtl::cat("dynamic_of(", a, ")"));
        })
            : ({
            auto&& m12901_15 = f_3;
            (m12901_15 == Text::lit("Dynamic::of"));
        }) ? ({
            auto&& m12901_15 = f_3;
            prism_rtl::finished(prism_rtl::cat("dynamic_of(", a, ")"));
        })
            : ({
            auto&& m12901_16 = f_3;
            (m12901_16 == Text::lit("prism_rtl::Event::of"));
        }) ? ({
            auto&& m12901_16 = f_3;
            prism_rtl::finished(prism_rtl::cat("event_of(", a, ")"));
        })
            : ({
            auto&& m12901_17 = f_3;
            (m12901_17 == Text::lit("prism_rtl::Host::new"));
        }) ? ({
            auto&& m12901_17 = f_3;
            prism_rtl::finished(prism_rtl::cat("host_new(", a, ")"));
        })
            : ({
            auto&& m12901_18 = f_3;
            (m12901_18 == Text::lit("prism_rtl::Entry::new"));
        }) ? ({
            auto&& m12901_18 = f_3;
            prism_rtl::finished(prism_rtl::cat("entry_new(", a, ")"));
        })
            : ({
            auto&& m12901_19 = f_3;
            (m12901_19 == Text::lit("prism_rtl::forward_on_none"));
        }) ? ({
            auto&& m12901_19 = f_3;
            prism_rtl::finished(prism_rtl::cat("prism_rtl::forward_on_none<crate::Elem, crate::Answer>(", a, ")"));
        })
            : ({
            auto&& m12901_20 = f_3;
            (m12901_20 == Text::lit("Event::never"));
        }) ? ({
            auto&& m12901_20 = f_3;
            prism_rtl::finished(Text::lit("never_event()"));
        })
            : is_fresh(f_3)
            ? prism_rtl::finished(Text::lit("{}"))
            : prism_rtl::finished(prism_rtl::cat(free_call_path(cp_2, f_3), "(", a, ")"));
        });
        });
    });
}


/// `Start CppCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_call(crate::emit::cpp::Cp cp, Text f, Array<crate::lower::model::Ex> args) {
    return prism_rtl::make_rc<CppCall>(cp, f, args);
}


/// FreeCallPath: fn Cp, Text -> Text
Text free_call_path(const crate::emit::cpp::Cp& cp, const Text& f) {
    auto p_ = call_path(f);
    auto hidden = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::prelude::get(cp.members, f);
        if (prism_rtl::is_some(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::emit::cpp::in_list(std_names(), p_) || crate::emit::cpp::in_list(cp.mods, p_));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::syntax::lexer::chars::contains(p_, Text::lit(":"))
        ? p_
        : std::move(hidden) ? qualified_call(cp, f, p_) : p_;
}


/// QualifiedCall: fn Cp, Text, Text -> Text
Text qualified_call(const crate::emit::cpp::Cp& cp, const Text& f, const Text& p_) {
    auto&& _m = crate::prelude::get(cp.fns, prism_rtl::cat(cp.home, "::", f));
    if (prism_rtl::is_some(_m)) {
        return prism_rtl::cat("crate::", cp.home, "::", p_);
    }
    if (prism_rtl::is_none(_m)) {
        return prism_rtl::cat("crate::prelude::", p_);
    }
    prism_rtl::unreachable("no arm matched");
}


/// let stdNames
Array<Text> std_names() {
    return Array(std::vector{Text::lit("apply"), Text::lit("begin"), Text::lit("end"), Text::lit("size"), Text::lit("empty"), Text::lit("data"), Text::lit("get"), Text::lit("swap"), Text::lit("move"), Text::lit("forward"), Text::lit("find"), Text::lit("count"), Text::lit("copy"), Text::lit("fill"), Text::lit("sort"), Text::lit("min"), Text::lit("max"), Text::lit("visit"), Text::lit("invoke"), Text::lit("merge"), Text::lit("remove"), Text::lit("replace"), Text::lit("reverse"), Text::lit("unique"), Text::lit("transform"), Text::lit("accumulate"), Text::lit("distance"), Text::lit("next"), Text::lit("prev"), Text::lit("exchange"), Text::lit("tie"), Text::lit("to_string"), Text::lit("clamp"), Text::lit("partition"), Text::lit("equal"), Text::lit("mismatch"), Text::lit("erase"), Text::lit("search"), Text::lit("rotate")});
}


/// IsFresh: fn Text -> Bool
bool is_fresh(const Text& f) {
    return crate::emit::cpp::in_list(Array(std::vector{Text::lit("Stamped::new"), Text::lit("Cache::new"), Text::lit("Port::new"), Text::lit("Map::new"), Text::lit("Array::new"), Text::lit("Vec::new"), Text::lit("Default::default"), Text::lit("Wakes::default"), Text::lit("Defer::new"), Text::lit("prism_rtl::HostDoc::new"), Text::lit("prism_rtl::Watch::new"), Text::lit("prism_rtl::PerKey::new")}), f);
}


/// CallPath: fn Text -> Text
Text call_path(const Text& f) {
    auto last = crate::emit::cpp::last_segment(f);
    auto owner = crate::emit::cpp::last_segment(crate::emit::cpp::parent_path(f));
    auto is_type = (crate::emit::cpp::parent_path(f) != Text::lit("")) && crate::syntax::lexer::chars::contains(Text::lit("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), crate::syntax::lexer::chars::head(owner));
    return (last == Text::lit("build")) && std::move(is_type)
        ? prism_rtl::cat(crate::emit::cpp::type_path(crate::emit::cpp::parent_path(f)), "::make")
        : last == Text::lit("new")
        ? crate::emit::cpp::type_path(crate::emit::cpp::parent_path(f))
        : crate::emit::cpp::cpp_path_id(crate::emit::cpp::type_path(f));
}


/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
Text cpp_method(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& r, const Text& m, const Array<crate::lower::model::Ex>& args) {
    auto recv = r == crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})
        ? Text::lit("this")
        : cpp_tight_place(cp, r);
    auto a = cpp_args(cp, args);
    auto n = len(args);
    auto sep = n == Nat(0u) ? Text::lit("") : Text::lit(", ");
    auto&& _m = method_form(m, n);
    {
        auto&& m16237_0 = _m;
        if (m16237_0 == Text::lit("id")) {
            return recv;
        }
    }
    {
        auto&& m16237_1 = _m;
        if (m16237_1 == Text::lit("deref")) {
            auto&& _m = pointer(cp, r);
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                return b ? prism_rtl::cat("(*", recv, ")") : recv;
            }
            if (prism_rtl::is_none(_m)) {
                return recv;
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    {
        auto&& m16237_2 = _m;
        if (m16237_2 == Text::lit("assign")) {
            return prism_rtl::cat(recv, " = ", a);
        }
    }
    {
        auto&& m16237_3 = _m;
        if (m16237_3 == Text::lit("take")) {
            return prism_rtl::cat("std::exchange(", recv, ", {})");
        }
    }
    {
        auto&& m16237_4 = _m;
        if (m16237_4 == Text::lit("free")) {
            return prism_rtl::cat(free_name(m), "(", recv, sep, a, ")");
        }
    }
    {
        auto&& m16237_5 = _m;
        if (m16237_5 == Text::lit("arrow")) {
            auto through = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = pointer(cp, r);
                if (prism_rtl::is_some(_m)) {
                    auto&& b = prism_rtl::some_of(_m);
                    _v.set(b ? Text::lit("->") : Text::lit("."));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit("->"));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            return prism_rtl::cat(recv, through, member_name(m), "(", a, ")");
        }
    }
    {
        auto&& m16237_6 = _m;
        if (m16237_6 == Text::lit("exchange")) {
            return prism_rtl::cat("std::exchange(", recv, ", ", a, ")");
        }
    }
    {
        auto through = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            auto&& _m = pointer(cp, r);
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                _v.set(b ? Text::lit("->") : Text::lit("."));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = crate::prelude::get(cp.members, m);
                    if (prism_rtl::is_some(_m)) {
                        _v.set(Text::lit("->"));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit("."));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return prism_rtl::cat(recv, through, node_method_name(cp, m), "(", a, ")");
    }
}


prism_rtl::Turn<Text> CppMethod::cycle() const {
    const auto& cp = this->cp;
    const auto& r = this->r;
    const auto& m = this->m;
    const auto& args = this->args;
    auto recv = r == crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})
        ? Text::lit("this")
        : cpp_tight_place(cp, r);
    auto args_1 = args;
    auto cp_2 = cp;
    auto m_3 = m;
    auto r_4 = r;
    return call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_16156) {
        return ({
            auto a = cpp_args_16156;
            auto n = len(args_1);
            auto sep = n == Nat(0u) ? Text::lit("") : Text::lit(", ");
            ({
            auto&& _m = method_form(m_3, n);
            ({
            auto&& m16237_0 = _m;
            (m16237_0 == Text::lit("id"));
        }) ? ({
            auto&& m16237_0 = _m;
            prism_rtl::finished(recv);
        })
            : ({
            auto&& m16237_1 = _m;
            (m16237_1 == Text::lit("deref"));
        }) ? ({
            auto&& m16237_1 = _m;
            ({
            auto&& _m = pointer(cp_2, r_4);
            prism_rtl::is_some(_m) ? ({
            auto&& b = prism_rtl::some_of(_m);
            b
            ? prism_rtl::finished(prism_rtl::cat("(*", recv, ")"))
            : prism_rtl::finished(recv);
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(recv)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : ({
            auto&& m16237_2 = _m;
            (m16237_2 == Text::lit("assign"));
        }) ? ({
            auto&& m16237_2 = _m;
            prism_rtl::finished(prism_rtl::cat(recv, " = ", a));
        })
            : ({
            auto&& m16237_3 = _m;
            (m16237_3 == Text::lit("take"));
        }) ? ({
            auto&& m16237_3 = _m;
            prism_rtl::finished(prism_rtl::cat("std::exchange(", recv, ", {})"));
        })
            : ({
            auto&& m16237_4 = _m;
            (m16237_4 == Text::lit("free"));
        }) ? ({
            auto&& m16237_4 = _m;
            prism_rtl::finished(prism_rtl::cat(free_name(m_3), "(", recv, sep, a, ")"));
        })
            : ({
            auto&& m16237_5 = _m;
            (m16237_5 == Text::lit("arrow"));
        }) ? ({
            auto&& m16237_5 = _m;
            ({
            auto through = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = pointer(cp_2, r_4);
                if (prism_rtl::is_some(_m)) {
                    auto&& b = prism_rtl::some_of(_m);
                    _v.set(b ? Text::lit("->") : Text::lit("."));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit("->"));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(prism_rtl::cat(recv, through, member_name(m_3), "(", a, ")")));
        });
        })
            : ({
            auto&& m16237_6 = _m;
            (m16237_6 == Text::lit("exchange"));
        }) ? ({
            auto&& m16237_6 = _m;
            prism_rtl::finished(prism_rtl::cat("std::exchange(", recv, ", ", a, ")"));
        })
            : ({
            auto through = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = pointer(cp_2, r_4);
                if (prism_rtl::is_some(_m)) {
                    auto&& b = prism_rtl::some_of(_m);
                    _v.set(b ? Text::lit("->") : Text::lit("."));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        auto&& _m = crate::prelude::get(prism_rtl::deref(cp_2).members, m_3);
                        if (prism_rtl::is_some(_m)) {
                            _v.set(Text::lit("->"));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(Text::lit("."));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(prism_rtl::cat(recv, through, node_method_name(cp_2, m_3), "(", a, ")")));
        });
        });
        });
    });
}


/// `Start CppMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_method(crate::emit::cpp::Cp cp, crate::lower::model::Ex r, Text m, Array<crate::lower::model::Ex> args) {
    return prism_rtl::make_rc<CppMethod>(cp, r, m, args);
}


/// NodeMethodName: fn Cp, Text -> Text
Text node_method_name(const crate::emit::cpp::Cp& cp, const Text& m) {
    auto&& _m = std::tuple{crate::prelude::get(cp.methods, m), crate::prelude::get(cp.field_names, m)};
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        return prism_rtl::cat(crate::emit::cpp::cpp_id(m), "_");
    }
    {
        return member_name(m);
    }
}


/// ?Pointer: fn Cp, Ex -> ?Bool
std::optional<bool> pointer(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& r) {
    if (prism_rtl::is<crate::lower::model::Ex::XSelf>(r)) {
        return std::optional(true);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCx>(r)) {
        return std::optional(false);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(r)) {
        auto&& m17753_2_0 = prism_rtl::as<crate::lower::model::Ex::XVar>(r).a0;
        if (m17753_2_0 == Text::lit("path")) {
            return std::optional(false);
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(r)) {
        auto&& m17753_3_1 = prism_rtl::as<crate::lower::model::Ex::XField>(r).a1;
        if (m17753_3_1 == Text::lit("path")) {
            return std::optional(false);
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCall>(r)) {
        auto&& m17753_4_0 = prism_rtl::as<crate::lower::model::Ex::XCall>(r).a0;
        if (m17753_4_0 == Text::lit("Path::root")) {
            return std::optional(false);
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMethod>(r)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XMethod>(r).a0;
        auto&& m = prism_rtl::as<crate::lower::model::Ex::XMethod>(r).a1;
        if (((m == Text::lit("at")) || (m == Text::lit("child"))) || (m == Text::lit("join"))) {
            auto&& _m = pointer(cp, prism_rtl::deref(prism_rtl::deref(y)));
            if (prism_rtl::is_some(_m) && !prism_rtl::some_of(_m)) {
                return std::optional(false);
            }
            {
                return std::optional<bool>{};
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(r)) {
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(r).a0;
        return crate::prelude::get(cp.pointers, n);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClone>(r)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XClone>(r).a0;
        return pointer(cp, prism_rtl::deref(prism_rtl::deref(y)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(r)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRef>(r).a0;
        return pointer(cp, prism_rtl::deref(prism_rtl::deref(y)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(r)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDeref>(r).a0;
        auto&& _m = ex_ty(cp, r);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            return std::optional(is_pointer_ty(cp, unref(t)));
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<bool>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(r)) {
        auto&& m17753_10_0 = prism_rtl::as<crate::lower::model::Ex::XField>(r).a0;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XField>(r).a1;
        if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m17753_10_0)))) {
            auto&& _m = crate::prelude::get(cp.fields, f);
            if (prism_rtl::is_some(_m)) {
                auto&& t = prism_rtl::some_of(_m);
                return std::optional(is_pointer_ty(cp, t));
            }
            if (prism_rtl::is_none(_m)) {
                return std::optional<bool>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(r)) {
        auto&& m17753_11_0 = prism_rtl::as<crate::lower::model::Ex::XField>(r).a0;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XField>(r).a1;
        if (prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m17753_11_0)))) {
            auto&& m17753_11_0_r_0 = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m17753_11_0))).a0;
            if (m17753_11_0_r_0 == Text::lit("node")) {
                auto&& _m = crate::prelude::get(cp.fields, f);
                if (prism_rtl::is_some(_m)) {
                    auto&& t = prism_rtl::some_of(_m);
                    return std::optional(is_pointer_ty(cp, t));
                }
                if (prism_rtl::is_none(_m)) {
                    return std::optional<bool>{};
                }
                prism_rtl::unreachable("no arm matched");
            }
        }
    }
    {
        return std::optional<bool>{};
    }
}


/// IsPointerTy: fn Cp, OutTy -> Bool
bool is_pointer_ty(const crate::emit::cpp::Cp& cp, const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& m18597_0_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        if (m18597_0_0 == Text::lit("prism_rtl::Rows")) {
            return true;
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPort>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutObj>(t)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJob>(t)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutShowAny>(t)) {
        return true;
    }
    {
        return false;
    }
}


/// MethodForm: fn Text, Nat -> Text
Text method_form(const Text& m, const Nat& n) {
    auto&& _m = std::tuple{m, n};
    {
        auto&& m19124_0_0 = std::get<0>(_m);
        auto&& m19124_0_1 = std::get<1>(_m);
        if (m19124_0_0 == Text::lit("borrow")) {
            if (m19124_0_1 == Nat(0u)) {
                return Text::lit("deref");
            }
        }
    }
    {
        auto&& m19124_1_0 = std::get<0>(_m);
        auto&& m19124_1_1 = std::get<1>(_m);
        if (m19124_1_0 == Text::lit("borrow_mut")) {
            if (m19124_1_1 == Nat(0u)) {
                return Text::lit("deref");
            }
        }
    }
    {
        auto&& m19124_2_0 = std::get<0>(_m);
        auto&& m19124_2_1 = std::get<1>(_m);
        if (m19124_2_0 == Text::lit("clone")) {
            if (m19124_2_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m19124_3_0 = std::get<0>(_m);
        auto&& m19124_3_1 = std::get<1>(_m);
        if (m19124_3_0 == Text::lit("iter")) {
            if (m19124_3_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m19124_4_0 = std::get<0>(_m);
        auto&& m19124_4_1 = std::get<1>(_m);
        if (m19124_4_0 == Text::lit("collect")) {
            if (m19124_4_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m19124_5_0 = std::get<0>(_m);
        auto&& m19124_5_1 = std::get<1>(_m);
        if (m19124_5_0 == Text::lit("unwrap_or_default")) {
            if (m19124_5_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19124_6_0 = std::get<0>(_m);
        auto&& m19124_6_1 = std::get<1>(_m);
        if (m19124_6_0 == Text::lit("for_each")) {
            if (m19124_6_1 == Nat(1u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19124_7_0 = std::get<0>(_m);
        auto&& m19124_7_1 = std::get<1>(_m);
        if (m19124_7_0 == Text::lit("into_iter")) {
            if (m19124_7_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m19124_8_0 = std::get<0>(_m);
        auto&& m19124_8_1 = std::get<1>(_m);
        if (m19124_8_0 == Text::lit("as_ref")) {
            if (m19124_8_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m19124_9_0 = std::get<0>(_m);
        auto&& m19124_9_1 = std::get<1>(_m);
        if (m19124_9_0 == Text::lit("get")) {
            if (m19124_9_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m19124_10_0 = std::get<0>(_m);
        auto&& m19124_10_1 = std::get<1>(_m);
        if (m19124_10_0 == Text::lit("set")) {
            if (m19124_10_1 == Nat(1u)) {
                return Text::lit("assign");
            }
        }
    }
    {
        auto&& m19124_11_0 = std::get<0>(_m);
        auto&& m19124_11_1 = std::get<1>(_m);
        if (m19124_11_0 == Text::lit("take")) {
            if (m19124_11_1 == Nat(0u)) {
                return Text::lit("take");
            }
        }
    }
    {
        auto&& m19124_12_0 = std::get<0>(_m);
        auto&& m19124_12_1 = std::get<1>(_m);
        if (m19124_12_0 == Text::lit("replace")) {
            if (m19124_12_1 == Nat(1u)) {
                return Text::lit("exchange");
            }
        }
    }
    {
        auto&& m19124_13_0 = std::get<0>(_m);
        auto&& m19124_13_1 = std::get<1>(_m);
        if (m19124_13_0 == Text::lit("values")) {
            if (m19124_13_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19124_14_0 = std::get<0>(_m);
        auto&& m19124_14_1 = std::get<1>(_m);
        if (m19124_14_0 == Text::lit("keys")) {
            if (m19124_14_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19124_15_0 = std::get<0>(_m);
        auto&& m19124_15_1 = std::get<1>(_m);
        if (m19124_15_0 == Text::lit("enumerate")) {
            if (m19124_15_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19124_16_0 = std::get<0>(_m);
        auto&& m19124_16_1 = std::get<1>(_m);
        if (m19124_16_0 == Text::lit("fire")) {
            if (m19124_16_1 == Nat(2u)) {
                return Text::lit("arrow");
            }
        }
    }
    {
        auto&& m19124_17_0 = std::get<0>(_m);
        auto&& m19124_17_1 = std::get<1>(_m);
        if (m19124_17_0 == Text::lit("subscribe")) {
            if (m19124_17_1 == Nat(1u)) {
                return Text::lit("arrow");
            }
        }
    }
    {
        auto&& m19124_18_0 = std::get<0>(_m);
        auto&& m19124_18_1 = std::get<1>(_m);
        if (m19124_18_0 == Text::lit("unsubscribe")) {
            if (m19124_18_1 == Nat(1u)) {
                return Text::lit("arrow");
            }
        }
    }
    {
        auto&& m19124_19_0 = std::get<0>(_m);
        auto&& m19124_19_1 = std::get<1>(_m);
        if (m19124_19_0 == Text::lit("cycle")) {
            if (m19124_19_1 == Nat(0u)) {
                return Text::lit("arrow");
            }
        }
    }
    {
        auto&& m19124_20_0 = std::get<0>(_m);
        auto&& m19124_20_1 = std::get<1>(_m);
        if (m19124_20_0 == Text::lit("upgrade")) {
            if (m19124_20_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19124_21_0 = std::get<0>(_m);
        auto&& m19124_21_1 = std::get<1>(_m);
        if (m19124_21_0 == Text::lit("expect")) {
            if (m19124_21_1 == Nat(1u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19124_22_0 = std::get<0>(_m);
        auto&& m19124_22_1 = std::get<1>(_m);
        if (m19124_22_0 == Text::lit("to_pod")) {
            if (m19124_22_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19124_23_0 = std::get<0>(_m);
        auto&& m19124_23_1 = std::get<1>(_m);
        if (m19124_23_0 == Text::lit("cloned")) {
            if (m19124_23_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19124_24_0 = std::get<0>(_m);
        auto&& m19124_24_1 = std::get<1>(_m);
        if (m19124_24_0 == Text::lit("ok")) {
            if (m19124_24_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19124_25_0 = std::get<0>(_m);
        auto&& m19124_25_1 = std::get<1>(_m);
        if (m19124_25_0 == Text::lit("ok_or")) {
            if (m19124_25_1 == Nat(1u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19124_26_0 = std::get<0>(_m);
        auto&& m19124_26_1 = std::get<1>(_m);
        if (m19124_26_0 == Text::lit("map")) {
            if (m19124_26_1 == Nat(1u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19124_27_0 = std::get<0>(_m);
        auto&& m19124_27_1 = std::get<1>(_m);
        if (m19124_27_0 == Text::lit("iter_mut")) {
            if (m19124_27_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19124_28_0 = std::get<0>(_m);
        auto&& m19124_28_1 = std::get<1>(_m);
        if (m19124_28_0 == Text::lit("to_vec")) {
            if (m19124_28_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19124_29_0 = std::get<0>(_m);
        auto&& m19124_29_1 = std::get<1>(_m);
        if (m19124_29_0 == Text::lit("filter_some")) {
            if (m19124_29_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        return Text::lit("dot");
    }
}


/// FreeName: fn Text -> Text
Text free_name(const Text& m) {
    {
        auto&& m20061_0 = m;
        if (m20061_0 == Text::lit("to_pod")) {
            return Text::lit("prism_rtl::to_pod");
        }
    }
    {
        auto&& m20061_1 = m;
        if (m20061_1 == Text::lit("ok")) {
            return Text::lit("prism_rtl::ignore");
        }
    }
    {
        auto&& m20061_2 = m;
        if (m20061_2 == Text::lit("map")) {
            return Text::lit("prism_rtl::fmap");
        }
    }
    {
        auto&& m20061_3 = m;
        if (m20061_3 == Text::lit("to_vec")) {
            return Text::lit("path_of");
        }
    }
    {
        auto&& m20061_4 = m;
        if (m20061_4 == Text::lit("values")) {
            return Text::lit("crate::prelude::values");
        }
    }
    {
        auto&& m20061_5 = m;
        if (m20061_5 == Text::lit("keys")) {
            return Text::lit("crate::prelude::keys");
        }
    }
    {
        auto&& m20061_6 = m;
        if (m20061_6 == Text::lit("enumerate")) {
            return Text::lit("prism_rtl::enumerate");
        }
    }
    {
        auto&& m20061_7 = m;
        if (m20061_7 == Text::lit("unwrap_or_default")) {
            return Text::lit("prism_rtl::unwrap_or_default");
        }
    }
    {
        auto&& m20061_8 = m;
        if (m20061_8 == Text::lit("for_each")) {
            return Text::lit("prism_rtl::for_each");
        }
    }
    {
        return m;
    }
}


/// MemberName: fn Text -> Text
Text member_name(const Text& m) {
    {
        auto&& m20459_0 = m;
        if (m20459_0 == Text::lit("push_str")) {
            return Text::lit("append");
        }
    }
    {
        auto&& m20459_1 = m;
        if (m20459_1 == Text::lit("len")) {
            return Text::lit("size");
        }
    }
    {
        auto&& m20459_2 = m;
        if (m20459_2 == Text::lit("is_empty")) {
            return Text::lit("empty");
        }
    }
    {
        auto&& m20459_3 = m;
        if (m20459_3 == Text::lit("push")) {
            return Text::lit("push_back");
        }
    }
    {
        auto&& m20459_4 = m;
        if (m20459_4 == Text::lit("contains_key")) {
            return Text::lit("contains");
        }
    }
    {
        auto&& m20459_5 = m;
        if (m20459_5 == Text::lit("build")) {
            return Text::lit("make");
        }
    }
    {
        return crate::emit::cpp::cpp_id(m);
    }
}


/// CaseTest: fn Cp, Text, Text -> Text
Text case_test(const crate::emit::cpp::Cp& cp, const Text& c, const Text& v_) {
    {
        auto&& m20758_0 = c;
        if (m20758_0 == Text::lit("Some")) {
            return prism_rtl::cat("prism_rtl::is_some(", v_, ")");
        }
    }
    {
        auto&& m20758_1 = c;
        if (m20758_1 == Text::lit("None")) {
            return prism_rtl::cat("prism_rtl::is_none(", v_, ")");
        }
    }
    {
        auto&& m20758_2 = c;
        if (m20758_2 == Text::lit("Ok")) {
            return prism_rtl::cat("prism_rtl::is_ok(", v_, ")");
        }
    }
    {
        auto&& m20758_3 = c;
        if (m20758_3 == Text::lit("Err")) {
            return prism_rtl::cat("prism_rtl::is_err(", v_, ")");
        }
    }
    {
        auto&& m20758_4 = c;
        if (m20758_4 == Text::lit("prism_rtl::Turn::More")) {
            return prism_rtl::cat(v_, ".if_more()");
        }
    }
    {
        auto&& m20758_5 = c;
        if (m20758_5 == Text::lit("prism_rtl::Turn::Finished")) {
            return prism_rtl::cat(v_, ".if_finished()");
        }
    }
    {
        auto&& _m = crate::emit::cpp::case_of(cp, c);
        if (prism_rtl::is_some(_m)) {
            return prism_rtl::cat("prism_rtl::is<", case_type(c), ">(", v_, ")");
        }
        if (prism_rtl::is_none(_m)) {
            return is_runtime_case(c)
                ? prism_rtl::cat("prism_rtl::is<", case_type(c), ">(", v_, ")")
                : Text::lit("true");
        }
        prism_rtl::unreachable("no arm matched");
    }
}


/// CaseType: fn Text -> Text
Text case_type(const Text& c) {
    {
        auto&& m21310_0 = c;
        if (m21310_0 == Text::lit("Segment::Pos")) {
            return Text::lit("pat::Pos");
        }
    }
    {
        auto&& m21310_1 = c;
        if (m21310_1 == Text::lit("Segment::Gen")) {
            return Text::lit("pat::Gen");
        }
    }
    {
        auto&& m21310_2 = c;
        if (m21310_2 == Text::lit("Segment::Key")) {
            return Text::lit("pat::Key");
        }
    }
    {
        return crate::emit::cpp::type_path(c);
    }
}


/// Payload: fn Cp, Text, Text, Nat -> Text
Text payload(const crate::emit::cpp::Cp& cp, const Text& c, const Text& v_, const Nat& i) {
    {
        auto&& m21559_0 = c;
        if (m21559_0 == Text::lit("Some")) {
            return prism_rtl::cat("prism_rtl::some_of(", v_, ")");
        }
    }
    {
        auto&& m21559_1 = c;
        if (m21559_1 == Text::lit("Ok")) {
            return prism_rtl::cat("*", v_);
        }
    }
    {
        auto&& m21559_2 = c;
        if (m21559_2 == Text::lit("Err")) {
            return prism_rtl::cat(v_, ".error()");
        }
    }
    {
        auto&& m21559_3 = c;
        if (m21559_3 == Text::lit("prism_rtl::Turn::More")) {
            return prism_rtl::cat(v_, ".if_more()->next");
        }
    }
    {
        auto&& m21559_4 = c;
        if (m21559_4 == Text::lit("prism_rtl::Turn::Finished")) {
            return prism_rtl::cat(v_, ".if_finished()->value");
        }
    }
    {
        auto&& _m = crate::emit::cpp::case_of(cp, c);
        if (prism_rtl::is_some(_m)) {
            return prism_rtl::cat("prism_rtl::as<", case_type(c), ">(", v_, ").a", i);
        }
        if (prism_rtl::is_none(_m)) {
            return is_runtime_case(c)
                ? prism_rtl::cat("prism_rtl::as<", case_type(c), ">(", v_, ").a", i)
                : prism_rtl::cat(v_, ".a", i);
        }
        prism_rtl::unreachable("no arm matched");
    }
}


/// IsRuntimeCase: fn Text -> Bool
bool is_runtime_case(const Text& c) {
    return crate::syntax::lexer::chars::has_prefix(c, Text::lit("Segment::"));
}


/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
Text cpp_if(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& c, const crate::lower::model::Ex& t, const crate::lower::model::Ex& e) {
    auto ct = cpp_expr(cp, c);
    auto err_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::lower::model::Ex>> _v;
        auto&& _m = std::tuple{err_of(t), err_of(e)};
        if (prism_rtl::is_some(std::get<0>(_m))) {
            auto&& y = prism_rtl::some_of(std::get<0>(_m));
            _v.set(std::optional(y));
            goto _done;
        }
        if (prism_rtl::is_none(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
            auto&& y = prism_rtl::some_of(std::get<1>(_m));
            _v.set(std::optional(y));
            goto _done;
        }
        {
            _v.set(std::optional<crate::lower::model::Ex>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto tt = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(err_opt)) {
            auto&& y = prism_rtl::some_of(err_opt);
            _v.set(ok_branch(cp, t, y));
            goto _done;
        }
        if (prism_rtl::is_none(err_opt)) {
            _v.set(cpp_expr(cp, t));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto et = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(err_opt)) {
            auto&& y = prism_rtl::some_of(err_opt);
            _v.set(ok_branch(cp, e, y));
            goto _done;
        }
        if (prism_rtl::is_none(err_opt)) {
            _v.set(cpp_expr(cp, e));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto short_ = (!crate::syntax::lexer::chars::contains(prism_rtl::cat(tt, et), Text::lit("\n"))) && (len_text(prism_rtl::cat(ct, tt, et)) < Nat(70u));
    return std::move(short_)
        ? prism_rtl::cat(ct, " ? ", tt, " : ", et)
        : crate::emit::cpp::templates::items::cond_expr(ct, tt, et);
}


prism_rtl::Turn<Text> CppIf::cycle() const {
    const auto& cp = this->cp;
    const auto& c = this->c;
    const auto& t = this->t;
    const auto& e = this->e;
    auto c_1 = c;
    auto cp_2 = cp;
    auto e_3 = e;
    auto t_4 = t;
    return call_then(start_cpp_expr(cp_2, c_1), [=](Text cpp_expr_22136) {
        return ({
            auto ct = cpp_expr_22136;
            auto err_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::lower::model::Ex>> _v;
                auto&& _m = std::tuple{err_of(t_4), err_of(e_3)};
                if (prism_rtl::is_some(std::get<0>(_m))) {
                    auto&& y = prism_rtl::some_of(std::get<0>(_m));
                    _v.set(std::optional(y));
                    goto _done;
                }
                if (prism_rtl::is_none(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                    auto&& y = prism_rtl::some_of(std::get<1>(_m));
                    _v.set(std::optional(y));
                    goto _done;
                }
                {
                    _v.set(std::optional<crate::lower::model::Ex>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto tt = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is_some(err_opt)) {
                    auto&& y = prism_rtl::some_of(err_opt);
                    _v.set(ok_branch(cp_2, t_4, y));
                    goto _done;
                }
                if (prism_rtl::is_none(err_opt)) {
                    _v.set(cpp_expr(cp_2, t_4));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto et = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is_some(err_opt)) {
                    auto&& y = prism_rtl::some_of(err_opt);
                    _v.set(ok_branch(cp_2, e_3, y));
                    goto _done;
                }
                if (prism_rtl::is_none(err_opt)) {
                    _v.set(cpp_expr(cp_2, e_3));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto short_ = (!crate::syntax::lexer::chars::contains(prism_rtl::cat(tt, et), Text::lit("\n"))) && (len_text(prism_rtl::cat(ct, tt, et)) < Nat(70u));
            (std::move(short_)
            ? prism_rtl::finished(prism_rtl::cat(ct, " ? ", tt, " : ", et))
            : prism_rtl::finished(crate::emit::cpp::templates::items::cond_expr(ct, tt, et)));
        });
    });
}


/// `Start CppIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_if(crate::emit::cpp::Cp cp, crate::lower::model::Ex c, crate::lower::model::Ex t, crate::lower::model::Ex e) {
    return prism_rtl::make_rc<CppIf>(cp, c, t, e);
}


/// WithMoveCaptures: unbounded fn Cp, [Do], Ex -> Cp
crate::emit::cpp::Cp with_move_captures(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Do>& dos, const crate::lower::model::Ex& e) {
    auto lets = fold(dos, Array<Text>{}, [&](const Array<Text>& acc, const crate::lower::model::Do& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is<crate::lower::model::Do::DoLet>(d)) {
                auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = crate::emit::cpp::stmts::let_name(p_);
                    if (prism_rtl::is_some(_m)) {
                        auto&& n = prism_rtl::some_of(_m);
                        _v.set(crate::emit::cpp::in_list(acc, n) ? acc : crate::prelude::push(acc, n));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return len(lets) == Nat(0u)
        ? ({
        crate::emit::cpp::Cp this_ = cp;
        this_.move_captures = Array<Text>{};
        (std::move(this_));
    })
        : ({
        auto [reads, has_move] = reads_of(e, false, std::tuple{Array<Text>{}, false});
        ({
        crate::emit::cpp::Cp this_ = cp;
        this_.move_captures = has_move
            ? filter(lets, [&](const Text& n) { return !crate::emit::cpp::in_list(reads, n); })
            : Array<Text>{};
        (std::move(this_));
    });
    });
}


prism_rtl::Turn<crate::emit::cpp::Cp> WithMoveCaptures::cycle() const {
    const auto& cp = this->cp;
    const auto& dos = this->dos;
    const auto& e = this->e;
    auto lets = fold(dos, Array<Text>{}, [&](const Array<Text>& acc, const crate::lower::model::Do& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is<crate::lower::model::Do::DoLet>(d)) {
                auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = crate::emit::cpp::stmts::let_name(p_);
                    if (prism_rtl::is_some(_m)) {
                        auto&& n = prism_rtl::some_of(_m);
                        _v.set(crate::emit::cpp::in_list(acc, n) ? acc : crate::prelude::push(acc, n));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return len(lets) == Nat(0u)
        ? prism_rtl::finished(({
        crate::emit::cpp::Cp this_ = cp;
        this_.move_captures = Array<Text>{};
        (std::move(this_));
    }))
        : ({
        auto cp_1 = cp;
        auto e_2 = e;
        call_then(start_reads_of(e_2, false, std::tuple{Array<Text>{}, false}), [=, cp_1 = std::move(cp_1)](std::tuple<Array<Text>, bool> reads_of_23385) {
        return ({
            auto [reads, has_move] = reads_of_23385;
            (prism_rtl::finished(({
            crate::emit::cpp::Cp this_ = cp_1;
            this_.move_captures = has_move
                ? filter(lets, [&](const Text& n) { return !crate::emit::cpp::in_list(reads, n); })
                : Array<Text>{};
            (std::move(this_));
        })));
        });
    });
    });
}


/// `Start WithMoveCaptures, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::emit::cpp::Cp> start_with_move_captures(crate::emit::cpp::Cp cp, Array<crate::lower::model::Do> dos, crate::lower::model::Ex e) {
    return prism_rtl::make_rc<WithMoveCaptures>(cp, dos, e);
}


/// ReadsOf: unbounded fn Ex, Bool, (([Text], Bool)) -> (([Text], Bool))
std::tuple<Array<Text>, bool> reads_of(const crate::lower::model::Ex& x, const bool& into, const std::tuple<Array<Text>, bool>& acc) {
    auto [reads, has_move] = acc;
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x)) {
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(x).a0;
        return std::tuple{crate::prelude::push(reads, n), has_move};
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClosure>(x) && prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a0) {
        auto&& ps = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a2;
        return into
            ? reads_of(prism_rtl::deref(prism_rtl::deref(body)), into, std::tuple{reads, true})
            : std::tuple{reads, true};
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClosure>(x) && !prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a0) {
        auto&& ps = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a2;
        return reads_of(prism_rtl::deref(prism_rtl::deref(body)), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRef>(x).a0;
        return reads_of(prism_rtl::deref(prism_rtl::deref(y)), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRefMut>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRefMut>(x).a0;
        return reads_of(prism_rtl::deref(prism_rtl::deref(y)), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDeref>(x).a0;
        return reads_of(prism_rtl::deref(prism_rtl::deref(y)), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTarget>(x).a0;
        return reads_of(prism_rtl::deref(prism_rtl::deref(y)), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClone>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XClone>(x).a0;
        return reads_of(prism_rtl::deref(prism_rtl::deref(y)), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XWeak>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XWeak>(x).a0;
        return reads_of(prism_rtl::deref(prism_rtl::deref(y)), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x).a0;
        return reads_of(prism_rtl::deref(prism_rtl::deref(y)), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBreak>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XBreak>(x).a1;
        return reads_of(prism_rtl::deref(prism_rtl::deref(y)), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XLater>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XLater>(x).a0;
        return reads_of(prism_rtl::deref(prism_rtl::deref(y)), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFormatStr>(x)) {
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XFormatStr>(x).a0;
        return reads_each(xs, into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIsCase>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a0;
        return reads_of(prism_rtl::deref(prism_rtl::deref(y)), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCall>(x)) {
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XCall>(x).a1;
        return reads_each(xs, into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XApply>(x)) {
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XApply>(x).a0;
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XApply>(x).a1;
        return reads_each(append(Array(std::vector{prism_rtl::deref(prism_rtl::deref(f))}), xs), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMethod>(x)) {
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a0;
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a2;
        return reads_each(append(Array(std::vector{prism_rtl::deref(prism_rtl::deref(r))}), xs), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBin>(x)) {
        auto&& l = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a1;
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a2;
        return reads_each(Array(std::vector{prism_rtl::deref(prism_rtl::deref(l)), prism_rtl::deref(prism_rtl::deref(r))}), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnary>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XUnary>(x).a1;
        return reads_of(prism_rtl::deref(prism_rtl::deref(y)), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCtor>(x)) {
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a1;
        return reads_each(xs, into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRecord>(x)) {
        auto&& fs = prism_rtl::as<crate::lower::model::Ex::XRecord>(x).a1;
        return reads_each(each(fs, [&](const std::tuple<Text, crate::lower::model::Ex>& _p0) {
            auto&& v_ = std::get<1>(_p0);
            return v_;
        }), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTuple>(x)) {
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XTuple>(x).a0;
        return reads_each(xs, into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XVec>(x)) {
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XVec>(x).a0;
        return reads_each(xs, into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFormat>(x)) {
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XFormat>(x).a0;
        return reads_each(xs, into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMatch>(x)) {
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a0;
        auto&& arms = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a1;
        return reads_arms(arms, into, reads_of(prism_rtl::deref(prism_rtl::deref(s)), into, acc));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XChain>(x)) {
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a1;
        auto&& arms = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a2;
        return reads_arms(arms, into, reads_of(prism_rtl::deref(prism_rtl::deref(s)), into, acc));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIf>(x)) {
        auto&& c = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a2;
        return reads_each(Array(std::vector{prism_rtl::deref(prism_rtl::deref(c)), prism_rtl::deref(prism_rtl::deref(t)), prism_rtl::deref(prism_rtl::deref(e))}), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x)) {
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        return reads_of(prism_rtl::deref(prism_rtl::deref(e)), into, reads_dos(dos, into, acc));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XLabeled>(x)) {
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a2;
        return reads_of(prism_rtl::deref(prism_rtl::deref(e)), into, reads_dos(dos, into, acc));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTry>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTry>(x).a0;
        return reads_of(prism_rtl::deref(prism_rtl::deref(y)), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        return reads_of(prism_rtl::deref(prism_rtl::deref(r)), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x)) {
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a0;
        return reads_of(prism_rtl::deref(prism_rtl::deref(r)), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDecode>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDecode>(x).a1;
        return reads_of(prism_rtl::deref(prism_rtl::deref(y)), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCast>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XCast>(x).a0;
        return reads_of(prism_rtl::deref(prism_rtl::deref(y)), into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTyped>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTyped>(x).a0;
        return reads_of(prism_rtl::deref(prism_rtl::deref(y)), into, acc);
    }
    {
        return acc;
    }
}


prism_rtl::Turn<std::tuple<Array<Text>, bool>> ReadsOf::cycle() const {
    const auto& x = this->x;
    const auto& into = this->into;
    const auto& acc = this->acc;
    auto [reads, has_move] = acc;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XVar>(x) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(x).a0;
        prism_rtl::finished(std::tuple{crate::prelude::push(reads, n), has_move});
    })
        : prism_rtl::is<crate::lower::model::Ex::XClosure>(x) && prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a0 ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a2;
        prism_rtl::deref(into)
        ? prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(body)), prism_rtl::deref(into), std::tuple{reads, true})))
        : prism_rtl::finished(std::tuple{reads, true});
    })
        : prism_rtl::is<crate::lower::model::Ex::XClosure>(x) && !prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a0 ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a2;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(body)), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRef>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRef>(x).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y)), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRefMut>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRefMut>(x).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y)), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XDeref>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDeref>(x).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y)), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XTarget>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTarget>(x).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y)), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XClone>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XClone>(x).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y)), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XWeak>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XWeak>(x).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y)), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y)), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBreak>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XBreak>(x).a1;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y)), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XLater>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XLater>(x).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y)), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XFormatStr>(x) ? ({
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XFormatStr>(x).a0;
        prism_rtl::more(prism_rtl::rc(ReadsEach(xs, prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIsCase>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y)), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XCall>(x) ? ({
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XCall>(x).a1;
        prism_rtl::more(prism_rtl::rc(ReadsEach(xs, prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XApply>(x) ? ({
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XApply>(x).a0;
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XApply>(x).a1;
        prism_rtl::more(prism_rtl::rc(ReadsEach(append(Array(std::vector{prism_rtl::deref(prism_rtl::deref(f))}), xs), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XMethod>(x) ? ({
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a0;
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a2;
        prism_rtl::more(prism_rtl::rc(ReadsEach(append(Array(std::vector{prism_rtl::deref(prism_rtl::deref(r))}), xs), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBin>(x) ? ({
        auto&& l = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a1;
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a2;
        prism_rtl::more(prism_rtl::rc(ReadsEach(Array(std::vector{prism_rtl::deref(prism_rtl::deref(l)), prism_rtl::deref(prism_rtl::deref(r))}), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XUnary>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XUnary>(x).a1;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y)), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XCtor>(x) ? ({
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a1;
        prism_rtl::more(prism_rtl::rc(ReadsEach(xs, prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRecord>(x) ? ({
        auto&& fs = prism_rtl::as<crate::lower::model::Ex::XRecord>(x).a1;
        prism_rtl::more(prism_rtl::rc(ReadsEach(each(fs, [&](const std::tuple<Text, crate::lower::model::Ex>& _p0) {
        auto&& v_ = std::get<1>(_p0);
        return v_;
    }), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XTuple>(x) ? ({
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XTuple>(x).a0;
        prism_rtl::more(prism_rtl::rc(ReadsEach(xs, prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XVec>(x) ? ({
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XVec>(x).a0;
        prism_rtl::more(prism_rtl::rc(ReadsEach(xs, prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XFormat>(x) ? ({
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XFormat>(x).a0;
        prism_rtl::more(prism_rtl::rc(ReadsEach(xs, prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XMatch>(x) ? ({
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a0;
        auto&& arms = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a1;
        ({
        auto acc_1 = acc;
        auto arms_2 = arms;
        auto into_3 = prism_rtl::deref(into);
        auto s_4 = prism_rtl::deref(prism_rtl::deref(s));
        call_then(start_reads_of(s_4, std::move(into_3), acc_1), [=, arms_2 = std::move(arms_2)](std::tuple<Array<Text>, bool> reads_of_25087) { return prism_rtl::more(prism_rtl::rc(ReadsArms(arms_2, into_3, reads_of_25087))); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XChain>(x) ? ({
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a1;
        auto&& arms = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a2;
        ({
        auto acc_1 = acc;
        auto arms_2 = arms;
        auto into_3 = prism_rtl::deref(into);
        auto s_4 = prism_rtl::deref(prism_rtl::deref(s));
        call_then(start_reads_of(s_4, std::move(into_3), acc_1), [=, arms_2 = std::move(arms_2)](std::tuple<Array<Text>, bool> reads_of_25172) { return prism_rtl::more(prism_rtl::rc(ReadsArms(arms_2, into_3, reads_of_25172))); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XIf>(x) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a2;
        prism_rtl::more(prism_rtl::rc(ReadsEach(Array(std::vector{prism_rtl::deref(prism_rtl::deref(c)), prism_rtl::deref(prism_rtl::deref(t)), prism_rtl::deref(prism_rtl::deref(e))}), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBlock>(x) ? ({
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        ({
        auto acc_1 = acc;
        auto dos_2 = dos;
        auto e_3 = prism_rtl::deref(prism_rtl::deref(e));
        auto into_4 = prism_rtl::deref(into);
        call_then(start_reads_dos(dos_2, std::move(into_4), acc_1), [=, e_3 = std::move(e_3)](std::tuple<Array<Text>, bool> reads_dos_25289) { return prism_rtl::more(prism_rtl::rc(ReadsOf(e_3, into_4, reads_dos_25289))); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XLabeled>(x) ? ({
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a2;
        ({
        auto acc_1 = acc;
        auto dos_2 = dos;
        auto e_3 = prism_rtl::deref(prism_rtl::deref(e));
        auto into_4 = prism_rtl::deref(into);
        call_then(start_reads_dos(dos_2, std::move(into_4), acc_1), [=, e_3 = std::move(e_3)](std::tuple<Array<Text>, bool> reads_dos_25373) { return prism_rtl::more(prism_rtl::rc(ReadsOf(e_3, into_4, reads_dos_25373))); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTry>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTry>(x).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y)), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XField>(x) ? ({
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(r)), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XPart>(x) ? ({
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(r)), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XDecode>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDecode>(x).a1;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y)), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XCast>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XCast>(x).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y)), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XTyped>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTyped>(x).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y)), prism_rtl::deref(into), acc)));
    })
        : prism_rtl::finished(acc);
    });
}


/// `Start ReadsOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, bool>> start_reads_of(crate::lower::model::Ex x, bool into, std::tuple<Array<Text>, bool> acc) {
    return prism_rtl::make_rc<ReadsOf>(x, into, acc);
}


/// ReadsEach: unbounded fn [Ex], Bool, (([Text], Bool)) -> (([Text], Bool))
std::tuple<Array<Text>, bool> reads_each(const Array<crate::lower::model::Ex>& xs, const bool& into, const std::tuple<Array<Text>, bool>& acc) {
    return run_to_end(fold_job(xs, acc, ({
        auto into_1 = into;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, bool>>(std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Ex>)>>(prism_rtl::rc([=, into_1 = std::move(into_1)](std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Ex> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto into_1_2 = into_1;
            entered(once_job([=, into_1_2 = std::move(into_1_2)]() {
            return ({
                auto a = p0;
                auto x = p1;
                (prism_rtl::more(prism_rtl::rc(ReadsOf(x, into_1_2, a))));
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<Text>, bool>> ReadsEach::cycle() const {
    const auto& xs = this->xs;
    const auto& into = this->into;
    const auto& acc = this->acc;
    return fold_job(xs, acc, ({
        auto into_1 = prism_rtl::deref(into);
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, bool>>(std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Ex>)>>(prism_rtl::rc([=, into_1 = std::move(into_1)](std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Ex> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto into_1_2 = into_1;
            entered(once_job([=, into_1_2 = std::move(into_1_2)]() {
            return ({
                auto a = p0;
                auto x = p1;
                (prism_rtl::more(prism_rtl::rc(ReadsOf(x, into_1_2, a))));
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start ReadsEach, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, bool>> start_reads_each(Array<crate::lower::model::Ex> xs, bool into, std::tuple<Array<Text>, bool> acc) {
    return prism_rtl::make_rc<ReadsEach>(xs, into, acc);
}


/// ReadsArms: unbounded fn [XArm], Bool, (([Text], Bool)) -> (([Text], Bool))
std::tuple<Array<Text>, bool> reads_arms(const Array<crate::lower::model::XArm>& arms, const bool& into, const std::tuple<Array<Text>, bool>& acc) {
    return run_to_end(fold_job(arms, acc, ({
        auto into_1 = into;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, bool>>(std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::XArm>)>>(prism_rtl::rc([=, into_1 = std::move(into_1)](std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::XArm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto into_1_2 = into_1;
            entered(once_job([=, into_1_2 = std::move(into_1_2)]() {
            return ({
                auto a = p0;
                auto arm = p1;
                call_value(fold_job(prism_rtl::deref(arm).conds, a, ({
                auto into_1_2_2 = into_1_2;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, bool>>(std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Cc>)>>(prism_rtl::rc([=, into_1_2_2 = std::move(into_1_2_2)](std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Cc> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto into_1_2_2_2 = into_1_2_2;
                    entered(once_job([=, into_1_2_2_2 = std::move(into_1_2_2_2)]() {
                    return ({
                        auto a2 = p0;
                        auto c = p1;
                        (prism_rtl::more(prism_rtl::rc(ReadsCond(c, into_1_2_2_2, a2))));
                    });
                }));
                });
            }));
            })), [=](std::tuple<Array<Text>, bool> fold_25994) { return prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(arm).body, into_1_2, fold_25994))); });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<Text>, bool>> ReadsArms::cycle() const {
    const auto& arms = this->arms;
    const auto& into = this->into;
    const auto& acc = this->acc;
    return fold_job(arms, acc, ({
        auto into_1 = prism_rtl::deref(into);
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, bool>>(std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::XArm>)>>(prism_rtl::rc([=, into_1 = std::move(into_1)](std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::XArm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto into_1_2 = into_1;
            entered(once_job([=, into_1_2 = std::move(into_1_2)]() {
            return ({
                auto a = p0;
                auto arm = p1;
                call_value(fold_job(prism_rtl::deref(arm).conds, a, ({
                auto into_1_2_2 = into_1_2;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, bool>>(std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Cc>)>>(prism_rtl::rc([=, into_1_2_2 = std::move(into_1_2_2)](std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Cc> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto into_1_2_2_2 = into_1_2_2;
                    entered(once_job([=, into_1_2_2_2 = std::move(into_1_2_2_2)]() {
                    return ({
                        auto a2 = p0;
                        auto c = p1;
                        (prism_rtl::more(prism_rtl::rc(ReadsCond(c, into_1_2_2_2, a2))));
                    });
                }));
                });
            }));
            })), [=](std::tuple<Array<Text>, bool> fold_25994) { return prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(arm).body, into_1_2, fold_25994))); });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start ReadsArms, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, bool>> start_reads_arms(Array<crate::lower::model::XArm> arms, bool into, std::tuple<Array<Text>, bool> acc) {
    return prism_rtl::make_rc<ReadsArms>(arms, into, acc);
}


/// ReadsCond: unbounded fn Cc, Bool, (([Text], Bool)) -> (([Text], Bool))
std::tuple<Array<Text>, bool> reads_cond(const crate::lower::model::Cc& cc0, const bool& into, const std::tuple<Array<Text>, bool>& acc) {
    if (prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0)) {
        auto&& x = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a1;
        return reads_of(x, into, acc);
    }
    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0)) {
        auto&& x = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc0).a0;
        return reads_of(x, into, acc);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Array<Text>, bool>> ReadsCond::cycle() const {
    const auto& cc0 = this->cc0;
    const auto& into = this->into;
    const auto& acc = this->acc;
    return ({
        prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a1;
        prism_rtl::more(prism_rtl::rc(ReadsOf(x, prism_rtl::deref(into), acc)));
    })
        : prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc0).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(x, prism_rtl::deref(into), acc)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ReadsCond, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, bool>> start_reads_cond(crate::lower::model::Cc cc0, bool into, std::tuple<Array<Text>, bool> acc) {
    return prism_rtl::make_rc<ReadsCond>(cc0, into, acc);
}


/// ReadsDos: unbounded fn [Do], Bool, (([Text], Bool)) -> (([Text], Bool))
std::tuple<Array<Text>, bool> reads_dos(const Array<crate::lower::model::Do>& dos, const bool& into, const std::tuple<Array<Text>, bool>& acc) {
    return run_to_end(fold_job(dos, acc, ({
        auto into_1 = into;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, bool>>(std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Do>)>>(prism_rtl::rc([=, into_1 = std::move(into_1)](std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Do> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto into_1_2 = into_1;
            entered(once_job([=, into_1_2 = std::move(into_1_2)]() {
            return ({
                auto a = p0;
                auto d = p1;
                ({
                prism_rtl::is<crate::lower::model::Do::DoLet>(d) ? ({
                auto&& x = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a1;
                prism_rtl::more(prism_rtl::rc(ReadsOf(x, into_1_2, a)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoLetElse>(d) ? ({
                auto&& x = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a1;
                auto&& e = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a2;
                prism_rtl::more(prism_rtl::rc(ReadsEach(Array(std::vector{x, e}), into_1_2, a)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoAssign>(d) ? ({
                auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoAssign>(d).a0;
                auto&& x = prism_rtl::as<crate::lower::model::Do::DoAssign>(d).a1;
                prism_rtl::more(prism_rtl::rc(ReadsEach(Array(std::vector{p_, x}), into_1_2, a)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoWhile>(d) ? ({
                auto&& c = prism_rtl::as<crate::lower::model::Do::DoWhile>(d).a0;
                auto&& body = prism_rtl::as<crate::lower::model::Do::DoWhile>(d).a1;
                ({
                auto body_2 = body;
                auto c_3 = c;
                call_then(start_reads_of(c_3, into_1_2, a), [=, body_2 = std::move(body_2)](std::tuple<Array<Text>, bool> reads_of_26558) { return prism_rtl::more(prism_rtl::rc(ReadsDos(body_2, into_1_2, reads_of_26558))); });
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoWhileLet>(d) ? ({
                auto&& x = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a1;
                auto&& body = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a2;
                ({
                auto body_2 = body;
                auto x_3 = x;
                call_then(start_reads_of(x_3, into_1_2, a), [=, body_2 = std::move(body_2)](std::tuple<Array<Text>, bool> reads_of_26632) { return prism_rtl::more(prism_rtl::rc(ReadsDos(body_2, into_1_2, reads_of_26632))); });
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoFor>(d) ? ({
                auto&& x = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a1;
                auto&& body = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a2;
                ({
                auto body_2 = body;
                auto x_3 = x;
                call_then(start_reads_of(x_3, into_1_2, a), [=, body_2 = std::move(body_2)](std::tuple<Array<Text>, bool> reads_of_26701) { return prism_rtl::more(prism_rtl::rc(ReadsDos(body_2, into_1_2, reads_of_26701))); });
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoExpr>(d) ? ({
                auto&& x = prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0;
                prism_rtl::more(prism_rtl::rc(ReadsOf(x, into_1_2, a)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoIf>(d) ? ({
                auto&& c = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a0;
                auto&& t = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a1;
                auto&& e = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a2;
                ({
                auto c_2 = c;
                auto e_3 = e;
                auto t_4 = t;
                call_then(start_reads_of(c_2, into_1_2, a), [=, e_3 = std::move(e_3), t_4 = std::move(t_4)](std::tuple<Array<Text>, bool> reads_of_26810) { return call_then(start_reads_dos(t_4, into_1_2, reads_of_26810), [=](std::tuple<Array<Text>, bool> reads_dos_26791) { return prism_rtl::more(prism_rtl::rc(ReadsDos(e_3, into_1_2, reads_dos_26791))); }); });
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoIfLet>(d) ? ({
                auto&& x = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a1;
                auto&& t = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a2;
                auto&& e = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a3;
                ({
                auto e_2 = e;
                auto t_3 = t;
                auto x_4 = x;
                call_then(start_reads_of(x_4, into_1_2, a), [=, e_2 = std::move(e_2), t_3 = std::move(t_3)](std::tuple<Array<Text>, bool> reads_of_26898) { return call_then(start_reads_dos(t_3, into_1_2, reads_of_26898), [=](std::tuple<Array<Text>, bool> reads_dos_26879) { return prism_rtl::more(prism_rtl::rc(ReadsDos(e_2, into_1_2, reads_dos_26879))); }); });
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoMatch>(d) ? ({
                auto&& x = prism_rtl::as<crate::lower::model::Do::DoMatch>(d).a0;
                auto&& cases = prism_rtl::as<crate::lower::model::Do::DoMatch>(d).a1;
                ({
                auto cases_2 = cases;
                auto x_3 = x;
                call_then(start_reads_of(x_3, into_1_2, a), [=, cases_2 = std::move(cases_2)](std::tuple<Array<Text>, bool> reads_of_26954) {
                return fold_job(cases_2, reads_of_26954, ({
                    auto into_1_2_4 = into_1_2;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, bool>>(std::tuple<std::tuple<Array<Text>, bool>, std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>>)>>(prism_rtl::rc([=, into_1_2_4 = std::move(into_1_2_4)](std::tuple<std::tuple<Array<Text>, bool>, std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto into_1_2_4_4 = into_1_2_4;
                        entered(once_job([=, into_1_2_4_4 = std::move(into_1_2_4_4)]() {
                        return ({
                            auto a2 = p0;
                            auto&& _body = p1;
                            auto&& body = std::get<1>(_body);
                            (prism_rtl::more(prism_rtl::rc(ReadsDos(body, into_1_2_4_4, a2))));
                        });
                    }));
                    });
                }));
                }))->cycle();
            });
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoReturn>(d) ? ({
                auto&& x = prism_rtl::as<crate::lower::model::Do::DoReturn>(d).a0;
                prism_rtl::more(prism_rtl::rc(ReadsOf(x, into_1_2, a)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoBlock>(d) ? ({
                auto&& body = prism_rtl::as<crate::lower::model::Do::DoBlock>(d).a0;
                prism_rtl::more(prism_rtl::rc(ReadsDos(body, into_1_2, a)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoScope>(d) ? ({
                auto&& body = prism_rtl::as<crate::lower::model::Do::DoScope>(d).a0;
                prism_rtl::more(prism_rtl::rc(ReadsDos(body, into_1_2, a)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoLine>(d) ? ({
                auto&& body = prism_rtl::as<crate::lower::model::Do::DoLine>(d).a0;
                prism_rtl::more(prism_rtl::rc(ReadsDos(body, into_1_2, a)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoNote>(d) ? prism_rtl::finished(a)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<Text>, bool>> ReadsDos::cycle() const {
    const auto& dos = this->dos;
    const auto& into = this->into;
    const auto& acc = this->acc;
    return fold_job(dos, acc, ({
        auto into_1 = prism_rtl::deref(into);
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, bool>>(std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Do>)>>(prism_rtl::rc([=, into_1 = std::move(into_1)](std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Do> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto into_1_2 = into_1;
            entered(once_job([=, into_1_2 = std::move(into_1_2)]() {
            return ({
                auto a = p0;
                auto d = p1;
                ({
                prism_rtl::is<crate::lower::model::Do::DoLet>(d) ? ({
                auto&& x = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a1;
                prism_rtl::more(prism_rtl::rc(ReadsOf(x, into_1_2, a)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoLetElse>(d) ? ({
                auto&& x = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a1;
                auto&& e = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a2;
                prism_rtl::more(prism_rtl::rc(ReadsEach(Array(std::vector{x, e}), into_1_2, a)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoAssign>(d) ? ({
                auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoAssign>(d).a0;
                auto&& x = prism_rtl::as<crate::lower::model::Do::DoAssign>(d).a1;
                prism_rtl::more(prism_rtl::rc(ReadsEach(Array(std::vector{p_, x}), into_1_2, a)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoWhile>(d) ? ({
                auto&& c = prism_rtl::as<crate::lower::model::Do::DoWhile>(d).a0;
                auto&& body = prism_rtl::as<crate::lower::model::Do::DoWhile>(d).a1;
                ({
                auto body_2 = body;
                auto c_3 = c;
                call_then(start_reads_of(c_3, into_1_2, a), [=, body_2 = std::move(body_2)](std::tuple<Array<Text>, bool> reads_of_26558) { return prism_rtl::more(prism_rtl::rc(ReadsDos(body_2, into_1_2, reads_of_26558))); });
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoWhileLet>(d) ? ({
                auto&& x = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a1;
                auto&& body = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a2;
                ({
                auto body_2 = body;
                auto x_3 = x;
                call_then(start_reads_of(x_3, into_1_2, a), [=, body_2 = std::move(body_2)](std::tuple<Array<Text>, bool> reads_of_26632) { return prism_rtl::more(prism_rtl::rc(ReadsDos(body_2, into_1_2, reads_of_26632))); });
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoFor>(d) ? ({
                auto&& x = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a1;
                auto&& body = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a2;
                ({
                auto body_2 = body;
                auto x_3 = x;
                call_then(start_reads_of(x_3, into_1_2, a), [=, body_2 = std::move(body_2)](std::tuple<Array<Text>, bool> reads_of_26701) { return prism_rtl::more(prism_rtl::rc(ReadsDos(body_2, into_1_2, reads_of_26701))); });
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoExpr>(d) ? ({
                auto&& x = prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0;
                prism_rtl::more(prism_rtl::rc(ReadsOf(x, into_1_2, a)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoIf>(d) ? ({
                auto&& c = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a0;
                auto&& t = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a1;
                auto&& e = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a2;
                ({
                auto c_2 = c;
                auto e_3 = e;
                auto t_4 = t;
                call_then(start_reads_of(c_2, into_1_2, a), [=, e_3 = std::move(e_3), t_4 = std::move(t_4)](std::tuple<Array<Text>, bool> reads_of_26810) { return call_then(start_reads_dos(t_4, into_1_2, reads_of_26810), [=](std::tuple<Array<Text>, bool> reads_dos_26791) { return prism_rtl::more(prism_rtl::rc(ReadsDos(e_3, into_1_2, reads_dos_26791))); }); });
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoIfLet>(d) ? ({
                auto&& x = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a1;
                auto&& t = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a2;
                auto&& e = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a3;
                ({
                auto e_2 = e;
                auto t_3 = t;
                auto x_4 = x;
                call_then(start_reads_of(x_4, into_1_2, a), [=, e_2 = std::move(e_2), t_3 = std::move(t_3)](std::tuple<Array<Text>, bool> reads_of_26898) { return call_then(start_reads_dos(t_3, into_1_2, reads_of_26898), [=](std::tuple<Array<Text>, bool> reads_dos_26879) { return prism_rtl::more(prism_rtl::rc(ReadsDos(e_2, into_1_2, reads_dos_26879))); }); });
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoMatch>(d) ? ({
                auto&& x = prism_rtl::as<crate::lower::model::Do::DoMatch>(d).a0;
                auto&& cases = prism_rtl::as<crate::lower::model::Do::DoMatch>(d).a1;
                ({
                auto cases_2 = cases;
                auto x_3 = x;
                call_then(start_reads_of(x_3, into_1_2, a), [=, cases_2 = std::move(cases_2)](std::tuple<Array<Text>, bool> reads_of_26954) {
                return fold_job(cases_2, reads_of_26954, ({
                    auto into_1_2_4 = into_1_2;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, bool>>(std::tuple<std::tuple<Array<Text>, bool>, std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>>)>>(prism_rtl::rc([=, into_1_2_4 = std::move(into_1_2_4)](std::tuple<std::tuple<Array<Text>, bool>, std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto into_1_2_4_4 = into_1_2_4;
                        entered(once_job([=, into_1_2_4_4 = std::move(into_1_2_4_4)]() {
                        return ({
                            auto a2 = p0;
                            auto&& _body = p1;
                            auto&& body = std::get<1>(_body);
                            (prism_rtl::more(prism_rtl::rc(ReadsDos(body, into_1_2_4_4, a2))));
                        });
                    }));
                    });
                }));
                }))->cycle();
            });
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoReturn>(d) ? ({
                auto&& x = prism_rtl::as<crate::lower::model::Do::DoReturn>(d).a0;
                prism_rtl::more(prism_rtl::rc(ReadsOf(x, into_1_2, a)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoBlock>(d) ? ({
                auto&& body = prism_rtl::as<crate::lower::model::Do::DoBlock>(d).a0;
                prism_rtl::more(prism_rtl::rc(ReadsDos(body, into_1_2, a)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoScope>(d) ? ({
                auto&& body = prism_rtl::as<crate::lower::model::Do::DoScope>(d).a0;
                prism_rtl::more(prism_rtl::rc(ReadsDos(body, into_1_2, a)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoLine>(d) ? ({
                auto&& body = prism_rtl::as<crate::lower::model::Do::DoLine>(d).a0;
                prism_rtl::more(prism_rtl::rc(ReadsDos(body, into_1_2, a)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoNote>(d) ? prism_rtl::finished(a)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start ReadsDos, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, bool>> start_reads_dos(Array<crate::lower::model::Do> dos, bool into, std::tuple<Array<Text>, bool> acc) {
    return prism_rtl::make_rc<ReadsDos>(dos, into, acc);
}


/// IsCtor: fn Ex, Text -> Bool
bool is_ctor(const crate::lower::model::Ex& ex0, const Text& c) {
    if (prism_rtl::is<crate::lower::model::Ex::XCtor>(ex0)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XCtor>(ex0).a0;
        return p_ == c;
    }
    {
        auto&& x = ex0;
        return false;
    }
}


/// ?ErrOf: fn Ex -> ?Ex
std::optional<crate::lower::model::Ex> err_of(const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XCtor>(x)) {
        auto&& m27398_0_0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a0;
        auto&& m27398_0_1 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a1;
        if (m27398_0_0 == Text::lit("Err")) {
            if (m27398_0_1.size() == 1u) {
                {
                    auto&& _c1 = index(m27398_0_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& y = prism_rtl::some_of(_c1);
                        return std::optional(y);
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x)) {
        auto&& tail = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        return err_of(prism_rtl::deref(prism_rtl::deref(tail)));
    }
    {
        return std::optional<crate::lower::model::Ex>{};
    }
}


/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
Text ok_branch(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& x, const crate::lower::model::Ex& y) {
    if (prism_rtl::is<crate::lower::model::Ex::XCtor>(x)) {
        auto&& m27701_0_0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a0;
        auto&& m27701_0_1 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a1;
        if (m27701_0_0 == Text::lit("Ok")) {
            if (m27701_0_1.size() == 1u) {
                {
                    auto&& _c1 = index(m27701_0_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& v_ = prism_rtl::some_of(_c1);
                        return prism_rtl::cat("Expected<std::decay_t<decltype(", cpp_expr(cp, v_), ")>, std::decay_t<decltype(", cpp_expr(cp, y), ")>>(", cpp_expr(cp, v_), ")");
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x)) {
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& m27701_1_1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        if (prism_rtl::is<crate::lower::model::Ex::XCtor>(prism_rtl::deref(prism_rtl::deref(m27701_1_1)))) {
            auto&& m27701_1_1_r_0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(prism_rtl::deref(prism_rtl::deref(m27701_1_1))).a0;
            auto&& m27701_1_1_r_1 = prism_rtl::as<crate::lower::model::Ex::XCtor>(prism_rtl::deref(prism_rtl::deref(m27701_1_1))).a1;
            if (m27701_1_1_r_0 == Text::lit("Ok")) {
                if (m27701_1_1_r_1.size() == 1u) {
                    {
                        auto&& _c1 = index(m27701_1_1_r_1, Nat(0u));
                        if (prism_rtl::is_some(_c1)) {
                            auto&& v_ = prism_rtl::some_of(_c1);
                            auto [st, cp2] = crate::emit::cpp::stmts::cpp_statements_cp(cp, dos);
                            return crate::emit::cpp::templates::items::stmt_expr(st, prism_rtl::cat("Expected<std::decay_t<decltype(", cpp_expr(cp2, v_), ")>, std::decay_t<decltype(", cpp_expr(cp2, y), ")>>(", cpp_expr(cp2, v_), ")"));
                        }
                    }
                }
            }
        }
    }
    {
        return cpp_expr(cp, x);
    }
}


prism_rtl::Turn<Text> OkBranch::cycle() const {
    const auto& cp = this->cp;
    const auto& x = this->x;
    const auto& y = this->y;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XCtor>(x) && ({
        auto&& m27701_0_0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a0;
        auto&& m27701_0_1 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a1;
        (m27701_0_0 == Text::lit("Ok")) && (m27701_0_1.size() == 1u) && ({
        auto&& _c1 = index(m27701_0_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m27701_0_0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a0;
        auto&& m27701_0_1 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a1;
        auto&& _c1 = index(m27701_0_1, Nat(0u));
        auto&& v_ = prism_rtl::some_of(_c1);
        ({
        auto cp_1 = cp;
        auto y_2 = y;
        call_then(start_cpp_expr(cp_1, v_), [=, y_2 = std::move(y_2)](Text cpp_expr_27766) { return call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_27807) { return call_then(start_cpp_expr(cp_1, v_), [=](Text cpp_expr_27826) { return prism_rtl::finished(prism_rtl::cat("Expected<std::decay_t<decltype(", cpp_expr_27766, ")>, std::decay_t<decltype(", cpp_expr_27807, ")>>(", cpp_expr_27826, ")")); }); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XBlock>(x) && ({
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& m27701_1_1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        prism_rtl::is<crate::lower::model::Ex::XCtor>(prism_rtl::deref(prism_rtl::deref(m27701_1_1))) && ({
        auto&& m27701_1_1_r_0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(prism_rtl::deref(prism_rtl::deref(m27701_1_1))).a0;
        auto&& m27701_1_1_r_1 = prism_rtl::as<crate::lower::model::Ex::XCtor>(prism_rtl::deref(prism_rtl::deref(m27701_1_1))).a1;
        (m27701_1_1_r_0 == Text::lit("Ok")) && (m27701_1_1_r_1.size() == 1u) && ({
        auto&& _c1 = index(m27701_1_1_r_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    });
    }) ? ({
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& m27701_1_1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        auto&& m27701_1_1_r_0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(prism_rtl::deref(prism_rtl::deref(m27701_1_1))).a0;
        auto&& m27701_1_1_r_1 = prism_rtl::as<crate::lower::model::Ex::XCtor>(prism_rtl::deref(prism_rtl::deref(m27701_1_1))).a1;
        auto&& _c1 = index(m27701_1_1_r_1, Nat(0u));
        auto&& v_ = prism_rtl::some_of(_c1);
        ({
        auto cp_1 = cp;
        auto dos_2 = dos;
        auto y_3 = y;
        call_then(crate::emit::cpp::stmts::start_cpp_statements_cp(cp_1, dos_2), [=, y_3 = std::move(y_3)](std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp_27906) {
        return ({
            auto [st, cp2] = cpp_statements_cp_27906;
            call_then(start_cpp_expr(cp2, v_), [=](Text cpp_expr_27984) { return call_then(start_cpp_expr(cp2, y_3), [=](Text cpp_expr_28026) { return call_then(start_cpp_expr(cp2, v_), [=](Text cpp_expr_28046) { return prism_rtl::finished(crate::emit::cpp::templates::items::stmt_expr(st, prism_rtl::cat("Expected<std::decay_t<decltype(", cpp_expr_27984, ")>, std::decay_t<decltype(", cpp_expr_28026, ")>>(", cpp_expr_28046, ")"))); }); }); });
        });
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(CppExpr(cp, x)));
    });
}


/// `Start OkBranch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ok_branch(crate::emit::cpp::Cp cp, crate::lower::model::Ex x, crate::lower::model::Ex y) {
    return prism_rtl::make_rc<OkBranch>(cp, x, y);
}


/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
Text cpp_closure(const crate::emit::cpp::Cp& cp0, const bool& mv, const Array<crate::lower::model::Pa>& ps, const crate::lower::model::Ex& body) {
    auto names = crate::emit::cpp::patterns::concat2(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::stmts::PatNames(p_))));
            });
        }));
    })))));
    auto cp = fold(ps, crate::emit::cpp::stmts::unbind(crate::emit::cpp::stmts::captured(cp0), names), [&](const crate::emit::cpp::Cp& c, const crate::lower::model::Pa& p_) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::emit::cpp::Cp> _v;
            if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_)) {
                auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
                _v.set(crate::emit::cpp::stmts::owning(c, n));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
                auto&& m28683_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
                if (prism_rtl::is<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(m28683_1_0)))) {
                    auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(m28683_1_0))).a0;
                    _v.set(crate::emit::cpp::stmts::owning(c, n));
                    goto _done;
                }
            }
            {
                _v.set(c);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto params = crate::syntax::lexer::chars::join(run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_1 = std::move(cp_1), ps_2 = std::move(ps_2)](Nat p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto ps_2_3 = ps_2;
            entered(once_job([=, cp_1_3 = std::move(cp_1_3), ps_2_3 = std::move(ps_2_3)]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(ClosureParam(cp_1_3, or_(index(ps_2_3, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), i))));
            });
        }));
        });
    })));
    }))), Text::lit(", "));
    auto binds = concat(run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_1 = std::move(cp_1), ps_2 = std::move(ps_2)](Nat p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto ps_2_3 = ps_2;
            entered(once_job([=, cp_1_3 = std::move(cp_1_3), ps_2_3 = std::move(ps_2_3)]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(ClosureBinds(cp_1_3, or_(index(ps_2_3, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), i))));
            });
        }));
        });
    })));
    }))));
    auto b = cpp_expr(cp, body);
    auto moved = mv
        ? filter(cp0.move_captures, [&](const Text& n) { return (or_(crate::prelude::get(cp0.owned, n), false) && (!crate::emit::cpp::in_list(names, n))) && crate::emit::cpp::stmts::cpp_mentions(b, crate::emit::cpp::stmts::var_name(cp0, n)); })
        : Array<Text>{};
    auto capture = crate::syntax::lexer::chars::join(append(Array(std::vector{mv ? Text::lit("=") : Text::lit("&")}), each(moved, [&](const Text& n) { return prism_rtl::cat(crate::emit::cpp::stmts::var_name(cp0, n), " = std::move(", crate::emit::cpp::stmts::var_name(cp0, n), ")"); })), Text::lit(", "));
    auto [ret, value] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Text>> _v;
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(body)) {
            _v.set(std::tuple{Text::lit(" -> decltype(auto)"), prism_rtl::cat("(", b, ")")});
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Ex::XRefMut>(body)) {
            _v.set(std::tuple{Text::lit(" -> decltype(auto)"), prism_rtl::cat("(", b, ")")});
            goto _done;
        }
        {
            _v.set(std::tuple{Text::lit(""), b});
            goto _done;
        }
    _done:
        _v.take();
    });
    return (binds == Text::lit("")) && (!crate::syntax::lexer::chars::contains(b, Text::lit("\n")))
        ? prism_rtl::cat("[", capture, "](", params, ")", ret, " { return ", value, "; }")
        : crate::emit::cpp::templates::items::lambda(capture, prism_rtl::cat(params, ")", ret), prism_rtl::cat(binds, "return ", value, ";"));
}


prism_rtl::Turn<Text> CppClosure::cycle() const {
    const auto& cp0 = this->cp0;
    const auto& mv = this->mv;
    const auto& ps = this->ps;
    const auto& body = this->body;
    auto body_1 = body;
    auto cp0_2 = cp0;
    auto mv_3 = prism_rtl::deref(mv);
    auto ps_4 = ps;
    return call_value(each_job(ps_4, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::stmts::PatNames(p_))));
            });
        }));
    }))), [=](Array<Array<Text>> each_28595) {
        return ({
            auto names = crate::emit::cpp::patterns::concat2(each_28595);
            auto cp = fold(ps_4, crate::emit::cpp::stmts::unbind(crate::emit::cpp::stmts::captured(cp0_2), names), [&](const crate::emit::cpp::Cp& c, const crate::lower::model::Pa& p_) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<crate::emit::cpp::Cp> _v;
                    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_)) {
                        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
                        _v.set(crate::emit::cpp::stmts::owning(c, n));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
                        auto&& m28683_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
                        if (prism_rtl::is<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(m28683_1_0)))) {
                            auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(m28683_1_0))).a0;
                            _v.set(crate::emit::cpp::stmts::owning(c, n));
                            goto _done;
                        }
                    }
                    {
                        _v.set(c);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            call_value(each_job(crate::check::errors::range0(len(ps_4)), ({
            auto cp_5 = cp;
            auto ps_4_6 = ps_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_5 = std::move(cp_5), ps_4_6 = std::move(ps_4_6)](Nat p0) {
            return ({
                auto cp_5_6 = cp_5;
                auto ps_4_6_6 = ps_4_6;
                entered(once_job([=, cp_5_6 = std::move(cp_5_6), ps_4_6_6 = std::move(ps_4_6_6)]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(ClosureParam(cp_5_6, or_(index(ps_4_6_6, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), i))));
                });
            }));
            });
        })));
        })), [=, names = std::move(names)](Array<Text> each_28812) {
            return ({
                auto params = crate::syntax::lexer::chars::join(each_28812, Text::lit(", "));
                call_value(each_job(crate::check::errors::range0(len(ps_4)), ({
                auto cp_5 = cp;
                auto ps_4_6 = ps_4;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_5 = std::move(cp_5), ps_4_6 = std::move(ps_4_6)](Nat p0) {
                return ({
                    auto cp_5_6 = cp_5;
                    auto ps_4_6_6 = ps_4_6;
                    entered(once_job([=, cp_5_6 = std::move(cp_5_6), ps_4_6_6 = std::move(ps_4_6_6)]() {
                    return ({
                        auto i = p0;
                        (prism_rtl::more(prism_rtl::rc(ClosureBinds(cp_5_6, or_(index(ps_4_6_6, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), i))));
                    });
                }));
                });
            })));
            })), [=, params = std::move(params)](Array<Text> each_28911) {
                return ({
                    auto binds = concat(each_28911);
                    call_then(start_cpp_expr(cp, body_1), [=, binds = std::move(binds)](Text cpp_expr_28992) {
                    return ({
                        auto b = cpp_expr_28992;
                        auto moved = mv_3
                            ? filter(prism_rtl::deref(cp0_2).move_captures, [&](const Text& n) { return (or_(crate::prelude::get(prism_rtl::deref(cp0_2).owned, n), false) && (!crate::emit::cpp::in_list(names, n))) && crate::emit::cpp::stmts::cpp_mentions(b, crate::emit::cpp::stmts::var_name(cp0_2, n)); })
                            : Array<Text>{};
                        auto capture = crate::syntax::lexer::chars::join(append(Array(std::vector{mv_3 ? Text::lit("=") : Text::lit("&")}), each(moved, [&](const Text& n) { return prism_rtl::cat(crate::emit::cpp::stmts::var_name(cp0_2, n), " = std::move(", crate::emit::cpp::stmts::var_name(cp0_2, n), ")"); })), Text::lit(", "));
                        auto [ret, value] = ({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<Text, Text>> _v;
                            if (prism_rtl::is<crate::lower::model::Ex::XRef>(body_1)) {
                                _v.set(std::tuple{Text::lit(" -> decltype(auto)"), prism_rtl::cat("(", b, ")")});
                                goto _done;
                            }
                            if (prism_rtl::is<crate::lower::model::Ex::XRefMut>(body_1)) {
                                _v.set(std::tuple{Text::lit(" -> decltype(auto)"), prism_rtl::cat("(", b, ")")});
                                goto _done;
                            }
                            {
                                _v.set(std::tuple{Text::lit(""), b});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        (binds == Text::lit("")) && (!crate::syntax::lexer::chars::contains(b, Text::lit("\n")))
                        ? prism_rtl::finished(prism_rtl::cat("[", capture, "](", params, ")", ret, " { return ", value, "; }"))
                        : prism_rtl::finished(crate::emit::cpp::templates::items::lambda(capture, prism_rtl::cat(params, ")", ret), prism_rtl::cat(binds, "return ", value, ";")));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start CppClosure, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_closure(crate::emit::cpp::Cp cp0, bool mv, Array<crate::lower::model::Pa> ps, crate::lower::model::Ex body) {
    return prism_rtl::make_rc<CppClosure>(cp0, mv, ps, body);
}


/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
Text closure_param(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& pa1, const Nat& i) {
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1)) {
        auto&& c0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(c0_1_0)))) {
            auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(c0_1_0))).a0;
            return prism_rtl::cat(param_type(cp, t), " ", crate::emit::cpp::cpp_id(n));
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1)) {
        auto&& c1_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(c1_1_0)))) {
            auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(c1_1_0))).a0;
            return prism_rtl::cat(crate::emit::cpp::cpp_type(cp, unref(t)), " ", crate::emit::cpp::cpp_id(n));
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        return prism_rtl::cat(param_type(cp, t), " _p", i);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(pa1)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(pa1).a0;
        return prism_rtl::cat("auto&& ", crate::emit::cpp::cpp_id(n));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(pa1)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(pa1).a0;
        return prism_rtl::cat("auto ", crate::emit::cpp::cpp_id(n));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(pa1)) {
        return Text::lit("const auto&");
    }
    {
        auto&& p_ = pa1;
        return prism_rtl::cat("const auto& _p", i);
    }
}


prism_rtl::Turn<Text> ClosureParam::cycle() const {
    const auto& cp = this->cp;
    const auto& pa1 = this->pa1;
    const auto& i = this->i;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1) && ({
        auto&& j0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        prism_rtl::is<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(j0_1_0)));
    }) ? ({
        auto&& j0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(j0_1_0))).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto t_3 = t;
        call_then(start_param_type(cp_1, t_3), [=, n_2 = std::move(n_2)](Text param_type_29741) { return prism_rtl::finished(prism_rtl::cat(param_type_29741, " ", crate::emit::cpp::cpp_id(n_2))); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1) && ({
        auto&& j1_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        prism_rtl::is<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(j1_1_0)));
    }) ? ({
        auto&& j1_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(j1_1_0))).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto t_3 = t;
        call_then(crate::emit::cpp::start_cpp_type(cp_1, unref(t_3)), [=, n_2 = std::move(n_2)](Text cpp_type_29819) { return prism_rtl::finished(prism_rtl::cat(cpp_type_29819, " ", crate::emit::cpp::cpp_id(n_2))); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        auto t_3 = t;
        call_then(start_param_type(cp_1, t_3), [=, i_2 = std::move(i_2)](Text param_type_29895) { return prism_rtl::finished(prism_rtl::cat(param_type_29895, " _p", i_2)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaBind>(pa1) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(pa1).a0;
        prism_rtl::finished(prism_rtl::cat("auto&& ", crate::emit::cpp::cpp_id(n)));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(pa1) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(pa1).a0;
        prism_rtl::finished(prism_rtl::cat("auto ", crate::emit::cpp::cpp_id(n)));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaWild>(pa1) ? prism_rtl::finished(Text::lit("const auto&"))
        : ({
        auto&& p_ = pa1;
        prism_rtl::finished(prism_rtl::cat("const auto& _p", i));
    });
    });
}


/// `Start ClosureParam, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_closure_param(crate::emit::cpp::Cp cp, crate::lower::model::Pa pa1, Nat i) {
    return prism_rtl::make_rc<ClosureParam>(cp, pa1, i);
}


/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
Text closure_binds(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& pa1, const Nat& i) {
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1)) {
        auto&& c0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(c0_1_0)))) {
            auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(c0_1_0))).a0;
            return Text::lit("");
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1)) {
        auto&& c1_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(c1_1_0)))) {
            auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(c1_1_0))).a0;
            return Text::lit("");
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        return closure_binds(cp, prism_rtl::deref(prism_rtl::deref(p_)), i);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(pa1)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(pa1).a0;
        return Text::lit("");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(pa1)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(pa1).a0;
        return Text::lit("");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(pa1)) {
        return Text::lit("");
    }
    {
        auto&& p_ = pa1;
        return concat(each(crate::emit::cpp::patterns::pat_binds(cp, p_, prism_rtl::cat("_p", i)), [&](const Text& b) { return prism_rtl::cat(b, "\n"); }));
    }
}


prism_rtl::Turn<Text> ClosureBinds::cycle() const {
    const auto& cp = this->cp;
    const auto& pa1 = this->pa1;
    const auto& i = this->i;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1) && ({
        auto&& j0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        prism_rtl::is<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(j0_1_0)));
    }) ? ({
        auto&& j0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(j0_1_0))).a0;
        prism_rtl::finished(Text::lit(""));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1) && ({
        auto&& j1_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        prism_rtl::is<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(j1_1_0)));
    }) ? ({
        auto&& j1_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(j1_1_0))).a0;
        prism_rtl::finished(Text::lit(""));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        prism_rtl::more(prism_rtl::rc(ClosureBinds(cp, prism_rtl::deref(prism_rtl::deref(p_)), i)));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaBind>(pa1) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(pa1).a0;
        prism_rtl::finished(Text::lit(""));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(pa1) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(pa1).a0;
        prism_rtl::finished(Text::lit(""));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaWild>(pa1) ? prism_rtl::finished(Text::lit(""))
        : ({
        auto&& p_ = pa1;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        auto p__3 = p_;
        call_then(crate::emit::cpp::patterns::start_pat_binds(cp_1, p__3, prism_rtl::cat("_p", i_2)), [=](Array<Text> pat_binds_30485) { return prism_rtl::finished(concat(each(pat_binds_30485, [&](const Text& b) { return prism_rtl::cat(b, "\n"); }))); });
    });
    });
    });
}


/// `Start ClosureBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_closure_binds(crate::emit::cpp::Cp cp, crate::lower::model::Pa pa1, Nat i) {
    return prism_rtl::make_rc<ClosureBinds>(cp, pa1, i);
}


/// Unref: fn OutTy -> OutTy
crate::lower::model::OutTy unref(const crate::lower::model::OutTy& out_ty0) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(out_ty0)) {
        auto&& t = prism_rtl::as<crate::lower::model::OutTy::OutRef>(out_ty0).a0;
        return prism_rtl::deref(prism_rtl::deref(t));
    }
    {
        auto&& t = out_ty0;
        return t;
    }
}


/// ParamType: unbounded fn Cp, OutTy -> Text
Text param_type(const crate::emit::cpp::Cp& cp, const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(t)) {
        return crate::emit::cpp::cpp_type(cp, t);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutSlice>(t)) {
        return crate::emit::cpp::cpp_type(cp, t);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnit>(t)) {
        return Text::lit("Unit");
    }
    {
        return crate::emit::cpp::cpp_type(cp, t);
    }
}


prism_rtl::Turn<Text> ParamType::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutRef>(t) ? prism_rtl::more(prism_rtl::rc(crate::emit::cpp::CppType(cp, t)))
        : prism_rtl::is<crate::lower::model::OutTy::OutSlice>(t) ? prism_rtl::more(prism_rtl::rc(crate::emit::cpp::CppType(cp, t)))
        : prism_rtl::is<crate::lower::model::OutTy::OutUnit>(t) ? prism_rtl::finished(Text::lit("Unit"))
        : prism_rtl::more(prism_rtl::rc(crate::emit::cpp::CppType(cp, t)));
    });
}


/// `Start ParamType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_param_type(crate::emit::cpp::Cp cp, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<ParamType>(cp, t);
}

}  // namespace crate::emit::cpp::expr
