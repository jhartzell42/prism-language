// The module `Check.Types.Schemes`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/types/schemes/module.hpp>
#include <check/errors/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Types.Schemes`, from `target/bootstrap/cpp-src/prismc/check/types/schemes.prism`.
namespace crate::check::types::schemes {

bool Inst::operator==(const Inst& o) const { return tys_p == o.tys_p && rows_p == o.rows_p && cols_p == o.cols_p; }

void Inst::show(Printer& p) const {
    p.record("Inst", {{"tys", tys_p}, {"rows", rows_p}, {"cols", cols_p}});
}

Pod Inst::to_pod() const {
    return Pod::record("Inst", {{"tys", prism_rtl::to_pod(tys_p)}, {"rows", prism_rtl::to_pod(rows_p)}, {"cols", prism_rtl::to_pod(cols_p)}});
}

Result<Inst> Inst::from_pod(const Pod& whole) {
    return Inst{.tys_p = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "tys")))), .rows_p = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Tail>>(TRY(crate::prelude::field(whole, "rows")))), .cols_p = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Col>>(TRY(crate::prelude::field(whole, "cols"))))};
}


/// Mono: fn Ty -> Scheme
crate::check::types::Scheme mono_f(const crate::check::types::Ty& t_p0) {
    return crate::check::types::Scheme{.qs_p = Array<Text>{}, .plain_qs_p = Array<Text>{}, .rqs_p = Array<Text>{}, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = Array<std::tuple<Text, Text>>{}, .ty_p = t_p0};
}


/// SubstQ: unbounded fn Inst, Ty -> Ty
crate::check::types::Ty subst_q_f(const Inst& m_p0, const crate::check::types::Ty& t_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t_p1)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyQ>(t_p1).a0;
        return crate::prelude::or_(crate::prelude::get(m_p0.tys_p, n_p2), crate::check::types::Ty(crate::check::types::Ty::TyQ{n_p2}));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& args_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p3, crate::prelude::run_to_end(crate::prelude::each_job(args_p4, ({
            auto m_p0x = m_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0x = std::move(m_p0x)](crate::check::types::Ty p0) {
            return ({
                auto m_p0xy = m_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, m_p0xy = std::move(m_p0xy)]() {
                return ({
                    auto a_p5 = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstQ(m_p0xy, a_p5))));
                });
            })));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1)) {
        auto&& c_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a0;
        auto&& ps_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& res_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{subst_col_f(m_p0, c_p6), crate::prelude::run_to_end(crate::prelude::each_job(ps_p7, ({
            auto m_p0x = m_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0x = std::move(m_p0x)](crate::check::types::Ty p0) {
            return ({
                auto m_p0xy = m_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, m_p0xy = std::move(m_p0xy)]() {
                return ({
                    auto p_p9 = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstQ(m_p0xy, p_p9))));
                });
            })));
            });
        })));
        }))), prism_rtl::rc(subst_q_f(m_p0, prism_rtl::deref(prism_rtl::deref(res_p8))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1)) {
        auto&& ts_pa = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{crate::prelude::run_to_end(crate::prelude::each_job(ts_pa, ({
            auto m_p0x = m_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0x = std::move(m_p0x)](crate::check::types::Ty p0) {
            return ({
                auto m_p0xy = m_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, m_p0xy = std::move(m_p0xy)]() {
                return ({
                    auto a_pb = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstQ(m_p0xy, a_pb))));
                });
            })));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1)) {
        auto&& e_pc = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(subst_q_f(m_p0, prism_rtl::deref(prism_rtl::deref(e_pc))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1)) {
        auto&& k_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(subst_q_f(m_p0, prism_rtl::deref(prism_rtl::deref(k_pd)))), prism_rtl::rc(subst_q_f(m_p0, prism_rtl::deref(prism_rtl::deref(v_pe))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& s_pf = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s_pf, prism_rtl::rc(subst_q_f(m_p0, prism_rtl::deref(prism_rtl::deref(i_pg))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1)) {
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a0;
        auto&& rw_pi = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(subst_q_f(m_p0, prism_rtl::deref(prism_rtl::deref(i_ph)))), subst_row_q_f(m_p0, rw_pi)});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1)) {
        auto&& rw_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a0;
        auto&& o_pk = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyElem{subst_row_q_f(m_p0, rw_pj), prism_rtl::rc(subst_q_f(m_p0, prism_rtl::deref(prism_rtl::deref(o_pk))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p1)) {
        auto&& rw_pl = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t_p1).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyElemAny{subst_row_q_f(m_p0, rw_pl)});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1)) {
        auto&& n_pm = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a0;
        auto&& a_pn = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n_pm, prism_rtl::rc(subst_q_f(m_p0, prism_rtl::deref(prism_rtl::deref(a_pn))))});
    }
    {
        auto&& other_po = t_p1;
        return other_po;
    }
}


prism_rtl::Turn<crate::check::types::Ty> SubstQ::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyQ>(t_p1) ? ({
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyQ>(t_p1).a0;
        prism_rtl::finished(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(m_p0).tys_p, n_p2), crate::check::types::Ty(crate::check::types::Ty::TyQ{n_p2})));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) ? ({
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& args_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        ({
        auto args_p4x = args_p4;
        auto m_p0x = m_p0;
        auto n_p3x = n_p3;
        (crate::prelude::call_value(crate::prelude::each_job(args_p4x, ({
        auto m_p0xx = m_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0xx = std::move(m_p0xx)](crate::check::types::Ty p0) {
        return ({
            auto m_p0xxy = m_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, m_p0xxy = std::move(m_p0xxy)]() {
            return ({
                auto a_p5 = p0;
                (prism_rtl::more(prism_rtl::rc(SubstQ(m_p0xxy, a_p5))));
            });
        })));
        });
    })));
    })), [=, n_p3x = std::move(n_p3x)](Array<crate::check::types::Ty> each_1157) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p3x, each_1157})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1) ? ({
        auto&& c_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a0;
        auto&& ps_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& res_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        ({
        auto c_p6x = c_p6;
        auto m_p0x = m_p0;
        auto ps_p7x = ps_p7;
        auto res_p8x = prism_rtl::deref(prism_rtl::deref(res_p8));
        (crate::prelude::call_value(crate::prelude::each_job(ps_p7x, ({
        auto m_p0xx = m_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0xx = std::move(m_p0xx)](crate::check::types::Ty p0) {
        return ({
            auto m_p0xxy = m_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, m_p0xxy = std::move(m_p0xxy)]() {
            return ({
                auto p_p9 = p0;
                (prism_rtl::more(prism_rtl::rc(SubstQ(m_p0xxy, p_p9))));
            });
        })));
        });
    })));
    })), [=, c_p6x = std::move(c_p6x), res_p8x = std::move(res_p8x)](Array<crate::check::types::Ty> each_1230) { return crate::prelude::call_then(start_subst_q_f(m_p0x, res_p8x), [=](crate::check::types::Ty subst_q_f_1259) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{subst_col_f(m_p0x, c_p6x), each_1230, prism_rtl::rc(subst_q_f_1259)})); }); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1) ? ({
        auto&& ts_pa = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        ({
        auto m_p0x = m_p0;
        auto ts_pax = ts_pa;
        (crate::prelude::call_value(crate::prelude::each_job(ts_pax, ({
        auto m_p0xx = m_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0xx = std::move(m_p0xx)](crate::check::types::Ty p0) {
        return ({
            auto m_p0xxy = m_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, m_p0xxy = std::move(m_p0xxy)]() {
            return ({
                auto a_pb = p0;
                (prism_rtl::more(prism_rtl::rc(SubstQ(m_p0xxy, a_pb))));
            });
        })));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_1299) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyTuple{each_1299})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1) ? ({
        auto&& e_pc = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        ({
        auto e_pcx = prism_rtl::deref(prism_rtl::deref(e_pc));
        auto m_p0x = m_p0;
        (crate::prelude::call_then(start_subst_q_f(m_p0x, e_pcx), [=](crate::check::types::Ty subst_q_f_1350) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(subst_q_f_1350)})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1) ? ({
        auto&& k_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        ({
        auto k_pdx = prism_rtl::deref(prism_rtl::deref(k_pd));
        auto m_p0x = m_p0;
        auto v_pex = prism_rtl::deref(prism_rtl::deref(v_pe));
        (crate::prelude::call_then(start_subst_q_f(m_p0x, k_pdx), [=, v_pex = std::move(v_pex)](crate::check::types::Ty subst_q_f_1386) { return crate::prelude::call_then(start_subst_q_f(m_p0x, v_pex), [=](crate::check::types::Ty subst_q_f_1401) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(subst_q_f_1386), prism_rtl::rc(subst_q_f_1401)})); }); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p1) ? ({
        auto&& s_pf = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        ({
        auto i_pgx = prism_rtl::deref(prism_rtl::deref(i_pg));
        auto m_p0x = m_p0;
        auto s_pfx = s_pf;
        (crate::prelude::call_then(start_subst_q_f(m_p0x, i_pgx), [=, s_pfx = std::move(s_pfx)](crate::check::types::Ty subst_q_f_1440) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{s_pfx, prism_rtl::rc(subst_q_f_1440)})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1) ? ({
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a0;
        auto&& rw_pi = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a1;
        ({
        auto i_phx = prism_rtl::deref(prism_rtl::deref(i_ph));
        auto m_p0x = m_p0;
        auto rw_pix = rw_pi;
        (crate::prelude::call_then(start_subst_q_f(m_p0x, i_phx), [=, rw_pix = std::move(rw_pix)](crate::check::types::Ty subst_q_f_1475) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(subst_q_f_1475), subst_row_q_f(m_p0x, rw_pix)})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1) ? ({
        auto&& rw_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a0;
        auto&& o_pk = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a1;
        ({
        auto m_p0x = m_p0;
        auto o_pkx = prism_rtl::deref(prism_rtl::deref(o_pk));
        auto rw_pjx = rw_pj;
        (crate::prelude::call_then(start_subst_q_f(m_p0x, o_pkx), [=, rw_pjx = std::move(rw_pjx)](crate::check::types::Ty subst_q_f_1552) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyElem{subst_row_q_f(m_p0x, rw_pjx), prism_rtl::rc(subst_q_f_1552)})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p1) ? ({
        auto&& rw_pl = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t_p1).a0;
        prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyElemAny{subst_row_q_f(m_p0, rw_pl)}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1) ? ({
        auto&& n_pm = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a0;
        auto&& a_pn = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        ({
        auto a_pnx = prism_rtl::deref(prism_rtl::deref(a_pn));
        auto m_p0x = m_p0;
        auto n_pmx = n_pm;
        (crate::prelude::call_then(start_subst_q_f(m_p0x, a_pnx), [=, n_pmx = std::move(n_pmx)](crate::check::types::Ty subst_q_f_1641) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n_pmx, prism_rtl::rc(subst_q_f_1641)})); }));
    });
    })
        : ({
        auto&& other_po = t_p1;
        prism_rtl::finished(other_po);
    });
    });
}


/// `Start SubstQ, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_subst_q_f(Inst m_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<SubstQ>(m_p0, t_p1);
}


/// SubstRowQ: fn Inst, Rw -> Rw
crate::check::types::Rw subst_row_q_f(const Inst& m_p0, const crate::check::types::Rw& rw_p1) {
    auto&& _m = rw_p1.tail_p;
    if (prism_rtl::is<crate::check::types::Tail::TlQ>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Tail::TlQ>(_m).a0;
        auto&& _m = crate::prelude::get(m_p0.rows_p, n_p2);
        if (prism_rtl::is_some(_m)) {
            auto&& t_p3 = prism_rtl::some_of(_m);
            return crate::check::types::Rw{.fams_p = rw_p1.fams_p, .minus_p = rw_p1.minus_p, .tail_p = t_p3};
        }
        if (prism_rtl::is_none(_m)) {
            return rw_p1;
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return rw_p1;
    }
}


/// SubstCol: fn Inst, Col -> Col
crate::check::types::Col subst_col_f(const Inst& m_p0, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CQ>(col1)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Col::CQ>(col1).a0;
        return crate::prelude::or_(crate::prelude::get(m_p0.cols_p, n_p1), crate::check::types::Col(crate::check::types::Col::CQ{n_p1}));
    }
    {
        auto&& c_p3 = col1;
        return c_p3;
    }
}


/// Instantiate: unbounded fn St, Scheme, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_f(const crate::check::types::St& st_p0, const crate::check::types::Scheme& sc_p1, const crate::syntax::Range& span_p2) {
    auto&& _t_p3 = instantiate_with_f(st_p0, sc_p1, span_p2, Array<crate::check::types::Ty>{});
    auto&& t_p3 = std::get<0>(_t_p3);
    auto&& st2_p4 = std::get<1>(_t_p3);
    return std::tuple{t_p3, st2_p4};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> Instantiate::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& sc_p1 = this->sc_p1;
    const auto& span_p2 = this->span_p2;
    auto sc_p1x = sc_p1;
    auto span_p2x = span_p2;
    auto st_p0x = st_p0;
    return crate::prelude::call_then(start_instantiate_with_f(st_p0x, sc_p1x, span_p2x, Array<crate::check::types::Ty>{}), [=](std::tuple<crate::check::types::Ty, crate::check::types::St, Inst> instantiate_with_f_2231) {
        return ({
            auto&& _t_p3 = instantiate_with_f_2231;
            auto&& t_p3 = std::get<0>(_t_p3);
            auto&& st2_p4 = std::get<1>(_t_p3);
            (prism_rtl::finished(std::tuple{t_p3, st2_p4}));
        });
    });
}


/// `Start Instantiate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_instantiate_f(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1, crate::syntax::Range span_p2) {
    return prism_rtl::make_rc<Instantiate>(st_p0, sc_p1, span_p2);
}


/// InstantiateWith: unbounded fn St, Scheme, Range, [Ty] -> ((Ty, St, Inst))
std::tuple<crate::check::types::Ty, crate::check::types::St, Inst> instantiate_with_f(const crate::check::types::St& st_p0, const crate::check::types::Scheme& sc_p1, const crate::syntax::Range& span_p2, const Array<crate::check::types::Ty>& explicit_p3) {
    auto [tys_pf, st1_pg] = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(sc_p1.qs_p)), std::tuple{Map<Text, crate::check::types::Ty>{}, st_p0}, [&](const std::tuple<Map<Text, crate::check::types::Ty>, crate::check::types::St>& _p0, const Nat& i_pa) {
        auto&& m_p8 = std::get<0>(_p0);
        auto&& s_p9 = std::get<1>(_p0);
        return ({
            auto q_pb = crate::prelude::or_(crate::prelude::index(sc_p1.qs_p, i_pa), Text::lit(""));
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Map<Text, crate::check::types::Ty>, crate::check::types::St>> _v;
            auto&& _m = crate::prelude::index(explicit_p3, i_pa);
            if (prism_rtl::is_some(_m)) {
                auto&& g_pc = prism_rtl::some_of(_m);
                _v.set(std::tuple{crate::prelude::insert(m_p8, q_pb, g_pc), s_p9});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    auto [v_pd, s2_pe] = crate::check::types::fresh_var_f(s_p9, crate::check::types::has_text_f(sc_p1.plain_qs_p, q_pb), Text::lit(""));
                    std::tuple{crate::prelude::insert(m_p8, q_pb, v_pd), s2_pe};
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    });
    auto nq_p4 = crate::prelude::len(sc_p1.qs_p);
    auto [rows_pm, st2_pn] = crate::prelude::run_to_end(crate::prelude::fold_job(sc_p1.rqs_p, std::tuple{Map<Text, crate::check::types::Tail>{}, st1_pg}, ({
        auto sc_p1x = sc_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, crate::check::types::Tail>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, crate::check::types::Tail>, crate::check::types::St>, Text>)>>(prism_rtl::rc([=, sc_p1x = std::move(sc_p1x)](std::tuple<std::tuple<Map<Text, crate::check::types::Tail>, crate::check::types::St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sc_p1xy = sc_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, sc_p1xy = std::move(sc_p1xy)]() {
            return ({
                auto [m_ph, s_pi] = p0;
                auto q_pj = p1;
                (crate::prelude::call_then(start_lacks_in_f(prism_rtl::deref(sc_p1xy).ty_p, q_pj), [=](Array<Text> lacks_in_f_2973) {
                return ({
                    auto [rw_pk, s2_pl] = crate::check::types::recording::fresh_row_f(s_pi, lacks_in_f_2973);
                    (prism_rtl::finished(std::tuple{crate::prelude::insert(m_ph, q_pj, prism_rtl::deref(rw_pk).tail_p), crate::check::types::unify::name_row_f(s2_pl, prism_rtl::deref(rw_pk).tail_p, q_pj)}));
                });
            }));
            });
        })));
        });
    }));
    })));
    auto [cols_pt, st2b_pu] = crate::prelude::fold(sc_p1.cqs_p, std::tuple{Map<Text, crate::check::types::Col>{}, st2_pn}, [&](const std::tuple<Map<Text, crate::check::types::Col>, crate::check::types::St>& _p0, const Text& q_pq) {
        auto&& m_po = std::get<0>(_p0);
        auto&& s_pp = std::get<1>(_p0);
        return ({
            auto [c_pr, s2_ps] = crate::check::types::fresh_col_f(s_pp);
            std::tuple{crate::prelude::insert(m_po, q_pq, c_pr), s2_ps};
        });
    });
    auto inst_p5 = Inst{.tys_p = tys_pf, .rows_p = rows_pm, .cols_p = cols_pt};
    auto st2c_p6 = crate::prelude::run_to_end(crate::prelude::fold_job(sc_p1.cjoins_p, st2b_pu, ({
        auto cols_ptx = cols_pt;
        auto span_p2x = span_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<Text, Text>>)>>(prism_rtl::rc([=, cols_ptx = std::move(cols_ptx), span_p2x = std::move(span_p2x)](std::tuple<crate::check::types::St, std::tuple<Text, Text>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cols_ptxy = cols_ptx;
            auto span_p2xy = span_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, cols_ptxy = std::move(cols_ptxy), span_p2xy = std::move(span_p2xy)]() {
            return ({
                auto s_pv = p0;
                auto [lo_p10, hi_p11] = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::colors::AddLeq(s_pv, crate::prelude::or_(crate::prelude::get(cols_ptxy, lo_p10), crate::check::types::Col(crate::check::types::Col::CBound{})), crate::prelude::or_(crate::prelude::get(cols_ptxy, hi_p11), crate::check::types::Col(crate::check::types::Col::CBound{})), span_p2xy, Text::lit("arg"), Text::lit(""), Text::lit("")))));
            });
        })));
        });
    })));
    })));
    auto st3_p7 = crate::prelude::fold(sc_p1.bounds_p, st2c_p6, [&](const crate::check::types::St& s_p12, const std::tuple<Text, Text>& _p1) {
        auto&& v_p13 = std::get<0>(_p1);
        auto&& tr_p14 = std::get<1>(_p1);
        return ({
            crate::check::types::St this_ = s_p12;
            this_.wants_p = crate::prelude::push(this_.wants_p, crate::check::types::Want{.cls_p = tr_p14, .ty_p = crate::prelude::or_(crate::prelude::get(tys_pf, v_p13), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), .file_p = prism_rtl::deref(s_p12).file_p, .span_p = span_p2, .level_p = prism_rtl::deref(s_p12).level_p});
            (std::move(this_));
        });
    });
    return std::tuple{subst_q_f(inst_p5, sc_p1.ty_p), st3_p7, inst_p5};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St, Inst>> InstantiateWith::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& sc_p1 = this->sc_p1;
    const auto& span_p2 = this->span_p2;
    const auto& explicit_p3 = this->explicit_p3;
    auto [tys_pf, st1_pg] = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(sc_p1).qs_p)), std::tuple{Map<Text, crate::check::types::Ty>{}, st_p0}, [&](const std::tuple<Map<Text, crate::check::types::Ty>, crate::check::types::St>& _p0, const Nat& i_pa) {
        auto&& m_p8 = std::get<0>(_p0);
        auto&& s_p9 = std::get<1>(_p0);
        return ({
            auto q_pb = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(sc_p1).qs_p, i_pa), Text::lit(""));
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Map<Text, crate::check::types::Ty>, crate::check::types::St>> _v;
            auto&& _m = crate::prelude::index(explicit_p3, i_pa);
            if (prism_rtl::is_some(_m)) {
                auto&& g_pc = prism_rtl::some_of(_m);
                _v.set(std::tuple{crate::prelude::insert(m_p8, q_pb, g_pc), s_p9});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    auto [v_pd, s2_pe] = crate::check::types::fresh_var_f(s_p9, crate::check::types::has_text_f(prism_rtl::deref(sc_p1).plain_qs_p, q_pb), Text::lit(""));
                    std::tuple{crate::prelude::insert(m_p8, q_pb, v_pd), s2_pe};
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    });
    auto nq_p4 = crate::prelude::len(prism_rtl::deref(sc_p1).qs_p);
    auto sc_p1x = sc_p1;
    auto span_p2x = span_p2;
    return crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(sc_p1x).rqs_p, std::tuple{Map<Text, crate::check::types::Tail>{}, st1_pg}, ({
        auto sc_p1xx = sc_p1x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, crate::check::types::Tail>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, crate::check::types::Tail>, crate::check::types::St>, Text>)>>(prism_rtl::rc([=, sc_p1xx = std::move(sc_p1xx)](std::tuple<std::tuple<Map<Text, crate::check::types::Tail>, crate::check::types::St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sc_p1xxy = sc_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, sc_p1xxy = std::move(sc_p1xxy)]() {
            return ({
                auto [m_ph, s_pi] = p0;
                auto q_pj = p1;
                (crate::prelude::call_then(start_lacks_in_f(prism_rtl::deref(sc_p1xxy).ty_p, q_pj), [=](Array<Text> lacks_in_f_2973) {
                return ({
                    auto [rw_pk, s2_pl] = crate::check::types::recording::fresh_row_f(s_pi, lacks_in_f_2973);
                    (prism_rtl::finished(std::tuple{crate::prelude::insert(m_ph, q_pj, prism_rtl::deref(rw_pk).tail_p), crate::check::types::unify::name_row_f(s2_pl, prism_rtl::deref(rw_pk).tail_p, q_pj)}));
                });
            }));
            });
        })));
        });
    }));
    })), [=](std::tuple<Map<Text, crate::check::types::Tail>, crate::check::types::St> fold_2894) {
        return ({
            auto [rows_pm, st2_pn] = fold_2894;
            auto [cols_pt, st2b_pu] = crate::prelude::fold(prism_rtl::deref(sc_p1x).cqs_p, std::tuple{Map<Text, crate::check::types::Col>{}, st2_pn}, [&](const std::tuple<Map<Text, crate::check::types::Col>, crate::check::types::St>& _p0, const Text& q_pq) {
                auto&& m_po = std::get<0>(_p0);
                auto&& s_pp = std::get<1>(_p0);
                return ({
                    auto [c_pr, s2_ps] = crate::check::types::fresh_col_f(s_pp);
                    std::tuple{crate::prelude::insert(m_po, q_pq, c_pr), s2_ps};
                });
            });
            auto inst_p5 = Inst{.tys_p = tys_pf, .rows_p = rows_pm, .cols_p = cols_pt};
            (crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(sc_p1x).cjoins_p, st2b_pu, ({
            auto cols_ptx = cols_pt;
            auto span_p2xx = span_p2x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<Text, Text>>)>>(prism_rtl::rc([=, cols_ptx = std::move(cols_ptx), span_p2xx = std::move(span_p2xx)](std::tuple<crate::check::types::St, std::tuple<Text, Text>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cols_ptxy = cols_ptx;
                auto span_p2xxy = span_p2xx;
                (crate::prelude::entered(crate::prelude::once_job([=, cols_ptxy = std::move(cols_ptxy), span_p2xxy = std::move(span_p2xxy)]() {
                return ({
                    auto s_pv = p0;
                    auto [lo_p10, hi_p11] = p1;
                    (prism_rtl::more(prism_rtl::rc(crate::check::types::colors::AddLeq(s_pv, crate::prelude::or_(crate::prelude::get(cols_ptxy, lo_p10), crate::check::types::Col(crate::check::types::Col::CBound{})), crate::prelude::or_(crate::prelude::get(cols_ptxy, hi_p11), crate::check::types::Col(crate::check::types::Col::CBound{})), span_p2xxy, Text::lit("arg"), Text::lit(""), Text::lit("")))));
                });
            })));
            });
        })));
        })), [=, inst_p5 = std::move(inst_p5)](crate::check::types::St fold_3252) {
            return ({
                auto st2c_p6 = fold_3252;
                auto st3_p7 = crate::prelude::fold(prism_rtl::deref(sc_p1x).bounds_p, st2c_p6, [&](const crate::check::types::St& s_p12, const std::tuple<Text, Text>& _p1) {
                    auto&& v_p13 = std::get<0>(_p1);
                    auto&& tr_p14 = std::get<1>(_p1);
                    return ({
                        crate::check::types::St this_ = s_p12;
                        this_.wants_p = crate::prelude::push(this_.wants_p, crate::check::types::Want{.cls_p = tr_p14, .ty_p = crate::prelude::or_(crate::prelude::get(tys_pf, v_p13), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), .file_p = prism_rtl::deref(s_p12).file_p, .span_p = span_p2x, .level_p = prism_rtl::deref(s_p12).level_p});
                        (std::move(this_));
                    });
                });
                (crate::prelude::call_then(start_subst_q_f(inst_p5, prism_rtl::deref(sc_p1x).ty_p), [=, st3_p7 = std::move(st3_p7)](crate::check::types::Ty subst_q_f_3546) { return prism_rtl::finished(std::tuple{subst_q_f_3546, st3_p7, inst_p5}); }));
            });
        }));
        });
    });
}


/// `Start InstantiateWith, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St, Inst>> start_instantiate_with_f(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1, crate::syntax::Range span_p2, Array<crate::check::types::Ty> explicit_p3) {
    return prism_rtl::make_rc<InstantiateWith>(st_p0, sc_p1, span_p2, explicit_p3);
}


/// LacksIn: unbounded fn Ty, Text -> [Text]
Array<Text> lacks_in_f(const crate::check::types::Ty& t_p0, const Text& q_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0)) {
        auto&& args_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(args_p2, Array<Text>{}, ({
            auto q_p1x = q_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, q_p1x = std::move(q_p1x)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto q_p1xy = q_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, q_p1xy = std::move(q_p1xy)]() {
                return ({
                    auto acc_p3 = p0;
                    auto a_p4 = p1;
                    (crate::prelude::call_then(start_lacks_in_f(a_p4, q_p1xy), [=, acc_p3 = std::move(acc_p3)](Array<Text> lacks_in_f_3833) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p3, lacks_in_f_3833)); }));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0)) {
        auto&& ps_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& r_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ps_p5, lacks_in_f(prism_rtl::deref(prism_rtl::deref(r_p6)), q_p1), ({
            auto q_p1x = q_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, q_p1x = std::move(q_p1x)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto q_p1xy = q_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, q_p1xy = std::move(q_p1xy)]() {
                return ({
                    auto acc_p7 = p0;
                    auto a_p8 = p1;
                    (crate::prelude::call_then(start_lacks_in_f(a_p8, q_p1xy), [=, acc_p7 = std::move(acc_p7)](Array<Text> lacks_in_f_3923) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p7, lacks_in_f_3923)); }));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_p9 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_p9, Array<Text>{}, ({
            auto q_p1x = q_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, q_p1x = std::move(q_p1x)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto q_p1xy = q_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, q_p1xy = std::move(q_p1xy)]() {
                return ({
                    auto acc_pa = p0;
                    auto a_pb = p1;
                    (crate::prelude::call_then(start_lacks_in_f(a_pb, q_p1xy), [=, acc_pa = std::move(acc_pa)](Array<Text> lacks_in_f_3995) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_pa, lacks_in_f_3995)); }));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0)) {
        auto&& e_pc = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        return lacks_in_f(prism_rtl::deref(prism_rtl::deref(e_pc)), q_p1);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0)) {
        auto&& k_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        return crate::check::types::union_texts_f(lacks_in_f(prism_rtl::deref(prism_rtl::deref(k_pd)), q_p1), lacks_in_f(prism_rtl::deref(prism_rtl::deref(v_pe)), q_p1));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& i_pf = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return lacks_in_f(prism_rtl::deref(prism_rtl::deref(i_pf)), q_p1);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0)) {
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        auto&& rw_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a1;
        return crate::check::types::union_texts_f(lacks_in_f(prism_rtl::deref(prism_rtl::deref(i_pg)), q_p1), row_lacks_f(rw_ph, q_p1));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p0)) {
        auto&& rw_pi = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a0;
        auto&& o_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a1;
        return crate::check::types::union_texts_f(lacks_in_f(prism_rtl::deref(prism_rtl::deref(o_pj)), q_p1), row_lacks_f(rw_pi, q_p1));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p0)) {
        auto&& rw_pk = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t_p0).a0;
        return row_lacks_f(rw_pk, q_p1);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> LacksIn::cycle() const {
    const auto& t_p0 = this->t_p0;
    const auto& q_p1 = this->q_p1;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0) ? ({
        auto&& args_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        crate::prelude::fold_job(args_p2, Array<Text>{}, ({
        auto q_p1x = q_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, q_p1x = std::move(q_p1x)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto q_p1xy = q_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, q_p1xy = std::move(q_p1xy)]() {
            return ({
                auto acc_p3 = p0;
                auto a_p4 = p1;
                (crate::prelude::call_then(start_lacks_in_f(a_p4, q_p1xy), [=, acc_p3 = std::move(acc_p3)](Array<Text> lacks_in_f_3833) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p3, lacks_in_f_3833)); }));
            });
        })));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0) ? ({
        auto&& ps_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& r_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        ({
        auto ps_p5x = ps_p5;
        auto q_p1x = q_p1;
        auto r_p6x = prism_rtl::deref(prism_rtl::deref(r_p6));
        (crate::prelude::call_then(start_lacks_in_f(r_p6x, q_p1x), [=, ps_p5x = std::move(ps_p5x)](Array<Text> lacks_in_f_3881) {
        return crate::prelude::fold_job(ps_p5x, lacks_in_f_3881, ({
            auto q_p1xx = q_p1x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, q_p1xx = std::move(q_p1xx)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto q_p1xxy = q_p1xx;
                (crate::prelude::entered(crate::prelude::once_job([=, q_p1xxy = std::move(q_p1xxy)]() {
                return ({
                    auto acc_p7 = p0;
                    auto a_p8 = p1;
                    (crate::prelude::call_then(start_lacks_in_f(a_p8, q_p1xxy), [=, acc_p7 = std::move(acc_p7)](Array<Text> lacks_in_f_3923) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p7, lacks_in_f_3923)); }));
                });
            })));
            });
        })));
        }))->cycle();
    }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0) ? ({
        auto&& ts_p9 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        crate::prelude::fold_job(ts_p9, Array<Text>{}, ({
        auto q_p1x = q_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, q_p1x = std::move(q_p1x)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto q_p1xy = q_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, q_p1xy = std::move(q_p1xy)]() {
            return ({
                auto acc_pa = p0;
                auto a_pb = p1;
                (crate::prelude::call_then(start_lacks_in_f(a_pb, q_p1xy), [=, acc_pa = std::move(acc_pa)](Array<Text> lacks_in_f_3995) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_pa, lacks_in_f_3995)); }));
            });
        })));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0) ? ({
        auto&& e_pc = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(LacksIn(prism_rtl::deref(prism_rtl::deref(e_pc)), q_p1)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0) ? ({
        auto&& k_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        ({
        auto k_pdx = prism_rtl::deref(prism_rtl::deref(k_pd));
        auto q_p1x = q_p1;
        auto v_pex = prism_rtl::deref(prism_rtl::deref(v_pe));
        (crate::prelude::call_then(start_lacks_in_f(k_pdx, q_p1x), [=, v_pex = std::move(v_pex)](Array<Text> lacks_in_f_4065) { return crate::prelude::call_then(start_lacks_in_f(v_pex, q_p1x), [=](Array<Text> lacks_in_f_4081) { return prism_rtl::finished(crate::check::types::union_texts_f(lacks_in_f_4065, lacks_in_f_4081)); }); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p0) ? ({
        auto&& i_pf = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        prism_rtl::more(prism_rtl::rc(LacksIn(prism_rtl::deref(prism_rtl::deref(i_pf)), q_p1)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0) ? ({
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        auto&& rw_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a1;
        ({
        auto i_pgx = prism_rtl::deref(prism_rtl::deref(i_pg));
        auto q_p1x = q_p1;
        auto rw_phx = rw_ph;
        (crate::prelude::call_then(start_lacks_in_f(i_pgx, q_p1x), [=, rw_phx = std::move(rw_phx)](Array<Text> lacks_in_f_4157) { return prism_rtl::finished(crate::check::types::union_texts_f(lacks_in_f_4157, row_lacks_f(rw_phx, q_p1x))); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p0) ? ({
        auto&& rw_pi = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a0;
        auto&& o_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a1;
        ({
        auto o_pjx = prism_rtl::deref(prism_rtl::deref(o_pj));
        auto q_p1x = q_p1;
        auto rw_pix = rw_pi;
        (crate::prelude::call_then(start_lacks_in_f(o_pjx, q_p1x), [=, rw_pix = std::move(rw_pix)](Array<Text> lacks_in_f_4219) { return prism_rtl::finished(crate::check::types::union_texts_f(lacks_in_f_4219, row_lacks_f(rw_pix, q_p1x))); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p0) ? ({
        auto&& rw_pk = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t_p0).a0;
        prism_rtl::finished(row_lacks_f(rw_pk, q_p1));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start LacksIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_lacks_in_f(crate::check::types::Ty t_p0, Text q_p1) {
    return prism_rtl::make_rc<LacksIn>(t_p0, q_p1);
}


/// RowLacks: fn Rw, Text -> [Text]
Array<Text> row_lacks_f(const crate::check::types::Rw& rw_p0, const Text& q_p1) {
    return rw_p0.tail_p == crate::check::types::Tail(crate::check::types::Tail::TlQ{q_p1})
        ? rw_p0.fams_p
        : Array<Text>{};
}


/// Skolemize: unbounded fn Scheme -> Ty
crate::check::types::Ty skolemize_f(const crate::check::types::Scheme& sc_p0) {
    auto tys_p1 = crate::prelude::fold(sc_p0.qs_p, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m_p4, const Text& q_p5) { return crate::prelude::insert(m_p4, q_p5, crate::check::types::Ty(crate::check::types::Ty::TyRigid{q_p5})); });
    auto rows_p2 = crate::prelude::fold(sc_p0.rqs_p, Map<Text, crate::check::types::Tail>{}, [&](const Map<Text, crate::check::types::Tail>& m_p6, const Text& q_p7) { return crate::prelude::insert(m_p6, q_p7, crate::check::types::Tail(crate::check::types::Tail::TlRigid{q_p7})); });
    auto cols_p3 = crate::prelude::fold(sc_p0.cqs_p, Map<Text, crate::check::types::Col>{}, [&](const Map<Text, crate::check::types::Col>& m_p8, const Text& q_p9) { return crate::prelude::insert(m_p8, q_p9, crate::check::types::Col(crate::check::types::Col::CRigid{q_p9})); });
    return subst_q_f(Inst{.tys_p = tys_p1, .rows_p = rows_p2, .cols_p = cols_p3}, sc_p0.ty_p);
}


prism_rtl::Turn<crate::check::types::Ty> Skolemize::cycle() const {
    const auto& sc_p0 = this->sc_p0;
    auto tys_p1 = crate::prelude::fold(prism_rtl::deref(sc_p0).qs_p, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m_p4, const Text& q_p5) { return crate::prelude::insert(m_p4, q_p5, crate::check::types::Ty(crate::check::types::Ty::TyRigid{q_p5})); });
    auto rows_p2 = crate::prelude::fold(prism_rtl::deref(sc_p0).rqs_p, Map<Text, crate::check::types::Tail>{}, [&](const Map<Text, crate::check::types::Tail>& m_p6, const Text& q_p7) { return crate::prelude::insert(m_p6, q_p7, crate::check::types::Tail(crate::check::types::Tail::TlRigid{q_p7})); });
    auto cols_p3 = crate::prelude::fold(prism_rtl::deref(sc_p0).cqs_p, Map<Text, crate::check::types::Col>{}, [&](const Map<Text, crate::check::types::Col>& m_p8, const Text& q_p9) { return crate::prelude::insert(m_p8, q_p9, crate::check::types::Col(crate::check::types::Col::CRigid{q_p9})); });
    return prism_rtl::more(prism_rtl::rc(SubstQ(Inst{.tys_p = tys_p1, .rows_p = rows_p2, .cols_p = cols_p3}, prism_rtl::deref(sc_p0).ty_p)));
}


/// `Start Skolemize, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_skolemize_f(crate::check::types::Scheme sc_p0) {
    return prism_rtl::make_rc<Skolemize>(sc_p0);
}


/// Generalize: unbounded fn St, Ty, [Nat], [((Nat, Text))] -> ((Scheme, St))
std::tuple<crate::check::types::Scheme, crate::check::types::St> generalize_f(const crate::check::types::St& st0_p0, const crate::check::types::Ty& t_p1, const Array<Nat>& keep_p2, const Array<std::tuple<Nat, Text>>& bounds_p3) {
    auto waiting_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(st0_p0.field_qs_p, Array<Nat>{}, ({
        auto st0_p0x = st0_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::unify::FieldQ>)>>(prism_rtl::rc([=, st0_p0x = std::move(st0_p0x)](std::tuple<Array<Nat>, crate::check::types::unify::FieldQ> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st0_p0xy = st0_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, st0_p0xy = std::move(st0_p0xy)]() {
            return ({
                auto acc_pf = p0;
                auto q_pg = p1;
                (crate::prelude::call_then(crate::check::types::recording::start_free_vars_into_f(st0_p0xy, acc_pf, prism_rtl::deref(q_pg).recv_p), [=](Array<Nat> free_vars_into_f_5383) { return prism_rtl::more(prism_rtl::rc(crate::check::types::recording::FreeVarsInto(st0_p0xy, free_vars_into_f_5383, prism_rtl::deref(q_pg).result_p))); }));
            });
        })));
        });
    })));
    })));
    auto st_p5 = crate::check::types::colors::generalize_cols_f(crate::check::types::unify::lower_levels_f(st0_p0, waiting_p4, st0_p0.level_p));
    auto z_p6 = crate::check::types::recording::zonk_f(st_p5, t_p1);
    auto vs_p7 = crate::prelude::filter(crate::check::types::recording::free_vars_f(st_p5, z_p6), [&](const Nat& v_ph) { return (prism_rtl::deref(crate::check::types::recording::info_of_f(st_p5, v_ph)).level_p > prism_rtl::deref(st_p5).level_p) && (!crate::check::types::has_nat_f(keep_p2, v_ph)); });
    auto cvs_p8 = crate::prelude::filter(crate::check::types::colors::free_col_vars_f(st_p5, z_p6), [&](const Nat& v_pi) { return prism_rtl::deref(crate::check::types::recording::info_of_f(st_p5, v_pi)).level_p > prism_rtl::deref(st_p5).level_p; });
    auto tys_p9 = crate::prelude::fold(vs_p7, Map<Nat, crate::check::types::Ty>{}, [&](const Map<Nat, crate::check::types::Ty>& m_pj, const Nat& v_pk) { return crate::prelude::insert(m_pj, v_pk, crate::check::types::Ty(crate::check::types::Ty::TyQ{prism_rtl::cat("\'", v_pk)})); });
    auto cols_pa = crate::prelude::fold(cvs_p8, Map<Nat, crate::check::types::Col>{}, [&](const Map<Nat, crate::check::types::Col>& m_pl, const Nat& v_pm) { return crate::prelude::insert(m_pl, v_pm, crate::check::types::Col(crate::check::types::Col::CQ{prism_rtl::cat("\'c", v_pm)})); });
    auto named_pb = subst_flex_f(tys_p9, cols_pa, z_p6);
    auto plains_pc = crate::prelude::each(crate::prelude::filter(vs_p7, [&](const Nat& v_pn) { return prism_rtl::deref(crate::check::types::recording::info_of_f(st_p5, v_pn)).plain_p; }), [&](const Nat& v_po) { return prism_rtl::cat("\'", v_po); });
    auto bs_pd = crate::prelude::each(crate::prelude::filter(bounds_p3, [&](const std::tuple<Nat, Text>& _p0) {
        auto&& v_pp = std::get<0>(_p0);
        return crate::check::types::has_nat_f(vs_p7, v_pp);
    }), [&](const std::tuple<Nat, Text>& _p0) {
        auto&& v_pq = std::get<0>(_p0);
        auto&& tr_pr = std::get<1>(_p0);
        return std::tuple{prism_rtl::cat("\'", v_pq), tr_pr};
    });
    auto st2_pe = ({
        crate::check::types::St this_ = st_p5;
        this_.col_q_p = crate::prelude::fold(cvs_p8, this_.col_q_p, [&](const Map<Nat, Text>& m_ps, const Nat& v_pt) { return crate::prelude::insert(m_ps, v_pt, prism_rtl::cat("\'c", v_pt)); });
        (std::move(this_));
    });
    return std::tuple{crate::check::types::Scheme{.qs_p = crate::prelude::each(vs_p7, [&](const Nat& v_pu) { return prism_rtl::cat("\'", v_pu); }), .plain_qs_p = plains_pc, .rqs_p = Array<Text>{}, .cqs_p = crate::prelude::each(cvs_p8, [&](const Nat& v_pv) { return prism_rtl::cat("\'c", v_pv); }), .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = bs_pd, .ty_p = named_pb}, st2_pe};
}


prism_rtl::Turn<std::tuple<crate::check::types::Scheme, crate::check::types::St>> Generalize::cycle() const {
    const auto& st0_p0 = this->st0_p0;
    const auto& t_p1 = this->t_p1;
    const auto& keep_p2 = this->keep_p2;
    const auto& bounds_p3 = this->bounds_p3;
    auto bounds_p3x = bounds_p3;
    auto keep_p2x = keep_p2;
    auto st0_p0x = st0_p0;
    auto t_p1x = t_p1;
    return crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(st0_p0x).field_qs_p, Array<Nat>{}, ({
        auto st0_p0xx = st0_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::unify::FieldQ>)>>(prism_rtl::rc([=, st0_p0xx = std::move(st0_p0xx)](std::tuple<Array<Nat>, crate::check::types::unify::FieldQ> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st0_p0xxy = st0_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, st0_p0xxy = std::move(st0_p0xxy)]() {
            return ({
                auto acc_pf = p0;
                auto q_pg = p1;
                (crate::prelude::call_then(crate::check::types::recording::start_free_vars_into_f(st0_p0xxy, acc_pf, prism_rtl::deref(q_pg).recv_p), [=](Array<Nat> free_vars_into_f_5383) { return prism_rtl::more(prism_rtl::rc(crate::check::types::recording::FreeVarsInto(st0_p0xxy, free_vars_into_f_5383, prism_rtl::deref(q_pg).result_p))); }));
            });
        })));
        });
    })));
    })), [=](Array<Nat> fold_5330) {
        return ({
            auto waiting_p4 = fold_5330;
            (crate::prelude::call_then(crate::check::types::colors::start_generalize_cols_f(crate::check::types::unify::lower_levels_f(st0_p0x, waiting_p4, prism_rtl::deref(st0_p0x).level_p)), [=](crate::check::types::St generalize_cols_f_5437) {
            return ({
                auto st_p5 = generalize_cols_f_5437;
                (crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p5, t_p1x), [=](crate::check::types::Ty zonk_f_5502) {
                return ({
                    auto z_p6 = zonk_f_5502;
                    (crate::prelude::call_then(crate::check::types::recording::start_free_vars_f(st_p5, z_p6), [=](Array<Nat> free_vars_f_5534) {
                    return ({
                        auto vs_p7 = crate::prelude::filter(free_vars_f_5534, [&](const Nat& v_ph) { return (prism_rtl::deref(crate::check::types::recording::info_of_f(st_p5, v_ph)).level_p > prism_rtl::deref(st_p5).level_p) && (!crate::check::types::has_nat_f(keep_p2x, v_ph)); });
                        (crate::prelude::call_then(crate::check::types::colors::start_free_col_vars_f(st_p5, z_p6), [=, vs_p7 = std::move(vs_p7)](Array<Nat> free_col_vars_f_5635) {
                        return ({
                            auto cvs_p8 = crate::prelude::filter(free_col_vars_f_5635, [&](const Nat& v_pi) { return prism_rtl::deref(crate::check::types::recording::info_of_f(st_p5, v_pi)).level_p > prism_rtl::deref(st_p5).level_p; });
                            auto tys_p9 = crate::prelude::fold(vs_p7, Map<Nat, crate::check::types::Ty>{}, [&](const Map<Nat, crate::check::types::Ty>& m_pj, const Nat& v_pk) { return crate::prelude::insert(m_pj, v_pk, crate::check::types::Ty(crate::check::types::Ty::TyQ{prism_rtl::cat("\'", v_pk)})); });
                            auto cols_pa = crate::prelude::fold(cvs_p8, Map<Nat, crate::check::types::Col>{}, [&](const Map<Nat, crate::check::types::Col>& m_pl, const Nat& v_pm) { return crate::prelude::insert(m_pl, v_pm, crate::check::types::Col(crate::check::types::Col::CQ{prism_rtl::cat("\'c", v_pm)})); });
                            (crate::prelude::call_then(start_subst_flex_f(tys_p9, cols_pa, z_p6), [=, cvs_p8 = std::move(cvs_p8)](crate::check::types::Ty subst_flex_f_5832) {
                            return ({
                                auto named_pb = subst_flex_f_5832;
                                auto plains_pc = crate::prelude::each(crate::prelude::filter(vs_p7, [&](const Nat& v_pn) { return prism_rtl::deref(crate::check::types::recording::info_of_f(st_p5, v_pn)).plain_p; }), [&](const Nat& v_po) { return prism_rtl::cat("\'", v_po); });
                                auto bs_pd = crate::prelude::each(crate::prelude::filter(bounds_p3x, [&](const std::tuple<Nat, Text>& _p0) {
                                    auto&& v_pp = std::get<0>(_p0);
                                    return crate::check::types::has_nat_f(vs_p7, v_pp);
                                }), [&](const std::tuple<Nat, Text>& _p0) {
                                    auto&& v_pq = std::get<0>(_p0);
                                    auto&& tr_pr = std::get<1>(_p0);
                                    return std::tuple{prism_rtl::cat("\'", v_pq), tr_pr};
                                });
                                auto st2_pe = ({
                                    crate::check::types::St this_ = st_p5;
                                    this_.col_q_p = crate::prelude::fold(cvs_p8, this_.col_q_p, [&](const Map<Nat, Text>& m_ps, const Nat& v_pt) { return crate::prelude::insert(m_ps, v_pt, prism_rtl::cat("\'c", v_pt)); });
                                    (std::move(this_));
                                });
                                (prism_rtl::finished(std::tuple{crate::check::types::Scheme{.qs_p = crate::prelude::each(vs_p7, [&](const Nat& v_pu) { return prism_rtl::cat("\'", v_pu); }), .plain_qs_p = plains_pc, .rqs_p = Array<Text>{}, .cqs_p = crate::prelude::each(cvs_p8, [&](const Nat& v_pv) { return prism_rtl::cat("\'c", v_pv); }), .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = bs_pd, .ty_p = named_pb}, st2_pe}));
                            });
                        }));
                        });
                    }));
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start Generalize, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Scheme, crate::check::types::St>> start_generalize_f(crate::check::types::St st0_p0, crate::check::types::Ty t_p1, Array<Nat> keep_p2, Array<std::tuple<Nat, Text>> bounds_p3) {
    return prism_rtl::make_rc<Generalize>(st0_p0, t_p1, keep_p2, bounds_p3);
}


/// SubstFlex: unbounded fn (Nat ==> Ty), (Nat ==> Col), Ty -> Ty
crate::check::types::Ty subst_flex_f(const Map<Nat, crate::check::types::Ty>& m_p0, const Map<Nat, crate::check::types::Col>& cm_p1, const crate::check::types::Ty& t_p2) {
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(t_p2)) {
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyFlex>(t_p2).a0;
        return crate::prelude::or_(crate::prelude::get(m_p0, n_p3), crate::check::types::Ty(crate::check::types::Ty::TyFlex{n_p3}));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2)) {
        auto&& n_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& args_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p4, crate::prelude::run_to_end(crate::prelude::each_job(args_p5, ({
            auto m_p0x = m_p0;
            auto cm_p1x = cm_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0x = std::move(m_p0x), cm_p1x = std::move(cm_p1x)](crate::check::types::Ty p0) {
            return ({
                auto m_p0xy = m_p0x;
                auto cm_p1xy = cm_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, m_p0xy = std::move(m_p0xy), cm_p1xy = std::move(cm_p1xy)]() {
                return ({
                    auto a_p6 = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstFlex(m_p0xy, cm_p1xy, a_p6))));
                });
            })));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p2)) {
        auto&& c_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a0;
        auto&& ps_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a1;
        auto&& res_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a2;
        auto c2_pa = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Col> _v;
            if (prism_rtl::is<crate::check::types::Col::CFlex>(c_p7)) {
                auto&& n_pb = prism_rtl::as<crate::check::types::Col::CFlex>(c_p7).a0;
                _v.set(crate::prelude::or_(crate::prelude::get(cm_p1, n_pb), c_p7));
                goto _done;
            }
            {
                auto&& other_pc = c_p7;
                _v.set(other_pc);
                goto _done;
            }
        _done:
            _v.take();
        });
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{c2_pa, crate::prelude::run_to_end(crate::prelude::each_job(ps_p8, ({
            auto m_p0x = m_p0;
            auto cm_p1x = cm_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0x = std::move(m_p0x), cm_p1x = std::move(cm_p1x)](crate::check::types::Ty p0) {
            return ({
                auto m_p0xy = m_p0x;
                auto cm_p1xy = cm_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, m_p0xy = std::move(m_p0xy), cm_p1xy = std::move(cm_p1xy)]() {
                return ({
                    auto p_pd = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstFlex(m_p0xy, cm_p1xy, p_pd))));
                });
            })));
            });
        })));
        }))), prism_rtl::rc(subst_flex_f(m_p0, cm_p1, prism_rtl::deref(prism_rtl::deref(res_p9))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p2)) {
        auto&& ts_pe = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p2).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{crate::prelude::run_to_end(crate::prelude::each_job(ts_pe, ({
            auto m_p0x = m_p0;
            auto cm_p1x = cm_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0x = std::move(m_p0x), cm_p1x = std::move(cm_p1x)](crate::check::types::Ty p0) {
            return ({
                auto m_p0xy = m_p0x;
                auto cm_p1xy = cm_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, m_p0xy = std::move(m_p0xy), cm_p1xy = std::move(cm_p1xy)]() {
                return ({
                    auto a_pf = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstFlex(m_p0xy, cm_p1xy, a_pf))));
                });
            })));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p2)) {
        auto&& e_pg = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p2).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(subst_flex_f(m_p0, cm_p1, prism_rtl::deref(prism_rtl::deref(e_pg))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p2)) {
        auto&& k_ph = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a0;
        auto&& v_pi = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(subst_flex_f(m_p0, cm_p1, prism_rtl::deref(prism_rtl::deref(k_ph)))), prism_rtl::rc(subst_flex_f(m_p0, cm_p1, prism_rtl::deref(prism_rtl::deref(v_pi))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p2)) {
        auto&& s_pj = prism_rtl::as<crate::check::types::Ty::TySig>(t_p2).a0;
        auto&& i_pk = prism_rtl::as<crate::check::types::Ty::TySig>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s_pj, prism_rtl::rc(subst_flex_f(m_p0, cm_p1, prism_rtl::deref(prism_rtl::deref(i_pk))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p2)) {
        auto&& i_pl = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p2).a0;
        auto&& rw_pm = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(subst_flex_f(m_p0, cm_p1, prism_rtl::deref(prism_rtl::deref(i_pl)))), rw_pm});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p2)) {
        auto&& rw_pn = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p2).a0;
        auto&& o_po = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyElem{rw_pn, prism_rtl::rc(subst_flex_f(m_p0, cm_p1, prism_rtl::deref(prism_rtl::deref(o_po))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p2)) {
        auto&& n_pp = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p2).a0;
        auto&& a_pq = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n_pp, prism_rtl::rc(subst_flex_f(m_p0, cm_p1, prism_rtl::deref(prism_rtl::deref(a_pq))))});
    }
    {
        auto&& other_pr = t_p2;
        return other_pr;
    }
}


prism_rtl::Turn<crate::check::types::Ty> SubstFlex::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& cm_p1 = this->cm_p1;
    const auto& t_p2 = this->t_p2;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFlex>(t_p2) ? ({
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyFlex>(t_p2).a0;
        prism_rtl::finished(crate::prelude::or_(crate::prelude::get(m_p0, n_p3), crate::check::types::Ty(crate::check::types::Ty::TyFlex{n_p3})));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2) ? ({
        auto&& n_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& args_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        ({
        auto args_p5x = args_p5;
        auto cm_p1x = cm_p1;
        auto m_p0x = m_p0;
        auto n_p4x = n_p4;
        (crate::prelude::call_value(crate::prelude::each_job(args_p5x, ({
        auto m_p0xx = m_p0x;
        auto cm_p1xx = cm_p1x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0xx = std::move(m_p0xx), cm_p1xx = std::move(cm_p1xx)](crate::check::types::Ty p0) {
        return ({
            auto m_p0xxy = m_p0xx;
            auto cm_p1xxy = cm_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, m_p0xxy = std::move(m_p0xxy), cm_p1xxy = std::move(cm_p1xxy)]() {
            return ({
                auto a_p6 = p0;
                (prism_rtl::more(prism_rtl::rc(SubstFlex(m_p0xxy, cm_p1xxy, a_p6))));
            });
        })));
        });
    })));
    })), [=, n_p4x = std::move(n_p4x)](Array<crate::check::types::Ty> each_6411) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p4x, each_6411})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p2) ? ({
        auto&& c_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a0;
        auto&& ps_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a1;
        auto&& res_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a2;
        ({
        auto c2_pa = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Col> _v;
            if (prism_rtl::is<crate::check::types::Col::CFlex>(c_p7)) {
                auto&& n_pb = prism_rtl::as<crate::check::types::Col::CFlex>(c_p7).a0;
                _v.set(crate::prelude::or_(crate::prelude::get(cm_p1, n_pb), c_p7));
                goto _done;
            }
            {
                auto&& other_pc = c_p7;
                _v.set(other_pc);
                goto _done;
            }
        _done:
            _v.take();
        });
        auto cm_p1x = cm_p1;
        auto m_p0x = m_p0;
        auto ps_p8x = ps_p8;
        auto res_p9x = prism_rtl::deref(prism_rtl::deref(res_p9));
        (crate::prelude::call_value(crate::prelude::each_job(ps_p8x, ({
        auto m_p0xx = m_p0x;
        auto cm_p1xx = cm_p1x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0xx = std::move(m_p0xx), cm_p1xx = std::move(cm_p1xx)](crate::check::types::Ty p0) {
        return ({
            auto m_p0xxy = m_p0xx;
            auto cm_p1xxy = cm_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, m_p0xxy = std::move(m_p0xxy), cm_p1xxy = std::move(cm_p1xxy)]() {
            return ({
                auto p_pd = p0;
                (prism_rtl::more(prism_rtl::rc(SubstFlex(m_p0xxy, cm_p1xxy, p_pd))));
            });
        })));
        });
    })));
    })), [=, c2_pa = std::move(c2_pa), res_p9x = std::move(res_p9x)](Array<crate::check::types::Ty> each_6570) { return crate::prelude::call_then(start_subst_flex_f(m_p0x, cm_p1x, res_p9x), [=](crate::check::types::Ty subst_flex_f_6606) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{c2_pa, each_6570, prism_rtl::rc(subst_flex_f_6606)})); }); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p2) ? ({
        auto&& ts_pe = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p2).a0;
        ({
        auto cm_p1x = cm_p1;
        auto m_p0x = m_p0;
        auto ts_pex = ts_pe;
        (crate::prelude::call_value(crate::prelude::each_job(ts_pex, ({
        auto m_p0xx = m_p0x;
        auto cm_p1xx = cm_p1x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, m_p0xx = std::move(m_p0xx), cm_p1xx = std::move(cm_p1xx)](crate::check::types::Ty p0) {
        return ({
            auto m_p0xxy = m_p0xx;
            auto cm_p1xxy = cm_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, m_p0xxy = std::move(m_p0xxy), cm_p1xxy = std::move(cm_p1xxy)]() {
            return ({
                auto a_pf = p0;
                (prism_rtl::more(prism_rtl::rc(SubstFlex(m_p0xxy, cm_p1xxy, a_pf))));
            });
        })));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_6653) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyTuple{each_6653})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p2) ? ({
        auto&& e_pg = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p2).a0;
        ({
        auto cm_p1x = cm_p1;
        auto e_pgx = prism_rtl::deref(prism_rtl::deref(e_pg));
        auto m_p0x = m_p0;
        (crate::prelude::call_then(start_subst_flex_f(m_p0x, cm_p1x, e_pgx), [=](crate::check::types::Ty subst_flex_f_6711) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(subst_flex_f_6711)})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p2) ? ({
        auto&& k_ph = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a0;
        auto&& v_pi = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a1;
        ({
        auto cm_p1x = cm_p1;
        auto k_phx = prism_rtl::deref(prism_rtl::deref(k_ph));
        auto m_p0x = m_p0;
        auto v_pix = prism_rtl::deref(prism_rtl::deref(v_pi));
        (crate::prelude::call_then(start_subst_flex_f(m_p0x, cm_p1x, k_phx), [=, v_pix = std::move(v_pix)](crate::check::types::Ty subst_flex_f_6754) { return crate::prelude::call_then(start_subst_flex_f(m_p0x, cm_p1x, v_pix), [=](crate::check::types::Ty subst_flex_f_6776) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(subst_flex_f_6754), prism_rtl::rc(subst_flex_f_6776)})); }); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p2) ? ({
        auto&& s_pj = prism_rtl::as<crate::check::types::Ty::TySig>(t_p2).a0;
        auto&& i_pk = prism_rtl::as<crate::check::types::Ty::TySig>(t_p2).a1;
        ({
        auto cm_p1x = cm_p1;
        auto i_pkx = prism_rtl::deref(prism_rtl::deref(i_pk));
        auto m_p0x = m_p0;
        auto s_pjx = s_pj;
        (crate::prelude::call_then(start_subst_flex_f(m_p0x, cm_p1x, i_pkx), [=, s_pjx = std::move(s_pjx)](crate::check::types::Ty subst_flex_f_6822) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{s_pjx, prism_rtl::rc(subst_flex_f_6822)})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p2) ? ({
        auto&& i_pl = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p2).a0;
        auto&& rw_pm = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p2).a1;
        ({
        auto cm_p1x = cm_p1;
        auto i_plx = prism_rtl::deref(prism_rtl::deref(i_pl));
        auto m_p0x = m_p0;
        auto rw_pmx = rw_pm;
        (crate::prelude::call_then(start_subst_flex_f(m_p0x, cm_p1x, i_plx), [=, rw_pmx = std::move(rw_pmx)](crate::check::types::Ty subst_flex_f_6864) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(subst_flex_f_6864), rw_pmx})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p2) ? ({
        auto&& rw_pn = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p2).a0;
        auto&& o_po = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p2).a1;
        ({
        auto cm_p1x = cm_p1;
        auto m_p0x = m_p0;
        auto o_pox = prism_rtl::deref(prism_rtl::deref(o_po));
        auto rw_pnx = rw_pn;
        (crate::prelude::call_then(start_subst_flex_f(m_p0x, cm_p1x, o_pox), [=, rw_pnx = std::move(rw_pnx)](crate::check::types::Ty subst_flex_f_6918) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyElem{rw_pnx, prism_rtl::rc(subst_flex_f_6918)})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p2) ? ({
        auto&& n_pp = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p2).a0;
        auto&& a_pq = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p2).a1;
        ({
        auto a_pqx = prism_rtl::deref(prism_rtl::deref(a_pq));
        auto cm_p1x = cm_p1;
        auto m_p0x = m_p0;
        auto n_ppx = n_pp;
        (crate::prelude::call_then(start_subst_flex_f(m_p0x, cm_p1x, a_pqx), [=, n_ppx = std::move(n_ppx)](crate::check::types::Ty subst_flex_f_6968) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n_ppx, prism_rtl::rc(subst_flex_f_6968)})); }));
    });
    })
        : ({
        auto&& other_pr = t_p2;
        prism_rtl::finished(other_pr);
    });
    });
}


/// `Start SubstFlex, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_subst_flex_f(Map<Nat, crate::check::types::Ty> m_p0, Map<Nat, crate::check::types::Col> cm_p1, crate::check::types::Ty t_p2) {
    return prism_rtl::make_rc<SubstFlex>(m_p0, cm_p1, t_p2);
}


/// HoldsNode: unbounded fn St, Ty -> Bool
bool holds_node_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    auto&& _m = crate::check::types::recording::walk_f(st_p0, t_p1);
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& s_p2 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i_p3 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return ((s_p2 == Text::lit("$")) || (s_p2 == Text::lit("!"))) || holds_node_f(st_p0, prism_rtl::deref(i_p3));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts_p4 = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_p4, false, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto seen_p5 = p0;
                    auto x_p6 = p1;
                    (prism_rtl::finished(std::move(seen_p5) || holds_node_f(st_p0xy, x_p6)));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& e_p7 = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        return holds_node_f(st_p0, prism_rtl::deref(e_p7));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k_p8 = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_p9 = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return holds_node_f(st_p0, prism_rtl::deref(k_p8)) || holds_node_f(st_p0, prism_rtl::deref(v_p9));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& args_pa = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(args_pa, false, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto seen_pb = p0;
                    auto x_pc = p1;
                    (prism_rtl::finished(std::move(seen_pb) || holds_node_f(st_p0xy, x_pc)));
                });
            })));
            });
        })));
        })));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> HoldsNode::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0x = st_p0;
    auto t_p1x = t_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x, t_p1x), [=](crate::check::types::Ty walk_f_7202) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TySig>(walk_f_7202) ? ({
            auto&& s_p2 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_7202).a0;
            auto&& i_p3 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_7202).a1;
            prism_rtl::finished(((s_p2 == Text::lit("$")) || (s_p2 == Text::lit("!"))) || holds_node_f(st_p0x, prism_rtl::deref(i_p3)));
        })
            : prism_rtl::is<crate::check::types::Ty::TyTuple>(walk_f_7202) ? ({
            auto&& ts_p4 = prism_rtl::as<crate::check::types::Ty::TyTuple>(walk_f_7202).a0;
            crate::prelude::fold_job(ts_p4, false, ({
            auto st_p0xx = st_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xxy = st_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
                return ({
                    auto seen_p5 = p0;
                    auto x_p6 = p1;
                    (prism_rtl::finished(std::move(seen_p5) || holds_node_f(st_p0xxy, x_p6)));
                });
            })));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::types::Ty::TyArray>(walk_f_7202) ? ({
            auto&& e_p7 = prism_rtl::as<crate::check::types::Ty::TyArray>(walk_f_7202).a0;
            prism_rtl::more(prism_rtl::rc(HoldsNode(st_p0x, prism_rtl::deref(e_p7))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyMap>(walk_f_7202) ? ({
            auto&& k_p8 = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_f_7202).a0;
            auto&& v_p9 = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_f_7202).a1;
            crate::prelude::call_then(start_holds_node_f(st_p0x, prism_rtl::deref(k_p8)), [=](bool holds_node_f_7385) { return prism_rtl::finished(holds_node_f_7385 || holds_node_f(st_p0x, prism_rtl::deref(v_p9))); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_f_7202) ? ({
            auto&& args_pa = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_7202).a1;
            crate::prelude::fold_job(args_pa, false, ({
            auto st_p0xx = st_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xxy = st_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
                return ({
                    auto seen_pb = p0;
                    auto x_pc = p1;
                    (prism_rtl::finished(std::move(seen_pb) || holds_node_f(st_p0xxy, x_pc)));
                });
            })));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::finished(false);
        });
    });
}


/// `Start HoldsNode, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_holds_node_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<HoldsNode>(st_p0, t_p1);
}


/// EnterLevel: fn St -> St
crate::check::types::St enter_level_f(const crate::check::types::St& st_p0) {
    crate::check::types::St this_ = st_p0;
    this_.level_p = this_.level_p + Nat(1u);
    return this_;
}


/// LeaveLevel: fn St -> St
crate::check::types::St leave_level_f(const crate::check::types::St& st_p0) {
    crate::check::types::St this_ = st_p0;
    this_.level_p = crate::prelude::or_(this_.level_p.checked_sub(Nat(1u)), Nat(0u));
    return this_;
}

}  // namespace crate::check::types::schemes
