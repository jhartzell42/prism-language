// The module `CheckPasses`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "check_passes.decl.hpp"
#include "elem.decl.hpp"
#include "check_blocks.decl.hpp"
#include "check_errors.decl.hpp"
#include "check_expr.decl.hpp"
#include "check_types.decl.hpp"
#include "lexer.decl.hpp"
#include "ast.types.hpp"
#include "check_env.types.hpp"
#include "typed.types.hpp"

namespace crate {

using namespace prelude;

namespace check_passes {

/// `Ctor`:
///
/// ```prism
/// type Ctor = record:
/// ```
struct Ctor {
    using prism_value = void;
    Text name;
    Nat arity;
    Array<check_types::Ty> args;
    Text shown;
    const Ctor* operator->() const { return this; }
    Ctor* operator->() { return this; }
    bool operator==(const Ctor&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Ctor> from_pod(const Pod& whole);
};


}  // namespace check_passes

namespace check_passes {

/// `PCx`:
///
/// ```prism
/// type PCx = record:
/// ```
struct PCx {
    using prism_value = void;
    check_env::G g;
    Text home;
    Map<Nat, ast::Expr> lams;
    Map<Text, Rel> base;
    const PCx* operator->() const { return this; }
    PCx* operator->() { return this; }
    bool operator==(const PCx&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<PCx> from_pod(const Pod& whole);
};


}  // namespace check_passes

namespace check_passes {

/// `Rel`:
///
/// ```prism
/// type Rel = record:
/// ```
struct Rel {
    using prism_value = void;
    Nat param;
    bool strict;
    const Rel* operator->() const { return this; }
    Rel* operator->() { return this; }
    bool operator==(const Rel&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Rel> from_pod(const Pod& whole);
};


}  // namespace check_passes

namespace check_passes {

/// `Report`:
///
/// ```prism
/// type Report = record:
/// ```
struct Report_ {
    using prism_value = void;
    Text text;
    Nat errors;
    Text root_row;
    typed::TProgram typed;
    const Report_* operator->() const { return this; }
    Report_* operator->() { return this; }
    bool operator==(const Report_&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Report_> from_pod(const Pod& whole);
};


}  // namespace check_passes

namespace check_passes {

/// `Sc`:
///
/// ```prism
/// type Sc = record:
/// ```
struct Sc {
    using prism_value = void;
    Text caller;
    Text callee;
    Array<std::tuple<Nat, Nat, bool>> edges;
    ast::Range span;
    Nat file;
    Text arg;
    const Sc* operator->() const { return this; }
    Sc* operator->() { return this; }
    bool operator==(const Sc&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Sc> from_pod(const Pod& whole);
};


}  // namespace check_passes

namespace check_passes {

/// `Shrink`:
///
/// ```prism
/// type Shrink = record:
/// ```
struct Shrink {
    using prism_value = void;
    check_env::G g;
    Array<check_env::Def> fns;
    Map<Text, check_env::Def> by_key;
    Map<Text, Array<Text>> targets;
    Map<Text, Text> impl_defs;
    Map<Text, Array<Text>> choices;
    Map<Text, Nat> sums;
    Map<Text, Map<Text, Rel>> seeds;
    Map<Text, Text> local_of;
    Map<Text, Map<Text, Rel>> local_base;
    const Shrink* operator->() const { return this; }
    Shrink* operator->() { return this; }
    bool operator==(const Shrink&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Shrink> from_pod(const Pod& whole);
};


}  // namespace check_passes

namespace check_passes {

/// `Site`:
///
/// ```prism
/// type Site = record:
/// ```
struct Site {
    using prism_value = void;
    Text callee;
    Array<ast::Arg> args;
    ast::Range span;
    Map<Text, Rel> rels;
    const Site* operator->() const { return this; }
    Site* operator->() { return this; }
    bool operator==(const Site&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Site> from_pod(const Pod& whole);
};


}  // namespace check_passes

namespace check_passes {

/// `Slot`:
///
/// ```prism
/// type Slot = record:
/// ```
struct Slot_ {
    using prism_value = void;
    Text owner;
    Nat at;
    Nat arity;
    const Slot_* operator->() const { return this; }
    Slot_* operator->() { return this; }
    bool operator==(const Slot_&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Slot_> from_pod(const Pod& whole);
};


}  // namespace check_passes

namespace check_passes {

struct Kid::KidExpr {
    ast::Expr a0;
    Map<Text, Rel> a1;
    bool operator==(const KidExpr&) const = default;
};


struct Kid::KidStmts {
    Array<ast::Stmt> a0;
    Map<Text, Rel> a1;
    bool operator==(const KidStmts&) const = default;
};


inline const Kid::Cases& Kid::cases() const { return *cases_; }

inline bool operator==(const Kid& a, const Kid& b) { return a.cases() == b.cases(); }

struct Pat::PtAny {
    bool operator==(const PtAny&) const = default;
};


struct Pat::PtCon {
    Text a0;
    Array<Pat> a1;
    bool operator==(const PtCon&) const = default;
};


struct Pat::PtLit {
    Text a0;
    bool operator==(const PtLit&) const = default;
};


struct Pat::PtFam {
    Text a0;
    bool operator==(const PtFam&) const = default;
};


inline const Pat::Cases& Pat::cases() const { return *cases_; }

inline bool operator==(const Pat& a, const Pat& b) { return a.cases() == b.cases(); }

struct Spot::SpotExpr {
    ast::Expr a0;
    Map<Text, Rel> a1;
    bool operator==(const SpotExpr&) const = default;
};


struct Spot::SpotStmt {
    ast::Stmt a0;
    Map<Text, Rel> a1;
    bool operator==(const SpotStmt&) const = default;
};


inline const Spot::Cases& Spot::cases() const { return *cases_; }

inline bool operator==(const Spot& a, const Spot& b) { return a.cases() == b.cases(); }

}  // namespace check_passes

}  // namespace crate
