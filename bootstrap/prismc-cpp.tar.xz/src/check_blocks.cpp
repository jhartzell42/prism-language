// The module `CheckBlocks`, from `target/bootstrap/cpp-src/prismc/check-blocks.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "check_blocks.hpp"
#include "ast.hpp"
#include "check_env.hpp"
#include "check_errors.hpp"
#include "check_expr.hpp"
#include "check_passes.hpp"
#include "check_types.hpp"
#include "lexer.hpp"
#include "typed.hpp"
#include "check_env.generic.hpp"
#include "lexer.generic.hpp"

namespace crate::check_blocks {

/// GroupOrder: fn [Stmt] -> [Nat]
Array<Nat> group_order(const Array<ast::Stmt>& stmts) {
    auto all = check_errors::range0(len(stmts));
    auto holds = filter(all, [&](const Nat& i) { return is_hold(or_(index(stmts, i), dummy_stmt2())); });
    auto lets = filter(all, [&](const Nat& i) { return is_let_like(or_(index(stmts, i), dummy_stmt2())); });
    auto rest = filter(all, [&](const Nat& i) { return (!is_hold(or_(index(stmts, i), dummy_stmt2()))) && (!is_let_like(or_(index(stmts, i), dummy_stmt2()))); });
    return append(append(holds, lets), rest);
}


/// DepOrder: unbounded fn [Stmt] -> [ [Nat] ]
Array<Array<Nat>> dep_order(const Array<ast::Stmt>& stmts) {
    auto n = len(stmts);
    auto defs = run_to_end(each_job(stmts, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(ast::Stmt)>>(prism_rtl::rc([=](ast::Stmt p0) {
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                (prism_rtl::more(prism_rtl::rc(GroupDefs(s))));
            });
        }));
    }))));
    auto uses = run_to_end(each_job(stmts, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(ast::Stmt)>>(prism_rtl::rc([=](ast::Stmt p0) {
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                (prism_rtl::more(prism_rtl::rc(check_passes::NamesInStmt(s))));
            });
        }));
    }))));
    auto deps = each(check_errors::range0(n), [&](const Nat& i) { return filter(check_errors::range0(n), [&](const Nat& j) { return fold(or_(index(defs, j), Array<Text>{}), false, [&](const bool& seen, const Text& d) { return seen || check_types::has_text(or_(index(uses, i), Array<Text>{}), d); }); }); });
    auto reach = run_to_end(each_job(check_errors::range0(n), ({
        auto deps_1 = deps;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto deps_1_2 = deps_1;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(ReachIdx(deps_1_2, or_(index(deps_1_2, i), Array<Nat>{}), Array<Nat>{}))));
            });
        }));
        });
    })));
    })));
    auto comps = each(check_errors::range0(n), [&](const Nat& i) { return filter(check_errors::range0(n), [&](const Nat& j) { return (j == i) || (check_types::has_nat(or_(index(reach, i), Array<Nat>{}), j) && check_types::has_nat(or_(index(reach, j), Array<Nat>{}), i)); }); });
    return emit_groups(comps, deps, Array<Nat>{}, Array<Array<Nat>>{});
}


prism_rtl::Turn<Array<Array<Nat>>> DepOrder::cycle() const {
    const auto& stmts = this->stmts;
    auto n = len(stmts);
    auto stmts_1 = stmts;
    return call_value(each_job(stmts_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(ast::Stmt)>>(prism_rtl::rc([=](ast::Stmt p0) {
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                (prism_rtl::more(prism_rtl::rc(GroupDefs(s))));
            });
        }));
    }))), [=](Array<Array<Text>> each_1872) {
        return ({
            auto defs = each_1872;
            call_value(each_job(stmts_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(ast::Stmt)>>(prism_rtl::rc([=](ast::Stmt p0) {
            return entered(once_job([=]() {
                return ({
                    auto s = p0;
                    (prism_rtl::more(prism_rtl::rc(check_passes::NamesInStmt(s))));
                });
            }));
        }))), [=](Array<Array<Text>> each_1916) {
            return ({
                auto uses = each_1916;
                auto deps = each(check_errors::range0(n), [&](const Nat& i) { return filter(check_errors::range0(n), [&](const Nat& j) { return fold(or_(index(defs, j), Array<Text>{}), false, [&](const bool& seen, const Text& d) { return seen || check_types::has_text(or_(index(uses, i), Array<Text>{}), d); }); }); });
                call_value(each_job(check_errors::range0(n), ({
                auto deps_2 = deps;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto deps_2_3 = deps_2;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        (prism_rtl::more(prism_rtl::rc(ReachIdx(deps_2_3, or_(index(deps_2_3, i), Array<Nat>{}), Array<Nat>{}))));
                    });
                }));
                });
            })));
            })), [=](Array<Array<Nat>> each_2105) {
                return ({
                    auto reach = each_2105;
                    auto comps = each(check_errors::range0(n), [&](const Nat& i) { return filter(check_errors::range0(n), [&](const Nat& j) { return (j == i) || (check_types::has_nat(or_(index(reach, i), Array<Nat>{}), j) && check_types::has_nat(or_(index(reach, j), Array<Nat>{}), i)); }); });
                    (prism_rtl::more(prism_rtl::rc(EmitGroups(comps, deps, Array<Nat>{}, Array<Array<Nat>>{}))));
                });
            });
            });
        });
        });
    });
}


/// `Start DepOrder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Array<Nat>>> start_dep_order(Array<ast::Stmt> stmts) {
    return prism_rtl::make_rc<DepOrder>(stmts);
}


/// GroupDefs: unbounded fn Stmt -> [Text]
Array<Text> group_defs(const ast::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<ast::StmtKind::SBind>(_m)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        return check_env::pattern_names(p_);
    }
    if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        return check_env::pattern_names(p_);
    }
    if (prism_rtl::is<ast::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
        return Array(std::vector{check_env::def_name_text(f.name)});
    }
    if (prism_rtl::is<ast::StmtKind::SWidget>(_m)) {
        auto&& w = prism_rtl::as<ast::StmtKind::SWidget>(_m).a0;
        return Array(std::vector{check_env::sname_key(w.name)});
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> GroupDefs::cycle() const {
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SBind>(_m) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        prism_rtl::more(prism_rtl::rc(check_env::PatternNames(p_)));
    })
        : prism_rtl::is<ast::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        prism_rtl::more(prism_rtl::rc(check_env::PatternNames(p_)));
    })
        : prism_rtl::is<ast::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
        prism_rtl::finished(Array(std::vector{check_env::def_name_text(f.name)}));
    })
        : prism_rtl::is<ast::StmtKind::SWidget>(_m) ? ({
        auto&& w = prism_rtl::as<ast::StmtKind::SWidget>(_m).a0;
        prism_rtl::finished(Array(std::vector{check_env::sname_key(w.name)}));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start GroupDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_group_defs(ast::Stmt s) {
    return prism_rtl::make_rc<GroupDefs>(s);
}


/// ReachIdx: unbounded fn [ [Nat] ], [Nat], [Nat] -> [Nat]
Array<Nat> reach_idx(const Array<Array<Nat>>& deps, const Array<Nat>& frontier, const Array<Nat>& seen) {
    auto&& _m = index(frontier, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return seen;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& x = prism_rtl::some_of(_m);
        return check_types::has_nat(seen, x)
            ? reach_idx(deps, drop(frontier, Nat(1u)), seen)
            : reach_idx(deps, append(drop(frontier, Nat(1u)), or_(index(deps, x), Array<Nat>{})), prelude::push(seen, x));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Nat>> ReachIdx::cycle() const {
    const auto& deps = this->deps;
    const auto& frontier = this->frontier;
    const auto& seen = this->seen;
    return ({
        auto&& _m = index(frontier, Nat(0u));
        prism_rtl::is_none(_m) ? prism_rtl::finished(seen)
        : prism_rtl::is_some(_m) ? ({
        auto&& x = prism_rtl::some_of(_m);
        check_types::has_nat(seen, x)
        ? prism_rtl::more(prism_rtl::rc(ReachIdx(deps, drop(frontier, Nat(1u)), seen)))
        : prism_rtl::more(prism_rtl::rc(ReachIdx(deps, append(drop(frontier, Nat(1u)), or_(index(deps, x), Array<Nat>{})), prelude::push(seen, x))));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ReachIdx, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_reach_idx(Array<Array<Nat>> deps, Array<Nat> frontier, Array<Nat> seen) {
    return prism_rtl::make_rc<ReachIdx>(deps, frontier, seen);
}


/// EmitGroups: unbounded fn [ [Nat] ], [ [Nat] ], [Nat], [ [Nat] ] -> [ [Nat] ]
Array<Array<Nat>> emit_groups(const Array<Array<Nat>>& comps, const Array<Array<Nat>>& deps, const Array<Nat>& done, const Array<Array<Nat>>& acc) {
    auto ready = filter(check_errors::range0(len(comps)), [&](const Nat& i) { return (!check_types::has_nat(done, i)) && fold(or_(index(deps, i), Array<Nat>{}), true, [&](const bool& ok, const Nat& d) { return ok && (check_types::has_nat(done, d) || check_types::has_nat(or_(index(comps, i), Array<Nat>{}), d)); }); });
    auto&& _m = index(ready, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return acc;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& i = prism_rtl::some_of(_m);
        auto c = or_(index(comps, i), Array(std::vector{i}));
        return emit_groups(comps, deps, append(done, c), prelude::push(acc, c));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Array<Nat>>> EmitGroups::cycle() const {
    const auto& comps = this->comps;
    const auto& deps = this->deps;
    const auto& done = this->done;
    const auto& acc = this->acc;
    auto ready = filter(check_errors::range0(len(comps)), [&](const Nat& i) { return (!check_types::has_nat(done, i)) && fold(or_(index(deps, i), Array<Nat>{}), true, [&](const bool& ok, const Nat& d) { return ok && (check_types::has_nat(done, d) || check_types::has_nat(or_(index(comps, i), Array<Nat>{}), d)); }); });
    return ({
        auto&& _m = index(ready, Nat(0u));
        prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
        : prism_rtl::is_some(_m) ? ({
        auto&& i = prism_rtl::some_of(_m);
        ({
        auto c = or_(index(comps, i), Array(std::vector{i}));
        (prism_rtl::more(prism_rtl::rc(EmitGroups(comps, deps, append(done, c), prelude::push(acc, c)))));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start EmitGroups, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Array<Nat>>> start_emit_groups(Array<Array<Nat>> comps, Array<Array<Nat>> deps, Array<Nat> done, Array<Array<Nat>> acc) {
    return prism_rtl::make_rc<EmitGroups>(comps, deps, done, acc);
}


/// IsHold: fn Stmt -> Bool
bool is_hold(const ast::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<ast::StmtKind::SBind>(_m).a2)) {
        return true;
    }
    {
        return false;
    }
}


/// IsLetLike: fn Stmt -> Bool
bool is_let_like(const ast::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
        return true;
    }
    if (prism_rtl::is<ast::StmtKind::SFn>(_m)) {
        return true;
    }
    if (prism_rtl::is<ast::StmtKind::SSignature>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// InferWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_widget_block(const check_expr::Env& env, const check_types::St& st, const ast::Block& b) {
    auto [env1, st1] = block_row(env, st, b.stmts);
    auto [env2, st2] = run_to_end(fold_job(b.stmts, std::tuple{env1, st1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St>>(std::tuple<std::tuple<check_expr::Env, check_types::St>, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<check_expr::Env, check_types::St>, ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto stmt = p1;
                (prism_rtl::more(prism_rtl::rc(PreBindStmt(en, s, stmt))));
            });
        }));
    }))));
    auto n = len(b.stmts);
    auto [env3, st3, res_opt] = run_to_end(fold_job(group_order(b.stmts), std::tuple{env2, st2, std::optional<check_types::Ty>{}}, ({
        auto b_1 = b;
        auto n_2 = n;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>>(std::tuple<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_3 = b_1;
            auto n_2_3 = n_2;
            entered(once_job([=]() {
            return ({
                auto [en, s, r_opt] = p0;
                auto i = p1;
                ({
                auto stmt = or_(index(b_1_3.stmts, i), dummy_stmt2());
                call_then(start_widget_stmt(en, s, stmt, (i + Nat(1u)) == n_2_3), [=](std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>> widget_stmt_4497) {
                return ({
                    auto [en2, s2, r2_opt] = widget_stmt_4497;
                    ({
                    prism_rtl::is_some(r2_opt) ? ({
                    auto&& t = prism_rtl::some_of(r2_opt);
                    prism_rtl::finished(std::tuple{en2, s2, std::optional(t)});
                })
                    : prism_rtl::is_none(r2_opt) ? prism_rtl::finished(std::tuple{en2, s2, r_opt})
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto st4 = check_passes::block_prompt_cycles(env3, st3, b);
    auto st5 = st4.recording
        ? check_types::note_group(st4, b.span, Text::lit("widget"), dep_order(b.stmts))
        : st4;
    return std::tuple{or_(res_opt, check_types::t_unit()), st5};
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferWidgetBlock::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& b = this->b;
    auto b_1 = b;
    auto env_2 = env;
    auto st_3 = st;
    return call_then(start_block_row(env_2, st_3, b_1.stmts), [=](std::tuple<check_expr::Env, check_types::St> block_row_4178) {
        return ({
            auto [env1, st1] = block_row_4178;
            call_value(fold_job(b_1.stmts, std::tuple{env1, st1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St>>(std::tuple<std::tuple<check_expr::Env, check_types::St>, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<check_expr::Env, check_types::St>, ast::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto [en, s] = p0;
                    auto stmt = p1;
                    (prism_rtl::more(prism_rtl::rc(PreBindStmt(en, s, stmt))));
                });
            }));
        }))), [=](std::tuple<check_expr::Env, check_types::St> fold_4228) {
            return ({
                auto [env2, st2] = fold_4228;
                auto n = len(b_1.stmts);
                call_value(fold_job(group_order(b_1.stmts), std::tuple{env2, st2, std::optional<check_types::Ty>{}}, ({
                auto b_1_4 = b_1;
                auto n_4 = n;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>>(std::tuple<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto b_1_4_5 = b_1_4;
                    auto n_4_5 = n_4;
                    entered(once_job([=]() {
                    return ({
                        auto [en, s, r_opt] = p0;
                        auto i = p1;
                        ({
                        auto stmt = or_(index(b_1_4_5.stmts, i), dummy_stmt2());
                        call_then(start_widget_stmt(en, s, stmt, (i + Nat(1u)) == n_4_5), [=](std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>> widget_stmt_4497) {
                        return ({
                            auto [en2, s2, r2_opt] = widget_stmt_4497;
                            ({
                            prism_rtl::is_some(r2_opt) ? ({
                            auto&& t = prism_rtl::some_of(r2_opt);
                            prism_rtl::finished(std::tuple{en2, s2, std::optional(t)});
                        })
                            : prism_rtl::is_none(r2_opt) ? prism_rtl::finished(std::tuple{en2, s2, r_opt})
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                    });
                    });
                    });
                }));
                });
            }));
            })), [=](std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>> fold_4354) {
                return ({
                    auto [env3, st3, res_opt] = fold_4354;
                    call_then(check_passes::start_block_prompt_cycles(env3, st3, b_1), [=](check_types::St block_prompt_cycles_4632) {
                    return ({
                        auto st4 = block_prompt_cycles_4632;
                        auto st5 = st4.recording
                            ? check_types::note_group(st4, b_1.span, Text::lit("widget"), dep_order(b_1.stmts))
                            : st4;
                        (prism_rtl::finished(std::tuple{or_(res_opt, check_types::t_unit()), st5}));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start InferWidgetBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_widget_block(check_expr::Env env, check_types::St st, ast::Block b) {
    return prism_rtl::make_rc<InferWidgetBlock>(env, st, b);
}


/// let dummyStmt2
ast::Stmt dummy_stmt2() {
    return ast::Stmt{.kind = ast::StmtKind(ast::StmtKind::SExpr{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}}}), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// BlockRow: unbounded fn Env, St, [Stmt] -> ((Env, St))
std::tuple<check_expr::Env, check_types::St> block_row(const check_expr::Env& env, const check_types::St& st, const Array<ast::Stmt>& stmts) {
    return run_to_end(fold_job(check_errors::range0(len(stmts)), std::tuple{env, st}, ({
        auto stmts_1 = stmts;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St>>(std::tuple<std::tuple<check_expr::Env, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<check_expr::Env, check_types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto stmts_1_2 = stmts_1;
            entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto i = p1;
                ({
                auto&& _m = index(stmts_1_2, i);
                prism_rtl::is_some(_m) ? ({
                auto&& stmt = prism_rtl::some_of(_m);
                ({
                auto&& _m = stmt.kind;
                prism_rtl::is<ast::StmtKind::SEmit>(_m) ? ({
                auto&& row_decl = prism_rtl::as<ast::StmtKind::SEmit>(_m).a0;
                i > Nat(0u)
                ? prism_rtl::finished(std::tuple{en, check_types::err_fix(s, Text::lit("emit-element"), stmt.span, Text::lit("`emit` comes first in its block"), Text::lit("move this line to the top of the block"))})
                : ({
                auto row_decl_2 = row_decl;
                call_then(check_env::start_conv_row(check_expr::env_cx(en), s, row_as_type(row_decl_2)), [=](std::tuple<check_types::Rw, check_types::St> conv_row_5394) {
                return ({
                    auto [rw, s2] = conv_row_5394;
                    auto en2 = ({
                        check_expr::Env this_ = en;
                        this_.scope = resolve_scope_row(en, rw);
                        this_;
                    });
                    (prism_rtl::finished(std::tuple{en2, s2}));
                });
            });
            });
            })
                : prism_rtl::finished(std::tuple{en, s});
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en, s})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<check_expr::Env, check_types::St>> BlockRow::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& stmts = this->stmts;
    return fold_job(check_errors::range0(len(stmts)), std::tuple{env, st}, ({
        auto stmts_1 = stmts;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St>>(std::tuple<std::tuple<check_expr::Env, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<check_expr::Env, check_types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto stmts_1_2 = stmts_1;
            entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto i = p1;
                ({
                auto&& _m = index(stmts_1_2, i);
                prism_rtl::is_some(_m) ? ({
                auto&& stmt = prism_rtl::some_of(_m);
                ({
                auto&& _m = stmt.kind;
                prism_rtl::is<ast::StmtKind::SEmit>(_m) ? ({
                auto&& row_decl = prism_rtl::as<ast::StmtKind::SEmit>(_m).a0;
                i > Nat(0u)
                ? prism_rtl::finished(std::tuple{en, check_types::err_fix(s, Text::lit("emit-element"), stmt.span, Text::lit("`emit` comes first in its block"), Text::lit("move this line to the top of the block"))})
                : ({
                auto row_decl_2 = row_decl;
                call_then(check_env::start_conv_row(check_expr::env_cx(en), s, row_as_type(row_decl_2)), [=](std::tuple<check_types::Rw, check_types::St> conv_row_5394) {
                return ({
                    auto [rw, s2] = conv_row_5394;
                    auto en2 = ({
                        check_expr::Env this_ = en;
                        this_.scope = resolve_scope_row(en, rw);
                        this_;
                    });
                    (prism_rtl::finished(std::tuple{en2, s2}));
                });
            });
            });
            })
                : prism_rtl::finished(std::tuple{en, s});
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en, s})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start BlockRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St>> start_block_row(check_expr::Env env, check_types::St st, Array<ast::Stmt> stmts) {
    return prism_rtl::make_rc<BlockRow>(env, st, stmts);
}


/// RowAsType: fn Row -> Type
ast::Type row_as_type(const ast::Row_& row_decl) {
    return ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TRowUnion{each(row_decl.terms, row_term_type)})), .span = row_decl.span};
}


/// RowTermType: fn RowTerm -> Type
ast::Type row_term_type(const ast::RowTerm& row_term0) {
    if (prism_rtl::is<ast::RowTerm::RFamily>(row_term0)) {
        auto&& q = prism_rtl::as<ast::RowTerm::RFamily>(row_term0).a0;
        return ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TFamily{q})), .span = q.span};
    }
    if (prism_rtl::is<ast::RowTerm::RVar>(row_term0)) {
        auto&& v_ = prism_rtl::as<ast::RowTerm::RVar>(row_term0).a0;
        return ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TName{ast::SName{.sigils = Text::lit(""), .path_ = Array(std::vector{v_.name}), .span = v_.span}, Array<ast::Type>{}})), .span = v_.span};
    }
    if (prism_rtl::is<ast::RowTerm::RType>(row_term0)) {
        auto&& t = prism_rtl::as<ast::RowTerm::RType>(row_term0).a0;
        return t;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ResolveScopeRow: fn Env, Rw -> Rw
check_types::Rw resolve_scope_row(const check_expr::Env& env, const check_types::Rw& rw) {
    auto&& _m = rw.tail;
    if (prism_rtl::is<check_types::Tail::TlQ>(_m)) {
        auto&& v_ = prism_rtl::as<check_types::Tail::TlQ>(_m).a0;
        return check_types::Rw{.fams = rw.fams, .minus = rw.minus, .tail = env.scope.tail};
    }
    {
        return rw;
    }
}


/// PreBindStmt: unbounded fn Env, St, Stmt -> ((Env, St))
std::tuple<check_expr::Env, check_types::St> pre_bind_stmt(const check_expr::Env& env, const check_types::St& st, const ast::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<ast::StmtKind::SBind>(_m)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        return pre_bind_pattern(env, st, p_);
    }
    if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
        return check_expr::pre_bind(env, st, s);
    }
    if (prism_rtl::is<ast::StmtKind::SFn>(_m)) {
        return check_expr::pre_bind(env, st, s);
    }
    if (prism_rtl::is<ast::StmtKind::SSignature>(_m)) {
        return check_expr::pre_bind(env, st, s);
    }
    if (prism_rtl::is<ast::StmtKind::SWidget>(_m)) {
        auto&& w = prism_rtl::as<ast::StmtKind::SWidget>(_m).a0;
        auto [v_, st2] = check_types::fresh_var(st, false, Text::lit(""));
        return std::tuple{check_expr::with_local(env, check_env::sname_key(w.name), check_types::mono(check_types::Ty(check_types::Ty::TyAt{prism_rtl::rc(v_), env.scope}))), st2};
    }
    {
        return std::tuple{env, st};
    }
}


prism_rtl::Turn<std::tuple<check_expr::Env, check_types::St>> PreBindStmt::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SBind>(_m) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PreBindPattern(env, st, p_)));
    })
        : prism_rtl::is<ast::StmtKind::SLet>(_m) ? prism_rtl::more(prism_rtl::rc(check_expr::PreBind(env, st, s)))
        : prism_rtl::is<ast::StmtKind::SFn>(_m) ? prism_rtl::more(prism_rtl::rc(check_expr::PreBind(env, st, s)))
        : prism_rtl::is<ast::StmtKind::SSignature>(_m) ? prism_rtl::more(prism_rtl::rc(check_expr::PreBind(env, st, s)))
        : prism_rtl::is<ast::StmtKind::SWidget>(_m) ? ({
        auto&& w = prism_rtl::as<ast::StmtKind::SWidget>(_m).a0;
        ({
        auto [v_, st2] = check_types::fresh_var(st, false, Text::lit(""));
        (prism_rtl::finished(std::tuple{check_expr::with_local(env, check_env::sname_key(w.name), check_types::mono(check_types::Ty(check_types::Ty::TyAt{prism_rtl::rc(v_), env.scope}))), st2}));
    });
    })
        : prism_rtl::finished(std::tuple{env, st});
    });
}


/// `Start PreBindStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St>> start_pre_bind_stmt(check_expr::Env env, check_types::St st, ast::Stmt s) {
    return prism_rtl::make_rc<PreBindStmt>(env, st, s);
}


/// PreBindPattern: unbounded fn Env, St, Pattern -> ((Env, St))
std::tuple<check_expr::Env, check_types::St> pre_bind_pattern(const check_expr::Env& env, const check_types::St& st, const ast::Pattern_& p_) {
    return fold(check_env::pattern_binders(p_), std::tuple{env, st}, [&](const std::tuple<check_expr::Env, check_types::St>& _p0, const std::tuple<Text, ast::Range>& _p1) {
        auto&& en = std::get<0>(_p0);
        auto&& s = std::get<1>(_p0);
        auto&& name = std::get<0>(_p1);
        auto&& at_ = std::get<1>(_p1);
        return ({
            auto [v_, s1] = check_types::fresh_var(s, true, name);
            auto s2 = check_types::at_binder(s1, v_, at_);
            auto [rw, s3] = check_types::fresh_row(s2, Array<Text>{});
            auto t = check_types::with_marks(check_expr::type_marks(check_types::marks_of(name)), v_, rw);
            auto en2 = ({
                check_expr::Env this_ = check_expr::with_local(en, name, check_types::mono(t));
                this_.pending = check_types::add_text(this_.pending, name);
                this_;
            });
            std::tuple{en2, s3};
        });
    });
}


prism_rtl::Turn<std::tuple<check_expr::Env, check_types::St>> PreBindPattern::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    auto env_1 = env;
    auto p__2 = p_;
    auto st_3 = st;
    return call_then(check_env::start_pattern_binders(p__2), [=](Array<std::tuple<Text, ast::Range>> pattern_binders_6915) {
        return prism_rtl::finished(fold(pattern_binders_6915, std::tuple{env_1, st_3}, [&](const std::tuple<check_expr::Env, check_types::St>& _p0, const std::tuple<Text, ast::Range>& _p1) {
            auto&& en = std::get<0>(_p0);
            auto&& s = std::get<1>(_p0);
            auto&& name = std::get<0>(_p1);
            auto&& at_ = std::get<1>(_p1);
            return ({
                auto [v_, s1] = check_types::fresh_var(s, true, name);
                auto s2 = check_types::at_binder(s1, v_, at_);
                auto [rw, s3] = check_types::fresh_row(s2, Array<Text>{});
                auto t = check_types::with_marks(check_expr::type_marks(check_types::marks_of(name)), v_, rw);
                auto en2 = ({
                    check_expr::Env this_ = check_expr::with_local(en, name, check_types::mono(t));
                    this_.pending = check_types::add_text(this_.pending, name);
                    this_;
                });
                std::tuple{en2, s3};
            });
        }));
    });
}


/// `Start PreBindPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St>> start_pre_bind_pattern(check_expr::Env env, check_types::St st, ast::Pattern_ p_) {
    return prism_rtl::make_rc<PreBindPattern>(env, st, p_);
}


/// WidgetStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St, ?Ty))
std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>> widget_stmt(const check_expr::Env& env, const check_types::St& st, const ast::Stmt& s, const bool& last) {
    auto&& _m = s.kind;
    if (prism_rtl::is<ast::StmtKind::SEmit>(_m)) {
        return std::tuple{env, st, last
            ? std::optional(check_types::t_unit())
            : std::optional<check_types::Ty>{}};
    }
    if (prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<ast::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
        auto st2 = bind_stmt(env, st, p_, e, s.span);
        return std::tuple{env, st2, last
            ? std::optional(check_types::t_unit())
            : std::optional<check_types::Ty>{}};
    }
    if (prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<ast::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        auto&& init = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
        auto&& step_ = prism_rtl::some_of(prism_rtl::as<ast::StmtKind::SBind>(_m).a2);
        auto st2 = hold_stmt(env, st, p_, init, step_, s.span);
        return std::tuple{env, st2, last
            ? std::optional(check_types::t_unit())
            : std::optional<check_types::Ty>{}};
    }
    if (prism_rtl::is<ast::StmtKind::SIgnore>(_m)) {
        auto&& e = prism_rtl::as<ast::StmtKind::SIgnore>(_m).a0;
        auto st2 = ignore_stmt(env, st, e, s.span);
        return std::tuple{env, st2, last
            ? std::optional(check_types::t_unit())
            : std::optional<check_types::Ty>{}};
    }
    if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<ast::StmtKind::SLet>(_m).a1;
        auto&& e = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
        auto [env2, st2] = check_expr::check_let(env, st, p_, ty_opt, e, s.span);
        return std::tuple{env2, st2, last
            ? std::optional(check_types::t_unit())
            : std::optional<check_types::Ty>{}};
    }
    if (prism_rtl::is<ast::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
        auto [env2, st2] = check_expr::check_local_fn(env, st, f, s.span);
        return std::tuple{env2, st2, last
            ? std::optional(check_types::t_unit())
            : std::optional<check_types::Ty>{}};
    }
    if (prism_rtl::is<ast::StmtKind::SSignature>(_m)) {
        return std::tuple{env, st, last
            ? std::optional(check_types::t_unit())
            : std::optional<check_types::Ty>{}};
    }
    if (prism_rtl::is<ast::StmtKind::SWidget>(_m)) {
        auto&& w = prism_rtl::as<ast::StmtKind::SWidget>(_m).a0;
        auto [t, st2] = infer_widget_block(env, st, w.body);
        auto st3 = ({
            __label__ _done;
            prism_rtl::Slot<check_types::St> _v;
            auto&& _m = prelude::get(env.locals, check_env::sname_key(w.name));
            if (prism_rtl::is_some(_m)) {
                auto&& sc = prism_rtl::some_of(_m);
                _v.set(check_types::unify(st2, sc.ty, check_types::Ty(check_types::Ty::TyAt{prism_rtl::rc(t), env.scope}), w.span));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(st2);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return std::tuple{env, st3, last
            ? std::optional(check_types::t_unit())
            : std::optional<check_types::Ty>{}};
    }
    if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
        auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        auto [t, st2] = bare_line(env, st, e, last);
        return last
            ? std::tuple{env, st2, std::optional(t)}
            : std::tuple{env, st2, std::optional<check_types::Ty>{}};
    }
    {
        return std::tuple{env, check_types::err(st, Text::lit("mismatch"), s.span, Text::lit("this statement belongs in a `given:` or `update` block")), last
            ? std::optional(check_types::t_unit())
            : std::optional<check_types::Ty>{}};
    }
}


prism_rtl::Turn<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>> WidgetStmt::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& s = this->s;
    const auto& last = this->last;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SEmit>(_m) ? prism_rtl::finished(std::tuple{env, st, last
        ? std::optional(check_types::t_unit())
        : std::optional<check_types::Ty>{}})
        : prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<ast::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
        ({
        auto e_1 = e;
        auto env_2 = env;
        auto last_3 = last;
        auto p__4 = p_;
        auto s_5 = s;
        auto st_6 = st;
        call_then(start_bind_stmt(env_2, st_6, p__4, e_1, s_5.span), [=](check_types::St bind_stmt_7540) {
        return ({
            auto st2 = bind_stmt_7540;
            (prism_rtl::finished(std::tuple{env_2, st2, last_3
            ? std::optional(check_types::t_unit())
            : std::optional<check_types::Ty>{}}));
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<ast::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        auto&& init = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
        auto&& step_ = prism_rtl::some_of(prism_rtl::as<ast::StmtKind::SBind>(_m).a2);
        ({
        auto env_1 = env;
        auto init_2 = init;
        auto last_3 = last;
        auto p__4 = p_;
        auto s_5 = s;
        auto st_6 = st;
        auto step__7 = step_;
        call_then(start_hold_stmt(env_1, st_6, p__4, init_2, step__7, s_5.span), [=](check_types::St hold_stmt_7667) {
        return ({
            auto st2 = hold_stmt_7667;
            (prism_rtl::finished(std::tuple{env_1, st2, last_3
            ? std::optional(check_types::t_unit())
            : std::optional<check_types::Ty>{}}));
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SIgnore>(_m) ? ({
        auto&& e = prism_rtl::as<ast::StmtKind::SIgnore>(_m).a0;
        ({
        auto e_1 = e;
        auto env_2 = env;
        auto last_3 = last;
        auto s_4 = s;
        auto st_5 = st;
        call_then(start_ignore_stmt(env_2, st_5, e_1, s_4.span), [=](check_types::St ignore_stmt_7789) {
        return ({
            auto st2 = ignore_stmt_7789;
            (prism_rtl::finished(std::tuple{env_2, st2, last_3
            ? std::optional(check_types::t_unit())
            : std::optional<check_types::Ty>{}}));
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<ast::StmtKind::SLet>(_m).a1;
        auto&& e = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
        ({
        auto ty_opt_1 = ty_opt;
        auto e_2 = e;
        auto env_3 = env;
        auto last_4 = last;
        auto p__5 = p_;
        auto s_6 = s;
        auto st_7 = st;
        call_then(check_expr::start_check_let(env_3, st_7, p__5, ty_opt_1, e_2, s_6.span), [=](std::tuple<check_expr::Env, check_types::St> check_let_7916) {
        return ({
            auto [env2, st2] = check_let_7916;
            (prism_rtl::finished(std::tuple{env2, st2, last_4
            ? std::optional(check_types::t_unit())
            : std::optional<check_types::Ty>{}}));
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
        ({
        auto env_1 = env;
        auto f_2 = f;
        auto last_3 = last;
        auto s_4 = s;
        auto st_5 = st;
        call_then(check_expr::start_check_local_fn(env_1, st_5, f_2, s_4.span), [=](std::tuple<check_expr::Env, check_types::St> check_local_fn_8041) {
        return ({
            auto [env2, st2] = check_local_fn_8041;
            (prism_rtl::finished(std::tuple{env2, st2, last_3
            ? std::optional(check_types::t_unit())
            : std::optional<check_types::Ty>{}}));
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SSignature>(_m) ? prism_rtl::finished(std::tuple{env, st, last
        ? std::optional(check_types::t_unit())
        : std::optional<check_types::Ty>{}})
        : prism_rtl::is<ast::StmtKind::SWidget>(_m) ? ({
        auto&& w = prism_rtl::as<ast::StmtKind::SWidget>(_m).a0;
        ({
        auto env_1 = env;
        auto last_2 = last;
        auto st_3 = st;
        auto w_4 = w;
        call_then(start_infer_widget_block(env_1, st_3, w_4.body), [=](std::tuple<check_types::Ty, check_types::St> infer_widget_block_8226) {
        return ({
            auto [t, st2] = infer_widget_block_8226;
            auto st3 = ({
                __label__ _done;
                prism_rtl::Slot<check_types::St> _v;
                auto&& _m = prelude::get(env_1.locals, check_env::sname_key(w_4.name));
                if (prism_rtl::is_some(_m)) {
                    auto&& sc = prism_rtl::some_of(_m);
                    _v.set(check_types::unify(st2, sc.ty, check_types::Ty(check_types::Ty::TyAt{prism_rtl::rc(t), env_1.scope}), w_4.span));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(st2);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(std::tuple{env_1, st3, last_2
            ? std::optional(check_types::t_unit())
            : std::optional<check_types::Ty>{}}));
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
        auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        ({
        auto e_1 = e;
        auto env_2 = env;
        auto last_3 = last;
        auto st_4 = st;
        call_then(start_bare_line(env_2, st_4, e_1, last_3), [=](std::tuple<check_types::Ty, check_types::St> bare_line_8484) {
        return ({
            auto [t, st2] = bare_line_8484;
            last_3
            ? prism_rtl::finished(std::tuple{env_2, st2, std::optional(t)})
            : prism_rtl::finished(std::tuple{env_2, st2, std::optional<check_types::Ty>{}});
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{env, check_types::err(st, Text::lit("mismatch"), s.span, Text::lit("this statement belongs in a `given:` or `update` block")), last
        ? std::optional(check_types::t_unit())
        : std::optional<check_types::Ty>{}});
    });
}


/// `Start WidgetStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>> start_widget_stmt(check_expr::Env env, check_types::St st, ast::Stmt s, bool last) {
    return prism_rtl::make_rc<WidgetStmt>(env, st, s, last);
}


/// BindStmt: unbounded fn Env, St, Pattern, Expr, Range -> St
check_types::St bind_stmt(const check_expr::Env& env, const check_types::St& st, const ast::Pattern_& p_, const ast::Expr& e, const ast::Range& span) {
    auto [t, st1] = check_expr::infer(env, st, e);
    auto [out, st2] = is_builder(e) ? std::tuple{t, st1} : bind_output(env, st1, t, e.span);
    auto&& _st3 = check_expr::bind_pattern(env, st2, p_, out, false);
    auto&& st3 = std::get<1>(_st3);
    return st3;
}


prism_rtl::Turn<check_types::St> BindStmt::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& e = this->e;
    const auto& span = this->span;
    auto e_1 = e;
    auto env_2 = env;
    auto p__3 = p_;
    auto span_4 = span;
    auto st_5 = st;
    return call_then(check_expr::start_infer(env_2, st_5, e_1), [=](std::tuple<check_types::Ty, check_types::St> infer_9099) {
        return ({
            auto [t, st1] = infer_9099;
            auto [out, st2] = is_builder(e_1) ? std::tuple{t, st1} : bind_output(env_2, st1, t, e_1.span);
            call_then(check_expr::start_bind_pattern(env_2, st2, p__3, out, false), [=](std::tuple<check_expr::Env, check_types::St> bind_pattern_9229) {
            return ({
                auto&& _st3 = bind_pattern_9229;
                auto&& st3 = std::get<1>(_st3);
                (prism_rtl::finished(st3));
            });
        });
        });
    });
}


/// `Start BindStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_bind_stmt(check_expr::Env env, check_types::St st, ast::Pattern_ p_, ast::Expr e, ast::Range span) {
    return prism_rtl::make_rc<BindStmt>(env, st, p_, e, span);
}


/// IsBuilder: fn Expr -> Bool
bool is_builder(const ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<ast::ExprKind::ERebuild>(_m)) {
        return true;
    }
    if (prism_rtl::is<ast::ExprKind::EFor>(_m)) {
        return true;
    }
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        return is_builder(x);
    }
    {
        return false;
    }
}


/// BindOutput: unbounded fn Env, St, Ty, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> bind_output(const check_expr::Env& env, const check_types::St& st, const check_types::Ty& t, const ast::Range& span) {
    auto&& _m = check_types::walk(st, t);
    if (prism_rtl::is<check_types::Ty::TyAt>(_m)) {
        auto&& inner = prism_rtl::as<check_types::Ty::TyAt>(_m).a0;
        auto&& rw = prism_rtl::as<check_types::Ty::TyAt>(_m).a1;
        return std::tuple{inner, add_incl(st, rw, env.scope, span, Text::lit("child"))};
    }
    if (prism_rtl::is<check_types::Ty::TyElem>(_m)) {
        auto&& rw = prism_rtl::as<check_types::Ty::TyElem>(_m).a0;
        auto&& o = prism_rtl::as<check_types::Ty::TyElem>(_m).a1;
        return std::tuple{o, add_incl(st, rw, env.scope, span, Text::lit("element"))};
    }
    if (prism_rtl::is<check_types::Ty::TySig>(_m)) {
        auto&& s = prism_rtl::as<check_types::Ty::TySig>(_m).a0;
        auto&& inner = prism_rtl::as<check_types::Ty::TySig>(_m).a1;
        auto&& _m = check_types::walk(st, inner);
        if (prism_rtl::is<check_types::Ty::TyAt>(_m)) {
            return std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err_fix(st, Text::lit("bind-dynamic"), span, prism_rtl::cat("binding a `", check_types::show_ty(st, t), "`; say what happens to the old widgets with `rebuild`"), Text::lit("write `rebuild` over the dynamic, with the blueprint inside"))};
        }
        if (prism_rtl::is<check_types::Ty::TyElem>(_m)) {
            return std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err_fix(st, Text::lit("bind-dynamic"), span, prism_rtl::cat("binding a `", check_types::show_ty(st, t), "`, a ", s == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of elements; say what happens to the old element with `rebuild`"), Text::lit("write `rebuild` over the dynamic field's value, with the element inside"))};
        }
        {
            return std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`<-` binds a blueprint or an element; this is `", check_types::show_ty(st, t), "`"))};
        }
    }
    if (prism_rtl::is<check_types::Ty::TyFlex>(_m)) {
        auto [v_, st2] = check_types::fresh_var(st, false, Text::lit(""));
        return std::tuple{v_, check_types::unify(st2, t, check_types::Ty(check_types::Ty::TyAt{prism_rtl::rc(v_), env.scope}), span)};
    }
    if (prism_rtl::is<check_types::Ty::TyErr>(_m)) {
        return std::tuple{check_types::Ty(check_types::Ty::TyErr{}), st};
    }
    {
        auto&& other = _m;
        return std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`<-` binds a blueprint or an element; this is `", check_types::show_ty(st, other), "`"))};
    }
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> BindOutput::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& span = this->span;
    auto env_1 = env;
    auto span_2 = span;
    auto st_3 = st;
    auto t_4 = t;
    return call_then(check_types::start_walk(st_3, t_4), [=](check_types::Ty walk_9624) {
        return ({
            prism_rtl::is<check_types::Ty::TyAt>(walk_9624) ? ({
            auto&& inner = prism_rtl::as<check_types::Ty::TyAt>(walk_9624).a0;
            auto&& rw = prism_rtl::as<check_types::Ty::TyAt>(walk_9624).a1;
            prism_rtl::finished(std::tuple{inner, add_incl(st_3, rw, env_1.scope, span_2, Text::lit("child"))});
        })
            : prism_rtl::is<check_types::Ty::TyElem>(walk_9624) ? ({
            auto&& rw = prism_rtl::as<check_types::Ty::TyElem>(walk_9624).a0;
            auto&& o = prism_rtl::as<check_types::Ty::TyElem>(walk_9624).a1;
            prism_rtl::finished(std::tuple{o, add_incl(st_3, rw, env_1.scope, span_2, Text::lit("element"))});
        })
            : prism_rtl::is<check_types::Ty::TySig>(walk_9624) ? ({
            auto&& s = prism_rtl::as<check_types::Ty::TySig>(walk_9624).a0;
            auto&& inner = prism_rtl::as<check_types::Ty::TySig>(walk_9624).a1;
            call_then(check_types::start_walk(st_3, inner), [=](check_types::Ty walk_9814) {
            return ({
                prism_rtl::is<check_types::Ty::TyAt>(walk_9814) ? call_then(check_types::start_show_ty(st_3, t_4), [=](Text show_ty_9919) { return prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err_fix(st_3, Text::lit("bind-dynamic"), span_2, prism_rtl::cat("binding a `", show_ty_9919, "`; say what happens to the old widgets with `rebuild`"), Text::lit("write `rebuild` over the dynamic, with the blueprint inside"))}); })
                : prism_rtl::is<check_types::Ty::TyElem>(walk_9814) ? call_then(check_types::start_show_ty(st_3, t_4), [=](Text show_ty_10144) { return prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err_fix(st_3, Text::lit("bind-dynamic"), span_2, prism_rtl::cat("binding a `", show_ty_10144, "`, a ", s == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of elements; say what happens to the old element with `rebuild`"), Text::lit("write `rebuild` over the dynamic field's value, with the element inside"))}); })
                : call_then(check_types::start_show_ty(st_3, t_4), [=](Text show_ty_10452) { return prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st_3, Text::lit("mismatch"), span_2, prism_rtl::cat("`<-` binds a blueprint or an element; this is `", show_ty_10452, "`"))}); });
            });
        });
        })
            : prism_rtl::is<check_types::Ty::TyFlex>(walk_9624) ? ({
            auto [v_, st2] = check_types::fresh_var(st_3, false, Text::lit(""));
            call_then(check_types::start_unify(st2, t_4, check_types::Ty(check_types::Ty::TyAt{prism_rtl::rc(v_), env_1.scope}), span_2), [=](check_types::St unify_10552) { return prism_rtl::finished(std::tuple{v_, unify_10552}); });
        })
            : prism_rtl::is<check_types::Ty::TyErr>(walk_9624) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), st_3})
            : ({
            auto&& other = walk_9624;
            call_then(check_types::start_show_ty(st_3, other), [=](Text show_ty_10716) { return prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st_3, Text::lit("mismatch"), span_2, prism_rtl::cat("`<-` binds a blueprint or an element; this is `", show_ty_10716, "`"))}); });
        });
        });
    });
}


/// `Start BindOutput, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_bind_output(check_expr::Env env, check_types::St st, check_types::Ty t, ast::Range span) {
    return prism_rtl::make_rc<BindOutput>(env, st, t, span);
}


/// AddIncl: fn St, Rw, Rw, Range, Text -> St
check_types::St add_incl(const check_types::St& st, const check_types::Rw& sub, const check_types::Rw& sup, const ast::Range& span, const Text& what) {
    check_types::St this_ = st;
    this_.incls = prelude::push(this_.incls, check_types::Incl{.sub = sub, .sup = sup, .file = this_.file, .span = span, .what = what, .forward = false});
    return this_;
}


/// HoldStmt: unbounded fn Env, St, Pattern, Expr, Expr, Range -> St
check_types::St hold_stmt(const check_expr::Env& env, const check_types::St& st, const ast::Pattern_& p_, const ast::Expr& init, const ast::Expr& step_, const ast::Range& span) {
    auto [v_, st1] = check_types::fresh_var(st, false, Text::lit(""));
    auto held = check_types::Ty(check_types::Ty::TySig{Text::lit("$"), prism_rtl::rc(v_)});
    auto&& _st2 = check_expr::bind_pattern(env, st1, p_, held, false);
    auto&& st2 = std::get<1>(_st2);
    auto st3 = check_expr::check(env, st2, init, v_);
    auto [step_ty, st4] = check_expr::infer(env, st3, step_);
    return (check_types::head_sigil(st4, step_ty) == Text::lit("!")) || (step_ty == check_types::Ty(check_types::Ty::TyErr{}))
        ? check_types::unify(st4, check_types::Ty(check_types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_)}), step_ty, step_.span)
        : check_types::err_fix(st4, Text::lit("mismatch"), step_.span, prism_rtl::cat("a hold's step is an event; this is `", check_types::show_ty(st4, step_ty), "`"), Text::lit("fire it with an event: `... on !e`"));
}


prism_rtl::Turn<check_types::St> HoldStmt::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& init = this->init;
    const auto& step_ = this->step_;
    const auto& span = this->span;
    auto [v_, st1] = check_types::fresh_var(st, false, Text::lit(""));
    auto held = check_types::Ty(check_types::Ty::TySig{Text::lit("$"), prism_rtl::rc(v_)});
    auto env_1 = env;
    auto init_2 = init;
    auto p__3 = p_;
    auto span_4 = span;
    auto step__5 = step_;
    return call_then(check_expr::start_bind_pattern(env_1, st1, p__3, held, false), [=](std::tuple<check_expr::Env, check_types::St> bind_pattern_11259) {
        return ({
            auto&& _st2 = bind_pattern_11259;
            auto&& st2 = std::get<1>(_st2);
            call_then(check_expr::start_check(env_1, st2, init_2, v_), [=](check_types::St check_11310) {
            return ({
                auto st3 = check_11310;
                call_then(check_expr::start_infer(env_1, st3, step__5), [=](std::tuple<check_types::Ty, check_types::St> infer_11360) {
                return ({
                    auto [step_ty, st4] = infer_11360;
                    call_then(check_types::start_head_sigil(st4, step_ty), [=](Text head_sigil_11389) {
                    return (head_sigil_11389 == Text::lit("!")) || (step_ty == check_types::Ty(check_types::Ty::TyErr{}))
                        ? prism_rtl::more(prism_rtl::rc(check_types::Unify(st4, check_types::Ty(check_types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_)}), step_ty, step__5.span)))
                        : call_then(check_types::start_show_ty(st4, step_ty), [=](Text show_ty_11567) { return prism_rtl::finished(check_types::err_fix(st4, Text::lit("mismatch"), step__5.span, prism_rtl::cat("a hold's step is an event; this is `", show_ty_11567, "`"), Text::lit("fire it with an event: `... on !e`"))); });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start HoldStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_hold_stmt(check_expr::Env env, check_types::St st, ast::Pattern_ p_, ast::Expr init, ast::Expr step_, ast::Range span) {
    return prism_rtl::make_rc<HoldStmt>(env, st, p_, init, step_, span);
}


/// IgnoreStmt: unbounded fn Env, St, Expr, Range -> St
check_types::St ignore_stmt(const check_expr::Env& env, const check_types::St& st, const ast::Expr& e, const ast::Range& span) {
    auto [t, st1] = check_expr::infer(env, st, e);
    auto&& _m = check_types::walk(st1, t);
    if (prism_rtl::is<check_types::Ty::TyAt>(_m)) {
        auto&& _st2 = bind_output(env, st1, t, e.span);
        auto&& st2 = std::get<1>(_st2);
        return st2;
    }
    if (prism_rtl::is<check_types::Ty::TyElem>(_m)) {
        auto&& _st2 = bind_output(env, st1, t, e.span);
        auto&& st2 = std::get<1>(_st2);
        return st2;
    }
    if (prism_rtl::is<check_types::Ty::TySig>(_m)) {
        auto&& inner = prism_rtl::as<check_types::Ty::TySig>(_m).a1;
        auto&& _m = check_types::walk(st1, inner);
        if (prism_rtl::is<check_types::Ty::TyAt>(_m)) {
            auto&& _st2 = bind_output(env, st1, t, e.span);
            auto&& st2 = std::get<1>(_st2);
            return st2;
        }
        if (prism_rtl::is<check_types::Ty::TyElem>(_m)) {
            auto&& _st2 = bind_output(env, st1, t, e.span);
            auto&& st2 = std::get<1>(_st2);
            return st2;
        }
        {
            return st1;
        }
    }
    {
        return st1;
    }
}


prism_rtl::Turn<check_types::St> IgnoreStmt::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    const auto& span = this->span;
    auto e_1 = e;
    auto env_2 = env;
    auto span_3 = span;
    auto st_4 = st;
    return call_then(check_expr::start_infer(env_2, st_4, e_1), [=](std::tuple<check_types::Ty, check_types::St> infer_11800) {
        return ({
            auto [t, st1] = infer_11800;
            call_then(check_types::start_walk(st1, t), [=](check_types::Ty walk_11827) {
            return ({
                prism_rtl::is<check_types::Ty::TyAt>(walk_11827) ? call_then(start_bind_output(env_2, st1, t, e_1.span), [=](std::tuple<check_types::Ty, check_types::St> bind_output_11903) {
                return ({
                    auto&& _st2 = bind_output_11903;
                    auto&& st2 = std::get<1>(_st2);
                    (prism_rtl::finished(st2));
                });
            })
                : prism_rtl::is<check_types::Ty::TyElem>(walk_11827) ? call_then(start_bind_output(env_2, st1, t, e_1.span), [=](std::tuple<check_types::Ty, check_types::St> bind_output_12015) {
                return ({
                    auto&& _st2 = bind_output_12015;
                    auto&& st2 = std::get<1>(_st2);
                    (prism_rtl::finished(st2));
                });
            })
                : prism_rtl::is<check_types::Ty::TySig>(walk_11827) ? ({
                auto&& inner = prism_rtl::as<check_types::Ty::TySig>(walk_11827).a1;
                call_then(check_types::start_walk(st1, inner), [=](check_types::Ty walk_12097) {
                return ({
                    prism_rtl::is<check_types::Ty::TyAt>(walk_12097) ? call_then(start_bind_output(env_2, st1, t, e_1.span), [=](std::tuple<check_types::Ty, check_types::St> bind_output_12185) {
                    return ({
                        auto&& _st2 = bind_output_12185;
                        auto&& st2 = std::get<1>(_st2);
                        (prism_rtl::finished(st2));
                    });
                })
                    : prism_rtl::is<check_types::Ty::TyElem>(walk_12097) ? call_then(start_bind_output(env_2, st1, t, e_1.span), [=](std::tuple<check_types::Ty, check_types::St> bind_output_12309) {
                    return ({
                        auto&& _st2 = bind_output_12309;
                        auto&& st2 = std::get<1>(_st2);
                        (prism_rtl::finished(st2));
                    });
                })
                    : prism_rtl::finished(st1);
                });
            });
            })
                : prism_rtl::finished(st1);
            });
        });
        });
    });
}


/// `Start IgnoreStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_ignore_stmt(check_expr::Env env, check_types::St st, ast::Expr e, ast::Range span) {
    return prism_rtl::make_rc<IgnoreStmt>(env, st, e, span);
}


/// BareLine: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> bare_line(const check_expr::Env& env, const check_types::St& st, const ast::Expr& e, const bool& last) {
    auto [t, st2] = bare_line_kind(env, st, e, last);
    auto shown = ({
        __label__ _done;
        prism_rtl::Slot<check_types::Ty> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
            auto&& m12768_0_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
            if (m12768_0_0 == Text::lit("@")) {
                _v.set(check_types::Ty(check_types::Ty::TyAt{prism_rtl::rc(t), env.scope}));
                goto _done;
            }
        }
        if (prism_rtl::is<ast::ExprKind::EMatch>(_m)) {
            _v.set(check_types::Ty(check_types::Ty::TyAt{prism_rtl::rc(t), env.scope}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EIf>(_m)) {
            _v.set(check_types::Ty(check_types::Ty::TyAt{prism_rtl::rc(t), env.scope}));
            goto _done;
        }
        {
            _v.set(t);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto&& _m = e.kind;
    if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
        auto&& m12960_0_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
        if (m12960_0_0 == Text::lit("@")) {
            return std::tuple{t, check_types::note_ty(st2, e.span, shown)};
        }
    }
    if (prism_rtl::is<ast::ExprKind::EMatch>(_m)) {
        return std::tuple{t, check_types::note_ty(st2, e.span, shown)};
    }
    if (prism_rtl::is<ast::ExprKind::EIf>(_m)) {
        return std::tuple{t, check_types::note_ty(st2, e.span, shown)};
    }
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        return std::tuple{t, note_as_last(st2, e.span)};
    }
    {
        return std::tuple{t, st2};
    }
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> BareLine::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    const auto& last = this->last;
    auto e_1 = e;
    auto env_2 = env;
    auto last_3 = last;
    auto st_4 = st;
    return call_then(start_bare_line_kind(env_2, st_4, e_1, last_3), [=](std::tuple<check_types::Ty, check_types::St> bare_line_kind_12722) {
        return ({
            auto [t, st2] = bare_line_kind_12722;
            auto shown = ({
                __label__ _done;
                prism_rtl::Slot<check_types::Ty> _v;
                auto&& _m = e_1.kind;
                if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
                    auto&& m12768_0_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
                    if (m12768_0_0 == Text::lit("@")) {
                        _v.set(check_types::Ty(check_types::Ty::TyAt{prism_rtl::rc(t), env_2.scope}));
                        goto _done;
                    }
                }
                if (prism_rtl::is<ast::ExprKind::EMatch>(_m)) {
                    _v.set(check_types::Ty(check_types::Ty::TyAt{prism_rtl::rc(t), env_2.scope}));
                    goto _done;
                }
                if (prism_rtl::is<ast::ExprKind::EIf>(_m)) {
                    _v.set(check_types::Ty(check_types::Ty::TyAt{prism_rtl::rc(t), env_2.scope}));
                    goto _done;
                }
                {
                    _v.set(t);
                    goto _done;
                }
            _done:
                _v.take();
            });
            ({
            auto&& _m = e_1.kind;
            prism_rtl::is<ast::ExprKind::EFreeSigil>(_m) && ({
            auto&& m12960_0_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
            (m12960_0_0 == Text::lit("@"));
        }) ? ({
            auto&& m12960_0_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
            prism_rtl::finished(std::tuple{t, check_types::note_ty(st2, e_1.span, shown)});
        })
            : prism_rtl::is<ast::ExprKind::EMatch>(_m) ? prism_rtl::finished(std::tuple{t, check_types::note_ty(st2, e_1.span, shown)})
            : prism_rtl::is<ast::ExprKind::EIf>(_m) ? prism_rtl::finished(std::tuple{t, check_types::note_ty(st2, e_1.span, shown)})
            : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? prism_rtl::finished(std::tuple{t, note_as_last(st2, e_1.span)})
            : prism_rtl::finished(std::tuple{t, st2});
        });
        });
    });
}


/// `Start BareLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_bare_line(check_expr::Env env, check_types::St st, ast::Expr e, bool last) {
    return prism_rtl::make_rc<BareLine>(env, st, e, last);
}


/// NoteAsLast: fn St, Range -> St
check_types::St note_as_last(const check_types::St& st, const ast::Range& span) {
    auto&& _m = lexer::last(st->typed.exprs);
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        return check_types::note_ty(st, span, n.ty);
    }
    if (prism_rtl::is_none(_m)) {
        return st;
    }
    prism_rtl::unreachable("no arm matched");
}


/// BareLineKind: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> bare_line_kind(const check_expr::Env& env, const check_types::St& st, const ast::Expr& e, const bool& last) {
    auto&& _m = e.kind;
    if (prism_rtl::is<ast::ExprKind::EMatch>(_m)) {
        auto&& scrut = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
        return building_match(env, st, scrut, arms, e.span, last);
    }
    if (prism_rtl::is<ast::ExprKind::EIf>(_m)) {
        auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
        return building_if(env, st, c, then_b, else_b_opt, e.span, last);
    }
    if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
        auto&& m13542_2_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
        if (m13542_2_0 == Text::lit("@")) {
            auto [t, st2] = check_expr::infer(env, st, x);
            return last ? std::tuple{t, st2} : std::tuple{t, discarded(st2, t, e.span)};
        }
    }
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        return bare_line(env, st, x, last);
    }
    {
        auto [t, st1] = check_expr::infer(env, st, e);
        auto [res, st2] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
            auto&& _m = check_types::walk(st1, t);
            if (prism_rtl::is<check_types::Ty::TyAt>(_m)) {
                _v.set(bind_output(env, st1, t, e.span));
                goto _done;
            }
            if (prism_rtl::is<check_types::Ty::TyElem>(_m)) {
                _v.set(bind_output(env, st1, t, e.span));
                goto _done;
            }
            if (prism_rtl::is<check_types::Ty::TyErr>(_m)) {
                _v.set(std::tuple{check_types::t_unit(), st1});
                goto _done;
            }
            {
                auto&& other = _m;
                _v.set(is_builder(e)
                    ? std::tuple{other, st1}
                    : check_types::walk(st1, other) == check_types::t_unit()
                    ? std::tuple{check_types::t_unit(), st1}
                    : std::tuple{other, check_types::err_fix(st1, Text::lit("mismatch"), e.span, prism_rtl::cat("a bare line emits an element or builds a blueprint; this is `", check_types::show_ty(st1, other), "`"), prism_rtl::cat("end the block on a value with `@ ", check_expr::src_text(env, e.span), "`"))});
                goto _done;
            }
        _done:
            _v.take();
        });
        return last ? std::tuple{res, st2} : std::tuple{res, discarded(st2, res, e.span)};
    }
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> BareLineKind::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    const auto& last = this->last;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EMatch>(_m) ? ({
        auto&& scrut = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
        prism_rtl::more(prism_rtl::rc(BuildingMatch(env, st, scrut, arms, e.span, last)));
    })
        : prism_rtl::is<ast::ExprKind::EIf>(_m) ? ({
        auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
        prism_rtl::more(prism_rtl::rc(BuildingIf(env, st, c, then_b, else_b_opt, e.span, last)));
    })
        : prism_rtl::is<ast::ExprKind::EFreeSigil>(_m) && ({
        auto&& m13542_2_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
        (m13542_2_0 == Text::lit("@"));
    }) ? ({
        auto&& m13542_2_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
        ({
        auto e_1 = e;
        auto env_2 = env;
        auto last_3 = last;
        auto st_4 = st;
        auto x_5 = x;
        call_then(check_expr::start_infer(env_2, st_4, x_5), [=](std::tuple<check_types::Ty, check_types::St> infer_13754) {
        return ({
            auto [t, st2] = infer_13754;
            last_3
            ? prism_rtl::finished(std::tuple{t, st2})
            : call_then(start_discarded(st2, t, e_1.span), [=](check_types::St discarded_13811) { return prism_rtl::finished(std::tuple{t, discarded_13811}); });
        });
    });
    });
    })
        : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BareLine(env, st, x, last)));
    })
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto last_3 = last;
        auto st_4 = st;
        call_then(check_expr::start_infer(env_2, st_4, e_1), [=](std::tuple<check_types::Ty, check_types::St> infer_13919) {
        return ({
            auto [t, st1] = infer_13919;
            call_then(check_types::start_walk(st1, t), [=](check_types::Ty walk_13969) {
            return ({
                auto [res, st2] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                    if (prism_rtl::is<check_types::Ty::TyAt>(walk_13969)) {
                        _v.set(bind_output(env_2, st1, t, e_1.span));
                        goto _done;
                    }
                    if (prism_rtl::is<check_types::Ty::TyElem>(walk_13969)) {
                        _v.set(bind_output(env_2, st1, t, e_1.span));
                        goto _done;
                    }
                    if (prism_rtl::is<check_types::Ty::TyErr>(walk_13969)) {
                        _v.set(std::tuple{check_types::t_unit(), st1});
                        goto _done;
                    }
                    {
                        auto&& other = walk_13969;
                        _v.set(is_builder(e_1)
                            ? std::tuple{other, st1}
                            : check_types::walk(st1, other) == check_types::t_unit()
                            ? std::tuple{check_types::t_unit(), st1}
                            : std::tuple{other, check_types::err_fix(st1, Text::lit("mismatch"), e_1.span, prism_rtl::cat("a bare line emits an element or builds a blueprint; this is `", check_types::show_ty(st1, other), "`"), prism_rtl::cat("end the block on a value with `@ ", check_expr::src_text(env_2, e_1.span), "`"))});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                last_3
                ? prism_rtl::finished(std::tuple{res, st2})
                : call_then(start_discarded(st2, res, e_1.span), [=](check_types::St discarded_14534) { return prism_rtl::finished(std::tuple{res, discarded_14534}); });
            });
        });
        });
    });
    });
    });
}


/// `Start BareLineKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_bare_line_kind(check_expr::Env env, check_types::St st, ast::Expr e, bool last) {
    return prism_rtl::make_rc<BareLineKind>(env, st, e, last);
}


/// Discarded: unbounded fn St, Ty, Range -> St
check_types::St discarded(const check_types::St& st, const check_types::Ty& t, const ast::Range& span) {
    auto&& _m = check_types::walk(st, t);
    if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
        auto&& m14698_0_0 = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
        auto&& m14698_0_1 = prism_rtl::as<check_types::Ty::TyCon>(_m).a1;
        if (m14698_0_0 == Text::lit("unit")) {
            if (m14698_0_1.size() == 0u) {
                return st;
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyErr>(_m)) {
        return st;
    }
    if (prism_rtl::is<check_types::Ty::TyFlex>(_m)) {
        return check_types::unify(st, check_types::t_unit(), t, span);
    }
    {
        auto&& other = _m;
        return check_types::err_fix(st, Text::lit("discarded"), span, prism_rtl::cat("this line's result is `", check_types::show_ty(st, other), "`; drop it with `ignore <-`"), Text::lit("write `ignore <-` in front of it, or bind it"));
    }
}


prism_rtl::Turn<check_types::St> Discarded::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& span = this->span;
    auto span_1 = span;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(check_types::start_walk(st_2, t_3), [=](check_types::Ty walk_14704) {
        return ({
            prism_rtl::is<check_types::Ty::TyCon>(walk_14704) && ({
            auto&& m14698_0_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_14704).a0;
            auto&& m14698_0_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_14704).a1;
            (m14698_0_0 == Text::lit("unit")) && (m14698_0_1.size() == 0u);
        }) ? ({
            auto&& m14698_0_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_14704).a0;
            auto&& m14698_0_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_14704).a1;
            prism_rtl::finished(st_2);
        })
            : prism_rtl::is<check_types::Ty::TyErr>(walk_14704) ? prism_rtl::finished(st_2)
            : prism_rtl::is<check_types::Ty::TyFlex>(walk_14704) ? prism_rtl::more(prism_rtl::rc(check_types::Unify(st_2, check_types::t_unit(), t_3, span_1)))
            : ({
            auto&& other = walk_14704;
            call_then(check_types::start_show_ty(st_2, other), [=](Text show_ty_14867) { return prism_rtl::finished(check_types::err_fix(st_2, Text::lit("discarded"), span_1, prism_rtl::cat("this line's result is `", show_ty_14867, "`; drop it with `ignore <-`"), Text::lit("write `ignore <-` in front of it, or bind it"))); });
        });
        });
    });
}


/// `Start Discarded, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_discarded(check_types::St st, check_types::Ty t, ast::Range span) {
    return prism_rtl::make_rc<Discarded>(st, t, span);
}


/// BuildingMatch: unbounded fn Env, St, Expr, [Arm], Range, Bool -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> building_match(const check_expr::Env& env, const check_types::St& st, const ast::Expr& scrut, const Array<ast::Arm>& arms, const ast::Range& span, const bool& last) {
    auto [st_ty, st1] = check_expr::infer(env, st, scrut);
    auto sh = check_types::head_sigil(st1, st_ty);
    auto st2 = check_expr::is_time_sigil(sh)
        ? check_types::err_fix(st1, Text::lit("building-match"), scrut.span, prism_rtl::cat("a blueprint in a match over a ", sh == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), "; use `rebuild`"), prism_rtl::cat("write `rebuild ", check_expr::src_text(env, scrut.span), ":` with `match _:` inside"))
        : st1;
    auto plain_scrut = check_expr::is_time_sigil(sh) ? check_expr::inner_of(st2, st_ty) : st_ty;
    auto [res, st3] = check_types::fresh_var(st2, false, Text::lit(""));
    auto st4 = run_to_end(fold_job(arms, st3, ({
        auto env_1 = env;
        auto plain_scrut_2 = plain_scrut;
        auto res_3 = res;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::Arm>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_4 = env_1;
            auto plain_scrut_2_4 = plain_scrut_2;
            auto res_3_4 = res_3;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto arm = p1;
                ({
                auto [env2, s1] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<check_expr::Env, check_types::St>> _v;
                    auto&& _m = arm.pattern;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p_ = prism_rtl::some_of(_m);
                        _v.set(check_expr::bind_pattern(env_1_4, s, p_, plain_scrut_2_4, true));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::tuple{env_1_4, s});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto s2 = ({
                    __label__ _done;
                    prism_rtl::Slot<check_types::St> _v;
                    auto&& _m = arm.guard;
                    if (prism_rtl::is_some(_m)) {
                        auto&& gd = prism_rtl::some_of(_m);
                        _v.set(check_expr::check_cond(env2, s1, gd));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s1);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto [bt, s3] = arm_widget_block(env2, s2, arm.body);
                (prism_rtl::more(prism_rtl::rc(check_types::Unify(s3, res_3_4, bt, arm.body.span))));
            });
            });
        }));
        });
    })));
    })));
    auto st5 = check_passes::match_coverage(env, st4, plain_scrut, arms, span);
    return last ? std::tuple{res, st5} : std::tuple{res, discarded(st5, res, span)};
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> BuildingMatch::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& scrut = this->scrut;
    const auto& arms = this->arms;
    const auto& span = this->span;
    const auto& last = this->last;
    auto arms_1 = arms;
    auto env_2 = env;
    auto last_3 = last;
    auto scrut_4 = scrut;
    auto span_5 = span;
    auto st_6 = st;
    return call_then(check_expr::start_infer(env_2, st_6, scrut_4), [=](std::tuple<check_types::Ty, check_types::St> infer_15271) {
        return ({
            auto [st_ty, st1] = infer_15271;
            call_then(check_types::start_head_sigil(st1, st_ty), [=](Text head_sigil_15305) {
            return ({
                auto sh = head_sigil_15305;
                auto st2 = check_expr::is_time_sigil(sh)
                    ? check_types::err_fix(st1, Text::lit("building-match"), scrut_4.span, prism_rtl::cat("a blueprint in a match over a ", sh == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), "; use `rebuild`"), prism_rtl::cat("write `rebuild ", check_expr::src_text(env_2, scrut_4.span), ":` with `match _:` inside"))
                    : st1;
                auto plain_scrut = check_expr::is_time_sigil(sh) ? check_expr::inner_of(st2, st_ty) : st_ty;
                auto [res, st3] = check_types::fresh_var(st2, false, Text::lit(""));
                call_value(fold_job(arms_1, st3, ({
                auto env_2_7 = env_2;
                auto plain_scrut_7 = plain_scrut;
                auto res_8 = res;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::Arm>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_2_7_9 = env_2_7;
                    auto plain_scrut_7_9 = plain_scrut_7;
                    auto res_8_9 = res_8;
                    entered(once_job([=]() {
                    return ({
                        auto s = p0;
                        auto arm = p1;
                        ({
                        auto [env2, s1] = ({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<check_expr::Env, check_types::St>> _v;
                            auto&& _m = arm.pattern;
                            if (prism_rtl::is_some(_m)) {
                                auto&& p_ = prism_rtl::some_of(_m);
                                _v.set(check_expr::bind_pattern(env_2_7_9, s, p_, plain_scrut_7_9, true));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(std::tuple{env_2_7_9, s});
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                        auto s2 = ({
                            __label__ _done;
                            prism_rtl::Slot<check_types::St> _v;
                            auto&& _m = arm.guard;
                            if (prism_rtl::is_some(_m)) {
                                auto&& gd = prism_rtl::some_of(_m);
                                _v.set(check_expr::check_cond(env2, s1, gd));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(s1);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                        auto [bt, s3] = arm_widget_block(env2, s2, arm.body);
                        (prism_rtl::more(prism_rtl::rc(check_types::Unify(s3, res_8_9, bt, arm.body.span))));
                    });
                    });
                }));
                });
            })));
            })), [=](check_types::St fold_15696) {
                return ({
                    auto st4 = fold_15696;
                    call_then(check_passes::start_match_coverage(env_2, st4, plain_scrut, arms_1, span_5), [=](check_types::St match_coverage_16064) {
                    return ({
                        auto st5 = match_coverage_16064;
                        last_3
                        ? prism_rtl::finished(std::tuple{res, st5})
                        : call_then(start_discarded(st5, res, span_5), [=](check_types::St discarded_16151) { return prism_rtl::finished(std::tuple{res, discarded_16151}); });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start BuildingMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_building_match(check_expr::Env env, check_types::St st, ast::Expr scrut, Array<ast::Arm> arms, ast::Range span, bool last) {
    return prism_rtl::make_rc<BuildingMatch>(env, st, scrut, arms, span, last);
}


/// BuildingIf: unbounded fn Env, St, Cond, Block, ?Block, Range, Bool -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> building_if(const check_expr::Env& env, const check_types::St& st, const ast::Cond& c, const ast::Block& then_b, const std::optional<ast::Block>& else_b_opt, const ast::Range& span, const bool& last) {
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_expr::Env, check_types::St>> _v;
        if (prism_rtl::is<ast::Cond::CondExpr>(c)) {
            auto&& e = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
            _v.set(({
                auto [ct, s1] = check_expr::infer(env, st, e);
                auto sh = check_types::head_sigil(s1, ct);
                auto s2 = check_expr::is_time_sigil(sh)
                    ? check_types::err_fix(s1, Text::lit("building-match"), e.span, Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), Text::lit("write `rebuild` over the condition, with `if _:` inside"))
                    : s1;
                std::tuple{env, check_types::unify(s2, check_types::t_bool(), check_expr::is_time_sigil(sh) ? check_expr::inner_of(s2, ct) : ct, e.span)};
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c).a0;
            auto&& e = prism_rtl::as<ast::Cond::CondBind>(c).a1;
            auto&& gd_opt = prism_rtl::as<ast::Cond::CondBind>(c).a2;
            _v.set(({
                auto [et, s1] = check_expr::infer(env, st, e);
                auto [en, s2] = check_expr::bind_pattern(env, s1, p_, et, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_expr::Env, check_types::St>> _v;
                auto&& _m = gd_opt;
                if (prism_rtl::is_some(_m)) {
                    auto&& g = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en, check_expr::check_cond(en, s2, g)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en, s2});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [t1, st2] = arm_widget_block(env2, st1, then_b);
    if (prism_rtl::is_some(else_b_opt)) {
        auto&& b = prism_rtl::some_of(else_b_opt);
        auto [t2, st3] = arm_widget_block(env, st2, b);
        auto st4 = check_types::unify(st3, t1, t2, b.span);
        return last ? std::tuple{t1, st4} : std::tuple{t1, discarded(st4, t1, span)};
    }
    if (prism_rtl::is_none(else_b_opt)) {
        auto st3 = check_types::unify(st2, check_types::t_unit(), t1, then_b.span);
        return std::tuple{check_types::t_unit(), st3};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> BuildingIf::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& then_b = this->then_b;
    const auto& else_b_opt = this->else_b_opt;
    const auto& span = this->span;
    const auto& last = this->last;
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_expr::Env, check_types::St>> _v;
        if (prism_rtl::is<ast::Cond::CondExpr>(c)) {
            auto&& e = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
            _v.set(({
                auto [ct, s1] = check_expr::infer(env, st, e);
                auto sh = check_types::head_sigil(s1, ct);
                auto s2 = check_expr::is_time_sigil(sh)
                    ? check_types::err_fix(s1, Text::lit("building-match"), e.span, Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), Text::lit("write `rebuild` over the condition, with `if _:` inside"))
                    : s1;
                std::tuple{env, check_types::unify(s2, check_types::t_bool(), check_expr::is_time_sigil(sh) ? check_expr::inner_of(s2, ct) : ct, e.span)};
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c).a0;
            auto&& e = prism_rtl::as<ast::Cond::CondBind>(c).a1;
            auto&& gd_opt = prism_rtl::as<ast::Cond::CondBind>(c).a2;
            _v.set(({
                auto [et, s1] = check_expr::infer(env, st, e);
                auto [en, s2] = check_expr::bind_pattern(env, s1, p_, et, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_expr::Env, check_types::St>> _v;
                auto&& _m = gd_opt;
                if (prism_rtl::is_some(_m)) {
                    auto&& g = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en, check_expr::check_cond(en, s2, g)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en, s2});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [t1, st2] = arm_widget_block(env2, st1, then_b);
    return ({
        prism_rtl::is_some(else_b_opt) ? ({
        auto&& b = prism_rtl::some_of(else_b_opt);
        ({
        auto [t2, st3] = arm_widget_block(env, st2, b);
        auto b_1 = b;
        auto last_2 = last;
        auto span_3 = span;
        call_then(check_types::start_unify(st3, t1, t2, b_1.span), [=](check_types::St unify_17150) {
        return ({
            auto st4 = unify_17150;
            last_2
            ? prism_rtl::finished(std::tuple{t1, st4})
            : call_then(start_discarded(st4, t1, span_3), [=](check_types::St discarded_17222) { return prism_rtl::finished(std::tuple{t1, discarded_17222}); });
        });
    });
    });
    })
        : prism_rtl::is_none(else_b_opt) ? ({
        auto span_1 = span;
        auto then_b_2 = then_b;
        call_then(check_types::start_unify(st2, check_types::t_unit(), t1, then_b_2.span), [=](check_types::St unify_17284) {
        return ({
            auto st3 = unify_17284;
            (prism_rtl::finished(std::tuple{check_types::t_unit(), st3}));
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BuildingIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_building_if(check_expr::Env env, check_types::St st, ast::Cond c, ast::Block then_b, std::optional<ast::Block> else_b_opt, ast::Range span, bool last) {
    return prism_rtl::make_rc<BuildingIf>(env, st, c, then_b, else_b_opt, span, last);
}


/// ArmWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> arm_widget_block(const check_expr::Env& env, const check_types::St& st, const ast::Block& b) {
    return infer_widget_block(env, st, b);
}


/// InferRebuild: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_rebuild(const check_expr::Env& env, const check_types::St& st, const ast::Expr& scrut, const ast::Block& body, const ast::Range& span) {
    auto [t, st1] = check_expr::infer(env, st, scrut);
    auto [inner, st2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        auto&& _m = check_types::walk(st1, t);
        if (prism_rtl::is<check_types::Ty::TySig>(_m)) {
            auto&& m18151_0_0 = prism_rtl::as<check_types::Ty::TySig>(_m).a0;
            auto&& i = prism_rtl::as<check_types::Ty::TySig>(_m).a1;
            if (m18151_0_0 == Text::lit("$")) {
                _v.set(std::tuple{i, st1});
                goto _done;
            }
        }
        if (prism_rtl::is<check_types::Ty::TyErr>(_m)) {
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), st1});
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyFlex>(_m)) {
            _v.set(({
                auto [v_, s2] = check_types::fresh_var(st1, false, Text::lit(""));
                std::tuple{v_, check_types::unify(s2, check_types::Ty(check_types::Ty::TySig{Text::lit("$"), prism_rtl::rc(v_)}), t, scrut.span)};
            }));
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err_fix(st1, Text::lit("mismatch"), scrut.span, prism_rtl::cat("`rebuild` builds over a dynamic; this is `", check_types::show_ty(st1, other), "`"), Text::lit("a plain value is built once: write the block's lines in place"))});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto env2 = with_topic(env, Text::lit("_"), inner);
    auto [res, st3] = infer_widget_block(env2, st2, body);
    auto&& _m = check_types::walk(st3, res);
    if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
        auto&& m18664_0_0 = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
        auto&& m18664_0_1 = prism_rtl::as<check_types::Ty::TyCon>(_m).a1;
        if (m18664_0_0 == Text::lit("unit")) {
            if (m18664_0_1.size() == 0u) {
                return std::tuple{check_types::t_unit(), st3};
            }
        }
    }
    {
        auto&& other = _m;
        return std::tuple{check_types::Ty(check_types::Ty::TySig{Text::lit("$"), prism_rtl::rc(other)}), st3};
    }
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferRebuild::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& scrut = this->scrut;
    const auto& body = this->body;
    const auto& span = this->span;
    auto body_1 = body;
    auto env_2 = env;
    auto scrut_3 = scrut;
    auto span_4 = span;
    auto st_5 = st;
    return call_then(check_expr::start_infer(env_2, st_5, scrut_3), [=](std::tuple<check_types::Ty, check_types::St> infer_18105) {
        return ({
            auto [t, st1] = infer_18105;
            call_then(check_types::start_walk(st1, t), [=](check_types::Ty walk_18157) {
            return ({
                auto [inner, st2] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                    if (prism_rtl::is<check_types::Ty::TySig>(walk_18157)) {
                        auto&& m18151_0_0 = prism_rtl::as<check_types::Ty::TySig>(walk_18157).a0;
                        auto&& i = prism_rtl::as<check_types::Ty::TySig>(walk_18157).a1;
                        if (m18151_0_0 == Text::lit("$")) {
                            _v.set(std::tuple{i, st1});
                            goto _done;
                        }
                    }
                    if (prism_rtl::is<check_types::Ty::TyErr>(walk_18157)) {
                        _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), st1});
                        goto _done;
                    }
                    if (prism_rtl::is<check_types::Ty::TyFlex>(walk_18157)) {
                        _v.set(({
                            auto [v_, s2] = check_types::fresh_var(st1, false, Text::lit(""));
                            std::tuple{v_, check_types::unify(s2, check_types::Ty(check_types::Ty::TySig{Text::lit("$"), prism_rtl::rc(v_)}), t, scrut_3.span)};
                        }));
                        goto _done;
                    }
                    {
                        auto&& other = walk_18157;
                        _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err_fix(st1, Text::lit("mismatch"), scrut_3.span, prism_rtl::cat("`rebuild` builds over a dynamic; this is `", check_types::show_ty(st1, other), "`"), Text::lit("a plain value is built once: write the block's lines in place"))});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto env2 = with_topic(env_2, Text::lit("_"), inner);
                call_then(start_infer_widget_block(env2, st2, body_1), [=](std::tuple<check_types::Ty, check_types::St> infer_widget_block_18627) {
                return ({
                    auto [res, st3] = infer_widget_block_18627;
                    call_then(check_types::start_walk(st3, res), [=](check_types::Ty walk_18670) {
                    return ({
                        prism_rtl::is<check_types::Ty::TyCon>(walk_18670) && ({
                        auto&& m18664_0_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_18670).a0;
                        auto&& m18664_0_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_18670).a1;
                        (m18664_0_0 == Text::lit("unit")) && (m18664_0_1.size() == 0u);
                    }) ? ({
                        auto&& m18664_0_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_18670).a0;
                        auto&& m18664_0_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_18670).a1;
                        prism_rtl::finished(std::tuple{check_types::t_unit(), st3});
                    })
                        : ({
                        auto&& other = walk_18670;
                        prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TySig{Text::lit("$"), prism_rtl::rc(other)}), st3});
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start InferRebuild, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_rebuild(check_expr::Env env, check_types::St st, ast::Expr scrut, ast::Block body, ast::Range span) {
    return prism_rtl::make_rc<InferRebuild>(env, st, scrut, body, span);
}


/// WithTopic: fn Env, Text, Ty -> Env
check_expr::Env with_topic(const check_expr::Env& env, const Text& name, const check_types::Ty& t) {
    check_expr::Env this_ = check_expr::with_local(env, name, check_types::mono(t));
    this_.pending = filter(this_.pending, [&](const Text& x) { return x != name; });
    return this_;
}


/// InferFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_for(const check_expr::Env& env, const check_types::St& st, const std::optional<ast::ForBinders>& binders_opt, const ast::Expr& source, const ast::Block& body, const ast::Range& span) {
    return env.in_update
        ? std::tuple{check_types::t_unit(), update_for(env, st, binders_opt, source, body, span)}
        : ({
        auto [t, st1] = check_expr::infer(env, st, source);
        auto sh = check_types::head_sigil(st1, t);
        auto coll = sh == Text::lit("$") ? check_expr::inner_of(st1, t) : t;
        auto st2 = (sh == Text::lit("!")) || (sh == Text::lit("@"))
            ? check_types::err(st1, Text::lit("mismatch"), source.span, prism_rtl::cat("`for` runs over a map or an array, plain or dynamic; this is `", check_types::show_ty(st1, t), "`"))
            : st1;
        auto [k, v_, st3] = coll_parts(st2, coll, source.span);
        auto live = sh == Text::lit("$");
        auto env1 = loop_indices(env);
        auto [env2, st4] = bind_for_binders(env1, st3, binders_opt, k, v_, live);
        auto [res, st5] = infer_widget_block(env2, st4, body);
        gather(st5, res, k, live);
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferFor::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& binders_opt = this->binders_opt;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& span = this->span;
    return env.in_update
        ? ({
        auto binders_opt_1 = binders_opt;
        auto body_2 = body;
        auto env_3 = env;
        auto source_4 = source;
        auto span_5 = span;
        auto st_6 = st;
        call_then(start_update_for(env_3, st_6, binders_opt_1, source_4, body_2, span_5), [=](check_types::St update_for_19255) { return prism_rtl::finished(std::tuple{check_types::t_unit(), update_for_19255}); });
    })
        : ({
        auto binders_opt_1 = binders_opt;
        auto body_2 = body;
        auto env_3 = env;
        auto source_4 = source;
        auto span_5 = span;
        auto st_6 = st;
        call_then(check_expr::start_infer(env_3, st_6, source_4), [=](std::tuple<check_types::Ty, check_types::St> infer_19341) {
        return ({
            auto [t, st1] = infer_19341;
            call_then(check_types::start_head_sigil(st1, t), [=](Text head_sigil_19380) {
            return ({
                auto sh = head_sigil_19380;
                auto coll = sh == Text::lit("$") ? check_expr::inner_of(st1, t) : t;
                auto st2 = (sh == Text::lit("!")) || (sh == Text::lit("@"))
                    ? check_types::err(st1, Text::lit("mismatch"), source_4.span, prism_rtl::cat("`for` runs over a map or an array, plain or dynamic; this is `", check_types::show_ty(st1, t), "`"))
                    : st1;
                call_then(start_coll_parts(st2, coll, source_4.span), [=](std::tuple<check_types::Ty, check_types::Ty, check_types::St> coll_parts_19651) {
                return ({
                    auto [k, v_, st3] = coll_parts_19651;
                    auto live = sh == Text::lit("$");
                    auto env1 = loop_indices(env_3);
                    call_then(start_bind_for_binders(env1, st3, binders_opt_1, k, v_, live), [=](std::tuple<check_expr::Env, check_types::St> bind_for_binders_19776) {
                    return ({
                        auto [env2, st4] = bind_for_binders_19776;
                        call_then(start_infer_widget_block(env2, st4, body_2), [=](std::tuple<check_types::Ty, check_types::St> infer_widget_block_19850) {
                        return ({
                            auto [res, st5] = infer_widget_block_19850;
                            (prism_rtl::more(prism_rtl::rc(Gather(st5, res, k, live))));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
    });
}


/// `Start InferFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_for(check_expr::Env env, check_types::St st, std::optional<ast::ForBinders> binders_opt, ast::Expr source, ast::Block body, ast::Range span) {
    return prism_rtl::make_rc<InferFor>(env, st, binders_opt, source, body, span);
}


/// CollParts: unbounded fn St, Ty, Range -> ((Ty, Ty, St))
std::tuple<check_types::Ty, check_types::Ty, check_types::St> coll_parts(const check_types::St& st, const check_types::Ty& t, const ast::Range& span) {
    auto&& _m = check_types::walk(st, t);
    if (prism_rtl::is<check_types::Ty::TyMap>(_m)) {
        auto&& k = prism_rtl::as<check_types::Ty::TyMap>(_m).a0;
        auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(_m).a1;
        return std::tuple{k, v_, st};
    }
    if (prism_rtl::is<check_types::Ty::TyArray>(_m)) {
        auto&& v_ = prism_rtl::as<check_types::Ty::TyArray>(_m).a0;
        return std::tuple{check_types::t_nat(), v_, st};
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
        auto&& m20043_2_0 = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
        auto&& m20043_2_1 = prism_rtl::as<check_types::Ty::TyCon>(_m).a1;
        if (m20043_2_0 == Text::lit("Buffer")) {
            if (m20043_2_1.size() == 1u) {
                {
                    auto&& _c1 = index(m20043_2_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& v_ = prism_rtl::some_of(_c1);
                        return std::tuple{check_types::t_nat(), v_, st};
                    }
                }
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyErr>(_m)) {
        return std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::Ty(check_types::Ty::TyErr{}), st};
    }
    if (prism_rtl::is<check_types::Ty::TyFlex>(_m)) {
        auto [v_, st2] = check_types::fresh_var(st, false, Text::lit(""));
        return std::tuple{check_types::t_nat(), v_, check_types::unify(st2, check_types::Ty(check_types::Ty::TyArray{prism_rtl::rc(v_)}), t, span)};
    }
    {
        auto&& other = _m;
        return std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`for` runs over a map or an array; this is `", check_types::show_ty(st, other), "`"))};
    }
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::Ty, check_types::St>> CollParts::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& span = this->span;
    auto span_1 = span;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(check_types::start_walk(st_2, t_3), [=](check_types::Ty walk_20049) {
        return ({
            prism_rtl::is<check_types::Ty::TyMap>(walk_20049) ? ({
            auto&& k = prism_rtl::as<check_types::Ty::TyMap>(walk_20049).a0;
            auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(walk_20049).a1;
            prism_rtl::finished(std::tuple{k, v_, st_2});
        })
            : prism_rtl::is<check_types::Ty::TyArray>(walk_20049) ? ({
            auto&& v_ = prism_rtl::as<check_types::Ty::TyArray>(walk_20049).a0;
            prism_rtl::finished(std::tuple{check_types::t_nat(), v_, st_2});
        })
            : prism_rtl::is<check_types::Ty::TyCon>(walk_20049) && ({
            auto&& m20043_2_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_20049).a0;
            auto&& m20043_2_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_20049).a1;
            (m20043_2_0 == Text::lit("Buffer")) && (m20043_2_1.size() == 1u) && ({
            auto&& _c1 = index(m20043_2_1, Nat(0u));
            prism_rtl::is_some(_c1);
        });
        }) ? ({
            auto&& m20043_2_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_20049).a0;
            auto&& m20043_2_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_20049).a1;
            auto&& _c1 = index(m20043_2_1, Nat(0u));
            auto&& v_ = prism_rtl::some_of(_c1);
            prism_rtl::finished(std::tuple{check_types::t_nat(), v_, st_2});
        })
            : prism_rtl::is<check_types::Ty::TyErr>(walk_20049) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::Ty(check_types::Ty::TyErr{}), st_2})
            : prism_rtl::is<check_types::Ty::TyFlex>(walk_20049) ? ({
            auto [v_, st2] = check_types::fresh_var(st_2, false, Text::lit(""));
            call_then(check_types::start_unify(st2, check_types::Ty(check_types::Ty::TyArray{prism_rtl::rc(v_)}), t_3, span_1), [=](check_types::St unify_20283) { return prism_rtl::finished(std::tuple{check_types::t_nat(), v_, unify_20283}); });
        })
            : ({
            auto&& other = walk_20049;
            ({
            auto other_4 = other;
            call_then(check_types::start_show_ty(st_2, other_4), [=](Text show_ty_20418) { return prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st_2, Text::lit("mismatch"), span_1, prism_rtl::cat("`for` runs over a map or an array; this is `", show_ty_20418, "`"))}); });
        });
        });
        });
    });
}


/// `Start CollParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::Ty, check_types::St>> start_coll_parts(check_types::St st, check_types::Ty t, ast::Range span) {
    return prism_rtl::make_rc<CollParts>(st, t, span);
}


/// LoopIndices: fn Env -> Env
check_expr::Env loop_indices(const check_expr::Env& env) {
    auto outer1_opt = prelude::get(env.locals, Text::lit("ix"));
    auto outer2_opt = prelude::get(env.locals, Text::lit("jx"));
    auto e1 = check_expr::with_local(env, Text::lit("ix"), check_types::mono(check_types::t_nat()));
    auto e2 = ({
        __label__ _done;
        prism_rtl::Slot<check_expr::Env> _v;
        if (prism_rtl::is_some(outer1_opt)) {
            auto&& sc = prism_rtl::some_of(outer1_opt);
            _v.set(check_expr::with_local(e1, Text::lit("jx"), sc));
            goto _done;
        }
        if (prism_rtl::is_none(outer1_opt)) {
            _v.set(e1);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is_some(outer2_opt)) {
        auto&& sc = prism_rtl::some_of(outer2_opt);
        return check_expr::with_local(e2, Text::lit("kx"), sc);
    }
    if (prism_rtl::is_none(outer2_opt)) {
        return e2;
    }
    prism_rtl::unreachable("no arm matched");
}


/// BindForBinders: unbounded fn Env, St, ?ForBinders, Ty, Ty, Bool -> ((Env, St))
std::tuple<check_expr::Env, check_types::St> bind_for_binders(const check_expr::Env& env, const check_types::St& st, const std::optional<ast::ForBinders>& binders_opt, const check_types::Ty& k, const check_types::Ty& v_, const bool& live) {
    auto vt = live
        ? check_types::Ty(check_types::Ty::TySig{Text::lit("$"), prism_rtl::rc(v_)})
        : v_;
    if (prism_rtl::is_none(binders_opt)) {
        auto e1 = with_topic(env, live ? Text::lit("$_") : Text::lit("_"), vt);
        return std::tuple{with_topic(e1, Text::lit("key"), k), st};
    }
    if (prism_rtl::is_some(binders_opt)) {
        auto&& bs = prism_rtl::some_of(binders_opt);
        auto&& _m = bs.second;
        if (prism_rtl::is_some(_m)) {
            auto&& second = prism_rtl::some_of(_m);
            auto [e1, st1] = check_expr::bind_pattern(unpending(env), st, bs.first, k, false);
            return check_expr::bind_pattern(e1, st1, second, vt, false);
        }
        if (prism_rtl::is_none(_m)) {
            auto e1 = with_topic(env, Text::lit("key"), k);
            return check_expr::bind_pattern(unpending(e1), st, bs.first, vt, false);
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<check_expr::Env, check_types::St>> BindForBinders::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& binders_opt = this->binders_opt;
    const auto& k = this->k;
    const auto& v_ = this->v_;
    const auto& live = this->live;
    auto vt = live
        ? check_types::Ty(check_types::Ty::TySig{Text::lit("$"), prism_rtl::rc(v_)})
        : v_;
    return ({
        prism_rtl::is_none(binders_opt) ? ({
        auto e1 = with_topic(env, live ? Text::lit("$_") : Text::lit("_"), vt);
        (prism_rtl::finished(std::tuple{with_topic(e1, Text::lit("key"), k), st}));
    })
        : prism_rtl::is_some(binders_opt) ? ({
        auto&& bs = prism_rtl::some_of(binders_opt);
        ({
        auto&& _m = bs.second;
        prism_rtl::is_some(_m) ? ({
        auto&& second = prism_rtl::some_of(_m);
        ({
        auto bs_1 = bs;
        auto env_2 = env;
        auto k_3 = k;
        auto second_4 = second;
        auto st_5 = st;
        call_then(check_expr::start_bind_pattern(unpending(env_2), st_5, bs_1.first, k_3, false), [=](std::tuple<check_expr::Env, check_types::St> bind_pattern_21414) {
        return ({
            auto [e1, st1] = bind_pattern_21414;
            (prism_rtl::more(prism_rtl::rc(check_expr::BindPattern(e1, st1, second_4, vt, false))));
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto e1 = with_topic(env, Text::lit("key"), k);
        (prism_rtl::more(prism_rtl::rc(check_expr::BindPattern(unpending(e1), st, bs.first, vt, false))));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindForBinders, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St>> start_bind_for_binders(check_expr::Env env, check_types::St st, std::optional<ast::ForBinders> binders_opt, check_types::Ty k, check_types::Ty v_, bool live) {
    return prism_rtl::make_rc<BindForBinders>(env, st, binders_opt, k, v_, live);
}


/// Unpending: fn Env -> Env
check_expr::Env unpending(const check_expr::Env& env) {
    check_expr::Env this_ = env;
    this_.pending = Array<Text>{};
    return this_;
}


/// Gather: unbounded fn St, Ty, Ty, Bool -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> gather(const check_types::St& st, const check_types::Ty& res, const check_types::Ty& k, const bool& live) {
    auto&& _m = check_types::walk(st, res);
    if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
        auto&& m22080_0_0 = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
        auto&& m22080_0_1 = prism_rtl::as<check_types::Ty::TyCon>(_m).a1;
        if (m22080_0_0 == Text::lit("unit")) {
            if (m22080_0_1.size() == 0u) {
                return std::tuple{check_types::t_unit(), st};
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TySig>(_m)) {
        auto&& m22080_1_0 = prism_rtl::as<check_types::Ty::TySig>(_m).a0;
        auto&& t = prism_rtl::as<check_types::Ty::TySig>(_m).a1;
        if (m22080_1_0 == Text::lit("!")) {
            return std::tuple{check_types::Ty(check_types::Ty::TySig{Text::lit("!"), prism_rtl::rc(check_types::Ty(check_types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(t)}))}), st};
        }
    }
    if (prism_rtl::is<check_types::Ty::TySig>(_m)) {
        auto&& m22080_2_0 = prism_rtl::as<check_types::Ty::TySig>(_m).a0;
        auto&& t = prism_rtl::as<check_types::Ty::TySig>(_m).a1;
        if (m22080_2_0 == Text::lit("$")) {
            return std::tuple{check_types::Ty(check_types::Ty::TySig{Text::lit("$"), prism_rtl::rc(check_types::Ty(check_types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(t)}))}), st};
        }
    }
    if (prism_rtl::is<check_types::Ty::TyTuple>(_m)) {
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(_m).a0;
        return run_to_end(fold_job(ts, false, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto x = p1;
                    (prism_rtl::finished(seen || check_expr::is_time_sigil(check_types::head_sigil(st_1_2, x))));
                });
            }));
            });
        })));
        })))
            ? ({
            auto [parts, st2] = run_to_end(fold_job(ts, std::tuple{Array<check_types::Ty>{}, st}, ({
                auto k_1 = k;
                auto live_2 = live;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<check_types::Ty>, check_types::St>>(std::tuple<std::tuple<Array<check_types::Ty>, check_types::St>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<check_types::Ty>, check_types::St>, check_types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto k_1_3 = k_1;
                    auto live_2_3 = live_2;
                    entered(once_job([=]() {
                    return ({
                        auto [acc, s] = p0;
                        auto x = p1;
                        call_then(start_gather(s, x, k_1_3, live_2_3), [=](std::tuple<check_types::Ty, check_types::St> gather_22440) {
                        return ({
                            auto [g, s2] = gather_22440;
                            (prism_rtl::finished(std::tuple{prelude::push(acc, g), s2}));
                        });
                    });
                    });
                }));
                });
            }));
            })));
            std::tuple{check_types::Ty(check_types::Ty::TyTuple{parts}), st2};
        })
            : std::tuple{live_map(live, k, check_types::Ty(check_types::Ty::TyTuple{ts})), st};
    }
    {
        auto&& other = _m;
        return std::tuple{live_map(live, k, other), st};
    }
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> Gather::cycle() const {
    const auto& st = this->st;
    const auto& res = this->res;
    const auto& k = this->k;
    const auto& live = this->live;
    auto k_1 = k;
    auto live_2 = live;
    auto res_3 = res;
    auto st_4 = st;
    return call_then(check_types::start_walk(st_4, res_3), [=](check_types::Ty walk_22086) {
        return ({
            prism_rtl::is<check_types::Ty::TyCon>(walk_22086) && ({
            auto&& m22080_0_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_22086).a0;
            auto&& m22080_0_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_22086).a1;
            (m22080_0_0 == Text::lit("unit")) && (m22080_0_1.size() == 0u);
        }) ? ({
            auto&& m22080_0_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_22086).a0;
            auto&& m22080_0_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_22086).a1;
            prism_rtl::finished(std::tuple{check_types::t_unit(), st_4});
        })
            : prism_rtl::is<check_types::Ty::TySig>(walk_22086) && ({
            auto&& m22080_1_0 = prism_rtl::as<check_types::Ty::TySig>(walk_22086).a0;
            auto&& t = prism_rtl::as<check_types::Ty::TySig>(walk_22086).a1;
            (m22080_1_0 == Text::lit("!"));
        }) ? ({
            auto&& m22080_1_0 = prism_rtl::as<check_types::Ty::TySig>(walk_22086).a0;
            auto&& t = prism_rtl::as<check_types::Ty::TySig>(walk_22086).a1;
            prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TySig{Text::lit("!"), prism_rtl::rc(check_types::Ty(check_types::Ty::TyMap{prism_rtl::rc(k_1), prism_rtl::rc(t)}))}), st_4});
        })
            : prism_rtl::is<check_types::Ty::TySig>(walk_22086) && ({
            auto&& m22080_2_0 = prism_rtl::as<check_types::Ty::TySig>(walk_22086).a0;
            auto&& t = prism_rtl::as<check_types::Ty::TySig>(walk_22086).a1;
            (m22080_2_0 == Text::lit("$"));
        }) ? ({
            auto&& m22080_2_0 = prism_rtl::as<check_types::Ty::TySig>(walk_22086).a0;
            auto&& t = prism_rtl::as<check_types::Ty::TySig>(walk_22086).a1;
            prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TySig{Text::lit("$"), prism_rtl::rc(check_types::Ty(check_types::Ty::TyMap{prism_rtl::rc(k_1), prism_rtl::rc(t)}))}), st_4});
        })
            : prism_rtl::is<check_types::Ty::TyTuple>(walk_22086) ? ({
            auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(walk_22086).a0;
            call_value(fold_job(ts, false, ({
            auto st_4_5 = st_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_4_5_5 = st_4_5;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto x = p1;
                    (prism_rtl::finished(seen || check_expr::is_time_sigil(check_types::head_sigil(st_4_5_5, x))));
                });
            }));
            });
        })));
        })), [=](bool fold_22269) {
            return fold_22269
                ? call_value(fold_job(ts, std::tuple{Array<check_types::Ty>{}, st_4}, ({
                auto k_1_5 = k_1;
                auto live_2_5 = live_2;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<check_types::Ty>, check_types::St>>(std::tuple<std::tuple<Array<check_types::Ty>, check_types::St>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<check_types::Ty>, check_types::St>, check_types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto k_1_5_5 = k_1_5;
                    auto live_2_5_5 = live_2_5;
                    entered(once_job([=]() {
                    return ({
                        auto [acc, s] = p0;
                        auto x = p1;
                        call_then(start_gather(s, x, k_1_5_5, live_2_5_5), [=](std::tuple<check_types::Ty, check_types::St> gather_22440) {
                        return ({
                            auto [g, s2] = gather_22440;
                            (prism_rtl::finished(std::tuple{prelude::push(acc, g), s2}));
                        });
                    });
                    });
                }));
                });
            }));
            })), [=](std::tuple<Array<check_types::Ty>, check_types::St> fold_22368) {
                return ({
                    auto [parts, st2] = fold_22368;
                    (prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyTuple{parts}), st2}));
                });
            })
                : prism_rtl::finished(std::tuple{live_map(live_2, k_1, check_types::Ty(check_types::Ty::TyTuple{ts})), st_4});
        });
        })
            : ({
            auto&& other = walk_22086;
            prism_rtl::finished(std::tuple{live_map(live_2, k_1, other), st_4});
        });
        });
    });
}


/// `Start Gather, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_gather(check_types::St st, check_types::Ty res, check_types::Ty k, bool live) {
    return prism_rtl::make_rc<Gather>(st, res, k, live);
}


/// LiveMap: fn Bool, Ty, Ty -> Ty
check_types::Ty live_map(const bool& live, const check_types::Ty& k, const check_types::Ty& v_) {
    return live
        ? check_types::Ty(check_types::Ty::TySig{Text::lit("$"), prism_rtl::rc(check_types::Ty(check_types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)}))})
        : check_types::Ty(check_types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)});
}


/// InferGiven: unbounded fn Env, St, Block, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_given(const check_expr::Env& env, const check_types::St& st, const ast::Block& b, const ast::Range& span) {
    auto mark = (env.mark == Text::lit("?")) || (env.mark == Text::lit("~"))
        ? env.mark
        : given_mark_of(b.stmts);
    return infer_given_block(env, st, b, mark);
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferGiven::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& b = this->b;
    const auto& span = this->span;
    auto mark = (env.mark == Text::lit("?")) || (env.mark == Text::lit("~"))
        ? env.mark
        : given_mark_of(b.stmts);
    return prism_rtl::more(prism_rtl::rc(InferGivenBlock(env, st, b, mark)));
}


/// `Start InferGiven, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_given(check_expr::Env env, check_types::St st, ast::Block b, ast::Range span) {
    return prism_rtl::make_rc<InferGiven>(env, st, b, span);
}


/// GivenMarkOf: fn [Stmt] -> Text
Text given_mark_of(const Array<ast::Stmt>& stmts) {
    return fold(stmts, Text::lit("?"), [&](const Text& m, const ast::Stmt& s) { return m; });
}


/// InferGivenBlock: unbounded fn Env, St, Block, Text -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_given_block(const check_expr::Env& env, const check_types::St& st, const ast::Block& b, const Text& mark) {
    auto n = len(b.stmts);
    auto [env2, st2, res_opt] = run_to_end(fold_job(check_errors::range0(n), std::tuple{env, st, std::optional<check_types::Ty>{}}, ({
        auto b_1 = b;
        auto mark_2 = mark;
        auto n_3 = n;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>>(std::tuple<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_4 = b_1;
            auto mark_2_4 = mark_2;
            auto n_3_4 = n_3;
            entered(once_job([=]() {
            return ({
                auto [en, s, r_opt] = p0;
                auto i = p1;
                ({
                auto stmt = or_(index(b_1_4.stmts, i), dummy_stmt2());
                (prism_rtl::more(prism_rtl::rc(GivenStmt(en, s, stmt, mark_2_4, (i + Nat(1u)) == n_3_4, r_opt))));
            });
            });
        }));
        });
    }));
    })));
    if (prism_rtl::is_some(res_opt)) {
        auto&& t = prism_rtl::some_of(res_opt);
        return std::tuple{t, st2};
    }
    if (prism_rtl::is_none(res_opt)) {
        auto [v_, st3] = check_types::fresh_var(st2, false, Text::lit(""));
        return std::tuple{check_types::Ty(check_types::Ty::TySig{mark, prism_rtl::rc(v_)}), st3};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferGivenBlock::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& b = this->b;
    const auto& mark = this->mark;
    auto n = len(b.stmts);
    auto b_1 = b;
    auto env_2 = env;
    auto mark_3 = mark;
    auto st_4 = st;
    return call_value(fold_job(check_errors::range0(n), std::tuple{env_2, st_4, std::optional<check_types::Ty>{}}, ({
        auto b_1_5 = b_1;
        auto mark_3_5 = mark_3;
        auto n_5 = n;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>>(std::tuple<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_5_6 = b_1_5;
            auto mark_3_5_6 = mark_3_5;
            auto n_5_6 = n_5;
            entered(once_job([=]() {
            return ({
                auto [en, s, r_opt] = p0;
                auto i = p1;
                ({
                auto stmt = or_(index(b_1_5_6.stmts, i), dummy_stmt2());
                (prism_rtl::more(prism_rtl::rc(GivenStmt(en, s, stmt, mark_3_5_6, (i + Nat(1u)) == n_5_6, r_opt))));
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>> fold_23637) {
        return ({
            auto [env2, st2, res_opt] = fold_23637;
            ({
            prism_rtl::is_some(res_opt) ? ({
            auto&& t = prism_rtl::some_of(res_opt);
            prism_rtl::finished(std::tuple{t, st2});
        })
            : prism_rtl::is_none(res_opt) ? ({
            auto [v_, st3] = check_types::fresh_var(st2, false, Text::lit(""));
            (prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TySig{mark_3, prism_rtl::rc(v_)}), st3}));
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start InferGivenBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_given_block(check_expr::Env env, check_types::St st, ast::Block b, Text mark) {
    return prism_rtl::make_rc<InferGivenBlock>(env, st, b, mark);
}


/// GivenStmt: unbounded fn Env, St, Stmt, Text, Bool, ?Ty -> ((Env, St, ?Ty))
std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>> given_stmt(const check_expr::Env& env, const check_types::St& st, const ast::Stmt& s, const Text& mark, const bool& last, const std::optional<check_types::Ty>& res_opt) {
    auto&& _m = s.kind;
    if (prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<ast::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
        auto [t, st1] = check_expr::infer(env, st, e);
        auto [v_, st2] = check_types::fresh_var(st1, false, Text::lit(""));
        auto st3 = check_types::unify(st2, check_types::Ty(check_types::Ty::TySig{mark, prism_rtl::rc(v_)}), t, e.span);
        auto [env2, st4] = check_expr::bind_pattern(unpending(env), st3, p_, v_, true);
        return std::tuple{env2, st4, res_opt};
    }
    if (prism_rtl::is<ast::StmtKind::SRequire>(_m)) {
        auto&& c = prism_rtl::as<ast::StmtKind::SRequire>(_m).a0;
        return std::tuple{env, check_expr::check_cond(env, st, c), res_opt};
    }
    if (prism_rtl::is<ast::StmtKind::SForbid>(_m)) {
        auto&& c = prism_rtl::as<ast::StmtKind::SForbid>(_m).a0;
        return std::tuple{env, check_expr::check_cond(env, st, c), res_opt};
    }
    if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<ast::StmtKind::SLet>(_m).a1;
        auto&& e = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
        auto [env2, st2] = check_expr::check_let(env, st, p_, ty_opt, e, s.span);
        return std::tuple{env2, st2, res_opt};
    }
    if (prism_rtl::is<ast::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
        auto [env1, st1] = check_expr::pre_bind(env, st, s);
        auto [env2, st2] = check_expr::check_local_fn(env1, st1, f, s.span);
        return std::tuple{env2, st2, res_opt};
    }
    if (prism_rtl::is<ast::StmtKind::SSignature>(_m)) {
        auto [env2, st2] = check_expr::pre_bind(env, st, s);
        return std::tuple{env2, st2, res_opt};
    }
    if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
        auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        return last
            ? ({
            auto [t, st1] = check_expr::infer(env, st, e);
            auto [v_, st2] = check_types::fresh_var(st1, false, Text::lit(""));
            auto st3 = check_types::unify(st2, check_types::Ty(check_types::Ty::TySig{mark, prism_rtl::rc(v_)}), t, e.span);
            std::tuple{env, st3, std::optional(check_types::Ty(check_types::Ty::TySig{mark, prism_rtl::rc(v_)}))};
        })
            : ({
            auto [t, st1] = check_expr::infer(env, st, e);
            std::tuple{env, discarded(st1, t, e.span), res_opt};
        });
    }
    {
        return std::tuple{env, check_types::err(st, Text::lit("mismatch"), s.span, Text::lit("this statement belongs in a widget or `update` block")), res_opt};
    }
}


prism_rtl::Turn<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>> GivenStmt::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& s = this->s;
    const auto& mark = this->mark;
    const auto& last = this->last;
    const auto& res_opt = this->res_opt;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<ast::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
        ({
        auto res_opt_1 = res_opt;
        auto e_2 = e;
        auto env_3 = env;
        auto mark_4 = mark;
        auto p__5 = p_;
        auto st_6 = st;
        call_then(check_expr::start_infer(env_3, st_6, e_2), [=](std::tuple<check_types::Ty, check_types::St> infer_24112) {
        return ({
            auto [t, st1] = infer_24112;
            auto [v_, st2] = check_types::fresh_var(st1, false, Text::lit(""));
            call_then(check_types::start_unify(st2, check_types::Ty(check_types::Ty::TySig{mark_4, prism_rtl::rc(v_)}), t, e_2.span), [=](check_types::St unify_24196) {
            return ({
                auto st3 = unify_24196;
                call_then(check_expr::start_bind_pattern(unpending(env_3), st3, p__5, v_, true), [=](std::tuple<check_expr::Env, check_types::St> bind_pattern_24262) {
                return ({
                    auto [env2, st4] = bind_pattern_24262;
                    (prism_rtl::finished(std::tuple{env2, st4, res_opt_1}));
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SRequire>(_m) ? ({
        auto&& c = prism_rtl::as<ast::StmtKind::SRequire>(_m).a0;
        ({
        auto res_opt_1 = res_opt;
        auto c_2 = c;
        auto env_3 = env;
        auto st_4 = st;
        call_then(check_expr::start_check_cond(env_3, st_4, c_2), [=](check_types::St check_cond_24359) { return prism_rtl::finished(std::tuple{env_3, check_cond_24359, res_opt_1}); });
    });
    })
        : prism_rtl::is<ast::StmtKind::SForbid>(_m) ? ({
        auto&& c = prism_rtl::as<ast::StmtKind::SForbid>(_m).a0;
        ({
        auto res_opt_1 = res_opt;
        auto c_2 = c;
        auto env_3 = env;
        auto st_4 = st;
        call_then(check_expr::start_check_cond(env_3, st_4, c_2), [=](check_types::St check_cond_24412) { return prism_rtl::finished(std::tuple{env_3, check_cond_24412, res_opt_1}); });
    });
    })
        : prism_rtl::is<ast::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<ast::StmtKind::SLet>(_m).a1;
        auto&& e = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
        ({
        auto res_opt_1 = res_opt;
        auto ty_opt_2 = ty_opt;
        auto e_3 = e;
        auto env_4 = env;
        auto p__5 = p_;
        auto s_6 = s;
        auto st_7 = st;
        call_then(check_expr::start_check_let(env_4, st_7, p__5, ty_opt_2, e_3, s_6.span), [=](std::tuple<check_expr::Env, check_types::St> check_let_24490) {
        return ({
            auto [env2, st2] = check_let_24490;
            (prism_rtl::finished(std::tuple{env2, st2, res_opt_1}));
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
        ({
        auto res_opt_1 = res_opt;
        auto env_2 = env;
        auto f_3 = f;
        auto s_4 = s;
        auto st_5 = st;
        call_then(check_expr::start_pre_bind(env_2, st_5, s_4), [=](std::tuple<check_expr::Env, check_types::St> pre_bind_24593) {
        return ({
            auto [env1, st1] = pre_bind_24593;
            call_then(check_expr::start_check_local_fn(env1, st1, f_3, s_4.span), [=](std::tuple<check_expr::Env, check_types::St> check_local_fn_24640) {
            return ({
                auto [env2, st2] = check_local_fn_24640;
                (prism_rtl::finished(std::tuple{env2, st2, res_opt_1}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SSignature>(_m) ? ({
        auto res_opt_1 = res_opt;
        auto env_2 = env;
        auto s_3 = s;
        auto st_4 = st;
        call_then(check_expr::start_pre_bind(env_2, st_4, s_3), [=](std::tuple<check_expr::Env, check_types::St> pre_bind_24753) {
        return ({
            auto [env2, st2] = pre_bind_24753;
            (prism_rtl::finished(std::tuple{env2, st2, res_opt_1}));
        });
    });
    })
        : prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
        auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        last
        ? ({
        auto e_1 = e;
        auto env_2 = env;
        auto last_3 = last;
        auto mark_4 = mark;
        auto st_5 = st;
        call_then(check_expr::start_infer(env_2, st_5, e_1), [=](std::tuple<check_types::Ty, check_types::St> infer_24859) {
        return ({
            auto [t, st1] = infer_24859;
            auto [v_, st2] = check_types::fresh_var(st1, false, Text::lit(""));
            call_then(check_types::start_unify(st2, check_types::Ty(check_types::Ty::TySig{mark_4, prism_rtl::rc(v_)}), t, e_1.span), [=](check_types::St unify_24951) {
            return ({
                auto st3 = unify_24951;
                (prism_rtl::finished(std::tuple{env_2, st3, std::optional(check_types::Ty(check_types::Ty::TySig{mark_4, prism_rtl::rc(v_)}))}));
            });
        });
        });
    });
    })
        : ({
        auto res_opt_1 = res_opt;
        auto e_2 = e;
        auto env_3 = env;
        auto st_4 = st;
        call_then(check_expr::start_infer(env_3, st_4, e_2), [=](std::tuple<check_types::Ty, check_types::St> infer_25218) {
        return ({
            auto [t, st1] = infer_25218;
            call_then(start_discarded(st1, t, e_2.span), [=](check_types::St discarded_25255) { return prism_rtl::finished(std::tuple{env_3, discarded_25255, res_opt_1}); });
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{env, check_types::err(st, Text::lit("mismatch"), s.span, Text::lit("this statement belongs in a widget or `update` block")), res_opt});
    });
}


/// `Start GivenStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>> start_given_stmt(check_expr::Env env, check_types::St st, ast::Stmt s, Text mark, bool last, std::optional<check_types::Ty> res_opt) {
    return prism_rtl::make_rc<GivenStmt>(env, st, s, mark, last, res_opt);
}


/// InferUpdate: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_update(const check_expr::Env& env, const check_types::St& st, const ast::Expr& target, const ast::Block& body, const ast::Range& span) {
    auto [t, st1] = check_expr::infer(env, st, target);
    auto sh = check_types::head_sigil(st1, t);
    auto st2 = check_expr::is_time_sigil(sh) || (sh == Text::lit("@"))
        ? check_types::err_fix(st1, Text::lit("time-in-update"), target.span, prism_rtl::cat("`update` over a `", check_types::show_ty(st1, t), "`"), Text::lit("update the plain value, and lift the function that does it"))
        : st1;
    auto env2 = ({
        check_expr::Env this_ = with_topic(env, Text::lit("&_"), t);
        this_.in_update = true;
        this_;
    });
    auto&& _st3 = update_stmts(env2, st2, body.stmts);
    auto&& st3 = std::get<1>(_st3);
    auto st4 = check_passes::and_block_checks(env2, st3, body, t);
    return std::tuple{t, st4};
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferUpdate::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& target = this->target;
    const auto& body = this->body;
    const auto& span = this->span;
    auto body_1 = body;
    auto env_2 = env;
    auto span_3 = span;
    auto st_4 = st;
    auto target_5 = target;
    return call_then(check_expr::start_infer(env_2, st_4, target_5), [=](std::tuple<check_types::Ty, check_types::St> infer_25934) {
        return ({
            auto [t, st1] = infer_25934;
            call_then(check_types::start_head_sigil(st1, t), [=](Text head_sigil_25969) {
            return ({
                auto sh = head_sigil_25969;
                auto st2 = check_expr::is_time_sigil(sh) || (sh == Text::lit("@"))
                    ? check_types::err_fix(st1, Text::lit("time-in-update"), target_5.span, prism_rtl::cat("`update` over a `", check_types::show_ty(st1, t), "`"), Text::lit("update the plain value, and lift the function that does it"))
                    : st1;
                auto env2 = ({
                    check_expr::Env this_ = with_topic(env_2, Text::lit("&_"), t);
                    this_.in_update = true;
                    this_;
                });
                call_then(start_update_stmts(env2, st2, body_1.stmts), [=](std::tuple<check_expr::Env, check_types::St> update_stmts_26287) {
                return ({
                    auto&& _st3 = update_stmts_26287;
                    auto&& st3 = std::get<1>(_st3);
                    call_then(check_passes::start_and_block_checks(env2, st3, body_1, t), [=](check_types::St and_block_checks_26335) {
                    return ({
                        auto st4 = and_block_checks_26335;
                        (prism_rtl::finished(std::tuple{t, st4}));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start InferUpdate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_update(check_expr::Env env, check_types::St st, ast::Expr target, ast::Block body, ast::Range span) {
    return prism_rtl::make_rc<InferUpdate>(env, st, target, body, span);
}


/// UpdateStmts: unbounded fn Env, St, [Stmt] -> ((Env, St))
std::tuple<check_expr::Env, check_types::St> update_stmts(const check_expr::Env& env, const check_types::St& st, const Array<ast::Stmt>& stmts) {
    return run_to_end(fold_job(stmts, std::tuple{env, st}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St>>(std::tuple<std::tuple<check_expr::Env, check_types::St>, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<check_expr::Env, check_types::St>, ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto stmt = p1;
                (prism_rtl::more(prism_rtl::rc(UpdateStmt(en, s, stmt))));
            });
        }));
    }))));
}


prism_rtl::Turn<std::tuple<check_expr::Env, check_types::St>> UpdateStmts::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& stmts = this->stmts;
    return fold_job(stmts, std::tuple{env, st}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St>>(std::tuple<std::tuple<check_expr::Env, check_types::St>, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<check_expr::Env, check_types::St>, ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto stmt = p1;
                (prism_rtl::more(prism_rtl::rc(UpdateStmt(en, s, stmt))));
            });
        }));
    })))->cycle();
}


/// `Start UpdateStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St>> start_update_stmts(check_expr::Env env, check_types::St st, Array<ast::Stmt> stmts) {
    return prism_rtl::make_rc<UpdateStmts>(env, st, stmts);
}


/// UpdateStmt: unbounded fn Env, St, Stmt -> ((Env, St))
std::tuple<check_expr::Env, check_types::St> update_stmt(const check_expr::Env& env, const check_types::St& st, const ast::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<ast::StmtKind::SSet>(_m)) {
        auto&& target = prism_rtl::as<ast::StmtKind::SSet>(_m).a0;
        auto&& value = prism_rtl::as<ast::StmtKind::SSet>(_m).a1;
        auto [tt, st1] = check_expr::infer(env, st, target);
        auto st2 = ref_target(env, st1, target);
        return std::tuple{env, check_expr::check(env, st2, value, tt)};
    }
    if (prism_rtl::is<ast::StmtKind::SAccum>(_m)) {
        auto&& target = prism_rtl::as<ast::StmtKind::SAccum>(_m).a0;
        auto&& op = prism_rtl::as<ast::StmtKind::SAccum>(_m).a1;
        auto&& value = prism_rtl::as<ast::StmtKind::SAccum>(_m).a2;
        auto [tt, st1] = check_expr::infer(env, st, target);
        auto st2 = ref_target(env, st1, target);
        auto st3 = check_expr::check(env, st2, value, tt);
        auto st4 = check_expr::add_want(st3, Text::lit("Prelude.Num"), tt, s.span);
        auto st5 = op == Text::lit("-=")
            ? check_expr::add_want(st4, Text::lit("Prelude.Sub"), tt, s.span)
            : st4;
        return std::tuple{env, st5};
    }
    if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<ast::StmtKind::SLet>(_m).a1;
        auto&& e = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
        auto [t, st1] = check_expr::infer(env, st, e);
        auto st2 = ({
            __label__ _done;
            prism_rtl::Slot<check_types::St> _v;
            if (prism_rtl::is_some(ty_opt)) {
                auto&& ty = prism_rtl::some_of(ty_opt);
                _v.set(({
                    auto [at_, s2] = check_env::conv_type(check_expr::env_cx(env), st1, ty);
                    (check_types::unify(s2, at_, t, e.span));
                }));
                goto _done;
            }
            if (prism_rtl::is_none(ty_opt)) {
                _v.set(st1);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto [env2, st3] = check_expr::bind_pattern(unpending(env), st2, p_, t, false);
        return std::tuple{env2, st3};
    }
    if (prism_rtl::is<ast::StmtKind::SWhile>(_m)) {
        auto&& c = prism_rtl::as<ast::StmtKind::SWhile>(_m).a0;
        auto&& body = prism_rtl::as<ast::StmtKind::SWhile>(_m).a1;
        return std::tuple{env, update_while(env, st, c, body)};
    }
    if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
        auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::EIf>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
            auto&& else_b_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
            return std::tuple{env, update_if(env, st, c, then_b, else_b_opt)};
        }
        if (prism_rtl::is<ast::ExprKind::EMatch>(_m)) {
            auto&& scrut = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
            return std::tuple{env, update_match(env, st, scrut, arms, e.span)};
        }
        if (prism_rtl::is<ast::ExprKind::EFor>(_m)) {
            auto&& binders_opt = prism_rtl::as<ast::ExprKind::EFor>(_m).a0;
            auto&& source = prism_rtl::as<ast::ExprKind::EFor>(_m).a1;
            auto&& body = prism_rtl::as<ast::ExprKind::EFor>(_m).a2;
            return std::tuple{env, update_for(env, st, binders_opt, source, body, e.span)};
        }
        {
            auto [t, st1] = check_expr::infer(env, st, e);
            return std::tuple{env, discarded(st1, t, e.span)};
        }
    }
    if (prism_rtl::is<ast::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
        auto [env1, st1] = check_expr::pre_bind(env, st, s);
        return check_expr::check_local_fn(env1, st1, f, s.span);
    }
    if (prism_rtl::is<ast::StmtKind::SSignature>(_m)) {
        return check_expr::pre_bind(env, st, s);
    }
    {
        return std::tuple{env, check_types::err(st, Text::lit("mismatch"), s.span, Text::lit("this statement belongs in a widget or `given:` block"))};
    }
}


prism_rtl::Turn<std::tuple<check_expr::Env, check_types::St>> UpdateStmt::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SSet>(_m) ? ({
        auto&& target = prism_rtl::as<ast::StmtKind::SSet>(_m).a0;
        auto&& value = prism_rtl::as<ast::StmtKind::SSet>(_m).a1;
        ({
        auto env_1 = env;
        auto st_2 = st;
        auto target_3 = target;
        auto value_4 = value;
        call_then(check_expr::start_infer(env_1, st_2, target_3), [=](std::tuple<check_types::Ty, check_types::St> infer_26687) {
        return ({
            auto [tt, st1] = infer_26687;
            auto st2 = ref_target(env_1, st1, target_3);
            call_then(check_expr::start_check(env_1, st2, value_4, tt), [=](check_types::St check_26770) { return prism_rtl::finished(std::tuple{env_1, check_26770}); });
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SAccum>(_m) ? ({
        auto&& target = prism_rtl::as<ast::StmtKind::SAccum>(_m).a0;
        auto&& op = prism_rtl::as<ast::StmtKind::SAccum>(_m).a1;
        auto&& value = prism_rtl::as<ast::StmtKind::SAccum>(_m).a2;
        ({
        auto env_1 = env;
        auto op_2 = op;
        auto s_3 = s;
        auto st_4 = st;
        auto target_5 = target;
        auto value_6 = value;
        call_then(check_expr::start_infer(env_1, st_4, target_5), [=](std::tuple<check_types::Ty, check_types::St> infer_26855) {
        return ({
            auto [tt, st1] = infer_26855;
            auto st2 = ref_target(env_1, st1, target_5);
            call_then(check_expr::start_check(env_1, st2, value_6, tt), [=](check_types::St check_26940) {
            return ({
                auto st3 = check_26940;
                auto st4 = check_expr::add_want(st3, Text::lit("Prelude.Num"), tt, s_3.span);
                auto st5 = op_2 == Text::lit("-=")
                    ? check_expr::add_want(st4, Text::lit("Prelude.Sub"), tt, s_3.span)
                    : st4;
                (prism_rtl::finished(std::tuple{env_1, st5}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<ast::StmtKind::SLet>(_m).a1;
        auto&& e = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
        ({
        auto ty_opt_1 = ty_opt;
        auto e_2 = e;
        auto env_3 = env;
        auto p__4 = p_;
        auto st_5 = st;
        call_then(check_expr::start_infer(env_3, st_5, e_2), [=](std::tuple<check_types::Ty, check_types::St> infer_27171) {
        return ({
            auto [t, st1] = infer_27171;
            auto st2 = ({
                __label__ _done;
                prism_rtl::Slot<check_types::St> _v;
                if (prism_rtl::is_some(ty_opt)) {
                    auto&& ty = prism_rtl::some_of(ty_opt);
                    _v.set(({
                        auto [at_, s2] = check_env::conv_type(check_expr::env_cx(env_3), st1, ty);
                        (check_types::unify(s2, at_, t, e_2.span));
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(ty_opt)) {
                    _v.set(st1);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            call_then(check_expr::start_bind_pattern(unpending(env_3), st2, p__4, t, false), [=](std::tuple<check_expr::Env, check_types::St> bind_pattern_27387) {
            return ({
                auto [env2, st3] = bind_pattern_27387;
                (prism_rtl::finished(std::tuple{env2, st3}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SWhile>(_m) ? ({
        auto&& c = prism_rtl::as<ast::StmtKind::SWhile>(_m).a0;
        auto&& body = prism_rtl::as<ast::StmtKind::SWhile>(_m).a1;
        ({
        auto body_1 = body;
        auto c_2 = c;
        auto env_3 = env;
        auto st_4 = st;
        call_then(start_update_while(env_3, st_4, c_2, body_1), [=](check_types::St update_while_27483) { return prism_rtl::finished(std::tuple{env_3, update_while_27483}); });
    });
    })
        : prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
        auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EIf>(_m) ? ({
        auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
        ({
        auto else_b_opt_1 = else_b_opt;
        auto c_2 = c;
        auto env_3 = env;
        auto st_4 = st;
        auto then_b_5 = then_b;
        call_then(start_update_if(env_3, st_4, c_2, then_b_5, else_b_opt_1), [=](check_types::St update_if_27580) { return prism_rtl::finished(std::tuple{env_3, update_if_27580}); });
    });
    })
        : prism_rtl::is<ast::ExprKind::EMatch>(_m) ? ({
        auto&& scrut = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
        ({
        auto arms_1 = arms;
        auto e_2 = e;
        auto env_3 = env;
        auto scrut_4 = scrut;
        auto st_5 = st;
        call_then(start_update_match(env_3, st_5, scrut_4, arms_1, e_2.span), [=](check_types::St update_match_27654) { return prism_rtl::finished(std::tuple{env_3, update_match_27654}); });
    });
    })
        : prism_rtl::is<ast::ExprKind::EFor>(_m) ? ({
        auto&& binders_opt = prism_rtl::as<ast::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<ast::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<ast::ExprKind::EFor>(_m).a2;
        ({
        auto binders_opt_1 = binders_opt;
        auto body_2 = body;
        auto e_3 = e;
        auto env_4 = env;
        auto source_5 = source;
        auto st_6 = st;
        call_then(start_update_for(env_4, st_6, binders_opt_1, source_5, body_2, e_3.span), [=](check_types::St update_for_27743) { return prism_rtl::finished(std::tuple{env_4, update_for_27743}); });
    });
    })
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto st_3 = st;
        call_then(check_expr::start_infer(env_2, st_3, e_1), [=](std::tuple<check_types::Ty, check_types::St> infer_27844) {
        return ({
            auto [t, st1] = infer_27844;
            call_then(start_discarded(st1, t, e_1.span), [=](check_types::St discarded_27881) { return prism_rtl::finished(std::tuple{env_2, discarded_27881}); });
        });
    });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
        ({
        auto env_1 = env;
        auto f_2 = f;
        auto s_3 = s;
        auto st_4 = st;
        call_then(check_expr::start_pre_bind(env_1, st_4, s_3), [=](std::tuple<check_expr::Env, check_types::St> pre_bind_27948) {
        return ({
            auto [env1, st1] = pre_bind_27948;
            (prism_rtl::more(prism_rtl::rc(check_expr::CheckLocalFn(env1, st1, f_2, s_3.span))));
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SSignature>(_m) ? prism_rtl::more(prism_rtl::rc(check_expr::PreBind(env, st, s)))
        : prism_rtl::finished(std::tuple{env, check_types::err(st, Text::lit("mismatch"), s.span, Text::lit("this statement belongs in a widget or `given:` block"))});
    });
}


/// `Start UpdateStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St>> start_update_stmt(check_expr::Env env, check_types::St st, ast::Stmt s) {
    return prism_rtl::make_rc<UpdateStmt>(env, st, s);
}


/// RefTarget: fn Env, St, Expr -> St
check_types::St ref_target(const check_expr::Env& env, const check_types::St& st, const ast::Expr& e) {
    return is_ref(e)
        ? st
        : check_types::err_fix(st, Text::lit("mismatch"), e.span, Text::lit("the left of `<=` is a reference: `&_`, a local `&x`, or a path from one"), prism_rtl::cat("write `&_.", check_expr::src_text(env, e.span), "`, or make a local with `let &x = ...`"));
}


/// IsRef: fn Expr -> Bool
bool is_ref(const ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        return lexer::has_prefix(n.sigils, Text::lit("&"));
    }
    if (prism_rtl::is<ast::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
        return is_ref(r);
    }
    if (prism_rtl::is<ast::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
        return is_ref(r);
    }
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        return is_ref(x);
    }
    {
        return false;
    }
}


/// UpdateIf: unbounded fn Env, St, Cond, Block, ?Block -> St
check_types::St update_if(const check_expr::Env& env, const check_types::St& st, const ast::Cond& c, const ast::Block& then_b, const std::optional<ast::Block>& else_b_opt) {
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_expr::Env, check_types::St>> _v;
        if (prism_rtl::is<ast::Cond::CondExpr>(c)) {
            auto&& e = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
            _v.set(std::tuple{env, check_expr::check_cond(env, st, e)});
            goto _done;
        }
        if (prism_rtl::is<ast::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c).a0;
            auto&& e = prism_rtl::as<ast::Cond::CondBind>(c).a1;
            auto&& gd_opt = prism_rtl::as<ast::Cond::CondBind>(c).a2;
            _v.set(({
                auto [et, s1] = check_expr::infer(env, st, e);
                auto [en, s2] = check_expr::bind_pattern(unpending(env), s1, p_, et, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_expr::Env, check_types::St>> _v;
                auto&& _m = gd_opt;
                if (prism_rtl::is_some(_m)) {
                    auto&& g = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en, check_expr::check_cond(en, s2, g)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en, s2});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _st2 = update_stmts(env2, st1, then_b.stmts);
    auto&& st2 = std::get<1>(_st2);
    if (prism_rtl::is_some(else_b_opt)) {
        auto&& b = prism_rtl::some_of(else_b_opt);
        auto&& _st3 = update_stmts(env, st2, b.stmts);
        auto&& st3 = std::get<1>(_st3);
        return st3;
    }
    if (prism_rtl::is_none(else_b_opt)) {
        return st2;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<check_types::St> UpdateIf::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& then_b = this->then_b;
    const auto& else_b_opt = this->else_b_opt;
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_expr::Env, check_types::St>> _v;
        if (prism_rtl::is<ast::Cond::CondExpr>(c)) {
            auto&& e = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
            _v.set(std::tuple{env, check_expr::check_cond(env, st, e)});
            goto _done;
        }
        if (prism_rtl::is<ast::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c).a0;
            auto&& e = prism_rtl::as<ast::Cond::CondBind>(c).a1;
            auto&& gd_opt = prism_rtl::as<ast::Cond::CondBind>(c).a2;
            _v.set(({
                auto [et, s1] = check_expr::infer(env, st, e);
                auto [en, s2] = check_expr::bind_pattern(unpending(env), s1, p_, et, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_expr::Env, check_types::St>> _v;
                auto&& _m = gd_opt;
                if (prism_rtl::is_some(_m)) {
                    auto&& g = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en, check_expr::check_cond(en, s2, g)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en, s2});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto else_b_opt_1 = else_b_opt;
    auto env_2 = env;
    auto then_b_3 = then_b;
    return call_then(start_update_stmts(env2, st1, then_b_3.stmts), [=](std::tuple<check_expr::Env, check_types::St> update_stmts_29165) {
        return ({
            auto&& _st2 = update_stmts_29165;
            auto&& st2 = std::get<1>(_st2);
            ({
            prism_rtl::is_some(else_b_opt_1) ? ({
            auto&& b = prism_rtl::some_of(else_b_opt_1);
            ({
            auto b_4 = b;
            call_then(start_update_stmts(env_2, st2, b_4.stmts), [=](std::tuple<check_expr::Env, check_types::St> update_stmts_29265) {
            return ({
                auto&& _st3 = update_stmts_29265;
                auto&& st3 = std::get<1>(_st3);
                (prism_rtl::finished(st3));
            });
        });
        });
        })
            : prism_rtl::is_none(else_b_opt_1) ? prism_rtl::finished(st2)
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start UpdateIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_update_if(check_expr::Env env, check_types::St st, ast::Cond c, ast::Block then_b, std::optional<ast::Block> else_b_opt) {
    return prism_rtl::make_rc<UpdateIf>(env, st, c, then_b, else_b_opt);
}


/// UpdateMatch: unbounded fn Env, St, Expr, [Arm], Range -> St
check_types::St update_match(const check_expr::Env& env, const check_types::St& st, const ast::Expr& scrut, const Array<ast::Arm>& arms, const ast::Range& span) {
    auto [t, st1] = check_expr::infer(env, st, scrut);
    auto st2 = run_to_end(fold_job(arms, st1, ({
        auto env_1 = env;
        auto t_2 = t;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::Arm>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_3 = env_1;
            auto t_2_3 = t_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto arm = p1;
                ({
                auto [env2, s1] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<check_expr::Env, check_types::St>> _v;
                    auto&& _m = arm.pattern;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p_ = prism_rtl::some_of(_m);
                        _v.set(check_expr::bind_pattern(unpending(env_1_3), s, p_, t_2_3, true));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::tuple{env_1_3, s});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto s2 = ({
                    __label__ _done;
                    prism_rtl::Slot<check_types::St> _v;
                    auto&& _m = arm.guard;
                    if (prism_rtl::is_some(_m)) {
                        auto&& gd = prism_rtl::some_of(_m);
                        _v.set(check_expr::check_cond(env2, s1, gd));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s1);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_update_stmts(env2, s2, arm.body.stmts), [=](std::tuple<check_expr::Env, check_types::St> update_stmts_29774) {
                return ({
                    auto&& _s3 = update_stmts_29774;
                    auto&& s3 = std::get<1>(_s3);
                    (prism_rtl::finished(s3));
                });
            });
            });
            });
        }));
        });
    })));
    })));
    return check_passes::match_coverage(env, st2, t, arms, span);
}


prism_rtl::Turn<check_types::St> UpdateMatch::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& scrut = this->scrut;
    const auto& arms = this->arms;
    const auto& span = this->span;
    auto arms_1 = arms;
    auto env_2 = env;
    auto scrut_3 = scrut;
    auto span_4 = span;
    auto st_5 = st;
    return call_then(check_expr::start_infer(env_2, st_5, scrut_3), [=](std::tuple<check_types::Ty, check_types::St> infer_29453) {
        return ({
            auto [t, st1] = infer_29453;
            call_value(fold_job(arms_1, st1, ({
            auto env_2_6 = env_2;
            auto t_6 = t;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::Arm>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_2_6_7 = env_2_6;
                auto t_6_7 = t_6;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto arm = p1;
                    ({
                    auto [env2, s1] = ({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<check_expr::Env, check_types::St>> _v;
                        auto&& _m = arm.pattern;
                        if (prism_rtl::is_some(_m)) {
                            auto&& p_ = prism_rtl::some_of(_m);
                            _v.set(check_expr::bind_pattern(unpending(env_2_6_7), s, p_, t_6_7, true));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::tuple{env_2_6_7, s});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    auto s2 = ({
                        __label__ _done;
                        prism_rtl::Slot<check_types::St> _v;
                        auto&& _m = arm.guard;
                        if (prism_rtl::is_some(_m)) {
                            auto&& gd = prism_rtl::some_of(_m);
                            _v.set(check_expr::check_cond(env2, s1, gd));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(s1);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    call_then(start_update_stmts(env2, s2, arm.body.stmts), [=](std::tuple<check_expr::Env, check_types::St> update_stmts_29774) {
                    return ({
                        auto&& _s3 = update_stmts_29774;
                        auto&& s3 = std::get<1>(_s3);
                        (prism_rtl::finished(s3));
                    });
                });
                });
                });
            }));
            });
        })));
        })), [=](check_types::St fold_29488) {
            return ({
                auto st2 = fold_29488;
                (prism_rtl::more(prism_rtl::rc(check_passes::MatchCoverage(env_2, st2, t, arms_1, span_4))));
            });
        });
        });
    });
}


/// `Start UpdateMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_update_match(check_expr::Env env, check_types::St st, ast::Expr scrut, Array<ast::Arm> arms, ast::Range span) {
    return prism_rtl::make_rc<UpdateMatch>(env, st, scrut, arms, span);
}


/// UpdateWhile: unbounded fn Env, St, Cond, Block -> St
check_types::St update_while(const check_expr::Env& env, const check_types::St& st, const ast::Cond& c, const ast::Block& body) {
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_expr::Env, check_types::St>> _v;
        if (prism_rtl::is<ast::Cond::CondExpr>(c)) {
            auto&& e = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
            _v.set(std::tuple{env, check_expr::check_cond(env, st, e)});
            goto _done;
        }
        if (prism_rtl::is<ast::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c).a0;
            auto&& e = prism_rtl::as<ast::Cond::CondBind>(c).a1;
            auto&& gd_opt = prism_rtl::as<ast::Cond::CondBind>(c).a2;
            _v.set(({
                auto [et, s1] = check_expr::infer(env, st, e);
                auto [en, s2] = check_expr::bind_pattern(unpending(env), s1, p_, et, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_expr::Env, check_types::St>> _v;
                auto&& _m = gd_opt;
                if (prism_rtl::is_some(_m)) {
                    auto&& g = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en, check_expr::check_cond(en, s2, g)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en, s2});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _st2 = update_stmts(env2, st1, body.stmts);
    auto&& st2 = std::get<1>(_st2);
    return st2;
}


prism_rtl::Turn<check_types::St> UpdateWhile::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& body = this->body;
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_expr::Env, check_types::St>> _v;
        if (prism_rtl::is<ast::Cond::CondExpr>(c)) {
            auto&& e = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
            _v.set(std::tuple{env, check_expr::check_cond(env, st, e)});
            goto _done;
        }
        if (prism_rtl::is<ast::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c).a0;
            auto&& e = prism_rtl::as<ast::Cond::CondBind>(c).a1;
            auto&& gd_opt = prism_rtl::as<ast::Cond::CondBind>(c).a2;
            _v.set(({
                auto [et, s1] = check_expr::infer(env, st, e);
                auto [en, s2] = check_expr::bind_pattern(unpending(env), s1, p_, et, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_expr::Env, check_types::St>> _v;
                auto&& _m = gd_opt;
                if (prism_rtl::is_some(_m)) {
                    auto&& g = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en, check_expr::check_cond(en, s2, g)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en, s2});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto body_1 = body;
    return call_then(start_update_stmts(env2, st1, body_1.stmts), [=](std::tuple<check_expr::Env, check_types::St> update_stmts_30409) {
        return ({
            auto&& _st2 = update_stmts_30409;
            auto&& st2 = std::get<1>(_st2);
            (prism_rtl::finished(st2));
        });
    });
}


/// `Start UpdateWhile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_update_while(check_expr::Env env, check_types::St st, ast::Cond c, ast::Block body) {
    return prism_rtl::make_rc<UpdateWhile>(env, st, c, body);
}


/// UpdateFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> St
check_types::St update_for(const check_expr::Env& env, const check_types::St& st, const std::optional<ast::ForBinders>& binders_opt, const ast::Expr& source, const ast::Block& body, const ast::Range& span) {
    auto [t, st1] = check_expr::infer(env, st, source);
    auto [k, v_, st2] = coll_parts(st1, t, source.span);
    auto env1 = loop_indices(env);
    auto [env2, st3] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_expr::Env, check_types::St>> _v;
        if (prism_rtl::is_none(binders_opt)) {
            _v.set(std::tuple{with_topic(env1, Text::lit("&_"), v_), st2});
            goto _done;
        }
        if (prism_rtl::is_some(binders_opt)) {
            auto&& bs = prism_rtl::some_of(binders_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_expr::Env, check_types::St>> _v;
                auto&& _m = bs.second;
                if (prism_rtl::is_some(_m)) {
                    auto&& second = prism_rtl::some_of(_m);
                    _v.set(({
                        auto [e1, s1] = check_expr::bind_pattern(unpending(env1), st2, bs.first, k, false);
                        (check_expr::bind_pattern(e1, s1, second, v_, false));
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(check_expr::bind_pattern(unpending(env1), st2, bs.first, v_, false));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _st4 = update_stmts(env2, st3, body.stmts);
    auto&& st4 = std::get<1>(_st4);
    return st4;
}


prism_rtl::Turn<check_types::St> UpdateFor::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& binders_opt = this->binders_opt;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& span = this->span;
    auto binders_opt_1 = binders_opt;
    auto body_2 = body;
    auto env_3 = env;
    auto source_4 = source;
    auto span_5 = span;
    auto st_6 = st;
    return call_then(check_expr::start_infer(env_3, st_6, source_4), [=](std::tuple<check_types::Ty, check_types::St> infer_30717) {
        return ({
            auto [t, st1] = infer_30717;
            call_then(start_coll_parts(st1, t, source_4.span), [=](std::tuple<check_types::Ty, check_types::Ty, check_types::St> coll_parts_30763) {
            return ({
                auto [k, v_, st2] = coll_parts_30763;
                auto env1 = loop_indices(env_3);
                auto [env2, st3] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<check_expr::Env, check_types::St>> _v;
                    if (prism_rtl::is_none(binders_opt)) {
                        _v.set(std::tuple{with_topic(env1, Text::lit("&_"), v_), st2});
                        goto _done;
                    }
                    if (prism_rtl::is_some(binders_opt)) {
                        auto&& bs = prism_rtl::some_of(binders_opt);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<check_expr::Env, check_types::St>> _v;
                            auto&& _m = bs.second;
                            if (prism_rtl::is_some(_m)) {
                                auto&& second = prism_rtl::some_of(_m);
                                _v.set(({
                                    auto [e1, s1] = check_expr::bind_pattern(unpending(env1), st2, bs.first, k, false);
                                    (check_expr::bind_pattern(e1, s1, second, v_, false));
                                }));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(check_expr::bind_pattern(unpending(env1), st2, bs.first, v_, false));
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_update_stmts(env2, st3, body_2.stmts), [=](std::tuple<check_expr::Env, check_types::St> update_stmts_31203) {
                return ({
                    auto&& _st4 = update_stmts_31203;
                    auto&& st4 = std::get<1>(_st4);
                    (prism_rtl::finished(st4));
                });
            });
            });
        });
        });
    });
}


/// `Start UpdateFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_update_for(check_expr::Env env, check_types::St st, std::optional<ast::ForBinders> binders_opt, ast::Expr source, ast::Block body, ast::Range span) {
    return prism_rtl::make_rc<UpdateFor>(env, st, binders_opt, source, body, span);
}

}  // namespace crate::check_blocks
