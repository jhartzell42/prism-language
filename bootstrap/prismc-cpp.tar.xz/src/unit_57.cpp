// The module `Lower.Templates`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/templates/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Templates`, from `target/bootstrap/cpp-src/prismc/lower/templates.prism`.
namespace crate::lower::templates {

/// TemplateValue: unbounded fn Lx, Env, Template -> Vl
crate::lower::types::Vl template_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Template& tp_p2) {
    auto start_p3 = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("out")}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("String::new"), Array<crate::lower::model::Ex>{}})})});
    auto dos_p4 = run_to_end(fold_job(tp_p2.parts, start_p3, ({
        auto lx_p0_1 = lx_p0;
        auto env_p1_2 = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), env_p1_2 = std::move(env_p1_2)](std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_3 = lx_p0_1;
            auto env_p1_2_3 = env_p1_2;
            entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), env_p1_2_3 = std::move(env_p1_2_3)]() {
            return ({
                auto acc_p5 = p0;
                auto part_p6 = p1;
                call_then(start_template_part_dos(lx_p0_1_3, env_p1_2_3, part_p6), [=, acc_p5 = std::move(acc_p5)](Array<crate::lower::model::Do> template_part_dos_1601) { return prism_rtl::finished(append(acc_p5, template_part_dos_1601)); });
            });
        }));
        });
    })));
    })));
    return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_p4, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Text::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})})}))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})});
}


prism_rtl::Turn<crate::lower::types::Vl> TemplateValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& tp_p2 = this->tp_p2;
    auto start_p3 = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("out")}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("String::new"), Array<crate::lower::model::Ex>{}})})});
    auto env_p1_1 = env_p1;
    auto lx_p0_2 = lx_p0;
    auto tp_p2_3 = tp_p2;
    return call_value(fold_job(prism_rtl::deref(tp_p2_3).parts, start_p3, ({
        auto lx_p0_2_4 = lx_p0_2;
        auto env_p1_1_4 = env_p1_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=, lx_p0_2_4 = std::move(lx_p0_2_4), env_p1_1_4 = std::move(env_p1_1_4)](std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_2_4_4 = lx_p0_2_4;
            auto env_p1_1_4_4 = env_p1_1_4;
            entered(once_job([=, lx_p0_2_4_4 = std::move(lx_p0_2_4_4), env_p1_1_4_4 = std::move(env_p1_1_4_4)]() {
            return ({
                auto acc_p5 = p0;
                auto part_p6 = p1;
                call_then(start_template_part_dos(lx_p0_2_4_4, env_p1_1_4_4, part_p6), [=, acc_p5 = std::move(acc_p5)](Array<crate::lower::model::Do> template_part_dos_1601) { return prism_rtl::finished(append(acc_p5, template_part_dos_1601)); });
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::Do> fold_1553) {
        return ({
            auto dos_p4 = fold_1553;
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_p4, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Text::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})})}))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})));
        });
    });
}


/// `Start TemplateValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_template_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Template tp_p2) {
    return prism_rtl::make_rc<TemplateValue>(lx_p0, env_p1, tp_p2);
}


/// TemplatePartDos: unbounded fn Lx, Env, TemplatePart -> [Do]
Array<crate::lower::model::Do> template_part_dos(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::TemplatePart& part_p2) {
    if (prism_rtl::is<crate::syntax::TemplatePart::TpText>(part_p2)) {
        auto&& t_p3 = prism_rtl::as<crate::syntax::TemplatePart::TpText>(part_p2).a0;
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})), Text::lit("push_str"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{t_p3})})})})});
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(part_p2)) {
        auto&& x_p4 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part_p2).a0;
        auto&& col_o5 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part_p2).a1;
        auto v_p6 = crate::lower::expr::value_of(lx_p0, env_p1, x_p4);
        auto column_p7 = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::Ex> _v;
            if (prism_rtl::is_some(col_o5)) {
                auto&& c_p8 = prism_rtl::some_of(col_o5);
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{c_p8})})}));
                goto _done;
            }
            if (prism_rtl::is_none(col_o5)) {
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XNone{}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("place"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), shown_text(v_p6), column_p7})})})});
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(part_p2)) {
        auto&& b_p9 = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(part_p2).a0;
        auto v_pa = crate::lower::expr::block_value(lx_p0, env_p1, b_p9);
        return crate::lower::types::value_ty(v_pa) == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
            ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own(v_pa)})})
            : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("place"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), shown_text(v_pa), crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})})});
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpCall>(part_p2)) {
        auto&& n_pb = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a0;
        auto&& args_pc = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a1;
        auto&& parts_od = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a2;
        auto plain_pe = crate::syntax::SName{.sigils = crate::syntax::lexer::chars::after_first(prism_rtl::deref(n_pb).sigils), .path_ = n_pb->path_, .span = prism_rtl::deref(n_pb).span};
        auto&& _qk_oj = crate::check::env::names::resolve_value(lx_p0.g, lx_p0.home, n_pb);
        auto&& qk_oj = std::get<0>(_qk_oj);
        auto&& _qk2_ok = crate::check::env::names::resolve_value(lx_p0.g, lx_p0.home, plain_pe);
        auto&& qk2_ok = std::get<0>(_qk2_ok);
        auto callee_pf = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(qk_oj)) {
                auto&& q_pl = prism_rtl::some_of(qk_oj);
                _v.set(crate::lower::value_path(lx_p0, q_pl));
                goto _done;
            }
            if (prism_rtl::is_none(qk_oj)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    if (prism_rtl::is_some(qk2_ok)) {
                        auto&& q_pm = prism_rtl::some_of(qk2_ok);
                        _v.set(crate::lower::value_path(lx_p0, q_pm));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk2_ok)) {
                        _v.set(crate::lower::snake(crate::check::env::sname_key(n_pb)));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto body_pg = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
            if (prism_rtl::is_some(parts_od)) {
                auto&& ps_pn = prism_rtl::some_of(parts_od);
                _v.set(({
                    auto inner_po = run_to_end(fold_job(ps_pn, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("out")}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("String::new"), Array<crate::lower::model::Ex>{}})})}), ({
                        auto lx_p0_1 = lx_p0;
                        auto env_p1_2 = env_p1;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), env_p1_2 = std::move(env_p1_2)](std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto lx_p0_1_3 = lx_p0_1;
                            auto env_p1_2_3 = env_p1_2;
                            entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), env_p1_2_3 = std::move(env_p1_2_3)]() {
                            return ({
                                auto acc_pp = p0;
                                auto p_pq = p1;
                                call_then(start_template_part_dos(lx_p0_1_3, env_p1_2_3, p_pq), [=, acc_pp = std::move(acc_pp)](Array<crate::lower::model::Do> template_part_dos_2911) { return prism_rtl::finished(append(acc_pp, template_part_dos_2911)); });
                            });
                        }));
                        });
                    })));
                    })));
                    (Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{inner_po, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Text::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})})}))}))})}));
                }));
                goto _done;
            }
            if (prism_rtl::is_none(parts_od)) {
                _v.set(Array<crate::lower::model::Ex>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto passed_ph = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
            if (prism_rtl::is_some(qk_oj)) {
                auto&& q_pr = prism_rtl::some_of(qk_oj);
                _v.set(template_args(lx_p0, env_p1, q_pr, args_pc, body_pg));
                goto _done;
            }
            if (prism_rtl::is_none(qk_oj)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                    if (prism_rtl::is_some(qk2_ok)) {
                        auto&& q_ps = prism_rtl::some_of(qk2_ok);
                        _v.set(template_args(lx_p0, env_p1, q_ps, args_pc, body_pg));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk2_ok)) {
                        _v.set(append(run_to_end(each_job(args_pc, ({
                            auto lx_p0_1 = lx_p0;
                            auto env_p1_2 = env_p1;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), env_p1_2 = std::move(env_p1_2)](crate::syntax::Arg p0) {
                            return ({
                                auto lx_p0_1_3 = lx_p0_1;
                                auto env_p1_2_3 = env_p1_2;
                                entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), env_p1_2_3 = std::move(env_p1_2_3)]() {
                                return ({
                                    auto a_pt = p0;
                                    (prism_rtl::more(prism_rtl::rc(crate::lower::expr::Argument(lx_p0_1_3, env_p1_2_3, a_pt->value))));
                                });
                            }));
                            });
                        })));
                        }))), body_pg));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto call_pi = crate::lower::model::Ex(crate::lower::model::Ex::XCall{callee_pf, passed_ph});
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("place"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(call_pi)}), crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})})});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::lower::model::Do>> TemplatePartDos::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& part_p2 = this->part_p2;
    return ({
        prism_rtl::is<crate::syntax::TemplatePart::TpText>(part_p2) ? ({
        auto&& t_p3 = prism_rtl::as<crate::syntax::TemplatePart::TpText>(part_p2).a0;
        prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})), Text::lit("push_str"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{t_p3})})})})}));
    })
        : prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(part_p2) ? ({
        auto&& x_p4 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part_p2).a0;
        auto&& col_o5 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part_p2).a1;
        ({
        auto col_o5_1 = col_o5;
        auto env_p1_2 = env_p1;
        auto lx_p0_3 = lx_p0;
        auto x_p4_4 = x_p4;
        call_then(crate::lower::expr::start_value_of(lx_p0_3, env_p1_2, x_p4_4), [=, col_o5_1 = std::move(col_o5_1)](crate::lower::types::Vl value_of_1931) {
        return ({
            auto v_p6 = value_of_1931;
            auto column_p7 = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::Ex> _v;
                if (prism_rtl::is_some(col_o5_1)) {
                    auto&& c_p8 = prism_rtl::some_of(col_o5_1);
                    _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{c_p8})})}));
                    goto _done;
                }
                if (prism_rtl::is_none(col_o5_1)) {
                    _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XNone{}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("place"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), shown_text(v_p6), column_p7})})})})));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(part_p2) ? ({
        auto&& b_p9 = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(part_p2).a0;
        ({
        auto b_p9_1 = b_p9;
        auto env_p1_2 = env_p1;
        auto lx_p0_3 = lx_p0;
        call_then(crate::lower::expr::start_block_value(lx_p0_3, env_p1_2, b_p9_1), [=](crate::lower::types::Vl block_value_2165) {
        return ({
            auto v_pa = block_value_2165;
            (crate::lower::types::value_ty(v_pa) == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
            ? prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own(v_pa)})}))
            : prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("place"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), shown_text(v_pa), crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})})})));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TemplatePart::TpCall>(part_p2) ? ({
        auto&& n_pb = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a0;
        auto&& args_pc = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a1;
        auto&& parts_od = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a2;
        ({
        auto plain_pe = crate::syntax::SName{.sigils = crate::syntax::lexer::chars::after_first(prism_rtl::deref(n_pb).sigils), .path_ = n_pb->path_, .span = prism_rtl::deref(n_pb).span};
        auto&& _qk_oj = crate::check::env::names::resolve_value(prism_rtl::deref(lx_p0).g, prism_rtl::deref(lx_p0).home, n_pb);
        auto&& qk_oj = std::get<0>(_qk_oj);
        auto&& _qk2_ok = crate::check::env::names::resolve_value(prism_rtl::deref(lx_p0).g, prism_rtl::deref(lx_p0).home, plain_pe);
        auto&& qk2_ok = std::get<0>(_qk2_ok);
        auto callee_pf = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(qk_oj)) {
                auto&& q_pl = prism_rtl::some_of(qk_oj);
                _v.set(crate::lower::value_path(lx_p0, q_pl));
                goto _done;
            }
            if (prism_rtl::is_none(qk_oj)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    if (prism_rtl::is_some(qk2_ok)) {
                        auto&& q_pm = prism_rtl::some_of(qk2_ok);
                        _v.set(crate::lower::value_path(lx_p0, q_pm));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk2_ok)) {
                        _v.set(crate::lower::snake(crate::check::env::sname_key(n_pb)));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto body_pg = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
            if (prism_rtl::is_some(parts_od)) {
                auto&& ps_pn = prism_rtl::some_of(parts_od);
                _v.set(({
                    auto inner_po = run_to_end(fold_job(ps_pn, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("out")}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("String::new"), Array<crate::lower::model::Ex>{}})})}), ({
                        auto lx_p0_1 = lx_p0;
                        auto env_p1_2 = env_p1;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), env_p1_2 = std::move(env_p1_2)](std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto lx_p0_1_3 = lx_p0_1;
                            auto env_p1_2_3 = env_p1_2;
                            entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), env_p1_2_3 = std::move(env_p1_2_3)]() {
                            return ({
                                auto acc_pp = p0;
                                auto p_pq = p1;
                                call_then(start_template_part_dos(lx_p0_1_3, env_p1_2_3, p_pq), [=, acc_pp = std::move(acc_pp)](Array<crate::lower::model::Do> template_part_dos_2911) { return prism_rtl::finished(append(acc_pp, template_part_dos_2911)); });
                            });
                        }));
                        });
                    })));
                    })));
                    (Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{inner_po, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Text::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})})}))}))})}));
                }));
                goto _done;
            }
            if (prism_rtl::is_none(parts_od)) {
                _v.set(Array<crate::lower::model::Ex>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto passed_ph = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
            if (prism_rtl::is_some(qk_oj)) {
                auto&& q_pr = prism_rtl::some_of(qk_oj);
                _v.set(template_args(lx_p0, env_p1, q_pr, args_pc, body_pg));
                goto _done;
            }
            if (prism_rtl::is_none(qk_oj)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                    if (prism_rtl::is_some(qk2_ok)) {
                        auto&& q_ps = prism_rtl::some_of(qk2_ok);
                        _v.set(template_args(lx_p0, env_p1, q_ps, args_pc, body_pg));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk2_ok)) {
                        _v.set(append(run_to_end(each_job(args_pc, ({
                            auto lx_p0_1 = lx_p0;
                            auto env_p1_2 = env_p1;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), env_p1_2 = std::move(env_p1_2)](crate::syntax::Arg p0) {
                            return ({
                                auto lx_p0_1_3 = lx_p0_1;
                                auto env_p1_2_3 = env_p1_2;
                                entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), env_p1_2_3 = std::move(env_p1_2_3)]() {
                                return ({
                                    auto a_pt = p0;
                                    (prism_rtl::more(prism_rtl::rc(crate::lower::expr::Argument(lx_p0_1_3, env_p1_2_3, a_pt->value))));
                                });
                            }));
                            });
                        })));
                        }))), body_pg));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto call_pi = crate::lower::model::Ex(crate::lower::model::Ex::XCall{callee_pf, passed_ph});
        (prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("place"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(call_pi)}), crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})})})));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplatePartDos, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Do>> start_template_part_dos(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::TemplatePart part_p2) {
    return prism_rtl::make_rc<TemplatePartDos>(lx_p0, env_p1, part_p2);
}


/// TemplateArgs: unbounded fn Lx, Env, Text, [Arg], [Ex] -> [Ex]
Array<crate::lower::model::Ex> template_args(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Text& qk_p2, const Array<crate::syntax::Arg>& args_p3, const Array<crate::lower::model::Ex>& body_p4) {
    auto clauses_p5 = crate::lower::jobs::clauses_of(lx_p0.g, qk_p2);
    auto arity_p6 = len(prism_rtl::deref(or_(index(clauses_p5, Nat(0u)), crate::lower::functions::dummy_clause())).params);
    return run_to_end(each_job(crate::check::errors::range0(arity_p6), ({
        auto body_p4_1 = body_p4;
        auto arity_p6_2 = arity_p6;
        auto clauses_p5_3 = clauses_p5;
        auto args_p3_4 = args_p3;
        auto lx_p0_5 = lx_p0;
        auto env_p1_6 = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=, body_p4_1 = std::move(body_p4_1), arity_p6_2 = std::move(arity_p6_2), clauses_p5_3 = std::move(clauses_p5_3), args_p3_4 = std::move(args_p3_4), lx_p0_5 = std::move(lx_p0_5), env_p1_6 = std::move(env_p1_6)](Nat p0) {
        return ({
            auto body_p4_1_7 = body_p4_1;
            auto arity_p6_2_7 = arity_p6_2;
            auto clauses_p5_3_7 = clauses_p5_3;
            auto args_p3_4_7 = args_p3_4;
            auto lx_p0_5_7 = lx_p0_5;
            auto env_p1_6_7 = env_p1_6;
            entered(once_job([=, body_p4_1_7 = std::move(body_p4_1_7), arity_p6_2_7 = std::move(arity_p6_2_7), clauses_p5_3_7 = std::move(clauses_p5_3_7), args_p3_4_7 = std::move(args_p3_4_7), lx_p0_5_7 = std::move(lx_p0_5_7), env_p1_6_7 = std::move(env_p1_6_7)]() {
            return ({
                auto j_p7 = p0;
                (len(body_p4_1_7) > Nat(0u)) && ((j_p7 + Nat(1u)) == arity_p6_2_7)
                ? prism_rtl::finished(or_(index(body_p4_1_7, Nat(0u)), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})))
                : ({
                auto&& _m = attr_at(clauses_p5_3_7, j_p7, args_p3_4_7);
                prism_rtl::is_some(_m) ? ({
                auto&& a_p8 = prism_rtl::some_of(_m);
                prism_rtl::more(prism_rtl::rc(crate::lower::expr::Argument(lx_p0_5_7, env_p1_6_7, a_p8->value)));
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::expr::refusal(prism_rtl::cat("a template call that fills no argument at place ", j_p7)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Ex>> TemplateArgs::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& qk_p2 = this->qk_p2;
    const auto& args_p3 = this->args_p3;
    const auto& body_p4 = this->body_p4;
    auto clauses_p5 = crate::lower::jobs::clauses_of(prism_rtl::deref(lx_p0).g, qk_p2);
    auto arity_p6 = len(prism_rtl::deref(or_(index(clauses_p5, Nat(0u)), crate::lower::functions::dummy_clause())).params);
    return each_job(crate::check::errors::range0(arity_p6), ({
        auto body_p4_1 = body_p4;
        auto arity_p6_2 = arity_p6;
        auto clauses_p5_3 = clauses_p5;
        auto args_p3_4 = args_p3;
        auto lx_p0_5 = lx_p0;
        auto env_p1_6 = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=, body_p4_1 = std::move(body_p4_1), arity_p6_2 = std::move(arity_p6_2), clauses_p5_3 = std::move(clauses_p5_3), args_p3_4 = std::move(args_p3_4), lx_p0_5 = std::move(lx_p0_5), env_p1_6 = std::move(env_p1_6)](Nat p0) {
        return ({
            auto body_p4_1_7 = body_p4_1;
            auto arity_p6_2_7 = arity_p6_2;
            auto clauses_p5_3_7 = clauses_p5_3;
            auto args_p3_4_7 = args_p3_4;
            auto lx_p0_5_7 = lx_p0_5;
            auto env_p1_6_7 = env_p1_6;
            entered(once_job([=, body_p4_1_7 = std::move(body_p4_1_7), arity_p6_2_7 = std::move(arity_p6_2_7), clauses_p5_3_7 = std::move(clauses_p5_3_7), args_p3_4_7 = std::move(args_p3_4_7), lx_p0_5_7 = std::move(lx_p0_5_7), env_p1_6_7 = std::move(env_p1_6_7)]() {
            return ({
                auto j_p7 = p0;
                (len(body_p4_1_7) > Nat(0u)) && ((j_p7 + Nat(1u)) == arity_p6_2_7)
                ? prism_rtl::finished(or_(index(body_p4_1_7, Nat(0u)), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})))
                : ({
                auto&& _m = attr_at(clauses_p5_3_7, j_p7, args_p3_4_7);
                prism_rtl::is_some(_m) ? ({
                auto&& a_p8 = prism_rtl::some_of(_m);
                prism_rtl::more(prism_rtl::rc(crate::lower::expr::Argument(lx_p0_5_7, env_p1_6_7, a_p8->value)));
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::expr::refusal(prism_rtl::cat("a template call that fills no argument at place ", j_p7)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start TemplateArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_template_args(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text qk_p2, Array<crate::syntax::Arg> args_p3, Array<crate::lower::model::Ex> body_p4) {
    return prism_rtl::make_rc<TemplateArgs>(lx_p0, env_p1, qk_p2, args_p3, body_p4);
}


/// ?AttrAt: fn [FnClause], Nat, [Arg] -> ?Arg
std::optional<crate::syntax::Arg> attr_at(const Array<crate::syntax::decls::FnClause>& clauses_p0, const Nat& j_p1, const Array<crate::syntax::Arg>& args_p2) {
    auto names_p7 = fold(clauses_p0, Array<Text>{}, [&](const Array<Text>& acc_p3, const crate::syntax::decls::FnClause& c_p4) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = index(prism_rtl::deref(c_p4).params, j_p1);
            if (prism_rtl::is_some(_m)) {
                auto&& p_p5 = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = place_name(p_p5);
                    if (prism_rtl::is_some(_m)) {
                        auto&& n_p6 = prism_rtl::some_of(_m);
                        _v.set(crate::check::types::add_text(acc_p3, n_p6));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc_p3);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc_p3);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    return fold(args_p2, std::optional<crate::syntax::Arg>{}, [&](const std::optional<crate::syntax::Arg>& found_o8, const crate::syntax::Arg& a_p9) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::syntax::Arg>> _v;
            auto&& _m = prism_rtl::deref(a_p9).name;
            if (prism_rtl::is_some(_m)) {
                auto&& n_pa = prism_rtl::some_of(_m);
                _v.set(crate::check::types::has_text(names_p7, prism_rtl::deref(n_pa).name)
                    ? std::optional(a_p9)
                    : found_o8);
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(found_o8);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// ?PlaceName: fn Pattern -> ?Text
std::optional<Text> place_name(const crate::syntax::Pattern_& p_p0) {
    auto&& _m = prism_rtl::deref(p_p0.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return std::optional(crate::check::env::dotted(n_p1->path_));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_p2 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return place_name(prism_rtl::deref(prism_rtl::deref(q_p2)));
    }
    {
        return std::optional<Text>{};
    }
}


/// ShownText: fn Vl -> Ex
crate::lower::model::Ex shown_text(const crate::lower::types::Vl& v_p0) {
    auto&& _m = crate::lower::types::value_ty(v_p0);
    if (prism_rtl::is<crate::lower::model::OutTy::OutText>(_m)) {
        return crate::lower::types::ref_(v_p0);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutChar>(_m)) {
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XFormat{Array(std::vector{crate::lower::types::ref_(v_p0)})}))});
    }
    {
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("show_text"), Array(std::vector{crate::lower::types::ref_(v_p0)})}))});
    }
}


/// GivenValue: unbounded fn Lx, Env, Block, OutTy, Range -> Vl
crate::lower::types::Vl given_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Block& b_p2, const crate::lower::model::OutTy& t_p3, const crate::syntax::Range& span_p4) {
    auto label_p5 = prism_rtl::cat("\'g", span_p4.start);
    auto is_try_p6 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p3)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto n_p7 = len(b_p2.stmts);
    auto [dos_po, env2_pp, last_oq] = run_to_end(fold_job(crate::check::errors::range0(n_p7), std::tuple{Array<crate::lower::model::Do>{}, env_p1, std::optional<crate::lower::types::Vl>{}}, ({
        auto b_p2_1 = b_p2;
        auto is_try_p6_2 = std::move(is_try_p6);
        auto lx_p0_3 = lx_p0;
        auto label_p5_4 = label_p5;
        auto n_p7_5 = n_p7;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat>)>>(prism_rtl::rc([=, b_p2_1 = std::move(b_p2_1), is_try_p6_2 = std::move(is_try_p6_2), lx_p0_3 = std::move(lx_p0_3), label_p5_4 = std::move(label_p5_4), n_p7_5 = std::move(n_p7_5)](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_p2_1_6 = b_p2_1;
            auto is_try_p6_2_6 = is_try_p6_2;
            auto lx_p0_3_6 = lx_p0_3;
            auto label_p5_4_6 = label_p5_4;
            auto n_p7_5_6 = n_p7_5;
            entered(once_job([=, b_p2_1_6 = std::move(b_p2_1_6), is_try_p6_2_6 = std::move(is_try_p6_2_6), lx_p0_3_6 = std::move(lx_p0_3_6), label_p5_4_6 = std::move(label_p5_4_6), n_p7_5_6 = std::move(n_p7_5_6)]() {
            return ({
                auto [acc_p9, en_pa, lv_ob] = p0;
                auto i_pc = p1;
                ({
                auto s_pd = or_(index(b_p2_1_6.stmts, i_pc), crate::lower::expr::dummy_stmt_l());
                auto fail_pe = is_try_p6_2_6
                    ? crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Error::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("Prelude.Unmet")}), crate::lower::model::Ex(crate::lower::model::Ex::XStr{source_text(lx_p0_3_6, prism_rtl::deref(s_pd).span)})})})})})
                    : crate::lower::model::Ex(crate::lower::model::Ex::XNone{});
                ({
                auto&& _m = prism_rtl::deref(s_pd).kind;
                prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
                auto&& p_pf = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
                auto&& x_pg = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
                ({
                auto p_pf_6 = p_pf;
                auto x_pg_7 = x_pg;
                call_then(crate::lower::expr::start_value_of(lx_p0_3_6, en_pa, x_pg_7), [=, p_pf_6 = std::move(p_pf_6)](crate::lower::types::Vl value_of_5940) {
                return ({
                    auto v_ph = value_of_5940;
                    call_then(crate::lower::patterns::start_rust_pat(lx_p0_3_6, p_pf_6, crate::lower::patterns::inner_ty(crate::lower::type_at(lx_p0_3_6, prism_rtl::deref(x_pg_7).span)), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("g", prism_rtl::deref(prism_rtl::deref(s_pd).span).start)), [=, v_ph = std::move(v_ph)](crate::lower::patterns::PatOut rust_pat_5983) {
                    return ({
                        auto po_pi = rust_pat_5983;
                        call_then(crate::lower::types::start_out_ty_of(lx_p0_3_6, crate::lower::patterns::inner_ty(crate::lower::type_at(lx_p0_3_6, prism_rtl::deref(x_pg_7).span))), [=, po_pi = std::move(po_pi)](crate::lower::model::OutTy out_ty_of_6125) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, given_bind(is_try_p6_2_6, prism_rtl::deref(po_pi).pa, crate::lower::types::own(v_ph), label_p5_4_6, out_ty_of_6125)), crate::lower::expr::bind_all(en_pa, prism_rtl::deref(po_pi).binds), lv_ob}); });
                    });
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m) ? ({
                auto&& c_pj = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
                ({
                auto c_pj_6 = c_pj;
                call_then(crate::lower::expr::start_value_of(lx_p0_3_6, en_pa, c_pj_6), [=](crate::lower::types::Vl value_of_6266) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("!"), prism_rtl::rc(crate::lower::types::as_bool(value_of_6266))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label_p5_4_6, prism_rtl::rc(fail_pe)})})}), Array<crate::lower::model::Do>{}})), en_pa, lv_ob}); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m) ? ({
                auto&& c_pk = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
                ({
                auto c_pk_6 = c_pk;
                call_then(crate::lower::expr::start_value_of(lx_p0_3_6, en_pa, c_pk_6), [=](crate::lower::types::Vl value_of_6390) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::types::as_bool(value_of_6390), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label_p5_4_6, prism_rtl::rc(fail_pe)})})}), Array<crate::lower::model::Do>{}})), en_pa, lv_ob}); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& x_pl = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                (i_pc + Nat(1u)) == n_p7_5_6
                ? prism_rtl::finished(std::tuple{acc_p9, en_pa, std::optional(crate::lower::expr::value_of(lx_p0_3_6, en_pa, x_pl))})
                : ({
                auto x_pl_6 = x_pl;
                call_then(crate::lower::expr::start_value_of(lx_p0_3_6, en_pa, x_pl_6), [=](crate::lower::types::Vl value_of_6598) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own(value_of_6598)})), en_pa, lv_ob}); });
            });
            })
                : call_then(crate::lower::expr::start_block_stmt(lx_p0_3_6, en_pa, s_pd), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt_6690) {
                return ({
                    auto [more_pm, en2_pn] = block_stmt_6690;
                    (prism_rtl::finished(std::tuple{append(acc_p9, more_pm), en2_pn, lv_ob}));
                });
            });
            });
            });
            });
        }));
        });
    }));
    })));
    auto last_p8 = or_(last_oq, crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XNone{}), t_p3}));
    return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XLabeled{label_p5, dos_po, prism_rtl::rc(crate::lower::types::own(last_p8)), t_p3}), t_p3});
}


prism_rtl::Turn<crate::lower::types::Vl> GivenValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& b_p2 = this->b_p2;
    const auto& t_p3 = this->t_p3;
    const auto& span_p4 = this->span_p4;
    auto label_p5 = prism_rtl::cat("\'g", prism_rtl::deref(span_p4).start);
    auto is_try_p6 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p3)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto n_p7 = len(prism_rtl::deref(b_p2).stmts);
    auto b_p2_1 = b_p2;
    auto env_p1_2 = env_p1;
    auto lx_p0_3 = lx_p0;
    auto span_p4_4 = span_p4;
    auto t_p3_5 = t_p3;
    return call_value(fold_job(crate::check::errors::range0(n_p7), std::tuple{Array<crate::lower::model::Do>{}, env_p1_2, std::optional<crate::lower::types::Vl>{}}, ({
        auto b_p2_1_6 = b_p2_1;
        auto is_try_p6_6 = std::move(is_try_p6);
        auto lx_p0_3_7 = lx_p0_3;
        auto label_p5_7 = label_p5;
        auto n_p7_8 = n_p7;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat>)>>(prism_rtl::rc([=, b_p2_1_6 = std::move(b_p2_1_6), is_try_p6_6 = std::move(is_try_p6_6), lx_p0_3_7 = std::move(lx_p0_3_7), label_p5_7 = std::move(label_p5_7), n_p7_8 = std::move(n_p7_8)](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_p2_1_6_9 = b_p2_1_6;
            auto is_try_p6_6_9 = is_try_p6_6;
            auto lx_p0_3_7_9 = lx_p0_3_7;
            auto label_p5_7_9 = label_p5_7;
            auto n_p7_8_9 = n_p7_8;
            entered(once_job([=, b_p2_1_6_9 = std::move(b_p2_1_6_9), is_try_p6_6_9 = std::move(is_try_p6_6_9), lx_p0_3_7_9 = std::move(lx_p0_3_7_9), label_p5_7_9 = std::move(label_p5_7_9), n_p7_8_9 = std::move(n_p7_8_9)]() {
            return ({
                auto [acc_p9, en_pa, lv_ob] = p0;
                auto i_pc = p1;
                ({
                auto s_pd = or_(index(prism_rtl::deref(b_p2_1_6_9).stmts, i_pc), crate::lower::expr::dummy_stmt_l());
                auto fail_pe = is_try_p6_6_9
                    ? crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Error::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("Prelude.Unmet")}), crate::lower::model::Ex(crate::lower::model::Ex::XStr{source_text(lx_p0_3_7_9, prism_rtl::deref(s_pd).span)})})})})})
                    : crate::lower::model::Ex(crate::lower::model::Ex::XNone{});
                ({
                auto&& _m = prism_rtl::deref(s_pd).kind;
                prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
                auto&& p_pf = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
                auto&& x_pg = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
                ({
                auto p_pf_9 = p_pf;
                auto x_pg_10 = x_pg;
                call_then(crate::lower::expr::start_value_of(lx_p0_3_7_9, en_pa, x_pg_10), [=, p_pf_9 = std::move(p_pf_9)](crate::lower::types::Vl value_of_5940) {
                return ({
                    auto v_ph = value_of_5940;
                    call_then(crate::lower::patterns::start_rust_pat(lx_p0_3_7_9, p_pf_9, crate::lower::patterns::inner_ty(crate::lower::type_at(lx_p0_3_7_9, prism_rtl::deref(x_pg_10).span)), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("g", prism_rtl::deref(prism_rtl::deref(s_pd).span).start)), [=, v_ph = std::move(v_ph)](crate::lower::patterns::PatOut rust_pat_5983) {
                    return ({
                        auto po_pi = rust_pat_5983;
                        call_then(crate::lower::types::start_out_ty_of(lx_p0_3_7_9, crate::lower::patterns::inner_ty(crate::lower::type_at(lx_p0_3_7_9, prism_rtl::deref(x_pg_10).span))), [=, po_pi = std::move(po_pi)](crate::lower::model::OutTy out_ty_of_6125) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, given_bind(is_try_p6_6_9, prism_rtl::deref(po_pi).pa, crate::lower::types::own(v_ph), label_p5_7_9, out_ty_of_6125)), crate::lower::expr::bind_all(en_pa, prism_rtl::deref(po_pi).binds), lv_ob}); });
                    });
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m) ? ({
                auto&& c_pj = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
                ({
                auto c_pj_9 = c_pj;
                call_then(crate::lower::expr::start_value_of(lx_p0_3_7_9, en_pa, c_pj_9), [=](crate::lower::types::Vl value_of_6266) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("!"), prism_rtl::rc(crate::lower::types::as_bool(value_of_6266))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label_p5_7_9, prism_rtl::rc(fail_pe)})})}), Array<crate::lower::model::Do>{}})), en_pa, lv_ob}); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m) ? ({
                auto&& c_pk = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
                ({
                auto c_pk_9 = c_pk;
                call_then(crate::lower::expr::start_value_of(lx_p0_3_7_9, en_pa, c_pk_9), [=](crate::lower::types::Vl value_of_6390) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::types::as_bool(value_of_6390), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label_p5_7_9, prism_rtl::rc(fail_pe)})})}), Array<crate::lower::model::Do>{}})), en_pa, lv_ob}); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& x_pl = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                (i_pc + Nat(1u)) == n_p7_8_9
                ? prism_rtl::finished(std::tuple{acc_p9, en_pa, std::optional(crate::lower::expr::value_of(lx_p0_3_7_9, en_pa, x_pl))})
                : ({
                auto x_pl_9 = x_pl;
                call_then(crate::lower::expr::start_value_of(lx_p0_3_7_9, en_pa, x_pl_9), [=](crate::lower::types::Vl value_of_6598) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own(value_of_6598)})), en_pa, lv_ob}); });
            });
            })
                : call_then(crate::lower::expr::start_block_stmt(lx_p0_3_7_9, en_pa, s_pd), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt_6690) {
                return ({
                    auto [more_pm, en2_pn] = block_stmt_6690;
                    (prism_rtl::finished(std::tuple{append(acc_p9, more_pm), en2_pn, lv_ob}));
                });
            });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>> fold_5624) {
        return ({
            auto [dos_po, env2_pp, last_oq] = fold_5624;
            auto last_p8 = or_(last_oq, crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XNone{}), t_p3_5}));
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XLabeled{label_p5, dos_po, prism_rtl::rc(crate::lower::types::own(last_p8)), t_p3_5}), t_p3_5})));
        });
    });
}


/// `Start GivenValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_given_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Block b_p2, crate::lower::model::OutTy t_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<GivenValue>(lx_p0, env_p1, b_p2, t_p3, span_p4);
}


/// GivenBind: fn Bool, Pa, Ex, Text, OutTy -> Do
crate::lower::model::Do given_bind(const bool& is_try_p0, const crate::lower::model::Pa& pa_p1, const crate::lower::model::Ex& x_p2, const Text& label_p3, const crate::lower::model::OutTy& t_p4) {
    return is_try_p0
        ? crate::lower::model::Do(crate::lower::model::Do::DoLet{pa_p1, crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(x_p2), Array(std::vector{crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Ok"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("e")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label_p3, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("e")})})}))})}}), false, t_p4})})
        : crate::lower::model::Do(crate::lower::model::Do::DoLetElse{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{pa_p1})}), x_p2, crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label_p3, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNone{}))})});
}


/// SourceText: fn Lx, Range -> Text
Text source_text(const crate::lower::Lx& lx_p0, const crate::syntax::Range& r_p1) {
    auto&& _m = index(prism_rtl::deref(lx_p0.g).srcs, lx_p0.file);
    if (prism_rtl::is_some(_m)) {
        auto&& src_p2 = prism_rtl::some_of(_m);
        return crate::check::errors::span_text(src_p2, r_p1);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// UpdateValue: unbounded fn Lx, Env, Expr, Block, OutTy, Range -> Vl
crate::lower::types::Vl update_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& target_p2, const crate::syntax::Block& b_p3, const crate::lower::model::OutTy& t_p4, const crate::syntax::Range& span_p5) {
    auto tv_p6 = crate::lower::expr::value_of(lx_p0, env_p1, target_p2);
    auto env1_p7 = crate::lower::types::bind(env_p1, Text::lit("&_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_p4}));
    auto&& _dos_p8 = upd_stmts(lx_p0, env1_p7, b_p3.stmts);
    auto&& dos_p8 = std::get<0>(_dos_p8);
    return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("this")})), t_p4}), crate::lower::types::own(tv_p6)})}), dos_p8), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}))}), t_p4});
}


prism_rtl::Turn<crate::lower::types::Vl> UpdateValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& target_p2 = this->target_p2;
    const auto& b_p3 = this->b_p3;
    const auto& t_p4 = this->t_p4;
    const auto& span_p5 = this->span_p5;
    auto b_p3_1 = b_p3;
    auto env_p1_2 = env_p1;
    auto lx_p0_3 = lx_p0;
    auto t_p4_4 = t_p4;
    auto target_p2_5 = target_p2;
    return call_then(crate::lower::expr::start_value_of(lx_p0_3, env_p1_2, target_p2_5), [=](crate::lower::types::Vl value_of_7889) {
        return ({
            auto tv_p6 = value_of_7889;
            auto env1_p7 = crate::lower::types::bind(env_p1_2, Text::lit("&_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_p4_4}));
            call_then(start_upd_stmts(lx_p0_3, env1_p7, prism_rtl::deref(b_p3_1).stmts), [=, tv_p6 = std::move(tv_p6)](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_8004) {
            return ({
                auto&& _dos_p8 = upd_stmts_8004;
                auto&& dos_p8 = std::get<0>(_dos_p8);
                (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("this")})), t_p4_4}), crate::lower::types::own(tv_p6)})}), dos_p8), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}))}), t_p4_4})));
            });
        });
        });
    });
}


/// `Start UpdateValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_update_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr target_p2, crate::syntax::Block b_p3, crate::lower::model::OutTy t_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<UpdateValue>(lx_p0, env_p1, target_p2, b_p3, t_p4, span_p5);
}


/// UpdStmts: unbounded fn Lx, Env, [Stmt] -> (([Do], Env))
std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::Stmt>& stmts_p2) {
    return run_to_end(fold_job(stmts_p2, std::tuple{Array<crate::lower::model::Do>{}, env_p1}, ({
        auto lx_p0_1 = lx_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, crate::syntax::Stmt>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_2 = lx_p0_1;
            entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
            return ({
                auto [acc_p3, en_p4] = p0;
                auto s_p5 = p1;
                call_then(start_upd_stmt(lx_p0_1_2, en_p4, s_p5), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmt_8289) {
                return ({
                    auto [more_p6, en2_p7] = upd_stmt_8289;
                    (prism_rtl::finished(std::tuple{append(acc_p3, more_p6), en2_p7}));
                });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> UpdStmts::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& stmts_p2 = this->stmts_p2;
    return fold_job(stmts_p2, std::tuple{Array<crate::lower::model::Do>{}, env_p1}, ({
        auto lx_p0_1 = lx_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, crate::syntax::Stmt>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_2 = lx_p0_1;
            entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
            return ({
                auto [acc_p3, en_p4] = p0;
                auto s_p5 = p1;
                call_then(start_upd_stmt(lx_p0_1_2, en_p4, s_p5), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmt_8289) {
                return ({
                    auto [more_p6, en2_p7] = upd_stmt_8289;
                    (prism_rtl::finished(std::tuple{append(acc_p3, more_p6), en2_p7}));
                });
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start UpdStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_upd_stmts(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Stmt> stmts_p2) {
    return prism_rtl::make_rc<UpdStmts>(lx_p0, env_p1, stmts_p2);
}


/// UpdStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmt(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Stmt& s_p2) {
    auto&& _m = s_p2.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
        auto&& target_p3 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value_p4 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        auto v_p5 = crate::lower::types::own(crate::lower::expr::value_of(lx_p0, env_p1, value_p4));
        return std::tuple{Array(std::vector{assign(lx_p0, env_p1, target_p3, v_p5)}), env_p1};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
        auto&& target_p6 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& op_p7 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a1;
        auto&& value_p8 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        auto cur_p9 = place_of(lx_p0, env_p1, target_p6);
        auto tt_pa = crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, prism_rtl::deref(target_p6).span)));
        auto rv_pb = crate::lower::expr::value_of(lx_p0, env_p1, value_p8);
        auto bin_pc = crate::syntax::lexer::chars::head(op_p7);
        auto next_pd = crate::lower::expr::op_value(lx_p0, bin_pc, crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{cur_p9, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), tt_pa}), rv_pb, s_p2.span, tt_pa);
        return std::tuple{Array(std::vector{assign(lx_p0, env_p1, target_p6, crate::lower::types::own(next_pd))}), env_p1};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_pe = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& x_pf = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto v_pg = crate::lower::types::own(crate::lower::expr::value_of(lx_p0, env_p1, x_pf));
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_pe).kind);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n_ph = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n_ph).sigils, Text::lit("&"))
                ? ({
                auto rs_pi = crate::lower::local_name_at(lx_p0, crate::check::env::sname_key(n_ph), prism_rtl::deref(n_ph).span);
                auto bt_pj = crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::binder_ty(lx_p0, prism_rtl::deref(n_ph).span)));
                auto pa_pk = crate::lower::expr::is_known_ty(bt_pj)
                    ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(rs_pi)})), bt_pj})
                    : crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(rs_pi)});
                std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{pa_pk, v_pg})}), crate::lower::types::bind(env_p1, crate::check::env::sname_key(n_ph), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_pi}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_pj}))};
            })
                : crate::lower::expr::block_stmt(lx_p0, env_p1, s_p2);
        }
        {
            return crate::lower::expr::block_stmt(lx_p0, env_p1, s_p2);
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& c_pl = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& body_pm = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        auto&& _inner_pn = upd_stmts(lx_p0, env_p1, prism_rtl::deref(body_pm).stmts);
        auto&& inner_pn = std::get<0>(_inner_pn);
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c_pl)) {
            auto&& x_po = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_pl).a0;
            return std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoWhile{crate::lower::types::as_bool(crate::lower::expr::value_of(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_po)))), inner_pn})}), env_p1};
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c_pl)) {
            auto&& p_pp = prism_rtl::as<crate::syntax::Cond::CondBind>(c_pl).a0;
            auto&& x_pq = prism_rtl::as<crate::syntax::Cond::CondBind>(c_pl).a1;
            auto&& g_or = prism_rtl::as<crate::syntax::Cond::CondBind>(c_pl).a2;
            auto po_ps = crate::lower::patterns::rust_pat(lx_p0, p_pp, crate::lower::type_at(lx_p0, prism_rtl::deref(x_pq).span), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("w", prism_rtl::deref(s_p2.span).start));
            auto env_b_pt = crate::lower::expr::bind_all(env_p1, prism_rtl::deref(po_ps).binds);
            auto&& _inner2_p13 = upd_stmts(lx_p0, env_b_pt, prism_rtl::deref(body_pm).stmts);
            auto&& inner2_p13 = std::get<0>(_inner2_p13);
            auto conds_pu = append(prism_rtl::deref(po_ps).conds, guard_conds(lx_p0, env_b_pt, prism_rtl::deref(prism_rtl::deref(g_or))));
            auto tests_pv = fold(conds_pu, Array<crate::lower::model::Ex>{}, [&](const Array<crate::lower::model::Ex>& acc_p14, const crate::lower::model::Cc& c_p15) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(c_p15)) {
                        auto&& t_p16 = prism_rtl::as<crate::lower::model::Cc::CcIf>(c_p15).a0;
                        _v.set(crate::prelude::push(acc_p14, t_p16));
                        goto _done;
                    }
                    {
                        _v.set(acc_p14);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            auto lets_p10 = fold(conds_pu, false, [&](const bool& f_p17, const crate::lower::model::Cc& c_p18) { return prism_rtl::deref(f_p17) || crate::lower::expr::is_let_cond(c_p18); });
            auto stop_p11 = len(tests_pv) == Nat(0u)
                ? Array<crate::lower::model::Do>{}
                : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("!"), prism_rtl::rc(all_of(tests_pv))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("break")})})}), Array<crate::lower::model::Do>{}})});
            auto body2_p12 = std::move(lets_p10)
                ? Array(std::vector{crate::lower::expr::refusal_do(Text::lit("a `while` whose pattern matches through an `Rc`"))})
                : append(stop_p11, inner2_p13);
            return std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoWhileLet{prism_rtl::deref(po_ps).pa, crate::lower::types::own(crate::lower::expr::value_of(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pq)))), body2_p12})}), env_p1};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& x_p19 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p19).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& c_p1a = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& then_b_p1b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b_o1c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            return std::tuple{Array(std::vector{upd_if(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(c_p1a)), then_b_p1b, else_b_o1c)}), env_p1};
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& scrut_p1d = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms_p1e = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            return std::tuple{Array(std::vector{upd_match(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(scrut_p1d)), arms_p1e)}), env_p1};
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
            auto&& binders_o1f = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
            auto&& source_p1g = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
            auto&& body_p1h = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
            return std::tuple{Array(std::vector{upd_for(lx_p0, env_p1, binders_o1f, prism_rtl::deref(prism_rtl::deref(source_p1g)), body_p1h, prism_rtl::deref(x_p19).span)}), env_p1};
        }
        {
            return std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own(crate::lower::expr::value_of(lx_p0, env_p1, x_p19))})}), env_p1};
        }
    }
    {
        return crate::lower::expr::block_stmt(lx_p0, env_p1, s_p2);
    }
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> UpdStmt::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& s_p2 = this->s_p2;
    return ({
        auto&& _m = prism_rtl::deref(s_p2).kind;
        prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& target_p3 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value_p4 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        ({
        auto env_p1_1 = env_p1;
        auto lx_p0_2 = lx_p0;
        auto target_p3_3 = target_p3;
        auto value_p4_4 = value_p4;
        call_then(crate::lower::expr::start_value_of(lx_p0_2, env_p1_1, value_p4_4), [=, target_p3_3 = std::move(target_p3_3)](crate::lower::types::Vl value_of_8476) {
        return ({
            auto v_p5 = crate::lower::types::own(value_of_8476);
            call_then(start_assign(lx_p0_2, env_p1_1, target_p3_3, v_p5), [=](crate::lower::model::Do assign_8513) { return prism_rtl::finished(std::tuple{Array(std::vector{assign_8513}), env_p1_1}); });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& target_p6 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& op_p7 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a1;
        auto&& value_p8 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        ({
        auto env_p1_1 = env_p1;
        auto lx_p0_2 = lx_p0;
        auto op_p7_3 = op_p7;
        auto s_p2_4 = s_p2;
        auto target_p6_5 = target_p6;
        auto value_p8_6 = value_p8;
        call_then(start_place_of(lx_p0_2, env_p1_1, target_p6_5), [=, op_p7_3 = std::move(op_p7_3), s_p2_4 = std::move(s_p2_4), value_p8_6 = std::move(value_p8_6)](crate::lower::model::Ex place_of_8597) {
        return ({
            auto cur_p9 = place_of_8597;
            call_then(crate::lower::types::start_out_ty_of(lx_p0_2, crate::lower::types::peel(crate::lower::type_at(lx_p0_2, prism_rtl::deref(target_p6_5).span))), [=, cur_p9 = std::move(cur_p9)](crate::lower::model::OutTy out_ty_of_8638) {
            return ({
                auto tt_pa = out_ty_of_8638;
                call_then(crate::lower::expr::start_value_of(lx_p0_2, env_p1_1, value_p8_6), [=, tt_pa = std::move(tt_pa)](crate::lower::types::Vl value_of_8699) {
                return ({
                    auto rv_pb = value_of_8699;
                    auto bin_pc = crate::syntax::lexer::chars::head(op_p7_3);
                    auto next_pd = crate::lower::expr::op_value(lx_p0_2, bin_pc, crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{cur_p9, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), tt_pa}), rv_pb, prism_rtl::deref(s_p2_4).span, tt_pa);
                    call_then(start_assign(lx_p0_2, env_p1_1, target_p6_5, crate::lower::types::own(next_pd)), [=](crate::lower::model::Do assign_8838) { return prism_rtl::finished(std::tuple{Array(std::vector{assign_8838}), env_p1_1}); });
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_pe = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& x_pf = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto env_p1_1 = env_p1;
        auto lx_p0_2 = lx_p0;
        auto p_pe_3 = p_pe;
        auto s_p2_4 = s_p2;
        auto x_pf_5 = x_pf;
        call_then(crate::lower::expr::start_value_of(lx_p0_2, env_p1_1, x_pf_5), [=, p_pe_3 = std::move(p_pe_3), s_p2_4 = std::move(s_p2_4)](crate::lower::types::Vl value_of_8927) {
        return ({
            auto v_pg = crate::lower::types::own(value_of_8927);
            ({
            auto&& _m = prism_rtl::deref(prism_rtl::deref(p_pe_3).kind);
            prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
            auto&& n_ph = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n_ph).sigils, Text::lit("&"))
            ? ({
            auto n_ph_6 = n_ph;
            call_then(crate::lower::start_local_name_at(lx_p0_2, crate::check::env::sname_key(n_ph_6), prism_rtl::deref(n_ph_6).span), [=](Text local_name_at_9065) {
            return ({
                auto rs_pi = local_name_at_9065;
                call_then(crate::lower::types::start_out_ty_of(lx_p0_2, crate::lower::types::peel(crate::lower::binder_ty(lx_p0_2, prism_rtl::deref(n_ph_6).span))), [=, rs_pi = std::move(rs_pi)](crate::lower::model::OutTy out_ty_of_9131) {
                return ({
                    auto bt_pj = out_ty_of_9131;
                    call_then(crate::lower::expr::start_is_known_ty(bt_pj), [=](bool is_known_ty_9204) {
                    return ({
                        auto pa_pk = is_known_ty_9204
                            ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(rs_pi)})), bt_pj})
                            : crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(rs_pi)});
                        (prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{pa_pk, v_pg})}), crate::lower::types::bind(env_p1_1, crate::check::env::sname_key(n_ph_6), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_pi}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_pj}))}));
                    });
                });
                });
            });
            });
        });
        })
            : prism_rtl::more(prism_rtl::rc(crate::lower::expr::BlockStmt(lx_p0_2, env_p1_1, s_p2_4)));
        })
            : prism_rtl::more(prism_rtl::rc(crate::lower::expr::BlockStmt(lx_p0_2, env_p1_1, s_p2_4)));
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
        auto&& c_pl = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& body_pm = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        ({
        auto body_pm_1 = body_pm;
        auto c_pl_2 = c_pl;
        auto env_p1_3 = env_p1;
        auto lx_p0_4 = lx_p0;
        auto s_p2_5 = s_p2;
        call_then(start_upd_stmts(lx_p0_4, env_p1_3, prism_rtl::deref(body_pm_1).stmts), [=, c_pl_2 = std::move(c_pl_2), s_p2_5 = std::move(s_p2_5)](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_9503) {
        return ({
            auto&& _inner_pn = upd_stmts_9503;
            auto&& inner_pn = std::get<0>(_inner_pn);
            ({
            prism_rtl::is<crate::syntax::Cond::CondExpr>(c_pl_2) ? ({
            auto&& x_po = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_pl_2).a0;
            ({
            auto x_po_6 = prism_rtl::deref(prism_rtl::deref(x_po));
            call_then(crate::lower::expr::start_value_of(lx_p0_4, env_p1_3, x_po_6), [=](crate::lower::types::Vl value_of_9595) { return prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoWhile{crate::lower::types::as_bool(value_of_9595), inner_pn})}), env_p1_3}); });
        });
        })
            : prism_rtl::is<crate::syntax::Cond::CondBind>(c_pl_2) ? ({
            auto&& p_pp = prism_rtl::as<crate::syntax::Cond::CondBind>(c_pl_2).a0;
            auto&& x_pq = prism_rtl::as<crate::syntax::Cond::CondBind>(c_pl_2).a1;
            auto&& g_or = prism_rtl::as<crate::syntax::Cond::CondBind>(c_pl_2).a2;
            ({
            auto g_or_6 = prism_rtl::deref(prism_rtl::deref(g_or));
            auto p_pp_7 = p_pp;
            auto x_pq_8 = prism_rtl::deref(prism_rtl::deref(x_pq));
            call_then(crate::lower::patterns::start_rust_pat(lx_p0_4, p_pp_7, crate::lower::type_at(lx_p0_4, prism_rtl::deref(x_pq_8).span), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("w", prism_rtl::deref(prism_rtl::deref(s_p2_5).span).start)), [=, g_or_6 = std::move(g_or_6)](crate::lower::patterns::PatOut rust_pat_9689) {
            return ({
                auto po_ps = rust_pat_9689;
                auto env_b_pt = crate::lower::expr::bind_all(env_p1_3, prism_rtl::deref(po_ps).binds);
                call_then(start_upd_stmts(lx_p0_4, env_b_pt, prism_rtl::deref(body_pm_1).stmts), [=, po_ps = std::move(po_ps)](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_9840) {
                return ({
                    auto&& _inner2_p13 = upd_stmts_9840;
                    auto&& inner2_p13 = std::get<0>(_inner2_p13);
                    call_then(start_guard_conds(lx_p0_4, env_b_pt, g_or_6), [=](Array<crate::lower::model::Cc> guard_conds_10098) {
                    return ({
                        auto conds_pu = append(prism_rtl::deref(po_ps).conds, guard_conds_10098);
                        auto tests_pv = fold(conds_pu, Array<crate::lower::model::Ex>{}, [&](const Array<crate::lower::model::Ex>& acc_p14, const crate::lower::model::Cc& c_p15) {
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                                if (prism_rtl::is<crate::lower::model::Cc::CcIf>(c_p15)) {
                                    auto&& t_p16 = prism_rtl::as<crate::lower::model::Cc::CcIf>(c_p15).a0;
                                    _v.set(crate::prelude::push(acc_p14, t_p16));
                                    goto _done;
                                }
                                {
                                    _v.set(acc_p14);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        });
                        auto lets_p10 = fold(conds_pu, false, [&](const bool& f_p17, const crate::lower::model::Cc& c_p18) { return prism_rtl::deref(f_p17) || crate::lower::expr::is_let_cond(c_p18); });
                        auto stop_p11 = len(tests_pv) == Nat(0u)
                            ? Array<crate::lower::model::Do>{}
                            : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("!"), prism_rtl::rc(all_of(tests_pv))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("break")})})}), Array<crate::lower::model::Do>{}})});
                        auto body2_p12 = std::move(lets_p10)
                            ? Array(std::vector{crate::lower::expr::refusal_do(Text::lit("a `while` whose pattern matches through an `Rc`"))})
                            : append(stop_p11, inner2_p13);
                        call_then(crate::lower::expr::start_value_of(lx_p0_4, env_p1_3, x_pq_8), [=, body2_p12 = std::move(body2_p12)](crate::lower::types::Vl value_of_10637) { return prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoWhileLet{prism_rtl::deref(po_ps).pa, crate::lower::types::own(value_of_10637), body2_p12})}), env_p1_3}); });
                    });
                });
                });
            });
            });
        });
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& x_p19 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p19).kind);
        prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c_p1a = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_p1b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_o1c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        ({
        auto else_b_o1c_1 = else_b_o1c;
        auto c_p1a_2 = prism_rtl::deref(prism_rtl::deref(c_p1a));
        auto env_p1_3 = env_p1;
        auto lx_p0_4 = lx_p0;
        auto then_b_p1b_5 = then_b_p1b;
        call_then(start_upd_if(lx_p0_4, env_p1_3, c_p1a_2, then_b_p1b_5, else_b_o1c_1), [=](crate::lower::model::Do upd_if_10737) { return prism_rtl::finished(std::tuple{Array(std::vector{upd_if_10737}), env_p1_3}); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& scrut_p1d = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p1e = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        ({
        auto arms_p1e_1 = arms_p1e;
        auto env_p1_2 = env_p1;
        auto lx_p0_3 = lx_p0;
        auto scrut_p1d_4 = prism_rtl::deref(prism_rtl::deref(scrut_p1d));
        call_then(start_upd_match(lx_p0_3, env_p1_2, scrut_p1d_4, arms_p1e_1), [=](crate::lower::model::Do upd_match_10812) { return prism_rtl::finished(std::tuple{Array(std::vector{upd_match_10812}), env_p1_2}); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& binders_o1f = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source_p1g = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body_p1h = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        ({
        auto binders_o1f_1 = binders_o1f;
        auto body_p1h_2 = body_p1h;
        auto env_p1_3 = env_p1;
        auto lx_p0_4 = lx_p0;
        auto source_p1g_5 = prism_rtl::deref(prism_rtl::deref(source_p1g));
        auto x_p19_6 = x_p19;
        call_then(start_upd_for(lx_p0_4, env_p1_3, binders_o1f_1, source_p1g_5, body_p1h_2, prism_rtl::deref(x_p19_6).span), [=](crate::lower::model::Do upd_for_10894) { return prism_rtl::finished(std::tuple{Array(std::vector{upd_for_10894}), env_p1_3}); });
    });
    })
        : ({
        auto env_p1_1 = env_p1;
        auto lx_p0_2 = lx_p0;
        auto x_p19_3 = x_p19;
        call_then(crate::lower::expr::start_value_of(lx_p0_2, env_p1_1, x_p19_3), [=](crate::lower::types::Vl value_of_10987) { return prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own(value_of_10987)})}), env_p1_1}); });
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(crate::lower::expr::BlockStmt(lx_p0, env_p1, s_p2)));
    });
}


/// `Start UpdStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_upd_stmt(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Stmt s_p2) {
    return prism_rtl::make_rc<UpdStmt>(lx_p0, env_p1, s_p2);
}


/// UpdFor: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range -> Do
crate::lower::model::Do upd_for(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const std::optional<crate::syntax::ForBinders>& binders_o2, const crate::syntax::Expr& source_p3, const crate::syntax::Block& body_p4, const crate::syntax::Range& span_p5) {
    auto sty_p6 = crate::lower::types::peel(crate::lower::type_at(lx_p0, source_p3.span));
    auto&& _m = ref_binder(binders_o2);
    if (prism_rtl::is_some(_m)) {
        auto&& n_p7 = prism_rtl::some_of(_m);
        return is_ref_path(source_p3)
            ? upd_for_refs(lx_p0, env_p1, n_p7, source_p3, body_p4, span_p5, sty_p6)
            : upd_for_values(lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5, sty_p6);
    }
    if (prism_rtl::is_none(_m)) {
        return upd_for_values(lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5, sty_p6);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Do> UpdFor::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& binders_o2 = this->binders_o2;
    const auto& source_p3 = this->source_p3;
    const auto& body_p4 = this->body_p4;
    const auto& span_p5 = this->span_p5;
    auto sty_p6 = crate::lower::types::peel(crate::lower::type_at(lx_p0, prism_rtl::deref(source_p3).span));
    return ({
        auto&& _m = ref_binder(binders_o2);
        prism_rtl::is_some(_m) ? ({
        auto&& n_p7 = prism_rtl::some_of(_m);
        is_ref_path(source_p3)
        ? prism_rtl::more(prism_rtl::rc(UpdForRefs(lx_p0, env_p1, n_p7, source_p3, body_p4, span_p5, sty_p6)))
        : prism_rtl::more(prism_rtl::rc(UpdForValues(lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5, sty_p6)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(UpdForValues(lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5, sty_p6)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start UpdFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_upd_for(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, std::optional<crate::syntax::ForBinders> binders_o2, crate::syntax::Expr source_p3, crate::syntax::Block body_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<UpdFor>(lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5);
}


/// UpdForRefs: unbounded fn Lx, Env, SName, Expr, Block, Range, Ty -> Do
crate::lower::model::Do upd_for_refs(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::SName& n_p2, const crate::syntax::Expr& source_p3, const crate::syntax::Block& body_p4, const crate::syntax::Range& span_p5, const crate::check::types::Ty& sty_p6) {
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty_p6)) {
        auto&& v_p7 = prism_rtl::as<crate::check::types::Ty::TyArray>(sty_p6).a0;
        auto key_name_p8 = prism_rtl::cat("k", span_p5.start);
        auto ref_name_p9 = prism_rtl::cat("r", span_p5.start);
        auto env1_pa = crate::lower::types::bind(crate::lower::types::bind(crate::lower::types::bind(env_p1, Text::lit("key"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_p8}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})})), Text::lit("ix"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_p8}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})})), crate::check::env::sname_key(n_p2), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XTarget{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{ref_name_p9}))}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::types::out_ty_of(lx_p0, prism_rtl::deref(prism_rtl::deref(v_p7)))}));
        auto&& _dos_pc = upd_stmts(lx_p0, env1_pa, body_p4.stmts);
        auto&& dos_pc = std::get<0>(_dos_pc);
        auto head_pb = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name_p8}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("nat_of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("i", span_p5.start)})})})});
        return crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("i", span_p5.start)}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{ref_name_p9})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(place_of(lx_p0, env_p1, source_p3)), Text::lit("iter_mut"), Array<crate::lower::model::Ex>{}})), Text::lit("enumerate"), Array<crate::lower::model::Ex>{}}), append(Array(std::vector{head_pb}), dos_pc)});
    }
    {
        return crate::lower::expr::refusal_do(Text::lit("a `for` by reference over what is not an array"));
    }
}


prism_rtl::Turn<crate::lower::model::Do> UpdForRefs::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& n_p2 = this->n_p2;
    const auto& source_p3 = this->source_p3;
    const auto& body_p4 = this->body_p4;
    const auto& span_p5 = this->span_p5;
    const auto& sty_p6 = this->sty_p6;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyArray>(sty_p6) ? ({
        auto&& v_p7 = prism_rtl::as<crate::check::types::Ty::TyArray>(sty_p6).a0;
        ({
        auto key_name_p8 = prism_rtl::cat("k", prism_rtl::deref(span_p5).start);
        auto ref_name_p9 = prism_rtl::cat("r", prism_rtl::deref(span_p5).start);
        auto body_p4_1 = body_p4;
        auto env_p1_2 = env_p1;
        auto lx_p0_3 = lx_p0;
        auto n_p2_4 = n_p2;
        auto source_p3_5 = source_p3;
        auto span_p5_6 = span_p5;
        auto v_p7_7 = prism_rtl::deref(prism_rtl::deref(v_p7));
        call_then(crate::lower::types::start_out_ty_of(lx_p0_3, v_p7_7), [=, key_name_p8 = std::move(key_name_p8), ref_name_p9 = std::move(ref_name_p9), body_p4_1 = std::move(body_p4_1), env_p1_2 = std::move(env_p1_2), n_p2_4 = std::move(n_p2_4), source_p3_5 = std::move(source_p3_5), span_p5_6 = std::move(span_p5_6)](crate::lower::model::OutTy out_ty_of_12347) {
        return ({
            auto env1_pa = crate::lower::types::bind(crate::lower::types::bind(crate::lower::types::bind(env_p1_2, Text::lit("key"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_p8}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})})), Text::lit("ix"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_p8}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})})), crate::check::env::sname_key(n_p2_4), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XTarget{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{ref_name_p9}))}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), out_ty_of_12347}));
            call_then(start_upd_stmts(lx_p0_3, env1_pa, prism_rtl::deref(body_p4_1).stmts), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_12393) {
            return ({
                auto&& _dos_pc = upd_stmts_12393;
                auto&& dos_pc = std::get<0>(_dos_pc);
                auto head_pb = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name_p8}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("nat_of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("i", prism_rtl::deref(span_p5_6).start)})})})});
                call_then(start_place_of(lx_p0_3, env_p1_2, source_p3_5), [=, head_pb = std::move(head_pb)](crate::lower::model::Ex place_of_12602) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("i", prism_rtl::deref(span_p5_6).start)}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{ref_name_p9})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(place_of_12602), Text::lit("iter_mut"), Array<crate::lower::model::Ex>{}})), Text::lit("enumerate"), Array<crate::lower::model::Ex>{}}), append(Array(std::vector{head_pb}), dos_pc)})); });
            });
        });
        });
    });
    });
    })
        : prism_rtl::finished(crate::lower::expr::refusal_do(Text::lit("a `for` by reference over what is not an array")));
    });
}


/// `Start UpdForRefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_upd_for_refs(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::SName n_p2, crate::syntax::Expr source_p3, crate::syntax::Block body_p4, crate::syntax::Range span_p5, crate::check::types::Ty sty_p6) {
    return prism_rtl::make_rc<UpdForRefs>(lx_p0, env_p1, n_p2, source_p3, body_p4, span_p5, sty_p6);
}


/// ?RefBinder: fn ?ForBinders -> ?SName
std::optional<crate::syntax::SName> ref_binder(const std::optional<crate::syntax::ForBinders>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& fb_p0 = prism_rtl::some_of(opt0);
        auto&& _m = prism_rtl::deref(fb_p0).second;
        if (prism_rtl::is_none(_m)) {
            auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(fb_p0).first).kind);
            if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                auto&& n_p1 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                return crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n_p1).sigils, Text::lit("&"))
                    ? std::optional(n_p1)
                    : std::optional<crate::syntax::SName>{};
            }
            {
                return std::optional<crate::syntax::SName>{};
            }
        }
        {
            return std::optional<crate::syntax::SName>{};
        }
    }
    if (prism_rtl::is_none(opt0)) {
        return std::optional<crate::syntax::SName>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsRefPath: fn Expr -> Bool
bool is_ref_path(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n_p1).sigils, Text::lit("&"));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r_p2 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        return is_ref_path(prism_rtl::deref(prism_rtl::deref(r_p2)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r_p3 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        return is_ref_path(prism_rtl::deref(prism_rtl::deref(r_p3)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_ref_path(prism_rtl::deref(prism_rtl::deref(x_p4)));
    }
    {
        return false;
    }
}


/// UpdForValues: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range, Ty -> Do
crate::lower::model::Do upd_for_values(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const std::optional<crate::syntax::ForBinders>& binders_o2, const crate::syntax::Expr& source_p3, const crate::syntax::Block& body_p4, const crate::syntax::Range& span_p5, const crate::check::types::Ty& sty_p6) {
    auto src_p7 = crate::lower::types::own(crate::lower::expr::value_of(lx_p0, env_p1, source_p3));
    auto [kt_pf, vt_pg, is_array_ph] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy, bool>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty_p6)) {
            auto&& v_pc = prism_rtl::as<crate::check::types::Ty::TyArray>(sty_p6).a0;
            _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}), crate::lower::types::out_ty_of(lx_p0, prism_rtl::deref(prism_rtl::deref(v_pc))), true});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty_p6)) {
            auto&& k_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_p6).a0;
            auto&& v_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_p6).a1;
            _v.set(std::tuple{crate::lower::types::out_ty_of(lx_p0, prism_rtl::deref(prism_rtl::deref(k_pd))), crate::lower::types::out_ty_of(lx_p0, prism_rtl::deref(prism_rtl::deref(v_pe))), false});
            goto _done;
        }
        {
            _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), true});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [vty_pl, kty_pm] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::Ty>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty_p6)) {
            auto&& v_pi = prism_rtl::as<crate::check::types::Ty::TyArray>(sty_p6).a0;
            _v.set(std::tuple{prism_rtl::deref(prism_rtl::deref(v_pi)), crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Nat"), Array<crate::check::types::Ty>{}})});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty_p6)) {
            auto&& k_pj = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_p6).a0;
            auto&& v_pk = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_p6).a1;
            _v.set(std::tuple{prism_rtl::deref(prism_rtl::deref(v_pk)), prism_rtl::deref(prism_rtl::deref(k_pj))});
            goto _done;
        }
        {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto key_name_p8 = prism_rtl::cat("k", span_p5.start);
    auto val_name_p9 = prism_rtl::cat("v", span_p5.start);
    auto env1_pa = crate::lower::types::bind(crate::lower::types::bind(env_p1, Text::lit("key"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_p8}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt_pf})), Text::lit("_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name_p9}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), vt_pg}));
    auto env2_pb = is_array_ph
        ? crate::lower::types::bind(env1_pa, Text::lit("ix"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_p8}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt_pf}))
        : env1_pa;
    auto [binds_ps, env3_pt] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
        if (prism_rtl::is_none(binders_o2)) {
            _v.set(std::tuple{Array<crate::lower::model::Do>{}, env2_pb});
            goto _done;
        }
        if (prism_rtl::is_some(binders_o2)) {
            auto&& fb_pn = prism_rtl::some_of(binders_o2);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                auto&& _m = prism_rtl::deref(fb_pn).second;
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto po_po = crate::lower::patterns::rust_pat(lx_p0, prism_rtl::deref(fb_pn).first, vty_pl, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("e", span_p5.start));
                        std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(po_po).pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name_p9}))})})}), crate::lower::expr::bind_all(env2_pb, prism_rtl::deref(po_po).binds)};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_some(_m)) {
                    auto&& second_pp = prism_rtl::some_of(_m);
                    _v.set(({
                        auto pk_pq = crate::lower::patterns::rust_pat(lx_p0, prism_rtl::deref(fb_pn).first, kty_pm, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("k", span_p5.start, "_"));
                        auto pv_pr = crate::lower::patterns::rust_pat(lx_p0, second_pp, vty_pl, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("e", span_p5.start));
                        std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(pk_pq).pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_p8}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(pv_pr).pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name_p9}))})})}), crate::lower::expr::bind_all(crate::lower::expr::bind_all(env2_pb, prism_rtl::deref(pk_pq).binds), prism_rtl::deref(pv_pr).binds)};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _dos_pu = upd_stmts(lx_p0, env3_pt, body_p4.stmts);
    auto&& dos_pu = std::get<0>(_dos_pu);
    return is_array_ph
        ? ({
        auto head_pv = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name_p8}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("nat_of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("i", span_p5.start)})})})});
        (crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("i", span_p5.start)}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name_p9})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src_p7), Text::lit("into_iter"), Array<crate::lower::model::Ex>{}})), Text::lit("enumerate"), Array<crate::lower::model::Ex>{}}), append(crate::prelude::push(Array<crate::lower::model::Do>{}, head_pv), append(binds_ps, dos_pu))}));
    })
        : crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name_p8}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name_p9})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src_p7), Text::lit("into_iter"), Array<crate::lower::model::Ex>{}}), append(binds_ps, dos_pu)});
}


prism_rtl::Turn<crate::lower::model::Do> UpdForValues::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& binders_o2 = this->binders_o2;
    const auto& source_p3 = this->source_p3;
    const auto& body_p4 = this->body_p4;
    const auto& span_p5 = this->span_p5;
    const auto& sty_p6 = this->sty_p6;
    auto binders_o2_1 = binders_o2;
    auto body_p4_2 = body_p4;
    auto env_p1_3 = env_p1;
    auto lx_p0_4 = lx_p0;
    auto source_p3_5 = source_p3;
    auto span_p5_6 = span_p5;
    auto sty_p6_7 = sty_p6;
    return call_then(crate::lower::expr::start_value_of(lx_p0_4, env_p1_3, source_p3_5), [=](crate::lower::types::Vl value_of_13497) {
        return ({
            auto src_p7 = crate::lower::types::own(value_of_13497);
            auto [kt_pf, vt_pg, is_array_ph] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy, bool>> _v;
                if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty_p6_7)) {
                    auto&& v_pc = prism_rtl::as<crate::check::types::Ty::TyArray>(sty_p6_7).a0;
                    _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}), crate::lower::types::out_ty_of(lx_p0_4, prism_rtl::deref(prism_rtl::deref(v_pc))), true});
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty_p6_7)) {
                    auto&& k_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_p6_7).a0;
                    auto&& v_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_p6_7).a1;
                    _v.set(std::tuple{crate::lower::types::out_ty_of(lx_p0_4, prism_rtl::deref(prism_rtl::deref(k_pd))), crate::lower::types::out_ty_of(lx_p0_4, prism_rtl::deref(prism_rtl::deref(v_pe))), false});
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), true});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [vty_pl, kty_pm] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::Ty>> _v;
                if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty_p6_7)) {
                    auto&& v_pi = prism_rtl::as<crate::check::types::Ty::TyArray>(sty_p6_7).a0;
                    _v.set(std::tuple{prism_rtl::deref(prism_rtl::deref(v_pi)), crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Nat"), Array<crate::check::types::Ty>{}})});
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty_p6_7)) {
                    auto&& k_pj = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_p6_7).a0;
                    auto&& v_pk = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_p6_7).a1;
                    _v.set(std::tuple{prism_rtl::deref(prism_rtl::deref(v_pk)), prism_rtl::deref(prism_rtl::deref(k_pj))});
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto key_name_p8 = prism_rtl::cat("k", prism_rtl::deref(span_p5_6).start);
            auto val_name_p9 = prism_rtl::cat("v", prism_rtl::deref(span_p5_6).start);
            auto env1_pa = crate::lower::types::bind(crate::lower::types::bind(env_p1_3, Text::lit("key"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_p8}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt_pf})), Text::lit("_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name_p9}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), vt_pg}));
            auto env2_pb = is_array_ph
                ? crate::lower::types::bind(env1_pa, Text::lit("ix"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_p8}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt_pf}))
                : env1_pa;
            auto [binds_ps, env3_pt] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                if (prism_rtl::is_none(binders_o2_1)) {
                    _v.set(std::tuple{Array<crate::lower::model::Do>{}, env2_pb});
                    goto _done;
                }
                if (prism_rtl::is_some(binders_o2_1)) {
                    auto&& fb_pn = prism_rtl::some_of(binders_o2_1);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                        auto&& _m = prism_rtl::deref(fb_pn).second;
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                auto po_po = crate::lower::patterns::rust_pat(lx_p0_4, prism_rtl::deref(fb_pn).first, vty_pl, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("e", prism_rtl::deref(span_p5_6).start));
                                std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(po_po).pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name_p9}))})})}), crate::lower::expr::bind_all(env2_pb, prism_rtl::deref(po_po).binds)};
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_some(_m)) {
                            auto&& second_pp = prism_rtl::some_of(_m);
                            _v.set(({
                                auto pk_pq = crate::lower::patterns::rust_pat(lx_p0_4, prism_rtl::deref(fb_pn).first, kty_pm, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("k", prism_rtl::deref(span_p5_6).start, "_"));
                                auto pv_pr = crate::lower::patterns::rust_pat(lx_p0_4, second_pp, vty_pl, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("e", prism_rtl::deref(span_p5_6).start));
                                std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(pk_pq).pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_p8}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(pv_pr).pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name_p9}))})})}), crate::lower::expr::bind_all(crate::lower::expr::bind_all(env2_pb, prism_rtl::deref(pk_pq).binds), prism_rtl::deref(pv_pr).binds)};
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            call_then(start_upd_stmts(lx_p0_4, env3_pt, prism_rtl::deref(body_p4_2).stmts), [=, src_p7 = std::move(src_p7), key_name_p8 = std::move(key_name_p8), val_name_p9 = std::move(val_name_p9)](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_14778) {
            return ({
                auto&& _dos_pu = upd_stmts_14778;
                auto&& dos_pu = std::get<0>(_dos_pu);
                is_array_ph
                ? ({
                auto head_pv = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name_p8}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("nat_of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("i", prism_rtl::deref(span_p5_6).start)})})})});
                (prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("i", prism_rtl::deref(span_p5_6).start)}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name_p9})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src_p7), Text::lit("into_iter"), Array<crate::lower::model::Ex>{}})), Text::lit("enumerate"), Array<crate::lower::model::Ex>{}}), append(crate::prelude::push(Array<crate::lower::model::Do>{}, head_pv), append(binds_ps, dos_pu))})));
            })
                : prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name_p8}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name_p9})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src_p7), Text::lit("into_iter"), Array<crate::lower::model::Ex>{}}), append(binds_ps, dos_pu)}));
            });
        });
        });
    });
}


/// `Start UpdForValues, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_upd_for_values(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, std::optional<crate::syntax::ForBinders> binders_o2, crate::syntax::Expr source_p3, crate::syntax::Block body_p4, crate::syntax::Range span_p5, crate::check::types::Ty sty_p6) {
    return prism_rtl::make_rc<UpdForValues>(lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5, sty_p6);
}


/// UpdIf: unbounded fn Lx, Env, Cond, Block, ?Block -> Do
crate::lower::model::Do upd_if(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Cond& c_p2, const crate::syntax::Block& then_b_p3, const std::optional<crate::syntax::Block>& else_b_o4) {
    auto&& _else_dos_p6 = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
        if (prism_rtl::is_some(else_b_o4)) {
            auto&& b_p5 = prism_rtl::some_of(else_b_o4);
            _v.set(upd_stmts(lx_p0, env_p1, prism_rtl::deref(b_p5).stmts));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_o4)) {
            _v.set(std::tuple{Array<crate::lower::model::Do>{}, env_p1});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& else_dos_p6 = std::get<0>(_else_dos_p6);
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p2)) {
        auto&& x_p7 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p2).a0;
        auto&& _then_dos_p8 = upd_stmts(lx_p0, env_p1, then_b_p3.stmts);
        auto&& then_dos_p8 = std::get<0>(_then_dos_p8);
        return crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::types::as_bool(crate::lower::expr::value_of(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p7)))), then_dos_p8, else_dos_p6});
    }
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(c_p2)) {
        auto&& p_p9 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a0;
        auto&& x_pa = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a1;
        auto po_pb = crate::lower::patterns::rust_pat(lx_p0, p_p9, crate::lower::type_at(lx_p0, prism_rtl::deref(x_pa).span), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("u", prism_rtl::deref(prism_rtl::deref(x_pa).span).start));
        auto&& _then_dos_pc = upd_stmts(lx_p0, crate::lower::expr::bind_all(env_p1, prism_rtl::deref(po_pb).binds), then_b_p3.stmts);
        auto&& then_dos_pc = std::get<0>(_then_dos_pc);
        return crate::lower::model::Do(crate::lower::model::Do::DoIfLet{prism_rtl::deref(po_pb).pa, crate::lower::types::own(crate::lower::expr::value_of(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pa)))), then_dos_pc, else_dos_p6});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Do> UpdIf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& c_p2 = this->c_p2;
    const auto& then_b_p3 = this->then_b_p3;
    const auto& else_b_o4 = this->else_b_o4;
    auto&& _else_dos_p6 = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
        if (prism_rtl::is_some(else_b_o4)) {
            auto&& b_p5 = prism_rtl::some_of(else_b_o4);
            _v.set(upd_stmts(lx_p0, env_p1, prism_rtl::deref(b_p5).stmts));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_o4)) {
            _v.set(std::tuple{Array<crate::lower::model::Do>{}, env_p1});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& else_dos_p6 = std::get<0>(_else_dos_p6);
    return ({
        prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p2) ? ({
        auto&& x_p7 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p2).a0;
        ({
        auto env_p1_1 = env_p1;
        auto lx_p0_2 = lx_p0;
        auto then_b_p3_3 = then_b_p3;
        auto x_p7_4 = prism_rtl::deref(prism_rtl::deref(x_p7));
        call_then(start_upd_stmts(lx_p0_2, env_p1_1, prism_rtl::deref(then_b_p3_3).stmts), [=, x_p7_4 = std::move(x_p7_4)](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_15488) {
        return ({
            auto&& _then_dos_p8 = upd_stmts_15488;
            auto&& then_dos_p8 = std::get<0>(_then_dos_p8);
            call_then(crate::lower::expr::start_value_of(lx_p0_2, env_p1_1, x_p7_4), [=](crate::lower::types::Vl value_of_15544) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::types::as_bool(value_of_15544), then_dos_p8, else_dos_p6})); });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::Cond::CondBind>(c_p2) ? ({
        auto&& p_p9 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a0;
        auto&& x_pa = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a1;
        ({
        auto env_p1_1 = env_p1;
        auto lx_p0_2 = lx_p0;
        auto p_p9_3 = p_p9;
        auto then_b_p3_4 = then_b_p3;
        auto x_pa_5 = prism_rtl::deref(prism_rtl::deref(x_pa));
        call_then(crate::lower::patterns::start_rust_pat(lx_p0_2, p_p9_3, crate::lower::type_at(lx_p0_2, prism_rtl::deref(x_pa_5).span), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("u", prism_rtl::deref(prism_rtl::deref(x_pa_5).span).start)), [=, env_p1_1 = std::move(env_p1_1), then_b_p3_4 = std::move(then_b_p3_4)](crate::lower::patterns::PatOut rust_pat_15635) {
        return ({
            auto po_pb = rust_pat_15635;
            call_then(start_upd_stmts(lx_p0_2, crate::lower::expr::bind_all(env_p1_1, prism_rtl::deref(po_pb).binds), prism_rtl::deref(then_b_p3_4).stmts), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_15734) {
            return ({
                auto&& _then_dos_pc = upd_stmts_15734;
                auto&& then_dos_pc = std::get<0>(_then_dos_pc);
                call_then(crate::lower::expr::start_value_of(lx_p0_2, env_p1_1, x_pa_5), [=](crate::lower::types::Vl value_of_15817) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoIfLet{prism_rtl::deref(po_pb).pa, crate::lower::types::own(value_of_15817), then_dos_pc, else_dos_p6})); });
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start UpdIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_upd_if(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Cond c_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4) {
    return prism_rtl::make_rc<UpdIf>(lx_p0, env_p1, c_p2, then_b_p3, else_b_o4);
}


/// UpdMatch: unbounded fn Lx, Env, Expr, [Arm] -> Do
crate::lower::model::Do upd_match(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& scrut_p2, const Array<crate::syntax::Arm>& arms_p3) {
    auto sv_p4 = crate::lower::expr::value_of(lx_p0, env_p1, scrut_p2);
    auto sty_p5 = crate::lower::type_at(lx_p0, scrut_p2.span);
    auto arms3_p6 = run_to_end(each_job(crate::check::errors::range0(len(arms_p3)), ({
        auto arms_p3_1 = arms_p3;
        auto lx_p0_2 = lx_p0;
        auto sty_p5_3 = sty_p5;
        auto scrut_p2_4 = scrut_p2;
        auto env_p1_5 = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=, arms_p3_1 = std::move(arms_p3_1), lx_p0_2 = std::move(lx_p0_2), sty_p5_3 = std::move(sty_p5_3), scrut_p2_4 = std::move(scrut_p2_4), env_p1_5 = std::move(env_p1_5)](Nat p0) {
        return ({
            auto arms_p3_1_6 = arms_p3_1;
            auto lx_p0_2_6 = lx_p0_2;
            auto sty_p5_3_6 = sty_p5_3;
            auto scrut_p2_4_6 = scrut_p2_4;
            auto env_p1_5_6 = env_p1_5;
            entered(once_job([=, arms_p3_1_6 = std::move(arms_p3_1_6), lx_p0_2_6 = std::move(lx_p0_2_6), sty_p5_3_6 = std::move(sty_p5_3_6), scrut_p2_4_6 = std::move(scrut_p2_4_6), env_p1_5_6 = std::move(env_p1_5_6)]() {
            return ({
                auto i_p7 = p0;
                ({
                auto arm_p8 = or_(index(arms_p3_1_6, i_p7), crate::lower::expr::dummy_arm());
                call_then(crate::lower::expr::start_arm_pat(lx_p0_2_6, prism_rtl::deref(arm_p8).pattern, sty_p5_3_6, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat("u", prism_rtl::deref(scrut_p2_4_6.span).start, "_", i_p7)), [=](crate::lower::patterns::PatOut arm_pat_16116) {
                return ({
                    auto po_p9 = arm_pat_16116;
                    call_then(start_upd_stmts(lx_p0_2_6, crate::lower::expr::bind_all(env_p1_5_6, prism_rtl::deref(po_p9).binds), prism_rtl::deref(prism_rtl::deref(arm_p8).body).stmts), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_16209) {
                    return ({
                        auto&& _dos_pb = upd_stmts_16209;
                        auto&& dos_pb = std::get<0>(_dos_pb);
                        call_then(start_guard_conds(lx_p0_2_6, crate::lower::expr::bind_all(env_p1_5_6, prism_rtl::deref(po_p9).binds), prism_rtl::deref(arm_p8).guard), [=](Array<crate::lower::model::Cc> guard_conds_16302) {
                        return ({
                            auto guarded_pa = append(prism_rtl::deref(po_p9).conds, guard_conds_16302);
                            (prism_rtl::finished(crate::lower::model::XArm{.pat = prism_rtl::deref(po_p9).pa, .conds = guarded_pa, .body = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_pb, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))})}));
                        });
                    });
                    });
                });
                });
            });
            });
            });
        }));
        });
    })));
    })));
    return fold(arms3_p6, false, [&](const bool& f_pc, const crate::lower::model::XArm& a_pd) { return prism_rtl::deref(f_pc) || (len(prism_rtl::deref(a_pd).conds) > Nat(0u)); })
        ? crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own(crate::lower::expr::arms_value(crate::lower::types::ref_(sv_p4), arms3_p6, prism_rtl::cat("\'u", prism_rtl::deref(scrut_p2.span).start), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})
        : crate::lower::model::Do(crate::lower::model::Do::DoMatch{crate::lower::types::ref_(sv_p4), each(arms3_p6, [&](const crate::lower::model::XArm& a_pe) { return std::tuple{prism_rtl::deref(a_pe).pat, arm_dos(prism_rtl::deref(a_pe).body)}; })});
}


prism_rtl::Turn<crate::lower::model::Do> UpdMatch::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& scrut_p2 = this->scrut_p2;
    const auto& arms_p3 = this->arms_p3;
    auto arms_p3_1 = arms_p3;
    auto env_p1_2 = env_p1;
    auto lx_p0_3 = lx_p0;
    auto scrut_p2_4 = scrut_p2;
    return call_then(crate::lower::expr::start_value_of(lx_p0_3, env_p1_2, scrut_p2_4), [=](crate::lower::types::Vl value_of_15954) {
        return ({
            auto sv_p4 = value_of_15954;
            auto sty_p5 = crate::lower::type_at(lx_p0_3, prism_rtl::deref(scrut_p2_4).span);
            call_value(each_job(crate::check::errors::range0(len(arms_p3_1)), ({
            auto arms_p3_1_5 = arms_p3_1;
            auto lx_p0_3_5 = lx_p0_3;
            auto sty_p5_5 = sty_p5;
            auto scrut_p2_4_6 = scrut_p2_4;
            auto env_p1_2_6 = env_p1_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=, arms_p3_1_5 = std::move(arms_p3_1_5), lx_p0_3_5 = std::move(lx_p0_3_5), sty_p5_5 = std::move(sty_p5_5), scrut_p2_4_6 = std::move(scrut_p2_4_6), env_p1_2_6 = std::move(env_p1_2_6)](Nat p0) {
            return ({
                auto arms_p3_1_5_6 = arms_p3_1_5;
                auto lx_p0_3_5_6 = lx_p0_3_5;
                auto sty_p5_5_6 = sty_p5_5;
                auto scrut_p2_4_6_6 = scrut_p2_4_6;
                auto env_p1_2_6_6 = env_p1_2_6;
                entered(once_job([=, arms_p3_1_5_6 = std::move(arms_p3_1_5_6), lx_p0_3_5_6 = std::move(lx_p0_3_5_6), sty_p5_5_6 = std::move(sty_p5_5_6), scrut_p2_4_6_6 = std::move(scrut_p2_4_6_6), env_p1_2_6_6 = std::move(env_p1_2_6_6)]() {
                return ({
                    auto i_p7 = p0;
                    ({
                    auto arm_p8 = or_(index(arms_p3_1_5_6, i_p7), crate::lower::expr::dummy_arm());
                    call_then(crate::lower::expr::start_arm_pat(lx_p0_3_5_6, prism_rtl::deref(arm_p8).pattern, sty_p5_5_6, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat("u", prism_rtl::deref(prism_rtl::deref(scrut_p2_4_6_6).span).start, "_", i_p7)), [=](crate::lower::patterns::PatOut arm_pat_16116) {
                    return ({
                        auto po_p9 = arm_pat_16116;
                        call_then(start_upd_stmts(lx_p0_3_5_6, crate::lower::expr::bind_all(env_p1_2_6_6, prism_rtl::deref(po_p9).binds), prism_rtl::deref(prism_rtl::deref(arm_p8).body).stmts), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_16209) {
                        return ({
                            auto&& _dos_pb = upd_stmts_16209;
                            auto&& dos_pb = std::get<0>(_dos_pb);
                            call_then(start_guard_conds(lx_p0_3_5_6, crate::lower::expr::bind_all(env_p1_2_6_6, prism_rtl::deref(po_p9).binds), prism_rtl::deref(arm_p8).guard), [=](Array<crate::lower::model::Cc> guard_conds_16302) {
                            return ({
                                auto guarded_pa = append(prism_rtl::deref(po_p9).conds, guard_conds_16302);
                                (prism_rtl::finished(crate::lower::model::XArm{.pat = prism_rtl::deref(po_p9).pa, .conds = guarded_pa, .body = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_pb, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))})}));
                            });
                        });
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        })));
        })), [=, sv_p4 = std::move(sv_p4)](Array<crate::lower::model::XArm> each_16029) {
            return ({
                auto arms3_p6 = each_16029;
                fold(arms3_p6, false, [&](const bool& f_pc, const crate::lower::model::XArm& a_pd) { return prism_rtl::deref(f_pc) || (len(prism_rtl::deref(a_pd).conds) > Nat(0u)); })
                ? prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own(crate::lower::expr::arms_value(crate::lower::types::ref_(sv_p4), arms3_p6, prism_rtl::cat("\'u", prism_rtl::deref(prism_rtl::deref(scrut_p2_4).span).start), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))}))
                : prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoMatch{crate::lower::types::ref_(sv_p4), each(arms3_p6, [&](const crate::lower::model::XArm& a_pe) { return std::tuple{prism_rtl::deref(a_pe).pat, arm_dos(prism_rtl::deref(a_pe).body)}; })}));
            });
        });
        });
    });
}


/// `Start UpdMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_upd_match(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr scrut_p2, Array<crate::syntax::Arm> arms_p3) {
    return prism_rtl::make_rc<UpdMatch>(lx_p0, env_p1, scrut_p2, arms_p3);
}


/// AllOf: fn [Ex] -> Ex
crate::lower::model::Ex all_of(const Array<crate::lower::model::Ex>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 1u) {
            {
                auto&& _c1 = index(c0_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one_p0 = prism_rtl::some_of(_c1);
                    return one_p0;
                }
            }
        }
    }
    {
        auto&& xs_p1 = xs0;
        return fold(drop(xs_p1, Nat(1u)), or_(index(xs_p1, Nat(0u)), crate::lower::model::Ex(crate::lower::model::Ex::XBool{true})), [&](const crate::lower::model::Ex& acc_p2, const crate::lower::model::Ex& x_p3) { return crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("&&"), prism_rtl::rc(acc_p2), prism_rtl::rc(x_p3)}); });
    }
}


/// ArmDos: fn Ex -> [Do]
Array<crate::lower::model::Do> arm_dos(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(ex0)) {
        auto&& dos_p0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex0).a0;
        return dos_p0;
    }
    {
        auto&& x_p1 = ex0;
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{x_p1})});
    }
}


/// GuardConds: unbounded fn Lx, Env, ?Expr -> [Cc]
Array<crate::lower::model::Cc> guard_conds(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const std::optional<crate::syntax::Expr>& opt2) {
    if (prism_rtl::is_some(opt2)) {
        auto&& ge_p2 = prism_rtl::some_of(opt2);
        return Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::types::as_bool(crate::lower::expr::value_of(lx_p0, env_p1, ge_p2))})});
    }
    if (prism_rtl::is_none(opt2)) {
        return Array<crate::lower::model::Cc>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::lower::model::Cc>> GuardConds::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& opt2 = this->opt2;
    return ({
        prism_rtl::is_some(opt2) ? ({
        auto&& ge_p2 = prism_rtl::some_of(opt2);
        ({
        auto env_p1_1 = env_p1;
        auto ge_p2_2 = ge_p2;
        auto lx_p0_3 = lx_p0;
        call_then(crate::lower::expr::start_value_of(lx_p0_3, env_p1_1, ge_p2_2), [=](crate::lower::types::Vl value_of_17144) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::types::as_bool(value_of_17144)})})); });
    });
    })
        : prism_rtl::is_none(opt2) ? prism_rtl::finished(Array<crate::lower::model::Cc>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start GuardConds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Cc>> start_guard_conds(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, std::optional<crate::syntax::Expr> opt2) {
    return prism_rtl::make_rc<GuardConds>(lx_p0, env_p1, opt2);
}


/// PlaceOf: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex place_of(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = prism_rtl::deref(e_p2.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto&& _m = crate::prelude::get(env_p1.names, crate::check::env::sname_key(n_p3));
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
            auto&& rs_p4 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            return rs_p4;
        }
        {
            return crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::snake(crate::check::env::sname_key(n_p3))});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r_p5 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& name_p6 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        return crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(place_of(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(r_p5)))), crate::lower::snake(prism_rtl::deref(name_p6).name)});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r_p7 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& k_p8 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        auto rt_p9 = crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, prism_rtl::deref(r_p7).span)));
        auto f_pa = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt_p9)) {
                _v.set(Text::lit("at_mut_map"));
                goto _done;
            }
            {
                _v.set(Text::lit("at_mut"));
                goto _done;
            }
        _done:
            _v.take();
        });
        return crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{f_pa, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(place_of(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(r_p7))))}), crate::lower::expr::argument(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(k_p8)))})}))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_pb = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return place_of(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pb)));
    }
    {
        return crate::lower::expr::refusal(Text::lit("a reference path this back end does not lower"));
    }
}


prism_rtl::Turn<crate::lower::model::Ex> PlaceOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto&& _m = crate::prelude::get(env_p1->names, crate::check::env::sname_key(n_p3));
        prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
        auto&& rs_p4 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
        prism_rtl::finished(rs_p4);
    })
        : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::snake(crate::check::env::sname_key(n_p3))}));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& r_p5 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& name_p6 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        ({
        auto env_p1_1 = env_p1;
        auto lx_p0_2 = lx_p0;
        auto name_p6_3 = name_p6;
        auto r_p5_4 = prism_rtl::deref(prism_rtl::deref(r_p5));
        call_then(start_place_of(lx_p0_2, env_p1_1, r_p5_4), [=, name_p6_3 = std::move(name_p6_3)](crate::lower::model::Ex place_of_17512) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(place_of_17512), crate::lower::snake(prism_rtl::deref(name_p6_3).name)})); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& r_p7 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& k_p8 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        ({
        auto env_p1_1 = env_p1;
        auto k_p8_2 = prism_rtl::deref(prism_rtl::deref(k_p8));
        auto lx_p0_3 = lx_p0;
        auto r_p7_4 = prism_rtl::deref(prism_rtl::deref(r_p7));
        call_then(crate::lower::types::start_out_ty_of(lx_p0_3, crate::lower::types::peel(crate::lower::type_at(lx_p0_3, prism_rtl::deref(r_p7_4).span))), [=, env_p1_1 = std::move(env_p1_1), k_p8_2 = std::move(k_p8_2)](crate::lower::model::OutTy out_ty_of_17585) {
        return ({
            auto rt_p9 = out_ty_of_17585;
            auto f_pa = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt_p9)) {
                    _v.set(Text::lit("at_mut_map"));
                    goto _done;
                }
                {
                    _v.set(Text::lit("at_mut"));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_then(start_place_of(lx_p0_3, env_p1_1, r_p7_4), [=, f_pa = std::move(f_pa)](crate::lower::model::Ex place_of_17767) { return call_then(crate::lower::expr::start_argument(lx_p0_3, env_p1_1, k_p8_2), [=](crate::lower::model::Ex argument_17790) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{f_pa, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(place_of_17767)}), argument_17790})}))})); }); });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_pb = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PlaceOf(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pb)))));
    })
        : prism_rtl::finished(crate::lower::expr::refusal(Text::lit("a reference path this back end does not lower")));
    });
}


/// `Start PlaceOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_place_of(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<PlaceOf>(lx_p0, env_p1, e_p2);
}


/// Assign: unbounded fn Lx, Env, Expr, Ex -> Do
crate::lower::model::Do assign(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& target_p2, const crate::lower::model::Ex& v_p3) {
    auto&& _m = prism_rtl::deref(target_p2.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r_p4 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& k_p5 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        auto rt_p6 = crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, prism_rtl::deref(r_p4).span)));
        auto f_p7 = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt_p6)) {
                _v.set(Text::lit("set_key"));
                goto _done;
            }
            {
                _v.set(Text::lit("set_index"));
                goto _done;
            }
        _done:
            _v.take();
        });
        return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{f_p7, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(place_of(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(r_p4))))}), crate::lower::expr::argument(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(k_p5))), v_p3})})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p8 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return assign(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p8)), v_p3);
    }
    {
        return crate::lower::model::Do(crate::lower::model::Do::DoAssign{place_of(lx_p0, env_p1, target_p2), v_p3});
    }
}


prism_rtl::Turn<crate::lower::model::Do> Assign::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& target_p2 = this->target_p2;
    const auto& v_p3 = this->v_p3;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(target_p2).kind);
        prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& r_p4 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& k_p5 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        ({
        auto env_p1_1 = env_p1;
        auto k_p5_2 = prism_rtl::deref(prism_rtl::deref(k_p5));
        auto lx_p0_3 = lx_p0;
        auto r_p4_4 = prism_rtl::deref(prism_rtl::deref(r_p4));
        auto v_p3_5 = v_p3;
        call_then(crate::lower::types::start_out_ty_of(lx_p0_3, crate::lower::types::peel(crate::lower::type_at(lx_p0_3, prism_rtl::deref(r_p4_4).span))), [=, env_p1_1 = std::move(env_p1_1), k_p5_2 = std::move(k_p5_2), v_p3_5 = std::move(v_p3_5)](crate::lower::model::OutTy out_ty_of_18198) {
        return ({
            auto rt_p6 = out_ty_of_18198;
            auto f_p7 = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt_p6)) {
                    _v.set(Text::lit("set_key"));
                    goto _done;
                }
                {
                    _v.set(Text::lit("set_index"));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_then(start_place_of(lx_p0_3, env_p1_1, r_p4_4), [=, f_p7 = std::move(f_p7)](crate::lower::model::Ex place_of_18380) { return call_then(crate::lower::expr::start_argument(lx_p0_3, env_p1_1, k_p5_2), [=](crate::lower::model::Ex argument_18403) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{f_p7, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(place_of_18380)}), argument_18403, v_p3_5})})})); }); });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p8 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Assign(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p8)), v_p3)));
    })
        : ({
        auto env_p1_1 = env_p1;
        auto lx_p0_2 = lx_p0;
        auto target_p2_3 = target_p2;
        auto v_p3_4 = v_p3;
        call_then(start_place_of(lx_p0_2, env_p1_1, target_p2_3), [=, v_p3_4 = std::move(v_p3_4)](crate::lower::model::Ex place_of_18490) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoAssign{place_of_18490, v_p3_4})); });
    });
    });
}


/// `Start Assign, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_assign(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr target_p2, crate::lower::model::Ex v_p3) {
    return prism_rtl::make_rc<Assign>(lx_p0, env_p1, target_p2, v_p3);
}

}  // namespace crate::lower::templates
