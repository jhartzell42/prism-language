// The modules `Syntax.Lexer.Templates`, `Syntax.Lexer.Words`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Syntax.Lexer.Templates`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/templates.prism`.
namespace crate::syntax::lexer::templates {

bool CallRead::operator==(const CallRead& o) const { return l == o.l && attrs == o.attrs && body == o.body && going == o.going; }

void CallRead::show(Printer& p) const {
    p.record("CallRead", {{"l", l}, {"attrs", attrs}, {"body", body}, {"going", going}});
}

Pod CallRead::to_pod() const {
    return Pod::record("CallRead", {{"l", prism_rtl::to_pod(l)}, {"attrs", prism_rtl::to_pod(attrs)}, {"body", prism_rtl::to_pod(body)}, {"going", prism_rtl::to_pod(going)}});
}

Result<CallRead> CallRead::from_pod(const Pod& whole) {
    return CallRead{.l = TRY(prism_rtl::from_pod<crate::syntax::lexer::Lex>(TRY(crate::prelude::field(whole, "l")))), .attrs = TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::AttrTok>>(TRY(crate::prelude::field(whole, "attrs")))), .body = TRY(prism_rtl::from_pod<std::optional<Array<crate::syntax::lexer::TPartTok>>>(TRY(crate::prelude::field(whole, "body")))), .going = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "going"))))};
}


bool RawItem::RiPlaceholder::operator==(const RiPlaceholder& o) const { return a0 == o.a0 && a1 == o.a1; }

bool RawItem::RiBlock::operator==(const RiBlock& o) const { return a0 == o.a0 && a1 == o.a1; }

bool RawItem::RiCall::operator==(const RiCall& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2 && a3 == o.a3; }

void RawItem::show(Printer& p) const {
    if (auto c = std::get_if<RiText>(&cases())) p.choice("RiText", {c->a0});
    else if (auto c = std::get_if<RiPlaceholder>(&cases())) p.choice("RiPlaceholder", {c->a0, c->a1});
    else if (auto c = std::get_if<RiBlock>(&cases())) p.choice("RiBlock", {c->a0, c->a1});
    else if (auto c = std::get_if<RiCall>(&cases())) p.choice("RiCall", {c->a0, c->a1, c->a2, c->a3});
}

Pod RawItem::to_pod() const {
    return std::holds_alternative<RiText>(cases()) ? Pod::choice("RiText", {prism_rtl::to_pod(std::get<RiText>(cases()).a0)})
        : std::holds_alternative<RiPlaceholder>(cases()) ? Pod::choice("RiPlaceholder", {prism_rtl::to_pod(std::get<RiPlaceholder>(cases()).a0), prism_rtl::to_pod(std::get<RiPlaceholder>(cases()).a1)})
        : std::holds_alternative<RiBlock>(cases()) ? Pod::choice("RiBlock", {prism_rtl::to_pod(std::get<RiBlock>(cases()).a0), prism_rtl::to_pod(std::get<RiBlock>(cases()).a1)})
        : std::holds_alternative<RiCall>(cases()) ? Pod::choice("RiCall", {prism_rtl::to_pod(std::get<RiCall>(cases()).a0), prism_rtl::to_pod(std::get<RiCall>(cases()).a1), prism_rtl::to_pod(std::get<RiCall>(cases()).a2), prism_rtl::to_pod(std::get<RiCall>(cases()).a3)})
        : Pod();
}

Result<RawItem> RawItem::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "RiText" && c->args.size() == 1) return RawItem(RiText{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "RiPlaceholder" && c->args.size() == 2) return RawItem(RiPlaceholder{TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::Tok>>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[1]))});
        if (c->ctor == "RiBlock" && c->args.size() == 2) return RawItem(RiBlock{TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::Tok>>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[1]))});
        if (c->ctor == "RiCall" && c->args.size() == 4) return RawItem(RiCall{TRY(prism_rtl::from_pod<crate::syntax::lexer::NameTok>(c->args[0])), TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::AttrTok>>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Array<crate::syntax::lexer::TPartTok>>>(c->args[2])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[3]))});
    }
    return mismatch<RawItem>("a RawItem", p);
}


bool RawLine::operator==(const RawLine& o) const { return items == o.items && newline == o.newline && block == o.block; }

void RawLine::show(Printer& p) const {
    p.record("RawLine", {{"items", items}, {"newline", newline}, {"block", block}});
}

Pod RawLine::to_pod() const {
    return Pod::record("RawLine", {{"items", prism_rtl::to_pod(items)}, {"newline", prism_rtl::to_pod(newline)}, {"block", prism_rtl::to_pod(block)}});
}

Result<RawLine> RawLine::from_pod(const Pod& whole) {
    return RawLine{.items = TRY(prism_rtl::from_pod<Array<RawItem>>(TRY(crate::prelude::field(whole, "items")))), .newline = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "newline")))), .block = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "block"))))};
}


void TplHow::show(Printer& p) const {
    p.record("TplHow", {{"close", close}, {"delims", delims}, {"open", open}, {"is_raw", is_raw}, {"first_continues", first_continues}});
}

Pod TplHow::to_pod() const {
    return Pod::record("TplHow", {{"close", prism_rtl::to_pod(close)}, {"delims", prism_rtl::to_pod(delims)}, {"open", prism_rtl::to_pod(open)}, {"is_raw", prism_rtl::to_pod(is_raw)}, {"first_continues", prism_rtl::to_pod(first_continues)}});
}

Result<TplHow> TplHow::from_pod(const Pod& whole) {
    return TplHow{.close = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "close")))), .delims = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "delims")))), .open = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "open")))), .is_raw = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "is_raw")))), .first_continues = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "first_continues"))))};
}


bool TplRead::operator==(const TplRead& o) const { return l == o.l && lines == o.lines && cur == o.cur && closing_col == o.closing_col && closed == o.closed && at_line_start == o.at_line_start && going == o.going; }

void TplRead::show(Printer& p) const {
    p.record("TplRead", {{"l", l}, {"lines", lines}, {"cur", cur}, {"closing_col", closing_col}, {"closed", closed}, {"at_line_start", at_line_start}, {"going", going}});
}

Pod TplRead::to_pod() const {
    return Pod::record("TplRead", {{"l", prism_rtl::to_pod(l)}, {"lines", prism_rtl::to_pod(lines)}, {"cur", prism_rtl::to_pod(cur)}, {"closing_col", prism_rtl::to_pod(closing_col)}, {"closed", prism_rtl::to_pod(closed)}, {"at_line_start", prism_rtl::to_pod(at_line_start)}, {"going", prism_rtl::to_pod(going)}});
}

Result<TplRead> TplRead::from_pod(const Pod& whole) {
    return TplRead{.l = TRY(prism_rtl::from_pod<crate::syntax::lexer::Lex>(TRY(crate::prelude::field(whole, "l")))), .lines = TRY(prism_rtl::from_pod<Array<RawLine>>(TRY(crate::prelude::field(whole, "lines")))), .cur = TRY(prism_rtl::from_pod<RawLine>(TRY(crate::prelude::field(whole, "cur")))), .closing_col = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(crate::prelude::field(whole, "closing_col")))), .closed = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "closed")))), .at_line_start = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "at_line_start")))), .going = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "going"))))};
}


/// MaybeTemplate: unbounded fn Lex, Text -> Lex
crate::syntax::lexer::Lex maybe_template(const crate::syntax::lexer::Lex& l0, const Text& kw) {
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit(" *", ""); return r; }()), this_.src, this_.pos);
        (std::move(this_));
    });
    return (crate::syntax::lexer::chars::peek(l) == Text::lit("<")) && (template_tag_ahead(l) != Text::lit(""))
        ? ({
        auto keyword = kw == Text::lit("output")
            ? Text::lit("Output")
            : kw == Text::lit("inline_text") ? Text::lit("InlineText") : Text::lit("Raw");
        auto [kind, l2] = lex_template(l, keyword, prism_rtl::deref(l).pos);
        auto l3 = ({
            crate::syntax::lexer::Lex this_ = l2;
            this_.last_ws = true;
            (std::move(this_));
        });
        (crate::syntax::lexer::push_tok(l3, kind, prism_rtl::deref(l).pos, prism_rtl::deref(l3).pos));
    })
        : crate::syntax::lexer::chars::lex_err(l0, l0.pos, l0.pos, prism_rtl::cat("`", kw, "` is followed by a language tag, `<rust>`"));
}


prism_rtl::Turn<crate::syntax::lexer::Lex> MaybeTemplate::cycle() const {
    const auto& l0 = this->l0;
    const auto& kw = this->kw;
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit(" *", ""); return r; }()), this_.src, this_.pos);
        (std::move(this_));
    });
    return (crate::syntax::lexer::chars::peek(l) == Text::lit("<")) && (template_tag_ahead(l) != Text::lit(""))
        ? ({
        auto keyword = kw == Text::lit("output")
            ? Text::lit("Output")
            : kw == Text::lit("inline_text") ? Text::lit("InlineText") : Text::lit("Raw");
        call_then(start_lex_template(l, keyword, prism_rtl::deref(l).pos), [=](std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_template_1019) {
        return ({
            auto [kind, l2] = lex_template_1019;
            auto l3 = ({
                crate::syntax::lexer::Lex this_ = l2;
                this_.last_ws = true;
                (std::move(this_));
            });
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l3, kind, prism_rtl::deref(l).pos, prism_rtl::deref(l3).pos)));
        });
    });
    })
        : prism_rtl::finished(crate::syntax::lexer::chars::lex_err(l0, prism_rtl::deref(l0).pos, prism_rtl::deref(l0).pos, prism_rtl::cat("`", kw, "` is followed by a language tag, `<rust>`")));
}


/// `Start MaybeTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_maybe_template(crate::syntax::lexer::Lex l0, Text kw) {
    return prism_rtl::make_rc<MaybeTemplate>(l0, kw);
}


/// TemplateTagAhead: unbounded fn Lex -> Text
Text template_tag_ahead(const crate::syntax::lexer::Lex& l) {
    auto&& _name = crate::syntax::lexer::words::lex_ident(crate::syntax::lexer::chars::bump(l));
    auto&& name = std::get<0>(_name);
    auto after_ = crate::syntax::lexer::chars::peek_at(l, len_text(name) + Nat(1u));
    return (((crate::syntax::lexer::chars::peek(l) == Text::lit("<")) && (name != Text::lit(""))) && crate::syntax::lexer::chars::is_lower(crate::syntax::lexer::chars::head(name))) && (after_ == Text::lit(">"))
        ? name
        : Text::lit("");
}


prism_rtl::Turn<Text> TemplateTagAhead::cycle() const {
    const auto& l = this->l;
    auto l_1 = l;
    return call_then(crate::syntax::lexer::words::start_lex_ident(crate::syntax::lexer::chars::bump(l_1)), [=](std::tuple<Text, crate::syntax::lexer::Lex> lex_ident_1410) {
        return ({
            auto&& _name = lex_ident_1410;
            auto&& name = std::get<0>(_name);
            auto after_ = crate::syntax::lexer::chars::peek_at(l_1, len_text(name) + Nat(1u));
            (((crate::syntax::lexer::chars::peek(l_1) == Text::lit("<")) && (name != Text::lit(""))) && crate::syntax::lexer::chars::is_lower(crate::syntax::lexer::chars::head(name))) && (after_ == Text::lit(">"))
            ? prism_rtl::finished(name)
            : prism_rtl::finished(Text::lit(""));
        });
    });
}


/// `Start TemplateTagAhead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_template_tag_ahead(crate::syntax::lexer::Lex l) {
    return prism_rtl::make_rc<TemplateTagAhead>(l);
}


/// LexTemplate: unbounded fn Lex, Text, Nat -> ((TokKind, Lex))
std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_template(const crate::syntax::lexer::Lex& l0, const Text& keyword, const Nat& start) {
    auto lang = template_tag_ahead(l0);
    auto l1 = crate::syntax::lexer::chars::forward(l0, len_text(lang) + Nat(2u));
    auto delims = (lang == Text::lit("markdown")) || (lang == Text::lit("html"))
        ? Text::lit("single")
        : Text::lit("double");
    auto ends_line = (crate::syntax::lexer::chars::peek(l1) == Text::lit("\n")) || crate::syntax::lexer::chars::starts_with(l1, Text::lit("\r\n"));
    auto skip = crate::syntax::lexer::chars::peek(l1) == Text::lit("\r")
        ? Nat(2u)
        : Nat(1u);
    auto l2 = std::move(ends_line) ? crate::syntax::lexer::chars::forward(l1, skip) : l1;
    auto [parts, l3] = template_body(l2, prism_rtl::cat("</", lang, ">"), delims, keyword == Text::lit("Raw"), !std::move(ends_line), start);
    auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KTemplate{crate::syntax::lexer::TemplateTok{.keyword = keyword, .lang = lang, .delims = delims, .parts = parts}});
    return std::tuple{kind, l3};
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> LexTemplate::cycle() const {
    const auto& l0 = this->l0;
    const auto& keyword = this->keyword;
    const auto& start = this->start;
    auto keyword_1 = keyword;
    auto l0_2 = l0;
    auto start_3 = start;
    return call_then(start_template_tag_ahead(l0_2), [=](Text template_tag_ahead_1743) {
        return ({
            auto lang = template_tag_ahead_1743;
            auto l1 = crate::syntax::lexer::chars::forward(l0_2, len_text(lang) + Nat(2u));
            auto delims = (lang == Text::lit("markdown")) || (lang == Text::lit("html"))
                ? Text::lit("single")
                : Text::lit("double");
            auto ends_line = (crate::syntax::lexer::chars::peek(l1) == Text::lit("\n")) || crate::syntax::lexer::chars::starts_with(l1, Text::lit("\r\n"));
            auto skip = crate::syntax::lexer::chars::peek(l1) == Text::lit("\r")
                ? Nat(2u)
                : Nat(1u);
            auto l2 = std::move(ends_line) ? crate::syntax::lexer::chars::forward(l1, skip) : l1;
            call_then(start_template_body(l2, prism_rtl::cat("</", lang, ">"), delims, keyword_1 == Text::lit("Raw"), !std::move(ends_line), start_3), [=](std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> template_body_2157) {
            return ({
                auto [parts, l3] = template_body_2157;
                auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KTemplate{crate::syntax::lexer::TemplateTok{.keyword = keyword_1, .lang = lang, .delims = delims, .parts = parts}});
                (prism_rtl::finished(std::tuple{kind, l3}));
            });
        });
        });
    });
}


/// `Start LexTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_template(crate::syntax::lexer::Lex l0, Text keyword, Nat start) {
    return prism_rtl::make_rc<LexTemplate>(l0, keyword, start);
}


/// let emptyLine
RawLine empty_line() {
    return RawLine{.items = Array<RawItem>{}, .newline = false, .block = false};
}


/// AddItem: fn RawLine, RawItem -> RawLine
RawLine add_item(const RawLine& line, const RawItem& item) {
    RawLine this_ = line;
    this_.items = add_raw(this_.items, item);
    return this_;
}


/// AddRaw: fn [RawItem], RawItem -> [RawItem]
Array<RawItem> add_raw(const Array<RawItem>& items, const RawItem& raw_item1) {
    if (prism_rtl::is<RawItem::RiText>(raw_item1)) {
        auto&& t = prism_rtl::as<RawItem::RiText>(raw_item1).a0;
        auto&& _m = crate::syntax::lexer::chars::last(items);
        if (prism_rtl::is_some(_m) && prism_rtl::is<RawItem::RiText>(prism_rtl::some_of(_m))) {
            auto&& s = prism_rtl::as<RawItem::RiText>(prism_rtl::some_of(_m)).a0;
            return crate::prelude::push(crate::syntax::lexer::chars::pop(items), RawItem(RawItem::RiText{prism_rtl::cat(s, t)}));
        }
        {
            return crate::prelude::push(items, RawItem(RawItem::RiText{t}));
        }
    }
    {
        auto&& item = raw_item1;
        return crate::prelude::push(items, item);
    }
}


/// OnlyWhitespace: fn RawLine -> Bool
bool only_whitespace(const RawLine& line) {
    return fold(line.items, true, [&](const bool& ok_, const RawItem& it) { return prism_rtl::deref(ok_) && is_blank_text(it); });
}


/// IsBlankText: fn RawItem -> Bool
bool is_blank_text(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiText>(raw_item0)) {
        auto&& s = prism_rtl::as<RawItem::RiText>(raw_item0).a0;
        return crate::syntax::lexer::chars::all_chars(s, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
            return once_job([=]() {
                return ({
                    auto c = p0;
                    (prism_rtl::finished((c == Text::lit(" ")) || (c == Text::lit("\r"))));
                });
            });
        })));
    }
    {
        return false;
    }
}


/// TextLen: fn RawLine -> Nat
Nat text_len(const RawLine& line) {
    return fold(line.items, Nat(0u), [&](const Nat& n, const RawItem& it) { return n + text_len_of(it); });
}


/// TextLenOf: fn RawItem -> Nat
Nat text_len_of(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiText>(raw_item0)) {
        auto&& s = prism_rtl::as<RawItem::RiText>(raw_item0).a0;
        return len_text(s);
    }
    {
        return Nat(0u);
    }
}


/// TemplateBody: unbounded fn Lex, Text, Text, Bool, Bool, Nat -> (([TPartTok], Lex))
std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> template_body(const crate::syntax::lexer::Lex& l0, const Text& close, const Text& delims, const bool& is_raw, const bool& first_continues, const Nat& open_start) {
    auto open = delims == Text::lit("double") ? Text::lit("{{") : Text::lit("{");
    auto how = TplHow{.close = close, .delims = delims, .open = open, .is_raw = is_raw, .first_continues = first_continues};
    auto start = TplRead{.l = l0, .lines = Array<RawLine>{}, .cur = empty_line(), .closing_col = std::optional<Nat>{}, .closed = false, .at_line_start = !first_continues, .going = true};
    auto r = ({
        TplRead this_ = start;
        while (this_.going) {
            this_ = template_step(this_, how);
        }
        (std::move(this_));
    });
    auto l1 = prism_rtl::deref(r).closed
        ? prism_rtl::deref(r).l
        : crate::syntax::lexer::chars::lex_err(prism_rtl::deref(r).l, open_start, prism_rtl::deref(prism_rtl::deref(r).l).pos, prism_rtl::cat("a template never closes: expected `", close, "`"));
    return finish_template_lines(l1, crate::prelude::push(prism_rtl::deref(r).lines, prism_rtl::deref(r).cur), or_(prism_rtl::deref(r).closing_col, Nat(0u)), first_continues);
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex>> TemplateBody::cycle() const {
    const auto& l0 = this->l0;
    const auto& close = this->close;
    const auto& delims = this->delims;
    const auto& is_raw = this->is_raw;
    const auto& first_continues = this->first_continues;
    const auto& open_start = this->open_start;
    auto open = delims == Text::lit("double") ? Text::lit("{{") : Text::lit("{");
    auto how = TplHow{.close = close, .delims = delims, .open = open, .is_raw = prism_rtl::deref(is_raw), .first_continues = prism_rtl::deref(first_continues)};
    auto start = TplRead{.l = l0, .lines = Array<RawLine>{}, .cur = empty_line(), .closing_col = std::optional<Nat>{}, .closed = false, .at_line_start = !prism_rtl::deref(first_continues), .going = true};
    TplRead this_ = start;
    auto close_1 = close;
    auto first_continues_2 = prism_rtl::deref(first_continues);
    auto open_start_3 = open_start;
    return call_then(loop_job(std::tuple{std::move(this_)}, ({
        auto how_4 = how;
        [=, how_4 = std::move(how_4)](std::tuple<TplRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return prism_rtl::deref(this_).going
            ? ({
            this_ = template_step(this_, how_4);
            Expected<std::tuple<TplRead>, std::tuple<TplRead>>(std::tuple{this_});
        })
            : Expected<std::tuple<TplRead>, std::tuple<TplRead>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<TplRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto r = this_;
            auto l1 = prism_rtl::deref(r).closed
                ? prism_rtl::deref(r).l
                : crate::syntax::lexer::chars::lex_err(prism_rtl::deref(r).l, open_start_3, prism_rtl::deref(prism_rtl::deref(r).l).pos, prism_rtl::cat("a template never closes: expected `", close_1, "`"));
            (prism_rtl::finished(finish_template_lines(l1, crate::prelude::push(prism_rtl::deref(r).lines, prism_rtl::deref(r).cur), or_(prism_rtl::deref(r).closing_col, Nat(0u)), first_continues_2)));
        });
    });
}


/// `Start TemplateBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex>> start_template_body(crate::syntax::lexer::Lex l0, Text close, Text delims, bool is_raw, bool first_continues, Nat open_start) {
    return prism_rtl::make_rc<TemplateBody>(l0, close, delims, is_raw, first_continues, open_start);
}


/// TemplateStep: unbounded fn TplRead, TplHow -> TplRead
TplRead template_step(const TplRead& s, const TplHow& how) {
    auto c = crate::syntax::lexer::chars::peek(s.l);
    return (s.at_line_start && (!how.is_raw)) && (crate::syntax::lexer::chars::trim(crate::syntax::lexer::chars::rest_of_line(s.l)) == how.open)
        ? brace_block_line(s, crate::syntax::lexer::chars::rest_of_line(s.l), how)
        : crate::syntax::lexer::chars::starts_with(s.l, how.close)
        ? close_template(s, how)
        : c == Text::lit("")
        ? ({
        TplRead this_ = s;
        this_.at_line_start = false;
        this_.going = false;
        (std::move(this_));
    })
        : c == Text::lit("\n")
        ? ({
        TplRead this_ = s;
        this_.l = crate::syntax::lexer::chars::bump(this_.l);
        prism_rtl::deref(this_.cur).newline = true;
        this_.lines = crate::prelude::push(this_.lines, this_.cur);
        this_.cur = empty_line();
        this_.at_line_start = true;
        (std::move(this_));
    })
        : ({
        auto [item, l2] = template_item(s.l, how);
        ({
        TplRead this_ = s;
        this_.at_line_start = false;
        this_.l = l2;
        this_.cur = add_item(this_.cur, item);
        (std::move(this_));
    });
    });
}


prism_rtl::Turn<TplRead> TemplateStep::cycle() const {
    const auto& s = this->s;
    const auto& how = this->how;
    auto c = crate::syntax::lexer::chars::peek(prism_rtl::deref(s).l);
    return (prism_rtl::deref(s).at_line_start && (!prism_rtl::deref(how).is_raw)) && (crate::syntax::lexer::chars::trim(crate::syntax::lexer::chars::rest_of_line(prism_rtl::deref(s).l)) == prism_rtl::deref(how).open)
        ? ({
        auto how_1 = how;
        auto s_2 = s;
        call_then(crate::syntax::lexer::chars::start_rest_of_line(prism_rtl::deref(s_2).l), [=, how_1 = std::move(how_1)](Text rest_of_line_5173) { return prism_rtl::more(prism_rtl::rc(BraceBlockLine(s_2, rest_of_line_5173, how_1))); });
    })
        : crate::syntax::lexer::chars::starts_with(prism_rtl::deref(s).l, prism_rtl::deref(how).close)
        ? prism_rtl::finished(close_template(s, how))
        : c == Text::lit("")
        ? prism_rtl::finished(({
        TplRead this_ = s;
        this_.at_line_start = false;
        this_.going = false;
        (std::move(this_));
    }))
        : c == Text::lit("\n")
        ? prism_rtl::finished(({
        TplRead this_ = s;
        this_.l = crate::syntax::lexer::chars::bump(this_.l);
        prism_rtl::deref(this_.cur).newline = true;
        this_.lines = crate::prelude::push(this_.lines, this_.cur);
        this_.cur = empty_line();
        this_.at_line_start = true;
        (std::move(this_));
    }))
        : ({
        auto how_1 = how;
        auto s_2 = s;
        call_then(start_template_item(prism_rtl::deref(s_2).l, how_1), [=](std::tuple<RawItem, crate::syntax::lexer::Lex> template_item_5618) {
        return ({
            auto [item, l2] = template_item_5618;
            (prism_rtl::finished(({
            TplRead this_ = s_2;
            this_.at_line_start = false;
            this_.l = l2;
            this_.cur = add_item(this_.cur, item);
            (std::move(this_));
        })));
        });
    });
    });
}


/// `Start TemplateStep, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TplRead> start_template_step(TplRead s, TplHow how) {
    return prism_rtl::make_rc<TemplateStep>(s, how);
}


/// BraceBlockLine: unbounded fn TplRead, Text, TplHow -> TplRead
TplRead brace_block_line(const TplRead& s, const Text& rest, const TplHow& how) {
    auto bs = prism_rtl::deref(s.l).pos;
    auto past = crate::syntax::lexer::chars::forward(s.l, len_text(rest));
    auto at_ = crate::syntax::lexer::chars::peek(past) == Text::lit("\n")
        ? crate::syntax::lexer::chars::bump(past)
        : past;
    auto [toks, l2] = crate::syntax::lexer::layout::nested(at_, crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MBrace{how.delims}));
    auto line = RawLine{.items = Array(std::vector{RawItem(RawItem::RiBlock{toks, crate::syntax::Range{.start = bs, .end = prism_rtl::deref(l2).pos}})}), .newline = false, .block = true};
    TplRead this_ = s;
    this_.lines = crate::prelude::push(this_.lines, line);
    this_.l = l2;
    return this_;
}


prism_rtl::Turn<TplRead> BraceBlockLine::cycle() const {
    const auto& s = this->s;
    const auto& rest = this->rest;
    const auto& how = this->how;
    auto bs = prism_rtl::deref(prism_rtl::deref(s).l).pos;
    auto past = crate::syntax::lexer::chars::forward(prism_rtl::deref(s).l, len_text(rest));
    auto at_ = crate::syntax::lexer::chars::peek(past) == Text::lit("\n")
        ? crate::syntax::lexer::chars::bump(past)
        : past;
    auto how_1 = how;
    auto s_2 = s;
    return call_then(crate::syntax::lexer::layout::start_nested(at_, crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MBrace{prism_rtl::deref(how_1).delims})), [=](std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> nested_5996) {
        return ({
            auto [toks, l2] = nested_5996;
            auto line = RawLine{.items = Array(std::vector{RawItem(RawItem::RiBlock{toks, crate::syntax::Range{.start = bs, .end = prism_rtl::deref(l2).pos}})}), .newline = false, .block = true};
            (prism_rtl::finished(({
            TplRead this_ = s_2;
            this_.lines = crate::prelude::push(this_.lines, line);
            this_.l = l2;
            (std::move(this_));
        })));
        });
    });
}


/// `Start BraceBlockLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TplRead> start_brace_block_line(TplRead s, Text rest, TplHow how) {
    return prism_rtl::make_rc<BraceBlockLine>(s, rest, how);
}


/// CloseTemplate: fn TplRead, TplHow -> TplRead
TplRead close_template(const TplRead& s, const TplHow& how) {
    TplRead this_ = s;
    this_.at_line_start = false;
    if (only_whitespace(this_.cur) && ((len(this_.lines) > Nat(0u)) || (!how.first_continues))) {
        this_.closing_col = std::optional(text_len(this_.cur));
        prism_rtl::deref(this_.cur).items = Array<RawItem>{};
    }
    this_.l = crate::syntax::lexer::chars::forward(this_.l, len_text(how.close));
    this_.closed = true;
    this_.going = false;
    return this_;
}


/// TemplateItem: unbounded fn Lex, TplHow -> ((RawItem, Lex))
std::tuple<RawItem, crate::syntax::lexer::Lex> template_item(const crate::syntax::lexer::Lex& l, const TplHow& how) {
    auto live = !how.is_raw;
    return (std::move(live) && (how.delims == Text::lit("double"))) && crate::syntax::lexer::chars::starts_with(l, Text::lit("\\{{"))
        ? std::tuple{RawItem(RawItem::RiText{Text::lit("{{")}), crate::syntax::lexer::chars::forward(l, Nat(3u))}
        : (std::move(live) && (how.delims == Text::lit("single"))) && crate::syntax::lexer::chars::starts_with(l, Text::lit("\\{"))
        ? std::tuple{RawItem(RawItem::RiText{Text::lit("{")}), crate::syntax::lexer::chars::forward(l, Nat(2u))}
        : std::move(live) && crate::syntax::lexer::chars::starts_with(l, how.open)
        ? ({
        auto ps = l.pos;
        auto [toks, l2] = crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::forward(l, len_text(how.open)), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{how.delims}));
        auto item = RawItem(RawItem::RiPlaceholder{toks, crate::syntax::Range{.start = ps, .end = prism_rtl::deref(l2).pos}});
        std::tuple{item, l2};
    })
        : (std::move(live) && crate::syntax::lexer::chars::starts_with(l, Text::lit("<@"))) && crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::peek_at(l, Nat(2u)))
        ? template_call(l, how.delims, how.open)
        : ({
        auto run_ = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("[^\\\\{<\\n]+", ""); return r; }()), l);
        auto n = run_ == Text::lit("")
            ? len_text(crate::syntax::lexer::chars::peek(l))
            : len_text(run_);
        auto l2 = ({
            crate::syntax::lexer::Lex this_ = l;
            this_.pos = this_.pos + n;
            (std::move(this_));
        });
        std::tuple{RawItem(RawItem::RiText{crate::syntax::lexer::chars::slice(l, l.pos, prism_rtl::deref(l2).pos)}), l2};
    });
}


prism_rtl::Turn<std::tuple<RawItem, crate::syntax::lexer::Lex>> TemplateItem::cycle() const {
    const auto& l = this->l;
    const auto& how = this->how;
    auto live = !prism_rtl::deref(how).is_raw;
    return (std::move(live) && (prism_rtl::deref(how).delims == Text::lit("double"))) && crate::syntax::lexer::chars::starts_with(l, Text::lit("\\{{"))
        ? prism_rtl::finished(std::tuple{RawItem(RawItem::RiText{Text::lit("{{")}), crate::syntax::lexer::chars::forward(l, Nat(3u))})
        : (std::move(live) && (prism_rtl::deref(how).delims == Text::lit("single"))) && crate::syntax::lexer::chars::starts_with(l, Text::lit("\\{"))
        ? prism_rtl::finished(std::tuple{RawItem(RawItem::RiText{Text::lit("{")}), crate::syntax::lexer::chars::forward(l, Nat(2u))})
        : std::move(live) && crate::syntax::lexer::chars::starts_with(l, prism_rtl::deref(how).open)
        ? ({
        auto ps = prism_rtl::deref(l).pos;
        auto how_1 = how;
        auto l_2 = l;
        call_then(crate::syntax::lexer::layout::start_nested(crate::syntax::lexer::chars::forward(l_2, len_text(prism_rtl::deref(how_1).open)), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{prism_rtl::deref(how_1).delims})), [=, ps = std::move(ps)](std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> nested_7242) {
        return ({
            auto [toks, l2] = nested_7242;
            auto item = RawItem(RawItem::RiPlaceholder{toks, crate::syntax::Range{.start = ps, .end = prism_rtl::deref(l2).pos}});
            (prism_rtl::finished(std::tuple{item, l2}));
        });
    });
    })
        : (std::move(live) && crate::syntax::lexer::chars::starts_with(l, Text::lit("<@"))) && crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::peek_at(l, Nat(2u)))
        ? prism_rtl::more(prism_rtl::rc(TemplateCall(l, prism_rtl::deref(how).delims, prism_rtl::deref(how).open)))
        : ({
        auto run_ = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("[^\\\\{<\\n]+", ""); return r; }()), l);
        auto n = run_ == Text::lit("")
            ? len_text(crate::syntax::lexer::chars::peek(l))
            : len_text(run_);
        auto l2 = ({
            crate::syntax::lexer::Lex this_ = l;
            this_.pos = this_.pos + n;
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{RawItem(RawItem::RiText{crate::syntax::lexer::chars::slice(l, prism_rtl::deref(l).pos, prism_rtl::deref(l2).pos)}), l2}));
    });
}


/// `Start TemplateItem, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<RawItem, crate::syntax::lexer::Lex>> start_template_item(crate::syntax::lexer::Lex l, TplHow how) {
    return prism_rtl::make_rc<TemplateItem>(l, how);
}


/// TemplateCall: unbounded fn Lex, Text, Text -> ((RawItem, Lex))
std::tuple<RawItem, crate::syntax::lexer::Lex> template_call(const crate::syntax::lexer::Lex& l0, const Text& delims, const Text& open) {
    auto start = l0.pos;
    auto&& _sigils = crate::syntax::lexer::words::read_sigils(crate::syntax::lexer::chars::bump(l0));
    auto&& sigils = std::get<0>(_sigils);
    auto&& l1 = std::get<2>(_sigils);
    auto [path_, l2] = crate::syntax::lexer::words::lex_qualified_path(l1);
    auto name = crate::syntax::lexer::NameTok{.sigils = sigils, .path_ = path_, .case_ = crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})};
    auto close = prism_rtl::cat("</", sigils, crate::syntax::lexer::chars::join(path_, Text::lit(".")), ">");
    auto r = ({
        CallRead this_ = CallRead{.l = l2, .attrs = Array<crate::syntax::lexer::AttrTok>{}, .body = std::optional<Array<crate::syntax::lexer::TPartTok>>{}, .going = true};
        while (this_.going) {
            this_ = call_step(this_, start, close, delims, open);
        }
        (std::move(this_));
    });
    auto item = RawItem(RawItem::RiCall{name, prism_rtl::deref(r).attrs, prism_rtl::deref(r).body, crate::syntax::Range{.start = start, .end = prism_rtl::deref(prism_rtl::deref(r).l).pos}});
    return std::tuple{item, prism_rtl::deref(r).l};
}


prism_rtl::Turn<std::tuple<RawItem, crate::syntax::lexer::Lex>> TemplateCall::cycle() const {
    const auto& l0 = this->l0;
    const auto& delims = this->delims;
    const auto& open = this->open;
    auto start = prism_rtl::deref(l0).pos;
    auto delims_1 = delims;
    auto l0_2 = l0;
    auto open_3 = open;
    return call_then(crate::syntax::lexer::words::start_read_sigils(crate::syntax::lexer::chars::bump(l0_2)), [=](std::tuple<Text, bool, crate::syntax::lexer::Lex> read_sigils_8234) {
        return ({
            auto&& _sigils = read_sigils_8234;
            auto&& sigils = std::get<0>(_sigils);
            auto&& l1 = std::get<2>(_sigils);
            call_then(crate::syntax::lexer::words::start_lex_qualified_path(l1), [=](std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_8278) {
            return ({
                auto [path_, l2] = lex_qualified_path_8278;
                auto name = crate::syntax::lexer::NameTok{.sigils = sigils, .path_ = path_, .case_ = crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})};
                auto close = prism_rtl::cat("</", sigils, crate::syntax::lexer::chars::join(path_, Text::lit(".")), ">");
                CallRead this_ = CallRead{.l = l2, .attrs = Array<crate::syntax::lexer::AttrTok>{}, .body = std::optional<Array<crate::syntax::lexer::TPartTok>>{}, .going = true};
                auto name_4 = name;
                auto start_5 = start;
                call_then(loop_job(std::tuple{std::move(this_)}, ({
                auto close_6 = close;
                auto delims_1_7 = delims_1;
                auto open_3_7 = open_3;
                auto start_5_7 = start_5;
                [=, close_6 = std::move(close_6), delims_1_7 = std::move(delims_1_7), open_3_7 = std::move(open_3_7), start_5_7 = std::move(start_5_7)](std::tuple<CallRead> _p0) {
                auto this_ = std::get<0>(_p0);
                return prism_rtl::deref(this_).going
                    ? ({
                    this_ = call_step(this_, start_5_7, close_6, delims_1_7, open_3_7);
                    Expected<std::tuple<CallRead>, std::tuple<CallRead>>(std::tuple{this_});
                })
                    : Expected<std::tuple<CallRead>, std::tuple<CallRead>>(unexpected(std::tuple{this_}));
            };
            })), [=, name_4 = std::move(name_4)](std::tuple<CallRead> _p0) {
                auto this_ = std::get<0>(_p0);
                return ({
                    auto r = this_;
                    auto item = RawItem(RawItem::RiCall{name_4, prism_rtl::deref(r).attrs, prism_rtl::deref(r).body, crate::syntax::Range{.start = start_5, .end = prism_rtl::deref(prism_rtl::deref(r).l).pos}});
                    (prism_rtl::finished(std::tuple{item, prism_rtl::deref(r).l}));
                });
            });
            });
        });
        });
    });
}


/// `Start TemplateCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<RawItem, crate::syntax::lexer::Lex>> start_template_call(crate::syntax::lexer::Lex l0, Text delims, Text open) {
    return prism_rtl::make_rc<TemplateCall>(l0, delims, open);
}


/// CallStep: unbounded fn CallRead, Nat, Text, Text, Text -> CallRead
CallRead call_step(const CallRead& s0, const Nat& start, const Text& close, const Text& delims, const Text& open) {
    auto l = ({
        crate::syntax::lexer::Lex this_ = s0.l;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[ \\n\\r]*", ""); return r; }()), this_.src, this_.pos);
        (std::move(this_));
    });
    auto s = ({
        CallRead this_ = s0;
        this_.l = l;
        (std::move(this_));
    });
    auto at_ = prism_rtl::deref(l).pos;
    return crate::syntax::lexer::chars::starts_with(l, Text::lit("/>"))
        ? ({
        CallRead this_ = s;
        this_.l = crate::syntax::lexer::chars::forward(l, Nat(2u));
        this_.going = false;
        (std::move(this_));
    })
        : crate::syntax::lexer::chars::peek(l) == Text::lit(">")
        ? ({
        auto past = crate::syntax::lexer::chars::bump(l);
        auto continues = crate::syntax::lexer::chars::peek(past) != Text::lit("\n");
        auto from = std::move(continues) ? past : crate::syntax::lexer::chars::bump(past);
        auto [parts, l3] = template_body(from, close, delims, false, continues, start);
        ({
        CallRead this_ = s;
        this_.body = std::optional(parts);
        this_.l = l3;
        this_.going = false;
        (std::move(this_));
    });
    })
        : !crate::syntax::lexer::chars::is_ident_start(crate::syntax::lexer::chars::peek(l))
        ? ({
        CallRead this_ = s;
        this_.l = crate::syntax::lexer::chars::lex_err(l, at_, at_ + Nat(1u), Text::lit("expected an attribute `name=value`, `/>` or `>` in a template call"));
        this_.going = false;
        (std::move(this_));
    })
        : ({
        auto [aname, l3] = crate::syntax::lexer::words::lex_ident(l);
        (crate::syntax::lexer::chars::peek(l3) != Text::lit("=")
        ? ({
        CallRead this_ = s;
        this_.l = crate::syntax::lexer::chars::lex_err(l3, at_, prism_rtl::deref(l3).pos, Text::lit("an attribute is `name=value`"));
        (std::move(this_));
    })
        : ({
        auto [tokens, l4] = attr_value(crate::syntax::lexer::chars::bump(l3), delims, open);
        ({
        CallRead this_ = s;
        this_.attrs = crate::prelude::push(this_.attrs, crate::syntax::lexer::AttrTok{.name = aname, .tokens = tokens, .span = crate::syntax::Range{.start = at_, .end = prism_rtl::deref(l4).pos}});
        this_.l = l4;
        (std::move(this_));
    });
    }));
    });
}


prism_rtl::Turn<CallRead> CallStep::cycle() const {
    const auto& s0 = this->s0;
    const auto& start = this->start;
    const auto& close = this->close;
    const auto& delims = this->delims;
    const auto& open = this->open;
    auto l = ({
        crate::syntax::lexer::Lex this_ = prism_rtl::deref(s0).l;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[ \\n\\r]*", ""); return r; }()), this_.src, this_.pos);
        (std::move(this_));
    });
    auto s = ({
        CallRead this_ = s0;
        this_.l = l;
        (std::move(this_));
    });
    auto at_ = prism_rtl::deref(l).pos;
    return crate::syntax::lexer::chars::starts_with(l, Text::lit("/>"))
        ? prism_rtl::finished(({
        CallRead this_ = s;
        this_.l = crate::syntax::lexer::chars::forward(l, Nat(2u));
        this_.going = false;
        (std::move(this_));
    }))
        : crate::syntax::lexer::chars::peek(l) == Text::lit(">")
        ? ({
        auto past = crate::syntax::lexer::chars::bump(l);
        auto continues = crate::syntax::lexer::chars::peek(past) != Text::lit("\n");
        auto from = std::move(continues) ? past : crate::syntax::lexer::chars::bump(past);
        auto close_1 = close;
        auto delims_2 = delims;
        auto start_3 = start;
        call_then(start_template_body(from, close_1, delims_2, false, std::move(continues), start_3), [=](std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> template_body_9198) {
        return ({
            auto [parts, l3] = template_body_9198;
            (prism_rtl::finished(({
            CallRead this_ = s;
            this_.body = std::optional(parts);
            this_.l = l3;
            this_.going = false;
            (std::move(this_));
        })));
        });
    });
    })
        : !crate::syntax::lexer::chars::is_ident_start(crate::syntax::lexer::chars::peek(l))
        ? prism_rtl::finished(({
        CallRead this_ = s;
        this_.l = crate::syntax::lexer::chars::lex_err(l, at_, at_ + Nat(1u), Text::lit("expected an attribute `name=value`, `/>` or `>` in a template call"));
        this_.going = false;
        (std::move(this_));
    }))
        : ({
        auto delims_1 = delims;
        auto open_2 = open;
        auto start_3 = start;
        call_then(crate::syntax::lexer::words::start_lex_ident(l), [=, delims_1 = std::move(delims_1), open_2 = std::move(open_2)](std::tuple<Text, crate::syntax::lexer::Lex> lex_ident_9597) {
        return ({
            auto [aname, l3] = lex_ident_9597;
            (crate::syntax::lexer::chars::peek(l3) != Text::lit("=")
            ? prism_rtl::finished(({
            CallRead this_ = s;
            this_.l = crate::syntax::lexer::chars::lex_err(l3, at_, prism_rtl::deref(l3).pos, Text::lit("an attribute is `name=value`"));
            (std::move(this_));
        }))
            : ({
            auto [tokens, l4] = attr_value(crate::syntax::lexer::chars::bump(l3), delims_1, open_2);
            (prism_rtl::finished(({
            CallRead this_ = s;
            this_.attrs = crate::prelude::push(this_.attrs, crate::syntax::lexer::AttrTok{.name = aname, .tokens = tokens, .span = crate::syntax::Range{.start = at_, .end = prism_rtl::deref(l4).pos}});
            this_.l = l4;
            (std::move(this_));
        })));
        }));
        });
    });
    });
}


/// `Start CallStep, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<CallRead> start_call_step(CallRead s0, Nat start, Text close, Text delims, Text open) {
    return prism_rtl::make_rc<CallStep>(s0, start, close, delims, open);
}


/// AttrValue: unbounded fn Lex, Text, Text -> (([Tok], Lex))
std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> attr_value(const crate::syntax::lexer::Lex& l, const Text& delims, const Text& open) {
    return crate::syntax::lexer::chars::starts_with(l, open)
        ? crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::forward(l, len_text(open)), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{delims}))
        : crate::syntax::lexer::chars::peek(l) == Text::lit("\"")
        ? ({
        auto [text_, l2] = crate::syntax::lexer::literals::lex_text(l);
        auto tok = crate::syntax::lexer::Tok{.kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KText{Text::lit(""), text_}), .span = crate::syntax::Range{.start = l.pos, .end = prism_rtl::deref(l2).pos}, .touches = false, .line_start = false};
        std::tuple{Array(std::vector{tok}), l2};
    })
        : std::tuple{Array<crate::syntax::lexer::Tok>{}, crate::syntax::lexer::chars::lex_err(l, l.pos, l.pos, prism_rtl::cat("an attribute\'s value is a placeholder `", open, "...` or a text literal"))};
}


/// FinishTemplateLines: fn Lex, [RawLine], Nat, Bool -> (([TPartTok], Lex))
std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> finish_template_lines(const crate::syntax::lexer::Lex& l0, const Array<RawLine>& lines, const Nat& strip, const bool& first_continues) {
    std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<crate::syntax::lexer::TPartTok>{}, l0};
    crate::syntax::lexer::Lex l = l0;
    Array<crate::syntax::lexer::TPartTok> parts = Array<crate::syntax::lexer::TPartTok>{};
    for (auto&& [i10950, v10950] : prism_rtl::enumerate(lines)) {
        auto k10950 = nat_of(i10950);
        auto line = v10950;
        if (prism_rtl::deref(line).block) {
            parts = append(parts, block_parts(prism_rtl::deref(line).items));
        } else  {
            auto first_ = (k10950 == Nat(0u)) && first_continues;
            auto [items, l2] = (!std::move(first_)) && (strip > Nat(0u))
                ? strip_line(line, strip, l)
                : std::tuple{prism_rtl::deref(line).items, l};
            l = l2;
            auto non_blank = fold(items, Array<RawItem>{}, [&](const Array<RawItem>& acc, const RawItem& it) { return is_blank_or_empty(it) ? acc : crate::prelude::push(acc, it); });
            auto alone = (((!std::move(first_)) && prism_rtl::deref(line).newline) && (len(non_blank) == Nat(1u))) && is_placeholder_item(or_(index(non_blank, Nat(0u)), RawItem(RawItem::RiText{Text::lit("")})));
            if (std::move(alone)) {
                parts = crate::prelude::push(parts, alone_placeholder(items));
            } else  {
                parts = fold(items, parts, push_part);
                if (prism_rtl::deref(line).newline) {
                    parts = push_part(parts, RawItem(RawItem::RiText{Text::lit("\n")}));
                }
            }
        }
    }
    this_ = std::tuple{parts, l};
    return this_;
}


/// BlockParts: fn [RawItem] -> [TPartTok]
Array<crate::syntax::lexer::TPartTok> block_parts(const Array<RawItem>& items) {
    return fold(items, Array<crate::syntax::lexer::TPartTok>{}, [&](const Array<crate::syntax::lexer::TPartTok>& acc, const RawItem& it) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::lexer::TPartTok>> _v;
            if (prism_rtl::is<RawItem::RiBlock>(it)) {
                auto&& tokens = prism_rtl::as<RawItem::RiBlock>(it).a0;
                auto&& span = prism_rtl::as<RawItem::RiBlock>(it).a1;
                _v.set(crate::prelude::push(acc, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptBlock{tokens, span})));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// StripLine: fn RawLine, Nat, Lex -> (([RawItem], Lex))
std::tuple<Array<RawItem>, crate::syntax::lexer::Lex> strip_line(const RawLine& line, const Nat& strip, const crate::syntax::lexer::Lex& l) {
    auto blank = only_whitespace(line);
    auto n = ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = index(line.items, Nat(0u));
        if (prism_rtl::is_some(_m) && prism_rtl::is<RawItem::RiText>(prism_rtl::some_of(_m))) {
            auto&& s = prism_rtl::as<RawItem::RiText>(prism_rtl::some_of(_m)).a0;
            _v.set(crate::syntax::lexer::chars::leading_in(s, Text::lit(" ")));
            goto _done;
        }
        {
            _v.set(Nat(0u));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto items = ({
        __label__ _done;
        prism_rtl::Slot<Array<RawItem>> _v;
        auto&& _m = index(line.items, Nat(0u));
        if (prism_rtl::is_some(_m) && prism_rtl::is<RawItem::RiText>(prism_rtl::some_of(_m))) {
            auto&& s = prism_rtl::as<RawItem::RiText>(prism_rtl::some_of(_m)).a0;
            _v.set(({
                auto rest = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = cursor_at(s, crate::prelude::min(n, strip));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c = prism_rtl::some_of(_m);
                        _v.set(after(c));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                append(Array(std::vector{RawItem(RawItem::RiText{rest})}), drop(line.items, Nat(1u)));
            }));
            goto _done;
        }
        {
            _v.set(line.items);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto l2 = (n < strip) && (!std::move(blank))
        ? crate::syntax::lexer::chars::lex_err(l, prism_rtl::deref(first_item_span(items)).start, prism_rtl::deref(first_item_span(items)).end, Text::lit("a template line is indented less than its closing tag (Q-CT3)"))
        : l;
    auto kept = index(items, Nat(0u)) == std::optional(RawItem(RawItem::RiText{Text::lit("")}))
        ? drop(items, Nat(1u))
        : items;
    return std::tuple{kept, l2};
}


/// IsBlankOrEmpty: fn RawItem -> Bool
bool is_blank_or_empty(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiText>(raw_item0)) {
        auto&& s = prism_rtl::as<RawItem::RiText>(raw_item0).a0;
        return crate::syntax::lexer::chars::trim(s) == Text::lit("");
    }
    {
        return false;
    }
}


/// IsPlaceholderItem: fn RawItem -> Bool
bool is_placeholder_item(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiPlaceholder>(raw_item0)) {
        return true;
    }
    {
        return false;
    }
}


/// FirstItemSpan: fn [RawItem] -> Range
crate::syntax::Range first_item_span(const Array<RawItem>& items) {
    return or_(fold(items, std::optional<crate::syntax::Range>{}, [&](const std::optional<crate::syntax::Range>& found_opt, const RawItem& it) {
        return found_opt != std::optional<crate::syntax::Range>{}
            ? found_opt
            : item_span(it);
    }), crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)});
}


/// ?ItemSpan: fn RawItem -> ?Range
std::optional<crate::syntax::Range> item_span(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiPlaceholder>(raw_item0)) {
        auto&& span = prism_rtl::as<RawItem::RiPlaceholder>(raw_item0).a1;
        return std::optional(span);
    }
    if (prism_rtl::is<RawItem::RiBlock>(raw_item0)) {
        auto&& span = prism_rtl::as<RawItem::RiBlock>(raw_item0).a1;
        return std::optional(span);
    }
    if (prism_rtl::is<RawItem::RiCall>(raw_item0)) {
        auto&& span = prism_rtl::as<RawItem::RiCall>(raw_item0).a3;
        return std::optional(span);
    }
    {
        return std::optional<crate::syntax::Range>{};
    }
}


/// AlonePlaceholder: fn [RawItem] -> TPartTok
crate::syntax::lexer::TPartTok alone_placeholder(const Array<RawItem>& items) {
    auto&& _part = fold(items, std::tuple{Nat(0u), crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{Text::lit("")})}, [&](const std::tuple<Nat, crate::syntax::lexer::TPartTok>& _p0, const RawItem& it) {
        auto&& c = std::get<0>(_p0);
        auto&& p_ = std::get<1>(_p0);
        return alone_step(c, p_, it);
    });
    auto&& part = std::get<1>(_part);
    return part;
}


/// AloneStep: fn Nat, TPartTok, RawItem -> ((Nat, TPartTok))
std::tuple<Nat, crate::syntax::lexer::TPartTok> alone_step(const Nat& c, const crate::syntax::lexer::TPartTok& tpart_tok1, const RawItem& raw_item2) {
    auto&& _m = std::tuple{tpart_tok1, raw_item2};
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(std::get<0>(_m)) && prism_rtl::is<RawItem::RiText>(std::get<1>(_m))) {
        auto&& c0_1_0 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(std::get<0>(_m)).a0;
        auto&& s = prism_rtl::as<RawItem::RiText>(std::get<1>(_m)).a0;
        if (c0_1_0 == Text::lit("")) {
            return c == Nat(0u)
                ? std::tuple{crate::syntax::lexer::chars::leading_in(s, Text::lit(" ")), crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{Text::lit("")})}
                : std::tuple{c, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{Text::lit("")})};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(std::get<0>(_m)) && prism_rtl::is<RawItem::RiPlaceholder>(std::get<1>(_m))) {
        auto&& c1_1_0 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(std::get<0>(_m)).a0;
        auto&& tokens = prism_rtl::as<RawItem::RiPlaceholder>(std::get<1>(_m)).a0;
        auto&& span = prism_rtl::as<RawItem::RiPlaceholder>(std::get<1>(_m)).a1;
        if (c1_1_0 == Text::lit("")) {
            return std::tuple{c, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptPlaceholder{tokens, std::optional(c), span})};
        }
    }
    {
        auto&& p_ = std::get<0>(_m);
        return std::tuple{c, p_};
    }
    prism_rtl::unreachable("no arm matched");
}


/// PushPart: fn [TPartTok], RawItem -> [TPartTok]
Array<crate::syntax::lexer::TPartTok> push_part(const Array<crate::syntax::lexer::TPartTok>& parts, const RawItem& raw_item1) {
    if (prism_rtl::is<RawItem::RiText>(raw_item1)) {
        auto&& c0_1_0 = prism_rtl::as<RawItem::RiText>(raw_item1).a0;
        if (c0_1_0 == Text::lit("")) {
            return parts;
        }
    }
    if (prism_rtl::is<RawItem::RiText>(raw_item1)) {
        auto&& t = prism_rtl::as<RawItem::RiText>(raw_item1).a0;
        auto&& _m = crate::syntax::lexer::chars::last(parts);
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(prism_rtl::some_of(_m))) {
            auto&& s = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(prism_rtl::some_of(_m)).a0;
            return crate::prelude::push(crate::syntax::lexer::chars::pop(parts), crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{prism_rtl::cat(s, t)}));
        }
        {
            return crate::prelude::push(parts, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{t}));
        }
    }
    if (prism_rtl::is<RawItem::RiPlaceholder>(raw_item1)) {
        auto&& tokens = prism_rtl::as<RawItem::RiPlaceholder>(raw_item1).a0;
        auto&& span = prism_rtl::as<RawItem::RiPlaceholder>(raw_item1).a1;
        return crate::prelude::push(parts, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptPlaceholder{tokens, std::optional<Nat>{}, span}));
    }
    if (prism_rtl::is<RawItem::RiBlock>(raw_item1)) {
        auto&& tokens = prism_rtl::as<RawItem::RiBlock>(raw_item1).a0;
        auto&& span = prism_rtl::as<RawItem::RiBlock>(raw_item1).a1;
        return crate::prelude::push(parts, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptBlock{tokens, span}));
    }
    if (prism_rtl::is<RawItem::RiCall>(raw_item1)) {
        auto&& name = prism_rtl::as<RawItem::RiCall>(raw_item1).a0;
        auto&& attrs = prism_rtl::as<RawItem::RiCall>(raw_item1).a1;
        auto&& body_opt = prism_rtl::as<RawItem::RiCall>(raw_item1).a2;
        auto&& span = prism_rtl::as<RawItem::RiCall>(raw_item1).a3;
        return crate::prelude::push(parts, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptCall{name, attrs, body_opt, span}));
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::syntax::lexer::templates


// The module `Syntax.Lexer.Words`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/words.prism`.
namespace crate::syntax::lexer::words {

/// LexToken: unbounded fn Lex -> Lex
crate::syntax::lexer::Lex lex_token(const crate::syntax::lexer::Lex& l0) {
    auto start = l0.pos;
    auto c = crate::syntax::lexer::chars::peek(l0);
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.path_next = false;
        (std::move(this_));
    });
    return l0.path_next && ((crate::syntax::lexer::chars::is_digit(c) || (c == Text::lit("#"))) || (c == Text::lit("[")))
        ? lex_path_token(l, start)
        : lex_token_at(l, start, c);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexToken::cycle() const {
    const auto& l0 = this->l0;
    auto start = prism_rtl::deref(l0).pos;
    auto c = crate::syntax::lexer::chars::peek(l0);
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.path_next = false;
        (std::move(this_));
    });
    return prism_rtl::deref(l0).path_next && ((crate::syntax::lexer::chars::is_digit(c) || (c == Text::lit("#"))) || (c == Text::lit("[")))
        ? prism_rtl::more(prism_rtl::rc(LexPathToken(l, start)))
        : prism_rtl::more(prism_rtl::rc(LexTokenAt(l, start, c)));
}


/// `Start LexToken, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_token(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexToken>(l0);
}


/// LexPathToken: unbounded fn Lex, Nat -> Lex
crate::syntax::lexer::Lex lex_path_token(const crate::syntax::lexer::Lex& l, const Nat& start) {
    auto [segs, l2] = crate::syntax::lexer::literals::lex_path(l);
    return crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KPath{segs}), start, prism_rtl::deref(l2).pos);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexPathToken::cycle() const {
    const auto& l = this->l;
    const auto& start = this->start;
    auto l_1 = l;
    auto start_2 = start;
    return call_then(crate::syntax::lexer::literals::start_lex_path(l_1), [=](std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex> lex_path_963) {
        return ({
            auto [segs, l2] = lex_path_963;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KPath{segs}), start_2, prism_rtl::deref(l2).pos)));
        });
    });
}


/// `Start LexPathToken, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_path_token(crate::syntax::lexer::Lex l, Nat start) {
    return prism_rtl::make_rc<LexPathToken>(l, start);
}


/// LexTokenAt: unbounded fn Lex, Nat, Text -> Lex
crate::syntax::lexer::Lex lex_token_at(const crate::syntax::lexer::Lex& l, const Nat& start, const Text& c) {
    {
        auto&& m1093_0 = c;
        if (m1093_0 == Text::lit("\"")) {
            auto [text_, l2] = crate::syntax::lexer::literals::lex_text(l);
            return crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KText{Text::lit(""), text_}), start, prism_rtl::deref(l2).pos);
        }
    }
    {
        auto&& m1093_1 = c;
        if (m1093_1 == Text::lit("\'")) {
            auto [ch, l2] = crate::syntax::lexer::literals::lex_char(l);
            return crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KChar{Text::lit(""), ch}), start, prism_rtl::deref(l2).pos);
        }
    }
    {
        if (crate::syntax::lexer::chars::is_digit(c)) {
            auto [kind, l2] = crate::syntax::lexer::literals::lex_number(l, Text::lit(""));
            return crate::syntax::lexer::push_tok(l2, kind, start, prism_rtl::deref(l2).pos);
        }
    }
    {
        if (crate::syntax::lexer::chars::is_ident_start(c)) {
            return lex_word_token(l, Text::lit(""), start);
        }
    }
    {
        if (crate::syntax::lexer::chars::contains(Text::lit("$@?~&^"), c)) {
            return lex_sigils(l);
        }
    }
    {
        auto&& m1093_5 = c;
        if (m1093_5 == Text::lit("!")) {
            return crate::syntax::lexer::chars::peek_at(l, Nat(1u)) == Text::lit("=")
                ? push_op_suffix(crate::syntax::lexer::chars::forward(l, Nat(2u)), Text::lit("!="), start)
                : lex_sigils(l);
        }
    }
    {
        if (crate::syntax::lexer::chars::contains(Text::lit("([{"), c)) {
            return lex_open(l, c, start);
        }
    }
    {
        if (crate::syntax::lexer::chars::contains(Text::lit(")]}"), c)) {
            return lex_close(l, c, start);
        }
    }
    {
        auto&& m1093_8 = c;
        if (m1093_8 == Text::lit(",")) {
            return crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KComma{}), start, start + Nat(1u));
        }
    }
    {
        auto&& m1093_9 = c;
        if (m1093_9 == Text::lit(":")) {
            return crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}), start, start + Nat(1u));
        }
    }
    {
        auto&& m1093_10 = c;
        if (m1093_10 == Text::lit(";")) {
            return crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSemi{}), start, start + Nat(1u));
        }
    }
    {
        auto&& m1093_11 = c;
        if (m1093_11 == Text::lit("\\")) {
            return lex_backslash(l, start);
        }
    }
    {
        auto&& m1093_12 = c;
        if (m1093_12 == Text::lit("%")) {
            return crate::syntax::lexer::regexes::lex_regex(l, Text::lit(""), start);
        }
    }
    {
        auto&& m1093_13 = c;
        if (m1093_13 == Text::lit("|")) {
            return lex_bar(l, start);
        }
    }
    {
        auto&& m1093_14 = c;
        if (m1093_14 == Text::lit(".")) {
            return lex_dot(l, start);
        }
    }
    {
        auto&& _m = lex_operator(l, start);
        if (prism_rtl::is_some(_m)) {
            auto&& l2 = prism_rtl::some_of(_m);
            return l2;
        }
        if (prism_rtl::is_none(_m)) {
            auto l1 = crate::syntax::lexer::chars::bump(l);
            auto l2 = crate::syntax::lexer::chars::lex_err(l1, start, prism_rtl::deref(l1).pos, prism_rtl::cat("unexpected character `", c, "`"));
            crate::syntax::lexer::Lex this_ = l2;
            this_.last_ws = true;
            return this_;
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexTokenAt::cycle() const {
    const auto& l = this->l;
    const auto& start = this->start;
    const auto& c = this->c;
    return ({
        ({
        auto&& m1093_0 = c;
        (m1093_0 == Text::lit("\""));
    }) ? ({
        auto&& m1093_0 = c;
        ({
        auto l_1 = l;
        auto start_2 = start;
        call_then(crate::syntax::lexer::literals::start_lex_text(l_1), [=, start_2 = std::move(start_2)](std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> lex_text_1139) {
        return ({
            auto [text_, l2] = lex_text_1139;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KText{Text::lit(""), text_}), start_2, prism_rtl::deref(l2).pos)));
        });
    });
    });
    })
        : ({
        auto&& m1093_1 = c;
        (m1093_1 == Text::lit("\'"));
    }) ? ({
        auto&& m1093_1 = c;
        ({
        auto l_1 = l;
        auto start_2 = start;
        call_then(crate::syntax::lexer::literals::start_lex_char(l_1), [=, start_2 = std::move(start_2)](std::tuple<Text, crate::syntax::lexer::Lex> lex_char_1235) {
        return ({
            auto [ch, l2] = lex_char_1235;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KChar{Text::lit(""), ch}), start_2, prism_rtl::deref(l2).pos)));
        });
    });
    });
    })
        : ({
        crate::syntax::lexer::chars::is_digit(c);
    }) ? ({
        auto l_1 = l;
        auto start_2 = start;
        call_then(crate::syntax::lexer::literals::start_lex_number(l_1, Text::lit("")), [=, start_2 = std::move(start_2)](std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_number_1347) {
        return ({
            auto [kind, l2] = lex_number_1347;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2, kind, start_2, prism_rtl::deref(l2).pos)));
        });
    });
    })
        : ({
        crate::syntax::lexer::chars::is_ident_start(c);
    }) ? prism_rtl::more(prism_rtl::rc(LexWordToken(l, Text::lit(""), start)))
        : ({
        crate::syntax::lexer::chars::contains(Text::lit("$@?~&^"), c);
    }) ? prism_rtl::more(prism_rtl::rc(LexSigils(l)))
        : ({
        auto&& m1093_5 = c;
        (m1093_5 == Text::lit("!"));
    }) ? ({
        auto&& m1093_5 = c;
        crate::syntax::lexer::chars::peek_at(l, Nat(1u)) == Text::lit("=")
        ? prism_rtl::more(prism_rtl::rc(PushOpSuffix(crate::syntax::lexer::chars::forward(l, Nat(2u)), Text::lit("!="), start)))
        : prism_rtl::more(prism_rtl::rc(LexSigils(l)));
    })
        : ({
        crate::syntax::lexer::chars::contains(Text::lit("([{"), c);
    }) ? prism_rtl::finished(lex_open(l, c, start))
        : ({
        crate::syntax::lexer::chars::contains(Text::lit(")]}"), c);
    }) ? prism_rtl::finished(lex_close(l, c, start))
        : ({
        auto&& m1093_8 = c;
        (m1093_8 == Text::lit(","));
    }) ? ({
        auto&& m1093_8 = c;
        prism_rtl::finished(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KComma{}), start, start + Nat(1u)));
    })
        : ({
        auto&& m1093_9 = c;
        (m1093_9 == Text::lit(":"));
    }) ? ({
        auto&& m1093_9 = c;
        prism_rtl::finished(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}), start, start + Nat(1u)));
    })
        : ({
        auto&& m1093_10 = c;
        (m1093_10 == Text::lit(";"));
    }) ? ({
        auto&& m1093_10 = c;
        prism_rtl::finished(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSemi{}), start, start + Nat(1u)));
    })
        : ({
        auto&& m1093_11 = c;
        (m1093_11 == Text::lit("\\"));
    }) ? ({
        auto&& m1093_11 = c;
        prism_rtl::finished(lex_backslash(l, start));
    })
        : ({
        auto&& m1093_12 = c;
        (m1093_12 == Text::lit("%"));
    }) ? ({
        auto&& m1093_12 = c;
        prism_rtl::more(prism_rtl::rc(crate::syntax::lexer::regexes::LexRegex(l, Text::lit(""), start)));
    })
        : ({
        auto&& m1093_13 = c;
        (m1093_13 == Text::lit("|"));
    }) ? ({
        auto&& m1093_13 = c;
        prism_rtl::finished(lex_bar(l, start));
    })
        : ({
        auto&& m1093_14 = c;
        (m1093_14 == Text::lit("."));
    }) ? ({
        auto&& m1093_14 = c;
        prism_rtl::finished(lex_dot(l, start));
    })
        : ({
        auto c_1 = c;
        auto l_2 = l;
        auto start_3 = start;
        call_then(start_lex_operator(l_2, start_3), [=, c_1 = std::move(c_1)](std::optional<crate::syntax::lexer::Lex> lex_operator_1998) {
        return ({
            prism_rtl::is_some(lex_operator_1998) ? ({
            auto&& l2 = prism_rtl::some_of(lex_operator_1998);
            prism_rtl::finished(l2);
        })
            : prism_rtl::is_none(lex_operator_1998) ? ({
            auto l1 = crate::syntax::lexer::chars::bump(l_2);
            auto l2 = crate::syntax::lexer::chars::lex_err(l1, start_3, prism_rtl::deref(l1).pos, prism_rtl::cat("unexpected character `", c_1, "`"));
            (prism_rtl::finished(({
            crate::syntax::lexer::Lex this_ = l2;
            this_.last_ws = true;
            (std::move(this_));
        })));
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    });
}


/// `Start LexTokenAt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_token_at(crate::syntax::lexer::Lex l, Nat start, Text c) {
    return prism_rtl::make_rc<LexTokenAt>(l, start, c);
}


/// LexOpen: fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex lex_open(const crate::syntax::lexer::Lex& l, const Text& c, const Nat& start) {
    auto prefix = ((c == Text::lit("[")) && crate::syntax::lexer::prefix_position(l)) && (!crate::syntax::lexer::chars::next_is_space(l, Nat(1u)));
    auto l2 = ({
        crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l);
        this_.frames = crate::prelude::push(this_.frames, c);
        (std::move(this_));
    });
    return crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOpen{c, std::move(prefix)}), start, prism_rtl::deref(l2).pos);
}


/// LexClose: fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex lex_close(const crate::syntax::lexer::Lex& l, const Text& c, const Nat& start) {
    auto kind = crate::syntax::lexer::open_of(c);
    auto l1 = crate::syntax::lexer::chars::bump(l);
    auto l2 = ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::lexer::Lex> _v;
        auto&& _m = crate::syntax::lexer::chars::last(prism_rtl::deref(l1).frames);
        if (prism_rtl::is_some(_m)) {
            auto&& k = prism_rtl::some_of(_m);
            if (k == kind) {
                _v.set(({
                    crate::syntax::lexer::Lex this_ = l1;
                    this_.frames = crate::syntax::lexer::chars::pop(this_.frames);
                    (std::move(this_));
                }));
                goto _done;
            }
        }
        if (prism_rtl::is_some(_m)) {
            auto&& m2675_1 = prism_rtl::some_of(_m);
            if (m2675_1 == Text::lit("<<")) {
                _v.set(crate::syntax::lexer::chars::lex_err(l1, start, prism_rtl::deref(l1).pos, prism_rtl::cat("`", c, "` inside `<<`: expected `>>`")));
                goto _done;
            }
        }
        if (prism_rtl::is_some(_m)) {
            auto&& k = prism_rtl::some_of(_m);
            _v.set(({
                auto l3 = crate::syntax::lexer::chars::lex_err(l1, start, prism_rtl::deref(l1).pos, prism_rtl::cat("`", c, "` closes a `", k, "`"));
                ({
                crate::syntax::lexer::Lex this_ = l3;
                this_.frames = crate::syntax::lexer::chars::pop(this_.frames);
                (std::move(this_));
            });
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::syntax::lexer::chars::lex_err(l1, start, prism_rtl::deref(l1).pos, prism_rtl::cat("`", c, "` closes nothing")));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KClose{kind}), start, prism_rtl::deref(l2).pos);
}


/// LexBackslash: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex lex_backslash(const crate::syntax::lexer::Lex& l, const Nat& start) {
    auto l1 = crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBackslash{}), start, start + Nat(1u));
    return crate::syntax::lexer::chars::peek(l1) == Text::lit("|")
        ? ({
        auto l2 = ({
            crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l1);
            this_.lambda_open = true;
            (std::move(this_));
        });
        (crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{true}), prism_rtl::deref(l1).pos, prism_rtl::deref(l1).pos + Nat(1u)));
    })
        : l1;
}


/// LexBar: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex lex_bar(const crate::syntax::lexer::Lex& l, const Nat& start) {
    auto l1 = crate::syntax::lexer::chars::bump(l);
    return prism_rtl::deref(l1).lambda_open
        ? ({
        auto l2 = ({
            crate::syntax::lexer::Lex this_ = l1;
            this_.lambda_open = false;
            (std::move(this_));
        });
        (crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{false}), start, prism_rtl::deref(l2).pos));
    })
        : crate::syntax::lexer::push_tok(l1, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{}), start, prism_rtl::deref(l1).pos);
}


/// LexDot: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex lex_dot(const crate::syntax::lexer::Lex& l, const Nat& start) {
    return crate::syntax::lexer::chars::starts_with(l, Text::lit(".."))
        ? crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::forward(l, Nat(2u)), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDotDot{}), start, start + Nat(2u))
        : ({
        auto prefix = crate::syntax::lexer::prefix_position(l) && (!crate::syntax::lexer::chars::next_is_space(l, Nat(1u)));
        auto l1 = std::move(prefix) && crate::syntax::lexer::chars::is_digit(crate::syntax::lexer::chars::peek_at(l, Nat(1u)))
            ? crate::syntax::lexer::chars::lex_err(l, start, start + Nat(1u), Text::lit("a decimal literal has digits on both sides of its point: write `0.5`, not `.5`"))
            : l;
        (crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l1), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDot{std::move(prefix)}), start, start + Nat(1u)));
    });
}


/// PushOpSuffix: unbounded fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex push_op_suffix(const crate::syntax::lexer::Lex& l, const Text& op, const Nat& start) {
    return crate::syntax::lexer::takes_suffix(op) && crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::peek(l))
        ? ({
        auto [path_, l2] = lex_qualified_path(l);
        (crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSuffixed{op, path_}), start, prism_rtl::deref(l2).pos));
    })
        : crate::syntax::lexer::push_tok(l, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOp{op, false}), start, l.pos);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> PushOpSuffix::cycle() const {
    const auto& l = this->l;
    const auto& op = this->op;
    const auto& start = this->start;
    return crate::syntax::lexer::takes_suffix(op) && crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::peek(l))
        ? ({
        auto l_1 = l;
        auto op_2 = op;
        auto start_3 = start;
        call_then(start_lex_qualified_path(l_1), [=, op_2 = std::move(op_2), start_3 = std::move(start_3)](std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_4539) {
        return ({
            auto [path_, l2] = lex_qualified_path_4539;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSuffixed{op_2, path_}), start_3, prism_rtl::deref(l2).pos)));
        });
    });
    })
        : prism_rtl::finished(crate::syntax::lexer::push_tok(l, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOp{op, false}), start, prism_rtl::deref(l).pos));
}


/// `Start PushOpSuffix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_push_op_suffix(crate::syntax::lexer::Lex l, Text op, Nat start) {
    return prism_rtl::make_rc<PushOpSuffix>(l, op, start);
}


/// FirstOp: fn Lex -> Text
Text first_op(const crate::syntax::lexer::Lex& l) {
    return crate::syntax::lexer::chars::match_here(crate::syntax::lexer::fat_arrow_on(l)
        ? ([]() -> const Regex& { static const Regex r = Regex::lit("==>|<-|<=|<\\||->|-=|-\\?|\\+=|\\+\\?|\\*=|\\*\\?|\\/=|==|>=|=>|<|>|-|\\+|\\*|\\/|=", ""); return r; }())
        : ([]() -> const Regex& { static const Regex r = Regex::lit("==>|<-|<=|<\\||->|-=|-\\?|\\+=|\\+\\?|\\*=|\\*\\?|\\/=|==|>=|<|>|-|\\+|\\*|\\/|=", ""); return r; }()), l);
}


/// EndsMark: fn Text -> Bool
bool ends_mark(const Text& a) {
    return (a == Text::lit("")) || crate::syntax::lexer::chars::contains(Text::lit(" \n\r,)]}"), a);
}


/// ClosesSquareOrBrace: fn ?Tok -> Bool
bool closes_square_or_brace(const std::optional<crate::syntax::lexer::Tok>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& t = prism_rtl::some_of(opt0);
        return (prism_rtl::deref(t).kind == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KClose{Text::lit("[")})) || (prism_rtl::deref(t).kind == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KClose{Text::lit("{")}));
    }
    if (prism_rtl::is_none(opt0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?LexOperator: unbounded fn Lex, Nat -> ?Lex
std::optional<crate::syntax::lexer::Lex> lex_operator(const crate::syntax::lexer::Lex& l, const Nat& start) {
    auto c = crate::syntax::lexer::chars::peek(l);
    auto after_ = crate::syntax::lexer::chars::peek_at(l, Nat(1u));
    auto non_empty = (((c == Text::lit("+")) && (!l.last_ws)) && closes_square_or_brace(crate::syntax::lexer::chars::last(l.tokens))) && (ends_mark(after_) || ((after_ == Text::lit("?")) && ends_mark(crate::syntax::lexer::chars::peek_at(l, Nat(2u)))));
    return (c == Text::lit("-")) && crate::syntax::lexer::chars::contains(Text::lit(",)]}"), after_)
        ? std::optional(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KAbsent{}), start, start + Nat(1u)))
        : std::move(non_empty)
        ? std::optional(non_empty_mark(l, start, after_))
        : crate::syntax::lexer::chars::starts_with(l, Text::lit("<<"))
        ? std::optional(open_type_args(l, start))
        : crate::syntax::lexer::chars::starts_with(l, Text::lit(">>")) && (crate::syntax::lexer::chars::last(l.frames) == std::optional(Text::lit("<<")))
        ? std::optional(close_type_args(l, start))
        : crate::syntax::lexer::chars::starts_with(l, Text::lit(">>"))
        ? std::optional(crate::syntax::lexer::chars::lex_err(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::forward(l, Nat(2u)), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KGtGt{}), start, start + Nat(2u)), start, start + Nat(2u), Text::lit("`>>` closes explicit type arguments, and none is open (Prism has no shift operators)")))
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::syntax::lexer::Lex>> _v;
        auto&& _m = first_op(l);
        {
            auto&& m6465_0 = _m;
            if (m6465_0 == Text::lit("")) {
                _v.set(std::optional<crate::syntax::lexer::Lex>{});
                goto _done;
            }
        }
        {
            auto&& op = _m;
            _v.set(std::optional(push_operator(l, op, start)));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::optional<crate::syntax::lexer::Lex>> LexOperator::cycle() const {
    const auto& l = this->l;
    const auto& start = this->start;
    auto c = crate::syntax::lexer::chars::peek(l);
    auto after_ = crate::syntax::lexer::chars::peek_at(l, Nat(1u));
    auto non_empty = (((c == Text::lit("+")) && (!prism_rtl::deref(l).last_ws)) && closes_square_or_brace(crate::syntax::lexer::chars::last(l->tokens))) && (ends_mark(after_) || ((after_ == Text::lit("?")) && ends_mark(crate::syntax::lexer::chars::peek_at(l, Nat(2u)))));
    return (c == Text::lit("-")) && crate::syntax::lexer::chars::contains(Text::lit(",)]}"), after_)
        ? prism_rtl::finished(std::optional(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KAbsent{}), start, start + Nat(1u))))
        : std::move(non_empty)
        ? prism_rtl::finished(std::optional(non_empty_mark(l, start, after_)))
        : crate::syntax::lexer::chars::starts_with(l, Text::lit("<<"))
        ? prism_rtl::finished(std::optional(open_type_args(l, start)))
        : crate::syntax::lexer::chars::starts_with(l, Text::lit(">>")) && (crate::syntax::lexer::chars::last(prism_rtl::deref(l).frames) == std::optional(Text::lit("<<")))
        ? prism_rtl::finished(std::optional(close_type_args(l, start)))
        : crate::syntax::lexer::chars::starts_with(l, Text::lit(">>"))
        ? prism_rtl::finished(std::optional(crate::syntax::lexer::chars::lex_err(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::forward(l, Nat(2u)), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KGtGt{}), start, start + Nat(2u)), start, start + Nat(2u), Text::lit("`>>` closes explicit type arguments, and none is open (Prism has no shift operators)"))))
        : ({
        auto&& _m = first_op(l);
        ({
        auto&& m6465_0 = _m;
        (m6465_0 == Text::lit(""));
    }) ? ({
        auto&& m6465_0 = _m;
        prism_rtl::finished(std::optional<crate::syntax::lexer::Lex>{});
    })
        : ({
        auto&& op = _m;
        prism_rtl::finished(std::optional(push_operator(l, op, start)));
    });
    });
}


/// `Start LexOperator, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::syntax::lexer::Lex>> start_lex_operator(crate::syntax::lexer::Lex l, Nat start) {
    return prism_rtl::make_rc<LexOperator>(l, start);
}


/// NonEmptyMark: fn Lex, Nat, Text -> Lex
crate::syntax::lexer::Lex non_empty_mark(const crate::syntax::lexer::Lex& l, const Nat& start, const Text& after_) {
    auto l1 = crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KNonEmpty{}), start, start + Nat(1u));
    return after_ == Text::lit("?")
        ? crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l1), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFree{Text::lit("?")}), prism_rtl::deref(l1).pos, prism_rtl::deref(l1).pos + Nat(1u))
        : l1;
}


/// OpenTypeArgs: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex open_type_args(const crate::syntax::lexer::Lex& l, const Nat& start) {
    auto touching = (!l.last_ws) && is_name_tok(crate::syntax::lexer::chars::last(l.tokens));
    auto l1 = crate::syntax::lexer::chars::forward(l, Nat(2u));
    auto l2 = std::move(touching)
        ? l1
        : crate::syntax::lexer::chars::lex_err(l1, start, prism_rtl::deref(l1).pos, Text::lit("`<<` opens explicit type arguments and must touch a name on its left (Prism has no shift operators)"));
    auto l3 = ({
        crate::syntax::lexer::Lex this_ = l2;
        this_.frames = crate::prelude::push(this_.frames, Text::lit("<<"));
        (std::move(this_));
    });
    return crate::syntax::lexer::push_tok(l3, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLtLt{}), start, prism_rtl::deref(l3).pos);
}


/// IsNameTok: fn ?Tok -> Bool
bool is_name_tok(const std::optional<crate::syntax::lexer::Tok>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& t = prism_rtl::some_of(opt0);
        auto&& _m = prism_rtl::deref(t).kind;
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(opt0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CloseTypeArgs: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex close_type_args(const crate::syntax::lexer::Lex& l, const Nat& start) {
    auto l1 = ({
        crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::forward(l, Nat(2u));
        this_.frames = crate::syntax::lexer::chars::pop(this_.frames);
        (std::move(this_));
    });
    return crate::syntax::lexer::push_tok(l1, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KGtGt{}), start, prism_rtl::deref(l1).pos);
}


/// PushOperator: unbounded fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex push_operator(const crate::syntax::lexer::Lex& l, const Text& op, const Nat& start) {
    auto l1 = crate::syntax::lexer::chars::forward(l, len_text(op));
    return (((op == Text::lit("+")) || (op == Text::lit("-"))) || (op == Text::lit("-?"))) && (!crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::peek(l1)))
        ? crate::syntax::lexer::push_tok(l1, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOp{op, crate::syntax::lexer::prefix_position(l1) && (!crate::syntax::lexer::chars::next_is_space(l1, Nat(0u)))}), start, prism_rtl::deref(l1).pos)
        : push_op_suffix(l1, op, start);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> PushOperator::cycle() const {
    const auto& l = this->l;
    const auto& op = this->op;
    const auto& start = this->start;
    auto l1 = crate::syntax::lexer::chars::forward(l, len_text(op));
    return (((op == Text::lit("+")) || (op == Text::lit("-"))) || (op == Text::lit("-?"))) && (!crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::peek(l1)))
        ? prism_rtl::finished(crate::syntax::lexer::push_tok(l1, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOp{op, crate::syntax::lexer::prefix_position(l1) && (!crate::syntax::lexer::chars::next_is_space(l1, Nat(0u)))}), start, prism_rtl::deref(l1).pos))
        : prism_rtl::more(prism_rtl::rc(PushOpSuffix(l1, op, start)));
}


/// `Start PushOperator, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_push_operator(crate::syntax::lexer::Lex l, Text op, Nat start) {
    return prism_rtl::make_rc<PushOperator>(l, op, start);
}


/// LexSigils: unbounded fn Lex -> Lex
crate::syntax::lexer::Lex lex_sigils(const crate::syntax::lexer::Lex& l0) {
    auto start = l0.pos;
    auto [sigils, caret, l] = read_sigils(l0);
    auto next_ = crate::syntax::lexer::chars::peek(l);
    return caret
        ? lex_caret(l, start, sigils, next_)
        : ((crate::syntax::lexer::chars::is_ident_start(next_) || crate::syntax::lexer::chars::is_digit(next_)) || (next_ == Text::lit("\""))) || (next_ == Text::lit("%"))
        ? lex_attached(l, start, sigils, next_)
        : ((sigils == Text::lit("&")) && (next_ == Text::lit("."))) && crate::syntax::lexer::chars::is_lower(crate::syntax::lexer::chars::peek_at(l, Nat(1u)))
        ? crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLensDot{}), start, prism_rtl::deref(l).pos + Nat(1u))
        : free_sigils(l, start, sigils);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexSigils::cycle() const {
    const auto& l0 = this->l0;
    auto start = prism_rtl::deref(l0).pos;
    auto l0_1 = l0;
    return call_then(start_read_sigils(l0_1), [=](std::tuple<Text, bool, crate::syntax::lexer::Lex> read_sigils_8705) {
        return ({
            auto [sigils, caret, l] = read_sigils_8705;
            auto next_ = crate::syntax::lexer::chars::peek(l);
            caret
            ? prism_rtl::more(prism_rtl::rc(LexCaret(l, start, sigils, next_)))
            : ((crate::syntax::lexer::chars::is_ident_start(next_) || crate::syntax::lexer::chars::is_digit(next_)) || (next_ == Text::lit("\""))) || (next_ == Text::lit("%"))
            ? prism_rtl::more(prism_rtl::rc(LexAttached(l, start, sigils, next_)))
            : ((sigils == Text::lit("&")) && (next_ == Text::lit("."))) && crate::syntax::lexer::chars::is_lower(crate::syntax::lexer::chars::peek_at(l, Nat(1u)))
            ? prism_rtl::finished(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLensDot{}), start, prism_rtl::deref(l).pos + Nat(1u)))
            : prism_rtl::finished(free_sigils(l, start, sigils));
        });
    });
}


/// `Start LexSigils, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_sigils(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexSigils>(l0);
}


/// ReadSigils: unbounded fn Lex -> ((Text, Bool, Lex))
std::tuple<Text, bool, crate::syntax::lexer::Lex> read_sigils(const crate::syntax::lexer::Lex& l0) {
    std::tuple<Text, bool, crate::syntax::lexer::Lex> this_ = std::tuple{Text::lit(""), false, l0};
    crate::syntax::lexer::Lex l = l0;
    Text sigils = Text::lit("");
    bool caret = false;
    bool going = true;
    while (std::move(going)) {
        auto c = crate::syntax::lexer::chars::peek(l);
        if (c == Text::lit("^")) {
            l = crate::syntax::lexer::chars::bump(l);
            caret = true;
            going = false;
        } else if (crate::syntax::lexer::chars::is_sigil_char(c) && (!((c == Text::lit("!")) && (crate::syntax::lexer::chars::peek_at(l, Nat(1u)) == Text::lit("="))))) {
            l = crate::syntax::lexer::chars::bump(l);
            sigils = prism_rtl::cat(sigils, c);
        } else  {
            going = false;
        }
    }
    this_ = std::tuple{sigils, std::move(caret), l};
    return this_;
}


prism_rtl::Turn<std::tuple<Text, bool, crate::syntax::lexer::Lex>> ReadSigils::cycle() const {
    const auto& l0 = this->l0;
    std::tuple<Text, bool, crate::syntax::lexer::Lex> this_ = std::tuple{Text::lit(""), false, l0};
    crate::syntax::lexer::Lex l = l0;
    Text sigils = Text::lit("");
    bool caret = false;
    bool going = true;
    return call_then(loop_job(std::tuple{std::move(this_), std::move(caret), std::move(going), std::move(l), std::move(sigils)}, [=](std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text> _p0) {
        auto this_ = std::get<0>(_p0);
        auto caret = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto l = std::get<3>(_p0);
        auto sigils = std::get<4>(_p0);
        return going
            ? ({
            auto c = crate::syntax::lexer::chars::peek(l);
            if (c == Text::lit("^")) {
                l = crate::syntax::lexer::chars::bump(l);
                caret = true;
                going = false;
            } else if (crate::syntax::lexer::chars::is_sigil_char(c) && (!((c == Text::lit("!")) && (crate::syntax::lexer::chars::peek_at(l, Nat(1u)) == Text::lit("="))))) {
                l = crate::syntax::lexer::chars::bump(l);
                sigils = prism_rtl::cat(sigils, c);
            } else  {
                going = false;
            }
            Expected<std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text>, std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text>>(std::tuple{this_, caret, going, l, sigils});
        })
            : Expected<std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text>, std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text>>(unexpected(std::tuple{this_, caret, going, l, sigils}));
    }), [=](std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text> _p0) {
        auto this_ = std::get<0>(_p0);
        auto caret = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto l = std::get<3>(_p0);
        auto sigils = std::get<4>(_p0);
        return ({
            this_ = std::tuple{sigils, caret, l};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start ReadSigils, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, bool, crate::syntax::lexer::Lex>> start_read_sigils(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<ReadSigils>(l0);
}


/// LexCaret: unbounded fn Lex, Nat, Text, Text -> Lex
crate::syntax::lexer::Lex lex_caret(const crate::syntax::lexer::Lex& l, const Nat& start, const Text& sigils, const Text& next_) {
    return crate::syntax::lexer::chars::is_upper(next_) && (sigils == Text::lit(""))
        ? ({
        auto [path_, l2] = lex_qualified_path(l);
        (crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KTrait{path_}), start, prism_rtl::deref(l2).pos));
    })
        : ({
        auto&& _skipped = lex_qualified_path(l);
        auto&& skipped = std::get<1>(_skipped);
        auto l2 = crate::syntax::lexer::chars::is_ident_start(next_) ? skipped : l;
        (crate::syntax::lexer::chars::lex_err(l2, start, crate::prelude::max(prism_rtl::deref(l2).pos, l.pos), Text::lit("`^` marks a trait and attaches to its uppercase name: no trait is a value")));
    });
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexCaret::cycle() const {
    const auto& l = this->l;
    const auto& start = this->start;
    const auto& sigils = this->sigils;
    const auto& next_ = this->next_;
    return crate::syntax::lexer::chars::is_upper(next_) && (sigils == Text::lit(""))
        ? ({
        auto l_1 = l;
        auto start_2 = start;
        call_then(start_lex_qualified_path(l_1), [=, start_2 = std::move(start_2)](std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_9909) {
        return ({
            auto [path_, l2] = lex_qualified_path_9909;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KTrait{path_}), start_2, prism_rtl::deref(l2).pos)));
        });
    });
    })
        : ({
        auto l_1 = l;
        auto next__2 = next_;
        auto start_3 = start;
        call_then(start_lex_qualified_path(l_1), [=, next__2 = std::move(next__2), start_3 = std::move(start_3)](std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_10021) {
        return ({
            auto&& _skipped = lex_qualified_path_10021;
            auto&& skipped = std::get<1>(_skipped);
            auto l2 = crate::syntax::lexer::chars::is_ident_start(next__2) ? skipped : l_1;
            (prism_rtl::finished(crate::syntax::lexer::chars::lex_err(l2, start_3, crate::prelude::max(prism_rtl::deref(l2).pos, prism_rtl::deref(l_1).pos), Text::lit("`^` marks a trait and attaches to its uppercase name: no trait is a value"))));
        });
    });
    });
}


/// `Start LexCaret, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_caret(crate::syntax::lexer::Lex l, Nat start, Text sigils, Text next_) {
    return prism_rtl::make_rc<LexCaret>(l, start, sigils, next_);
}


/// LexAttached: unbounded fn Lex, Nat, Text, Text -> Lex
crate::syntax::lexer::Lex lex_attached(const crate::syntax::lexer::Lex& l, const Nat& start, const Text& sigils, const Text& next_) {
    return next_ == Text::lit("\"")
        ? ({
        auto [text_, l2] = crate::syntax::lexer::literals::lex_text(l);
        (crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KText{sigils, text_}), start, prism_rtl::deref(l2).pos));
    })
        : crate::syntax::lexer::chars::is_digit(next_)
        ? ({
        auto [kind, l2] = crate::syntax::lexer::literals::lex_number(l, sigils);
        (crate::syntax::lexer::push_tok(l2, kind, start, prism_rtl::deref(l2).pos));
    })
        : next_ == Text::lit("%")
        ? crate::syntax::lexer::regexes::lex_regex(l, sigils, start)
        : lex_word_token(l, sigils, start);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexAttached::cycle() const {
    const auto& l = this->l;
    const auto& start = this->start;
    const auto& sigils = this->sigils;
    const auto& next_ = this->next_;
    return next_ == Text::lit("\"")
        ? ({
        auto l_1 = l;
        auto sigils_2 = sigils;
        auto start_3 = start;
        call_then(crate::syntax::lexer::literals::start_lex_text(l_1), [=, sigils_2 = std::move(sigils_2), start_3 = std::move(start_3)](std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> lex_text_10360) {
        return ({
            auto [text_, l2] = lex_text_10360;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KText{sigils_2, text_}), start_3, prism_rtl::deref(l2).pos)));
        });
    });
    })
        : crate::syntax::lexer::chars::is_digit(next_)
        ? ({
        auto l_1 = l;
        auto sigils_2 = sigils;
        auto start_3 = start;
        call_then(crate::syntax::lexer::literals::start_lex_number(l_1, sigils_2), [=, start_3 = std::move(start_3)](std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_number_10480) {
        return ({
            auto [kind, l2] = lex_number_10480;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2, kind, start_3, prism_rtl::deref(l2).pos)));
        });
    });
    })
        : next_ == Text::lit("%")
        ? prism_rtl::more(prism_rtl::rc(crate::syntax::lexer::regexes::LexRegex(l, sigils, start)))
        : prism_rtl::more(prism_rtl::rc(LexWordToken(l, sigils, start)));
}


/// `Start LexAttached, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_attached(crate::syntax::lexer::Lex l, Nat start, Text sigils, Text next_) {
    return prism_rtl::make_rc<LexAttached>(l, start, sigils, next_);
}


/// FreeSigils: fn Lex, Nat, Text -> Lex
crate::syntax::lexer::Lex free_sigils(const crate::syntax::lexer::Lex& l0, const Nat& start, const Text& sigils) {
    crate::syntax::lexer::Lex this_ = l0;
    auto space_after = crate::syntax::lexer::chars::next_is_space(this_, Nat(0u));
    auto all = crate::syntax::lexer::chars::fold_chars(sigils, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                (prism_rtl::finished(crate::prelude::push(acc, c)));
            });
        });
    })));
    for (auto&& [i10960, v10960] : prism_rtl::enumerate(all)) {
        auto k10960 = nat_of(i10960);
        auto s = v10960;
        auto at_ = start + k10960;
        if (std::move(space_after) && ((k10960 + Nat(1u)) == len(all))) {
            if (s == Text::lit("!")) {
                this_ = crate::syntax::lexer::chars::lex_err(this_, at_, at_ + Nat(1u), Text::lit("`!` is never free: no event fires a constant (write `!e` touching its name)"));
            }
            if (s == Text::lit("&")) {
                this_ = crate::syntax::lexer::chars::lex_err(this_, at_, at_ + Nat(1u), Text::lit("`&` is never free: no reference exists outside the value an `update` block names"));
            }
        }
        this_ = crate::syntax::lexer::push_tok(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFree{s}), at_, at_ + Nat(1u));
    }
    return this_;
}


/// LexQualifiedPath: unbounded fn Lex -> (([Text], Lex))
std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path(const crate::syntax::lexer::Lex& l0) {
    std::tuple<Array<Text>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<Text>{}, l0};
    auto [first_, l1] = lex_ident(l0);
    Array<Text> path_ = Array(std::vector{first_});
    crate::syntax::lexer::Lex l = l1;
    bool going = true;
    while (std::move(going)) {
        auto last_1 = or_(crate::syntax::lexer::chars::last(path_), Text::lit(""));
        auto next_ = crate::syntax::lexer::chars::peek_at(l, Nat(1u));
        if ((crate::syntax::lexer::chars::peek(l) != Text::lit(".")) || (!crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::head(last_1)))) {
            going = false;
        } else if (crate::syntax::lexer::chars::is_upper(next_)) {
            auto [seg, l2] = lex_ident(crate::syntax::lexer::chars::bump(l));
            path_ = crate::prelude::push(path_, seg);
            l = l2;
        } else  {
            going = false;
            if (crate::syntax::lexer::chars::is_ident_start(next_)) {
                auto [w, l2] = lex_ident(crate::syntax::lexer::chars::bump(l));
                if (crate::syntax::lexer::chars::is_reserved_ctor(w)) {
                    path_ = crate::prelude::push(path_, w);
                    l = l2;
                }
            }
        }
    }
    this_ = std::tuple{path_, l};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<Text>, crate::syntax::lexer::Lex>> LexQualifiedPath::cycle() const {
    const auto& l0 = this->l0;
    std::tuple<Array<Text>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<Text>{}, l0};
    auto [first_, l1] = lex_ident(l0);
    Array<Text> path_ = Array(std::vector{first_});
    crate::syntax::lexer::Lex l = l1;
    bool going = true;
    return call_then(loop_job(std::tuple{std::move(this_), std::move(going), std::move(l), std::move(path_)}, [=](std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto l = std::get<2>(_p0);
        auto path_ = std::get<3>(_p0);
        return going
            ? ({
            auto last_1 = or_(crate::syntax::lexer::chars::last(path_), Text::lit(""));
            auto next_ = crate::syntax::lexer::chars::peek_at(l, Nat(1u));
            if ((crate::syntax::lexer::chars::peek(l) != Text::lit(".")) || (!crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::head(last_1)))) {
                going = false;
            } else if (crate::syntax::lexer::chars::is_upper(next_)) {
                auto [seg, l2] = lex_ident(crate::syntax::lexer::chars::bump(l));
                path_ = crate::prelude::push(path_, seg);
                l = l2;
            } else  {
                going = false;
                if (crate::syntax::lexer::chars::is_ident_start(next_)) {
                    auto [w, l2] = lex_ident(crate::syntax::lexer::chars::bump(l));
                    if (crate::syntax::lexer::chars::is_reserved_ctor(w)) {
                        path_ = crate::prelude::push(path_, w);
                        l = l2;
                    }
                }
            }
            Expected<std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>>, std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>>>(std::tuple{this_, going, l, path_});
        })
            : Expected<std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>>, std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>>>(unexpected(std::tuple{this_, going, l, path_}));
    }), [=](std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto l = std::get<2>(_p0);
        auto path_ = std::get<3>(_p0);
        return ({
            this_ = std::tuple{path_, l};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start LexQualifiedPath, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, crate::syntax::lexer::Lex>> start_lex_qualified_path(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexQualifiedPath>(l0);
}


/// LexIdent: unbounded fn Lex -> ((Text, Lex))
std::tuple<Text, crate::syntax::lexer::Lex> lex_ident(const crate::syntax::lexer::Lex& l0) {
    auto word = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_]*", ""); return r; }()), l0);
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = this_.pos + len_text(word);
        (std::move(this_));
    });
    return std::tuple{word, l};
}


prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> LexIdent::cycle() const {
    const auto& l0 = this->l0;
    auto word = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_]*", ""); return r; }()), l0);
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = this_.pos + len_text(word);
        (std::move(this_));
    });
    return prism_rtl::finished(std::tuple{word, l});
}


/// `Start LexIdent, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_lex_ident(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexIdent>(l0);
}


/// LexWordToken: unbounded fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex lex_word_token(const crate::syntax::lexer::Lex& l0, const Text& sigils, const Nat& start) {
    auto w_start = l0.pos;
    auto [path_, l1] = lex_qualified_path(l0);
    auto l = crate::syntax::lexer::chars::is_non_ascii(crate::syntax::lexer::chars::peek(l1))
        ? skip_non_ascii(l1, w_start)
        : l1;
    auto first_ = or_(index(path_, Nat(0u)), Text::lit(""));
    return crate::syntax::lexer::chars::starts_with(l, Text::lit(".*")) && crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::head(first_))
        ? ({
        auto l2 = crate::syntax::lexer::chars::forward(l, Nat(2u));
        auto l3 = sigils != Text::lit("")
            ? crate::syntax::lexer::chars::lex_err(l2, start, prism_rtl::deref(l2).pos, Text::lit("a family pattern takes no sigil"))
            : l2;
        (crate::syntax::lexer::push_tok(l3, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFamily{path_}), start, prism_rtl::deref(l3).pos));
    })
        : ((len(path_) == Nat(1u)) && crate::syntax::lexer::is_keyword(first_)) && (!(crate::syntax::lexer::is_bound_word(first_) && (sigils != Text::lit(""))))
        ? lex_keyword(l, first_, sigils, start)
        : lex_name(l, path_, sigils, start, w_start);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexWordToken::cycle() const {
    const auto& l0 = this->l0;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    auto w_start = prism_rtl::deref(l0).pos;
    auto l0_1 = l0;
    auto sigils_2 = sigils;
    auto start_3 = start;
    return call_then(start_lex_qualified_path(l0_1), [=](std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_12808) {
        return ({
            auto [path_, l1] = lex_qualified_path_12808;
            auto l = crate::syntax::lexer::chars::is_non_ascii(crate::syntax::lexer::chars::peek(l1))
                ? skip_non_ascii(l1, w_start)
                : l1;
            auto first_ = or_(index(path_, Nat(0u)), Text::lit(""));
            (crate::syntax::lexer::chars::starts_with(l, Text::lit(".*")) && crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::head(first_))
            ? ({
            auto l2 = crate::syntax::lexer::chars::forward(l, Nat(2u));
            auto l3 = sigils_2 != Text::lit("")
                ? crate::syntax::lexer::chars::lex_err(l2, start_3, prism_rtl::deref(l2).pos, Text::lit("a family pattern takes no sigil"))
                : l2;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l3, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFamily{path_}), start_3, prism_rtl::deref(l3).pos)));
        })
            : ((len(path_) == Nat(1u)) && crate::syntax::lexer::is_keyword(first_)) && (!(crate::syntax::lexer::is_bound_word(first_) && (sigils_2 != Text::lit(""))))
            ? prism_rtl::more(prism_rtl::rc(LexKeyword(l, first_, sigils_2, start_3)))
            : prism_rtl::more(prism_rtl::rc(LexName(l, path_, sigils_2, start_3, w_start))));
        });
    });
}


/// `Start LexWordToken, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_word_token(crate::syntax::lexer::Lex l0, Text sigils, Nat start) {
    return prism_rtl::make_rc<LexWordToken>(l0, sigils, start);
}


/// SkipNonAscii: unbounded fn Lex, Nat -> Lex
crate::syntax::lexer::Lex skip_non_ascii(const crate::syntax::lexer::Lex& l0, const Nat& w_start) {
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_\\x{80}-\\x{10FFFF}]*", ""); return r; }()), this_.src, this_.pos);
        (std::move(this_));
    });
    return crate::syntax::lexer::chars::lex_err(l, w_start, prism_rtl::deref(l).pos, Text::lit("names are ASCII letters, digits and underscores"));
}


prism_rtl::Turn<crate::syntax::lexer::Lex> SkipNonAscii::cycle() const {
    const auto& l0 = this->l0;
    const auto& w_start = this->w_start;
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_\\x{80}-\\x{10FFFF}]*", ""); return r; }()), this_.src, this_.pos);
        (std::move(this_));
    });
    return prism_rtl::finished(crate::syntax::lexer::chars::lex_err(l, w_start, prism_rtl::deref(l).pos, Text::lit("names are ASCII letters, digits and underscores")));
}


/// `Start SkipNonAscii, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_skip_non_ascii(crate::syntax::lexer::Lex l0, Nat w_start) {
    return prism_rtl::make_rc<SkipNonAscii>(l0, w_start);
}


/// LexKeyword: unbounded fn Lex, Text, Text, Nat -> Lex
crate::syntax::lexer::Lex lex_keyword(const crate::syntax::lexer::Lex& l, const Text& w, const Text& sigils, const Nat& start) {
    auto l1 = (sigils != Text::lit("")) && (!(((w == Text::lit("widget")) || (w == Text::lit("unit"))) || (w == Text::lit("nil"))))
        ? crate::syntax::lexer::chars::lex_err(l, start, l.pos, prism_rtl::cat("`", w, "` is a keyword and takes no sigil"))
        : l;
    auto l2 = (w == Text::lit("widget")) && (sigils != Text::lit("@"))
        ? crate::syntax::lexer::chars::lex_err(l1, start, prism_rtl::deref(l1).pos, Text::lit("`widget` is a block only as `@widget:`"))
        : l1;
    auto l3 = crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KKw{w, sigils}), start, prism_rtl::deref(l2).pos);
    return ((w == Text::lit("output")) || (w == Text::lit("inline_text"))) || (w == Text::lit("raw"))
        ? crate::syntax::lexer::templates::maybe_template(l3, w)
        : l3;
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexKeyword::cycle() const {
    const auto& l = this->l;
    const auto& w = this->w;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    auto l1 = (sigils != Text::lit("")) && (!(((w == Text::lit("widget")) || (w == Text::lit("unit"))) || (w == Text::lit("nil"))))
        ? crate::syntax::lexer::chars::lex_err(l, start, prism_rtl::deref(l).pos, prism_rtl::cat("`", w, "` is a keyword and takes no sigil"))
        : l;
    auto l2 = (w == Text::lit("widget")) && (sigils != Text::lit("@"))
        ? crate::syntax::lexer::chars::lex_err(l1, start, prism_rtl::deref(l1).pos, Text::lit("`widget` is a block only as `@widget:`"))
        : l1;
    auto l3 = crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KKw{w, sigils}), start, prism_rtl::deref(l2).pos);
    return ((w == Text::lit("output")) || (w == Text::lit("inline_text"))) || (w == Text::lit("raw"))
        ? prism_rtl::more(prism_rtl::rc(crate::syntax::lexer::templates::MaybeTemplate(l3, w)))
        : prism_rtl::finished(l3);
}


/// `Start LexKeyword, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_keyword(crate::syntax::lexer::Lex l, Text w, Text sigils, Nat start) {
    return prism_rtl::make_rc<LexKeyword>(l, w, sigils, start);
}


/// LexName: unbounded fn Lex, [Text], Text, Nat, Nat -> Lex
crate::syntax::lexer::Lex lex_name(const crate::syntax::lexer::Lex& l, const Array<Text>& path_, const Text& sigils, const Nat& start, const Nat& w_start) {
    auto [case_, l1] = name_case_of(l, path_, w_start);
    auto l2 = is_path_word(l1, sigils, path_)
        ? ({
        crate::syntax::lexer::Lex this_ = l1;
        this_.path_next = true;
        (std::move(this_));
    })
        : l1;
    return crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KName{crate::syntax::lexer::NameTok{.sigils = sigils, .path_ = path_, .case_ = case_}}), start, prism_rtl::deref(l2).pos);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexName::cycle() const {
    const auto& l = this->l;
    const auto& path_ = this->path_;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    const auto& w_start = this->w_start;
    auto [case_, l1] = name_case_of(l, path_, w_start);
    auto l2 = is_path_word(l1, sigils, path_)
        ? ({
        crate::syntax::lexer::Lex this_ = l1;
        this_.path_next = true;
        (std::move(this_));
    })
        : l1;
    return prism_rtl::finished(crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KName{crate::syntax::lexer::NameTok{.sigils = sigils, .path_ = path_, .case_ = case_}}), start, prism_rtl::deref(l2).pos));
}


/// `Start LexName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_name(crate::syntax::lexer::Lex l, Array<Text> path_, Text sigils, Nat start, Nat w_start) {
    return prism_rtl::make_rc<LexName>(l, path_, sigils, start, w_start);
}


/// NameCaseOf: fn Lex, [Text], Nat -> ((NameCase, Lex))
std::tuple<crate::syntax::lexer::NameCase, crate::syntax::lexer::Lex> name_case_of(const crate::syntax::lexer::Lex& l, const Array<Text>& path_, const Nat& w_start) {
    auto last_1 = or_(crate::syntax::lexer::chars::last(path_), Text::lit(""));
    return last_1 == Text::lit("_")
        ? std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseTopic{}), l}
        : (crate::syntax::lexer::chars::head(last_1) == Text::lit("_")) && crate::syntax::lexer::chars::all_chars(crate::syntax::lexer::chars::after_first(last_1), ({
        auto f = prism_rtl::rc(crate::syntax::lexer::chars::is_digit);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
        return ({
            auto f_2 = f;
            once_job([=, f_2 = std::move(f_2)]() { return prism_rtl::finished(f_2(a0)); });
        });
    })));
    }))
        ? std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseHole{}), l}
        : crate::syntax::lexer::chars::head(last_1) == Text::lit("_")
        ? std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}), crate::syntax::lexer::chars::lex_err(l, w_start, l.pos, Text::lit("`_` followed by a letter is not a name: `_` alone is the topic, `_1` a hole"))}
        : crate::syntax::lexer::chars::is_reserved_ctor(last_1)
        ? std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseReserved{}), l}
        : crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::head(last_1))
        ? ({
        auto underscored = fold(path_, false, [&](const bool& seen, const Text& seg) { return prism_rtl::deref(seen) || crate::syntax::lexer::chars::contains(seg, Text::lit("_")); });
        std::move(underscored)
        ? std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{}), crate::syntax::lexer::chars::lex_err(l, w_start, l.pos, prism_rtl::cat("`", crate::syntax::lexer::chars::join(path_, Text::lit(".")), "`: a capital promises UpperCamelCase"))}
        : std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{}), l};
    })
        : std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}), l};
}


/// IsPathWord: fn Lex, Text, [Text] -> Bool
bool is_path_word(const crate::syntax::lexer::Lex& l, const Text& sigils, const Array<Text>& path_) {
    auto w = or_(index(path_, Nat(0u)), Text::lit(""));
    auto words = w == Text::lit("at")
        ? Array(std::vector{Text::lit("send"), Text::lit("click"), Text::lit("answer")})
        : Array(std::vector{Text::lit("click")});
    auto prev = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::syntax::lexer::chars::last(l.tokens);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = prism_rtl::deref(t).kind;
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
                    auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
                    if ((prism_rtl::deref(n).sigils == Text::lit("")) && (len(n->path_) == Nat(1u))) {
                        _v.set(or_(index(n->path_, Nat(0u)), Text::lit("")));
                        goto _done;
                    }
                }
                {
                    _v.set(Text::lit(""));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ((((l.test_depth != std::optional<Nat>{}) && (sigils == Text::lit(""))) && (len(path_) == Nat(1u))) && ((w == Text::lit("at")) || (w == Text::lit("element")))) && fold(words, false, [&](const bool& seen, const Text& x) { return prism_rtl::deref(seen) || (x == prev); });
}

}  // namespace crate::syntax::lexer::words
