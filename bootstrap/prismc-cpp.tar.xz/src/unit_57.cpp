// The module `Lower.Patterns`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/patterns/module.hpp>
#include <lower/model/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Lower.Patterns`, from `target/bootstrap/cpp-src/prismc/lower/patterns.prism`.
namespace crate::lower::patterns {



/// PatOnly: fn Pa -> PatOut
PatOut pat_only_f(const crate::lower::model::Pa& pa_p0) {
    return PatOut{.pa_p = pa_p0, .conds_p = Array<crate::lower::model::Cc>{}, .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
}


/// RustPat: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
PatOut rust_pat_f(const crate::lower::Lx& lx_p0, const crate::syntax::Pattern_& p_p1, const crate::check::types::Ty& ty_p2, const crate::lower::types::Holding& mode_p3, const Text& fresh_p4) {
    auto&& _m = prism_rtl::deref(p_p1.kind_p);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p5 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto nkey_p6 = crate::check::env::sname_key_f(n_p5);
        auto [qk_o9, why_pa] = crate::check::env::names::resolve_value_f(lx_p0.g_p, lx_p0.home_p, n_p5);
        auto is_ctor_p7 = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is_some(qk_o9)) {
                auto&& qk_pb = prism_rtl::some_of(qk_o9);
                _v.set(crate::check::env::has_key_f(prism_rtl::deref(lx_p0.g_p).ctors_p, qk_pb) && ((crate::check::env::is_upper_text_f(crate::lower::base_f(nkey_p6)) || (crate::prelude::len(prism_rtl::deref(n_p5).path_p) > Nat(1u))) || is_unit_ctor_f(lx_p0, qk_pb)));
                goto _done;
            }
            if (prism_rtl::is_none(qk_o9)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto tagged_o8 = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::check::env::TagInfo>> _v;
            if (prism_rtl::is_some(qk_o9)) {
                auto&& qk_pc = prism_rtl::some_of(qk_o9);
                _v.set(crate::prelude::get(prism_rtl::deref(lx_p0.g_p).tags_p, qk_pc));
                goto _done;
            }
            if (prism_rtl::is_none(qk_o9)) {
                _v.set(std::optional<crate::check::env::TagInfo>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return std::move(is_ctor_p7)
            ? ctor_pat_f(lx_p0, n_p5, Array<crate::syntax::Pattern_>{}, ty_p2, mode_p3, fresh_p4)
            : (why_pa == Text::lit("tag")) && (tagged_o8 != std::optional<crate::check::env::TagInfo>{})
            ? tag_pat_f(lx_p0, crate::prelude::or_(tagged_o8, dummy_tag_info_p()), Array<crate::syntax::FieldPat>{}, true, ty_p2, mode_p3, fresh_p4)
            : ({
            auto rs_pd = crate::lower::local_name_at_f(lx_p0, nkey_p6, prism_rtl::deref(n_p5).span_p);
            auto bt_pe = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::binder_ty_f(lx_p0, prism_rtl::deref(n_p5).span_p)));
            PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs_pd}), .conds_p = Array<crate::lower::model::Cc>{}, .binds_p = Array(std::vector{std::tuple{nkey_p6, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_pd}), mode_p3, bt_pe})}})};
        });
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
        return pat_only_f(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m)) {
        return pat_only_f(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNil>(_m)) {
        return pat_only_f(crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PLit>(_m)) {
        auto&& l_pf = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        return lit_pat_f(lx_p0, l_pf, ty_p2, mode_p3, fresh_p4, false);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m)) {
        auto&& l_pg = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        return lit_pat_f(lx_p0, l_pg, ty_p2, mode_p3, fresh_p4, true);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& m1652_6_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q_ph = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        if (m1652_6_0 == Text::lit("?")) {
            return wrap_pat_f(lx_p0, Text::lit("Some"), prism_rtl::deref(prism_rtl::deref(q_ph)), inner_ty_f(ty_p2), mode_p3, fresh_p4);
        }
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& m1652_7_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q_pi = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        if (m1652_7_0 == Text::lit("~")) {
            return wrap_pat_f(lx_p0, Text::lit("Ok"), prism_rtl::deref(prism_rtl::deref(q_pi)), inner_ty_f(ty_p2), mode_p3, fresh_p4);
        }
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& q_pj = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        return rust_pat_f(lx_p0, prism_rtl::deref(prism_rtl::deref(q_pj)), ty_p2, mode_p3, fresh_p4);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_pk = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return rust_pat_f(lx_p0, prism_rtl::deref(prism_rtl::deref(q_pk)), ty_p2, mode_p3, fresh_p4);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& n_pl = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& ps_pm = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        return ctor_pat_f(lx_p0, n_pl, ps_pm, ty_p2, mode_p3, fresh_p4);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& n_pn = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fps_po = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        auto&& rest_pp = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a2;
        return record_pat_f(lx_p0, n_pn, fps_po, rest_pp, ty_p2, mode_p3, fresh_p4);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps_pq = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        auto ts_pr = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
            auto&& _m = crate::lower::types::peel_f(ty_p2);
            if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
                auto&& xs_pt = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
                _v.set(xs_pt);
                goto _done;
            }
            {
                _v.set(Array<crate::check::types::Ty>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subs_ps = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_pq)), ({
            auto lx_p0x = lx_p0;
            auto ps_pqx = ps_pq;
            auto ts_prx = ts_pr;
            auto mode_p3x = mode_p3;
            auto fresh_p4x = fresh_p4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), ps_pqx = std::move(ps_pqx), ts_prx = std::move(ts_prx), mode_p3x = std::move(mode_p3x), fresh_p4x = std::move(fresh_p4x)](Nat p0) {
            return ({
                auto lx_p0xy = lx_p0x;
                auto ps_pqxy = ps_pqx;
                auto ts_prxy = ts_prx;
                auto mode_p3xy = mode_p3x;
                auto fresh_p4xy = fresh_p4x;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), ps_pqxy = std::move(ps_pqxy), ts_prxy = std::move(ts_prxy), mode_p3xy = std::move(mode_p3xy), fresh_p4xy = std::move(fresh_p4xy)]() {
                return ({
                    auto i_pu = p0;
                    (prism_rtl::more(prism_rtl::rc(RustPat(lx_p0xy, crate::prelude::or_(crate::prelude::index(ps_pqxy, i_pu), dummy_pat_p()), crate::prelude::or_(crate::prelude::index(ts_prxy, i_pu), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), mode_p3xy, prism_rtl::cat(fresh_p4xy, "_", i_pu)))));
                });
            })));
            });
        })));
        })));
        return PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{crate::prelude::each(subs_ps, [&](const PatOut& o_pv) { return prism_rtl::deref(o_pv).pa_p; })}), .conds_p = crate::prelude::fold(subs_ps, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_p10, const PatOut& o_p11) { return crate::prelude::append(acc_p10, prism_rtl::deref(o_p11).conds_p); }), .binds_p = crate::prelude::fold(subs_ps, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_p12, const PatOut& o_p13) { return crate::prelude::append(acc_p12, prism_rtl::deref(o_p13).binds_p); })};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
        auto&& ps_p14 = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        return array_pat_f(lx_p0, ps_p14, ty_p2, mode_p3, fresh_p4);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
        auto&& q_p15 = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        return family_pat_f(lx_p0, q_p15, ty_p2, fresh_p4);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<PatOut> RustPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& p_p1 = this->p_p1;
    const auto& ty_p2 = this->ty_p2;
    const auto& mode_p3 = this->mode_p3;
    const auto& fresh_p4 = this->fresh_p4;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p1).kind_p);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_p5 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto nkey_p6 = crate::check::env::sname_key_f(n_p5);
        auto [qk_o9, why_pa] = crate::check::env::names::resolve_value_f(prism_rtl::deref(lx_p0).g_p, prism_rtl::deref(lx_p0).home_p, n_p5);
        auto is_ctor_p7 = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is_some(qk_o9)) {
                auto&& qk_pb = prism_rtl::some_of(qk_o9);
                _v.set(crate::check::env::has_key_f(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).ctors_p, qk_pb) && ((crate::check::env::is_upper_text_f(crate::lower::base_f(nkey_p6)) || (crate::prelude::len(prism_rtl::deref(n_p5).path_p) > Nat(1u))) || is_unit_ctor_f(lx_p0, qk_pb)));
                goto _done;
            }
            if (prism_rtl::is_none(qk_o9)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto tagged_o8 = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::check::env::TagInfo>> _v;
            if (prism_rtl::is_some(qk_o9)) {
                auto&& qk_pc = prism_rtl::some_of(qk_o9);
                _v.set(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).tags_p, qk_pc));
                goto _done;
            }
            if (prism_rtl::is_none(qk_o9)) {
                _v.set(std::optional<crate::check::env::TagInfo>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (std::move(is_ctor_p7)
        ? prism_rtl::more(prism_rtl::rc(CtorPat(lx_p0, n_p5, Array<crate::syntax::Pattern_>{}, ty_p2, mode_p3, fresh_p4)))
        : (why_pa == Text::lit("tag")) && (tagged_o8 != std::optional<crate::check::env::TagInfo>{})
        ? prism_rtl::more(prism_rtl::rc(TagPat(lx_p0, crate::prelude::or_(tagged_o8, dummy_tag_info_p()), Array<crate::syntax::FieldPat>{}, true, ty_p2, mode_p3, fresh_p4)))
        : ({
        auto lx_p0x = lx_p0;
        auto mode_p3x = mode_p3;
        auto n_p5x = n_p5;
        (crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_p0x, nkey_p6, prism_rtl::deref(n_p5x).span_p), [=, mode_p3x = std::move(mode_p3x)](Text local_name_at_f_2230) {
        return ({
            auto rs_pd = local_name_at_f_2230;
            (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(crate::lower::binder_ty_f(lx_p0x, prism_rtl::deref(n_p5x).span_p))), [=, rs_pd = std::move(rs_pd)](crate::lower::model::OutTy out_ty_of_f_2280) {
            return ({
                auto bt_pe = out_ty_of_f_2280;
                (prism_rtl::finished(PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs_pd}), .conds_p = Array<crate::lower::model::Cc>{}, .binds_p = Array(std::vector{std::tuple{nkey_p6, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_pd}), mode_p3x, bt_pe})}})}));
            });
        }));
        });
    }));
    }));
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(pat_only_f(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})))
        : prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m) ? prism_rtl::finished(pat_only_f(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})))
        : prism_rtl::is<crate::syntax::PatternKind::PNil>(_m) ? prism_rtl::finished(pat_only_f(crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")})))
        : prism_rtl::is<crate::syntax::PatternKind::PLit>(_m) ? ({
        auto&& l_pf = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        prism_rtl::more(prism_rtl::rc(LitPat(lx_p0, l_pf, ty_p2, mode_p3, fresh_p4, false)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m) ? ({
        auto&& l_pg = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        prism_rtl::more(prism_rtl::rc(LitPat(lx_p0, l_pg, ty_p2, mode_p3, fresh_p4, true)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) && ({
        auto&& m1652_6_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q_ph = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        (m1652_6_0 == Text::lit("?"));
    }) ? ({
        auto&& m1652_6_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q_ph = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(WrapPat(lx_p0, Text::lit("Some"), prism_rtl::deref(prism_rtl::deref(q_ph)), inner_ty_f(ty_p2), mode_p3, fresh_p4)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) && ({
        auto&& m1652_7_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q_pi = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        (m1652_7_0 == Text::lit("~"));
    }) ? ({
        auto&& m1652_7_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q_pi = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(WrapPat(lx_p0, Text::lit("Ok"), prism_rtl::deref(prism_rtl::deref(q_pi)), inner_ty_f(ty_p2), mode_p3, fresh_p4)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) ? ({
        auto&& q_pj = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(RustPat(lx_p0, prism_rtl::deref(prism_rtl::deref(q_pj)), ty_p2, mode_p3, fresh_p4)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q_pk = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RustPat(lx_p0, prism_rtl::deref(prism_rtl::deref(q_pk)), ty_p2, mode_p3, fresh_p4)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m) ? ({
        auto&& n_pl = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& ps_pm = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        prism_rtl::more(prism_rtl::rc(CtorPat(lx_p0, n_pl, ps_pm, ty_p2, mode_p3, fresh_p4)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m) ? ({
        auto&& n_pn = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fps_po = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        auto&& rest_pp = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a2;
        prism_rtl::more(prism_rtl::rc(RecordPat(lx_p0, n_pn, fps_po, prism_rtl::deref(rest_pp), ty_p2, mode_p3, fresh_p4)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m) ? ({
        auto&& ps_pq = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        ({
        auto ts_pr = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
            auto&& _m = crate::lower::types::peel_f(ty_p2);
            if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
                auto&& xs_pt = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
                _v.set(xs_pt);
                goto _done;
            }
            {
                _v.set(Array<crate::check::types::Ty>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto fresh_p4x = fresh_p4;
        auto lx_p0x = lx_p0;
        auto mode_p3x = mode_p3;
        auto ps_pqx = ps_pq;
        (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_pqx)), ({
        auto lx_p0xx = lx_p0x;
        auto ps_pqxx = ps_pqx;
        auto ts_prx = ts_pr;
        auto mode_p3xx = mode_p3x;
        auto fresh_p4xx = fresh_p4x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), ps_pqxx = std::move(ps_pqxx), ts_prx = std::move(ts_prx), mode_p3xx = std::move(mode_p3xx), fresh_p4xx = std::move(fresh_p4xx)](Nat p0) {
        return ({
            auto lx_p0xxy = lx_p0xx;
            auto ps_pqxxy = ps_pqxx;
            auto ts_prxy = ts_prx;
            auto mode_p3xxy = mode_p3xx;
            auto fresh_p4xxy = fresh_p4xx;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), ps_pqxxy = std::move(ps_pqxxy), ts_prxy = std::move(ts_prxy), mode_p3xxy = std::move(mode_p3xxy), fresh_p4xxy = std::move(fresh_p4xxy)]() {
            return ({
                auto i_pu = p0;
                (prism_rtl::more(prism_rtl::rc(RustPat(lx_p0xxy, crate::prelude::or_(crate::prelude::index(ps_pqxxy, i_pu), dummy_pat_p()), crate::prelude::or_(crate::prelude::index(ts_prxy, i_pu), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), mode_p3xxy, prism_rtl::cat(fresh_p4xxy, "_", i_pu)))));
            });
        })));
        });
    })));
    })), [=](Array<PatOut> each_3079) {
        return ({
            auto subs_ps = each_3079;
            (prism_rtl::finished(PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{crate::prelude::each(subs_ps, [&](const PatOut& o_pv) { return prism_rtl::deref(o_pv).pa_p; })}), .conds_p = crate::prelude::fold(subs_ps, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_p10, const PatOut& o_p11) { return crate::prelude::append(acc_p10, prism_rtl::deref(o_p11).conds_p); }), .binds_p = crate::prelude::fold(subs_ps, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_p12, const PatOut& o_p13) { return crate::prelude::append(acc_p12, prism_rtl::deref(o_p13).binds_p); })}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PArray>(_m) ? ({
        auto&& ps_p14 = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ArrayPat(lx_p0, ps_p14, ty_p2, mode_p3, fresh_p4)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m) ? ({
        auto&& q_p15 = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FamilyPat(lx_p0, q_p15, ty_p2, fresh_p4)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RustPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_rust_pat_f(crate::lower::Lx lx_p0, crate::syntax::Pattern_ p_p1, crate::check::types::Ty ty_p2, crate::lower::types::Holding mode_p3, Text fresh_p4) {
    return prism_rtl::make_rc<RustPat>(lx_p0, p_p1, ty_p2, mode_p3, fresh_p4);
}


/// let dummyPat
crate::syntax::Pattern_ dummy_pat_p() {
    return crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}};
}


/// InnerTy: fn Ty -> Ty
crate::check::types::Ty inner_ty_f(const crate::check::types::Ty& t_p0) {
    auto&& _m = crate::lower::types::peel_f(t_p0);
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& m3538_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i_p1 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (m3538_0_0 == Text::lit("?")) {
            return prism_rtl::deref(i_p1);
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& m3538_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i_p2 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (m3538_1_0 == Text::lit("~")) {
            return prism_rtl::deref(i_p2);
        }
    }
    {
        return crate::check::types::Ty(crate::check::types::Ty::TyErr{});
    }
}


/// IsUnitCtor: fn Lx, Text -> Bool
bool is_unit_ctor_f(const crate::lower::Lx& lx_p0, const Text& qk_p1) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).ctors_p, qk_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& c_p2 = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::deref(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0.g_p).types_p, prism_rtl::deref(c_p2).owner_p), crate::check::env::names::dummy_ty_info_p())).body_p;
        if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
            auto&& m3791_0_0 = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
            if (m3791_0_0.size() == 1u) {
                {
                    auto&& _c2 = crate::prelude::index(m3791_0_0, Nat(0u));
                    if (prism_rtl::is_some(_c2)) {
                        auto&& m3791_0_0_0_1 = std::get<1>(prism_rtl::some_of(_c2));
                        if (m3791_0_0_0_1.size() == 0u) {
                            return crate::check::env::is_lower_text_f(crate::check::types::bare_name_f(qk_p1));
                        }
                    }
                }
            }
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// WrapPat: unbounded fn Lx, Text, Pattern, Ty, Holding, Text -> PatOut
PatOut wrap_pat_f(const crate::lower::Lx& lx_p0, const Text& ctor_p1, const crate::syntax::Pattern_& q_p2, const crate::check::types::Ty& inner_p3, const crate::lower::types::Holding& mode_p4, const Text& fresh_p5) {
    auto o_p6 = rust_pat_f(lx_p0, q_p2, inner_p3, mode_p4, fresh_p5);
    PatOut this_ = o_p6;
    this_.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{ctor_p1, Array(std::vector{this_.pa_p})});
    return this_;
}


prism_rtl::Turn<PatOut> WrapPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& ctor_p1 = this->ctor_p1;
    const auto& q_p2 = this->q_p2;
    const auto& inner_p3 = this->inner_p3;
    const auto& mode_p4 = this->mode_p4;
    const auto& fresh_p5 = this->fresh_p5;
    auto ctor_p1x = ctor_p1;
    auto fresh_p5x = fresh_p5;
    auto inner_p3x = inner_p3;
    auto lx_p0x = lx_p0;
    auto mode_p4x = mode_p4;
    auto q_p2x = q_p2;
    return crate::prelude::call_then(start_rust_pat_f(lx_p0x, q_p2x, inner_p3x, mode_p4x, fresh_p5x), [=](PatOut rust_pat_f_4071) {
        return ({
            auto o_p6 = rust_pat_f_4071;
            (prism_rtl::finished(({
            PatOut this_ = o_p6;
            this_.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{ctor_p1x, Array(std::vector{this_.pa_p})});
            (std::move(this_));
        })));
        });
    });
}


/// `Start WrapPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_wrap_pat_f(crate::lower::Lx lx_p0, Text ctor_p1, crate::syntax::Pattern_ q_p2, crate::check::types::Ty inner_p3, crate::lower::types::Holding mode_p4, Text fresh_p5) {
    return prism_rtl::make_rc<WrapPat>(lx_p0, ctor_p1, q_p2, inner_p3, mode_p4, fresh_p5);
}


/// LitPat: unbounded fn Lx, Literal, Ty, Holding, Text, Bool -> PatOut
PatOut lit_pat_f(const crate::lower::Lx& lx_p0, const crate::syntax::Literal& l_p1, const crate::check::types::Ty& ty_p2, const crate::lower::types::Holding& mode_p3, const Text& fresh_p4, const bool& neg_p5) {
    auto t_p6 = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(ty_p2));
    auto&& _m = l_p1.kind_p;
    if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
        auto&& c_p7 = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
        return pat_only_f(crate::lower::model::Pa(crate::lower::model::Pa::PaChar{c_p7}));
    }
    {
        auto lit_p8 = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::types::Vl> _v;
            auto&& _m = l_p1.kind_p;
            if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
                auto&& d_pb = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
                _v.set((((t_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})) || (t_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutInt{}))) || (t_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutU8{}))) || (t_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{}))
                    ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::expr::number_f(t_p6, d_pb, neg_p5), t_p6})
                    : crate::lower::expr::literal_value_f(lx_p0, crate::lower::types::empty_env_p(), l_p1, l_p1.span_p, neg_p5));
                goto _done;
            }
            {
                _v.set(crate::lower::expr::literal_value_f(lx_p0, crate::lower::types::empty_env_p(), l_p1, l_p1.span_p, neg_p5));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto lv_p9 = crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::types::own_f(lit_p8), t_p6});
        auto b_pa = crate::lower::types::local_place_f(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4}), mode_p3, t_p6);
        return PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p4}), .conds_p = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{crate::lower::model::BinOp(crate::lower::model::BinOp::OpEq{}), prism_rtl::rc(crate::lower::types::ref_f(b_pa)), prism_rtl::rc(crate::lower::types::ref_f(lv_p9))})})}), .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
    }
}


prism_rtl::Turn<PatOut> LitPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& l_p1 = this->l_p1;
    const auto& ty_p2 = this->ty_p2;
    const auto& mode_p3 = this->mode_p3;
    const auto& fresh_p4 = this->fresh_p4;
    const auto& neg_p5 = this->neg_p5;
    auto fresh_p4x = fresh_p4;
    auto l_p1x = l_p1;
    auto lx_p0x = lx_p0;
    auto mode_p3x = mode_p3;
    auto neg_p5x = prism_rtl::deref(neg_p5);
    auto ty_p2x = ty_p2;
    return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(ty_p2x)), [=](crate::lower::model::OutTy out_ty_of_f_4383) {
        return ({
            auto t_p6 = out_ty_of_f_4383;
            ({
            auto&& _m = prism_rtl::deref(l_p1x).kind_p;
            prism_rtl::is<crate::syntax::LitKind::LChar>(_m) ? ({
            auto&& c_p7 = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
            prism_rtl::finished(pat_only_f(crate::lower::model::Pa(crate::lower::model::Pa::PaChar{c_p7})));
        })
            : ({
            auto lit_p8 = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::types::Vl> _v;
                auto&& _m = prism_rtl::deref(l_p1x).kind_p;
                if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
                    auto&& d_pb = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
                    _v.set((((t_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})) || (t_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutInt{}))) || (t_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutU8{}))) || (t_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{}))
                        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::expr::number_f(t_p6, d_pb, neg_p5x), t_p6})
                        : crate::lower::expr::literal_value_f(lx_p0x, crate::lower::types::empty_env_p(), l_p1x, prism_rtl::deref(l_p1x).span_p, neg_p5x));
                    goto _done;
                }
                {
                    _v.set(crate::lower::expr::literal_value_f(lx_p0x, crate::lower::types::empty_env_p(), l_p1x, prism_rtl::deref(l_p1x).span_p, neg_p5x));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto lv_p9 = crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::types::own_f(lit_p8), t_p6});
            auto b_pa = crate::lower::types::local_place_f(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4x}), mode_p3x, t_p6);
            (prism_rtl::finished(PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p4x}), .conds_p = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{crate::lower::model::BinOp(crate::lower::model::BinOp::OpEq{}), prism_rtl::rc(crate::lower::types::ref_f(b_pa)), prism_rtl::rc(crate::lower::types::ref_f(lv_p9))})})}), .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}}));
        });
        });
        });
    });
}


/// `Start LitPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_lit_pat_f(crate::lower::Lx lx_p0, crate::syntax::Literal l_p1, crate::check::types::Ty ty_p2, crate::lower::types::Holding mode_p3, Text fresh_p4, bool neg_p5) {
    return prism_rtl::make_rc<LitPat>(lx_p0, l_p1, ty_p2, mode_p3, fresh_p4, neg_p5);
}


/// CtorPat: unbounded fn Lx, SName, [Pattern], Ty, Holding, Text -> PatOut
PatOut ctor_pat_f(const crate::lower::Lx& lx_p0, const crate::syntax::SName& n_p1, const Array<crate::syntax::Pattern_>& ps_p2, const crate::check::types::Ty& ty_p3, const crate::lower::types::Holding& mode_p4, const Text& fresh_p5) {
    auto&& _qk_o6 = crate::check::env::names::resolve_value_f(lx_p0.g_p, lx_p0.home_p, n_p1);
    auto&& qk_o6 = std::get<0>(_qk_o6);
    if (prism_rtl::is_some(qk_o6)) {
        auto&& m5426_0 = prism_rtl::some_of(qk_o6);
        if (m5426_0 == Text::lit("True")) {
            return pat_only_f(crate::lower::model::Pa(crate::lower::model::Pa::PaBool{true}));
        }
    }
    if (prism_rtl::is_some(qk_o6)) {
        auto&& m5426_1 = prism_rtl::some_of(qk_o6);
        if (m5426_1 == Text::lit("False")) {
            return pat_only_f(crate::lower::model::Pa(crate::lower::model::Pa::PaBool{false}));
        }
    }
    if (prism_rtl::is_some(qk_o6)) {
        auto&& qk_p7 = prism_rtl::some_of(qk_o6);
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).ctors_p, qk_p7);
        if (prism_rtl::is_some(_m)) {
            auto&& c_p8 = prism_rtl::some_of(_m);
            auto owner_p9 = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0.g_p).types_p, prism_rtl::deref(c_p8).owner_p), crate::check::env::names::dummy_ty_info_p());
            auto ty_path_pa = crate::lower::path_in_f(lx_p0, prism_rtl::deref(owner_p9).home_p, crate::lower::camel_f(crate::check::types::bare_name_f(prism_rtl::deref(c_p8).owner_p)));
            auto args_pb = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
                auto&& _m = crate::lower::types::peel_f(ty_p3);
                if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                    auto&& xs_pg = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
                    _v.set(xs_pg);
                    goto _done;
                }
                {
                    _v.set(Array<crate::check::types::Ty>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto subs_pc = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_p2)), ({
                auto lx_p0x = lx_p0;
                auto c_p8x = c_p8;
                auto ps_p2x = ps_p2;
                auto args_pbx = args_pb;
                auto mode_p4x = mode_p4;
                auto fresh_p5x = fresh_p5;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), c_p8x = std::move(c_p8x), ps_p2x = std::move(ps_p2x), args_pbx = std::move(args_pbx), mode_p4x = std::move(mode_p4x), fresh_p5x = std::move(fresh_p5x)](Nat p0) {
                return ({
                    auto lx_p0xy = lx_p0x;
                    auto c_p8xy = c_p8x;
                    auto ps_p2xy = ps_p2x;
                    auto args_pbxy = args_pbx;
                    auto mode_p4xy = mode_p4x;
                    auto fresh_p5xy = fresh_p5x;
                    (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), c_p8xy = std::move(c_p8xy), ps_p2xy = std::move(ps_p2xy), args_pbxy = std::move(args_pbxy), mode_p4xy = std::move(mode_p4xy), fresh_p5xy = std::move(fresh_p5xy)]() {
                    return ({
                        auto i_ph = p0;
                        (crate::prelude::call_then(crate::lower::expr::start_instantiated_f(crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p8xy).args_p, i_ph), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), prism_rtl::deref(c_p8xy).params_p, args_pbxy), [=](crate::check::types::Ty instantiated_f_5930) { return prism_rtl::more(prism_rtl::rc(SubPat(lx_p0xy, c_p8xy, i_ph, crate::prelude::or_(crate::prelude::index(ps_p2xy, i_ph), dummy_pat_p()), instantiated_f_5930, mode_p4xy, prism_rtl::cat(fresh_p5xy, "_", i_ph)))); }));
                    });
                })));
                });
            })));
            })));
            auto conds_pd = crate::prelude::fold(subs_pc, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_pi, const PatOut& o_pj) { return crate::prelude::append(acc_pi, prism_rtl::deref(o_pj).conds_p); });
            auto binds_pe = crate::prelude::fold(subs_pc, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_pk, const PatOut& o_pl) { return crate::prelude::append(acc_pk, prism_rtl::deref(o_pl).binds_p); });
            auto pas_pf = crate::prelude::each(subs_pc, [&](const PatOut& o_pm) { return prism_rtl::deref(o_pm).pa_p; });
            auto&& _m = prism_rtl::deref(owner_p9).body_p;
            if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                auto&& fs_pn = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                return PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{ty_path_pa, crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(pas_pf)), ({
                    auto c_p8x = c_p8;
                    auto pas_pfx = pas_pf;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::Pa>>(Nat)>>(prism_rtl::rc([=, c_p8x = std::move(c_p8x), pas_pfx = std::move(pas_pfx)](Nat p0) {
                    return ({
                        auto c_p8xy = c_p8x;
                        auto pas_pfxy = pas_pfx;
                        (crate::prelude::entered(crate::prelude::once_job([=, c_p8xy = std::move(c_p8xy), pas_pfxy = std::move(pas_pfxy)]() {
                        return ({
                            auto i_po = p0;
                            (crate::prelude::call_then(crate::lower::start_field_spell_f(crate::lower::owner_of_f(prism_rtl::deref(c_p8xy).owner_p), crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p8xy).fields_p, i_po), Text::lit("")), crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p8xy).args_p, i_po), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](Text field_spell_f_6328) { return prism_rtl::finished(std::tuple{field_spell_f_6328, crate::prelude::or_(crate::prelude::index(pas_pfxy, i_po), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}))}); }));
                        });
                    })));
                    });
                }));
                }))), crate::prelude::len(pas_pf) < crate::prelude::len(prism_rtl::deref(c_p8).fields_p)}), .conds_p = conds_pd, .binds_p = binds_pe};
            }
            {
                auto is_unit_type_pp = (crate::prelude::len(prism_rtl::deref(c_p8).args_p) == Nat(0u)) && is_unit_ctor_f(lx_p0, qk_p7);
                auto is_newtype_pq = (crate::check::types::bare_name_f(prism_rtl::deref(c_p8).name_p) == crate::check::types::bare_name_f(prism_rtl::deref(c_p8).owner_p)) && ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = prism_rtl::deref(owner_p9).body_p;
                    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                        auto&& cases_ps = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                        _v.set(crate::prelude::len(cases_ps) == Nat(1u));
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto path_pr = std::move(is_unit_type_pp) || std::move(is_newtype_pq)
                    ? ty_path_pa
                    : prism_rtl::cat(ty_path_pa, "::", crate::lower::camel_f(crate::check::types::bare_name_f(prism_rtl::deref(c_p8).name_p)));
                return crate::prelude::len(prism_rtl::deref(c_p8).args_p) == Nat(0u)
                    ? PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{path_pr}), .conds_p = Array<crate::lower::model::Cc>{}, .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}}
                    : PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{path_pr, pas_pf}), .conds_p = conds_pd, .binds_p = binds_pe};
            }
        }
        if (prism_rtl::is_none(_m)) {
            return PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal_f(prism_rtl::cat("a pattern of ", qk_p7))})}), .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(qk_o6)) {
        return PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal_f(Text::lit("a pattern of an unknown constructor"))})}), .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<PatOut> CtorPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& n_p1 = this->n_p1;
    const auto& ps_p2 = this->ps_p2;
    const auto& ty_p3 = this->ty_p3;
    const auto& mode_p4 = this->mode_p4;
    const auto& fresh_p5 = this->fresh_p5;
    auto&& _qk_o6 = crate::check::env::names::resolve_value_f(prism_rtl::deref(lx_p0).g_p, prism_rtl::deref(lx_p0).home_p, n_p1);
    auto&& qk_o6 = std::get<0>(_qk_o6);
    return ({
        prism_rtl::is_some(qk_o6) && ({
        auto&& m5426_0 = prism_rtl::some_of(qk_o6);
        (m5426_0 == Text::lit("True"));
    }) ? ({
        auto&& m5426_0 = prism_rtl::some_of(qk_o6);
        prism_rtl::finished(pat_only_f(crate::lower::model::Pa(crate::lower::model::Pa::PaBool{true})));
    })
        : prism_rtl::is_some(qk_o6) && ({
        auto&& m5426_1 = prism_rtl::some_of(qk_o6);
        (m5426_1 == Text::lit("False"));
    }) ? ({
        auto&& m5426_1 = prism_rtl::some_of(qk_o6);
        prism_rtl::finished(pat_only_f(crate::lower::model::Pa(crate::lower::model::Pa::PaBool{false})));
    })
        : prism_rtl::is_some(qk_o6) ? ({
        auto&& qk_p7 = prism_rtl::some_of(qk_o6);
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).ctors_p, qk_p7);
        prism_rtl::is_some(_m) ? ({
        auto&& c_p8 = prism_rtl::some_of(_m);
        ({
        auto owner_p9 = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).types_p, prism_rtl::deref(c_p8).owner_p), crate::check::env::names::dummy_ty_info_p());
        auto ty_path_pa = crate::lower::path_in_f(lx_p0, prism_rtl::deref(owner_p9).home_p, crate::lower::camel_f(crate::check::types::bare_name_f(prism_rtl::deref(c_p8).owner_p)));
        auto args_pb = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
            auto&& _m = crate::lower::types::peel_f(ty_p3);
            if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                auto&& xs_pg = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
                _v.set(xs_pg);
                goto _done;
            }
            {
                _v.set(Array<crate::check::types::Ty>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto fresh_p5x = fresh_p5;
        auto lx_p0x = lx_p0;
        auto mode_p4x = mode_p4;
        auto ps_p2x = ps_p2;
        auto qk_p7x = qk_p7;
        (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_p2x)), ({
        auto lx_p0xx = lx_p0x;
        auto c_p8x = c_p8;
        auto ps_p2xx = ps_p2x;
        auto args_pbx = args_pb;
        auto mode_p4xx = mode_p4x;
        auto fresh_p5xx = fresh_p5x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), c_p8x = std::move(c_p8x), ps_p2xx = std::move(ps_p2xx), args_pbx = std::move(args_pbx), mode_p4xx = std::move(mode_p4xx), fresh_p5xx = std::move(fresh_p5xx)](Nat p0) {
        return ({
            auto lx_p0xxy = lx_p0xx;
            auto c_p8xy = c_p8x;
            auto ps_p2xxy = ps_p2xx;
            auto args_pbxy = args_pbx;
            auto mode_p4xxy = mode_p4xx;
            auto fresh_p5xxy = fresh_p5xx;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), c_p8xy = std::move(c_p8xy), ps_p2xxy = std::move(ps_p2xxy), args_pbxy = std::move(args_pbxy), mode_p4xxy = std::move(mode_p4xxy), fresh_p5xxy = std::move(fresh_p5xxy)]() {
            return ({
                auto i_ph = p0;
                (crate::prelude::call_then(crate::lower::expr::start_instantiated_f(crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p8xy).args_p, i_ph), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), prism_rtl::deref(c_p8xy).params_p, args_pbxy), [=](crate::check::types::Ty instantiated_f_5930) { return prism_rtl::more(prism_rtl::rc(SubPat(lx_p0xxy, c_p8xy, i_ph, crate::prelude::or_(crate::prelude::index(ps_p2xxy, i_ph), dummy_pat_p()), instantiated_f_5930, mode_p4xxy, prism_rtl::cat(fresh_p5xxy, "_", i_ph)))); }));
            });
        })));
        });
    })));
    })), [=, owner_p9 = std::move(owner_p9), ty_path_pa = std::move(ty_path_pa), qk_p7x = std::move(qk_p7x)](Array<PatOut> each_5861) {
        return ({
            auto subs_pc = each_5861;
            auto conds_pd = crate::prelude::fold(subs_pc, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_pi, const PatOut& o_pj) { return crate::prelude::append(acc_pi, prism_rtl::deref(o_pj).conds_p); });
            auto binds_pe = crate::prelude::fold(subs_pc, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_pk, const PatOut& o_pl) { return crate::prelude::append(acc_pk, prism_rtl::deref(o_pl).binds_p); });
            auto pas_pf = crate::prelude::each(subs_pc, [&](const PatOut& o_pm) { return prism_rtl::deref(o_pm).pa_p; });
            ({
            auto&& _m = prism_rtl::deref(owner_p9).body_p;
            prism_rtl::is<crate::check::env::TyBody::BRecord>(_m) ? ({
            auto&& fs_pn = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
            crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(pas_pf)), ({
            auto c_p8x = c_p8;
            auto pas_pfx = pas_pf;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::Pa>>(Nat)>>(prism_rtl::rc([=, c_p8x = std::move(c_p8x), pas_pfx = std::move(pas_pfx)](Nat p0) {
            return ({
                auto c_p8xy = c_p8x;
                auto pas_pfxy = pas_pfx;
                (crate::prelude::entered(crate::prelude::once_job([=, c_p8xy = std::move(c_p8xy), pas_pfxy = std::move(pas_pfxy)]() {
                return ({
                    auto i_po = p0;
                    (crate::prelude::call_then(crate::lower::start_field_spell_f(crate::lower::owner_of_f(prism_rtl::deref(c_p8xy).owner_p), crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p8xy).fields_p, i_po), Text::lit("")), crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p8xy).args_p, i_po), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](Text field_spell_f_6328) { return prism_rtl::finished(std::tuple{field_spell_f_6328, crate::prelude::or_(crate::prelude::index(pas_pfxy, i_po), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}))}); }));
                });
            })));
            });
        }));
        })), [=](Array<std::tuple<Text, crate::lower::model::Pa>> each_6295) { return prism_rtl::finished(PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{ty_path_pa, each_6295, crate::prelude::len(pas_pf) < crate::prelude::len(prism_rtl::deref(c_p8).fields_p)}), .conds_p = conds_pd, .binds_p = binds_pe}); });
        })
            : ({
            auto is_unit_type_pp = (crate::prelude::len(prism_rtl::deref(c_p8).args_p) == Nat(0u)) && is_unit_ctor_f(lx_p0x, qk_p7x);
            auto is_newtype_pq = (crate::check::types::bare_name_f(prism_rtl::deref(c_p8).name_p) == crate::check::types::bare_name_f(prism_rtl::deref(c_p8).owner_p)) && ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = prism_rtl::deref(owner_p9).body_p;
                if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                    auto&& cases_ps = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                    _v.set(crate::prelude::len(cases_ps) == Nat(1u));
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto path_pr = std::move(is_unit_type_pp) || std::move(is_newtype_pq)
                ? ty_path_pa
                : prism_rtl::cat(ty_path_pa, "::", crate::lower::camel_f(crate::check::types::bare_name_f(prism_rtl::deref(c_p8).name_p)));
            (crate::prelude::len(prism_rtl::deref(c_p8).args_p) == Nat(0u)
            ? prism_rtl::finished(PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{path_pr}), .conds_p = Array<crate::lower::model::Cc>{}, .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}})
            : prism_rtl::finished(PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{path_pr, pas_pf}), .conds_p = conds_pd, .binds_p = binds_pe}));
        });
        });
        });
    }));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal_f(prism_rtl::cat("a pattern of ", qk_p7))})}), .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(qk_o6) ? prism_rtl::finished(PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal_f(Text::lit("a pattern of an unknown constructor"))})}), .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CtorPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_ctor_pat_f(crate::lower::Lx lx_p0, crate::syntax::SName n_p1, Array<crate::syntax::Pattern_> ps_p2, crate::check::types::Ty ty_p3, crate::lower::types::Holding mode_p4, Text fresh_p5) {
    return prism_rtl::make_rc<CtorPat>(lx_p0, n_p1, ps_p2, ty_p3, mode_p4, fresh_p5);
}


/// SubPat: unbounded fn Lx, CtorInfo, Nat, Pattern, Ty, Holding, Text -> PatOut
PatOut sub_pat_f(const crate::lower::Lx& lx_p0, const crate::check::env::CtorInfo& c_p1, const Nat& i_p2, const crate::syntax::Pattern_& p_p3, const crate::check::types::Ty& ty_p4, const crate::lower::types::Holding& mode_p5, const Text& fresh_p6) {
    return !crate::lower::types::rc_field_f(lx_p0, c_p1.name_p, i_p2)
        ? rust_pat_f(lx_p0, p_p3, ty_p4, mode_p5, fresh_p6)
        : ({
        auto rc_mode_p7 = mode_p5 == crate::lower::types::Holding(crate::lower::types::Holding::Owned{})
            ? crate::lower::types::Holding(crate::lower::types::Holding::RcOwned{})
            : crate::lower::types::Holding(crate::lower::types::Holding::RcRef{});
        ({
        __label__ _done;
        prism_rtl::Slot<PatOut> _v;
        auto&& _m = prism_rtl::deref(p_p3.kind_p);
        if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
            _v.set(pat_only_f(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n_p8 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            _v.set(({
                auto o_p9 = rust_pat_f(lx_p0, p_p3, ty_p4, rc_mode_p7, fresh_p6);
                ({
                __label__ _done;
                prism_rtl::Slot<PatOut> _v;
                auto&& _m = prism_rtl::deref(o_p9).pa_p;
                if (prism_rtl::is<crate::lower::model::Pa::PaBind>(_m)) {
                    _v.set(o_p9);
                    goto _done;
                }
                {
                    _v.set(behind_rc_f(lx_p0, p_p3, ty_p4, rc_mode_p7, fresh_p6));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        {
            _v.set(behind_rc_f(lx_p0, p_p3, ty_p4, rc_mode_p7, fresh_p6));
            goto _done;
        }
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<PatOut> SubPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& c_p1 = this->c_p1;
    const auto& i_p2 = this->i_p2;
    const auto& p_p3 = this->p_p3;
    const auto& ty_p4 = this->ty_p4;
    const auto& mode_p5 = this->mode_p5;
    const auto& fresh_p6 = this->fresh_p6;
    return !crate::lower::types::rc_field_f(lx_p0, prism_rtl::deref(c_p1).name_p, i_p2)
        ? prism_rtl::more(prism_rtl::rc(RustPat(lx_p0, p_p3, ty_p4, mode_p5, fresh_p6)))
        : ({
        auto rc_mode_p7 = mode_p5 == crate::lower::types::Holding(crate::lower::types::Holding::Owned{})
            ? crate::lower::types::Holding(crate::lower::types::Holding::RcOwned{})
            : crate::lower::types::Holding(crate::lower::types::Holding::RcRef{});
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p3).kind_p);
        prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(pat_only_f(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})))
        : prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_p8 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto fresh_p6x = fresh_p6;
        auto lx_p0x = lx_p0;
        auto p_p3x = p_p3;
        auto ty_p4x = ty_p4;
        (crate::prelude::call_then(start_rust_pat_f(lx_p0x, p_p3x, ty_p4x, rc_mode_p7, fresh_p6x), [=](PatOut rust_pat_f_7871) {
        return ({
            auto o_p9 = rust_pat_f_7871;
            ({
            auto&& _m = prism_rtl::deref(o_p9).pa_p;
            prism_rtl::is<crate::lower::model::Pa::PaBind>(_m) ? prism_rtl::finished(o_p9)
            : prism_rtl::more(prism_rtl::rc(BehindRc(lx_p0x, p_p3x, ty_p4x, rc_mode_p7, fresh_p6x)));
        });
        });
    }));
    });
    })
        : prism_rtl::more(prism_rtl::rc(BehindRc(lx_p0, p_p3, ty_p4, rc_mode_p7, fresh_p6)));
    });
    });
}


/// `Start SubPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_sub_pat_f(crate::lower::Lx lx_p0, crate::check::env::CtorInfo c_p1, Nat i_p2, crate::syntax::Pattern_ p_p3, crate::check::types::Ty ty_p4, crate::lower::types::Holding mode_p5, Text fresh_p6) {
    return prism_rtl::make_rc<SubPat>(lx_p0, c_p1, i_p2, p_p3, ty_p4, mode_p5, fresh_p6);
}


/// BehindRc: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
PatOut behind_rc_f(const crate::lower::Lx& lx_p0, const crate::syntax::Pattern_& p_p1, const crate::check::types::Ty& ty_p2, const crate::lower::types::Holding& rc_mode_p3, const Text& fresh_p4) {
    auto inner_p5 = rust_pat_f(lx_p0, p_p1, ty_p2, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(fresh_p4, "_r"));
    auto place_p6 = crate::lower::types::ref_f(crate::lower::types::local_place_f(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4}), rc_mode_p3, crate::lower::model::OutTy(crate::lower::model::OutTy::OutRefused{Text::lit("a payload")})));
    return PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p4}), .conds_p = crate::prelude::append(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcLet{prism_rtl::deref(inner_p5).pa_p, place_p6})}), prism_rtl::deref(inner_p5).conds_p), .binds_p = prism_rtl::deref(inner_p5).binds_p};
}


prism_rtl::Turn<PatOut> BehindRc::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& p_p1 = this->p_p1;
    const auto& ty_p2 = this->ty_p2;
    const auto& rc_mode_p3 = this->rc_mode_p3;
    const auto& fresh_p4 = this->fresh_p4;
    auto fresh_p4x = fresh_p4;
    auto lx_p0x = lx_p0;
    auto p_p1x = p_p1;
    auto rc_mode_p3x = rc_mode_p3;
    auto ty_p2x = ty_p2;
    return crate::prelude::call_then(start_rust_pat_f(lx_p0x, p_p1x, ty_p2x, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(fresh_p4x, "_r")), [=](PatOut rust_pat_f_8210) {
        return ({
            auto inner_p5 = rust_pat_f_8210;
            auto place_p6 = crate::lower::types::ref_f(crate::lower::types::local_place_f(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4x}), rc_mode_p3x, crate::lower::model::OutTy(crate::lower::model::OutTy::OutRefused{Text::lit("a payload")})));
            (prism_rtl::finished(PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p4x}), .conds_p = crate::prelude::append(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcLet{prism_rtl::deref(inner_p5).pa_p, place_p6})}), prism_rtl::deref(inner_p5).conds_p), .binds_p = prism_rtl::deref(inner_p5).binds_p}));
        });
    });
}


/// `Start BehindRc, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_behind_rc_f(crate::lower::Lx lx_p0, crate::syntax::Pattern_ p_p1, crate::check::types::Ty ty_p2, crate::lower::types::Holding rc_mode_p3, Text fresh_p4) {
    return prism_rtl::make_rc<BehindRc>(lx_p0, p_p1, ty_p2, rc_mode_p3, fresh_p4);
}


/// RecordPat: unbounded fn Lx, SName, [FieldPat], Bool, Ty, Holding, Text -> PatOut
PatOut record_pat_f(const crate::lower::Lx& lx_p0, const crate::syntax::SName& n_p1, const Array<crate::syntax::FieldPat>& fps_p2, const bool& rest_p3, const crate::check::types::Ty& ty_p4, const crate::lower::types::Holding& mode_p5, const Text& fresh_p6) {
    auto [qk_o8, why_p9] = crate::check::env::names::resolve_value_f(lx_p0.g_p, lx_p0.home_p, n_p1);
    auto qk_p7 = crate::prelude::or_(qk_o8, Text::lit(""));
    return qk_p7 == Text::lit("Prelude.Error")
        ? error_pat_f(lx_p0, fps_p2, ty_p4, mode_p5, fresh_p6)
        : (why_p9 == Text::lit("tag")) && crate::check::env::has_key_f(prism_rtl::deref(lx_p0.g_p).tags_p, qk_p7)
        ? tag_pat_f(lx_p0, crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0.g_p).tags_p, qk_p7), dummy_tag_info_p()), fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6)
        : ({
        __label__ _done;
        prism_rtl::Slot<PatOut> _v;
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).ctors_p, qk_p7);
        if (prism_rtl::is_some(_m)) {
            auto&& c_pa = prism_rtl::some_of(_m);
            _v.set(({
                auto owner_pb = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0.g_p).types_p, prism_rtl::deref(c_pa).owner_p), crate::check::env::names::dummy_ty_info_p());
                auto ty_path_pc = crate::lower::path_in_f(lx_p0, prism_rtl::deref(owner_pb).home_p, crate::lower::camel_f(crate::check::types::bare_name_f(prism_rtl::deref(c_pa).owner_p)));
                ({
                __label__ _done;
                prism_rtl::Slot<PatOut> _v;
                auto&& _m = prism_rtl::deref(owner_pb).body_p;
                if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                    auto&& cases_pd = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                    if (crate::prelude::len(fps_p2) == Nat(0u)) {
                        _v.set(rest_case_pat_f(c_pa, cases_pd, ty_path_pc));
                        goto _done;
                    }
                }
                {
                    _v.set(fields_pat_f(lx_p0, c_pa, fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6, ty_path_pc));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<PatOut> _v;
                auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).tags_p, qk_p7);
                if (prism_rtl::is_some(_m)) {
                    auto&& tg_pe = prism_rtl::some_of(_m);
                    _v.set(tag_pat_f(lx_p0, tg_pe, fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal_f(prism_rtl::cat("a pattern of ", qk_p7))})}), .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<PatOut> RecordPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& n_p1 = this->n_p1;
    const auto& fps_p2 = this->fps_p2;
    const auto& rest_p3 = this->rest_p3;
    const auto& ty_p4 = this->ty_p4;
    const auto& mode_p5 = this->mode_p5;
    const auto& fresh_p6 = this->fresh_p6;
    auto [qk_o8, why_p9] = crate::check::env::names::resolve_value_f(prism_rtl::deref(lx_p0).g_p, prism_rtl::deref(lx_p0).home_p, n_p1);
    auto qk_p7 = crate::prelude::or_(qk_o8, Text::lit(""));
    return qk_p7 == Text::lit("Prelude.Error")
        ? prism_rtl::more(prism_rtl::rc(ErrorPat(lx_p0, fps_p2, ty_p4, mode_p5, fresh_p6)))
        : (why_p9 == Text::lit("tag")) && crate::check::env::has_key_f(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).tags_p, qk_p7)
        ? prism_rtl::more(prism_rtl::rc(TagPat(lx_p0, crate::prelude::or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).tags_p, qk_p7), dummy_tag_info_p()), fps_p2, prism_rtl::deref(rest_p3), ty_p4, mode_p5, fresh_p6)))
        : ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).ctors_p, qk_p7);
        prism_rtl::is_some(_m) ? ({
        auto&& c_pa = prism_rtl::some_of(_m);
        ({
        auto owner_pb = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).types_p, prism_rtl::deref(c_pa).owner_p), crate::check::env::names::dummy_ty_info_p());
        auto ty_path_pc = crate::lower::path_in_f(lx_p0, prism_rtl::deref(owner_pb).home_p, crate::lower::camel_f(crate::check::types::bare_name_f(prism_rtl::deref(c_pa).owner_p)));
        ({
        auto&& _m = prism_rtl::deref(owner_pb).body_p;
        prism_rtl::is<crate::check::env::TyBody::BChoice>(_m) && ({
        auto&& cases_pd = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
        (crate::prelude::len(fps_p2) == Nat(0u));
    }) ? ({
        auto&& cases_pd = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
        prism_rtl::finished(rest_case_pat_f(c_pa, cases_pd, ty_path_pc));
    })
        : prism_rtl::more(prism_rtl::rc(FieldsPat(lx_p0, c_pa, fps_p2, prism_rtl::deref(rest_p3), ty_p4, mode_p5, fresh_p6, ty_path_pc)));
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).tags_p, qk_p7);
        prism_rtl::is_some(_m) ? ({
        auto&& tg_pe = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(TagPat(lx_p0, tg_pe, fps_p2, prism_rtl::deref(rest_p3), ty_p4, mode_p5, fresh_p6)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal_f(prism_rtl::cat("a pattern of ", qk_p7))})}), .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}})
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RecordPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_record_pat_f(crate::lower::Lx lx_p0, crate::syntax::SName n_p1, Array<crate::syntax::FieldPat> fps_p2, bool rest_p3, crate::check::types::Ty ty_p4, crate::lower::types::Holding mode_p5, Text fresh_p6) {
    return prism_rtl::make_rc<RecordPat>(lx_p0, n_p1, fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6);
}


/// RestCasePat: fn CtorInfo, [((Text, [Ty]))], Text -> PatOut
PatOut rest_case_pat_f(const crate::check::env::CtorInfo& c_p0, const Array<std::tuple<Text, Array<crate::check::types::Ty>>>& cases_p1, const Text& ty_path_p2) {
    auto is_newtype_p3 = (crate::prelude::len(cases_p1) == Nat(1u)) && (crate::check::types::bare_name_f(c_p0.name_p) == crate::check::types::bare_name_f(c_p0.owner_p));
    auto path_p4 = std::move(is_newtype_p3)
        ? ty_path_p2
        : prism_rtl::cat(ty_path_p2, "::", crate::lower::camel_f(crate::check::types::bare_name_f(c_p0.name_p)));
    return crate::prelude::len(c_p0.args_p) == Nat(0u)
        ? PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{path_p4}), .conds_p = Array<crate::lower::model::Cc>{}, .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}}
        : PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{path_p4, crate::prelude::each(c_p0.args_p, [&](const crate::check::types::Ty& _p0) { return crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}); })}), .conds_p = Array<crate::lower::model::Cc>{}, .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
}


/// FieldsPat: unbounded fn Lx, CtorInfo, [FieldPat], Bool, Ty, Holding, Text, Text -> PatOut
PatOut fields_pat_f(const crate::lower::Lx& lx_p0, const crate::check::env::CtorInfo& c_p1, const Array<crate::syntax::FieldPat>& fps_p2, const bool& rest_p3, const crate::check::types::Ty& ty_p4, const crate::lower::types::Holding& mode_p5, const Text& fresh_p6, const Text& ty_path_p7) {
    auto args_p8 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = crate::lower::types::peel_f(ty_p4);
        if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
            auto&& xs_pc = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
            _v.set(xs_pc);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto subs_p9 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(fps_p2)), ({
        auto fps_p2x = fps_p2;
        auto c_p1x = c_p1;
        auto lx_p0x = lx_p0;
        auto args_p8x = args_p8;
        auto mode_p5x = mode_p5;
        auto fresh_p6x = fresh_p6;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, PatOut>>(Nat)>>(prism_rtl::rc([=, fps_p2x = std::move(fps_p2x), c_p1x = std::move(c_p1x), lx_p0x = std::move(lx_p0x), args_p8x = std::move(args_p8x), mode_p5x = std::move(mode_p5x), fresh_p6x = std::move(fresh_p6x)](Nat p0) {
        return ({
            auto fps_p2xy = fps_p2x;
            auto c_p1xy = c_p1x;
            auto lx_p0xy = lx_p0x;
            auto args_p8xy = args_p8x;
            auto mode_p5xy = mode_p5x;
            auto fresh_p6xy = fresh_p6x;
            (crate::prelude::entered(crate::prelude::once_job([=, fps_p2xy = std::move(fps_p2xy), c_p1xy = std::move(c_p1xy), lx_p0xy = std::move(lx_p0xy), args_p8xy = std::move(args_p8xy), mode_p5xy = std::move(mode_p5xy), fresh_p6xy = std::move(fresh_p6xy)]() {
            return ({
                auto i_pd = p0;
                ({
                auto fp_pe = crate::prelude::or_(crate::prelude::index(fps_p2xy, i_pd), dummy_field_pat_p());
                auto fname_pf = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = prism_rtl::deref(fp_pe).name_o;
                    if (prism_rtl::is_some(_m)) {
                        auto&& id_ph = prism_rtl::some_of(_m);
                        _v.set(prism_rtl::deref(id_ph).name_p);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p1xy).fields_p, i_pd), Text::lit("")));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto fix_pg = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(c_p1xy).fields_p)), i_pd, [&](const Nat& found_pi, const Nat& j_pj) {
                    return crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p1xy).fields_p, j_pj), Text::lit("")) == fname_pf
                        ? j_pj
                        : found_pi;
                });
                (crate::prelude::call_then(crate::lower::start_field_spell_f(crate::lower::owner_of_f(prism_rtl::deref(c_p1xy).owner_p), fname_pf, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p1xy).args_p, fix_pg), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=, fp_pe = std::move(fp_pe)](Text field_spell_f_10672) { return crate::prelude::call_then(crate::lower::expr::start_instantiated_f(crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p1xy).args_p, fix_pg), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), prism_rtl::deref(c_p1xy).params_p, args_p8xy), [=](crate::check::types::Ty instantiated_f_10768) { return crate::prelude::call_then(start_sub_pat_f(lx_p0xy, c_p1xy, fix_pg, prism_rtl::deref(fp_pe).pattern_p, instantiated_f_10768, mode_p5xy, prism_rtl::cat(fresh_p6xy, "_", i_pd)), [=](PatOut sub_pat_f_10736) { return prism_rtl::finished(std::tuple{field_spell_f_10672, sub_pat_f_10736}); }); }); }));
            });
            });
        })));
        });
    }));
    })));
    auto conds_pa = crate::prelude::fold(subs_p9, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_pk, const std::tuple<Text, PatOut>& _p1) {
        auto&& o_pl = std::get<1>(_p1);
        return crate::prelude::append(acc_pk, prism_rtl::deref(o_pl).conds_p);
    });
    auto binds_pb = crate::prelude::fold(subs_p9, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_pm, const std::tuple<Text, PatOut>& _p1) {
        auto&& o_pn = std::get<1>(_p1);
        return crate::prelude::append(acc_pm, prism_rtl::deref(o_pn).binds_p);
    });
    return PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{ty_path_p7, crate::prelude::each(subs_p9, [&](const std::tuple<Text, PatOut>& _p0) {
        auto&& f_po = std::get<0>(_p0);
        auto&& o_pp = std::get<1>(_p0);
        return std::tuple{f_po, prism_rtl::deref(o_pp).pa_p};
    }), rest_p3 || (crate::prelude::len(subs_p9) < crate::prelude::len(c_p1.fields_p))}), .conds_p = conds_pa, .binds_p = binds_pb};
}


prism_rtl::Turn<PatOut> FieldsPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& c_p1 = this->c_p1;
    const auto& fps_p2 = this->fps_p2;
    const auto& rest_p3 = this->rest_p3;
    const auto& ty_p4 = this->ty_p4;
    const auto& mode_p5 = this->mode_p5;
    const auto& fresh_p6 = this->fresh_p6;
    const auto& ty_path_p7 = this->ty_path_p7;
    auto args_p8 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = crate::lower::types::peel_f(ty_p4);
        if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
            auto&& xs_pc = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
            _v.set(xs_pc);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto c_p1x = c_p1;
    auto fps_p2x = fps_p2;
    auto fresh_p6x = fresh_p6;
    auto lx_p0x = lx_p0;
    auto mode_p5x = mode_p5;
    auto rest_p3x = prism_rtl::deref(rest_p3);
    auto ty_path_p7x = ty_path_p7;
    return crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(fps_p2x)), ({
        auto fps_p2xx = fps_p2x;
        auto c_p1xx = c_p1x;
        auto lx_p0xx = lx_p0x;
        auto args_p8x = args_p8;
        auto mode_p5xx = mode_p5x;
        auto fresh_p6xx = fresh_p6x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, PatOut>>(Nat)>>(prism_rtl::rc([=, fps_p2xx = std::move(fps_p2xx), c_p1xx = std::move(c_p1xx), lx_p0xx = std::move(lx_p0xx), args_p8x = std::move(args_p8x), mode_p5xx = std::move(mode_p5xx), fresh_p6xx = std::move(fresh_p6xx)](Nat p0) {
        return ({
            auto fps_p2xxy = fps_p2xx;
            auto c_p1xxy = c_p1xx;
            auto lx_p0xxy = lx_p0xx;
            auto args_p8xy = args_p8x;
            auto mode_p5xxy = mode_p5xx;
            auto fresh_p6xxy = fresh_p6xx;
            (crate::prelude::entered(crate::prelude::once_job([=, fps_p2xxy = std::move(fps_p2xxy), c_p1xxy = std::move(c_p1xxy), lx_p0xxy = std::move(lx_p0xxy), args_p8xy = std::move(args_p8xy), mode_p5xxy = std::move(mode_p5xxy), fresh_p6xxy = std::move(fresh_p6xxy)]() {
            return ({
                auto i_pd = p0;
                ({
                auto fp_pe = crate::prelude::or_(crate::prelude::index(fps_p2xxy, i_pd), dummy_field_pat_p());
                auto fname_pf = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = prism_rtl::deref(fp_pe).name_o;
                    if (prism_rtl::is_some(_m)) {
                        auto&& id_ph = prism_rtl::some_of(_m);
                        _v.set(prism_rtl::deref(id_ph).name_p);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p1xxy).fields_p, i_pd), Text::lit("")));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto fix_pg = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(c_p1xxy).fields_p)), i_pd, [&](const Nat& found_pi, const Nat& j_pj) {
                    return crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p1xxy).fields_p, j_pj), Text::lit("")) == fname_pf
                        ? j_pj
                        : found_pi;
                });
                (crate::prelude::call_then(crate::lower::start_field_spell_f(crate::lower::owner_of_f(prism_rtl::deref(c_p1xxy).owner_p), fname_pf, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p1xxy).args_p, fix_pg), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=, fp_pe = std::move(fp_pe)](Text field_spell_f_10672) { return crate::prelude::call_then(crate::lower::expr::start_instantiated_f(crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p1xxy).args_p, fix_pg), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), prism_rtl::deref(c_p1xxy).params_p, args_p8xy), [=](crate::check::types::Ty instantiated_f_10768) { return crate::prelude::call_then(start_sub_pat_f(lx_p0xxy, c_p1xxy, fix_pg, prism_rtl::deref(fp_pe).pattern_p, instantiated_f_10768, mode_p5xxy, prism_rtl::cat(fresh_p6xxy, "_", i_pd)), [=](PatOut sub_pat_f_10736) { return prism_rtl::finished(std::tuple{field_spell_f_10672, sub_pat_f_10736}); }); }); }));
            });
            });
        })));
        });
    }));
    })), [=](Array<std::tuple<Text, PatOut>> each_10332) {
        return ({
            auto subs_p9 = each_10332;
            auto conds_pa = crate::prelude::fold(subs_p9, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_pk, const std::tuple<Text, PatOut>& _p1) {
                auto&& o_pl = std::get<1>(_p1);
                return crate::prelude::append(acc_pk, prism_rtl::deref(o_pl).conds_p);
            });
            auto binds_pb = crate::prelude::fold(subs_p9, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_pm, const std::tuple<Text, PatOut>& _p1) {
                auto&& o_pn = std::get<1>(_p1);
                return crate::prelude::append(acc_pm, prism_rtl::deref(o_pn).binds_p);
            });
            (prism_rtl::finished(PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{ty_path_p7x, crate::prelude::each(subs_p9, [&](const std::tuple<Text, PatOut>& _p0) {
            auto&& f_po = std::get<0>(_p0);
            auto&& o_pp = std::get<1>(_p0);
            return std::tuple{f_po, prism_rtl::deref(o_pp).pa_p};
        }), rest_p3x || (crate::prelude::len(subs_p9) < crate::prelude::len(prism_rtl::deref(c_p1x).fields_p))}), .conds_p = conds_pa, .binds_p = binds_pb}));
        });
    });
}


/// `Start FieldsPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_fields_pat_f(crate::lower::Lx lx_p0, crate::check::env::CtorInfo c_p1, Array<crate::syntax::FieldPat> fps_p2, bool rest_p3, crate::check::types::Ty ty_p4, crate::lower::types::Holding mode_p5, Text fresh_p6, Text ty_path_p7) {
    return prism_rtl::make_rc<FieldsPat>(lx_p0, c_p1, fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6, ty_path_p7);
}


/// let dummyFieldPat
crate::syntax::FieldPat dummy_field_pat_p() {
    return crate::syntax::FieldPat{.name_o = std::optional<crate::syntax::Ident>{}, .pattern_p = dummy_pat_p(), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}};
}


/// let dummyTagInfo
crate::check::env::TagInfo dummy_tag_info_p() {
    return crate::check::env::TagInfo{.name_p = Text::lit(""), .family_p = Text::lit(""), .kind_p = Text::lit(""), .out_p = crate::check::types::Ty(crate::check::types::Ty::TyErr{}), .qs_p = Array<Text>{}, .rqs_p = Array<Text>{}, .bounds_p = Array<std::tuple<Text, Text>>{}, .fields_p = Array<std::tuple<Text, crate::check::types::Ty>>{}, .home_p = Text::lit(""), .file_p = Nat(0u), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}};
}


/// IsLive: fn Ty -> Bool
bool is_live_f(const crate::check::types::Ty& t_p0) {
    auto&& _m = crate::lower::types::peel_f(t_p0);
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// TagFieldName: fn FieldPat, [Text], Nat -> Text
Text tag_field_name_f(const crate::syntax::FieldPat& fp_p0, const Array<Text>& names_p1, const Nat& i_p2) {
    auto&& _m = fp_p0.name_o;
    if (prism_rtl::is_some(_m)) {
        auto&& id_p3 = prism_rtl::some_of(_m);
        return prism_rtl::deref(id_p3).name_p;
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = prism_rtl::deref(prism_rtl::deref(fp_p0.pattern_p).kind_p);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n_p4 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return crate::check::types::has_text_f(names_p1, crate::check::env::sname_key_f(n_p4))
                ? crate::check::env::sname_key_f(n_p4)
                : crate::prelude::or_(crate::prelude::index(names_p1, i_p2), Text::lit(""));
        }
        {
            return crate::prelude::or_(crate::prelude::index(names_p1, i_p2), Text::lit(""));
        }
    }
    prism_rtl::unreachable("no arm matched");
}


/// TagPat: unbounded fn Lx, TagInfo, [FieldPat], Bool, Ty, Holding, Text -> PatOut
PatOut tag_pat_f(const crate::lower::Lx& lx_p0, const crate::check::env::TagInfo& tg_p1, const Array<crate::syntax::FieldPat>& fps_p2, const bool& rest_p3, const crate::check::types::Ty& ty_p4, const crate::lower::types::Holding& mode_p5, const Text& fresh_p6) {
    auto [variant_pg, struct_path_ph] = crate::lower::program::tag_paths_f(lx_p0, tg_p1);
    auto live_p7 = is_live_f(ty_p4);
    auto names_p8 = crate::prelude::each(tg_p1.fields_p, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& f_pi = std::get<0>(_p0);
        return f_pi;
    });
    auto sub_mode_p9 = std::move(live_p7)
        ? crate::lower::types::Holding(crate::lower::types::Holding::ByRef{})
        : mode_p5;
    auto parts_pa = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(fps_p2)), ({
        auto fps_p2x = fps_p2;
        auto names_p8x = names_p8;
        auto tg_p1x = tg_p1;
        auto live_p7x = std::move(live_p7);
        auto lx_p0x = lx_p0;
        auto variant_pgx = variant_pg;
        auto fresh_p6x = fresh_p6;
        auto sub_mode_p9x = sub_mode_p9;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<std::optional<Text>, PatOut>>(Nat)>>(prism_rtl::rc([=, fps_p2x = std::move(fps_p2x), names_p8x = std::move(names_p8x), tg_p1x = std::move(tg_p1x), live_p7x = std::move(live_p7x), lx_p0x = std::move(lx_p0x), variant_pgx = std::move(variant_pgx), fresh_p6x = std::move(fresh_p6x), sub_mode_p9x = std::move(sub_mode_p9x)](Nat p0) {
        return ({
            auto fps_p2xy = fps_p2x;
            auto names_p8xy = names_p8x;
            auto tg_p1xy = tg_p1x;
            auto live_p7xy = live_p7x;
            auto lx_p0xy = lx_p0x;
            auto variant_pgxy = variant_pgx;
            auto fresh_p6xy = fresh_p6x;
            auto sub_mode_p9xy = sub_mode_p9x;
            (crate::prelude::entered(crate::prelude::once_job([=, fps_p2xy = std::move(fps_p2xy), names_p8xy = std::move(names_p8xy), tg_p1xy = std::move(tg_p1xy), live_p7xy = std::move(live_p7xy), lx_p0xy = std::move(lx_p0xy), variant_pgxy = std::move(variant_pgxy), fresh_p6xy = std::move(fresh_p6xy), sub_mode_p9xy = std::move(sub_mode_p9xy)]() {
            return ({
                auto i_pj = p0;
                ({
                auto fp_pk = crate::prelude::or_(crate::prelude::index(fps_p2xy, i_pj), dummy_field_pat_p());
                auto fname_pl = tag_field_name_f(fp_pk, names_p8xy, i_pj);
                auto ft_pm = crate::prelude::fold(prism_rtl::deref(tg_p1xy).fields_p, crate::check::types::Ty(crate::check::types::Ty::TyErr{}), [&](const crate::check::types::Ty& found_pn, const std::tuple<Text, crate::check::types::Ty>& _p1) {
                    auto&& f_po = std::get<0>(_p1);
                    auto&& t_pp = std::get<1>(_p1);
                    return f_po == fname_pl ? t_pp : found_pn;
                });
                ({
                auto&& _m = crate::lower::types::layer_of_f(ft_pm);
                prism_rtl::is<crate::lower::types::Layer::LyEv>(_m) ? prism_rtl::finished(std::tuple{std::optional<Text>{}, PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal_f(prism_rtl::cat("an event field in an element pattern (", prism_rtl::deref(tg_p1xy).name_p, ".", fname_pl, ")"))})}), .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}}})
                : prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m) && ({
                live_p7xy;
            }) ? crate::prelude::call_then(crate::lower::start_field_spell_f(prism_rtl::deref(tg_p1xy).home_p, fname_pl, ft_pm), [=](Text field_spell_f_13189) { return crate::prelude::call_then(start_live_field_pat_f(lx_p0xy, prism_rtl::deref(fp_pk).pattern_p, variant_pgxy, fname_pl, field_spell_f_13189, ft_pm, fresh_p6xy), [=](PatOut live_field_pat_f_13143) { return prism_rtl::finished(std::tuple{std::optional<Text>{}, live_field_pat_f_13143}); }); })
                : crate::prelude::call_then(start_rust_pat_f(lx_p0xy, prism_rtl::deref(fp_pk).pattern_p, crate::lower::types::peel_f(ft_pm), sub_mode_p9xy, prism_rtl::cat(fresh_p6xy, "_", i_pj)), [=](PatOut rust_pat_f_13281) {
                return ({
                    auto o_pq = rust_pat_f_13281;
                    (prism_rtl::finished(std::tuple{std::optional(crate::lower::field_spell_f(prism_rtl::deref(tg_p1xy).home_p, fname_pl, ft_pm)), o_pq}));
                });
            });
            });
            });
            });
        })));
        });
    }));
    })));
    auto field_pas_pb = crate::prelude::fold(parts_pa, Array<std::tuple<Text, crate::lower::model::Pa>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Pa>>& acc_pr, const std::tuple<std::optional<Text>, PatOut>& _p1) {
        auto&& f_os = std::get<0>(_p1);
        auto&& o_pt = std::get<1>(_p1);
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::Pa>>> _v;
            if (prism_rtl::is_some(f_os)) {
                auto&& f_pu = prism_rtl::some_of(f_os);
                _v.set(crate::prelude::push(acc_pr, std::tuple{f_pu, prism_rtl::deref(o_pt).pa_p}));
                goto _done;
            }
            if (prism_rtl::is_none(f_os)) {
                _v.set(acc_pr);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto conds_pc = crate::prelude::fold(parts_pa, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_pv, const std::tuple<std::optional<Text>, PatOut>& _p1) {
        auto&& o_p10 = std::get<1>(_p1);
        return crate::prelude::append(acc_pv, prism_rtl::deref(o_p10).conds_p);
    });
    auto binds_pd = crate::prelude::fold(parts_pa, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_p11, const std::tuple<std::optional<Text>, PatOut>& _p1) {
        auto&& o_p12 = std::get<1>(_p1);
        return crate::prelude::append(acc_p11, prism_rtl::deref(o_p12).binds_p);
    });
    auto level_pe = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{variant_pg, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{struct_path_ph, field_pas_pb, true})})});
    auto tagged_pf = crate::prelude::push(binds_pd, std::tuple{Text::lit("#tag"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::node_::elements::answer_variant_f(tg_p1)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})})});
    return std::move(live_p7)
        ? PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p6}), .conds_p = crate::prelude::append(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcLet{level_pe, crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p6})), Text::lit("identity")}))})})}), conds_pc), .binds_p = tagged_pf}
        : PatOut{.pa_p = level_pe, .conds_p = conds_pc, .binds_p = binds_pd};
}


prism_rtl::Turn<PatOut> TagPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& tg_p1 = this->tg_p1;
    const auto& fps_p2 = this->fps_p2;
    const auto& rest_p3 = this->rest_p3;
    const auto& ty_p4 = this->ty_p4;
    const auto& mode_p5 = this->mode_p5;
    const auto& fresh_p6 = this->fresh_p6;
    auto [variant_pg, struct_path_ph] = crate::lower::program::tag_paths_f(lx_p0, tg_p1);
    auto live_p7 = is_live_f(ty_p4);
    auto names_p8 = crate::prelude::each(prism_rtl::deref(tg_p1).fields_p, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& f_pi = std::get<0>(_p0);
        return f_pi;
    });
    auto sub_mode_p9 = std::move(live_p7)
        ? crate::lower::types::Holding(crate::lower::types::Holding::ByRef{})
        : mode_p5;
    auto fps_p2x = fps_p2;
    auto fresh_p6x = fresh_p6;
    auto lx_p0x = lx_p0;
    auto tg_p1x = tg_p1;
    return crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(fps_p2x)), ({
        auto fps_p2xx = fps_p2x;
        auto names_p8x = names_p8;
        auto tg_p1xx = tg_p1x;
        auto live_p7x = std::move(live_p7);
        auto lx_p0xx = lx_p0x;
        auto variant_pgx = variant_pg;
        auto fresh_p6xx = fresh_p6x;
        auto sub_mode_p9x = sub_mode_p9;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<std::optional<Text>, PatOut>>(Nat)>>(prism_rtl::rc([=, fps_p2xx = std::move(fps_p2xx), names_p8x = std::move(names_p8x), tg_p1xx = std::move(tg_p1xx), live_p7x = std::move(live_p7x), lx_p0xx = std::move(lx_p0xx), variant_pgx = std::move(variant_pgx), fresh_p6xx = std::move(fresh_p6xx), sub_mode_p9x = std::move(sub_mode_p9x)](Nat p0) {
        return ({
            auto fps_p2xxy = fps_p2xx;
            auto names_p8xy = names_p8x;
            auto tg_p1xxy = tg_p1xx;
            auto live_p7xy = live_p7x;
            auto lx_p0xxy = lx_p0xx;
            auto variant_pgxy = variant_pgx;
            auto fresh_p6xxy = fresh_p6xx;
            auto sub_mode_p9xy = sub_mode_p9x;
            (crate::prelude::entered(crate::prelude::once_job([=, fps_p2xxy = std::move(fps_p2xxy), names_p8xy = std::move(names_p8xy), tg_p1xxy = std::move(tg_p1xxy), live_p7xy = std::move(live_p7xy), lx_p0xxy = std::move(lx_p0xxy), variant_pgxy = std::move(variant_pgxy), fresh_p6xxy = std::move(fresh_p6xxy), sub_mode_p9xy = std::move(sub_mode_p9xy)]() {
            return ({
                auto i_pj = p0;
                ({
                auto fp_pk = crate::prelude::or_(crate::prelude::index(fps_p2xxy, i_pj), dummy_field_pat_p());
                auto fname_pl = tag_field_name_f(fp_pk, names_p8xy, i_pj);
                auto ft_pm = crate::prelude::fold(prism_rtl::deref(tg_p1xxy).fields_p, crate::check::types::Ty(crate::check::types::Ty::TyErr{}), [&](const crate::check::types::Ty& found_pn, const std::tuple<Text, crate::check::types::Ty>& _p1) {
                    auto&& f_po = std::get<0>(_p1);
                    auto&& t_pp = std::get<1>(_p1);
                    return f_po == fname_pl ? t_pp : found_pn;
                });
                ({
                auto&& _m = crate::lower::types::layer_of_f(ft_pm);
                prism_rtl::is<crate::lower::types::Layer::LyEv>(_m) ? prism_rtl::finished(std::tuple{std::optional<Text>{}, PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal_f(prism_rtl::cat("an event field in an element pattern (", prism_rtl::deref(tg_p1xxy).name_p, ".", fname_pl, ")"))})}), .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}}})
                : prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m) && ({
                live_p7xy;
            }) ? crate::prelude::call_then(crate::lower::start_field_spell_f(prism_rtl::deref(tg_p1xxy).home_p, fname_pl, ft_pm), [=](Text field_spell_f_13189) { return crate::prelude::call_then(start_live_field_pat_f(lx_p0xxy, prism_rtl::deref(fp_pk).pattern_p, variant_pgxy, fname_pl, field_spell_f_13189, ft_pm, fresh_p6xxy), [=](PatOut live_field_pat_f_13143) { return prism_rtl::finished(std::tuple{std::optional<Text>{}, live_field_pat_f_13143}); }); })
                : crate::prelude::call_then(start_rust_pat_f(lx_p0xxy, prism_rtl::deref(fp_pk).pattern_p, crate::lower::types::peel_f(ft_pm), sub_mode_p9xy, prism_rtl::cat(fresh_p6xxy, "_", i_pj)), [=](PatOut rust_pat_f_13281) {
                return ({
                    auto o_pq = rust_pat_f_13281;
                    (prism_rtl::finished(std::tuple{std::optional(crate::lower::field_spell_f(prism_rtl::deref(tg_p1xxy).home_p, fname_pl, ft_pm)), o_pq}));
                });
            });
            });
            });
            });
        })));
        });
    }));
    })), [=](Array<std::tuple<std::optional<Text>, PatOut>> each_12732) {
        return ({
            auto parts_pa = each_12732;
            auto field_pas_pb = crate::prelude::fold(parts_pa, Array<std::tuple<Text, crate::lower::model::Pa>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Pa>>& acc_pr, const std::tuple<std::optional<Text>, PatOut>& _p1) {
                auto&& f_os = std::get<0>(_p1);
                auto&& o_pt = std::get<1>(_p1);
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::Pa>>> _v;
                    if (prism_rtl::is_some(f_os)) {
                        auto&& f_pu = prism_rtl::some_of(f_os);
                        _v.set(crate::prelude::push(acc_pr, std::tuple{f_pu, prism_rtl::deref(o_pt).pa_p}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(f_os)) {
                        _v.set(acc_pr);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
            });
            auto conds_pc = crate::prelude::fold(parts_pa, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_pv, const std::tuple<std::optional<Text>, PatOut>& _p1) {
                auto&& o_p10 = std::get<1>(_p1);
                return crate::prelude::append(acc_pv, prism_rtl::deref(o_p10).conds_p);
            });
            auto binds_pd = crate::prelude::fold(parts_pa, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_p11, const std::tuple<std::optional<Text>, PatOut>& _p1) {
                auto&& o_p12 = std::get<1>(_p1);
                return crate::prelude::append(acc_p11, prism_rtl::deref(o_p12).binds_p);
            });
            auto level_pe = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{variant_pg, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{struct_path_ph, field_pas_pb, true})})});
            auto tagged_pf = crate::prelude::push(binds_pd, std::tuple{Text::lit("#tag"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::node_::elements::answer_variant_f(tg_p1x)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})})});
            live_p7
            ? prism_rtl::finished(PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p6x}), .conds_p = crate::prelude::append(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcLet{level_pe, crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p6x})), Text::lit("identity")}))})})}), conds_pc), .binds_p = tagged_pf})
            : prism_rtl::finished(PatOut{.pa_p = level_pe, .conds_p = conds_pc, .binds_p = binds_pd});
        });
    });
}


/// `Start TagPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_tag_pat_f(crate::lower::Lx lx_p0, crate::check::env::TagInfo tg_p1, Array<crate::syntax::FieldPat> fps_p2, bool rest_p3, crate::check::types::Ty ty_p4, crate::lower::types::Holding mode_p5, Text fresh_p6) {
    return prism_rtl::make_rc<TagPat>(lx_p0, tg_p1, fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6);
}


/// LiveFieldPat: unbounded fn Lx, Pattern, Text, Text, Text, Ty, Text -> PatOut
PatOut live_field_pat_f(const crate::lower::Lx& lx_p0, const crate::syntax::Pattern_& p_p1, const Text& variant_p2, const Text& fname_p3, const Text& rs_field_p4, const crate::check::types::Ty& ft_p5, const Text& fresh_p6) {
    auto&& _m = prism_rtl::deref(p_p1.kind_p);
    if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
        return pat_only_f(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p7 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto rs_p8 = lx_p0.in_node_p
            ? live_projection_f(fresh_p6, variant_p2, rs_field_p4, crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(ft_p5)))
            : crate::lower::expr::refusal_f(prism_rtl::cat("a live element\'s `$` field (", fname_p3, ") in a plain function, which has no read point (gap LE)"));
        return PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array<crate::lower::model::Cc>{}, .binds_p = Array(std::vector{std::tuple{crate::check::env::sname_key_f(n_p7), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{rs_p8, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(ft_p5)))})})}})};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_p9 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return live_field_pat_f(lx_p0, prism_rtl::deref(prism_rtl::deref(q_p9)), variant_p2, fname_p3, rs_field_p4, ft_p5, fresh_p6);
    }
    {
        return PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal_f(prism_rtl::cat("a pattern inside a live element\'s `$` field (", fname_p3, ")"))})}), .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
    }
}


prism_rtl::Turn<PatOut> LiveFieldPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& p_p1 = this->p_p1;
    const auto& variant_p2 = this->variant_p2;
    const auto& fname_p3 = this->fname_p3;
    const auto& rs_field_p4 = this->rs_field_p4;
    const auto& ft_p5 = this->ft_p5;
    const auto& fresh_p6 = this->fresh_p6;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p1).kind_p);
        prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(pat_only_f(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})))
        : prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_p7 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto rs_p8 = prism_rtl::deref(lx_p0).in_node_p
            ? live_projection_f(fresh_p6, variant_p2, rs_field_p4, crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(ft_p5)))
            : crate::lower::expr::refusal_f(prism_rtl::cat("a live element\'s `$` field (", fname_p3, ") in a plain function, which has no read point (gap LE)"));
        auto ft_p5x = ft_p5;
        auto lx_p0x = lx_p0;
        auto n_p7x = n_p7;
        (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(ft_p5x)), [=, rs_p8 = std::move(rs_p8), n_p7x = std::move(n_p7x)](crate::lower::model::OutTy out_ty_of_f_14928) { return prism_rtl::finished(PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array<crate::lower::model::Cc>{}, .binds_p = Array(std::vector{std::tuple{crate::check::env::sname_key_f(n_p7x), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{rs_p8, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(out_ty_of_f_14928)})})}})}); }));
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q_p9 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(LiveFieldPat(lx_p0, prism_rtl::deref(prism_rtl::deref(q_p9)), variant_p2, fname_p3, rs_field_p4, ft_p5, fresh_p6)));
    })
        : prism_rtl::finished(PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal_f(prism_rtl::cat("a pattern inside a live element\'s `$` field (", fname_p3, ")"))})}), .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
    });
}


/// `Start LiveFieldPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_live_field_pat_f(crate::lower::Lx lx_p0, crate::syntax::Pattern_ p_p1, Text variant_p2, Text fname_p3, Text rs_field_p4, crate::check::types::Ty ft_p5, Text fresh_p6) {
    return prism_rtl::make_rc<LiveFieldPat>(lx_p0, p_p1, variant_p2, fname_p3, rs_field_p4, ft_p5, fresh_p6);
}


/// LiveProjection: fn Text, Text, Text, OutTy -> Ex
crate::lower::model::Ex live_projection_f(const Text& fresh_p0, const Text& variant_p1, const Text& fname_p2, const crate::lower::model::OutTy& ft_p3) {
    auto arm_p4 = crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{variant_p1, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("x")})})}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("x")})), fname_p2}))})};
    auto other_p5 = crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = crate::lower::model::Ex(crate::lower::model::Ex::XUnreachable{})};
    return crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p0})), Text::lit("level")})), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("l")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("l")})), Array(std::vector{arm_p4, other_p5}), false, ft_p3}))})})});
}


/// FamilyPat: unbounded fn Lx, QualName, Ty, Text -> PatOut
PatOut family_pat_f(const crate::lower::Lx& lx_p0, const crate::syntax::QualName& q_p1, const crate::check::types::Ty& ty_p2, const Text& fresh_p3) {
    auto fam_p4 = crate::check::env::dotted_f(crate::prelude::filter(q_p1.path_p, [&](const Text& x_p8) { return x_p8 != Text::lit("*"); }));
    auto kind_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::lower::types::peel_f(ty_p2);
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            _v.set(Text::lit("Element"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
            _v.set(Text::lit("Element"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
            auto&& k_p9 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
            _v.set(k_p9);
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto tags_p6 = crate::prelude::filter(crate::lower::program::kind_tags_f(lx_p0, kind_p5, crate::prelude::keys(lx_p0.rs_mods_p)), [&](const crate::check::env::TagInfo& tg_pa) { return prism_rtl::deref(tg_pa).family_p == fam_p4; });
    auto place_p7 = is_live_f(ty_p2)
        ? crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p3})), Text::lit("identity")})
        : crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p3});
    return PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p3}), .conds_p = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XIsCase{prism_rtl::rc(place_p7), crate::prelude::each(tags_p6, [&](const crate::check::env::TagInfo& tg_pb) { return crate::lower::program::variant_of_f(lx_p0, tg_pb); })})})}), .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
}


prism_rtl::Turn<PatOut> FamilyPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& q_p1 = this->q_p1;
    const auto& ty_p2 = this->ty_p2;
    const auto& fresh_p3 = this->fresh_p3;
    auto fam_p4 = crate::check::env::dotted_f(crate::prelude::filter(prism_rtl::deref(q_p1).path_p, [&](const Text& x_p8) { return x_p8 != Text::lit("*"); }));
    auto kind_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::lower::types::peel_f(ty_p2);
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            _v.set(Text::lit("Element"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
            _v.set(Text::lit("Element"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
            auto&& k_p9 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
            _v.set(k_p9);
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto tags_p6 = crate::prelude::filter(crate::lower::program::kind_tags_f(lx_p0, kind_p5, crate::prelude::keys(prism_rtl::deref(lx_p0).rs_mods_p)), [&](const crate::check::env::TagInfo& tg_pa) { return prism_rtl::deref(tg_pa).family_p == fam_p4; });
    auto place_p7 = is_live_f(ty_p2)
        ? crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p3})), Text::lit("identity")})
        : crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p3});
    return prism_rtl::finished(PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p3}), .conds_p = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XIsCase{prism_rtl::rc(place_p7), crate::prelude::each(tags_p6, [&](const crate::check::env::TagInfo& tg_pb) { return crate::lower::program::variant_of_f(lx_p0, tg_pb); })})})}), .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
}


/// `Start FamilyPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_family_pat_f(crate::lower::Lx lx_p0, crate::syntax::QualName q_p1, crate::check::types::Ty ty_p2, Text fresh_p3) {
    return prism_rtl::make_rc<FamilyPat>(lx_p0, q_p1, ty_p2, fresh_p3);
}


/// ErrorPat: unbounded fn Lx, [FieldPat], Ty, Holding, Text -> PatOut
PatOut error_pat_f(const crate::lower::Lx& lx_p0, const Array<crate::syntax::FieldPat>& fps_p1, const crate::check::types::Ty& ty_p2, const crate::lower::types::Holding& mode_p3, const Text& fresh_p4) {
    auto e_p5 = crate::lower::types::local_place_f(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4}), mode_p3, crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{}));
    auto parts_p6 = crate::prelude::each(fps_p1, [&](const crate::syntax::FieldPat& fp_p8) {
        return ({
            auto fname_p9 = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = prism_rtl::deref(fp_p8).name_o;
                if (prism_rtl::is_some(_m)) {
                    auto&& id_pa = prism_rtl::some_of(_m);
                    _v.set(prism_rtl::deref(id_pa).name_p);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
            {
                auto&& m16544_0 = fname_p9;
                if (m16544_0 == Text::lit("kind")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
                        auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(fp_p8).pattern_p).kind_p);
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& k_pb = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(({
                                auto&& _kq_oc = crate::check::env::names::resolve_value_f(lx_p0.g_p, lx_p0.home_p, k_pb);
                                auto&& kq_oc = std::get<0>(_kq_oc);
                                ({
                                __label__ _done;
                                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
                                if (prism_rtl::is_some(kq_oc)) {
                                    auto&& kq_pd = prism_rtl::some_of(kq_oc);
                                    _v.set(crate::check::env::has_key_f(prism_rtl::deref(lx_p0.g_p).tags_p, kq_pd)
                                        ? std::tuple{Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{crate::lower::model::BinOp(crate::lower::model::BinOp::OpEq{}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4})), Text::lit("kind_p")}))}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XStr{kq_pd}))})})}), Array<std::tuple<Text, crate::lower::types::Bn>>{}}
                                        : std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key_f(k_pb), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4})), Text::lit("kind_p")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                                    goto _done;
                                }
                                if (prism_rtl::is_none(kq_oc)) {
                                    _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key_f(k_pb), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4})), Text::lit("kind_p")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                auto&& m16544_1 = fname_p9;
                if (m16544_1 == Text::lit("message")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
                        auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(fp_p8).pattern_p).kind_p);
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& m_pe = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key_f(m_pe), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4})), Text::lit("message_p")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                goto _done;
            }
        _done:
            _v.take();
        });
        });
    });
    auto wrapped_p7 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Pa> _v;
        auto&& _m = crate::lower::types::peel_f(ty_p2);
        if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
            auto&& m17389_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
            if (m17389_0_0 == Text::lit("~")) {
                _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p4})})}));
                goto _done;
            }
        }
        {
            _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p4}));
            goto _done;
        }
    _done:
        _v.take();
    });
    return PatOut{.pa_p = wrapped_p7, .conds_p = crate::prelude::fold(parts_p6, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_pf, const std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>& _p1) {
        auto&& cs_pg = std::get<0>(_p1);
        return crate::prelude::append(acc_pf, cs_pg);
    }), .binds_p = crate::prelude::fold(parts_p6, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_ph, const std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>& _p1) {
        auto&& bs_pi = std::get<1>(_p1);
        return crate::prelude::append(acc_ph, bs_pi);
    })};
}


prism_rtl::Turn<PatOut> ErrorPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& fps_p1 = this->fps_p1;
    const auto& ty_p2 = this->ty_p2;
    const auto& mode_p3 = this->mode_p3;
    const auto& fresh_p4 = this->fresh_p4;
    auto e_p5 = crate::lower::types::local_place_f(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4}), mode_p3, crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{}));
    auto parts_p6 = crate::prelude::each(fps_p1, [&](const crate::syntax::FieldPat& fp_p8) {
        return ({
            auto fname_p9 = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = prism_rtl::deref(fp_p8).name_o;
                if (prism_rtl::is_some(_m)) {
                    auto&& id_pa = prism_rtl::some_of(_m);
                    _v.set(prism_rtl::deref(id_pa).name_p);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
            {
                auto&& m16544_0 = fname_p9;
                if (m16544_0 == Text::lit("kind")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
                        auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(fp_p8).pattern_p).kind_p);
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& k_pb = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(({
                                auto&& _kq_oc = crate::check::env::names::resolve_value_f(prism_rtl::deref(lx_p0).g_p, prism_rtl::deref(lx_p0).home_p, k_pb);
                                auto&& kq_oc = std::get<0>(_kq_oc);
                                ({
                                __label__ _done;
                                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
                                if (prism_rtl::is_some(kq_oc)) {
                                    auto&& kq_pd = prism_rtl::some_of(kq_oc);
                                    _v.set(crate::check::env::has_key_f(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).tags_p, kq_pd)
                                        ? std::tuple{Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{crate::lower::model::BinOp(crate::lower::model::BinOp::OpEq{}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4})), Text::lit("kind_p")}))}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XStr{kq_pd}))})})}), Array<std::tuple<Text, crate::lower::types::Bn>>{}}
                                        : std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key_f(k_pb), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4})), Text::lit("kind_p")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                                    goto _done;
                                }
                                if (prism_rtl::is_none(kq_oc)) {
                                    _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key_f(k_pb), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4})), Text::lit("kind_p")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                auto&& m16544_1 = fname_p9;
                if (m16544_1 == Text::lit("message")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
                        auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(fp_p8).pattern_p).kind_p);
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& m_pe = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key_f(m_pe), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4})), Text::lit("message_p")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                goto _done;
            }
        _done:
            _v.take();
        });
        });
    });
    auto wrapped_p7 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Pa> _v;
        auto&& _m = crate::lower::types::peel_f(ty_p2);
        if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
            auto&& m17389_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
            if (m17389_0_0 == Text::lit("~")) {
                _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p4})})}));
                goto _done;
            }
        }
        {
            _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p4}));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(PatOut{.pa_p = wrapped_p7, .conds_p = crate::prelude::fold(parts_p6, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_pf, const std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>& _p1) {
        auto&& cs_pg = std::get<0>(_p1);
        return crate::prelude::append(acc_pf, cs_pg);
    }), .binds_p = crate::prelude::fold(parts_p6, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_ph, const std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>& _p1) {
        auto&& bs_pi = std::get<1>(_p1);
        return crate::prelude::append(acc_ph, bs_pi);
    })});
}


/// `Start ErrorPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_error_pat_f(crate::lower::Lx lx_p0, Array<crate::syntax::FieldPat> fps_p1, crate::check::types::Ty ty_p2, crate::lower::types::Holding mode_p3, Text fresh_p4) {
    return prism_rtl::make_rc<ErrorPat>(lx_p0, fps_p1, ty_p2, mode_p3, fresh_p4);
}


/// ArrayPat: unbounded fn Lx, [Pattern], Ty, Holding, Text -> PatOut
PatOut array_pat_f(const crate::lower::Lx& lx_p0, const Array<crate::syntax::Pattern_>& ps_p1, const crate::check::types::Ty& ty_p2, const crate::lower::types::Holding& mode_p3, const Text& fresh_p4) {
    auto et_p5 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        auto&& _m = crate::lower::types::peel_f(ty_p2);
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
            auto&& x_pb = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
            _v.set(prism_rtl::deref(x_pb));
            goto _done;
        }
        {
            _v.set(crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto arr_p6 = crate::lower::types::local_place_f(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4}), mode_p3, crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(ty_p2)));
    auto len_cond_p7 = crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{crate::lower::model::BinOp(crate::lower::model::BinOp::OpEq{}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::ref_f(arr_p6)), Text::lit("len"), Array<crate::lower::model::Ex>{}})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XIndex{crate::prelude::len(ps_p1)}))})});
    auto subs_p8 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_p1)), ({
        auto lx_p0x = lx_p0;
        auto ps_p1x = ps_p1;
        auto et_p5x = et_p5;
        auto fresh_p4x = fresh_p4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Nat, PatOut>>(Nat)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), ps_p1x = std::move(ps_p1x), et_p5x = std::move(et_p5x), fresh_p4x = std::move(fresh_p4x)](Nat p0) {
        return ({
            auto lx_p0xy = lx_p0x;
            auto ps_p1xy = ps_p1x;
            auto et_p5xy = et_p5x;
            auto fresh_p4xy = fresh_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), ps_p1xy = std::move(ps_p1xy), et_p5xy = std::move(et_p5xy), fresh_p4xy = std::move(fresh_p4xy)]() {
            return ({
                auto i_pc = p0;
                (crate::prelude::call_then(start_rust_pat_f(lx_p0xy, crate::prelude::or_(crate::prelude::index(ps_p1xy, i_pc), dummy_pat_p()), et_p5xy, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat(fresh_p4xy, "_", i_pc)), [=](PatOut rust_pat_f_18086) { return prism_rtl::finished(std::tuple{i_pc, rust_pat_f_18086}); }));
            });
        })));
        });
    }));
    })));
    auto conds_p9 = crate::prelude::fold(subs_p8, Array(std::vector{len_cond_p7}), [&](const Array<crate::lower::model::Cc>& acc_pd, const std::tuple<Nat, PatOut>& _p1) {
        auto&& i_pe = std::get<0>(_p1);
        auto&& o_pf = std::get<1>(_p1);
        return crate::prelude::append(crate::prelude::push(acc_pd, crate::lower::model::Cc(crate::lower::model::Cc::CcLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{prism_rtl::deref(o_pf).pa_p})}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("index")), Array(std::vector{crate::lower::types::ref_f(arr_p6), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNat{prism_rtl::cat(i_pe)}))})})})})), prism_rtl::deref(o_pf).conds_p);
    });
    auto binds_pa = crate::prelude::fold(subs_p8, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_pg, const std::tuple<Nat, PatOut>& _p1) {
        auto&& o_ph = std::get<1>(_p1);
        return crate::prelude::append(acc_pg, prism_rtl::deref(o_ph).binds_p);
    });
    return PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p4}), .conds_p = conds_p9, .binds_p = binds_pa};
}


prism_rtl::Turn<PatOut> ArrayPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& ps_p1 = this->ps_p1;
    const auto& ty_p2 = this->ty_p2;
    const auto& mode_p3 = this->mode_p3;
    const auto& fresh_p4 = this->fresh_p4;
    auto et_p5 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        auto&& _m = crate::lower::types::peel_f(ty_p2);
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
            auto&& x_pb = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
            _v.set(prism_rtl::deref(x_pb));
            goto _done;
        }
        {
            _v.set(crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto fresh_p4x = fresh_p4;
    auto lx_p0x = lx_p0;
    auto mode_p3x = mode_p3;
    auto ps_p1x = ps_p1;
    auto ty_p2x = ty_p2;
    return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(ty_p2x)), [=](crate::lower::model::OutTy out_ty_of_f_17925) {
        return ({
            auto arr_p6 = crate::lower::types::local_place_f(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4x}), mode_p3x, out_ty_of_f_17925);
            auto len_cond_p7 = crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{crate::lower::model::BinOp(crate::lower::model::BinOp::OpEq{}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::ref_f(arr_p6)), Text::lit("len"), Array<crate::lower::model::Ex>{}})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XIndex{crate::prelude::len(ps_p1x)}))})});
            (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_p1x)), ({
            auto lx_p0xx = lx_p0x;
            auto ps_p1xx = ps_p1x;
            auto et_p5x = et_p5;
            auto fresh_p4xx = fresh_p4x;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Nat, PatOut>>(Nat)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), ps_p1xx = std::move(ps_p1xx), et_p5x = std::move(et_p5x), fresh_p4xx = std::move(fresh_p4xx)](Nat p0) {
            return ({
                auto lx_p0xxy = lx_p0xx;
                auto ps_p1xxy = ps_p1xx;
                auto et_p5xy = et_p5x;
                auto fresh_p4xxy = fresh_p4xx;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), ps_p1xxy = std::move(ps_p1xxy), et_p5xy = std::move(et_p5xy), fresh_p4xxy = std::move(fresh_p4xxy)]() {
                return ({
                    auto i_pc = p0;
                    (crate::prelude::call_then(start_rust_pat_f(lx_p0xxy, crate::prelude::or_(crate::prelude::index(ps_p1xxy, i_pc), dummy_pat_p()), et_p5xy, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat(fresh_p4xxy, "_", i_pc)), [=](PatOut rust_pat_f_18086) { return prism_rtl::finished(std::tuple{i_pc, rust_pat_f_18086}); }));
                });
            })));
            });
        }));
        })), [=, arr_p6 = std::move(arr_p6), len_cond_p7 = std::move(len_cond_p7)](Array<std::tuple<Nat, PatOut>> each_18051) {
            return ({
                auto subs_p8 = each_18051;
                auto conds_p9 = crate::prelude::fold(subs_p8, Array(std::vector{len_cond_p7}), [&](const Array<crate::lower::model::Cc>& acc_pd, const std::tuple<Nat, PatOut>& _p1) {
                    auto&& i_pe = std::get<0>(_p1);
                    auto&& o_pf = std::get<1>(_p1);
                    return crate::prelude::append(crate::prelude::push(acc_pd, crate::lower::model::Cc(crate::lower::model::Cc::CcLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{prism_rtl::deref(o_pf).pa_p})}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("index")), Array(std::vector{crate::lower::types::ref_f(arr_p6), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNat{prism_rtl::cat(i_pe)}))})})})})), prism_rtl::deref(o_pf).conds_p);
                });
                auto binds_pa = crate::prelude::fold(subs_p8, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_pg, const std::tuple<Nat, PatOut>& _p1) {
                    auto&& o_ph = std::get<1>(_p1);
                    return crate::prelude::append(acc_pg, prism_rtl::deref(o_ph).binds_p);
                });
                (prism_rtl::finished(PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p4x}), .conds_p = conds_p9, .binds_p = binds_pa}));
            });
        }));
        });
    });
}


/// `Start ArrayPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_array_pat_f(crate::lower::Lx lx_p0, Array<crate::syntax::Pattern_> ps_p1, crate::check::types::Ty ty_p2, crate::lower::types::Holding mode_p3, Text fresh_p4) {
    return prism_rtl::make_rc<ArrayPat>(lx_p0, ps_p1, ty_p2, mode_p3, fresh_p4);
}

}  // namespace crate::lower::patterns
