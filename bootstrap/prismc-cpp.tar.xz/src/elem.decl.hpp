// The program's `Elem` and `Answer` declared, and the prelude's rows, emitted by prismc
// (claude/backend.md). Edit the Prism sources, not this file.
#pragma once

#include "prelude.hpp"
#include <fs/decl.hpp>
#include <process/decl.hpp>

namespace crate {

using namespace prelude;

class Elem;

class Answer;

namespace prelude {

/// A row of a `for` or a generation of a `rebuild`: a node its builder tears down. A row
/// of a hosted child's (prismc/README.md, pick HO) is an entry of its host's document: its
/// own places' entries, by their paths relative to the row, and a host's typed answer to
/// one of them.
class Row : public Node {
public:
    virtual void leave_row(Cx& cx) = 0;
    virtual std::vector<std::tuple<Path, prism_rtl::Rc<prism_rtl::Entry<Elem>>>> document(const Cx& cx) const {
        static_cast<void>(cx);
        return {};
    }
    virtual Done deliver(std::span<const Segment> at, const Answer& v, Cx& cx) {
        static_cast<void>(v);
        static_cast<void>(cx);
        return unexpected(Fault::answer(str("no hosted place at ", path_of(at), " to answer: the row is not hosted")));
    }
};

/// A row subscribing to its block's port for one event: the row heard weakly, the handle
/// kept for its leaving (claude/backend.md: `Port::subscribe`).
template <class N, class P, class Port, class Call>
void subscribe_row(const prism_rtl::Rc<N>& node, std::optional<prism_rtl::Rc<P>> parent, Port port, Call call, std::optional<Handle>& slot) {
    if (!parent) return;
    prism_rtl::Weak<N> me = node;
    using T = typename std::remove_cvref_t<decltype(deref(port(*parent)))>::Value;
    Handle h = deref(port(*parent)).subscribe([me, call](const T& v, Cx& cx) -> Done {
        if (auto n = me.lock()) call(n, v, cx);
        return {};
    });
    slot = h;
}

}  // namespace prelude

}  // namespace crate
