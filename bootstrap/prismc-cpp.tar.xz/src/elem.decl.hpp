// The program's `Elem` and `Answer` declared, their handles, and the prelude's rows,
// emitted by prismc (claude/backend.md). Edit the Prism sources, not this file.
#pragma once

#include "prelude.hpp"
#include <fs/decl.hpp>
#include <process/decl.hpp>

namespace crate {

using namespace prelude;

class Elem;

class Answer;

/// `Elem`, a row kind's values:
///
/// ```prism
/// `Elem r`: an element as a document holds it, its `Level` in a tick.
/// ```
class Elem {
public:
    using prism_value = void;
    struct FsContents;
    struct FsFile;
    struct FsList_;
    struct FsOutput;
    struct PreludeExceptions;
    struct PreludeUnwrap;
    struct ProcessArgs;
    struct ProcessEnv;
    struct ProcessExit;
    using Cases = std::variant<FsContents, FsFile, FsList_, FsOutput, PreludeExceptions, PreludeUnwrap, ProcessArgs, ProcessEnv, ProcessExit>;
    template <class C>
        requires prism_rtl::one_of<C, FsContents, FsFile, FsList_, FsOutput, PreludeExceptions, PreludeUnwrap, ProcessArgs, ProcessEnv, ProcessExit>
    Elem(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    Pod to_pod() const;
    void show(Printer& p) const;
    static Result<Elem> from_pod(const Pod& p);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host's
/// supplier answers a child place with, and what a World's answer to a forwarded element
/// decodes to, carrying the tag's output.
class Answer {
public:
    using prism_value = void;
    struct FsContents;
    struct FsFile;
    struct FsList_;
    struct FsOutput;
    struct PreludeExceptions;
    struct PreludeUnwrap;
    struct ProcessArgs;
    struct ProcessEnv;
    struct ProcessExit;
    using Cases = std::variant<FsContents, FsFile, FsList_, FsOutput, PreludeExceptions, PreludeUnwrap, ProcessArgs, ProcessEnv, ProcessExit>;
    template <class C>
        requires prism_rtl::one_of<C, FsContents, FsFile, FsList_, FsOutput, PreludeExceptions, PreludeUnwrap, ProcessArgs, ProcessEnv, ProcessExit>
    Answer(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    const char* tag() const;
    Result<Fallible<crate::fs::Contents>> fs_contents() const;
    Result<Fallible<crate::fs::Contents>> fs_file() const;
    Result<Array<Text>> fs_list_() const;
    Result<crate::fs::WriteState> fs_output() const;
    Result<Exception> prelude_exceptions() const;
    Result<Pod> prelude_unwrap() const;
    Result<Array<Text>> process_args() const;
    Result<std::optional<Text>> process_env() const;
    Result<Unit> process_exit() const;
    static Result<Answer> decode(const Elem& e, const Pod& v);

private:
    prism_rtl::Rc<const Cases> cases_;
};

namespace prelude {

/// A row of a `for` or a generation of a `rebuild`: a node its builder tears down. A row
/// of a hosted child's (prismc/README.md, pick HO) is an entry of its host's document: its
/// own places, by their paths relative to the row, and a host's typed answer to one of them.
class Row : public Node {
public:
    virtual void leave_row(Cx& cx) = 0;
    virtual std::vector<std::tuple<Path, Elem>> document(const Cx& cx) const {
        static_cast<void>(cx);
        return {};
    }
    virtual Done deliver(std::span<const Segment> at, const Answer& v, Cx& cx) {
        static_cast<void>(v);
        static_cast<void>(cx);
        return unexpected(Fault::answer(str("no hosted place at ", path_of(at), " to answer: the row is not hosted")));
    }
};

/// A row subscribing to its block's port for one event: the row heard weakly, the handle
/// kept for its leaving (claude/backend.md: `Port::subscribe`).
template <class N, class P, class Port, class Call>
void subscribe_row(const prism_rtl::Rc<N>& node, std::optional<prism_rtl::Rc<P>> parent, Port port, Call call, std::optional<Handle>& slot) {
    if (!parent) return;
    prism_rtl::Weak<N> me = node;
    using T = typename std::remove_cvref_t<decltype(deref(port(*parent)))>::Value;
    Handle h = deref(port(*parent)).subscribe([me, call](const T& v, Cx& cx) -> Done {
        if (auto n = me.lock()) call(n, v, cx);
        return {};
    });
    slot = h;
}

}  // namespace prelude

}  // namespace crate
