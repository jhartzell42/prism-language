// The module `Syntax.Parser.Types`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/parser/types/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/sexp/module.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Syntax.Parser.Types`, from `target/bootstrap/cpp-src/prismc/syntax/parser/types.prism`.
namespace crate::syntax::parser::types {

bool FieldsRead::operator==(const FieldsRead& o) const { return fields_p == o.fields_p && rest_p == o.rest_p && p_p == o.p_p && going_p == o.going_p; }

void FieldsRead::show(Printer& p) const {
    p.record("FieldsRead", {{"fields", fields_p}, {"rest", rest_p}, {"p", p_p}, {"going", going_p}});
}

Pod FieldsRead::to_pod() const {
    return Pod::record("FieldsRead", {{"fields", prism_rtl::to_pod(fields_p)}, {"rest", prism_rtl::to_pod(rest_p)}, {"p", prism_rtl::to_pod(p_p)}, {"going", prism_rtl::to_pod(going_p)}});
}

Result<FieldsRead> FieldsRead::from_pod(const Pod& whole) {
    return FieldsRead{.fields_p = TRY(prism_rtl::from_pod<Array<crate::syntax::FieldPat>>(TRY(crate::prelude::field(whole, "fields")))), .rest_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "rest")))), .p_p = TRY(prism_rtl::from_pod<crate::syntax::parser::Ps>(TRY(crate::prelude::field(whole, "p")))), .going_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "going"))))};
}


/// ParseType: unbounded fn Ps -> ((Type, Ps))
std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_f(const crate::syntax::parser::Ps& p_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto color_var_p2 = is_plain_lower_one_f(crate::syntax::parser::kind_f(p_p0)) && is_fn_kw_f(crate::syntax::parser::kind_at_f(p_p0, Nat(1u)));
    auto [color_p3, p1_p4] = crate::syntax::parser::at_kw_f(p_p0, Text::lit("unbounded"))
        ? std::tuple{crate::syntax::Color(crate::syntax::Color::Unbounded{}), crate::syntax::parser::adv_f(p_p0)}
        : std::move(color_var_p2)
        ? color_var_of_f(p_p0)
        : std::tuple{crate::syntax::Color(crate::syntax::Color::Bounded{}), p_p0};
    return crate::syntax::parser::at_kw_f(p1_p4, Text::lit("fn"))
        ? ({
        auto p2_p5 = crate::syntax::parser::adv_f(p1_p4);
        auto [params_p6, p3_p7] = crate::syntax::parser::at_op_f(p2_p5, Text::lit("->"))
            ? std::tuple{Array<crate::syntax::Type>{}, p2_p5}
            : crate::syntax::parser::commas_f(p2_p5, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(start_parse_emit_type_f(a0)); })));
        auto [result_p8, p4_p9] = parse_type_f(crate::syntax::parser::expect_op_f(p3_p7, Text::lit("->")));
        std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TFn{color_p3, params_p6, prism_rtl::rc(result_p8)})), .span_p = crate::syntax::parser::to_f(start_p1, prism_rtl::deref(result_p8).span_p)}, p4_p9};
    })
        : color_p3 != crate::syntax::Color(crate::syntax::Color::Bounded{})
        ? std::tuple{crate::syntax::parser::decls::no_type_p(), crate::syntax::parser::error_here_f(p1_p4, Text::lit("a color (`unbounded`, or a color variable) is written before a function type\'s `fn`"))}
        : ({
        auto [t_pa, q_pb] = parse_emit_type_f(p1_p4);
        crate::syntax::parser::at_op_f(q_pb, Text::lit("->"))
        ? std::tuple{t_pa, crate::syntax::parser::error_at_f(q_pb, crate::syntax::parser::here_f(q_pb), Text::lit("a function type begins with `fn`: `fn A -> B`"))}
        : std::tuple{t_pa, q_pb};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> ParseType::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto color_var_p2 = is_plain_lower_one_f(crate::syntax::parser::kind_f(p_p0)) && is_fn_kw_f(crate::syntax::parser::kind_at_f(p_p0, Nat(1u)));
    auto [color_p3, p1_p4] = crate::syntax::parser::at_kw_f(p_p0, Text::lit("unbounded"))
        ? std::tuple{crate::syntax::Color(crate::syntax::Color::Unbounded{}), crate::syntax::parser::adv_f(p_p0)}
        : std::move(color_var_p2)
        ? color_var_of_f(p_p0)
        : std::tuple{crate::syntax::Color(crate::syntax::Color::Bounded{}), p_p0};
    return crate::syntax::parser::at_kw_f(p1_p4, Text::lit("fn"))
        ? ({
        auto p2_p5 = crate::syntax::parser::adv_f(p1_p4);
        auto [params_p6, p3_p7] = crate::syntax::parser::at_op_f(p2_p5, Text::lit("->"))
            ? std::tuple{Array<crate::syntax::Type>{}, p2_p5}
            : crate::syntax::parser::commas_f(p2_p5, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(start_parse_emit_type_f(a0)); })));
        (crate::prelude::call_then(start_parse_type_f(crate::syntax::parser::expect_op_f(p3_p7, Text::lit("->"))), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_f_1974) {
        return ({
            auto [result_p8, p4_p9] = parse_type_f_1974;
            (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TFn{color_p3, params_p6, prism_rtl::rc(result_p8)})), .span_p = crate::syntax::parser::to_f(start_p1, prism_rtl::deref(result_p8).span_p)}, p4_p9}));
        });
    }));
    })
        : color_p3 != crate::syntax::Color(crate::syntax::Color::Bounded{})
        ? prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_type_p(), crate::syntax::parser::error_here_f(p1_p4, Text::lit("a color (`unbounded`, or a color variable) is written before a function type\'s `fn`"))})
        : crate::prelude::call_then(start_parse_emit_type_f(p1_p4), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_emit_type_f_2267) {
        return ({
            auto [t_pa, q_pb] = parse_emit_type_f_2267;
            (crate::syntax::parser::at_op_f(q_pb, Text::lit("->"))
            ? prism_rtl::finished(std::tuple{t_pa, crate::syntax::parser::error_at_f(q_pb, crate::syntax::parser::here_f(q_pb), Text::lit("a function type begins with `fn`: `fn A -> B`"))})
            : prism_rtl::finished(std::tuple{t_pa, q_pb}));
        });
    });
}


/// `Start ParseType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_parse_type_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseType>(p_p0);
}


/// IsPlainLowerOne: fn TokKind -> Bool
bool is_plain_lower_one_f(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(tok_kind0)) {
        auto&& n_p0 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(tok_kind0).a0;
        return ((prism_rtl::deref(n_p0).sigils_p == Text::lit("")) && (prism_rtl::deref(n_p0).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) && (crate::prelude::len(prism_rtl::deref(n_p0).path_p) == Nat(1u));
    }
    {
        return false;
    }
}


/// IsFnKw: fn TokKind -> Bool
bool is_fn_kw_f(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(tok_kind0)) {
        auto&& c0_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(tok_kind0).a0;
        if (c0_0_0 == Text::lit("fn")) {
            return true;
        }
    }
    {
        return false;
    }
}


/// ColorVarOf: fn Ps -> ((Color, Ps))
std::tuple<crate::syntax::Color, crate::syntax::parser::Ps> color_var_of_f(const crate::syntax::parser::Ps& p_p0) {
    auto [i_p1, q_p2] = crate::syntax::parser::parse_ident_f(p_p0);
    return std::tuple{crate::syntax::Color(crate::syntax::Color::ColorVar{i_p1}), q_p2};
}


/// ParseEmitType: unbounded fn Ps -> ((Type, Ps))
std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_emit_type_f(const crate::syntax::parser::Ps& p_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto [t_p2, p1_p3] = parse_union_type_f(p_p0);
    return crate::syntax::parser::at_kw_f(p1_p3, Text::lit("emit"))
        ? ({
        auto [r_p4, q_p5] = parse_union_type_f(crate::syntax::parser::adv_f(p1_p3));
        std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TEmit{prism_rtl::rc(t_p2), prism_rtl::rc(r_p4)})), .span_p = crate::syntax::parser::to_f(start_p1, prism_rtl::deref(r_p4).span_p)}, q_p5};
    })
        : std::tuple{t_p2, p1_p3};
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> ParseEmitType::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto p_p0x = p_p0;
    return crate::prelude::call_then(start_parse_union_type_f(p_p0x), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_union_type_f_2872) {
        return ({
            auto [t_p2, p1_p3] = parse_union_type_f_2872;
            (crate::syntax::parser::at_kw_f(p1_p3, Text::lit("emit"))
            ? crate::prelude::call_then(start_parse_union_type_f(crate::syntax::parser::adv_f(p1_p3)), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_union_type_f_2936) {
            return ({
                auto [r_p4, q_p5] = parse_union_type_f_2936;
                (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TEmit{prism_rtl::rc(t_p2), prism_rtl::rc(r_p4)})), .span_p = crate::syntax::parser::to_f(start_p1, prism_rtl::deref(r_p4).span_p)}, q_p5}));
            });
        })
            : prism_rtl::finished(std::tuple{t_p2, p1_p3}));
        });
    });
}


/// `Start ParseEmitType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_parse_emit_type_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseEmitType>(p_p0);
}


/// ParseUnionType: unbounded fn Ps -> ((Type, Ps))
std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_union_type_f(const crate::syntax::parser::Ps& p_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto [first_p2, p1_p3] = parse_map_type_f(p_p0);
    return crate::syntax::parser::kind_f(p1_p3) != crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{})
        ? std::tuple{first_p2, p1_p3}
        : ({
        auto r_p4 = ({
            std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_p2}), p1_p3};
            Array<crate::syntax::Type> terms_p5 = Array(std::vector{first_p2});
            crate::syntax::parser::Ps q_p6 = p1_p3;
            while ((crate::syntax::parser::kind_f(q_p6) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{})) && (!q_p6.bad_p)) {
                auto [t_p7, q2_p8] = parse_map_type_f(crate::syntax::parser::adv_f(q_p6));
                terms_p5 = crate::prelude::push(terms_p5, t_p7);
                q_p6 = q2_p8;
            }
            this_ = std::tuple{terms_p5, q_p6};
            (std::move(this_));
        });
        auto [terms_p9, q_pa] = r_p4;
        std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TRowUnion{terms_p9})), .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_pa))}, q_pa};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> ParseUnionType::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto p_p0x = p_p0;
    return crate::prelude::call_then(start_parse_map_type_f(p_p0x), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_map_type_f_3161) {
        return ({
            auto [first_p2, p1_p3] = parse_map_type_f_3161;
            (crate::syntax::parser::kind_f(p1_p3) != crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{})
            ? prism_rtl::finished(std::tuple{first_p2, p1_p3})
            : ({
            std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_p2}), p1_p3};
            Array<crate::syntax::Type> terms_p5 = Array(std::vector{first_p2});
            crate::syntax::parser::Ps q_p6 = p1_p3;
            auto start_p1z = start_p1;
            (crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_), std::move(q_p6), std::move(terms_p5)}, [=](std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Type>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q_p6 = std::get<1>(_p0);
            auto terms_p5 = std::get<2>(_p0);
            return (crate::syntax::parser::kind_f(q_p6) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{})) && (!prism_rtl::deref(q_p6).bad_p)
                ? ({
                auto [t_p7, q2_p8] = parse_map_type_f(crate::syntax::parser::adv_f(q_p6));
                terms_p5 = crate::prelude::push(terms_p5, t_p7);
                q_p6 = q2_p8;
                Expected<std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Type>>, std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Type>>>(std::tuple{this_, q_p6, terms_p5});
            })
                : Expected<std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Type>>, std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Type>>>(unexpected(std::tuple{this_, q_p6, terms_p5}));
        }), [=, start_p1z = std::move(start_p1z)](std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Type>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q_p6 = std::get<1>(_p0);
            auto terms_p5 = std::get<2>(_p0);
            return ({
                this_ = std::tuple{terms_p5, q_p6};
                auto r_p4 = this_;
                auto [terms_p9, q_pa] = r_p4;
                (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TRowUnion{terms_p9})), .span_p = crate::syntax::parser::to_f(start_p1z, crate::syntax::parser::prev_f(q_pa))}, q_pa}));
            });
        }));
        }));
        });
    });
}


/// `Start ParseUnionType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_parse_union_type_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseUnionType>(p_p0);
}


/// ParseMapType: unbounded fn Ps -> ((Type, Ps))
std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_map_type_f(const crate::syntax::parser::Ps& p_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto [k_p2, p1_p3] = parse_sigiled_type_f(p_p0);
    return crate::syntax::parser::at_op_f(p1_p3, Text::lit("==>"))
        ? ({
        auto [value_p4, q_p5] = parse_map_type_f(crate::syntax::parser::adv_f(p1_p3));
        std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TMap{prism_rtl::rc(k_p2), prism_rtl::rc(value_p4)})), .span_p = crate::syntax::parser::to_f(start_p1, prism_rtl::deref(value_p4).span_p)}, q_p5};
    })
        : std::tuple{k_p2, p1_p3};
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> ParseMapType::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto p_p0x = p_p0;
    return crate::prelude::call_then(start_parse_sigiled_type_f(p_p0x), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_sigiled_type_f_3741) {
        return ({
            auto [k_p2, p1_p3] = parse_sigiled_type_f_3741;
            (crate::syntax::parser::at_op_f(p1_p3, Text::lit("==>"))
            ? crate::prelude::call_then(start_parse_map_type_f(crate::syntax::parser::adv_f(p1_p3)), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_map_type_f_3810) {
            return ({
                auto [value_p4, q_p5] = parse_map_type_f_3810;
                (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TMap{prism_rtl::rc(k_p2), prism_rtl::rc(value_p4)})), .span_p = crate::syntax::parser::to_f(start_p1, prism_rtl::deref(value_p4).span_p)}, q_p5}));
            });
        })
            : prism_rtl::finished(std::tuple{k_p2, p1_p3}));
        });
    });
}


/// `Start ParseMapType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_parse_map_type_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseMapType>(p_p0);
}


/// ParseSigiledType: unbounded fn Ps -> ((Type, Ps))
std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_sigiled_type_f(const crate::syntax::parser::Ps& p_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto [sigils_p2, p1_p3] = free_sigil_run_f(p_p0);
    auto [inner_p4, q_p5] = parse_app_type_f(p1_p3);
    return sigils_p2 == Text::lit("")
        ? std::tuple{inner_p4, q_p5}
        : std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TSigiled{sigils_p2, prism_rtl::rc(inner_p4)})), .span_p = crate::syntax::parser::to_f(start_p1, prism_rtl::deref(inner_p4).span_p)}, q_p5};
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> ParseSigiledType::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto [sigils_p2, p1_p3] = free_sigil_run_f(p_p0);
    return crate::prelude::call_then(start_parse_app_type_f(p1_p3), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_app_type_f_4083) {
        return ({
            auto [inner_p4, q_p5] = parse_app_type_f_4083;
            sigils_p2 == Text::lit("")
            ? prism_rtl::finished(std::tuple{inner_p4, q_p5})
            : prism_rtl::finished(std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TSigiled{sigils_p2, prism_rtl::rc(inner_p4)})), .span_p = crate::syntax::parser::to_f(start_p1, prism_rtl::deref(inner_p4).span_p)}, q_p5});
        });
    });
}


/// `Start ParseSigiledType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_parse_sigiled_type_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseSigiledType>(p_p0);
}


/// FreeSigilRun: fn Ps -> ((Text, Ps))
std::tuple<Text, crate::syntax::parser::Ps> free_sigil_run_f(const crate::syntax::parser::Ps& p0_p0) {
    std::tuple<Text, crate::syntax::parser::Ps> this_ = std::tuple{Text::lit(""), p0_p0};
    Text sigils_p1 = Text::lit("");
    crate::syntax::parser::Ps p_p2 = p0_p0;
    Nat fuel_p3 = crate::prelude::len(p0_p0.toks_p);
    while (true) {
        auto&& _m = fuel_p3.checked_sub(Nat(1u));
        if (!(prism_rtl::is_some(_m))) break;
        auto&& left_p4 = prism_rtl::some_of(_m);
        fuel_p3 = left_p4;
        {
            auto&& _m = crate::syntax::parser::kind_f(p_p2);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
                auto&& s_p5 = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
                sigils_p1 = prism_rtl::cat(sigils_p1, s_p5);
                p_p2 = crate::syntax::parser::adv_f(p_p2);
            } else {
                fuel_p3 = Nat(0u);
            }
        }
    }
    this_ = std::tuple{sigils_p1, p_p2};
    return this_;
}


/// ParseAppType: unbounded fn Ps -> ((Type, Ps))
std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_app_type_f(const crate::syntax::parser::Ps& p_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto [head_p2, p1_p3] = parse_type_atom_f(p_p0);
    auto&& _m = prism_rtl::deref(prism_rtl::deref(head_p2).kind_p);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& name_p4 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m4714_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        if (m4714_0_1.size() == 0u) {
            if (type_atom_starts_here_f(p1_p3)) {
                auto r_p5 = ({
                    std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Type>{}, p1_p3};
                    Array<crate::syntax::Type> args_p6 = Array<crate::syntax::Type>{};
                    crate::syntax::parser::Ps q_p7 = p1_p3;
                    while (type_atom_starts_here_f(q_p7) && (!q_p7.bad_p)) {
                        auto [a_p8, q2_p9] = parse_type_atom_f(q_p7);
                        args_p6 = crate::prelude::push(args_p6, a_p8);
                        q_p7 = q2_p9;
                    }
                    this_ = std::tuple{args_p6, q_p7};
                    (std::move(this_));
                });
                auto [args_pa, q_pb] = r_p5;
                return std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TName{name_p4, args_pa})), .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_pb))}, q_pb};
            }
        }
    }
    {
        return std::tuple{head_p2, p1_p3};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> ParseAppType::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto p_p0x = p_p0;
    return crate::prelude::call_then(start_parse_type_atom_f(p_p0x), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_atom_f_4694) {
        return ({
            auto [head_p2, p1_p3] = parse_type_atom_f_4694;
            ({
            auto&& _m = prism_rtl::deref(prism_rtl::deref(head_p2).kind_p);
            prism_rtl::is<crate::syntax::TypeKind::TName>(_m) && ({
            auto&& name_p4 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
            auto&& m4714_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
            (m4714_0_1.size() == 0u) && type_atom_starts_here_f(p1_p3);
        }) ? ({
            auto&& name_p4 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
            auto&& m4714_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
            ({
            std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Type>{}, p1_p3};
            Array<crate::syntax::Type> args_p6 = Array<crate::syntax::Type>{};
            crate::syntax::parser::Ps q_p7 = p1_p3;
            auto name_p4z = name_p4;
            auto start_p1z = start_p1;
            (crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_), std::move(args_p6), std::move(q_p7)}, [=](std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, Array<crate::syntax::Type>, crate::syntax::parser::Ps> _p0) {
            auto this_ = std::get<0>(_p0);
            auto args_p6 = std::get<1>(_p0);
            auto q_p7 = std::get<2>(_p0);
            return type_atom_starts_here_f(q_p7) && (!prism_rtl::deref(q_p7).bad_p)
                ? ({
                auto [a_p8, q2_p9] = parse_type_atom_f(q_p7);
                args_p6 = crate::prelude::push(args_p6, a_p8);
                q_p7 = q2_p9;
                Expected<std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, Array<crate::syntax::Type>, crate::syntax::parser::Ps>, std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, Array<crate::syntax::Type>, crate::syntax::parser::Ps>>(std::tuple{this_, args_p6, q_p7});
            })
                : Expected<std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, Array<crate::syntax::Type>, crate::syntax::parser::Ps>, std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, Array<crate::syntax::Type>, crate::syntax::parser::Ps>>(unexpected(std::tuple{this_, args_p6, q_p7}));
        }), [=, name_p4z = std::move(name_p4z), start_p1z = std::move(start_p1z)](std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, Array<crate::syntax::Type>, crate::syntax::parser::Ps> _p0) {
            auto this_ = std::get<0>(_p0);
            auto args_p6 = std::get<1>(_p0);
            auto q_p7 = std::get<2>(_p0);
            return ({
                this_ = std::tuple{args_p6, q_p7};
                auto r_p5 = this_;
                auto [args_pa, q_pb] = r_p5;
                (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TName{name_p4z, args_pa})), .span_p = crate::syntax::parser::to_f(start_p1z, crate::syntax::parser::prev_f(q_pb))}, q_pb}));
            });
        }));
        });
        })
            : prism_rtl::finished(std::tuple{head_p2, p1_p3});
        });
        });
    });
}


/// `Start ParseAppType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_parse_app_type_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseAppType>(p_p0);
}


/// TypeAtomStartsHere: fn Ps -> Bool
bool type_atom_starts_here_f(const crate::syntax::parser::Ps& p_p0) {
    auto&& _m = crate::syntax::parser::kind_f(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& w_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        return (w_p1 == Text::lit("unit")) || (w_p1 == Text::lit("any"));
    }
    {
        return false;
    }
}


/// ParseTypeAtom: unbounded fn Ps -> ((Type, Ps))
std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_atom_f(const crate::syntax::parser::Ps& p_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto&& _m = crate::syntax::parser::kind_f(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
        return parse_sigiled_type_f(p_p0);
    }
    {
        auto [t_p2, p1_p3] = type_atom_body_f(p_p0, start_p1);
        return crate::syntax::parser::kind_f(p1_p3) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KNonEmpty{})
            ? ({
            auto m_p4 = crate::syntax::parser::here_f(p1_p3);
            auto q_p5 = crate::syntax::parser::out_of_scope_f(crate::syntax::parser::adv_f(p1_p3), m_p4, Text::lit("non-empty arrays"), Text::lit("the non-empty array type `[a]+` is out of this compiler"));
            std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TNonEmpty{prism_rtl::rc(t_p2)})), .span_p = crate::syntax::parser::to_f(start_p1, m_p4)}, q_p5};
        })
            : std::tuple{t_p2, p1_p3};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> ParseTypeAtom::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    return ({
        auto&& _m = crate::syntax::parser::kind_f(p_p0);
        prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m) ? prism_rtl::more(prism_rtl::rc(ParseSigiledType(p_p0)))
        : ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(start_type_atom_body_f(p_p0x, start_p1), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> type_atom_body_f_5777) {
        return ({
            auto [t_p2, p1_p3] = type_atom_body_f_5777;
            (crate::syntax::parser::kind_f(p1_p3) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KNonEmpty{})
            ? ({
            auto m_p4 = crate::syntax::parser::here_f(p1_p3);
            auto q_p5 = crate::syntax::parser::out_of_scope_f(crate::syntax::parser::adv_f(p1_p3), m_p4, Text::lit("non-empty arrays"), Text::lit("the non-empty array type `[a]+` is out of this compiler"));
            (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TNonEmpty{prism_rtl::rc(t_p2)})), .span_p = crate::syntax::parser::to_f(start_p1, m_p4)}, q_p5}));
        })
            : prism_rtl::finished(std::tuple{t_p2, p1_p3}));
        });
    }));
    });
    });
}


/// `Start ParseTypeAtom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_parse_type_atom_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseTypeAtom>(p_p0);
}


/// TypeAtomBody: unbounded fn Ps, Range -> ((Type, Ps))
std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> type_atom_body_f(const crate::syntax::parser::Ps& p_p0, const crate::syntax::Range& start_p1) {
    auto&& _m = crate::syntax::parser::kind_f(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        auto name_p3 = crate::syntax::SName{.sigils_p = prism_rtl::deref(n_p2).sigils_p, .path_p = prism_rtl::deref(n_p2).path_p, .span_p = start_p1};
        return (prism_rtl::deref(n_p2).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseTopic{})) || (prism_rtl::deref(n_p2).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseHole{}))
            ? std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::THole{name_p3})), .span_p = start_p1}, crate::syntax::parser::adv_f(p_p0)}
            : std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TName{name_p3, Array<crate::syntax::Type>{}})), .span_p = start_p1}, crate::syntax::parser::check_type_name_scope_f(crate::syntax::parser::adv_f(p_p0), name_p3)};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m6173_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& sigils_p4 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m6173_1_0 == Text::lit("unit")) {
            return std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TUnit{sigils_p4})), .span_p = start_p1}, crate::syntax::parser::adv_f(p_p0)};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m6173_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m6173_2_0 == Text::lit("any")) {
            auto [tr_p5, q_p6] = crate::syntax::parser::parse_trait_ref_f(crate::syntax::parser::adv_f(p_p0));
            return std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TAny{tr_p5})), .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_p6))}, q_p6};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        auto&& path_p7 = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        return std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TFamily{crate::syntax::QualName{.path_p = path_p7, .span_p = start_p1}})), .span_p = start_p1}, crate::syntax::parser::adv_f(p_p0)};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KAbsent>(_m)) {
        return std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TAbsent{})), .span_p = start_p1}, crate::syntax::parser::out_of_scope_f(crate::syntax::parser::adv_f(p_p0), start_p1, Text::lit("sparse tuples"), Text::lit("a sparse tuple type is out of this compiler"))};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m6173_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m6173_5_0 == Text::lit("(")) {
            return crate::syntax::parser::at_double_open_f(p_p0, Text::lit("("))
                ? ({
                auto [elems_p9, p1_pa] = crate::syntax::parser::commas_f(crate::syntax::parser::open_double_f(p_p0), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(start_parse_type_f(a0)); })));
                auto p2_p8 = crate::syntax::parser::close_double_f(p1_pa, Text::lit("("));
                std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TTuple{elems_p9})), .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(p2_p8))}, p2_p8};
            })
                : ({
                auto [inner_pc, p1_pd] = parse_type_f(crate::syntax::parser::adv_f(p_p0));
                auto p2_pb = crate::syntax::parser::expect_close_f(p1_pd, Text::lit("("));
                std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TGroup{prism_rtl::rc(inner_pc)})), .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(p2_pb))}, p2_pb};
            });
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m6173_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m6173_6_0 == Text::lit("[")) {
            auto doubled_pe = crate::syntax::parser::at_double_open_f(p_p0, Text::lit("["));
            auto [elem_pg, p1_ph] = parse_type_f(std::move(doubled_pe)
                ? crate::syntax::parser::open_double_f(p_p0)
                : crate::syntax::parser::adv_f(p_p0));
            auto p2_pf = std::move(doubled_pe)
                ? crate::syntax::parser::close_double_f(p1_ph, Text::lit("["))
                : crate::syntax::parser::expect_close_f(p1_ph, Text::lit("["));
            return std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TArray{prism_rtl::rc(elem_pg), std::move(doubled_pe)})), .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(p2_pf))}, p2_pf};
        }
    }
    {
        return std::tuple{crate::syntax::parser::decls::no_type_p(), crate::syntax::parser::error_here_f(p_p0, Text::lit("expected a type"))};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> TypeAtomBody::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& start_p1 = this->start_p1;
    return ({
        auto&& _m = crate::syntax::parser::kind_f(p_p0);
        prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) ? ({
        auto&& n_p2 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ({
        auto name_p3 = crate::syntax::SName{.sigils_p = prism_rtl::deref(n_p2).sigils_p, .path_p = prism_rtl::deref(n_p2).path_p, .span_p = start_p1};
        (prism_rtl::deref(n_p2).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseTopic{})) || (prism_rtl::deref(n_p2).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseHole{}))
        ? prism_rtl::finished(std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::THole{name_p3})), .span_p = start_p1}, crate::syntax::parser::adv_f(p_p0)})
        : prism_rtl::finished(std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TName{name_p3, Array<crate::syntax::Type>{}})), .span_p = start_p1}, crate::syntax::parser::check_type_name_scope_f(crate::syntax::parser::adv_f(p_p0), name_p3)});
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m6173_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& sigils_p4 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m6173_1_0 == Text::lit("unit"));
    }) ? ({
        auto&& m6173_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& sigils_p4 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        prism_rtl::finished(std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TUnit{sigils_p4})), .span_p = start_p1}, crate::syntax::parser::adv_f(p_p0)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m6173_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m6173_2_0 == Text::lit("any"));
    }) ? ({
        auto&& m6173_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto [tr_p5, q_p6] = crate::syntax::parser::parse_trait_ref_f(crate::syntax::parser::adv_f(p_p0));
        (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TAny{tr_p5})), .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_p6))}, q_p6}));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m) ? ({
        auto&& path_p7 = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TFamily{crate::syntax::QualName{.path_p = path_p7, .span_p = start_p1}})), .span_p = start_p1}, crate::syntax::parser::adv_f(p_p0)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KAbsent>(_m) ? prism_rtl::finished(std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TAbsent{})), .span_p = start_p1}, crate::syntax::parser::out_of_scope_f(crate::syntax::parser::adv_f(p_p0), start_p1, Text::lit("sparse tuples"), Text::lit("a sparse tuple type is out of this compiler"))})
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && ({
        auto&& m6173_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        (m6173_5_0 == Text::lit("("));
    }) ? ({
        auto&& m6173_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        crate::syntax::parser::at_double_open_f(p_p0, Text::lit("("))
        ? ({
        auto p_p0x = p_p0;
        auto start_p1x = start_p1;
        (crate::prelude::call_then(crate::syntax::parser::start_commas_f(crate::syntax::parser::open_double_f(p_p0x), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(start_parse_type_f(a0)); }))), [=, start_p1x = std::move(start_p1x)](std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps> commas_f_7134) {
        return ({
            auto [elems_p9, p1_pa] = commas_f_7134;
            auto p2_p8 = crate::syntax::parser::close_double_f(p1_pa, Text::lit("("));
            (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TTuple{elems_p9})), .span_p = crate::syntax::parser::to_f(start_p1x, crate::syntax::parser::prev_f(p2_p8))}, p2_p8}));
        });
    }));
    })
        : ({
        auto p_p0x = p_p0;
        auto start_p1x = start_p1;
        (crate::prelude::call_then(start_parse_type_f(crate::syntax::parser::adv_f(p_p0x)), [=, start_p1x = std::move(start_p1x)](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_f_7328) {
        return ({
            auto [inner_pc, p1_pd] = parse_type_f_7328;
            auto p2_pb = crate::syntax::parser::expect_close_f(p1_pd, Text::lit("("));
            (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TGroup{prism_rtl::rc(inner_pc)})), .span_p = crate::syntax::parser::to_f(start_p1x, crate::syntax::parser::prev_f(p2_pb))}, p2_pb}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && ({
        auto&& m6173_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        (m6173_6_0 == Text::lit("["));
    }) ? ({
        auto&& m6173_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        ({
        auto doubled_pe = crate::syntax::parser::at_double_open_f(p_p0, Text::lit("["));
        auto p_p0x = p_p0;
        auto start_p1x = start_p1;
        (crate::prelude::call_then(start_parse_type_f(std::move(doubled_pe)
        ? crate::syntax::parser::open_double_f(p_p0x)
        : crate::syntax::parser::adv_f(p_p0x)), [=, start_p1x = std::move(start_p1x)](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_f_7553) {
        return ({
            auto [elem_pg, p1_ph] = parse_type_f_7553;
            auto p2_pf = doubled_pe
                ? crate::syntax::parser::close_double_f(p1_ph, Text::lit("["))
                : crate::syntax::parser::expect_close_f(p1_ph, Text::lit("["));
            (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TArray{prism_rtl::rc(elem_pg), doubled_pe})), .span_p = crate::syntax::parser::to_f(start_p1x, crate::syntax::parser::prev_f(p2_pf))}, p2_pf}));
        });
    }));
    });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_type_p(), crate::syntax::parser::error_here_f(p_p0, Text::lit("expected a type"))});
    });
}


/// `Start TypeAtomBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_type_atom_body_f(crate::syntax::parser::Ps p_p0, crate::syntax::Range start_p1) {
    return prism_rtl::make_rc<TypeAtomBody>(p_p0, start_p1);
}


/// ParseBounds: unbounded fn Ps -> (([Bound], Ps))
std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps> parse_bounds_f(const crate::syntax::parser::Ps& p0_p0) {
    std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::decls::Bound>{}, p0_p0};
    Array<crate::syntax::decls::Bound> bounds_p1 = Array<crate::syntax::decls::Bound>{};
    crate::syntax::parser::Ps p_p2 = p0_p0;
    bool going_p3 = true;
    while (std::move(going_p3) && (!p_p2.bad_p)) {
        auto [b_p4, q_p5] = parse_bound_f(p_p2);
        bounds_p1 = crate::prelude::push(bounds_p1, b_p4);
        p_p2 = q_p5;
        if ((crate::syntax::parser::at_comma_f(p_p2) && is_name_kind_f(crate::syntax::parser::kind_at_f(p_p2, Nat(1u)))) && (crate::syntax::parser::kind_at_f(p_p2, Nat(2u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}))) {
            p_p2 = crate::syntax::parser::adv_f(p_p2);
        } else  {
            going_p3 = false;
        }
    }
    this_ = std::tuple{bounds_p1, p_p2};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>> ParseBounds::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::decls::Bound>{}, p0_p0};
    Array<crate::syntax::decls::Bound> bounds_p1 = Array<crate::syntax::decls::Bound>{};
    crate::syntax::parser::Ps p_p2 = p0_p0;
    bool going_p3 = true;
    return crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_), std::move(bounds_p1), std::move(going_p3), std::move(p_p2)}, [=](std::tuple<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>, Array<crate::syntax::decls::Bound>, bool, crate::syntax::parser::Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto bounds_p1 = std::get<1>(_p0);
        auto going_p3 = std::get<2>(_p0);
        auto p_p2 = std::get<3>(_p0);
        return going_p3 && (!prism_rtl::deref(p_p2).bad_p)
            ? ({
            auto [b_p4, q_p5] = parse_bound_f(p_p2);
            bounds_p1 = crate::prelude::push(bounds_p1, b_p4);
            p_p2 = q_p5;
            if ((crate::syntax::parser::at_comma_f(p_p2) && is_name_kind_f(crate::syntax::parser::kind_at_f(p_p2, Nat(1u)))) && (crate::syntax::parser::kind_at_f(p_p2, Nat(2u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}))) {
                p_p2 = crate::syntax::parser::adv_f(p_p2);
            } else  {
                going_p3 = false;
            }
            Expected<std::tuple<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>, Array<crate::syntax::decls::Bound>, bool, crate::syntax::parser::Ps>, std::tuple<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>, Array<crate::syntax::decls::Bound>, bool, crate::syntax::parser::Ps>>(std::tuple{this_, bounds_p1, going_p3, p_p2});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>, Array<crate::syntax::decls::Bound>, bool, crate::syntax::parser::Ps>, std::tuple<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>, Array<crate::syntax::decls::Bound>, bool, crate::syntax::parser::Ps>>(unexpected(std::tuple{this_, bounds_p1, going_p3, p_p2}));
    }), [=](std::tuple<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>, Array<crate::syntax::decls::Bound>, bool, crate::syntax::parser::Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto bounds_p1 = std::get<1>(_p0);
        auto going_p3 = std::get<2>(_p0);
        auto p_p2 = std::get<3>(_p0);
        return ({
            this_ = std::tuple{bounds_p1, p_p2};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start ParseBounds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>> start_parse_bounds_f(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseBounds>(p0_p0);
}


/// IsNameKind: fn TokKind -> Bool
bool is_name_kind_f(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// IsTraitKind: fn TokKind -> Bool
bool is_trait_kind_f(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTrait>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// ParseBound: unbounded fn Ps -> ((Bound, Ps))
std::tuple<crate::syntax::decls::Bound, crate::syntax::parser::Ps> parse_bound_f(const crate::syntax::parser::Ps& p_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto [var_p3, p1_p4] = crate::syntax::parser::parse_ident_f(p_p0);
    auto [first_p5, p2_p6] = crate::syntax::parser::parse_trait_ref_f(crate::syntax::parser::expect_colon_f(p1_p4));
    auto r_p2 = ({
        std::tuple<Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_p5}), p2_p6};
        Array<crate::syntax::TraitRef> traits_p7 = Array(std::vector{first_p5});
        crate::syntax::parser::Ps q_p8 = p2_p6;
        while ((crate::syntax::parser::at_comma_f(q_p8) && is_trait_kind_f(crate::syntax::parser::kind_at_f(q_p8, Nat(1u)))) && (!q_p8.bad_p)) {
            auto [t_p9, q2_pa] = crate::syntax::parser::parse_trait_ref_f(crate::syntax::parser::adv_f(q_p8));
            traits_p7 = crate::prelude::push(traits_p7, t_p9);
            q_p8 = q2_pa;
        }
        this_ = std::tuple{traits_p7, q_p8};
        (std::move(this_));
    });
    auto [traits_pb, q_pc] = r_p2;
    return std::tuple{crate::syntax::decls::Bound{.var_p = var_p3, .traits_p = traits_pb, .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_pc))}, q_pc};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::Bound, crate::syntax::parser::Ps>> ParseBound::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto [var_p3, p1_p4] = crate::syntax::parser::parse_ident_f(p_p0);
    auto [first_p5, p2_p6] = crate::syntax::parser::parse_trait_ref_f(crate::syntax::parser::expect_colon_f(p1_p4));
    std::tuple<Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_p5}), p2_p6};
    Array<crate::syntax::TraitRef> traits_p7 = Array(std::vector{first_p5});
    crate::syntax::parser::Ps q_p8 = p2_p6;
    auto start_p1z = start_p1;
    auto var_p3z = var_p3;
    return crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_), std::move(q_p8), std::move(traits_p7)}, [=](std::tuple<std::tuple<Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::TraitRef>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto q_p8 = std::get<1>(_p0);
        auto traits_p7 = std::get<2>(_p0);
        return (crate::syntax::parser::at_comma_f(q_p8) && is_trait_kind_f(crate::syntax::parser::kind_at_f(q_p8, Nat(1u)))) && (!prism_rtl::deref(q_p8).bad_p)
            ? ({
            auto [t_p9, q2_pa] = crate::syntax::parser::parse_trait_ref_f(crate::syntax::parser::adv_f(q_p8));
            traits_p7 = crate::prelude::push(traits_p7, t_p9);
            q_p8 = q2_pa;
            Expected<std::tuple<std::tuple<Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::TraitRef>>, std::tuple<std::tuple<Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::TraitRef>>>(std::tuple{this_, q_p8, traits_p7});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::TraitRef>>, std::tuple<std::tuple<Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::TraitRef>>>(unexpected(std::tuple{this_, q_p8, traits_p7}));
    }), [=](std::tuple<std::tuple<Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::TraitRef>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto q_p8 = std::get<1>(_p0);
        auto traits_p7 = std::get<2>(_p0);
        return ({
            this_ = std::tuple{traits_p7, q_p8};
            auto r_p2 = this_;
            auto [traits_pb, q_pc] = r_p2;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::Bound{.var_p = var_p3z, .traits_p = traits_pb, .span_p = crate::syntax::parser::to_f(start_p1z, crate::syntax::parser::prev_f(q_pc))}, q_pc}));
        });
    });
}


/// `Start ParseBound, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::Bound, crate::syntax::parser::Ps>> start_parse_bound_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseBound>(p_p0);
}


/// ParseRow: unbounded fn Ps -> ((Row, Ps))
std::tuple<crate::syntax::Row_, crate::syntax::parser::Ps> parse_row_f(const crate::syntax::parser::Ps& p_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto [first_p3, p1_p4] = parse_row_term_f(p_p0);
    auto r_p2 = ({
        std::tuple<Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_p3}), p1_p4};
        Array<crate::syntax::RowTerm> terms_p5 = Array(std::vector{first_p3});
        crate::syntax::parser::Ps q_p6 = p1_p4;
        while ((crate::syntax::parser::kind_f(q_p6) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{})) && (!q_p6.bad_p)) {
            auto [t_p7, q2_p8] = parse_row_term_f(crate::syntax::parser::adv_f(q_p6));
            terms_p5 = crate::prelude::push(terms_p5, t_p7);
            q_p6 = q2_p8;
        }
        this_ = std::tuple{terms_p5, q_p6};
        (std::move(this_));
    });
    auto [terms_p9, q_pa] = r_p2;
    return std::tuple{crate::syntax::Row_{.terms_p = terms_p9, .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_pa))}, q_pa};
}


prism_rtl::Turn<std::tuple<crate::syntax::Row_, crate::syntax::parser::Ps>> ParseRow::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto p_p0x = p_p0;
    return crate::prelude::call_then(start_parse_row_term_f(p_p0x), [=](std::tuple<crate::syntax::RowTerm, crate::syntax::parser::Ps> parse_row_term_f_9352) {
        return ({
            auto [first_p3, p1_p4] = parse_row_term_f_9352;
            std::tuple<Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_p3}), p1_p4};
            Array<crate::syntax::RowTerm> terms_p5 = Array(std::vector{first_p3});
            crate::syntax::parser::Ps q_p6 = p1_p4;
            auto start_p1z = start_p1;
            (crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_), std::move(q_p6), std::move(terms_p5)}, [=](std::tuple<std::tuple<Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::RowTerm>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q_p6 = std::get<1>(_p0);
            auto terms_p5 = std::get<2>(_p0);
            return (crate::syntax::parser::kind_f(q_p6) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{})) && (!prism_rtl::deref(q_p6).bad_p)
                ? ({
                auto [t_p7, q2_p8] = parse_row_term_f(crate::syntax::parser::adv_f(q_p6));
                terms_p5 = crate::prelude::push(terms_p5, t_p7);
                q_p6 = q2_p8;
                Expected<std::tuple<std::tuple<Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::RowTerm>>, std::tuple<std::tuple<Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::RowTerm>>>(std::tuple{this_, q_p6, terms_p5});
            })
                : Expected<std::tuple<std::tuple<Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::RowTerm>>, std::tuple<std::tuple<Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::RowTerm>>>(unexpected(std::tuple{this_, q_p6, terms_p5}));
        }), [=, start_p1z = std::move(start_p1z)](std::tuple<std::tuple<Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::RowTerm>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q_p6 = std::get<1>(_p0);
            auto terms_p5 = std::get<2>(_p0);
            return ({
                this_ = std::tuple{terms_p5, q_p6};
                auto r_p2 = this_;
                auto [terms_p9, q_pa] = r_p2;
                (prism_rtl::finished(std::tuple{crate::syntax::Row_{.terms_p = terms_p9, .span_p = crate::syntax::parser::to_f(start_p1z, crate::syntax::parser::prev_f(q_pa))}, q_pa}));
            });
        }));
        });
    });
}


/// `Start ParseRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Row_, crate::syntax::parser::Ps>> start_parse_row_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseRow>(p_p0);
}


/// ParseRowTerm: unbounded fn Ps -> ((RowTerm, Ps))
std::tuple<crate::syntax::RowTerm, crate::syntax::parser::Ps> parse_row_term_f(const crate::syntax::parser::Ps& p_p0) {
    auto&& _m = crate::syntax::parser::kind_f(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        auto&& path_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        return std::tuple{crate::syntax::RowTerm(crate::syntax::RowTerm::RFamily{crate::syntax::QualName{.path_p = path_p1, .span_p = crate::syntax::parser::here_f(p_p0)}}), crate::syntax::parser::adv_f(p_p0)};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if (is_plain_lower_one_f(crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KName{n_p2})) && (!type_atom_after_name_f(p_p0))) {
            return std::tuple{crate::syntax::RowTerm(crate::syntax::RowTerm::RVar{crate::syntax::Ident{.name_p = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(n_p2).path_p, Nat(0u)), Text::lit("")), .span_p = crate::syntax::parser::here_f(p_p0)}}), crate::syntax::parser::adv_f(p_p0)};
        }
    }
    {
        auto [t_p3, q_p4] = parse_map_type_f(p_p0);
        return std::tuple{crate::syntax::RowTerm(crate::syntax::RowTerm::RType{t_p3}), q_p4};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::RowTerm, crate::syntax::parser::Ps>> ParseRowTerm::cycle() const {
    const auto& p_p0 = this->p_p0;
    return ({
        auto&& _m = crate::syntax::parser::kind_f(p_p0);
        prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m) ? ({
        auto&& path_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::RowTerm(crate::syntax::RowTerm::RFamily{crate::syntax::QualName{.path_p = path_p1, .span_p = crate::syntax::parser::here_f(p_p0)}}), crate::syntax::parser::adv_f(p_p0)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n_p2 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        (is_plain_lower_one_f(crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KName{n_p2})) && (!type_atom_after_name_f(p_p0)));
    }) ? ({
        auto&& n_p2 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::RowTerm(crate::syntax::RowTerm::RVar{crate::syntax::Ident{.name_p = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(n_p2).path_p, Nat(0u)), Text::lit("")), .span_p = crate::syntax::parser::here_f(p_p0)}}), crate::syntax::parser::adv_f(p_p0)});
    })
        : ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(start_parse_map_type_f(p_p0x), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_map_type_f_10063) {
        return ({
            auto [t_p3, q_p4] = parse_map_type_f_10063;
            (prism_rtl::finished(std::tuple{crate::syntax::RowTerm(crate::syntax::RowTerm::RType{t_p3}), q_p4}));
        });
    }));
    });
    });
}


/// `Start ParseRowTerm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::RowTerm, crate::syntax::parser::Ps>> start_parse_row_term_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseRowTerm>(p_p0);
}


/// TypeAtomAfterName: fn Ps -> Bool
bool type_atom_after_name_f(const crate::syntax::parser::Ps& p_p0) {
    auto&& _m = crate::syntax::parser::kind_at_f(p_p0, Nat(1u));
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// ParsePattern: unbounded fn Ps, Bool -> ((Pattern, Ps))
std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_f(const crate::syntax::parser::Ps& p_p0, const bool& commas0_p1) {
    auto commas_p2 = commas0_p1 && (!p_p0.step_mode_p);
    auto start_p3 = crate::syntax::parser::here_f(p_p0);
    auto&& _m = crate::syntax::parser::kind_f(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
        auto&& s_p4 = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        if ((s_p4 == Text::lit("?")) || (s_p4 == Text::lit("~"))) {
            auto [inner_p5, q_p6] = parse_pattern_f(crate::syntax::parser::adv_f(p_p0), commas_p2);
            return std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PSigil{s_p4, prism_rtl::rc(inner_p5)})), .span_p = crate::syntax::parser::to_f(start_p3, prism_rtl::deref(inner_p5).span_p)}, q_p6};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
        auto&& s_p7 = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        return std::tuple{crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_at_f(p_p0, start_p3, prism_rtl::cat("a free `", s_p7, "` is not a pattern: only `? p` and `~ p` take a value apart"))};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n_p8 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        return name_pattern_f(p_p0, n_p8, commas_p2);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m10847_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m10847_3_0 == Text::lit("ignore")) {
            return std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span_p = start_p3}, crate::syntax::parser::adv_f(p_p0)};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m10847_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m10847_4_0 == Text::lit("unit")) {
            return std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PUnit{})), .span_p = start_p3}, crate::syntax::parser::adv_f(p_p0)};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m10847_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m10847_5_0 == Text::lit("nil")) {
            return std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PNil{})), .span_p = start_p3}, crate::syntax::parser::adv_f(p_p0)};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m)) {
        return literal_pattern_f(p_p0);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(_m)) {
        return literal_pattern_f(p_p0);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(_m)) {
        return literal_pattern_f(p_p0);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(_m)) {
        return literal_pattern_f(p_p0);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m)) {
        return literal_pattern_f(p_p0);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KRegex>(_m)) {
        return std::tuple{crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_at_f(p_p0, start_p3, Text::lit("a regular expression is not a pattern: match a text with `?Match` or `?Find`"))};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a1) {
        auto&& m10847_12_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        if (m10847_12_0 == Text::lit("-")) {
            auto p1_p9 = crate::syntax::parser::adv_f(p_p0);
            return is_number_kind_f(crate::syntax::parser::kind_f(p1_p9))
                ? ({
                auto [lit_pa, q_pb] = crate::syntax::parser::expr::parse_literal_f(p1_p9);
                std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PNeg{lit_pa})), .span_p = crate::syntax::parser::to_f(start_p3, prism_rtl::deref(lit_pa).span_p)}, q_pb};
            })
                : std::tuple{crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_here_f(p1_p9, Text::lit("a `-` in a pattern is the sign of a number literal"))};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m10847_13_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m10847_13_0 == Text::lit("(")) {
            return crate::syntax::parser::at_double_open_f(p_p0, Text::lit("("))
                ? ({
                auto [elems_pe, p1_pf] = crate::syntax::parser::commas_f(crate::syntax::parser::open_double_f(p_p0), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
                    return crate::prelude::entered(crate::prelude::once_job([=]() {
                        return ({
                            auto q_pd = p0;
                            (prism_rtl::more(prism_rtl::rc(ParsePattern(q_pd, false))));
                        });
                    }));
                })));
                auto p2_pc = crate::syntax::parser::close_double_f(p1_pf, Text::lit("("));
                std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PTuple{elems_pe})), .span_p = crate::syntax::parser::to_f(start_p3, crate::syntax::parser::prev_f(p2_pc))}, p2_pc};
            })
                : ({
                auto [inner_pi, p1_pj] = crate::syntax::parser::bracketed_f(crate::syntax::parser::adv_f(p_p0), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
                    return crate::prelude::entered(crate::prelude::once_job([=]() {
                        return ({
                            auto q_ph = p0;
                            (prism_rtl::more(prism_rtl::rc(ParsePattern(q_ph, true))));
                        });
                    }));
                })));
                auto p2_pg = crate::syntax::parser::expect_close_f(p1_pj, Text::lit("("));
                std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PGroup{prism_rtl::rc(inner_pi)})), .span_p = crate::syntax::parser::to_f(start_p3, crate::syntax::parser::prev_f(p2_pg))}, p2_pg};
            });
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m10847_14_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m10847_14_0 == Text::lit("[")) {
            if (crate::syntax::parser::at_double_open_f(p_p0, Text::lit("["))) {
                auto p1_pk = crate::syntax::parser::open_double_f(p_p0);
                auto [elems_pn, p2_po] = crate::syntax::parser::at_close_f(p1_pk, Text::lit("["))
                    ? std::tuple{Array<crate::syntax::Pattern_>{}, p1_pk}
                    : crate::syntax::parser::commas_f(p1_pk, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
                    return crate::prelude::entered(crate::prelude::once_job([=]() {
                        return ({
                            auto q_pm = p0;
                            (prism_rtl::more(prism_rtl::rc(ParsePattern(q_pm, false))));
                        });
                    }));
                })));
                auto p3_pl = crate::syntax::parser::close_double_f(p2_po, Text::lit("["));
                return std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PArray{elems_pn})), .span_p = crate::syntax::parser::to_f(start_p3, crate::syntax::parser::prev_f(p3_pl))}, p3_pl};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        auto&& path_pp = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        return std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PFamily{crate::syntax::QualName{.path_p = path_pp, .span_p = start_p3}})), .span_p = start_p3}, crate::syntax::parser::adv_f(p_p0)};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KAbsent>(_m)) {
        return std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span_p = start_p3}, crate::syntax::parser::out_of_scope_f(crate::syntax::parser::adv_f(p_p0), start_p3, Text::lit("sparse tuples"), Text::lit("an absent component `-` is a sparse tuple\'s, out of this compiler"))};
    }
    {
        return std::tuple{crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_here_f(p_p0, Text::lit("expected a pattern"))};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> ParsePattern::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& commas0_p1 = this->commas0_p1;
    auto commas_p2 = prism_rtl::deref(commas0_p1) && (!prism_rtl::deref(p_p0).step_mode_p);
    auto start_p3 = crate::syntax::parser::here_f(p_p0);
    return ({
        auto&& _m = crate::syntax::parser::kind_f(p_p0);
        prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m) && ({
        auto&& s_p4 = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        ((s_p4 == Text::lit("?")) || (s_p4 == Text::lit("~")));
    }) ? ({
        auto&& s_p4 = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(start_parse_pattern_f(crate::syntax::parser::adv_f(p_p0x), std::move(commas_p2)), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_f_10933) {
        return ({
            auto [inner_p5, q_p6] = parse_pattern_f_10933;
            (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PSigil{s_p4, prism_rtl::rc(inner_p5)})), .span_p = crate::syntax::parser::to_f(start_p3, prism_rtl::deref(inner_p5).span_p)}, q_p6}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m) ? ({
        auto&& s_p7 = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_at_f(p_p0, start_p3, prism_rtl::cat("a free `", s_p7, "` is not a pattern: only `? p` and `~ p` take a value apart"))});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) ? ({
        auto&& n_p8 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(NamePattern(p_p0, n_p8, std::move(commas_p2))));
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m10847_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m10847_3_0 == Text::lit("ignore"));
    }) ? ({
        auto&& m10847_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span_p = start_p3}, crate::syntax::parser::adv_f(p_p0)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m10847_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m10847_4_0 == Text::lit("unit"));
    }) ? ({
        auto&& m10847_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PUnit{})), .span_p = start_p3}, crate::syntax::parser::adv_f(p_p0)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m10847_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m10847_5_0 == Text::lit("nil"));
    }) ? ({
        auto&& m10847_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PNil{})), .span_p = start_p3}, crate::syntax::parser::adv_f(p_p0)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPattern(p_p0)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPattern(p_p0)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPattern(p_p0)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPattern(p_p0)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPattern(p_p0)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KRegex>(_m) ? prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_at_f(p_p0, start_p3, Text::lit("a regular expression is not a pattern: match a text with `?Match` or `?Find`"))})
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a1 && ({
        auto&& m10847_12_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        (m10847_12_0 == Text::lit("-"));
    }) ? ({
        auto&& m10847_12_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        ({
        auto p1_p9 = crate::syntax::parser::adv_f(p_p0);
        is_number_kind_f(crate::syntax::parser::kind_f(p1_p9))
        ? crate::prelude::call_then(crate::syntax::parser::expr::start_parse_literal_f(p1_p9), [=](std::tuple<crate::syntax::Literal, crate::syntax::parser::Ps> parse_literal_f_11989) {
        return ({
            auto [lit_pa, q_pb] = parse_literal_f_11989;
            (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PNeg{lit_pa})), .span_p = crate::syntax::parser::to_f(start_p3, prism_rtl::deref(lit_pa).span_p)}, q_pb}));
        });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_here_f(p1_p9, Text::lit("a `-` in a pattern is the sign of a number literal"))});
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && ({
        auto&& m10847_13_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        (m10847_13_0 == Text::lit("("));
    }) ? ({
        auto&& m10847_13_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        crate::syntax::parser::at_double_open_f(p_p0, Text::lit("("))
        ? ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(crate::syntax::parser::start_commas_f(crate::syntax::parser::open_double_f(p_p0x), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto q_pd = p0;
                (prism_rtl::more(prism_rtl::rc(ParsePattern(q_pd, false))));
            });
        }));
    }))), [=](std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps> commas_f_12281) {
        return ({
            auto [elems_pe, p1_pf] = commas_f_12281;
            auto p2_pc = crate::syntax::parser::close_double_f(p1_pf, Text::lit("("));
            (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PTuple{elems_pe})), .span_p = crate::syntax::parser::to_f(start_p3, crate::syntax::parser::prev_f(p2_pc))}, p2_pc}));
        });
    }));
    })
        : ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(crate::syntax::parser::start_bracketed_f(crate::syntax::parser::adv_f(p_p0x), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto q_ph = p0;
                (prism_rtl::more(prism_rtl::rc(ParsePattern(q_ph, true))));
            });
        }));
    }))), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> bracketed_f_12668) {
        return ({
            auto [inner_pi, p1_pj] = bracketed_f_12668;
            auto p2_pg = crate::syntax::parser::expect_close_f(p1_pj, Text::lit("("));
            (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PGroup{prism_rtl::rc(inner_pi)})), .span_p = crate::syntax::parser::to_f(start_p3, crate::syntax::parser::prev_f(p2_pg))}, p2_pg}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && ({
        auto&& m10847_14_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        (m10847_14_0 == Text::lit("[")) && crate::syntax::parser::at_double_open_f(p_p0, Text::lit("["));
    }) ? ({
        auto&& m10847_14_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        ({
        auto p1_pk = crate::syntax::parser::open_double_f(p_p0);
        auto [elems_pn, p2_po] = crate::syntax::parser::at_close_f(p1_pk, Text::lit("["))
            ? std::tuple{Array<crate::syntax::Pattern_>{}, p1_pk}
            : crate::syntax::parser::commas_f(p1_pk, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto q_pm = p0;
                    (prism_rtl::more(prism_rtl::rc(ParsePattern(q_pm, false))));
                });
            }));
        })));
        auto p3_pl = crate::syntax::parser::close_double_f(p2_po, Text::lit("["));
        (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PArray{elems_pn})), .span_p = crate::syntax::parser::to_f(start_p3, crate::syntax::parser::prev_f(p3_pl))}, p3_pl}));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m) ? ({
        auto&& path_pp = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PFamily{crate::syntax::QualName{.path_p = path_pp, .span_p = start_p3}})), .span_p = start_p3}, crate::syntax::parser::adv_f(p_p0)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KAbsent>(_m) ? prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span_p = start_p3}, crate::syntax::parser::out_of_scope_f(crate::syntax::parser::adv_f(p_p0), start_p3, Text::lit("sparse tuples"), Text::lit("an absent component `-` is a sparse tuple\'s, out of this compiler"))})
        : prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_here_f(p_p0, Text::lit("expected a pattern"))});
    });
}


/// `Start ParsePattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> start_parse_pattern_f(crate::syntax::parser::Ps p_p0, bool commas0_p1) {
    return prism_rtl::make_rc<ParsePattern>(p_p0, commas0_p1);
}


/// IsNumberKind: fn TokKind -> Bool
bool is_number_kind_f(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// LiteralPattern: unbounded fn Ps -> ((Pattern, Ps))
std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> literal_pattern_f(const crate::syntax::parser::Ps& p_p0) {
    auto [lit_p1, q_p2] = crate::syntax::parser::expr::parse_literal_f(p_p0);
    return std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PLit{lit_p1})), .span_p = prism_rtl::deref(lit_p1).span_p}, q_p2};
}


prism_rtl::Turn<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> LiteralPattern::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto p_p0x = p_p0;
    return crate::prelude::call_then(crate::syntax::parser::expr::start_parse_literal_f(p_p0x), [=](std::tuple<crate::syntax::Literal, crate::syntax::parser::Ps> parse_literal_f_13802) {
        return ({
            auto [lit_p1, q_p2] = parse_literal_f_13802;
            (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PLit{lit_p1})), .span_p = prism_rtl::deref(lit_p1).span_p}, q_p2}));
        });
    });
}


/// `Start LiteralPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> start_literal_pattern_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<LiteralPattern>(p_p0);
}


/// NamePattern: unbounded fn Ps, NameTok, Bool -> ((Pattern, Ps))
std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> name_pattern_f(const crate::syntax::parser::Ps& p0_p0, const crate::syntax::lexer::NameTok& n_p1, const bool& commas_p2) {
    auto start_p3 = crate::syntax::parser::here_f(p0_p0);
    auto name_p4 = crate::syntax::SName{.sigils_p = n_p1.sigils_p, .path_p = n_p1.path_p, .span_p = start_p3};
    auto p_p5 = crate::syntax::parser::adv_f(p0_p0);
    return (crate::syntax::parser::is_callee_f(name_p4) && crate::syntax::parser::at_single_open_f(p_p5, Text::lit("("))) && prism_rtl::deref(crate::syntax::parser::tk_f(p_p5)).touches_p
        ? parse_record_pattern_f(p_p5, name_p4)
        : crate::syntax::parser::is_callee_f(name_p4) && pat_arg_starts_here_f(p_p5)
        ? ({
        auto [first_p7, p1_p8] = parse_pattern_f(p_p5, false);
        auto r_p6 = ({
            std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_p7}), p1_p8};
            Array<crate::syntax::Pattern_> args_p9 = Array(std::vector{first_p7});
            crate::syntax::parser::Ps q_pa = p1_p8;
            while ((commas_p2 && crate::syntax::parser::at_comma_f(q_pa)) && (!q_pa.bad_p)) {
                auto [a_pb, q2_pc] = parse_pattern_f(crate::syntax::parser::adv_f(q_pa), false);
                args_p9 = crate::prelude::push(args_p9, a_pb);
                q_pa = q2_pc;
            }
            this_ = std::tuple{args_p9, q_pa};
            (std::move(this_));
        });
        auto [args_pd, q_pe] = r_p6;
        std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PCtor{name_p4, args_pd})), .span_p = crate::syntax::parser::to_f(start_p3, crate::syntax::parser::prev_f(q_pe))}, q_pe};
    })
        : std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PName{name_p4})), .span_p = start_p3}, p_p5};
}


prism_rtl::Turn<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> NamePattern::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    const auto& n_p1 = this->n_p1;
    const auto& commas_p2 = this->commas_p2;
    auto start_p3 = crate::syntax::parser::here_f(p0_p0);
    auto name_p4 = crate::syntax::SName{.sigils_p = prism_rtl::deref(n_p1).sigils_p, .path_p = prism_rtl::deref(n_p1).path_p, .span_p = start_p3};
    auto p_p5 = crate::syntax::parser::adv_f(p0_p0);
    return (crate::syntax::parser::is_callee_f(name_p4) && crate::syntax::parser::at_single_open_f(p_p5, Text::lit("("))) && prism_rtl::deref(crate::syntax::parser::tk_f(p_p5)).touches_p
        ? prism_rtl::more(prism_rtl::rc(ParseRecordPattern(p_p5, name_p4)))
        : crate::syntax::parser::is_callee_f(name_p4) && pat_arg_starts_here_f(p_p5)
        ? ({
        auto commas_p2x = prism_rtl::deref(commas_p2);
        (crate::prelude::call_then(start_parse_pattern_f(p_p5, false), [=, commas_p2x = std::move(commas_p2x)](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_f_14247) {
        return ({
            auto [first_p7, p1_p8] = parse_pattern_f_14247;
            std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_p7}), p1_p8};
            Array<crate::syntax::Pattern_> args_p9 = Array(std::vector{first_p7});
            crate::syntax::parser::Ps q_pa = p1_p8;
            auto name_p4z = name_p4;
            auto start_p3z = start_p3;
            (crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_), std::move(args_p9), std::move(q_pa)}, ({
            auto commas_p2xx = commas_p2x;
            [=, commas_p2xx = std::move(commas_p2xx)](std::tuple<std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps>, Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps> _p0) {
            auto this_ = std::get<0>(_p0);
            auto args_p9 = std::get<1>(_p0);
            auto q_pa = std::get<2>(_p0);
            return (commas_p2xx && crate::syntax::parser::at_comma_f(q_pa)) && (!prism_rtl::deref(q_pa).bad_p)
                ? ({
                auto [a_pb, q2_pc] = parse_pattern_f(crate::syntax::parser::adv_f(q_pa), false);
                args_p9 = crate::prelude::push(args_p9, a_pb);
                q_pa = q2_pc;
                Expected<std::tuple<std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps>, Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps>, std::tuple<std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps>, Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps>>(std::tuple{this_, args_p9, q_pa});
            })
                : Expected<std::tuple<std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps>, Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps>, std::tuple<std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps>, Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps>>(unexpected(std::tuple{this_, args_p9, q_pa}));
        };
        })), [=, name_p4z = std::move(name_p4z), start_p3z = std::move(start_p3z)](std::tuple<std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps>, Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps> _p0) {
            auto this_ = std::get<0>(_p0);
            auto args_p9 = std::get<1>(_p0);
            auto q_pa = std::get<2>(_p0);
            return ({
                this_ = std::tuple{args_p9, q_pa};
                auto r_p6 = this_;
                auto [args_pd, q_pe] = r_p6;
                (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PCtor{name_p4z, args_pd})), .span_p = crate::syntax::parser::to_f(start_p3z, crate::syntax::parser::prev_f(q_pe))}, q_pe}));
            });
        }));
        });
    }));
    })
        : prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PName{name_p4})), .span_p = start_p3}, p_p5});
}


/// `Start NamePattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> start_name_pattern_f(crate::syntax::parser::Ps p0_p0, crate::syntax::lexer::NameTok n_p1, bool commas_p2) {
    return prism_rtl::make_rc<NamePattern>(p0_p0, n_p1, commas_p2);
}


/// PatArgStartsHere: fn Ps -> Bool
bool pat_arg_starts_here_f(const crate::syntax::parser::Ps& p_p0) {
    auto&& _m = crate::syntax::parser::kind_f(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
        auto&& s_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        return (s_p1 == Text::lit("?")) || (s_p1 == Text::lit("~"));
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m14865_8_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m14865_8_0 == Text::lit("(")) {
            return (!prism_rtl::deref(crate::syntax::parser::tk_f(p_p0)).touches_p) || crate::syntax::parser::at_double_open_f(p_p0, Text::lit("("));
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m14865_9_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m14865_9_0 == Text::lit("[")) {
            return crate::syntax::parser::at_double_open_f(p_p0, Text::lit("["));
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a1) {
        auto&& m14865_10_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        if (m14865_10_0 == Text::lit("-")) {
            return true;
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& w_p2 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        return ((w_p2 == Text::lit("ignore")) || (w_p2 == Text::lit("unit"))) || (w_p2 == Text::lit("nil"));
    }
    {
        return false;
    }
}


/// ParseRecordPattern: unbounded fn Ps, SName -> ((Pattern, Ps))
std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_record_pattern_f(const crate::syntax::parser::Ps& p0_p0, const crate::syntax::SName& name_p1) {
    auto p_p2 = crate::syntax::parser::adv_f(p0_p0);
    auto r_p3 = ({
        FieldsRead this_ = FieldsRead{.fields_p = Array<crate::syntax::FieldPat>{}, .rest_p = false, .p_p = p_p2, .going_p = !crate::syntax::parser::at_close_f(p_p2, Text::lit("("))};
        while (this_.going_p && (!prism_rtl::deref(this_.p_p).bad_p)) {
            if (crate::syntax::parser::kind_f(this_.p_p) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDotDot{})) {
                this_.p_p = crate::syntax::parser::adv_f(this_.p_p);
                this_.rest_p = true;
            } else  {
                auto fstart_p5 = crate::syntax::parser::here_f(this_.p_p);
                auto [fname_o6, p1_p7] = crate::syntax::parser::expr::parse_arg_name_f(this_.p_p);
                auto [pattern_p8, p2_p9] = parse_pattern_f(p1_p7, false);
                this_.fields_p = crate::prelude::push(this_.fields_p, crate::syntax::FieldPat{.name_o = fname_o6, .pattern_p = pattern_p8, .span_p = crate::syntax::parser::to_f(fstart_p5, prism_rtl::deref(pattern_p8).span_p)});
                this_.p_p = p2_p9;
            }
            if (crate::syntax::parser::at_comma_f(this_.p_p)) {
                this_.p_p = crate::syntax::parser::adv_f(this_.p_p);
            } else  {
                this_.going_p = false;
            }
        }
        (std::move(this_));
    });
    auto q_p4 = crate::syntax::parser::expect_close_f(prism_rtl::deref(r_p3).p_p, Text::lit("("));
    return std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PRecord{name_p1, prism_rtl::deref(r_p3).fields_p, prism_rtl::deref(r_p3).rest_p})), .span_p = crate::syntax::parser::to_f(name_p1.span_p, crate::syntax::parser::prev_f(q_p4))}, q_p4};
}


prism_rtl::Turn<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> ParseRecordPattern::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    const auto& name_p1 = this->name_p1;
    auto p_p2 = crate::syntax::parser::adv_f(p0_p0);
    FieldsRead this_ = FieldsRead{.fields_p = Array<crate::syntax::FieldPat>{}, .rest_p = false, .p_p = p_p2, .going_p = !crate::syntax::parser::at_close_f(p_p2, Text::lit("("))};
    auto name_p1z = name_p1;
    auto p_p2z = p_p2;
    return crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_)}, ({
        auto name_p1x = name_p1;
        auto p_p2x = p_p2;
        [=](std::tuple<FieldsRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return prism_rtl::deref(this_).going_p && (!prism_rtl::deref(prism_rtl::deref(this_).p_p).bad_p)
            ? ({
            if (crate::syntax::parser::kind_f(prism_rtl::deref(this_).p_p) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDotDot{})) {
                prism_rtl::deref(this_).p_p = crate::syntax::parser::adv_f(prism_rtl::deref(this_).p_p);
                prism_rtl::deref(this_).rest_p = true;
            } else  {
                auto fstart_p5 = crate::syntax::parser::here_f(prism_rtl::deref(this_).p_p);
                auto [fname_o6, p1_p7] = crate::syntax::parser::expr::parse_arg_name_f(prism_rtl::deref(this_).p_p);
                auto [pattern_p8, p2_p9] = parse_pattern_f(p1_p7, false);
                prism_rtl::deref(this_).fields_p = crate::prelude::push(prism_rtl::deref(this_).fields_p, crate::syntax::FieldPat{.name_o = fname_o6, .pattern_p = pattern_p8, .span_p = crate::syntax::parser::to_f(fstart_p5, prism_rtl::deref(pattern_p8).span_p)});
                prism_rtl::deref(this_).p_p = p2_p9;
            }
            if (crate::syntax::parser::at_comma_f(prism_rtl::deref(this_).p_p)) {
                prism_rtl::deref(this_).p_p = crate::syntax::parser::adv_f(prism_rtl::deref(this_).p_p);
            } else  {
                prism_rtl::deref(this_).going_p = false;
            }
            Expected<std::tuple<FieldsRead>, std::tuple<FieldsRead>>(std::tuple{this_});
        })
            : Expected<std::tuple<FieldsRead>, std::tuple<FieldsRead>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<FieldsRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto r_p3 = this_;
            auto q_p4 = crate::syntax::parser::expect_close_f(prism_rtl::deref(r_p3).p_p, Text::lit("("));
            (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PRecord{name_p1z, prism_rtl::deref(r_p3).fields_p, prism_rtl::deref(r_p3).rest_p})), .span_p = crate::syntax::parser::to_f(prism_rtl::deref(name_p1z).span_p, crate::syntax::parser::prev_f(q_p4))}, q_p4}));
        });
    });
}


/// `Start ParseRecordPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> start_parse_record_pattern_f(crate::syntax::parser::Ps p0_p0, crate::syntax::SName name_p1) {
    return prism_rtl::make_rc<ParseRecordPattern>(p0_p0, name_p1);
}

}  // namespace crate::syntax::parser::types
