// The module `Emit.Cpp.Patterns`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/cpp/patterns/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Emit.Cpp.Patterns`, from `target/bootstrap/cpp-src/prismc/emit/cpp/patterns.prism`.
namespace crate::emit::cpp::patterns {

/// PatConds: unbounded fn Cp, Pa, Text -> [Text]
Array<Text> pat_conds(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Pa& p_p1, const Text& v_p2) {
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(p_p1)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p1)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p1)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p1)) {
        auto&& q_p3 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p1).a0;
        return pat_conds(cp_p0, prism_rtl::deref(prism_rtl::deref(q_p3)), v_p2);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_p1)) {
        auto&& c_p4 = prism_rtl::as<crate::lower::model::Pa::PaUnit>(p_p1).a0;
        return Array(std::vector{crate::emit::cpp::expr::case_test(cp_p0, c_p4, v_p2)});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_p1)) {
        auto&& c_p5 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p1).a0;
        auto&& ps_p6 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p1).a1;
        auto own_p7 = crate::emit::cpp::expr::case_test(cp_p0, c_p5, v_p2);
        auto inner_p8 = concat2(run_to_end(each_job(crate::check::errors::range0(len(ps_p6)), ({
            auto cp_p0_1 = cp_p0;
            auto ps_p6_2 = ps_p6;
            auto c_p5_3 = c_p5;
            auto v_p2_4 = v_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1), ps_p6_2 = std::move(ps_p6_2), c_p5_3 = std::move(c_p5_3), v_p2_4 = std::move(v_p2_4)](Nat p0) {
            return ({
                auto cp_p0_1_5 = cp_p0_1;
                auto ps_p6_2_5 = ps_p6_2;
                auto c_p5_3_5 = c_p5_3;
                auto v_p2_4_5 = v_p2_4;
                entered(once_job([=, cp_p0_1_5 = std::move(cp_p0_1_5), ps_p6_2_5 = std::move(ps_p6_2_5), c_p5_3_5 = std::move(c_p5_3_5), v_p2_4_5 = std::move(v_p2_4_5)]() {
                return ({
                    auto i_p9 = p0;
                    (prism_rtl::more(prism_rtl::rc(PatConds(cp_p0_1_5, or_(index(ps_p6_2_5, i_p9), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), crate::emit::cpp::expr::payload(cp_p0_1_5, c_p5_3_5, v_p2_4_5, i_p9)))));
                });
            }));
            });
        })));
        }))));
        return filter(append(Array(std::vector{own_p7}), inner_p8), [&](const Text& t_pa) { return t_pa != Text::lit("true"); });
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_p1)) {
        auto&& c_pb = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p1).a0;
        auto&& fs_pc = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p1).a1;
        return concat2(run_to_end(each_job(fs_pc, ({
            auto cp_p0_1 = cp_p0;
            auto v_p2_2 = v_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1), v_p2_2 = std::move(v_p2_2)](std::tuple<Text, crate::lower::model::Pa> p0) {
            return ({
                auto cp_p0_1_3 = cp_p0_1;
                auto v_p2_2_3 = v_p2_2;
                entered(once_job([=, cp_p0_1_3 = std::move(cp_p0_1_3), v_p2_2_3 = std::move(v_p2_2_3)]() {
                return ({
                    auto [f_pd, q_pe] = p0;
                    (prism_rtl::more(prism_rtl::rc(PatConds(cp_p0_1_3, q_pe, prism_rtl::cat(v_p2_2_3, ".", crate::emit::cpp::field_id(f_pd))))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p1)) {
        auto&& ps_pf = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p1).a0;
        return concat2(run_to_end(each_job(crate::check::errors::range0(len(ps_pf)), ({
            auto cp_p0_1 = cp_p0;
            auto ps_pf_2 = ps_pf;
            auto v_p2_3 = v_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1), ps_pf_2 = std::move(ps_pf_2), v_p2_3 = std::move(v_p2_3)](Nat p0) {
            return ({
                auto cp_p0_1_4 = cp_p0_1;
                auto ps_pf_2_4 = ps_pf_2;
                auto v_p2_3_4 = v_p2_3;
                entered(once_job([=, cp_p0_1_4 = std::move(cp_p0_1_4), ps_pf_2_4 = std::move(ps_pf_2_4), v_p2_3_4 = std::move(v_p2_3_4)]() {
                return ({
                    auto i_pg = p0;
                    (prism_rtl::more(prism_rtl::rc(PatConds(cp_p0_1_4, or_(index(ps_pf_2_4, i_pg), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat("std::get<", i_pg, ">(", v_p2_3_4, ")")))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaChar>(p_p1)) {
        auto&& c_ph = prism_rtl::as<crate::lower::model::Pa::PaChar>(p_p1).a0;
        return Array(std::vector{prism_rtl::cat(v_p2, " == U\'", crate::emit::cpp::expr::cpp_char_escape(c_ph), "\'")});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBool>(p_p1)) {
        auto&& b_pi = prism_rtl::as<crate::lower::model::Pa::PaBool>(p_p1).a0;
        return Array(std::vector{prism_rtl::deref(b_pi) ? v_p2 : prism_rtl::cat("!", v_p2)});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaIndex>(p_p1)) {
        auto&& n_pj = prism_rtl::as<crate::lower::model::Pa::PaIndex>(p_p1).a0;
        return Array(std::vector{prism_rtl::cat(v_p2, " == ", n_pj, "u")});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaConst>(p_p1)) {
        auto&& n_pk = prism_rtl::as<crate::lower::model::Pa::PaConst>(p_p1).a0;
        return Array(std::vector{prism_rtl::cat(v_p2, " == ", n_pk)});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_p1)) {
        auto&& ps_pl = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_p1).a0;
        auto rest_pm = fold(ps_pl, false, [&](const bool& f_pp, const crate::lower::model::Pa& q_pq) { return prism_rtl::deref(f_pp) || is_rest(q_pq); });
        auto fixed_pn = len(filter(ps_pl, [&](const crate::lower::model::Pa& q_pr) { return !is_rest(q_pr); }));
        auto size_po = std::move(rest_pm)
            ? prism_rtl::cat(v_p2, ".size() >= ", fixed_pn)
            : prism_rtl::cat(v_p2, ".size() == ", fixed_pn);
        return append(Array(std::vector{size_po}), concat2(run_to_end(each_job(crate::check::errors::range0(len(ps_pl)), ({
            auto cp_p0_1 = cp_p0;
            auto ps_pl_2 = ps_pl;
            auto v_p2_3 = v_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1), ps_pl_2 = std::move(ps_pl_2), v_p2_3 = std::move(v_p2_3)](Nat p0) {
            return ({
                auto cp_p0_1_4 = cp_p0_1;
                auto ps_pl_2_4 = ps_pl_2;
                auto v_p2_3_4 = v_p2_3;
                entered(once_job([=, cp_p0_1_4 = std::move(cp_p0_1_4), ps_pl_2_4 = std::move(ps_pl_2_4), v_p2_3_4 = std::move(v_p2_3_4)]() {
                return ({
                    auto i_ps = p0;
                    (prism_rtl::more(prism_rtl::rc(PatConds(cp_p0_1_4, or_(index(ps_pl_2_4, i_ps), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat(v_p2_3_4, "[", i_ps, "]")))));
                });
            }));
            });
        })));
        })))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(p_p1)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> PatConds::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& p_p1 = this->p_p1;
    const auto& v_p2 = this->v_p2;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaWild>(p_p1) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p1) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p1) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p1) ? ({
        auto&& q_p3 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p1).a0;
        prism_rtl::more(prism_rtl::rc(PatConds(cp_p0, prism_rtl::deref(prism_rtl::deref(q_p3)), v_p2)));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_p1) ? ({
        auto&& c_p4 = prism_rtl::as<crate::lower::model::Pa::PaUnit>(p_p1).a0;
        prism_rtl::finished(Array(std::vector{crate::emit::cpp::expr::case_test(cp_p0, c_p4, v_p2)}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_p1) ? ({
        auto&& c_p5 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p1).a0;
        auto&& ps_p6 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p1).a1;
        ({
        auto own_p7 = crate::emit::cpp::expr::case_test(cp_p0, c_p5, v_p2);
        auto c_p5_1 = c_p5;
        auto cp_p0_2 = cp_p0;
        auto ps_p6_3 = ps_p6;
        auto v_p2_4 = v_p2;
        call_value(each_job(crate::check::errors::range0(len(ps_p6_3)), ({
        auto cp_p0_2_5 = cp_p0_2;
        auto ps_p6_3_5 = ps_p6_3;
        auto c_p5_1_5 = c_p5_1;
        auto v_p2_4_5 = v_p2_4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0_2_5 = std::move(cp_p0_2_5), ps_p6_3_5 = std::move(ps_p6_3_5), c_p5_1_5 = std::move(c_p5_1_5), v_p2_4_5 = std::move(v_p2_4_5)](Nat p0) {
        return ({
            auto cp_p0_2_5_5 = cp_p0_2_5;
            auto ps_p6_3_5_5 = ps_p6_3_5;
            auto c_p5_1_5_5 = c_p5_1_5;
            auto v_p2_4_5_5 = v_p2_4_5;
            entered(once_job([=, cp_p0_2_5_5 = std::move(cp_p0_2_5_5), ps_p6_3_5_5 = std::move(ps_p6_3_5_5), c_p5_1_5_5 = std::move(c_p5_1_5_5), v_p2_4_5_5 = std::move(v_p2_4_5_5)]() {
            return ({
                auto i_p9 = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_p0_2_5_5, or_(index(ps_p6_3_5_5, i_p9), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), crate::emit::cpp::expr::payload(cp_p0_2_5_5, c_p5_1_5_5, v_p2_4_5_5, i_p9)))));
            });
        }));
        });
    })));
    })), [=, own_p7 = std::move(own_p7)](Array<Array<Text>> each_1488) {
        return ({
            auto inner_p8 = concat2(each_1488);
            (prism_rtl::finished(filter(append(Array(std::vector{own_p7}), inner_p8), [&](const Text& t_pa) { return t_pa != Text::lit("true"); })));
        });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_p1) ? ({
        auto&& c_pb = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p1).a0;
        auto&& fs_pc = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p1).a1;
        ({
        auto cp_p0_1 = cp_p0;
        auto fs_pc_2 = fs_pc;
        auto v_p2_3 = v_p2;
        call_value(each_job(fs_pc_2, ({
        auto cp_p0_1_4 = cp_p0_1;
        auto v_p2_3_4 = v_p2_3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=, cp_p0_1_4 = std::move(cp_p0_1_4), v_p2_3_4 = std::move(v_p2_3_4)](std::tuple<Text, crate::lower::model::Pa> p0) {
        return ({
            auto cp_p0_1_4_4 = cp_p0_1_4;
            auto v_p2_3_4_4 = v_p2_3_4;
            entered(once_job([=, cp_p0_1_4_4 = std::move(cp_p0_1_4_4), v_p2_3_4_4 = std::move(v_p2_3_4_4)]() {
            return ({
                auto [f_pd, q_pe] = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_p0_1_4_4, q_pe, prism_rtl::cat(v_p2_3_4_4, ".", crate::emit::cpp::field_id(f_pd))))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_1667) { return prism_rtl::finished(concat2(each_1667)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p1) ? ({
        auto&& ps_pf = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p1).a0;
        ({
        auto cp_p0_1 = cp_p0;
        auto ps_pf_2 = ps_pf;
        auto v_p2_3 = v_p2;
        call_value(each_job(crate::check::errors::range0(len(ps_pf_2)), ({
        auto cp_p0_1_4 = cp_p0_1;
        auto ps_pf_2_4 = ps_pf_2;
        auto v_p2_3_4 = v_p2_3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0_1_4 = std::move(cp_p0_1_4), ps_pf_2_4 = std::move(ps_pf_2_4), v_p2_3_4 = std::move(v_p2_3_4)](Nat p0) {
        return ({
            auto cp_p0_1_4_4 = cp_p0_1_4;
            auto ps_pf_2_4_4 = ps_pf_2_4;
            auto v_p2_3_4_4 = v_p2_3_4;
            entered(once_job([=, cp_p0_1_4_4 = std::move(cp_p0_1_4_4), ps_pf_2_4_4 = std::move(ps_pf_2_4_4), v_p2_3_4_4 = std::move(v_p2_3_4_4)]() {
            return ({
                auto i_pg = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_p0_1_4_4, or_(index(ps_pf_2_4_4, i_pg), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat("std::get<", i_pg, ">(", v_p2_3_4_4, ")")))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_1748) { return prism_rtl::finished(concat2(each_1748)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaChar>(p_p1) ? ({
        auto&& c_ph = prism_rtl::as<crate::lower::model::Pa::PaChar>(p_p1).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat(v_p2, " == U\'", crate::emit::cpp::expr::cpp_char_escape(c_ph), "\'")}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaBool>(p_p1) ? ({
        auto&& b_pi = prism_rtl::as<crate::lower::model::Pa::PaBool>(p_p1).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::deref(b_pi) ? v_p2 : prism_rtl::cat("!", v_p2)}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaIndex>(p_p1) ? ({
        auto&& n_pj = prism_rtl::as<crate::lower::model::Pa::PaIndex>(p_p1).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat(v_p2, " == ", n_pj, "u")}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaConst>(p_p1) ? ({
        auto&& n_pk = prism_rtl::as<crate::lower::model::Pa::PaConst>(p_p1).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat(v_p2, " == ", n_pk)}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_p1) ? ({
        auto&& ps_pl = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_p1).a0;
        ({
        auto rest_pm = fold(ps_pl, false, [&](const bool& f_pp, const crate::lower::model::Pa& q_pq) { return prism_rtl::deref(f_pp) || is_rest(q_pq); });
        auto fixed_pn = len(filter(ps_pl, [&](const crate::lower::model::Pa& q_pr) { return !is_rest(q_pr); }));
        auto size_po = std::move(rest_pm)
            ? prism_rtl::cat(v_p2, ".size() >= ", fixed_pn)
            : prism_rtl::cat(v_p2, ".size() == ", fixed_pn);
        auto cp_p0_1 = cp_p0;
        auto ps_pl_2 = ps_pl;
        auto v_p2_3 = v_p2;
        call_value(each_job(crate::check::errors::range0(len(ps_pl_2)), ({
        auto cp_p0_1_4 = cp_p0_1;
        auto ps_pl_2_4 = ps_pl_2;
        auto v_p2_3_4 = v_p2_3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0_1_4 = std::move(cp_p0_1_4), ps_pl_2_4 = std::move(ps_pl_2_4), v_p2_3_4 = std::move(v_p2_3_4)](Nat p0) {
        return ({
            auto cp_p0_1_4_4 = cp_p0_1_4;
            auto ps_pl_2_4_4 = ps_pl_2_4;
            auto v_p2_3_4_4 = v_p2_3_4;
            entered(once_job([=, cp_p0_1_4_4 = std::move(cp_p0_1_4_4), ps_pl_2_4_4 = std::move(ps_pl_2_4_4), v_p2_3_4_4 = std::move(v_p2_3_4_4)]() {
            return ({
                auto i_ps = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_p0_1_4_4, or_(index(ps_pl_2_4_4, i_ps), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat(v_p2_3_4_4, "[", i_ps, "]")))));
            });
        }));
        });
    })));
    })), [=, size_po = std::move(size_po)](Array<Array<Text>> each_2231) { return prism_rtl::finished(append(Array(std::vector{size_po}), concat2(each_2231))); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRest>(p_p1) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start PatConds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_pat_conds(crate::emit::cpp::Cp cp_p0, crate::lower::model::Pa p_p1, Text v_p2) {
    return prism_rtl::make_rc<PatConds>(cp_p0, p_p1, v_p2);
}


/// PatBinds: unbounded fn Cp, Pa, Text -> [Text]
Array<Text> pat_binds(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Pa& p_p1, const Text& v_p2) {
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(p_p1)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p1)) {
        auto&& n_p3 = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_p1).a0;
        return Array(std::vector{prism_rtl::cat("auto&& ", crate::emit::cpp::cpp_id(n_p3), " = ", v_p2, ";")});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p1)) {
        auto&& n_p4 = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_p1).a0;
        return Array(std::vector{prism_rtl::cat("auto ", crate::emit::cpp::cpp_id(n_p4), " = ", v_p2, ";")});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p1)) {
        auto&& m2400_3_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p1).a0;
        auto&& t_p6 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p1).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(m2400_3_0)))) {
            auto&& n_p5 = prism_rtl::as<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(m2400_3_0))).a0;
            return Array(std::vector{prism_rtl::cat(crate::emit::cpp::cpp_type(cp_p0, crate::emit::cpp::expr::unref(t_p6)), " ", crate::emit::cpp::cpp_id(n_p5), " = ", v_p2, ";")});
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p1)) {
        auto&& q_p7 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p1).a0;
        return pat_binds(cp_p0, prism_rtl::deref(prism_rtl::deref(q_p7)), v_p2);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_p1)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_p1)) {
        auto&& c_p8 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p1).a0;
        auto&& ps_p9 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p1).a1;
        return concat2(run_to_end(each_job(crate::check::errors::range0(len(ps_p9)), ({
            auto cp_p0_1 = cp_p0;
            auto ps_p9_2 = ps_p9;
            auto c_p8_3 = c_p8;
            auto v_p2_4 = v_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1), ps_p9_2 = std::move(ps_p9_2), c_p8_3 = std::move(c_p8_3), v_p2_4 = std::move(v_p2_4)](Nat p0) {
            return ({
                auto cp_p0_1_5 = cp_p0_1;
                auto ps_p9_2_5 = ps_p9_2;
                auto c_p8_3_5 = c_p8_3;
                auto v_p2_4_5 = v_p2_4;
                entered(once_job([=, cp_p0_1_5 = std::move(cp_p0_1_5), ps_p9_2_5 = std::move(ps_p9_2_5), c_p8_3_5 = std::move(c_p8_3_5), v_p2_4_5 = std::move(v_p2_4_5)]() {
                return ({
                    auto i_pa = p0;
                    (prism_rtl::more(prism_rtl::rc(PatBinds(cp_p0_1_5, or_(index(ps_p9_2_5, i_pa), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), crate::emit::cpp::expr::payload(cp_p0_1_5, c_p8_3_5, v_p2_4_5, i_pa)))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_p1)) {
        auto&& c_pb = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p1).a0;
        auto&& fs_pc = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p1).a1;
        return concat2(run_to_end(each_job(fs_pc, ({
            auto cp_p0_1 = cp_p0;
            auto v_p2_2 = v_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1), v_p2_2 = std::move(v_p2_2)](std::tuple<Text, crate::lower::model::Pa> p0) {
            return ({
                auto cp_p0_1_3 = cp_p0_1;
                auto v_p2_2_3 = v_p2_2;
                entered(once_job([=, cp_p0_1_3 = std::move(cp_p0_1_3), v_p2_2_3 = std::move(v_p2_2_3)]() {
                return ({
                    auto [f_pd, q_pe] = p0;
                    (prism_rtl::more(prism_rtl::rc(PatBinds(cp_p0_1_3, q_pe, prism_rtl::cat(v_p2_2_3, ".", crate::emit::cpp::field_id(f_pd))))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p1)) {
        auto&& ps_pf = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p1).a0;
        return concat2(run_to_end(each_job(crate::check::errors::range0(len(ps_pf)), ({
            auto cp_p0_1 = cp_p0;
            auto ps_pf_2 = ps_pf;
            auto v_p2_3 = v_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1), ps_pf_2 = std::move(ps_pf_2), v_p2_3 = std::move(v_p2_3)](Nat p0) {
            return ({
                auto cp_p0_1_4 = cp_p0_1;
                auto ps_pf_2_4 = ps_pf_2;
                auto v_p2_3_4 = v_p2_3;
                entered(once_job([=, cp_p0_1_4 = std::move(cp_p0_1_4), ps_pf_2_4 = std::move(ps_pf_2_4), v_p2_3_4 = std::move(v_p2_3_4)]() {
                return ({
                    auto i_pg = p0;
                    (prism_rtl::more(prism_rtl::rc(PatBinds(cp_p0_1_4, or_(index(ps_pf_2_4, i_pg), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat("std::get<", i_pg, ">(", v_p2_3_4, ")")))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_p1)) {
        auto&& ps_ph = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_p1).a0;
        return concat2(run_to_end(each_job(crate::check::errors::range0(len(ps_ph)), ({
            auto cp_p0_1 = cp_p0;
            auto ps_ph_2 = ps_ph;
            auto v_p2_3 = v_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1), ps_ph_2 = std::move(ps_ph_2), v_p2_3 = std::move(v_p2_3)](Nat p0) {
            return ({
                auto cp_p0_1_4 = cp_p0_1;
                auto ps_ph_2_4 = ps_ph_2;
                auto v_p2_3_4 = v_p2_3;
                entered(once_job([=, cp_p0_1_4 = std::move(cp_p0_1_4), ps_ph_2_4 = std::move(ps_ph_2_4), v_p2_3_4 = std::move(v_p2_3_4)]() {
                return ({
                    auto i_pi = p0;
                    (prism_rtl::more(prism_rtl::rc(SliceBinds(cp_p0_1_4, or_(index(ps_ph_2_4, i_pi), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), v_p2_3_4, i_pi))));
                });
            }));
            });
        })));
        }))));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> PatBinds::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& p_p1 = this->p_p1;
    const auto& v_p2 = this->v_p2;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaWild>(p_p1) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p1) ? ({
        auto&& n_p3 = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_p1).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat("auto&& ", crate::emit::cpp::cpp_id(n_p3), " = ", v_p2, ";")}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p1) ? ({
        auto&& n_p4 = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_p1).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat("auto ", crate::emit::cpp::cpp_id(n_p4), " = ", v_p2, ";")}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p1) && ({
        auto&& m2400_3_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p1).a0;
        auto&& t_p6 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p1).a1;
        prism_rtl::is<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(m2400_3_0)));
    }) ? ({
        auto&& m2400_3_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p1).a0;
        auto&& t_p6 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p1).a1;
        auto&& n_p5 = prism_rtl::as<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(m2400_3_0))).a0;
        ({
        auto cp_p0_1 = cp_p0;
        auto n_p5_2 = n_p5;
        auto t_p6_3 = t_p6;
        auto v_p2_4 = v_p2;
        call_then(crate::emit::cpp::start_cpp_type(cp_p0_1, crate::emit::cpp::expr::unref(t_p6_3)), [=, n_p5_2 = std::move(n_p5_2), v_p2_4 = std::move(v_p2_4)](Text cpp_type_2542) { return prism_rtl::finished(Array(std::vector{prism_rtl::cat(cpp_type_2542, " ", crate::emit::cpp::cpp_id(n_p5_2), " = ", v_p2_4, ";")})); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p1) ? ({
        auto&& q_p7 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p1).a0;
        prism_rtl::more(prism_rtl::rc(PatBinds(cp_p0, prism_rtl::deref(prism_rtl::deref(q_p7)), v_p2)));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_p1) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_p1) ? ({
        auto&& c_p8 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p1).a0;
        auto&& ps_p9 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p1).a1;
        ({
        auto c_p8_1 = c_p8;
        auto cp_p0_2 = cp_p0;
        auto ps_p9_3 = ps_p9;
        auto v_p2_4 = v_p2;
        call_value(each_job(crate::check::errors::range0(len(ps_p9_3)), ({
        auto cp_p0_2_5 = cp_p0_2;
        auto ps_p9_3_5 = ps_p9_3;
        auto c_p8_1_5 = c_p8_1;
        auto v_p2_4_5 = v_p2_4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0_2_5 = std::move(cp_p0_2_5), ps_p9_3_5 = std::move(ps_p9_3_5), c_p8_1_5 = std::move(c_p8_1_5), v_p2_4_5 = std::move(v_p2_4_5)](Nat p0) {
        return ({
            auto cp_p0_2_5_5 = cp_p0_2_5;
            auto ps_p9_3_5_5 = ps_p9_3_5;
            auto c_p8_1_5_5 = c_p8_1_5;
            auto v_p2_4_5_5 = v_p2_4_5;
            entered(once_job([=, cp_p0_2_5_5 = std::move(cp_p0_2_5_5), ps_p9_3_5_5 = std::move(ps_p9_3_5_5), c_p8_1_5_5 = std::move(c_p8_1_5_5), v_p2_4_5_5 = std::move(v_p2_4_5_5)]() {
            return ({
                auto i_pa = p0;
                (prism_rtl::more(prism_rtl::rc(PatBinds(cp_p0_2_5_5, or_(index(ps_p9_3_5_5, i_pa), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), crate::emit::cpp::expr::payload(cp_p0_2_5_5, c_p8_1_5_5, v_p2_4_5_5, i_pa)))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_2677) { return prism_rtl::finished(concat2(each_2677)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_p1) ? ({
        auto&& c_pb = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p1).a0;
        auto&& fs_pc = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p1).a1;
        ({
        auto cp_p0_1 = cp_p0;
        auto fs_pc_2 = fs_pc;
        auto v_p2_3 = v_p2;
        call_value(each_job(fs_pc_2, ({
        auto cp_p0_1_4 = cp_p0_1;
        auto v_p2_3_4 = v_p2_3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=, cp_p0_1_4 = std::move(cp_p0_1_4), v_p2_3_4 = std::move(v_p2_3_4)](std::tuple<Text, crate::lower::model::Pa> p0) {
        return ({
            auto cp_p0_1_4_4 = cp_p0_1_4;
            auto v_p2_3_4_4 = v_p2_3_4;
            entered(once_job([=, cp_p0_1_4_4 = std::move(cp_p0_1_4_4), v_p2_3_4_4 = std::move(v_p2_3_4_4)]() {
            return ({
                auto [f_pd, q_pe] = p0;
                (prism_rtl::more(prism_rtl::rc(PatBinds(cp_p0_1_4_4, q_pe, prism_rtl::cat(v_p2_3_4_4, ".", crate::emit::cpp::field_id(f_pd))))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_2799) { return prism_rtl::finished(concat2(each_2799)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p1) ? ({
        auto&& ps_pf = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p1).a0;
        ({
        auto cp_p0_1 = cp_p0;
        auto ps_pf_2 = ps_pf;
        auto v_p2_3 = v_p2;
        call_value(each_job(crate::check::errors::range0(len(ps_pf_2)), ({
        auto cp_p0_1_4 = cp_p0_1;
        auto ps_pf_2_4 = ps_pf_2;
        auto v_p2_3_4 = v_p2_3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0_1_4 = std::move(cp_p0_1_4), ps_pf_2_4 = std::move(ps_pf_2_4), v_p2_3_4 = std::move(v_p2_3_4)](Nat p0) {
        return ({
            auto cp_p0_1_4_4 = cp_p0_1_4;
            auto ps_pf_2_4_4 = ps_pf_2_4;
            auto v_p2_3_4_4 = v_p2_3_4;
            entered(once_job([=, cp_p0_1_4_4 = std::move(cp_p0_1_4_4), ps_pf_2_4_4 = std::move(ps_pf_2_4_4), v_p2_3_4_4 = std::move(v_p2_3_4_4)]() {
            return ({
                auto i_pg = p0;
                (prism_rtl::more(prism_rtl::rc(PatBinds(cp_p0_1_4_4, or_(index(ps_pf_2_4_4, i_pg), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat("std::get<", i_pg, ">(", v_p2_3_4_4, ")")))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_2880) { return prism_rtl::finished(concat2(each_2880)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_p1) ? ({
        auto&& ps_ph = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_p1).a0;
        ({
        auto cp_p0_1 = cp_p0;
        auto ps_ph_2 = ps_ph;
        auto v_p2_3 = v_p2;
        call_value(each_job(crate::check::errors::range0(len(ps_ph_2)), ({
        auto cp_p0_1_4 = cp_p0_1;
        auto ps_ph_2_4 = ps_ph_2;
        auto v_p2_3_4 = v_p2_3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0_1_4 = std::move(cp_p0_1_4), ps_ph_2_4 = std::move(ps_ph_2_4), v_p2_3_4 = std::move(v_p2_3_4)](Nat p0) {
        return ({
            auto cp_p0_1_4_4 = cp_p0_1_4;
            auto ps_ph_2_4_4 = ps_ph_2_4;
            auto v_p2_3_4_4 = v_p2_3_4;
            entered(once_job([=, cp_p0_1_4_4 = std::move(cp_p0_1_4_4), ps_ph_2_4_4 = std::move(ps_ph_2_4_4), v_p2_3_4_4 = std::move(v_p2_3_4_4)]() {
            return ({
                auto i_pi = p0;
                (prism_rtl::more(prism_rtl::rc(SliceBinds(cp_p0_1_4_4, or_(index(ps_ph_2_4_4, i_pi), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), v_p2_3_4_4, i_pi))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_2989) { return prism_rtl::finished(concat2(each_2989)); });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start PatBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_pat_binds(crate::emit::cpp::Cp cp_p0, crate::lower::model::Pa p_p1, Text v_p2) {
    return prism_rtl::make_rc<PatBinds>(cp_p0, p_p1, v_p2);
}


/// SliceBinds: unbounded fn Cp, Pa, Text, Nat -> [Text]
Array<Text> slice_binds(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Pa& pa1, const Text& v_p1, const Nat& i_p2) {
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(pa1)) {
        auto&& c0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaRest>(pa1).a0;
        if (c0_1_0 == Text::lit("")) {
            return Array<Text>{};
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(pa1)) {
        auto&& n_p4 = prism_rtl::as<crate::lower::model::Pa::PaRest>(pa1).a0;
        return Array(std::vector{prism_rtl::cat("auto ", crate::emit::cpp::cpp_id(n_p4), " = ", v_p1, ".subspan(", i_p2, ");")});
    }
    {
        auto&& p_p8 = pa1;
        return pat_binds(cp_p0, p_p8, prism_rtl::cat(v_p1, "[", i_p2, "]"));
    }
}


prism_rtl::Turn<Array<Text>> SliceBinds::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& pa1 = this->pa1;
    const auto& v_p1 = this->v_p1;
    const auto& i_p2 = this->i_p2;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaRest>(pa1) && ({
        auto&& j0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaRest>(pa1).a0;
        (j0_1_0 == Text::lit(""));
    }) ? ({
        auto&& j0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaRest>(pa1).a0;
        prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRest>(pa1) ? ({
        auto&& n_p4 = prism_rtl::as<crate::lower::model::Pa::PaRest>(pa1).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat("auto ", crate::emit::cpp::cpp_id(n_p4), " = ", v_p1, ".subspan(", i_p2, ");")}));
    })
        : ({
        auto&& p_p8 = pa1;
        prism_rtl::more(prism_rtl::rc(PatBinds(cp_p0, p_p8, prism_rtl::cat(v_p1, "[", i_p2, "]"))));
    });
    });
}


/// `Start SliceBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_slice_binds(crate::emit::cpp::Cp cp_p0, crate::lower::model::Pa pa1, Text v_p1, Nat i_p2) {
    return prism_rtl::make_rc<SliceBinds>(cp_p0, pa1, v_p1, i_p2);
}


/// IsRest: fn Pa -> Bool
bool is_rest(const crate::lower::model::Pa& pa0) {
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(pa0)) {
        return true;
    }
    {
        auto&& other_p0 = pa0;
        return false;
    }
}


/// Concat2: fn [ [Text] ] -> [Text]
Array<Text> concat2(const Array<Array<Text>>& xss_p0) {
    return fold(xss_p0, Array<Text>{}, [&](const Array<Text>& acc_p1, const Array<Text>& xs_p2) { return append(acc_p1, xs_p2); });
}


/// Conds: fn [Text] -> Text
Text conds(const Array<Text>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("true");
        }
    }
    {
        auto&& cs_p0 = xs0;
        return crate::syntax::lexer::chars::join(cs_p0, Text::lit(" && "));
    }
}


/// IsCatchAll: fn Pa -> Bool
bool is_catch_all(const crate::lower::model::Pa& p_p0) {
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(p_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p0)) {
        auto&& q_p1 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p0).a0;
        return is_catch_all(prism_rtl::deref(prism_rtl::deref(q_p1)));
    }
    {
        return false;
    }
}


/// Leaves: fn Ex -> Bool
bool leaves(const crate::lower::model::Ex& x_p0) {
    if (prism_rtl::is<crate::lower::model::Ex::XBreak>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnreachable>(x_p0)) {
        return true;
    }
    {
        return false;
    }
}


/// CppMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
Text cpp_match(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& s_p1, const Array<crate::lower::model::XArm>& arms_p2, const crate::lower::model::OutTy& out_ty3) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(out_ty3)) {
        auto&& what_p3 = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(out_ty3).a0;
        return ternary_match(cp_p0, s_p1, arms_p2);
    }
    {
        auto&& t_p7 = out_ty3;
        auto bound_o8 = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(s_p1)) {
                auto&& n_pc = prism_rtl::as<crate::lower::model::Ex::XVar>(s_p1).a0;
                _v.set(std::optional(crate::emit::cpp::stmts::var_name(cp_p0, n_pc)));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::model::Ex::XRef>(s_p1)) {
                auto&& m4524_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s_p1).a0;
                if (prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m4524_1_0)))) {
                    auto&& n_pd = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m4524_1_0))).a0;
                    _v.set(std::optional(crate::emit::cpp::stmts::var_name(cp_p0, n_pd)));
                    goto _done;
                }
            }
            {
                _v.set(std::optional<Text>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subject_p9 = or_(bound_o8, Text::lit("_m"));
        auto bind_pa = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(bound_o8)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            if (prism_rtl::is_none(bound_o8)) {
                _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp_p0, s_p1), ";\n"));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto lines_pb = run_to_end(each_job(arms_p2, ({
            auto cp_p0_1 = cp_p0;
            auto subject_p9_2 = subject_p9;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1), subject_p9_2 = std::move(subject_p9_2)](crate::lower::model::XArm p0) {
            return ({
                auto cp_p0_1_3 = cp_p0_1;
                auto subject_p9_2_3 = subject_p9_2;
                entered(once_job([=, cp_p0_1_3 = std::move(cp_p0_1_3), subject_p9_2_3 = std::move(subject_p9_2_3)]() {
                return ({
                    auto a_pe = p0;
                    (prism_rtl::more(prism_rtl::rc(MatchArm(cp_p0_1_3, subject_p9_2_3, a_pe, false))));
                });
            }));
            });
        })));
        })));
        return crate::emit::cpp::templates::items::match_expr(crate::emit::cpp::cpp_type(cp_p0, t_p7), prism_rtl::cat(bind_pa, crate::syntax::lexer::chars::join(lines_pb, Text::lit("\n")), "\n", match_tail(arms_p2)));
    }
}


prism_rtl::Turn<Text> CppMatch::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& s_p1 = this->s_p1;
    const auto& arms_p2 = this->arms_p2;
    const auto& out_ty3 = this->out_ty3;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(out_ty3) ? ({
        auto&& what_p3 = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(out_ty3).a0;
        prism_rtl::more(prism_rtl::rc(TernaryMatch(cp_p0, s_p1, arms_p2)));
    })
        : ({
        auto&& t_p7 = out_ty3;
        ({
        auto bound_o8 = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(s_p1)) {
                auto&& n_pc = prism_rtl::as<crate::lower::model::Ex::XVar>(s_p1).a0;
                _v.set(std::optional(crate::emit::cpp::stmts::var_name(cp_p0, n_pc)));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::model::Ex::XRef>(s_p1)) {
                auto&& m4524_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s_p1).a0;
                if (prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m4524_1_0)))) {
                    auto&& n_pd = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m4524_1_0))).a0;
                    _v.set(std::optional(crate::emit::cpp::stmts::var_name(cp_p0, n_pd)));
                    goto _done;
                }
            }
            {
                _v.set(std::optional<Text>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subject_p9 = or_(bound_o8, Text::lit("_m"));
        auto bind_pa = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(bound_o8)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            if (prism_rtl::is_none(bound_o8)) {
                _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp_p0, s_p1), ";\n"));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arms_p2_1 = arms_p2;
        auto cp_p0_2 = cp_p0;
        auto s_p1_3 = s_p1;
        auto t_p7_4 = t_p7;
        call_value(each_job(arms_p2_1, ({
        auto cp_p0_2_5 = cp_p0_2;
        auto subject_p9_5 = subject_p9;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=, cp_p0_2_5 = std::move(cp_p0_2_5), subject_p9_5 = std::move(subject_p9_5)](crate::lower::model::XArm p0) {
        return ({
            auto cp_p0_2_5_6 = cp_p0_2_5;
            auto subject_p9_5_6 = subject_p9_5;
            entered(once_job([=, cp_p0_2_5_6 = std::move(cp_p0_2_5_6), subject_p9_5_6 = std::move(subject_p9_5_6)]() {
            return ({
                auto a_pe = p0;
                (prism_rtl::more(prism_rtl::rc(MatchArm(cp_p0_2_5_6, subject_p9_5_6, a_pe, false))));
            });
        }));
        });
    })));
    })), [=, bind_pa = std::move(bind_pa), t_p7_4 = std::move(t_p7_4)](Array<Text> each_4777) {
        return ({
            auto lines_pb = each_4777;
            call_then(crate::emit::cpp::start_cpp_type(cp_p0_2, t_p7_4), [=, lines_pb = std::move(lines_pb)](Text cpp_type_4839) { return prism_rtl::finished(crate::emit::cpp::templates::items::match_expr(cpp_type_4839, prism_rtl::cat(bind_pa, crate::syntax::lexer::chars::join(lines_pb, Text::lit("\n")), "\n", match_tail(arms_p2_1)))); });
        });
    });
    });
    });
    });
}


/// `Start CppMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_match(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex s_p1, Array<crate::lower::model::XArm> arms_p2, crate::lower::model::OutTy out_ty3) {
    return prism_rtl::make_rc<CppMatch>(cp_p0, s_p1, arms_p2, out_ty3);
}


/// ReturnMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
Text return_match(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& s_p1, const Array<crate::lower::model::XArm>& arms_p2, const crate::lower::model::OutTy& out_ty3) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(out_ty3)) {
        auto&& what_p3 = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(out_ty3).a0;
        return prism_rtl::cat("return ", ternary_match(cp_p0, s_p1, arms_p2), ";");
    }
    {
        auto&& t_p7 = out_ty3;
        auto bound_o8 = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(s_p1)) {
                auto&& n_pc = prism_rtl::as<crate::lower::model::Ex::XVar>(s_p1).a0;
                _v.set(std::optional(crate::emit::cpp::stmts::var_name(cp_p0, n_pc)));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::model::Ex::XRef>(s_p1)) {
                auto&& m5310_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s_p1).a0;
                if (prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m5310_1_0)))) {
                    auto&& n_pd = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m5310_1_0))).a0;
                    _v.set(std::optional(crate::emit::cpp::stmts::var_name(cp_p0, n_pd)));
                    goto _done;
                }
            }
            {
                _v.set(std::optional<Text>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subject_p9 = or_(bound_o8, Text::lit("_m"));
        auto bind_pa = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(bound_o8)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            if (prism_rtl::is_none(bound_o8)) {
                _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp_p0, s_p1), ";\n"));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto lines_pb = run_to_end(each_job(arms_p2, ({
            auto cp_p0_1 = cp_p0;
            auto subject_p9_2 = subject_p9;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1), subject_p9_2 = std::move(subject_p9_2)](crate::lower::model::XArm p0) {
            return ({
                auto cp_p0_1_3 = cp_p0_1;
                auto subject_p9_2_3 = subject_p9_2;
                entered(once_job([=, cp_p0_1_3 = std::move(cp_p0_1_3), subject_p9_2_3 = std::move(subject_p9_2_3)]() {
                return ({
                    auto a_pe = p0;
                    (prism_rtl::more(prism_rtl::rc(MatchArm(cp_p0_1_3, subject_p9_2_3, a_pe, true))));
                });
            }));
            });
        })));
        })));
        return prism_rtl::cat(bind_pa, crate::syntax::lexer::chars::join(lines_pb, Text::lit("\n")), "\n", match_tail(arms_p2));
    }
}


prism_rtl::Turn<Text> ReturnMatch::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& s_p1 = this->s_p1;
    const auto& arms_p2 = this->arms_p2;
    const auto& out_ty3 = this->out_ty3;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(out_ty3) ? ({
        auto&& what_p3 = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(out_ty3).a0;
        ({
        auto arms_p2_1 = arms_p2;
        auto cp_p0_2 = cp_p0;
        auto s_p1_3 = s_p1;
        call_then(start_ternary_match(cp_p0_2, s_p1_3, arms_p2_1), [=](Text ternary_match_5234) { return prism_rtl::finished(prism_rtl::cat("return ", ternary_match_5234, ";")); });
    });
    })
        : ({
        auto&& t_p7 = out_ty3;
        ({
        auto bound_o8 = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(s_p1)) {
                auto&& n_pc = prism_rtl::as<crate::lower::model::Ex::XVar>(s_p1).a0;
                _v.set(std::optional(crate::emit::cpp::stmts::var_name(cp_p0, n_pc)));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::model::Ex::XRef>(s_p1)) {
                auto&& m5310_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s_p1).a0;
                if (prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m5310_1_0)))) {
                    auto&& n_pd = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m5310_1_0))).a0;
                    _v.set(std::optional(crate::emit::cpp::stmts::var_name(cp_p0, n_pd)));
                    goto _done;
                }
            }
            {
                _v.set(std::optional<Text>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subject_p9 = or_(bound_o8, Text::lit("_m"));
        auto bind_pa = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(bound_o8)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            if (prism_rtl::is_none(bound_o8)) {
                _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp_p0, s_p1), ";\n"));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arms_p2_1 = arms_p2;
        auto cp_p0_2 = cp_p0;
        auto s_p1_3 = s_p1;
        call_value(each_job(arms_p2_1, ({
        auto cp_p0_2_4 = cp_p0_2;
        auto subject_p9_4 = subject_p9;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=, cp_p0_2_4 = std::move(cp_p0_2_4), subject_p9_4 = std::move(subject_p9_4)](crate::lower::model::XArm p0) {
        return ({
            auto cp_p0_2_4_5 = cp_p0_2_4;
            auto subject_p9_4_5 = subject_p9_4;
            entered(once_job([=, cp_p0_2_4_5 = std::move(cp_p0_2_4_5), subject_p9_4_5 = std::move(subject_p9_4_5)]() {
            return ({
                auto a_pe = p0;
                (prism_rtl::more(prism_rtl::rc(MatchArm(cp_p0_2_4_5, subject_p9_4_5, a_pe, true))));
            });
        }));
        });
    })));
    })), [=, bind_pa = std::move(bind_pa)](Array<Text> each_5563) {
        return ({
            auto lines_pb = each_5563;
            (prism_rtl::finished(prism_rtl::cat(bind_pa, crate::syntax::lexer::chars::join(lines_pb, Text::lit("\n")), "\n", match_tail(arms_p2_1))));
        });
    });
    });
    });
    });
}


/// `Start ReturnMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_return_match(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex s_p1, Array<crate::lower::model::XArm> arms_p2, crate::lower::model::OutTy out_ty3) {
    return prism_rtl::make_rc<ReturnMatch>(cp_p0, s_p1, arms_p2, out_ty3);
}


/// MatchTail: fn [XArm] -> Text
Text match_tail(const Array<crate::lower::model::XArm>& arms_p0) {
    auto ends_p1 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::syntax::lexer::chars::last(arms_p0);
        if (prism_rtl::is_some(_m)) {
            auto&& a_p2 = prism_rtl::some_of(_m);
            _v.set(is_catch_all(prism_rtl::deref(a_p2).pat) && (len(prism_rtl::deref(a_p2).conds) == Nat(0u)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return std::move(ends_p1)
        ? Text::lit("")
        : Text::lit("prism_rtl::unreachable(\"no arm matched\");\n");
}


/// TernaryMatch: unbounded fn Cp, Ex, [XArm] -> Text
Text ternary_match(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& s_p1, const Array<crate::lower::model::XArm>& arms_p2) {
    auto bound_o3 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        if (prism_rtl::is<crate::lower::model::Ex::XVar>(s_p1)) {
            auto&& n_p9 = prism_rtl::as<crate::lower::model::Ex::XVar>(s_p1).a0;
            _v.set(std::optional(crate::emit::cpp::stmts::var_name(cp_p0, n_p9)));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(s_p1)) {
            auto&& m6295_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s_p1).a0;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m6295_1_0)))) {
                auto&& n_pa = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m6295_1_0))).a0;
                _v.set(std::optional(crate::emit::cpp::stmts::var_name(cp_p0, n_pa)));
                goto _done;
            }
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto subject_p4 = or_(bound_o3, Text::lit("_m"));
    auto bind_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(bound_o3)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        if (prism_rtl::is_none(bound_o3)) {
            _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp_p0, s_p1), ";\n"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto reached_p6 = run_to_end(fold_job(arms_p2, std::tuple{Array<crate::lower::model::XArm>{}, false}, ({
        auto cp_p0_1 = cp_p0;
        auto subject_p4_2 = subject_p4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::XArm>, bool>>(std::tuple<std::tuple<Array<crate::lower::model::XArm>, bool>, crate::lower::model::XArm>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1), subject_p4_2 = std::move(subject_p4_2)](std::tuple<std::tuple<Array<crate::lower::model::XArm>, bool>, crate::lower::model::XArm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_p0_1_3 = cp_p0_1;
            auto subject_p4_2_3 = subject_p4_2;
            entered(once_job([=, cp_p0_1_3 = std::move(cp_p0_1_3), subject_p4_2_3 = std::move(subject_p4_2_3)]() {
            return ({
                auto [acc_pb, done_pc] = p0;
                auto a_pd = p1;
                done_pc
                ? prism_rtl::finished(std::tuple{acc_pb, done_pc})
                : call_then(start_pat_conds(cp_p0_1_3, prism_rtl::deref(a_pd).pat, subject_p4_2_3), [=](Array<Text> pat_conds_6734) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_pb, a_pd), (len(pat_conds_6734) == Nat(0u)) && (len(prism_rtl::deref(a_pd).conds) == Nat(0u))}); });
            });
        }));
        });
    }));
    })));
    auto [kept_pe, ends_pf] = reached_p6;
    auto parts_p7 = run_to_end(each_job(kept_pe, ({
        auto cp_p0_1 = cp_p0;
        auto subject_p4_2 = subject_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1), subject_p4_2 = std::move(subject_p4_2)](crate::lower::model::XArm p0) {
        return ({
            auto cp_p0_1_3 = cp_p0_1;
            auto subject_p4_2_3 = subject_p4_2;
            entered(once_job([=, cp_p0_1_3 = std::move(cp_p0_1_3), subject_p4_2_3 = std::move(subject_p4_2_3)]() {
            return ({
                auto a_pg = p0;
                (prism_rtl::more(prism_rtl::rc(TernaryArm(cp_p0_1_3, subject_p4_2_3, a_pg))));
            });
        }));
        });
    })));
    })));
    auto last_text_p8 = ends_pf
        ? Text::lit("")
        : Text::lit("\n    : throw prism_rtl::Panic(\"no arm matched\")");
    return crate::emit::cpp::templates::items::stmt_expr(prism_rtl::cat(bind_p5), prism_rtl::cat(crate::syntax::lexer::chars::join(parts_p7, Text::lit("\n    : ")), last_text_p8));
}


prism_rtl::Turn<Text> TernaryMatch::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& s_p1 = this->s_p1;
    const auto& arms_p2 = this->arms_p2;
    auto bound_o3 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        if (prism_rtl::is<crate::lower::model::Ex::XVar>(s_p1)) {
            auto&& n_p9 = prism_rtl::as<crate::lower::model::Ex::XVar>(s_p1).a0;
            _v.set(std::optional(crate::emit::cpp::stmts::var_name(cp_p0, n_p9)));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(s_p1)) {
            auto&& m6295_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s_p1).a0;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m6295_1_0)))) {
                auto&& n_pa = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m6295_1_0))).a0;
                _v.set(std::optional(crate::emit::cpp::stmts::var_name(cp_p0, n_pa)));
                goto _done;
            }
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto subject_p4 = or_(bound_o3, Text::lit("_m"));
    auto bind_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(bound_o3)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        if (prism_rtl::is_none(bound_o3)) {
            _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp_p0, s_p1), ";\n"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto arms_p2_1 = arms_p2;
    auto cp_p0_2 = cp_p0;
    return call_value(fold_job(arms_p2_1, std::tuple{Array<crate::lower::model::XArm>{}, false}, ({
        auto cp_p0_2_3 = cp_p0_2;
        auto subject_p4_3 = subject_p4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::XArm>, bool>>(std::tuple<std::tuple<Array<crate::lower::model::XArm>, bool>, crate::lower::model::XArm>)>>(prism_rtl::rc([=, cp_p0_2_3 = std::move(cp_p0_2_3), subject_p4_3 = std::move(subject_p4_3)](std::tuple<std::tuple<Array<crate::lower::model::XArm>, bool>, crate::lower::model::XArm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_p0_2_3_4 = cp_p0_2_3;
            auto subject_p4_3_4 = subject_p4_3;
            entered(once_job([=, cp_p0_2_3_4 = std::move(cp_p0_2_3_4), subject_p4_3_4 = std::move(subject_p4_3_4)]() {
            return ({
                auto [acc_pb, done_pc] = p0;
                auto a_pd = p1;
                done_pc
                ? prism_rtl::finished(std::tuple{acc_pb, done_pc})
                : call_then(start_pat_conds(cp_p0_2_3_4, prism_rtl::deref(a_pd).pat, subject_p4_3_4), [=](Array<Text> pat_conds_6734) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_pb, a_pd), (len(pat_conds_6734) == Nat(0u)) && (len(prism_rtl::deref(a_pd).conds) == Nat(0u))}); });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<crate::lower::model::XArm>, bool> fold_6634) {
        return ({
            auto reached_p6 = fold_6634;
            auto [kept_pe, ends_pf] = reached_p6;
            call_value(each_job(kept_pe, ({
            auto cp_p0_2_3 = cp_p0_2;
            auto subject_p4_3 = subject_p4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=, cp_p0_2_3 = std::move(cp_p0_2_3), subject_p4_3 = std::move(subject_p4_3)](crate::lower::model::XArm p0) {
            return ({
                auto cp_p0_2_3_4 = cp_p0_2_3;
                auto subject_p4_3_4 = subject_p4_3;
                entered(once_job([=, cp_p0_2_3_4 = std::move(cp_p0_2_3_4), subject_p4_3_4 = std::move(subject_p4_3_4)]() {
                return ({
                    auto a_pg = p0;
                    (prism_rtl::more(prism_rtl::rc(TernaryArm(cp_p0_2_3_4, subject_p4_3_4, a_pg))));
                });
            }));
            });
        })));
        })), [=](Array<Text> each_6843) {
            return ({
                auto parts_p7 = each_6843;
                auto last_text_p8 = ends_pf
                    ? Text::lit("")
                    : Text::lit("\n    : throw prism_rtl::Panic(\"no arm matched\")");
                (prism_rtl::finished(crate::emit::cpp::templates::items::stmt_expr(prism_rtl::cat(bind_p5), prism_rtl::cat(crate::syntax::lexer::chars::join(parts_p7, Text::lit("\n    : ")), last_text_p8))));
            });
        });
        });
    });
}


/// `Start TernaryMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ternary_match(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex s_p1, Array<crate::lower::model::XArm> arms_p2) {
    return prism_rtl::make_rc<TernaryMatch>(cp_p0, s_p1, arms_p2);
}


/// TernaryArm: unbounded fn Cp, Text, XArm -> Text
Text ternary_arm(const crate::emit::cpp::Cp& cp0_p0, const Text& subject_p1, const crate::lower::model::XArm& a_p2) {
    auto cp_p3 = crate::emit::cpp::stmts::unbind(cp0_p0, crate::emit::cpp::stmts::arm_names(a_p2));
    auto tests_p4 = pat_conds(cp_p3, a_p2.pat, subject_p1);
    auto binds_p5 = pat_binds(cp_p3, a_p2.pat, subject_p1);
    auto n_p6 = len(a_p2.conds);
    auto lets_p7 = concat2(run_to_end(each_job(crate::check::errors::range0(n_p6), ({
        auto cp_p3_1 = cp_p3;
        auto a_p2_2 = a_p2;
        auto n_p6_3 = n_p6;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p3_1 = std::move(cp_p3_1), a_p2_2 = std::move(a_p2_2), n_p6_3 = std::move(n_p6_3)](Nat p0) {
        return ({
            auto cp_p3_1_4 = cp_p3_1;
            auto a_p2_2_4 = a_p2_2;
            auto n_p6_3_4 = n_p6_3;
            entered(once_job([=, cp_p3_1_4 = std::move(cp_p3_1_4), a_p2_2_4 = std::move(a_p2_2_4), n_p6_3_4 = std::move(n_p6_3_4)]() {
            return ({
                auto i_pb = p0;
                (prism_rtl::more(prism_rtl::rc(CondBinds(cp_p3_1_4, or_(index(a_p2_2_4.conds, i_pb), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})), or_(n_p6_3_4.checked_sub(i_pb), Nat(0u))))));
            });
        }));
        });
    })));
    }))));
    auto value_p8 = (len(binds_p5) + len(lets_p7)) == Nat(0u)
        ? crate::emit::cpp::expr::cpp_expr(cp_p3, a_p2.body)
        : crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(append(binds_p5, lets_p7), Text::lit("\n")), crate::emit::cpp::expr::cpp_expr(cp_p3, a_p2.body));
    auto guard_p9 = len(a_p2.conds) == Nat(0u)
        ? Array<Text>{}
        : Array(std::vector{crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(binds_p5, Text::lit("\n")), guard_test(cp_p3, a_p2.conds))});
    auto all_pa = append(tests_p4, guard_p9);
    return len(all_pa) == Nat(0u)
        ? value_p8
        : prism_rtl::cat(conds(all_pa), " ? ", value_p8);
}


prism_rtl::Turn<Text> TernaryArm::cycle() const {
    const auto& cp0_p0 = this->cp0_p0;
    const auto& subject_p1 = this->subject_p1;
    const auto& a_p2 = this->a_p2;
    auto a_p2_1 = a_p2;
    auto cp0_p0_2 = cp0_p0;
    auto subject_p1_3 = subject_p1;
    return call_then(crate::emit::cpp::stmts::start_arm_names(a_p2_1), [=](Array<Text> arm_names_7141) {
        return ({
            auto cp_p3 = crate::emit::cpp::stmts::unbind(cp0_p0_2, arm_names_7141);
            call_then(start_pat_conds(cp_p3, prism_rtl::deref(a_p2_1).pat, subject_p1_3), [=](Array<Text> pat_conds_7169) {
            return ({
                auto tests_p4 = pat_conds_7169;
                call_then(start_pat_binds(cp_p3, prism_rtl::deref(a_p2_1).pat, subject_p1_3), [=, tests_p4 = std::move(tests_p4)](Array<Text> pat_binds_7213) {
                return ({
                    auto binds_p5 = pat_binds_7213;
                    auto n_p6 = len(prism_rtl::deref(a_p2_1).conds);
                    call_value(each_job(crate::check::errors::range0(n_p6), ({
                    auto cp_p3_4 = cp_p3;
                    auto a_p2_1_5 = a_p2_1;
                    auto n_p6_5 = n_p6;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p3_4 = std::move(cp_p3_4), a_p2_1_5 = std::move(a_p2_1_5), n_p6_5 = std::move(n_p6_5)](Nat p0) {
                    return ({
                        auto cp_p3_4_6 = cp_p3_4;
                        auto a_p2_1_5_6 = a_p2_1_5;
                        auto n_p6_5_6 = n_p6_5;
                        entered(once_job([=, cp_p3_4_6 = std::move(cp_p3_4_6), a_p2_1_5_6 = std::move(a_p2_1_5_6), n_p6_5_6 = std::move(n_p6_5_6)]() {
                        return ({
                            auto i_pb = p0;
                            (prism_rtl::more(prism_rtl::rc(CondBinds(cp_p3_4_6, or_(index(prism_rtl::deref(a_p2_1_5_6).conds, i_pb), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})), or_(n_p6_5_6.checked_sub(i_pb), Nat(0u))))));
                        });
                    }));
                    });
                })));
                })), [=, binds_p5 = std::move(binds_p5)](Array<Array<Text>> each_7289) {
                    return ({
                        auto lets_p7 = concat2(each_7289);
                        auto value_p8 = (len(binds_p5) + len(lets_p7)) == Nat(0u)
                            ? crate::emit::cpp::expr::cpp_expr(cp_p3, prism_rtl::deref(a_p2_1).body)
                            : crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(append(binds_p5, lets_p7), Text::lit("\n")), crate::emit::cpp::expr::cpp_expr(cp_p3, prism_rtl::deref(a_p2_1).body));
                        auto guard_p9 = len(prism_rtl::deref(a_p2_1).conds) == Nat(0u)
                            ? Array<Text>{}
                            : Array(std::vector{crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(binds_p5, Text::lit("\n")), guard_test(cp_p3, prism_rtl::deref(a_p2_1).conds))});
                        auto all_pa = append(tests_p4, guard_p9);
                        len(all_pa) == Nat(0u)
                        ? prism_rtl::finished(value_p8)
                        : prism_rtl::finished(prism_rtl::cat(conds(all_pa), " ? ", value_p8));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start TernaryArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ternary_arm(crate::emit::cpp::Cp cp0_p0, Text subject_p1, crate::lower::model::XArm a_p2) {
    return prism_rtl::make_rc<TernaryArm>(cp0_p0, subject_p1, a_p2);
}


/// CondBinds: unbounded fn Cp, Cc, Nat -> [Text]
Array<Text> cond_binds(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Cc& cc1, const Nat& k_p3) {
    if (prism_rtl::is<crate::lower::model::Cc::CcLet>(cc1)) {
        auto&& p_p1 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc1).a0;
        auto&& x_p2 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc1).a1;
        auto [v_p4, pre_p5] = cond_subject(cp_p0, x_p2, k_p3);
        return append(pre_p5, pat_binds(cp_p0, p_p1, v_p4));
    }
    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(cc1)) {
        auto&& x_p7 = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc1).a0;
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> CondBinds::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& cc1 = this->cc1;
    const auto& k_p3 = this->k_p3;
    return ({
        prism_rtl::is<crate::lower::model::Cc::CcLet>(cc1) ? ({
        auto&& p_p1 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc1).a0;
        auto&& x_p2 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc1).a1;
        ({
        auto cp_p0_1 = cp_p0;
        auto k_p3_2 = k_p3;
        auto p_p1_3 = p_p1;
        auto x_p2_4 = x_p2;
        call_then(start_cond_subject(cp_p0_1, x_p2_4, k_p3_2), [=, p_p1_3 = std::move(p_p1_3)](std::tuple<Text, Array<Text>> cond_subject_7818) {
        return ({
            auto [v_p4, pre_p5] = cond_subject_7818;
            call_then(start_pat_binds(cp_p0_1, p_p1_3, v_p4), [=](Array<Text> pat_binds_7856) { return prism_rtl::finished(append(pre_p5, pat_binds_7856)); });
        });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Cc::CcIf>(cc1) ? ({
        auto&& x_p7 = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc1).a0;
        prism_rtl::finished(Array<Text>{});
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cond_binds(crate::emit::cpp::Cp cp_p0, crate::lower::model::Cc cc1, Nat k_p3) {
    return prism_rtl::make_rc<CondBinds>(cp_p0, cc1, k_p3);
}


/// CondSubject: unbounded fn Cp, Ex, Nat -> ((Text, [Text]))
std::tuple<Text, Array<Text>> cond_subject(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& x_p1, const Nat& k_p2) {
    return is_place_ex(x_p1)
        ? std::tuple{crate::emit::cpp::expr::cpp_tight(cp_p0, x_p1), Array<Text>{}}
        : std::tuple{prism_rtl::cat("_c", k_p2), Array(std::vector{prism_rtl::cat("auto&& _c", k_p2, " = ", crate::emit::cpp::expr::cpp_expr(cp_p0, x_p1), ";")})};
}


prism_rtl::Turn<std::tuple<Text, Array<Text>>> CondSubject::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& x_p1 = this->x_p1;
    const auto& k_p2 = this->k_p2;
    return is_place_ex(x_p1)
        ? ({
        auto cp_p0_1 = cp_p0;
        auto x_p1_2 = x_p1;
        call_then(crate::emit::cpp::expr::start_cpp_tight(cp_p0_1, x_p1_2), [=](Text cpp_tight_8273) { return prism_rtl::finished(std::tuple{cpp_tight_8273, Array<Text>{}}); });
    })
        : ({
        auto cp_p0_1 = cp_p0;
        auto k_p2_2 = k_p2;
        auto x_p1_3 = x_p1;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0_1, x_p1_3), [=, k_p2_2 = std::move(k_p2_2)](Text cpp_expr_8333) { return prism_rtl::finished(std::tuple{prism_rtl::cat("_c", k_p2_2), Array(std::vector{prism_rtl::cat("auto&& _c", k_p2_2, " = ", cpp_expr_8333, ";")})}); });
    });
}


/// `Start CondSubject, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Array<Text>>> start_cond_subject(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex x_p1, Nat k_p2) {
    return prism_rtl::make_rc<CondSubject>(cp_p0, x_p1, k_p2);
}


/// IsPlaceEx: fn Ex -> Bool
bool is_place_ex(const crate::lower::model::Ex& x_p0) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x_p0)) {
        auto&& y_p1 = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a0;
        return is_place_ex(prism_rtl::deref(prism_rtl::deref(y_p1)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x_p0)) {
        auto&& y_p2 = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a0;
        return is_place_ex(prism_rtl::deref(prism_rtl::deref(y_p2)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XSelf>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x_p0)) {
        auto&& y_p3 = prism_rtl::as<crate::lower::model::Ex::XRef>(x_p0).a0;
        return is_place_ex(prism_rtl::deref(prism_rtl::deref(y_p3)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x_p0)) {
        auto&& y_p4 = prism_rtl::as<crate::lower::model::Ex::XDeref>(x_p0).a0;
        return is_place_ex(prism_rtl::deref(prism_rtl::deref(y_p4)));
    }
    {
        return false;
    }
}


/// GuardTest: unbounded fn Cp, [Cc] -> Text
Text guard_test(const crate::emit::cpp::Cp& cp_p0, const Array<crate::lower::model::Cc>& xs1) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return Text::lit("true");
        }
    }
    {
        auto&& cs_p2 = xs1;
        auto first_p3 = or_(index(cs_p2, Nat(0u)), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})}));
        auto rest_p4 = guard_test(cp_p0, drop(cs_p2, Nat(1u)));
        if (prism_rtl::is<crate::lower::model::Cc::CcIf>(first_p3)) {
            auto&& x_p5 = prism_rtl::as<crate::lower::model::Cc::CcIf>(first_p3).a0;
            return len(cs_p2) == Nat(1u)
                ? crate::emit::cpp::expr::cpp_tight(cp_p0, x_p5)
                : prism_rtl::cat(crate::emit::cpp::expr::cpp_tight(cp_p0, x_p5), " && ", rest_p4);
        }
        if (prism_rtl::is<crate::lower::model::Cc::CcLet>(first_p3)) {
            auto&& p_p6 = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_p3).a0;
            auto&& x_p7 = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_p3).a1;
            auto [v_pa, pre_pb] = cond_subject(cp_p0, x_p7, len(cs_p2));
            auto tests_p8 = conds(pat_conds(cp_p0, p_p6, v_pa));
            auto whole_p9 = len(cs_p2) == Nat(1u)
                ? tests_p8
                : prism_rtl::cat(tests_p8, " && ", crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(pat_binds(cp_p0, p_p6, v_pa), Text::lit("\n")), rest_p4));
            return len(pre_pb) == Nat(0u)
                ? whole_p9
                : crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(pre_pb, Text::lit("\n")), whole_p9);
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<Text> GuardTest::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& xs1 = this->xs1;
    return ({
        ({
        auto&& j0_1 = xs1;
        (j0_1.size() == 0u);
    }) ? ({
        auto&& j0_1 = xs1;
        prism_rtl::finished(Text::lit("true"));
    })
        : ({
        auto&& cs_p2 = xs1;
        ({
        auto first_p3 = or_(index(cs_p2, Nat(0u)), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})}));
        auto cp_p0_1 = cp_p0;
        auto cs_p2_2 = cs_p2;
        call_then(start_guard_test(cp_p0_1, drop(cs_p2_2, Nat(1u))), [=, first_p3 = std::move(first_p3)](Text guard_test_8837) {
        return ({
            auto rest_p4 = guard_test_8837;
            ({
            prism_rtl::is<crate::lower::model::Cc::CcIf>(first_p3) ? ({
            auto&& x_p5 = prism_rtl::as<crate::lower::model::Cc::CcIf>(first_p3).a0;
            len(cs_p2_2) == Nat(1u)
            ? prism_rtl::more(prism_rtl::rc(crate::emit::cpp::expr::CppTight(cp_p0_1, x_p5)))
            : ({
            auto x_p5_3 = x_p5;
            call_then(crate::emit::cpp::expr::start_cpp_tight(cp_p0_1, x_p5_3), [=](Text cpp_tight_8938) { return prism_rtl::finished(prism_rtl::cat(cpp_tight_8938, " && ", rest_p4)); });
        });
        })
            : prism_rtl::is<crate::lower::model::Cc::CcLet>(first_p3) ? ({
            auto&& p_p6 = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_p3).a0;
            auto&& x_p7 = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_p3).a1;
            ({
            auto p_p6_3 = p_p6;
            auto x_p7_4 = x_p7;
            call_then(start_cond_subject(cp_p0_1, x_p7_4, len(cs_p2_2)), [=, p_p6_3 = std::move(p_p6_3)](std::tuple<Text, Array<Text>> cond_subject_9014) {
            return ({
                auto [v_pa, pre_pb] = cond_subject_9014;
                call_then(start_pat_conds(cp_p0_1, p_p6_3, v_pa), [=](Array<Text> pat_conds_9073) {
                return ({
                    auto tests_p8 = conds(pat_conds_9073);
                    auto whole_p9 = len(cs_p2_2) == Nat(1u)
                        ? tests_p8
                        : prism_rtl::cat(tests_p8, " && ", crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(pat_binds(cp_p0_1, p_p6_3, v_pa), Text::lit("\n")), rest_p4));
                    len(pre_pb) == Nat(0u)
                    ? prism_rtl::finished(whole_p9)
                    : prism_rtl::finished(crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(pre_pb, Text::lit("\n")), whole_p9));
                });
            });
            });
        });
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    });
    });
    });
}


/// `Start GuardTest, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_guard_test(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Cc> xs1) {
    return prism_rtl::make_rc<GuardTest>(cp_p0, xs1);
}


/// MatchArm: unbounded fn Cp, Text, XArm, Bool -> Text
Text match_arm(const crate::emit::cpp::Cp& cp0_p0, const Text& subject_p1, const crate::lower::model::XArm& a_p2, const bool& returns_p3) {
    auto cp_p4 = crate::emit::cpp::stmts::unbind(cp0_p0, crate::emit::cpp::stmts::arm_names(a_p2));
    auto tests_p5 = pat_conds(cp_p4, a_p2.pat, subject_p1);
    auto binds_p6 = pat_binds(cp_p4, a_p2.pat, subject_p1);
    auto body_p7 = returns_p3
        ? crate::emit::cpp::stmts::cpp_body(cp_p4, a_p2.body)
        : leaves(a_p2.body)
        ? prism_rtl::cat(crate::emit::cpp::expr::cpp_expr(cp_p4, a_p2.body), ";")
        : prism_rtl::cat("_v.set(", crate::emit::cpp::expr::cpp_expr(cp_p4, a_p2.body), ");\ngoto _done;");
    auto guarded_p8 = len(a_p2.conds) == Nat(0u)
        ? body_p7
        : guarded_arm(cp_p4, a_p2.conds, body_p7);
    auto inner_p9 = crate::syntax::lexer::chars::join(append(binds_p6, Array(std::vector{guarded_p8})), Text::lit("\n"));
    return len(tests_p5) == Nat(0u)
        ? crate::emit::cpp::templates::items::braced(inner_p9)
        : crate::emit::cpp::templates::items::if_block(conds(tests_p5), inner_p9);
}


prism_rtl::Turn<Text> MatchArm::cycle() const {
    const auto& cp0_p0 = this->cp0_p0;
    const auto& subject_p1 = this->subject_p1;
    const auto& a_p2 = this->a_p2;
    const auto& returns_p3 = this->returns_p3;
    auto a_p2_1 = a_p2;
    auto cp0_p0_2 = cp0_p0;
    auto returns_p3_3 = prism_rtl::deref(returns_p3);
    auto subject_p1_4 = subject_p1;
    return call_then(crate::emit::cpp::stmts::start_arm_names(a_p2_1), [=](Array<Text> arm_names_9531) {
        return ({
            auto cp_p4 = crate::emit::cpp::stmts::unbind(cp0_p0_2, arm_names_9531);
            call_then(start_pat_conds(cp_p4, prism_rtl::deref(a_p2_1).pat, subject_p1_4), [=](Array<Text> pat_conds_9559) {
            return ({
                auto tests_p5 = pat_conds_9559;
                call_then(start_pat_binds(cp_p4, prism_rtl::deref(a_p2_1).pat, subject_p1_4), [=, tests_p5 = std::move(tests_p5)](Array<Text> pat_binds_9603) {
                return ({
                    auto binds_p6 = pat_binds_9603;
                    auto body_p7 = returns_p3_3
                        ? crate::emit::cpp::stmts::cpp_body(cp_p4, prism_rtl::deref(a_p2_1).body)
                        : leaves(prism_rtl::deref(a_p2_1).body)
                        ? prism_rtl::cat(crate::emit::cpp::expr::cpp_expr(cp_p4, prism_rtl::deref(a_p2_1).body), ";")
                        : prism_rtl::cat("_v.set(", crate::emit::cpp::expr::cpp_expr(cp_p4, prism_rtl::deref(a_p2_1).body), ");\ngoto _done;");
                    auto guarded_p8 = len(prism_rtl::deref(a_p2_1).conds) == Nat(0u)
                        ? body_p7
                        : guarded_arm(cp_p4, prism_rtl::deref(a_p2_1).conds, body_p7);
                    auto inner_p9 = crate::syntax::lexer::chars::join(append(binds_p6, Array(std::vector{guarded_p8})), Text::lit("\n"));
                    len(tests_p5) == Nat(0u)
                    ? prism_rtl::finished(crate::emit::cpp::templates::items::braced(inner_p9))
                    : prism_rtl::finished(crate::emit::cpp::templates::items::if_block(conds(tests_p5), inner_p9));
                });
            });
            });
        });
        });
    });
}


/// `Start MatchArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_match_arm(crate::emit::cpp::Cp cp0_p0, Text subject_p1, crate::lower::model::XArm a_p2, bool returns_p3) {
    return prism_rtl::make_rc<MatchArm>(cp0_p0, subject_p1, a_p2, returns_p3);
}


/// GuardedArm: unbounded fn Cp, [Cc], Text -> Text
Text guarded_arm(const crate::emit::cpp::Cp& cp_p0, const Array<crate::lower::model::Cc>& xs1, const Text& body_p1) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return body_p1;
        }
    }
    {
        auto&& cs_p3 = xs1;
        auto first_p5 = or_(index(cs_p3, Nat(0u)), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})}));
        auto rest_p6 = guarded_arm(cp_p0, drop(cs_p3, Nat(1u)), body_p1);
        if (prism_rtl::is<crate::lower::model::Cc::CcIf>(first_p5)) {
            auto&& x_p7 = prism_rtl::as<crate::lower::model::Cc::CcIf>(first_p5).a0;
            return crate::emit::cpp::templates::items::if_block(crate::emit::cpp::expr::cpp_expr(cp_p0, x_p7), rest_p6);
        }
        if (prism_rtl::is<crate::lower::model::Cc::CcLet>(first_p5)) {
            auto&& p_p8 = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_p5).a0;
            auto&& x_p9 = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_p5).a1;
            auto [v_pb, pre_pc] = cond_subject(cp_p0, x_p9, len(cs_p3));
            auto inner_pa = crate::emit::cpp::templates::items::if_block(conds(pat_conds(cp_p0, p_p8, v_pb)), crate::syntax::lexer::chars::join(append(pat_binds(cp_p0, p_p8, v_pb), Array(std::vector{rest_p6})), Text::lit("\n")));
            return len(pre_pc) == Nat(0u)
                ? inner_pa
                : crate::emit::cpp::templates::items::braced(crate::syntax::lexer::chars::join(crate::prelude::push(pre_pc, inner_pa), Text::lit("\n")));
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<Text> GuardedArm::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& xs1 = this->xs1;
    const auto& body_p1 = this->body_p1;
    return ({
        ({
        auto&& j0_1 = xs1;
        (j0_1.size() == 0u);
    }) ? ({
        auto&& j0_1 = xs1;
        prism_rtl::finished(body_p1);
    })
        : ({
        auto&& cs_p3 = xs1;
        ({
        auto first_p5 = or_(index(cs_p3, Nat(0u)), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})}));
        auto body_p1_1 = body_p1;
        auto cp_p0_2 = cp_p0;
        auto cs_p3_3 = cs_p3;
        call_then(start_guarded_arm(cp_p0_2, drop(cs_p3_3, Nat(1u)), body_p1_1), [=, first_p5 = std::move(first_p5)](Text guarded_arm_10240) {
        return ({
            auto rest_p6 = guarded_arm_10240;
            ({
            prism_rtl::is<crate::lower::model::Cc::CcIf>(first_p5) ? ({
            auto&& x_p7 = prism_rtl::as<crate::lower::model::Cc::CcIf>(first_p5).a0;
            ({
            auto x_p7_4 = x_p7;
            call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0_2, x_p7_4), [=](Text cpp_expr_10316) { return prism_rtl::finished(crate::emit::cpp::templates::items::if_block(cpp_expr_10316, rest_p6)); });
        });
        })
            : prism_rtl::is<crate::lower::model::Cc::CcLet>(first_p5) ? ({
            auto&& p_p8 = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_p5).a0;
            auto&& x_p9 = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_p5).a1;
            ({
            auto p_p8_4 = p_p8;
            auto x_p9_5 = x_p9;
            call_then(start_cond_subject(cp_p0_2, x_p9_5, len(cs_p3_3)), [=, p_p8_4 = std::move(p_p8_4)](std::tuple<Text, Array<Text>> cond_subject_10386) {
            return ({
                auto [v_pb, pre_pc] = cond_subject_10386;
                call_then(start_pat_conds(cp_p0_2, p_p8_4, v_pb), [=](Array<Text> pat_conds_10454) {
                return call_then(start_pat_binds(cp_p0_2, p_p8_4, v_pb), [=](Array<Text> pat_binds_10490) {
                    return ({
                        auto inner_pa = crate::emit::cpp::templates::items::if_block(conds(pat_conds_10454), crate::syntax::lexer::chars::join(append(pat_binds_10490, Array(std::vector{rest_p6})), Text::lit("\n")));
                        len(pre_pc) == Nat(0u)
                        ? prism_rtl::finished(inner_pa)
                        : prism_rtl::finished(crate::emit::cpp::templates::items::braced(crate::syntax::lexer::chars::join(crate::prelude::push(pre_pc, inner_pa), Text::lit("\n"))));
                    });
                });
            });
            });
        });
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    });
    });
    });
}


/// `Start GuardedArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_guarded_arm(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Cc> xs1, Text body_p1) {
    return prism_rtl::make_rc<GuardedArm>(cp_p0, xs1, body_p1);
}


/// CppLabeled: unbounded fn Cp, Text, [Do], Ex, OutTy -> Text
Text cpp_labeled(const crate::emit::cpp::Cp& cp_p0, const Text& label_p1, const Array<crate::lower::model::Do>& dos_p2, const crate::lower::model::Ex& e_p3, const crate::lower::model::OutTy& t_p4) {
    auto l_p5 = cpp_label(label_p1);
    auto last_p6 = leaves(e_p3)
        ? prism_rtl::cat(crate::emit::cpp::expr::cpp_expr(cp_p0, e_p3), ";")
        : prism_rtl::cat(l_p5, "_v.set(", crate::emit::cpp::expr::cpp_expr(cp_p0, e_p3), ");");
    return crate::emit::cpp::templates::items::labeled_expr(l_p5, crate::emit::cpp::cpp_type(cp_p0, t_p4), crate::syntax::lexer::chars::join(crate::prelude::push(run_to_end(each_job(dos_p2, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](crate::lower::model::Do p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto d_p7 = p0;
                (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::stmts::CppStatement(cp_p0_1_2, d_p7))));
            });
        }));
        });
    })));
    }))), last_p6), Text::lit("\n")));
}


prism_rtl::Turn<Text> CppLabeled::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& label_p1 = this->label_p1;
    const auto& dos_p2 = this->dos_p2;
    const auto& e_p3 = this->e_p3;
    const auto& t_p4 = this->t_p4;
    auto l_p5 = cpp_label(label_p1);
    auto last_p6 = leaves(e_p3)
        ? prism_rtl::cat(crate::emit::cpp::expr::cpp_expr(cp_p0, e_p3), ";")
        : prism_rtl::cat(l_p5, "_v.set(", crate::emit::cpp::expr::cpp_expr(cp_p0, e_p3), ");");
    auto cp_p0_1 = cp_p0;
    auto dos_p2_2 = dos_p2;
    auto t_p4_3 = t_p4;
    return call_then(crate::emit::cpp::start_cpp_type(cp_p0_1, t_p4_3), [=](Text cpp_type_10916) {
        return call_value(each_job(dos_p2_2, ({
            auto cp_p0_1_4 = cp_p0_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=, cp_p0_1_4 = std::move(cp_p0_1_4)](crate::lower::model::Do p0) {
            return ({
                auto cp_p0_1_4_4 = cp_p0_1_4;
                entered(once_job([=, cp_p0_1_4_4 = std::move(cp_p0_1_4_4)]() {
                return ({
                    auto d_p7 = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::stmts::CppStatement(cp_p0_1_4_4, d_p7))));
                });
            }));
            });
        })));
        })), [=](Array<Text> each_10945) { return prism_rtl::finished(crate::emit::cpp::templates::items::labeled_expr(l_p5, cpp_type_10916, crate::syntax::lexer::chars::join(crate::prelude::push(each_10945, last_p6), Text::lit("\n")))); });
    });
}


/// `Start CppLabeled, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_labeled(crate::emit::cpp::Cp cp_p0, Text label_p1, Array<crate::lower::model::Do> dos_p2, crate::lower::model::Ex e_p3, crate::lower::model::OutTy t_p4) {
    return prism_rtl::make_rc<CppLabeled>(cp_p0, label_p1, dos_p2, e_p3, t_p4);
}


/// CppLabel: fn Text -> Text
Text cpp_label(const Text& l_p0) {
    return crate::syntax::lexer::chars::has_prefix(l_p0, Text::lit("\'"))
        ? crate::syntax::lexer::chars::after_first(l_p0)
        : l_p0;
}


/// CppBreak: unbounded fn Cp, Text, Ex -> Text
Text cpp_break(const crate::emit::cpp::Cp& cp_p0, const Text& l_p1, const crate::lower::model::Ex& y_p2) {
    auto n_p3 = cpp_label(l_p1);
    return prism_rtl::cat("{ ", n_p3, "_v.set(", crate::emit::cpp::expr::cpp_expr(cp_p0, y_p2), "); goto ", n_p3, "; }");
}


prism_rtl::Turn<Text> CppBreak::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& l_p1 = this->l_p1;
    const auto& y_p2 = this->y_p2;
    auto n_p3 = cpp_label(l_p1);
    auto cp_p0_1 = cp_p0;
    auto y_p2_2 = y_p2;
    return call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0_1, y_p2_2), [=](Text cpp_expr_11190) { return prism_rtl::finished(prism_rtl::cat("{ ", n_p3, "_v.set(", cpp_expr_11190, "); goto ", n_p3, "; }")); });
}


/// `Start CppBreak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_break(crate::emit::cpp::Cp cp_p0, Text l_p1, crate::lower::model::Ex y_p2) {
    return prism_rtl::make_rc<CppBreak>(cp_p0, l_p1, y_p2);
}

}  // namespace crate::emit::cpp::patterns
