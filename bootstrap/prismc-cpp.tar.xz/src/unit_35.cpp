// The module `Emit.Cpp.Patterns`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/cpp/patterns/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Emit.Cpp.Patterns`, from `target/bootstrap/cpp-src/prismc/emit/cpp/patterns.prism`.
namespace crate::emit::cpp::patterns {

/// PatConds: unbounded fn Cp, Pa, Text -> [Text]
Array<Text> pat_conds_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Pa& p_p1, const Text& v_p2) {
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(p_p1)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p1)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p1)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p1)) {
        auto&& q_p3 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p1).a0;
        return pat_conds_f(cp_p0, prism_rtl::deref(prism_rtl::deref(q_p3)), v_p2);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_p1)) {
        auto&& c_p4 = prism_rtl::as<crate::lower::model::Pa::PaUnit>(p_p1).a0;
        return Array(std::vector{crate::emit::cpp::expr::case_test_f(cp_p0, c_p4, v_p2)});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_p1)) {
        auto&& c_p5 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p1).a0;
        auto&& ps_p6 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p1).a1;
        auto own_p7 = crate::emit::cpp::expr::case_test_f(cp_p0, c_p5, v_p2);
        auto inner_p8 = concat2_f(crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_p6)), ({
            auto cp_p0x = cp_p0;
            auto ps_p6x = ps_p6;
            auto c_p5x = c_p5;
            auto v_p2x = v_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), ps_p6x = std::move(ps_p6x), c_p5x = std::move(c_p5x), v_p2x = std::move(v_p2x)](Nat p0) {
            return ({
                auto cp_p0xy = cp_p0x;
                auto ps_p6xy = ps_p6x;
                auto c_p5xy = c_p5x;
                auto v_p2xy = v_p2x;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), ps_p6xy = std::move(ps_p6xy), c_p5xy = std::move(c_p5xy), v_p2xy = std::move(v_p2xy)]() {
                return ({
                    auto i_p9 = p0;
                    (prism_rtl::more(prism_rtl::rc(PatConds(cp_p0xy, crate::prelude::or_(crate::prelude::index(ps_p6xy, i_p9), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), crate::emit::cpp::expr::payload_f(cp_p0xy, c_p5xy, v_p2xy, i_p9)))));
                });
            })));
            });
        })));
        }))));
        return crate::prelude::filter(crate::prelude::append(Array(std::vector{own_p7}), inner_p8), [&](const Text& t_pa) { return t_pa != Text::lit("true"); });
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_p1)) {
        auto&& c_pb = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p1).a0;
        auto&& fs_pc = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p1).a1;
        return concat2_f(crate::prelude::run_to_end(crate::prelude::each_job(fs_pc, ({
            auto cp_p0x = cp_p0;
            auto v_p2x = v_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), v_p2x = std::move(v_p2x)](std::tuple<Text, crate::lower::model::Pa> p0) {
            return ({
                auto cp_p0xy = cp_p0x;
                auto v_p2xy = v_p2x;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), v_p2xy = std::move(v_p2xy)]() {
                return ({
                    auto [f_pd, q_pe] = p0;
                    (prism_rtl::more(prism_rtl::rc(PatConds(cp_p0xy, q_pe, prism_rtl::cat(v_p2xy, ".", crate::emit::cpp::field_id_f(f_pd))))));
                });
            })));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p1)) {
        auto&& ps_pf = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p1).a0;
        return concat2_f(crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_pf)), ({
            auto cp_p0x = cp_p0;
            auto ps_pfx = ps_pf;
            auto v_p2x = v_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), ps_pfx = std::move(ps_pfx), v_p2x = std::move(v_p2x)](Nat p0) {
            return ({
                auto cp_p0xy = cp_p0x;
                auto ps_pfxy = ps_pfx;
                auto v_p2xy = v_p2x;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), ps_pfxy = std::move(ps_pfxy), v_p2xy = std::move(v_p2xy)]() {
                return ({
                    auto i_pg = p0;
                    (prism_rtl::more(prism_rtl::rc(PatConds(cp_p0xy, crate::prelude::or_(crate::prelude::index(ps_pfxy, i_pg), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat("std::get<", i_pg, ">(", v_p2xy, ")")))));
                });
            })));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaChar>(p_p1)) {
        auto&& c_ph = prism_rtl::as<crate::lower::model::Pa::PaChar>(p_p1).a0;
        return Array(std::vector{prism_rtl::cat(v_p2, " == U\'", crate::emit::cpp::expr::cpp_char_escape_f(c_ph), "\'")});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBool>(p_p1)) {
        auto&& b_pi = prism_rtl::as<crate::lower::model::Pa::PaBool>(p_p1).a0;
        return Array(std::vector{prism_rtl::deref(b_pi) ? v_p2 : prism_rtl::cat("!", v_p2)});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaIndex>(p_p1)) {
        auto&& n_pj = prism_rtl::as<crate::lower::model::Pa::PaIndex>(p_p1).a0;
        return Array(std::vector{prism_rtl::cat(v_p2, " == ", n_pj, "u")});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaConst>(p_p1)) {
        auto&& n_pk = prism_rtl::as<crate::lower::model::Pa::PaConst>(p_p1).a0;
        return Array(std::vector{prism_rtl::cat(v_p2, " == ", n_pk)});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_p1)) {
        auto&& ps_pl = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_p1).a0;
        auto rest_pm = crate::prelude::fold(ps_pl, false, [&](const bool& f_pp, const crate::lower::model::Pa& q_pq) { return prism_rtl::deref(f_pp) || is_rest_f(q_pq); });
        auto fixed_pn = crate::prelude::len(crate::prelude::filter(ps_pl, [&](const crate::lower::model::Pa& q_pr) { return !is_rest_f(q_pr); }));
        auto size_po = std::move(rest_pm)
            ? prism_rtl::cat(v_p2, ".size() >= ", fixed_pn)
            : prism_rtl::cat(v_p2, ".size() == ", fixed_pn);
        return crate::prelude::append(Array(std::vector{size_po}), concat2_f(crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_pl)), ({
            auto cp_p0x = cp_p0;
            auto ps_plx = ps_pl;
            auto v_p2x = v_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), ps_plx = std::move(ps_plx), v_p2x = std::move(v_p2x)](Nat p0) {
            return ({
                auto cp_p0xy = cp_p0x;
                auto ps_plxy = ps_plx;
                auto v_p2xy = v_p2x;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), ps_plxy = std::move(ps_plxy), v_p2xy = std::move(v_p2xy)]() {
                return ({
                    auto i_ps = p0;
                    (prism_rtl::more(prism_rtl::rc(PatConds(cp_p0xy, crate::prelude::or_(crate::prelude::index(ps_plxy, i_ps), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat(v_p2xy, "[", i_ps, "]")))));
                });
            })));
            });
        })));
        })))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(p_p1)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> PatConds::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& p_p1 = this->p_p1;
    const auto& v_p2 = this->v_p2;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaWild>(p_p1) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p1) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p1) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p1) ? ({
        auto&& q_p3 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p1).a0;
        prism_rtl::more(prism_rtl::rc(PatConds(cp_p0, prism_rtl::deref(prism_rtl::deref(q_p3)), v_p2)));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_p1) ? ({
        auto&& c_p4 = prism_rtl::as<crate::lower::model::Pa::PaUnit>(p_p1).a0;
        prism_rtl::finished(Array(std::vector{crate::emit::cpp::expr::case_test_f(cp_p0, c_p4, v_p2)}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_p1) ? ({
        auto&& c_p5 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p1).a0;
        auto&& ps_p6 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p1).a1;
        ({
        auto own_p7 = crate::emit::cpp::expr::case_test_f(cp_p0, c_p5, v_p2);
        auto c_p5x = c_p5;
        auto cp_p0x = cp_p0;
        auto ps_p6x = ps_p6;
        auto v_p2x = v_p2;
        (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_p6x)), ({
        auto cp_p0xx = cp_p0x;
        auto ps_p6xx = ps_p6x;
        auto c_p5xx = c_p5x;
        auto v_p2xx = v_p2x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx), ps_p6xx = std::move(ps_p6xx), c_p5xx = std::move(c_p5xx), v_p2xx = std::move(v_p2xx)](Nat p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            auto ps_p6xxy = ps_p6xx;
            auto c_p5xxy = c_p5xx;
            auto v_p2xxy = v_p2xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy), ps_p6xxy = std::move(ps_p6xxy), c_p5xxy = std::move(c_p5xxy), v_p2xxy = std::move(v_p2xxy)]() {
            return ({
                auto i_p9 = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_p0xxy, crate::prelude::or_(crate::prelude::index(ps_p6xxy, i_p9), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), crate::emit::cpp::expr::payload_f(cp_p0xxy, c_p5xxy, v_p2xxy, i_p9)))));
            });
        })));
        });
    })));
    })), [=, own_p7 = std::move(own_p7)](Array<Array<Text>> each_1488) {
        return ({
            auto inner_p8 = concat2_f(each_1488);
            (prism_rtl::finished(crate::prelude::filter(crate::prelude::append(Array(std::vector{own_p7}), inner_p8), [&](const Text& t_pa) { return t_pa != Text::lit("true"); })));
        });
    }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_p1) ? ({
        auto&& c_pb = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p1).a0;
        auto&& fs_pc = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p1).a1;
        ({
        auto cp_p0x = cp_p0;
        auto fs_pcx = fs_pc;
        auto v_p2x = v_p2;
        (crate::prelude::call_value(crate::prelude::each_job(fs_pcx, ({
        auto cp_p0xx = cp_p0x;
        auto v_p2xx = v_p2x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx), v_p2xx = std::move(v_p2xx)](std::tuple<Text, crate::lower::model::Pa> p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            auto v_p2xxy = v_p2xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy), v_p2xxy = std::move(v_p2xxy)]() {
            return ({
                auto [f_pd, q_pe] = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_p0xxy, q_pe, prism_rtl::cat(v_p2xxy, ".", crate::emit::cpp::field_id_f(f_pd))))));
            });
        })));
        });
    })));
    })), [=](Array<Array<Text>> each_1667) { return prism_rtl::finished(concat2_f(each_1667)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p1) ? ({
        auto&& ps_pf = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto ps_pfx = ps_pf;
        auto v_p2x = v_p2;
        (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_pfx)), ({
        auto cp_p0xx = cp_p0x;
        auto ps_pfxx = ps_pfx;
        auto v_p2xx = v_p2x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx), ps_pfxx = std::move(ps_pfxx), v_p2xx = std::move(v_p2xx)](Nat p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            auto ps_pfxxy = ps_pfxx;
            auto v_p2xxy = v_p2xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy), ps_pfxxy = std::move(ps_pfxxy), v_p2xxy = std::move(v_p2xxy)]() {
            return ({
                auto i_pg = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_p0xxy, crate::prelude::or_(crate::prelude::index(ps_pfxxy, i_pg), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat("std::get<", i_pg, ">(", v_p2xxy, ")")))));
            });
        })));
        });
    })));
    })), [=](Array<Array<Text>> each_1748) { return prism_rtl::finished(concat2_f(each_1748)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaChar>(p_p1) ? ({
        auto&& c_ph = prism_rtl::as<crate::lower::model::Pa::PaChar>(p_p1).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat(v_p2, " == U\'", crate::emit::cpp::expr::cpp_char_escape_f(c_ph), "\'")}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaBool>(p_p1) ? ({
        auto&& b_pi = prism_rtl::as<crate::lower::model::Pa::PaBool>(p_p1).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::deref(b_pi) ? v_p2 : prism_rtl::cat("!", v_p2)}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaIndex>(p_p1) ? ({
        auto&& n_pj = prism_rtl::as<crate::lower::model::Pa::PaIndex>(p_p1).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat(v_p2, " == ", n_pj, "u")}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaConst>(p_p1) ? ({
        auto&& n_pk = prism_rtl::as<crate::lower::model::Pa::PaConst>(p_p1).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat(v_p2, " == ", n_pk)}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_p1) ? ({
        auto&& ps_pl = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_p1).a0;
        ({
        auto rest_pm = crate::prelude::fold(ps_pl, false, [&](const bool& f_pp, const crate::lower::model::Pa& q_pq) { return prism_rtl::deref(f_pp) || is_rest_f(q_pq); });
        auto fixed_pn = crate::prelude::len(crate::prelude::filter(ps_pl, [&](const crate::lower::model::Pa& q_pr) { return !is_rest_f(q_pr); }));
        auto size_po = std::move(rest_pm)
            ? prism_rtl::cat(v_p2, ".size() >= ", fixed_pn)
            : prism_rtl::cat(v_p2, ".size() == ", fixed_pn);
        auto cp_p0x = cp_p0;
        auto ps_plx = ps_pl;
        auto v_p2x = v_p2;
        (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_plx)), ({
        auto cp_p0xx = cp_p0x;
        auto ps_plxx = ps_plx;
        auto v_p2xx = v_p2x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx), ps_plxx = std::move(ps_plxx), v_p2xx = std::move(v_p2xx)](Nat p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            auto ps_plxxy = ps_plxx;
            auto v_p2xxy = v_p2xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy), ps_plxxy = std::move(ps_plxxy), v_p2xxy = std::move(v_p2xxy)]() {
            return ({
                auto i_ps = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_p0xxy, crate::prelude::or_(crate::prelude::index(ps_plxxy, i_ps), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat(v_p2xxy, "[", i_ps, "]")))));
            });
        })));
        });
    })));
    })), [=, size_po = std::move(size_po)](Array<Array<Text>> each_2231) { return prism_rtl::finished(crate::prelude::append(Array(std::vector{size_po}), concat2_f(each_2231))); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRest>(p_p1) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start PatConds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_pat_conds_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Pa p_p1, Text v_p2) {
    return prism_rtl::make_rc<PatConds>(cp_p0, p_p1, v_p2);
}


/// PatBinds: unbounded fn Cp, Pa, Text -> [Text]
Array<Text> pat_binds_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Pa& p_p1, const Text& v_p2) {
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(p_p1)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p1)) {
        auto&& n_p3 = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_p1).a0;
        return Array(std::vector{prism_rtl::cat("auto&& ", crate::emit::cpp::cpp_id_f(n_p3), " = ", v_p2, ";")});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p1)) {
        auto&& n_p4 = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_p1).a0;
        return Array(std::vector{prism_rtl::cat("auto ", crate::emit::cpp::cpp_id_f(n_p4), " = ", v_p2, ";")});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p1)) {
        auto&& m2400_3_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p1).a0;
        auto&& t_p6 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p1).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(m2400_3_0)))) {
            auto&& n_p5 = prism_rtl::as<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(m2400_3_0))).a0;
            return Array(std::vector{prism_rtl::cat(crate::emit::cpp::cpp_type_f(cp_p0, crate::emit::cpp::expr::unref_f(t_p6)), " ", crate::emit::cpp::cpp_id_f(n_p5), " = ", v_p2, ";")});
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p1)) {
        auto&& q_p7 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p1).a0;
        return pat_binds_f(cp_p0, prism_rtl::deref(prism_rtl::deref(q_p7)), v_p2);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_p1)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_p1)) {
        auto&& c_p8 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p1).a0;
        auto&& ps_p9 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p1).a1;
        return concat2_f(crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_p9)), ({
            auto cp_p0x = cp_p0;
            auto ps_p9x = ps_p9;
            auto c_p8x = c_p8;
            auto v_p2x = v_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), ps_p9x = std::move(ps_p9x), c_p8x = std::move(c_p8x), v_p2x = std::move(v_p2x)](Nat p0) {
            return ({
                auto cp_p0xy = cp_p0x;
                auto ps_p9xy = ps_p9x;
                auto c_p8xy = c_p8x;
                auto v_p2xy = v_p2x;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), ps_p9xy = std::move(ps_p9xy), c_p8xy = std::move(c_p8xy), v_p2xy = std::move(v_p2xy)]() {
                return ({
                    auto i_pa = p0;
                    (prism_rtl::more(prism_rtl::rc(PatBinds(cp_p0xy, crate::prelude::or_(crate::prelude::index(ps_p9xy, i_pa), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), crate::emit::cpp::expr::payload_f(cp_p0xy, c_p8xy, v_p2xy, i_pa)))));
                });
            })));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_p1)) {
        auto&& c_pb = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p1).a0;
        auto&& fs_pc = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p1).a1;
        return concat2_f(crate::prelude::run_to_end(crate::prelude::each_job(fs_pc, ({
            auto cp_p0x = cp_p0;
            auto v_p2x = v_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), v_p2x = std::move(v_p2x)](std::tuple<Text, crate::lower::model::Pa> p0) {
            return ({
                auto cp_p0xy = cp_p0x;
                auto v_p2xy = v_p2x;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), v_p2xy = std::move(v_p2xy)]() {
                return ({
                    auto [f_pd, q_pe] = p0;
                    (prism_rtl::more(prism_rtl::rc(PatBinds(cp_p0xy, q_pe, prism_rtl::cat(v_p2xy, ".", crate::emit::cpp::field_id_f(f_pd))))));
                });
            })));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p1)) {
        auto&& ps_pf = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p1).a0;
        return concat2_f(crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_pf)), ({
            auto cp_p0x = cp_p0;
            auto ps_pfx = ps_pf;
            auto v_p2x = v_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), ps_pfx = std::move(ps_pfx), v_p2x = std::move(v_p2x)](Nat p0) {
            return ({
                auto cp_p0xy = cp_p0x;
                auto ps_pfxy = ps_pfx;
                auto v_p2xy = v_p2x;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), ps_pfxy = std::move(ps_pfxy), v_p2xy = std::move(v_p2xy)]() {
                return ({
                    auto i_pg = p0;
                    (prism_rtl::more(prism_rtl::rc(PatBinds(cp_p0xy, crate::prelude::or_(crate::prelude::index(ps_pfxy, i_pg), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat("std::get<", i_pg, ">(", v_p2xy, ")")))));
                });
            })));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_p1)) {
        auto&& ps_ph = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_p1).a0;
        return concat2_f(crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_ph)), ({
            auto cp_p0x = cp_p0;
            auto ps_phx = ps_ph;
            auto v_p2x = v_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), ps_phx = std::move(ps_phx), v_p2x = std::move(v_p2x)](Nat p0) {
            return ({
                auto cp_p0xy = cp_p0x;
                auto ps_phxy = ps_phx;
                auto v_p2xy = v_p2x;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), ps_phxy = std::move(ps_phxy), v_p2xy = std::move(v_p2xy)]() {
                return ({
                    auto i_pi = p0;
                    (prism_rtl::more(prism_rtl::rc(SliceBinds(cp_p0xy, crate::prelude::or_(crate::prelude::index(ps_phxy, i_pi), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), v_p2xy, i_pi))));
                });
            })));
            });
        })));
        }))));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> PatBinds::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& p_p1 = this->p_p1;
    const auto& v_p2 = this->v_p2;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaWild>(p_p1) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p1) ? ({
        auto&& n_p3 = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_p1).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat("auto&& ", crate::emit::cpp::cpp_id_f(n_p3), " = ", v_p2, ";")}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p1) ? ({
        auto&& n_p4 = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_p1).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat("auto ", crate::emit::cpp::cpp_id_f(n_p4), " = ", v_p2, ";")}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p1) && ({
        auto&& m2400_3_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p1).a0;
        auto&& t_p6 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p1).a1;
        prism_rtl::is<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(m2400_3_0)));
    }) ? ({
        auto&& m2400_3_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p1).a0;
        auto&& t_p6 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p1).a1;
        auto&& n_p5 = prism_rtl::as<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(m2400_3_0))).a0;
        ({
        auto cp_p0x = cp_p0;
        auto n_p5x = n_p5;
        auto t_p6x = t_p6;
        auto v_p2x = v_p2;
        (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, crate::emit::cpp::expr::unref_f(t_p6x)), [=, n_p5x = std::move(n_p5x), v_p2x = std::move(v_p2x)](Text cpp_type_f_2542) { return prism_rtl::finished(Array(std::vector{prism_rtl::cat(cpp_type_f_2542, " ", crate::emit::cpp::cpp_id_f(n_p5x), " = ", v_p2x, ";")})); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p1) ? ({
        auto&& q_p7 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p1).a0;
        prism_rtl::more(prism_rtl::rc(PatBinds(cp_p0, prism_rtl::deref(prism_rtl::deref(q_p7)), v_p2)));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_p1) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_p1) ? ({
        auto&& c_p8 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p1).a0;
        auto&& ps_p9 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p1).a1;
        ({
        auto c_p8x = c_p8;
        auto cp_p0x = cp_p0;
        auto ps_p9x = ps_p9;
        auto v_p2x = v_p2;
        (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_p9x)), ({
        auto cp_p0xx = cp_p0x;
        auto ps_p9xx = ps_p9x;
        auto c_p8xx = c_p8x;
        auto v_p2xx = v_p2x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx), ps_p9xx = std::move(ps_p9xx), c_p8xx = std::move(c_p8xx), v_p2xx = std::move(v_p2xx)](Nat p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            auto ps_p9xxy = ps_p9xx;
            auto c_p8xxy = c_p8xx;
            auto v_p2xxy = v_p2xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy), ps_p9xxy = std::move(ps_p9xxy), c_p8xxy = std::move(c_p8xxy), v_p2xxy = std::move(v_p2xxy)]() {
            return ({
                auto i_pa = p0;
                (prism_rtl::more(prism_rtl::rc(PatBinds(cp_p0xxy, crate::prelude::or_(crate::prelude::index(ps_p9xxy, i_pa), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), crate::emit::cpp::expr::payload_f(cp_p0xxy, c_p8xxy, v_p2xxy, i_pa)))));
            });
        })));
        });
    })));
    })), [=](Array<Array<Text>> each_2677) { return prism_rtl::finished(concat2_f(each_2677)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_p1) ? ({
        auto&& c_pb = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p1).a0;
        auto&& fs_pc = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p1).a1;
        ({
        auto cp_p0x = cp_p0;
        auto fs_pcx = fs_pc;
        auto v_p2x = v_p2;
        (crate::prelude::call_value(crate::prelude::each_job(fs_pcx, ({
        auto cp_p0xx = cp_p0x;
        auto v_p2xx = v_p2x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx), v_p2xx = std::move(v_p2xx)](std::tuple<Text, crate::lower::model::Pa> p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            auto v_p2xxy = v_p2xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy), v_p2xxy = std::move(v_p2xxy)]() {
            return ({
                auto [f_pd, q_pe] = p0;
                (prism_rtl::more(prism_rtl::rc(PatBinds(cp_p0xxy, q_pe, prism_rtl::cat(v_p2xxy, ".", crate::emit::cpp::field_id_f(f_pd))))));
            });
        })));
        });
    })));
    })), [=](Array<Array<Text>> each_2799) { return prism_rtl::finished(concat2_f(each_2799)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p1) ? ({
        auto&& ps_pf = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto ps_pfx = ps_pf;
        auto v_p2x = v_p2;
        (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_pfx)), ({
        auto cp_p0xx = cp_p0x;
        auto ps_pfxx = ps_pfx;
        auto v_p2xx = v_p2x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx), ps_pfxx = std::move(ps_pfxx), v_p2xx = std::move(v_p2xx)](Nat p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            auto ps_pfxxy = ps_pfxx;
            auto v_p2xxy = v_p2xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy), ps_pfxxy = std::move(ps_pfxxy), v_p2xxy = std::move(v_p2xxy)]() {
            return ({
                auto i_pg = p0;
                (prism_rtl::more(prism_rtl::rc(PatBinds(cp_p0xxy, crate::prelude::or_(crate::prelude::index(ps_pfxxy, i_pg), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat("std::get<", i_pg, ">(", v_p2xxy, ")")))));
            });
        })));
        });
    })));
    })), [=](Array<Array<Text>> each_2880) { return prism_rtl::finished(concat2_f(each_2880)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_p1) ? ({
        auto&& ps_ph = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto ps_phx = ps_ph;
        auto v_p2x = v_p2;
        (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_phx)), ({
        auto cp_p0xx = cp_p0x;
        auto ps_phxx = ps_phx;
        auto v_p2xx = v_p2x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx), ps_phxx = std::move(ps_phxx), v_p2xx = std::move(v_p2xx)](Nat p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            auto ps_phxxy = ps_phxx;
            auto v_p2xxy = v_p2xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy), ps_phxxy = std::move(ps_phxxy), v_p2xxy = std::move(v_p2xxy)]() {
            return ({
                auto i_pi = p0;
                (prism_rtl::more(prism_rtl::rc(SliceBinds(cp_p0xxy, crate::prelude::or_(crate::prelude::index(ps_phxxy, i_pi), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), v_p2xxy, i_pi))));
            });
        })));
        });
    })));
    })), [=](Array<Array<Text>> each_2989) { return prism_rtl::finished(concat2_f(each_2989)); }));
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start PatBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_pat_binds_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Pa p_p1, Text v_p2) {
    return prism_rtl::make_rc<PatBinds>(cp_p0, p_p1, v_p2);
}


/// SliceBinds: unbounded fn Cp, Pa, Text, Nat -> [Text]
Array<Text> slice_binds_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Pa& pa1, const Text& v_p1, const Nat& i_p2) {
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(pa1)) {
        auto&& c0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaRest>(pa1).a0;
        if (c0_1_0 == Text::lit("")) {
            return Array<Text>{};
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(pa1)) {
        auto&& n_p4 = prism_rtl::as<crate::lower::model::Pa::PaRest>(pa1).a0;
        return Array(std::vector{prism_rtl::cat("auto ", crate::emit::cpp::cpp_id_f(n_p4), " = ", v_p1, ".subspan(", i_p2, ");")});
    }
    {
        auto&& p_p8 = pa1;
        return pat_binds_f(cp_p0, p_p8, prism_rtl::cat(v_p1, "[", i_p2, "]"));
    }
}


prism_rtl::Turn<Array<Text>> SliceBinds::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& pa1 = this->pa1;
    const auto& v_p1 = this->v_p1;
    const auto& i_p2 = this->i_p2;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaRest>(pa1) && ({
        auto&& j0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaRest>(pa1).a0;
        (j0_1_0 == Text::lit(""));
    }) ? ({
        auto&& j0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaRest>(pa1).a0;
        prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRest>(pa1) ? ({
        auto&& n_p4 = prism_rtl::as<crate::lower::model::Pa::PaRest>(pa1).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat("auto ", crate::emit::cpp::cpp_id_f(n_p4), " = ", v_p1, ".subspan(", i_p2, ");")}));
    })
        : ({
        auto&& p_p8 = pa1;
        prism_rtl::more(prism_rtl::rc(PatBinds(cp_p0, p_p8, prism_rtl::cat(v_p1, "[", i_p2, "]"))));
    });
    });
}


/// `Start SliceBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_slice_binds_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Pa pa1, Text v_p1, Nat i_p2) {
    return prism_rtl::make_rc<SliceBinds>(cp_p0, pa1, v_p1, i_p2);
}


/// IsRest: fn Pa -> Bool
bool is_rest_f(const crate::lower::model::Pa& pa0) {
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(pa0)) {
        return true;
    }
    {
        auto&& other_p0 = pa0;
        return false;
    }
}


/// Concat2: fn [ [Text] ] -> [Text]
Array<Text> concat2_f(const Array<Array<Text>>& xss_p0) {
    return crate::prelude::fold(xss_p0, Array<Text>{}, [&](const Array<Text>& acc_p1, const Array<Text>& xs_p2) { return crate::prelude::append(acc_p1, xs_p2); });
}


/// Conds: fn [Text] -> Text
Text conds_f(const Array<Text>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("true");
        }
    }
    {
        auto&& cs_p0 = xs0;
        return crate::syntax::lexer::chars::join_f(cs_p0, Text::lit(" && "));
    }
}


/// IsCatchAll: fn Pa -> Bool
bool is_catch_all_f(const crate::lower::model::Pa& p_p0) {
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(p_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p0)) {
        auto&& q_p1 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p0).a0;
        return is_catch_all_f(prism_rtl::deref(prism_rtl::deref(q_p1)));
    }
    {
        return false;
    }
}


/// Leaves: fn Ex -> Bool
bool leaves_f(const crate::lower::model::Ex& x_p0) {
    if (prism_rtl::is<crate::lower::model::Ex::XBreak>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnreachable>(x_p0)) {
        return true;
    }
    {
        return false;
    }
}


/// CppMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
Text cpp_match_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& s_p1, const Array<crate::lower::model::XArm>& arms_p2, const crate::lower::model::OutTy& out_ty3) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutTurn>(out_ty3)) {
        return ternary_match_f(cp_p0, s_p1, arms_p2);
    }
    {
        auto&& t_p6 = out_ty3;
        auto bound_o7 = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(s_p1)) {
                auto&& n_pb = prism_rtl::as<crate::lower::model::Ex::XVar>(s_p1).a0;
                _v.set(std::optional(crate::emit::cpp::stmts::var_name_f(cp_p0, n_pb)));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::model::Ex::XRef>(s_p1)) {
                auto&& m4514_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s_p1).a0;
                if (prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m4514_1_0)))) {
                    auto&& n_pc = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m4514_1_0))).a0;
                    _v.set(std::optional(crate::emit::cpp::stmts::var_name_f(cp_p0, n_pc)));
                    goto _done;
                }
            }
            {
                _v.set(std::optional<Text>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subject_p8 = crate::prelude::or_(bound_o7, Text::lit("_m"));
        auto bind_p9 = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(bound_o7)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            if (prism_rtl::is_none(bound_o7)) {
                _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr_f(cp_p0, s_p1), ";\n"));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto lines_pa = crate::prelude::run_to_end(crate::prelude::each_job(arms_p2, ({
            auto cp_p0x = cp_p0;
            auto subject_p8x = subject_p8;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), subject_p8x = std::move(subject_p8x)](crate::lower::model::XArm p0) {
            return ({
                auto cp_p0xy = cp_p0x;
                auto subject_p8xy = subject_p8x;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), subject_p8xy = std::move(subject_p8xy)]() {
                return ({
                    auto a_pd = p0;
                    (prism_rtl::more(prism_rtl::rc(MatchArm(cp_p0xy, subject_p8xy, a_pd, false))));
                });
            })));
            });
        })));
        })));
        return crate::emit::cpp::templates::items::match_expr_f(crate::emit::cpp::cpp_type_f(cp_p0, t_p6), prism_rtl::cat(bind_p9, crate::syntax::lexer::chars::join_f(lines_pa, Text::lit("\n")), "\n", match_tail_f(arms_p2)));
    }
}


prism_rtl::Turn<Text> CppMatch::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& s_p1 = this->s_p1;
    const auto& arms_p2 = this->arms_p2;
    const auto& out_ty3 = this->out_ty3;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutTurn>(out_ty3) ? prism_rtl::more(prism_rtl::rc(TernaryMatch(cp_p0, s_p1, arms_p2)))
        : ({
        auto&& t_p6 = out_ty3;
        ({
        auto bound_o7 = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(s_p1)) {
                auto&& n_pb = prism_rtl::as<crate::lower::model::Ex::XVar>(s_p1).a0;
                _v.set(std::optional(crate::emit::cpp::stmts::var_name_f(cp_p0, n_pb)));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::model::Ex::XRef>(s_p1)) {
                auto&& m4514_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s_p1).a0;
                if (prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m4514_1_0)))) {
                    auto&& n_pc = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m4514_1_0))).a0;
                    _v.set(std::optional(crate::emit::cpp::stmts::var_name_f(cp_p0, n_pc)));
                    goto _done;
                }
            }
            {
                _v.set(std::optional<Text>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subject_p8 = crate::prelude::or_(bound_o7, Text::lit("_m"));
        auto bind_p9 = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(bound_o7)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            if (prism_rtl::is_none(bound_o7)) {
                _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr_f(cp_p0, s_p1), ";\n"));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arms_p2x = arms_p2;
        auto cp_p0x = cp_p0;
        auto s_p1x = s_p1;
        auto t_p6x = t_p6;
        (crate::prelude::call_value(crate::prelude::each_job(arms_p2x, ({
        auto cp_p0xx = cp_p0x;
        auto subject_p8x = subject_p8;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx), subject_p8x = std::move(subject_p8x)](crate::lower::model::XArm p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            auto subject_p8xy = subject_p8x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy), subject_p8xy = std::move(subject_p8xy)]() {
            return ({
                auto a_pd = p0;
                (prism_rtl::more(prism_rtl::rc(MatchArm(cp_p0xxy, subject_p8xy, a_pd, false))));
            });
        })));
        });
    })));
    })), [=, bind_p9 = std::move(bind_p9), t_p6x = std::move(t_p6x)](Array<Text> each_4767) {
        return ({
            auto lines_pa = each_4767;
            (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, t_p6x), [=, lines_pa = std::move(lines_pa)](Text cpp_type_f_4829) { return prism_rtl::finished(crate::emit::cpp::templates::items::match_expr_f(cpp_type_f_4829, prism_rtl::cat(bind_p9, crate::syntax::lexer::chars::join_f(lines_pa, Text::lit("\n")), "\n", match_tail_f(arms_p2x)))); }));
        });
    }));
    });
    });
    });
}


/// `Start CppMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_match_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex s_p1, Array<crate::lower::model::XArm> arms_p2, crate::lower::model::OutTy out_ty3) {
    return prism_rtl::make_rc<CppMatch>(cp_p0, s_p1, arms_p2, out_ty3);
}


/// ReturnMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
Text return_match_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& s_p1, const Array<crate::lower::model::XArm>& arms_p2, const crate::lower::model::OutTy& out_ty3) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutTurn>(out_ty3)) {
        return prism_rtl::cat("return ", ternary_match_f(cp_p0, s_p1, arms_p2), ";");
    }
    {
        auto&& t_p6 = out_ty3;
        auto bound_o7 = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(s_p1)) {
                auto&& n_pb = prism_rtl::as<crate::lower::model::Ex::XVar>(s_p1).a0;
                _v.set(std::optional(crate::emit::cpp::stmts::var_name_f(cp_p0, n_pb)));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::model::Ex::XRef>(s_p1)) {
                auto&& m5290_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s_p1).a0;
                if (prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m5290_1_0)))) {
                    auto&& n_pc = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m5290_1_0))).a0;
                    _v.set(std::optional(crate::emit::cpp::stmts::var_name_f(cp_p0, n_pc)));
                    goto _done;
                }
            }
            {
                _v.set(std::optional<Text>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subject_p8 = crate::prelude::or_(bound_o7, Text::lit("_m"));
        auto bind_p9 = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(bound_o7)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            if (prism_rtl::is_none(bound_o7)) {
                _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr_f(cp_p0, s_p1), ";\n"));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto lines_pa = crate::prelude::run_to_end(crate::prelude::each_job(arms_p2, ({
            auto cp_p0x = cp_p0;
            auto subject_p8x = subject_p8;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), subject_p8x = std::move(subject_p8x)](crate::lower::model::XArm p0) {
            return ({
                auto cp_p0xy = cp_p0x;
                auto subject_p8xy = subject_p8x;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), subject_p8xy = std::move(subject_p8xy)]() {
                return ({
                    auto a_pd = p0;
                    (prism_rtl::more(prism_rtl::rc(MatchArm(cp_p0xy, subject_p8xy, a_pd, true))));
                });
            })));
            });
        })));
        })));
        return prism_rtl::cat(bind_p9, crate::syntax::lexer::chars::join_f(lines_pa, Text::lit("\n")), "\n", match_tail_f(arms_p2));
    }
}


prism_rtl::Turn<Text> ReturnMatch::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& s_p1 = this->s_p1;
    const auto& arms_p2 = this->arms_p2;
    const auto& out_ty3 = this->out_ty3;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutTurn>(out_ty3) ? ({
        auto arms_p2x = arms_p2;
        auto cp_p0x = cp_p0;
        auto s_p1x = s_p1;
        (crate::prelude::call_then(start_ternary_match_f(cp_p0x, s_p1x, arms_p2x), [=](Text ternary_match_f_5214) { return prism_rtl::finished(prism_rtl::cat("return ", ternary_match_f_5214, ";")); }));
    })
        : ({
        auto&& t_p6 = out_ty3;
        ({
        auto bound_o7 = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(s_p1)) {
                auto&& n_pb = prism_rtl::as<crate::lower::model::Ex::XVar>(s_p1).a0;
                _v.set(std::optional(crate::emit::cpp::stmts::var_name_f(cp_p0, n_pb)));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::model::Ex::XRef>(s_p1)) {
                auto&& m5290_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s_p1).a0;
                if (prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m5290_1_0)))) {
                    auto&& n_pc = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m5290_1_0))).a0;
                    _v.set(std::optional(crate::emit::cpp::stmts::var_name_f(cp_p0, n_pc)));
                    goto _done;
                }
            }
            {
                _v.set(std::optional<Text>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subject_p8 = crate::prelude::or_(bound_o7, Text::lit("_m"));
        auto bind_p9 = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(bound_o7)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            if (prism_rtl::is_none(bound_o7)) {
                _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr_f(cp_p0, s_p1), ";\n"));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arms_p2x = arms_p2;
        auto cp_p0x = cp_p0;
        auto s_p1x = s_p1;
        (crate::prelude::call_value(crate::prelude::each_job(arms_p2x, ({
        auto cp_p0xx = cp_p0x;
        auto subject_p8x = subject_p8;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx), subject_p8x = std::move(subject_p8x)](crate::lower::model::XArm p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            auto subject_p8xy = subject_p8x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy), subject_p8xy = std::move(subject_p8xy)]() {
            return ({
                auto a_pd = p0;
                (prism_rtl::more(prism_rtl::rc(MatchArm(cp_p0xxy, subject_p8xy, a_pd, true))));
            });
        })));
        });
    })));
    })), [=, bind_p9 = std::move(bind_p9)](Array<Text> each_5543) {
        return ({
            auto lines_pa = each_5543;
            (prism_rtl::finished(prism_rtl::cat(bind_p9, crate::syntax::lexer::chars::join_f(lines_pa, Text::lit("\n")), "\n", match_tail_f(arms_p2x))));
        });
    }));
    });
    });
    });
}


/// `Start ReturnMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_return_match_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex s_p1, Array<crate::lower::model::XArm> arms_p2, crate::lower::model::OutTy out_ty3) {
    return prism_rtl::make_rc<ReturnMatch>(cp_p0, s_p1, arms_p2, out_ty3);
}


/// MatchTail: fn [XArm] -> Text
Text match_tail_f(const Array<crate::lower::model::XArm>& arms_p0) {
    auto ends_p1 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::syntax::lexer::chars::last_o(arms_p0);
        if (prism_rtl::is_some(_m)) {
            auto&& a_p2 = prism_rtl::some_of(_m);
            _v.set(is_catch_all_f(prism_rtl::deref(a_p2).pat_p) && (crate::prelude::len(prism_rtl::deref(a_p2).conds_p) == Nat(0u)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return std::move(ends_p1)
        ? Text::lit("")
        : Text::lit("prism_rtl::unreachable(\"no arm matched\");\n");
}


/// TernaryMatch: unbounded fn Cp, Ex, [XArm] -> Text
Text ternary_match_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& s_p1, const Array<crate::lower::model::XArm>& arms_p2) {
    auto bound_o3 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        if (prism_rtl::is<crate::lower::model::Ex::XVar>(s_p1)) {
            auto&& n_p9 = prism_rtl::as<crate::lower::model::Ex::XVar>(s_p1).a0;
            _v.set(std::optional(crate::emit::cpp::stmts::var_name_f(cp_p0, n_p9)));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(s_p1)) {
            auto&& m6275_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s_p1).a0;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m6275_1_0)))) {
                auto&& n_pa = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m6275_1_0))).a0;
                _v.set(std::optional(crate::emit::cpp::stmts::var_name_f(cp_p0, n_pa)));
                goto _done;
            }
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto subject_p4 = crate::prelude::or_(bound_o3, Text::lit("_m"));
    auto bind_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(bound_o3)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        if (prism_rtl::is_none(bound_o3)) {
            _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr_f(cp_p0, s_p1), ";\n"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto reached_p6 = crate::prelude::run_to_end(crate::prelude::fold_job(arms_p2, std::tuple{Array<crate::lower::model::XArm>{}, false}, ({
        auto cp_p0x = cp_p0;
        auto subject_p4x = subject_p4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::XArm>, bool>>(std::tuple<std::tuple<Array<crate::lower::model::XArm>, bool>, crate::lower::model::XArm>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), subject_p4x = std::move(subject_p4x)](std::tuple<std::tuple<Array<crate::lower::model::XArm>, bool>, crate::lower::model::XArm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_p0xy = cp_p0x;
            auto subject_p4xy = subject_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), subject_p4xy = std::move(subject_p4xy)]() {
            return ({
                auto [acc_pb, done_pc] = p0;
                auto a_pd = p1;
                done_pc
                ? prism_rtl::finished(std::tuple{acc_pb, done_pc})
                : crate::prelude::call_then(start_pat_conds_f(cp_p0xy, prism_rtl::deref(a_pd).pat_p, subject_p4xy), [=](Array<Text> pat_conds_f_6714) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_pb, a_pd), (crate::prelude::len(pat_conds_f_6714) == Nat(0u)) && (crate::prelude::len(prism_rtl::deref(a_pd).conds_p) == Nat(0u))}); });
            });
        })));
        });
    }));
    })));
    auto [kept_pe, ends_pf] = reached_p6;
    auto parts_p7 = crate::prelude::run_to_end(crate::prelude::each_job(kept_pe, ({
        auto cp_p0x = cp_p0;
        auto subject_p4x = subject_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), subject_p4x = std::move(subject_p4x)](crate::lower::model::XArm p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            auto subject_p4xy = subject_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), subject_p4xy = std::move(subject_p4xy)]() {
            return ({
                auto a_pg = p0;
                (prism_rtl::more(prism_rtl::rc(TernaryArm(cp_p0xy, subject_p4xy, a_pg))));
            });
        })));
        });
    })));
    })));
    auto last_text_p8 = ends_pf
        ? Text::lit("")
        : Text::lit("\n    : throw prism_rtl::Panic(\"no arm matched\")");
    return crate::emit::cpp::templates::items::stmt_expr_f(prism_rtl::cat(bind_p5), prism_rtl::cat(crate::syntax::lexer::chars::join_f(parts_p7, Text::lit("\n    : ")), last_text_p8));
}


prism_rtl::Turn<Text> TernaryMatch::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& s_p1 = this->s_p1;
    const auto& arms_p2 = this->arms_p2;
    auto bound_o3 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        if (prism_rtl::is<crate::lower::model::Ex::XVar>(s_p1)) {
            auto&& n_p9 = prism_rtl::as<crate::lower::model::Ex::XVar>(s_p1).a0;
            _v.set(std::optional(crate::emit::cpp::stmts::var_name_f(cp_p0, n_p9)));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(s_p1)) {
            auto&& m6275_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s_p1).a0;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m6275_1_0)))) {
                auto&& n_pa = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m6275_1_0))).a0;
                _v.set(std::optional(crate::emit::cpp::stmts::var_name_f(cp_p0, n_pa)));
                goto _done;
            }
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto subject_p4 = crate::prelude::or_(bound_o3, Text::lit("_m"));
    auto bind_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(bound_o3)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        if (prism_rtl::is_none(bound_o3)) {
            _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr_f(cp_p0, s_p1), ";\n"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto arms_p2x = arms_p2;
    auto cp_p0x = cp_p0;
    return crate::prelude::call_value(crate::prelude::fold_job(arms_p2x, std::tuple{Array<crate::lower::model::XArm>{}, false}, ({
        auto cp_p0xx = cp_p0x;
        auto subject_p4x = subject_p4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::XArm>, bool>>(std::tuple<std::tuple<Array<crate::lower::model::XArm>, bool>, crate::lower::model::XArm>)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx), subject_p4x = std::move(subject_p4x)](std::tuple<std::tuple<Array<crate::lower::model::XArm>, bool>, crate::lower::model::XArm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_p0xxy = cp_p0xx;
            auto subject_p4xy = subject_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy), subject_p4xy = std::move(subject_p4xy)]() {
            return ({
                auto [acc_pb, done_pc] = p0;
                auto a_pd = p1;
                done_pc
                ? prism_rtl::finished(std::tuple{acc_pb, done_pc})
                : crate::prelude::call_then(start_pat_conds_f(cp_p0xxy, prism_rtl::deref(a_pd).pat_p, subject_p4xy), [=](Array<Text> pat_conds_f_6714) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_pb, a_pd), (crate::prelude::len(pat_conds_f_6714) == Nat(0u)) && (crate::prelude::len(prism_rtl::deref(a_pd).conds_p) == Nat(0u))}); });
            });
        })));
        });
    }));
    })), [=](std::tuple<Array<crate::lower::model::XArm>, bool> fold_6614) {
        return ({
            auto reached_p6 = fold_6614;
            auto [kept_pe, ends_pf] = reached_p6;
            (crate::prelude::call_value(crate::prelude::each_job(kept_pe, ({
            auto cp_p0xx = cp_p0x;
            auto subject_p4x = subject_p4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx), subject_p4x = std::move(subject_p4x)](crate::lower::model::XArm p0) {
            return ({
                auto cp_p0xxy = cp_p0xx;
                auto subject_p4xy = subject_p4x;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy), subject_p4xy = std::move(subject_p4xy)]() {
                return ({
                    auto a_pg = p0;
                    (prism_rtl::more(prism_rtl::rc(TernaryArm(cp_p0xxy, subject_p4xy, a_pg))));
                });
            })));
            });
        })));
        })), [=](Array<Text> each_6823) {
            return ({
                auto parts_p7 = each_6823;
                auto last_text_p8 = ends_pf
                    ? Text::lit("")
                    : Text::lit("\n    : throw prism_rtl::Panic(\"no arm matched\")");
                (prism_rtl::finished(crate::emit::cpp::templates::items::stmt_expr_f(prism_rtl::cat(bind_p5), prism_rtl::cat(crate::syntax::lexer::chars::join_f(parts_p7, Text::lit("\n    : ")), last_text_p8))));
            });
        }));
        });
    });
}


/// `Start TernaryMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ternary_match_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex s_p1, Array<crate::lower::model::XArm> arms_p2) {
    return prism_rtl::make_rc<TernaryMatch>(cp_p0, s_p1, arms_p2);
}


/// TernaryArm: unbounded fn Cp, Text, XArm -> Text
Text ternary_arm_f(const crate::emit::cpp::Cp& cp0_p0, const Text& subject_p1, const crate::lower::model::XArm& a_p2) {
    auto cp_p3 = crate::emit::cpp::stmts::unbind_f(cp0_p0, crate::emit::cpp::stmts::arm_names_f(a_p2));
    auto tests_p4 = pat_conds_f(cp_p3, a_p2.pat_p, subject_p1);
    auto binds_p5 = pat_binds_f(cp_p3, a_p2.pat_p, subject_p1);
    auto n_p6 = crate::prelude::len(a_p2.conds_p);
    auto lets_p7 = concat2_f(crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(n_p6), ({
        auto cp_p3x = cp_p3;
        auto a_p2x = a_p2;
        auto n_p6x = n_p6;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p3x = std::move(cp_p3x), a_p2x = std::move(a_p2x), n_p6x = std::move(n_p6x)](Nat p0) {
        return ({
            auto cp_p3xy = cp_p3x;
            auto a_p2xy = a_p2x;
            auto n_p6xy = n_p6x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p3xy = std::move(cp_p3xy), a_p2xy = std::move(a_p2xy), n_p6xy = std::move(n_p6xy)]() {
            return ({
                auto i_pb = p0;
                (prism_rtl::more(prism_rtl::rc(CondBinds(cp_p3xy, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(a_p2xy).conds_p, i_pb), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})), crate::prelude::or_(n_p6xy.checked_sub(i_pb), Nat(0u))))));
            });
        })));
        });
    })));
    }))));
    auto value_p8 = (crate::prelude::len(binds_p5) + crate::prelude::len(lets_p7)) == Nat(0u)
        ? crate::emit::cpp::expr::cpp_expr_f(cp_p3, a_p2.body_p)
        : crate::emit::cpp::templates::items::stmt_expr_f(crate::syntax::lexer::chars::join_f(crate::prelude::append(binds_p5, lets_p7), Text::lit("\n")), crate::emit::cpp::expr::cpp_expr_f(cp_p3, a_p2.body_p));
    auto guard_p9 = crate::prelude::len(a_p2.conds_p) == Nat(0u)
        ? Array<Text>{}
        : Array(std::vector{crate::emit::cpp::templates::items::stmt_expr_f(crate::syntax::lexer::chars::join_f(binds_p5, Text::lit("\n")), guard_test_f(cp_p3, a_p2.conds_p))});
    auto all_pa = crate::prelude::append(tests_p4, guard_p9);
    return crate::prelude::len(all_pa) == Nat(0u)
        ? value_p8
        : prism_rtl::cat(conds_f(all_pa), " ? ", value_p8);
}


prism_rtl::Turn<Text> TernaryArm::cycle() const {
    const auto& cp0_p0 = this->cp0_p0;
    const auto& subject_p1 = this->subject_p1;
    const auto& a_p2 = this->a_p2;
    auto a_p2x = a_p2;
    auto cp0_p0x = cp0_p0;
    auto subject_p1x = subject_p1;
    return crate::prelude::call_then(crate::emit::cpp::stmts::start_arm_names_f(a_p2x), [=](Array<Text> arm_names_f_7121) {
        return ({
            auto cp_p3 = crate::emit::cpp::stmts::unbind_f(cp0_p0x, arm_names_f_7121);
            (crate::prelude::call_then(start_pat_conds_f(cp_p3, prism_rtl::deref(a_p2x).pat_p, subject_p1x), [=](Array<Text> pat_conds_f_7149) {
            return ({
                auto tests_p4 = pat_conds_f_7149;
                (crate::prelude::call_then(start_pat_binds_f(cp_p3, prism_rtl::deref(a_p2x).pat_p, subject_p1x), [=, tests_p4 = std::move(tests_p4)](Array<Text> pat_binds_f_7193) {
                return ({
                    auto binds_p5 = pat_binds_f_7193;
                    auto n_p6 = crate::prelude::len(prism_rtl::deref(a_p2x).conds_p);
                    (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(n_p6), ({
                    auto cp_p3x = cp_p3;
                    auto a_p2xx = a_p2x;
                    auto n_p6x = n_p6;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=, cp_p3x = std::move(cp_p3x), a_p2xx = std::move(a_p2xx), n_p6x = std::move(n_p6x)](Nat p0) {
                    return ({
                        auto cp_p3xy = cp_p3x;
                        auto a_p2xxy = a_p2xx;
                        auto n_p6xy = n_p6x;
                        (crate::prelude::entered(crate::prelude::once_job([=, cp_p3xy = std::move(cp_p3xy), a_p2xxy = std::move(a_p2xxy), n_p6xy = std::move(n_p6xy)]() {
                        return ({
                            auto i_pb = p0;
                            (prism_rtl::more(prism_rtl::rc(CondBinds(cp_p3xy, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(a_p2xxy).conds_p, i_pb), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})), crate::prelude::or_(n_p6xy.checked_sub(i_pb), Nat(0u))))));
                        });
                    })));
                    });
                })));
                })), [=, binds_p5 = std::move(binds_p5)](Array<Array<Text>> each_7269) {
                    return ({
                        auto lets_p7 = concat2_f(each_7269);
                        auto value_p8 = (crate::prelude::len(binds_p5) + crate::prelude::len(lets_p7)) == Nat(0u)
                            ? crate::emit::cpp::expr::cpp_expr_f(cp_p3, prism_rtl::deref(a_p2x).body_p)
                            : crate::emit::cpp::templates::items::stmt_expr_f(crate::syntax::lexer::chars::join_f(crate::prelude::append(binds_p5, lets_p7), Text::lit("\n")), crate::emit::cpp::expr::cpp_expr_f(cp_p3, prism_rtl::deref(a_p2x).body_p));
                        auto guard_p9 = crate::prelude::len(prism_rtl::deref(a_p2x).conds_p) == Nat(0u)
                            ? Array<Text>{}
                            : Array(std::vector{crate::emit::cpp::templates::items::stmt_expr_f(crate::syntax::lexer::chars::join_f(binds_p5, Text::lit("\n")), guard_test_f(cp_p3, prism_rtl::deref(a_p2x).conds_p))});
                        auto all_pa = crate::prelude::append(tests_p4, guard_p9);
                        (crate::prelude::len(all_pa) == Nat(0u)
                        ? prism_rtl::finished(value_p8)
                        : prism_rtl::finished(prism_rtl::cat(conds_f(all_pa), " ? ", value_p8)));
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start TernaryArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ternary_arm_f(crate::emit::cpp::Cp cp0_p0, Text subject_p1, crate::lower::model::XArm a_p2) {
    return prism_rtl::make_rc<TernaryArm>(cp0_p0, subject_p1, a_p2);
}


/// CondBinds: unbounded fn Cp, Cc, Nat -> [Text]
Array<Text> cond_binds_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Cc& cc1, const Nat& k_p3) {
    if (prism_rtl::is<crate::lower::model::Cc::CcLet>(cc1)) {
        auto&& p_p1 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc1).a0;
        auto&& x_p2 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc1).a1;
        auto [v_p4, pre_p5] = cond_subject_f(cp_p0, x_p2, k_p3);
        return crate::prelude::append(pre_p5, pat_binds_f(cp_p0, p_p1, v_p4));
    }
    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(cc1)) {
        auto&& x_p7 = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc1).a0;
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> CondBinds::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& cc1 = this->cc1;
    const auto& k_p3 = this->k_p3;
    return ({
        prism_rtl::is<crate::lower::model::Cc::CcLet>(cc1) ? ({
        auto&& p_p1 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc1).a0;
        auto&& x_p2 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc1).a1;
        ({
        auto cp_p0x = cp_p0;
        auto k_p3x = k_p3;
        auto p_p1x = p_p1;
        auto x_p2x = x_p2;
        (crate::prelude::call_then(start_cond_subject_f(cp_p0x, x_p2x, k_p3x), [=, p_p1x = std::move(p_p1x)](std::tuple<Text, Array<Text>> cond_subject_f_7798) {
        return ({
            auto [v_p4, pre_p5] = cond_subject_f_7798;
            (crate::prelude::call_then(start_pat_binds_f(cp_p0x, p_p1x, v_p4), [=](Array<Text> pat_binds_f_7836) { return prism_rtl::finished(crate::prelude::append(pre_p5, pat_binds_f_7836)); }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::lower::model::Cc::CcIf>(cc1) ? ({
        auto&& x_p7 = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc1).a0;
        prism_rtl::finished(Array<Text>{});
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cond_binds_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Cc cc1, Nat k_p3) {
    return prism_rtl::make_rc<CondBinds>(cp_p0, cc1, k_p3);
}


/// CondSubject: unbounded fn Cp, Ex, Nat -> ((Text, [Text]))
std::tuple<Text, Array<Text>> cond_subject_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& x_p1, const Nat& k_p2) {
    return is_place_ex_f(x_p1)
        ? std::tuple{crate::emit::cpp::expr::cpp_tight_f(cp_p0, x_p1), Array<Text>{}}
        : std::tuple{prism_rtl::cat("_c", k_p2), Array(std::vector{prism_rtl::cat("auto&& _c", k_p2, " = ", crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p1), ";")})};
}


prism_rtl::Turn<std::tuple<Text, Array<Text>>> CondSubject::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& x_p1 = this->x_p1;
    const auto& k_p2 = this->k_p2;
    return is_place_ex_f(x_p1)
        ? ({
        auto cp_p0x = cp_p0;
        auto x_p1x = x_p1;
        (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_tight_f(cp_p0x, x_p1x), [=](Text cpp_tight_f_8253) { return prism_rtl::finished(std::tuple{cpp_tight_f_8253, Array<Text>{}}); }));
    })
        : ({
        auto cp_p0x = cp_p0;
        auto k_p2x = k_p2;
        auto x_p1x = x_p1;
        (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, x_p1x), [=, k_p2x = std::move(k_p2x)](Text cpp_expr_f_8313) { return prism_rtl::finished(std::tuple{prism_rtl::cat("_c", k_p2x), Array(std::vector{prism_rtl::cat("auto&& _c", k_p2x, " = ", cpp_expr_f_8313, ";")})}); }));
    });
}


/// `Start CondSubject, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Array<Text>>> start_cond_subject_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex x_p1, Nat k_p2) {
    return prism_rtl::make_rc<CondSubject>(cp_p0, x_p1, k_p2);
}


/// IsPlaceEx: fn Ex -> Bool
bool is_place_ex_f(const crate::lower::model::Ex& x_p0) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x_p0)) {
        auto&& y_p1 = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a0;
        return is_place_ex_f(prism_rtl::deref(prism_rtl::deref(y_p1)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x_p0)) {
        auto&& y_p2 = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a0;
        return is_place_ex_f(prism_rtl::deref(prism_rtl::deref(y_p2)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XSelf>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x_p0)) {
        auto&& y_p3 = prism_rtl::as<crate::lower::model::Ex::XRef>(x_p0).a0;
        return is_place_ex_f(prism_rtl::deref(prism_rtl::deref(y_p3)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x_p0)) {
        auto&& y_p4 = prism_rtl::as<crate::lower::model::Ex::XDeref>(x_p0).a0;
        return is_place_ex_f(prism_rtl::deref(prism_rtl::deref(y_p4)));
    }
    {
        return false;
    }
}


/// GuardTest: unbounded fn Cp, [Cc] -> Text
Text guard_test_f(const crate::emit::cpp::Cp& cp_p0, const Array<crate::lower::model::Cc>& xs1) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return Text::lit("true");
        }
    }
    {
        auto&& cs_p2 = xs1;
        auto first_p3 = crate::prelude::or_(crate::prelude::index(cs_p2, Nat(0u)), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})}));
        auto rest_p4 = guard_test_f(cp_p0, crate::prelude::drop(cs_p2, Nat(1u)));
        if (prism_rtl::is<crate::lower::model::Cc::CcIf>(first_p3)) {
            auto&& x_p5 = prism_rtl::as<crate::lower::model::Cc::CcIf>(first_p3).a0;
            return crate::prelude::len(cs_p2) == Nat(1u)
                ? crate::emit::cpp::expr::cpp_tight_f(cp_p0, x_p5)
                : prism_rtl::cat(crate::emit::cpp::expr::cpp_tight_f(cp_p0, x_p5), " && ", rest_p4);
        }
        if (prism_rtl::is<crate::lower::model::Cc::CcLet>(first_p3)) {
            auto&& p_p6 = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_p3).a0;
            auto&& x_p7 = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_p3).a1;
            auto [v_pa, pre_pb] = cond_subject_f(cp_p0, x_p7, crate::prelude::len(cs_p2));
            auto tests_p8 = conds_f(pat_conds_f(cp_p0, p_p6, v_pa));
            auto whole_p9 = crate::prelude::len(cs_p2) == Nat(1u)
                ? tests_p8
                : prism_rtl::cat(tests_p8, " && ", crate::emit::cpp::templates::items::stmt_expr_f(crate::syntax::lexer::chars::join_f(pat_binds_f(cp_p0, p_p6, v_pa), Text::lit("\n")), rest_p4));
            return crate::prelude::len(pre_pb) == Nat(0u)
                ? whole_p9
                : crate::emit::cpp::templates::items::stmt_expr_f(crate::syntax::lexer::chars::join_f(pre_pb, Text::lit("\n")), whole_p9);
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<Text> GuardTest::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& xs1 = this->xs1;
    return ({
        ({
        auto&& j0_1 = xs1;
        (j0_1.size() == 0u);
    }) ? ({
        auto&& j0_1 = xs1;
        prism_rtl::finished(Text::lit("true"));
    })
        : ({
        auto&& cs_p2 = xs1;
        ({
        auto first_p3 = crate::prelude::or_(crate::prelude::index(cs_p2, Nat(0u)), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})}));
        auto cp_p0x = cp_p0;
        auto cs_p2x = cs_p2;
        (crate::prelude::call_then(start_guard_test_f(cp_p0x, crate::prelude::drop(cs_p2x, Nat(1u))), [=, first_p3 = std::move(first_p3)](Text guard_test_f_8817) {
        return ({
            auto rest_p4 = guard_test_f_8817;
            ({
            prism_rtl::is<crate::lower::model::Cc::CcIf>(first_p3) ? ({
            auto&& x_p5 = prism_rtl::as<crate::lower::model::Cc::CcIf>(first_p3).a0;
            crate::prelude::len(cs_p2x) == Nat(1u)
            ? prism_rtl::more(prism_rtl::rc(crate::emit::cpp::expr::CppTight(cp_p0x, x_p5)))
            : ({
            auto x_p5x = x_p5;
            (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_tight_f(cp_p0x, x_p5x), [=](Text cpp_tight_f_8918) { return prism_rtl::finished(prism_rtl::cat(cpp_tight_f_8918, " && ", rest_p4)); }));
        });
        })
            : prism_rtl::is<crate::lower::model::Cc::CcLet>(first_p3) ? ({
            auto&& p_p6 = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_p3).a0;
            auto&& x_p7 = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_p3).a1;
            ({
            auto p_p6x = p_p6;
            auto x_p7x = x_p7;
            (crate::prelude::call_then(start_cond_subject_f(cp_p0x, x_p7x, crate::prelude::len(cs_p2x)), [=, p_p6x = std::move(p_p6x)](std::tuple<Text, Array<Text>> cond_subject_f_8994) {
            return ({
                auto [v_pa, pre_pb] = cond_subject_f_8994;
                (crate::prelude::call_then(start_pat_conds_f(cp_p0x, p_p6x, v_pa), [=](Array<Text> pat_conds_f_9053) {
                return ({
                    auto tests_p8 = conds_f(pat_conds_f_9053);
                    auto whole_p9 = crate::prelude::len(cs_p2x) == Nat(1u)
                        ? tests_p8
                        : prism_rtl::cat(tests_p8, " && ", crate::emit::cpp::templates::items::stmt_expr_f(crate::syntax::lexer::chars::join_f(pat_binds_f(cp_p0x, p_p6x, v_pa), Text::lit("\n")), rest_p4));
                    (crate::prelude::len(pre_pb) == Nat(0u)
                    ? prism_rtl::finished(whole_p9)
                    : prism_rtl::finished(crate::emit::cpp::templates::items::stmt_expr_f(crate::syntax::lexer::chars::join_f(pre_pb, Text::lit("\n")), whole_p9)));
                });
            }));
            });
        }));
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    }));
    });
    });
    });
}


/// `Start GuardTest, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_guard_test_f(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Cc> xs1) {
    return prism_rtl::make_rc<GuardTest>(cp_p0, xs1);
}


/// MatchArm: unbounded fn Cp, Text, XArm, Bool -> Text
Text match_arm_f(const crate::emit::cpp::Cp& cp0_p0, const Text& subject_p1, const crate::lower::model::XArm& a_p2, const bool& returns_p3) {
    auto cp_p4 = crate::emit::cpp::stmts::unbind_f(cp0_p0, crate::emit::cpp::stmts::arm_names_f(a_p2));
    auto tests_p5 = pat_conds_f(cp_p4, a_p2.pat_p, subject_p1);
    auto binds_p6 = pat_binds_f(cp_p4, a_p2.pat_p, subject_p1);
    auto body_p7 = returns_p3
        ? crate::emit::cpp::stmts::cpp_body_f(cp_p4, a_p2.body_p)
        : leaves_f(a_p2.body_p)
        ? prism_rtl::cat(crate::emit::cpp::expr::cpp_expr_f(cp_p4, a_p2.body_p), ";")
        : prism_rtl::cat("_v.set(", crate::emit::cpp::expr::cpp_expr_f(cp_p4, a_p2.body_p), ");\ngoto _done;");
    auto guarded_p8 = crate::prelude::len(a_p2.conds_p) == Nat(0u)
        ? body_p7
        : guarded_arm_f(cp_p4, a_p2.conds_p, body_p7);
    auto inner_p9 = crate::syntax::lexer::chars::join_f(crate::prelude::append(binds_p6, Array(std::vector{guarded_p8})), Text::lit("\n"));
    return crate::prelude::len(tests_p5) == Nat(0u)
        ? crate::emit::cpp::templates::items::braced_f(inner_p9)
        : crate::emit::cpp::templates::items::if_block_f(conds_f(tests_p5), inner_p9);
}


prism_rtl::Turn<Text> MatchArm::cycle() const {
    const auto& cp0_p0 = this->cp0_p0;
    const auto& subject_p1 = this->subject_p1;
    const auto& a_p2 = this->a_p2;
    const auto& returns_p3 = this->returns_p3;
    auto a_p2x = a_p2;
    auto cp0_p0x = cp0_p0;
    auto returns_p3x = prism_rtl::deref(returns_p3);
    auto subject_p1x = subject_p1;
    return crate::prelude::call_then(crate::emit::cpp::stmts::start_arm_names_f(a_p2x), [=](Array<Text> arm_names_f_9511) {
        return ({
            auto cp_p4 = crate::emit::cpp::stmts::unbind_f(cp0_p0x, arm_names_f_9511);
            (crate::prelude::call_then(start_pat_conds_f(cp_p4, prism_rtl::deref(a_p2x).pat_p, subject_p1x), [=](Array<Text> pat_conds_f_9539) {
            return ({
                auto tests_p5 = pat_conds_f_9539;
                (crate::prelude::call_then(start_pat_binds_f(cp_p4, prism_rtl::deref(a_p2x).pat_p, subject_p1x), [=, tests_p5 = std::move(tests_p5)](Array<Text> pat_binds_f_9583) {
                return ({
                    auto binds_p6 = pat_binds_f_9583;
                    auto body_p7 = returns_p3x
                        ? crate::emit::cpp::stmts::cpp_body_f(cp_p4, prism_rtl::deref(a_p2x).body_p)
                        : leaves_f(prism_rtl::deref(a_p2x).body_p)
                        ? prism_rtl::cat(crate::emit::cpp::expr::cpp_expr_f(cp_p4, prism_rtl::deref(a_p2x).body_p), ";")
                        : prism_rtl::cat("_v.set(", crate::emit::cpp::expr::cpp_expr_f(cp_p4, prism_rtl::deref(a_p2x).body_p), ");\ngoto _done;");
                    auto guarded_p8 = crate::prelude::len(prism_rtl::deref(a_p2x).conds_p) == Nat(0u)
                        ? body_p7
                        : guarded_arm_f(cp_p4, prism_rtl::deref(a_p2x).conds_p, body_p7);
                    auto inner_p9 = crate::syntax::lexer::chars::join_f(crate::prelude::append(binds_p6, Array(std::vector{guarded_p8})), Text::lit("\n"));
                    (crate::prelude::len(tests_p5) == Nat(0u)
                    ? prism_rtl::finished(crate::emit::cpp::templates::items::braced_f(inner_p9))
                    : prism_rtl::finished(crate::emit::cpp::templates::items::if_block_f(conds_f(tests_p5), inner_p9)));
                });
            }));
            });
        }));
        });
    });
}


/// `Start MatchArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_match_arm_f(crate::emit::cpp::Cp cp0_p0, Text subject_p1, crate::lower::model::XArm a_p2, bool returns_p3) {
    return prism_rtl::make_rc<MatchArm>(cp0_p0, subject_p1, a_p2, returns_p3);
}


/// GuardedArm: unbounded fn Cp, [Cc], Text -> Text
Text guarded_arm_f(const crate::emit::cpp::Cp& cp_p0, const Array<crate::lower::model::Cc>& xs1, const Text& body_p1) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return body_p1;
        }
    }
    {
        auto&& cs_p3 = xs1;
        auto first_p5 = crate::prelude::or_(crate::prelude::index(cs_p3, Nat(0u)), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})}));
        auto rest_p6 = guarded_arm_f(cp_p0, crate::prelude::drop(cs_p3, Nat(1u)), body_p1);
        if (prism_rtl::is<crate::lower::model::Cc::CcIf>(first_p5)) {
            auto&& x_p7 = prism_rtl::as<crate::lower::model::Cc::CcIf>(first_p5).a0;
            return crate::emit::cpp::templates::items::if_block_f(crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p7), rest_p6);
        }
        if (prism_rtl::is<crate::lower::model::Cc::CcLet>(first_p5)) {
            auto&& p_p8 = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_p5).a0;
            auto&& x_p9 = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_p5).a1;
            auto [v_pb, pre_pc] = cond_subject_f(cp_p0, x_p9, crate::prelude::len(cs_p3));
            auto inner_pa = crate::emit::cpp::templates::items::if_block_f(conds_f(pat_conds_f(cp_p0, p_p8, v_pb)), crate::syntax::lexer::chars::join_f(crate::prelude::append(pat_binds_f(cp_p0, p_p8, v_pb), Array(std::vector{rest_p6})), Text::lit("\n")));
            return crate::prelude::len(pre_pc) == Nat(0u)
                ? inner_pa
                : crate::emit::cpp::templates::items::braced_f(crate::syntax::lexer::chars::join_f(crate::prelude::push(pre_pc, inner_pa), Text::lit("\n")));
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<Text> GuardedArm::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& xs1 = this->xs1;
    const auto& body_p1 = this->body_p1;
    return ({
        ({
        auto&& j0_1 = xs1;
        (j0_1.size() == 0u);
    }) ? ({
        auto&& j0_1 = xs1;
        prism_rtl::finished(body_p1);
    })
        : ({
        auto&& cs_p3 = xs1;
        ({
        auto first_p5 = crate::prelude::or_(crate::prelude::index(cs_p3, Nat(0u)), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})}));
        auto body_p1x = body_p1;
        auto cp_p0x = cp_p0;
        auto cs_p3x = cs_p3;
        (crate::prelude::call_then(start_guarded_arm_f(cp_p0x, crate::prelude::drop(cs_p3x, Nat(1u)), body_p1x), [=, first_p5 = std::move(first_p5)](Text guarded_arm_f_10220) {
        return ({
            auto rest_p6 = guarded_arm_f_10220;
            ({
            prism_rtl::is<crate::lower::model::Cc::CcIf>(first_p5) ? ({
            auto&& x_p7 = prism_rtl::as<crate::lower::model::Cc::CcIf>(first_p5).a0;
            ({
            auto x_p7x = x_p7;
            (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, x_p7x), [=](Text cpp_expr_f_10296) { return prism_rtl::finished(crate::emit::cpp::templates::items::if_block_f(cpp_expr_f_10296, rest_p6)); }));
        });
        })
            : prism_rtl::is<crate::lower::model::Cc::CcLet>(first_p5) ? ({
            auto&& p_p8 = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_p5).a0;
            auto&& x_p9 = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_p5).a1;
            ({
            auto p_p8x = p_p8;
            auto x_p9x = x_p9;
            (crate::prelude::call_then(start_cond_subject_f(cp_p0x, x_p9x, crate::prelude::len(cs_p3x)), [=, p_p8x = std::move(p_p8x)](std::tuple<Text, Array<Text>> cond_subject_f_10366) {
            return ({
                auto [v_pb, pre_pc] = cond_subject_f_10366;
                (crate::prelude::call_then(start_pat_conds_f(cp_p0x, p_p8x, v_pb), [=](Array<Text> pat_conds_f_10434) {
                return crate::prelude::call_then(start_pat_binds_f(cp_p0x, p_p8x, v_pb), [=](Array<Text> pat_binds_f_10470) {
                    return ({
                        auto inner_pa = crate::emit::cpp::templates::items::if_block_f(conds_f(pat_conds_f_10434), crate::syntax::lexer::chars::join_f(crate::prelude::append(pat_binds_f_10470, Array(std::vector{rest_p6})), Text::lit("\n")));
                        (crate::prelude::len(pre_pc) == Nat(0u)
                        ? prism_rtl::finished(inner_pa)
                        : prism_rtl::finished(crate::emit::cpp::templates::items::braced_f(crate::syntax::lexer::chars::join_f(crate::prelude::push(pre_pc, inner_pa), Text::lit("\n")))));
                    });
                });
            }));
            });
        }));
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    }));
    });
    });
    });
}


/// `Start GuardedArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_guarded_arm_f(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Cc> xs1, Text body_p1) {
    return prism_rtl::make_rc<GuardedArm>(cp_p0, xs1, body_p1);
}


/// CppLabeled: unbounded fn Cp, Text, [Do], Ex, OutTy -> Text
Text cpp_labeled_f(const crate::emit::cpp::Cp& cp_p0, const Text& label_p1, const Array<crate::lower::model::Do>& dos_p2, const crate::lower::model::Ex& e_p3, const crate::lower::model::OutTy& t_p4) {
    auto l_p5 = cpp_label_f(label_p1);
    auto last_p6 = leaves_f(e_p3)
        ? prism_rtl::cat(crate::emit::cpp::expr::cpp_expr_f(cp_p0, e_p3), ";")
        : prism_rtl::cat(l_p5, "_v.set(", crate::emit::cpp::expr::cpp_expr_f(cp_p0, e_p3), ");");
    return crate::emit::cpp::templates::items::labeled_expr_f(l_p5, crate::emit::cpp::cpp_type_f(cp_p0, t_p4), crate::syntax::lexer::chars::join_f(crate::prelude::push(crate::prelude::run_to_end(crate::prelude::each_job(dos_p2, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](crate::lower::model::Do p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto d_p7 = p0;
                (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::stmts::CppStatement(cp_p0xy, d_p7))));
            });
        })));
        });
    })));
    }))), last_p6), Text::lit("\n")));
}


prism_rtl::Turn<Text> CppLabeled::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& label_p1 = this->label_p1;
    const auto& dos_p2 = this->dos_p2;
    const auto& e_p3 = this->e_p3;
    const auto& t_p4 = this->t_p4;
    auto l_p5 = cpp_label_f(label_p1);
    auto last_p6 = leaves_f(e_p3)
        ? prism_rtl::cat(crate::emit::cpp::expr::cpp_expr_f(cp_p0, e_p3), ";")
        : prism_rtl::cat(l_p5, "_v.set(", crate::emit::cpp::expr::cpp_expr_f(cp_p0, e_p3), ");");
    auto cp_p0x = cp_p0;
    auto dos_p2x = dos_p2;
    auto t_p4x = t_p4;
    return crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, t_p4x), [=](Text cpp_type_f_10896) {
        return crate::prelude::call_value(crate::prelude::each_job(dos_p2x, ({
            auto cp_p0xx = cp_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](crate::lower::model::Do p0) {
            return ({
                auto cp_p0xxy = cp_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
                return ({
                    auto d_p7 = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::stmts::CppStatement(cp_p0xxy, d_p7))));
                });
            })));
            });
        })));
        })), [=](Array<Text> each_10925) { return prism_rtl::finished(crate::emit::cpp::templates::items::labeled_expr_f(l_p5, cpp_type_f_10896, crate::syntax::lexer::chars::join_f(crate::prelude::push(each_10925, last_p6), Text::lit("\n")))); });
    });
}


/// `Start CppLabeled, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_labeled_f(crate::emit::cpp::Cp cp_p0, Text label_p1, Array<crate::lower::model::Do> dos_p2, crate::lower::model::Ex e_p3, crate::lower::model::OutTy t_p4) {
    return prism_rtl::make_rc<CppLabeled>(cp_p0, label_p1, dos_p2, e_p3, t_p4);
}


/// CppLabel: fn Text -> Text
Text cpp_label_f(const Text& l_p0) {
    return crate::syntax::lexer::chars::has_prefix_f(l_p0, Text::lit("\'"))
        ? crate::syntax::lexer::chars::after_first_f(l_p0)
        : l_p0;
}


/// CppBreak: unbounded fn Cp, Text, Ex -> Text
Text cpp_break_f(const crate::emit::cpp::Cp& cp_p0, const Text& l_p1, const crate::lower::model::Ex& y_p2) {
    auto n_p3 = cpp_label_f(l_p1);
    return prism_rtl::cat("{ ", n_p3, "_v.set(", crate::emit::cpp::expr::cpp_expr_f(cp_p0, y_p2), "); goto ", n_p3, "; }");
}


prism_rtl::Turn<Text> CppBreak::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& l_p1 = this->l_p1;
    const auto& y_p2 = this->y_p2;
    auto n_p3 = cpp_label_f(l_p1);
    auto cp_p0x = cp_p0;
    auto y_p2x = y_p2;
    return crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, y_p2x), [=](Text cpp_expr_f_11170) { return prism_rtl::finished(prism_rtl::cat("{ ", n_p3, "_v.set(", cpp_expr_f_11170, "); goto ", n_p3, "; }")); });
}


/// `Start CppBreak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_break_f(crate::emit::cpp::Cp cp_p0, Text l_p1, crate::lower::model::Ex y_p2) {
    return prism_rtl::make_rc<CppBreak>(cp_p0, l_p1, y_p2);
}

}  // namespace crate::emit::cpp::patterns
