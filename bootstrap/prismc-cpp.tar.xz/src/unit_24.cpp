// The module `Check.Shrink.Types`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/shrink/types/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Shrink.Types`, from `target/bootstrap/cpp-src/prismc/check/shrink/types.prism`.
namespace crate::check::shrink::types {

/// NegativeTypes: unbounded fn G, St -> St
crate::check::types::St negative_types(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1) {
    auto arrowy_p2 = arrowy_types(g_p0);
    return run_to_end(fold_job(keys(g_p0.types), st_p1, ({
        auto g_p0_1 = g_p0;
        auto arrowy_p2_2 = arrowy_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1), arrowy_p2_2 = std::move(arrowy_p2_2)](std::tuple<crate::check::types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_3 = g_p0_1;
            auto arrowy_p2_2_3 = arrowy_p2_2;
            entered(once_job([=, g_p0_1_3 = std::move(g_p0_1_3), arrowy_p2_2_3 = std::move(arrowy_p2_2_3)]() {
            return ({
                auto s_p3 = p0;
                auto n_p4 = p1;
                (prism_rtl::more(prism_rtl::rc(NegativeType(g_p0_1_3, s_p3, arrowy_p2_2_3, n_p4))));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> NegativeTypes::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    auto g_p0_1 = g_p0;
    auto st_p1_2 = st_p1;
    return call_then(start_arrowy_types(g_p0_1), [=](Map<Text, bool> arrowy_types_1927) {
        return ({
            auto arrowy_p2 = arrowy_types_1927;
            fold_job(keys(prism_rtl::deref(g_p0_1).types), st_p1_2, ({
            auto g_p0_1_3 = g_p0_1;
            auto arrowy_p2_3 = arrowy_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=, g_p0_1_3 = std::move(g_p0_1_3), arrowy_p2_3 = std::move(arrowy_p2_3)](std::tuple<crate::check::types::St, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_p0_1_3_4 = g_p0_1_3;
                auto arrowy_p2_3_4 = arrowy_p2_3;
                entered(once_job([=, g_p0_1_3_4 = std::move(g_p0_1_3_4), arrowy_p2_3_4 = std::move(arrowy_p2_3_4)]() {
                return ({
                    auto s_p3 = p0;
                    auto n_p4 = p1;
                    (prism_rtl::more(prism_rtl::rc(NegativeType(g_p0_1_3_4, s_p3, arrowy_p2_3_4, n_p4))));
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start NegativeTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_negative_types(crate::check::env::G g_p0, crate::check::types::St st_p1) {
    return prism_rtl::make_rc<NegativeTypes>(g_p0, st_p1);
}


/// NegativeType: unbounded fn G, St, (Text ==> Bool), Text -> St
crate::check::types::St negative_type(const crate::check::env::G& g_p0, const crate::check::types::St& s_p1, const Map<Text, bool>& arrowy_p2, const Text& n_p3) {
    auto&& _m = crate::prelude::get(g_p0.types, n_p3);
    if (prism_rtl::is_some(_m)) {
        auto&& ti_p4 = prism_rtl::some_of(_m);
        auto&& _neg_p5 = (ti_p4->file >= g_p0.prelude_from) || (!crate::check::env::has_key(arrowy_p2, n_p3))
            ? std::tuple{false, Map<Text, bool>{}}
            : neg_walks(g_p0, n_p3, body_tys(ti_p4), false, Map<Text, bool>{});
        auto&& neg_p5 = std::get<0>(_neg_p5);
        return !neg_p5
            ? s_p1
            : ({
            auto s0_p6 = ({
                crate::check::types::St this_ = s_p1;
                this_.file = ti_p4->file;
                (std::move(this_));
            });
            auto s1_p7 = crate::check::types::recording::err_fix(s0_p6, Text::lit("may-not-end"), prism_rtl::deref(ti_p4).span, prism_rtl::cat("`", crate::check::types::bare_name(n_p3), "` stands left of a function arrow in its own definition: a call through the function it holds is a cycle, and nothing in it shrinks"), prism_rtl::cat("keep `", crate::check::types::bare_name(n_p3), "` right of the arrow, or make the arrow `unbounded fn`, which makes every call through it unbounded"));
            ({
            crate::check::types::St this_ = s1_p7;
            this_.file = s_p1.file;
            (std::move(this_));
        });
        });
    }
    if (prism_rtl::is_none(_m)) {
        return s_p1;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> NegativeType::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& s_p1 = this->s_p1;
    const auto& arrowy_p2 = this->arrowy_p2;
    const auto& n_p3 = this->n_p3;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).types, n_p3);
        prism_rtl::is_some(_m) ? ({
        auto&& ti_p4 = prism_rtl::some_of(_m);
        ({
        auto&& _neg_p5 = (ti_p4->file >= prism_rtl::deref(g_p0).prelude_from) || (!crate::check::env::has_key(arrowy_p2, n_p3))
            ? std::tuple{false, Map<Text, bool>{}}
            : neg_walks(g_p0, n_p3, body_tys(ti_p4), false, Map<Text, bool>{});
        auto&& neg_p5 = std::get<0>(_neg_p5);
        !neg_p5
        ? prism_rtl::finished(s_p1)
        : ({
        auto s0_p6 = ({
            crate::check::types::St this_ = s_p1;
            this_.file = ti_p4->file;
            (std::move(this_));
        });
        auto s1_p7 = crate::check::types::recording::err_fix(s0_p6, Text::lit("may-not-end"), prism_rtl::deref(ti_p4).span, prism_rtl::cat("`", crate::check::types::bare_name(n_p3), "` stands left of a function arrow in its own definition: a call through the function it holds is a cycle, and nothing in it shrinks"), prism_rtl::cat("keep `", crate::check::types::bare_name(n_p3), "` right of the arrow, or make the arrow `unbounded fn`, which makes every call through it unbounded"));
        (prism_rtl::finished(({
        crate::check::types::St this_ = s1_p7;
        this_.file = s_p1->file;
        (std::move(this_));
    })));
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(s_p1)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start NegativeType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_negative_type(crate::check::env::G g_p0, crate::check::types::St s_p1, Map<Text, bool> arrowy_p2, Text n_p3) {
    return prism_rtl::make_rc<NegativeType>(g_p0, s_p1, arrowy_p2, n_p3);
}


/// ArrowyTypes: unbounded fn G -> (Text ==> Bool)
Map<Text, bool> arrowy_types(const crate::check::env::G& g_p0) {
    auto names_p1 = run_to_end(fold_job(keys(g_p0.types), Map<Text, Array<Text>>{}, ({
        auto g_p0_1 = g_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1)](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_2 = g_p0_1;
            entered(once_job([=, g_p0_1_2 = std::move(g_p0_1_2)]() {
            return ({
                auto m_p3 = p0;
                auto n_p4 = p1;
                ({
                auto&& _m = crate::prelude::get(g_p0_1_2.types, n_p4);
                prism_rtl::is_some(_m) ? ({
                auto&& ti_p5 = prism_rtl::some_of(_m);
                call_value(fold_job(body_tys(ti_p5), Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc_p6 = p0;
                        auto t_p7 = p1;
                        call_then(start_ty_names_in(t_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> ty_names_in_3223) { return prism_rtl::finished(crate::check::types::union_texts(acc_p6, ty_names_in_3223)); });
                    });
                }));
            }))), [=](Array<Text> fold_3171) { return prism_rtl::finished(insert(m_p3, n_p4, fold_3171)); });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p3)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
    auto direct_p2 = run_to_end(fold_job(keys(g_p0.types), Map<Text, bool>{}, ({
        auto g_p0_1 = g_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, bool>>(std::tuple<Map<Text, bool>, Text>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1)](std::tuple<Map<Text, bool>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_2 = g_p0_1;
            entered(once_job([=, g_p0_1_2 = std::move(g_p0_1_2)]() {
            return ({
                auto m_p8 = p0;
                auto n_p9 = p1;
                ({
                auto&& _m = crate::prelude::get(g_p0_1_2.types, n_p9);
                prism_rtl::is_some(_m) ? ({
                auto&& ti_pa = prism_rtl::some_of(_m);
                call_value(fold_job(body_tys(ti_pa), false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto seen_pb = p0;
                        auto t_pc = p1;
                        (prism_rtl::finished(std::move(seen_pb) || has_arrow(t_pc)));
                    });
                }));
            }))), [=](bool fold_3337) {
                return fold_3337
                    ? prism_rtl::finished(insert(m_p8, n_p9, true))
                    : prism_rtl::finished(m_p8);
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p8)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
    return arrowy_from(names_p1, direct_p2);
}


prism_rtl::Turn<Map<Text, bool>> ArrowyTypes::cycle() const {
    const auto& g_p0 = this->g_p0;
    auto g_p0_1 = g_p0;
    return call_value(fold_job(keys(prism_rtl::deref(g_p0_1).types), Map<Text, Array<Text>>{}, ({
        auto g_p0_1_2 = g_p0_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=, g_p0_1_2 = std::move(g_p0_1_2)](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_2_2 = g_p0_1_2;
            entered(once_job([=, g_p0_1_2_2 = std::move(g_p0_1_2_2)]() {
            return ({
                auto m_p3 = p0;
                auto n_p4 = p1;
                ({
                auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0_1_2_2).types, n_p4);
                prism_rtl::is_some(_m) ? ({
                auto&& ti_p5 = prism_rtl::some_of(_m);
                call_value(fold_job(body_tys(ti_p5), Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc_p6 = p0;
                        auto t_p7 = p1;
                        call_then(start_ty_names_in(t_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> ty_names_in_3223) { return prism_rtl::finished(crate::check::types::union_texts(acc_p6, ty_names_in_3223)); });
                    });
                }));
            }))), [=](Array<Text> fold_3171) { return prism_rtl::finished(insert(m_p3, n_p4, fold_3171)); });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p3)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=](Map<Text, Array<Text>> fold_3092) {
        return ({
            auto names_p1 = fold_3092;
            call_value(fold_job(keys(prism_rtl::deref(g_p0_1).types), Map<Text, bool>{}, ({
            auto g_p0_1_2 = g_p0_1;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, bool>>(std::tuple<Map<Text, bool>, Text>)>>(prism_rtl::rc([=, g_p0_1_2 = std::move(g_p0_1_2)](std::tuple<Map<Text, bool>, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_p0_1_2_2 = g_p0_1_2;
                entered(once_job([=, g_p0_1_2_2 = std::move(g_p0_1_2_2)]() {
                return ({
                    auto m_p8 = p0;
                    auto n_p9 = p1;
                    ({
                    auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0_1_2_2).types, n_p9);
                    prism_rtl::is_some(_m) ? ({
                    auto&& ti_pa = prism_rtl::some_of(_m);
                    call_value(fold_job(body_tys(ti_pa), false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto seen_pb = p0;
                            auto t_pc = p1;
                            (prism_rtl::finished(std::move(seen_pb) || has_arrow(t_pc)));
                        });
                    }));
                }))), [=](bool fold_3337) {
                    return fold_3337
                        ? prism_rtl::finished(insert(m_p8, n_p9, true))
                        : prism_rtl::finished(m_p8);
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p8)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        }));
        })), [=, names_p1 = std::move(names_p1)](Map<Text, bool> fold_3269) {
            return ({
                auto direct_p2 = fold_3269;
                (prism_rtl::more(prism_rtl::rc(ArrowyFrom(names_p1, direct_p2))));
            });
        });
        });
    });
}


/// `Start ArrowyTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, bool>> start_arrowy_types(crate::check::env::G g_p0) {
    return prism_rtl::make_rc<ArrowyTypes>(g_p0);
}


/// ArrowyFrom: unbounded fn (Text ==> [Text]), (Text ==> Bool) -> (Text ==> Bool)
Map<Text, bool> arrowy_from(const Map<Text, Array<Text>>& names_p0, const Map<Text, bool>& got_p1) {
    auto next_p2 = fold(keys(names_p0), got_p1, [&](const Map<Text, bool>& m_p3, const Text& n_p4) {
        return crate::check::env::has_key(m_p3, n_p4)
            ? m_p3
            : fold(or_(crate::prelude::get(names_p0, n_p4), Array<Text>{}), false, [&](const bool& seen_p5, const Text& r_p6) { return prism_rtl::deref(seen_p5) || crate::check::env::has_key(got_p1, r_p6); })
            ? insert(m_p3, n_p4, true)
            : m_p3;
    });
    return len(keys(next_p2)) == len(keys(got_p1))
        ? got_p1
        : arrowy_from(names_p0, next_p2);
}


prism_rtl::Turn<Map<Text, bool>> ArrowyFrom::cycle() const {
    const auto& names_p0 = this->names_p0;
    const auto& got_p1 = this->got_p1;
    auto next_p2 = fold(keys(names_p0), got_p1, [&](const Map<Text, bool>& m_p3, const Text& n_p4) {
        return crate::check::env::has_key(m_p3, n_p4)
            ? m_p3
            : fold(or_(crate::prelude::get(names_p0, n_p4), Array<Text>{}), false, [&](const bool& seen_p5, const Text& r_p6) { return prism_rtl::deref(seen_p5) || crate::check::env::has_key(got_p1, r_p6); })
            ? insert(m_p3, n_p4, true)
            : m_p3;
    });
    return len(keys(next_p2)) == len(keys(got_p1))
        ? prism_rtl::finished(got_p1)
        : prism_rtl::more(prism_rtl::rc(ArrowyFrom(names_p0, next_p2)));
}


/// `Start ArrowyFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, bool>> start_arrowy_from(Map<Text, Array<Text>> names_p0, Map<Text, bool> got_p1) {
    return prism_rtl::make_rc<ArrowyFrom>(names_p0, got_p1);
}


/// TyNamesIn: unbounded fn Ty -> [Text]
Array<Text> ty_names_in(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0)) {
        auto&& c_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& args_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        return run_to_end(fold_job(args_p2, Array(std::vector{c_p1}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p3 = p0;
                    auto a_p4 = p1;
                    call_then(start_ty_names_in(a_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> ty_names_in_4019) { return prism_rtl::finished(crate::check::types::union_texts(acc_p3, ty_names_in_4019)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0)) {
        auto&& ps_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& res_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        return run_to_end(fold_job(ps_p5, ty_names_in(prism_rtl::deref(prism_rtl::deref(res_p6))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p7 = p0;
                    auto a_p8 = p1;
                    call_then(start_ty_names_in(a_p8), [=, acc_p7 = std::move(acc_p7)](Array<Text> ty_names_in_4111) { return prism_rtl::finished(crate::check::types::union_texts(acc_p7, ty_names_in_4111)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_p9 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return run_to_end(fold_job(ts_p9, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_pa = p0;
                    auto a_pb = p1;
                    call_then(start_ty_names_in(a_pb), [=, acc_pa = std::move(acc_pa)](Array<Text> ty_names_in_4182) { return prism_rtl::finished(crate::check::types::union_texts(acc_pa, ty_names_in_4182)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0)) {
        auto&& e_pc = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        return ty_names_in(prism_rtl::deref(prism_rtl::deref(e_pc)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0)) {
        auto&& k_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        return crate::check::types::union_texts(ty_names_in(prism_rtl::deref(prism_rtl::deref(k_pd))), ty_names_in(prism_rtl::deref(prism_rtl::deref(v_pe))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& i_pf = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return ty_names_in(prism_rtl::deref(prism_rtl::deref(i_pf)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0)) {
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        return ty_names_in(prism_rtl::deref(prism_rtl::deref(i_pg)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p0)) {
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a1;
        return ty_names_in(prism_rtl::deref(prism_rtl::deref(i_ph)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p0)) {
        auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p0).a1;
        return ty_names_in(prism_rtl::deref(prism_rtl::deref(i_pi)));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> TyNamesIn::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0) ? ({
        auto&& c_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& args_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        fold_job(args_p2, Array(std::vector{c_p1}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p3 = p0;
                auto a_p4 = p1;
                call_then(start_ty_names_in(a_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> ty_names_in_4019) { return prism_rtl::finished(crate::check::types::union_texts(acc_p3, ty_names_in_4019)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0) ? ({
        auto&& ps_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& res_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        ({
        auto ps_p5_1 = ps_p5;
        auto res_p6_2 = prism_rtl::deref(prism_rtl::deref(res_p6));
        call_then(start_ty_names_in(res_p6_2), [=, ps_p5_1 = std::move(ps_p5_1)](Array<Text> ty_names_in_4068) {
        return fold_job(ps_p5_1, ty_names_in_4068, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p7 = p0;
                    auto a_p8 = p1;
                    call_then(start_ty_names_in(a_p8), [=, acc_p7 = std::move(acc_p7)](Array<Text> ty_names_in_4111) { return prism_rtl::finished(crate::check::types::union_texts(acc_p7, ty_names_in_4111)); });
                });
            }));
        })))->cycle();
    });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0) ? ({
        auto&& ts_p9 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        fold_job(ts_p9, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_pa = p0;
                auto a_pb = p1;
                call_then(start_ty_names_in(a_pb), [=, acc_pa = std::move(acc_pa)](Array<Text> ty_names_in_4182) { return prism_rtl::finished(crate::check::types::union_texts(acc_pa, ty_names_in_4182)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0) ? ({
        auto&& e_pc = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(prism_rtl::deref(prism_rtl::deref(e_pc)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0) ? ({
        auto&& k_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        ({
        auto k_pd_1 = prism_rtl::deref(prism_rtl::deref(k_pd));
        auto v_pe_2 = prism_rtl::deref(prism_rtl::deref(v_pe));
        call_then(start_ty_names_in(k_pd_1), [=, v_pe_2 = std::move(v_pe_2)](Array<Text> ty_names_in_4250) { return call_then(start_ty_names_in(v_pe_2), [=](Array<Text> ty_names_in_4265) { return prism_rtl::finished(crate::check::types::union_texts(ty_names_in_4250, ty_names_in_4265)); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p0) ? ({
        auto&& i_pf = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(prism_rtl::deref(prism_rtl::deref(i_pf)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0) ? ({
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(prism_rtl::deref(prism_rtl::deref(i_pg)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p0) ? ({
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a1;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(prism_rtl::deref(prism_rtl::deref(i_ph)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p0) ? ({
        auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p0).a1;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(prism_rtl::deref(prism_rtl::deref(i_pi)))));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start TyNamesIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_ty_names_in(crate::check::types::Ty t_p0) {
    return prism_rtl::make_rc<TyNamesIn>(t_p0);
}


/// HasArrow: unbounded fn Ty -> Bool
bool has_arrow(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0)) {
        auto&& args_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        return run_to_end(fold_job(args_p1, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen_p2 = p0;
                    auto a_p3 = p1;
                    (prism_rtl::finished(std::move(seen_p2) || has_arrow(a_p3)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_p4 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return run_to_end(fold_job(ts_p4, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen_p5 = p0;
                    auto a_p6 = p1;
                    (prism_rtl::finished(std::move(seen_p5) || has_arrow(a_p6)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0)) {
        auto&& e_p7 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        return has_arrow(prism_rtl::deref(prism_rtl::deref(e_p7)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0)) {
        auto&& k_p8 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_p9 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        return has_arrow(prism_rtl::deref(prism_rtl::deref(k_p8))) || has_arrow(prism_rtl::deref(prism_rtl::deref(v_p9)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& i_pa = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return has_arrow(prism_rtl::deref(prism_rtl::deref(i_pa)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0)) {
        auto&& i_pb = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        return has_arrow(prism_rtl::deref(prism_rtl::deref(i_pb)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p0)) {
        auto&& i_pc = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a1;
        return has_arrow(prism_rtl::deref(prism_rtl::deref(i_pc)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p0)) {
        auto&& i_pd = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p0).a1;
        return has_arrow(prism_rtl::deref(prism_rtl::deref(i_pd)));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> HasArrow::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0) ? prism_rtl::finished(true)
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0) ? ({
        auto&& args_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        fold_job(args_p1, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen_p2 = p0;
                auto a_p3 = p1;
                (prism_rtl::finished(std::move(seen_p2) || has_arrow(a_p3)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0) ? ({
        auto&& ts_p4 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        fold_job(ts_p4, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen_p5 = p0;
                auto a_p6 = p1;
                (prism_rtl::finished(std::move(seen_p5) || has_arrow(a_p6)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0) ? ({
        auto&& e_p7 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(HasArrow(prism_rtl::deref(prism_rtl::deref(e_p7)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0) ? ({
        auto&& k_p8 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_p9 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        ({
        auto k_p8_1 = prism_rtl::deref(prism_rtl::deref(k_p8));
        auto v_p9_2 = prism_rtl::deref(prism_rtl::deref(v_p9));
        call_then(start_has_arrow(k_p8_1), [=, v_p9_2 = std::move(v_p9_2)](bool has_arrow_4707) { return prism_rtl::finished(has_arrow_4707 || has_arrow(v_p9_2)); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p0) ? ({
        auto&& i_pa = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        prism_rtl::more(prism_rtl::rc(HasArrow(prism_rtl::deref(prism_rtl::deref(i_pa)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0) ? ({
        auto&& i_pb = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(HasArrow(prism_rtl::deref(prism_rtl::deref(i_pb)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p0) ? ({
        auto&& i_pc = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a1;
        prism_rtl::more(prism_rtl::rc(HasArrow(prism_rtl::deref(prism_rtl::deref(i_pc)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p0) ? ({
        auto&& i_pd = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p0).a1;
        prism_rtl::more(prism_rtl::rc(HasArrow(prism_rtl::deref(prism_rtl::deref(i_pd)))));
    })
        : prism_rtl::finished(false);
    });
}


/// `Start HasArrow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_has_arrow(crate::check::types::Ty t_p0) {
    return prism_rtl::make_rc<HasArrow>(t_p0);
}


/// BodyTys: fn TyInfo -> [Ty]
Array<crate::check::types::Ty> body_tys(const crate::check::env::TyInfo& ti_p0) {
    auto&& _m = ti_p0.body;
    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
        auto&& fields_p1 = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
        return each(fields_p1, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& t_p2 = std::get<1>(_p0);
            return t_p2;
        });
    }
    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
        auto&& cases_p3 = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
        return fold(cases_p3, Array<crate::check::types::Ty>{}, [&](const Array<crate::check::types::Ty>& acc_p4, const std::tuple<Text, Array<crate::check::types::Ty>>& _p1) {
            auto&& args_p5 = std::get<1>(_p1);
            return append(acc_p4, args_p5);
        });
    }
    if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
        auto&& t_p6 = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
        return Array(std::vector{t_p6});
    }
    {
        return Array<crate::check::types::Ty>{};
    }
}


/// NegWalk: unbounded fn G, Text, Ty, Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
std::tuple<bool, Map<Text, bool>> neg_walk(const crate::check::env::G& g_p0, const Text& target_p1, const crate::check::types::Ty& t_p2, const bool& b_p3, const Map<Text, bool>& seen_p4) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2)) {
        auto&& c_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& args_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        return c_p5 == target_p1
            ? std::tuple{b_p3, seen_p4}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<bool, Map<Text, bool>>> _v;
            auto&& _m = crate::prelude::get(g_p0.types, c_p5);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_p7 = prism_rtl::some_of(_m);
                _v.set(({
                    auto sk_p8 = prism_rtl::cat(b_p3 ? Text::lit("-") : Text::lit("+"), crate::check::types::show_ty(crate::check::types::new_st(Nat(0u)), t_p2));
                    (crate::check::env::has_key(seen_p4, sk_p8)
                    ? std::tuple{false, seen_p4}
                    : len(keys(seen_p4)) > Nat(400u)
                    ? std::tuple{true, seen_p4}
                    : neg_walks(g_p0, target_p1, run_to_end(each_job(body_tys(ti_p7), ({
                    auto ti_p7_1 = ti_p7;
                    auto args_p6_2 = args_p6;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, ti_p7_1 = std::move(ti_p7_1), args_p6_2 = std::move(args_p6_2)](crate::check::types::Ty p0) {
                    return ({
                        auto ti_p7_1_3 = ti_p7_1;
                        auto args_p6_2_3 = args_p6_2;
                        entered(once_job([=, ti_p7_1_3 = std::move(ti_p7_1_3), args_p6_2_3 = std::move(args_p6_2_3)]() {
                        return ({
                            auto bt_p9 = p0;
                            (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(crate::check::env::reading::param_inst(prism_rtl::deref(ti_p7_1_3).params, args_p6_2_3), bt_p9))));
                        });
                    }));
                    });
                })));
                }))), b_p3, insert(seen_p4, sk_p8, true)));
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(neg_walks(g_p0, target_p1, args_p6, b_p3, seen_p4));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p2)) {
        auto&& col_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a0;
        auto&& ps_pb = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a1;
        auto&& res_pc = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a2;
        auto [bad_pd, seen2_pe] = neg_walks(g_p0, target_p1, ps_pb, b_p3 || (col_pa != crate::check::types::Col(crate::check::types::Col::CUnbound{})), seen_p4);
        return bad_pd
            ? std::tuple{true, seen2_pe}
            : neg_walk(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(res_pc)), b_p3, seen2_pe);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p2)) {
        auto&& ts_pf = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p2).a0;
        return neg_walks(g_p0, target_p1, ts_pf, b_p3, seen_p4);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p2)) {
        auto&& e_pg = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p2).a0;
        return neg_walk(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(e_pg)), b_p3, seen_p4);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p2)) {
        auto&& k_ph = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a0;
        auto&& v_pi = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a1;
        return neg_walks(g_p0, target_p1, Array(std::vector{prism_rtl::deref(prism_rtl::deref(k_ph)), prism_rtl::deref(prism_rtl::deref(v_pi))}), b_p3, seen_p4);
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p2)) {
        auto&& i_pj = prism_rtl::as<crate::check::types::Ty::TySig>(t_p2).a1;
        return neg_walk(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(i_pj)), b_p3, seen_p4);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p2)) {
        auto&& i_pk = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p2).a0;
        return neg_walk(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(i_pk)), b_p3, seen_p4);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p2)) {
        auto&& i_pl = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p2).a1;
        return neg_walk(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(i_pl)), b_p3, seen_p4);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p2)) {
        auto&& i_pm = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p2).a1;
        return neg_walk(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(i_pm)), b_p3, seen_p4);
    }
    {
        return std::tuple{false, seen_p4};
    }
}


prism_rtl::Turn<std::tuple<bool, Map<Text, bool>>> NegWalk::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& target_p1 = this->target_p1;
    const auto& t_p2 = this->t_p2;
    const auto& b_p3 = this->b_p3;
    const auto& seen_p4 = this->seen_p4;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2) ? ({
        auto&& c_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& args_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        c_p5 == target_p1
        ? prism_rtl::finished(std::tuple{prism_rtl::deref(b_p3), seen_p4})
        : ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).types, c_p5);
        prism_rtl::is_some(_m) ? ({
        auto&& ti_p7 = prism_rtl::some_of(_m);
        ({
        auto args_p6_1 = args_p6;
        auto b_p3_2 = prism_rtl::deref(b_p3);
        auto g_p0_3 = g_p0;
        auto seen_p4_4 = seen_p4;
        auto t_p2_5 = t_p2;
        auto target_p1_6 = target_p1;
        call_then(crate::check::types::start_show_ty(crate::check::types::new_st(Nat(0u)), t_p2_5), [=, args_p6_1 = std::move(args_p6_1), b_p3_2 = std::move(b_p3_2), g_p0_3 = std::move(g_p0_3), seen_p4_4 = std::move(seen_p4_4), target_p1_6 = std::move(target_p1_6)](Text show_ty_5844) {
        return ({
            auto sk_p8 = prism_rtl::cat(b_p3_2 ? Text::lit("-") : Text::lit("+"), show_ty_5844);
            (crate::check::env::has_key(seen_p4_4, sk_p8)
            ? prism_rtl::finished(std::tuple{false, seen_p4_4})
            : len(keys(seen_p4_4)) > Nat(400u)
            ? prism_rtl::finished(std::tuple{true, seen_p4_4})
            : call_value(each_job(body_tys(ti_p7), ({
            auto ti_p7_7 = ti_p7;
            auto args_p6_1_8 = args_p6_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, ti_p7_7 = std::move(ti_p7_7), args_p6_1_8 = std::move(args_p6_1_8)](crate::check::types::Ty p0) {
            return ({
                auto ti_p7_7_8 = ti_p7_7;
                auto args_p6_1_8_8 = args_p6_1_8;
                entered(once_job([=, ti_p7_7_8 = std::move(ti_p7_7_8), args_p6_1_8_8 = std::move(args_p6_1_8_8)]() {
                return ({
                    auto bt_p9 = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(crate::check::env::reading::param_inst(prism_rtl::deref(ti_p7_7_8).params, args_p6_1_8_8), bt_p9))));
                });
            }));
            });
        })));
        })), [=](Array<crate::check::types::Ty> each_6026) { return prism_rtl::more(prism_rtl::rc(NegWalks(g_p0_3, target_p1_6, each_6026, b_p3_2, insert(seen_p4_4, sk_p8, true)))); }));
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(NegWalks(g_p0, target_p1, args_p6, prism_rtl::deref(b_p3), seen_p4)))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p2) ? ({
        auto&& col_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a0;
        auto&& ps_pb = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a1;
        auto&& res_pc = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a2;
        ({
        auto b_p3_1 = prism_rtl::deref(b_p3);
        auto col_pa_2 = col_pa;
        auto g_p0_3 = g_p0;
        auto ps_pb_4 = ps_pb;
        auto res_pc_5 = prism_rtl::deref(prism_rtl::deref(res_pc));
        auto seen_p4_6 = seen_p4;
        auto target_p1_7 = target_p1;
        call_then(start_neg_walks(g_p0_3, target_p1_7, ps_pb_4, std::move(b_p3_1) || (col_pa_2 != crate::check::types::Col(crate::check::types::Col::CUnbound{})), seen_p4_6), [=, res_pc_5 = std::move(res_pc_5)](std::tuple<bool, Map<Text, bool>> neg_walks_6222) {
        return ({
            auto [bad_pd, seen2_pe] = neg_walks_6222;
            bad_pd
            ? prism_rtl::finished(std::tuple{true, seen2_pe})
            : prism_rtl::more(prism_rtl::rc(NegWalk(g_p0_3, target_p1_7, res_pc_5, b_p3_1, seen2_pe)));
        });
    });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p2) ? ({
        auto&& ts_pf = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p2).a0;
        prism_rtl::more(prism_rtl::rc(NegWalks(g_p0, target_p1, ts_pf, prism_rtl::deref(b_p3), seen_p4)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p2) ? ({
        auto&& e_pg = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p2).a0;
        prism_rtl::more(prism_rtl::rc(NegWalk(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(e_pg)), prism_rtl::deref(b_p3), seen_p4)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p2) ? ({
        auto&& k_ph = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a0;
        auto&& v_pi = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a1;
        prism_rtl::more(prism_rtl::rc(NegWalks(g_p0, target_p1, Array(std::vector{prism_rtl::deref(prism_rtl::deref(k_ph)), prism_rtl::deref(prism_rtl::deref(v_pi))}), prism_rtl::deref(b_p3), seen_p4)));
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p2) ? ({
        auto&& i_pj = prism_rtl::as<crate::check::types::Ty::TySig>(t_p2).a1;
        prism_rtl::more(prism_rtl::rc(NegWalk(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(i_pj)), prism_rtl::deref(b_p3), seen_p4)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p2) ? ({
        auto&& i_pk = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p2).a0;
        prism_rtl::more(prism_rtl::rc(NegWalk(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(i_pk)), prism_rtl::deref(b_p3), seen_p4)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p2) ? ({
        auto&& i_pl = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p2).a1;
        prism_rtl::more(prism_rtl::rc(NegWalk(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(i_pl)), prism_rtl::deref(b_p3), seen_p4)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p2) ? ({
        auto&& i_pm = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p2).a1;
        prism_rtl::more(prism_rtl::rc(NegWalk(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(i_pm)), prism_rtl::deref(b_p3), seen_p4)));
    })
        : prism_rtl::finished(std::tuple{false, seen_p4});
    });
}


/// `Start NegWalk, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>> start_neg_walk(crate::check::env::G g_p0, Text target_p1, crate::check::types::Ty t_p2, bool b_p3, Map<Text, bool> seen_p4) {
    return prism_rtl::make_rc<NegWalk>(g_p0, target_p1, t_p2, b_p3, seen_p4);
}


/// NegWalks: unbounded fn G, Text, [Ty], Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
std::tuple<bool, Map<Text, bool>> neg_walks(const crate::check::env::G& g_p0, const Text& target_p1, const Array<crate::check::types::Ty>& ts_p2, const bool& b_p3, const Map<Text, bool>& seen_p4) {
    return run_to_end(fold_job(ts_p2, std::tuple{false, seen_p4}, ({
        auto g_p0_1 = g_p0;
        auto target_p1_2 = target_p1;
        auto b_p3_3 = b_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>>(std::tuple<std::tuple<bool, Map<Text, bool>>, crate::check::types::Ty>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1), target_p1_2 = std::move(target_p1_2), b_p3_3 = std::move(b_p3_3)](std::tuple<std::tuple<bool, Map<Text, bool>>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_4 = g_p0_1;
            auto target_p1_2_4 = target_p1_2;
            auto b_p3_3_4 = b_p3_3;
            entered(once_job([=, g_p0_1_4 = std::move(g_p0_1_4), target_p1_2_4 = std::move(target_p1_2_4), b_p3_3_4 = std::move(b_p3_3_4)]() {
            return ({
                auto [bad_p5, sn_p6] = p0;
                auto t_p7 = p1;
                bad_p5
                ? prism_rtl::finished(std::tuple{true, sn_p6})
                : prism_rtl::more(prism_rtl::rc(NegWalk(g_p0_1_4, target_p1_2_4, t_p7, b_p3_3_4, sn_p6)));
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<bool, Map<Text, bool>>> NegWalks::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& target_p1 = this->target_p1;
    const auto& ts_p2 = this->ts_p2;
    const auto& b_p3 = this->b_p3;
    const auto& seen_p4 = this->seen_p4;
    return fold_job(ts_p2, std::tuple{false, seen_p4}, ({
        auto g_p0_1 = g_p0;
        auto target_p1_2 = target_p1;
        auto b_p3_3 = prism_rtl::deref(b_p3);
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>>(std::tuple<std::tuple<bool, Map<Text, bool>>, crate::check::types::Ty>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1), target_p1_2 = std::move(target_p1_2), b_p3_3 = std::move(b_p3_3)](std::tuple<std::tuple<bool, Map<Text, bool>>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_4 = g_p0_1;
            auto target_p1_2_4 = target_p1_2;
            auto b_p3_3_4 = b_p3_3;
            entered(once_job([=, g_p0_1_4 = std::move(g_p0_1_4), target_p1_2_4 = std::move(target_p1_2_4), b_p3_3_4 = std::move(b_p3_3_4)]() {
            return ({
                auto [bad_p5, sn_p6] = p0;
                auto t_p7 = p1;
                bad_p5
                ? prism_rtl::finished(std::tuple{true, sn_p6})
                : prism_rtl::more(prism_rtl::rc(NegWalk(g_p0_1_4, target_p1_2_4, t_p7, b_p3_3_4, sn_p6)));
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start NegWalks, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>> start_neg_walks(crate::check::env::G g_p0, Text target_p1, Array<crate::check::types::Ty> ts_p2, bool b_p3, Map<Text, bool> seen_p4) {
    return prism_rtl::make_rc<NegWalks>(g_p0, target_p1, ts_p2, b_p3, seen_p4);
}


/// NatMinusSeeds: unbounded fn St -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> nat_minus_seeds(const crate::check::types::St& st_p0) {
    return run_to_end(fold_job(keys(st_p0.size_tys), Map<Text, crate::check::shrink::Rel>{}, ({
        auto st_p0_1 = st_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Text>)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](std::tuple<Map<Text, crate::check::shrink::Rel>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_p0_1_2 = st_p0_1;
            entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
            return ({
                auto m_p1 = p0;
                auto k_p2 = p1;
                ({
                auto&& _m = crate::prelude::get(st_p0_1_2.size_tys, k_p2);
                prism_rtl::is_some(_m) ? ({
                auto&& t_p3 = prism_rtl::some_of(_m);
                call_then(crate::check::types::recording::start_zonk(st_p0_1_2, t_p3), [=](crate::check::types::Ty zonk_7185) {
                return zonk_7185 == crate::check::types::t_nat()
                    ? prism_rtl::finished(insert(m_p1, prism_rtl::cat("nat:", k_p2), crate::check::shrink::relations::no_rel()))
                    : prism_rtl::finished(m_p1);
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p1)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> NatMinusSeeds::cycle() const {
    const auto& st_p0 = this->st_p0;
    return fold_job(keys(prism_rtl::deref(st_p0).size_tys), Map<Text, crate::check::shrink::Rel>{}, ({
        auto st_p0_1 = st_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Text>)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](std::tuple<Map<Text, crate::check::shrink::Rel>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_p0_1_2 = st_p0_1;
            entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
            return ({
                auto m_p1 = p0;
                auto k_p2 = p1;
                ({
                auto&& _m = crate::prelude::get(prism_rtl::deref(st_p0_1_2).size_tys, k_p2);
                prism_rtl::is_some(_m) ? ({
                auto&& t_p3 = prism_rtl::some_of(_m);
                call_then(crate::check::types::recording::start_zonk(st_p0_1_2, t_p3), [=](crate::check::types::Ty zonk_7185) {
                return zonk_7185 == crate::check::types::t_nat()
                    ? prism_rtl::finished(insert(m_p1, prism_rtl::cat("nat:", k_p2), crate::check::shrink::relations::no_rel()))
                    : prism_rtl::finished(m_p1);
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p1)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start NatMinusSeeds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_nat_minus_seeds(crate::check::types::St st_p0) {
    return prism_rtl::make_rc<NatMinusSeeds>(st_p0);
}


/// DefClauses: fn Def -> [FnClause]
Array<crate::syntax::decls::FnClause> def_clauses(const crate::check::env::Def& d_p0) {
    auto&& _m = d_p0.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
        auto&& clauses_p1 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
        return clauses_p1;
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
        auto&& clauses_p2 = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a0;
        return clauses_p2;
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbDefault>(_m)) {
        auto&& clauses_p3 = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a0;
        return clauses_p3;
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
        auto&& w_p4 = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
        return Array(std::vector{crate::syntax::decls::FnClause{.name = crate::syntax::decls::DefName(crate::syntax::decls::DefName::DefSName{prism_rtl::deref(w_p4).name}), .params = Array<crate::syntax::Pattern_>{}, .body = crate::syntax::decls::FnBody(crate::syntax::decls::FnBody::BodyBlock{prism_rtl::deref(w_p4).body}), .span = prism_rtl::deref(w_p4).span}});
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
        auto&& l_p5 = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
        return Array(std::vector{crate::syntax::decls::FnClause{.name = crate::syntax::decls::DefName(crate::syntax::decls::DefName::DefOp{d_p0.name, prism_rtl::deref(l_p5).span}), .params = Array<crate::syntax::Pattern_>{}, .body = crate::syntax::decls::FnBody(crate::syntax::decls::FnBody::BodyExpr{l_p5->value}), .span = prism_rtl::deref(l_p5).span}});
    }
    {
        return Array<crate::syntax::decls::FnClause>{};
    }
}


/// OwnKey: fn Def -> Def
crate::check::env::Def own_key(const crate::check::env::Def& d_p0) {
    auto&& _m = d_p0.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
        auto&& im_p1 = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a2;
        crate::check::env::Def this_ = d_p0;
        this_.qk = prism_rtl::cat(d_p0.qk, " #", im_p1->file, ".", prism_rtl::deref(prism_rtl::deref(im_p1).span).start);
        return this_;
    }
    {
        return d_p0;
    }
}


/// ?MethodOf: fn G, Def -> ?Text
std::optional<Text> method_of(const crate::check::env::G& g_p0, const crate::check::env::Def& d_p1) {
    auto&& _m = d_p1.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
        auto&& cls_p2 = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a1;
        return crate::check::method_key(g_p0, cls_p2, d_p1.name);
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbDefault>(_m)) {
        auto&& cls_p3 = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a1;
        return crate::check::method_key(g_p0, cls_p3, d_p1.name);
    }
    {
        return std::optional<Text>{};
    }
}


/// MethodTargets: fn G, [Def] -> (Text ==> [Text])
Map<Text, Array<Text>> method_targets(const crate::check::env::G& g_p0, const Array<crate::check::env::Def>& fns_p1) {
    return fold(fns_p1, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m_p2, const crate::check::env::Def& d_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = method_of(g_p0, d_p3);
            if (prism_rtl::is_some(_m)) {
                auto&& mk_p4 = prism_rtl::some_of(_m);
                _v.set(insert(m_p2, mk_p4, crate::check::types::add_text(or_(crate::prelude::get(m_p2, mk_p4), Array<Text>{}), prism_rtl::deref(d_p3).qk)));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(m_p2);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// ImplDefs: fn G, [Def] -> (Text ==> Text)
Map<Text, Text> impl_defs(const crate::check::env::G& g_p0, const Array<crate::check::env::Def>& fns_p1) {
    return fold(fns_p1, Map<Text, Text>{}, [&](const Map<Text, Text>& m_p2, const crate::check::env::Def& d_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Text>> _v;
            auto&& _m = prism_rtl::deref(d_p3).body;
            if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
                auto&& im_p4 = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, Text>> _v;
                    auto&& _m = method_of(g_p0, d_p3);
                    if (prism_rtl::is_some(_m)) {
                        auto&& mk_p5 = prism_rtl::some_of(_m);
                        _v.set(insert(m_p2, prism_rtl::cat(mk_p5, "|", im_p4->file, ".", prism_rtl::deref(prism_rtl::deref(im_p4).span).start), prism_rtl::deref(d_p3).qk));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(m_p2);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(m_p2);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// ?MethodClass: fn G, Text -> ?Text
std::optional<Text> method_class(const crate::check::env::G& g_p0, const Text& k_p1) {
    auto&& _m = crate::prelude::get(g_p0.vals, k_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& v_p2 = prism_rtl::some_of(_m);
        return prism_rtl::deref(v_p2).sort != Text::lit("method")
            ? std::optional<Text>{}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            auto&& _m = index(prism_rtl::deref(prism_rtl::deref(v_p2).scheme).bounds, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& cls_p3 = std::get<1>(prism_rtl::some_of(_m));
                _v.set(std::optional(cls_p3));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// DispatchTargets: unbounded fn Shrink, Def, Site, Text -> [Text]
Array<Text> dispatch_targets(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const crate::check::shrink::walk::Site& site_p2, const Text& k_p3) {
    auto all_p4 = targets_of(sk_p0, k_p3);
    auto&& _m = method_class(sk_p0.g, k_p3);
    if (prism_rtl::is_none(_m)) {
        return all_p4;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& cls_p5 = prism_rtl::some_of(_m);
        auto ck_p6 = crate::check::types::recording::choice_key(d_p1.file, site_p2.span, cls_p5);
        auto&& _m = crate::prelude::get(sk_p0.choices, ck_p6);
        if (prism_rtl::is_none(_m)) {
            return all_p4;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& cs_p7 = prism_rtl::some_of(_m);
            return run_to_end(fold_job(cs_p7, Array<Text>{}, ({
                auto sk_p0_1 = sk_p0;
                auto k_p3_2 = k_p3;
                auto cls_p5_3 = cls_p5;
                auto all_p4_4 = all_p4;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, sk_p0_1 = std::move(sk_p0_1), k_p3_2 = std::move(k_p3_2), cls_p5_3 = std::move(cls_p5_3), all_p4_4 = std::move(all_p4_4)](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto sk_p0_1_5 = sk_p0_1;
                    auto k_p3_2_5 = k_p3_2;
                    auto cls_p5_3_5 = cls_p5_3;
                    auto all_p4_4_5 = all_p4_4;
                    entered(once_job([=, sk_p0_1_5 = std::move(sk_p0_1_5), k_p3_2_5 = std::move(k_p3_2_5), cls_p5_3_5 = std::move(cls_p5_3_5), all_p4_4_5 = std::move(all_p4_4_5)]() {
                    return ({
                        auto acc_p8 = p0;
                        auto ch_p9 = p1;
                        call_then(start_choice_targets(sk_p0_1_5, k_p3_2_5, cls_p5_3_5, all_p4_4_5, ch_p9, Array<Text>{}), [=, acc_p8 = std::move(acc_p8)](Array<Text> choice_targets_10578) { return prism_rtl::finished(crate::check::types::union_texts(acc_p8, choice_targets_10578)); });
                    });
                }));
                });
            })));
            })));
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> DispatchTargets::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& d_p1 = this->d_p1;
    const auto& site_p2 = this->site_p2;
    const auto& k_p3 = this->k_p3;
    auto all_p4 = targets_of(sk_p0, k_p3);
    return ({
        auto&& _m = method_class(prism_rtl::deref(sk_p0).g, k_p3);
        prism_rtl::is_none(_m) ? prism_rtl::finished(all_p4)
        : prism_rtl::is_some(_m) ? ({
        auto&& cls_p5 = prism_rtl::some_of(_m);
        ({
        auto ck_p6 = crate::check::types::recording::choice_key(d_p1->file, prism_rtl::deref(site_p2).span, cls_p5);
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(sk_p0).choices, ck_p6);
        prism_rtl::is_none(_m) ? prism_rtl::finished(all_p4)
        : prism_rtl::is_some(_m) ? ({
        auto&& cs_p7 = prism_rtl::some_of(_m);
        fold_job(cs_p7, Array<Text>{}, ({
        auto sk_p0_1 = sk_p0;
        auto k_p3_2 = k_p3;
        auto cls_p5_3 = cls_p5;
        auto all_p4_4 = all_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, sk_p0_1 = std::move(sk_p0_1), k_p3_2 = std::move(k_p3_2), cls_p5_3 = std::move(cls_p5_3), all_p4_4 = std::move(all_p4_4)](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0_1_5 = sk_p0_1;
            auto k_p3_2_5 = k_p3_2;
            auto cls_p5_3_5 = cls_p5_3;
            auto all_p4_4_5 = all_p4_4;
            entered(once_job([=, sk_p0_1_5 = std::move(sk_p0_1_5), k_p3_2_5 = std::move(k_p3_2_5), cls_p5_3_5 = std::move(cls_p5_3_5), all_p4_4_5 = std::move(all_p4_4_5)]() {
            return ({
                auto acc_p8 = p0;
                auto ch_p9 = p1;
                call_then(start_choice_targets(sk_p0_1_5, k_p3_2_5, cls_p5_3_5, all_p4_4_5, ch_p9, Array<Text>{}), [=, acc_p8 = std::move(acc_p8)](Array<Text> choice_targets_10578) { return prism_rtl::finished(crate::check::types::union_texts(acc_p8, choice_targets_10578)); });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start DispatchTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_dispatch_targets(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, crate::check::shrink::walk::Site site_p2, Text k_p3) {
    return prism_rtl::make_rc<DispatchTargets>(sk_p0, d_p1, site_p2, k_p3);
}


/// ChoiceTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
Array<Text> choice_targets(const crate::check::shrink::Shrink& sk_p0, const Text& k_p1, const Text& cls_p2, const Array<Text>& all_p3, const Text& ch_p4, const Array<Text>& seen_p5) {
    return ch_p4 == Text::lit("none")
        ? Array<Text>{}
        : crate::syntax::lexer::chars::has_prefix(ch_p4, Text::lit("impl:"))
        ? ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = crate::prelude::get(sk_p0.impl_defs, prism_rtl::cat(k_p1, "|", crate::syntax::lexer::chars::drop_prefix(ch_p4, Text::lit("impl:"))));
        if (prism_rtl::is_some(_m)) {
            auto&& q_p6 = prism_rtl::some_of(_m);
            _v.set(Array(std::vector{q_p6}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(filter(all_p3, [&](const Text& q_p7) { return q_p7 == k_p1; }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    })
        : crate::syntax::lexer::chars::has_prefix(ch_p4, Text::lit("derived:"))
        ? derived_targets(sk_p0, k_p1, cls_p2, all_p3, crate::syntax::lexer::chars::drop_prefix(ch_p4, Text::lit("derived:")), seen_p5)
        : all_p3;
}


prism_rtl::Turn<Array<Text>> ChoiceTargets::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& k_p1 = this->k_p1;
    const auto& cls_p2 = this->cls_p2;
    const auto& all_p3 = this->all_p3;
    const auto& ch_p4 = this->ch_p4;
    const auto& seen_p5 = this->seen_p5;
    return ch_p4 == Text::lit("none")
        ? prism_rtl::finished(Array<Text>{})
        : crate::syntax::lexer::chars::has_prefix(ch_p4, Text::lit("impl:"))
        ? ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(sk_p0).impl_defs, prism_rtl::cat(k_p1, "|", crate::syntax::lexer::chars::drop_prefix(ch_p4, Text::lit("impl:"))));
        prism_rtl::is_some(_m) ? ({
        auto&& q_p6 = prism_rtl::some_of(_m);
        prism_rtl::finished(Array(std::vector{q_p6}));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(filter(all_p3, [&](const Text& q_p7) { return q_p7 == k_p1; }))
        : throw prism_rtl::Panic("no arm matched");
    })
        : crate::syntax::lexer::chars::has_prefix(ch_p4, Text::lit("derived:"))
        ? prism_rtl::more(prism_rtl::rc(DerivedTargets(sk_p0, k_p1, cls_p2, all_p3, crate::syntax::lexer::chars::drop_prefix(ch_p4, Text::lit("derived:")), seen_p5)))
        : prism_rtl::finished(all_p3);
}


/// `Start ChoiceTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_choice_targets(crate::check::shrink::Shrink sk_p0, Text k_p1, Text cls_p2, Array<Text> all_p3, Text ch_p4, Array<Text> seen_p5) {
    return prism_rtl::make_rc<ChoiceTargets>(sk_p0, k_p1, cls_p2, all_p3, ch_p4, seen_p5);
}


/// DerivedTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
Array<Text> derived_targets(const crate::check::shrink::Shrink& sk_p0, const Text& k_p1, const Text& cls_p2, const Array<Text>& all_p3, const Text& n_p4, const Array<Text>& seen_p5) {
    return crate::check::types::has_text(seen_p5, n_p4)
        ? Array<Text>{}
        : ({
        auto tys_p6 = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(sk_p0.g).types, n_p4);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_p8 = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
                    auto&& _m = prism_rtl::deref(ti_p8).body;
                    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                        auto&& fields_p9 = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                        _v.set(each(fields_p9, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                            auto&& t_pa = std::get<1>(_p0);
                            return t_pa;
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                        auto&& cases_pb = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                        _v.set(fold(cases_pb, Array<crate::check::types::Ty>{}, [&](const Array<crate::check::types::Ty>& acc_pc, const std::tuple<Text, Array<crate::check::types::Ty>>& _p1) {
                            auto&& args_pd = std::get<1>(_p1);
                            return append(acc_pc, args_pd);
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
                        auto&& t_pe = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
                        _v.set(Array(std::vector{t_pe}));
                        goto _done;
                    }
                    {
                        _v.set(Array<crate::check::types::Ty>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::check::types::Ty>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto heads_p7 = fold(tys_p6, Array<Text>{}, [&](const Array<Text>& acc_pf, const crate::check::types::Ty& t_pg) { return crate::check::types::union_texts(acc_pf, ty_heads(t_pg)); });
        run_to_end(fold_job(heads_p7, Array<Text>{}, ({
        auto sk_p0_1 = sk_p0;
        auto k_p1_2 = k_p1;
        auto cls_p2_3 = cls_p2;
        auto all_p3_4 = all_p3;
        auto seen_p5_5 = seen_p5;
        auto n_p4_6 = n_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, sk_p0_1 = std::move(sk_p0_1), k_p1_2 = std::move(k_p1_2), cls_p2_3 = std::move(cls_p2_3), all_p3_4 = std::move(all_p3_4), seen_p5_5 = std::move(seen_p5_5), n_p4_6 = std::move(n_p4_6)](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0_1_7 = sk_p0_1;
            auto k_p1_2_7 = k_p1_2;
            auto cls_p2_3_7 = cls_p2_3;
            auto all_p3_4_7 = all_p3_4;
            auto seen_p5_5_7 = seen_p5_5;
            auto n_p4_6_7 = n_p4_6;
            entered(once_job([=, sk_p0_1_7 = std::move(sk_p0_1_7), k_p1_2_7 = std::move(k_p1_2_7), cls_p2_3_7 = std::move(cls_p2_3_7), all_p3_4_7 = std::move(all_p3_4_7), seen_p5_5_7 = std::move(seen_p5_5_7), n_p4_6_7 = std::move(n_p4_6_7)]() {
            return ({
                auto acc_ph = p0;
                auto h_pi = p1;
                (prism_rtl::finished(crate::check::types::union_texts(acc_ph, head_targets(sk_p0_1_7, k_p1_2_7, cls_p2_3_7, all_p3_4_7, h_pi, crate::prelude::push(seen_p5_5_7, n_p4_6_7)))));
            });
        }));
        });
    })));
    })));
    });
}


prism_rtl::Turn<Array<Text>> DerivedTargets::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& k_p1 = this->k_p1;
    const auto& cls_p2 = this->cls_p2;
    const auto& all_p3 = this->all_p3;
    const auto& n_p4 = this->n_p4;
    const auto& seen_p5 = this->seen_p5;
    return crate::check::types::has_text(seen_p5, n_p4)
        ? prism_rtl::finished(Array<Text>{})
        : ({
        auto tys_p6 = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(sk_p0).g).types, n_p4);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_p8 = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
                    auto&& _m = prism_rtl::deref(ti_p8).body;
                    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                        auto&& fields_p9 = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                        _v.set(each(fields_p9, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                            auto&& t_pa = std::get<1>(_p0);
                            return t_pa;
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                        auto&& cases_pb = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                        _v.set(fold(cases_pb, Array<crate::check::types::Ty>{}, [&](const Array<crate::check::types::Ty>& acc_pc, const std::tuple<Text, Array<crate::check::types::Ty>>& _p1) {
                            auto&& args_pd = std::get<1>(_p1);
                            return append(acc_pc, args_pd);
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
                        auto&& t_pe = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
                        _v.set(Array(std::vector{t_pe}));
                        goto _done;
                    }
                    {
                        _v.set(Array<crate::check::types::Ty>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::check::types::Ty>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto heads_p7 = fold(tys_p6, Array<Text>{}, [&](const Array<Text>& acc_pf, const crate::check::types::Ty& t_pg) { return crate::check::types::union_texts(acc_pf, ty_heads(t_pg)); });
        fold_job(heads_p7, Array<Text>{}, ({
        auto sk_p0_1 = sk_p0;
        auto k_p1_2 = k_p1;
        auto cls_p2_3 = cls_p2;
        auto all_p3_4 = all_p3;
        auto seen_p5_5 = seen_p5;
        auto n_p4_6 = n_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, sk_p0_1 = std::move(sk_p0_1), k_p1_2 = std::move(k_p1_2), cls_p2_3 = std::move(cls_p2_3), all_p3_4 = std::move(all_p3_4), seen_p5_5 = std::move(seen_p5_5), n_p4_6 = std::move(n_p4_6)](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0_1_7 = sk_p0_1;
            auto k_p1_2_7 = k_p1_2;
            auto cls_p2_3_7 = cls_p2_3;
            auto all_p3_4_7 = all_p3_4;
            auto seen_p5_5_7 = seen_p5_5;
            auto n_p4_6_7 = n_p4_6;
            entered(once_job([=, sk_p0_1_7 = std::move(sk_p0_1_7), k_p1_2_7 = std::move(k_p1_2_7), cls_p2_3_7 = std::move(cls_p2_3_7), all_p3_4_7 = std::move(all_p3_4_7), seen_p5_5_7 = std::move(seen_p5_5_7), n_p4_6_7 = std::move(n_p4_6_7)]() {
            return ({
                auto acc_ph = p0;
                auto h_pi = p1;
                (prism_rtl::finished(crate::check::types::union_texts(acc_ph, head_targets(sk_p0_1_7, k_p1_2_7, cls_p2_3_7, all_p3_4_7, h_pi, crate::prelude::push(seen_p5_5_7, n_p4_6_7)))));
            });
        }));
        });
    })));
    }))->cycle();
    });
}


/// `Start DerivedTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_derived_targets(crate::check::shrink::Shrink sk_p0, Text k_p1, Text cls_p2, Array<Text> all_p3, Text n_p4, Array<Text> seen_p5) {
    return prism_rtl::make_rc<DerivedTargets>(sk_p0, k_p1, cls_p2, all_p3, n_p4, seen_p5);
}


/// TyHeads: fn Ty -> [Text]
Array<Text> ty_heads(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& args_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        return fold(args_p2, Array(std::vector{n_p1}), [&](const Array<Text>& acc_p3, const crate::check::types::Ty& a_p4) { return crate::check::types::union_texts(acc_p3, ty_heads(a_p4)); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_p5 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return fold(ts_p5, Array<Text>{}, [&](const Array<Text>& acc_p6, const crate::check::types::Ty& a_p7) { return crate::check::types::union_texts(acc_p6, ty_heads(a_p7)); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0)) {
        auto&& e_p8 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        return ty_heads(prism_rtl::deref(prism_rtl::deref(e_p8)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0)) {
        auto&& a_p9 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& b_pa = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        return crate::check::types::union_texts(ty_heads(prism_rtl::deref(prism_rtl::deref(a_p9))), ty_heads(prism_rtl::deref(prism_rtl::deref(b_pa))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& i_pb = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return ty_heads(prism_rtl::deref(prism_rtl::deref(i_pb)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t_p0)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(t_p0)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p0)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p0)) {
        return Array<Text>{};
    }
    {
        return Array(std::vector{Text::lit("?")});
    }
}


/// HeadTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
Array<Text> head_targets(const crate::check::shrink::Shrink& sk_p0, const Text& k_p1, const Text& cls_p2, const Array<Text>& all_p3, const Text& h_p4, const Array<Text>& seen_p5) {
    return h_p4 == Text::lit("?")
        ? all_p3
        : crate::check::env::traits::builtin_has(cls_p2, h_p4) || crate::check::env::is_prim_type(h_p4)
        ? Array<Text>{}
        : ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = index(filter(or_(crate::prelude::get(prism_rtl::deref(sk_p0.g).impls, cls_p2), Array<crate::check::env::ImplInfo>{}), [&](const crate::check::env::ImplInfo& im_p6) { return head_key(prism_rtl::deref(im_p6).head) == std::optional(h_p4); }), Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& im_p7 = prism_rtl::some_of(_m);
            _v.set(choice_targets(sk_p0, k_p1, cls_p2, all_p3, crate::check::env::traits::impl_choice(im_p7), seen_p5));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(all_p3);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// ?HeadKey: fn Ty -> ?Text
std::optional<Text> head_key(const crate::check::types::Ty& ty0) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(ty0)) {
        auto&& n_p0 = prism_rtl::as<crate::check::types::Ty::TyCon>(ty0).a0;
        return std::optional(n_p0);
    }
    {
        return std::optional<Text>{};
    }
}


/// TargetsOf: fn Shrink, Text -> [Text]
Array<Text> targets_of(const crate::check::shrink::Shrink& sk_p0, const Text& k_p1) {
    return or_(crate::prelude::get(sk_p0.targets, k_p1), Array(std::vector{k_p1}));
}


/// SigKeyOf: fn Shrink, Text -> Text
Text sig_key_of(const crate::check::shrink::Shrink& sk_p0, const Text& k_p1) {
    auto&& _m = crate::prelude::get(sk_p0.by_key, k_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& d_p2 = prism_rtl::some_of(_m);
        return or_(method_of(sk_p0.g, d_p2), k_p1);
    }
    if (prism_rtl::is_none(_m)) {
        return k_p1;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ShownKey: fn Text -> Text
Text shown_key(const Text& k_p0) {
    return crate::check::types::bare_name(or_(index(split_on(or_(crate::syntax::lexer::chars::last(split_on(k_p0, Text::lit(" impl "))), k_p0), Text::lit(" #")), Nat(0u)), k_p0));
}


/// IsUnboundedKey: fn G, Text -> Bool
bool is_unbounded_key(const crate::check::env::G& g_p0, const Text& k_p1) {
    auto&& _m = crate::prelude::get(g_p0.vals, k_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& v_p2 = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p2).scheme).ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CUnbound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::check::shrink::types
