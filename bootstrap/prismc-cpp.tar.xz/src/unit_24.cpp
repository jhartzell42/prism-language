// The module `Check.Shrink.Types`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/shrink/types/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Shrink.Types`, from `target/bootstrap/cpp-src/prismc/check/shrink/types.prism`.
namespace crate::check::shrink::types {

/// NegativeTypes: unbounded fn G, St -> St
crate::check::types::St negative_types_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1) {
    auto arrowy_p2 = arrowy_types_f(g_p0);
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(g_p0.types_p), st_p1, ({
        auto g_p0x = g_p0;
        auto arrowy_p2x = arrowy_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=, g_p0x = std::move(g_p0x), arrowy_p2x = std::move(arrowy_p2x)](std::tuple<crate::check::types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0xy = g_p0x;
            auto arrowy_p2xy = arrowy_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, g_p0xy = std::move(g_p0xy), arrowy_p2xy = std::move(arrowy_p2xy)]() {
            return ({
                auto s_p3 = p0;
                auto n_p4 = p1;
                (prism_rtl::more(prism_rtl::rc(NegativeType(g_p0xy, s_p3, arrowy_p2xy, n_p4))));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> NegativeTypes::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    auto g_p0x = g_p0;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(start_arrowy_types_f(g_p0x), [=](Map<Text, bool> arrowy_types_f_1927) {
        return ({
            auto arrowy_p2 = arrowy_types_f_1927;
            (crate::prelude::fold_job(crate::prelude::keys(prism_rtl::deref(g_p0x).types_p), st_p1x, ({
            auto g_p0xx = g_p0x;
            auto arrowy_p2x = arrowy_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=, g_p0xx = std::move(g_p0xx), arrowy_p2x = std::move(arrowy_p2x)](std::tuple<crate::check::types::St, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_p0xxy = g_p0xx;
                auto arrowy_p2xy = arrowy_p2x;
                (crate::prelude::entered(crate::prelude::once_job([=, g_p0xxy = std::move(g_p0xxy), arrowy_p2xy = std::move(arrowy_p2xy)]() {
                return ({
                    auto s_p3 = p0;
                    auto n_p4 = p1;
                    (prism_rtl::more(prism_rtl::rc(NegativeType(g_p0xxy, s_p3, arrowy_p2xy, n_p4))));
                });
            })));
            });
        })));
        }))->cycle());
        });
    });
}


/// `Start NegativeTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_negative_types_f(crate::check::env::G g_p0, crate::check::types::St st_p1) {
    return prism_rtl::make_rc<NegativeTypes>(g_p0, st_p1);
}


/// NegativeType: unbounded fn G, St, (Text ==> Bool), Text -> St
crate::check::types::St negative_type_f(const crate::check::env::G& g_p0, const crate::check::types::St& s_p1, const Map<Text, bool>& arrowy_p2, const Text& n_p3) {
    auto&& _m = crate::prelude::get(g_p0.types_p, n_p3);
    if (prism_rtl::is_some(_m)) {
        auto&& ti_p4 = prism_rtl::some_of(_m);
        auto&& _neg_p5 = (prism_rtl::deref(ti_p4).file_p >= g_p0.prelude_from_p) || (!crate::check::env::has_key_f(arrowy_p2, n_p3))
            ? std::tuple{false, Map<Text, bool>{}}
            : neg_walks_f(g_p0, n_p3, body_tys_f(ti_p4), false, Map<Text, bool>{});
        auto&& neg_p5 = std::get<0>(_neg_p5);
        return !neg_p5
            ? s_p1
            : ({
            auto s0_p6 = ({
                crate::check::types::St this_ = s_p1;
                this_.file_p = prism_rtl::deref(ti_p4).file_p;
                (std::move(this_));
            });
            auto s1_p7 = crate::check::types::recording::err_fix_f(s0_p6, Text::lit("may-not-end"), prism_rtl::deref(ti_p4).span_p, prism_rtl::cat("`", crate::check::types::bare_name_f(n_p3), "` stands left of a function arrow in its own definition: a call through the function it holds is a cycle, and nothing in it shrinks"), prism_rtl::cat("keep `", crate::check::types::bare_name_f(n_p3), "` right of the arrow, or make the arrow `unbounded fn`, which makes every call through it unbounded"));
            ({
            crate::check::types::St this_ = s1_p7;
            this_.file_p = s_p1.file_p;
            (std::move(this_));
        });
        });
    }
    if (prism_rtl::is_none(_m)) {
        return s_p1;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> NegativeType::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& s_p1 = this->s_p1;
    const auto& arrowy_p2 = this->arrowy_p2;
    const auto& n_p3 = this->n_p3;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).types_p, n_p3);
        prism_rtl::is_some(_m) ? ({
        auto&& ti_p4 = prism_rtl::some_of(_m);
        ({
        auto&& _neg_p5 = (prism_rtl::deref(ti_p4).file_p >= prism_rtl::deref(g_p0).prelude_from_p) || (!crate::check::env::has_key_f(arrowy_p2, n_p3))
            ? std::tuple{false, Map<Text, bool>{}}
            : neg_walks_f(g_p0, n_p3, body_tys_f(ti_p4), false, Map<Text, bool>{});
        auto&& neg_p5 = std::get<0>(_neg_p5);
        !neg_p5
        ? prism_rtl::finished(s_p1)
        : ({
        auto s0_p6 = ({
            crate::check::types::St this_ = s_p1;
            this_.file_p = prism_rtl::deref(ti_p4).file_p;
            (std::move(this_));
        });
        auto s1_p7 = crate::check::types::recording::err_fix_f(s0_p6, Text::lit("may-not-end"), prism_rtl::deref(ti_p4).span_p, prism_rtl::cat("`", crate::check::types::bare_name_f(n_p3), "` stands left of a function arrow in its own definition: a call through the function it holds is a cycle, and nothing in it shrinks"), prism_rtl::cat("keep `", crate::check::types::bare_name_f(n_p3), "` right of the arrow, or make the arrow `unbounded fn`, which makes every call through it unbounded"));
        (prism_rtl::finished(({
        crate::check::types::St this_ = s1_p7;
        this_.file_p = prism_rtl::deref(s_p1).file_p;
        (std::move(this_));
    })));
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(s_p1)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start NegativeType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_negative_type_f(crate::check::env::G g_p0, crate::check::types::St s_p1, Map<Text, bool> arrowy_p2, Text n_p3) {
    return prism_rtl::make_rc<NegativeType>(g_p0, s_p1, arrowy_p2, n_p3);
}


/// ArrowyTypes: unbounded fn G -> (Text ==> Bool)
Map<Text, bool> arrowy_types_f(const crate::check::env::G& g_p0) {
    auto names_p1 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(g_p0.types_p), Map<Text, Array<Text>>{}, ({
        auto g_p0x = g_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=, g_p0x = std::move(g_p0x)](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0xy = g_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, g_p0xy = std::move(g_p0xy)]() {
            return ({
                auto m_p3 = p0;
                auto n_p4 = p1;
                ({
                auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0xy).types_p, n_p4);
                prism_rtl::is_some(_m) ? ({
                auto&& ti_p5 = prism_rtl::some_of(_m);
                crate::prelude::call_value(crate::prelude::fold_job(body_tys_f(ti_p5), Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto acc_p6 = p0;
                        auto t_p7 = p1;
                        (crate::prelude::call_then(start_ty_names_in_f(t_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> ty_names_in_f_3223) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p6, ty_names_in_f_3223)); }));
                    });
                }));
            }))), [=](Array<Text> fold_3171) { return prism_rtl::finished(crate::prelude::insert(m_p3, n_p4, fold_3171)); });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p3)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    })));
    auto direct_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(g_p0.types_p), Map<Text, bool>{}, ({
        auto g_p0x = g_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, bool>>(std::tuple<Map<Text, bool>, Text>)>>(prism_rtl::rc([=, g_p0x = std::move(g_p0x)](std::tuple<Map<Text, bool>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0xy = g_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, g_p0xy = std::move(g_p0xy)]() {
            return ({
                auto m_p8 = p0;
                auto n_p9 = p1;
                ({
                auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0xy).types_p, n_p9);
                prism_rtl::is_some(_m) ? ({
                auto&& ti_pa = prism_rtl::some_of(_m);
                crate::prelude::call_value(crate::prelude::fold_job(body_tys_f(ti_pa), false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto seen_pb = p0;
                        auto t_pc = p1;
                        (prism_rtl::finished(std::move(seen_pb) || has_arrow_f(t_pc)));
                    });
                }));
            }))), [=](bool fold_3337) {
                return fold_3337
                    ? prism_rtl::finished(crate::prelude::insert(m_p8, n_p9, true))
                    : prism_rtl::finished(m_p8);
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p8)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    })));
    return arrowy_from_f(names_p1, direct_p2);
}


prism_rtl::Turn<Map<Text, bool>> ArrowyTypes::cycle() const {
    const auto& g_p0 = this->g_p0;
    auto g_p0x = g_p0;
    return crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::keys(prism_rtl::deref(g_p0x).types_p), Map<Text, Array<Text>>{}, ({
        auto g_p0xx = g_p0x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=, g_p0xx = std::move(g_p0xx)](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0xxy = g_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, g_p0xxy = std::move(g_p0xxy)]() {
            return ({
                auto m_p3 = p0;
                auto n_p4 = p1;
                ({
                auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0xxy).types_p, n_p4);
                prism_rtl::is_some(_m) ? ({
                auto&& ti_p5 = prism_rtl::some_of(_m);
                crate::prelude::call_value(crate::prelude::fold_job(body_tys_f(ti_p5), Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto acc_p6 = p0;
                        auto t_p7 = p1;
                        (crate::prelude::call_then(start_ty_names_in_f(t_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> ty_names_in_f_3223) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p6, ty_names_in_f_3223)); }));
                    });
                }));
            }))), [=](Array<Text> fold_3171) { return prism_rtl::finished(crate::prelude::insert(m_p3, n_p4, fold_3171)); });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p3)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    })), [=](Map<Text, Array<Text>> fold_3092) {
        return ({
            auto names_p1 = fold_3092;
            (crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::keys(prism_rtl::deref(g_p0x).types_p), Map<Text, bool>{}, ({
            auto g_p0xx = g_p0x;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, bool>>(std::tuple<Map<Text, bool>, Text>)>>(prism_rtl::rc([=, g_p0xx = std::move(g_p0xx)](std::tuple<Map<Text, bool>, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_p0xxy = g_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, g_p0xxy = std::move(g_p0xxy)]() {
                return ({
                    auto m_p8 = p0;
                    auto n_p9 = p1;
                    ({
                    auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0xxy).types_p, n_p9);
                    prism_rtl::is_some(_m) ? ({
                    auto&& ti_pa = prism_rtl::some_of(_m);
                    crate::prelude::call_value(crate::prelude::fold_job(body_tys_f(ti_pa), false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return crate::prelude::entered(crate::prelude::once_job([=]() {
                        return ({
                            auto seen_pb = p0;
                            auto t_pc = p1;
                            (prism_rtl::finished(std::move(seen_pb) || has_arrow_f(t_pc)));
                        });
                    }));
                }))), [=](bool fold_3337) {
                    return fold_3337
                        ? prism_rtl::finished(crate::prelude::insert(m_p8, n_p9, true))
                        : prism_rtl::finished(m_p8);
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p8)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            })));
            });
        }));
        })), [=, names_p1 = std::move(names_p1)](Map<Text, bool> fold_3269) {
            return ({
                auto direct_p2 = fold_3269;
                (prism_rtl::more(prism_rtl::rc(ArrowyFrom(names_p1, direct_p2))));
            });
        }));
        });
    });
}


/// `Start ArrowyTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, bool>> start_arrowy_types_f(crate::check::env::G g_p0) {
    return prism_rtl::make_rc<ArrowyTypes>(g_p0);
}


/// ArrowyFrom: unbounded fn (Text ==> [Text]), (Text ==> Bool) -> (Text ==> Bool)
Map<Text, bool> arrowy_from_f(const Map<Text, Array<Text>>& names_p0, const Map<Text, bool>& got_p1) {
    auto next_p2 = crate::prelude::fold(crate::prelude::keys(names_p0), got_p1, [&](const Map<Text, bool>& m_p3, const Text& n_p4) {
        return crate::check::env::has_key_f(m_p3, n_p4)
            ? m_p3
            : crate::prelude::fold(crate::prelude::or_(crate::prelude::get(names_p0, n_p4), Array<Text>{}), false, [&](const bool& seen_p5, const Text& r_p6) { return prism_rtl::deref(seen_p5) || crate::check::env::has_key_f(got_p1, r_p6); })
            ? crate::prelude::insert(m_p3, n_p4, true)
            : m_p3;
    });
    return crate::prelude::len(crate::prelude::keys(next_p2)) == crate::prelude::len(crate::prelude::keys(got_p1))
        ? got_p1
        : arrowy_from_f(names_p0, next_p2);
}


prism_rtl::Turn<Map<Text, bool>> ArrowyFrom::cycle() const {
    const auto& names_p0 = this->names_p0;
    const auto& got_p1 = this->got_p1;
    auto next_p2 = crate::prelude::fold(crate::prelude::keys(names_p0), got_p1, [&](const Map<Text, bool>& m_p3, const Text& n_p4) {
        return crate::check::env::has_key_f(m_p3, n_p4)
            ? m_p3
            : crate::prelude::fold(crate::prelude::or_(crate::prelude::get(names_p0, n_p4), Array<Text>{}), false, [&](const bool& seen_p5, const Text& r_p6) { return prism_rtl::deref(seen_p5) || crate::check::env::has_key_f(got_p1, r_p6); })
            ? crate::prelude::insert(m_p3, n_p4, true)
            : m_p3;
    });
    return crate::prelude::len(crate::prelude::keys(next_p2)) == crate::prelude::len(crate::prelude::keys(got_p1))
        ? prism_rtl::finished(got_p1)
        : prism_rtl::more(prism_rtl::rc(ArrowyFrom(names_p0, next_p2)));
}


/// `Start ArrowyFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, bool>> start_arrowy_from_f(Map<Text, Array<Text>> names_p0, Map<Text, bool> got_p1) {
    return prism_rtl::make_rc<ArrowyFrom>(names_p0, got_p1);
}


/// TyNamesIn: unbounded fn Ty -> [Text]
Array<Text> ty_names_in_f(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0)) {
        auto&& c_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& args_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(args_p2, Array(std::vector{c_p1}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p3 = p0;
                    auto a_p4 = p1;
                    (crate::prelude::call_then(start_ty_names_in_f(a_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> ty_names_in_f_4019) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p3, ty_names_in_f_4019)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0)) {
        auto&& ps_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& res_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ps_p5, ty_names_in_f(prism_rtl::deref(prism_rtl::deref(res_p6))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p7 = p0;
                    auto a_p8 = p1;
                    (crate::prelude::call_then(start_ty_names_in_f(a_p8), [=, acc_p7 = std::move(acc_p7)](Array<Text> ty_names_in_f_4111) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p7, ty_names_in_f_4111)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_p9 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_p9, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_pa = p0;
                    auto a_pb = p1;
                    (crate::prelude::call_then(start_ty_names_in_f(a_pb), [=, acc_pa = std::move(acc_pa)](Array<Text> ty_names_in_f_4182) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_pa, ty_names_in_f_4182)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0)) {
        auto&& e_pc = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        return ty_names_in_f(prism_rtl::deref(prism_rtl::deref(e_pc)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0)) {
        auto&& k_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        return crate::check::types::union_texts_f(ty_names_in_f(prism_rtl::deref(prism_rtl::deref(k_pd))), ty_names_in_f(prism_rtl::deref(prism_rtl::deref(v_pe))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& i_pf = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return ty_names_in_f(prism_rtl::deref(prism_rtl::deref(i_pf)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0)) {
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        return ty_names_in_f(prism_rtl::deref(prism_rtl::deref(i_pg)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p0)) {
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a1;
        return ty_names_in_f(prism_rtl::deref(prism_rtl::deref(i_ph)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p0)) {
        auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p0).a1;
        return ty_names_in_f(prism_rtl::deref(prism_rtl::deref(i_pi)));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> TyNamesIn::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0) ? ({
        auto&& c_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& args_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        crate::prelude::fold_job(args_p2, Array(std::vector{c_p1}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p3 = p0;
                auto a_p4 = p1;
                (crate::prelude::call_then(start_ty_names_in_f(a_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> ty_names_in_f_4019) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p3, ty_names_in_f_4019)); }));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0) ? ({
        auto&& ps_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& res_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        ({
        auto ps_p5x = ps_p5;
        auto res_p6x = prism_rtl::deref(prism_rtl::deref(res_p6));
        (crate::prelude::call_then(start_ty_names_in_f(res_p6x), [=, ps_p5x = std::move(ps_p5x)](Array<Text> ty_names_in_f_4068) {
        return crate::prelude::fold_job(ps_p5x, ty_names_in_f_4068, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p7 = p0;
                    auto a_p8 = p1;
                    (crate::prelude::call_then(start_ty_names_in_f(a_p8), [=, acc_p7 = std::move(acc_p7)](Array<Text> ty_names_in_f_4111) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p7, ty_names_in_f_4111)); }));
                });
            }));
        })))->cycle();
    }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0) ? ({
        auto&& ts_p9 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        crate::prelude::fold_job(ts_p9, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_pa = p0;
                auto a_pb = p1;
                (crate::prelude::call_then(start_ty_names_in_f(a_pb), [=, acc_pa = std::move(acc_pa)](Array<Text> ty_names_in_f_4182) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_pa, ty_names_in_f_4182)); }));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0) ? ({
        auto&& e_pc = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(prism_rtl::deref(prism_rtl::deref(e_pc)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0) ? ({
        auto&& k_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        ({
        auto k_pdx = prism_rtl::deref(prism_rtl::deref(k_pd));
        auto v_pex = prism_rtl::deref(prism_rtl::deref(v_pe));
        (crate::prelude::call_then(start_ty_names_in_f(k_pdx), [=, v_pex = std::move(v_pex)](Array<Text> ty_names_in_f_4250) { return crate::prelude::call_then(start_ty_names_in_f(v_pex), [=](Array<Text> ty_names_in_f_4265) { return prism_rtl::finished(crate::check::types::union_texts_f(ty_names_in_f_4250, ty_names_in_f_4265)); }); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p0) ? ({
        auto&& i_pf = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(prism_rtl::deref(prism_rtl::deref(i_pf)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0) ? ({
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(prism_rtl::deref(prism_rtl::deref(i_pg)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p0) ? ({
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a1;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(prism_rtl::deref(prism_rtl::deref(i_ph)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p0) ? ({
        auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p0).a1;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(prism_rtl::deref(prism_rtl::deref(i_pi)))));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start TyNamesIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_ty_names_in_f(crate::check::types::Ty t_p0) {
    return prism_rtl::make_rc<TyNamesIn>(t_p0);
}


/// HasArrow: unbounded fn Ty -> Bool
bool has_arrow_f(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0)) {
        auto&& args_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(args_p1, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto seen_p2 = p0;
                    auto a_p3 = p1;
                    (prism_rtl::finished(std::move(seen_p2) || has_arrow_f(a_p3)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_p4 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_p4, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto seen_p5 = p0;
                    auto a_p6 = p1;
                    (prism_rtl::finished(std::move(seen_p5) || has_arrow_f(a_p6)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0)) {
        auto&& e_p7 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        return has_arrow_f(prism_rtl::deref(prism_rtl::deref(e_p7)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0)) {
        auto&& k_p8 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_p9 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        return has_arrow_f(prism_rtl::deref(prism_rtl::deref(k_p8))) || has_arrow_f(prism_rtl::deref(prism_rtl::deref(v_p9)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& i_pa = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return has_arrow_f(prism_rtl::deref(prism_rtl::deref(i_pa)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0)) {
        auto&& i_pb = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        return has_arrow_f(prism_rtl::deref(prism_rtl::deref(i_pb)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p0)) {
        auto&& i_pc = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a1;
        return has_arrow_f(prism_rtl::deref(prism_rtl::deref(i_pc)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p0)) {
        auto&& i_pd = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p0).a1;
        return has_arrow_f(prism_rtl::deref(prism_rtl::deref(i_pd)));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> HasArrow::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0) ? prism_rtl::finished(true)
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0) ? ({
        auto&& args_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        crate::prelude::fold_job(args_p1, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto seen_p2 = p0;
                auto a_p3 = p1;
                (prism_rtl::finished(std::move(seen_p2) || has_arrow_f(a_p3)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0) ? ({
        auto&& ts_p4 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        crate::prelude::fold_job(ts_p4, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto seen_p5 = p0;
                auto a_p6 = p1;
                (prism_rtl::finished(std::move(seen_p5) || has_arrow_f(a_p6)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0) ? ({
        auto&& e_p7 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(HasArrow(prism_rtl::deref(prism_rtl::deref(e_p7)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0) ? ({
        auto&& k_p8 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_p9 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        ({
        auto k_p8x = prism_rtl::deref(prism_rtl::deref(k_p8));
        auto v_p9x = prism_rtl::deref(prism_rtl::deref(v_p9));
        (crate::prelude::call_then(start_has_arrow_f(k_p8x), [=, v_p9x = std::move(v_p9x)](bool has_arrow_f_4707) { return prism_rtl::finished(has_arrow_f_4707 || has_arrow_f(v_p9x)); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p0) ? ({
        auto&& i_pa = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        prism_rtl::more(prism_rtl::rc(HasArrow(prism_rtl::deref(prism_rtl::deref(i_pa)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0) ? ({
        auto&& i_pb = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(HasArrow(prism_rtl::deref(prism_rtl::deref(i_pb)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p0) ? ({
        auto&& i_pc = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a1;
        prism_rtl::more(prism_rtl::rc(HasArrow(prism_rtl::deref(prism_rtl::deref(i_pc)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p0) ? ({
        auto&& i_pd = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p0).a1;
        prism_rtl::more(prism_rtl::rc(HasArrow(prism_rtl::deref(prism_rtl::deref(i_pd)))));
    })
        : prism_rtl::finished(false);
    });
}


/// `Start HasArrow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_has_arrow_f(crate::check::types::Ty t_p0) {
    return prism_rtl::make_rc<HasArrow>(t_p0);
}


/// BodyTys: fn TyInfo -> [Ty]
Array<crate::check::types::Ty> body_tys_f(const crate::check::env::TyInfo& ti_p0) {
    auto&& _m = ti_p0.body_p;
    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
        auto&& fields_p1 = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
        return crate::prelude::each(fields_p1, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& t_p2 = std::get<1>(_p0);
            return t_p2;
        });
    }
    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
        auto&& cases_p3 = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
        return crate::prelude::fold(cases_p3, Array<crate::check::types::Ty>{}, [&](const Array<crate::check::types::Ty>& acc_p4, const std::tuple<Text, Array<crate::check::types::Ty>>& _p1) {
            auto&& args_p5 = std::get<1>(_p1);
            return crate::prelude::append(acc_p4, args_p5);
        });
    }
    if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
        auto&& t_p6 = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
        return Array(std::vector{t_p6});
    }
    {
        return Array<crate::check::types::Ty>{};
    }
}


/// NegWalk: unbounded fn G, Text, Ty, Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
std::tuple<bool, Map<Text, bool>> neg_walk_f(const crate::check::env::G& g_p0, const Text& target_p1, const crate::check::types::Ty& t_p2, const bool& b_p3, const Map<Text, bool>& seen_p4) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2)) {
        auto&& c_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& args_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        return c_p5 == target_p1
            ? std::tuple{b_p3, seen_p4}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<bool, Map<Text, bool>>> _v;
            auto&& _m = crate::prelude::get(g_p0.types_p, c_p5);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_p7 = prism_rtl::some_of(_m);
                _v.set(({
                    auto sk_p8 = prism_rtl::cat(b_p3 ? Text::lit("-") : Text::lit("+"), crate::check::types::show_ty_f(crate::check::types::new_st_f(Nat(0u)), t_p2));
                    (crate::check::env::has_key_f(seen_p4, sk_p8)
                    ? std::tuple{false, seen_p4}
                    : crate::prelude::len(crate::prelude::keys(seen_p4)) > Nat(400u)
                    ? std::tuple{true, seen_p4}
                    : neg_walks_f(g_p0, target_p1, crate::prelude::run_to_end(crate::prelude::each_job(body_tys_f(ti_p7), ({
                    auto ti_p7x = ti_p7;
                    auto args_p6x = args_p6;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, ti_p7x = std::move(ti_p7x), args_p6x = std::move(args_p6x)](crate::check::types::Ty p0) {
                    return ({
                        auto ti_p7xy = ti_p7x;
                        auto args_p6xy = args_p6x;
                        (crate::prelude::entered(crate::prelude::once_job([=, ti_p7xy = std::move(ti_p7xy), args_p6xy = std::move(args_p6xy)]() {
                        return ({
                            auto bt_p9 = p0;
                            (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(crate::check::env::reading::param_inst_f(prism_rtl::deref(ti_p7xy).params_p, args_p6xy), bt_p9))));
                        });
                    })));
                    });
                })));
                }))), b_p3, crate::prelude::insert(seen_p4, sk_p8, true)));
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(neg_walks_f(g_p0, target_p1, args_p6, b_p3, seen_p4));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p2)) {
        auto&& col_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a0;
        auto&& ps_pb = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a1;
        auto&& res_pc = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a2;
        auto [bad_pd, seen2_pe] = neg_walks_f(g_p0, target_p1, ps_pb, b_p3 || (col_pa != crate::check::types::Col(crate::check::types::Col::CUnbound{})), seen_p4);
        return bad_pd
            ? std::tuple{true, seen2_pe}
            : neg_walk_f(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(res_pc)), b_p3, seen2_pe);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p2)) {
        auto&& ts_pf = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p2).a0;
        return neg_walks_f(g_p0, target_p1, ts_pf, b_p3, seen_p4);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p2)) {
        auto&& e_pg = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p2).a0;
        return neg_walk_f(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(e_pg)), b_p3, seen_p4);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p2)) {
        auto&& k_ph = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a0;
        auto&& v_pi = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a1;
        return neg_walks_f(g_p0, target_p1, Array(std::vector{prism_rtl::deref(prism_rtl::deref(k_ph)), prism_rtl::deref(prism_rtl::deref(v_pi))}), b_p3, seen_p4);
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p2)) {
        auto&& i_pj = prism_rtl::as<crate::check::types::Ty::TySig>(t_p2).a1;
        return neg_walk_f(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(i_pj)), b_p3, seen_p4);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p2)) {
        auto&& i_pk = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p2).a0;
        return neg_walk_f(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(i_pk)), b_p3, seen_p4);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p2)) {
        auto&& i_pl = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p2).a1;
        return neg_walk_f(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(i_pl)), b_p3, seen_p4);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p2)) {
        auto&& i_pm = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p2).a1;
        return neg_walk_f(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(i_pm)), b_p3, seen_p4);
    }
    {
        return std::tuple{false, seen_p4};
    }
}


prism_rtl::Turn<std::tuple<bool, Map<Text, bool>>> NegWalk::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& target_p1 = this->target_p1;
    const auto& t_p2 = this->t_p2;
    const auto& b_p3 = this->b_p3;
    const auto& seen_p4 = this->seen_p4;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2) ? ({
        auto&& c_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& args_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        c_p5 == target_p1
        ? prism_rtl::finished(std::tuple{prism_rtl::deref(b_p3), seen_p4})
        : ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).types_p, c_p5);
        prism_rtl::is_some(_m) ? ({
        auto&& ti_p7 = prism_rtl::some_of(_m);
        ({
        auto args_p6x = args_p6;
        auto b_p3x = prism_rtl::deref(b_p3);
        auto g_p0x = g_p0;
        auto seen_p4x = seen_p4;
        auto t_p2x = t_p2;
        auto target_p1x = target_p1;
        (crate::prelude::call_then(crate::check::types::start_show_ty_f(crate::check::types::new_st_f(Nat(0u)), t_p2x), [=, args_p6x = std::move(args_p6x), b_p3x = std::move(b_p3x), g_p0x = std::move(g_p0x), seen_p4x = std::move(seen_p4x), target_p1x = std::move(target_p1x)](Text show_ty_f_5844) {
        return ({
            auto sk_p8 = prism_rtl::cat(b_p3x ? Text::lit("-") : Text::lit("+"), show_ty_f_5844);
            (crate::check::env::has_key_f(seen_p4x, sk_p8)
            ? prism_rtl::finished(std::tuple{false, seen_p4x})
            : crate::prelude::len(crate::prelude::keys(seen_p4x)) > Nat(400u)
            ? prism_rtl::finished(std::tuple{true, seen_p4x})
            : crate::prelude::call_value(crate::prelude::each_job(body_tys_f(ti_p7), ({
            auto ti_p7x = ti_p7;
            auto args_p6xx = args_p6x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, ti_p7x = std::move(ti_p7x), args_p6xx = std::move(args_p6xx)](crate::check::types::Ty p0) {
            return ({
                auto ti_p7xy = ti_p7x;
                auto args_p6xxy = args_p6xx;
                (crate::prelude::entered(crate::prelude::once_job([=, ti_p7xy = std::move(ti_p7xy), args_p6xxy = std::move(args_p6xxy)]() {
                return ({
                    auto bt_p9 = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(crate::check::env::reading::param_inst_f(prism_rtl::deref(ti_p7xy).params_p, args_p6xxy), bt_p9))));
                });
            })));
            });
        })));
        })), [=](Array<crate::check::types::Ty> each_6026) { return prism_rtl::more(prism_rtl::rc(NegWalks(g_p0x, target_p1x, each_6026, b_p3x, crate::prelude::insert(seen_p4x, sk_p8, true)))); }));
        });
    }));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(NegWalks(g_p0, target_p1, args_p6, prism_rtl::deref(b_p3), seen_p4)))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p2) ? ({
        auto&& col_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a0;
        auto&& ps_pb = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a1;
        auto&& res_pc = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a2;
        ({
        auto b_p3x = prism_rtl::deref(b_p3);
        auto col_pax = col_pa;
        auto g_p0x = g_p0;
        auto ps_pbx = ps_pb;
        auto res_pcx = prism_rtl::deref(prism_rtl::deref(res_pc));
        auto seen_p4x = seen_p4;
        auto target_p1x = target_p1;
        (crate::prelude::call_then(start_neg_walks_f(g_p0x, target_p1x, ps_pbx, std::move(b_p3x) || (col_pax != crate::check::types::Col(crate::check::types::Col::CUnbound{})), seen_p4x), [=, res_pcx = std::move(res_pcx)](std::tuple<bool, Map<Text, bool>> neg_walks_f_6222) {
        return ({
            auto [bad_pd, seen2_pe] = neg_walks_f_6222;
            bad_pd
            ? prism_rtl::finished(std::tuple{true, seen2_pe})
            : prism_rtl::more(prism_rtl::rc(NegWalk(g_p0x, target_p1x, res_pcx, b_p3x, seen2_pe)));
        });
    }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p2) ? ({
        auto&& ts_pf = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p2).a0;
        prism_rtl::more(prism_rtl::rc(NegWalks(g_p0, target_p1, ts_pf, prism_rtl::deref(b_p3), seen_p4)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p2) ? ({
        auto&& e_pg = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p2).a0;
        prism_rtl::more(prism_rtl::rc(NegWalk(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(e_pg)), prism_rtl::deref(b_p3), seen_p4)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p2) ? ({
        auto&& k_ph = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a0;
        auto&& v_pi = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a1;
        prism_rtl::more(prism_rtl::rc(NegWalks(g_p0, target_p1, Array(std::vector{prism_rtl::deref(prism_rtl::deref(k_ph)), prism_rtl::deref(prism_rtl::deref(v_pi))}), prism_rtl::deref(b_p3), seen_p4)));
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p2) ? ({
        auto&& i_pj = prism_rtl::as<crate::check::types::Ty::TySig>(t_p2).a1;
        prism_rtl::more(prism_rtl::rc(NegWalk(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(i_pj)), prism_rtl::deref(b_p3), seen_p4)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p2) ? ({
        auto&& i_pk = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p2).a0;
        prism_rtl::more(prism_rtl::rc(NegWalk(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(i_pk)), prism_rtl::deref(b_p3), seen_p4)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p2) ? ({
        auto&& i_pl = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p2).a1;
        prism_rtl::more(prism_rtl::rc(NegWalk(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(i_pl)), prism_rtl::deref(b_p3), seen_p4)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p2) ? ({
        auto&& i_pm = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p2).a1;
        prism_rtl::more(prism_rtl::rc(NegWalk(g_p0, target_p1, prism_rtl::deref(prism_rtl::deref(i_pm)), prism_rtl::deref(b_p3), seen_p4)));
    })
        : prism_rtl::finished(std::tuple{false, seen_p4});
    });
}


/// `Start NegWalk, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>> start_neg_walk_f(crate::check::env::G g_p0, Text target_p1, crate::check::types::Ty t_p2, bool b_p3, Map<Text, bool> seen_p4) {
    return prism_rtl::make_rc<NegWalk>(g_p0, target_p1, t_p2, b_p3, seen_p4);
}


/// NegWalks: unbounded fn G, Text, [Ty], Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
std::tuple<bool, Map<Text, bool>> neg_walks_f(const crate::check::env::G& g_p0, const Text& target_p1, const Array<crate::check::types::Ty>& ts_p2, const bool& b_p3, const Map<Text, bool>& seen_p4) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(ts_p2, std::tuple{false, seen_p4}, ({
        auto g_p0x = g_p0;
        auto target_p1x = target_p1;
        auto b_p3x = b_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>>(std::tuple<std::tuple<bool, Map<Text, bool>>, crate::check::types::Ty>)>>(prism_rtl::rc([=, g_p0x = std::move(g_p0x), target_p1x = std::move(target_p1x), b_p3x = std::move(b_p3x)](std::tuple<std::tuple<bool, Map<Text, bool>>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0xy = g_p0x;
            auto target_p1xy = target_p1x;
            auto b_p3xy = b_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, g_p0xy = std::move(g_p0xy), target_p1xy = std::move(target_p1xy), b_p3xy = std::move(b_p3xy)]() {
            return ({
                auto [bad_p5, sn_p6] = p0;
                auto t_p7 = p1;
                bad_p5
                ? prism_rtl::finished(std::tuple{true, sn_p6})
                : prism_rtl::more(prism_rtl::rc(NegWalk(g_p0xy, target_p1xy, t_p7, b_p3xy, sn_p6)));
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<bool, Map<Text, bool>>> NegWalks::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& target_p1 = this->target_p1;
    const auto& ts_p2 = this->ts_p2;
    const auto& b_p3 = this->b_p3;
    const auto& seen_p4 = this->seen_p4;
    return crate::prelude::fold_job(ts_p2, std::tuple{false, seen_p4}, ({
        auto g_p0x = g_p0;
        auto target_p1x = target_p1;
        auto b_p3x = prism_rtl::deref(b_p3);
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>>(std::tuple<std::tuple<bool, Map<Text, bool>>, crate::check::types::Ty>)>>(prism_rtl::rc([=, g_p0x = std::move(g_p0x), target_p1x = std::move(target_p1x), b_p3x = std::move(b_p3x)](std::tuple<std::tuple<bool, Map<Text, bool>>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0xy = g_p0x;
            auto target_p1xy = target_p1x;
            auto b_p3xy = b_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, g_p0xy = std::move(g_p0xy), target_p1xy = std::move(target_p1xy), b_p3xy = std::move(b_p3xy)]() {
            return ({
                auto [bad_p5, sn_p6] = p0;
                auto t_p7 = p1;
                bad_p5
                ? prism_rtl::finished(std::tuple{true, sn_p6})
                : prism_rtl::more(prism_rtl::rc(NegWalk(g_p0xy, target_p1xy, t_p7, b_p3xy, sn_p6)));
            });
        })));
        });
    }));
    }))->cycle();
}


/// `Start NegWalks, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>> start_neg_walks_f(crate::check::env::G g_p0, Text target_p1, Array<crate::check::types::Ty> ts_p2, bool b_p3, Map<Text, bool> seen_p4) {
    return prism_rtl::make_rc<NegWalks>(g_p0, target_p1, ts_p2, b_p3, seen_p4);
}


/// NatMinusSeeds: unbounded fn St -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> nat_minus_seeds_f(const crate::check::types::St& st_p0) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(st_p0.size_tys_p), Map<Text, crate::check::shrink::Rel>{}, ({
        auto st_p0x = st_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Text>)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](std::tuple<Map<Text, crate::check::shrink::Rel>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_p0xy = st_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
            return ({
                auto m_p1 = p0;
                auto k_p2 = p1;
                ({
                auto&& _m = crate::prelude::get(prism_rtl::deref(st_p0xy).size_tys_p, k_p2);
                prism_rtl::is_some(_m) ? ({
                auto&& t_p3 = prism_rtl::some_of(_m);
                crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p0xy, t_p3), [=](crate::check::types::Ty zonk_f_7185) {
                return zonk_f_7185 == crate::check::types::t_nat_p()
                    ? prism_rtl::finished(crate::prelude::insert(m_p1, prism_rtl::cat("nat:", k_p2), crate::check::shrink::relations::no_rel_p()))
                    : prism_rtl::finished(m_p1);
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p1)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> NatMinusSeeds::cycle() const {
    const auto& st_p0 = this->st_p0;
    return crate::prelude::fold_job(crate::prelude::keys(prism_rtl::deref(st_p0).size_tys_p), Map<Text, crate::check::shrink::Rel>{}, ({
        auto st_p0x = st_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Text>)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](std::tuple<Map<Text, crate::check::shrink::Rel>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_p0xy = st_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
            return ({
                auto m_p1 = p0;
                auto k_p2 = p1;
                ({
                auto&& _m = crate::prelude::get(prism_rtl::deref(st_p0xy).size_tys_p, k_p2);
                prism_rtl::is_some(_m) ? ({
                auto&& t_p3 = prism_rtl::some_of(_m);
                crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p0xy, t_p3), [=](crate::check::types::Ty zonk_f_7185) {
                return zonk_f_7185 == crate::check::types::t_nat_p()
                    ? prism_rtl::finished(crate::prelude::insert(m_p1, prism_rtl::cat("nat:", k_p2), crate::check::shrink::relations::no_rel_p()))
                    : prism_rtl::finished(m_p1);
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p1)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    }))->cycle();
}


/// `Start NatMinusSeeds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_nat_minus_seeds_f(crate::check::types::St st_p0) {
    return prism_rtl::make_rc<NatMinusSeeds>(st_p0);
}


/// DefClauses: fn Def -> [FnClause]
Array<crate::syntax::decls::FnClause> def_clauses_f(const crate::check::env::Def& d_p0) {
    auto&& _m = d_p0.body_p;
    if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
        auto&& clauses_p1 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
        return clauses_p1;
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
        auto&& clauses_p2 = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a0;
        return clauses_p2;
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbDefault>(_m)) {
        auto&& clauses_p3 = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a0;
        return clauses_p3;
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
        auto&& w_p4 = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
        return Array(std::vector{crate::syntax::decls::FnClause{.name_p = crate::syntax::decls::DefName(crate::syntax::decls::DefName::DefSName{prism_rtl::deref(w_p4).name_p}), .params_p = Array<crate::syntax::Pattern_>{}, .body_p = crate::syntax::decls::FnBody(crate::syntax::decls::FnBody::BodyBlock{prism_rtl::deref(w_p4).body_p}), .span_p = prism_rtl::deref(w_p4).span_p}});
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
        auto&& l_p5 = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
        return Array(std::vector{crate::syntax::decls::FnClause{.name_p = crate::syntax::decls::DefName(crate::syntax::decls::DefName::DefOp{d_p0.name_p, prism_rtl::deref(l_p5).span_p}), .params_p = Array<crate::syntax::Pattern_>{}, .body_p = crate::syntax::decls::FnBody(crate::syntax::decls::FnBody::BodyExpr{prism_rtl::deref(l_p5).value_p}), .span_p = prism_rtl::deref(l_p5).span_p}});
    }
    {
        return Array<crate::syntax::decls::FnClause>{};
    }
}


/// OwnKey: fn Def -> Def
crate::check::env::Def own_key_f(const crate::check::env::Def& d_p0) {
    auto&& _m = d_p0.body_p;
    if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
        auto&& im_p1 = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a2;
        crate::check::env::Def this_ = d_p0;
        this_.qk_p = prism_rtl::cat(d_p0.qk_p, " #", prism_rtl::deref(im_p1).file_p, ".", prism_rtl::deref(prism_rtl::deref(im_p1).span_p).start_p);
        return this_;
    }
    {
        return d_p0;
    }
}


/// ?MethodOf: fn G, Def -> ?Text
std::optional<Text> method_of_o(const crate::check::env::G& g_p0, const crate::check::env::Def& d_p1) {
    auto&& _m = d_p1.body_p;
    if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
        auto&& cls_p2 = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a1;
        return crate::check::method_key_o(g_p0, cls_p2, d_p1.name_p);
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbDefault>(_m)) {
        auto&& cls_p3 = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a1;
        return crate::check::method_key_o(g_p0, cls_p3, d_p1.name_p);
    }
    {
        return std::optional<Text>{};
    }
}


/// MethodTargets: fn G, [Def] -> (Text ==> [Text])
Map<Text, Array<Text>> method_targets_f(const crate::check::env::G& g_p0, const Array<crate::check::env::Def>& fns_p1) {
    return crate::prelude::fold(fns_p1, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m_p2, const crate::check::env::Def& d_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = method_of_o(g_p0, d_p3);
            if (prism_rtl::is_some(_m)) {
                auto&& mk_p4 = prism_rtl::some_of(_m);
                _v.set(crate::prelude::insert(m_p2, mk_p4, crate::check::types::add_text_f(crate::prelude::or_(crate::prelude::get(m_p2, mk_p4), Array<Text>{}), prism_rtl::deref(d_p3).qk_p)));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(m_p2);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// ImplDefs: fn G, [Def] -> (Text ==> Text)
Map<Text, Text> impl_defs_f(const crate::check::env::G& g_p0, const Array<crate::check::env::Def>& fns_p1) {
    return crate::prelude::fold(fns_p1, Map<Text, Text>{}, [&](const Map<Text, Text>& m_p2, const crate::check::env::Def& d_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Text>> _v;
            auto&& _m = prism_rtl::deref(d_p3).body_p;
            if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
                auto&& im_p4 = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, Text>> _v;
                    auto&& _m = method_of_o(g_p0, d_p3);
                    if (prism_rtl::is_some(_m)) {
                        auto&& mk_p5 = prism_rtl::some_of(_m);
                        _v.set(crate::prelude::insert(m_p2, prism_rtl::cat(mk_p5, "|", prism_rtl::deref(im_p4).file_p, ".", prism_rtl::deref(prism_rtl::deref(im_p4).span_p).start_p), prism_rtl::deref(d_p3).qk_p));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(m_p2);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(m_p2);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// ?MethodClass: fn G, Text -> ?Text
std::optional<Text> method_class_o(const crate::check::env::G& g_p0, const Text& k_p1) {
    auto&& _m = crate::prelude::get(g_p0.vals_p, k_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& v_p2 = prism_rtl::some_of(_m);
        return prism_rtl::deref(v_p2).sort_p != Text::lit("method")
            ? std::optional<Text>{}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            auto&& _m = crate::prelude::index(prism_rtl::deref(prism_rtl::deref(v_p2).scheme_p).bounds_p, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& cls_p3 = std::get<1>(prism_rtl::some_of(_m));
                _v.set(std::optional(cls_p3));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// DispatchTargets: unbounded fn Shrink, Def, Site, Text -> [Text]
Array<Text> dispatch_targets_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const crate::check::shrink::walk::Site& site_p2, const Text& k_p3) {
    auto all_p4 = targets_of_f(sk_p0, k_p3);
    auto&& _m = method_class_o(sk_p0.g_p, k_p3);
    if (prism_rtl::is_none(_m)) {
        return all_p4;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& cls_p5 = prism_rtl::some_of(_m);
        auto ck_p6 = crate::check::types::recording::choice_key_f(d_p1.file_p, site_p2.span_p, cls_p5);
        auto&& _m = crate::prelude::get(sk_p0.choices_p, ck_p6);
        if (prism_rtl::is_none(_m)) {
            return all_p4;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& cs_p7 = prism_rtl::some_of(_m);
            return crate::prelude::run_to_end(crate::prelude::fold_job(cs_p7, Array<Text>{}, ({
                auto sk_p0x = sk_p0;
                auto k_p3x = k_p3;
                auto cls_p5x = cls_p5;
                auto all_p4x = all_p4;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, sk_p0x = std::move(sk_p0x), k_p3x = std::move(k_p3x), cls_p5x = std::move(cls_p5x), all_p4x = std::move(all_p4x)](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto sk_p0xy = sk_p0x;
                    auto k_p3xy = k_p3x;
                    auto cls_p5xy = cls_p5x;
                    auto all_p4xy = all_p4x;
                    (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xy = std::move(sk_p0xy), k_p3xy = std::move(k_p3xy), cls_p5xy = std::move(cls_p5xy), all_p4xy = std::move(all_p4xy)]() {
                    return ({
                        auto acc_p8 = p0;
                        auto ch_p9 = p1;
                        (crate::prelude::call_then(start_choice_targets_f(sk_p0xy, k_p3xy, cls_p5xy, all_p4xy, ch_p9, Array<Text>{}), [=, acc_p8 = std::move(acc_p8)](Array<Text> choice_targets_f_10578) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p8, choice_targets_f_10578)); }));
                    });
                })));
                });
            })));
            })));
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> DispatchTargets::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& d_p1 = this->d_p1;
    const auto& site_p2 = this->site_p2;
    const auto& k_p3 = this->k_p3;
    auto all_p4 = targets_of_f(sk_p0, k_p3);
    return ({
        auto&& _m = method_class_o(prism_rtl::deref(sk_p0).g_p, k_p3);
        prism_rtl::is_none(_m) ? prism_rtl::finished(all_p4)
        : prism_rtl::is_some(_m) ? ({
        auto&& cls_p5 = prism_rtl::some_of(_m);
        ({
        auto ck_p6 = crate::check::types::recording::choice_key_f(prism_rtl::deref(d_p1).file_p, prism_rtl::deref(site_p2).span_p, cls_p5);
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(sk_p0).choices_p, ck_p6);
        prism_rtl::is_none(_m) ? prism_rtl::finished(all_p4)
        : prism_rtl::is_some(_m) ? ({
        auto&& cs_p7 = prism_rtl::some_of(_m);
        crate::prelude::fold_job(cs_p7, Array<Text>{}, ({
        auto sk_p0x = sk_p0;
        auto k_p3x = k_p3;
        auto cls_p5x = cls_p5;
        auto all_p4x = all_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, sk_p0x = std::move(sk_p0x), k_p3x = std::move(k_p3x), cls_p5x = std::move(cls_p5x), all_p4x = std::move(all_p4x)](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0xy = sk_p0x;
            auto k_p3xy = k_p3x;
            auto cls_p5xy = cls_p5x;
            auto all_p4xy = all_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xy = std::move(sk_p0xy), k_p3xy = std::move(k_p3xy), cls_p5xy = std::move(cls_p5xy), all_p4xy = std::move(all_p4xy)]() {
            return ({
                auto acc_p8 = p0;
                auto ch_p9 = p1;
                (crate::prelude::call_then(start_choice_targets_f(sk_p0xy, k_p3xy, cls_p5xy, all_p4xy, ch_p9, Array<Text>{}), [=, acc_p8 = std::move(acc_p8)](Array<Text> choice_targets_f_10578) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p8, choice_targets_f_10578)); }));
            });
        })));
        });
    })));
    }))->cycle();
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start DispatchTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_dispatch_targets_f(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, crate::check::shrink::walk::Site site_p2, Text k_p3) {
    return prism_rtl::make_rc<DispatchTargets>(sk_p0, d_p1, site_p2, k_p3);
}


/// ChoiceTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
Array<Text> choice_targets_f(const crate::check::shrink::Shrink& sk_p0, const Text& k_p1, const Text& cls_p2, const Array<Text>& all_p3, const Text& ch_p4, const Array<Text>& seen_p5) {
    return ch_p4 == Text::lit("none")
        ? Array<Text>{}
        : crate::syntax::lexer::chars::has_prefix_f(ch_p4, Text::lit("impl:"))
        ? ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = crate::prelude::get(sk_p0.impl_defs_p, prism_rtl::cat(k_p1, "|", crate::syntax::lexer::chars::drop_prefix_f(ch_p4, Text::lit("impl:"))));
        if (prism_rtl::is_some(_m)) {
            auto&& q_p6 = prism_rtl::some_of(_m);
            _v.set(Array(std::vector{q_p6}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::prelude::filter(all_p3, [&](const Text& q_p7) { return q_p7 == k_p1; }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    })
        : crate::syntax::lexer::chars::has_prefix_f(ch_p4, Text::lit("derived:"))
        ? derived_targets_f(sk_p0, k_p1, cls_p2, all_p3, crate::syntax::lexer::chars::drop_prefix_f(ch_p4, Text::lit("derived:")), seen_p5)
        : all_p3;
}


prism_rtl::Turn<Array<Text>> ChoiceTargets::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& k_p1 = this->k_p1;
    const auto& cls_p2 = this->cls_p2;
    const auto& all_p3 = this->all_p3;
    const auto& ch_p4 = this->ch_p4;
    const auto& seen_p5 = this->seen_p5;
    return ch_p4 == Text::lit("none")
        ? prism_rtl::finished(Array<Text>{})
        : crate::syntax::lexer::chars::has_prefix_f(ch_p4, Text::lit("impl:"))
        ? ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(sk_p0).impl_defs_p, prism_rtl::cat(k_p1, "|", crate::syntax::lexer::chars::drop_prefix_f(ch_p4, Text::lit("impl:"))));
        prism_rtl::is_some(_m) ? ({
        auto&& q_p6 = prism_rtl::some_of(_m);
        prism_rtl::finished(Array(std::vector{q_p6}));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::prelude::filter(all_p3, [&](const Text& q_p7) { return q_p7 == k_p1; }))
        : throw prism_rtl::Panic("no arm matched");
    })
        : crate::syntax::lexer::chars::has_prefix_f(ch_p4, Text::lit("derived:"))
        ? prism_rtl::more(prism_rtl::rc(DerivedTargets(sk_p0, k_p1, cls_p2, all_p3, crate::syntax::lexer::chars::drop_prefix_f(ch_p4, Text::lit("derived:")), seen_p5)))
        : prism_rtl::finished(all_p3);
}


/// `Start ChoiceTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_choice_targets_f(crate::check::shrink::Shrink sk_p0, Text k_p1, Text cls_p2, Array<Text> all_p3, Text ch_p4, Array<Text> seen_p5) {
    return prism_rtl::make_rc<ChoiceTargets>(sk_p0, k_p1, cls_p2, all_p3, ch_p4, seen_p5);
}


/// DerivedTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
Array<Text> derived_targets_f(const crate::check::shrink::Shrink& sk_p0, const Text& k_p1, const Text& cls_p2, const Array<Text>& all_p3, const Text& n_p4, const Array<Text>& seen_p5) {
    return crate::check::types::has_text_f(seen_p5, n_p4)
        ? Array<Text>{}
        : ({
        auto tys_p6 = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(sk_p0.g_p).types_p, n_p4);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_p8 = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
                    auto&& _m = prism_rtl::deref(ti_p8).body_p;
                    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                        auto&& fields_p9 = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                        _v.set(crate::prelude::each(fields_p9, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                            auto&& t_pa = std::get<1>(_p0);
                            return t_pa;
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                        auto&& cases_pb = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                        _v.set(crate::prelude::fold(cases_pb, Array<crate::check::types::Ty>{}, [&](const Array<crate::check::types::Ty>& acc_pc, const std::tuple<Text, Array<crate::check::types::Ty>>& _p1) {
                            auto&& args_pd = std::get<1>(_p1);
                            return crate::prelude::append(acc_pc, args_pd);
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
                        auto&& t_pe = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
                        _v.set(Array(std::vector{t_pe}));
                        goto _done;
                    }
                    {
                        _v.set(Array<crate::check::types::Ty>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::check::types::Ty>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto heads_p7 = crate::prelude::fold(tys_p6, Array<Text>{}, [&](const Array<Text>& acc_pf, const crate::check::types::Ty& t_pg) { return crate::check::types::union_texts_f(acc_pf, ty_heads_f(t_pg)); });
        (crate::prelude::run_to_end(crate::prelude::fold_job(heads_p7, Array<Text>{}, ({
        auto sk_p0x = sk_p0;
        auto k_p1x = k_p1;
        auto cls_p2x = cls_p2;
        auto all_p3x = all_p3;
        auto seen_p5x = seen_p5;
        auto n_p4x = n_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, sk_p0x = std::move(sk_p0x), k_p1x = std::move(k_p1x), cls_p2x = std::move(cls_p2x), all_p3x = std::move(all_p3x), seen_p5x = std::move(seen_p5x), n_p4x = std::move(n_p4x)](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0xy = sk_p0x;
            auto k_p1xy = k_p1x;
            auto cls_p2xy = cls_p2x;
            auto all_p3xy = all_p3x;
            auto seen_p5xy = seen_p5x;
            auto n_p4xy = n_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xy = std::move(sk_p0xy), k_p1xy = std::move(k_p1xy), cls_p2xy = std::move(cls_p2xy), all_p3xy = std::move(all_p3xy), seen_p5xy = std::move(seen_p5xy), n_p4xy = std::move(n_p4xy)]() {
            return ({
                auto acc_ph = p0;
                auto h_pi = p1;
                (prism_rtl::finished(crate::check::types::union_texts_f(acc_ph, head_targets_f(sk_p0xy, k_p1xy, cls_p2xy, all_p3xy, h_pi, crate::prelude::push(seen_p5xy, n_p4xy)))));
            });
        })));
        });
    })));
    }))));
    });
}


prism_rtl::Turn<Array<Text>> DerivedTargets::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& k_p1 = this->k_p1;
    const auto& cls_p2 = this->cls_p2;
    const auto& all_p3 = this->all_p3;
    const auto& n_p4 = this->n_p4;
    const auto& seen_p5 = this->seen_p5;
    return crate::check::types::has_text_f(seen_p5, n_p4)
        ? prism_rtl::finished(Array<Text>{})
        : ({
        auto tys_p6 = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(sk_p0).g_p).types_p, n_p4);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_p8 = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
                    auto&& _m = prism_rtl::deref(ti_p8).body_p;
                    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                        auto&& fields_p9 = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                        _v.set(crate::prelude::each(fields_p9, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                            auto&& t_pa = std::get<1>(_p0);
                            return t_pa;
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                        auto&& cases_pb = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                        _v.set(crate::prelude::fold(cases_pb, Array<crate::check::types::Ty>{}, [&](const Array<crate::check::types::Ty>& acc_pc, const std::tuple<Text, Array<crate::check::types::Ty>>& _p1) {
                            auto&& args_pd = std::get<1>(_p1);
                            return crate::prelude::append(acc_pc, args_pd);
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
                        auto&& t_pe = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
                        _v.set(Array(std::vector{t_pe}));
                        goto _done;
                    }
                    {
                        _v.set(Array<crate::check::types::Ty>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::check::types::Ty>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto heads_p7 = crate::prelude::fold(tys_p6, Array<Text>{}, [&](const Array<Text>& acc_pf, const crate::check::types::Ty& t_pg) { return crate::check::types::union_texts_f(acc_pf, ty_heads_f(t_pg)); });
        (crate::prelude::fold_job(heads_p7, Array<Text>{}, ({
        auto sk_p0x = sk_p0;
        auto k_p1x = k_p1;
        auto cls_p2x = cls_p2;
        auto all_p3x = all_p3;
        auto seen_p5x = seen_p5;
        auto n_p4x = n_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, sk_p0x = std::move(sk_p0x), k_p1x = std::move(k_p1x), cls_p2x = std::move(cls_p2x), all_p3x = std::move(all_p3x), seen_p5x = std::move(seen_p5x), n_p4x = std::move(n_p4x)](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0xy = sk_p0x;
            auto k_p1xy = k_p1x;
            auto cls_p2xy = cls_p2x;
            auto all_p3xy = all_p3x;
            auto seen_p5xy = seen_p5x;
            auto n_p4xy = n_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xy = std::move(sk_p0xy), k_p1xy = std::move(k_p1xy), cls_p2xy = std::move(cls_p2xy), all_p3xy = std::move(all_p3xy), seen_p5xy = std::move(seen_p5xy), n_p4xy = std::move(n_p4xy)]() {
            return ({
                auto acc_ph = p0;
                auto h_pi = p1;
                (prism_rtl::finished(crate::check::types::union_texts_f(acc_ph, head_targets_f(sk_p0xy, k_p1xy, cls_p2xy, all_p3xy, h_pi, crate::prelude::push(seen_p5xy, n_p4xy)))));
            });
        })));
        });
    })));
    }))->cycle());
    });
}


/// `Start DerivedTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_derived_targets_f(crate::check::shrink::Shrink sk_p0, Text k_p1, Text cls_p2, Array<Text> all_p3, Text n_p4, Array<Text> seen_p5) {
    return prism_rtl::make_rc<DerivedTargets>(sk_p0, k_p1, cls_p2, all_p3, n_p4, seen_p5);
}


/// TyHeads: fn Ty -> [Text]
Array<Text> ty_heads_f(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& args_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        return crate::prelude::fold(args_p2, Array(std::vector{n_p1}), [&](const Array<Text>& acc_p3, const crate::check::types::Ty& a_p4) { return crate::check::types::union_texts_f(acc_p3, ty_heads_f(a_p4)); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_p5 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return crate::prelude::fold(ts_p5, Array<Text>{}, [&](const Array<Text>& acc_p6, const crate::check::types::Ty& a_p7) { return crate::check::types::union_texts_f(acc_p6, ty_heads_f(a_p7)); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0)) {
        auto&& e_p8 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        return ty_heads_f(prism_rtl::deref(prism_rtl::deref(e_p8)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0)) {
        auto&& a_p9 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& b_pa = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        return crate::check::types::union_texts_f(ty_heads_f(prism_rtl::deref(prism_rtl::deref(a_p9))), ty_heads_f(prism_rtl::deref(prism_rtl::deref(b_pa))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& i_pb = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return ty_heads_f(prism_rtl::deref(prism_rtl::deref(i_pb)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t_p0)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(t_p0)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p0)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p0)) {
        return Array<Text>{};
    }
    {
        return Array(std::vector{Text::lit("?")});
    }
}


/// HeadTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
Array<Text> head_targets_f(const crate::check::shrink::Shrink& sk_p0, const Text& k_p1, const Text& cls_p2, const Array<Text>& all_p3, const Text& h_p4, const Array<Text>& seen_p5) {
    return h_p4 == Text::lit("?")
        ? all_p3
        : crate::check::env::traits::builtin_has_f(cls_p2, h_p4) || crate::check::env::is_prim_type_f(h_p4)
        ? Array<Text>{}
        : ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = crate::prelude::index(crate::prelude::filter(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(sk_p0.g_p).impls_p, cls_p2), Array<crate::check::env::ImplInfo>{}), [&](const crate::check::env::ImplInfo& im_p6) { return head_key_o(prism_rtl::deref(im_p6).head_p) == std::optional(h_p4); }), Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& im_p7 = prism_rtl::some_of(_m);
            _v.set(choice_targets_f(sk_p0, k_p1, cls_p2, all_p3, crate::check::env::traits::impl_choice_f(im_p7), seen_p5));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(all_p3);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// ?HeadKey: fn Ty -> ?Text
std::optional<Text> head_key_o(const crate::check::types::Ty& ty0) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(ty0)) {
        auto&& n_p0 = prism_rtl::as<crate::check::types::Ty::TyCon>(ty0).a0;
        return std::optional(n_p0);
    }
    {
        return std::optional<Text>{};
    }
}


/// TargetsOf: fn Shrink, Text -> [Text]
Array<Text> targets_of_f(const crate::check::shrink::Shrink& sk_p0, const Text& k_p1) {
    return crate::prelude::or_(crate::prelude::get(sk_p0.targets_p, k_p1), Array(std::vector{k_p1}));
}


/// SigKeyOf: fn Shrink, Text -> Text
Text sig_key_of_f(const crate::check::shrink::Shrink& sk_p0, const Text& k_p1) {
    auto&& _m = crate::prelude::get(sk_p0.by_key_p, k_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& d_p2 = prism_rtl::some_of(_m);
        return crate::prelude::or_(method_of_o(sk_p0.g_p, d_p2), k_p1);
    }
    if (prism_rtl::is_none(_m)) {
        return k_p1;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ShownKey: fn Text -> Text
Text shown_key_f(const Text& k_p0) {
    return crate::check::types::bare_name_f(crate::prelude::or_(crate::prelude::index(crate::prelude::split_on(crate::prelude::or_(crate::syntax::lexer::chars::last_o(crate::prelude::split_on(k_p0, Text::lit(" impl "))), k_p0), Text::lit(" #")), Nat(0u)), k_p0));
}


/// IsUnboundedKey: fn G, Text -> Bool
bool is_unbounded_key_f(const crate::check::env::G& g_p0, const Text& k_p1) {
    auto&& _m = crate::prelude::get(g_p0.vals_p, k_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& v_p2 = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p2).scheme_p).ty_p;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CUnbound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::check::shrink::types
