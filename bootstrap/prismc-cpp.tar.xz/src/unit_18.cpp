// The modules `Check.Regex`, `Check.Shrink`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <syntax/module.hpp>
#include <check/env/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Regex`, from `target/bootstrap/cpp-src/prismc/check/regex/mod.prism`.
namespace crate::check::regex {

void RxCp::show(Printer& p) const {
    if (auto c = std::get_if<RxLit>(&cases())) p.choice("RxLit", {c->a0});
    else if (auto c = std::get_if<RxNum>(&cases())) p.choice("RxNum", {c->a0});
}

Pod RxCp::to_pod() const {
    return std::holds_alternative<RxLit>(cases()) ? Pod::choice("RxLit", {prism_rtl::to_pod(std::get<RxLit>(cases()).a0)})
        : std::holds_alternative<RxNum>(cases()) ? Pod::choice("RxNum", {prism_rtl::to_pod(std::get<RxNum>(cases()).a0)})
        : Pod();
}

Result<RxCp> RxCp::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "RxLit" && c->args.size() == 1) return RxCp(RxLit{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "RxNum" && c->args.size() == 1) return RxCp(RxNum{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
    }
    return mismatch<RxCp>("a RxCp", p);
}


void RxDiag::show(Printer& p) const {
    p.record("RxDiag", {{"part", part}, {"at", at}, {"message", message}});
}

Pod RxDiag::to_pod() const {
    return Pod::record("RxDiag", {{"part", prism_rtl::to_pod(part)}, {"at", prism_rtl::to_pod(at)}, {"message", prism_rtl::to_pod(message)}});
}

Result<RxDiag> RxDiag::from_pod(const Pod& whole) {
    return RxDiag{.part = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "part")))), .at = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "at")))), .message = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "message"))))};
}


void RxLast::show(Printer& p) const {
    if (auto c = std::get_if<RxLastNothing>(&cases())) p.choice("RxLastNothing", {});
    else if (auto c = std::get_if<RxLastFlagGroup>(&cases())) p.choice("RxLastFlagGroup", {});
    else if (auto c = std::get_if<RxLastAssertion>(&cases())) p.choice("RxLastAssertion", {});
    else if (auto c = std::get_if<RxLastRepetition>(&cases())) p.choice("RxLastRepetition", {});
    else if (auto c = std::get_if<RxLastAtom>(&cases())) p.choice("RxLastAtom", {});
}

Pod RxLast::to_pod() const {
    return std::holds_alternative<RxLastNothing>(cases()) ? Pod::choice("RxLastNothing", {})
        : std::holds_alternative<RxLastFlagGroup>(cases()) ? Pod::choice("RxLastFlagGroup", {})
        : std::holds_alternative<RxLastAssertion>(cases()) ? Pod::choice("RxLastAssertion", {})
        : std::holds_alternative<RxLastRepetition>(cases()) ? Pod::choice("RxLastRepetition", {})
        : std::holds_alternative<RxLastAtom>(cases()) ? Pod::choice("RxLastAtom", {})
        : Pod();
}

Result<RxLast> RxLast::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "RxLastNothing" && c->args.size() == 0) return RxLast(RxLastNothing{});
        if (c->ctor == "RxLastFlagGroup" && c->args.size() == 0) return RxLast(RxLastFlagGroup{});
        if (c->ctor == "RxLastAssertion" && c->args.size() == 0) return RxLast(RxLastAssertion{});
        if (c->ctor == "RxLastRepetition" && c->args.size() == 0) return RxLast(RxLastRepetition{});
        if (c->ctor == "RxLastAtom" && c->args.size() == 0) return RxLast(RxLastAtom{});
    }
    return mismatch<RxLast>("a RxLast", p);
}


void RxMeasure::show(Printer& p) const {
    p.record("RxMeasure", {{"depth", depth}, {"size", size}, {"product", product}});
}

Pod RxMeasure::to_pod() const {
    return Pod::record("RxMeasure", {{"depth", prism_rtl::to_pod(depth)}, {"size", prism_rtl::to_pod(size)}, {"product", prism_rtl::to_pod(product)}});
}

Result<RxMeasure> RxMeasure::from_pod(const Pod& whole) {
    return RxMeasure{.depth = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "depth")))), .size = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "size")))), .product = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "product"))))};
}


void RxState::show(Printer& p) const {
    p.record("RxState", {{"s", s}, {"i", i}, {"open", open}, {"groups", groups}, {"names", names}, {"err", err}});
}

Pod RxState::to_pod() const {
    return Pod::record("RxState", {{"s", prism_rtl::to_pod(s)}, {"i", prism_rtl::to_pod(i)}, {"open", prism_rtl::to_pod(open)}, {"groups", prism_rtl::to_pod(groups)}, {"names", prism_rtl::to_pod(names)}, {"err", prism_rtl::to_pod(err)}});
}

Result<RxState> RxState::from_pod(const Pod& whole) {
    return RxState{.s = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "s")))), .i = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "i")))), .open = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "open")))), .groups = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "groups")))), .names = TRY(prism_rtl::from_pod<Map<Text, Nat>>(TRY(crate::prelude::field(whole, "names")))), .err = TRY(prism_rtl::from_pod<std::optional<RxDiag>>(TRY(crate::prelude::field(whole, "err"))))};
}


/// let rxUnknownFlag
Text rx_unknown_flag() {
    return Text::lit("an unknown flag: the flags are i, m and s");
}


/// let rxFlagTwice
Text rx_flag_twice() {
    return Text::lit("a flag written twice");
}


/// let rxStrayBracket
Text rx_stray_bracket() {
    return Text::lit("a ] outside a class: a literal one is \\]");
}


/// let rxStrayBrace
Text rx_stray_brace() {
    return Text::lit("a } outside a count: a literal one is \\}");
}


/// let rxTrailingBackslash
Text rx_trailing_backslash() {
    return Text::lit("a \\ at the end of the pattern");
}


/// let rxHexTwo
Text rx_hex_two() {
    return Text::lit("a \\x escape needs two hex digits or braces");
}


/// let rxHexBraces
Text rx_hex_braces() {
    return Text::lit("a \\x{...} escape needs one to six hex digits");
}


/// let rxHexNoChar
Text rx_hex_no_char() {
    return Text::lit("a \\x escape names no character: a surrogate or past U+10FFFF");
}


/// let rxWordBraces
Text rx_word_braces() {
    return Text::lit("\\b{...} is Rust\'s only: write \\b");
}


/// let rxAngle
Text rx_angle() {
    return Text::lit("\\< and \\> are Rust\'s only: write \\b");
}


/// let rxBackreference
Text rx_backreference() {
    return Text::lit("a backreference: refused so that every match is linear in its text");
}


/// let rxOctal
Text rx_octal() {
    return Text::lit("an octal escape is RE2\'s only: write \\x");
}


/// let rxQuote
Text rx_quote() {
    return Text::lit("\\Q...\\E is RE2\'s only: escape each character");
}


/// let rxOneByte
Text rx_one_byte() {
    return Text::lit("\\C, one byte, is RE2\'s only");
}


/// let rxUnknownEscape
Text rx_unknown_escape() {
    return Text::lit("an unknown escape");
}


/// let rxPropertyName
Text rx_property_name() {
    return Text::lit("a \\p escape needs a property name");
}


/// let rxPropertyOpen
Text rx_property_open() {
    return Text::lit("a \\p{ that is never closed");
}


/// let rxPropertyNegated
Text rx_property_negated() {
    return Text::lit("a negated property is written \\P{...}");
}


/// let rxPropertyRefused
Text rx_property_refused() {
    return Text::lit("the property is refused: RE2 and Rust disagree on C, Cn, Cs and LC");
}


/// let rxPropertyUnknown
Text rx_property_unknown() {
    return Text::lit("an unknown property: general categories by short name, scripts and Any");
}


/// let rxClassOpen
Text rx_class_open() {
    return Text::lit("a class opened here is never closed");
}


/// let rxClassFirstBracket
Text rx_class_first_bracket() {
    return Text::lit("a ] first in a class: write \\]");
}


/// let rxClassNested
Text rx_class_nested() {
    return Text::lit("a [ inside a class: write \\[ (nested classes are Rust\'s only)");
}


/// let rxClassAsciiUnknown
Text rx_class_ascii_unknown() {
    return Text::lit("an unknown ASCII class");
}


/// let rxClassSetOperation
Text rx_class_set_operation() {
    return Text::lit("&&, ~~ and -- in a class are Rust\'s set operations: escape them");
}


/// let rxClassDash
Text rx_class_dash() {
    return Text::lit("a - in a class that is neither a range nor first or last: write \\-");
}


/// let rxClassOrder
Text rx_class_order() {
    return Text::lit("a range whose ends are out of order");
}


/// let rxClassRangeSet
Text rx_class_range_set() {
    return Text::lit("a range end that is a class");
}


/// let rxClassNegatedUnderI
Text rx_class_negated_under_i() {
    return Text::lit("a negated class inside a class under i: write it outside the class");
}


/// let rxClassEscape
Text rx_class_escape() {
    return Text::lit("an escape that a class cannot hold");
}


/// let rxLookaround
Text rx_lookaround() {
    return Text::lit("a lookaround: refused so that every match is linear in its text");
}


/// let rxUnknownGroup
Text rx_unknown_group() {
    return Text::lit("an unknown group: the groups are (re), (?:re), (?<name>re), (?P<name>re) and the flag groups");
}


/// let rxNameShape
Text rx_name_shape() {
    return Text::lit("a group name is a lowercase value name, [a-z_][a-z0-9_]*");
}


/// let rxNameOpen
Text rx_name_open() {
    return Text::lit("a group name that is never closed");
}


/// let rxNameTwice
Text rx_name_twice() {
    return Text::lit("a group name used twice");
}


/// let rxGroupOpen
Text rx_group_open() {
    return Text::lit("a group opened here is never closed");
}


/// let rxGroupClose
Text rx_group_close() {
    return Text::lit("a ) that closes no group");
}


/// let rxFlagsEmpty
Text rx_flags_empty() {
    return Text::lit("an empty flag group");
}


/// let rxFlagsSecondDash
Text rx_flags_second_dash() {
    return Text::lit("a second - in a flag group");
}


/// let rxFlagsDash
Text rx_flags_dash() {
    return Text::lit("a - that turns off no flag");
}


/// let rxBrace
Text rx_brace() {
    return Text::lit("a brace that opens no count: a literal one is \\{");
}


/// let rxCountZero
Text rx_count_zero() {
    return Text::lit("a count with a leading zero");
}


/// let rxCountBound
Text rx_count_bound() {
    return Text::lit("a count above 1000");
}


/// let rxCountOrder
Text rx_count_order() {
    return Text::lit("a count whose minimum exceeds its maximum");
}


/// let rxNothingToRepeat
Text rx_nothing_to_repeat() {
    return Text::lit("a repetition with nothing to repeat");
}


/// let rxRepeatRepeat
Text rx_repeat_repeat() {
    return Text::lit("a repetition of a repetition: write (?:a*)* to say it");
}


/// let rxRepeatAssertion
Text rx_repeat_assertion() {
    return Text::lit("a repetition of an assertion");
}


/// let rxProduct
Text rx_product() {
    return Text::lit("nested counts multiplying past 1000");
}


/// let rxNesting
Text rx_nesting() {
    return Text::lit("groups and repetitions nested more than 100 deep");
}


/// let rxSize
Text rx_size() {
    return Text::lit("the pattern expands past 10,000 atoms");
}


/// let rxRZero
Text rx_rzero() {
    return Text::lit("a group number with a leading zero");
}


/// let rxRBraces
Text rx_rbraces() {
    return Text::lit("a ${...} that is neither a group number nor a group name");
}


/// let rxRDollar
Text rx_rdollar() {
    return Text::lit("a $ that is not $n, ${n}, ${name} or $$");
}


/// let rxRNoNumber
Text rx_rno_number() {
    return Text::lit("the pattern has no group of that number");
}


/// let rxRNoName
Text rx_rno_name() {
    return Text::lit("the pattern has no group of that name");
}


/// let rxRUnicode
Text rx_runicode() {
    return Text::lit("a \\u{...} escape needs one to six hex digits naming a character");
}


/// let rxREscape
Text rx_rescape() {
    return Text::lit("an unknown escape in a replacement: the escapes are \\\\, \\n, \\t, \\u{hex} and \\/");
}


/// let rxCategories
Array<Text> rx_categories() {
    return Array(std::vector{Text::lit("Cc"), Text::lit("Cf"), Text::lit("Co"), Text::lit("L"), Text::lit("Ll"), Text::lit("Lm"), Text::lit("Lo"), Text::lit("Lt"), Text::lit("Lu"), Text::lit("M"), Text::lit("Mc"), Text::lit("Me"), Text::lit("Mn"), Text::lit("N"), Text::lit("Nd"), Text::lit("Nl"), Text::lit("No"), Text::lit("P"), Text::lit("Pc"), Text::lit("Pd"), Text::lit("Pe"), Text::lit("Pf"), Text::lit("Pi"), Text::lit("Po"), Text::lit("Ps"), Text::lit("S"), Text::lit("Sc"), Text::lit("Sk"), Text::lit("Sm"), Text::lit("So"), Text::lit("Z"), Text::lit("Zl"), Text::lit("Zp"), Text::lit("Zs")});
}


/// let rxScripts
Array<Text> rx_scripts() {
    return Array(std::vector{Text::lit("Adlam"), Text::lit("Ahom"), Text::lit("Anatolian_Hieroglyphs"), Text::lit("Arabic"), Text::lit("Armenian"), Text::lit("Avestan"), Text::lit("Balinese"), Text::lit("Bamum"), Text::lit("Bassa_Vah"), Text::lit("Batak"), Text::lit("Bengali"), Text::lit("Bhaiksuki"), Text::lit("Bopomofo"), Text::lit("Brahmi"), Text::lit("Braille"), Text::lit("Buginese"), Text::lit("Buhid"), Text::lit("Canadian_Aboriginal"), Text::lit("Carian"), Text::lit("Caucasian_Albanian"), Text::lit("Chakma"), Text::lit("Cham"), Text::lit("Cherokee"), Text::lit("Chorasmian"), Text::lit("Common"), Text::lit("Coptic"), Text::lit("Cuneiform"), Text::lit("Cypriot"), Text::lit("Cypro_Minoan"), Text::lit("Cyrillic"), Text::lit("Deseret"), Text::lit("Devanagari"), Text::lit("Dives_Akuru"), Text::lit("Dogra"), Text::lit("Duployan"), Text::lit("Egyptian_Hieroglyphs"), Text::lit("Elbasan"), Text::lit("Elymaic"), Text::lit("Ethiopic"), Text::lit("Georgian"), Text::lit("Glagolitic"), Text::lit("Gothic"), Text::lit("Grantha"), Text::lit("Greek"), Text::lit("Gujarati"), Text::lit("Gunjala_Gondi"), Text::lit("Gurmukhi"), Text::lit("Han"), Text::lit("Hangul"), Text::lit("Hanifi_Rohingya"), Text::lit("Hanunoo"), Text::lit("Hatran"), Text::lit("Hebrew"), Text::lit("Hiragana"), Text::lit("Imperial_Aramaic"), Text::lit("Inherited"), Text::lit("Inscriptional_Pahlavi"), Text::lit("Inscriptional_Parthian"), Text::lit("Javanese"), Text::lit("Kaithi"), Text::lit("Kannada"), Text::lit("Katakana"), Text::lit("Kawi"), Text::lit("Kayah_Li"), Text::lit("Kharoshthi"), Text::lit("Khitan_Small_Script"), Text::lit("Khmer"), Text::lit("Khojki"), Text::lit("Khudawadi"), Text::lit("Lao"), Text::lit("Latin"), Text::lit("Lepcha"), Text::lit("Limbu"), Text::lit("Linear_A"), Text::lit("Linear_B"), Text::lit("Lisu"), Text::lit("Lycian"), Text::lit("Lydian"), Text::lit("Mahajani"), Text::lit("Makasar"), Text::lit("Malayalam"), Text::lit("Mandaic"), Text::lit("Manichaean"), Text::lit("Marchen"), Text::lit("Masaram_Gondi"), Text::lit("Medefaidrin"), Text::lit("Meetei_Mayek"), Text::lit("Mende_Kikakui"), Text::lit("Meroitic_Cursive"), Text::lit("Meroitic_Hieroglyphs"), Text::lit("Miao"), Text::lit("Modi"), Text::lit("Mongolian"), Text::lit("Mro"), Text::lit("Multani"), Text::lit("Myanmar"), Text::lit("Nabataean"), Text::lit("Nag_Mundari"), Text::lit("Nandinagari"), Text::lit("New_Tai_Lue"), Text::lit("Newa"), Text::lit("Nko"), Text::lit("Nushu"), Text::lit("Nyiakeng_Puachue_Hmong"), Text::lit("Ogham"), Text::lit("Ol_Chiki"), Text::lit("Old_Hungarian"), Text::lit("Old_Italic"), Text::lit("Old_North_Arabian"), Text::lit("Old_Permic"), Text::lit("Old_Persian"), Text::lit("Old_Sogdian"), Text::lit("Old_South_Arabian"), Text::lit("Old_Turkic"), Text::lit("Old_Uyghur"), Text::lit("Oriya"), Text::lit("Osage"), Text::lit("Osmanya"), Text::lit("Pahawh_Hmong"), Text::lit("Palmyrene"), Text::lit("Pau_Cin_Hau"), Text::lit("Phags_Pa"), Text::lit("Phoenician"), Text::lit("Psalter_Pahlavi"), Text::lit("Rejang"), Text::lit("Runic"), Text::lit("Samaritan"), Text::lit("Saurashtra"), Text::lit("Sharada"), Text::lit("Shavian"), Text::lit("Siddham"), Text::lit("SignWriting"), Text::lit("Sinhala"), Text::lit("Sogdian"), Text::lit("Sora_Sompeng"), Text::lit("Soyombo"), Text::lit("Sundanese"), Text::lit("Syloti_Nagri"), Text::lit("Syriac"), Text::lit("Tagalog"), Text::lit("Tagbanwa"), Text::lit("Tai_Le"), Text::lit("Tai_Tham"), Text::lit("Tai_Viet"), Text::lit("Takri"), Text::lit("Tamil"), Text::lit("Tangsa"), Text::lit("Tangut"), Text::lit("Telugu"), Text::lit("Thaana"), Text::lit("Thai"), Text::lit("Tibetan"), Text::lit("Tifinagh"), Text::lit("Tirhuta"), Text::lit("Toto"), Text::lit("Ugaritic"), Text::lit("Vai"), Text::lit("Vithkuqi"), Text::lit("Wancho"), Text::lit("Warang_Citi"), Text::lit("Yezidi"), Text::lit("Yi"), Text::lit("Zanabazar_Square")});
}


/// let rxProperties
Map<Text, bool> rx_properties() {
    return map(each(crate::prelude::push(append(rx_categories(), rx_scripts()), Text::lit("Any")), [&](const Text& n) { return std::tuple{n, true}; }));
}


/// let rxAsciiClasses
Map<Text, bool> rx_ascii_classes() {
    return map(each(Array(std::vector{Text::lit("alnum"), Text::lit("alpha"), Text::lit("ascii"), Text::lit("blank"), Text::lit("cntrl"), Text::lit("digit"), Text::lit("graph"), Text::lit("lower"), Text::lit("print"), Text::lit("punct"), Text::lit("space"), Text::lit("upper"), Text::lit("word"), Text::lit("xdigit")}), [&](const Text& n) { return std::tuple{n, true}; }));
}


/// let rxAscii
Text rx_ascii() {
    return Text::lit("\000\t\n\r !\"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"sv);
}


/// let rxPunctuation
Text rx_punctuation() {
    return Text::lit("!\"#$%&\'()*+,-./:;=?@[\\]^_`{|}~");
}


/// let rxNone
RxMeasure rx_none() {
    return RxMeasure{.depth = Nat(0u), .size = Nat(0u), .product = Nat(0u)};
}


/// let rxAtom
RxMeasure rx_atom() {
    return RxMeasure{.depth = Nat(0u), .size = Nat(1u), .product = Nat(1u)};
}


/// RxThen: fn RxMeasure, RxMeasure -> RxMeasure
RxMeasure rx_then(const RxMeasure& a, const RxMeasure& b) {
    return RxMeasure{.depth = crate::prelude::max(a.depth, b.depth), .size = a.size + b.size, .product = crate::prelude::max(a.product, b.product)};
}


/// RxBad: fn RxState -> Bool
bool rx_bad(const RxState& st) {
    return st.err != std::optional<RxDiag>{};
}


/// RxFail: fn RxState, Nat, Text -> RxState
RxState rx_fail(const RxState& st, const Nat& at_, const Text& message) {
    return rx_bad(st)
        ? st
        : RxState{.s = st.s, .i = st.i, .open = st.open, .groups = st.groups, .names = st.names, .err = std::optional(RxDiag{.part = Text::lit("pattern"), .at = at_, .message = message})};
}


/// RxGo: fn RxState, Nat -> RxState
RxState rx_go(const RxState& st, const Nat& n) {
    RxState this_ = st;
    this_.i = n;
    return this_;
}


/// RxPeek: fn RxState -> Text
Text rx_peek(const RxState& st) {
    return rx_char_at(st.s, st.i);
}


/// RxCharAt: fn Text, Nat -> Text
Text rx_char_at(const Text& t, const Nat& n) {
    auto&& _m = cursor_at(t, n);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        auto&& _m = step(front(after(c)));
        if (prism_rtl::is_some(_m)) {
            auto&& one = std::get<1>(prism_rtl::some_of(_m));
            return before(one);
        }
        if (prism_rtl::is_none(_m)) {
            return Text::lit("");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// RxSlice: fn Text, Nat, Nat -> Text
Text rx_slice(const Text& t, const Nat& a, const Nat& b) {
    auto&& _m = cursor_at(t, b);
    if (prism_rtl::is_some(_m)) {
        auto&& cb = prism_rtl::some_of(_m);
        auto&& _m = cursor_at(before(cb), a);
        if (prism_rtl::is_some(_m)) {
            auto&& ca = prism_rtl::some_of(_m);
            return after(ca);
        }
        if (prism_rtl::is_none(_m)) {
            return Text::lit("");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?RxFind: fn Text, Nat, Text -> ?Nat
std::optional<Nat> rx_find(const Text& t, const Nat& from, const Text& x) {
    auto&& _m = cursor_at(t, from);
    if (prism_rtl::is_none(_m)) {
        return std::optional<Nat>{};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& c0 = prism_rtl::some_of(_m);
        auto&& _found_opt = ({
            std::tuple<std::optional<Nat>, Cursor> this_ = std::tuple{std::optional<Nat>{}, c0};
            Cursor c = c0;
            std::optional<Nat> found_opt = std::optional<Nat>{};
            while (true) {
                auto&& _m = step(c);
                if (!(prism_rtl::is_some(_m))) break;
                auto&& next_ = std::get<1>(prism_rtl::some_of(_m));
                if (!(found_opt == std::optional<Nat>{})) {
                    break;
                }
                if (rx_slice(t, at(c), at(next_)) == x) {
                    found_opt = std::optional(at(c));
                }
                c = next_;
            }
            this_ = std::tuple{found_opt, c};
            this_;
        });
        auto&& found_opt = std::get<0>(_found_opt);
        return found_opt;
    }
    prism_rtl::unreachable("no arm matched");
}


/// RxIn: fn Text, Text -> Bool
bool rx_in(const Text& set, const Text& c) {
    return (c != Text::lit("")) && (rx_find(set, Nat(0u), c) != std::optional<Nat>{});
}


/// RxIsDigit: fn Text -> Bool
bool rx_is_digit(const Text& c) {
    return ((Text::lit("0") <= c) && (c <= Text::lit("9"))) && (len_text(c) == Nat(1u));
}


/// RxIsLetter: fn Text -> Bool
bool rx_is_letter(const Text& c) {
    return ((Text::lit("a") <= c) && (c <= Text::lit("z"))) || ((Text::lit("A") <= c) && (c <= Text::lit("Z")));
}


/// RxIsHex: fn Text -> Bool
bool rx_is_hex(const Text& c) {
    return (rx_is_digit(c) || ((Text::lit("a") <= c) && (c <= Text::lit("f")))) || ((Text::lit("A") <= c) && (c <= Text::lit("F")));
}


/// RxIsName: fn Text -> Bool
bool rx_is_name(const Text& t) {
    auto first_ = rx_char_at(t, Nat(0u));
    return ((t != Text::lit("")) && (((Text::lit("a") <= first_) && (first_ <= Text::lit("z"))) || (first_ == Text::lit("_")))) && rx_all(t, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
        return once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::finished((((Text::lit("a") <= c) && (c <= Text::lit("z"))) || rx_is_digit(c)) || (c == Text::lit("_"))));
            });
        });
    })));
}


/// RxAll: fn Text, (fn Text -> Bool) -> Bool
bool rx_all(const Text& t, const prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>& p__fn) {
    bool this_ = true;
    Cursor c = front(t);
    while (true) {
        auto&& _m = step(c);
        if (!(prism_rtl::is_some(_m))) break;
        auto&& next_ = std::get<1>(prism_rtl::some_of(_m));
        if (!run_to_end(p__fn(rx_slice(t, at(c), at(next_))))) {
            this_ = false;
        }
        c = next_;
    }
    return this_;
}


prism_rtl::Turn<bool> RxAll::cycle() const {
    const auto& t = this->t;
    const auto& p__fn = this->p__fn;
    return prism_rtl::finished(({
        bool this_ = true;
        Cursor c = front(t);
        while (true) {
            auto&& _m = step(c);
            if (!(prism_rtl::is_some(_m))) break;
            auto&& next_ = std::get<1>(prism_rtl::some_of(_m));
            if (!run_to_end(p__fn(rx_slice(t, at(c), at(next_))))) {
                this_ = false;
            }
            c = next_;
        }
        this_;
    }));
}


/// `Start RxAll, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_rx_all(Text t, prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p__fn) {
    return prism_rtl::make_rc<RxAll>(t, p__fn);
}


/// RxSpanEnd: unbounded fn Text, Nat, (fn Text -> Bool) -> Nat
Nat rx_span_end(const Text& t, const Nat& at_, const prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>& p__fn) {
    Nat this_ = at_;
    while (run_to_end(p__fn(rx_char_at(t, this_)))) {
        this_ = this_ + Nat(1u);
    }
    return this_;
}


prism_rtl::Turn<Nat> RxSpanEnd::cycle() const {
    const auto& t = this->t;
    const auto& at_ = this->at_;
    const auto& p__fn = this->p__fn;
    Nat this_ = at_;
    return call_then(loop_job(std::tuple{this_}, ({
        auto p__fn_1 = p__fn;
        auto t_2 = t;
        [=](std::tuple<Nat> _p0) {
        auto this_ = std::get<0>(_p0);
        return run_to_end(p__fn_1(rx_char_at(t_2, this_)))
            ? ({
            this_ = this_ + Nat(1u);
            Expected<std::tuple<Nat>, std::tuple<Nat>>(std::tuple{this_});
        })
            : Expected<std::tuple<Nat>, std::tuple<Nat>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<Nat> _p0) {
        auto this_ = std::get<0>(_p0);
        return prism_rtl::finished(this_);
    });
}


/// `Start RxSpanEnd, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Nat> start_rx_span_end(Text t, Nat at_, prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p__fn) {
    return prism_rtl::make_rc<RxSpanEnd>(t, at_, p__fn);
}


/// RxHexValue: fn Text -> Nat
Nat rx_hex_value(const Text& t) {
    Nat this_ = Nat(0u);
    Cursor c = front(t);
    while (true) {
        auto&& _m = step(c);
        if (!(prism_rtl::is_some(_m))) break;
        auto&& next_ = std::get<1>(prism_rtl::some_of(_m));
        auto d = rx_slice(t, at(c), at(next_));
        this_ = (this_ * Nat(16u)) + or_(rx_find(Text::lit("0123456789abcdef"), Nat(0u), crate::prelude::lower(d)), Nat(0u));
        c = next_;
    }
    return this_;
}


/// RxCpOf: fn Nat -> RxCp
RxCp rx_cp_of(const Nat& v_) {
    return v_ < Nat(128u)
        ? RxCp(RxCp::RxLit{rx_char_at(rx_ascii(), v_)})
        : RxCp(RxCp::RxNum{v_});
}


/// RxWidth: fn Nat -> Nat
Nat rx_width(const Nat& v_) {
    return v_ < Nat(128u)
        ? Nat(1u)
        : v_ < Nat(2048u) ? Nat(2u) : v_ < Nat(65536u) ? Nat(3u) : Nat(4u);
}


/// RxPast: fn RxCp, RxCp -> Bool
bool rx_past(const RxCp& rx_cp0, const RxCp& rx_cp1) {
    auto&& _m = std::tuple{rx_cp0, rx_cp1};
    if (prism_rtl::is<RxCp::RxLit>(std::get<0>(_m)) && prism_rtl::is<RxCp::RxLit>(std::get<1>(_m))) {
        auto&& a = prism_rtl::as<RxCp::RxLit>(std::get<0>(_m)).a0;
        auto&& b = prism_rtl::as<RxCp::RxLit>(std::get<1>(_m)).a0;
        return a > b;
    }
    if (prism_rtl::is<RxCp::RxNum>(std::get<0>(_m)) && prism_rtl::is<RxCp::RxNum>(std::get<1>(_m))) {
        auto&& a = prism_rtl::as<RxCp::RxNum>(std::get<0>(_m)).a0;
        auto&& b = prism_rtl::as<RxCp::RxNum>(std::get<1>(_m)).a0;
        return a > b;
    }
    if (prism_rtl::is<RxCp::RxLit>(std::get<0>(_m)) && prism_rtl::is<RxCp::RxNum>(std::get<1>(_m))) {
        auto&& a = prism_rtl::as<RxCp::RxLit>(std::get<0>(_m)).a0;
        auto&& b = prism_rtl::as<RxCp::RxNum>(std::get<1>(_m)).a0;
        return len_text(a) != rx_width(b)
            ? len_text(a) > rx_width(b)
            : !rx_in_range(a, Nat(0u), b);
    }
    if (prism_rtl::is<RxCp::RxNum>(std::get<0>(_m)) && prism_rtl::is<RxCp::RxLit>(std::get<1>(_m))) {
        auto&& a = prism_rtl::as<RxCp::RxNum>(std::get<0>(_m)).a0;
        auto&& b = prism_rtl::as<RxCp::RxLit>(std::get<1>(_m)).a0;
        return rx_width(a) != len_text(b)
            ? rx_width(a) > len_text(b)
            : !rx_in_range(b, a, Nat(1114111u));
    }
    prism_rtl::unreachable("no arm matched");
}


/// RxInRange: fn Text, Nat, Nat -> Bool
bool rx_in_range(const Text& c, const Nat& lo, const Nat& hi) {
    auto&& _m = crate::prelude::regex(prism_rtl::cat("[\\x{", rx_hex_text(lo), "}-\\x{", rx_hex_text(hi), "}]"));
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return crate::prelude::find(r, c) != std::optional<Match>{};
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// RxHexText: fn Nat -> Text
Text rx_hex_text(const Nat& n) {
    Text this_ = Text::lit("");
    Nat k = n;
    Nat fuel = Nat(6u);
    while (true) {
        auto&& _m = fuel.checked_sub(Nat(1u));
        if (!(prism_rtl::is_some(_m))) break;
        auto&& left = prism_rtl::some_of(_m);
        fuel = left;
        this_ = prism_rtl::cat(rx_char_at(Text::lit("0123456789abcdef"), or_(mod_(k, Nat(16u)), Nat(0u))), this_);
        k = or_(div(k, Nat(16u)), Nat(0u));
    }
    return this_;
}


/// ?RegexRefusal: unbounded fn Text, Text, ?Text -> ?RxDiag
std::optional<RxDiag> regex_refusal(const Text& pattern, const Text& flags, const std::optional<Text>& replacement_opt) {
    auto&& _m = rx_flags_refusal(flags);
    if (prism_rtl::is_some(_m)) {
        auto&& d = prism_rtl::some_of(_m);
        return std::optional(d);
    }
    if (prism_rtl::is_none(_m)) {
        auto st0 = RxState{.s = pattern, .i = Nat(0u), .open = Nat(0u), .groups = Nat(0u), .names = Map<Text, Nat>{}, .err = std::optional<RxDiag>{}};
        auto [m, st] = rx_alternation(st0, rx_find(flags, Nat(0u), Text::lit("i")) != std::optional<Nat>{});
        auto&& _m = prism_rtl::val(st).err;
        if (prism_rtl::is_some(_m)) {
            auto&& d = prism_rtl::some_of(_m);
            return std::optional(d);
        }
        if (prism_rtl::is_none(_m)) {
            return prism_rtl::val(st).i < len_text(pattern)
                ? std::optional(RxDiag{.part = Text::lit("pattern"), .at = prism_rtl::val(st).i, .message = rx_group_close()})
                : prism_rtl::val(m).depth > Nat(100u)
                ? std::optional(RxDiag{.part = Text::lit("pattern"), .at = Nat(0u), .message = rx_nesting()})
                : prism_rtl::val(m).size > Nat(10000u)
                ? std::optional(RxDiag{.part = Text::lit("pattern"), .at = Nat(0u), .message = rx_size()})
                : ({
                __label__ _done;
                prism_rtl::Slot<std::optional<RxDiag>> _v;
                if (prism_rtl::is_none(replacement_opt)) {
                    _v.set(std::optional<RxDiag>{});
                    goto _done;
                }
                if (prism_rtl::is_some(replacement_opt)) {
                    auto&& r = prism_rtl::some_of(replacement_opt);
                    _v.set(rx_replacement_refusal(r, prism_rtl::val(st).groups, st->names));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::optional<RxDiag>> RegexRefusal::cycle() const {
    const auto& pattern = this->pattern;
    const auto& flags = this->flags;
    const auto& replacement_opt = this->replacement_opt;
    return ({
        auto&& _m = rx_flags_refusal(flags);
        prism_rtl::is_some(_m) ? ({
        auto&& d = prism_rtl::some_of(_m);
        prism_rtl::finished(std::optional(d));
    })
        : prism_rtl::is_none(_m) ? ({
        auto st0 = RxState{.s = pattern, .i = Nat(0u), .open = Nat(0u), .groups = Nat(0u), .names = Map<Text, Nat>{}, .err = std::optional<RxDiag>{}};
        auto replacement_opt_1 = replacement_opt;
        auto flags_2 = flags;
        auto pattern_3 = pattern;
        call_then(start_rx_alternation(st0, rx_find(flags_2, Nat(0u), Text::lit("i")) != std::optional<Nat>{}), [=](std::tuple<RxMeasure, RxState> rx_alternation_15542) {
        return ({
            auto [m, st] = rx_alternation_15542;
            ({
            auto&& _m = prism_rtl::val(st).err;
            prism_rtl::is_some(_m) ? ({
            auto&& d = prism_rtl::some_of(_m);
            prism_rtl::finished(std::optional(d));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::val(st).i < len_text(pattern_3)
            ? prism_rtl::finished(std::optional(RxDiag{.part = Text::lit("pattern"), .at = prism_rtl::val(st).i, .message = rx_group_close()}))
            : prism_rtl::val(m).depth > Nat(100u)
            ? prism_rtl::finished(std::optional(RxDiag{.part = Text::lit("pattern"), .at = Nat(0u), .message = rx_nesting()}))
            : prism_rtl::val(m).size > Nat(10000u)
            ? prism_rtl::finished(std::optional(RxDiag{.part = Text::lit("pattern"), .at = Nat(0u), .message = rx_size()}))
            : ({
            prism_rtl::is_none(replacement_opt_1) ? prism_rtl::finished(std::optional<RxDiag>{})
            : prism_rtl::is_some(replacement_opt_1) ? ({
            auto&& r = prism_rtl::some_of(replacement_opt_1);
            prism_rtl::more(prism_rtl::rc(RxReplacementRefusal(r, prism_rtl::val(st).groups, st->names)));
        })
            : throw prism_rtl::Panic("no arm matched");
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RegexRefusal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<RxDiag>> start_regex_refusal(Text pattern, Text flags, std::optional<Text> replacement_opt) {
    return prism_rtl::make_rc<RegexRefusal>(pattern, flags, replacement_opt);
}


/// ?RxFlagsRefusal: fn Text -> ?RxDiag
std::optional<RxDiag> rx_flags_refusal(const Text& flags) {
    auto&& _d_opt = ({
        std::tuple<std::optional<RxDiag>, Text> this_ = std::tuple{std::optional<RxDiag>{}, Text::lit("")};
        Cursor c = front(flags);
        std::optional<RxDiag> d_opt = std::optional<RxDiag>{};
        Text seen = Text::lit("");
        while (true) {
            auto&& _m = step(c);
            if (!(prism_rtl::is_some(_m))) break;
            auto&& next_ = std::get<1>(prism_rtl::some_of(_m));
            if (!(d_opt == std::optional<RxDiag>{})) {
                break;
            }
            auto ch = rx_slice(flags, at(c), at(next_));
            if (!(((ch == Text::lit("i")) || (ch == Text::lit("m"))) || (ch == Text::lit("s")))) {
                d_opt = std::optional(RxDiag{.part = Text::lit("flags"), .at = at(c), .message = rx_unknown_flag()});
            } else if (rx_in(seen, ch)) {
                d_opt = std::optional(RxDiag{.part = Text::lit("flags"), .at = at(c), .message = rx_flag_twice()});
            } else  {
                seen = prism_rtl::cat(seen, ch);
            }
            c = next_;
        }
        this_ = std::tuple{d_opt, seen};
        this_;
    });
    auto&& d_opt = std::get<0>(_d_opt);
    return d_opt;
}


/// RxAlternation: unbounded fn RxState, Bool -> ((RxMeasure, RxState))
std::tuple<RxMeasure, RxState> rx_alternation(const RxState& st0, const bool& fi0) {
    auto [m0, fi1, st1] = rx_sequence(st0, fi0);
    std::tuple<RxMeasure, RxState> this_ = std::tuple{m0, st1};
    RxMeasure m = m0;
    bool fi = fi1;
    RxState st = st1;
    while ((!rx_bad(st)) && (rx_peek(st) == Text::lit("|"))) {
        auto [m2, fi2, st2] = rx_sequence(rx_go(st, st.i + Nat(1u)), fi);
        m = rx_then(m, m2);
        fi = fi2;
        st = st2;
    }
    this_ = std::tuple{m, st};
    return this_;
}


prism_rtl::Turn<std::tuple<RxMeasure, RxState>> RxAlternation::cycle() const {
    const auto& st0 = this->st0;
    const auto& fi0 = this->fi0;
    auto fi0_1 = prism_rtl::val(fi0);
    auto st0_2 = st0;
    return call_then(start_rx_sequence(st0_2, fi0_1), [=](std::tuple<RxMeasure, bool, RxState> rx_sequence_17135) {
        return ({
            auto [m0, fi1, st1] = rx_sequence_17135;
            std::tuple<RxMeasure, RxState> this_ = std::tuple{m0, st1};
            RxMeasure m = m0;
            bool fi = fi1;
            RxState st = st1;
            call_then(loop_job(std::tuple{this_, fi, m, st}, [=](std::tuple<std::tuple<RxMeasure, RxState>, bool, RxMeasure, RxState> _p0) {
            auto this_ = std::get<0>(_p0);
            auto fi = std::get<1>(_p0);
            auto m = std::get<2>(_p0);
            auto st = std::get<3>(_p0);
            return (!rx_bad(st)) && (rx_peek(st) == Text::lit("|"))
                ? ({
                auto [m2, fi2, st2] = rx_sequence(rx_go(st, prism_rtl::val(st).i + Nat(1u)), fi);
                m = rx_then(m, m2);
                fi = fi2;
                st = st2;
                Expected<std::tuple<std::tuple<RxMeasure, RxState>, bool, RxMeasure, RxState>, std::tuple<std::tuple<RxMeasure, RxState>, bool, RxMeasure, RxState>>(std::tuple{this_, fi, m, st});
            })
                : Expected<std::tuple<std::tuple<RxMeasure, RxState>, bool, RxMeasure, RxState>, std::tuple<std::tuple<RxMeasure, RxState>, bool, RxMeasure, RxState>>(unexpected(std::tuple{this_, fi, m, st}));
        }), [=](std::tuple<std::tuple<RxMeasure, RxState>, bool, RxMeasure, RxState> _p0) {
            auto this_ = std::get<0>(_p0);
            auto fi = std::get<1>(_p0);
            auto m = std::get<2>(_p0);
            auto st = std::get<3>(_p0);
            return ({
                this_ = std::tuple{m, st};
                (prism_rtl::finished(this_));
            });
        });
        });
    });
}


/// `Start RxAlternation, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<RxMeasure, RxState>> start_rx_alternation(RxState st0, bool fi0) {
    return prism_rtl::make_rc<RxAlternation>(st0, fi0);
}


/// RxSequence: unbounded fn RxState, Bool -> ((RxMeasure, Bool, RxState))
std::tuple<RxMeasure, bool, RxState> rx_sequence(const RxState& st0, const bool& fi0) {
    std::tuple<RxMeasure, bool, RxState> this_ = std::tuple{rx_none(), prism_rtl::val(fi0), st0};
    RxMeasure total = rx_none();
    bool fi = prism_rtl::val(fi0);
    RxState st = st0;
    RxLast last = RxLast(RxLast::RxLastNothing{});
    RxMeasure last_m = rx_none();
    bool going = true;
    while (going && (!rx_bad(st))) {
        auto c = rx_peek(st);
        auto at_ = st.i;
        if (((c == Text::lit("")) || (c == Text::lit("|"))) || (c == Text::lit(")"))) {
            going = false;
        } else if ((((c == Text::lit("*")) || (c == Text::lit("+"))) || (c == Text::lit("?"))) || (c == Text::lit("{"))) {
            auto [lo, hi_opt, st2] = c == Text::lit("{") ? rx_count(st) : rx_simple_repetition(st, c);
            st = st2;
            if (!rx_bad(st)) {
                st = ({
                    __label__ _done;
                    prism_rtl::Slot<RxState> _v;
                    if (prism_rtl::is<RxLast::RxLastNothing>(last)) {
                        _v.set(rx_fail(st, at_, rx_nothing_to_repeat()));
                        goto _done;
                    }
                    if (prism_rtl::is<RxLast::RxLastFlagGroup>(last)) {
                        _v.set(rx_fail(st, at_, rx_nothing_to_repeat()));
                        goto _done;
                    }
                    if (prism_rtl::is<RxLast::RxLastRepetition>(last)) {
                        _v.set(rx_fail(st, at_, rx_repeat_repeat()));
                        goto _done;
                    }
                    if (prism_rtl::is<RxLast::RxLastAssertion>(last)) {
                        _v.set(rx_fail(st, at_, rx_repeat_assertion()));
                        goto _done;
                    }
                    if (prism_rtl::is<RxLast::RxLastAtom>(last)) {
                        _v.set(st);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
            }
            if (!rx_bad(st)) {
                auto counted = c == Text::lit("{");
                auto factor = counted ? crate::prelude::max(or_(hi_opt, lo), Nat(1u)) : Nat(1u);
                auto product = factor * crate::prelude::max(last_m.product, Nat(1u));
                if (counted && (product > Nat(1000u))) {
                    st = rx_fail(st, at_, rx_product());
                } else  {
                    if (rx_peek(st) == Text::lit("?")) {
                        st = rx_go(st, st.i + Nat(1u));
                    }
                    auto m = RxMeasure{.depth = last_m.depth + Nat(1u), .size = last_m.size * factor, .product = product};
                    total = RxMeasure{.depth = crate::prelude::max(total.depth, prism_rtl::val(m).depth), .size = or_(total.size.checked_sub(last_m.size), Nat(0u)) + prism_rtl::val(m).size, .product = crate::prelude::max(total.product, prism_rtl::val(m).product)};
                    last = RxLast(RxLast::RxLastRepetition{});
                    last_m = m;
                }
            }
        } else  {
            auto [kind, m, fi2, st2] = rx_piece(st, fi);
            st = st2;
            fi = fi2;
            if (kind != RxLast(RxLast::RxLastFlagGroup{})) {
                total = rx_then(total, m);
            }
            last = kind;
            last_m = m;
        }
    }
    this_ = std::tuple{total, fi, st};
    return this_;
}


prism_rtl::Turn<std::tuple<RxMeasure, bool, RxState>> RxSequence::cycle() const {
    const auto& st0 = this->st0;
    const auto& fi0 = this->fi0;
    std::tuple<RxMeasure, bool, RxState> this_ = std::tuple{rx_none(), prism_rtl::val(fi0), st0};
    RxMeasure total = rx_none();
    bool fi = prism_rtl::val(fi0);
    RxState st = st0;
    RxLast last = RxLast(RxLast::RxLastNothing{});
    RxMeasure last_m = rx_none();
    bool going = true;
    return call_then(loop_job(std::tuple{this_, fi, going, last, last_m, st, total}, [=](std::tuple<std::tuple<RxMeasure, bool, RxState>, bool, bool, RxLast, RxMeasure, RxState, RxMeasure> _p0) {
        auto this_ = std::get<0>(_p0);
        auto fi = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto last = std::get<3>(_p0);
        auto last_m = std::get<4>(_p0);
        auto st = std::get<5>(_p0);
        auto total = std::get<6>(_p0);
        return going && (!rx_bad(st))
            ? ({
            auto c = rx_peek(st);
            auto at_ = prism_rtl::val(st).i;
            if (((c == Text::lit("")) || (c == Text::lit("|"))) || (c == Text::lit(")"))) {
                going = false;
            } else if ((((c == Text::lit("*")) || (c == Text::lit("+"))) || (c == Text::lit("?"))) || (c == Text::lit("{"))) {
                auto [lo, hi_opt, st2] = c == Text::lit("{") ? rx_count(st) : rx_simple_repetition(st, c);
                st = st2;
                if (!rx_bad(st)) {
                    st = ({
                        __label__ _done;
                        prism_rtl::Slot<RxState> _v;
                        if (prism_rtl::is<RxLast::RxLastNothing>(last)) {
                            _v.set(rx_fail(st, at_, rx_nothing_to_repeat()));
                            goto _done;
                        }
                        if (prism_rtl::is<RxLast::RxLastFlagGroup>(last)) {
                            _v.set(rx_fail(st, at_, rx_nothing_to_repeat()));
                            goto _done;
                        }
                        if (prism_rtl::is<RxLast::RxLastRepetition>(last)) {
                            _v.set(rx_fail(st, at_, rx_repeat_repeat()));
                            goto _done;
                        }
                        if (prism_rtl::is<RxLast::RxLastAssertion>(last)) {
                            _v.set(rx_fail(st, at_, rx_repeat_assertion()));
                            goto _done;
                        }
                        if (prism_rtl::is<RxLast::RxLastAtom>(last)) {
                            _v.set(st);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }
                if (!rx_bad(st)) {
                    auto counted = c == Text::lit("{");
                    auto factor = counted ? crate::prelude::max(or_(hi_opt, lo), Nat(1u)) : Nat(1u);
                    auto product = factor * crate::prelude::max(prism_rtl::val(last_m).product, Nat(1u));
                    if (counted && (product > Nat(1000u))) {
                        st = rx_fail(st, at_, rx_product());
                    } else  {
                        if (rx_peek(st) == Text::lit("?")) {
                            st = rx_go(st, prism_rtl::val(st).i + Nat(1u));
                        }
                        auto m = RxMeasure{.depth = prism_rtl::val(last_m).depth + Nat(1u), .size = prism_rtl::val(last_m).size * factor, .product = product};
                        total = RxMeasure{.depth = crate::prelude::max(prism_rtl::val(total).depth, prism_rtl::val(m).depth), .size = or_(prism_rtl::val(total).size.checked_sub(prism_rtl::val(last_m).size), Nat(0u)) + prism_rtl::val(m).size, .product = crate::prelude::max(prism_rtl::val(total).product, prism_rtl::val(m).product)};
                        last = RxLast(RxLast::RxLastRepetition{});
                        last_m = m;
                    }
                }
            } else  {
                auto [kind, m, fi2, st2] = rx_piece(st, fi);
                st = st2;
                fi = fi2;
                if (kind != RxLast(RxLast::RxLastFlagGroup{})) {
                    total = rx_then(total, m);
                }
                last = kind;
                last_m = m;
            }
            Expected<std::tuple<std::tuple<RxMeasure, bool, RxState>, bool, bool, RxLast, RxMeasure, RxState, RxMeasure>, std::tuple<std::tuple<RxMeasure, bool, RxState>, bool, bool, RxLast, RxMeasure, RxState, RxMeasure>>(std::tuple{this_, fi, going, last, last_m, st, total});
        })
            : Expected<std::tuple<std::tuple<RxMeasure, bool, RxState>, bool, bool, RxLast, RxMeasure, RxState, RxMeasure>, std::tuple<std::tuple<RxMeasure, bool, RxState>, bool, bool, RxLast, RxMeasure, RxState, RxMeasure>>(unexpected(std::tuple{this_, fi, going, last, last_m, st, total}));
    }), [=](std::tuple<std::tuple<RxMeasure, bool, RxState>, bool, bool, RxLast, RxMeasure, RxState, RxMeasure> _p0) {
        auto this_ = std::get<0>(_p0);
        auto fi = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto last = std::get<3>(_p0);
        auto last_m = std::get<4>(_p0);
        auto st = std::get<5>(_p0);
        auto total = std::get<6>(_p0);
        return ({
            this_ = std::tuple{total, fi, st};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start RxSequence, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<RxMeasure, bool, RxState>> start_rx_sequence(RxState st0, bool fi0) {
    return prism_rtl::make_rc<RxSequence>(st0, fi0);
}


/// RxSimpleRepetition: fn RxState, Text -> ((Nat, ?Nat, RxState))
std::tuple<Nat, std::optional<Nat>, RxState> rx_simple_repetition(const RxState& st, const Text& c) {
    auto st2 = rx_go(st, st.i + Nat(1u));
    return c == Text::lit("*")
        ? std::tuple{Nat(0u), std::optional<Nat>{}, st2}
        : c == Text::lit("+")
        ? std::tuple{Nat(1u), std::optional<Nat>{}, st2}
        : std::tuple{Nat(0u), std::optional(Nat(1u)), st2};
}


/// RxCount: unbounded fn RxState -> ((Nat, ?Nat, RxState))
std::tuple<Nat, std::optional<Nat>, RxState> rx_count(const RxState& st) {
    auto at_ = st.i;
    auto s = st.s;
    auto j1 = rx_span_end(s, at_ + Nat(1u), ({
        auto f = prism_rtl::rc(rx_is_digit);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }));
    auto first_ = rx_slice(s, at_ + Nat(1u), j1);
    auto c = rx_char_at(s, j1);
    return first_ == Text::lit("")
        ? std::tuple{Nat(0u), std::optional<Nat>{}, rx_fail(st, at_, rx_brace())}
        : c == Text::lit("}")
        ? rx_count_checked(st, at_, first_, std::optional<Text>{}, j1 + Nat(1u))
        : c == Text::lit(",")
        ? ({
        auto j2 = rx_span_end(s, j1 + Nat(1u), ({
            auto f = prism_rtl::rc(rx_is_digit);
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text a0) {
            return ({
                auto f_1 = f;
                once_job([=]() { return prism_rtl::finished(f_1(a0)); });
            });
        })));
        }));
        rx_char_at(s, j2) != Text::lit("}")
        ? std::tuple{Nat(0u), std::optional<Nat>{}, rx_fail(st, at_, rx_brace())}
        : rx_count_checked(st, at_, first_, std::optional(rx_slice(s, j1 + Nat(1u), j2)), j2 + Nat(1u));
    })
        : std::tuple{Nat(0u), std::optional<Nat>{}, rx_fail(st, at_, rx_brace())};
}


/// RxCountChecked: fn RxState, Nat, Text, ?Text, Nat -> ((Nat, ?Nat, RxState))
std::tuple<Nat, std::optional<Nat>, RxState> rx_count_checked(const RxState& st, const Nat& at_, const Text& first_, const std::optional<Text>& second_opt, const Nat& next_) {
    auto st1 = rx_go(st, next_);
    auto lo = or_(parse_nat_opt(first_), Nat(0u));
    auto hi_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Nat>> _v;
        if (prism_rtl::is_none(second_opt)) {
            _v.set(std::optional(lo));
            goto _done;
        }
        if (prism_rtl::is_some(second_opt)) {
            auto&& m20974_1 = prism_rtl::some_of(second_opt);
            if (m20974_1 == Text::lit("")) {
                _v.set(std::optional<Nat>{});
                goto _done;
            }
        }
        if (prism_rtl::is_some(second_opt)) {
            auto&& d = prism_rtl::some_of(second_opt);
            _v.set(parse_nat_opt(d));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto zero = rx_leading_zero(first_) || rx_leading_zero(or_(second_opt, Text::lit("")));
    return zero
        ? std::tuple{Nat(0u), std::optional<Nat>{}, rx_fail(st1, at_, rx_count_zero())}
        : (lo > Nat(1000u)) || (or_(hi_opt, Nat(0u)) > Nat(1000u))
        ? std::tuple{Nat(0u), std::optional<Nat>{}, rx_fail(st1, at_, rx_count_bound())}
        : lo > or_(hi_opt, lo)
        ? std::tuple{Nat(0u), std::optional<Nat>{}, rx_fail(st1, at_, rx_count_order())}
        : std::tuple{lo, hi_opt, st1};
}


/// RxLeadingZero: fn Text -> Bool
bool rx_leading_zero(const Text& d) {
    return (len_text(d) > Nat(1u)) && (rx_char_at(d, Nat(0u)) == Text::lit("0"));
}


/// RxPiece: unbounded fn RxState, Bool -> ((RxLast, RxMeasure, Bool, RxState))
std::tuple<RxLast, RxMeasure, bool, RxState> rx_piece(const RxState& st, const bool& fi) {
    auto at_ = st.i;
    auto c = rx_peek(st);
    {
        auto&& m21753_0 = c;
        if (m21753_0 == Text::lit("(")) {
            return rx_group(st, fi);
        }
    }
    {
        auto&& m21753_1 = c;
        if (m21753_1 == Text::lit("[")) {
            return std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), prism_rtl::val(fi), rx_class(st, fi)};
        }
    }
    {
        auto&& m21753_2 = c;
        if (m21753_2 == Text::lit("]")) {
            return std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), prism_rtl::val(fi), rx_fail(st, at_, rx_stray_bracket())};
        }
    }
    {
        auto&& m21753_3 = c;
        if (m21753_3 == Text::lit("}")) {
            return std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), prism_rtl::val(fi), rx_fail(st, at_, rx_stray_brace())};
        }
    }
    {
        auto&& m21753_4 = c;
        if (m21753_4 == Text::lit("^")) {
            return std::tuple{RxLast(RxLast::RxLastAssertion{}), rx_atom(), prism_rtl::val(fi), rx_go(st, at_ + Nat(1u))};
        }
    }
    {
        auto&& m21753_5 = c;
        if (m21753_5 == Text::lit("$")) {
            return std::tuple{RxLast(RxLast::RxLastAssertion{}), rx_atom(), prism_rtl::val(fi), rx_go(st, at_ + Nat(1u))};
        }
    }
    {
        auto&& m21753_6 = c;
        if (m21753_6 == Text::lit("\\")) {
            return rx_escape(st, fi);
        }
    }
    {
        return std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), prism_rtl::val(fi), rx_go(st, at_ + len_text(c))};
    }
}


/// RxEscape: unbounded fn RxState, Bool -> ((RxLast, RxMeasure, Bool, RxState))
std::tuple<RxLast, RxMeasure, bool, RxState> rx_escape(const RxState& st, const bool& fi) {
    auto at_ = st.i;
    auto s = st.s;
    auto c = rx_char_at(s, at_ + Nat(1u));
    auto atom_fn = ({
        auto fi_1 = prism_rtl::val(fi);
        (prism_rtl::rc([=](const RxState& next_) { return std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), fi_1, next_}; }));
    });
    return c == Text::lit("")
        ? atom_fn(rx_fail(st, at_, rx_trailing_backslash()))
        : (c == Text::lit("<")) || (c == Text::lit(">"))
        ? atom_fn(rx_fail(st, at_, rx_angle()))
        : rx_in(rx_punctuation(), c)
        ? atom_fn(rx_go(st, at_ + Nat(2u)))
        : rx_in(Text::lit("tnrfva"), c)
        ? atom_fn(rx_go(st, at_ + Nat(2u)))
        : c == Text::lit("x")
        ? ({
        auto&& _st2 = rx_hex(st, at_);
        auto&& st2 = std::get<1>(_st2);
        atom_fn(st2);
    })
        : rx_in(Text::lit("dwsDWS"), c)
        ? atom_fn(rx_go(st, at_ + Nat(2u)))
        : (c == Text::lit("p")) || (c == Text::lit("P"))
        ? ({
        auto&& _st2 = rx_property(st, at_);
        auto&& st2 = std::get<1>(_st2);
        atom_fn(st2);
    })
        : rx_in(Text::lit("AzbB"), c)
        ? (c == Text::lit("b")) && (rx_char_at(s, at_ + Nat(2u)) == Text::lit("{"))
        ? atom_fn(rx_fail(st, at_, rx_word_braces()))
        : std::tuple{RxLast(RxLast::RxLastAssertion{}), rx_atom(), prism_rtl::val(fi), rx_go(st, at_ + Nat(2u))}
        : rx_in(Text::lit("123456789"), c)
        ? atom_fn(rx_fail(st, at_, rx_backreference()))
        : c == Text::lit("0")
        ? atom_fn(rx_fail(st, at_, rx_octal()))
        : (c == Text::lit("Q")) || (c == Text::lit("E"))
        ? atom_fn(rx_fail(st, at_, rx_quote()))
        : c == Text::lit("C")
        ? atom_fn(rx_fail(st, at_, rx_one_byte()))
        : atom_fn(rx_fail(st, at_, rx_unknown_escape()));
}


/// RxHex: unbounded fn RxState, Nat -> ((Nat, RxState))
std::tuple<Nat, RxState> rx_hex(const RxState& st, const Nat& at_) {
    auto s = st.s;
    auto x = at_ + Nat(1u);
    return rx_char_at(s, x + Nat(1u)) == Text::lit("{")
        ? ({
        auto start = x + Nat(2u);
        auto j = rx_span_end(s, start, ({
            auto f = prism_rtl::rc(rx_is_hex);
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text a0) {
            return ({
                auto f_1 = f;
                once_job([=]() { return prism_rtl::finished(f_1(a0)); });
            });
        })));
        }));
        auto digits = rx_slice(s, start, j);
        ((rx_char_at(s, j) != Text::lit("}")) || (digits == Text::lit(""))) || (len_text(digits) > Nat(6u))
        ? std::tuple{Nat(0u), rx_fail(st, at_, rx_hex_braces())}
        : rx_hex_checked(rx_go(st, j + Nat(1u)), at_, rx_hex_value(digits));
    })
        : ({
        auto a = rx_char_at(s, x + Nat(1u));
        auto b = rx_char_at(s, x + Nat(2u));
        rx_is_hex(a) && rx_is_hex(b)
        ? rx_hex_checked(rx_go(st, x + Nat(3u)), at_, rx_hex_value(prism_rtl::cat(a, b)))
        : std::tuple{Nat(0u), rx_fail(st, at_, rx_hex_two())};
    });
}


/// RxHexChecked: fn RxState, Nat, Nat -> ((Nat, RxState))
std::tuple<Nat, RxState> rx_hex_checked(const RxState& st, const Nat& at_, const Nat& v_) {
    return ((Nat(55296u) <= v_) && (v_ <= Nat(57343u))) || (v_ > Nat(1114111u))
        ? std::tuple{v_, rx_fail(st, at_, rx_hex_no_char())}
        : std::tuple{v_, st};
}


/// RxProperty: unbounded fn RxState, Nat -> ((Text, RxState))
std::tuple<Text, RxState> rx_property(const RxState& st, const Nat& at_) {
    auto s = st.s;
    auto c = rx_char_at(s, at_ + Nat(2u));
    return c == Text::lit("{")
        ? ({
        auto start = at_ + Nat(3u);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, RxState>> _v;
        auto&& _m = rx_find(s, start, Text::lit("}"));
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{Text::lit(""), rx_fail(st, at_, rx_property_open())});
            goto _done;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& close = prism_rtl::some_of(_m);
            _v.set(({
                auto name = rx_slice(s, start, close);
                rx_char_at(name, Nat(0u)) == Text::lit("^")
                ? std::tuple{name, rx_fail(st, at_, rx_property_negated())}
                : rx_property_named(rx_go(st, close + Nat(1u)), at_, name);
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    })
        : rx_is_letter(c)
        ? rx_property_named(rx_go(st, at_ + Nat(3u)), at_, c)
        : std::tuple{Text::lit(""), rx_fail(st, at_, rx_property_name())};
}


/// RxPropertyNamed: fn RxState, Nat, Text -> ((Text, RxState))
std::tuple<Text, RxState> rx_property_named(const RxState& st, const Nat& at_, const Text& name) {
    return (((name == Text::lit("C")) || (name == Text::lit("Cn"))) || (name == Text::lit("Cs"))) || (name == Text::lit("LC"))
        ? std::tuple{name, rx_fail(st, at_, rx_property_refused())}
        : crate::prelude::get(rx_properties(), name) != std::optional<bool>{}
        ? std::tuple{name, st}
        : std::tuple{name, rx_fail(st, at_, rx_property_unknown())};
}


/// RxClass: unbounded fn RxState, Bool -> RxState
RxState rx_class(const RxState& st0, const bool& fi) {
    auto open = st0.i;
    auto start = rx_char_at(st0.s, open + Nat(1u)) == Text::lit("^")
        ? open + Nat(2u)
        : open + Nat(1u);
    RxState this_ = rx_go(st0, start);
    bool first_ = true;
    bool done = false;
    while (!done) {
        auto [closed, st2] = rx_class_item(this_, open, start, first_, fi);
        this_ = st2;
        first_ = false;
        done = closed || rx_bad(st2);
    }
    return this_;
}


/// RxAtSetOperation: fn RxState -> Bool
bool rx_at_set_operation(const RxState& st) {
    auto c = rx_peek(st);
    return (((c == Text::lit("&")) || (c == Text::lit("~"))) || (c == Text::lit("-"))) && (rx_char_at(st.s, st.i + Nat(1u)) == c);
}


/// RxClassItem: unbounded fn RxState, Nat, Nat, Bool, Bool -> ((Bool, RxState))
std::tuple<bool, RxState> rx_class_item(const RxState& st, const Nat& open, const Nat& start, const bool& first_, const bool& fi) {
    auto at_ = st.i;
    auto c = rx_peek(st);
    auto next_ = rx_char_at(st.s, at_ + Nat(1u));
    return c == Text::lit("")
        ? std::tuple{true, rx_fail(st, open, rx_class_open())}
        : (c == Text::lit("]")) && prism_rtl::val(first_)
        ? std::tuple{true, rx_fail(st, at_, rx_class_first_bracket())}
        : c == Text::lit("]")
        ? std::tuple{true, rx_go(st, at_ + Nat(1u))}
        : rx_at_set_operation(st)
        ? std::tuple{true, rx_fail(st, at_, rx_class_set_operation())}
        : c == Text::lit("[")
        ? std::tuple{false, rx_ascii_item(st, fi)}
        : (c == Text::lit("-")) && (next_ == Text::lit(""))
        ? std::tuple{true, rx_fail(st, open, rx_class_open())}
        : (c == Text::lit("-")) && ((at_ == start) || (next_ == Text::lit("]")))
        ? std::tuple{false, rx_go(st, at_ + Nat(1u))}
        : c == Text::lit("-")
        ? std::tuple{true, rx_fail(st, at_, rx_class_dash())}
        : std::tuple{false, rx_class_range(st, open, fi)};
}


/// RxClassRange: unbounded fn RxState, Nat, Bool -> RxState
RxState rx_class_range(const RxState& st, const Nat& open, const bool& fi) {
    auto at_ = st.i;
    auto [lo_opt, st1] = rx_class_atom(st, fi);
    if (prism_rtl::is_none(lo_opt)) {
        return st1;
    }
    if (prism_rtl::is_some(lo_opt)) {
        auto&& lo = prism_rtl::some_of(lo_opt);
        auto s = st1->s;
        auto ranged = (rx_peek(st1) == Text::lit("-")) && (rx_char_at(s, prism_rtl::val(st1).i + Nat(1u)) != Text::lit("]"));
        return rx_bad(st1) || (!ranged)
            ? st1
            : rx_at_set_operation(st1)
            ? rx_fail(st1, prism_rtl::val(st1).i, rx_class_set_operation())
            : ({
            auto right = prism_rtl::val(st1).i + Nat(1u);
            auto st2 = rx_go(st1, right);
            auto rc_ = rx_peek(st2);
            rc_ == Text::lit("")
            ? rx_fail(st2, open, rx_class_open())
            : rc_ == Text::lit("[")
            ? rx_fail(st2, right, rx_class_nested())
            : rx_at_set_operation(st2)
            ? rx_fail(st2, right, rx_class_set_operation())
            : ({
            auto [hi_opt, st3] = rx_class_atom(st2, fi);
            rx_bad(st3)
            ? st3
            : ({
            __label__ _done;
            prism_rtl::Slot<RxState> _v;
            if (prism_rtl::is_none(hi_opt)) {
                _v.set(rx_fail(st3, right, rx_class_range_set()));
                goto _done;
            }
            if (prism_rtl::is_some(hi_opt)) {
                auto&& hi = prism_rtl::some_of(hi_opt);
                _v.set(rx_past(lo, hi) ? rx_fail(st3, at_, rx_class_order()) : st3);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
        });
    }
    prism_rtl::unreachable("no arm matched");
}


/// RxClassAtom: unbounded fn RxState, Bool -> ((?RxCp, RxState))
std::tuple<std::optional<RxCp>, RxState> rx_class_atom(const RxState& st, const bool& fi) {
    auto at_ = st.i;
    auto s = st.s;
    auto c = rx_peek(st);
    return c != Text::lit("\\")
        ? std::tuple{std::optional(RxCp(RxCp::RxLit{c})), rx_go(st, at_ + len_text(c))}
        : ({
        auto e = rx_char_at(s, at_ + Nat(1u));
        e == Text::lit("")
        ? std::tuple{std::optional<RxCp>{}, rx_fail(st, at_, rx_trailing_backslash())}
        : (e == Text::lit("<")) || (e == Text::lit(">"))
        ? std::tuple{std::optional<RxCp>{}, rx_fail(st, at_, rx_class_escape())}
        : rx_in(rx_punctuation(), e)
        ? std::tuple{std::optional(RxCp(RxCp::RxLit{e})), rx_go(st, at_ + Nat(2u))}
        : rx_in(Text::lit("tnrfva"), e)
        ? std::tuple{std::optional(RxCp(RxCp::RxLit{rx_control(e)})), rx_go(st, at_ + Nat(2u))}
        : e == Text::lit("x")
        ? ({
        auto [v_, st2] = rx_hex(st, at_);
        std::tuple{std::optional(rx_cp_of(v_)), st2};
    })
        : rx_in(Text::lit("dws"), e)
        ? std::tuple{std::optional<RxCp>{}, rx_go(st, at_ + Nat(2u))}
        : rx_in(Text::lit("DWS"), e)
        ? prism_rtl::val(fi)
        ? std::tuple{std::optional<RxCp>{}, rx_fail(st, at_, rx_class_negated_under_i())}
        : std::tuple{std::optional<RxCp>{}, rx_go(st, at_ + Nat(2u))}
        : (e == Text::lit("p")) || (e == Text::lit("P"))
        ? ({
        auto&& _st2 = rx_property(st, at_);
        auto&& st2 = std::get<1>(_st2);
        ((e == Text::lit("P")) && prism_rtl::val(fi)) && (!rx_bad(st2))
        ? std::tuple{std::optional<RxCp>{}, rx_fail(st2, at_, rx_class_negated_under_i())}
        : std::tuple{std::optional<RxCp>{}, st2};
    })
        : std::tuple{std::optional<RxCp>{}, rx_fail(st, at_, rx_class_escape())};
    });
}


/// RxControl: fn Text -> Text
Text rx_control(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("t")) {
            return Text::lit("\t");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("n")) {
            return Text::lit("\n");
        }
    }
    {
        auto&& c2_0 = text0;
        if (c2_0 == Text::lit("r")) {
            return Text::lit("\r");
        }
    }
    {
        auto&& c3_0 = text0;
        if (c3_0 == Text::lit("f")) {
            return Text::lit("");
        }
    }
    {
        auto&& c4_0 = text0;
        if (c4_0 == Text::lit("v")) {
            return Text::lit("");
        }
    }
    {
        return Text::lit("");
    }
}


/// RxAsciiItem: unbounded fn RxState, Bool -> RxState
RxState rx_ascii_item(const RxState& st, const bool& fi) {
    auto at_ = st.i;
    auto s = st.s;
    auto negated = rx_char_at(s, at_ + Nat(2u)) == Text::lit("^");
    auto start = negated ? at_ + Nat(3u) : at_ + Nat(2u);
    auto j = rx_span_end(s, start, ({
        auto f = prism_rtl::rc(rx_is_letter);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }));
    auto shaped = (((rx_char_at(s, at_ + Nat(1u)) == Text::lit(":")) && (j > start)) && (rx_char_at(s, j) == Text::lit(":"))) && (rx_char_at(s, j + Nat(1u)) == Text::lit("]"));
    return !shaped
        ? rx_fail(st, at_, rx_class_nested())
        : crate::prelude::get(rx_ascii_classes(), rx_slice(s, start, j)) == std::optional<bool>{}
        ? rx_fail(st, at_, rx_class_ascii_unknown())
        : negated && prism_rtl::val(fi)
        ? rx_fail(st, at_, rx_class_negated_under_i())
        : rx_go(st, j + Nat(2u));
}


/// RxGroup: unbounded fn RxState, Bool -> ((RxLast, RxMeasure, Bool, RxState))
std::tuple<RxLast, RxMeasure, bool, RxState> rx_group(const RxState& st, const bool& fi) {
    auto open = st.i;
    auto s = st.s;
    auto c = rx_char_at(s, open + Nat(1u));
    auto d = rx_char_at(s, open + Nat(2u));
    auto e = rx_char_at(s, open + Nat(3u));
    auto fail_fn = ({
        auto fi_1 = prism_rtl::val(fi);
        auto st_2 = st;
        auto open_3 = open;
        (prism_rtl::rc([=](const Text& message) { return std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), fi_1, rx_fail(st_2, open_3, message)}; }));
    });
    return c != Text::lit("?")
        ? rx_group_body(rx_go(st, open + Nat(1u)), open, fi, fi, true, std::optional<Text>{})
        : d == Text::lit("")
        ? fail_fn(rx_group_open())
        : d == Text::lit(":")
        ? rx_group_body(rx_go(st, open + Nat(3u)), open, fi, fi, false, std::optional<Text>{})
        : (d == Text::lit("=")) || (d == Text::lit("!"))
        ? fail_fn(rx_lookaround())
        : (d == Text::lit("<")) && ((e == Text::lit("=")) || (e == Text::lit("!")))
        ? fail_fn(rx_lookaround())
        : d == Text::lit("<")
        ? rx_named(st, open, open + Nat(3u), fi)
        : (d == Text::lit("P")) && (e == Text::lit(""))
        ? fail_fn(rx_group_open())
        : (d == Text::lit("P")) && (e == Text::lit("<"))
        ? rx_named(st, open, open + Nat(4u), fi)
        : (d == Text::lit("P")) && ((e == Text::lit("=")) || (e == Text::lit(">")))
        ? fail_fn(rx_backreference())
        : d == Text::lit("P")
        ? fail_fn(rx_unknown_group())
        : (rx_is_letter(d) || (d == Text::lit("-"))) || (d == Text::lit(")"))
        ? rx_flag_group(st, open, fi)
        : fail_fn(rx_unknown_group());
}


/// RxNamed: unbounded fn RxState, Nat, Nat, Bool -> ((RxLast, RxMeasure, Bool, RxState))
std::tuple<RxLast, RxMeasure, bool, RxState> rx_named(const RxState& st, const Nat& open, const Nat& start, const bool& fi) {
    auto&& _m = rx_find(st.s, start, Text::lit(">"));
    if (prism_rtl::is_none(_m)) {
        return std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), prism_rtl::val(fi), rx_fail(st, open, rx_name_open())};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& close = prism_rtl::some_of(_m);
        auto name = rx_slice(st.s, start, close);
        return !rx_is_name(name)
            ? std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), prism_rtl::val(fi), rx_fail(st, start, rx_name_shape())}
            : crate::prelude::get(st.names, name) != std::optional<Nat>{}
            ? std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), prism_rtl::val(fi), rx_fail(st, open, rx_name_twice())}
            : rx_group_body(rx_go(st, close + Nat(1u)), open, fi, fi, true, std::optional(name));
    }
    prism_rtl::unreachable("no arm matched");
}


/// RxFlagGroup: unbounded fn RxState, Nat, Bool -> ((RxLast, RxMeasure, Bool, RxState))
std::tuple<RxLast, RxMeasure, bool, RxState> rx_flag_group(const RxState& st, const Nat& open, const bool& fi) {
    auto [bare, inner, st2] = rx_flag_letters(st, open, fi);
    return rx_bad(st2)
        ? std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), prism_rtl::val(fi), st2}
        : bare
        ? std::tuple{RxLast(RxLast::RxLastFlagGroup{}), rx_none(), inner, st2}
        : rx_group_body(st2, open, inner, fi, false, std::optional<Text>{});
}


/// RxFlagLetters: unbounded fn RxState, Nat, Bool -> ((Bool, Bool, RxState))
std::tuple<bool, bool, RxState> rx_flag_letters(const RxState& st0, const Nat& open, const bool& fi0) {
    std::tuple<bool, bool, RxState> this_ = std::tuple{false, prism_rtl::val(fi0), st0};
    RxState st = rx_go(st0, open + Nat(2u));
    bool fi = prism_rtl::val(fi0);
    Text seen = Text::lit("");
    std::optional<Nat> dash_opt = std::optional<Nat>{};
    bool after_dash = false;
    bool named_ = false;
    bool bare = false;
    bool going = true;
    while (going && (!rx_bad(st))) {
        auto at_ = st.i;
        auto c = rx_peek(st);
        if (c == Text::lit("")) {
            st = rx_fail(st, open, rx_group_open());
        } else if ((c == Text::lit(")")) || (c == Text::lit(":"))) {
            if ((!named_) && (dash_opt == std::optional<Nat>{})) {
                st = rx_fail(st, open, rx_flags_empty());
            } else  {
                ({
                    __label__ _done;
                    prism_rtl::Slot<Unit> _v;
                    if (prism_rtl::is_some(dash_opt)) {
                        auto&& d = prism_rtl::some_of(dash_opt);
                        if (!after_dash) {
                            _v.set(({
                                st = rx_fail(st, d, rx_flags_dash());
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        _v.set(({
                            st = rx_go(st, at_ + Nat(1u));
                            bare = c == Text::lit(")");
                            going = false;
                            Unit{};
                        }));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            }
        } else if (c == Text::lit("-")) {
            if (dash_opt != std::optional<Nat>{}) {
                st = rx_fail(st, at_, rx_flags_second_dash());
            } else  {
                dash_opt = std::optional(at_);
                st = rx_go(st, at_ + Nat(1u));
            }
        } else if (rx_is_letter(c)) {
            if (!(((c == Text::lit("i")) || (c == Text::lit("m"))) || (c == Text::lit("s")))) {
                st = rx_fail(st, at_, rx_unknown_flag());
            } else if (rx_in(seen, c)) {
                st = rx_fail(st, at_, rx_flag_twice());
            } else  {
                seen = prism_rtl::cat(seen, c);
                named_ = true;
                if (dash_opt != std::optional<Nat>{}) {
                    after_dash = true;
                }
                if (c == Text::lit("i")) {
                    fi = dash_opt == std::optional<Nat>{};
                }
                st = rx_go(st, at_ + Nat(1u));
            }
        } else  {
            st = rx_fail(st, open, rx_unknown_group());
        }
    }
    this_ = std::tuple{bare, fi, st};
    return this_;
}


/// RxGroupBody: unbounded fn RxState, Nat, Bool, Bool, Bool, ?Text -> ((RxLast, RxMeasure, Bool, RxState))
std::tuple<RxLast, RxMeasure, bool, RxState> rx_group_body(const RxState& st0, const Nat& open, const bool& inner, const bool& outer, const bool& capture, const std::optional<Text>& name_opt) {
    auto counted = prism_rtl::val(capture) ? rx_capture(st0, name_opt) : st0;
    return prism_rtl::val(counted).open == Nat(100u)
        ? std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), prism_rtl::val(outer), rx_fail(counted, Nat(0u), rx_nesting())}
        : ({
        auto deeper = ({
            RxState this_ = counted;
            this_.open = this_.open + Nat(1u);
            this_;
        });
        auto [m, st2] = rx_alternation(deeper, inner);
        rx_bad(st2)
        ? std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), prism_rtl::val(outer), st2}
        : rx_peek(st2) != Text::lit(")")
        ? std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), prism_rtl::val(outer), rx_fail(st2, open, rx_group_open())}
        : ({
        auto closed = ({
            RxState this_ = st2;
            this_.i = this_.i + Nat(1u);
            this_.open = or_(this_.open.checked_sub(Nat(1u)), Nat(0u));
            this_;
        });
        std::tuple{RxLast(RxLast::RxLastAtom{}), RxMeasure{.depth = prism_rtl::val(m).depth + Nat(1u), .size = prism_rtl::val(m).size, .product = prism_rtl::val(m).product}, prism_rtl::val(outer), closed};
    });
    });
}


/// RxCapture: fn RxState, ?Text -> RxState
RxState rx_capture(const RxState& st, const std::optional<Text>& name_opt) {
    auto n = st.groups + Nat(1u);
    auto names = ({
        __label__ _done;
        prism_rtl::Slot<Map<Text, Nat>> _v;
        if (prism_rtl::is_some(name_opt)) {
            auto&& x = prism_rtl::some_of(name_opt);
            _v.set(insert(st.names, x, n));
            goto _done;
        }
        if (prism_rtl::is_none(name_opt)) {
            _v.set(st.names);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return RxState{.s = st.s, .i = st.i, .open = st.open, .groups = n, .names = names, .err = st.err};
}


/// ?RxReplacementRefusal: unbounded fn Text, Nat, (Text ==> Nat) -> ?RxDiag
std::optional<RxDiag> rx_replacement_refusal(const Text& r, const Nat& groups, const Map<Text, Nat>& names) {
    auto&& _d_opt = ({
        std::tuple<std::optional<RxDiag>, Nat> this_ = std::tuple{std::optional<RxDiag>{}, Nat(0u)};
        Nat i = Nat(0u);
        std::optional<RxDiag> d_opt = std::optional<RxDiag>{};
        while ((d_opt == std::optional<RxDiag>{}) && (rx_char_at(r, i) != Text::lit(""))) {
            auto at_ = i;
            auto c = rx_char_at(r, at_);
            auto next_ = rx_char_at(r, at_ + Nat(1u));
            if (c == Text::lit("$")) {
                if (next_ == Text::lit("$")) {
                    i = at_ + Nat(2u);
                } else if (rx_is_digit(next_)) {
                    auto j = rx_span_end(r, at_ + Nat(1u), ({
                        auto f = prism_rtl::rc(rx_is_digit);
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text a0) {
                        return ({
                            auto f_1 = f;
                            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                        });
                    })));
                    }));
                    d_opt = rx_group_number(rx_slice(r, at_ + Nat(1u), j), groups, at_);
                    i = j;
                } else if (next_ == Text::lit("{")) {
                    {
                        auto&& _m = rx_find(r, at_ + Nat(2u), Text::lit("}"));
                        if (prism_rtl::is_none(_m)) {
                            d_opt = rx_replacement_at(at_, rx_rbraces());
                        } else if (prism_rtl::is_some(_m)) {
                            auto&& close = prism_rtl::some_of(_m);
                            auto inner = rx_slice(r, at_ + Nat(2u), close);
                            if ((inner != Text::lit("")) && rx_all(inner, ({
                                auto f = prism_rtl::rc(rx_is_digit);
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text a0) {
                                return ({
                                    auto f_1 = f;
                                    once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                                });
                            })));
                            }))) {
                                d_opt = rx_group_number(inner, groups, at_);
                            } else if (rx_is_name(inner)) {
                                if (crate::prelude::get(names, inner) == std::optional<Nat>{}) {
                                    d_opt = rx_replacement_at(at_, rx_rno_name());
                                }
                            } else  {
                                d_opt = rx_replacement_at(at_, rx_rbraces());
                            }
                            i = close + Nat(1u);
                        }
                    }
                } else  {
                    d_opt = rx_replacement_at(at_, rx_rdollar());
                }
            } else if (c == Text::lit("\\")) {
                if ((((next_ == Text::lit("\\")) || (next_ == Text::lit("n"))) || (next_ == Text::lit("t"))) || (next_ == Text::lit("/"))) {
                    i = at_ + Nat(2u);
                } else if (next_ == Text::lit("u")) {
                    auto j = rx_span_end(r, at_ + Nat(3u), ({
                        auto f = prism_rtl::rc(rx_is_hex);
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text a0) {
                        return ({
                            auto f_1 = f;
                            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                        });
                    })));
                    }));
                    auto digits = rx_slice(r, at_ + Nat(3u), j);
                    auto v_ = rx_hex_value(digits);
                    auto named_ = ((((rx_char_at(r, at_ + Nat(2u)) == Text::lit("{")) && (rx_char_at(r, j) == Text::lit("}"))) && (digits != Text::lit(""))) && (len_text(digits) <= Nat(6u))) && (!(((Nat(55296u) <= v_) && (v_ <= Nat(57343u))) || (v_ > Nat(1114111u))));
                    if (named_) {
                        i = j + Nat(1u);
                    } else  {
                        d_opt = rx_replacement_at(at_, rx_runicode());
                    }
                } else  {
                    d_opt = rx_replacement_at(at_, rx_rescape());
                }
            } else  {
                i = at_ + len_text(c);
            }
        }
        this_ = std::tuple{d_opt, i};
        this_;
    });
    auto&& d_opt = std::get<0>(_d_opt);
    return d_opt;
}


prism_rtl::Turn<std::optional<RxDiag>> RxReplacementRefusal::cycle() const {
    const auto& r = this->r;
    const auto& groups = this->groups;
    const auto& names = this->names;
    std::tuple<std::optional<RxDiag>, Nat> this_ = std::tuple{std::optional<RxDiag>{}, Nat(0u)};
    Nat i = Nat(0u);
    std::optional<RxDiag> d_opt = std::optional<RxDiag>{};
    return call_then(loop_job(std::tuple{d_opt, this_, i}, ({
        auto groups_1 = groups;
        auto names_2 = names;
        auto r_3 = r;
        [=](std::tuple<std::optional<RxDiag>, std::tuple<std::optional<RxDiag>, Nat>, Nat> _p0) {
        auto d_opt = std::get<0>(_p0);
        auto this_ = std::get<1>(_p0);
        auto i = std::get<2>(_p0);
        return (d_opt == std::optional<RxDiag>{}) && (rx_char_at(r_3, i) != Text::lit(""))
            ? ({
            auto at_ = i;
            auto c = rx_char_at(r_3, at_);
            auto next_ = rx_char_at(r_3, at_ + Nat(1u));
            if (c == Text::lit("$")) {
                if (next_ == Text::lit("$")) {
                    i = at_ + Nat(2u);
                } else if (rx_is_digit(next_)) {
                    auto j = rx_span_end(r_3, at_ + Nat(1u), ({
                        auto f = prism_rtl::rc(rx_is_digit);
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text a0) {
                        return ({
                            auto f_4 = f;
                            once_job([=]() { return prism_rtl::finished(f_4(a0)); });
                        });
                    })));
                    }));
                    d_opt = rx_group_number(rx_slice(r_3, at_ + Nat(1u), j), groups_1, at_);
                    i = j;
                } else if (next_ == Text::lit("{")) {
                    {
                        auto&& _m = rx_find(r_3, at_ + Nat(2u), Text::lit("}"));
                        if (prism_rtl::is_none(_m)) {
                            d_opt = rx_replacement_at(at_, rx_rbraces());
                        } else if (prism_rtl::is_some(_m)) {
                            auto&& close = prism_rtl::some_of(_m);
                            auto inner = rx_slice(r_3, at_ + Nat(2u), close);
                            if ((inner != Text::lit("")) && rx_all(inner, ({
                                auto f = prism_rtl::rc(rx_is_digit);
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text a0) {
                                return ({
                                    auto f_4 = f;
                                    once_job([=]() { return prism_rtl::finished(f_4(a0)); });
                                });
                            })));
                            }))) {
                                d_opt = rx_group_number(inner, groups_1, at_);
                            } else if (rx_is_name(inner)) {
                                if (crate::prelude::get(names_2, inner) == std::optional<Nat>{}) {
                                    d_opt = rx_replacement_at(at_, rx_rno_name());
                                }
                            } else  {
                                d_opt = rx_replacement_at(at_, rx_rbraces());
                            }
                            i = close + Nat(1u);
                        }
                    }
                } else  {
                    d_opt = rx_replacement_at(at_, rx_rdollar());
                }
            } else if (c == Text::lit("\\")) {
                if ((((next_ == Text::lit("\\")) || (next_ == Text::lit("n"))) || (next_ == Text::lit("t"))) || (next_ == Text::lit("/"))) {
                    i = at_ + Nat(2u);
                } else if (next_ == Text::lit("u")) {
                    auto j = rx_span_end(r_3, at_ + Nat(3u), ({
                        auto f = prism_rtl::rc(rx_is_hex);
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text a0) {
                        return ({
                            auto f_4 = f;
                            once_job([=]() { return prism_rtl::finished(f_4(a0)); });
                        });
                    })));
                    }));
                    auto digits = rx_slice(r_3, at_ + Nat(3u), j);
                    auto v_ = rx_hex_value(digits);
                    auto named_ = ((((rx_char_at(r_3, at_ + Nat(2u)) == Text::lit("{")) && (rx_char_at(r_3, j) == Text::lit("}"))) && (digits != Text::lit(""))) && (len_text(digits) <= Nat(6u))) && (!(((Nat(55296u) <= v_) && (v_ <= Nat(57343u))) || (v_ > Nat(1114111u))));
                    if (named_) {
                        i = j + Nat(1u);
                    } else  {
                        d_opt = rx_replacement_at(at_, rx_runicode());
                    }
                } else  {
                    d_opt = rx_replacement_at(at_, rx_rescape());
                }
            } else  {
                i = at_ + len_text(c);
            }
            Expected<std::tuple<std::optional<RxDiag>, std::tuple<std::optional<RxDiag>, Nat>, Nat>, std::tuple<std::optional<RxDiag>, std::tuple<std::optional<RxDiag>, Nat>, Nat>>(std::tuple{d_opt, this_, i});
        })
            : Expected<std::tuple<std::optional<RxDiag>, std::tuple<std::optional<RxDiag>, Nat>, Nat>, std::tuple<std::optional<RxDiag>, std::tuple<std::optional<RxDiag>, Nat>, Nat>>(unexpected(std::tuple{d_opt, this_, i}));
    };
    })), [=](std::tuple<std::optional<RxDiag>, std::tuple<std::optional<RxDiag>, Nat>, Nat> _p0) {
        auto d_opt = std::get<0>(_p0);
        auto this_ = std::get<1>(_p0);
        auto i = std::get<2>(_p0);
        return ({
            this_ = std::tuple{d_opt, i};
            auto&& _d_opt = this_;
            auto&& d_opt = std::get<0>(_d_opt);
            (prism_rtl::finished(d_opt));
        });
    });
}


/// `Start RxReplacementRefusal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<RxDiag>> start_rx_replacement_refusal(Text r, Nat groups, Map<Text, Nat> names) {
    return prism_rtl::make_rc<RxReplacementRefusal>(r, groups, names);
}


/// ?RxReplacementAt: fn Nat, Text -> ?RxDiag
std::optional<RxDiag> rx_replacement_at(const Nat& at_, const Text& message) {
    return std::optional(RxDiag{.part = Text::lit("replacement"), .at = at_, .message = message});
}


/// ?RxGroupNumber: fn Text, Nat, Nat -> ?RxDiag
std::optional<RxDiag> rx_group_number(const Text& digits, const Nat& groups, const Nat& at_) {
    return rx_leading_zero(digits)
        ? rx_replacement_at(at_, rx_rzero())
        : or_(parse_nat_opt(digits), Nat(0u)) > groups
        ? rx_replacement_at(at_, rx_rno_number())
        : std::optional<RxDiag>{};
}

}  // namespace crate::check::regex


// The module `Check.Shrink`, from `target/bootstrap/cpp-src/prismc/check/shrink/mod.prism`.
namespace crate::check::shrink {

void Rel::show(Printer& p) const {
    p.record("Rel", {{"param", param}, {"strict", strict}});
}

Pod Rel::to_pod() const {
    return Pod::record("Rel", {{"param", prism_rtl::to_pod(param)}, {"strict", prism_rtl::to_pod(strict)}});
}

Result<Rel> Rel::from_pod(const Pod& whole) {
    return Rel{.param = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "param")))), .strict = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "strict"))))};
}


void Sc::show(Printer& p) const {
    p.record("Sc", {{"caller", caller}, {"callee", callee}, {"edges", edges}, {"span", span}, {"file", file}, {"arg", arg}});
}

Pod Sc::to_pod() const {
    return Pod::record("Sc", {{"caller", prism_rtl::to_pod(caller)}, {"callee", prism_rtl::to_pod(callee)}, {"edges", prism_rtl::to_pod(edges)}, {"span", prism_rtl::to_pod(span)}, {"file", prism_rtl::to_pod(file)}, {"arg", prism_rtl::to_pod(arg)}});
}

Result<Sc> Sc::from_pod(const Pod& whole) {
    return Sc{.caller = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "caller")))), .callee = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "callee")))), .edges = TRY(prism_rtl::from_pod<Array<std::tuple<Nat, Nat, bool>>>(TRY(crate::prelude::field(whole, "edges")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .arg = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "arg"))))};
}


bool Shrink::operator==(const Shrink& o) const { return g == o.g && fns == o.fns && by_key == o.by_key && targets == o.targets && impl_defs == o.impl_defs && choices == o.choices && sums == o.sums && seeds == o.seeds && local_of == o.local_of && local_base == o.local_base; }

void Shrink::show(Printer& p) const {
    p.record("Shrink", {{"g", g}, {"fns", fns}, {"by_key", by_key}, {"targets", targets}, {"impl_defs", impl_defs}, {"choices", choices}, {"sums", sums}, {"seeds", seeds}, {"local_of", local_of}, {"local_base", local_base}});
}

Pod Shrink::to_pod() const {
    return Pod::record("Shrink", {{"g", prism_rtl::to_pod(g)}, {"fns", prism_rtl::to_pod(fns)}, {"by_key", prism_rtl::to_pod(by_key)}, {"targets", prism_rtl::to_pod(targets)}, {"impl_defs", prism_rtl::to_pod(impl_defs)}, {"choices", prism_rtl::to_pod(choices)}, {"sums", prism_rtl::to_pod(sums)}, {"seeds", prism_rtl::to_pod(seeds)}, {"local_of", prism_rtl::to_pod(local_of)}, {"local_base", prism_rtl::to_pod(local_base)}});
}

Result<Shrink> Shrink::from_pod(const Pod& whole) {
    return Shrink{.g = TRY(prism_rtl::from_pod<crate::check::env::G>(TRY(crate::prelude::field(whole, "g")))), .fns = TRY(prism_rtl::from_pod<Array<crate::check::env::Def>>(TRY(crate::prelude::field(whole, "fns")))), .by_key = TRY(prism_rtl::from_pod<Map<Text, crate::check::env::Def>>(TRY(crate::prelude::field(whole, "by_key")))), .targets = TRY(prism_rtl::from_pod<Map<Text, Array<Text>>>(TRY(crate::prelude::field(whole, "targets")))), .impl_defs = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "impl_defs")))), .choices = TRY(prism_rtl::from_pod<Map<Text, Array<Text>>>(TRY(crate::prelude::field(whole, "choices")))), .sums = TRY(prism_rtl::from_pod<Map<Text, Nat>>(TRY(crate::prelude::field(whole, "sums")))), .seeds = TRY(prism_rtl::from_pod<Map<Text, Map<Text, Rel>>>(TRY(crate::prelude::field(whole, "seeds")))), .local_of = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "local_of")))), .local_base = TRY(prism_rtl::from_pod<Map<Text, Map<Text, Rel>>>(TRY(crate::prelude::field(whole, "local_base"))))};
}


/// ShrinkCheck: unbounded fn G, St, [Def] -> ((St, [((Text, [Text]))]))
std::tuple<crate::check::types::St, Array<std::tuple<Text, Array<Text>>>> shrink_check(const crate::check::env::G& g, const crate::check::types::St& st, const Array<crate::check::env::Def>& defs) {
    auto fns = each(filter(defs, [&](const crate::check::env::Def& d) { return len(crate::check::shrink::types::def_clauses(d)) > Nat(0u); }), [&](const crate::check::env::Def& d) { return crate::check::shrink::types::own_key(d); });
    auto by_key = fold(fns, Map<Text, crate::check::env::Def>{}, [&](const Map<Text, crate::check::env::Def>& m, const crate::check::env::Def& d) { return insert(m, prism_rtl::val(d).qk, d); });
    auto homes = fold(fns, Array<Text>{}, [&](const Array<Text>& acc, const crate::check::env::Def& d) { return crate::check::types::add_text(acc, prism_rtl::val(d).home); });
    auto nats = crate::check::shrink::types::nat_minus_seeds(st);
    auto pre = fold(homes, Map<Text, Map<Text, Rel>>{}, [&](const Map<Text, Map<Text, Rel>>& m, const Text& h) { return insert(m, h, fold(keys(nats), crate::check::shrink::relations::prelude_seeds(g, h), [&](const Map<Text, Rel>& m2, const Text& k) { return insert(m2, k, crate::check::shrink::relations::no_rel()); })); });
    auto sk0 = Shrink{.g = g, .fns = fns, .by_key = by_key, .targets = crate::check::shrink::types::method_targets(g, fns), .impl_defs = crate::check::shrink::types::impl_defs(g, fns), .choices = st.choices, .sums = Map<Text, Nat>{}, .seeds = pre, .local_of = Map<Text, Text>{}, .local_base = Map<Text, Map<Text, Rel>>{}};
    auto sk1 = ({
        Shrink this_ = sk0;
        this_.sums = crate::check::shrink::summaries::parts_summaries(sk0, fns);
        this_;
    });
    auto skg = ({
        Shrink this_ = sk1;
        this_.seeds = crate::check::shrink::calls::hof_seeds(sk1, homes);
        this_;
    });
    auto walked = run_to_end(each_job(fns, ({
        auto skg_1 = skg;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>>(crate::check::env::Def)>>(prism_rtl::rc([=](crate::check::env::Def p0) {
        return ({
            auto skg_1_2 = skg_1;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(crate::check::shrink::locals::DefWalk(skg_1_2, d))));
            });
        }));
        });
    }));
    })));
    auto sk = crate::check::shrink::locals::with_locals(skg, fold(walked, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{}, [&](const Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>& acc, const std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>& _p1) {
        auto&& ls = std::get<2>(_p1);
        return append(acc, ls);
    }));
    auto refs = append(each(walked, [&](const std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& rs = std::get<1>(_p0);
        return std::tuple{k, rs};
    }), run_to_end(each_job(drop(prism_rtl::val(sk).fns, len(fns)), ({
        auto sk_1 = sk;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>>>(crate::check::env::Def)>>(prism_rtl::rc([=](crate::check::env::Def p0) {
        return ({
            auto sk_1_2 = sk_1;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                call_then(crate::check::shrink::calls::start_def_refs(sk_1_2, d), [=](Array<Text> def_refs_3915) { return prism_rtl::finished(std::tuple{prism_rtl::val(d).qk, def_refs_3915}); });
            });
        }));
        });
    }));
    }))));
    auto keys_ = each(prism_rtl::val(sk).fns, [&](const crate::check::env::Def& d) { return prism_rtl::val(d).qk; });
    auto sccs_1 = crate::check::shrink::locals::sccs(keys_, refs);
    auto st2 = run_to_end(fold_job(sccs_1, crate::check::shrink::types::negative_types(g, st), ({
        auto sk_2 = sk;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Array<Text>>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Array<Text>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_2_3 = sk_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto comp = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::shrink::locals::ShrinkComponent(sk_2_3, s, comp))));
            });
        }));
        });
    })));
    })));
    auto st3 = run_to_end(fold_job(fns, st2, ({
        auto sk_2 = sk;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_2_3 = sk_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto d = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::shrink::summaries::LoopsOf(sk_2_3, s, d))));
            });
        }));
        });
    })));
    })));
    return std::tuple{st3, refs};
}


prism_rtl::Turn<std::tuple<crate::check::types::St, Array<std::tuple<Text, Array<Text>>>>> ShrinkCheck::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& defs = this->defs;
    auto fns = each(filter(defs, [&](const crate::check::env::Def& d) { return len(crate::check::shrink::types::def_clauses(d)) > Nat(0u); }), [&](const crate::check::env::Def& d) { return crate::check::shrink::types::own_key(d); });
    auto by_key = fold(fns, Map<Text, crate::check::env::Def>{}, [&](const Map<Text, crate::check::env::Def>& m, const crate::check::env::Def& d) { return insert(m, prism_rtl::val(d).qk, d); });
    auto homes = fold(fns, Array<Text>{}, [&](const Array<Text>& acc, const crate::check::env::Def& d) { return crate::check::types::add_text(acc, prism_rtl::val(d).home); });
    auto g_1 = g;
    auto st_2 = st;
    return call_then(crate::check::shrink::types::start_nat_minus_seeds(st_2), [=](Map<Text, Rel> nat_minus_seeds_3210) {
        return ({
            auto nats = nat_minus_seeds_3210;
            auto pre = fold(homes, Map<Text, Map<Text, Rel>>{}, [&](const Map<Text, Map<Text, Rel>>& m, const Text& h) { return insert(m, h, fold(keys(nats), crate::check::shrink::relations::prelude_seeds(g_1, h), [&](const Map<Text, Rel>& m2, const Text& k) { return insert(m2, k, crate::check::shrink::relations::no_rel()); })); });
            auto sk0 = Shrink{.g = g_1, .fns = fns, .by_key = by_key, .targets = crate::check::shrink::types::method_targets(g_1, fns), .impl_defs = crate::check::shrink::types::impl_defs(g_1, fns), .choices = prism_rtl::val(st_2).choices, .sums = Map<Text, Nat>{}, .seeds = pre, .local_of = Map<Text, Text>{}, .local_base = Map<Text, Map<Text, Rel>>{}};
            auto sk1 = ({
                Shrink this_ = sk0;
                this_.sums = crate::check::shrink::summaries::parts_summaries(sk0, fns);
                this_;
            });
            auto skg = ({
                Shrink this_ = sk1;
                this_.seeds = crate::check::shrink::calls::hof_seeds(sk1, homes);
                this_;
            });
            call_value(each_job(fns, ({
            auto skg_3 = skg;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>>(crate::check::env::Def)>>(prism_rtl::rc([=](crate::check::env::Def p0) {
            return ({
                auto skg_3_4 = skg_3;
                entered(once_job([=]() {
                return ({
                    auto d = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::check::shrink::locals::DefWalk(skg_3_4, d))));
                });
            }));
            });
        }));
        })), [=](Array<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>> each_3674) {
            return ({
                auto walked = each_3674;
                call_then(crate::check::shrink::locals::start_with_locals(skg, fold(walked, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{}, [&](const Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>& acc, const std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>& _p1) {
                auto&& ls = std::get<2>(_p1);
                return append(acc, ls);
            })), [=](Shrink with_locals_3717) {
                return ({
                    auto sk = with_locals_3717;
                    call_value(each_job(drop(prism_rtl::val(sk).fns, len(fns)), ({
                    auto sk_3 = sk;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>>>(crate::check::env::Def)>>(prism_rtl::rc([=](crate::check::env::Def p0) {
                    return ({
                        auto sk_3_4 = sk_3;
                        entered(once_job([=]() {
                        return ({
                            auto d = p0;
                            call_then(crate::check::shrink::calls::start_def_refs(sk_3_4, d), [=](Array<Text> def_refs_3915) { return prism_rtl::finished(std::tuple{prism_rtl::val(d).qk, def_refs_3915}); });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Text, Array<Text>>> each_3870) {
                    return ({
                        auto refs = append(each(walked, [&](const std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>& _p0) {
                            auto&& k = std::get<0>(_p0);
                            auto&& rs = std::get<1>(_p0);
                            return std::tuple{k, rs};
                        }), each_3870);
                        auto keys_ = each(prism_rtl::val(sk).fns, [&](const crate::check::env::Def& d) { return prism_rtl::val(d).qk; });
                        call_then(crate::check::shrink::locals::start_sccs(keys_, refs), [=](Array<Array<Text>> sccs_3986) {
                        return ({
                            auto sccs = sccs_3986;
                            call_then(crate::check::shrink::types::start_negative_types(g_1, st_2), [=](crate::check::types::St negative_types_4028) {
                            return call_value(fold_job(sccs, negative_types_4028, ({
                                auto sk_3 = sk;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Array<Text>>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Array<Text>> _p0) {
                                auto&& p0 = std::get<0>(_p0);
                                auto&& p1 = std::get<1>(_p0);
                                return ({
                                    auto sk_3_4 = sk_3;
                                    entered(once_job([=]() {
                                    return ({
                                        auto s = p0;
                                        auto comp = p1;
                                        (prism_rtl::more(prism_rtl::rc(crate::check::shrink::locals::ShrinkComponent(sk_3_4, s, comp))));
                                    });
                                }));
                                });
                            })));
                            })), [=](crate::check::types::St fold_4016) {
                                return ({
                                    auto st2 = fold_4016;
                                    call_value(fold_job(fns, st2, ({
                                    auto sk_3 = sk;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::env::Def> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto sk_3_4 = sk_3;
                                        entered(once_job([=]() {
                                        return ({
                                            auto s = p0;
                                            auto d = p1;
                                            (prism_rtl::more(prism_rtl::rc(crate::check::shrink::summaries::LoopsOf(sk_3_4, s, d))));
                                        });
                                    }));
                                    });
                                })));
                                })), [=](crate::check::types::St fold_4103) {
                                    return ({
                                        auto st3 = fold_4103;
                                        (prism_rtl::finished(std::tuple{st3, refs}));
                                    });
                                });
                                });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start ShrinkCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::St, Array<std::tuple<Text, Array<Text>>>>> start_shrink_check(crate::check::env::G g, crate::check::types::St st, Array<crate::check::env::Def> defs) {
    return prism_rtl::make_rc<ShrinkCheck>(g, st, defs);
}


/// UnusedDefs: unbounded fn [Def], [((Text, [Text]))], Nat -> [CDiag]
Array<crate::check::errors::CDiag> unused_defs(const Array<crate::check::env::Def>& defs, const Array<std::tuple<Text, Array<Text>>>& refs, const Nat& shown) {
    auto used0 = fold(refs, Map<Text, Unit>{}, [&](const Map<Text, Unit>& m, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        return fold(rs, m, [&](const Map<Text, Unit>& m2, const Text& r) { return r == k ? m2 : insert(m2, r, Unit{}); });
    });
    auto used = run_to_end(fold_job(defs, used0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Unit>>(std::tuple<Map<Text, Unit>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Unit>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto m = p0;
                auto d = p1;
                ({
                auto&& _m = prism_rtl::val(d).body;
                prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m) ? ({
                auto&& c = prism_rtl::as<crate::check::env::DefBody::DbCheck>(_m).a0;
                fold_job(prism_rtl::val(c).lines, m, ({
                auto d_1 = d;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Unit>>(std::tuple<Map<Text, Unit>, crate::syntax::decls::CheckLine>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Unit>, crate::syntax::decls::CheckLine> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto d_1_2 = d_1;
                    entered(once_job([=]() {
                    return ({
                        auto m2 = p0;
                        auto l = p1;
                        call_then(crate::check::typed::print::start_exprs_in(prism_rtl::val(l).expr), [=](Array<crate::syntax::Expr> exprs_in_4836) {
                        return prism_rtl::finished(fold(exprs_in_4836, m2, [&](const Map<Text, Unit>& m3, const crate::syntax::Expr& e) {
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<Map<Text, Unit>> _v;
                                auto&& _m = prism_rtl::val(prism_rtl::val(e).kind);
                                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                                    auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                                    _v.set(insert(insert(m3, crate::check::env::sname_key(n), Unit{}), crate::check::env::qual_key(prism_rtl::val(d_1_2).home, crate::check::env::sname_key(n)), Unit{}));
                                    goto _done;
                                }
                                {
                                    _v.set(m3);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        }));
                    });
                    });
                }));
                });
            }));
            }))->cycle();
            })
                : prism_rtl::finished(m);
            });
            });
        }));
    }))));
    auto own = filter(defs, [&](const crate::check::env::Def& d) { return ((((d->file < shown) && (!crate::check::env::has_key(used, prism_rtl::val(d).qk))) && (prism_rtl::val(d).name != Text::lit("@main"))) && (!is_method_def(d))) && (!is_testing_def(d)); });
    return each(own, [&](const crate::check::env::Def& d) { return crate::check::errors::CDiag{.code = Text::lit("unused"), .file = d->file, .span = prism_rtl::val(d).span, .message = prism_rtl::cat("nothing uses `", prism_rtl::val(d).name, "`"), .fix = Text::lit("delete it, or use it")}; });
}


prism_rtl::Turn<Array<crate::check::errors::CDiag>> UnusedDefs::cycle() const {
    const auto& defs = this->defs;
    const auto& refs = this->refs;
    const auto& shown = this->shown;
    auto used0 = fold(refs, Map<Text, Unit>{}, [&](const Map<Text, Unit>& m, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        return fold(rs, m, [&](const Map<Text, Unit>& m2, const Text& r) { return r == k ? m2 : insert(m2, r, Unit{}); });
    });
    auto defs_1 = defs;
    auto shown_2 = shown;
    return call_value(fold_job(defs_1, used0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Unit>>(std::tuple<Map<Text, Unit>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Unit>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto m = p0;
                auto d = p1;
                ({
                auto&& _m = prism_rtl::val(d).body;
                prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m) ? ({
                auto&& c = prism_rtl::as<crate::check::env::DefBody::DbCheck>(_m).a0;
                fold_job(prism_rtl::val(c).lines, m, ({
                auto d_3 = d;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Unit>>(std::tuple<Map<Text, Unit>, crate::syntax::decls::CheckLine>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Unit>, crate::syntax::decls::CheckLine> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto d_3_4 = d_3;
                    entered(once_job([=]() {
                    return ({
                        auto m2 = p0;
                        auto l = p1;
                        call_then(crate::check::typed::print::start_exprs_in(prism_rtl::val(l).expr), [=](Array<crate::syntax::Expr> exprs_in_4836) {
                        return prism_rtl::finished(fold(exprs_in_4836, m2, [&](const Map<Text, Unit>& m3, const crate::syntax::Expr& e) {
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<Map<Text, Unit>> _v;
                                auto&& _m = prism_rtl::val(prism_rtl::val(e).kind);
                                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                                    auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                                    _v.set(insert(insert(m3, crate::check::env::sname_key(n), Unit{}), crate::check::env::qual_key(prism_rtl::val(d_3_4).home, crate::check::env::sname_key(n)), Unit{}));
                                    goto _done;
                                }
                                {
                                    _v.set(m3);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        }));
                    });
                    });
                }));
                });
            }));
            }))->cycle();
            })
                : prism_rtl::finished(m);
            });
            });
        }));
    }))), [=](Map<Text, Unit> fold_4745) {
        return ({
            auto used = fold_4745;
            auto own = filter(defs_1, [&](const crate::check::env::Def& d) { return ((((d->file < shown_2) && (!crate::check::env::has_key(used, prism_rtl::val(d).qk))) && (prism_rtl::val(d).name != Text::lit("@main"))) && (!is_method_def(d))) && (!is_testing_def(d)); });
            (prism_rtl::finished(each(own, [&](const crate::check::env::Def& d) { return crate::check::errors::CDiag{.code = Text::lit("unused"), .file = d->file, .span = prism_rtl::val(d).span, .message = prism_rtl::cat("nothing uses `", prism_rtl::val(d).name, "`"), .fix = Text::lit("delete it, or use it")}; })));
        });
    });
}


/// `Start UnusedDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::errors::CDiag>> start_unused_defs(Array<crate::check::env::Def> defs, Array<std::tuple<Text, Array<Text>>> refs, Nat shown) {
    return prism_rtl::make_rc<UnusedDefs>(defs, refs, shown);
}


/// TestOnlyReached: fn [Src], [Def], [((Text, [Text]))] -> [CDiag]
Array<crate::check::errors::CDiag> test_only_reached(const Array<crate::check::errors::Src>& srcs, const Array<crate::check::env::Def>& defs, const Array<std::tuple<Text, Array<Text>>>& refs) {
    auto in_test = fold(defs, Map<Text, crate::check::env::Def>{}, [&](const Map<Text, crate::check::env::Def>& m, const crate::check::env::Def& d) {
        return def_role(srcs, d) == Text::lit("test")
            ? insert(m, prism_rtl::val(d).qk, d)
            : m;
    });
    return crate::prelude::size(in_test) == Nat(0u)
        ? Array<crate::check::errors::CDiag>{}
        : ({
        auto by_key = fold(defs, Map<Text, crate::check::env::Def>{}, [&](const Map<Text, crate::check::env::Def>& m, const crate::check::env::Def& d) { return insert(m, prism_rtl::val(d).qk, d); });
        fold(refs, Array<crate::check::errors::CDiag>{}, [&](const Array<crate::check::errors::CDiag>& acc, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::errors::CDiag>> _v;
            auto&& _m = crate::prelude::get(by_key, k);
            if (prism_rtl::is_some(_m)) {
                auto&& d = prism_rtl::some_of(_m);
                _v.set(def_role(srcs, d) == Text::lit("test")
                    ? acc
                    : fold(rs, acc, [&](const Array<crate::check::errors::CDiag>& a, const Text& r) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::check::errors::CDiag>> _v;
                        auto&& _m = crate::prelude::get(in_test, r);
                        if (prism_rtl::is_some(_m)) {
                            auto&& t = prism_rtl::some_of(_m);
                            _v.set(crate::prelude::push(a, crate::check::errors::CDiag{.code = Text::lit("test-only-reached"), .file = d->file, .span = prism_rtl::val(d).span, .message = prism_rtl::cat("`", prism_rtl::val(d).name, "` names `", prism_rtl::val(t).qk, "`, which a test module declares (", last_path_part(crate::check::errors::seg_at(or_(index(srcs, t->file), crate::check::errors::mk_src(Text::lit(""), Text::lit(""))), prism_rtl::val(prism_rtl::val(t).span).start)->path_), "): only test modules name it"), .fix = prism_rtl::cat("move `", prism_rtl::val(t).qk, "` out of the test module, or `", prism_rtl::val(d).name, "` into one")}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(a);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    });
}


/// DefRole: fn [Src], Def -> Text
Text def_role(const Array<crate::check::errors::Src>& srcs, const crate::check::env::Def& d) {
    return prism_rtl::val(crate::check::errors::seg_at(or_(index(srcs, d.file), crate::check::errors::mk_src(Text::lit(""), Text::lit(""))), prism_rtl::val(d.span).start)).role;
}


/// LastPathPart: fn Text -> Text
Text last_path_part(const Text& p_) {
    return or_(crate::syntax::lexer::chars::last(split_on(p_, Text::lit("/"))), p_);
}


/// IsTestingDef: fn Def -> Bool
bool is_testing_def(const crate::check::env::Def& d) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbTest>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// IsMethodDef: fn Def -> Bool
bool is_method_def(const crate::check::env::Def& d) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
        return true;
    }
    {
        return false;
    }
}

}  // namespace crate::check::shrink
