// The module `Check.Passes.Cycles`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/passes/cycles/module.hpp>
#include <check/env/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Passes.Cycles`, from `target/bootstrap/cpp-src/prismc/check/passes/cycles.prism`.
namespace crate::check::passes::cycles {

bool PCx::operator==(const PCx& o) const { return g == o.g && home == o.home && lams == o.lams && base == o.base; }

void PCx::show(Printer& p) const {
    p.record("PCx", {{"g", g}, {"home", home}, {"lams", lams}, {"base", base}});
}

Pod PCx::to_pod() const {
    return Pod::record("PCx", {{"g", prism_rtl::to_pod(g)}, {"home", prism_rtl::to_pod(home)}, {"lams", prism_rtl::to_pod(lams)}, {"base", prism_rtl::to_pod(base)}});
}

Result<PCx> PCx::from_pod(const Pod& whole) {
    return PCx{.g = TRY(prism_rtl::from_pod<crate::check::env::G>(TRY(crate::prelude::field(whole, "g")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .lams = TRY(prism_rtl::from_pod<Map<Nat, crate::syntax::Expr>>(TRY(crate::prelude::field(whole, "lams")))), .base = TRY(prism_rtl::from_pod<Map<Text, crate::check::shrink::Rel>>(TRY(crate::prelude::field(whole, "base"))))};
}


/// IsDelayedWidget: fn Text -> Bool
bool is_delayed_widget(const Text& n_p0) {
    return crate::check::types::has_text(Array(std::vector{Text::lit("@Defer"), Text::lit("@Later"), Text::lit("@Run"), Text::lit("@Machine"), Text::lit("@started")}), n_p0);
}


/// BlockPromptCycles: unbounded fn Env, St, Block -> St
crate::check::types::St block_prompt_cycles(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Block& b_p2) {
    auto defs_p3 = run_to_end(fold_job(b_p2.stmts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p7 = p0;
                auto s_p8 = p1;
                call_then(start_stmt_defs(s_p8), [=, acc_p7 = std::move(acc_p7)](Array<Text> stmt_defs_2204) { return prism_rtl::finished(append(acc_p7, stmt_defs_2204)); });
            });
        }));
    }))));
    auto cx_p4 = PCx{.g = env_p0.g, .home = env_p0.home, .lams = let_lambdas(b_p2.stmts), .base = prompt_base(env_p0, b_p2.stmts)};
    auto edges_p5 = run_to_end(fold_job(b_p2.stmts, Array<std::tuple<Text, Text>>{}, ({
        auto env_p0_1 = env_p0;
        auto st_p1_2 = st_p1;
        auto cx_p4_3 = cx_p4;
        auto defs_p3_4 = defs_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, Text>>>(std::tuple<Array<std::tuple<Text, Text>>, crate::syntax::Stmt>)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1), st_p1_2 = std::move(st_p1_2), cx_p4_3 = std::move(cx_p4_3), defs_p3_4 = std::move(defs_p3_4)](std::tuple<Array<std::tuple<Text, Text>>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0_1_5 = env_p0_1;
            auto st_p1_2_5 = st_p1_2;
            auto cx_p4_3_5 = cx_p4_3;
            auto defs_p3_4_5 = defs_p3_4;
            entered(once_job([=, env_p0_1_5 = std::move(env_p0_1_5), st_p1_2_5 = std::move(st_p1_2_5), cx_p4_3_5 = std::move(cx_p4_3_5), defs_p3_4_5 = std::move(defs_p3_4_5)]() {
            return ({
                auto acc_p9 = p0;
                auto s_pa = p1;
                call_then(start_prompt_edges(env_p0_1_5, st_p1_2_5, cx_p4_3_5, s_pa, defs_p3_4_5), [=, acc_p9 = std::move(acc_p9)](Array<std::tuple<Text, Text>> prompt_edges_2375) { return prism_rtl::finished(append(acc_p9, prompt_edges_2375)); });
            });
        }));
        });
    }));
    })));
    auto cyc_p6 = find_cycle(defs_p3, edges_p5);
    return len(cyc_p6) == Nat(0u)
        ? st_p1
        : ({
        auto span_pb = run_to_end(fold_job(b_p2.stmts, b_p2.span, ({
            auto cyc_p6_1 = cyc_p6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::Range>(std::tuple<crate::syntax::Range, crate::syntax::Stmt>)>>(prism_rtl::rc([=, cyc_p6_1 = std::move(cyc_p6_1)](std::tuple<crate::syntax::Range, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cyc_p6_1_2 = cyc_p6_1;
                entered(once_job([=, cyc_p6_1_2 = std::move(cyc_p6_1_2)]() {
                return ({
                    auto sp_pc = p0;
                    auto s_pd = p1;
                    call_then(start_stmt_defs(s_pd), [=, sp_pc = std::move(sp_pc)](Array<Text> stmt_defs_2543) {
                    return crate::check::types::has_text(stmt_defs_2543, or_(index(cyc_p6_1_2, Nat(0u)), Text::lit("")))
                        ? prism_rtl::finished(prism_rtl::deref(s_pd).span)
                        : prism_rtl::finished(sp_pc);
                });
                });
            }));
            });
        })));
        })));
        (crate::check::types::recording::err_fix(st_p1, Text::lit("prompt-cycle"), span_pb, prism_rtl::cat("a prompt cycle: ", crate::syntax::lexer::chars::join(each(cyc_p6, [&](const Text& n_pe) { return prism_rtl::cat("`", n_pe, "`"); }), Text::lit(", "))), Text::lit("break it with a hold: `$last <- start then ...` reads the value as the tick opened")));
    });
}


prism_rtl::Turn<crate::check::types::St> BlockPromptCycles::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& b_p2 = this->b_p2;
    auto b_p2_1 = b_p2;
    auto env_p0_2 = env_p0;
    auto st_p1_3 = st_p1;
    return call_value(fold_job(prism_rtl::deref(b_p2_1).stmts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p7 = p0;
                auto s_p8 = p1;
                call_then(start_stmt_defs(s_p8), [=, acc_p7 = std::move(acc_p7)](Array<Text> stmt_defs_2204) { return prism_rtl::finished(append(acc_p7, stmt_defs_2204)); });
            });
        }));
    }))), [=](Array<Text> fold_2161) {
        return ({
            auto defs_p3 = fold_2161;
            call_then(start_let_lambdas(prism_rtl::deref(b_p2_1).stmts), [=, defs_p3 = std::move(defs_p3)](Map<Nat, crate::syntax::Expr> let_lambdas_2263) {
            return call_then(start_prompt_base(env_p0_2, prism_rtl::deref(b_p2_1).stmts), [=](Map<Text, crate::check::shrink::Rel> prompt_base_2290) {
                return ({
                    auto cx_p4 = PCx{.g = prism_rtl::deref(env_p0_2).g, .home = prism_rtl::deref(env_p0_2).home, .lams = let_lambdas_2263, .base = prompt_base_2290};
                    call_value(fold_job(prism_rtl::deref(b_p2_1).stmts, Array<std::tuple<Text, Text>>{}, ({
                    auto env_p0_2_4 = env_p0_2;
                    auto st_p1_3_4 = st_p1_3;
                    auto cx_p4_4 = cx_p4;
                    auto defs_p3_5 = defs_p3;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, Text>>>(std::tuple<Array<std::tuple<Text, Text>>, crate::syntax::Stmt>)>>(prism_rtl::rc([=, env_p0_2_4 = std::move(env_p0_2_4), st_p1_3_4 = std::move(st_p1_3_4), cx_p4_4 = std::move(cx_p4_4), defs_p3_5 = std::move(defs_p3_5)](std::tuple<Array<std::tuple<Text, Text>>, crate::syntax::Stmt> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_p0_2_4_6 = env_p0_2_4;
                        auto st_p1_3_4_6 = st_p1_3_4;
                        auto cx_p4_4_6 = cx_p4_4;
                        auto defs_p3_5_6 = defs_p3_5;
                        entered(once_job([=, env_p0_2_4_6 = std::move(env_p0_2_4_6), st_p1_3_4_6 = std::move(st_p1_3_4_6), cx_p4_4_6 = std::move(cx_p4_4_6), defs_p3_5_6 = std::move(defs_p3_5_6)]() {
                        return ({
                            auto acc_p9 = p0;
                            auto s_pa = p1;
                            call_then(start_prompt_edges(env_p0_2_4_6, st_p1_3_4_6, cx_p4_4_6, s_pa, defs_p3_5_6), [=, acc_p9 = std::move(acc_p9)](Array<std::tuple<Text, Text>> prompt_edges_2375) { return prism_rtl::finished(append(acc_p9, prompt_edges_2375)); });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Text, Text>> fold_2332) {
                    return ({
                        auto edges_p5 = fold_2332;
                        call_then(start_find_cycle(defs_p3, edges_p5), [=](Array<Text> find_cycle_2423) {
                        return ({
                            auto cyc_p6 = find_cycle_2423;
                            len(cyc_p6) == Nat(0u)
                            ? prism_rtl::finished(st_p1_3)
                            : call_value(fold_job(prism_rtl::deref(b_p2_1).stmts, prism_rtl::deref(b_p2_1).span, ({
                            auto cyc_p6_4 = cyc_p6;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::Range>(std::tuple<crate::syntax::Range, crate::syntax::Stmt>)>>(prism_rtl::rc([=, cyc_p6_4 = std::move(cyc_p6_4)](std::tuple<crate::syntax::Range, crate::syntax::Stmt> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto cyc_p6_4_5 = cyc_p6_4;
                                entered(once_job([=, cyc_p6_4_5 = std::move(cyc_p6_4_5)]() {
                                return ({
                                    auto sp_pc = p0;
                                    auto s_pd = p1;
                                    call_then(start_stmt_defs(s_pd), [=, sp_pc = std::move(sp_pc)](Array<Text> stmt_defs_2543) {
                                    return crate::check::types::has_text(stmt_defs_2543, or_(index(cyc_p6_4_5, Nat(0u)), Text::lit("")))
                                        ? prism_rtl::finished(prism_rtl::deref(s_pd).span)
                                        : prism_rtl::finished(sp_pc);
                                });
                                });
                            }));
                            });
                        })));
                        })), [=](crate::syntax::Range fold_2500) {
                            return ({
                                auto span_pb = fold_2500;
                                (prism_rtl::finished(crate::check::types::recording::err_fix(st_p1_3, Text::lit("prompt-cycle"), span_pb, prism_rtl::cat("a prompt cycle: ", crate::syntax::lexer::chars::join(each(cyc_p6, [&](const Text& n_pe) { return prism_rtl::cat("`", n_pe, "`"); }), Text::lit(", "))), Text::lit("break it with a hold: `$last <- start then ...` reads the value as the tick opened"))));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
        });
        });
    });
}


/// `Start BlockPromptCycles, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_block_prompt_cycles(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2) {
    return prism_rtl::make_rc<BlockPromptCycles>(env_p0, st_p1, b_p2);
}


/// StmtDefs: unbounded fn Stmt -> [Text]
Array<Text> stmt_defs(const crate::syntax::Stmt& s_p0) {
    auto&& _m = s_p0.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
        auto&& p_p1 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        return crate::check::env::names::pattern_names(p_p1);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_p2 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        return crate::check::env::names::pattern_names(p_p2);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> StmtDefs::cycle() const {
    const auto& s_p0 = this->s_p0;
    return ({
        auto&& _m = prism_rtl::deref(s_p0).kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
        auto&& p_p1 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::env::names::PatternNames(p_p1)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_p2 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::env::names::PatternNames(p_p2)));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start StmtDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_stmt_defs(crate::syntax::Stmt s_p0) {
    return prism_rtl::make_rc<StmtDefs>(s_p0);
}


/// PromptEdges: unbounded fn Env, St, PCx, Stmt, [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> prompt_edges(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const PCx& cx_p2, const crate::syntax::Stmt& s_p3, const Array<Text>& defs_p4) {
    auto&& _m = s_p3.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        return Array<std::tuple<Text, Text>>{};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_p5 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e_p6 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        return crate::check::passes::cycles::edges(crate::check::env::names::pattern_names(p_p5), prompt_reads(cx_p2, e_p6, defs_p4));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_p7 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e_p8 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto names_p9 = crate::check::env::names::pattern_names(p_p7);
        auto layer_pa = run_to_end(fold_job(names_p9, Text::lit(""), ({
            auto env_p0_1 = env_p0;
            auto st_p1_2 = st_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text>)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1), st_p1_2 = std::move(st_p1_2)](std::tuple<Text, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_p0_1_3 = env_p0_1;
                auto st_p1_2_3 = st_p1_2;
                entered(once_job([=, env_p0_1_3 = std::move(env_p0_1_3), st_p1_2_3 = std::move(st_p1_2_3)]() {
                return ({
                    auto acc_pb = p0;
                    auto n_pc = p1;
                    ({
                    auto&& _m = crate::prelude::get(env_p0_1_3.locals, n_pc);
                    prism_rtl::is_some(_m) ? ({
                    auto&& sc_pd = prism_rtl::some_of(_m);
                    prism_rtl::more(prism_rtl::rc(crate::check::types::HeadSigil(st_p1_2_3, prism_rtl::deref(sc_pd).ty)));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(acc_pb)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })));
        return crate::check::passes::cycles::edges(names_p9, run_to_end(filter_job(prompt_reads(cx_p2, e_p8, defs_p4), ({
            auto env_p0_1 = env_p0;
            auto st_p1_2 = st_p1;
            auto layer_pa_3 = layer_pa;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1), st_p1_2 = std::move(st_p1_2), layer_pa_3 = std::move(layer_pa_3)](Text p0) {
            return ({
                auto env_p0_1_4 = env_p0_1;
                auto st_p1_2_4 = st_p1_2;
                auto layer_pa_3_4 = layer_pa_3;
                entered(once_job([=, env_p0_1_4 = std::move(env_p0_1_4), st_p1_2_4 = std::move(st_p1_2_4), layer_pa_3_4 = std::move(layer_pa_3_4)]() {
                return ({
                    auto n_pe = p0;
                    (prism_rtl::more(prism_rtl::rc(ReadIsPrompt(env_p0_1_4, st_p1_2_4, n_pe, layer_pa_3_4))));
                });
            }));
            });
        })));
        }))));
    }
    {
        return Array<std::tuple<Text, Text>>{};
    }
}


prism_rtl::Turn<Array<std::tuple<Text, Text>>> PromptEdges::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& cx_p2 = this->cx_p2;
    const auto& s_p3 = this->s_p3;
    const auto& defs_p4 = this->defs_p4;
    return ({
        auto&& _m = prism_rtl::deref(s_p3).kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? prism_rtl::finished(Array<std::tuple<Text, Text>>{})
        : prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_p5 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e_p6 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        ({
        auto cx_p2_1 = cx_p2;
        auto defs_p4_2 = defs_p4;
        auto e_p6_3 = e_p6;
        auto p_p5_4 = p_p5;
        call_then(crate::check::env::names::start_pattern_names(p_p5_4), [=, cx_p2_1 = std::move(cx_p2_1), defs_p4_2 = std::move(defs_p4_2), e_p6_3 = std::move(e_p6_3)](Array<Text> pattern_names_3267) { return call_then(start_prompt_reads(cx_p2_1, e_p6_3, defs_p4_2), [=](Array<Text> prompt_reads_3285) { return prism_rtl::finished(crate::check::passes::cycles::edges(pattern_names_3267, prompt_reads_3285)); }); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_p7 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e_p8 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto cx_p2_1 = cx_p2;
        auto defs_p4_2 = defs_p4;
        auto e_p8_3 = e_p8;
        auto env_p0_4 = env_p0;
        auto p_p7_5 = p_p7;
        auto st_p1_6 = st_p1;
        call_then(crate::check::env::names::start_pattern_names(p_p7_5), [=, cx_p2_1 = std::move(cx_p2_1), defs_p4_2 = std::move(defs_p4_2), e_p8_3 = std::move(e_p8_3), env_p0_4 = std::move(env_p0_4), st_p1_6 = std::move(st_p1_6)](Array<Text> pattern_names_3353) {
        return ({
            auto names_p9 = pattern_names_3353;
            call_value(fold_job(names_p9, Text::lit(""), ({
            auto env_p0_4_7 = env_p0_4;
            auto st_p1_6_7 = st_p1_6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text>)>>(prism_rtl::rc([=, env_p0_4_7 = std::move(env_p0_4_7), st_p1_6_7 = std::move(st_p1_6_7)](std::tuple<Text, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_p0_4_7_7 = env_p0_4_7;
                auto st_p1_6_7_7 = st_p1_6_7;
                entered(once_job([=, env_p0_4_7_7 = std::move(env_p0_4_7_7), st_p1_6_7_7 = std::move(st_p1_6_7_7)]() {
                return ({
                    auto acc_pb = p0;
                    auto n_pc = p1;
                    ({
                    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0_4_7_7).locals, n_pc);
                    prism_rtl::is_some(_m) ? ({
                    auto&& sc_pd = prism_rtl::some_of(_m);
                    prism_rtl::more(prism_rtl::rc(crate::check::types::HeadSigil(st_p1_6_7_7, prism_rtl::deref(sc_pd).ty)));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(acc_pb)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })), [=](Text fold_3388) {
            return ({
                auto layer_pa = fold_3388;
                call_then(start_prompt_reads(cx_p2_1, e_p8_3, defs_p4_2), [=, layer_pa = std::move(layer_pa)](Array<Text> prompt_reads_3524) {
                return call_value(filter_job(prompt_reads_3524, ({
                    auto env_p0_4_7 = env_p0_4;
                    auto st_p1_6_7 = st_p1_6;
                    auto layer_pa_7 = layer_pa;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, env_p0_4_7 = std::move(env_p0_4_7), st_p1_6_7 = std::move(st_p1_6_7), layer_pa_7 = std::move(layer_pa_7)](Text p0) {
                    return ({
                        auto env_p0_4_7_8 = env_p0_4_7;
                        auto st_p1_6_7_8 = st_p1_6_7;
                        auto layer_pa_7_8 = layer_pa_7;
                        entered(once_job([=, env_p0_4_7_8 = std::move(env_p0_4_7_8), st_p1_6_7_8 = std::move(st_p1_6_7_8), layer_pa_7_8 = std::move(layer_pa_7_8)]() {
                        return ({
                            auto n_pe = p0;
                            (prism_rtl::more(prism_rtl::rc(ReadIsPrompt(env_p0_4_7_8, st_p1_6_7_8, n_pe, layer_pa_7_8))));
                        });
                    }));
                    });
                })));
                })), [=](Array<Text> filter_3516) { return prism_rtl::finished(crate::check::passes::cycles::edges(names_p9, filter_3516)); });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::finished(Array<std::tuple<Text, Text>>{});
    });
}


/// `Start PromptEdges, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_prompt_edges(crate::check::expr::Env env_p0, crate::check::types::St st_p1, PCx cx_p2, crate::syntax::Stmt s_p3, Array<Text> defs_p4) {
    return prism_rtl::make_rc<PromptEdges>(env_p0, st_p1, cx_p2, s_p3, defs_p4);
}


/// Edges: fn [Text], [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> edges(const Array<Text>& froms_p0, const Array<Text>& tos_p1) {
    return fold(froms_p0, Array<std::tuple<Text, Text>>{}, [&](const Array<std::tuple<Text, Text>>& acc_p2, const Text& f_p3) { return append(acc_p2, each(tos_p1, [&](const Text& t_p4) { return std::tuple{f_p3, t_p4}; })); });
}


/// ReadIsPrompt: unbounded fn Env, St, Text, Text -> Bool
bool read_is_prompt(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& n_p2, const Text& layer_p3) {
    auto&& _m = crate::prelude::get(env_p0.locals, n_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& sc_p4 = prism_rtl::some_of(_m);
        auto h_p5 = crate::check::types::head_sigil(st_p1, prism_rtl::deref(sc_p4).ty);
        return layer_p3 == Text::lit("!")
            ? (h_p5 == Text::lit("!")) || (h_p5 == Text::lit("@"))
            : layer_p3 == Text::lit("$")
            ? (h_p5 == Text::lit("$")) || (h_p5 == Text::lit("!"))
            : ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::check::types::recording::walk(st_p1, prism_rtl::deref(sc_p4).ty);
            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                _v.set(false);
                goto _done;
            }
            {
                _v.set(crate::check::env::is_lower_text(crate::syntax::lexer::chars::drop_prefix(n_p2, crate::check::types::unify::marks_of(n_p2))) && (h_p5 == Text::lit("")));
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> ReadIsPrompt::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& n_p2 = this->n_p2;
    const auto& layer_p3 = this->layer_p3;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0).locals, n_p2);
        prism_rtl::is_some(_m) ? ({
        auto&& sc_p4 = prism_rtl::some_of(_m);
        ({
        auto layer_p3_1 = layer_p3;
        auto n_p2_2 = n_p2;
        auto st_p1_3 = st_p1;
        call_then(crate::check::types::start_head_sigil(st_p1_3, prism_rtl::deref(sc_p4).ty), [=, layer_p3_1 = std::move(layer_p3_1), n_p2_2 = std::move(n_p2_2)](Text head_sigil_4011) {
        return ({
            auto h_p5 = head_sigil_4011;
            layer_p3_1 == Text::lit("!")
            ? prism_rtl::finished((h_p5 == Text::lit("!")) || (h_p5 == Text::lit("@")))
            : layer_p3_1 == Text::lit("$")
            ? prism_rtl::finished((h_p5 == Text::lit("$")) || (h_p5 == Text::lit("!")))
            : call_then(crate::check::types::recording::start_walk(st_p1_3, prism_rtl::deref(sc_p4).ty), [=](crate::check::types::Ty walk_4149) {
            return ({
                prism_rtl::is<crate::check::types::Ty::TyFn>(walk_4149) ? prism_rtl::finished(false)
                : prism_rtl::finished(crate::check::env::is_lower_text(crate::syntax::lexer::chars::drop_prefix(n_p2_2, crate::check::types::unify::marks_of(n_p2_2))) && (h_p5 == Text::lit("")));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ReadIsPrompt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_read_is_prompt(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text n_p2, Text layer_p3) {
    return prism_rtl::make_rc<ReadIsPrompt>(env_p0, st_p1, n_p2, layer_p3);
}


/// PromptBase: unbounded fn Env, [Stmt] -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> prompt_base(const crate::check::expr::Env& env_p0, const Array<crate::syntax::Stmt>& stmts_p1) {
    auto pre_p2 = crate::check::shrink::relations::prelude_seeds(env_p0.g, env_p0.home);
    auto seeds_p3 = fold(keys(pre_p2), pre_p2, [&](const Map<Text, crate::check::shrink::Rel>& m_p4, const Text& k_p5) {
        return crate::check::env::has_key(env_p0.locals, crate::syntax::lexer::chars::drop_prefix(k_p5, Text::lit("pre:")))
            ? crate::prelude::remove(m_p4, k_p5)
            : m_p4;
    });
    return fold(stmts_p1, seeds_p3, [&](const Map<Text, crate::check::shrink::Rel>& m_p6, const crate::syntax::Stmt& s_p7) { return lam_let_rels(s_p7, m_p6); });
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> PromptBase::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& stmts_p1 = this->stmts_p1;
    auto pre_p2 = crate::check::shrink::relations::prelude_seeds(prism_rtl::deref(env_p0).g, prism_rtl::deref(env_p0).home);
    auto seeds_p3 = fold(keys(pre_p2), pre_p2, [&](const Map<Text, crate::check::shrink::Rel>& m_p4, const Text& k_p5) {
        return crate::check::env::has_key(prism_rtl::deref(env_p0).locals, crate::syntax::lexer::chars::drop_prefix(k_p5, Text::lit("pre:")))
            ? crate::prelude::remove(m_p4, k_p5)
            : m_p4;
    });
    return prism_rtl::finished(fold(stmts_p1, seeds_p3, [&](const Map<Text, crate::check::shrink::Rel>& m_p6, const crate::syntax::Stmt& s_p7) { return lam_let_rels(s_p7, m_p6); }));
}


/// `Start PromptBase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_prompt_base(crate::check::expr::Env env_p0, Array<crate::syntax::Stmt> stmts_p1) {
    return prism_rtl::make_rc<PromptBase>(env_p0, stmts_p1);
}


/// LamLetRels: fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> lam_let_rels(const crate::syntax::Stmt& s_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    auto&& _m = s_p0.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_p2 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e_p3 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto&& _m = std::tuple{prism_rtl::deref(prism_rtl::deref(p_p2).kind), lambda_of(e_p3)};
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
            auto&& n_p4 = prism_rtl::as<crate::syntax::PatternKind::PName>(std::get<0>(_m)).a0;
            auto&& lam_p5 = prism_rtl::some_of(std::get<1>(_m));
            return insert(m_p1, prism_rtl::cat("lamlet:", crate::check::env::sname_key(n_p4)), crate::check::shrink::Rel{.param = prism_rtl::deref(prism_rtl::deref(lam_p5).span).start, .strict = false});
        }
        {
            return m_p1;
        }
    }
    {
        return m_p1;
    }
}


/// ?LambdaOf: fn Expr -> ?Expr
std::optional<crate::syntax::Expr> lambda_of(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        return std::optional(e_p0);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p1 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return lambda_of(prism_rtl::deref(prism_rtl::deref(x_p1)));
    }
    {
        return std::optional<crate::syntax::Expr>{};
    }
}


/// LetLambdas: unbounded fn [Stmt] -> (Nat ==> Expr)
Map<Nat, crate::syntax::Expr> let_lambdas(const Array<crate::syntax::Stmt>& stmts_p0) {
    return fold(crate::check::shrink::walk::stmts_spots(stmts_p0, Map<Text, crate::check::shrink::Rel>{}), Map<Nat, crate::syntax::Expr>{}, [&](const Map<Nat, crate::syntax::Expr>& m_p1, const crate::check::shrink::walk::Spot& sp_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
            if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(sp_p2)) {
                auto&& s_p3 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp_p2).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
                    auto&& _m = prism_rtl::deref(s_p3).kind;
                    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                        auto&& e_p4 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
                            auto&& _m = lambda_of(e_p4);
                            if (prism_rtl::is_some(_m)) {
                                auto&& lam_p5 = prism_rtl::some_of(_m);
                                _v.set(insert(m_p1, prism_rtl::deref(prism_rtl::deref(lam_p5).span).start, lam_p5));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(m_p1);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    {
                        _v.set(m_p1);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(m_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Map<Nat, crate::syntax::Expr>> LetLambdas::cycle() const {
    const auto& stmts_p0 = this->stmts_p0;
    auto stmts_p0_1 = stmts_p0;
    return call_then(crate::check::shrink::walk::start_stmts_spots(stmts_p0_1, Map<Text, crate::check::shrink::Rel>{}), [=](Array<crate::check::shrink::walk::Spot> stmts_spots_5873) {
        return prism_rtl::finished(fold(stmts_spots_5873, Map<Nat, crate::syntax::Expr>{}, [&](const Map<Nat, crate::syntax::Expr>& m_p1, const crate::check::shrink::walk::Spot& sp_p2) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
                if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(sp_p2)) {
                    auto&& s_p3 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp_p2).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
                        auto&& _m = prism_rtl::deref(s_p3).kind;
                        if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                            auto&& e_p4 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
                                auto&& _m = lambda_of(e_p4);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& lam_p5 = prism_rtl::some_of(_m);
                                    _v.set(insert(m_p1, prism_rtl::deref(prism_rtl::deref(lam_p5).span).start, lam_p5));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(m_p1);
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        {
                            _v.set(m_p1);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                {
                    _v.set(m_p1);
                    goto _done;
                }
            _done:
                _v.take();
            });
        }));
    });
}


/// `Start LetLambdas, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Nat, crate::syntax::Expr>> start_let_lambdas(Array<crate::syntax::Stmt> stmts_p0) {
    return prism_rtl::make_rc<LetLambdas>(stmts_p0);
}


/// PromptReads: unbounded fn PCx, Expr, [Text] -> [Text]
Array<Text> prompt_reads(const PCx& cx_p0, const crate::syntax::Expr& e_p1, const Array<Text>& defs_p2) {
    auto spots_p3 = prompt_spots(cx_p0, e_p1, cx_p0.base);
    return run_to_end(fold_job(spots_p3, Array<Text>{}, ({
        auto defs_p2_1 = defs_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, defs_p2_1 = std::move(defs_p2_1)](std::tuple<Array<Text>, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto defs_p2_1_2 = defs_p2_1;
            entered(once_job([=, defs_p2_1_2 = std::move(defs_p2_1_2)]() {
            return ({
                auto acc_p4 = p0;
                auto sp_p5 = p1;
                call_then(crate::check::shrink::walk::start_spot_sites(sp_p5), [=, acc_p4 = std::move(acc_p4)](Array<crate::check::shrink::walk::Site> spot_sites_7222) {
                return prism_rtl::finished(fold(spot_sites_7222, acc_p4, [&](const Array<Text>& a2_p6, const crate::check::shrink::walk::Site& site_p7) {
                    return crate::check::types::has_text(defs_p2_1_2, prism_rtl::deref(site_p7).callee) && (!crate::check::shrink::relations::is_local(prism_rtl::deref(site_p7).rels, prism_rtl::deref(site_p7).callee))
                        ? crate::check::types::add_text(a2_p6, prism_rtl::deref(site_p7).callee)
                        : a2_p6;
                }));
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> PromptReads::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& e_p1 = this->e_p1;
    const auto& defs_p2 = this->defs_p2;
    auto cx_p0_1 = cx_p0;
    auto defs_p2_2 = defs_p2;
    auto e_p1_3 = e_p1;
    return call_then(start_prompt_spots(cx_p0_1, e_p1_3, prism_rtl::deref(cx_p0_1).base), [=](Array<crate::check::shrink::walk::Spot> prompt_spots_7156) {
        return ({
            auto spots_p3 = prompt_spots_7156;
            fold_job(spots_p3, Array<Text>{}, ({
            auto defs_p2_2_4 = defs_p2_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, defs_p2_2_4 = std::move(defs_p2_2_4)](std::tuple<Array<Text>, crate::check::shrink::walk::Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto defs_p2_2_4_4 = defs_p2_2_4;
                entered(once_job([=, defs_p2_2_4_4 = std::move(defs_p2_2_4_4)]() {
                return ({
                    auto acc_p4 = p0;
                    auto sp_p5 = p1;
                    call_then(crate::check::shrink::walk::start_spot_sites(sp_p5), [=, acc_p4 = std::move(acc_p4)](Array<crate::check::shrink::walk::Site> spot_sites_7222) {
                    return prism_rtl::finished(fold(spot_sites_7222, acc_p4, [&](const Array<Text>& a2_p6, const crate::check::shrink::walk::Site& site_p7) {
                        return crate::check::types::has_text(defs_p2_2_4_4, prism_rtl::deref(site_p7).callee) && (!crate::check::shrink::relations::is_local(prism_rtl::deref(site_p7).rels, prism_rtl::deref(site_p7).callee))
                            ? crate::check::types::add_text(a2_p6, prism_rtl::deref(site_p7).callee)
                            : a2_p6;
                    }));
                });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start PromptReads, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_prompt_reads(PCx cx_p0, crate::syntax::Expr e_p1, Array<Text> defs_p2) {
    return prism_rtl::make_rc<PromptReads>(cx_p0, e_p1, defs_p2);
}


/// PromptSpots: unbounded fn PCx, Expr, (Text ==> Rel) -> [Spot]
Array<crate::check::shrink::walk::Spot> prompt_spots(const PCx& cx_p0, const crate::syntax::Expr& e_p1, const Map<Text, crate::check::shrink::Rel>& m_p2) {
    return run_to_end(fold_job(prompt_kids(cx_p0, e_p1, m_p2), Array(std::vector{crate::check::shrink::walk::Spot(crate::check::shrink::walk::Spot::SpotExpr{e_p1, m_p2})}), ({
        auto cx_p0_1 = cx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Spot>>(std::tuple<Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid>)>>(prism_rtl::rc([=, cx_p0_1 = std::move(cx_p0_1)](std::tuple<Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx_p0_1_2 = cx_p0_1;
            entered(once_job([=, cx_p0_1_2 = std::move(cx_p0_1_2)]() {
            return ({
                auto acc_p3 = p0;
                auto k_p4 = p1;
                (prism_rtl::finished(append(acc_p3, prompt_kid_spots(cx_p0_1_2, k_p4))));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::check::shrink::walk::Spot>> PromptSpots::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& e_p1 = this->e_p1;
    const auto& m_p2 = this->m_p2;
    return fold_job(prompt_kids(cx_p0, e_p1, m_p2), Array(std::vector{crate::check::shrink::walk::Spot(crate::check::shrink::walk::Spot::SpotExpr{e_p1, m_p2})}), ({
        auto cx_p0_1 = cx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Spot>>(std::tuple<Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid>)>>(prism_rtl::rc([=, cx_p0_1 = std::move(cx_p0_1)](std::tuple<Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx_p0_1_2 = cx_p0_1;
            entered(once_job([=, cx_p0_1_2 = std::move(cx_p0_1_2)]() {
            return ({
                auto acc_p3 = p0;
                auto k_p4 = p1;
                (prism_rtl::finished(append(acc_p3, prompt_kid_spots(cx_p0_1_2, k_p4))));
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start PromptSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::shrink::walk::Spot>> start_prompt_spots(PCx cx_p0, crate::syntax::Expr e_p1, Map<Text, crate::check::shrink::Rel> m_p2) {
    return prism_rtl::make_rc<PromptSpots>(cx_p0, e_p1, m_p2);
}


/// PromptKids: unbounded fn PCx, Expr, (Text ==> Rel) -> [Kid]
Array<crate::check::shrink::walk::Kid> prompt_kids(const PCx& cx_p0, const crate::syntax::Expr& e_p1, const Map<Text, crate::check::shrink::Rel>& m_p2) {
    auto&& _m = prism_rtl::deref(e_p1.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        return Array<crate::check::shrink::walk::Kid>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
        auto&& body_p3 = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        return row_kids(body_p3, m_p2, Array<Text>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
        auto&& binders_o4 = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& body_p5 = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        return row_kids(body_p5, m_p2, for_binder_names(binders_o4));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        return Array<crate::check::shrink::walk::Kid>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_p6 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        return prompt_call_kids(cx_p0, e_p1, crate::check::shrink::walk::callee_name(prism_rtl::deref(prism_rtl::deref(c_p6))), m_p2);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& n_p7 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        return prompt_call_kids(cx_p0, e_p1, std::optional(crate::check::env::sname_key(n_p7)), m_p2);
    }
    {
        return crate::check::shrink::walk::expr_kids(e_p1, m_p2);
    }
}


/// RowKids: unbounded fn Block, (Text ==> Rel), [Text] -> [Kid]
Array<crate::check::shrink::walk::Kid> row_kids(const crate::syntax::Block& body_p0, const Map<Text, crate::check::shrink::Rel>& m_p1, const Array<Text>& binders_p2) {
    auto lines_p3 = filter(body_p0.stmts, [&](const crate::syntax::Stmt& s_p5) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = prism_rtl::deref(s_p5).kind;
            if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
                _v.set(false);
                goto _done;
            }
            {
                _v.set(true);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto own_p4 = run_to_end(fold_job(body_p0.stmts, append(binders_p2, Array(std::vector{Text::lit("_"), Text::lit("$_")})), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p6 = p0;
                auto s_p7 = p1;
                call_then(start_stmt_defs(s_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> stmt_defs_8893) { return prism_rtl::finished(append(acc_p6, stmt_defs_8893)); });
            });
        }));
    }))));
    return Array(std::vector{crate::check::shrink::walk::Kid(crate::check::shrink::walk::Kid::KidStmts{lines_p3, crate::check::shrink::relations::hide(m_p1, own_p4)})});
}


/// ForBinderNames: unbounded fn ?ForBinders -> [Text]
Array<Text> for_binder_names(const std::optional<crate::syntax::ForBinders>& binders_o0) {
    if (prism_rtl::is_some(binders_o0)) {
        auto&& fb_p1 = prism_rtl::some_of(binders_o0);
        auto&& _m = prism_rtl::deref(fb_p1).second;
        if (prism_rtl::is_some(_m)) {
            auto&& second_p2 = prism_rtl::some_of(_m);
            return append(crate::check::env::names::pattern_names(prism_rtl::deref(fb_p1).first), crate::check::env::names::pattern_names(second_p2));
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::env::names::pattern_names(prism_rtl::deref(fb_p1).first);
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(binders_o0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// PromptCallKids: unbounded fn PCx, Expr, ?Text, (Text ==> Rel) -> [Kid]
Array<crate::check::shrink::walk::Kid> prompt_call_kids(const PCx& cx_p0, const crate::syntax::Expr& e_p1, const std::optional<Text>& n_o2, const Map<Text, crate::check::shrink::Rel>& m_p3) {
    if (prism_rtl::is_some(n_o2)) {
        auto&& n_p4 = prism_rtl::some_of(n_o2);
        auto called_p5 = follow_lam_let(cx_p0, n_p4, m_p3);
        return crate::check::shrink::relations::is_local(m_p3, n_p4)
            ? append(called_p5, open_lambdas(cx_p0, crate::check::shrink::walk::expr_kids(e_p1, m_p3)))
            : len(called_p5) > Nat(0u)
            ? append(called_p5, open_lambdas(cx_p0, crate::check::shrink::walk::expr_kids(e_p1, m_p3)))
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::shrink::walk::Kid>> _v;
            auto&& _m = crate::check::shrink::locals::resolve_callee(cx_p0.g, cx_p0.home, n_p4);
            if (prism_rtl::is_some(_m)) {
                auto&& k_p6 = prism_rtl::some_of(_m);
                _v.set(crate::check::shrink::relations::is_prelude_key(cx_p0.g, k_p6) && is_delayed_widget(crate::syntax::lexer::chars::drop_prefix(k_p6, Text::lit("Prelude.")))
                    ? Array<crate::check::shrink::walk::Kid>{}
                    : crate::check::shrink::relations::is_prelude_key(cx_p0.g, k_p6) && crate::syntax::lexer::chars::has_prefix(k_p6, Text::lit("Prelude.@"))
                    ? crate::check::shrink::walk::expr_kids(e_p1, m_p3)
                    : open_lambdas(cx_p0, crate::check::shrink::walk::expr_kids(e_p1, m_p3)));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(open_lambdas(cx_p0, crate::check::shrink::walk::expr_kids(e_p1, m_p3)));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(n_o2)) {
        return open_lambdas(cx_p0, crate::check::shrink::walk::expr_kids(e_p1, m_p3));
    }
    prism_rtl::unreachable("no arm matched");
}


/// OpenLambdas: unbounded fn PCx, [Kid] -> [Kid]
Array<crate::check::shrink::walk::Kid> open_lambdas(const PCx& cx_p0, const Array<crate::check::shrink::walk::Kid>& kids_p1) {
    return run_to_end(fold_job(kids_p1, Array<crate::check::shrink::walk::Kid>{}, ({
        auto cx_p0_1 = cx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Kid>>(std::tuple<Array<crate::check::shrink::walk::Kid>, crate::check::shrink::walk::Kid>)>>(prism_rtl::rc([=, cx_p0_1 = std::move(cx_p0_1)](std::tuple<Array<crate::check::shrink::walk::Kid>, crate::check::shrink::walk::Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx_p0_1_2 = cx_p0_1;
            entered(once_job([=, cx_p0_1_2 = std::move(cx_p0_1_2)]() {
            return ({
                auto acc_p2 = p0;
                auto k_p3 = p1;
                ({
                prism_rtl::is<crate::check::shrink::walk::Kid::KidExpr>(k_p3) ? ({
                auto&& x_p4 = prism_rtl::as<crate::check::shrink::walk::Kid::KidExpr>(k_p3).a0;
                auto&& m_p5 = prism_rtl::as<crate::check::shrink::walk::Kid::KidExpr>(k_p3).a1;
                ({
                auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p4).kind);
                prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
                auto&& ps_o6 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
                auto&& body_p7 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
                ({
                auto ps_o6_2 = ps_o6;
                auto body_p7_3 = prism_rtl::deref(prism_rtl::deref(body_p7));
                auto m_p5_4 = m_p5;
                call_then(crate::check::shrink::walk::start_patterns_names(or_(ps_o6_2, Array<crate::syntax::Pattern_>{})), [=, body_p7_3 = std::move(body_p7_3), m_p5_4 = std::move(m_p5_4)](Array<Text> patterns_names_10512) { return prism_rtl::finished(crate::prelude::push(acc_p2, crate::check::shrink::walk::lambda_kid(body_p7_3, crate::check::shrink::relations::hide(m_p5_4, patterns_names_10512)))); });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
                auto&& n_p8 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                prism_rtl::finished(append(crate::prelude::push(acc_p2, k_p3), follow_lam_let(cx_p0_1_2, crate::check::env::sname_key(n_p8), m_p5)));
            })
                : prism_rtl::finished(crate::prelude::push(acc_p2, k_p3));
            });
            })
                : prism_rtl::finished(crate::prelude::push(acc_p2, k_p3));
            });
            });
        }));
        });
    })));
    })));
}


/// FollowLamLet: unbounded fn PCx, Text, (Text ==> Rel) -> [Kid]
Array<crate::check::shrink::walk::Kid> follow_lam_let(const PCx& cx_p0, const Text& n_p1, const Map<Text, crate::check::shrink::Rel>& m_p2) {
    auto&& _m = crate::prelude::get(m_p2, prism_rtl::cat("lamlet:", n_p1));
    if (prism_rtl::is_some(_m)) {
        auto&& r_p3 = prism_rtl::some_of(_m);
        return crate::check::env::has_key(m_p2, prism_rtl::cat("seen:", prism_rtl::deref(r_p3).param))
            ? Array<crate::check::shrink::walk::Kid>{}
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::shrink::walk::Kid>> _v;
            auto&& _m = crate::prelude::get(cx_p0.lams, prism_rtl::deref(r_p3).param);
            if (prism_rtl::is_some(_m)) {
                auto&& lam_p4 = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::check::shrink::walk::Kid>> _v;
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(lam_p4).kind);
                    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
                        auto&& ps_o5 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
                        auto&& body_p6 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
                        _v.set(({
                            auto seen_p7 = fold(keys(m_p2), cx_p0.base, [&](const Map<Text, crate::check::shrink::Rel>& m2_p8, const Text& k_p9) {
                                return crate::syntax::lexer::chars::has_prefix(k_p9, Text::lit("seen:"))
                                    ? insert(m2_p8, k_p9, crate::check::shrink::relations::no_rel())
                                    : m2_p8;
                            });
                            (Array(std::vector{crate::check::shrink::walk::lambda_kid(prism_rtl::deref(prism_rtl::deref(body_p6)), crate::check::shrink::relations::hide(insert(seen_p7, prism_rtl::cat("seen:", prism_rtl::deref(r_p3).param), crate::check::shrink::relations::no_rel()), crate::check::shrink::walk::patterns_names(or_(ps_o5, Array<crate::syntax::Pattern_>{}))))}));
                        }));
                        goto _done;
                    }
                    {
                        _v.set(Array<crate::check::shrink::walk::Kid>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::check::shrink::walk::Kid>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return Array<crate::check::shrink::walk::Kid>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// PromptKidSpots: unbounded fn PCx, Kid -> [Spot]
Array<crate::check::shrink::walk::Spot> prompt_kid_spots(const PCx& cx_p0, const crate::check::shrink::walk::Kid& k_p1) {
    if (prism_rtl::is<crate::check::shrink::walk::Kid::KidExpr>(k_p1)) {
        auto&& x_p2 = prism_rtl::as<crate::check::shrink::walk::Kid::KidExpr>(k_p1).a0;
        auto&& m_p3 = prism_rtl::as<crate::check::shrink::walk::Kid::KidExpr>(k_p1).a1;
        return prompt_spots(cx_p0, x_p2, m_p3);
    }
    if (prism_rtl::is<crate::check::shrink::walk::Kid::KidStmts>(k_p1)) {
        auto&& ss_p4 = prism_rtl::as<crate::check::shrink::walk::Kid::KidStmts>(k_p1).a0;
        auto&& m_p5 = prism_rtl::as<crate::check::shrink::walk::Kid::KidStmts>(k_p1).a1;
        auto bm_p6 = crate::check::shrink::relations::block_rels(ss_p4, m_p5);
        return run_to_end(fold_job(ss_p4, Array<crate::check::shrink::walk::Spot>{}, ({
            auto cx_p0_1 = cx_p0;
            auto bm_p6_2 = bm_p6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Spot>>(std::tuple<Array<crate::check::shrink::walk::Spot>, crate::syntax::Stmt>)>>(prism_rtl::rc([=, cx_p0_1 = std::move(cx_p0_1), bm_p6_2 = std::move(bm_p6_2)](std::tuple<Array<crate::check::shrink::walk::Spot>, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx_p0_1_3 = cx_p0_1;
                auto bm_p6_2_3 = bm_p6_2;
                entered(once_job([=, cx_p0_1_3 = std::move(cx_p0_1_3), bm_p6_2_3 = std::move(bm_p6_2_3)]() {
                return ({
                    auto acc_p7 = p0;
                    auto s_p8 = p1;
                    (prism_rtl::finished(append(acc_p7, prompt_stmt_spots(cx_p0_1_3, s_p8, bm_p6_2_3))));
                });
            }));
            });
        })));
        })));
    }
    prism_rtl::unreachable("no arm matched");
}


/// PromptStmtSpots: unbounded fn PCx, Stmt, (Text ==> Rel) -> [Spot]
Array<crate::check::shrink::walk::Spot> prompt_stmt_spots(const PCx& cx_p0, const crate::syntax::Stmt& s_p1, const Map<Text, crate::check::shrink::Rel>& m_p2) {
    auto&& _m = s_p1.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        return Array(std::vector{crate::check::shrink::walk::Spot(crate::check::shrink::walk::Spot::SpotStmt{s_p1, m_p2})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        return Array(std::vector{crate::check::shrink::walk::Spot(crate::check::shrink::walk::Spot::SpotStmt{s_p1, m_p2})});
    }
    {
        return run_to_end(fold_job(crate::check::shrink::walk::stmt_kids(s_p1, m_p2), Array(std::vector{crate::check::shrink::walk::Spot(crate::check::shrink::walk::Spot::SpotStmt{s_p1, m_p2})}), ({
            auto cx_p0_1 = cx_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Spot>>(std::tuple<Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid>)>>(prism_rtl::rc([=, cx_p0_1 = std::move(cx_p0_1)](std::tuple<Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx_p0_1_2 = cx_p0_1;
                entered(once_job([=, cx_p0_1_2 = std::move(cx_p0_1_2)]() {
                return ({
                    auto acc_p3 = p0;
                    auto k_p4 = p1;
                    (prism_rtl::finished(append(acc_p3, prompt_kid_spots(cx_p0_1_2, k_p4))));
                });
            }));
            });
        })));
        })));
    }
}


/// FindCycle: unbounded fn [Text], [((Text, Text))] -> [Text]
Array<Text> find_cycle(const Array<Text>& defs_p0, const Array<std::tuple<Text, Text>>& edges_p1) {
    return run_to_end(fold_job(defs_p0, Array<Text>{}, ({
        auto defs_p0_1 = defs_p0;
        auto edges_p1_2 = edges_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, defs_p0_1 = std::move(defs_p0_1), edges_p1_2 = std::move(edges_p1_2)](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto defs_p0_1_3 = defs_p0_1;
            auto edges_p1_2_3 = edges_p1_2;
            entered(once_job([=, defs_p0_1_3 = std::move(defs_p0_1_3), edges_p1_2_3 = std::move(edges_p1_2_3)]() {
            return ({
                auto found_p2 = p0;
                auto d_p3 = p1;
                len(found_p2) > Nat(0u)
                ? prism_rtl::finished(found_p2)
                : prism_rtl::more(prism_rtl::rc(CycleThrough(defs_p0_1_3, edges_p1_2_3, d_p3)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> FindCycle::cycle() const {
    const auto& defs_p0 = this->defs_p0;
    const auto& edges_p1 = this->edges_p1;
    return fold_job(defs_p0, Array<Text>{}, ({
        auto defs_p0_1 = defs_p0;
        auto edges_p1_2 = edges_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, defs_p0_1 = std::move(defs_p0_1), edges_p1_2 = std::move(edges_p1_2)](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto defs_p0_1_3 = defs_p0_1;
            auto edges_p1_2_3 = edges_p1_2;
            entered(once_job([=, defs_p0_1_3 = std::move(defs_p0_1_3), edges_p1_2_3 = std::move(edges_p1_2_3)]() {
            return ({
                auto found_p2 = p0;
                auto d_p3 = p1;
                len(found_p2) > Nat(0u)
                ? prism_rtl::finished(found_p2)
                : prism_rtl::more(prism_rtl::rc(CycleThrough(defs_p0_1_3, edges_p1_2_3, d_p3)));
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start FindCycle, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_find_cycle(Array<Text> defs_p0, Array<std::tuple<Text, Text>> edges_p1) {
    return prism_rtl::make_rc<FindCycle>(defs_p0, edges_p1);
}


/// CycleThrough: unbounded fn [Text], [((Text, Text))], Text -> [Text]
Array<Text> cycle_through(const Array<Text>& defs_p0, const Array<std::tuple<Text, Text>>& edges_p1, const Text& d_p2) {
    auto fwd_p3 = reach_from(edges_p1, d_p2);
    return crate::check::types::has_text(fwd_p3, d_p2)
        ? run_to_end(filter_job(defs_p0, ({
        auto fwd_p3_1 = fwd_p3;
        auto edges_p1_2 = edges_p1;
        auto d_p2_3 = d_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, fwd_p3_1 = std::move(fwd_p3_1), edges_p1_2 = std::move(edges_p1_2), d_p2_3 = std::move(d_p2_3)](Text p0) {
        return ({
            auto fwd_p3_1_4 = fwd_p3_1;
            auto edges_p1_2_4 = edges_p1_2;
            auto d_p2_3_4 = d_p2_3;
            entered(once_job([=, fwd_p3_1_4 = std::move(fwd_p3_1_4), edges_p1_2_4 = std::move(edges_p1_2_4), d_p2_3_4 = std::move(d_p2_3_4)]() {
            return ({
                auto x_p4 = p0;
                (prism_rtl::finished(crate::check::types::has_text(fwd_p3_1_4, x_p4) && crate::check::types::has_text(reach_from(edges_p1_2_4, x_p4), d_p2_3_4)));
            });
        }));
        });
    })));
    })))
        : Array<Text>{};
}


prism_rtl::Turn<Array<Text>> CycleThrough::cycle() const {
    const auto& defs_p0 = this->defs_p0;
    const auto& edges_p1 = this->edges_p1;
    const auto& d_p2 = this->d_p2;
    auto d_p2_1 = d_p2;
    auto defs_p0_2 = defs_p0;
    auto edges_p1_3 = edges_p1;
    return call_then(start_reach_from(edges_p1_3, d_p2_1), [=](Array<Text> reach_from_12532) {
        return ({
            auto fwd_p3 = reach_from_12532;
            (crate::check::types::has_text(fwd_p3, d_p2_1)
            ? filter_job(defs_p0_2, ({
            auto fwd_p3_4 = fwd_p3;
            auto edges_p1_3_5 = edges_p1_3;
            auto d_p2_1_5 = d_p2_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, fwd_p3_4 = std::move(fwd_p3_4), edges_p1_3_5 = std::move(edges_p1_3_5), d_p2_1_5 = std::move(d_p2_1_5)](Text p0) {
            return ({
                auto fwd_p3_4_5 = fwd_p3_4;
                auto edges_p1_3_5_5 = edges_p1_3_5;
                auto d_p2_1_5_5 = d_p2_1_5;
                entered(once_job([=, fwd_p3_4_5 = std::move(fwd_p3_4_5), edges_p1_3_5_5 = std::move(edges_p1_3_5_5), d_p2_1_5_5 = std::move(d_p2_1_5_5)]() {
                return ({
                    auto x_p4 = p0;
                    (prism_rtl::finished(crate::check::types::has_text(fwd_p3_4_5, x_p4) && crate::check::types::has_text(reach_from(edges_p1_3_5_5, x_p4), d_p2_1_5_5)));
                });
            }));
            });
        })));
        }))->cycle()
            : prism_rtl::finished(Array<Text>{}));
        });
    });
}


/// `Start CycleThrough, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cycle_through(Array<Text> defs_p0, Array<std::tuple<Text, Text>> edges_p1, Text d_p2) {
    return prism_rtl::make_rc<CycleThrough>(defs_p0, edges_p1, d_p2);
}


/// ReachFrom: unbounded fn [((Text, Text))], Text -> [Text]
Array<Text> reach_from(const Array<std::tuple<Text, Text>>& edges_p0, const Text& d_p1) {
    return reach(edges_p0, each(filter(edges_p0, [&](const std::tuple<Text, Text>& _p0) {
        auto&& f_p2 = std::get<0>(_p0);
        return f_p2 == d_p1;
    }), [&](const std::tuple<Text, Text>& _p0) {
        auto&& t_p3 = std::get<1>(_p0);
        return t_p3;
    }), Array<Text>{});
}


prism_rtl::Turn<Array<Text>> ReachFrom::cycle() const {
    const auto& edges_p0 = this->edges_p0;
    const auto& d_p1 = this->d_p1;
    return prism_rtl::finished(reach(edges_p0, each(filter(edges_p0, [&](const std::tuple<Text, Text>& _p0) {
        auto&& f_p2 = std::get<0>(_p0);
        return f_p2 == d_p1;
    }), [&](const std::tuple<Text, Text>& _p0) {
        auto&& t_p3 = std::get<1>(_p0);
        return t_p3;
    }), Array<Text>{}));
}


/// `Start ReachFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_reach_from(Array<std::tuple<Text, Text>> edges_p0, Text d_p1) {
    return prism_rtl::make_rc<ReachFrom>(edges_p0, d_p1);
}


/// Reach: unbounded fn [((Text, Text))], [Text], [Text] -> [Text]
Array<Text> reach(const Array<std::tuple<Text, Text>>& edges_p0, const Array<Text>& frontier_p1, const Array<Text>& seen_p2) {
    auto&& _m = index(frontier_p1, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return seen_p2;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& x_p3 = prism_rtl::some_of(_m);
        return crate::check::types::has_text(seen_p2, x_p3)
            ? reach(edges_p0, drop(frontier_p1, Nat(1u)), seen_p2)
            : reach(edges_p0, append(drop(frontier_p1, Nat(1u)), each(filter(edges_p0, [&](const std::tuple<Text, Text>& _p0) {
            auto&& f_p4 = std::get<0>(_p0);
            return f_p4 == x_p3;
        }), [&](const std::tuple<Text, Text>& _p0) {
            auto&& t_p5 = std::get<1>(_p0);
            return t_p5;
        })), crate::prelude::push(seen_p2, x_p3));
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::check::passes::cycles
