// The module `Check.Passes.Cycles`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/passes/cycles/module.hpp>
#include <check/env/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Passes.Cycles`, from `target/bootstrap/cpp-src/prismc/check/passes/cycles.prism`.
namespace crate::check::passes::cycles {

bool PCx::operator==(const PCx& o) const { return g_p == o.g_p && home_p == o.home_p && lams_p == o.lams_p && base_p == o.base_p; }

void PCx::show(Printer& p) const {
    p.record("PCx", {{"g", g_p}, {"home", home_p}, {"lams", lams_p}, {"base", base_p}});
}

Pod PCx::to_pod() const {
    return Pod::record("PCx", {{"g", prism_rtl::to_pod(g_p)}, {"home", prism_rtl::to_pod(home_p)}, {"lams", prism_rtl::to_pod(lams_p)}, {"base", prism_rtl::to_pod(base_p)}});
}

Result<PCx> PCx::from_pod(const Pod& whole) {
    return PCx{.g_p = TRY(prism_rtl::from_pod<crate::check::env::G>(TRY(crate::prelude::field(whole, "g")))), .home_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .lams_p = TRY(prism_rtl::from_pod<Map<Nat, crate::syntax::Expr>>(TRY(crate::prelude::field(whole, "lams")))), .base_p = TRY(prism_rtl::from_pod<Map<Text, crate::check::shrink::Rel>>(TRY(crate::prelude::field(whole, "base"))))};
}


/// IsDelayedWidget: fn Text -> Bool
bool is_delayed_widget_f(const Text& n_p0) {
    return crate::check::types::has_text_f(Array(std::vector{Text::lit("@Defer"), Text::lit("@Later"), Text::lit("@Run"), Text::lit("@Machine"), Text::lit("@started")}), n_p0);
}


/// BlockPromptCycles: unbounded fn Env, St, Block -> St
crate::check::types::St block_prompt_cycles_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Block& b_p2) {
    auto defs_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(b_p2.stmts_p, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p7 = p0;
                auto s_p8 = p1;
                (crate::prelude::call_then(start_stmt_defs_f(s_p8), [=, acc_p7 = std::move(acc_p7)](Array<Text> stmt_defs_f_2204) { return prism_rtl::finished(crate::prelude::append(acc_p7, stmt_defs_f_2204)); }));
            });
        }));
    }))));
    auto cx_p4 = PCx{.g_p = env_p0.g_p, .home_p = env_p0.home_p, .lams_p = let_lambdas_f(b_p2.stmts_p), .base_p = prompt_base_f(env_p0, b_p2.stmts_p)};
    auto edges_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(b_p2.stmts_p, Array<std::tuple<Text, Text>>{}, ({
        auto env_p0x = env_p0;
        auto st_p1x = st_p1;
        auto cx_p4x = cx_p4;
        auto defs_p3x = defs_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, Text>>>(std::tuple<Array<std::tuple<Text, Text>>, crate::syntax::Stmt>)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x), st_p1x = std::move(st_p1x), cx_p4x = std::move(cx_p4x), defs_p3x = std::move(defs_p3x)](std::tuple<Array<std::tuple<Text, Text>>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0xy = env_p0x;
            auto st_p1xy = st_p1x;
            auto cx_p4xy = cx_p4x;
            auto defs_p3xy = defs_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy), st_p1xy = std::move(st_p1xy), cx_p4xy = std::move(cx_p4xy), defs_p3xy = std::move(defs_p3xy)]() {
            return ({
                auto acc_p9 = p0;
                auto s_pa = p1;
                (crate::prelude::call_then(start_prompt_edges_f(env_p0xy, st_p1xy, cx_p4xy, s_pa, defs_p3xy), [=, acc_p9 = std::move(acc_p9)](Array<std::tuple<Text, Text>> prompt_edges_f_2375) { return prism_rtl::finished(crate::prelude::append(acc_p9, prompt_edges_f_2375)); }));
            });
        })));
        });
    }));
    })));
    auto cyc_p6 = find_cycle_f(defs_p3, edges_p5);
    return crate::prelude::len(cyc_p6) == Nat(0u)
        ? st_p1
        : ({
        auto span_pb = crate::prelude::run_to_end(crate::prelude::fold_job(b_p2.stmts_p, b_p2.span_p, ({
            auto cyc_p6x = cyc_p6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::Range>(std::tuple<crate::syntax::Range, crate::syntax::Stmt>)>>(prism_rtl::rc([=, cyc_p6x = std::move(cyc_p6x)](std::tuple<crate::syntax::Range, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cyc_p6xy = cyc_p6x;
                (crate::prelude::entered(crate::prelude::once_job([=, cyc_p6xy = std::move(cyc_p6xy)]() {
                return ({
                    auto sp_pc = p0;
                    auto s_pd = p1;
                    (crate::prelude::call_then(start_stmt_defs_f(s_pd), [=, sp_pc = std::move(sp_pc)](Array<Text> stmt_defs_f_2543) {
                    return crate::check::types::has_text_f(stmt_defs_f_2543, crate::prelude::or_(crate::prelude::index(cyc_p6xy, Nat(0u)), Text::lit("")))
                        ? prism_rtl::finished(prism_rtl::deref(s_pd).span_p)
                        : prism_rtl::finished(sp_pc);
                }));
                });
            })));
            });
        })));
        })));
        (crate::check::types::recording::err_fix_f(st_p1, Text::lit("prompt-cycle"), span_pb, prism_rtl::cat("a prompt cycle: ", crate::syntax::lexer::chars::join_f(crate::prelude::each(cyc_p6, [&](const Text& n_pe) { return prism_rtl::cat("`", n_pe, "`"); }), Text::lit(", "))), Text::lit("break it with a hold: `$last <- start then ...` reads the value as the tick opened")));
    });
}


prism_rtl::Turn<crate::check::types::St> BlockPromptCycles::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& b_p2 = this->b_p2;
    auto b_p2x = b_p2;
    auto env_p0x = env_p0;
    auto st_p1x = st_p1;
    return crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(b_p2x).stmts_p, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p7 = p0;
                auto s_p8 = p1;
                (crate::prelude::call_then(start_stmt_defs_f(s_p8), [=, acc_p7 = std::move(acc_p7)](Array<Text> stmt_defs_f_2204) { return prism_rtl::finished(crate::prelude::append(acc_p7, stmt_defs_f_2204)); }));
            });
        }));
    }))), [=](Array<Text> fold_2161) {
        return ({
            auto defs_p3 = fold_2161;
            (crate::prelude::call_then(start_let_lambdas_f(prism_rtl::deref(b_p2x).stmts_p), [=, defs_p3 = std::move(defs_p3)](Map<Nat, crate::syntax::Expr> let_lambdas_f_2263) {
            return crate::prelude::call_then(start_prompt_base_f(env_p0x, prism_rtl::deref(b_p2x).stmts_p), [=](Map<Text, crate::check::shrink::Rel> prompt_base_f_2290) {
                return ({
                    auto cx_p4 = PCx{.g_p = prism_rtl::deref(env_p0x).g_p, .home_p = prism_rtl::deref(env_p0x).home_p, .lams_p = let_lambdas_f_2263, .base_p = prompt_base_f_2290};
                    (crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(b_p2x).stmts_p, Array<std::tuple<Text, Text>>{}, ({
                    auto env_p0xx = env_p0x;
                    auto st_p1xx = st_p1x;
                    auto cx_p4x = cx_p4;
                    auto defs_p3x = defs_p3;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, Text>>>(std::tuple<Array<std::tuple<Text, Text>>, crate::syntax::Stmt>)>>(prism_rtl::rc([=, env_p0xx = std::move(env_p0xx), st_p1xx = std::move(st_p1xx), cx_p4x = std::move(cx_p4x), defs_p3x = std::move(defs_p3x)](std::tuple<Array<std::tuple<Text, Text>>, crate::syntax::Stmt> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_p0xxy = env_p0xx;
                        auto st_p1xxy = st_p1xx;
                        auto cx_p4xy = cx_p4x;
                        auto defs_p3xy = defs_p3x;
                        (crate::prelude::entered(crate::prelude::once_job([=, env_p0xxy = std::move(env_p0xxy), st_p1xxy = std::move(st_p1xxy), cx_p4xy = std::move(cx_p4xy), defs_p3xy = std::move(defs_p3xy)]() {
                        return ({
                            auto acc_p9 = p0;
                            auto s_pa = p1;
                            (crate::prelude::call_then(start_prompt_edges_f(env_p0xxy, st_p1xxy, cx_p4xy, s_pa, defs_p3xy), [=, acc_p9 = std::move(acc_p9)](Array<std::tuple<Text, Text>> prompt_edges_f_2375) { return prism_rtl::finished(crate::prelude::append(acc_p9, prompt_edges_f_2375)); }));
                        });
                    })));
                    });
                }));
                })), [=](Array<std::tuple<Text, Text>> fold_2332) {
                    return ({
                        auto edges_p5 = fold_2332;
                        (crate::prelude::call_then(start_find_cycle_f(defs_p3, edges_p5), [=](Array<Text> find_cycle_f_2423) {
                        return ({
                            auto cyc_p6 = find_cycle_f_2423;
                            (crate::prelude::len(cyc_p6) == Nat(0u)
                            ? prism_rtl::finished(st_p1x)
                            : crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(b_p2x).stmts_p, prism_rtl::deref(b_p2x).span_p, ({
                            auto cyc_p6x = cyc_p6;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::Range>(std::tuple<crate::syntax::Range, crate::syntax::Stmt>)>>(prism_rtl::rc([=, cyc_p6x = std::move(cyc_p6x)](std::tuple<crate::syntax::Range, crate::syntax::Stmt> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto cyc_p6xy = cyc_p6x;
                                (crate::prelude::entered(crate::prelude::once_job([=, cyc_p6xy = std::move(cyc_p6xy)]() {
                                return ({
                                    auto sp_pc = p0;
                                    auto s_pd = p1;
                                    (crate::prelude::call_then(start_stmt_defs_f(s_pd), [=, sp_pc = std::move(sp_pc)](Array<Text> stmt_defs_f_2543) {
                                    return crate::check::types::has_text_f(stmt_defs_f_2543, crate::prelude::or_(crate::prelude::index(cyc_p6xy, Nat(0u)), Text::lit("")))
                                        ? prism_rtl::finished(prism_rtl::deref(s_pd).span_p)
                                        : prism_rtl::finished(sp_pc);
                                }));
                                });
                            })));
                            });
                        })));
                        })), [=](crate::syntax::Range fold_2500) {
                            return ({
                                auto span_pb = fold_2500;
                                (prism_rtl::finished(crate::check::types::recording::err_fix_f(st_p1x, Text::lit("prompt-cycle"), span_pb, prism_rtl::cat("a prompt cycle: ", crate::syntax::lexer::chars::join_f(crate::prelude::each(cyc_p6, [&](const Text& n_pe) { return prism_rtl::cat("`", n_pe, "`"); }), Text::lit(", "))), Text::lit("break it with a hold: `$last <- start then ...` reads the value as the tick opened"))));
                            });
                        }));
                        });
                    }));
                    });
                }));
                });
            });
        }));
        });
    });
}


/// `Start BlockPromptCycles, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_block_prompt_cycles_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2) {
    return prism_rtl::make_rc<BlockPromptCycles>(env_p0, st_p1, b_p2);
}


/// StmtDefs: unbounded fn Stmt -> [Text]
Array<Text> stmt_defs_f(const crate::syntax::Stmt& s_p0) {
    auto&& _m = s_p0.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
        auto&& p_p1 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        return crate::check::env::names::pattern_names_f(p_p1);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_p2 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        return crate::check::env::names::pattern_names_f(p_p2);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> StmtDefs::cycle() const {
    const auto& s_p0 = this->s_p0;
    return ({
        auto&& _m = prism_rtl::deref(s_p0).kind_p;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
        auto&& p_p1 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::env::names::PatternNames(p_p1)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_p2 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::env::names::PatternNames(p_p2)));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start StmtDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_stmt_defs_f(crate::syntax::Stmt s_p0) {
    return prism_rtl::make_rc<StmtDefs>(s_p0);
}


/// PromptEdges: unbounded fn Env, St, PCx, Stmt, [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> prompt_edges_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const PCx& cx_p2, const crate::syntax::Stmt& s_p3, const Array<Text>& defs_p4) {
    auto&& _m = s_p3.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        return Array<std::tuple<Text, Text>>{};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_p5 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e_p6 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        return edges_f(crate::check::env::names::pattern_names_f(p_p5), prompt_reads_f(cx_p2, e_p6, defs_p4));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_p7 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e_p8 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto names_p9 = crate::check::env::names::pattern_names_f(p_p7);
        auto layer_pa = crate::prelude::run_to_end(crate::prelude::fold_job(names_p9, Text::lit(""), ({
            auto env_p0x = env_p0;
            auto st_p1x = st_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text>)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x), st_p1x = std::move(st_p1x)](std::tuple<Text, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_p0xy = env_p0x;
                auto st_p1xy = st_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy), st_p1xy = std::move(st_p1xy)]() {
                return ({
                    auto acc_pb = p0;
                    auto n_pc = p1;
                    ({
                    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0xy).locals_p, n_pc);
                    prism_rtl::is_some(_m) ? ({
                    auto&& sc_pd = prism_rtl::some_of(_m);
                    prism_rtl::more(prism_rtl::rc(crate::check::types::HeadSigil(st_p1xy, prism_rtl::deref(sc_pd).ty_p)));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(acc_pb)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            })));
            });
        })));
        })));
        return edges_f(names_p9, crate::prelude::run_to_end(crate::prelude::filter_job(prompt_reads_f(cx_p2, e_p8, defs_p4), ({
            auto env_p0x = env_p0;
            auto st_p1x = st_p1;
            auto layer_pax = layer_pa;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x), st_p1x = std::move(st_p1x), layer_pax = std::move(layer_pax)](Text p0) {
            return ({
                auto env_p0xy = env_p0x;
                auto st_p1xy = st_p1x;
                auto layer_paxy = layer_pax;
                (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy), st_p1xy = std::move(st_p1xy), layer_paxy = std::move(layer_paxy)]() {
                return ({
                    auto n_pe = p0;
                    (prism_rtl::more(prism_rtl::rc(ReadIsPrompt(env_p0xy, st_p1xy, n_pe, layer_paxy))));
                });
            })));
            });
        })));
        }))));
    }
    {
        return Array<std::tuple<Text, Text>>{};
    }
}


prism_rtl::Turn<Array<std::tuple<Text, Text>>> PromptEdges::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& cx_p2 = this->cx_p2;
    const auto& s_p3 = this->s_p3;
    const auto& defs_p4 = this->defs_p4;
    return ({
        auto&& _m = prism_rtl::deref(s_p3).kind_p;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? prism_rtl::finished(Array<std::tuple<Text, Text>>{})
        : prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_p5 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e_p6 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        ({
        auto cx_p2x = cx_p2;
        auto defs_p4x = defs_p4;
        auto e_p6x = e_p6;
        auto p_p5x = p_p5;
        (crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p5x), [=, cx_p2x = std::move(cx_p2x), defs_p4x = std::move(defs_p4x), e_p6x = std::move(e_p6x)](Array<Text> pattern_names_f_3267) { return crate::prelude::call_then(start_prompt_reads_f(cx_p2x, e_p6x, defs_p4x), [=](Array<Text> prompt_reads_f_3285) { return prism_rtl::finished(edges_f(pattern_names_f_3267, prompt_reads_f_3285)); }); }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_p7 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e_p8 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto cx_p2x = cx_p2;
        auto defs_p4x = defs_p4;
        auto e_p8x = e_p8;
        auto env_p0x = env_p0;
        auto p_p7x = p_p7;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p7x), [=, cx_p2x = std::move(cx_p2x), defs_p4x = std::move(defs_p4x), e_p8x = std::move(e_p8x), env_p0x = std::move(env_p0x), st_p1x = std::move(st_p1x)](Array<Text> pattern_names_f_3353) {
        return ({
            auto names_p9 = pattern_names_f_3353;
            (crate::prelude::call_value(crate::prelude::fold_job(names_p9, Text::lit(""), ({
            auto env_p0xx = env_p0x;
            auto st_p1xx = st_p1x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text>)>>(prism_rtl::rc([=, env_p0xx = std::move(env_p0xx), st_p1xx = std::move(st_p1xx)](std::tuple<Text, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_p0xxy = env_p0xx;
                auto st_p1xxy = st_p1xx;
                (crate::prelude::entered(crate::prelude::once_job([=, env_p0xxy = std::move(env_p0xxy), st_p1xxy = std::move(st_p1xxy)]() {
                return ({
                    auto acc_pb = p0;
                    auto n_pc = p1;
                    ({
                    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0xxy).locals_p, n_pc);
                    prism_rtl::is_some(_m) ? ({
                    auto&& sc_pd = prism_rtl::some_of(_m);
                    prism_rtl::more(prism_rtl::rc(crate::check::types::HeadSigil(st_p1xxy, prism_rtl::deref(sc_pd).ty_p)));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(acc_pb)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            })));
            });
        })));
        })), [=](Text fold_3388) {
            return ({
                auto layer_pa = fold_3388;
                (crate::prelude::call_then(start_prompt_reads_f(cx_p2x, e_p8x, defs_p4x), [=, layer_pa = std::move(layer_pa)](Array<Text> prompt_reads_f_3524) {
                return crate::prelude::call_value(crate::prelude::filter_job(prompt_reads_f_3524, ({
                    auto env_p0xx = env_p0x;
                    auto st_p1xx = st_p1x;
                    auto layer_pax = layer_pa;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, env_p0xx = std::move(env_p0xx), st_p1xx = std::move(st_p1xx), layer_pax = std::move(layer_pax)](Text p0) {
                    return ({
                        auto env_p0xxy = env_p0xx;
                        auto st_p1xxy = st_p1xx;
                        auto layer_paxy = layer_pax;
                        (crate::prelude::entered(crate::prelude::once_job([=, env_p0xxy = std::move(env_p0xxy), st_p1xxy = std::move(st_p1xxy), layer_paxy = std::move(layer_paxy)]() {
                        return ({
                            auto n_pe = p0;
                            (prism_rtl::more(prism_rtl::rc(ReadIsPrompt(env_p0xxy, st_p1xxy, n_pe, layer_paxy))));
                        });
                    })));
                    });
                })));
                })), [=](Array<Text> filter_3516) { return prism_rtl::finished(edges_f(names_p9, filter_3516)); });
            }));
            });
        }));
        });
    }));
    });
    })
        : prism_rtl::finished(Array<std::tuple<Text, Text>>{});
    });
}


/// `Start PromptEdges, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_prompt_edges_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, PCx cx_p2, crate::syntax::Stmt s_p3, Array<Text> defs_p4) {
    return prism_rtl::make_rc<PromptEdges>(env_p0, st_p1, cx_p2, s_p3, defs_p4);
}


/// Edges: fn [Text], [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> edges_f(const Array<Text>& froms_p0, const Array<Text>& tos_p1) {
    return crate::prelude::fold(froms_p0, Array<std::tuple<Text, Text>>{}, [&](const Array<std::tuple<Text, Text>>& acc_p2, const Text& f_p3) { return crate::prelude::append(acc_p2, crate::prelude::each(tos_p1, [&](const Text& t_p4) { return std::tuple{f_p3, t_p4}; })); });
}


/// ReadIsPrompt: unbounded fn Env, St, Text, Text -> Bool
bool read_is_prompt_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& n_p2, const Text& layer_p3) {
    auto&& _m = crate::prelude::get(env_p0.locals_p, n_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& sc_p4 = prism_rtl::some_of(_m);
        auto h_p5 = crate::check::types::head_sigil_f(st_p1, prism_rtl::deref(sc_p4).ty_p);
        return layer_p3 == Text::lit("!")
            ? (h_p5 == Text::lit("!")) || (h_p5 == Text::lit("@"))
            : layer_p3 == Text::lit("$")
            ? (h_p5 == Text::lit("$")) || (h_p5 == Text::lit("!"))
            : ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::check::types::recording::walk_f(st_p1, prism_rtl::deref(sc_p4).ty_p);
            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                _v.set(false);
                goto _done;
            }
            {
                _v.set(crate::check::env::is_lower_text_f(crate::syntax::lexer::chars::drop_prefix_f(n_p2, crate::check::types::unify::marks_of_f(n_p2))) && (h_p5 == Text::lit("")));
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> ReadIsPrompt::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& n_p2 = this->n_p2;
    const auto& layer_p3 = this->layer_p3;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0).locals_p, n_p2);
        prism_rtl::is_some(_m) ? ({
        auto&& sc_p4 = prism_rtl::some_of(_m);
        ({
        auto layer_p3x = layer_p3;
        auto n_p2x = n_p2;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x, prism_rtl::deref(sc_p4).ty_p), [=, layer_p3x = std::move(layer_p3x), n_p2x = std::move(n_p2x)](Text head_sigil_f_4011) {
        return ({
            auto h_p5 = head_sigil_f_4011;
            layer_p3x == Text::lit("!")
            ? prism_rtl::finished((h_p5 == Text::lit("!")) || (h_p5 == Text::lit("@")))
            : layer_p3x == Text::lit("$")
            ? prism_rtl::finished((h_p5 == Text::lit("$")) || (h_p5 == Text::lit("!")))
            : crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x, prism_rtl::deref(sc_p4).ty_p), [=](crate::check::types::Ty walk_f_4149) {
            return ({
                prism_rtl::is<crate::check::types::Ty::TyFn>(walk_f_4149) ? prism_rtl::finished(false)
                : prism_rtl::finished(crate::check::env::is_lower_text_f(crate::syntax::lexer::chars::drop_prefix_f(n_p2x, crate::check::types::unify::marks_of_f(n_p2x))) && (h_p5 == Text::lit("")));
            });
        });
        });
    }));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ReadIsPrompt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_read_is_prompt_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text n_p2, Text layer_p3) {
    return prism_rtl::make_rc<ReadIsPrompt>(env_p0, st_p1, n_p2, layer_p3);
}


/// PromptBase: unbounded fn Env, [Stmt] -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> prompt_base_f(const crate::check::expr::Env& env_p0, const Array<crate::syntax::Stmt>& stmts_p1) {
    auto pre_p2 = crate::check::shrink::relations::prelude_seeds_f(env_p0.g_p, env_p0.home_p);
    auto seeds_p3 = crate::prelude::fold(crate::prelude::keys(pre_p2), pre_p2, [&](const Map<Text, crate::check::shrink::Rel>& m_p4, const Text& k_p5) {
        return crate::check::env::has_key_f(env_p0.locals_p, crate::syntax::lexer::chars::drop_prefix_f(k_p5, Text::lit("pre:")))
            ? crate::prelude::remove(m_p4, k_p5)
            : m_p4;
    });
    return crate::prelude::fold(stmts_p1, seeds_p3, [&](const Map<Text, crate::check::shrink::Rel>& m_p6, const crate::syntax::Stmt& s_p7) { return lam_let_rels_f(s_p7, m_p6); });
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> PromptBase::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& stmts_p1 = this->stmts_p1;
    auto pre_p2 = crate::check::shrink::relations::prelude_seeds_f(prism_rtl::deref(env_p0).g_p, prism_rtl::deref(env_p0).home_p);
    auto seeds_p3 = crate::prelude::fold(crate::prelude::keys(pre_p2), pre_p2, [&](const Map<Text, crate::check::shrink::Rel>& m_p4, const Text& k_p5) {
        return crate::check::env::has_key_f(prism_rtl::deref(env_p0).locals_p, crate::syntax::lexer::chars::drop_prefix_f(k_p5, Text::lit("pre:")))
            ? crate::prelude::remove(m_p4, k_p5)
            : m_p4;
    });
    return prism_rtl::finished(crate::prelude::fold(stmts_p1, seeds_p3, [&](const Map<Text, crate::check::shrink::Rel>& m_p6, const crate::syntax::Stmt& s_p7) { return lam_let_rels_f(s_p7, m_p6); }));
}


/// `Start PromptBase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_prompt_base_f(crate::check::expr::Env env_p0, Array<crate::syntax::Stmt> stmts_p1) {
    return prism_rtl::make_rc<PromptBase>(env_p0, stmts_p1);
}


/// LamLetRels: fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> lam_let_rels_f(const crate::syntax::Stmt& s_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    auto&& _m = s_p0.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_p2 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e_p3 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto&& _m = std::tuple{prism_rtl::deref(prism_rtl::deref(p_p2).kind_p), lambda_of_o(e_p3)};
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
            auto&& n_p4 = prism_rtl::as<crate::syntax::PatternKind::PName>(std::get<0>(_m)).a0;
            auto&& lam_p5 = prism_rtl::some_of(std::get<1>(_m));
            return crate::prelude::insert(m_p1, prism_rtl::cat("lamlet:", crate::check::env::sname_key_f(n_p4)), crate::check::shrink::Rel{.param_p = prism_rtl::deref(prism_rtl::deref(lam_p5).span_p).start_p, .strict_p = false});
        }
        {
            return m_p1;
        }
    }
    {
        return m_p1;
    }
}


/// ?LambdaOf: fn Expr -> ?Expr
std::optional<crate::syntax::Expr> lambda_of_o(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        return std::optional(e_p0);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p1 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return lambda_of_o(prism_rtl::deref(prism_rtl::deref(x_p1)));
    }
    {
        return std::optional<crate::syntax::Expr>{};
    }
}


/// LetLambdas: unbounded fn [Stmt] -> (Nat ==> Expr)
Map<Nat, crate::syntax::Expr> let_lambdas_f(const Array<crate::syntax::Stmt>& stmts_p0) {
    return crate::prelude::fold(crate::check::shrink::walk::stmts_spots_f(stmts_p0, Map<Text, crate::check::shrink::Rel>{}), Map<Nat, crate::syntax::Expr>{}, [&](const Map<Nat, crate::syntax::Expr>& m_p1, const crate::check::shrink::walk::Spot& sp_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
            if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(sp_p2)) {
                auto&& s_p3 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp_p2).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
                    auto&& _m = prism_rtl::deref(s_p3).kind_p;
                    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                        auto&& e_p4 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
                            auto&& _m = lambda_of_o(e_p4);
                            if (prism_rtl::is_some(_m)) {
                                auto&& lam_p5 = prism_rtl::some_of(_m);
                                _v.set(crate::prelude::insert(m_p1, prism_rtl::deref(prism_rtl::deref(lam_p5).span_p).start_p, lam_p5));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(m_p1);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    {
                        _v.set(m_p1);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(m_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Map<Nat, crate::syntax::Expr>> LetLambdas::cycle() const {
    const auto& stmts_p0 = this->stmts_p0;
    auto stmts_p0x = stmts_p0;
    return crate::prelude::call_then(crate::check::shrink::walk::start_stmts_spots_f(stmts_p0x, Map<Text, crate::check::shrink::Rel>{}), [=](Array<crate::check::shrink::walk::Spot> stmts_spots_f_5873) {
        return prism_rtl::finished(crate::prelude::fold(stmts_spots_f_5873, Map<Nat, crate::syntax::Expr>{}, [&](const Map<Nat, crate::syntax::Expr>& m_p1, const crate::check::shrink::walk::Spot& sp_p2) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
                if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(sp_p2)) {
                    auto&& s_p3 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp_p2).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
                        auto&& _m = prism_rtl::deref(s_p3).kind_p;
                        if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                            auto&& e_p4 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
                                auto&& _m = lambda_of_o(e_p4);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& lam_p5 = prism_rtl::some_of(_m);
                                    _v.set(crate::prelude::insert(m_p1, prism_rtl::deref(prism_rtl::deref(lam_p5).span_p).start_p, lam_p5));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(m_p1);
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        {
                            _v.set(m_p1);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                {
                    _v.set(m_p1);
                    goto _done;
                }
            _done:
                _v.take();
            });
        }));
    });
}


/// `Start LetLambdas, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Nat, crate::syntax::Expr>> start_let_lambdas_f(Array<crate::syntax::Stmt> stmts_p0) {
    return prism_rtl::make_rc<LetLambdas>(stmts_p0);
}


/// PromptReads: unbounded fn PCx, Expr, [Text] -> [Text]
Array<Text> prompt_reads_f(const PCx& cx_p0, const crate::syntax::Expr& e_p1, const Array<Text>& defs_p2) {
    auto spots_p3 = prompt_spots_f(cx_p0, e_p1, cx_p0.base_p);
    return crate::prelude::run_to_end(crate::prelude::fold_job(spots_p3, Array<Text>{}, ({
        auto defs_p2x = defs_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, defs_p2x = std::move(defs_p2x)](std::tuple<Array<Text>, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto defs_p2xy = defs_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, defs_p2xy = std::move(defs_p2xy)]() {
            return ({
                auto acc_p4 = p0;
                auto sp_p5 = p1;
                (crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p5), [=, acc_p4 = std::move(acc_p4)](Array<crate::check::shrink::walk::Site> spot_sites_f_7222) {
                return prism_rtl::finished(crate::prelude::fold(spot_sites_f_7222, acc_p4, [&](const Array<Text>& a2_p6, const crate::check::shrink::walk::Site& site_p7) {
                    return crate::check::types::has_text_f(defs_p2xy, prism_rtl::deref(site_p7).callee_p) && (!crate::check::shrink::relations::is_local_f(prism_rtl::deref(site_p7).rels_p, prism_rtl::deref(site_p7).callee_p))
                        ? crate::check::types::add_text_f(a2_p6, prism_rtl::deref(site_p7).callee_p)
                        : a2_p6;
                }));
            }));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> PromptReads::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& e_p1 = this->e_p1;
    const auto& defs_p2 = this->defs_p2;
    auto cx_p0x = cx_p0;
    auto defs_p2x = defs_p2;
    auto e_p1x = e_p1;
    return crate::prelude::call_then(start_prompt_spots_f(cx_p0x, e_p1x, prism_rtl::deref(cx_p0x).base_p), [=](Array<crate::check::shrink::walk::Spot> prompt_spots_f_7156) {
        return ({
            auto spots_p3 = prompt_spots_f_7156;
            (crate::prelude::fold_job(spots_p3, Array<Text>{}, ({
            auto defs_p2xx = defs_p2x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, defs_p2xx = std::move(defs_p2xx)](std::tuple<Array<Text>, crate::check::shrink::walk::Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto defs_p2xxy = defs_p2xx;
                (crate::prelude::entered(crate::prelude::once_job([=, defs_p2xxy = std::move(defs_p2xxy)]() {
                return ({
                    auto acc_p4 = p0;
                    auto sp_p5 = p1;
                    (crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p5), [=, acc_p4 = std::move(acc_p4)](Array<crate::check::shrink::walk::Site> spot_sites_f_7222) {
                    return prism_rtl::finished(crate::prelude::fold(spot_sites_f_7222, acc_p4, [&](const Array<Text>& a2_p6, const crate::check::shrink::walk::Site& site_p7) {
                        return crate::check::types::has_text_f(defs_p2xxy, prism_rtl::deref(site_p7).callee_p) && (!crate::check::shrink::relations::is_local_f(prism_rtl::deref(site_p7).rels_p, prism_rtl::deref(site_p7).callee_p))
                            ? crate::check::types::add_text_f(a2_p6, prism_rtl::deref(site_p7).callee_p)
                            : a2_p6;
                    }));
                }));
                });
            })));
            });
        })));
        }))->cycle());
        });
    });
}


/// `Start PromptReads, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_prompt_reads_f(PCx cx_p0, crate::syntax::Expr e_p1, Array<Text> defs_p2) {
    return prism_rtl::make_rc<PromptReads>(cx_p0, e_p1, defs_p2);
}


/// PromptSpots: unbounded fn PCx, Expr, (Text ==> Rel) -> [Spot]
Array<crate::check::shrink::walk::Spot> prompt_spots_f(const PCx& cx_p0, const crate::syntax::Expr& e_p1, const Map<Text, crate::check::shrink::Rel>& m_p2) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(prompt_kids_f(cx_p0, e_p1, m_p2), Array(std::vector{crate::check::shrink::walk::Spot(crate::check::shrink::walk::Spot::SpotExpr{e_p1, m_p2})}), ({
        auto cx_p0x = cx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Spot>>(std::tuple<Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid>)>>(prism_rtl::rc([=, cx_p0x = std::move(cx_p0x)](std::tuple<Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx_p0xy = cx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cx_p0xy = std::move(cx_p0xy)]() {
            return ({
                auto acc_p3 = p0;
                auto k_p4 = p1;
                (prism_rtl::finished(crate::prelude::append(acc_p3, prompt_kid_spots_f(cx_p0xy, k_p4))));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::check::shrink::walk::Spot>> PromptSpots::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& e_p1 = this->e_p1;
    const auto& m_p2 = this->m_p2;
    return crate::prelude::fold_job(prompt_kids_f(cx_p0, e_p1, m_p2), Array(std::vector{crate::check::shrink::walk::Spot(crate::check::shrink::walk::Spot::SpotExpr{e_p1, m_p2})}), ({
        auto cx_p0x = cx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Spot>>(std::tuple<Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid>)>>(prism_rtl::rc([=, cx_p0x = std::move(cx_p0x)](std::tuple<Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx_p0xy = cx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cx_p0xy = std::move(cx_p0xy)]() {
            return ({
                auto acc_p3 = p0;
                auto k_p4 = p1;
                (prism_rtl::finished(crate::prelude::append(acc_p3, prompt_kid_spots_f(cx_p0xy, k_p4))));
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start PromptSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::shrink::walk::Spot>> start_prompt_spots_f(PCx cx_p0, crate::syntax::Expr e_p1, Map<Text, crate::check::shrink::Rel> m_p2) {
    return prism_rtl::make_rc<PromptSpots>(cx_p0, e_p1, m_p2);
}


/// PromptKids: unbounded fn PCx, Expr, (Text ==> Rel) -> [Kid]
Array<crate::check::shrink::walk::Kid> prompt_kids_f(const PCx& cx_p0, const crate::syntax::Expr& e_p1, const Map<Text, crate::check::shrink::Rel>& m_p2) {
    auto&& _m = prism_rtl::deref(e_p1.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        return Array<crate::check::shrink::walk::Kid>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
        auto&& body_p3 = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        return row_kids_f(body_p3, m_p2, Array<Text>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
        auto&& binders_o4 = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& body_p5 = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        return row_kids_f(body_p5, m_p2, for_binder_names_f(binders_o4));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        return Array<crate::check::shrink::walk::Kid>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_p6 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        return prompt_call_kids_f(cx_p0, e_p1, crate::check::shrink::walk::callee_name_o(prism_rtl::deref(prism_rtl::deref(c_p6))), m_p2);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& n_p7 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        return prompt_call_kids_f(cx_p0, e_p1, std::optional(crate::check::env::sname_key_f(n_p7)), m_p2);
    }
    {
        return crate::check::shrink::walk::expr_kids_f(e_p1, m_p2);
    }
}


/// RowKids: unbounded fn Block, (Text ==> Rel), [Text] -> [Kid]
Array<crate::check::shrink::walk::Kid> row_kids_f(const crate::syntax::Block& body_p0, const Map<Text, crate::check::shrink::Rel>& m_p1, const Array<Text>& binders_p2) {
    auto lines_p3 = crate::prelude::filter(body_p0.stmts_p, [&](const crate::syntax::Stmt& s_p5) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = prism_rtl::deref(s_p5).kind_p;
            if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
                _v.set(false);
                goto _done;
            }
            {
                _v.set(true);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto own_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(body_p0.stmts_p, crate::prelude::append(binders_p2, Array(std::vector{Text::lit("_"), Text::lit("$_")})), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p6 = p0;
                auto s_p7 = p1;
                (crate::prelude::call_then(start_stmt_defs_f(s_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> stmt_defs_f_8893) { return prism_rtl::finished(crate::prelude::append(acc_p6, stmt_defs_f_8893)); }));
            });
        }));
    }))));
    return Array(std::vector{crate::check::shrink::walk::Kid(crate::check::shrink::walk::Kid::KidStmts{lines_p3, crate::check::shrink::relations::hide_f(m_p1, own_p4)})});
}


/// ForBinderNames: unbounded fn ?ForBinders -> [Text]
Array<Text> for_binder_names_f(const std::optional<crate::syntax::ForBinders>& binders_o0) {
    if (prism_rtl::is_some(binders_o0)) {
        auto&& fb_p1 = prism_rtl::some_of(binders_o0);
        auto&& _m = prism_rtl::deref(fb_p1).second_o;
        if (prism_rtl::is_some(_m)) {
            auto&& second_p2 = prism_rtl::some_of(_m);
            return crate::prelude::append(crate::check::env::names::pattern_names_f(prism_rtl::deref(fb_p1).first_p), crate::check::env::names::pattern_names_f(second_p2));
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::env::names::pattern_names_f(prism_rtl::deref(fb_p1).first_p);
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(binders_o0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// PromptCallKids: unbounded fn PCx, Expr, ?Text, (Text ==> Rel) -> [Kid]
Array<crate::check::shrink::walk::Kid> prompt_call_kids_f(const PCx& cx_p0, const crate::syntax::Expr& e_p1, const std::optional<Text>& n_o2, const Map<Text, crate::check::shrink::Rel>& m_p3) {
    if (prism_rtl::is_some(n_o2)) {
        auto&& n_p4 = prism_rtl::some_of(n_o2);
        auto called_p5 = follow_lam_let_f(cx_p0, n_p4, m_p3);
        return crate::check::shrink::relations::is_local_f(m_p3, n_p4)
            ? crate::prelude::append(called_p5, open_lambdas_f(cx_p0, crate::check::shrink::walk::expr_kids_f(e_p1, m_p3)))
            : crate::prelude::len(called_p5) > Nat(0u)
            ? crate::prelude::append(called_p5, open_lambdas_f(cx_p0, crate::check::shrink::walk::expr_kids_f(e_p1, m_p3)))
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::shrink::walk::Kid>> _v;
            auto&& _m = crate::check::shrink::locals::resolve_callee_o(cx_p0.g_p, cx_p0.home_p, n_p4);
            if (prism_rtl::is_some(_m)) {
                auto&& k_p6 = prism_rtl::some_of(_m);
                _v.set(crate::check::shrink::relations::is_prelude_key_f(cx_p0.g_p, k_p6) && is_delayed_widget_f(crate::syntax::lexer::chars::drop_prefix_f(k_p6, Text::lit("Prelude.")))
                    ? Array<crate::check::shrink::walk::Kid>{}
                    : crate::check::shrink::relations::is_prelude_key_f(cx_p0.g_p, k_p6) && crate::syntax::lexer::chars::has_prefix_f(k_p6, Text::lit("Prelude.@"))
                    ? crate::check::shrink::walk::expr_kids_f(e_p1, m_p3)
                    : open_lambdas_f(cx_p0, crate::check::shrink::walk::expr_kids_f(e_p1, m_p3)));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(open_lambdas_f(cx_p0, crate::check::shrink::walk::expr_kids_f(e_p1, m_p3)));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(n_o2)) {
        return open_lambdas_f(cx_p0, crate::check::shrink::walk::expr_kids_f(e_p1, m_p3));
    }
    prism_rtl::unreachable("no arm matched");
}


/// OpenLambdas: unbounded fn PCx, [Kid] -> [Kid]
Array<crate::check::shrink::walk::Kid> open_lambdas_f(const PCx& cx_p0, const Array<crate::check::shrink::walk::Kid>& kids_p1) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(kids_p1, Array<crate::check::shrink::walk::Kid>{}, ({
        auto cx_p0x = cx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Kid>>(std::tuple<Array<crate::check::shrink::walk::Kid>, crate::check::shrink::walk::Kid>)>>(prism_rtl::rc([=, cx_p0x = std::move(cx_p0x)](std::tuple<Array<crate::check::shrink::walk::Kid>, crate::check::shrink::walk::Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx_p0xy = cx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cx_p0xy = std::move(cx_p0xy)]() {
            return ({
                auto acc_p2 = p0;
                auto k_p3 = p1;
                ({
                prism_rtl::is<crate::check::shrink::walk::Kid::KidExpr>(k_p3) ? ({
                auto&& x_p4 = prism_rtl::as<crate::check::shrink::walk::Kid::KidExpr>(k_p3).a0;
                auto&& m_p5 = prism_rtl::as<crate::check::shrink::walk::Kid::KidExpr>(k_p3).a1;
                ({
                auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p4).kind_p);
                prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
                auto&& ps_o6 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
                auto&& body_p7 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
                ({
                auto ps_o6x = ps_o6;
                auto body_p7x = prism_rtl::deref(prism_rtl::deref(body_p7));
                auto m_p5x = m_p5;
                (crate::prelude::call_then(crate::check::shrink::walk::start_patterns_names_f(crate::prelude::or_(ps_o6x, Array<crate::syntax::Pattern_>{})), [=, body_p7x = std::move(body_p7x), m_p5x = std::move(m_p5x)](Array<Text> patterns_names_f_10512) { return prism_rtl::finished(crate::prelude::push(acc_p2, crate::check::shrink::walk::lambda_kid_f(body_p7x, crate::check::shrink::relations::hide_f(m_p5x, patterns_names_f_10512)))); }));
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
                auto&& n_p8 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                prism_rtl::finished(crate::prelude::append(crate::prelude::push(acc_p2, k_p3), follow_lam_let_f(cx_p0xy, crate::check::env::sname_key_f(n_p8), m_p5)));
            })
                : prism_rtl::finished(crate::prelude::push(acc_p2, k_p3));
            });
            })
                : prism_rtl::finished(crate::prelude::push(acc_p2, k_p3));
            });
            });
        })));
        });
    })));
    })));
}


/// FollowLamLet: unbounded fn PCx, Text, (Text ==> Rel) -> [Kid]
Array<crate::check::shrink::walk::Kid> follow_lam_let_f(const PCx& cx_p0, const Text& n_p1, const Map<Text, crate::check::shrink::Rel>& m_p2) {
    auto&& _m = crate::prelude::get(m_p2, prism_rtl::cat("lamlet:", n_p1));
    if (prism_rtl::is_some(_m)) {
        auto&& r_p3 = prism_rtl::some_of(_m);
        return crate::check::env::has_key_f(m_p2, prism_rtl::cat("seen:", prism_rtl::deref(r_p3).param_p))
            ? Array<crate::check::shrink::walk::Kid>{}
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::shrink::walk::Kid>> _v;
            auto&& _m = crate::prelude::get(cx_p0.lams_p, prism_rtl::deref(r_p3).param_p);
            if (prism_rtl::is_some(_m)) {
                auto&& lam_p4 = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::check::shrink::walk::Kid>> _v;
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(lam_p4).kind_p);
                    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
                        auto&& ps_o5 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
                        auto&& body_p6 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
                        _v.set(({
                            auto seen_p7 = crate::prelude::fold(crate::prelude::keys(m_p2), cx_p0.base_p, [&](const Map<Text, crate::check::shrink::Rel>& m2_p8, const Text& k_p9) {
                                return crate::syntax::lexer::chars::has_prefix_f(k_p9, Text::lit("seen:"))
                                    ? crate::prelude::insert(m2_p8, k_p9, crate::check::shrink::relations::no_rel_p())
                                    : m2_p8;
                            });
                            (Array(std::vector{crate::check::shrink::walk::lambda_kid_f(prism_rtl::deref(prism_rtl::deref(body_p6)), crate::check::shrink::relations::hide_f(crate::prelude::insert(seen_p7, prism_rtl::cat("seen:", prism_rtl::deref(r_p3).param_p), crate::check::shrink::relations::no_rel_p()), crate::check::shrink::walk::patterns_names_f(crate::prelude::or_(ps_o5, Array<crate::syntax::Pattern_>{}))))}));
                        }));
                        goto _done;
                    }
                    {
                        _v.set(Array<crate::check::shrink::walk::Kid>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::check::shrink::walk::Kid>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return Array<crate::check::shrink::walk::Kid>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// PromptKidSpots: unbounded fn PCx, Kid -> [Spot]
Array<crate::check::shrink::walk::Spot> prompt_kid_spots_f(const PCx& cx_p0, const crate::check::shrink::walk::Kid& k_p1) {
    if (prism_rtl::is<crate::check::shrink::walk::Kid::KidExpr>(k_p1)) {
        auto&& x_p2 = prism_rtl::as<crate::check::shrink::walk::Kid::KidExpr>(k_p1).a0;
        auto&& m_p3 = prism_rtl::as<crate::check::shrink::walk::Kid::KidExpr>(k_p1).a1;
        return prompt_spots_f(cx_p0, x_p2, m_p3);
    }
    if (prism_rtl::is<crate::check::shrink::walk::Kid::KidStmts>(k_p1)) {
        auto&& ss_p4 = prism_rtl::as<crate::check::shrink::walk::Kid::KidStmts>(k_p1).a0;
        auto&& m_p5 = prism_rtl::as<crate::check::shrink::walk::Kid::KidStmts>(k_p1).a1;
        auto bm_p6 = crate::check::shrink::relations::block_rels_f(ss_p4, m_p5);
        return crate::prelude::run_to_end(crate::prelude::fold_job(ss_p4, Array<crate::check::shrink::walk::Spot>{}, ({
            auto cx_p0x = cx_p0;
            auto bm_p6x = bm_p6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Spot>>(std::tuple<Array<crate::check::shrink::walk::Spot>, crate::syntax::Stmt>)>>(prism_rtl::rc([=, cx_p0x = std::move(cx_p0x), bm_p6x = std::move(bm_p6x)](std::tuple<Array<crate::check::shrink::walk::Spot>, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx_p0xy = cx_p0x;
                auto bm_p6xy = bm_p6x;
                (crate::prelude::entered(crate::prelude::once_job([=, cx_p0xy = std::move(cx_p0xy), bm_p6xy = std::move(bm_p6xy)]() {
                return ({
                    auto acc_p7 = p0;
                    auto s_p8 = p1;
                    (prism_rtl::finished(crate::prelude::append(acc_p7, prompt_stmt_spots_f(cx_p0xy, s_p8, bm_p6xy))));
                });
            })));
            });
        })));
        })));
    }
    prism_rtl::unreachable("no arm matched");
}


/// PromptStmtSpots: unbounded fn PCx, Stmt, (Text ==> Rel) -> [Spot]
Array<crate::check::shrink::walk::Spot> prompt_stmt_spots_f(const PCx& cx_p0, const crate::syntax::Stmt& s_p1, const Map<Text, crate::check::shrink::Rel>& m_p2) {
    auto&& _m = s_p1.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        return Array(std::vector{crate::check::shrink::walk::Spot(crate::check::shrink::walk::Spot::SpotStmt{s_p1, m_p2})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        return Array(std::vector{crate::check::shrink::walk::Spot(crate::check::shrink::walk::Spot::SpotStmt{s_p1, m_p2})});
    }
    {
        return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::walk::stmt_kids_f(s_p1, m_p2), Array(std::vector{crate::check::shrink::walk::Spot(crate::check::shrink::walk::Spot::SpotStmt{s_p1, m_p2})}), ({
            auto cx_p0x = cx_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Spot>>(std::tuple<Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid>)>>(prism_rtl::rc([=, cx_p0x = std::move(cx_p0x)](std::tuple<Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx_p0xy = cx_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, cx_p0xy = std::move(cx_p0xy)]() {
                return ({
                    auto acc_p3 = p0;
                    auto k_p4 = p1;
                    (prism_rtl::finished(crate::prelude::append(acc_p3, prompt_kid_spots_f(cx_p0xy, k_p4))));
                });
            })));
            });
        })));
        })));
    }
}


/// FindCycle: unbounded fn [Text], [((Text, Text))] -> [Text]
Array<Text> find_cycle_f(const Array<Text>& defs_p0, const Array<std::tuple<Text, Text>>& edges_p1) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(defs_p0, Array<Text>{}, ({
        auto defs_p0x = defs_p0;
        auto edges_p1x = edges_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, defs_p0x = std::move(defs_p0x), edges_p1x = std::move(edges_p1x)](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto defs_p0xy = defs_p0x;
            auto edges_p1xy = edges_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, defs_p0xy = std::move(defs_p0xy), edges_p1xy = std::move(edges_p1xy)]() {
            return ({
                auto found_p2 = p0;
                auto d_p3 = p1;
                (crate::prelude::len(found_p2) > Nat(0u)
                ? prism_rtl::finished(found_p2)
                : prism_rtl::more(prism_rtl::rc(CycleThrough(defs_p0xy, edges_p1xy, d_p3))));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> FindCycle::cycle() const {
    const auto& defs_p0 = this->defs_p0;
    const auto& edges_p1 = this->edges_p1;
    return crate::prelude::fold_job(defs_p0, Array<Text>{}, ({
        auto defs_p0x = defs_p0;
        auto edges_p1x = edges_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, defs_p0x = std::move(defs_p0x), edges_p1x = std::move(edges_p1x)](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto defs_p0xy = defs_p0x;
            auto edges_p1xy = edges_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, defs_p0xy = std::move(defs_p0xy), edges_p1xy = std::move(edges_p1xy)]() {
            return ({
                auto found_p2 = p0;
                auto d_p3 = p1;
                (crate::prelude::len(found_p2) > Nat(0u)
                ? prism_rtl::finished(found_p2)
                : prism_rtl::more(prism_rtl::rc(CycleThrough(defs_p0xy, edges_p1xy, d_p3))));
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start FindCycle, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_find_cycle_f(Array<Text> defs_p0, Array<std::tuple<Text, Text>> edges_p1) {
    return prism_rtl::make_rc<FindCycle>(defs_p0, edges_p1);
}


/// CycleThrough: unbounded fn [Text], [((Text, Text))], Text -> [Text]
Array<Text> cycle_through_f(const Array<Text>& defs_p0, const Array<std::tuple<Text, Text>>& edges_p1, const Text& d_p2) {
    auto fwd_p3 = reach_from_f(edges_p1, d_p2);
    return crate::check::types::has_text_f(fwd_p3, d_p2)
        ? crate::prelude::run_to_end(crate::prelude::filter_job(defs_p0, ({
        auto fwd_p3x = fwd_p3;
        auto edges_p1x = edges_p1;
        auto d_p2x = d_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, fwd_p3x = std::move(fwd_p3x), edges_p1x = std::move(edges_p1x), d_p2x = std::move(d_p2x)](Text p0) {
        return ({
            auto fwd_p3xy = fwd_p3x;
            auto edges_p1xy = edges_p1x;
            auto d_p2xy = d_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, fwd_p3xy = std::move(fwd_p3xy), edges_p1xy = std::move(edges_p1xy), d_p2xy = std::move(d_p2xy)]() {
            return ({
                auto x_p4 = p0;
                (prism_rtl::finished(crate::check::types::has_text_f(fwd_p3xy, x_p4) && crate::check::types::has_text_f(reach_from_f(edges_p1xy, x_p4), d_p2xy)));
            });
        })));
        });
    })));
    })))
        : Array<Text>{};
}


prism_rtl::Turn<Array<Text>> CycleThrough::cycle() const {
    const auto& defs_p0 = this->defs_p0;
    const auto& edges_p1 = this->edges_p1;
    const auto& d_p2 = this->d_p2;
    auto d_p2x = d_p2;
    auto defs_p0x = defs_p0;
    auto edges_p1x = edges_p1;
    return crate::prelude::call_then(start_reach_from_f(edges_p1x, d_p2x), [=](Array<Text> reach_from_f_12532) {
        return ({
            auto fwd_p3 = reach_from_f_12532;
            (crate::check::types::has_text_f(fwd_p3, d_p2x)
            ? crate::prelude::filter_job(defs_p0x, ({
            auto fwd_p3x = fwd_p3;
            auto edges_p1xx = edges_p1x;
            auto d_p2xx = d_p2x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, fwd_p3x = std::move(fwd_p3x), edges_p1xx = std::move(edges_p1xx), d_p2xx = std::move(d_p2xx)](Text p0) {
            return ({
                auto fwd_p3xy = fwd_p3x;
                auto edges_p1xxy = edges_p1xx;
                auto d_p2xxy = d_p2xx;
                (crate::prelude::entered(crate::prelude::once_job([=, fwd_p3xy = std::move(fwd_p3xy), edges_p1xxy = std::move(edges_p1xxy), d_p2xxy = std::move(d_p2xxy)]() {
                return ({
                    auto x_p4 = p0;
                    (prism_rtl::finished(crate::check::types::has_text_f(fwd_p3xy, x_p4) && crate::check::types::has_text_f(reach_from_f(edges_p1xxy, x_p4), d_p2xxy)));
                });
            })));
            });
        })));
        }))->cycle()
            : prism_rtl::finished(Array<Text>{}));
        });
    });
}


/// `Start CycleThrough, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cycle_through_f(Array<Text> defs_p0, Array<std::tuple<Text, Text>> edges_p1, Text d_p2) {
    return prism_rtl::make_rc<CycleThrough>(defs_p0, edges_p1, d_p2);
}


/// ReachFrom: unbounded fn [((Text, Text))], Text -> [Text]
Array<Text> reach_from_f(const Array<std::tuple<Text, Text>>& edges_p0, const Text& d_p1) {
    return reach_f(edges_p0, crate::prelude::each(crate::prelude::filter(edges_p0, [&](const std::tuple<Text, Text>& _p0) {
        auto&& f_p2 = std::get<0>(_p0);
        return f_p2 == d_p1;
    }), [&](const std::tuple<Text, Text>& _p0) {
        auto&& t_p3 = std::get<1>(_p0);
        return t_p3;
    }), Array<Text>{});
}


prism_rtl::Turn<Array<Text>> ReachFrom::cycle() const {
    const auto& edges_p0 = this->edges_p0;
    const auto& d_p1 = this->d_p1;
    return prism_rtl::finished(reach_f(edges_p0, crate::prelude::each(crate::prelude::filter(edges_p0, [&](const std::tuple<Text, Text>& _p0) {
        auto&& f_p2 = std::get<0>(_p0);
        return f_p2 == d_p1;
    }), [&](const std::tuple<Text, Text>& _p0) {
        auto&& t_p3 = std::get<1>(_p0);
        return t_p3;
    }), Array<Text>{}));
}


/// `Start ReachFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_reach_from_f(Array<std::tuple<Text, Text>> edges_p0, Text d_p1) {
    return prism_rtl::make_rc<ReachFrom>(edges_p0, d_p1);
}


/// Reach: unbounded fn [((Text, Text))], [Text], [Text] -> [Text]
Array<Text> reach_f(const Array<std::tuple<Text, Text>>& edges_p0, const Array<Text>& frontier_p1, const Array<Text>& seen_p2) {
    auto&& _m = crate::prelude::index(frontier_p1, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return seen_p2;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& x_p3 = prism_rtl::some_of(_m);
        return crate::check::types::has_text_f(seen_p2, x_p3)
            ? reach_f(edges_p0, crate::prelude::drop(frontier_p1, Nat(1u)), seen_p2)
            : reach_f(edges_p0, crate::prelude::append(crate::prelude::drop(frontier_p1, Nat(1u)), crate::prelude::each(crate::prelude::filter(edges_p0, [&](const std::tuple<Text, Text>& _p0) {
            auto&& f_p4 = std::get<0>(_p0);
            return f_p4 == x_p3;
        }), [&](const std::tuple<Text, Text>& _p0) {
            auto&& t_p5 = std::get<1>(_p0);
            return t_p5;
        })), crate::prelude::push(seen_p2, x_p3));
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::check::passes::cycles
