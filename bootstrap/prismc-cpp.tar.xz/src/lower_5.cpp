// The module `Lower`, from `target/bootstrap/cpp-src/prismc/lower.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "lower.hpp"
#include "ast.hpp"
#include "check_env.hpp"
#include "check_errors.hpp"
#include "check_types.hpp"
#include "lexer.hpp"
#include "typed.hpp"
#include "lower.generic.hpp"
#include "check_env.generic.hpp"
#include "lexer.generic.hpp"

namespace crate::lower {

prism_rtl::Turn<Ex> TailMatch::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& s = this->s;
    const auto& arms = this->arms;
    const auto& span = this->span;
    auto arms_1 = arms;
    auto env_2 = env;
    auto lx_3 = lx;
    auto s_4 = s;
    auto span_5 = span;
    return call_then(start_value_of(lx_3, env_2, s_4), [=](Vl value_of_175400) {
        return ({
            auto sv = value_of_175400;
            auto sty = type_at(lx_3, s_4.span);
            auto label = prism_rtl::cat("m", span_5.start);
            call_value(each_job(check_errors::range0(len(arms_1)), ({
            auto lx_3_6 = lx_3;
            auto arms_1_6 = arms_1;
            auto sty_6 = sty;
            auto label_7 = label;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto lx_3_6_8 = lx_3_6;
                auto arms_1_6_8 = arms_1_6;
                auto sty_6_8 = sty_6;
                auto label_7_8 = label_7;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(ArmPat(lx_3_6_8, or_(index(arms_1_6_8, i), dummy_arm()).pattern, sty_6_8, Holding(Holding::ByRef{}), prism_rtl::cat(label_7_8, "_", i)))));
                });
            }));
            });
        })));
        })), [=](Array<PatOut> each_175499) {
            return ({
                auto by_ref = each_175499;
                auto chain = fold(by_ref, false, [&](const bool& f, const PatOut& po) { return f || fold(po.conds, false, [&](const bool& f2, const Cc& c) { return f2 || is_let_cond(c); }); });
                auto owned = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    if (prism_rtl::is<Vl::VlOwned>(sv)) {
                        _v.set(!chain);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto pats = owned
                    ? run_to_end(each_job(check_errors::range0(len(arms_1)), ({
                    auto lx_3_6 = lx_3;
                    auto arms_1_6 = arms_1;
                    auto sty_6 = sty;
                    auto label_7 = label;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto lx_3_6_8 = lx_3_6;
                        auto arms_1_6_8 = arms_1_6;
                        auto sty_6_8 = sty_6;
                        auto label_7_8 = label_7;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            (prism_rtl::more(prism_rtl::rc(ArmPat(lx_3_6_8, or_(index(arms_1_6_8, i), dummy_arm()).pattern, sty_6_8, Holding(Holding::Owned{}), prism_rtl::cat(label_7_8, "_", i)))));
                        });
                    }));
                    });
                })));
                })))
                    : by_ref;
                call_value(each_job(check_errors::range0(len(arms_1)), ({
                auto arms_1_6 = arms_1;
                auto pats_6 = pats;
                auto env_2_7 = env_2;
                auto lx_3_7 = lx_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto arms_1_6_7 = arms_1_6;
                    auto pats_6_7 = pats_6;
                    auto env_2_7_7 = env_2_7;
                    auto lx_3_7_7 = lx_3_7;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        ({
                        auto arm = or_(index(arms_1_6_7, i), dummy_arm());
                        auto po = or_(index(pats_6_7, i), PatOut{.pa = Pa(Pa::PaWild{}), .conds = Array<Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}});
                        auto env2 = bind_all(env_2_7_7, po.binds);
                        call_then(start_guard_conds(lx_3_7_7, env2, arm.guard), [=](Array<Cc> guard_conds_176178) { return call_then(start_tail_block(lx_3_7_7, env2, arm.body), [=](Ex tail_block_176219) { return prism_rtl::finished(XArm{.pat = po.pa, .conds = append(po.conds, guard_conds_176178), .body = tail_block_176219}); }); });
                    });
                    });
                }));
                });
            })));
            })), [=](Array<XArm> each_175945) {
                return ({
                    auto xarms = each_175945;
                    auto scrut = owned ? own(sv) : ref_(sv);
                    (prism_rtl::finished(own(arms_value(scrut, xarms, prism_rtl::cat("'", label), OutTy(OutTy::OutUnknown{Text("the job's turn")})))));
                });
            });
            });
        });
        });
    });
}


/// `Start TailMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_tail_match(Lx lx, Env env, ast::Expr s, Array<ast::Arm> arms, ast::Range span) {
    return std::make_shared<TailMatch>(lx, env, s, arms, span);
}


/// ?TailCallee: fn Lx, Env, Expr -> ?Text
std::optional<Text> tail_callee(const Lx& lx, const Env& env, const ast::Expr& callee) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        auto&& _m = callee.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set((len(n->path_) == Nat(1u)) && check_env::has_key(env->names, check_env::sname_key(n))
                ? std::optional<Text>{}
                : ({
                auto&& _qk_opt = check_env::resolve_value(lx.g, lx.home, n);
                auto&& qk_opt = std::get<0>(_qk_opt);
                ({
                __label__ _done;
                prism_rtl::Slot<std::optional<Text>> _v;
                if (prism_rtl::is_some(qk_opt)) {
                    auto&& qk = prism_rtl::some_of(qk_opt);
                    _v.set(check_types::has_text(lx.unbs, qk) && (!in_prelude(lx, qk))
                        ? std::optional(qk)
                        : std::optional<Text>{});
                    goto _done;
                }
                if (prism_rtl::is_none(qk_opt)) {
                    _v.set(std::optional<Text>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// SchemeParts: fn Lx, Text -> (([Ty], Ty))
std::tuple<Array<check_types::Ty>, check_types::Ty> scheme_parts(const Lx& lx, const Text& qk) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<check_types::Ty>, check_types::Ty>> _v;
        auto&& _m = prelude::get(lx.g.vals, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<check_types::Ty>, check_types::Ty>> _v;
                auto&& _m = v_.scheme.ty;
                if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                    auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
                    auto&& r = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
                    _v.set(std::tuple{ps, r});
                    goto _done;
                }
                {
                    auto&& other = _m;
                    _v.set(std::tuple{Array<check_types::Ty>{}, other});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{Array<check_types::Ty>{}, check_types::Ty(check_types::Ty::TyErr{})});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// JobFieldNames: unbounded fn Lx, Text -> [Text]
Array<Text> job_field_names(const Lx& lx, const Text& qk) {
    auto clauses = clauses_of(lx.g, qk);
    auto&& _ptys = scheme_parts(lx, qk);
    auto&& ptys = std::get<0>(_ptys);
    auto pts = run_to_end(each_job(ptys, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, peel(p_)))));
            });
        }));
        });
    })));
    })));
    return each(param_names(lx, clauses, pts), [&](const std::tuple<Text, bool>& _p0) {
        auto&& n = std::get<0>(_p0);
        return n;
    });
}


prism_rtl::Turn<Array<Text>> JobFieldNames::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    auto clauses = clauses_of(lx.g, qk);
    auto&& _ptys = scheme_parts(lx, qk);
    auto&& ptys = std::get<0>(_ptys);
    auto lx_1 = lx;
    return call_value(each_job(ptys, ({
        auto lx_1_2 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto lx_1_2_2 = lx_1_2;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2_2, peel(p_)))));
            });
        }));
        });
    })));
    })), [=](Array<OutTy> each_177286) {
        return ({
            auto pts = each_177286;
            (prism_rtl::finished(each(param_names(lx_1, clauses, pts), [&](const std::tuple<Text, bool>& _p0) {
            auto&& n = std::get<0>(_p0);
            return n;
        })));
        });
    });
}


/// `Start JobFieldNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_job_field_names(Lx lx, Text qk) {
    return std::make_shared<JobFieldNames>(lx, qk);
}


/// ClausesOf: fn G, Text -> [FnClause]
Array<ast::FnClause> clauses_of(const check_env::G& g, const Text& qk) {
    return fold(g.defs, Array<ast::FnClause>{}, [&](const Array<ast::FnClause>& acc, const check_env::Def& d) { return d.qk == qk ? def_clauses(d, acc) : acc; });
}


/// DefClauses: fn Def, [FnClause] -> [FnClause]
Array<ast::FnClause> def_clauses(const check_env::Def& d, const Array<ast::FnClause>& other) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<ast::FnClause>> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
            auto&& cs = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
            _v.set(cs);
            goto _done;
        }
        {
            _v.set(other);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// JobDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> JobDef
JobDef job_def_of(const Lx& lx, const Text& qk, const Array<ast::FnClause>& clauses, const check_types::Scheme& sc) {
    auto [ptys, res] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<check_types::Ty>, check_types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            auto&& r = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps, r});
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(std::tuple{Array<check_types::Ty>{}, other});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto pts = run_to_end(each_job(ptys, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, peel(p_)))));
            });
        }));
        });
    })));
    })));
    auto names = param_names(lx, clauses, pts);
    auto body = job_clauses(lx, clauses, names, ptys, pts);
    auto base_ = or_(prelude::get(lx.rs_names, qk), snake(check_types::bare_name(qk)));
    return JobDef{.name = camel(check_types::bare_name(qk)), .start = prism_rtl::cat("start_", base_), .generics = scheme_generics(lx, sc), .fields = each(check_errors::range0(len(pts)), [&](const Nat& i) {
        return std::tuple{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
            auto&& n = std::get<0>(_p0);
            return n;
        }), i), Text("arg")), or_(index(pts, i), OutTy(OutTy::OutUnit{}))};
    }), .ret = out_ty_of(lx, peel(res)), .body = body, .doc = signature_text(lx, qk)};
}


prism_rtl::Turn<JobDef> JobDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    const auto& clauses = this->clauses;
    const auto& sc = this->sc;
    auto [ptys, res] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<check_types::Ty>, check_types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            auto&& r = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps, r});
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(std::tuple{Array<check_types::Ty>{}, other});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto clauses_1 = clauses;
    auto lx_2 = lx;
    auto qk_3 = qk;
    auto sc_4 = sc;
    return call_value(each_job(ptys, ({
        auto lx_2_5 = lx_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto lx_2_5_5 = lx_2_5;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_2_5_5, peel(p_)))));
            });
        }));
        });
    })));
    })), [=](Array<OutTy> each_177940) {
        return ({
            auto pts = each_177940;
            auto names = param_names(lx_2, clauses_1, pts);
            call_then(start_job_clauses(lx_2, clauses_1, names, ptys, pts), [=](Ex job_clauses_178036) {
            return ({
                auto body = job_clauses_178036;
                auto base_ = or_(prelude::get(lx_2.rs_names, qk_3), snake(check_types::bare_name(qk_3)));
                call_then(start_out_ty_of(lx_2, peel(res)), [=](OutTy out_ty_of_178347) {
                return prism_rtl::finished(JobDef{.name = camel(check_types::bare_name(qk_3)), .start = prism_rtl::cat("start_", base_), .generics = scheme_generics(lx_2, sc_4), .fields = each(check_errors::range0(len(pts)), [&](const Nat& i) {
                    return std::tuple{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
                        auto&& n = std::get<0>(_p0);
                        return n;
                    }), i), Text("arg")), or_(index(pts, i), OutTy(OutTy::OutUnit{}))};
                }), .ret = out_ty_of_178347, .body = body, .doc = signature_text(lx_2, qk_3)});
            });
            });
        });
        });
    });
}


/// `Start JobDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<JobDef> start_job_def_of(Lx lx, Text qk, Array<ast::FnClause> clauses, check_types::Scheme sc) {
    return std::make_shared<JobDefOf>(lx, qk, clauses, sc);
}


/// JobClauses: unbounded fn Lx, [FnClause], [((Text, Bool))], [Ty], [OutTy] -> Ex
Ex job_clauses(const Lx& lx, const Array<ast::FnClause>& clauses, const Array<std::tuple<Text, bool>>& names, const Array<check_types::Ty>& ptys, const Array<OutTy>& pts) {
    auto lets = each(check_errors::range0(len(names)), [&](const Nat& i) {
        return ({
            auto&& _rs = or_(index(names, i), std::tuple{Text("arg"), true});
            auto&& rs = std::get<0>(_rs);
            (Do(Do::DoLet{Pa(Pa::PaBind{rs}), Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), rs}))})}));
        });
    });
    auto inner = clauses_body(lx, empty_env(), clauses, names, ptys, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Lx, Env, ast::FnBody>)>>(prism_rtl::rc([&](std::tuple<Lx, Env, ast::FnBody> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        auto&& a2 = std::get<2>(_p0);
        return entered(start_tail_body(a0, a1, a2));
    })), Text("j"), OutTy(OutTy::OutUnknown{Text("the job's turn")}));
    return Ex(Ex::XBlock{lets, prism_rtl::rc(inner)});
}


prism_rtl::Turn<Ex> JobClauses::cycle() const {
    const auto& lx = this->lx;
    const auto& clauses = this->clauses;
    const auto& names = this->names;
    const auto& ptys = this->ptys;
    const auto& pts = this->pts;
    auto lets = each(check_errors::range0(len(names)), [&](const Nat& i) {
        return ({
            auto&& _rs = or_(index(names, i), std::tuple{Text("arg"), true});
            auto&& rs = std::get<0>(_rs);
            (Do(Do::DoLet{Pa(Pa::PaBind{rs}), Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), rs}))})}));
        });
    });
    auto clauses_1 = clauses;
    auto lx_2 = lx;
    auto names_3 = names;
    auto ptys_4 = ptys;
    return call_then(start_clauses_body(lx_2, empty_env(), clauses_1, names_3, ptys_4, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Lx, Env, ast::FnBody>)>>(prism_rtl::rc([&](std::tuple<Lx, Env, ast::FnBody> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        auto&& a2 = std::get<2>(_p0);
        return entered(start_tail_body(a0, a1, a2));
    })), Text("j"), OutTy(OutTy::OutUnknown{Text("the job's turn")})), [=](Ex clauses_body_178776) {
        return ({
            auto inner = clauses_body_178776;
            (prism_rtl::finished(Ex(Ex::XBlock{lets, prism_rtl::rc(inner)})));
        });
    });
}


/// `Start JobClauses, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_job_clauses(Lx lx, Array<ast::FnClause> clauses, Array<std::tuple<Text, bool>> names, Array<check_types::Ty> ptys, Array<OutTy> pts) {
    return std::make_shared<JobClauses>(lx, clauses, names, ptys, pts);
}


/// IdPipe: unbounded fn Ex, (unbounded fn Ex -> [Do]) -> [Do]
Array<Do> id_pipe(const Ex& x, const prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>& k_fn) {
    return run_to_end(k_fn(x));
}


prism_rtl::Turn<Array<Do>> IdPipe::cycle() const {
    const auto& x = this->x;
    const auto& k_fn = this->k_fn;
    return k_fn(x)->cycle();
}


/// `Start IdPipe, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Do>> start_id_pipe(Ex x, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)> k_fn) {
    return std::make_shared<IdPipe>(x, k_fn);
}


/// EvRefOf: fn Wx, Nat -> EvRef
EvRef ev_ref_of(const Wx& wx, const Nat& n) {
    return EvRef{.node_ = n, .owner = wx.node_, .pipe = static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>)>>(prism_rtl::rc([&](std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        return entered(start_id_pipe(a0, a1));
    }))};
}


/// KindWord: fn GnKind -> Text
Text kind_word(const GnKind& k) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<GnKind::GnNamed>(k)) {
            _v.set(Text("named"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnAnswer>(k)) {
            _v.set(Text("answer"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnStarted>(k)) {
            _v.set(Text("started"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnDeferred>(k)) {
            _v.set(Text("deferred"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnPort>(k)) {
            _v.set(Text("port"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnMerge>(k)) {
            _v.set(Text("merge"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnUnion>(k)) {
            _v.set(Text("union"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnBoth>(k)) {
            _v.set(Text("both"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnExcept>(k)) {
            _v.set(Text("except"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnMergeAll>(k)) {
            _v.set(Text("mergeall"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnGather>(k)) {
            _v.set(Text("gather"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnUpdated>(k)) {
            _v.set(Text("updated"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnNever>(k)) {
            _v.set(Text("never"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// HasRead: fn [Read], Read -> Bool
bool has_read(const Array<Read>& rs, const Read& r) {
    return fold(rs, false, [&](const bool& seen, const Read& x) { return seen || (x == r); });
}


/// AddRead: fn [Read], Read -> [Read]
Array<Read> add_read(const Array<Read>& rs, const Read& r) {
    return has_read(rs, r) ? rs : prelude::push(rs, r);
}


/// UnionReads: fn [Read], [Read] -> [Read]
Array<Read> union_reads(const Array<Read>& xs, const Array<Read>& ys) {
    return fold(ys, xs, [&](const Array<Read>& acc, const Read& y) { return add_read(acc, y); });
}


/// let nodeHooks
Array<Text> node_hooks() {
    return Array(std::vector{Text("path"), Text("build"), Text("wake"), Text("started"), Text("deferred"), Text("answer"), Text("push"), Text("swap"), Text("leave"), Text("patch"), Text("clean_up"), Text("edges"), Text("release"), Text("leave_row"), Text("remove_places")});
}


/// NewWx: fn Lx, Text, [((Text, OutTy, Text))], [((Text, Ex))], [((Text, Ex))], [MethDef], (Text ==> [Read]), [Text], Nat, ?Text -> Wx
Wx new_wx(const Lx& lx, const Text& name, const Array<std::tuple<Text, OutTy, Text>>& fields, const Array<std::tuple<Text, Ex>>& inits, const Array<std::tuple<Text, Ex>>& moves_, const Array<MethDef>& getters, const Map<Text, Array<Read>>& dyn_reads, const Array<Text>& taken, const Nat& depth, const std::optional<Text>& hosted_by_opt) {
    auto hosted_fields = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Text, OutTy, Text>>> _v;
        if (prism_rtl::is_some(hosted_by_opt)) {
            _v.set(Array(std::vector{std::tuple{Text("enclosing"), host_of_ty(), Text("the host whose document this row's places are entries of (pick HO)")}}));
            goto _done;
        }
        if (prism_rtl::is_none(hosted_by_opt)) {
            _v.set(Array<std::tuple<Text, OutTy, Text>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto hosted_inits = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Text, Ex>>> _v;
        if (prism_rtl::is_some(hosted_by_opt)) {
            _v.set(Array(std::vector{std::tuple{Text("enclosing"), Ex(Ex::XVar{Text("enclosing")})}}));
            goto _done;
        }
        if (prism_rtl::is_none(hosted_by_opt)) {
            _v.set(Array<std::tuple<Text, Ex>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return Wx{.lx = lx, .node_ = name, .pos = pos0(), .gns = Array<Gn>{}, .fields = append(fields, hosted_fields), .inits = inits, .moves = append(moves_, hosted_inits), .lets = Array<Do>{}, .build = Array<Do>{}, .places = Array<Place>{}, .answers = Array<std::tuple<Pos_, Nat, OutTy, Text>>{}, .started = Array<Nat>{}, .defers = Array<std::tuple<Text, Nat>>{}, .getters = getters, .dyn_reads = dyn_reads, .taken = prelude::push(taken, Text("enclosing")), .fallible = false, .depth = depth, .result = Wres(Wres::WrUnit{}), .rows = Array<NodeDef>{}, .builders = Array<ForDef>{}, .build_holds = Array<Read>{}, .up_sink = Text(""), .gens = Array<GenDef>{}, .gen_holds = Array<std::tuple<Text, Array<Read>>>{}, .ports = Array<Text>{}, .subs = Array<std::tuple<Text, Text, OutTy>>{}, .parent_env = empty_env(), .hosts = Array<HostDef>{}, .dyn_places = Array<std::tuple<Pos_, Text, OutTy, Text>>{}, .scopes = Array<Text>{}, .hosted_by = hosted_by_opt, .root_dyn = std::optional<std::tuple<Ex, Array<Read>, OutTy>>{}, .row_marks = Array<RowMarks>{}, .pending = Array<PendingRow>{}, .floors = Map<Text, Nat>{}, .snaps = Array<SnapDef>{}, .result_moved = std::optional<std::tuple<Text, Array<Read>>>{}, .dyn_answers = Array<std::tuple<Text, Array<Read>>>{}, .inited = Array<Text>{}, .flattens = Array<FlatDef>{}};
}


/// FreshName: fn Wx, Text -> ((Text, Wx))
std::tuple<Text, Wx> fresh_name(const Wx& wx, const Text& base_) {
    auto pick = !check_types::has_text(wx.taken, base_)
        ? base_
        : prism_rtl::cat(base_, "_", first_free(wx.taken, base_, Nat(2u)));
    auto wx2 = ({
        Wx this_ = wx;
        this_.taken = prelude::push(this_.taken, pick);
        this_;
    });
    return std::tuple{pick, wx2};
}


/// FirstFree: fn [Text], Text, Nat -> Nat
Nat first_free(const Array<Text>& taken, const Text& base_, const Nat& from) {
    return fold(check_errors::range0(len(taken)), from, [&](const Nat& n, const Nat& _p1) {
        return check_types::has_text(taken, prism_rtl::cat(base_, "_", n))
            ? n + Nat(1u)
            : n;
    });
}


/// AddGn: fn Wx, Text, OutTy, GnKind, Nat -> ((Nat, Wx))
std::tuple<Nat, Wx> add_gn(const Wx& wx, const Text& name, const OutTy& ty, const GnKind& kind, const Nat& height) {
    auto id = len(wx.gns);
    auto wx2 = ({
        Wx this_ = wx;
        this_.gns = prelude::push(this_.gns, Gn{.id = id, .name = name, .ty = ty, .kind = kind, .height = height, .inputs = Array<Text>{}, .reads = Array<Read>{}, .floor = Nat(0u), .outs = Array<Out>{}});
        this_;
    });
    return std::tuple{id, wx2};
}


/// Connect: fn Wx, EvRef, Sk -> Wx
Wx connect(const Wx& wx, const EvRef& r, const Sk& sink) {
    return r.owner != wx.node_
        ? crossed(wx, prism_rtl::cat("an event of node `", r.owner, "` (its graph node ", r.node_, ")"))
        : ({
        Wx this_ = wx;
        this_.gns = each(this_.gns, [&](const Gn& n) { return n.id == r.node_ ? add_out(n, Out{.pipe = r.pipe, .sink = sink}) : n; });
        this_;
    });
}


/// Crossed: fn Wx, Text -> Wx
Wx crossed(const Wx& wx, const Text& what) {
    Wx this_ = wx;
    this_.build = prelude::push(this_.build, Do(Do::DoExpr{refusal(prism_rtl::cat(what, " read in node `", wx.node_, "` without a port (a lowering bug)"))}));
    return this_;
}


/// AddOut: fn Gn, Out -> Gn
Gn add_out(const Gn& n, const Out& o) {
    Gn this_ = n;
    this_.outs = prelude::push(this_.outs, o);
    return this_;
}


/// AddField: fn Wx, Text, OutTy, Text, Ex -> Wx
Wx add_field(const Wx& wx, const Text& name, const OutTy& t, const Text& doc, const Ex& init) {
    Wx this_ = wx;
    this_.fields = prelude::push(this_.fields, std::tuple{name, t, doc});
    this_.inits = prelude::push(this_.inits, std::tuple{name, init});
    return this_;
}


/// AddFieldLast: fn Wx, Text, OutTy, Text, Ex -> Wx
Wx add_field_last(const Wx& wx, const Text& name, const OutTy& t, const Text& doc, const Ex& init) {
    Wx this_ = wx;
    this_.fields = prelude::push(this_.fields, std::tuple{name, t, doc});
    this_.moves = prelude::push(this_.moves, std::tuple{name, init});
    return this_;
}


/// GnOf: fn Wx, Nat -> Gn
Gn gn_of(const Wx& wx, const Nat& n) {
    return or_(index(wx.gns, n), Gn{.id = n, .name = Text("never"), .ty = OutTy(OutTy::OutUnit{}), .kind = GnKind(GnKind::GnNever{}), .height = Nat(0u), .inputs = Array<Text>{}, .reads = Array<Read>{}, .floor = Nat(0u), .outs = Array<Out>{}});
}


/// BindPlain: fn Env, Env, Text, Text, OutTy -> ((Env, Env))
std::tuple<Env, Env> bind_plain(const Env& benv, const Env& menv, const Text& nkey, const Text& rs, const OutTy& t) {
    return std::tuple{bind(benv, nkey, Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::Owned{}), t})), bind(menv, nkey, Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), rs}), Holding(Holding::Owned{}), t}))};
}


/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
NodeDef node_def_of(const Lx& lx, const Text& qk, const Array<ast::Pattern_>& params, const ast::Block& body, const check_types::Scheme& sc, const bool& is_root) {
    auto name = camel(check_types::bare_name(qk));
    auto ptys = ({
        __label__ _done;
        prism_rtl::Slot<Array<check_types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            _v.set(ps);
            goto _done;
        }
        {
            _v.set(Array<check_types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto wx0 = new_wx(lx, name, Array<std::tuple<Text, OutTy, Text>>{}, Array<std::tuple<Text, Ex>>{}, Array<std::tuple<Text, Ex>>{}, Array<MethDef>{}, Map<Text, Array<Read>>{}, node_hooks(), Nat(0u), std::optional<Text>{});
    auto [ps, wx1, benv, menv] = run_to_end(fold_job(check_errors::range0(len(params)), std::tuple{Array<std::tuple<Text, OutTy>>{}, wx0, empty_env(), empty_env()}, ({
        auto params_1 = params;
        auto lx_2 = lx;
        auto ptys_3 = ptys;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, OutTy>>, Wx, Env, Env>>(std::tuple<std::tuple<Array<std::tuple<Text, OutTy>>, Wx, Env, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, OutTy>>, Wx, Env, Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_1_4 = params_1;
            auto lx_2_4 = lx_2;
            auto ptys_3_4 = ptys_3;
            entered(once_job([=]() {
            return ({
                auto [acc, w, be, me] = p0;
                auto i = p1;
                ({
                auto p_ = or_(index(params_1_4, i), dummy_pat());
                auto nkey = plain_binder(lx_2_4, p_);
                auto base_ = nkey == Text("") ? prism_rtl::cat("arg", i) : snake(nkey);
                auto [rs, w2] = fresh_name(w, base_);
                call_then(start_out_ty_of(lx_2_4, peel(or_(index(ptys_3_4, i), check_types::Ty(check_types::Ty::TyErr{})))), [=](OutTy out_ty_of_194675) {
                return ({
                    auto t = out_ty_of_194675;
                    auto w3 = ({
                        Wx this_ = w2;
                        this_.fields = prelude::push(this_.fields, std::tuple{rs, t, Text("a parameter")});
                        this_.inits = prelude::push(this_.inits, std::tuple{rs, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{rs}))})});
                        this_;
                    });
                    auto [be2, me2] = bind_plain(be, me, nkey, rs, t);
                    (prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{rs, t}), w3, be2, me2}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto wx2 = block_into(wx1, benv, menv, body);
    auto wx3 = is_root ? root_result(wx2) : wx2;
    return finish_node(wx3, qk, ps, false);
}


prism_rtl::Turn<NodeDef> NodeDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    const auto& params = this->params;
    const auto& body = this->body;
    const auto& sc = this->sc;
    const auto& is_root = this->is_root;
    auto name = camel(check_types::bare_name(qk));
    auto ptys = ({
        __label__ _done;
        prism_rtl::Slot<Array<check_types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            _v.set(ps);
            goto _done;
        }
        {
            _v.set(Array<check_types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto wx0 = new_wx(lx, name, Array<std::tuple<Text, OutTy, Text>>{}, Array<std::tuple<Text, Ex>>{}, Array<std::tuple<Text, Ex>>{}, Array<MethDef>{}, Map<Text, Array<Read>>{}, node_hooks(), Nat(0u), std::optional<Text>{});
    auto body_1 = body;
    auto is_root_2 = is_root;
    auto lx_3 = lx;
    auto params_4 = params;
    auto qk_5 = qk;
    return call_value(fold_job(check_errors::range0(len(params_4)), std::tuple{Array<std::tuple<Text, OutTy>>{}, wx0, empty_env(), empty_env()}, ({
        auto params_4_6 = params_4;
        auto lx_3_6 = lx_3;
        auto ptys_6 = ptys;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, OutTy>>, Wx, Env, Env>>(std::tuple<std::tuple<Array<std::tuple<Text, OutTy>>, Wx, Env, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, OutTy>>, Wx, Env, Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_4_6_7 = params_4_6;
            auto lx_3_6_7 = lx_3_6;
            auto ptys_6_7 = ptys_6;
            entered(once_job([=]() {
            return ({
                auto [acc, w, be, me] = p0;
                auto i = p1;
                ({
                auto p_ = or_(index(params_4_6_7, i), dummy_pat());
                auto nkey = plain_binder(lx_3_6_7, p_);
                auto base_ = nkey == Text("") ? prism_rtl::cat("arg", i) : snake(nkey);
                auto [rs, w2] = fresh_name(w, base_);
                call_then(start_out_ty_of(lx_3_6_7, peel(or_(index(ptys_6_7, i), check_types::Ty(check_types::Ty::TyErr{})))), [=](OutTy out_ty_of_194675) {
                return ({
                    auto t = out_ty_of_194675;
                    auto w3 = ({
                        Wx this_ = w2;
                        this_.fields = prelude::push(this_.fields, std::tuple{rs, t, Text("a parameter")});
                        this_.inits = prelude::push(this_.inits, std::tuple{rs, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{rs}))})});
                        this_;
                    });
                    auto [be2, me2] = bind_plain(be, me, nkey, rs, t);
                    (prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{rs, t}), w3, be2, me2}));
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<std::tuple<Text, OutTy>>, Wx, Env, Env> fold_194392) {
        return ({
            auto [ps, wx1, benv, menv] = fold_194392;
            call_then(start_block_into(wx1, benv, menv, body_1), [=](Wx block_into_194993) {
            return ({
                auto wx2 = block_into_194993;
                auto wx3 = is_root_2 ? root_result(wx2) : wx2;
                (prism_rtl::more(prism_rtl::rc(FinishNode(wx3, qk_5, ps, false))));
            });
        });
        });
    });
}


/// `Start NodeDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<NodeDef> start_node_def_of(Lx lx, Text qk, Array<ast::Pattern_> params, ast::Block body, check_types::Scheme sc, bool is_root) {
    return std::make_shared<NodeDefOf>(lx, qk, params, body, sc, is_root);
}


/// RootResult: fn Wx -> Wx
Wx root_result(const Wx& wx) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Wx> _v;
        auto&& _m = wx->result;
        if (prism_rtl::is<Wres::WrEv>(_m)) {
            auto&& r = prism_rtl::as<Wres::WrEv>(_m).a0;
            _v.set(connect(wx, r, Sk(Sk::SkResult{})));
            goto _done;
        }
        if (prism_rtl::is<Wres::WrDyn>(_m)) {
            auto&& x = prism_rtl::as<Wres::WrDyn>(_m).a0;
            auto&& rds = prism_rtl::as<Wres::WrDyn>(_m).a1;
            auto&& t = prism_rtl::as<Wres::WrDyn>(_m).a2;
            _v.set(({
                Wx this_ = wx;
                this_.root_dyn = std::optional(std::tuple{x, rds, t});
                this_.getters = prelude::push(this_.getters, MethDef{.name = Text("result_value"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = OutTy(OutTy::OutPod{}), .body = Array<Do>{}, .tail = Ex(Ex::XMethod{prism_rtl::rc(x), Text("to_pod"), Array<Ex>{}}), .doc = Text("The root's dynamic result, pulled after the tick.")});
                this_.fields = prelude::push(this_.fields, std::tuple{Text("result_last"), OutTy(OutTy::OutCell{prism_rtl::rc(OutTy(OutTy::OutOpt{prism_rtl::rc(OutTy(OutTy::OutPod{}))}))}), Text("the result the World last heard")});
                this_.moves = prelude::push(this_.moves, std::tuple{Text("result_last"), Ex(Ex::XCall{Text("RefCell::new"), Array(std::vector{Ex(Ex::XNone{})})})});
                this_.build = prelude::push(this_.build, Do(Do::DoScope{result_told(Ex(Ex::XVar{Text("node")}))}));
                this_;
            }));
            goto _done;
        }
        if (prism_rtl::is<Wres::WrPlain>(_m)) {
            auto&& x = prism_rtl::as<Wres::WrPlain>(_m).a0;
            _v.set(({
                Wx this_ = wx;
                this_.build = prelude::push(this_.build, Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("result"), Array(std::vector{Ex(Ex::XCtor{Text("Outcome::Value"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(x), Text("to_pod"), Array<Ex>{}})})})})})}));
                this_;
            }));
            goto _done;
        }
        {
            _v.set(wx);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
Wx block_into(const Wx& wx, const Env& benv, const Env& menv, const ast::Block& b) {
    auto [wx1, be1, me1] = run_to_end(fold_job(b.stmts, std::tuple{wx, benv, menv}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Env>>(std::tuple<std::tuple<Wx, Env, Env>, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Env>, ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [w, be, me] = p0;
                auto s = p1;
                (prism_rtl::more(prism_rtl::rc(PreBind(w, be, me, s))));
            });
        }));
    }))));
    auto n = len(b.stmts);
    auto&& _wx2 = run_to_end(fold_job(check_errors::range0(n), std::tuple{wx1, be1, me1}, ({
        auto b_1 = b;
        auto n_2 = n;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Env>>(std::tuple<std::tuple<Wx, Env, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_3 = b_1;
            auto n_2_3 = n_2;
            entered(once_job([=]() {
            return ({
                auto [w, be, me] = p0;
                auto i = p1;
                (prism_rtl::more(prism_rtl::rc(WidgetStmt(w, be, me, or_(index(b_1_3.stmts, i), dummy_stmt_l()), (i + Nat(1u)) == n_2_3))));
            });
        }));
        });
    }));
    })));
    auto&& wx2 = std::get<0>(_wx2);
    return wx2;
}


prism_rtl::Turn<Wx> BlockInto::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& b = this->b;
    auto b_1 = b;
    auto benv_2 = benv;
    auto menv_3 = menv;
    auto wx_4 = wx;
    return call_value(fold_job(b_1.stmts, std::tuple{wx_4, benv_2, menv_3}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Env>>(std::tuple<std::tuple<Wx, Env, Env>, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Env>, ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [w, be, me] = p0;
                auto s = p1;
                (prism_rtl::more(prism_rtl::rc(PreBind(w, be, me, s))));
            });
        }));
    }))), [=](std::tuple<Wx, Env, Env> fold_196314) {
        return ({
            auto [wx1, be1, me1] = fold_196314;
            auto n = len(b_1.stmts);
            call_value(fold_job(check_errors::range0(n), std::tuple{wx1, be1, me1}, ({
            auto b_1_5 = b_1;
            auto n_5 = n;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Env>>(std::tuple<std::tuple<Wx, Env, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Env>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto b_1_5_6 = b_1_5;
                auto n_5_6 = n_5;
                entered(once_job([=]() {
                return ({
                    auto [w, be, me] = p0;
                    auto i = p1;
                    (prism_rtl::more(prism_rtl::rc(WidgetStmt(w, be, me, or_(index(b_1_5_6.stmts, i), dummy_stmt_l()), (i + Nat(1u)) == n_5_6))));
                });
            }));
            });
        }));
        })), [=](std::tuple<Wx, Env, Env> fold_196447) {
            return ({
                auto&& _wx2 = fold_196447;
                auto&& wx2 = std::get<0>(_wx2);
                (prism_rtl::finished(wx2));
            });
        });
        });
    });
}


/// `Start BlockInto, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Wx> start_block_into(Wx wx, Env benv, Env menv, ast::Block b) {
    return std::make_shared<BlockInto>(wx, benv, menv, b);
}


/// PreBind: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
std::tuple<Wx, Env, Env> pre_bind(const Wx& wx, const Env& benv, const Env& menv, const ast::Stmt& s) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wx, Env, Env>> _v;
        auto&& _m = s.kind;
        if (prism_rtl::is<ast::StmtKind::SBind>(_m)) {
            auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
            auto&& init = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
            auto&& step_opt = prism_rtl::as<ast::StmtKind::SBind>(_m).a2;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Wx, Env, Env>> _v;
                auto&& _m = p_.kind;
                if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                    auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                    _v.set(pre_bind_name(wx, benv, menv, n, how_bound(step_opt)));
                    goto _done;
                }
                if (prism_rtl::is<ast::PatternKind::PTuple>(_m)) {
                    auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(_m).a0;
                    _v.set(run_to_end(fold_job(ps, std::tuple{wx, benv, menv}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Env>>(std::tuple<std::tuple<Wx, Env, Env>, ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Env>, ast::Pattern_> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return entered(once_job([=]() {
                            return ({
                                auto [w, be, me] = p0;
                                auto q = p1;
                                ({
                                auto&& _m = q.kind;
                                prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
                                auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                                prism_rtl::more(prism_rtl::rc(PreBindName(w, be, me, n, HowBound(HowBound::AsBind{}))));
                            })
                                : prism_rtl::finished(std::tuple{w, be, me});
                            });
                            });
                        }));
                    })))));
                    goto _done;
                }
                {
                    _v.set(std::tuple{wx, benv, menv});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
            auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Wx, Env, Env>> _v;
                auto&& _m = p_.kind;
                if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                    auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                    _v.set(pre_bind_name(wx, benv, menv, n, HowBound(HowBound::AsLet{})));
                    goto _done;
                }
                {
                    _v.set(std::tuple{wx, benv, menv});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SFn>(_m)) {
            auto&& c = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
            _v.set(({
                auto fname = check_env::def_name_text(c.name);
                std::tuple{wx, bind(benv, fname, Bn(Bn::BnLocalFn{c})), bind(menv, fname, Bn(Bn::BnLocalFn{c}))};
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{wx, benv, menv});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Wx, Env, Env>> PreBind::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SBind>(_m) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        auto&& init = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
        auto&& step_opt = prism_rtl::as<ast::StmtKind::SBind>(_m).a2;
        ({
        auto&& _m = p_.kind;
        prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PreBindName(wx, benv, menv, n, how_bound(step_opt))));
    })
        : prism_rtl::is<ast::PatternKind::PTuple>(_m) ? ({
        auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(_m).a0;
        fold_job(ps, std::tuple{wx, benv, menv}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Env>>(std::tuple<std::tuple<Wx, Env, Env>, ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Env>, ast::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [w, be, me] = p0;
                auto q = p1;
                ({
                auto&& _m = q.kind;
                prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
                auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                prism_rtl::more(prism_rtl::rc(PreBindName(w, be, me, n, HowBound(HowBound::AsBind{}))));
            })
                : prism_rtl::finished(std::tuple{w, be, me});
            });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::finished(std::tuple{wx, benv, menv});
    });
    })
        : prism_rtl::is<ast::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        ({
        auto&& _m = p_.kind;
        prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PreBindName(wx, benv, menv, n, HowBound(HowBound::AsLet{}))));
    })
        : prism_rtl::finished(std::tuple{wx, benv, menv});
    });
    })
        : prism_rtl::is<ast::StmtKind::SFn>(_m) ? ({
        auto&& c = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
        ({
        auto fname = check_env::def_name_text(c.name);
        (prism_rtl::finished(std::tuple{wx, bind(benv, fname, Bn(Bn::BnLocalFn{c})), bind(menv, fname, Bn(Bn::BnLocalFn{c}))}));
    });
    })
        : prism_rtl::finished(std::tuple{wx, benv, menv});
    });
}


/// `Start PreBind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Env, Env>> start_pre_bind(Wx wx, Env benv, Env menv, ast::Stmt s) {
    return std::make_shared<PreBind>(wx, benv, menv, s);
}


/// HowBound: fn ?Expr -> HowBound
HowBound how_bound(const std::optional<ast::Expr>& opt0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<HowBound> _v;
        if (prism_rtl::is_some(opt0)) {
            _v.set(HowBound(HowBound::AsHold{}));
            goto _done;
        }
        if (prism_rtl::is_none(opt0)) {
            _v.set(HowBound(HowBound::AsBind{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// PreBindName: unbounded fn Wx, Env, Env, SName, HowBound -> ((Wx, Env, Env))
std::tuple<Wx, Env, Env> pre_bind_name(const Wx& wx, const Env& benv, const Env& menv, const ast::SName& n, const HowBound& how) {
    auto lx = widget_let_lx(wx.lx, n.span);
    auto nkey = check_env::sname_key(n);
    auto full = binder_ty(lx, n.span);
    auto layer = layer_of(full);
    auto t = out_ty_of(lx, peel(full));
    auto [rs, wx1] = fresh_name(wx, snake(nkey));
    return (layer == Layer(Layer::LyEv{})) || is_switched(full)
        ? ({
        auto et = out_ty_of(lx, peel(peel(full)));
        auto [id, wx2] = add_gn(wx1, rs, et, GnKind(GnKind::GnNamed{}), Nat(0u));
        auto b = Bn(Bn::BnEv{ev_ref_of(wx2, id), t});
        auto pf = prism_rtl::cat(rs, "_v_port");
        auto pt = OutTy(OutTy::OutRc{prism_rtl::rc(OutTy(OutTy::OutPort{prism_rtl::rc(et)}))});
        auto wx3 = ({
            Wx this_ = connect(wx2, ev_ref_of(wx2, id), Sk(Sk::SkPort{prism_rtl::cat(rs, "_v")}));
            this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{pf})), pt}), Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{Ex(Ex::XCall{Text("Port::new"), Array<Ex>{}})})})}));
            this_.fields = prelude::push(this_.fields, std::tuple{pf, pt, prism_rtl::cat("`", nkey, "` as a value: the port it fires")});
            this_.moves = prelude::push(this_.moves, std::tuple{pf, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{pf}))})});
            this_;
        });
        auto be = bind(bind(benv, nkey, b), prism_rtl::cat(nkey, "#port"), Bn(Bn::BnLocal{Ex(Ex::XVar{pf}), Holding(Holding::Owned{}), pt}));
        auto me = bind(bind(menv, nkey, b), prism_rtl::cat(nkey, "#port"), Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), pf}), Holding(Holding::Owned{}), pt}));
        std::tuple{wx3, be, me};
    })
        : ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wx, Env, Env>> _v;
        auto&& _m = std::tuple{layer, how};
        if (prism_rtl::is<Layer::LyDyn>(std::get<0>(_m)) && prism_rtl::is<HowBound::AsLet>(std::get<1>(_m))) {
            _v.set(({
                auto b = Bn(Bn::BnDyn{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), rs, Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{rs})}), t});
                std::tuple{wx1, bind(benv, nkey, b), bind(menv, nkey, b)};
            }));
            goto _done;
        }
        if (prism_rtl::is<Layer::LyDyn>(std::get<0>(_m))) {
            _v.set(({
                auto b = Bn(Bn::BnHold{rs, t});
                std::tuple{wx1, bind(benv, nkey, b), bind(menv, nkey, b)};
            }));
            goto _done;
        }
        {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Wx, Env, Env>> _v;
                auto&& _m = many_instances(wx.lx, n.span);
                if (prism_rtl::is_some(_m)) {
                    auto&& insts = prism_rtl::some_of(_m);
                    _v.set(run_to_end(fold_job(check_errors::range0(len(insts)), std::tuple{wx1, benv, menv}, ({
                        auto insts_1 = insts;
                        auto wx_2 = wx;
                        auto n_3 = n;
                        auto rs_4 = rs;
                        auto nkey_5 = nkey;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Env>>(std::tuple<std::tuple<Wx, Env, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Env>, Nat> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto insts_1_6 = insts_1;
                            auto wx_2_6 = wx_2;
                            auto n_3_6 = n_3;
                            auto rs_4_6 = rs_4;
                            auto nkey_5_6 = nkey_5;
                            entered(once_job([=]() {
                            return ({
                                auto [w, be, me] = p0;
                                auto k = p1;
                                ({
                                auto inst = or_(index(insts_1_6, k), std::tuple{Array<std::tuple<Text, check_types::Ty>>{}, Array<std::tuple<Text, check_types::Col>>{}});
                                auto lxk = at_instance(wx_2_6.lx, inst);
                                call_then(start_out_ty_of(lxk, peel(binder_ty(lxk, n_3_6.span))), [=](OutTy out_ty_of_199809) {
                                return ({
                                    auto tk = out_ty_of_199809;
                                    auto [rk, w2] = k == Nat(0u)
                                        ? std::tuple{rs_4_6, w}
                                        : fresh_name(w, prism_rtl::cat(rs_4_6, "_", k));
                                    auto bkey = k == Nat(0u) ? nkey_5_6 : prism_rtl::cat(nkey_5_6, "#inst", k);
                                    auto [be2, me2] = bind_plain(be, me, bkey, rk, tk);
                                    auto ukey = prism_rtl::cat(nkey_5_6, "#", show_text(inst));
                                    (prism_rtl::finished(std::tuple{w2, with_use(be2, ukey, bkey), with_use(me2, ukey, bkey)}));
                                });
                            });
                            });
                            });
                        }));
                        });
                    }));
                    }))));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto [be, me] = bind_plain(benv, menv, nkey, rs, t);
                        std::tuple{wx1, be, me};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Wx, Env, Env>> PreBindName::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& n = this->n;
    const auto& how = this->how;
    auto benv_1 = benv;
    auto how_2 = how;
    auto menv_3 = menv;
    auto n_4 = n;
    auto wx_5 = wx;
    return call_then(start_widget_let_lx(wx_5.lx, n_4.span), [=](Lx widget_let_lx_197794) {
        return ({
            auto lx = widget_let_lx_197794;
            auto nkey = check_env::sname_key(n_4);
            auto full = binder_ty(lx, n_4.span);
            auto layer = layer_of(full);
            call_then(start_out_ty_of(lx, peel(full)), [=](OutTy out_ty_of_197922) {
            return ({
                auto t = out_ty_of_197922;
                auto [rs, wx1] = fresh_name(wx_5, snake(nkey));
                (layer == Layer(Layer::LyEv{})) || is_switched(full)
                ? call_then(start_out_ty_of(lx, peel(peel(full))), [=](OutTy out_ty_of_198053) {
                return ({
                    auto et = out_ty_of_198053;
                    auto [id, wx2] = add_gn(wx1, rs, et, GnKind(GnKind::GnNamed{}), Nat(0u));
                    auto b = Bn(Bn::BnEv{ev_ref_of(wx2, id), t});
                    auto pf = prism_rtl::cat(rs, "_v_port");
                    auto pt = OutTy(OutTy::OutRc{prism_rtl::rc(OutTy(OutTy::OutPort{prism_rtl::rc(et)}))});
                    auto wx3 = ({
                        Wx this_ = connect(wx2, ev_ref_of(wx2, id), Sk(Sk::SkPort{prism_rtl::cat(rs, "_v")}));
                        this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{pf})), pt}), Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{Ex(Ex::XCall{Text("Port::new"), Array<Ex>{}})})})}));
                        this_.fields = prelude::push(this_.fields, std::tuple{pf, pt, prism_rtl::cat("`", nkey, "` as a value: the port it fires")});
                        this_.moves = prelude::push(this_.moves, std::tuple{pf, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{pf}))})});
                        this_;
                    });
                    auto be = bind(bind(benv_1, nkey, b), prism_rtl::cat(nkey, "#port"), Bn(Bn::BnLocal{Ex(Ex::XVar{pf}), Holding(Holding::Owned{}), pt}));
                    auto me = bind(bind(menv_3, nkey, b), prism_rtl::cat(nkey, "#port"), Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), pf}), Holding(Holding::Owned{}), pt}));
                    (prism_rtl::finished(std::tuple{wx3, be, me}));
                });
            })
                : ({
                auto&& _m = std::tuple{layer, how_2};
                prism_rtl::is<Layer::LyDyn>(std::get<0>(_m)) && prism_rtl::is<HowBound::AsLet>(std::get<1>(_m)) ? ({
                auto b = Bn(Bn::BnDyn{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), rs, Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{rs})}), t});
                (prism_rtl::finished(std::tuple{wx1, bind(benv_1, nkey, b), bind(menv_3, nkey, b)}));
            })
                : prism_rtl::is<Layer::LyDyn>(std::get<0>(_m)) ? ({
                auto b = Bn(Bn::BnHold{rs, t});
                (prism_rtl::finished(std::tuple{wx1, bind(benv_1, nkey, b), bind(menv_3, nkey, b)}));
            })
                : call_then(start_many_instances(wx_5.lx, n_4.span), [=](std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>> many_instances_199341) {
                return ({
                    prism_rtl::is_some(many_instances_199341) ? ({
                    auto&& insts = prism_rtl::some_of(many_instances_199341);
                    fold_job(check_errors::range0(len(insts)), std::tuple{wx1, benv_1, menv_3}, ({
                    auto insts_6 = insts;
                    auto wx_5_7 = wx_5;
                    auto n_4_7 = n_4;
                    auto rs_7 = rs;
                    auto nkey_8 = nkey;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Env>>(std::tuple<std::tuple<Wx, Env, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Env>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto insts_6_9 = insts_6;
                        auto wx_5_7_9 = wx_5_7;
                        auto n_4_7_9 = n_4_7;
                        auto rs_7_9 = rs_7;
                        auto nkey_8_9 = nkey_8;
                        entered(once_job([=]() {
                        return ({
                            auto [w, be, me] = p0;
                            auto k = p1;
                            ({
                            auto inst = or_(index(insts_6_9, k), std::tuple{Array<std::tuple<Text, check_types::Ty>>{}, Array<std::tuple<Text, check_types::Col>>{}});
                            auto lxk = at_instance(wx_5_7_9.lx, inst);
                            call_then(start_out_ty_of(lxk, peel(binder_ty(lxk, n_4_7_9.span))), [=](OutTy out_ty_of_199809) {
                            return ({
                                auto tk = out_ty_of_199809;
                                auto [rk, w2] = k == Nat(0u)
                                    ? std::tuple{rs_7_9, w}
                                    : fresh_name(w, prism_rtl::cat(rs_7_9, "_", k));
                                auto bkey = k == Nat(0u) ? nkey_8_9 : prism_rtl::cat(nkey_8_9, "#inst", k);
                                auto [be2, me2] = bind_plain(be, me, bkey, rk, tk);
                                auto ukey = prism_rtl::cat(nkey_8_9, "#", show_text(inst));
                                (prism_rtl::finished(std::tuple{w2, with_use(be2, ukey, bkey), with_use(me2, ukey, bkey)}));
                            });
                        });
                        });
                        });
                    }));
                    });
                }));
                }))->cycle();
                })
                    : prism_rtl::is_none(many_instances_199341) ? ({
                    auto [be, me] = bind_plain(benv_1, menv_3, nkey, rs, t);
                    (prism_rtl::finished(std::tuple{wx1, be, me}));
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            });
        });
        });
    });
}


/// `Start PreBindName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Env, Env>> start_pre_bind_name(Wx wx, Env benv, Env menv, ast::SName n, HowBound how) {
    return std::make_shared<PreBindName>(wx, benv, menv, n, how);
}


/// WithUse: fn Env, Text, Text -> Env
Env with_use(const Env& env, const Text& ukey, const Text& bkey) {
    Env this_ = env;
    this_.uses = insert(this_.uses, ukey, bkey);
    return this_;
}


/// ?ManyInstances: unbounded fn Lx, Range -> ?[(([((Text, Ty))], [((Text, Col))]))]
std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>> many_instances(const Lx& lx, const ast::Range& span) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>> _v;
        auto&& _m = prelude::get(lx.gens, place_key(lx, span));
        if (prism_rtl::is_some(_m)) {
            auto&& gn = prism_rtl::some_of(_m);
            _v.set(({
                auto insts = instantiations(lx, gn);
                len(insts) > Nat(1u)
                ? std::optional(insts)
                : std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>{};
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>> ManyInstances::cycle() const {
    const auto& lx = this->lx;
    const auto& span = this->span;
    return ({
        auto&& _m = prelude::get(lx.gens, place_key(lx, span));
        prism_rtl::is_some(_m) ? ({
        auto&& gn = prism_rtl::some_of(_m);
        ({
        auto lx_1 = lx;
        call_then(start_instantiations(lx_1, gn), [=](Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>> instantiations_200686) {
        return ({
            auto insts = instantiations_200686;
            len(insts) > Nat(1u)
            ? prism_rtl::finished(std::optional(insts))
            : prism_rtl::finished(std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>{});
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ManyInstances, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>> start_many_instances(Lx lx, ast::Range span) {
    return std::make_shared<ManyInstances>(lx, span);
}


/// IsSwitched: fn Ty -> Bool
bool is_switched(const check_types::Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<check_types::Ty::TySig>(t)) {
            auto&& m201003_0_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
            auto&& m201003_0_1 = prism_rtl::as<check_types::Ty::TySig>(t).a1;
            if (m201003_0_0 == Text("$")) {
                if (prism_rtl::is<check_types::Ty::TySig>(m201003_0_1)) {
                    auto&& m201003_0_1_r_0 = prism_rtl::as<check_types::Ty::TySig>(m201003_0_1).a0;
                    if (m201003_0_1_r_0 == Text("!")) {
                        _v.set(true);
                        goto _done;
                    }
                }
            }
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ?BindingOf: fn Env, Pattern -> ?Bn
std::optional<Bn> binding_of(const Env& env, const ast::Pattern_& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Bn>> _v;
        auto&& _m = p_.kind;
        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
            _v.set(prelude::get(env->names, check_env::sname_key(n)));
            goto _done;
        }
        if (prism_rtl::is<ast::PatternKind::PTuple>(_m)) {
            auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(_m).a0;
            _v.set(std::optional(Bn(Bn::BnParts{each(ps, [&](const ast::Pattern_& q) { return binding_of_name(env, q); })})));
            goto _done;
        }
        {
            _v.set(std::optional<Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ?BindingOfName: fn Env, Pattern -> ?Bn
std::optional<Bn> binding_of_name(const Env& env, const ast::Pattern_& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Bn>> _v;
        auto&& _m = p_.kind;
        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
            _v.set(prelude::get(env->names, check_env::sname_key(n)));
            goto _done;
        }
        {
            _v.set(std::optional<Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// WidgetStmt: unbounded fn Wx, Env, Env, Stmt, Bool -> ((Wx, Env, Env))
std::tuple<Wx, Env, Env> widget_stmt(const Wx& wx, const Env& benv, const Env& menv, const ast::Stmt& s, const bool& last) {
    auto lx = wx.lx;
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wx, Env, Env>> _v;
        auto&& _m = s.kind;
        if (prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<ast::StmtKind::SBind>(_m).a2)) {
            auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
            auto&& e = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
            _v.set(({
                auto [wx2, res] = build_line(wx, benv, menv, e, binding_of(menv, p_));
                auto wx3 = bind_res(wx2, menv, p_, res);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Wx, Env, Env>> _v;
                auto&& _m = std::tuple{res, p_.kind};
                if (prism_rtl::is<Wres::WrDyn>(std::get<0>(_m)) && prism_rtl::is<ast::PatternKind::PName>(std::get<1>(_m))) {
                    auto&& ex = prism_rtl::as<Wres::WrDyn>(std::get<0>(_m)).a0;
                    auto&& rds = prism_rtl::as<Wres::WrDyn>(std::get<0>(_m)).a1;
                    auto&& t = prism_rtl::as<Wres::WrDyn>(std::get<0>(_m)).a2;
                    auto&& n = prism_rtl::as<ast::PatternKind::PName>(std::get<1>(_m)).a0;
                    _v.set(({
                        auto b = Bn(Bn::BnDyn{ex, rds, t});
                        std::tuple{wx3, bind(benv, check_env::sname_key(n), b), bind(menv, check_env::sname_key(n), b)};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<Wres::WrHosted>(std::get<0>(_m)) && prism_rtl::is<ast::PatternKind::PTuple>(std::get<1>(_m))) {
                    auto&& inner = prism_rtl::as<Wres::WrHosted>(std::get<0>(_m)).a0;
                    auto&& doc = prism_rtl::as<Wres::WrHosted>(std::get<0>(_m)).a1;
                    auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(std::get<1>(_m)).a0;
                    _v.set(bind_hosted(wx3, benv, menv, inner, doc, ps));
                    goto _done;
                }
                {
                    _v.set(std::tuple{wx3, benv, menv});
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<ast::StmtKind::SBind>(_m).a2)) {
            auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
            auto&& init = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
            auto&& step_ = prism_rtl::some_of(prism_rtl::as<ast::StmtKind::SBind>(_m).a2);
            _v.set(({
                auto [wx2, be2] = hold_line(wx, benv, menv, p_, init, step_);
                std::tuple{wx2, be2, menv};
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SIgnore>(_m)) {
            auto&& e = prism_rtl::as<ast::StmtKind::SIgnore>(_m).a0;
            _v.set(({
                auto&& _wx2 = build_line(wx, benv, menv, e, std::optional<Bn>{});
                auto&& wx2 = std::get<0>(_wx2);
                std::tuple{wx2, benv, menv};
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
            auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
            auto&& e = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
            _v.set(({
                auto [wx2, be2] = let_line(wx, benv, menv, p_, e);
                std::tuple{wx2, be2, menv};
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
            auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Wx, Env, Env>> _v;
                auto&& _m = e.kind;
                if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
                    auto&& m202520_0_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
                    auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
                    if (m202520_0_0 == Text("@")) {
                        _v.set(({
                            auto [res, wx2] = result_of(wx, benv, menv, x);
                            auto wx3 = ({
                                Wx this_ = wx2;
                                this_.result = res;
                                this_;
                            });
                            std::tuple{wx3, benv, menv};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        auto [wx2, res] = build_line(wx, benv, menv, e, std::optional<Bn>{});
                        auto wx3 = last ? set_result(wx2, res) : wx2;
                        std::tuple{wx3, benv, menv};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SEmit>(_m)) {
            _v.set(std::tuple{wx, benv, menv});
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SSignature>(_m)) {
            _v.set(std::tuple{wx, benv, menv});
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SFn>(_m)) {
            auto&& c = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
            _v.set(std::tuple{wx, benv, menv});
            goto _done;
        }
        {
            _v.set(({
                auto wx2 = ({
                    Wx this_ = wx;
                    this_.build = prelude::push(this_.build, refusal_do(Text("a statement this back end does not lower yet")));
                    this_;
                });
                std::tuple{wx2, benv, menv};
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Wx, Env, Env>> WidgetStmt::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& s = this->s;
    const auto& last = this->last;
    auto lx = wx.lx;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<ast::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
        ({
        auto benv_1 = benv;
        auto e_2 = e;
        auto menv_3 = menv;
        auto p__4 = p_;
        auto wx_5 = wx;
        call_then(start_build_line(wx_5, benv_1, menv_3, e_2, binding_of(menv_3, p__4)), [=](std::tuple<Wx, Wres> build_line_201674) {
        return ({
            auto [wx2, res] = build_line_201674;
            auto wx3 = bind_res(wx2, menv_3, p__4, res);
            ({
            auto&& _m = std::tuple{res, p__4.kind};
            prism_rtl::is<Wres::WrDyn>(std::get<0>(_m)) && prism_rtl::is<ast::PatternKind::PName>(std::get<1>(_m)) ? ({
            auto&& ex = prism_rtl::as<Wres::WrDyn>(std::get<0>(_m)).a0;
            auto&& rds = prism_rtl::as<Wres::WrDyn>(std::get<0>(_m)).a1;
            auto&& t = prism_rtl::as<Wres::WrDyn>(std::get<0>(_m)).a2;
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(std::get<1>(_m)).a0;
            ({
            auto b = Bn(Bn::BnDyn{ex, rds, t});
            (prism_rtl::finished(std::tuple{wx3, bind(benv_1, check_env::sname_key(n), b), bind(menv_3, check_env::sname_key(n), b)}));
        });
        })
            : prism_rtl::is<Wres::WrHosted>(std::get<0>(_m)) && prism_rtl::is<ast::PatternKind::PTuple>(std::get<1>(_m)) ? ({
            auto&& inner = prism_rtl::as<Wres::WrHosted>(std::get<0>(_m)).a0;
            auto&& doc = prism_rtl::as<Wres::WrHosted>(std::get<0>(_m)).a1;
            auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(std::get<1>(_m)).a0;
            prism_rtl::finished(bind_hosted(wx3, benv_1, menv_3, inner, doc, ps));
        })
            : prism_rtl::finished(std::tuple{wx3, benv_1, menv_3});
        });
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<ast::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        auto&& init = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
        auto&& step_ = prism_rtl::some_of(prism_rtl::as<ast::StmtKind::SBind>(_m).a2);
        ({
        auto benv_1 = benv;
        auto init_2 = init;
        auto menv_3 = menv;
        auto p__4 = p_;
        auto step__5 = step_;
        auto wx_6 = wx;
        call_then(start_hold_line(wx_6, benv_1, menv_3, p__4, init_2, step__5), [=](std::tuple<Wx, Env> hold_line_202197) {
        return ({
            auto [wx2, be2] = hold_line_202197;
            (prism_rtl::finished(std::tuple{wx2, be2, menv_3}));
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SIgnore>(_m) ? ({
        auto&& e = prism_rtl::as<ast::StmtKind::SIgnore>(_m).a0;
        ({
        auto benv_1 = benv;
        auto e_2 = e;
        auto menv_3 = menv;
        auto wx_4 = wx;
        call_then(start_build_line(wx_4, benv_1, menv_3, e_2, std::optional<Bn>{}), [=](std::tuple<Wx, Wres> build_line_202320) {
        return ({
            auto&& _wx2 = build_line_202320;
            auto&& wx2 = std::get<0>(_wx2);
            (prism_rtl::finished(std::tuple{wx2, benv_1, menv_3}));
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
        ({
        auto benv_1 = benv;
        auto e_2 = e;
        auto menv_3 = menv;
        auto p__4 = p_;
        auto wx_5 = wx;
        call_then(start_let_line(wx_5, benv_1, menv_3, p__4, e_2), [=](std::tuple<Wx, Env> let_line_202443) {
        return ({
            auto [wx2, be2] = let_line_202443;
            (prism_rtl::finished(std::tuple{wx2, be2, menv_3}));
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
        auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EFreeSigil>(_m) && ({
        auto&& m202520_0_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
        (m202520_0_0 == Text("@"));
    }) ? ({
        auto&& m202520_0_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
        ({
        auto benv_1 = benv;
        auto menv_2 = menv;
        auto wx_3 = wx;
        auto x_4 = x;
        call_then(start_result_of(wx_3, benv_1, menv_2, x_4), [=](std::tuple<Wres, Wx> result_of_202600) {
        return ({
            auto [res, wx2] = result_of_202600;
            auto wx3 = ({
                Wx this_ = wx2;
                this_.result = res;
                this_;
            });
            (prism_rtl::finished(std::tuple{wx3, benv_1, menv_2}));
        });
    });
    });
    })
        : ({
        auto benv_1 = benv;
        auto e_2 = e;
        auto last_3 = last;
        auto menv_4 = menv;
        auto wx_5 = wx;
        call_then(start_build_line(wx_5, benv_1, menv_4, e_2, std::optional<Bn>{}), [=](std::tuple<Wx, Wres> build_line_202796) {
        return ({
            auto [wx2, res] = build_line_202796;
            auto wx3 = last_3 ? set_result(wx2, res) : wx2;
            (prism_rtl::finished(std::tuple{wx3, benv_1, menv_4}));
        });
    });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SEmit>(_m) ? prism_rtl::finished(std::tuple{wx, benv, menv})
        : prism_rtl::is<ast::StmtKind::SSignature>(_m) ? prism_rtl::finished(std::tuple{wx, benv, menv})
        : prism_rtl::is<ast::StmtKind::SFn>(_m) ? ({
        auto&& c = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
        prism_rtl::finished(std::tuple{wx, benv, menv});
    })
        : ({
        auto wx2 = ({
            Wx this_ = wx;
            this_.build = prelude::push(this_.build, refusal_do(Text("a statement this back end does not lower yet")));
            this_;
        });
        (prism_rtl::finished(std::tuple{wx2, benv, menv}));
    });
    });
}


/// `Start WidgetStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Env, Env>> start_widget_stmt(Wx wx, Env benv, Env menv, ast::Stmt s, bool last) {
    return std::make_shared<WidgetStmt>(wx, benv, menv, s, last);
}


/// BindHosted: fn Wx, Env, Env, Wres, Bn, [Pattern] -> ((Wx, Env, Env))
std::tuple<Wx, Env, Env> bind_hosted(const Wx& wx, const Env& benv, const Env& menv, const Wres& res, const Bn& doc, const Array<ast::Pattern_>& ps) {
    auto r_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Bn>> _v;
        if (prism_rtl::is<Wres::WrEv>(res)) {
            auto&& r = prism_rtl::as<Wres::WrEv>(res).a0;
            _v.set(std::optional(Bn(Bn::BnEv{r, OutTy(OutTy::OutUnit{})})));
            goto _done;
        }
        if (prism_rtl::is<Wres::WrDyn>(res)) {
            auto&& ex = prism_rtl::as<Wres::WrDyn>(res).a0;
            auto&& rds = prism_rtl::as<Wres::WrDyn>(res).a1;
            auto&& t = prism_rtl::as<Wres::WrDyn>(res).a2;
            _v.set(std::optional(Bn(Bn::BnDyn{ex, rds, t})));
            goto _done;
        }
        {
            _v.set(std::optional<Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [be1, me1] = bind_part(benv, menv, index(ps, Nat(0u)), r_opt);
    return bind_part2(wx, be1, me1, index(ps, Nat(1u)), std::optional(doc));
}


/// BindPart: fn Env, Env, ?Pattern, ?Bn -> ((Env, Env))
std::tuple<Env, Env> bind_part(const Env& benv, const Env& menv, const std::optional<ast::Pattern_>& p__opt, const std::optional<Bn>& b_opt) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Env, Env>> _v;
        auto&& _m = std::tuple{p__opt, b_opt};
        if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
            auto&& p_ = prism_rtl::some_of(std::get<0>(_m));
            auto&& b = prism_rtl::some_of(std::get<1>(_m));
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Env, Env>> _v;
                auto&& _m = p_.kind;
                if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                    auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                    _v.set(std::tuple{bind(benv, check_env::sname_key(n), b), bind(menv, check_env::sname_key(n), b)});
                    goto _done;
                }
                {
                    _v.set(std::tuple{benv, menv});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{benv, menv});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// BindPart2: fn Wx, Env, Env, ?Pattern, ?Bn -> ((Wx, Env, Env))
std::tuple<Wx, Env, Env> bind_part2(const Wx& wx, const Env& benv, const Env& menv, const std::optional<ast::Pattern_>& p__opt, const std::optional<Bn>& b_opt) {
    auto [be, me] = bind_part(benv, menv, p__opt, b_opt);
    return std::tuple{wx, be, me};
}


/// SetResult: fn Wx, Wres -> Wx
Wx set_result(const Wx& wx, const Wres& res) {
    Wx this_ = wx;
    this_.result = res;
    return this_;
}


/// ResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
std::tuple<Wres, Wx> result_of(const Wx& wx, const Env& benv, const Env& menv, const ast::Expr& x) {
    auto lx = wx.lx;
    auto full = type_at(lx, x.span);
    auto t = out_ty_of(lx, peel(full));
    auto bound_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Bn>> _v;
        auto&& _m = x.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(len(n->path_) == Nat(1u)
                ? prelude::get(menv->names, check_env::sname_key(n))
                : std::optional<Bn>{});
            goto _done;
        }
        {
            _v.set(std::optional<Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wres, Wx>> _v;
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
            auto&& r = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
            _v.set(std::tuple{Wres(Wres::WrEv{r}), wx});
            goto _done;
        }
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnDyn>(prism_rtl::some_of(bound_opt))) {
            auto&& ex = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a0;
            auto&& rds = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a1;
            auto&& bt = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a2;
            _v.set(std::tuple{Wres(Wres::WrDyn{ex, rds, bt}), wx});
            goto _done;
        }
        {
            _v.set(result_of_typed(wx, benv, menv, x, full, t));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Wres, Wx>> ResultOf::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& x = this->x;
    auto lx = wx.lx;
    auto full = type_at(lx, x.span);
    auto benv_1 = benv;
    auto menv_2 = menv;
    auto wx_3 = wx;
    auto x_4 = x;
    return call_then(start_out_ty_of(lx, peel(full)), [=](OutTy out_ty_of_204708) {
        return ({
            auto t = out_ty_of_204708;
            auto bound_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<Bn>> _v;
                auto&& _m = x_4.kind;
                if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                    auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                    _v.set(len(n->path_) == Nat(1u)
                        ? prelude::get(menv_2->names, check_env::sname_key(n))
                        : std::optional<Bn>{});
                    goto _done;
                }
                {
                    _v.set(std::optional<Bn>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            ({
            prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(bound_opt)) ? ({
            auto&& r = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
            prism_rtl::finished(std::tuple{Wres(Wres::WrEv{r}), wx_3});
        })
            : prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnDyn>(prism_rtl::some_of(bound_opt)) ? ({
            auto&& ex = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a0;
            auto&& rds = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a1;
            auto&& bt = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a2;
            prism_rtl::finished(std::tuple{Wres(Wres::WrDyn{ex, rds, bt}), wx_3});
        })
            : prism_rtl::more(prism_rtl::rc(ResultOfTyped(wx_3, benv_1, menv_2, x_4, full, t)));
        });
        });
    });
}


/// `Start ResultOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wres, Wx>> start_result_of(Wx wx, Env benv, Env menv, ast::Expr x) {
    return std::make_shared<ResultOf>(wx, benv, menv, x);
}


/// ResultOfTyped: unbounded fn Wx, Env, Env, Expr, Ty, OutTy -> ((Wres, Wx))
std::tuple<Wres, Wx> result_of_typed(const Wx& wx, const Env& benv, const Env& menv, const ast::Expr& x, const check_types::Ty& full, const OutTy& t) {
    auto lx = wx.lx;
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wres, Wx>> _v;
        auto&& _m = layer_of(full);
        if (prism_rtl::is<Layer::LyEv>(_m)) {
            _v.set(({
                auto [r, wx2] = event_ref(wx, menv, x);
                std::tuple{Wres(Wres::WrEv{r}), wx2};
            }));
            goto _done;
        }
        if (prism_rtl::is<Layer::LyDyn>(_m)) {
            _v.set(({
                auto [ex, reads] = dynamic_expr(wx, menv, x);
                std::tuple{Wres(Wres::WrDyn{ex, reads, t}), wx};
            }));
            goto _done;
        }
        {
            _v.set(t == OutTy(OutTy::OutUnit{})
                ? std::tuple{Wres(Wres::WrUnit{}), wx}
                : std::tuple{Wres(Wres::WrPlain{own(value_of(lx, benv, x)), t}), wx});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Wres, Wx>> ResultOfTyped::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& x = this->x;
    const auto& full = this->full;
    const auto& t = this->t;
    auto lx = wx.lx;
    return ({
        auto&& _m = layer_of(full);
        prism_rtl::is<Layer::LyEv>(_m) ? ({
        auto menv_1 = menv;
        auto wx_2 = wx;
        auto x_3 = x;
        call_then(start_event_ref(wx_2, menv_1, x_3), [=](std::tuple<EvRef, Wx> event_ref_205244) {
        return ({
            auto [r, wx2] = event_ref_205244;
            (prism_rtl::finished(std::tuple{Wres(Wres::WrEv{r}), wx2}));
        });
    });
    })
        : prism_rtl::is<Layer::LyDyn>(_m) ? ({
        auto menv_1 = menv;
        auto t_2 = t;
        auto wx_3 = wx;
        auto x_4 = x;
        call_then(start_dynamic_expr(wx_3, menv_1, x_4), [=](std::tuple<Ex, Array<Read>> dynamic_expr_205340) {
        return ({
            auto [ex, reads] = dynamic_expr_205340;
            (prism_rtl::finished(std::tuple{Wres(Wres::WrDyn{ex, reads, t_2}), wx_3}));
        });
    });
    })
        : t == OutTy(OutTy::OutUnit{})
        ? prism_rtl::finished(std::tuple{Wres(Wres::WrUnit{}), wx})
        : ({
        auto benv_1 = benv;
        auto t_2 = t;
        auto wx_3 = wx;
        auto x_4 = x;
        call_then(start_value_of(lx, benv_1, x_4), [=](Vl value_of_205503) { return prism_rtl::finished(std::tuple{Wres(Wres::WrPlain{own(value_of_205503), t_2}), wx_3}); });
    });
    });
}


/// `Start ResultOfTyped, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wres, Wx>> start_result_of_typed(Wx wx, Env benv, Env menv, ast::Expr x, check_types::Ty full, OutTy t) {
    return std::make_shared<ResultOfTyped>(wx, benv, menv, x, full, t);
}


/// HoldLine: unbounded fn Wx, Env, Env, Pattern, Expr, Expr -> ((Wx, Env))
std::tuple<Wx, Env> hold_line(const Wx& wx, const Env& benv, const Env& menv, const ast::Pattern_& p_, const ast::Expr& init, const ast::Expr& step_) {
    auto lx = wx.lx;
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wx, Env>> _v;
        auto&& _m = binding_of(menv, p_);
        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnHold>(prism_rtl::some_of(_m))) {
            auto&& f = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(_m)).a0;
            auto&& t = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(_m)).a1;
            _v.set(({
                auto iv = own(value_of(lx, benv, init));
                auto wx1 = add_field(wx, f, OutTy(OutTy::OutHold{prism_rtl::rc(t)}), prism_rtl::cat("`", pat_text(p_), "`"), Ex(Ex::XCall{Text("Hold::new"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{prism_rtl::cat(f, "_init")}))}), Ex(Ex::XCx{})})}));
                auto [r, wx2] = event_ref(wx1, menv, step_);
                auto wx3 = ({
                    Wx this_ = connect(wx2, r, Sk(Sk::SkHold{f}));
                    this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{prism_rtl::cat(f, "_init")})), t}), iv}));
                    this_.inited = prelude::push(this_.inited, f);
                    this_;
                });
                std::tuple{wx3, bind(benv, prism_rtl::cat(pat_text(p_), "#init"), Bn(Bn::BnLocal{Ex(Ex::XVar{prism_rtl::cat(f, "_init")}), Holding(Holding::Owned{}), t}))};
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{wx, benv});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Wx, Env>> HoldLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& p_ = this->p_;
    const auto& init = this->init;
    const auto& step_ = this->step_;
    auto lx = wx.lx;
    return ({
        auto&& _m = binding_of(menv, p_);
        prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnHold>(prism_rtl::some_of(_m)) ? ({
        auto&& f = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(_m)).a0;
        auto&& t = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(_m)).a1;
        ({
        auto benv_1 = benv;
        auto init_2 = init;
        auto menv_3 = menv;
        auto p__4 = p_;
        auto step__5 = step_;
        auto wx_6 = wx;
        call_then(start_value_of(lx, benv_1, init_2), [=](Vl value_of_206058) {
        return ({
            auto iv = own(value_of_206058);
            auto wx1 = add_field(wx_6, f, OutTy(OutTy::OutHold{prism_rtl::rc(t)}), prism_rtl::cat("`", pat_text(p__4), "`"), Ex(Ex::XCall{Text("Hold::new"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{prism_rtl::cat(f, "_init")}))}), Ex(Ex::XCx{})})}));
            call_then(start_event_ref(wx1, menv_3, step__5), [=](std::tuple<EvRef, Wx> event_ref_206236) {
            return ({
                auto [r, wx2] = event_ref_206236;
                auto wx3 = ({
                    Wx this_ = connect(wx2, r, Sk(Sk::SkHold{f}));
                    this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{prism_rtl::cat(f, "_init")})), t}), iv}));
                    this_.inited = prelude::push(this_.inited, f);
                    this_;
                });
                (prism_rtl::finished(std::tuple{wx3, bind(benv_1, prism_rtl::cat(pat_text(p__4), "#init"), Bn(Bn::BnLocal{Ex(Ex::XVar{prism_rtl::cat(f, "_init")}), Holding(Holding::Owned{}), t}))}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{wx, benv});
    });
}


/// `Start HoldLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Env>> start_hold_line(Wx wx, Env benv, Env menv, ast::Pattern_ p_, ast::Expr init, ast::Expr step_) {
    return std::make_shared<HoldLine>(wx, benv, menv, p_, init, step_);
}


/// InitEnv: fn Env -> Env
Env init_env(const Env& env) {
    return fold(keys(env->names), env, [&](const Env& en, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Env> _v;
            auto&& _m = std::tuple{lexer::before_suffix(k, Text("#init")), prelude::get(env->names, k)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& name = prism_rtl::some_of(std::get<0>(_m));
                auto&& b = prism_rtl::some_of(std::get<1>(_m));
                _v.set(bind(en, name, b));
                goto _done;
            }
            {
                _v.set(en);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// AllInited: fn Wx, [Read] -> Bool
bool all_inited(const Wx& wx, const Array<Read>& reads) {
    return fold(reads_closed(wx.dyn_reads, reads), true, [&](const bool& ok, const Read& r) {
        return ok && ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is<Read::OwnRead>(r)) {
                auto&& f = prism_rtl::as<Read::OwnRead>(r).a0;
                _v.set(check_types::has_text(wx.inited, f));
                goto _done;
            }
            if (prism_rtl::is<Read::ParentRead>(r)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// PatText: fn Pattern -> Text
Text pat_text(const ast::Pattern_& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = p_.kind;
        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
            _v.set(check_env::sname_key(n));
            goto _done;
        }
        {
            _v.set(Text("_"));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// LetLine: unbounded fn Wx, Env, Env, Pattern, Expr -> ((Wx, Env))
std::tuple<Wx, Env> let_line(const Wx& wx, const Env& benv, const Env& menv, const ast::Pattern_& p_, const ast::Expr& e) {
    auto lx = wx.lx;
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wx, Env>> _v;
        auto&& _m = binding_of(menv, p_);
        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(_m))) {
            auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(_m)).a0;
            auto&& t = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(_m)).a1;
            _v.set(({
                auto [r, wx2] = event_ref(wx, menv, e);
                auto fed = out_ty_of(lx, peel(peel(type_at(lx, e.span))));
                auto r2 = ({
                    __label__ _done;
                    prism_rtl::Slot<EvRef> _v;
                    if (prism_rtl::is<OutTy::OutEvent>(t)) {
                        auto&& m208028_0_0 = prism_rtl::as<OutTy::OutEvent>(t).a0;
                        if (prism_rtl::is<OutTy::OutRes>(m208028_0_0)) {
                            _v.set(fed == OutTy(OutTy::OutError{}) ? err_pipe(r) : r);
                            goto _done;
                        }
                    }
                    if (prism_rtl::is<OutTy::OutRes>(t)) {
                        _v.set(fed == OutTy(OutTy::OutError{}) ? err_pipe(r) : r);
                        goto _done;
                    }
                    {
                        _v.set(r);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                std::tuple{connect(wx2, r2, Sk(Sk::SkNode{er.node_})), benv};
            }));
            goto _done;
        }
        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnDyn>(prism_rtl::some_of(_m))) {
            auto&& t = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
            _v.set(({
                auto rs = snake(pat_text(p_));
                auto [ex, reads] = dynamic_expr(wx, menv, e);
                auto getter = MethDef{.name = rs, .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = t, .body = Array<Do>{}, .tail = ex, .doc = prism_rtl::cat("`", pat_text(p_), "`")};
                auto wx2 = ({
                    Wx this_ = wx;
                    this_.getters = prelude::push(this_.getters, getter);
                    this_.dyn_reads = insert(this_.dyn_reads, rs, reads);
                    this_;
                });
                all_inited(wx2, reads)
                ? ({
                auto wx3 = ({
                    Wx this_ = wx2;
                    this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{prism_rtl::cat(rs, "_init")})), t}), own(value_of(lx, init_env(benv), e))}));
                    this_.inited = prelude::push(this_.inited, rs);
                    this_;
                });
                std::tuple{wx3, bind(benv, prism_rtl::cat(pat_text(p_), "#init"), Bn(Bn::BnLocal{Ex(Ex::XVar{prism_rtl::cat(rs, "_init")}), Holding(Holding::Owned{}), t}))};
            })
                : std::tuple{wx2, benv};
            }));
            goto _done;
        }
        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
            auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            auto&& t = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
            _v.set(({
                auto insts_opt = ({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>> _v;
                    auto&& _m = p_.kind;
                    if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                        _v.set(many_instances(lx, n.span));
                        goto _done;
                    }
                    {
                        _v.set(std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Wx, Env>> _v;
                if (prism_rtl::is_some(insts_opt)) {
                    auto&& insts = prism_rtl::some_of(insts_opt);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Wx, Env>> _v;
                        auto&& _m = p_.kind;
                        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                            _v.set(({
                                auto nkey = check_env::sname_key(n);
                                auto wxn = run_to_end(fold_job(check_errors::range0(len(insts)), wx, ({
                                    auto lx_1 = lx;
                                    auto insts_2 = insts;
                                    auto nkey_3 = nkey;
                                    auto menv_4 = menv;
                                    auto benv_5 = benv;
                                    auto e_6 = e;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Wx>(std::tuple<Wx, Nat>)>>(prism_rtl::rc([=](std::tuple<Wx, Nat> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto lx_1_7 = lx_1;
                                        auto insts_2_7 = insts_2;
                                        auto nkey_3_7 = nkey_3;
                                        auto menv_4_7 = menv_4;
                                        auto benv_5_7 = benv_5;
                                        auto e_6_7 = e_6;
                                        entered(once_job([=]() {
                                        return ({
                                            auto w = p0;
                                            auto k = p1;
                                            ({
                                            auto lxk = at_instance(lx_1_7, or_(index(insts_2_7, k), std::tuple{Array<std::tuple<Text, check_types::Ty>>{}, Array<std::tuple<Text, check_types::Col>>{}}));
                                            auto bkey = k == Nat(0u) ? nkey_3_7 : prism_rtl::cat(nkey_3_7, "#inst", k);
                                            ({
                                            auto&& _m = prelude::get(menv_4_7->names, bkey);
                                            prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
                                            auto&& rk = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                                            auto&& tk = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                                            call_then(start_value_of(lxk, benv_5_7, e_6_7), [=](Vl value_of_209831) { return prism_rtl::finished(widget_let_field(w, place_stem(rk), tk, own(value_of_209831), prism_rtl::cat("`", nkey_3_7, "` at its instantiation ", k))); });
                                        })
                                            : prism_rtl::finished(({
                                            Wx this_ = w;
                                            this_.build = prelude::push(this_.build, refusal_do(prism_rtl::cat("`", nkey_3_7, "` at its instantiation ", k, ", which has no binding")));
                                            this_;
                                        }));
                                        });
                                        });
                                        });
                                    }));
                                    });
                                })));
                                })));
                                std::tuple{wxn, benv};
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{wx, benv});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(insts_opt)) {
                    _v.set(({
                        auto lxw = ({
                            __label__ _done;
                            prism_rtl::Slot<Lx> _v;
                            auto&& _m = p_.kind;
                            if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                                auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                                _v.set(widget_let_lx(lx, n.span));
                                goto _done;
                            }
                            {
                                _v.set(lx);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto v_ = own(value_of(lxw, benv, e));
                        std::tuple{widget_let_field(wx, place_stem(rs), t, v_, prism_rtl::cat("`", pat_text(p_), "`")), benv};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{wx, benv});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Wx, Env>> LetLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& p_ = this->p_;
    const auto& e = this->e;
    auto lx = wx.lx;
    return ({
        auto&& _m = binding_of(menv, p_);
        prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(_m)) ? ({
        auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(_m)).a0;
        auto&& t = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(_m)).a1;
        ({
        auto benv_1 = benv;
        auto e_2 = e;
        auto menv_3 = menv;
        auto wx_4 = wx;
        call_then(start_event_ref(wx_4, menv_3, e_2), [=](std::tuple<EvRef, Wx> event_ref_207918) {
        return ({
            auto [r, wx2] = event_ref_207918;
            call_then(start_out_ty_of(lx, peel(peel(type_at(lx, e_2.span)))), [=](OutTy out_ty_of_207961) {
            return ({
                auto fed = out_ty_of_207961;
                auto r2 = ({
                    __label__ _done;
                    prism_rtl::Slot<EvRef> _v;
                    if (prism_rtl::is<OutTy::OutEvent>(t)) {
                        auto&& m208028_0_0 = prism_rtl::as<OutTy::OutEvent>(t).a0;
                        if (prism_rtl::is<OutTy::OutRes>(m208028_0_0)) {
                            _v.set(fed == OutTy(OutTy::OutError{}) ? err_pipe(r) : r);
                            goto _done;
                        }
                    }
                    if (prism_rtl::is<OutTy::OutRes>(t)) {
                        _v.set(fed == OutTy(OutTy::OutError{}) ? err_pipe(r) : r);
                        goto _done;
                    }
                    {
                        _v.set(r);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                (prism_rtl::finished(std::tuple{connect(wx2, r2, Sk(Sk::SkNode{er.node_})), benv_1}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnDyn>(prism_rtl::some_of(_m)) ? ({
        auto&& t = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
        ({
        auto rs = snake(pat_text(p_));
        auto benv_1 = benv;
        auto e_2 = e;
        auto menv_3 = menv;
        auto p__4 = p_;
        auto wx_5 = wx;
        call_then(start_dynamic_expr(wx_5, menv_3, e_2), [=](std::tuple<Ex, Array<Read>> dynamic_expr_208381) {
        return ({
            auto [ex, reads] = dynamic_expr_208381;
            auto getter = MethDef{.name = rs, .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = t, .body = Array<Do>{}, .tail = ex, .doc = prism_rtl::cat("`", pat_text(p__4), "`")};
            auto wx2 = ({
                Wx this_ = wx_5;
                this_.getters = prelude::push(this_.getters, getter);
                this_.dyn_reads = insert(this_.dyn_reads, rs, reads);
                this_;
            });
            all_inited(wx2, reads)
            ? ({
            auto wx3 = ({
                Wx this_ = wx2;
                this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{prism_rtl::cat(rs, "_init")})), t}), own(value_of(lx, init_env(benv_1), e_2))}));
                this_.inited = prelude::push(this_.inited, rs);
                this_;
            });
            (prism_rtl::finished(std::tuple{wx3, bind(benv_1, prism_rtl::cat(pat_text(p__4), "#init"), Bn(Bn::BnLocal{Ex(Ex::XVar{prism_rtl::cat(rs, "_init")}), Holding(Holding::Owned{}), t}))}));
        })
            : prism_rtl::finished(std::tuple{wx2, benv_1});
        });
    });
    });
    })
        : prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
        auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
        auto&& t = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
        ({
        auto insts_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>> _v;
            auto&& _m = p_.kind;
            if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                _v.set(many_instances(lx, n.span));
                goto _done;
            }
            {
                _v.set(std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        prism_rtl::is_some(insts_opt) ? ({
        auto&& insts = prism_rtl::some_of(insts_opt);
        ({
        auto&& _m = p_.kind;
        prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        ({
        auto nkey = check_env::sname_key(n);
        auto benv_1 = benv;
        auto e_2 = e;
        auto insts_3 = insts;
        auto menv_4 = menv;
        auto wx_5 = wx;
        call_value(fold_job(check_errors::range0(len(insts_3)), wx_5, ({
        auto lx_6 = lx;
        auto insts_3_7 = insts_3;
        auto nkey_7 = nkey;
        auto menv_4_8 = menv_4;
        auto benv_1_8 = benv_1;
        auto e_2_8 = e_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Wx>(std::tuple<Wx, Nat>)>>(prism_rtl::rc([=](std::tuple<Wx, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_6_8 = lx_6;
            auto insts_3_7_8 = insts_3_7;
            auto nkey_7_8 = nkey_7;
            auto menv_4_8_8 = menv_4_8;
            auto benv_1_8_8 = benv_1_8;
            auto e_2_8_8 = e_2_8;
            entered(once_job([=]() {
            return ({
                auto w = p0;
                auto k = p1;
                ({
                auto lxk = at_instance(lx_6_8, or_(index(insts_3_7_8, k), std::tuple{Array<std::tuple<Text, check_types::Ty>>{}, Array<std::tuple<Text, check_types::Col>>{}}));
                auto bkey = k == Nat(0u) ? nkey_7_8 : prism_rtl::cat(nkey_7_8, "#inst", k);
                ({
                auto&& _m = prelude::get(menv_4_8_8->names, bkey);
                prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
                auto&& rk = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& tk = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                call_then(start_value_of(lxk, benv_1_8_8, e_2_8_8), [=](Vl value_of_209831) { return prism_rtl::finished(widget_let_field(w, place_stem(rk), tk, own(value_of_209831), prism_rtl::cat("`", nkey_7_8, "` at its instantiation ", k))); });
            })
                : prism_rtl::finished(({
                Wx this_ = w;
                this_.build = prelude::push(this_.build, refusal_do(prism_rtl::cat("`", nkey_7_8, "` at its instantiation ", k, ", which has no binding")));
                this_;
            }));
            });
            });
            });
        }));
        });
    })));
    })), [=](Wx fold_209475) {
        return ({
            auto wxn = fold_209475;
            (prism_rtl::finished(std::tuple{wxn, benv_1}));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{wx, benv});
    });
    })
        : prism_rtl::is_none(insts_opt) ? ({
        auto lxw = ({
            __label__ _done;
            prism_rtl::Slot<Lx> _v;
            auto&& _m = p_.kind;
            if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                _v.set(widget_let_lx(lx, n.span));
                goto _done;
            }
            {
                _v.set(lx);
                goto _done;
            }
        _done:
            _v.take();
        });
        auto benv_1 = benv;
        auto e_2 = e;
        auto p__3 = p_;
        auto wx_4 = wx;
        call_then(start_value_of(lxw, benv_1, e_2), [=](Vl value_of_210351) {
        return ({
            auto v_ = own(value_of_210351);
            (prism_rtl::finished(std::tuple{widget_let_field(wx_4, place_stem(rs), t, v_, prism_rtl::cat("`", pat_text(p__3), "`")), benv_1}));
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::finished(std::tuple{wx, benv});
    });
}


/// `Start LetLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Env>> start_let_line(Wx wx, Env benv, Env menv, ast::Pattern_ p_, ast::Expr e) {
    return std::make_shared<LetLine>(wx, benv, menv, p_, e);
}


/// WidgetLetField: fn Wx, Text, OutTy, Ex, Text -> Wx
Wx widget_let_field(const Wx& wx, const Text& f, const OutTy& t, const Ex& v_, const Text& doc) {
    Wx this_ = wx;
    this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaBind{f}), v_}));
    this_.fields = prelude::push(this_.fields, std::tuple{f, t, doc});
    this_.inits = prelude::push(this_.inits, std::tuple{f, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{f}))})});
    return this_;
}


/// ErrPipe: fn EvRef -> EvRef
EvRef err_pipe(const EvRef& r) {
    return EvRef{.node_ = r.node_, .owner = r.owner, .pipe = ({
        auto r_1 = r;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>)>>(prism_rtl::rc([=](std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto r_1_2 = r_1;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                auto k_fn = p1;
                r_1_2.pipe(std::tuple{x, ({
                auto k_fn_2 = k_fn;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>(prism_rtl::rc([=](Ex p0) {
                return ({
                    auto k_fn_2_3 = k_fn_2;
                    entered(once_job([=]() {
                    return ({
                        auto y = p0;
                        k_fn_2_3(Ex(Ex::XCtor{Text("Err"), Array(std::vector{y})}))->cycle();
                    });
                }));
                });
            })));
            })})->cycle();
            });
        }));
        });
    })));
    })};
}


/// OwnAs: fn OutTy, Vl -> Ex
Ex own_as(const OutTy& t, const Vl& v_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        if (prism_rtl::is<OutTy::OutRes>(t)) {
            _v.set(value_ty(v_) == OutTy(OutTy::OutError{})
                ? Ex(Ex::XCtor{Text("Err"), Array(std::vector{own(v_)})})
                : own(v_));
            goto _done;
        }
        {
            _v.set(own(v_));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// BindRes: fn Wx, Env, Pattern, Wres -> Wx
Wx bind_res(const Wx& wx2, const Env& menv, const ast::Pattern_& p_, const Wres& res) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Wx> _v;
        auto&& _m = binding_of(menv, p_);
        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(_m))) {
            auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(_m)).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Wx> _v;
                if (prism_rtl::is<Wres::WrEv>(res)) {
                    auto&& r = prism_rtl::as<Wres::WrEv>(res).a0;
                    _v.set(er.owner != wx2.node_
                        ? crossed(wx2, prism_rtl::cat("the bound event of node `", er.owner, "` (its graph node ", er.node_, ")"))
                        : r.node_ == er.node_ ? wx2 : connect(wx2, r, Sk(Sk::SkNode{er.node_})));
                    goto _done;
                }
                {
                    _v.set(wx2);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(wx2);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// BuildLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> build_line(const Wx& wx, const Env& benv, const Env& menv, const ast::Expr& e, const std::optional<Bn>& bound_opt) {
    auto lx = wx.lx;
    auto full = type_at(lx, e.span);
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wx, Wres>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(build_line(wx, benv, menv, x, bound_opt));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EWidgetBlock>(_m)) {
            auto&& b = prism_rtl::as<ast::ExprKind::EWidgetBlock>(_m).a0;
            _v.set(inline_block(wx, benv, menv, b, lx));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EFor>(_m)) {
            auto&& binders_opt = prism_rtl::as<ast::ExprKind::EFor>(_m).a0;
            auto&& source = prism_rtl::as<ast::ExprKind::EFor>(_m).a1;
            auto&& body = prism_rtl::as<ast::ExprKind::EFor>(_m).a2;
            _v.set(for_line(wx, benv, menv, binders_opt, source, body, e, bound_opt));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ERebuild>(_m)) {
            auto&& scrut = prism_rtl::as<ast::ExprKind::ERebuild>(_m).a0;
            auto&& body = prism_rtl::as<ast::ExprKind::ERebuild>(_m).a1;
            _v.set(rebuild_line(wx, benv, menv, scrut, body, e, bound_opt));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::EIf>(_m).a2)) {
            auto&& m212128_4_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
            auto&& else_b = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
            if (prism_rtl::is<ast::Cond::CondExpr>(m212128_4_0)) {
                auto&& c = prism_rtl::as<ast::Cond::CondExpr>(m212128_4_0).a0;
                _v.set(if_gen_line(wx, menv, c, then_b, else_b, e));
                goto _done;
            }
        }
        {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Wx, Wres>> _v;
                auto&& _m = peel(full);
                if (prism_rtl::is<check_types::Ty::TyElem>(_m)) {
                    _v.set(element_line(wx, benv, menv, e, bound_opt));
                    goto _done;
                }
                if (prism_rtl::is<check_types::Ty::TyAt>(_m)) {
                    _v.set(widget_line(wx, benv, menv, e, bound_opt));
                    goto _done;
                }
                {
                    _v.set(({
                        auto wx2 = ({
                            Wx this_ = wx;
                            this_.build = prelude::push(this_.build, refusal_do(Text("a building line this back end does not lower yet")));
                            this_;
                        });
                        std::tuple{wx2, Wres(Wres::WrUnit{})};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Wx, Wres>> BuildLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& e = this->e;
    const auto& bound_opt = this->bound_opt;
    auto lx = wx.lx;
    auto full = type_at(lx, e.span);
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BuildLine(wx, benv, menv, x, bound_opt)));
    })
        : prism_rtl::is<ast::ExprKind::EWidgetBlock>(_m) ? ({
        auto&& b = prism_rtl::as<ast::ExprKind::EWidgetBlock>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InlineBlock(wx, benv, menv, b, lx)));
    })
        : prism_rtl::is<ast::ExprKind::EFor>(_m) ? ({
        auto&& binders_opt = prism_rtl::as<ast::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<ast::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<ast::ExprKind::EFor>(_m).a2;
        prism_rtl::more(prism_rtl::rc(ForLine(wx, benv, menv, binders_opt, source, body, e, bound_opt)));
    })
        : prism_rtl::is<ast::ExprKind::ERebuild>(_m) ? ({
        auto&& scrut = prism_rtl::as<ast::ExprKind::ERebuild>(_m).a0;
        auto&& body = prism_rtl::as<ast::ExprKind::ERebuild>(_m).a1;
        prism_rtl::more(prism_rtl::rc(RebuildLine(wx, benv, menv, scrut, body, e, bound_opt)));
    })
        : prism_rtl::is<ast::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::EIf>(_m).a2) && ({
        auto&& m212128_4_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
        prism_rtl::is<ast::Cond::CondExpr>(m212128_4_0);
    }) ? ({
        auto&& m212128_4_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
        auto&& c = prism_rtl::as<ast::Cond::CondExpr>(m212128_4_0).a0;
        prism_rtl::more(prism_rtl::rc(IfGenLine(wx, menv, c, then_b, else_b, e)));
    })
        : ({
        auto&& _m = peel(full);
        prism_rtl::is<check_types::Ty::TyElem>(_m) ? prism_rtl::more(prism_rtl::rc(ElementLine(wx, benv, menv, e, bound_opt)))
        : prism_rtl::is<check_types::Ty::TyAt>(_m) ? prism_rtl::more(prism_rtl::rc(WidgetLine(wx, benv, menv, e, bound_opt)))
        : ({
        auto wx2 = ({
            Wx this_ = wx;
            this_.build = prelude::push(this_.build, refusal_do(Text("a building line this back end does not lower yet")));
            this_;
        });
        (prism_rtl::finished(std::tuple{wx2, Wres(Wres::WrUnit{})}));
    });
    });
    });
}


/// `Start BuildLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Wres>> start_build_line(Wx wx, Env benv, Env menv, ast::Expr e, std::optional<Bn> bound_opt) {
    return std::make_shared<BuildLine>(wx, benv, menv, e, bound_opt);
}


/// ElementLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> element_line(const Wx& wx, const Env& benv, const Env& menv, const ast::Expr& e, const std::optional<Bn>& bound_opt) {
    auto lx = wx.lx;
    auto [tag_name, args] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Array<ast::Arg>>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& xs = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{tag_name_of(lx, c), xs});
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(std::tuple{tag_name_of(lx, e), Array<ast::Arg>{}});
            goto _done;
        }
        {
            _v.set(std::tuple{Text(""), Array<ast::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto full = type_at(lx, e.span);
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wx, Wres>> _v;
        auto&& _m = prelude::get(lx.g.tags, tag_name);
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                auto wx2 = ({
                    Wx this_ = wx;
                    this_.build = prelude::push(this_.build, refusal_do(Text("an element of an unknown tag")));
                    this_;
                });
                std::tuple{wx2, Wres(Wres::WrUnit{})};
            }));
            goto _done;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& tg = prism_rtl::some_of(_m);
            _v.set(({
                auto pos = wx.pos;
                auto wx1 = ({
                    Wx this_ = wx;
                    this_.pos = next_pos(this_.pos);
                    this_;
                });
                auto struct_path = path_in(lx, tg.home, tag_struct(tg.name));
                auto [live_fields, const_fields, reads, wx2] = run_to_end(fold_job(tg.fields, std::tuple{Array<std::tuple<Text, Ex>>{}, Array<std::tuple<Text, Ex>>{}, Array<Read>{}, wx1}, ({
                    auto args_1 = args;
                    auto menv_2 = menv;
                    auto pos_3 = pos;
                    auto tg_4 = tg;
                    auto lx_5 = lx;
                    auto benv_6 = benv;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Ex>>, Array<std::tuple<Text, Ex>>, Array<Read>, Wx>>(std::tuple<std::tuple<Array<std::tuple<Text, Ex>>, Array<std::tuple<Text, Ex>>, Array<Read>, Wx>, std::tuple<Text, check_types::Ty>>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, Ex>>, Array<std::tuple<Text, Ex>>, Array<Read>, Wx>, std::tuple<Text, check_types::Ty>> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto args_1_7 = args_1;
                        auto menv_2_7 = menv_2;
                        auto pos_3_7 = pos_3;
                        auto tg_4_7 = tg_4;
                        auto lx_5_7 = lx_5;
                        auto benv_6_7 = benv_6;
                        entered(once_job([=]() {
                        return ({
                            auto [lf, cf, rd, w] = p0;
                            auto [fname, fty] = p1;
                            ({
                            auto&& _m = tag_arg(args_1_7, fname);
                            prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{lf, cf, rd, w})
                            : prism_rtl::is_some(_m) ? ({
                            auto&& arg = prism_rtl::some_of(_m);
                            ({
                            auto&& _m = layer_of(fty);
                            prism_rtl::is<Layer::LyEv>(_m) ? call_then(start_event_ref(w, menv_2_7, arg), [=](std::tuple<EvRef, Wx> event_ref_214329) {
                            return ({
                                auto [r, w2] = event_ref_214329;
                                (prism_rtl::finished(std::tuple{lf, cf, rd, connect(w2, r, Sk(Sk::SkRequest{pos_3_7, request_field(tg_4_7, fname)}))}));
                            });
                        })
                            : call_then(start_dynamic_expr(w, menv_2_7, arg), [=](std::tuple<Ex, Array<Read>> dynamic_expr_214547) {
                            return ({
                                auto [ex, rds] = dynamic_expr_214547;
                                call_then(start_value_of(lx_5_7, benv_6_7, arg), [=](Vl value_of_214618) {
                                return ({
                                    auto cv = own(value_of_214618);
                                    (prism_rtl::finished(std::tuple{prelude::push(lf, std::tuple{snake(fname), ex}), prelude::push(cf, std::tuple{snake(fname), cv}), union_reads(rd, rds), w}));
                                });
                            });
                            });
                        });
                        });
                        })
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                    }));
                    });
                }));
                })));
                auto live = len(reads) > Nat(0u);
                auto [getter, wx3] = live
                    ? fresh_name(wx2, snake(check_types::bare_name(tg.name)))
                    : std::tuple{Text(""), wx2};
                auto variant = variant_of(lx, tg);
                auto level = Ex(Ex::XCtor{variant, Array(std::vector{Ex(Ex::XRecord{struct_path, live ? live_fields : const_fields})})});
                auto at_build = Ex(Ex::XCtor{variant, Array(std::vector{Ex(Ex::XRecord{struct_path, const_fields})})});
                auto added = live
                    ? Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("node")})), getter, Array(std::vector{Ex(Ex::XCx{})})})
                    : level;
                auto wx4 = ({
                    Wx this_ = wx3;
                    this_.places = prelude::push(this_.places, Place{.pos = pos, .level = level, .getter = getter, .reads = reads});
                    this_.build = emits(wx3, pos)
                        ? prelude::push(this_.build, Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("added"), Array(std::vector{place_at(wx3, Text("node"), pos), Ex(Ex::XMethod{prism_rtl::rc(added), Text("to_pod"), Array<Ex>{}})})})}))
                        : this_.build;
                    this_;
                });
                element_output(wx4, menv, tg, element_out(lx, tg, full), pos, bound_opt, at_build);
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Wx, Wres>> ElementLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& e = this->e;
    const auto& bound_opt = this->bound_opt;
    auto lx = wx.lx;
    auto [tag_name, args] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Array<ast::Arg>>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& xs = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{tag_name_of(lx, c), xs});
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(std::tuple{tag_name_of(lx, e), Array<ast::Arg>{}});
            goto _done;
        }
        {
            _v.set(std::tuple{Text(""), Array<ast::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto full = type_at(lx, e.span);
    return ({
        auto&& _m = prelude::get(lx.g.tags, tag_name);
        prism_rtl::is_none(_m) ? ({
        auto wx2 = ({
            Wx this_ = wx;
            this_.build = prelude::push(this_.build, refusal_do(Text("an element of an unknown tag")));
            this_;
        });
        (prism_rtl::finished(std::tuple{wx2, Wres(Wres::WrUnit{})}));
    })
        : prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        ({
        auto pos = wx.pos;
        auto wx1 = ({
            Wx this_ = wx;
            this_.pos = next_pos(this_.pos);
            this_;
        });
        auto struct_path = path_in(lx, tg.home, tag_struct(tg.name));
        auto bound_opt_1 = bound_opt;
        auto benv_2 = benv;
        auto menv_3 = menv;
        call_value(fold_job(tg.fields, std::tuple{Array<std::tuple<Text, Ex>>{}, Array<std::tuple<Text, Ex>>{}, Array<Read>{}, wx1}, ({
        auto args_4 = args;
        auto menv_3_5 = menv_3;
        auto pos_5 = pos;
        auto tg_6 = tg;
        auto lx_7 = lx;
        auto benv_2_8 = benv_2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Ex>>, Array<std::tuple<Text, Ex>>, Array<Read>, Wx>>(std::tuple<std::tuple<Array<std::tuple<Text, Ex>>, Array<std::tuple<Text, Ex>>, Array<Read>, Wx>, std::tuple<Text, check_types::Ty>>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, Ex>>, Array<std::tuple<Text, Ex>>, Array<Read>, Wx>, std::tuple<Text, check_types::Ty>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_4_8 = args_4;
            auto menv_3_5_8 = menv_3_5;
            auto pos_5_8 = pos_5;
            auto tg_6_8 = tg_6;
            auto lx_7_8 = lx_7;
            auto benv_2_8_8 = benv_2_8;
            entered(once_job([=]() {
            return ({
                auto [lf, cf, rd, w] = p0;
                auto [fname, fty] = p1;
                ({
                auto&& _m = tag_arg(args_4_8, fname);
                prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{lf, cf, rd, w})
                : prism_rtl::is_some(_m) ? ({
                auto&& arg = prism_rtl::some_of(_m);
                ({
                auto&& _m = layer_of(fty);
                prism_rtl::is<Layer::LyEv>(_m) ? call_then(start_event_ref(w, menv_3_5_8, arg), [=](std::tuple<EvRef, Wx> event_ref_214329) {
                return ({
                    auto [r, w2] = event_ref_214329;
                    (prism_rtl::finished(std::tuple{lf, cf, rd, connect(w2, r, Sk(Sk::SkRequest{pos_5_8, request_field(tg_6_8, fname)}))}));
                });
            })
                : call_then(start_dynamic_expr(w, menv_3_5_8, arg), [=](std::tuple<Ex, Array<Read>> dynamic_expr_214547) {
                return ({
                    auto [ex, rds] = dynamic_expr_214547;
                    call_then(start_value_of(lx_7_8, benv_2_8_8, arg), [=](Vl value_of_214618) {
                    return ({
                        auto cv = own(value_of_214618);
                        (prism_rtl::finished(std::tuple{prelude::push(lf, std::tuple{snake(fname), ex}), prelude::push(cf, std::tuple{snake(fname), cv}), union_reads(rd, rds), w}));
                    });
                });
                });
            });
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<std::tuple<Text, Ex>>, Array<std::tuple<Text, Ex>>, Array<Read>, Wx> fold_214011) {
        return ({
            auto [live_fields, const_fields, reads, wx2] = fold_214011;
            auto live = len(reads) > Nat(0u);
            auto [getter, wx3] = live
                ? fresh_name(wx2, snake(check_types::bare_name(tg.name)))
                : std::tuple{Text(""), wx2};
            auto variant = variant_of(lx, tg);
            auto level = Ex(Ex::XCtor{variant, Array(std::vector{Ex(Ex::XRecord{struct_path, live ? live_fields : const_fields})})});
            auto at_build = Ex(Ex::XCtor{variant, Array(std::vector{Ex(Ex::XRecord{struct_path, const_fields})})});
            auto added = live
                ? Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("node")})), getter, Array(std::vector{Ex(Ex::XCx{})})})
                : level;
            auto wx4 = ({
                Wx this_ = wx3;
                this_.places = prelude::push(this_.places, Place{.pos = pos, .level = level, .getter = getter, .reads = reads});
                this_.build = emits(wx3, pos)
                    ? prelude::push(this_.build, Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("added"), Array(std::vector{place_at(wx3, Text("node"), pos), Ex(Ex::XMethod{prism_rtl::rc(added), Text("to_pod"), Array<Ex>{}})})})}))
                    : this_.build;
                this_;
            });
            (prism_rtl::finished(element_output(wx4, menv_3, tg, element_out(lx, tg, full), pos, bound_opt_1, at_build)));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ElementLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Wres>> start_element_line(Wx wx, Env benv, Env menv, ast::Expr e, std::optional<Bn> bound_opt) {
    return std::make_shared<ElementLine>(wx, benv, menv, e, bound_opt);
}


/// ElementOut: unbounded fn Lx, TagInfo, Ty -> OutTy
OutTy element_out(const Lx& lx, const check_env::TagInfo& tg, const check_types::Ty& full) {
    auto t = ({
        __label__ _done;
        prism_rtl::Slot<OutTy> _v;
        auto&& _m = peel(full);
        if (prism_rtl::is<check_types::Ty::TyElem>(_m)) {
            auto&& o = prism_rtl::as<check_types::Ty::TyElem>(_m).a1;
            _v.set(out_ty_of(lx, peel(o)));
            goto _done;
        }
        {
            _v.set(out_ty_of(lx, peel(tg->out)));
            goto _done;
        }
    _done:
        _v.take();
    });
    return ({
        __label__ _done;
        prism_rtl::Slot<OutTy> _v;
        if (prism_rtl::is<OutTy::OutGen>(t)) {
            _v.set(OutTy(OutTy::OutPod{}));
            goto _done;
        }
        {
            _v.set(t);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// TagNameOf: fn Lx, Expr -> Text
Text tag_name_of(const Lx& lx, const ast::Expr& c) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = c.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _qk_opt = check_env::resolve_value(lx.g, lx.home, n);
                auto&& qk_opt = std::get<0>(_qk_opt);
                or_(qk_opt, check_env::dotted(n->path_));
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(tag_name_of(lx, x));
            goto _done;
        }
        {
            _v.set(Text(""));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ?TagArg: fn [Arg], Text -> ?Expr
std::optional<ast::Expr> tag_arg(const Array<ast::Arg>& args, const Text& fname) {
    return fold(args, std::optional<ast::Expr>{}, [&](const std::optional<ast::Expr>& found_opt, const ast::Arg& a) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<ast::Expr>> _v;
            auto&& _m = a.name;
            if (prism_rtl::is_some(_m)) {
                auto&& n = prism_rtl::some_of(_m);
                _v.set(n.name == fname ? std::optional(a->value) : found_opt);
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(found_opt);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// RequestField: fn TagInfo, Text -> Text
Text request_field(const check_env::TagInfo& tg, const Text& fname) {
    auto evs = filter(tg.fields, [&](const std::tuple<Text, check_types::Ty>& _p0) {
        auto&& t = std::get<1>(_p0);
        return layer_of(t) == Layer(Layer::LyEv{});
    });
    return len(evs) > Nat(1u) ? fname : Text("");
}


/// ElementOutput: unbounded fn Wx, Env, TagInfo, OutTy, Pos, ?Bn, Ex -> ((Wx, Wres))
std::tuple<Wx, Wres> element_output(const Wx& wx, const Env& menv, const check_env::TagInfo& tg, const OutTy& out, const Pos_& pos, const std::optional<Bn>& bound_opt, const Ex& level) {
    auto lx = wx.lx;
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wx, Wres>> _v;
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnParts>(prism_rtl::some_of(bound_opt))) {
            auto&& parts = prism_rtl::as<Bn::BnParts>(prism_rtl::some_of(bound_opt)).a0;
            _v.set(bundle_output(wx, tg, out, pos, parts, level));
            goto _done;
        }
        {
            _v.set(element_output_of(wx, menv, tg, out, pos, bound_opt, level));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// BundleOutput: unbounded fn Wx, TagInfo, OutTy, Pos, [?Bn], Ex -> ((Wx, Wres))
std::tuple<Wx, Wres> bundle_output(const Wx& wx, const check_env::TagInfo& tg, const OutTy& out, const Pos_& pos, const Array<std::optional<Bn>>& parts, const Ex& level) {
    return !emits(wx, pos)
        ? ({
        auto wx2 = ({
            Wx this_ = wx;
            this_.build = prelude::push(this_.build, refusal_do(prism_rtl::cat("a bundle (", tg.name, ") in a hosted scope")));
            this_;
        });
        std::tuple{wx2, Wres(Wres::WrUnit{})};
    })
        : bundle_output_of(wx, tg, out, pos, parts, level);
}


/// BundleOutputOf: unbounded fn Wx, TagInfo, OutTy, Pos, [?Bn], Ex -> ((Wx, Wres))
std::tuple<Wx, Wres> bundle_output_of(const Wx& wx, const check_env::TagInfo& tg, const OutTy& out, const Pos_& pos, const Array<std::optional<Bn>>& parts, const Ex& level) {
    auto layers = ({
        __label__ _done;
        prism_rtl::Slot<Array<Layer>> _v;
        auto&& _m = tg->out;
        if (prism_rtl::is<check_types::Ty::TyTuple>(_m)) {
            auto&& cs = prism_rtl::as<check_types::Ty::TyTuple>(_m).a0;
            _v.set(each(cs, [&](const check_types::Ty& c) { return layer_of(c); }));
            goto _done;
        }
        {
            _v.set(Array<Layer>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto tys = ({
        __label__ _done;
        prism_rtl::Slot<Array<OutTy>> _v;
        if (prism_rtl::is<OutTy::OutTuple>(out)) {
            auto&& ts = prism_rtl::as<OutTy::OutTuple>(out).a0;
            _v.set(ts);
            goto _done;
        }
        {
            _v.set(Array<OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto idx = check_errors::range0(len(layers));
    auto plain_ix = filter(idx, [&](const Nat& i) { return or_(index(layers, i), Layer(Layer::LyPlain{})) == Layer(Layer::LyPlain{}); });
    auto ev_ix = filter(idx, [&](const Nat& i) { return or_(index(layers, i), Layer(Layer::LyPlain{})) == Layer(Layer::LyEv{}); });
    auto dyn_ix = filter(idx, [&](const Nat& i) { return or_(index(layers, i), Layer(Layer::LyPlain{})) == Layer(Layer::LyDyn{}); });
    auto wx1 = bundle_first(wx, tg, pos, plain_ix, tys, parts, level);
    auto wx2 = fold(ev_ix, wx1, [&](const Wx& w, const Nat& i) { return bundle_answer(w, pos, or_(index(tys, i), OutTy(OutTy::OutUnit{})), or_(index(parts, i), std::optional<Bn>{})); });
    return (len(ev_ix) > Nat(1u)) || (len(dyn_ix) > Nat(0u))
        ? ({
        auto wx3 = ({
            Wx this_ = wx2;
            this_.build = prelude::push(this_.build, refusal_do(prism_rtl::cat("a bundle with a `$` part or two event parts (", tg.name, ")")));
            this_;
        });
        std::tuple{wx3, Wres(Wres::WrUnit{})};
    })
        : std::tuple{wx2, Wres(Wres::WrUnit{})};
}


/// BundleFirst: unbounded fn Wx, TagInfo, Pos, [Nat], [OutTy], [?Bn], Ex -> Wx
Wx bundle_first(const Wx& wx, const check_env::TagInfo& tg, const Pos_& pos, const Array<Nat>& plain_ix, const Array<OutTy>& tys, const Array<std::optional<Bn>>& parts, const Ex& level) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Wx> _v;
        {
            auto&& m219342_0 = plain_ix;
            if (m219342_0.size() == 0u) {
                _v.set(wx);
                goto _done;
            }
        }
        {
            _v.set(({
                auto one = len(plain_ix) == Nat(1u);
                auto plain_ty = one
                    ? or_(index(tys, or_(index(plain_ix, Nat(0u)), Nat(0u))), OutTy(OutTy::OutUnit{}))
                    : OutTy(OutTy::OutTuple{each(plain_ix, [&](const Nat& i) { return or_(index(tys, i), OutTy(OutTy::OutUnit{})); })});
                auto wx1 = ({
                    Wx this_ = wx;
                    this_.lets = append(this_.lets, Array(std::vector{first_value_let(wx, pos, tg, level), Do(Do::DoLet{Pa(Pa::PaBind{prism_rtl::cat("bundle_", place_text(pos))}), Ex(Ex::XDecode{plain_ty, prism_rtl::rc(Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{prism_rtl::cat("first_", place_text(pos))}))}))})})}));
                    this_.fallible = true;
                    this_;
                });
                fold(check_errors::range0(len(plain_ix)), wx1, [&](const Wx& w, const Nat& k) {
                return ({
                    auto i = or_(index(plain_ix, k), Nat(0u));
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Wx> _v;
                    auto&& _m = index(parts, i);
                    if (prism_rtl::is_some(_m) && prism_rtl::is_some(prism_rtl::some_of(_m)) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(prism_rtl::some_of(_m)))) {
                        auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(prism_rtl::some_of(_m))).a0;
                        _v.set(({
                            auto f = place_stem(rs);
                            auto part = one
                                ? Ex(Ex::XVar{prism_rtl::cat("bundle_", place_text(pos))})
                                : Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XPart{prism_rtl::rc(Ex(Ex::XVar{prism_rtl::cat("bundle_", place_text(pos))})), k}))});
                            ({
                            Wx this_ = w;
                            this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaBind{f}), part}));
                            this_.fields = prelude::push(this_.fields, std::tuple{f, or_(index(tys, i), OutTy(OutTy::OutUnit{})), prism_rtl::cat("place ", place_text(pos), "'s answer, part ", i, " of its first value")});
                            this_.inits = prelude::push(this_.inits, std::tuple{f, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{f}))})});
                            this_;
                        });
                        }));
                        goto _done;
                    }
                    {
                        _v.set(w);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                });
            });
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// BundleAnswer: fn Wx, Pos, OutTy, ?Bn -> Wx
Wx bundle_answer(const Wx& wx, const Pos_& pos, const OutTy& et, const std::optional<Bn>& b_opt) {
    auto t = ({
        __label__ _done;
        prism_rtl::Slot<OutTy> _v;
        if (prism_rtl::is<OutTy::OutEvent>(et)) {
            auto&& inner = prism_rtl::as<OutTy::OutEvent>(et).a0;
            _v.set(inner);
            goto _done;
        }
        {
            _v.set(et);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [id, wx2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
        if (prism_rtl::is_some(b_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(b_opt))) {
            auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(b_opt)).a0;
            _v.set(std::tuple{er.node_, wx});
            goto _done;
        }
        {
            _v.set(({
                auto [nm, w] = fresh_name(wx, prism_rtl::cat("place_", place_text(pos)));
                add_gn(w, nm, t, GnKind(GnKind::GnAnswer{}), Nat(0u));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    Wx this_ = wx2;
    this_.answers = prelude::push(this_.answers, std::tuple{pos, id, t, Text("")});
    return this_;
}


/// FirstValueLet: fn Wx, Pos, TagInfo, Ex -> Do
Do first_value_let(const Wx& wx, const Pos_& pos, const check_env::TagInfo& tg, const Ex& level) {
    auto missing = Ex(Ex::XCall{Text("Fault::answer"), Array(std::vector{Ex(Ex::XStr{prism_rtl::cat("no first value for ", tg.name)})})});
    return emits(wx, pos)
        ? ({
        auto asked = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("first_value"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(level), Text("to_pod"), Array<Ex>{}}))})})});
        (Do(Do::DoLet{Pa(Pa::PaBind{prism_rtl::cat("first_", place_text(pos))}), try_of(Ex(Ex::XMethod{prism_rtl::rc(asked), Text("ok_or"), Array(std::vector{missing})}))}));
    })
        : ({
        auto host = host_local(wx, pos);
        auto asked = try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{host})), Text("first_value"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(place_at(wx, Text(""), pos))}), Ex(Ex::XRef{prism_rtl::rc(level)}), Ex(Ex::XCx{})})}));
        (Do(Do::DoLet{Pa(Pa::PaBind{prism_rtl::cat("first_", place_text(pos))}), try_of(Ex(Ex::XMethod{prism_rtl::rc(try_of(Ex(Ex::XMethod{prism_rtl::rc(asked), Text("ok_or"), Array(std::vector{missing})}))), answer_accessor(tg), Array<Ex>{}}))}));
    });
}


/// HostLocal: fn Wx, Pos -> Text
Text host_local(const Wx& wx, const Pos_& pos) {
    return pos.scope == Nat(0u)
        ? Text("enclosing")
        : or_(index(wx.scopes, lexer::dec(pos.scope)), Text(""));
}


/// AnswerVariant: fn TagInfo -> Text
Text answer_variant(const check_env::TagInfo& tg) {
    return prism_rtl::cat("crate::Answer::", tag_struct(tg.name));
}


/// AnswerAccessor: fn TagInfo -> Text
Text answer_accessor(const check_env::TagInfo& tg) {
    return snake(tag_struct(tg.name));
}


/// ElementOutputOf: unbounded fn Wx, Env, TagInfo, OutTy, Pos, ?Bn, Ex -> ((Wx, Wres))
std::tuple<Wx, Wres> element_output_of(const Wx& wx, const Env& menv, const check_env::TagInfo& tg, const OutTy& out, const Pos_& pos, const std::optional<Bn>& bound_opt, const Ex& level) {
    auto lx = wx.lx;
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wx, Wres>> _v;
        auto&& _m = layer_of(tg->out);
        if (prism_rtl::is<Layer::LyEv>(_m)) {
            _v.set(({
                auto [id, wx2] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
                    if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
                        auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
                        _v.set(std::tuple{er.node_, wx});
                        goto _done;
                    }
                    {
                        _v.set(({
                            auto [nm, w] = fresh_name(wx, prism_rtl::cat("place_", place_text(pos)));
                            add_gn(w, nm, out, GnKind(GnKind::GnAnswer{}), Nat(0u));
                        }));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto wx3 = ({
                    Wx this_ = wx2;
                    this_.answers = prelude::push(this_.answers, std::tuple{pos, id, out, answer_accessor(tg)});
                    this_;
                });
                std::tuple{wx3, Wres(Wres::WrEv{ev_ref_of(wx3, id)})};
            }));
            goto _done;
        }
        if (prism_rtl::is<Layer::LyDyn>(_m)) {
            _v.set(({
                auto [f, wx1] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Text, Wx>> _v;
                    if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnHold>(prism_rtl::some_of(bound_opt))) {
                        auto&& hf = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(bound_opt)).a0;
                        _v.set(std::tuple{hf, wx});
                        goto _done;
                    }
                    {
                        _v.set(fresh_name(wx, prism_rtl::cat("place_", place_text(pos))));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto emits_ = emits(wx, pos);
                auto first__1 = emits_
                    ? Ex(Ex::XDecode{out, prism_rtl::rc(Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{prism_rtl::cat("first_", place_text(pos))}))}))})
                    : Ex(Ex::XVar{prism_rtl::cat("first_", place_text(pos))});
                auto wx2 = ({
                    Wx this_ = wx1;
                    this_.lets = prelude::push(this_.lets, first_value_let(wx, pos, tg, level));
                    this_.fields = prelude::push(this_.fields, std::tuple{f, OutTy(OutTy::OutHold{prism_rtl::rc(out)}), prism_rtl::cat("pushed to place ", place_text(pos))});
                    this_.inits = prelude::push(this_.inits, std::tuple{f, Ex(Ex::XCall{Text("Hold::new"), Array(std::vector{first__1, Ex(Ex::XCx{})})})});
                    this_.dyn_places = prelude::push(this_.dyn_places, std::tuple{pos, f, out, answer_accessor(tg)});
                    this_.fallible = true;
                    this_;
                });
                auto wx3 = emits_
                    ? ({
                    Wx this_ = wx2;
                    this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaBind{prism_rtl::cat(f, "_element")}), Ex(Ex::XMethod{prism_rtl::rc(level), Text("to_pod"), Array<Ex>{}})}));
                    this_.fields = prelude::push(this_.fields, std::tuple{prism_rtl::cat(f, "_element"), OutTy(OutTy::OutPod{}), prism_rtl::cat("place ", place_text(pos), "'s element, which pushes are keyed by")});
                    this_.moves = prelude::push(this_.moves, std::tuple{prism_rtl::cat(f, "_element"), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{prism_rtl::cat(f, "_element")}))})});
                    this_.build = prelude::push(this_.build, Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("listen"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text("node")})), prism_rtl::cat(f, "_element")}))}), Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XCast{prism_rtl::rc(Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text("node")}))})), OutTy(OutTy::OutObj{prism_rtl::rc(OutTy(OutTy::OutNamed{Text("Node"), Array<OutTy>{}}))})}))})})})}));
                    this_;
                })
                    : wx2;
                std::tuple{wx3, Wres(Wres::WrDyn{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f)})), Text("get"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{f})}), out})};
            }));
            goto _done;
        }
        {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Wx, Wres>> _v;
                if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(bound_opt))) {
                    auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(bound_opt)).a0;
                    _v.set(({
                        auto f = place_stem(rs);
                        auto first__1 = emits(wx, pos)
                            ? Ex(Ex::XDecode{out, prism_rtl::rc(Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{prism_rtl::cat("first_", place_text(pos))}))}))})
                            : Ex(Ex::XVar{prism_rtl::cat("first_", place_text(pos))});
                        auto wx2 = ({
                            Wx this_ = wx;
                            this_.lets = append(this_.lets, Array(std::vector{first_value_let(wx, pos, tg, level), Do(Do::DoLet{Pa(Pa::PaBind{f}), first__1})}));
                            this_.fields = prelude::push(this_.fields, std::tuple{f, out, prism_rtl::cat("place ", place_text(pos), "'s answer, its first value")});
                            this_.inits = prelude::push(this_.inits, std::tuple{f, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{f}))})});
                            this_.fallible = true;
                            this_;
                        });
                        std::tuple{wx2, Wres(Wres::WrUnit{})};
                    }));
                    goto _done;
                }
                {
                    _v.set(std::tuple{wx, Wres(Wres::WrUnit{})});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// WidgetLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> widget_line(const Wx& wx, const Env& benv, const Env& menv, const ast::Expr& e, const std::optional<Bn>& bound_opt) {
    auto lx = wx.lx;
    auto [callee, args] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::Expr, Array<ast::Arg>>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& xs = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{c, xs});
            goto _done;
        }
        {
            _v.set(std::tuple{e, Array<ast::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto qk = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = callee.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                auto&& q_opt = std::get<0>(_q_opt);
                or_(q_opt, Text(""));
            }));
            goto _done;
        }
        {
            _v.set(Text(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto target_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Nat>> _v;
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
            auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
            _v.set(std::optional(er.node_));
            goto _done;
        }
        {
            _v.set(std::optional<Nat>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto param_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Bn>> _v;
        auto&& _m = callee.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(len(n->path_) == Nat(1u)
                ? prelude::get(menv->names, check_env::sname_key(n))
                : std::optional<Bn>{});
            goto _done;
        }
        {
            _v.set(std::optional<Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wx, Wres>> _v;
        if (prism_rtl::is_some(param_opt) && prism_rtl::is<Bn::BnWidget>(prism_rtl::some_of(param_opt))) {
            auto&& x = prism_rtl::as<Bn::BnWidget>(prism_rtl::some_of(param_opt)).a0;
            auto&& cbenv = prism_rtl::as<Bn::BnWidget>(prism_rtl::some_of(param_opt)).a1;
            auto&& cmenv = prism_rtl::as<Bn::BnWidget>(prism_rtl::some_of(param_opt)).a2;
            auto&& clx = prism_rtl::as<Bn::BnWidget>(prism_rtl::some_of(param_opt)).a3;
            _v.set(apply_widget_param(wx, x, cbenv, cmenv, clx, len(args)));
            goto _done;
        }
        {
            _v.set(widget_call(wx, benv, menv, e, bound_opt, qk, args, target_opt));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Wx, Wres>> WidgetLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& e = this->e;
    const auto& bound_opt = this->bound_opt;
    auto lx = wx.lx;
    auto [callee, args] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::Expr, Array<ast::Arg>>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& xs = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{c, xs});
            goto _done;
        }
        {
            _v.set(std::tuple{e, Array<ast::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto qk = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = callee.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                auto&& q_opt = std::get<0>(_q_opt);
                or_(q_opt, Text(""));
            }));
            goto _done;
        }
        {
            _v.set(Text(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto target_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Nat>> _v;
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
            auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
            _v.set(std::optional(er.node_));
            goto _done;
        }
        {
            _v.set(std::optional<Nat>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto param_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Bn>> _v;
        auto&& _m = callee.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(len(n->path_) == Nat(1u)
                ? prelude::get(menv->names, check_env::sname_key(n))
                : std::optional<Bn>{});
            goto _done;
        }
        {
            _v.set(std::optional<Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return ({
        prism_rtl::is_some(param_opt) && prism_rtl::is<Bn::BnWidget>(prism_rtl::some_of(param_opt)) ? ({
        auto&& x = prism_rtl::as<Bn::BnWidget>(prism_rtl::some_of(param_opt)).a0;
        auto&& cbenv = prism_rtl::as<Bn::BnWidget>(prism_rtl::some_of(param_opt)).a1;
        auto&& cmenv = prism_rtl::as<Bn::BnWidget>(prism_rtl::some_of(param_opt)).a2;
        auto&& clx = prism_rtl::as<Bn::BnWidget>(prism_rtl::some_of(param_opt)).a3;
        prism_rtl::finished(apply_widget_param(wx, x, cbenv, cmenv, clx, len(args)));
    })
        : prism_rtl::finished(widget_call(wx, benv, menv, e, bound_opt, qk, args, target_opt));
    });
}


/// `Start WidgetLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Wres>> start_widget_line(Wx wx, Env benv, Env menv, ast::Expr e, std::optional<Bn> bound_opt) {
    return std::make_shared<WidgetLine>(wx, benv, menv, e, bound_opt);
}


/// ApplyWidgetParam: unbounded fn Wx, Expr, Env, Env, Lx, Nat -> ((Wx, Wres))
std::tuple<Wx, Wres> apply_widget_param(const Wx& wx, const ast::Expr& x, const Env& cbenv, const Env& cmenv, const Lx& clx, const Nat& nargs) {
    return nargs > Nat(0u)
        ? ({
        auto wx2 = ({
            Wx this_ = wx;
            this_.build = prelude::push(this_.build, refusal_do(Text("a widget parameter applied to arguments")));
            this_;
        });
        std::tuple{wx2, Wres(Wres::WrUnit{})};
    })
        : wx.depth > Nat(32u)
        ? std::tuple{wx, Wres(Wres::WrUnit{})}
        : ({
        auto lx = wx.lx;
        auto inner = ({
            Wx this_ = wx;
            this_.lx = clx;
            this_.depth = this_.depth + Nat(1u);
            this_;
        });
        auto [done, res] = build_line(inner, cbenv, cmenv, x, std::optional<Bn>{});
        auto back_ = ({
            Wx this_ = done;
            this_.lx = lx;
            this_.depth = wx.depth;
            this_;
        });
        std::tuple{back_, res};
    });
}


/// InlineBlock: unbounded fn Wx, Env, Env, Block, Lx -> ((Wx, Wres))
std::tuple<Wx, Wres> inline_block(const Wx& wx, const Env& benv, const Env& menv, const ast::Block& b, const Lx& lx) {
    auto inner = ({
        Wx this_ = wx;
        this_.result = Wres(Wres::WrUnit{});
        this_;
    });
    auto done = block_into(inner, benv, menv, b);
    auto back_ = ({
        Wx this_ = done;
        this_.result = wx->result;
        this_;
    });
    return std::tuple{back_, done->result};
}


prism_rtl::Turn<std::tuple<Wx, Wres>> InlineBlock::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& b = this->b;
    const auto& lx = this->lx;
    auto inner = ({
        Wx this_ = wx;
        this_.result = Wres(Wres::WrUnit{});
        this_;
    });
    auto b_1 = b;
    auto benv_2 = benv;
    auto menv_3 = menv;
    auto wx_4 = wx;
    return call_then(start_block_into(inner, benv_2, menv_3, b_1), [=](Wx block_into_228130) {
        return ({
            auto done = block_into_228130;
            auto back_ = ({
                Wx this_ = done;
                this_.result = wx_4->result;
                this_;
            });
            (prism_rtl::finished(std::tuple{back_, done->result}));
        });
    });
}


/// `Start InlineBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Wres>> start_inline_block(Wx wx, Env benv, Env menv, ast::Block b, Lx lx) {
    return std::make_shared<InlineBlock>(wx, benv, menv, b, lx);
}


/// WidgetCall: unbounded fn Wx, Env, Env, Expr, ?Bn, Text, [Arg], ?Nat -> ((Wx, Wres))
std::tuple<Wx, Wres> widget_call(const Wx& wx, const Env& benv, const Env& menv, const ast::Expr& e, const std::optional<Bn>& bound_opt, const Text& qk, const Array<ast::Arg>& args, const std::optional<Nat>& target_opt) {
    auto lx = wx.lx;
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wx, Wres>> _v;
        {
            auto&& m228414_0 = qk;
            if (m228414_0 == Text("Prelude.@started")) {
                _v.set(started_line(wx, bound_opt));
                goto _done;
            }
        }
        {
            auto&& m228414_1 = qk;
            if (m228414_1 == Text("Prelude.@Switch")) {
                _v.set(switch_line(wx, menv, args));
                goto _done;
            }
        }
        {
            auto&& m228414_2 = qk;
            if (m228414_2 == Text("Prelude.@Flatten")) {
                _v.set(flatten_line(wx, menv, args, bound_opt));
                goto _done;
            }
        }
        {
            auto&& m228414_3 = qk;
            if (m228414_3 == Text("Prelude.@Defer")) {
                _v.set(defer_line(wx, menv, args, e, target_opt));
                goto _done;
            }
        }
        {
            auto&& m228414_4 = qk;
            if (m228414_4 == Text("Prelude.@Run")) {
                _v.set(run_line(wx, benv, args, e, target_opt));
                goto _done;
            }
        }
        {
            auto&& m228414_5 = qk;
            if (m228414_5 == Text("Prelude.@Machine")) {
                _v.set(machine_line(wx, benv, menv, args, e, target_opt));
                goto _done;
            }
        }
        {
            auto&& m228414_6 = qk;
            if (m228414_6 == Text("Prelude.@HostDocument")) {
                _v.set(host_line(wx, benv, menv, HostForm(HostForm::HostEach{}), args, bound_opt));
                goto _done;
            }
        }
        {
            auto&& m228414_7 = qk;
            if (m228414_7 == Text("Prelude.@HostSome")) {
                _v.set(host_line(wx, benv, menv, HostForm(HostForm::HostSome{}), args, bound_opt));
                goto _done;
            }
        }
        {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Wx, Wres>> _v;
                auto&& _m = prelude::get(lx.g.vals, qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(inline_widget(wx, benv, menv, qk, v_, args, e));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto wx2 = ({
                            Wx this_ = wx;
                            this_.build = prelude::push(this_.build, refusal_do(Text("a widget this back end does not lower yet")));
                            this_;
                        });
                        std::tuple{wx2, Wres(Wres::WrUnit{})};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// HostLine: unbounded fn Wx, Env, Env, HostForm, [Arg], ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> host_line(const Wx& wx, const Env& benv, const Env& menv, const HostForm& form, const Array<ast::Arg>& args, const std::optional<Bn>& bound_opt) {
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto k = len(wx.scopes) + Nat(1u);
    auto hf = prism_rtl::cat("host_", k);
    auto rows_name = prism_rtl::cat(hf, "_rows");
    auto doc_getter = prism_rtl::cat(hf, "_doc");
    auto wx1 = ({
        Wx this_ = wx;
        this_.taken = append(this_.taken, Array(std::vector{hf, rows_name, doc_getter, prism_rtl::cat(doc_getter, "_now"), prism_rtl::cat(doc_getter, "_snap"), prism_rtl::cat(doc_getter, "_direct"), prism_rtl::cat(doc_getter, "_publish"), prism_rtl::cat(hf, "_answer"), prism_rtl::cat(hf, "_moved")}));
        this_;
    });
    auto named = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = index(args, Nat(1u));
        if (prism_rtl::is_some(_m)) {
            auto&& sup = prism_rtl::some_of(_m);
            _v.set(is_widget_name(sup->value));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wx, Wres>> _v;
        auto&& _m = std::tuple{index(args, Nat(0u)), index(args, Nat(1u))};
        if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
            if (named) {
                _v.set(({
                    auto wx2 = ({
                        Wx this_ = wx1;
                        this_.pos = next_pos(this_.pos);
                        this_.build = prelude::push(this_.build, refusal_do(Text("a named widget function as a host's supplier (gap NS): a lambda supplier is lowered, a widget function is not a value")));
                        this_;
                    });
                    std::tuple{wx2, Wres(Wres::WrHosted{prism_rtl::rc(Wres(Wres::WrUnit{})), Bn(Bn::BnLocal{Ex(Ex::XUnit{}), Holding(Holding::Owned{}), OutTy(OutTy::OutUnit{})})})};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
            auto&& child = prism_rtl::some_of(std::get<0>(_m));
            auto&& sup = prism_rtl::some_of(std::get<1>(_m));
            _v.set(({
                auto [wxd, dyn_env, dyn_lets] = dynamic_answers(wx1, benv, menv, hf, sup->value);
                auto offered = own(value_of(lx, dyn_env, sup->value));
                auto supplier0 = ({
                    __label__ _done;
                    prism_rtl::Slot<Ex> _v;
                    if (prism_rtl::is<HostForm::HostEach>(form)) {
                        _v.set(offered);
                        goto _done;
                    }
                    if (prism_rtl::is<HostForm::HostSome>(form)) {
                        _v.set(Ex(Ex::XCall{Text("prism_rtl::forward_on_none"), Array(std::vector{offered})}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto supplier = len(dyn_lets) == Nat(0u)
                    ? supplier0
                    : Ex(Ex::XBlock{dyn_lets, prism_rtl::rc(supplier0)});
                auto enclosing = emits(wx, pos)
                    ? Ex(Ex::XNone{})
                    : Ex(Ex::XCtor{Text("Some"), Array(std::vector{Ex(Ex::XCast{prism_rtl::rc(Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{host_local(wx, pos)}))})), host_of_ty()})})});
                auto made = Ex(Ex::XCall{Text("prism_rtl::Host::new"), Array(std::vector{place_at(wx, Text(""), pos), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{rows_name}))}), supplier, enclosing, Ex(Ex::XPath{prism_rtl::cat(wx.node_, "::", doc_getter, "_direct")}), Ex(Ex::XPath{prism_rtl::cat(wx.node_, "::", hf, "_answer")})})});
                auto host_ty = OutTy(OutTy::OutRc{prism_rtl::rc(OutTy(OutTy::OutNamed{Text("prism_rtl::Host"), Array(std::vector{elem_ty(), answer_ty_value(), OutTy(OutTy::OutNamed{wx.node_, Array<OutTy>{}})})}))});
                auto rows_ty = OutTy(OutTy::OutNamed{Text("prism_rtl::Rows"), Array(std::vector{elem_ty(), answer_ty_value()})});
                auto doc_ty = OutTy(OutTy::OutMap{prism_rtl::rc(OutTy(OutTy::OutPath{})), prism_rtl::rc(elem_ty())});
                auto what = prism_rtl::cat("the document of the child hosted at place ", place_text(pos));
                auto wx2 = ({
                    Wx this_ = wxd;
                    this_.pos = next_pos(this_.pos);
                    this_.lets = append(this_.lets, Array(std::vector{Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{rows_name})), rows_ty}), Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{Ex(Ex::XCall{Text("RefCell::new"), Array(std::vector{Ex(Ex::XCall{Text("Map::new"), Array<Ex>{}})})})})})}), Do(Do::DoLet{Pa(Pa::PaBind{hf}), made})}));
                    this_.fields = append(this_.fields, Array(std::vector{std::tuple{hf, host_ty, prism_rtl::cat("the host at place ", place_text(pos), ": its supplier, its rows, and the way back into its child (pick HO)")}, std::tuple{rows_name, rows_ty, prism_rtl::cat("the rows of the host at place ", place_text(pos), ": `for p, e <- $doc`, one supplier blueprint per child place")}, std::tuple{prism_rtl::cat(doc_getter, "_snap"), OutTy(OutTy::OutSnapshot{prism_rtl::rc(doc_ty)}), prism_rtl::cat("`$doc` of the host at place ", place_text(pos), ", a structural dynamic: its snapshots, the structure and the lagged dynamic (pick ST)")}}));
                    this_.moves = append(this_.moves, Array(std::vector{std::tuple{hf, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{hf}))})}, std::tuple{rows_name, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{rows_name}))})}}));
                    this_.inits = prelude::push(this_.inits, std::tuple{prism_rtl::cat(doc_getter, "_snap"), Ex(Ex::XCall{Text("Snapshot::new"), Array(std::vector{Ex(Ex::XStr{what})})})});
                    this_.hosts = prelude::push(this_.hosts, HostDef{.pos = pos, .name = hf, .scope = k});
                    this_.snaps = prelude::push(this_.snaps, SnapDef{.name = doc_getter, .live = prism_rtl::cat(doc_getter, "_now"), .ty = doc_ty, .eq = true, .builder = rows_name, .before = true, .what = what});
                    this_.getters = append(this_.getters, Array(std::vector{snap_getter(doc_getter, doc_ty, prism_rtl::cat("The document of the child hosted at place ", place_text(pos), ", `$doc`, a structural dynamic (pick ST): one tick behind the child's structure, the snapshot of the tick before the tick the read point is after.")), MethDef{.name = prism_rtl::cat(doc_getter, "_direct"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = doc_ty, .body = Array<Do>{}, .tail = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(doc_getter, "_snap")})), Text("current"), Array(std::vector{Ex(Ex::XCx{})})}), .doc = prism_rtl::cat("The structure of the child hosted at place ", place_text(pos), ", not the lagged `$doc`: the snapshot taken in this tick's construction step, the document as the tick opened during propagation. The host's own `for` and its rows' entries read it, so a newborn child place gets its row in the tick it is born (pick ST).")}}));
                    this_.scopes = prelude::push(this_.scopes, hf);
                    this_.builders = prelude::push(this_.builders, ForDef{.name = rows_name, .pos = pos, .at = place_at(wx, Text("self"), pos), .key_ty = OutTy(OutTy::OutPath{}), .value_ty = elem_ty(), .row_node = Text("prism_rtl::HostRow::<crate::Elem, crate::Answer>"), .keyed = true, .source = prism_rtl::cat(doc_getter, "_direct"), .parent = Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), hf}))}), .passed = Array<Ex>{}});
                    this_.build_holds = add_read(this_.build_holds, Read(Read::OwnRead{prism_rtl::cat(doc_getter, "_now")}));
                    this_.row_marks = prelude::push(this_.row_marks, RowMarks{.builder = rows_name, .reads = Array(std::vector{Read(Read::OwnRead{prism_rtl::cat(doc_getter, "_now")})}), .wrote = Array<Text>{}, .kind = RowKind(RowKind::ForRow{})});
                    this_.fallible = true;
                    this_;
                });
                auto inner = ({
                    Wx this_ = wx2;
                    this_.pos = scope_pos(k);
                    this_.result = Wres(Wres::WrUnit{});
                    this_;
                });
                auto [done, res] = build_line(inner, benv, menv, child->value, std::optional<Bn>{});
                auto child_places = drop(done.places, len(wx2.places));
                auto child_builds = filter(done.build_holds, [&](const Read& h) { return !has_read(wx2.build_holds, h); });
                auto child_gens = fold(drop(done.gen_holds, len(wx2.gen_holds)), Array<Read>{}, [&](const Array<Read>& acc, const std::tuple<Text, Array<Read>>& _p1) {
                    auto&& hs = std::get<1>(_p1);
                    return union_reads(acc, hs);
                });
                auto child_rows = fold(drop(done.row_marks, len(wx2.row_marks)), Array<Read>{}, [&](const Array<Read>& acc, const RowMarks& rm) { return union_reads(acc, rm.reads); });
                auto doc_reads = fold(child_places, union_reads(union_reads(child_builds, child_gens), child_rows), [&](const Array<Read>& acc, const Place& pl) { return union_reads(acc, pl.reads); });
                auto in_scope_fn = ({
                    auto k_1 = k;
                    (prism_rtl::rc([=](const Pos_& p_) { return p_.scope == k_1; }));
                });
                auto getter = host_doc_getter(prism_rtl::cat(doc_getter, "_now"), pos, filter(child_places, [&](const Place& pl) { return in_scope_fn(pl.pos); }), filter(drop(done.builders, len(wx2.builders)), [&](const ForDef& b) { return in_scope_fn(b.pos); }), filter(drop(done.gens, len(wx2.gens)), [&](const GenDef& gd) { return in_scope_fn(gd.pos); }));
                auto back_ = ({
                    Wx this_ = done;
                    this_.pos = wx2.pos;
                    this_.result = wx->result;
                    this_.getters = prelude::push(this_.getters, getter);
                    this_.dyn_reads = insert(this_.dyn_reads, prism_rtl::cat(doc_getter, "_now"), doc_reads);
                    this_;
                });
                auto doc_bn = Bn(Bn::BnDyn{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), doc_getter, Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{doc_getter})}), doc_ty});
                std::tuple{back_, Wres(Wres::WrHosted{prism_rtl::rc(res), doc_bn})};
            }));
            goto _done;
        }
        {
            _v.set(({
                auto wx2 = ({
                    Wx this_ = wx1;
                    this_.pos = next_pos(this_.pos);
                    this_.build = prelude::push(this_.build, refusal_do(Text("a host without its child or its supplier")));
                    this_;
                });
                std::tuple{wx2, Wres(Wres::WrHosted{prism_rtl::rc(Wres(Wres::WrUnit{})), Bn(Bn::BnLocal{Ex(Ex::XUnit{}), Holding(Holding::Owned{}), OutTy(OutTy::OutUnit{})})})};
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// IsWidgetName: fn Expr -> Bool
bool is_widget_name(const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(lexer::has_prefix(check_env::sname_key(n), Text("@")));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(is_widget_name(x));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// DynamicAnswers: unbounded fn Wx, Env, Env, Text, Expr -> ((Wx, Env, [Do]))
std::tuple<Wx, Env, Array<Do>> dynamic_answers(const Wx& wx, const Env& benv, const Env& menv, const Text& hf, const ast::Expr& sup) {
    auto lx = wx.lx;
    auto dyns = fold(typed::exprs_in(sup), Array<std::tuple<ast::Expr, ast::Expr>>{}, [&](const Array<std::tuple<ast::Expr, ast::Expr>>& acc, const ast::Expr& x) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<ast::Expr, ast::Expr>>> _v;
            auto&& _m = x.kind;
            if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
                auto&& m238575_0_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
                auto&& y = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
                if (m238575_0_0 == Text("@")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<std::tuple<ast::Expr, ast::Expr>>> _v;
                        auto&& _m = dynamic_answer(lx, y);
                        if (prism_rtl::is_some(_m)) {
                            auto&& d = prism_rtl::some_of(_m);
                            _v.set(prelude::push(acc, std::tuple{y, d}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(acc);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return len(dyns) == Nat(0u)
        ? std::tuple{wx, benv, Array<Do>{}}
        : ({
        auto owner = prism_rtl::cat(hf, "_owner");
        auto wx1 = ({
            Wx this_ = wx;
            this_.taken = prelude::push(this_.taken, owner);
            this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaBind{owner}), Ex(Ex::XCall{prism_rtl::cat("prism_rtl::Link::<", wx.node_, ">::new"), Array<Ex>{}})}));
            this_.build = prelude::push(this_.build, Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{owner})), Text("link"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text("node")}))})})})}));
            this_;
        });
        auto env0 = bind(benv, Text("#owner"), Bn(Bn::BnLocal{Ex(Ex::XVar{owner}), Holding(Holding::Owned{}), OutTy(OutTy::OutUnit{})}));
        auto lets0 = Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{owner}), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{owner}))})})});
        run_to_end(fold_job(check_errors::range0(len(dyns)), std::tuple{wx1, env0, lets0}, ({
        auto dyns_1 = dyns;
        auto hf_2 = hf;
        auto menv_3 = menv;
        auto lx_4 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Array<Do>>>(std::tuple<std::tuple<Wx, Env, Array<Do>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Array<Do>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto dyns_1_5 = dyns_1;
            auto hf_2_5 = hf_2;
            auto menv_3_5 = menv_3;
            auto lx_4_5 = lx_4;
            entered(once_job([=]() {
            return ({
                auto [w, en, ls] = p0;
                auto j = p1;
                ({
                auto&& _m = index(dyns_1_5, j);
                prism_rtl::is_some(_m) ? ({
                auto&& y = std::get<0>(prism_rtl::some_of(_m));
                auto&& d = std::get<1>(prism_rtl::some_of(_m));
                ({
                auto name = prism_rtl::cat(hf_2_5, "_dyn_", j + Nat(1u));
                auto port = prism_rtl::cat(name, "_port");
                call_then(start_dynamic_expr(w, menv_3_5, d), [=](std::tuple<Ex, Array<Read>> dynamic_expr_239487) {
                return ({
                    auto [ex, reads] = dynamic_expr_239487;
                    call_then(start_out_ty_of(lx_4_5, peel(type_at(lx_4_5, d.span))), [=](OutTy out_ty_of_239534) {
                    return ({
                        auto t = out_ty_of_239534;
                        !all_inited(w, reads)
                        ? prism_rtl::finished(std::tuple{w, en, ls})
                        : ({
                        auto w2 = ({
                            Wx this_ = w;
                            this_.taken = append(this_.taken, Array(std::vector{name, port}));
                            this_.getters = prelude::push(this_.getters, MethDef{.name = name, .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = t, .body = Array<Do>{}, .tail = ex, .doc = prism_rtl::cat("The host at `", hf_2_5, "`'s dynamic answer `", src_text(lx_4_5, lx_4_5->file, y.span), "`, read at the read point (round 3 DY).")});
                            this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{port})), OutTy(OutTy::OutRc{prism_rtl::rc(OutTy(OutTy::OutPort{prism_rtl::rc(OutTy(OutTy::OutUnit{}))}))})}), Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{Ex(Ex::XCall{Text("Port::new"), Array<Ex>{}})})})}));
                            this_.fields = prelude::push(this_.fields, std::tuple{port, OutTy(OutTy::OutRc{prism_rtl::rc(OutTy(OutTy::OutPort{prism_rtl::rc(OutTy(OutTy::OutUnit{}))}))}), prism_rtl::cat("the dynamic answer `", name, "` moved: its blueprints push the child's place next tick")});
                            this_.moves = prelude::push(this_.moves, std::tuple{port, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{port}))})});
                            this_.dyn_answers = prelude::push(this_.dyn_answers, std::tuple{name, reads});
                            this_;
                        });
                        (prism_rtl::finished(std::tuple{w2, bind(en, prism_rtl::cat("#dyn", dyn_key(y)), Bn(Bn::BnLocal{Ex(Ex::XVar{name}), Holding(Holding::Owned{}), t})), prelude::push(ls, Do(Do::DoLet{Pa(Pa::PaBind{port}), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{port}))})}))}));
                    });
                    });
                });
                });
            });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{w, en, ls})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
    });
}


/// ?DynamicAnswer: fn Lx, Expr -> ?Expr
std::optional<ast::Expr> dynamic_answer(const Lx& lx, const ast::Expr& x) {
    return layer_of(type_at(lx, x.span)) != Layer(Layer::LyDyn{})
        ? std::optional<ast::Expr>{}
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<ast::Expr>> _v;
        auto&& _m = x.kind;
        if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
            auto&& m240964_0_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
            auto&& inner = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
            if (m240964_0_0 == Text("$")) {
                _v.set(layer_of(type_at(lx, inner.span)) == Layer(Layer::LyDyn{})
                    ? std::optional(inner)
                    : std::optional<ast::Expr>{});
                goto _done;
            }
        }
        {
            _v.set(std::optional(x));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// DynKey: fn Expr -> Text
Text dyn_key(const ast::Expr& x) {
    return prism_rtl::cat(x.span.start, ":", x.span.end);
}


/// HostDocGetter: fn Text, Pos, [Place], [ForDef], [GenDef] -> MethDef
MethDef host_doc_getter(const Text& name, const Pos_& pos, const Array<Place>& places, const Array<ForDef>& builders, const Array<GenDef>& gens) {
    auto start = Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaMut{Text("doc")})), OutTy(OutTy::OutMap{prism_rtl::rc(OutTy(OutTy::OutPath{})), prism_rtl::rc(elem_ty())})}), Ex(Ex::XCall{Text("Map::new"), Array<Ex>{}})});
    auto body = document_body(({
        auto f = prism_rtl::rc(map_insert);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Do>(std::tuple<Ex, Ex>)>>(prism_rtl::rc([=](std::tuple<Ex, Ex> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0, a1)); });
        });
    })));
    }), places, builders, gens);
    return MethDef{.name = name, .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = OutTy(OutTy::OutMap{prism_rtl::rc(OutTy(OutTy::OutPath{})), prism_rtl::rc(elem_ty())}), .body = append(Array(std::vector{start}), body), .tail = Ex(Ex::XVar{Text("doc")}), .doc = prism_rtl::cat("The document of the child hosted at place ", place_text(pos), " computed live: each of its places by its path relative to the child, its level at the read point (pick HO). Read only by the snapshot `$doc` answers from (pick ST).")};
}


/// SnapGetter: fn Text, OutTy, Text -> MethDef
MethDef snap_getter(const Text& name, const OutTy& t, const Text& doc) {
    return MethDef{.name = name, .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = t, .body = Array<Do>{}, .tail = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(name, "_snap")})), Text("get"), Array(std::vector{Ex(Ex::XCx{})})}), .doc = doc};
}


/// StartedLine: fn Wx, ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> started_line(const Wx& wx, const std::optional<Bn>& bound_opt) {
    auto wx1 = ({
        Wx this_ = wx;
        this_.pos = next_pos(this_.pos);
        this_;
    });
    auto [id, wx2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
            auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
            _v.set(std::tuple{er.node_, wx1});
            goto _done;
        }
        {
            _v.set(({
                auto [nm, w] = fresh_name(wx1, Text("started"));
                add_gn(w, nm, OutTy(OutTy::OutUnit{}), GnKind(GnKind::GnStarted{}), Nat(0u));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto wx3 = ({
        Wx this_ = wx2;
        this_.started = prelude::push(this_.started, id);
        this_;
    });
    return std::tuple{wx3, Wres(Wres::WrEv{ev_ref_of(wx3, id)})};
}


/// DeferLine: unbounded fn Wx, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
std::tuple<Wx, Wres> defer_line(const Wx& wx, const Env& menv, const Array<ast::Arg>& args, const ast::Expr& e, const std::optional<Nat>& target_opt) {
    auto lx = wx.lx;
    auto t = out_ty_of(lx, out_of(type_at(lx, e.span)));
    auto [field, wx1] = fresh_name(wx, Text("deferred"));
    auto [id, wx2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
        if (prism_rtl::is_some(target_opt)) {
            auto&& n = prism_rtl::some_of(target_opt);
            _v.set(std::tuple{n, wx1});
            goto _done;
        }
        if (prism_rtl::is_none(target_opt)) {
            _v.set(add_gn(wx1, prism_rtl::cat(field, "_fired"), t, GnKind(GnKind::GnDeferred{}), Nat(0u)));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto wx3 = add_field_last(wx2, field, OutTy(OutTy::OutDefer{prism_rtl::rc(t)}), Text("`@Defer`"), Ex(Ex::XCall{Text("Defer::new"), Array<Ex>{}}));
    auto wx4 = ({
        Wx this_ = wx3;
        this_.defers = prelude::push(this_.defers, std::tuple{field, id});
        this_;
    });
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wx, Wres>> _v;
        auto&& _m = index(args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(({
                auto [r, wx5] = event_ref(wx4, menv, a->value);
                std::tuple{connect(wx5, r, Sk(Sk::SkArm{field})), Wres(Wres::WrEv{ev_ref_of(wx5, id)})};
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{wx4, Wres(Wres::WrEv{ev_ref_of(wx4, id)})});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// RunLine: unbounded fn Wx, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
std::tuple<Wx, Wres> run_line(const Wx& wx, const Env& benv, const Array<ast::Arg>& args, const ast::Expr& e, const std::optional<Nat>& target_opt) {
    auto lx = wx.lx;
    auto t = out_ty_of(lx, out_of(type_at(lx, e.span)));
    auto [p_, wx1] = fresh_name(wx, Text("run"));
    auto wx2 = ({
        Wx this_ = wx1;
        this_.pos = next_pos(this_.pos);
        this_.taken = append(this_.taken, Array(std::vector{prism_rtl::cat(p_, "_job"), prism_rtl::cat(p_, "_again"), prism_rtl::cat(p_, "_started"), prism_rtl::cat(p_, "_turn")}));
        this_;
    });
    auto start = ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        auto&& _m = index(args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Ex> _v;
                auto&& _m = a->value.kind;
                if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                    auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                    _v.set(({
                        auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                        auto&& q_opt = std::get<0>(_q_opt);
                        (Ex(Ex::XPath{start_path(lx, or_(q_opt, Text("")))}));
                    }));
                    goto _done;
                }
                {
                    _v.set(refusal(Text("an `@Run` of a function value that is not a name")));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(refusal(Text("an `@Run` without its function")));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto x = ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        auto&& _m = index(args, Nat(1u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(own(value_of(lx, benv, a->value)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Ex(Ex::XUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto wx3 = add_field(wx2, prism_rtl::cat(p_, "_job"), OutTy(OutTy::OutHold{prism_rtl::rc(OutTy(OutTy::OutJob{prism_rtl::rc(t)}))}), Text("`@Run`'s job (`@Machine`'s state)"), Ex(Ex::XCall{Text("Hold::new"), Array(std::vector{Ex(Ex::XApply{prism_rtl::rc(start), Array(std::vector{x})}), Ex(Ex::XCx{})})}));
    auto wx4 = add_field_last(wx3, prism_rtl::cat(p_, "_again"), OutTy(OutTy::OutDefer{prism_rtl::rc(OutTy(OutTy::OutUnit{}))}), Text("`@Run`'s `!again`"), Ex(Ex::XCall{Text("Defer::new"), Array<Ex>{}}));
    auto [s, wx5] = add_gn(wx4, prism_rtl::cat(p_, "_started"), OutTy(OutTy::OutUnit{}), GnKind(GnKind::GnStarted{}), Nat(0u));
    auto [a, wx6] = add_gn(wx5, prism_rtl::cat(p_, "_again"), OutTy(OutTy::OutUnit{}), GnKind(GnKind::GnDeferred{}), Nat(0u));
    auto [m, wx7] = lower::merge(wx6, prism_rtl::cat(p_, "_turn"), OutTy(OutTy::OutUnit{}), ev_ref_of(wx6, s), ev_ref_of(wx6, a));
    auto [res, wx8] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
        if (prism_rtl::is_some(target_opt)) {
            auto&& n = prism_rtl::some_of(target_opt);
            _v.set(std::tuple{n, wx7});
            goto _done;
        }
        if (prism_rtl::is_none(target_opt)) {
            _v.set(add_gn(wx7, prism_rtl::cat(p_, "_done"), t, GnKind(GnKind::GnNamed{}), Nat(0u)));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto wx9 = ({
        Wx this_ = connect(wx8, ev_ref_of(wx8, m), Sk(Sk::SkCycle{prism_rtl::cat(p_, "_job"), prism_rtl::cat(p_, "_again"), res}));
        this_.started = prelude::push(this_.started, s);
        this_.defers = prelude::push(this_.defers, std::tuple{prism_rtl::cat(p_, "_again"), a});
        this_;
    });
    return std::tuple{wx9, Wres(Wres::WrEv{ev_ref_of(wx9, res)})};
}


/// MachineLine: unbounded fn Wx, Env, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
std::tuple<Wx, Wres> machine_line(const Wx& wx, const Env& benv, const Env& menv, const Array<ast::Arg>& args, const ast::Expr& e, const std::optional<Nat>& target_opt) {
    auto lx = wx.lx;
    auto t = out_ty_of(lx, out_of(type_at(lx, e.span)));
    auto [f, wx1] = fresh_name(wx, Text("machine"));
    auto step_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = a->value.kind;
                if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                    auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                    _v.set(({
                        auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                        auto&& q_opt = std::get<0>(_q_opt);
                        ({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        if (prism_rtl::is_some(q_opt)) {
                            auto&& q = prism_rtl::some_of(q_opt);
                            _v.set(value_path(lx, q));
                            goto _done;
                        }
                        if (prism_rtl::is_none(q_opt)) {
                            _v.set(Text(""));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                {
                    _v.set(Text(""));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wx, Wres>> _v;
        auto&& _m = std::tuple{step_, index(args, Nat(1u)), index(args, Nat(2u))};
        if (prism_rtl::is_some(std::get<1>(_m)) && prism_rtl::is_some(std::get<2>(_m))) {
            auto&& sp = std::get<0>(_m);
            auto&& init = prism_rtl::some_of(std::get<1>(_m));
            auto&& ev = prism_rtl::some_of(std::get<2>(_m));
            if (sp != Text("")) {
                _v.set(({
                    auto st = out_ty_of(lx, peel(type_at(lx, init->value.span)));
                    auto x = own(value_of(lx, benv, init->value));
                    auto wx2 = add_field(wx1, prism_rtl::cat(f, "_state"), OutTy(OutTy::OutHold{prism_rtl::rc(st)}), Text("`@Machine`'s state"), Ex(Ex::XCall{Text("Hold::new"), Array(std::vector{x, Ex(Ex::XCx{})})}));
                    auto [out, wx3] = ({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
                        if (prism_rtl::is_some(target_opt)) {
                            auto&& n = prism_rtl::some_of(target_opt);
                            _v.set(std::tuple{n, wx2});
                            goto _done;
                        }
                        if (prism_rtl::is_none(target_opt)) {
                            _v.set(add_gn(wx2, prism_rtl::cat(f, "_fired"), t, GnKind(GnKind::GnNamed{}), Nat(0u)));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    auto [r, wx4] = event_ref(wx3, menv, ev->value);
                    std::tuple{connect(wx4, r, Sk(Sk::SkMachine{prism_rtl::cat(f, "_state"), sp, out})), Wres(Wres::WrEv{ev_ref_of(wx4, out)})};
                }));
                goto _done;
            }
        }
        {
            _v.set(({
                auto wx2 = ({
                    Wx this_ = wx1;
                    this_.build = prelude::push(this_.build, refusal_do(Text("an `@Machine` whose step is not a named function")));
                    this_;
                });
                std::tuple{wx2, Wres(Wres::WrUnit{})};
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// InlineWidget: unbounded fn Wx, Env, Env, Text, ValInfo, [Arg], Expr -> ((Wx, Wres))
std::tuple<Wx, Wres> inline_widget(const Wx& wx, const Env& benv, const Env& menv, const Text& qk, const check_env::ValInfo& v_, const Array<ast::Arg>& args, const ast::Expr& e) {
    auto lx = wx.lx;
    auto clauses = clauses_of(lx.g, qk);
    auto w_opt = widget_decl_of(lx.g, qk);
    auto [params, body_opt] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<ast::Pattern_>, std::optional<ast::Block>>> _v;
        if (prism_rtl::is_some(w_opt)) {
            auto&& wd = prism_rtl::some_of(w_opt);
            _v.set(std::tuple{Array<ast::Pattern_>{}, std::optional(wd.body)});
            goto _done;
        }
        if (prism_rtl::is_none(w_opt)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<ast::Pattern_>, std::optional<ast::Block>>> _v;
                {
                    auto&& m247900_0 = clauses;
                    if (m247900_0.size() == 1u) {
                        {
                            auto&& _c1 = index(m247900_0, Nat(0u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& c = prism_rtl::some_of(_c1);
                                _v.set(({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<Array<ast::Pattern_>, std::optional<ast::Block>>> _v;
                                    auto&& _m = c.body;
                                    if (prism_rtl::is<ast::FnBody::BodyBlock>(_m)) {
                                        auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(_m).a0;
                                        _v.set(std::tuple{c.params, std::optional(b)});
                                        goto _done;
                                    }
                                    if (prism_rtl::is<ast::FnBody::BodyExpr>(_m)) {
                                        auto&& x = prism_rtl::as<ast::FnBody::BodyExpr>(_m).a0;
                                        _v.set(std::tuple{c.params, std::optional(ast::Block{.stmts = Array(std::vector{ast::Stmt{.kind = ast::StmtKind(ast::StmtKind::SExpr{x}), .span = x.span}}), .inline_ = true, .span = x.span})});
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                }));
                                goto _done;
                            }
                        }
                    }
                }
                {
                    _v.set(std::tuple{Array<ast::Pattern_>{}, std::optional<ast::Block>{}});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wx, Wres>> _v;
        if (prism_rtl::is_none(body_opt)) {
            _v.set(len(clauses) == Nat(0u)
                ? ({
                auto wx2 = ({
                    Wx this_ = wx;
                    this_.build = prelude::push(this_.build, refusal_do(prism_rtl::cat("the builtin widget ", check_types::bare_name(qk))));
                    this_;
                });
                std::tuple{wx2, Wres(Wres::WrUnit{})};
            })
                : ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Wx, Wres>> _v;
                auto&& _m = index(args, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& a = prism_rtl::some_of(_m);
                    _v.set(({
                        auto call = ast::Block{.stmts = Array(std::vector{ast::Stmt{.kind = ast::StmtKind(ast::StmtKind::SExpr{e}), .span = e.span}}), .inline_ = true, .span = e.span};
                        clause_widget_line(wx, menv, a->value, call, qk, v_, e);
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto wx2 = ({
                            Wx this_ = wx;
                            this_.build = prelude::push(this_.build, refusal_do(Text("a widget of several clauses that takes no arguments")));
                            this_;
                        });
                        std::tuple{wx2, Wres(Wres::WrUnit{})};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_some(body_opt)) {
            auto&& body = prism_rtl::some_of(body_opt);
            _v.set(wx.depth > Nat(16u)
                ? std::tuple{wx, Wres(Wres::WrUnit{})}
                : ({
                auto lxc = in_module_at(lx, v_->file, v_.home, lx.site);
                auto ptys = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<check_types::Ty>> _v;
                    auto&& _m = v_.scheme.ty;
                    if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                        auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
                        _v.set(ps);
                        goto _done;
                    }
                    {
                        _v.set(Array<check_types::Ty>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto [wx1, be1, me1] = run_to_end(fold_job(check_errors::range0(len(params)), std::tuple{wx, empty_env(), empty_env()}, ({
                    auto params_1 = params;
                    auto lxc_2 = lxc;
                    auto ptys_3 = ptys;
                    auto args_4 = args;
                    auto benv_5 = benv;
                    auto menv_6 = menv;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Env>>(std::tuple<std::tuple<Wx, Env, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Env>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto params_1_7 = params_1;
                        auto lxc_2_7 = lxc_2;
                        auto ptys_3_7 = ptys_3;
                        auto args_4_7 = args_4;
                        auto benv_5_7 = benv_5;
                        auto menv_6_7 = menv_6;
                        entered(once_job([=]() {
                        return ({
                            auto [w, be, me] = p0;
                            auto i = p1;
                            ({
                            auto p_ = or_(index(params_1_7, i), dummy_pat());
                            auto nkey = plain_binder(lxc_2_7, p_);
                            auto pty = or_(index(ptys_3_7, i), check_types::Ty(check_types::Ty::TyErr{}));
                            ({
                            auto&& _m = index(args_4_7, i);
                            prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{w, be, me})
                            : prism_rtl::is_some(_m) ? ({
                            auto&& a = prism_rtl::some_of(_m);
                            prism_rtl::finished(bind_param(w, benv_5_7, menv_6_7, be, me, nkey, pty, a->value));
                        })
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                        });
                    }));
                    });
                }));
                })));
                auto inner = ({
                    Wx this_ = wx1;
                    this_.lx = lxc;
                    this_.depth = this_.depth + Nat(1u);
                    this_.result = Wres(Wres::WrUnit{});
                    this_;
                });
                auto done = block_into(inner, be1, me1, body);
                auto back_ = ({
                    Wx this_ = done;
                    this_.lx = lx;
                    this_.depth = wx.depth;
                    this_.result = wx->result;
                    this_;
                });
                std::tuple{back_, done->result};
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// ?WidgetDeclOf: fn G, Text -> ?WidgetDecl
std::optional<ast::WidgetDecl> widget_decl_of(const check_env::G& g, const Text& qk) {
    return fold(g.defs, std::optional<ast::WidgetDecl>{}, [&](const std::optional<ast::WidgetDecl>& found_opt, const check_env::Def& d) { return d.qk == qk ? def_widget(d, found_opt) : found_opt; });
}


/// ?DefWidget: fn Def, ?WidgetDecl -> ?WidgetDecl
std::optional<ast::WidgetDecl> def_widget(const check_env::Def& d, const std::optional<ast::WidgetDecl>& other_opt) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<ast::WidgetDecl>> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<check_env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<check_env::DefBody::DbWidget>(_m).a0;
            _v.set(std::optional(w));
            goto _done;
        }
        {
            _v.set(other_opt);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// BindParam: unbounded fn Wx, Env, Env, Env, Env, Text, Ty, Expr -> ((Wx, Env, Env))
std::tuple<Wx, Env, Env> bind_param(const Wx& wx, const Env& cbenv, const Env& cmenv, const Env& be, const Env& me, const Text& nkey, const check_types::Ty& pty, const ast::Expr& arg) {
    auto lx = wx.lx;
    auto t = out_ty_of(lx, peel(pty));
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wx, Env, Env>> _v;
        auto&& _m = layer_of(pty);
        if (prism_rtl::is<Layer::LyBlueprint>(_m)) {
            _v.set(({
                auto b = Bn(Bn::BnWidget{arg, cbenv, cmenv, lx});
                std::tuple{wx, bind(be, nkey, b), bind(me, nkey, b)};
            }));
            goto _done;
        }
        if (prism_rtl::is<Layer::LyEv>(_m)) {
            _v.set(({
                auto [r, wx2] = event_ref(wx, cmenv, arg);
                auto b = Bn(Bn::BnEv{r, t});
                std::tuple{wx2, bind(be, nkey, b), bind(me, nkey, b)};
            }));
            goto _done;
        }
        if (prism_rtl::is<Layer::LyDyn>(_m)) {
            _v.set(({
                auto [ex, reads] = dynamic_expr(wx, cmenv, arg);
                auto b = Bn(Bn::BnDyn{ex, reads, t});
                std::tuple{wx, bind(be, nkey, b), bind(me, nkey, b)};
            }));
            goto _done;
        }
        {
            _v.set(({
                auto [rs, wx2] = fresh_name(wx, snake(nkey));
                auto v_ = own(value_of(lx, cbenv, arg));
                auto wx3 = ({
                    Wx this_ = wx2;
                    this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaBind{rs}), v_}));
                    this_.fields = prelude::push(this_.fields, std::tuple{rs, t, prism_rtl::cat("`", nkey, "`")});
                    this_.inits = prelude::push(this_.inits, std::tuple{rs, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{rs}))})});
                    this_;
                });
                auto [be2, me2] = bind_plain(be, me, nkey, rs, t);
                std::tuple{wx3, be2, me2};
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// DynamicExpr: unbounded fn Wx, Env, Expr -> ((Ex, [Read]))
std::tuple<Ex, Array<Read>> dynamic_expr(const Wx& wx, const Env& menv, const ast::Expr& e) {
    auto v_ = value_of(wx.lx, menv, e);
    auto reads = fold(typed::exprs_in(e), Array<Read>{}, [&](const Array<Read>& acc, const ast::Expr& x) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Read>> _v;
            auto&& _m = x.kind;
            if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Read>> _v;
                    auto&& _m = prelude::get(menv->names, check_env::sname_key(n));
                    if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnHold>(prism_rtl::some_of(_m))) {
                        auto&& f = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(_m)).a0;
                        _v.set(add_read(acc, Read(Read::OwnRead{f})));
                        goto _done;
                    }
                    if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnDyn>(prism_rtl::some_of(_m))) {
                        auto&& rs = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a1;
                        _v.set(union_reads(acc, rs));
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return std::tuple{own(v_), reads};
}


prism_rtl::Turn<std::tuple<Ex, Array<Read>>> DynamicExpr::cycle() const {
    const auto& wx = this->wx;
    const auto& menv = this->menv;
    const auto& e = this->e;
    auto e_1 = e;
    auto menv_2 = menv;
    auto wx_3 = wx;
    return call_then(start_value_of(wx_3.lx, menv_2, e_1), [=](Vl value_of_252729) {
        return ({
            auto v_ = value_of_252729;
            call_then(typed::start_exprs_in(e_1), [=](Array<ast::Expr> exprs_in_252774) {
            return ({
                auto reads = fold(exprs_in_252774, Array<Read>{}, [&](const Array<Read>& acc, const ast::Expr& x) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Read>> _v;
                        auto&& _m = x.kind;
                        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<Array<Read>> _v;
                                auto&& _m = prelude::get(menv_2->names, check_env::sname_key(n));
                                if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnHold>(prism_rtl::some_of(_m))) {
                                    auto&& f = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(_m)).a0;
                                    _v.set(add_read(acc, Read(Read::OwnRead{f})));
                                    goto _done;
                                }
                                if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnDyn>(prism_rtl::some_of(_m))) {
                                    auto&& rs = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a1;
                                    _v.set(union_reads(acc, rs));
                                    goto _done;
                                }
                                {
                                    _v.set(acc);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        {
                            _v.set(acc);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                (prism_rtl::finished(std::tuple{own(v_), reads}));
            });
        });
        });
    });
}


/// `Start DynamicExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Ex, Array<Read>>> start_dynamic_expr(Wx wx, Env menv, ast::Expr e) {
    return std::make_shared<DynamicExpr>(wx, menv, e);
}


/// NeverEvent: fn Wx, OutTy -> ((EvRef, Wx))
std::tuple<EvRef, Wx> never_event(const Wx& wx, const OutTy& t) {
    auto [id, wx2] = add_gn(wx, Text("never"), t, GnKind(GnKind::GnNever{}), Nat(0u));
    return std::tuple{ev_ref_of(wx2, id), wx2};
}


/// EventRef: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
std::tuple<EvRef, Wx> event_ref(const Wx& wx, const Env& menv, const ast::Expr& e) {
    auto lx = wx.lx;
    auto t = out_ty_of(lx, peel(type_at(lx, e.span)));
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<EvRef, Wx>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(event_ref(wx, menv, x));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<EvRef, Wx>> _v;
                auto&& _m = prelude::get(menv->names, check_env::sname_key(n));
                if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(_m))) {
                    auto&& r = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(_m)).a0;
                    _v.set(r.owner == wx.node_
                        ? std::tuple{r, wx}
                        : never_event(crossed(wx, prism_rtl::cat("the event `", check_env::sname_key(n), "`, of node `", r.owner, "`,")), t));
                    goto _done;
                }
                {
                    _v.set(never_event(wx, t));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EBinary>(_m)) {
            auto&& m253638_2_0 = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
            if (m253638_2_0 == Text("<|")) {
                _v.set(({
                    auto [lr, w1] = event_ref(wx, menv, l);
                    auto [rr, w2] = event_ref(w1, menv, r);
                    auto [nm, w3] = fresh_name(w2, Text("anon"));
                    auto [id, w4] = lower::merge(w3, nm, t, lr, rr);
                    std::tuple{ev_ref_of(w4, id), w4};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<ast::ExprKind::EBinary>(_m)) {
            auto&& m253638_3_0 = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
            if (m253638_3_0 == Text("on")) {
                _v.set(({
                    auto [rr, w1] = event_ref(wx, menv, r);
                    auto value = own(value_of(lx, menv, l));
                    std::tuple{EvRef{.node_ = rr.node_, .owner = rr.owner, .pipe = ({
                    auto rr_1 = rr;
                    auto value_2 = value;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>)>>(prism_rtl::rc([=](std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto rr_1_3 = rr_1;
                        auto value_2_3 = value_2;
                        entered(once_job([=]() {
                        return ({
                            auto x = p0;
                            auto k_fn = p1;
                            rr_1_3.pipe(std::tuple{x, ({
                            auto k_fn_3 = k_fn;
                            auto value_2_3_4 = value_2_3;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>(prism_rtl::rc([=](Ex p0) {
                            return ({
                                auto k_fn_3_4 = k_fn_3;
                                auto value_2_3_4_4 = value_2_3_4;
                                entered(once_job([=]() {
                                return ({
                                    static_cast<void>(p0);
                                    k_fn_3_4(value_2_3_4_4)->cycle();
                                });
                            }));
                            });
                        })));
                        })})->cycle();
                        });
                    }));
                    });
                })));
                })}, w1};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<EvRef, Wx>> _v;
                auto&& _m = callee_key(lx, c);
                {
                    auto&& m254494_0 = _m;
                    if (m254494_0 == Text("Prelude.!Filter")) {
                        _v.set(filter_event(wx, menv, args, false));
                        goto _done;
                    }
                }
                {
                    auto&& m254494_1 = _m;
                    if (m254494_1 == Text("Prelude.!Present")) {
                        _v.set(filter_event(wx, menv, args, true));
                        goto _done;
                    }
                }
                {
                    auto&& m254494_2 = _m;
                    if (m254494_2 == Text("Prelude.!Gate")) {
                        _v.set(gate_event(wx, menv, args));
                        goto _done;
                    }
                }
                {
                    auto&& m254494_3 = _m;
                    if (m254494_3 == Text("Prelude.!Union")) {
                        _v.set(pair_event(wx, menv, args, GnKind(GnKind::GnUnion{}), t));
                        goto _done;
                    }
                }
                {
                    auto&& m254494_4 = _m;
                    if (m254494_4 == Text("Prelude.!Both")) {
                        _v.set(pair_event(wx, menv, args, GnKind(GnKind::GnBoth{}), t));
                        goto _done;
                    }
                }
                {
                    auto&& m254494_5 = _m;
                    if (m254494_5 == Text("Prelude.!Except")) {
                        _v.set(pair_event(wx, menv, args, GnKind(GnKind::GnExcept{}), t));
                        goto _done;
                    }
                }
                {
                    auto&& m254494_6 = _m;
                    if (m254494_6 == Text("Prelude.!MergeAll")) {
                        _v.set(merge_all_event(wx, menv, args, t));
                        goto _done;
                    }
                }
                {
                    auto&& m254494_7 = _m;
                    if (m254494_7 == Text("Prelude.!Updated")) {
                        _v.set(updated_event(wx, menv, args, t));
                        goto _done;
                    }
                }
                {
                    _v.set(event_map(wx, menv, e));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::EIf>(_m).a2)) {
            auto&& m253638_5_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
            auto&& else_b = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
            if (prism_rtl::is<ast::Cond::CondExpr>(m253638_5_0)) {
                auto&& c = prism_rtl::as<ast::Cond::CondExpr>(m253638_5_0).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<EvRef, Wx>> _v;
                    auto&& _m = std::tuple{block_expr(then_b), block_expr(else_b)};
                    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                        auto&& a = prism_rtl::some_of(std::get<0>(_m));
                        auto&& b = prism_rtl::some_of(std::get<1>(_m));
                        _v.set(event_if(wx, menv, c, a, b, t));
                        goto _done;
                    }
                    {
                        _v.set(event_map(wx, menv, e));
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
        }
        {
            _v.set(event_map(wx, menv, e));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<EvRef, Wx>> EventRef::cycle() const {
    const auto& wx = this->wx;
    const auto& menv = this->menv;
    const auto& e = this->e;
    auto lx = wx.lx;
    auto e_1 = e;
    auto menv_2 = menv;
    auto wx_3 = wx;
    return call_then(start_out_ty_of(lx, peel(type_at(lx, e_1.span))), [=](OutTy out_ty_of_253595) {
        return ({
            auto t = out_ty_of_253595;
            ({
            auto&& _m = e_1.kind;
            prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            prism_rtl::more(prism_rtl::rc(EventRef(wx_3, menv_2, x)));
        })
            : prism_rtl::is<ast::ExprKind::EName>(_m) ? ({
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            ({
            auto&& _m = prelude::get(menv_2->names, check_env::sname_key(n));
            prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(_m)) ? ({
            auto&& r = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(_m)).a0;
            r.owner == wx_3.node_
            ? prism_rtl::finished(std::tuple{r, wx_3})
            : prism_rtl::finished(never_event(crossed(wx_3, prism_rtl::cat("the event `", check_env::sname_key(n), "`, of node `", r.owner, "`,")), t));
        })
            : prism_rtl::finished(never_event(wx_3, t));
        });
        })
            : prism_rtl::is<ast::ExprKind::EBinary>(_m) && ({
            auto&& m253638_2_0 = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
            (m253638_2_0 == Text("<|"));
        }) ? ({
            auto&& m253638_2_0 = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
            ({
            auto l_4 = l;
            auto r_5 = r;
            call_then(start_event_ref(wx_3, menv_2, l_4), [=](std::tuple<EvRef, Wx> event_ref_254015) {
            return ({
                auto [lr, w1] = event_ref_254015;
                call_then(start_event_ref(w1, menv_2, r_5), [=](std::tuple<EvRef, Wx> event_ref_254065) {
                return ({
                    auto [rr, w2] = event_ref_254065;
                    auto [nm, w3] = fresh_name(w2, Text("anon"));
                    auto [id, w4] = lower::merge(w3, nm, t, lr, rr);
                    (prism_rtl::finished(std::tuple{ev_ref_of(w4, id), w4}));
                });
            });
            });
        });
        });
        })
            : prism_rtl::is<ast::ExprKind::EBinary>(_m) && ({
            auto&& m253638_3_0 = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
            (m253638_3_0 == Text("on"));
        }) ? ({
            auto&& m253638_3_0 = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
            ({
            auto l_4 = l;
            auto r_5 = r;
            call_then(start_event_ref(wx_3, menv_2, r_5), [=](std::tuple<EvRef, Wx> event_ref_254283) {
            return ({
                auto [rr, w1] = event_ref_254283;
                call_then(start_value_of(lx, menv_2, l_4), [=](Vl value_of_254333) {
                return ({
                    auto value = own(value_of_254333);
                    (prism_rtl::finished(std::tuple{EvRef{.node_ = rr.node_, .owner = rr.owner, .pipe = ({
                    auto rr_6 = rr;
                    auto value_7 = value;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>)>>(prism_rtl::rc([=](std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto rr_6_8 = rr_6;
                        auto value_7_8 = value_7;
                        entered(once_job([=]() {
                        return ({
                            auto x = p0;
                            auto k_fn = p1;
                            rr_6_8.pipe(std::tuple{x, ({
                            auto k_fn_8 = k_fn;
                            auto value_7_8_9 = value_7_8;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>(prism_rtl::rc([=](Ex p0) {
                            return ({
                                auto k_fn_8_9 = k_fn_8;
                                auto value_7_8_9_9 = value_7_8_9;
                                entered(once_job([=]() {
                                return ({
                                    static_cast<void>(p0);
                                    k_fn_8_9(value_7_8_9_9)->cycle();
                                });
                            }));
                            });
                        })));
                        })})->cycle();
                        });
                    }));
                    });
                })));
                })}, w1}));
                });
            });
            });
        });
        });
        })
            : prism_rtl::is<ast::ExprKind::ECall>(_m) ? ({
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            ({
            auto&& _m = callee_key(lx, c);
            ({
            auto&& m254494_0 = _m;
            (m254494_0 == Text("Prelude.!Filter"));
        }) ? ({
            auto&& m254494_0 = _m;
            prism_rtl::finished(filter_event(wx_3, menv_2, args, false));
        })
            : ({
            auto&& m254494_1 = _m;
            (m254494_1 == Text("Prelude.!Present"));
        }) ? ({
            auto&& m254494_1 = _m;
            prism_rtl::finished(filter_event(wx_3, menv_2, args, true));
        })
            : ({
            auto&& m254494_2 = _m;
            (m254494_2 == Text("Prelude.!Gate"));
        }) ? ({
            auto&& m254494_2 = _m;
            prism_rtl::finished(gate_event(wx_3, menv_2, args));
        })
            : ({
            auto&& m254494_3 = _m;
            (m254494_3 == Text("Prelude.!Union"));
        }) ? ({
            auto&& m254494_3 = _m;
            prism_rtl::finished(pair_event(wx_3, menv_2, args, GnKind(GnKind::GnUnion{}), t));
        })
            : ({
            auto&& m254494_4 = _m;
            (m254494_4 == Text("Prelude.!Both"));
        }) ? ({
            auto&& m254494_4 = _m;
            prism_rtl::finished(pair_event(wx_3, menv_2, args, GnKind(GnKind::GnBoth{}), t));
        })
            : ({
            auto&& m254494_5 = _m;
            (m254494_5 == Text("Prelude.!Except"));
        }) ? ({
            auto&& m254494_5 = _m;
            prism_rtl::finished(pair_event(wx_3, menv_2, args, GnKind(GnKind::GnExcept{}), t));
        })
            : ({
            auto&& m254494_6 = _m;
            (m254494_6 == Text("Prelude.!MergeAll"));
        }) ? ({
            auto&& m254494_6 = _m;
            prism_rtl::finished(merge_all_event(wx_3, menv_2, args, t));
        })
            : ({
            auto&& m254494_7 = _m;
            (m254494_7 == Text("Prelude.!Updated"));
        }) ? ({
            auto&& m254494_7 = _m;
            prism_rtl::finished(updated_event(wx_3, menv_2, args, t));
        })
            : prism_rtl::finished(event_map(wx_3, menv_2, e_1));
        });
        })
            : prism_rtl::is<ast::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::EIf>(_m).a2) && ({
            auto&& m253638_5_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
            auto&& else_b = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
            prism_rtl::is<ast::Cond::CondExpr>(m253638_5_0);
        }) ? ({
            auto&& m253638_5_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
            auto&& else_b = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
            auto&& c = prism_rtl::as<ast::Cond::CondExpr>(m253638_5_0).a0;
            ({
            auto&& _m = std::tuple{block_expr(then_b), block_expr(else_b)};
            prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m)) ? ({
            auto&& a = prism_rtl::some_of(std::get<0>(_m));
            auto&& b = prism_rtl::some_of(std::get<1>(_m));
            prism_rtl::finished(event_if(wx_3, menv_2, c, a, b, t));
        })
            : prism_rtl::finished(event_map(wx_3, menv_2, e_1));
        });
        })
            : prism_rtl::finished(event_map(wx_3, menv_2, e_1));
        });
        });
    });
}


/// `Start EventRef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<EvRef, Wx>> start_event_ref(Wx wx, Env menv, ast::Expr e) {
    return std::make_shared<EventRef>(wx, menv, e);
}


/// EventIf: unbounded fn Wx, Env, Expr, Expr, Expr, OutTy -> ((EvRef, Wx))
std::tuple<EvRef, Wx> event_if(const Wx& wx, const Env& menv, const ast::Expr& c, const ast::Expr& a, const ast::Expr& b, const OutTy& t) {
    auto cond = as_bool(value_of(wx.lx, menv, c));
    auto [ra, w1] = event_ref(wx, menv, a);
    auto [rb, w2] = event_ref(w1, menv, b);
    auto ga = EvRef{.node_ = ra.node_, .owner = ra.owner, .pipe = ({
        auto ra_1 = ra;
        auto cond_2 = cond;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>)>>(prism_rtl::rc([=](std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ra_1_3 = ra_1;
            auto cond_2_3 = cond_2;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                auto k_fn = p1;
                ra_1_3.pipe(std::tuple{x, ({
                auto cond_2_3_3 = cond_2_3;
                auto k_fn_3 = k_fn;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>(prism_rtl::rc([=](Ex p0) {
                return ({
                    auto cond_2_3_3_4 = cond_2_3_3;
                    auto k_fn_3_4 = k_fn_3;
                    entered(once_job([=]() {
                    return ({
                        auto y = p0;
                        call_value(k_fn_3_4(y), [=](Array<Do> k_255772) { return prism_rtl::finished(Array(std::vector{Do(Do::DoIf{cond_2_3_3_4, k_255772, Array<Do>{}})})); });
                    });
                }));
                });
            })));
            })})->cycle();
            });
        }));
        });
    })));
    })};
    auto gb = EvRef{.node_ = rb.node_, .owner = rb.owner, .pipe = ({
        auto rb_1 = rb;
        auto cond_2 = cond;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>)>>(prism_rtl::rc([=](std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rb_1_3 = rb_1;
            auto cond_2_3 = cond_2;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                auto k_fn = p1;
                rb_1_3.pipe(std::tuple{x, ({
                auto cond_2_3_3 = cond_2_3;
                auto k_fn_3 = k_fn;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>(prism_rtl::rc([=](Ex p0) {
                return ({
                    auto cond_2_3_3_4 = cond_2_3_3;
                    auto k_fn_3_4 = k_fn_3;
                    entered(once_job([=]() {
                    return ({
                        auto y = p0;
                        call_value(k_fn_3_4(y), [=](Array<Do> k_255910) { return prism_rtl::finished(Array(std::vector{Do(Do::DoIf{Ex(Ex::XBin{Text("=="), prism_rtl::rc(cond_2_3_3_4), prism_rtl::rc(Ex(Ex::XBool{false}))}), k_255910, Array<Do>{}})})); });
                    });
                }));
                });
            })));
            })})->cycle();
            });
        }));
        });
    })));
    })};
    auto [nm, w3] = fresh_name(w2, Text("chosen"));
    auto [id, w4] = lower::merge(w3, nm, t, ga, gb);
    return std::tuple{ev_ref_of(w4, id), w4};
}


/// ?BlockExpr: fn Block -> ?Expr
std::optional<ast::Expr> block_expr(const ast::Block& b) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<ast::Expr>> _v;
        auto&& _m = b.stmts;
        {
            auto&& m256144_0 = _m;
            if (m256144_0.size() == 1u) {
                {
                    auto&& _c1 = index(m256144_0, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& st = prism_rtl::some_of(_c1);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<std::optional<ast::Expr>> _v;
                            auto&& _m = st.kind;
                            if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
                                auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
                                _v.set(std::optional(x));
                                goto _done;
                            }
                            {
                                _v.set(std::optional<ast::Expr>{});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                }
            }
        }
        {
            _v.set(std::optional<ast::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// CalleeKey: fn Lx, Expr -> Text
Text callee_key(const Lx& lx, const ast::Expr& c) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = c.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                auto&& q_opt = std::get<0>(_q_opt);
                or_(q_opt, Text(""));
            }));
            goto _done;
        }
        {
            _v.set(Text(""));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// PairEvent: unbounded fn Wx, Env, [Arg], GnKind, OutTy -> ((EvRef, Wx))
std::tuple<EvRef, Wx> pair_event(const Wx& wx, const Env& menv, const Array<ast::Arg>& args, const GnKind& kind, const OutTy& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<EvRef, Wx>> _v;
        auto&& _m = std::tuple{index(args, Nat(0u)), index(args, Nat(1u))};
        if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
            auto&& a = prism_rtl::some_of(std::get<0>(_m));
            auto&& b = prism_rtl::some_of(std::get<1>(_m));
            _v.set(({
                auto [ra, w1] = event_ref(wx, menv, a->value);
                auto [rb, w2] = event_ref(w1, menv, b->value);
                auto lt = out_ty_of(wx.lx, peel(type_at(wx.lx, a->value.span)));
                auto rt = out_ty_of(wx.lx, peel(type_at(wx.lx, b->value.span)));
                auto [nm, w3] = fresh_name(w2, kind_word(kind));
                auto [id, w4] = combinator(w3, nm, t, kind, ra, rb, lt, rt);
                std::tuple{ev_ref_of(w4, id), w4};
            }));
            goto _done;
        }
        {
            _v.set(never_event(wx, t));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// MergeAllEvent: unbounded fn Wx, Env, [Arg], OutTy -> ((EvRef, Wx))
std::tuple<EvRef, Wx> merge_all_event(const Wx& wx, const Env& menv, const Array<ast::Arg>& args, const OutTy& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<EvRef, Wx>> _v;
        auto&& _m = index(args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<EvRef, Wx>> _v;
                auto&& _m = a->value.kind;
                if (prism_rtl::is<ast::ExprKind::EArray>(_m)) {
                    auto&& es = prism_rtl::as<ast::ExprKind::EArray>(_m).a0;
                    _v.set(({
                        auto et = ({
                            __label__ _done;
                            prism_rtl::Slot<OutTy> _v;
                            if (prism_rtl::is<OutTy::OutArray>(t)) {
                                auto&& x = prism_rtl::as<OutTy::OutArray>(t).a0;
                                _v.set(x);
                                goto _done;
                            }
                            {
                                _v.set(OutTy(OutTy::OutUnit{}));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto [nm, w1] = fresh_name(wx, Text("merged"));
                        auto [id, w2] = add_gn(w1, nm, t, GnKind(GnKind::GnMergeAll{}), Nat(1u));
                        auto ins = each(check_errors::range0(len(es)), [&](const Nat& i) { return prism_rtl::cat(nm, "_", i); });
                        auto w3 = fold(ins, w2, [&](const Wx& w, const Text& f) { return add_field_last(w, f, OutTy(OutTy::OutStamped{prism_rtl::rc(et)}), Text("an input of `!MergeAll`"), Ex(Ex::XCall{Text("Stamped::new"), Array<Ex>{}})); });
                        auto w4 = ({
                            Wx this_ = w3;
                            this_.gns = each(this_.gns, [&](const Gn& n) { return n.id == id ? with_inputs(n, ins) : n; });
                            this_;
                        });
                        auto w5 = run_to_end(fold_job(check_errors::range0(len(es)), w4, ({
                            auto menv_1 = menv;
                            auto es_2 = es;
                            auto a_3 = a;
                            auto id_4 = id;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Wx>(std::tuple<Wx, Nat>)>>(prism_rtl::rc([=](std::tuple<Wx, Nat> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto menv_1_5 = menv_1;
                                auto es_2_5 = es_2;
                                auto a_3_5 = a_3;
                                auto id_4_5 = id_4;
                                entered(once_job([=]() {
                                return ({
                                    auto w = p0;
                                    auto i = p1;
                                    call_then(start_event_ref(w, menv_1_5, or_(index(es_2_5, i), a_3_5->value)), [=](std::tuple<EvRef, Wx> event_ref_258078) {
                                    return ({
                                        auto [r, w6] = event_ref_258078;
                                        (prism_rtl::finished(connect(w6, r, Sk(Sk::SkIn{id_4_5, i}))));
                                    });
                                });
                                });
                            }));
                            });
                        })));
                        })));
                        std::tuple{ev_ref_of(w5, id), w5};
                    }));
                    goto _done;
                }
                {
                    _v.set(({
                        auto [r, w1] = never_event(wx, t);
                        auto w2 = ({
                            Wx this_ = w1;
                            this_.build = prelude::push(this_.build, refusal_do(Text("`!MergeAll` of a list that is not a literal")));
                            this_;
                        });
                        std::tuple{r, w2};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(never_event(wx, t));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}

}  // namespace crate::lower
