// The module `Lower`, from `target/bootstrap/cpp-src/prismc/lower.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include "lower.hpp"
#include "ast.hpp"
#include "check_env.hpp"
#include "check_errors.hpp"
#include "check_types.hpp"
#include "lexer.hpp"
#include "typed.hpp"
#include "lower.generic.hpp"
#include "check_env.generic.hpp"
#include "lexer.generic.hpp"

namespace crate::lower {

prism_rtl::Turn<std::tuple<Wx, Env, Env>> WidgetStmt::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& s = this->s;
    const auto& last = this->last;
    auto lx = wx.lx;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<ast::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
        ({
        auto benv_1 = benv;
        auto e_2 = e;
        auto menv_3 = menv;
        auto p__4 = p_;
        auto wx_5 = wx;
        call_then(start_build_line(wx_5, benv_1, menv_3, e_2, binding_of(menv_3, p__4)), [=](std::tuple<Wx, Wres> build_line_202524) {
        return ({
            auto [wx2, res] = build_line_202524;
            auto wx3 = bind_res(wx2, menv_3, p__4, res);
            ({
            auto&& _m = std::tuple{res, p__4.kind};
            prism_rtl::is<Wres::WrDyn>(std::get<0>(_m)) && prism_rtl::is<ast::PatternKind::PName>(std::get<1>(_m)) ? ({
            auto&& ex = prism_rtl::as<Wres::WrDyn>(std::get<0>(_m)).a0;
            auto&& rds = prism_rtl::as<Wres::WrDyn>(std::get<0>(_m)).a1;
            auto&& t = prism_rtl::as<Wres::WrDyn>(std::get<0>(_m)).a2;
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(std::get<1>(_m)).a0;
            ({
            auto b = Bn(Bn::BnDyn{ex, rds, t});
            (prism_rtl::finished(std::tuple{wx3, bind(benv_1, check_env::sname_key(n), b), bind(menv_3, check_env::sname_key(n), b)}));
        });
        })
            : prism_rtl::is<Wres::WrHosted>(std::get<0>(_m)) && prism_rtl::is<ast::PatternKind::PTuple>(std::get<1>(_m)) ? ({
            auto&& inner = prism_rtl::as<Wres::WrHosted>(std::get<0>(_m)).a0;
            auto&& doc = prism_rtl::as<Wres::WrHosted>(std::get<0>(_m)).a1;
            auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(std::get<1>(_m)).a0;
            prism_rtl::finished(bind_hosted(wx3, benv_1, menv_3, inner, doc, ps));
        })
            : prism_rtl::finished(std::tuple{wx3, benv_1, menv_3});
        });
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<ast::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        auto&& init = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
        auto&& step_ = prism_rtl::some_of(prism_rtl::as<ast::StmtKind::SBind>(_m).a2);
        ({
        auto benv_1 = benv;
        auto init_2 = init;
        auto menv_3 = menv;
        auto p__4 = p_;
        auto step__5 = step_;
        auto wx_6 = wx;
        call_then(start_hold_line(wx_6, benv_1, menv_3, p__4, init_2, step__5), [=](std::tuple<Wx, Env> hold_line_203047) {
        return ({
            auto [wx2, be2] = hold_line_203047;
            (prism_rtl::finished(std::tuple{wx2, be2, menv_3}));
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SIgnore>(_m) ? ({
        auto&& e = prism_rtl::as<ast::StmtKind::SIgnore>(_m).a0;
        ({
        auto benv_1 = benv;
        auto e_2 = e;
        auto menv_3 = menv;
        auto wx_4 = wx;
        call_then(start_build_line(wx_4, benv_1, menv_3, e_2, std::optional<Bn>{}), [=](std::tuple<Wx, Wres> build_line_203170) {
        return ({
            auto&& _wx2 = build_line_203170;
            auto&& wx2 = std::get<0>(_wx2);
            (prism_rtl::finished(std::tuple{wx2, benv_1, menv_3}));
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
        ({
        auto benv_1 = benv;
        auto e_2 = e;
        auto menv_3 = menv;
        auto p__4 = p_;
        auto wx_5 = wx;
        call_then(start_let_line(wx_5, benv_1, menv_3, p__4, e_2), [=](std::tuple<Wx, Env> let_line_203293) {
        return ({
            auto [wx2, be2] = let_line_203293;
            (prism_rtl::finished(std::tuple{wx2, be2, menv_3}));
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
        auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EFreeSigil>(_m) && ({
        auto&& m203370_0_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
        (m203370_0_0 == Text::lit("@"));
    }) ? ({
        auto&& m203370_0_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
        ({
        auto benv_1 = benv;
        auto menv_2 = menv;
        auto wx_3 = wx;
        auto x_4 = x;
        call_then(start_result_of(wx_3, benv_1, menv_2, x_4), [=](std::tuple<Wres, Wx> result_of_203450) {
        return ({
            auto [res, wx2] = result_of_203450;
            auto wx3 = ({
                Wx this_ = wx2;
                this_.result = res;
                this_;
            });
            (prism_rtl::finished(std::tuple{wx3, benv_1, menv_2}));
        });
    });
    });
    })
        : ({
        auto benv_1 = benv;
        auto e_2 = e;
        auto last_3 = last;
        auto menv_4 = menv;
        auto wx_5 = wx;
        call_then(start_build_line(wx_5, benv_1, menv_4, e_2, std::optional<Bn>{}), [=](std::tuple<Wx, Wres> build_line_203646) {
        return ({
            auto [wx2, res] = build_line_203646;
            auto wx3 = last_3 ? set_result(wx2, res) : wx2;
            (prism_rtl::finished(std::tuple{wx3, benv_1, menv_4}));
        });
    });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SEmit>(_m) ? prism_rtl::finished(std::tuple{wx, benv, menv})
        : prism_rtl::is<ast::StmtKind::SSignature>(_m) ? prism_rtl::finished(std::tuple{wx, benv, menv})
        : prism_rtl::is<ast::StmtKind::SFn>(_m) ? ({
        auto&& c = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
        prism_rtl::finished(std::tuple{wx, benv, menv});
    })
        : ({
        auto wx2 = ({
            Wx this_ = wx;
            this_.build = prelude::push(this_.build, refusal_do(Text::lit("a statement this back end does not lower yet")));
            this_;
        });
        (prism_rtl::finished(std::tuple{wx2, benv, menv}));
    });
    });
}


/// `Start WidgetStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Env, Env>> start_widget_stmt(Wx wx, Env benv, Env menv, ast::Stmt s, bool last) {
    return prism_rtl::make_rc<WidgetStmt>(wx, benv, menv, s, last);
}


/// BindHosted: fn Wx, Env, Env, Wres, Bn, [Pattern] -> ((Wx, Env, Env))
std::tuple<Wx, Env, Env> bind_hosted(const Wx& wx, const Env& benv, const Env& menv, const Wres& res, const Bn& doc, const Array<ast::Pattern_>& ps) {
    auto r_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Bn>> _v;
        if (prism_rtl::is<Wres::WrEv>(res)) {
            auto&& r = prism_rtl::as<Wres::WrEv>(res).a0;
            _v.set(std::optional(Bn(Bn::BnEv{r, OutTy(OutTy::OutUnit{})})));
            goto _done;
        }
        if (prism_rtl::is<Wres::WrDyn>(res)) {
            auto&& ex = prism_rtl::as<Wres::WrDyn>(res).a0;
            auto&& rds = prism_rtl::as<Wres::WrDyn>(res).a1;
            auto&& t = prism_rtl::as<Wres::WrDyn>(res).a2;
            _v.set(std::optional(Bn(Bn::BnDyn{ex, rds, t})));
            goto _done;
        }
        {
            _v.set(std::optional<Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [be1, me1] = bind_part(benv, menv, index(ps, Nat(0u)), r_opt);
    return bind_part2(wx, be1, me1, index(ps, Nat(1u)), std::optional(doc));
}


/// BindPart: fn Env, Env, ?Pattern, ?Bn -> ((Env, Env))
std::tuple<Env, Env> bind_part(const Env& benv, const Env& menv, const std::optional<ast::Pattern_>& p__opt, const std::optional<Bn>& b_opt) {
    auto&& _m = std::tuple{p__opt, b_opt};
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        auto&& p_ = prism_rtl::some_of(std::get<0>(_m));
        auto&& b = prism_rtl::some_of(std::get<1>(_m));
        auto&& _m = p_.kind;
        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
            return std::tuple{bind(benv, check_env::sname_key(n), b), bind(menv, check_env::sname_key(n), b)};
        }
        {
            return std::tuple{benv, menv};
        }
    }
    {
        return std::tuple{benv, menv};
    }
}


/// BindPart2: fn Wx, Env, Env, ?Pattern, ?Bn -> ((Wx, Env, Env))
std::tuple<Wx, Env, Env> bind_part2(const Wx& wx, const Env& benv, const Env& menv, const std::optional<ast::Pattern_>& p__opt, const std::optional<Bn>& b_opt) {
    auto [be, me] = bind_part(benv, menv, p__opt, b_opt);
    return std::tuple{wx, be, me};
}


/// SetResult: fn Wx, Wres -> Wx
Wx set_result(const Wx& wx, const Wres& res) {
    Wx this_ = wx;
    this_.result = res;
    return this_;
}


/// ResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
std::tuple<Wres, Wx> result_of(const Wx& wx, const Env& benv, const Env& menv, const ast::Expr& x) {
    auto lx = wx.lx;
    auto full = type_at(lx, x.span);
    auto t = out_ty_of(lx, peel(full));
    auto bound_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Bn>> _v;
        auto&& _m = x.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(len(n->path_) == Nat(1u)
                ? prelude::get(menv->names, check_env::sname_key(n))
                : std::optional<Bn>{});
            goto _done;
        }
        {
            _v.set(std::optional<Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
        auto&& r = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
        return std::tuple{Wres(Wres::WrEv{r}), wx};
    }
    if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnDyn>(prism_rtl::some_of(bound_opt))) {
        auto&& ex = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a0;
        auto&& rds = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a1;
        auto&& bt = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a2;
        return std::tuple{Wres(Wres::WrDyn{ex, rds, bt}), wx};
    }
    {
        return result_of_typed(wx, benv, menv, x, full, t);
    }
}


prism_rtl::Turn<std::tuple<Wres, Wx>> ResultOf::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& x = this->x;
    auto lx = wx.lx;
    auto full = type_at(lx, x.span);
    auto benv_1 = benv;
    auto menv_2 = menv;
    auto wx_3 = wx;
    auto x_4 = x;
    return call_then(start_out_ty_of(lx, peel(full)), [=](OutTy out_ty_of_205558) {
        return ({
            auto t = out_ty_of_205558;
            auto bound_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<Bn>> _v;
                auto&& _m = x_4.kind;
                if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                    auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                    _v.set(len(n->path_) == Nat(1u)
                        ? prelude::get(menv_2->names, check_env::sname_key(n))
                        : std::optional<Bn>{});
                    goto _done;
                }
                {
                    _v.set(std::optional<Bn>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            ({
            prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(bound_opt)) ? ({
            auto&& r = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
            prism_rtl::finished(std::tuple{Wres(Wres::WrEv{r}), wx_3});
        })
            : prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnDyn>(prism_rtl::some_of(bound_opt)) ? ({
            auto&& ex = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a0;
            auto&& rds = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a1;
            auto&& bt = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a2;
            prism_rtl::finished(std::tuple{Wres(Wres::WrDyn{ex, rds, bt}), wx_3});
        })
            : prism_rtl::more(prism_rtl::rc(ResultOfTyped(wx_3, benv_1, menv_2, x_4, full, t)));
        });
        });
    });
}


/// `Start ResultOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wres, Wx>> start_result_of(Wx wx, Env benv, Env menv, ast::Expr x) {
    return prism_rtl::make_rc<ResultOf>(wx, benv, menv, x);
}


/// ResultOfTyped: unbounded fn Wx, Env, Env, Expr, Ty, OutTy -> ((Wres, Wx))
std::tuple<Wres, Wx> result_of_typed(const Wx& wx, const Env& benv, const Env& menv, const ast::Expr& x, const check_types::Ty& full, const OutTy& t) {
    auto lx = wx.lx;
    auto&& _m = layer_of(full);
    if (prism_rtl::is<Layer::LyEv>(_m)) {
        auto [r, wx2] = event_ref(wx, menv, x);
        return std::tuple{Wres(Wres::WrEv{r}), wx2};
    }
    if (prism_rtl::is<Layer::LyDyn>(_m)) {
        auto [ex, reads] = dynamic_expr(wx, menv, x);
        return std::tuple{Wres(Wres::WrDyn{ex, reads, t}), wx};
    }
    {
        return t == OutTy(OutTy::OutUnit{})
            ? std::tuple{Wres(Wres::WrUnit{}), wx}
            : std::tuple{Wres(Wres::WrPlain{own(value_of(lx, benv, x)), t}), wx};
    }
}


prism_rtl::Turn<std::tuple<Wres, Wx>> ResultOfTyped::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& x = this->x;
    const auto& full = this->full;
    const auto& t = this->t;
    auto lx = wx.lx;
    return ({
        auto&& _m = layer_of(full);
        prism_rtl::is<Layer::LyEv>(_m) ? ({
        auto menv_1 = menv;
        auto wx_2 = wx;
        auto x_3 = x;
        call_then(start_event_ref(wx_2, menv_1, x_3), [=](std::tuple<EvRef, Wx> event_ref_206094) {
        return ({
            auto [r, wx2] = event_ref_206094;
            (prism_rtl::finished(std::tuple{Wres(Wres::WrEv{r}), wx2}));
        });
    });
    })
        : prism_rtl::is<Layer::LyDyn>(_m) ? ({
        auto menv_1 = menv;
        auto t_2 = t;
        auto wx_3 = wx;
        auto x_4 = x;
        call_then(start_dynamic_expr(wx_3, menv_1, x_4), [=](std::tuple<Ex, Array<Read>> dynamic_expr_206190) {
        return ({
            auto [ex, reads] = dynamic_expr_206190;
            (prism_rtl::finished(std::tuple{Wres(Wres::WrDyn{ex, reads, t_2}), wx_3}));
        });
    });
    })
        : t == OutTy(OutTy::OutUnit{})
        ? prism_rtl::finished(std::tuple{Wres(Wres::WrUnit{}), wx})
        : ({
        auto benv_1 = benv;
        auto t_2 = t;
        auto wx_3 = wx;
        auto x_4 = x;
        call_then(start_value_of(lx, benv_1, x_4), [=](Vl value_of_206353) { return prism_rtl::finished(std::tuple{Wres(Wres::WrPlain{own(value_of_206353), t_2}), wx_3}); });
    });
    });
}


/// `Start ResultOfTyped, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wres, Wx>> start_result_of_typed(Wx wx, Env benv, Env menv, ast::Expr x, check_types::Ty full, OutTy t) {
    return prism_rtl::make_rc<ResultOfTyped>(wx, benv, menv, x, full, t);
}


/// HoldLine: unbounded fn Wx, Env, Env, Pattern, Expr, Expr -> ((Wx, Env))
std::tuple<Wx, Env> hold_line(const Wx& wx, const Env& benv, const Env& menv, const ast::Pattern_& p_, const ast::Expr& init, const ast::Expr& step_) {
    auto lx = wx.lx;
    auto&& _m = binding_of(menv, p_);
    if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnHold>(prism_rtl::some_of(_m))) {
        auto&& f = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(_m)).a0;
        auto&& t = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(_m)).a1;
        auto iv = own(value_of(lx, benv, init));
        auto wx1 = add_field(wx, f, OutTy(OutTy::OutHold{prism_rtl::rc(t)}), prism_rtl::cat("`", pat_text(p_), "`"), Ex(Ex::XCall{Text::lit("Hold::new"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{prism_rtl::cat(f, "_init")}))}), Ex(Ex::XCx{})})}));
        auto [r, wx2] = event_ref(wx1, menv, step_);
        auto wx3 = ({
            Wx this_ = connect(wx2, r, Sk(Sk::SkHold{f}));
            this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{prism_rtl::cat(f, "_init")})), t}), iv}));
            this_.inited = prelude::push(this_.inited, f);
            this_;
        });
        return std::tuple{wx3, bind(benv, prism_rtl::cat(pat_text(p_), "#init"), Bn(Bn::BnLocal{Ex(Ex::XVar{prism_rtl::cat(f, "_init")}), Holding(Holding::Owned{}), t}))};
    }
    {
        return std::tuple{wx, benv};
    }
}


prism_rtl::Turn<std::tuple<Wx, Env>> HoldLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& p_ = this->p_;
    const auto& init = this->init;
    const auto& step_ = this->step_;
    auto lx = wx.lx;
    return ({
        auto&& _m = binding_of(menv, p_);
        prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnHold>(prism_rtl::some_of(_m)) ? ({
        auto&& f = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(_m)).a0;
        auto&& t = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(_m)).a1;
        ({
        auto benv_1 = benv;
        auto init_2 = init;
        auto menv_3 = menv;
        auto p__4 = p_;
        auto step__5 = step_;
        auto wx_6 = wx;
        call_then(start_value_of(lx, benv_1, init_2), [=](Vl value_of_206908) {
        return ({
            auto iv = own(value_of_206908);
            auto wx1 = add_field(wx_6, f, OutTy(OutTy::OutHold{prism_rtl::rc(t)}), prism_rtl::cat("`", pat_text(p__4), "`"), Ex(Ex::XCall{Text::lit("Hold::new"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{prism_rtl::cat(f, "_init")}))}), Ex(Ex::XCx{})})}));
            call_then(start_event_ref(wx1, menv_3, step__5), [=](std::tuple<EvRef, Wx> event_ref_207086) {
            return ({
                auto [r, wx2] = event_ref_207086;
                auto wx3 = ({
                    Wx this_ = connect(wx2, r, Sk(Sk::SkHold{f}));
                    this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{prism_rtl::cat(f, "_init")})), t}), iv}));
                    this_.inited = prelude::push(this_.inited, f);
                    this_;
                });
                (prism_rtl::finished(std::tuple{wx3, bind(benv_1, prism_rtl::cat(pat_text(p__4), "#init"), Bn(Bn::BnLocal{Ex(Ex::XVar{prism_rtl::cat(f, "_init")}), Holding(Holding::Owned{}), t}))}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{wx, benv});
    });
}


/// `Start HoldLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Env>> start_hold_line(Wx wx, Env benv, Env menv, ast::Pattern_ p_, ast::Expr init, ast::Expr step_) {
    return prism_rtl::make_rc<HoldLine>(wx, benv, menv, p_, init, step_);
}


/// InitEnv: fn Env -> Env
Env init_env(const Env& env) {
    return fold(keys(env->names), env, [&](const Env& en, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Env> _v;
            auto&& _m = std::tuple{lexer::before_suffix(k, Text::lit("#init")), prelude::get(env->names, k)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& name = prism_rtl::some_of(std::get<0>(_m));
                auto&& b = prism_rtl::some_of(std::get<1>(_m));
                _v.set(bind(en, name, b));
                goto _done;
            }
            {
                _v.set(en);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// AllInited: fn Wx, [Read] -> Bool
bool all_inited(const Wx& wx, const Array<Read>& reads) {
    return fold(reads_closed(wx.dyn_reads, reads), true, [&](const bool& ok, const Read& r) {
        return ok && ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is<Read::OwnRead>(r)) {
                auto&& f = prism_rtl::as<Read::OwnRead>(r).a0;
                _v.set(check_types::has_text(wx.inited, f));
                goto _done;
            }
            if (prism_rtl::is<Read::ParentRead>(r)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// PatText: fn Pattern -> Text
Text pat_text(const ast::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        return check_env::sname_key(n);
    }
    {
        return Text::lit("_");
    }
}


/// LetLine: unbounded fn Wx, Env, Env, Pattern, Expr -> ((Wx, Env))
std::tuple<Wx, Env> let_line(const Wx& wx, const Env& benv, const Env& menv, const ast::Pattern_& p_, const ast::Expr& e) {
    auto lx = wx.lx;
    auto&& _m = binding_of(menv, p_);
    if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(_m))) {
        auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(_m)).a0;
        auto&& t = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(_m)).a1;
        auto [r, wx2] = event_ref(wx, menv, e);
        auto fed = out_ty_of(lx, peel(peel(type_at(lx, e.span))));
        auto r2 = ({
            __label__ _done;
            prism_rtl::Slot<EvRef> _v;
            if (prism_rtl::is<OutTy::OutEvent>(t)) {
                auto&& m208878_0_0 = prism_rtl::as<OutTy::OutEvent>(t).a0;
                if (prism_rtl::is<OutTy::OutRes>(m208878_0_0)) {
                    _v.set(fed == OutTy(OutTy::OutError{}) ? err_pipe(r) : r);
                    goto _done;
                }
            }
            if (prism_rtl::is<OutTy::OutRes>(t)) {
                _v.set(fed == OutTy(OutTy::OutError{}) ? err_pipe(r) : r);
                goto _done;
            }
            {
                _v.set(r);
                goto _done;
            }
        _done:
            _v.take();
        });
        return std::tuple{connect(wx2, r2, Sk(Sk::SkNode{er.node_})), benv};
    }
    if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnDyn>(prism_rtl::some_of(_m))) {
        auto&& t = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
        auto rs = snake(pat_text(p_));
        auto [ex, reads] = dynamic_expr(wx, menv, e);
        auto getter = MethDef{.name = rs, .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = t, .body = Array<Do>{}, .tail = ex, .doc = prism_rtl::cat("`", pat_text(p_), "`")};
        auto wx2 = ({
            Wx this_ = wx;
            this_.getters = prelude::push(this_.getters, getter);
            this_.dyn_reads = insert(this_.dyn_reads, rs, reads);
            this_;
        });
        return all_inited(wx2, reads)
            ? ({
            auto wx3 = ({
                Wx this_ = wx2;
                this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{prism_rtl::cat(rs, "_init")})), t}), own(value_of(lx, init_env(benv), e))}));
                this_.inited = prelude::push(this_.inited, rs);
                this_;
            });
            std::tuple{wx3, bind(benv, prism_rtl::cat(pat_text(p_), "#init"), Bn(Bn::BnLocal{Ex(Ex::XVar{prism_rtl::cat(rs, "_init")}), Holding(Holding::Owned{}), t}))};
        })
            : std::tuple{wx2, benv};
    }
    if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
        auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
        auto&& t = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
        auto insts_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>> _v;
            auto&& _m = p_.kind;
            if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                _v.set(many_instances(lx, n.span));
                goto _done;
            }
            {
                _v.set(std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        if (prism_rtl::is_some(insts_opt)) {
            auto&& insts = prism_rtl::some_of(insts_opt);
            auto&& _m = p_.kind;
            if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                auto nkey = check_env::sname_key(n);
                auto wxn = run_to_end(fold_job(check_errors::range0(len(insts)), wx, ({
                    auto lx_1 = lx;
                    auto insts_2 = insts;
                    auto nkey_3 = nkey;
                    auto menv_4 = menv;
                    auto benv_5 = benv;
                    auto e_6 = e;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Wx>(std::tuple<Wx, Nat>)>>(prism_rtl::rc([=](std::tuple<Wx, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto lx_1_7 = lx_1;
                        auto insts_2_7 = insts_2;
                        auto nkey_3_7 = nkey_3;
                        auto menv_4_7 = menv_4;
                        auto benv_5_7 = benv_5;
                        auto e_6_7 = e_6;
                        entered(once_job([=]() {
                        return ({
                            auto w = p0;
                            auto k = p1;
                            ({
                            auto lxk = at_instance(lx_1_7, or_(index(insts_2_7, k), std::tuple{Array<std::tuple<Text, check_types::Ty>>{}, Array<std::tuple<Text, check_types::Col>>{}}));
                            auto bkey = k == Nat(0u) ? nkey_3_7 : prism_rtl::cat(nkey_3_7, "#inst", k);
                            ({
                            auto&& _m = prelude::get(menv_4_7->names, bkey);
                            prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
                            auto&& rk = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                            auto&& tk = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                            call_then(start_value_of(lxk, benv_5_7, e_6_7), [=](Vl value_of_210681) { return prism_rtl::finished(widget_let_field(w, place_stem(rk), tk, own(value_of_210681), prism_rtl::cat("`", nkey_3_7, "` at its instantiation ", k))); });
                        })
                            : prism_rtl::finished(({
                            Wx this_ = w;
                            this_.build = prelude::push(this_.build, refusal_do(prism_rtl::cat("`", nkey_3_7, "` at its instantiation ", k, ", which has no binding")));
                            this_;
                        }));
                        });
                        });
                        });
                    }));
                    });
                })));
                })));
                return std::tuple{wxn, benv};
            }
            {
                return std::tuple{wx, benv};
            }
        }
        if (prism_rtl::is_none(insts_opt)) {
            auto lxw = ({
                __label__ _done;
                prism_rtl::Slot<Lx> _v;
                auto&& _m = p_.kind;
                if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                    auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                    _v.set(widget_let_lx(lx, n.span));
                    goto _done;
                }
                {
                    _v.set(lx);
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto v_ = own(value_of(lxw, benv, e));
            return std::tuple{widget_let_field(wx, place_stem(rs), t, v_, prism_rtl::cat("`", pat_text(p_), "`")), benv};
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return std::tuple{wx, benv};
    }
}


prism_rtl::Turn<std::tuple<Wx, Env>> LetLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& p_ = this->p_;
    const auto& e = this->e;
    auto lx = wx.lx;
    return ({
        auto&& _m = binding_of(menv, p_);
        prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(_m)) ? ({
        auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(_m)).a0;
        auto&& t = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(_m)).a1;
        ({
        auto benv_1 = benv;
        auto e_2 = e;
        auto menv_3 = menv;
        auto wx_4 = wx;
        call_then(start_event_ref(wx_4, menv_3, e_2), [=](std::tuple<EvRef, Wx> event_ref_208768) {
        return ({
            auto [r, wx2] = event_ref_208768;
            call_then(start_out_ty_of(lx, peel(peel(type_at(lx, e_2.span)))), [=](OutTy out_ty_of_208811) {
            return ({
                auto fed = out_ty_of_208811;
                auto r2 = ({
                    __label__ _done;
                    prism_rtl::Slot<EvRef> _v;
                    if (prism_rtl::is<OutTy::OutEvent>(t)) {
                        auto&& m208878_0_0 = prism_rtl::as<OutTy::OutEvent>(t).a0;
                        if (prism_rtl::is<OutTy::OutRes>(m208878_0_0)) {
                            _v.set(fed == OutTy(OutTy::OutError{}) ? err_pipe(r) : r);
                            goto _done;
                        }
                    }
                    if (prism_rtl::is<OutTy::OutRes>(t)) {
                        _v.set(fed == OutTy(OutTy::OutError{}) ? err_pipe(r) : r);
                        goto _done;
                    }
                    {
                        _v.set(r);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                (prism_rtl::finished(std::tuple{connect(wx2, r2, Sk(Sk::SkNode{er.node_})), benv_1}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnDyn>(prism_rtl::some_of(_m)) ? ({
        auto&& t = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
        ({
        auto rs = snake(pat_text(p_));
        auto benv_1 = benv;
        auto e_2 = e;
        auto menv_3 = menv;
        auto p__4 = p_;
        auto wx_5 = wx;
        call_then(start_dynamic_expr(wx_5, menv_3, e_2), [=](std::tuple<Ex, Array<Read>> dynamic_expr_209231) {
        return ({
            auto [ex, reads] = dynamic_expr_209231;
            auto getter = MethDef{.name = rs, .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = t, .body = Array<Do>{}, .tail = ex, .doc = prism_rtl::cat("`", pat_text(p__4), "`")};
            auto wx2 = ({
                Wx this_ = wx_5;
                this_.getters = prelude::push(this_.getters, getter);
                this_.dyn_reads = insert(this_.dyn_reads, rs, reads);
                this_;
            });
            all_inited(wx2, reads)
            ? ({
            auto wx3 = ({
                Wx this_ = wx2;
                this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{prism_rtl::cat(rs, "_init")})), t}), own(value_of(lx, init_env(benv_1), e_2))}));
                this_.inited = prelude::push(this_.inited, rs);
                this_;
            });
            (prism_rtl::finished(std::tuple{wx3, bind(benv_1, prism_rtl::cat(pat_text(p__4), "#init"), Bn(Bn::BnLocal{Ex(Ex::XVar{prism_rtl::cat(rs, "_init")}), Holding(Holding::Owned{}), t}))}));
        })
            : prism_rtl::finished(std::tuple{wx2, benv_1});
        });
    });
    });
    })
        : prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
        auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
        auto&& t = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
        ({
        auto insts_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>> _v;
            auto&& _m = p_.kind;
            if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                _v.set(many_instances(lx, n.span));
                goto _done;
            }
            {
                _v.set(std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        prism_rtl::is_some(insts_opt) ? ({
        auto&& insts = prism_rtl::some_of(insts_opt);
        ({
        auto&& _m = p_.kind;
        prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        ({
        auto nkey = check_env::sname_key(n);
        auto benv_1 = benv;
        auto e_2 = e;
        auto insts_3 = insts;
        auto menv_4 = menv;
        auto wx_5 = wx;
        call_value(fold_job(check_errors::range0(len(insts_3)), wx_5, ({
        auto lx_6 = lx;
        auto insts_3_7 = insts_3;
        auto nkey_7 = nkey;
        auto menv_4_8 = menv_4;
        auto benv_1_8 = benv_1;
        auto e_2_8 = e_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Wx>(std::tuple<Wx, Nat>)>>(prism_rtl::rc([=](std::tuple<Wx, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_6_8 = lx_6;
            auto insts_3_7_8 = insts_3_7;
            auto nkey_7_8 = nkey_7;
            auto menv_4_8_8 = menv_4_8;
            auto benv_1_8_8 = benv_1_8;
            auto e_2_8_8 = e_2_8;
            entered(once_job([=]() {
            return ({
                auto w = p0;
                auto k = p1;
                ({
                auto lxk = at_instance(lx_6_8, or_(index(insts_3_7_8, k), std::tuple{Array<std::tuple<Text, check_types::Ty>>{}, Array<std::tuple<Text, check_types::Col>>{}}));
                auto bkey = k == Nat(0u) ? nkey_7_8 : prism_rtl::cat(nkey_7_8, "#inst", k);
                ({
                auto&& _m = prelude::get(menv_4_8_8->names, bkey);
                prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
                auto&& rk = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& tk = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                call_then(start_value_of(lxk, benv_1_8_8, e_2_8_8), [=](Vl value_of_210681) { return prism_rtl::finished(widget_let_field(w, place_stem(rk), tk, own(value_of_210681), prism_rtl::cat("`", nkey_7_8, "` at its instantiation ", k))); });
            })
                : prism_rtl::finished(({
                Wx this_ = w;
                this_.build = prelude::push(this_.build, refusal_do(prism_rtl::cat("`", nkey_7_8, "` at its instantiation ", k, ", which has no binding")));
                this_;
            }));
            });
            });
            });
        }));
        });
    })));
    })), [=](Wx fold_210325) {
        return ({
            auto wxn = fold_210325;
            (prism_rtl::finished(std::tuple{wxn, benv_1}));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{wx, benv});
    });
    })
        : prism_rtl::is_none(insts_opt) ? ({
        auto lxw = ({
            __label__ _done;
            prism_rtl::Slot<Lx> _v;
            auto&& _m = p_.kind;
            if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                _v.set(widget_let_lx(lx, n.span));
                goto _done;
            }
            {
                _v.set(lx);
                goto _done;
            }
        _done:
            _v.take();
        });
        auto benv_1 = benv;
        auto e_2 = e;
        auto p__3 = p_;
        auto wx_4 = wx;
        call_then(start_value_of(lxw, benv_1, e_2), [=](Vl value_of_211201) {
        return ({
            auto v_ = own(value_of_211201);
            (prism_rtl::finished(std::tuple{widget_let_field(wx_4, place_stem(rs), t, v_, prism_rtl::cat("`", pat_text(p__3), "`")), benv_1}));
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::finished(std::tuple{wx, benv});
    });
}


/// `Start LetLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Env>> start_let_line(Wx wx, Env benv, Env menv, ast::Pattern_ p_, ast::Expr e) {
    return prism_rtl::make_rc<LetLine>(wx, benv, menv, p_, e);
}


/// WidgetLetField: fn Wx, Text, OutTy, Ex, Text -> Wx
Wx widget_let_field(const Wx& wx, const Text& f, const OutTy& t, const Ex& v_, const Text& doc) {
    Wx this_ = wx;
    this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaBind{f}), v_}));
    this_.fields = prelude::push(this_.fields, std::tuple{f, t, doc});
    this_.inits = prelude::push(this_.inits, std::tuple{f, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{f}))})});
    return this_;
}


/// ErrPipe: fn EvRef -> EvRef
EvRef err_pipe(const EvRef& r) {
    return EvRef{.node_ = r.node_, .owner = r.owner, .pipe = ({
        auto r_1 = r;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>)>>(prism_rtl::rc([=](std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto r_1_2 = r_1;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                auto k_fn = p1;
                r_1_2.pipe(std::tuple{x, ({
                auto k_fn_2 = k_fn;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>(prism_rtl::rc([=](Ex p0) {
                return ({
                    auto k_fn_2_3 = k_fn_2;
                    entered(once_job([=]() {
                    return ({
                        auto y = p0;
                        k_fn_2_3(Ex(Ex::XCtor{Text::lit("Err"), Array(std::vector{y})}))->cycle();
                    });
                }));
                });
            })));
            })})->cycle();
            });
        }));
        });
    })));
    })};
}


/// OwnAs: fn OutTy, Vl -> Ex
Ex own_as(const OutTy& t, const Vl& v_) {
    if (prism_rtl::is<OutTy::OutRes>(t)) {
        return value_ty(v_) == OutTy(OutTy::OutError{})
            ? Ex(Ex::XCtor{Text::lit("Err"), Array(std::vector{own(v_)})})
            : own(v_);
    }
    {
        return own(v_);
    }
}


/// BindRes: fn Wx, Env, Pattern, Wres -> Wx
Wx bind_res(const Wx& wx2, const Env& menv, const ast::Pattern_& p_, const Wres& res) {
    auto&& _m = binding_of(menv, p_);
    if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(_m))) {
        auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(_m)).a0;
        if (prism_rtl::is<Wres::WrEv>(res)) {
            auto&& r = prism_rtl::as<Wres::WrEv>(res).a0;
            return er.owner != wx2.node_
                ? crossed(wx2, prism_rtl::cat("the bound event of node `", er.owner, "` (its graph node ", er.node_, ")"))
                : r.node_ == er.node_ ? wx2 : connect(wx2, r, Sk(Sk::SkNode{er.node_}));
        }
        {
            return wx2;
        }
    }
    {
        return wx2;
    }
}


/// BuildLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> build_line(const Wx& wx, const Env& benv, const Env& menv, const ast::Expr& e, const std::optional<Bn>& bound_opt) {
    auto lx = wx.lx;
    auto full = type_at(lx, e.span);
    auto&& _m = e.kind;
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        return build_line(wx, benv, menv, x, bound_opt);
    }
    if (prism_rtl::is<ast::ExprKind::EWidgetBlock>(_m)) {
        auto&& b = prism_rtl::as<ast::ExprKind::EWidgetBlock>(_m).a0;
        return inline_block(wx, benv, menv, b, lx);
    }
    if (prism_rtl::is<ast::ExprKind::EFor>(_m)) {
        auto&& binders_opt = prism_rtl::as<ast::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<ast::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<ast::ExprKind::EFor>(_m).a2;
        return for_line(wx, benv, menv, binders_opt, source, body, e, bound_opt);
    }
    if (prism_rtl::is<ast::ExprKind::ERebuild>(_m)) {
        auto&& scrut = prism_rtl::as<ast::ExprKind::ERebuild>(_m).a0;
        auto&& body = prism_rtl::as<ast::ExprKind::ERebuild>(_m).a1;
        return rebuild_line(wx, benv, menv, scrut, body, e, bound_opt);
    }
    if (prism_rtl::is<ast::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::EIf>(_m).a2)) {
        auto&& m212978_4_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
        if (prism_rtl::is<ast::Cond::CondExpr>(m212978_4_0)) {
            auto&& c = prism_rtl::as<ast::Cond::CondExpr>(m212978_4_0).a0;
            return if_gen_line(wx, menv, c, then_b, else_b, e);
        }
    }
    {
        auto&& _m = peel(full);
        if (prism_rtl::is<check_types::Ty::TyElem>(_m)) {
            return element_line(wx, benv, menv, e, bound_opt);
        }
        if (prism_rtl::is<check_types::Ty::TyAt>(_m)) {
            return widget_line(wx, benv, menv, e, bound_opt);
        }
        {
            auto wx2 = ({
                Wx this_ = wx;
                this_.build = prelude::push(this_.build, refusal_do(Text::lit("a building line this back end does not lower yet")));
                this_;
            });
            return std::tuple{wx2, Wres(Wres::WrUnit{})};
        }
    }
}


prism_rtl::Turn<std::tuple<Wx, Wres>> BuildLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& e = this->e;
    const auto& bound_opt = this->bound_opt;
    auto lx = wx.lx;
    auto full = type_at(lx, e.span);
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BuildLine(wx, benv, menv, x, bound_opt)));
    })
        : prism_rtl::is<ast::ExprKind::EWidgetBlock>(_m) ? ({
        auto&& b = prism_rtl::as<ast::ExprKind::EWidgetBlock>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InlineBlock(wx, benv, menv, b, lx)));
    })
        : prism_rtl::is<ast::ExprKind::EFor>(_m) ? ({
        auto&& binders_opt = prism_rtl::as<ast::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<ast::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<ast::ExprKind::EFor>(_m).a2;
        prism_rtl::more(prism_rtl::rc(ForLine(wx, benv, menv, binders_opt, source, body, e, bound_opt)));
    })
        : prism_rtl::is<ast::ExprKind::ERebuild>(_m) ? ({
        auto&& scrut = prism_rtl::as<ast::ExprKind::ERebuild>(_m).a0;
        auto&& body = prism_rtl::as<ast::ExprKind::ERebuild>(_m).a1;
        prism_rtl::more(prism_rtl::rc(RebuildLine(wx, benv, menv, scrut, body, e, bound_opt)));
    })
        : prism_rtl::is<ast::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::EIf>(_m).a2) && ({
        auto&& m212978_4_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
        prism_rtl::is<ast::Cond::CondExpr>(m212978_4_0);
    }) ? ({
        auto&& m212978_4_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
        auto&& c = prism_rtl::as<ast::Cond::CondExpr>(m212978_4_0).a0;
        prism_rtl::more(prism_rtl::rc(IfGenLine(wx, menv, c, then_b, else_b, e)));
    })
        : ({
        auto&& _m = peel(full);
        prism_rtl::is<check_types::Ty::TyElem>(_m) ? prism_rtl::more(prism_rtl::rc(ElementLine(wx, benv, menv, e, bound_opt)))
        : prism_rtl::is<check_types::Ty::TyAt>(_m) ? prism_rtl::more(prism_rtl::rc(WidgetLine(wx, benv, menv, e, bound_opt)))
        : ({
        auto wx2 = ({
            Wx this_ = wx;
            this_.build = prelude::push(this_.build, refusal_do(Text::lit("a building line this back end does not lower yet")));
            this_;
        });
        (prism_rtl::finished(std::tuple{wx2, Wres(Wres::WrUnit{})}));
    });
    });
    });
}


/// `Start BuildLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Wres>> start_build_line(Wx wx, Env benv, Env menv, ast::Expr e, std::optional<Bn> bound_opt) {
    return prism_rtl::make_rc<BuildLine>(wx, benv, menv, e, bound_opt);
}


/// ElementLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> element_line(const Wx& wx, const Env& benv, const Env& menv, const ast::Expr& e, const std::optional<Bn>& bound_opt) {
    auto lx = wx.lx;
    auto [tag_name, args] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Array<ast::Arg>>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& xs = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{tag_name_of(lx, c), xs});
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(std::tuple{tag_name_of(lx, e), Array<ast::Arg>{}});
            goto _done;
        }
        {
            _v.set(std::tuple{Text::lit(""), Array<ast::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto full = type_at(lx, e.span);
    auto&& _m = prelude::get(lx.g.tags, tag_name);
    if (prism_rtl::is_none(_m)) {
        auto wx2 = ({
            Wx this_ = wx;
            this_.build = prelude::push(this_.build, refusal_do(Text::lit("an element of an unknown tag")));
            this_;
        });
        return std::tuple{wx2, Wres(Wres::WrUnit{})};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& tg = prism_rtl::some_of(_m);
        auto pos = wx.pos;
        auto wx1 = ({
            Wx this_ = wx;
            this_.pos = next_pos(this_.pos);
            this_;
        });
        auto struct_path = path_in(lx, tg.home, tag_struct(tg.name));
        auto [live_fields, const_fields, reads, wx2] = run_to_end(fold_job(tg.fields, std::tuple{Array<std::tuple<Text, Ex>>{}, Array<std::tuple<Text, Ex>>{}, Array<Read>{}, wx1}, ({
            auto args_1 = args;
            auto menv_2 = menv;
            auto pos_3 = pos;
            auto tg_4 = tg;
            auto lx_5 = lx;
            auto benv_6 = benv;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Ex>>, Array<std::tuple<Text, Ex>>, Array<Read>, Wx>>(std::tuple<std::tuple<Array<std::tuple<Text, Ex>>, Array<std::tuple<Text, Ex>>, Array<Read>, Wx>, std::tuple<Text, check_types::Ty>>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, Ex>>, Array<std::tuple<Text, Ex>>, Array<Read>, Wx>, std::tuple<Text, check_types::Ty>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto args_1_7 = args_1;
                auto menv_2_7 = menv_2;
                auto pos_3_7 = pos_3;
                auto tg_4_7 = tg_4;
                auto lx_5_7 = lx_5;
                auto benv_6_7 = benv_6;
                entered(once_job([=]() {
                return ({
                    auto [lf, cf, rd, w] = p0;
                    auto [fname, fty] = p1;
                    ({
                    auto&& _m = tag_arg(args_1_7, fname);
                    prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{lf, cf, rd, w})
                    : prism_rtl::is_some(_m) ? ({
                    auto&& arg = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = layer_of(fty);
                    prism_rtl::is<Layer::LyEv>(_m) ? call_then(start_event_ref(w, menv_2_7, arg), [=](std::tuple<EvRef, Wx> event_ref_215181) {
                    return ({
                        auto [r, w2] = event_ref_215181;
                        (prism_rtl::finished(std::tuple{lf, cf, rd, connect(w2, r, Sk(Sk::SkRequest{pos_3_7, request_field(tg_4_7, fname)}))}));
                    });
                })
                    : call_then(start_dynamic_expr(w, menv_2_7, arg), [=](std::tuple<Ex, Array<Read>> dynamic_expr_215399) {
                    return ({
                        auto [ex, rds] = dynamic_expr_215399;
                        call_then(start_value_of(lx_5_7, benv_6_7, arg), [=](Vl value_of_215470) {
                        return ({
                            auto cv = own(value_of_215470);
                            (prism_rtl::finished(std::tuple{prelude::push(lf, std::tuple{snake(fname), ex}), prelude::push(cf, std::tuple{snake(fname), cv}), union_reads(rd, rds), w}));
                        });
                    });
                    });
                });
                });
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        }));
        })));
        auto live = len(reads) > Nat(0u);
        auto [getter, wx3] = live
            ? fresh_name(wx2, snake(check_types::bare_name(tg.name)))
            : std::tuple{Text::lit(""), wx2};
        auto variant = variant_of(lx, tg);
        auto level = Ex(Ex::XCtor{variant, Array(std::vector{Ex(Ex::XRecord{struct_path, live ? live_fields : const_fields})})});
        auto at_build = Ex(Ex::XCtor{variant, Array(std::vector{Ex(Ex::XRecord{struct_path, const_fields})})});
        auto added = live
            ? Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")})), getter, Array(std::vector{Ex(Ex::XCx{})})})
            : level;
        auto wx4 = ({
            Wx this_ = wx3;
            this_.places = prelude::push(this_.places, Place{.pos = pos, .level = level, .getter = getter, .reads = reads});
            this_.build = emits(wx3, pos)
                ? prelude::push(this_.build, Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("added"), Array(std::vector{place_at(wx3, Text::lit("node"), pos), Ex(Ex::XMethod{prism_rtl::rc(added), Text::lit("to_pod"), Array<Ex>{}})})})}))
                : this_.build;
            this_;
        });
        return element_output(wx4, menv, tg, element_out(lx, tg, full), pos, bound_opt, at_build);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Wx, Wres>> ElementLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& e = this->e;
    const auto& bound_opt = this->bound_opt;
    auto lx = wx.lx;
    auto [tag_name, args] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Array<ast::Arg>>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& xs = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{tag_name_of(lx, c), xs});
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(std::tuple{tag_name_of(lx, e), Array<ast::Arg>{}});
            goto _done;
        }
        {
            _v.set(std::tuple{Text::lit(""), Array<ast::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto full = type_at(lx, e.span);
    return ({
        auto&& _m = prelude::get(lx.g.tags, tag_name);
        prism_rtl::is_none(_m) ? ({
        auto wx2 = ({
            Wx this_ = wx;
            this_.build = prelude::push(this_.build, refusal_do(Text::lit("an element of an unknown tag")));
            this_;
        });
        (prism_rtl::finished(std::tuple{wx2, Wres(Wres::WrUnit{})}));
    })
        : prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        ({
        auto pos = wx.pos;
        auto wx1 = ({
            Wx this_ = wx;
            this_.pos = next_pos(this_.pos);
            this_;
        });
        auto struct_path = path_in(lx, tg.home, tag_struct(tg.name));
        auto bound_opt_1 = bound_opt;
        auto benv_2 = benv;
        auto menv_3 = menv;
        call_value(fold_job(tg.fields, std::tuple{Array<std::tuple<Text, Ex>>{}, Array<std::tuple<Text, Ex>>{}, Array<Read>{}, wx1}, ({
        auto args_4 = args;
        auto menv_3_5 = menv_3;
        auto pos_5 = pos;
        auto tg_6 = tg;
        auto lx_7 = lx;
        auto benv_2_8 = benv_2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Ex>>, Array<std::tuple<Text, Ex>>, Array<Read>, Wx>>(std::tuple<std::tuple<Array<std::tuple<Text, Ex>>, Array<std::tuple<Text, Ex>>, Array<Read>, Wx>, std::tuple<Text, check_types::Ty>>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, Ex>>, Array<std::tuple<Text, Ex>>, Array<Read>, Wx>, std::tuple<Text, check_types::Ty>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_4_8 = args_4;
            auto menv_3_5_8 = menv_3_5;
            auto pos_5_8 = pos_5;
            auto tg_6_8 = tg_6;
            auto lx_7_8 = lx_7;
            auto benv_2_8_8 = benv_2_8;
            entered(once_job([=]() {
            return ({
                auto [lf, cf, rd, w] = p0;
                auto [fname, fty] = p1;
                ({
                auto&& _m = tag_arg(args_4_8, fname);
                prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{lf, cf, rd, w})
                : prism_rtl::is_some(_m) ? ({
                auto&& arg = prism_rtl::some_of(_m);
                ({
                auto&& _m = layer_of(fty);
                prism_rtl::is<Layer::LyEv>(_m) ? call_then(start_event_ref(w, menv_3_5_8, arg), [=](std::tuple<EvRef, Wx> event_ref_215181) {
                return ({
                    auto [r, w2] = event_ref_215181;
                    (prism_rtl::finished(std::tuple{lf, cf, rd, connect(w2, r, Sk(Sk::SkRequest{pos_5_8, request_field(tg_6_8, fname)}))}));
                });
            })
                : call_then(start_dynamic_expr(w, menv_3_5_8, arg), [=](std::tuple<Ex, Array<Read>> dynamic_expr_215399) {
                return ({
                    auto [ex, rds] = dynamic_expr_215399;
                    call_then(start_value_of(lx_7_8, benv_2_8_8, arg), [=](Vl value_of_215470) {
                    return ({
                        auto cv = own(value_of_215470);
                        (prism_rtl::finished(std::tuple{prelude::push(lf, std::tuple{snake(fname), ex}), prelude::push(cf, std::tuple{snake(fname), cv}), union_reads(rd, rds), w}));
                    });
                });
                });
            });
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<std::tuple<Text, Ex>>, Array<std::tuple<Text, Ex>>, Array<Read>, Wx> fold_214863) {
        return ({
            auto [live_fields, const_fields, reads, wx2] = fold_214863;
            auto live = len(reads) > Nat(0u);
            auto [getter, wx3] = live
                ? fresh_name(wx2, snake(check_types::bare_name(tg.name)))
                : std::tuple{Text::lit(""), wx2};
            auto variant = variant_of(lx, tg);
            auto level = Ex(Ex::XCtor{variant, Array(std::vector{Ex(Ex::XRecord{struct_path, live ? live_fields : const_fields})})});
            auto at_build = Ex(Ex::XCtor{variant, Array(std::vector{Ex(Ex::XRecord{struct_path, const_fields})})});
            auto added = live
                ? Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")})), getter, Array(std::vector{Ex(Ex::XCx{})})})
                : level;
            auto wx4 = ({
                Wx this_ = wx3;
                this_.places = prelude::push(this_.places, Place{.pos = pos, .level = level, .getter = getter, .reads = reads});
                this_.build = emits(wx3, pos)
                    ? prelude::push(this_.build, Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("added"), Array(std::vector{place_at(wx3, Text::lit("node"), pos), Ex(Ex::XMethod{prism_rtl::rc(added), Text::lit("to_pod"), Array<Ex>{}})})})}))
                    : this_.build;
                this_;
            });
            (prism_rtl::finished(element_output(wx4, menv_3, tg, element_out(lx, tg, full), pos, bound_opt_1, at_build)));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ElementLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Wres>> start_element_line(Wx wx, Env benv, Env menv, ast::Expr e, std::optional<Bn> bound_opt) {
    return prism_rtl::make_rc<ElementLine>(wx, benv, menv, e, bound_opt);
}


/// ElementOut: unbounded fn Lx, TagInfo, Ty -> OutTy
OutTy element_out(const Lx& lx, const check_env::TagInfo& tg, const check_types::Ty& full) {
    auto t = ({
        __label__ _done;
        prism_rtl::Slot<OutTy> _v;
        auto&& _m = peel(full);
        if (prism_rtl::is<check_types::Ty::TyElem>(_m)) {
            auto&& o = prism_rtl::as<check_types::Ty::TyElem>(_m).a1;
            _v.set(out_ty_of(lx, peel(o)));
            goto _done;
        }
        {
            _v.set(out_ty_of(lx, peel(tg->out)));
            goto _done;
        }
    _done:
        _v.take();
    });
    if (prism_rtl::is<OutTy::OutGen>(t)) {
        return OutTy(OutTy::OutPod{});
    }
    {
        return t;
    }
}


/// TagNameOf: fn Lx, Expr -> Text
Text tag_name_of(const Lx& lx, const ast::Expr& c) {
    auto&& _m = c.kind;
    if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        auto&& _qk_opt = check_env::resolve_value(lx.g, lx.home, n);
        auto&& qk_opt = std::get<0>(_qk_opt);
        return or_(qk_opt, check_env::dotted(n->path_));
    }
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        return tag_name_of(lx, x);
    }
    {
        return Text::lit("");
    }
}


/// ?TagArg: fn [Arg], Text -> ?Expr
std::optional<ast::Expr> tag_arg(const Array<ast::Arg>& args, const Text& fname) {
    return fold(args, std::optional<ast::Expr>{}, [&](const std::optional<ast::Expr>& found_opt, const ast::Arg& a) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<ast::Expr>> _v;
            auto&& _m = a.name;
            if (prism_rtl::is_some(_m)) {
                auto&& n = prism_rtl::some_of(_m);
                _v.set(n.name == fname ? std::optional(a->value) : found_opt);
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(found_opt);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// RequestField: fn TagInfo, Text -> Text
Text request_field(const check_env::TagInfo& tg, const Text& fname) {
    auto evs = filter(tg.fields, [&](const std::tuple<Text, check_types::Ty>& _p0) {
        auto&& t = std::get<1>(_p0);
        return layer_of(t) == Layer(Layer::LyEv{});
    });
    return len(evs) > Nat(1u) ? fname : Text::lit("");
}


/// ElementOutput: unbounded fn Wx, Env, TagInfo, OutTy, Pos, ?Bn, Ex -> ((Wx, Wres))
std::tuple<Wx, Wres> element_output(const Wx& wx, const Env& menv, const check_env::TagInfo& tg, const OutTy& out, const Pos_& pos, const std::optional<Bn>& bound_opt, const Ex& level) {
    auto lx = wx.lx;
    if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnParts>(prism_rtl::some_of(bound_opt))) {
        auto&& parts = prism_rtl::as<Bn::BnParts>(prism_rtl::some_of(bound_opt)).a0;
        return bundle_output(wx, tg, out, pos, parts, level);
    }
    {
        return element_output_of(wx, menv, tg, out, pos, bound_opt, level);
    }
}


/// BundleOutput: unbounded fn Wx, TagInfo, OutTy, Pos, [?Bn], Ex -> ((Wx, Wres))
std::tuple<Wx, Wres> bundle_output(const Wx& wx, const check_env::TagInfo& tg, const OutTy& out, const Pos_& pos, const Array<std::optional<Bn>>& parts, const Ex& level) {
    return !emits(wx, pos)
        ? ({
        auto wx2 = ({
            Wx this_ = wx;
            this_.build = prelude::push(this_.build, refusal_do(prism_rtl::cat("a bundle (", tg.name, ") in a hosted scope")));
            this_;
        });
        std::tuple{wx2, Wres(Wres::WrUnit{})};
    })
        : bundle_output_of(wx, tg, out, pos, parts, level);
}


/// BundleOutputOf: unbounded fn Wx, TagInfo, OutTy, Pos, [?Bn], Ex -> ((Wx, Wres))
std::tuple<Wx, Wres> bundle_output_of(const Wx& wx, const check_env::TagInfo& tg, const OutTy& out, const Pos_& pos, const Array<std::optional<Bn>>& parts, const Ex& level) {
    auto layers = ({
        __label__ _done;
        prism_rtl::Slot<Array<Layer>> _v;
        auto&& _m = tg->out;
        if (prism_rtl::is<check_types::Ty::TyTuple>(_m)) {
            auto&& cs = prism_rtl::as<check_types::Ty::TyTuple>(_m).a0;
            _v.set(each(cs, [&](const check_types::Ty& c) { return layer_of(c); }));
            goto _done;
        }
        {
            _v.set(Array<Layer>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto tys = ({
        __label__ _done;
        prism_rtl::Slot<Array<OutTy>> _v;
        if (prism_rtl::is<OutTy::OutTuple>(out)) {
            auto&& ts = prism_rtl::as<OutTy::OutTuple>(out).a0;
            _v.set(ts);
            goto _done;
        }
        {
            _v.set(Array<OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto idx = check_errors::range0(len(layers));
    auto plain_ix = filter(idx, [&](const Nat& i) { return or_(index(layers, i), Layer(Layer::LyPlain{})) == Layer(Layer::LyPlain{}); });
    auto ev_ix = filter(idx, [&](const Nat& i) { return or_(index(layers, i), Layer(Layer::LyPlain{})) == Layer(Layer::LyEv{}); });
    auto dyn_ix = filter(idx, [&](const Nat& i) { return or_(index(layers, i), Layer(Layer::LyPlain{})) == Layer(Layer::LyDyn{}); });
    auto wx1 = bundle_first(wx, tg, pos, plain_ix, tys, parts, level);
    auto wx2 = fold(ev_ix, wx1, [&](const Wx& w, const Nat& i) { return bundle_answer(w, pos, or_(index(tys, i), OutTy(OutTy::OutUnit{})), or_(index(parts, i), std::optional<Bn>{})); });
    return (len(ev_ix) > Nat(1u)) || (len(dyn_ix) > Nat(0u))
        ? ({
        auto wx3 = ({
            Wx this_ = wx2;
            this_.build = prelude::push(this_.build, refusal_do(prism_rtl::cat("a bundle with a `$` part or two event parts (", tg.name, ")")));
            this_;
        });
        std::tuple{wx3, Wres(Wres::WrUnit{})};
    })
        : std::tuple{wx2, Wres(Wres::WrUnit{})};
}


/// BundleFirst: unbounded fn Wx, TagInfo, Pos, [Nat], [OutTy], [?Bn], Ex -> Wx
Wx bundle_first(const Wx& wx, const check_env::TagInfo& tg, const Pos_& pos, const Array<Nat>& plain_ix, const Array<OutTy>& tys, const Array<std::optional<Bn>>& parts, const Ex& level) {
    {
        auto&& m220196_0 = plain_ix;
        if (m220196_0.size() == 0u) {
            return wx;
        }
    }
    {
        auto one = len(plain_ix) == Nat(1u);
        auto plain_ty = one
            ? or_(index(tys, or_(index(plain_ix, Nat(0u)), Nat(0u))), OutTy(OutTy::OutUnit{}))
            : OutTy(OutTy::OutTuple{each(plain_ix, [&](const Nat& i) { return or_(index(tys, i), OutTy(OutTy::OutUnit{})); })});
        auto wx1 = ({
            Wx this_ = wx;
            this_.lets = append(this_.lets, Array(std::vector{first_value_let(wx, pos, tg, level), Do(Do::DoLet{Pa(Pa::PaBind{prism_rtl::cat("bundle_", place_text(pos))}), Ex(Ex::XDecode{plain_ty, prism_rtl::rc(Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{prism_rtl::cat("first_", place_text(pos))}))}))})})}));
            this_.fallible = true;
            this_;
        });
        return fold(check_errors::range0(len(plain_ix)), wx1, [&](const Wx& w, const Nat& k) {
            return ({
                auto i = or_(index(plain_ix, k), Nat(0u));
                ({
                __label__ _done;
                prism_rtl::Slot<Wx> _v;
                auto&& _m = index(parts, i);
                if (prism_rtl::is_some(_m) && prism_rtl::is_some(prism_rtl::some_of(_m)) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(prism_rtl::some_of(_m)))) {
                    auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(prism_rtl::some_of(_m))).a0;
                    _v.set(({
                        auto f = place_stem(rs);
                        auto part = one
                            ? Ex(Ex::XVar{prism_rtl::cat("bundle_", place_text(pos))})
                            : Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XPart{prism_rtl::rc(Ex(Ex::XVar{prism_rtl::cat("bundle_", place_text(pos))})), k}))});
                        ({
                        Wx this_ = w;
                        this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaBind{f}), part}));
                        this_.fields = prelude::push(this_.fields, std::tuple{f, or_(index(tys, i), OutTy(OutTy::OutUnit{})), prism_rtl::cat("place ", place_text(pos), "'s answer, part ", i, " of its first value")});
                        this_.inits = prelude::push(this_.inits, std::tuple{f, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{f}))})});
                        this_;
                    });
                    }));
                    goto _done;
                }
                {
                    _v.set(w);
                    goto _done;
                }
            _done:
                _v.take();
            });
            });
        });
    }
}


/// BundleAnswer: fn Wx, Pos, OutTy, ?Bn -> Wx
Wx bundle_answer(const Wx& wx, const Pos_& pos, const OutTy& et, const std::optional<Bn>& b_opt) {
    auto t = ({
        __label__ _done;
        prism_rtl::Slot<OutTy> _v;
        if (prism_rtl::is<OutTy::OutEvent>(et)) {
            auto&& inner = prism_rtl::as<OutTy::OutEvent>(et).a0;
            _v.set(inner);
            goto _done;
        }
        {
            _v.set(et);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [id, wx2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
        if (prism_rtl::is_some(b_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(b_opt))) {
            auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(b_opt)).a0;
            _v.set(std::tuple{er.node_, wx});
            goto _done;
        }
        {
            _v.set(({
                auto [nm, w] = fresh_name(wx, prism_rtl::cat("place_", place_text(pos)));
                add_gn(w, nm, t, GnKind(GnKind::GnAnswer{}), Nat(0u));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    Wx this_ = wx2;
    this_.answers = prelude::push(this_.answers, std::tuple{pos, id, t, Text::lit("")});
    return this_;
}


/// FirstValueLet: fn Wx, Pos, TagInfo, Ex -> Do
Do first_value_let(const Wx& wx, const Pos_& pos, const check_env::TagInfo& tg, const Ex& level) {
    auto missing = Ex(Ex::XCall{Text::lit("Fault::answer"), Array(std::vector{Ex(Ex::XStr{prism_rtl::cat("no first value for ", tg.name)})})});
    return emits(wx, pos)
        ? ({
        auto asked = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("first_value"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(level), Text::lit("to_pod"), Array<Ex>{}}))})})});
        (Do(Do::DoLet{Pa(Pa::PaBind{prism_rtl::cat("first_", place_text(pos))}), try_of(Ex(Ex::XMethod{prism_rtl::rc(asked), Text::lit("ok_or"), Array(std::vector{missing})}))}));
    })
        : ({
        auto host = host_local(wx, pos);
        auto asked = try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{host})), Text::lit("first_value"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(place_at(wx, Text::lit(""), pos))}), Ex(Ex::XRef{prism_rtl::rc(level)}), Ex(Ex::XCx{})})}));
        (Do(Do::DoLet{Pa(Pa::PaBind{prism_rtl::cat("first_", place_text(pos))}), try_of(Ex(Ex::XMethod{prism_rtl::rc(try_of(Ex(Ex::XMethod{prism_rtl::rc(asked), Text::lit("ok_or"), Array(std::vector{missing})}))), answer_accessor(tg), Array<Ex>{}}))}));
    });
}


/// HostLocal: fn Wx, Pos -> Text
Text host_local(const Wx& wx, const Pos_& pos) {
    return pos.scope == Nat(0u)
        ? Text::lit("enclosing")
        : or_(index(wx.scopes, lexer::dec(pos.scope)), Text::lit(""));
}


/// AnswerVariant: fn TagInfo -> Text
Text answer_variant(const check_env::TagInfo& tg) {
    return prism_rtl::cat("crate::Answer::", tag_struct(tg.name));
}


/// AnswerAccessor: fn TagInfo -> Text
Text answer_accessor(const check_env::TagInfo& tg) {
    return snake(tag_struct(tg.name));
}


/// ElementOutputOf: unbounded fn Wx, Env, TagInfo, OutTy, Pos, ?Bn, Ex -> ((Wx, Wres))
std::tuple<Wx, Wres> element_output_of(const Wx& wx, const Env& menv, const check_env::TagInfo& tg, const OutTy& out, const Pos_& pos, const std::optional<Bn>& bound_opt, const Ex& level) {
    auto lx = wx.lx;
    auto&& _m = layer_of(tg->out);
    if (prism_rtl::is<Layer::LyEv>(_m)) {
        auto [id, wx2] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
            if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
                auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
                _v.set(std::tuple{er.node_, wx});
                goto _done;
            }
            {
                _v.set(({
                    auto [nm, w] = fresh_name(wx, prism_rtl::cat("place_", place_text(pos)));
                    add_gn(w, nm, out, GnKind(GnKind::GnAnswer{}), Nat(0u));
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto wx3 = ({
            Wx this_ = wx2;
            this_.answers = prelude::push(this_.answers, std::tuple{pos, id, out, answer_accessor(tg)});
            this_;
        });
        return std::tuple{wx3, Wres(Wres::WrEv{ev_ref_of(wx3, id)})};
    }
    if (prism_rtl::is<Layer::LyDyn>(_m)) {
        auto [f, wx1] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, Wx>> _v;
            if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnHold>(prism_rtl::some_of(bound_opt))) {
                auto&& hf = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(bound_opt)).a0;
                _v.set(std::tuple{hf, wx});
                goto _done;
            }
            {
                _v.set(fresh_name(wx, prism_rtl::cat("place_", place_text(pos))));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto emits_ = emits(wx, pos);
        auto first__1 = emits_
            ? Ex(Ex::XDecode{out, prism_rtl::rc(Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{prism_rtl::cat("first_", place_text(pos))}))}))})
            : Ex(Ex::XVar{prism_rtl::cat("first_", place_text(pos))});
        auto wx2 = ({
            Wx this_ = wx1;
            this_.lets = prelude::push(this_.lets, first_value_let(wx, pos, tg, level));
            this_.fields = prelude::push(this_.fields, std::tuple{f, OutTy(OutTy::OutHold{prism_rtl::rc(out)}), prism_rtl::cat("pushed to place ", place_text(pos))});
            this_.inits = prelude::push(this_.inits, std::tuple{f, Ex(Ex::XCall{Text::lit("Hold::new"), Array(std::vector{first__1, Ex(Ex::XCx{})})})});
            this_.dyn_places = prelude::push(this_.dyn_places, std::tuple{pos, f, out, answer_accessor(tg)});
            this_.fallible = true;
            this_;
        });
        auto wx3 = emits_
            ? ({
            Wx this_ = wx2;
            this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaBind{prism_rtl::cat(f, "_element")}), Ex(Ex::XMethod{prism_rtl::rc(level), Text::lit("to_pod"), Array<Ex>{}})}));
            this_.fields = prelude::push(this_.fields, std::tuple{prism_rtl::cat(f, "_element"), OutTy(OutTy::OutPod{}), prism_rtl::cat("place ", place_text(pos), "'s element, which pushes are keyed by")});
            this_.moves = prelude::push(this_.moves, std::tuple{prism_rtl::cat(f, "_element"), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{prism_rtl::cat(f, "_element")}))})});
            this_.build = prelude::push(this_.build, Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("listen"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")})), prism_rtl::cat(f, "_element")}))}), Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XCast{prism_rtl::rc(Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")}))})), OutTy(OutTy::OutObj{prism_rtl::rc(OutTy(OutTy::OutNamed{Text::lit("Node"), Array<OutTy>{}}))})}))})})})}));
            this_;
        })
            : wx2;
        return std::tuple{wx3, Wres(Wres::WrDyn{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("get"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{f})}), out})};
    }
    {
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(bound_opt))) {
            auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(bound_opt)).a0;
            auto f = place_stem(rs);
            auto first__1 = emits(wx, pos)
                ? Ex(Ex::XDecode{out, prism_rtl::rc(Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{prism_rtl::cat("first_", place_text(pos))}))}))})
                : Ex(Ex::XVar{prism_rtl::cat("first_", place_text(pos))});
            auto wx2 = ({
                Wx this_ = wx;
                this_.lets = append(this_.lets, Array(std::vector{first_value_let(wx, pos, tg, level), Do(Do::DoLet{Pa(Pa::PaBind{f}), first__1})}));
                this_.fields = prelude::push(this_.fields, std::tuple{f, out, prism_rtl::cat("place ", place_text(pos), "'s answer, its first value")});
                this_.inits = prelude::push(this_.inits, std::tuple{f, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{f}))})});
                this_.fallible = true;
                this_;
            });
            return std::tuple{wx2, Wres(Wres::WrUnit{})};
        }
        {
            return std::tuple{wx, Wres(Wres::WrUnit{})};
        }
    }
}


/// WidgetLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> widget_line(const Wx& wx, const Env& benv, const Env& menv, const ast::Expr& e, const std::optional<Bn>& bound_opt) {
    auto lx = wx.lx;
    auto [callee, args] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::Expr, Array<ast::Arg>>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& xs = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{c, xs});
            goto _done;
        }
        {
            _v.set(std::tuple{e, Array<ast::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto qk = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = callee.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                auto&& q_opt = std::get<0>(_q_opt);
                or_(q_opt, Text::lit(""));
            }));
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto target_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Nat>> _v;
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
            auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
            _v.set(std::optional(er.node_));
            goto _done;
        }
        {
            _v.set(std::optional<Nat>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto param_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Bn>> _v;
        auto&& _m = callee.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(len(n->path_) == Nat(1u)
                ? prelude::get(menv->names, check_env::sname_key(n))
                : std::optional<Bn>{});
            goto _done;
        }
        {
            _v.set(std::optional<Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    if (prism_rtl::is_some(param_opt) && prism_rtl::is<Bn::BnWidget>(prism_rtl::some_of(param_opt))) {
        auto&& x = prism_rtl::as<Bn::BnWidget>(prism_rtl::some_of(param_opt)).a0;
        auto&& cbenv = prism_rtl::as<Bn::BnWidget>(prism_rtl::some_of(param_opt)).a1;
        auto&& cmenv = prism_rtl::as<Bn::BnWidget>(prism_rtl::some_of(param_opt)).a2;
        auto&& clx = prism_rtl::as<Bn::BnWidget>(prism_rtl::some_of(param_opt)).a3;
        return apply_widget_param(wx, x, cbenv, cmenv, clx, len(args));
    }
    {
        return widget_call(wx, benv, menv, e, bound_opt, qk, args, target_opt);
    }
}


prism_rtl::Turn<std::tuple<Wx, Wres>> WidgetLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& e = this->e;
    const auto& bound_opt = this->bound_opt;
    auto lx = wx.lx;
    auto [callee, args] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::Expr, Array<ast::Arg>>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& xs = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{c, xs});
            goto _done;
        }
        {
            _v.set(std::tuple{e, Array<ast::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto qk = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = callee.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                auto&& q_opt = std::get<0>(_q_opt);
                or_(q_opt, Text::lit(""));
            }));
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto target_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Nat>> _v;
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
            auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
            _v.set(std::optional(er.node_));
            goto _done;
        }
        {
            _v.set(std::optional<Nat>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto param_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Bn>> _v;
        auto&& _m = callee.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(len(n->path_) == Nat(1u)
                ? prelude::get(menv->names, check_env::sname_key(n))
                : std::optional<Bn>{});
            goto _done;
        }
        {
            _v.set(std::optional<Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return ({
        prism_rtl::is_some(param_opt) && prism_rtl::is<Bn::BnWidget>(prism_rtl::some_of(param_opt)) ? ({
        auto&& x = prism_rtl::as<Bn::BnWidget>(prism_rtl::some_of(param_opt)).a0;
        auto&& cbenv = prism_rtl::as<Bn::BnWidget>(prism_rtl::some_of(param_opt)).a1;
        auto&& cmenv = prism_rtl::as<Bn::BnWidget>(prism_rtl::some_of(param_opt)).a2;
        auto&& clx = prism_rtl::as<Bn::BnWidget>(prism_rtl::some_of(param_opt)).a3;
        prism_rtl::finished(apply_widget_param(wx, x, cbenv, cmenv, clx, len(args)));
    })
        : prism_rtl::finished(widget_call(wx, benv, menv, e, bound_opt, qk, args, target_opt));
    });
}


/// `Start WidgetLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Wres>> start_widget_line(Wx wx, Env benv, Env menv, ast::Expr e, std::optional<Bn> bound_opt) {
    return prism_rtl::make_rc<WidgetLine>(wx, benv, menv, e, bound_opt);
}


/// ApplyWidgetParam: unbounded fn Wx, Expr, Env, Env, Lx, Nat -> ((Wx, Wres))
std::tuple<Wx, Wres> apply_widget_param(const Wx& wx, const ast::Expr& x, const Env& cbenv, const Env& cmenv, const Lx& clx, const Nat& nargs) {
    return nargs > Nat(0u)
        ? ({
        auto wx2 = ({
            Wx this_ = wx;
            this_.build = prelude::push(this_.build, refusal_do(Text::lit("a widget parameter applied to arguments")));
            this_;
        });
        std::tuple{wx2, Wres(Wres::WrUnit{})};
    })
        : wx.depth > Nat(32u)
        ? std::tuple{wx, Wres(Wres::WrUnit{})}
        : ({
        auto lx = wx.lx;
        auto inner = ({
            Wx this_ = wx;
            this_.lx = clx;
            this_.depth = this_.depth + Nat(1u);
            this_;
        });
        auto [done, res] = build_line(inner, cbenv, cmenv, x, std::optional<Bn>{});
        auto back_ = ({
            Wx this_ = done;
            this_.lx = lx;
            this_.depth = wx.depth;
            this_;
        });
        std::tuple{back_, res};
    });
}


/// InlineBlock: unbounded fn Wx, Env, Env, Block, Lx -> ((Wx, Wres))
std::tuple<Wx, Wres> inline_block(const Wx& wx, const Env& benv, const Env& menv, const ast::Block& b, const Lx& lx) {
    auto inner = ({
        Wx this_ = wx;
        this_.result = Wres(Wres::WrUnit{});
        this_;
    });
    auto done = block_into(inner, benv, menv, b);
    auto back_ = ({
        Wx this_ = done;
        this_.result = wx->result;
        this_;
    });
    return std::tuple{back_, done->result};
}


prism_rtl::Turn<std::tuple<Wx, Wres>> InlineBlock::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& b = this->b;
    const auto& lx = this->lx;
    auto inner = ({
        Wx this_ = wx;
        this_.result = Wres(Wres::WrUnit{});
        this_;
    });
    auto b_1 = b;
    auto benv_2 = benv;
    auto menv_3 = menv;
    auto wx_4 = wx;
    return call_then(start_block_into(inner, benv_2, menv_3, b_1), [=](Wx block_into_228984) {
        return ({
            auto done = block_into_228984;
            auto back_ = ({
                Wx this_ = done;
                this_.result = wx_4->result;
                this_;
            });
            (prism_rtl::finished(std::tuple{back_, done->result}));
        });
    });
}


/// `Start InlineBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Wres>> start_inline_block(Wx wx, Env benv, Env menv, ast::Block b, Lx lx) {
    return prism_rtl::make_rc<InlineBlock>(wx, benv, menv, b, lx);
}


/// WidgetCall: unbounded fn Wx, Env, Env, Expr, ?Bn, Text, [Arg], ?Nat -> ((Wx, Wres))
std::tuple<Wx, Wres> widget_call(const Wx& wx, const Env& benv, const Env& menv, const ast::Expr& e, const std::optional<Bn>& bound_opt, const Text& qk, const Array<ast::Arg>& args, const std::optional<Nat>& target_opt) {
    auto lx = wx.lx;
    {
        auto&& m229268_0 = qk;
        if (m229268_0 == Text::lit("Prelude.@started")) {
            return started_line(wx, bound_opt);
        }
    }
    {
        auto&& m229268_1 = qk;
        if (m229268_1 == Text::lit("Prelude.@Switch")) {
            return switch_line(wx, menv, args);
        }
    }
    {
        auto&& m229268_2 = qk;
        if (m229268_2 == Text::lit("Prelude.@Flatten")) {
            return flatten_line(wx, menv, args, bound_opt);
        }
    }
    {
        auto&& m229268_3 = qk;
        if (m229268_3 == Text::lit("Prelude.@Defer")) {
            return defer_line(wx, menv, args, e, target_opt);
        }
    }
    {
        auto&& m229268_4 = qk;
        if (m229268_4 == Text::lit("Prelude.@Run")) {
            return run_line(wx, benv, args, e, target_opt);
        }
    }
    {
        auto&& m229268_5 = qk;
        if (m229268_5 == Text::lit("Prelude.@Machine")) {
            return machine_line(wx, benv, menv, args, e, target_opt);
        }
    }
    {
        auto&& m229268_6 = qk;
        if (m229268_6 == Text::lit("Prelude.@HostDocument")) {
            return host_line(wx, benv, menv, HostForm(HostForm::HostEach{}), args, bound_opt);
        }
    }
    {
        auto&& m229268_7 = qk;
        if (m229268_7 == Text::lit("Prelude.@HostSome")) {
            return host_line(wx, benv, menv, HostForm(HostForm::HostSome{}), args, bound_opt);
        }
    }
    {
        auto&& _m = prelude::get(lx.g.vals, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            return inline_widget(wx, benv, menv, qk, v_, args, e);
        }
        if (prism_rtl::is_none(_m)) {
            auto wx2 = ({
                Wx this_ = wx;
                this_.build = prelude::push(this_.build, refusal_do(Text::lit("a widget this back end does not lower yet")));
                this_;
            });
            return std::tuple{wx2, Wres(Wres::WrUnit{})};
        }
        prism_rtl::unreachable("no arm matched");
    }
}


/// HostLine: unbounded fn Wx, Env, Env, HostForm, [Arg], ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> host_line(const Wx& wx, const Env& benv, const Env& menv, const HostForm& form, const Array<ast::Arg>& args, const std::optional<Bn>& bound_opt) {
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto k = len(wx.scopes) + Nat(1u);
    auto hf = prism_rtl::cat("host_", k);
    auto rows_name = prism_rtl::cat(hf, "_rows");
    auto doc_getter = prism_rtl::cat(hf, "_doc");
    auto wx1 = ({
        Wx this_ = wx;
        this_.taken = append(this_.taken, Array(std::vector{hf, rows_name, doc_getter, prism_rtl::cat(doc_getter, "_now"), prism_rtl::cat(doc_getter, "_snap"), prism_rtl::cat(doc_getter, "_direct"), prism_rtl::cat(doc_getter, "_publish"), prism_rtl::cat(hf, "_answer"), prism_rtl::cat(hf, "_moved")}));
        this_;
    });
    auto named = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = index(args, Nat(1u));
        if (prism_rtl::is_some(_m)) {
            auto&& sup = prism_rtl::some_of(_m);
            _v.set(is_widget_name(sup->value));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _m = std::tuple{index(args, Nat(0u)), index(args, Nat(1u))};
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        if (named) {
            auto wx2 = ({
                Wx this_ = wx1;
                this_.pos = next_pos(this_.pos);
                this_.build = prelude::push(this_.build, refusal_do(Text::lit("a named widget function as a host's supplier (gap NS): a lambda supplier is lowered, a widget function is not a value")));
                this_;
            });
            return std::tuple{wx2, Wres(Wres::WrHosted{prism_rtl::rc(Wres(Wres::WrUnit{})), Bn(Bn::BnLocal{Ex(Ex::XUnit{}), Holding(Holding::Owned{}), OutTy(OutTy::OutUnit{})})})};
        }
    }
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        auto&& child = prism_rtl::some_of(std::get<0>(_m));
        auto&& sup = prism_rtl::some_of(std::get<1>(_m));
        auto [wxd, dyn_env, dyn_lets] = dynamic_answers(wx1, benv, menv, hf, sup->value);
        auto offered = own(value_of(lx, dyn_env, sup->value));
        auto supplier0 = ({
            __label__ _done;
            prism_rtl::Slot<Ex> _v;
            if (prism_rtl::is<HostForm::HostEach>(form)) {
                _v.set(offered);
                goto _done;
            }
            if (prism_rtl::is<HostForm::HostSome>(form)) {
                _v.set(Ex(Ex::XCall{Text::lit("prism_rtl::forward_on_none"), Array(std::vector{offered})}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto supplier = len(dyn_lets) == Nat(0u)
            ? supplier0
            : Ex(Ex::XBlock{dyn_lets, prism_rtl::rc(supplier0)});
        auto enclosing = emits(wx, pos)
            ? Ex(Ex::XNone{})
            : Ex(Ex::XCtor{Text::lit("Some"), Array(std::vector{Ex(Ex::XCast{prism_rtl::rc(Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{host_local(wx, pos)}))})), host_of_ty()})})});
        auto made = Ex(Ex::XCall{Text::lit("prism_rtl::Host::new"), Array(std::vector{place_at(wx, Text::lit(""), pos), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{rows_name}))}), supplier, enclosing, Ex(Ex::XPath{prism_rtl::cat(wx.node_, "::", doc_getter, "_direct")}), Ex(Ex::XPath{prism_rtl::cat(wx.node_, "::", hf, "_answer")})})});
        auto host_ty = OutTy(OutTy::OutRc{prism_rtl::rc(OutTy(OutTy::OutNamed{Text::lit("prism_rtl::Host"), Array(std::vector{elem_ty(), answer_ty_value(), OutTy(OutTy::OutNamed{wx.node_, Array<OutTy>{}})})}))});
        auto rows_ty = OutTy(OutTy::OutNamed{Text::lit("prism_rtl::Rows"), Array(std::vector{elem_ty(), answer_ty_value()})});
        auto doc_ty = OutTy(OutTy::OutMap{prism_rtl::rc(OutTy(OutTy::OutPath{})), prism_rtl::rc(elem_ty())});
        auto what = prism_rtl::cat("the document of the child hosted at place ", place_text(pos));
        auto wx2 = ({
            Wx this_ = wxd;
            this_.pos = next_pos(this_.pos);
            this_.lets = append(this_.lets, Array(std::vector{Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{rows_name})), rows_ty}), Ex(Ex::XCall{Text::lit("Rc::new"), Array(std::vector{Ex(Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{Ex(Ex::XCall{Text::lit("Map::new"), Array<Ex>{}})})})})})}), Do(Do::DoLet{Pa(Pa::PaBind{hf}), made})}));
            this_.fields = append(this_.fields, Array(std::vector{std::tuple{hf, host_ty, prism_rtl::cat("the host at place ", place_text(pos), ": its supplier, its rows, and the way back into its child (pick HO)")}, std::tuple{rows_name, rows_ty, prism_rtl::cat("the rows of the host at place ", place_text(pos), ": `for p, e <- $doc`, one supplier blueprint per child place")}, std::tuple{prism_rtl::cat(doc_getter, "_snap"), OutTy(OutTy::OutSnapshot{prism_rtl::rc(doc_ty)}), prism_rtl::cat("`$doc` of the host at place ", place_text(pos), ", a structural dynamic: its snapshots, the structure and the lagged dynamic (pick ST)")}}));
            this_.moves = append(this_.moves, Array(std::vector{std::tuple{hf, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{hf}))})}, std::tuple{rows_name, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{rows_name}))})}}));
            this_.inits = prelude::push(this_.inits, std::tuple{prism_rtl::cat(doc_getter, "_snap"), Ex(Ex::XCall{Text::lit("Snapshot::new"), Array(std::vector{Ex(Ex::XStr{what})})})});
            this_.hosts = prelude::push(this_.hosts, HostDef{.pos = pos, .name = hf, .scope = k});
            this_.snaps = prelude::push(this_.snaps, SnapDef{.name = doc_getter, .live = prism_rtl::cat(doc_getter, "_now"), .ty = doc_ty, .eq = true, .builder = rows_name, .before = true, .what = what});
            this_.getters = append(this_.getters, Array(std::vector{snap_getter(doc_getter, doc_ty, prism_rtl::cat("The document of the child hosted at place ", place_text(pos), ", `$doc`, a structural dynamic (pick ST): one tick behind the child's structure, the snapshot of the tick before the tick the read point is after.")), MethDef{.name = prism_rtl::cat(doc_getter, "_direct"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = doc_ty, .body = Array<Do>{}, .tail = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(doc_getter, "_snap")})), Text::lit("current"), Array(std::vector{Ex(Ex::XCx{})})}), .doc = prism_rtl::cat("The structure of the child hosted at place ", place_text(pos), ", not the lagged `$doc`: the snapshot taken in this tick's construction step, the document as the tick opened during propagation. The host's own `for` and its rows' entries read it, so a newborn child place gets its row in the tick it is born (pick ST).")}}));
            this_.scopes = prelude::push(this_.scopes, hf);
            this_.builders = prelude::push(this_.builders, ForDef{.name = rows_name, .pos = pos, .at = place_at(wx, Text::lit("self"), pos), .key_ty = OutTy(OutTy::OutPath{}), .value_ty = elem_ty(), .row_node = Text::lit("prism_rtl::HostRow::<crate::Elem, crate::Answer>"), .keyed = true, .source = prism_rtl::cat(doc_getter, "_direct"), .parent = Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), hf}))}), .passed = Array<Ex>{}});
            this_.build_holds = add_read(this_.build_holds, Read(Read::OwnRead{prism_rtl::cat(doc_getter, "_now")}));
            this_.row_marks = prelude::push(this_.row_marks, RowMarks{.builder = rows_name, .reads = Array(std::vector{Read(Read::OwnRead{prism_rtl::cat(doc_getter, "_now")})}), .wrote = Array<Text>{}, .kind = RowKind(RowKind::ForRow{})});
            this_.fallible = true;
            this_;
        });
        auto inner = ({
            Wx this_ = wx2;
            this_.pos = scope_pos(k);
            this_.result = Wres(Wres::WrUnit{});
            this_;
        });
        auto [done, res] = build_line(inner, benv, menv, child->value, std::optional<Bn>{});
        auto child_places = drop(done.places, len(wx2.places));
        auto child_builds = filter(done.build_holds, [&](const Read& h) { return !has_read(wx2.build_holds, h); });
        auto child_gens = fold(drop(done.gen_holds, len(wx2.gen_holds)), Array<Read>{}, [&](const Array<Read>& acc, const std::tuple<Text, Array<Read>>& _p1) {
            auto&& hs = std::get<1>(_p1);
            return union_reads(acc, hs);
        });
        auto child_rows = fold(drop(done.row_marks, len(wx2.row_marks)), Array<Read>{}, [&](const Array<Read>& acc, const RowMarks& rm) { return union_reads(acc, rm.reads); });
        auto doc_reads = fold(child_places, union_reads(union_reads(child_builds, child_gens), child_rows), [&](const Array<Read>& acc, const Place& pl) { return union_reads(acc, pl.reads); });
        auto in_scope_fn = ({
            auto k_1 = k;
            (prism_rtl::rc([=](const Pos_& p_) { return p_.scope == k_1; }));
        });
        auto getter = host_doc_getter(prism_rtl::cat(doc_getter, "_now"), pos, filter(child_places, [&](const Place& pl) { return in_scope_fn(pl.pos); }), filter(drop(done.builders, len(wx2.builders)), [&](const ForDef& b) { return in_scope_fn(b.pos); }), filter(drop(done.gens, len(wx2.gens)), [&](const GenDef& gd) { return in_scope_fn(gd.pos); }));
        auto back_ = ({
            Wx this_ = done;
            this_.pos = wx2.pos;
            this_.result = wx->result;
            this_.getters = prelude::push(this_.getters, getter);
            this_.dyn_reads = insert(this_.dyn_reads, prism_rtl::cat(doc_getter, "_now"), doc_reads);
            this_;
        });
        auto doc_bn = Bn(Bn::BnDyn{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), doc_getter, Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{doc_getter})}), doc_ty});
        return std::tuple{back_, Wres(Wres::WrHosted{prism_rtl::rc(res), doc_bn})};
    }
    {
        auto wx2 = ({
            Wx this_ = wx1;
            this_.pos = next_pos(this_.pos);
            this_.build = prelude::push(this_.build, refusal_do(Text::lit("a host without its child or its supplier")));
            this_;
        });
        return std::tuple{wx2, Wres(Wres::WrHosted{prism_rtl::rc(Wres(Wres::WrUnit{})), Bn(Bn::BnLocal{Ex(Ex::XUnit{}), Holding(Holding::Owned{}), OutTy(OutTy::OutUnit{})})})};
    }
}


/// IsWidgetName: fn Expr -> Bool
bool is_widget_name(const ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        return lexer::has_prefix(check_env::sname_key(n), Text::lit("@"));
    }
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        return is_widget_name(x);
    }
    {
        return false;
    }
}


/// DynamicAnswers: unbounded fn Wx, Env, Env, Text, Expr -> ((Wx, Env, [Do]))
std::tuple<Wx, Env, Array<Do>> dynamic_answers(const Wx& wx, const Env& benv, const Env& menv, const Text& hf, const ast::Expr& sup) {
    auto lx = wx.lx;
    auto dyns = fold(typed::exprs_in(sup), Array<std::tuple<ast::Expr, ast::Expr>>{}, [&](const Array<std::tuple<ast::Expr, ast::Expr>>& acc, const ast::Expr& x) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<ast::Expr, ast::Expr>>> _v;
            auto&& _m = x.kind;
            if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
                auto&& m239431_0_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
                auto&& y = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
                if (m239431_0_0 == Text::lit("@")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<std::tuple<ast::Expr, ast::Expr>>> _v;
                        auto&& _m = dynamic_answer(lx, y);
                        if (prism_rtl::is_some(_m)) {
                            auto&& d = prism_rtl::some_of(_m);
                            _v.set(prelude::push(acc, std::tuple{y, d}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(acc);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return len(dyns) == Nat(0u)
        ? std::tuple{wx, benv, Array<Do>{}}
        : ({
        auto owner = prism_rtl::cat(hf, "_owner");
        auto wx1 = ({
            Wx this_ = wx;
            this_.taken = prelude::push(this_.taken, owner);
            this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaBind{owner}), Ex(Ex::XCall{prism_rtl::cat("prism_rtl::Link::<", wx.node_, ">::new"), Array<Ex>{}})}));
            this_.build = prelude::push(this_.build, Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{owner})), Text::lit("link"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")}))})})})}));
            this_;
        });
        auto env0 = bind(benv, Text::lit("#owner"), Bn(Bn::BnLocal{Ex(Ex::XVar{owner}), Holding(Holding::Owned{}), OutTy(OutTy::OutUnit{})}));
        auto lets0 = Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{owner}), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{owner}))})})});
        run_to_end(fold_job(check_errors::range0(len(dyns)), std::tuple{wx1, env0, lets0}, ({
        auto dyns_1 = dyns;
        auto hf_2 = hf;
        auto menv_3 = menv;
        auto lx_4 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Array<Do>>>(std::tuple<std::tuple<Wx, Env, Array<Do>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Array<Do>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto dyns_1_5 = dyns_1;
            auto hf_2_5 = hf_2;
            auto menv_3_5 = menv_3;
            auto lx_4_5 = lx_4;
            entered(once_job([=]() {
            return ({
                auto [w, en, ls] = p0;
                auto j = p1;
                ({
                auto&& _m = index(dyns_1_5, j);
                prism_rtl::is_some(_m) ? ({
                auto&& y = std::get<0>(prism_rtl::some_of(_m));
                auto&& d = std::get<1>(prism_rtl::some_of(_m));
                ({
                auto name = prism_rtl::cat(hf_2_5, "_dyn_", j + Nat(1u));
                auto port = prism_rtl::cat(name, "_port");
                call_then(start_dynamic_expr(w, menv_3_5, d), [=](std::tuple<Ex, Array<Read>> dynamic_expr_240343) {
                return ({
                    auto [ex, reads] = dynamic_expr_240343;
                    call_then(start_out_ty_of(lx_4_5, peel(type_at(lx_4_5, d.span))), [=](OutTy out_ty_of_240390) {
                    return ({
                        auto t = out_ty_of_240390;
                        !all_inited(w, reads)
                        ? prism_rtl::finished(std::tuple{w, en, ls})
                        : ({
                        auto w2 = ({
                            Wx this_ = w;
                            this_.taken = append(this_.taken, Array(std::vector{name, port}));
                            this_.getters = prelude::push(this_.getters, MethDef{.name = name, .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = t, .body = Array<Do>{}, .tail = ex, .doc = prism_rtl::cat("The host at `", hf_2_5, "`'s dynamic answer `", src_text(lx_4_5, lx_4_5->file, y.span), "`, read at the read point (round 3 DY).")});
                            this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{port})), OutTy(OutTy::OutRc{prism_rtl::rc(OutTy(OutTy::OutPort{prism_rtl::rc(OutTy(OutTy::OutUnit{}))}))})}), Ex(Ex::XCall{Text::lit("Rc::new"), Array(std::vector{Ex(Ex::XCall{Text::lit("Port::new"), Array<Ex>{}})})})}));
                            this_.fields = prelude::push(this_.fields, std::tuple{port, OutTy(OutTy::OutRc{prism_rtl::rc(OutTy(OutTy::OutPort{prism_rtl::rc(OutTy(OutTy::OutUnit{}))}))}), prism_rtl::cat("the dynamic answer `", name, "` moved: its blueprints push the child's place next tick")});
                            this_.moves = prelude::push(this_.moves, std::tuple{port, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{port}))})});
                            this_.dyn_answers = prelude::push(this_.dyn_answers, std::tuple{name, reads});
                            this_;
                        });
                        (prism_rtl::finished(std::tuple{w2, bind(en, prism_rtl::cat("#dyn", dyn_key(y)), Bn(Bn::BnLocal{Ex(Ex::XVar{name}), Holding(Holding::Owned{}), t})), prelude::push(ls, Do(Do::DoLet{Pa(Pa::PaBind{port}), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{port}))})}))}));
                    });
                    });
                });
                });
            });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{w, en, ls})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
    });
}


/// ?DynamicAnswer: fn Lx, Expr -> ?Expr
std::optional<ast::Expr> dynamic_answer(const Lx& lx, const ast::Expr& x) {
    return layer_of(type_at(lx, x.span)) != Layer(Layer::LyDyn{})
        ? std::optional<ast::Expr>{}
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<ast::Expr>> _v;
        auto&& _m = x.kind;
        if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
            auto&& m241820_0_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
            auto&& inner = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
            if (m241820_0_0 == Text::lit("$")) {
                _v.set(layer_of(type_at(lx, inner.span)) == Layer(Layer::LyDyn{})
                    ? std::optional(inner)
                    : std::optional<ast::Expr>{});
                goto _done;
            }
        }
        {
            _v.set(std::optional(x));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// DynKey: fn Expr -> Text
Text dyn_key(const ast::Expr& x) {
    return prism_rtl::cat(x.span.start, ":", x.span.end);
}


/// HostDocGetter: fn Text, Pos, [Place], [ForDef], [GenDef] -> MethDef
MethDef host_doc_getter(const Text& name, const Pos_& pos, const Array<Place>& places, const Array<ForDef>& builders, const Array<GenDef>& gens) {
    auto start = Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaMut{Text::lit("doc")})), OutTy(OutTy::OutMap{prism_rtl::rc(OutTy(OutTy::OutPath{})), prism_rtl::rc(elem_ty())})}), Ex(Ex::XCall{Text::lit("Map::new"), Array<Ex>{}})});
    auto body = document_body(({
        auto f = prism_rtl::rc(map_insert);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Do>(std::tuple<Ex, Ex>)>>(prism_rtl::rc([=](std::tuple<Ex, Ex> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0, a1)); });
        });
    })));
    }), places, builders, gens);
    return MethDef{.name = name, .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = OutTy(OutTy::OutMap{prism_rtl::rc(OutTy(OutTy::OutPath{})), prism_rtl::rc(elem_ty())}), .body = append(Array(std::vector{start}), body), .tail = Ex(Ex::XVar{Text::lit("doc")}), .doc = prism_rtl::cat("The document of the child hosted at place ", place_text(pos), " computed live: each of its places by its path relative to the child, its level at the read point (pick HO). Read only by the snapshot `$doc` answers from (pick ST).")};
}


/// SnapGetter: fn Text, OutTy, Text -> MethDef
MethDef snap_getter(const Text& name, const OutTy& t, const Text& doc) {
    return MethDef{.name = name, .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = t, .body = Array<Do>{}, .tail = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(name, "_snap")})), Text::lit("get"), Array(std::vector{Ex(Ex::XCx{})})}), .doc = doc};
}


/// StartedLine: fn Wx, ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> started_line(const Wx& wx, const std::optional<Bn>& bound_opt) {
    auto wx1 = ({
        Wx this_ = wx;
        this_.pos = next_pos(this_.pos);
        this_;
    });
    auto [id, wx2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
            auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
            _v.set(std::tuple{er.node_, wx1});
            goto _done;
        }
        {
            _v.set(({
                auto [nm, w] = fresh_name(wx1, Text::lit("started"));
                add_gn(w, nm, OutTy(OutTy::OutUnit{}), GnKind(GnKind::GnStarted{}), Nat(0u));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto wx3 = ({
        Wx this_ = wx2;
        this_.started = prelude::push(this_.started, id);
        this_;
    });
    return std::tuple{wx3, Wres(Wres::WrEv{ev_ref_of(wx3, id)})};
}


/// DeferLine: unbounded fn Wx, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
std::tuple<Wx, Wres> defer_line(const Wx& wx, const Env& menv, const Array<ast::Arg>& args, const ast::Expr& e, const std::optional<Nat>& target_opt) {
    auto lx = wx.lx;
    auto t = out_ty_of(lx, out_of(type_at(lx, e.span)));
    auto [field, wx1] = fresh_name(wx, Text::lit("deferred"));
    auto [id, wx2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
        if (prism_rtl::is_some(target_opt)) {
            auto&& n = prism_rtl::some_of(target_opt);
            _v.set(std::tuple{n, wx1});
            goto _done;
        }
        if (prism_rtl::is_none(target_opt)) {
            _v.set(add_gn(wx1, prism_rtl::cat(field, "_fired"), t, GnKind(GnKind::GnDeferred{}), Nat(0u)));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto wx3 = add_field_last(wx2, field, OutTy(OutTy::OutDefer{prism_rtl::rc(t)}), Text::lit("`@Defer`"), Ex(Ex::XCall{Text::lit("Defer::new"), Array<Ex>{}}));
    auto wx4 = ({
        Wx this_ = wx3;
        this_.defers = prelude::push(this_.defers, std::tuple{field, id});
        this_;
    });
    auto&& _m = index(args, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& a = prism_rtl::some_of(_m);
        auto [r, wx5] = event_ref(wx4, menv, a->value);
        return std::tuple{connect(wx5, r, Sk(Sk::SkArm{field})), Wres(Wres::WrEv{ev_ref_of(wx5, id)})};
    }
    if (prism_rtl::is_none(_m)) {
        return std::tuple{wx4, Wres(Wres::WrEv{ev_ref_of(wx4, id)})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// RunLine: unbounded fn Wx, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
std::tuple<Wx, Wres> run_line(const Wx& wx, const Env& benv, const Array<ast::Arg>& args, const ast::Expr& e, const std::optional<Nat>& target_opt) {
    auto lx = wx.lx;
    auto t = out_ty_of(lx, out_of(type_at(lx, e.span)));
    auto [p_, wx1] = fresh_name(wx, Text::lit("run"));
    auto wx2 = ({
        Wx this_ = wx1;
        this_.pos = next_pos(this_.pos);
        this_.taken = append(this_.taken, Array(std::vector{prism_rtl::cat(p_, "_job"), prism_rtl::cat(p_, "_again"), prism_rtl::cat(p_, "_started"), prism_rtl::cat(p_, "_turn")}));
        this_;
    });
    auto start = ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        auto&& _m = index(args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Ex> _v;
                auto&& _m = a->value.kind;
                if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                    auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                    _v.set(({
                        auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                        auto&& q_opt = std::get<0>(_q_opt);
                        (Ex(Ex::XPath{start_path(lx, or_(q_opt, Text::lit("")))}));
                    }));
                    goto _done;
                }
                {
                    _v.set(refusal(Text::lit("an `@Run` of a function value that is not a name")));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(refusal(Text::lit("an `@Run` without its function")));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto x = ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        auto&& _m = index(args, Nat(1u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(own(value_of(lx, benv, a->value)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Ex(Ex::XUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto wx3 = add_field(wx2, prism_rtl::cat(p_, "_job"), OutTy(OutTy::OutHold{prism_rtl::rc(OutTy(OutTy::OutJob{prism_rtl::rc(t)}))}), Text::lit("`@Run`'s job (`@Machine`'s state)"), Ex(Ex::XCall{Text::lit("Hold::new"), Array(std::vector{Ex(Ex::XApply{prism_rtl::rc(start), Array(std::vector{x})}), Ex(Ex::XCx{})})}));
    auto wx4 = add_field_last(wx3, prism_rtl::cat(p_, "_again"), OutTy(OutTy::OutDefer{prism_rtl::rc(OutTy(OutTy::OutUnit{}))}), Text::lit("`@Run`'s `!again`"), Ex(Ex::XCall{Text::lit("Defer::new"), Array<Ex>{}}));
    auto [s, wx5] = add_gn(wx4, prism_rtl::cat(p_, "_started"), OutTy(OutTy::OutUnit{}), GnKind(GnKind::GnStarted{}), Nat(0u));
    auto [a, wx6] = add_gn(wx5, prism_rtl::cat(p_, "_again"), OutTy(OutTy::OutUnit{}), GnKind(GnKind::GnDeferred{}), Nat(0u));
    auto [m, wx7] = lower::merge(wx6, prism_rtl::cat(p_, "_turn"), OutTy(OutTy::OutUnit{}), ev_ref_of(wx6, s), ev_ref_of(wx6, a));
    auto [res, wx8] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
        if (prism_rtl::is_some(target_opt)) {
            auto&& n = prism_rtl::some_of(target_opt);
            _v.set(std::tuple{n, wx7});
            goto _done;
        }
        if (prism_rtl::is_none(target_opt)) {
            _v.set(add_gn(wx7, prism_rtl::cat(p_, "_done"), t, GnKind(GnKind::GnNamed{}), Nat(0u)));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto wx9 = ({
        Wx this_ = connect(wx8, ev_ref_of(wx8, m), Sk(Sk::SkCycle{prism_rtl::cat(p_, "_job"), prism_rtl::cat(p_, "_again"), res}));
        this_.started = prelude::push(this_.started, s);
        this_.defers = prelude::push(this_.defers, std::tuple{prism_rtl::cat(p_, "_again"), a});
        this_;
    });
    return std::tuple{wx9, Wres(Wres::WrEv{ev_ref_of(wx9, res)})};
}


/// MachineLine: unbounded fn Wx, Env, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
std::tuple<Wx, Wres> machine_line(const Wx& wx, const Env& benv, const Env& menv, const Array<ast::Arg>& args, const ast::Expr& e, const std::optional<Nat>& target_opt) {
    auto lx = wx.lx;
    auto t = out_ty_of(lx, out_of(type_at(lx, e.span)));
    auto [f, wx1] = fresh_name(wx, Text::lit("machine"));
    auto step_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = a->value.kind;
                if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                    auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                    _v.set(({
                        auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                        auto&& q_opt = std::get<0>(_q_opt);
                        ({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        if (prism_rtl::is_some(q_opt)) {
                            auto&& q = prism_rtl::some_of(q_opt);
                            _v.set(value_path(lx, q));
                            goto _done;
                        }
                        if (prism_rtl::is_none(q_opt)) {
                            _v.set(Text::lit(""));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                {
                    _v.set(Text::lit(""));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _m = std::tuple{step_, index(args, Nat(1u)), index(args, Nat(2u))};
    if (prism_rtl::is_some(std::get<1>(_m)) && prism_rtl::is_some(std::get<2>(_m))) {
        auto&& sp = std::get<0>(_m);
        auto&& init = prism_rtl::some_of(std::get<1>(_m));
        auto&& ev = prism_rtl::some_of(std::get<2>(_m));
        if (sp != Text::lit("")) {
            auto st = out_ty_of(lx, peel(type_at(lx, init->value.span)));
            auto x = own(value_of(lx, benv, init->value));
            auto wx2 = add_field(wx1, prism_rtl::cat(f, "_state"), OutTy(OutTy::OutHold{prism_rtl::rc(st)}), Text::lit("`@Machine`'s state"), Ex(Ex::XCall{Text::lit("Hold::new"), Array(std::vector{x, Ex(Ex::XCx{})})}));
            auto [out, wx3] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
                if (prism_rtl::is_some(target_opt)) {
                    auto&& n = prism_rtl::some_of(target_opt);
                    _v.set(std::tuple{n, wx2});
                    goto _done;
                }
                if (prism_rtl::is_none(target_opt)) {
                    _v.set(add_gn(wx2, prism_rtl::cat(f, "_fired"), t, GnKind(GnKind::GnNamed{}), Nat(0u)));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto [r, wx4] = event_ref(wx3, menv, ev->value);
            return std::tuple{connect(wx4, r, Sk(Sk::SkMachine{prism_rtl::cat(f, "_state"), sp, out})), Wres(Wres::WrEv{ev_ref_of(wx4, out)})};
        }
    }
    {
        auto wx2 = ({
            Wx this_ = wx1;
            this_.build = prelude::push(this_.build, refusal_do(Text::lit("an `@Machine` whose step is not a named function")));
            this_;
        });
        return std::tuple{wx2, Wres(Wres::WrUnit{})};
    }
}


/// InlineWidget: unbounded fn Wx, Env, Env, Text, ValInfo, [Arg], Expr -> ((Wx, Wres))
std::tuple<Wx, Wres> inline_widget(const Wx& wx, const Env& benv, const Env& menv, const Text& qk, const check_env::ValInfo& v_, const Array<ast::Arg>& args, const ast::Expr& e) {
    auto lx = wx.lx;
    auto clauses = clauses_of(lx.g, qk);
    auto w_opt = widget_decl_of(lx.g, qk);
    auto [params, body_opt] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<ast::Pattern_>, std::optional<ast::Block>>> _v;
        if (prism_rtl::is_some(w_opt)) {
            auto&& wd = prism_rtl::some_of(w_opt);
            _v.set(std::tuple{Array<ast::Pattern_>{}, std::optional(wd.body)});
            goto _done;
        }
        if (prism_rtl::is_none(w_opt)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<ast::Pattern_>, std::optional<ast::Block>>> _v;
                {
                    auto&& m248756_0 = clauses;
                    if (m248756_0.size() == 1u) {
                        {
                            auto&& _c1 = index(m248756_0, Nat(0u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& c = prism_rtl::some_of(_c1);
                                _v.set(({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<Array<ast::Pattern_>, std::optional<ast::Block>>> _v;
                                    auto&& _m = c.body;
                                    if (prism_rtl::is<ast::FnBody::BodyBlock>(_m)) {
                                        auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(_m).a0;
                                        _v.set(std::tuple{c.params, std::optional(b)});
                                        goto _done;
                                    }
                                    if (prism_rtl::is<ast::FnBody::BodyExpr>(_m)) {
                                        auto&& x = prism_rtl::as<ast::FnBody::BodyExpr>(_m).a0;
                                        _v.set(std::tuple{c.params, std::optional(ast::Block{.stmts = Array(std::vector{ast::Stmt{.kind = ast::StmtKind(ast::StmtKind::SExpr{x}), .span = x.span}}), .inline_ = true, .span = x.span})});
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                }));
                                goto _done;
                            }
                        }
                    }
                }
                {
                    _v.set(std::tuple{Array<ast::Pattern_>{}, std::optional<ast::Block>{}});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is_none(body_opt)) {
        return len(clauses) == Nat(0u)
            ? ({
            auto wx2 = ({
                Wx this_ = wx;
                this_.build = prelude::push(this_.build, refusal_do(prism_rtl::cat("the builtin widget ", check_types::bare_name(qk))));
                this_;
            });
            std::tuple{wx2, Wres(Wres::WrUnit{})};
        })
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Wx, Wres>> _v;
            auto&& _m = index(args, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& a = prism_rtl::some_of(_m);
                _v.set(({
                    auto call = ast::Block{.stmts = Array(std::vector{ast::Stmt{.kind = ast::StmtKind(ast::StmtKind::SExpr{e}), .span = e.span}}), .inline_ = true, .span = e.span};
                    clause_widget_line(wx, menv, a->value, call, qk, v_, e);
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    auto wx2 = ({
                        Wx this_ = wx;
                        this_.build = prelude::push(this_.build, refusal_do(Text::lit("a widget of several clauses that takes no arguments")));
                        this_;
                    });
                    std::tuple{wx2, Wres(Wres::WrUnit{})};
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_some(body_opt)) {
        auto&& body = prism_rtl::some_of(body_opt);
        return wx.depth > Nat(16u)
            ? std::tuple{wx, Wres(Wres::WrUnit{})}
            : ({
            auto lxc = in_module_at(lx, v_->file, v_.home, lx.site);
            auto ptys = ({
                __label__ _done;
                prism_rtl::Slot<Array<check_types::Ty>> _v;
                auto&& _m = v_.scheme.ty;
                if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                    auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
                    _v.set(ps);
                    goto _done;
                }
                {
                    _v.set(Array<check_types::Ty>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [wx1, be1, me1] = run_to_end(fold_job(check_errors::range0(len(params)), std::tuple{wx, empty_env(), empty_env()}, ({
                auto params_1 = params;
                auto lxc_2 = lxc;
                auto ptys_3 = ptys;
                auto args_4 = args;
                auto benv_5 = benv;
                auto menv_6 = menv;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Env>>(std::tuple<std::tuple<Wx, Env, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Env>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto params_1_7 = params_1;
                    auto lxc_2_7 = lxc_2;
                    auto ptys_3_7 = ptys_3;
                    auto args_4_7 = args_4;
                    auto benv_5_7 = benv_5;
                    auto menv_6_7 = menv_6;
                    entered(once_job([=]() {
                    return ({
                        auto [w, be, me] = p0;
                        auto i = p1;
                        ({
                        auto p_ = or_(index(params_1_7, i), dummy_pat());
                        auto nkey = plain_binder(lxc_2_7, p_);
                        auto pty = or_(index(ptys_3_7, i), check_types::Ty(check_types::Ty::TyErr{}));
                        ({
                        auto&& _m = index(args_4_7, i);
                        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{w, be, me})
                        : prism_rtl::is_some(_m) ? ({
                        auto&& a = prism_rtl::some_of(_m);
                        prism_rtl::finished(bind_param(w, benv_5_7, menv_6_7, be, me, nkey, pty, a->value));
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                    });
                }));
                });
            }));
            })));
            auto inner = ({
                Wx this_ = wx1;
                this_.lx = lxc;
                this_.depth = this_.depth + Nat(1u);
                this_.result = Wres(Wres::WrUnit{});
                this_;
            });
            auto done = block_into(inner, be1, me1, body);
            auto back_ = ({
                Wx this_ = done;
                this_.lx = lx;
                this_.depth = wx.depth;
                this_.result = wx->result;
                this_;
            });
            std::tuple{back_, done->result};
        });
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?WidgetDeclOf: fn G, Text -> ?WidgetDecl
std::optional<ast::WidgetDecl> widget_decl_of(const check_env::G& g, const Text& qk) {
    return fold(g.defs, std::optional<ast::WidgetDecl>{}, [&](const std::optional<ast::WidgetDecl>& found_opt, const check_env::Def& d) { return d.qk == qk ? def_widget(d, found_opt) : found_opt; });
}


/// ?DefWidget: fn Def, ?WidgetDecl -> ?WidgetDecl
std::optional<ast::WidgetDecl> def_widget(const check_env::Def& d, const std::optional<ast::WidgetDecl>& other_opt) {
    auto&& _m = d.body;
    if (prism_rtl::is<check_env::DefBody::DbWidget>(_m)) {
        auto&& w = prism_rtl::as<check_env::DefBody::DbWidget>(_m).a0;
        return std::optional(w);
    }
    {
        return other_opt;
    }
}


/// BindParam: unbounded fn Wx, Env, Env, Env, Env, Text, Ty, Expr -> ((Wx, Env, Env))
std::tuple<Wx, Env, Env> bind_param(const Wx& wx, const Env& cbenv, const Env& cmenv, const Env& be, const Env& me, const Text& nkey, const check_types::Ty& pty, const ast::Expr& arg) {
    auto lx = wx.lx;
    auto t = out_ty_of(lx, peel(pty));
    auto&& _m = layer_of(pty);
    if (prism_rtl::is<Layer::LyBlueprint>(_m)) {
        auto b = Bn(Bn::BnWidget{arg, cbenv, cmenv, lx});
        return std::tuple{wx, bind(be, nkey, b), bind(me, nkey, b)};
    }
    if (prism_rtl::is<Layer::LyEv>(_m)) {
        auto [r, wx2] = event_ref(wx, cmenv, arg);
        auto b = Bn(Bn::BnEv{r, t});
        return std::tuple{wx2, bind(be, nkey, b), bind(me, nkey, b)};
    }
    if (prism_rtl::is<Layer::LyDyn>(_m)) {
        auto [ex, reads] = dynamic_expr(wx, cmenv, arg);
        auto b = Bn(Bn::BnDyn{ex, reads, t});
        return std::tuple{wx, bind(be, nkey, b), bind(me, nkey, b)};
    }
    {
        auto [rs, wx2] = fresh_name(wx, snake(nkey));
        auto v_ = own(value_of(lx, cbenv, arg));
        auto wx3 = ({
            Wx this_ = wx2;
            this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaBind{rs}), v_}));
            this_.fields = prelude::push(this_.fields, std::tuple{rs, t, prism_rtl::cat("`", nkey, "`")});
            this_.inits = prelude::push(this_.inits, std::tuple{rs, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{rs}))})});
            this_;
        });
        auto [be2, me2] = bind_plain(be, me, nkey, rs, t);
        return std::tuple{wx3, be2, me2};
    }
}


/// DynamicExpr: unbounded fn Wx, Env, Expr -> ((Ex, [Read]))
std::tuple<Ex, Array<Read>> dynamic_expr(const Wx& wx, const Env& menv, const ast::Expr& e) {
    auto v_ = value_of(wx.lx, menv, e);
    auto reads = fold(typed::exprs_in(e), Array<Read>{}, [&](const Array<Read>& acc, const ast::Expr& x) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Read>> _v;
            auto&& _m = x.kind;
            if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Read>> _v;
                    auto&& _m = prelude::get(menv->names, check_env::sname_key(n));
                    if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnHold>(prism_rtl::some_of(_m))) {
                        auto&& f = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(_m)).a0;
                        _v.set(add_read(acc, Read(Read::OwnRead{f})));
                        goto _done;
                    }
                    if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnDyn>(prism_rtl::some_of(_m))) {
                        auto&& rs = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a1;
                        _v.set(union_reads(acc, rs));
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return std::tuple{own(v_), reads};
}


prism_rtl::Turn<std::tuple<Ex, Array<Read>>> DynamicExpr::cycle() const {
    const auto& wx = this->wx;
    const auto& menv = this->menv;
    const auto& e = this->e;
    auto e_1 = e;
    auto menv_2 = menv;
    auto wx_3 = wx;
    return call_then(start_value_of(wx_3.lx, menv_2, e_1), [=](Vl value_of_253587) {
        return ({
            auto v_ = value_of_253587;
            call_then(typed::start_exprs_in(e_1), [=](Array<ast::Expr> exprs_in_253632) {
            return ({
                auto reads = fold(exprs_in_253632, Array<Read>{}, [&](const Array<Read>& acc, const ast::Expr& x) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Read>> _v;
                        auto&& _m = x.kind;
                        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<Array<Read>> _v;
                                auto&& _m = prelude::get(menv_2->names, check_env::sname_key(n));
                                if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnHold>(prism_rtl::some_of(_m))) {
                                    auto&& f = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(_m)).a0;
                                    _v.set(add_read(acc, Read(Read::OwnRead{f})));
                                    goto _done;
                                }
                                if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnDyn>(prism_rtl::some_of(_m))) {
                                    auto&& rs = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a1;
                                    _v.set(union_reads(acc, rs));
                                    goto _done;
                                }
                                {
                                    _v.set(acc);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        {
                            _v.set(acc);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                (prism_rtl::finished(std::tuple{own(v_), reads}));
            });
        });
        });
    });
}


/// `Start DynamicExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Ex, Array<Read>>> start_dynamic_expr(Wx wx, Env menv, ast::Expr e) {
    return prism_rtl::make_rc<DynamicExpr>(wx, menv, e);
}


/// NeverEvent: fn Wx, OutTy -> ((EvRef, Wx))
std::tuple<EvRef, Wx> never_event(const Wx& wx, const OutTy& t) {
    auto [id, wx2] = add_gn(wx, Text::lit("never"), t, GnKind(GnKind::GnNever{}), Nat(0u));
    return std::tuple{ev_ref_of(wx2, id), wx2};
}


/// EventRef: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
std::tuple<EvRef, Wx> event_ref(const Wx& wx, const Env& menv, const ast::Expr& e) {
    auto lx = wx.lx;
    auto t = out_ty_of(lx, peel(type_at(lx, e.span)));
    auto&& _m = e.kind;
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        return event_ref(wx, menv, x);
    }
    if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        auto&& _m = prelude::get(menv->names, check_env::sname_key(n));
        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(_m))) {
            auto&& r = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(_m)).a0;
            return r.owner == wx.node_
                ? std::tuple{r, wx}
                : never_event(crossed(wx, prism_rtl::cat("the event `", check_env::sname_key(n), "`, of node `", r.owner, "`,")), t);
        }
        {
            return never_event(wx, t);
        }
    }
    if (prism_rtl::is<ast::ExprKind::EBinary>(_m)) {
        auto&& m254496_2_0 = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
        if (m254496_2_0 == Text::lit("<|")) {
            auto [lr, w1] = event_ref(wx, menv, l);
            auto [rr, w2] = event_ref(w1, menv, r);
            auto [nm, w3] = fresh_name(w2, Text::lit("anon"));
            auto [id, w4] = lower::merge(w3, nm, t, lr, rr);
            return std::tuple{ev_ref_of(w4, id), w4};
        }
    }
    if (prism_rtl::is<ast::ExprKind::EBinary>(_m)) {
        auto&& m254496_3_0 = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
        if (m254496_3_0 == Text::lit("on")) {
            auto [rr, w1] = event_ref(wx, menv, r);
            auto value = own(value_of(lx, menv, l));
            return std::tuple{EvRef{.node_ = rr.node_, .owner = rr.owner, .pipe = ({
                auto rr_1 = rr;
                auto value_2 = value;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>)>>(prism_rtl::rc([=](std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto rr_1_3 = rr_1;
                    auto value_2_3 = value_2;
                    entered(once_job([=]() {
                    return ({
                        auto x = p0;
                        auto k_fn = p1;
                        rr_1_3.pipe(std::tuple{x, ({
                        auto k_fn_3 = k_fn;
                        auto value_2_3_4 = value_2_3;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>(prism_rtl::rc([=](Ex p0) {
                        return ({
                            auto k_fn_3_4 = k_fn_3;
                            auto value_2_3_4_4 = value_2_3_4;
                            entered(once_job([=]() {
                            return ({
                                static_cast<void>(p0);
                                k_fn_3_4(value_2_3_4_4)->cycle();
                            });
                        }));
                        });
                    })));
                    })})->cycle();
                    });
                }));
                });
            })));
            })}, w1};
        }
    }
    if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
        auto&& _m = callee_key(lx, c);
        {
            auto&& m255352_0 = _m;
            if (m255352_0 == Text::lit("Prelude.!Filter")) {
                return filter_event(wx, menv, args, false);
            }
        }
        {
            auto&& m255352_1 = _m;
            if (m255352_1 == Text::lit("Prelude.!Present")) {
                return filter_event(wx, menv, args, true);
            }
        }
        {
            auto&& m255352_2 = _m;
            if (m255352_2 == Text::lit("Prelude.!Gate")) {
                return gate_event(wx, menv, args);
            }
        }
        {
            auto&& m255352_3 = _m;
            if (m255352_3 == Text::lit("Prelude.!Union")) {
                return pair_event(wx, menv, args, GnKind(GnKind::GnUnion{}), t);
            }
        }
        {
            auto&& m255352_4 = _m;
            if (m255352_4 == Text::lit("Prelude.!Both")) {
                return pair_event(wx, menv, args, GnKind(GnKind::GnBoth{}), t);
            }
        }
        {
            auto&& m255352_5 = _m;
            if (m255352_5 == Text::lit("Prelude.!Except")) {
                return pair_event(wx, menv, args, GnKind(GnKind::GnExcept{}), t);
            }
        }
        {
            auto&& m255352_6 = _m;
            if (m255352_6 == Text::lit("Prelude.!MergeAll")) {
                return merge_all_event(wx, menv, args, t);
            }
        }
        {
            auto&& m255352_7 = _m;
            if (m255352_7 == Text::lit("Prelude.!Updated")) {
                return updated_event(wx, menv, args, t);
            }
        }
        {
            return event_map(wx, menv, e);
        }
    }
    if (prism_rtl::is<ast::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::EIf>(_m).a2)) {
        auto&& m254496_5_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
        if (prism_rtl::is<ast::Cond::CondExpr>(m254496_5_0)) {
            auto&& c = prism_rtl::as<ast::Cond::CondExpr>(m254496_5_0).a0;
            auto&& _m = std::tuple{block_expr(then_b), block_expr(else_b)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& a = prism_rtl::some_of(std::get<0>(_m));
                auto&& b = prism_rtl::some_of(std::get<1>(_m));
                return event_if(wx, menv, c, a, b, t);
            }
            {
                return event_map(wx, menv, e);
            }
        }
    }
    {
        return event_map(wx, menv, e);
    }
}


prism_rtl::Turn<std::tuple<EvRef, Wx>> EventRef::cycle() const {
    const auto& wx = this->wx;
    const auto& menv = this->menv;
    const auto& e = this->e;
    auto lx = wx.lx;
    auto e_1 = e;
    auto menv_2 = menv;
    auto wx_3 = wx;
    return call_then(start_out_ty_of(lx, peel(type_at(lx, e_1.span))), [=](OutTy out_ty_of_254453) {
        return ({
            auto t = out_ty_of_254453;
            ({
            auto&& _m = e_1.kind;
            prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            prism_rtl::more(prism_rtl::rc(EventRef(wx_3, menv_2, x)));
        })
            : prism_rtl::is<ast::ExprKind::EName>(_m) ? ({
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            ({
            auto&& _m = prelude::get(menv_2->names, check_env::sname_key(n));
            prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(_m)) ? ({
            auto&& r = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(_m)).a0;
            r.owner == wx_3.node_
            ? prism_rtl::finished(std::tuple{r, wx_3})
            : prism_rtl::finished(never_event(crossed(wx_3, prism_rtl::cat("the event `", check_env::sname_key(n), "`, of node `", r.owner, "`,")), t));
        })
            : prism_rtl::finished(never_event(wx_3, t));
        });
        })
            : prism_rtl::is<ast::ExprKind::EBinary>(_m) && ({
            auto&& m254496_2_0 = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
            (m254496_2_0 == Text::lit("<|"));
        }) ? ({
            auto&& m254496_2_0 = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
            ({
            auto l_4 = l;
            auto r_5 = r;
            call_then(start_event_ref(wx_3, menv_2, l_4), [=](std::tuple<EvRef, Wx> event_ref_254873) {
            return ({
                auto [lr, w1] = event_ref_254873;
                call_then(start_event_ref(w1, menv_2, r_5), [=](std::tuple<EvRef, Wx> event_ref_254923) {
                return ({
                    auto [rr, w2] = event_ref_254923;
                    auto [nm, w3] = fresh_name(w2, Text::lit("anon"));
                    auto [id, w4] = lower::merge(w3, nm, t, lr, rr);
                    (prism_rtl::finished(std::tuple{ev_ref_of(w4, id), w4}));
                });
            });
            });
        });
        });
        })
            : prism_rtl::is<ast::ExprKind::EBinary>(_m) && ({
            auto&& m254496_3_0 = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
            (m254496_3_0 == Text::lit("on"));
        }) ? ({
            auto&& m254496_3_0 = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
            ({
            auto l_4 = l;
            auto r_5 = r;
            call_then(start_event_ref(wx_3, menv_2, r_5), [=](std::tuple<EvRef, Wx> event_ref_255141) {
            return ({
                auto [rr, w1] = event_ref_255141;
                call_then(start_value_of(lx, menv_2, l_4), [=](Vl value_of_255191) {
                return ({
                    auto value = own(value_of_255191);
                    (prism_rtl::finished(std::tuple{EvRef{.node_ = rr.node_, .owner = rr.owner, .pipe = ({
                    auto rr_6 = rr;
                    auto value_7 = value;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>)>>(prism_rtl::rc([=](std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto rr_6_8 = rr_6;
                        auto value_7_8 = value_7;
                        entered(once_job([=]() {
                        return ({
                            auto x = p0;
                            auto k_fn = p1;
                            rr_6_8.pipe(std::tuple{x, ({
                            auto k_fn_8 = k_fn;
                            auto value_7_8_9 = value_7_8;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>(prism_rtl::rc([=](Ex p0) {
                            return ({
                                auto k_fn_8_9 = k_fn_8;
                                auto value_7_8_9_9 = value_7_8_9;
                                entered(once_job([=]() {
                                return ({
                                    static_cast<void>(p0);
                                    k_fn_8_9(value_7_8_9_9)->cycle();
                                });
                            }));
                            });
                        })));
                        })})->cycle();
                        });
                    }));
                    });
                })));
                })}, w1}));
                });
            });
            });
        });
        });
        })
            : prism_rtl::is<ast::ExprKind::ECall>(_m) ? ({
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            ({
            auto&& _m = callee_key(lx, c);
            ({
            auto&& m255352_0 = _m;
            (m255352_0 == Text::lit("Prelude.!Filter"));
        }) ? ({
            auto&& m255352_0 = _m;
            prism_rtl::finished(filter_event(wx_3, menv_2, args, false));
        })
            : ({
            auto&& m255352_1 = _m;
            (m255352_1 == Text::lit("Prelude.!Present"));
        }) ? ({
            auto&& m255352_1 = _m;
            prism_rtl::finished(filter_event(wx_3, menv_2, args, true));
        })
            : ({
            auto&& m255352_2 = _m;
            (m255352_2 == Text::lit("Prelude.!Gate"));
        }) ? ({
            auto&& m255352_2 = _m;
            prism_rtl::finished(gate_event(wx_3, menv_2, args));
        })
            : ({
            auto&& m255352_3 = _m;
            (m255352_3 == Text::lit("Prelude.!Union"));
        }) ? ({
            auto&& m255352_3 = _m;
            prism_rtl::finished(pair_event(wx_3, menv_2, args, GnKind(GnKind::GnUnion{}), t));
        })
            : ({
            auto&& m255352_4 = _m;
            (m255352_4 == Text::lit("Prelude.!Both"));
        }) ? ({
            auto&& m255352_4 = _m;
            prism_rtl::finished(pair_event(wx_3, menv_2, args, GnKind(GnKind::GnBoth{}), t));
        })
            : ({
            auto&& m255352_5 = _m;
            (m255352_5 == Text::lit("Prelude.!Except"));
        }) ? ({
            auto&& m255352_5 = _m;
            prism_rtl::finished(pair_event(wx_3, menv_2, args, GnKind(GnKind::GnExcept{}), t));
        })
            : ({
            auto&& m255352_6 = _m;
            (m255352_6 == Text::lit("Prelude.!MergeAll"));
        }) ? ({
            auto&& m255352_6 = _m;
            prism_rtl::finished(merge_all_event(wx_3, menv_2, args, t));
        })
            : ({
            auto&& m255352_7 = _m;
            (m255352_7 == Text::lit("Prelude.!Updated"));
        }) ? ({
            auto&& m255352_7 = _m;
            prism_rtl::finished(updated_event(wx_3, menv_2, args, t));
        })
            : prism_rtl::finished(event_map(wx_3, menv_2, e_1));
        });
        })
            : prism_rtl::is<ast::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::EIf>(_m).a2) && ({
            auto&& m254496_5_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
            auto&& else_b = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
            prism_rtl::is<ast::Cond::CondExpr>(m254496_5_0);
        }) ? ({
            auto&& m254496_5_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
            auto&& else_b = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
            auto&& c = prism_rtl::as<ast::Cond::CondExpr>(m254496_5_0).a0;
            ({
            auto&& _m = std::tuple{block_expr(then_b), block_expr(else_b)};
            prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m)) ? ({
            auto&& a = prism_rtl::some_of(std::get<0>(_m));
            auto&& b = prism_rtl::some_of(std::get<1>(_m));
            prism_rtl::finished(event_if(wx_3, menv_2, c, a, b, t));
        })
            : prism_rtl::finished(event_map(wx_3, menv_2, e_1));
        });
        })
            : prism_rtl::finished(event_map(wx_3, menv_2, e_1));
        });
        });
    });
}


/// `Start EventRef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<EvRef, Wx>> start_event_ref(Wx wx, Env menv, ast::Expr e) {
    return prism_rtl::make_rc<EventRef>(wx, menv, e);
}


/// EventIf: unbounded fn Wx, Env, Expr, Expr, Expr, OutTy -> ((EvRef, Wx))
std::tuple<EvRef, Wx> event_if(const Wx& wx, const Env& menv, const ast::Expr& c, const ast::Expr& a, const ast::Expr& b, const OutTy& t) {
    auto cond = as_bool(value_of(wx.lx, menv, c));
    auto [ra, w1] = event_ref(wx, menv, a);
    auto [rb, w2] = event_ref(w1, menv, b);
    auto ga = EvRef{.node_ = ra.node_, .owner = ra.owner, .pipe = ({
        auto ra_1 = ra;
        auto cond_2 = cond;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>)>>(prism_rtl::rc([=](std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ra_1_3 = ra_1;
            auto cond_2_3 = cond_2;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                auto k_fn = p1;
                ra_1_3.pipe(std::tuple{x, ({
                auto cond_2_3_3 = cond_2_3;
                auto k_fn_3 = k_fn;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>(prism_rtl::rc([=](Ex p0) {
                return ({
                    auto cond_2_3_3_4 = cond_2_3_3;
                    auto k_fn_3_4 = k_fn_3;
                    entered(once_job([=]() {
                    return ({
                        auto y = p0;
                        call_value(k_fn_3_4(y), [=](Array<Do> k_256630) { return prism_rtl::finished(Array(std::vector{Do(Do::DoIf{cond_2_3_3_4, k_256630, Array<Do>{}})})); });
                    });
                }));
                });
            })));
            })})->cycle();
            });
        }));
        });
    })));
    })};
    auto gb = EvRef{.node_ = rb.node_, .owner = rb.owner, .pipe = ({
        auto rb_1 = rb;
        auto cond_2 = cond;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>)>>(prism_rtl::rc([=](std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rb_1_3 = rb_1;
            auto cond_2_3 = cond_2;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                auto k_fn = p1;
                rb_1_3.pipe(std::tuple{x, ({
                auto cond_2_3_3 = cond_2_3;
                auto k_fn_3 = k_fn;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>(prism_rtl::rc([=](Ex p0) {
                return ({
                    auto cond_2_3_3_4 = cond_2_3_3;
                    auto k_fn_3_4 = k_fn_3;
                    entered(once_job([=]() {
                    return ({
                        auto y = p0;
                        call_value(k_fn_3_4(y), [=](Array<Do> k_256768) { return prism_rtl::finished(Array(std::vector{Do(Do::DoIf{Ex(Ex::XBin{Text::lit("=="), prism_rtl::rc(cond_2_3_3_4), prism_rtl::rc(Ex(Ex::XBool{false}))}), k_256768, Array<Do>{}})})); });
                    });
                }));
                });
            })));
            })})->cycle();
            });
        }));
        });
    })));
    })};
    auto [nm, w3] = fresh_name(w2, Text::lit("chosen"));
    auto [id, w4] = lower::merge(w3, nm, t, ga, gb);
    return std::tuple{ev_ref_of(w4, id), w4};
}


/// ?BlockExpr: fn Block -> ?Expr
std::optional<ast::Expr> block_expr(const ast::Block& b) {
    auto&& _m = b.stmts;
    {
        auto&& m257002_0 = _m;
        if (m257002_0.size() == 1u) {
            {
                auto&& _c1 = index(m257002_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& st = prism_rtl::some_of(_c1);
                    auto&& _m = st.kind;
                    if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
                        auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
                        return std::optional(x);
                    }
                    {
                        return std::optional<ast::Expr>{};
                    }
                }
            }
        }
    }
    {
        return std::optional<ast::Expr>{};
    }
}


/// CalleeKey: fn Lx, Expr -> Text
Text callee_key(const Lx& lx, const ast::Expr& c) {
    auto&& _m = c.kind;
    if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
        auto&& q_opt = std::get<0>(_q_opt);
        return or_(q_opt, Text::lit(""));
    }
    {
        return Text::lit("");
    }
}


/// PairEvent: unbounded fn Wx, Env, [Arg], GnKind, OutTy -> ((EvRef, Wx))
std::tuple<EvRef, Wx> pair_event(const Wx& wx, const Env& menv, const Array<ast::Arg>& args, const GnKind& kind, const OutTy& t) {
    auto&& _m = std::tuple{index(args, Nat(0u)), index(args, Nat(1u))};
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        auto&& a = prism_rtl::some_of(std::get<0>(_m));
        auto&& b = prism_rtl::some_of(std::get<1>(_m));
        auto [ra, w1] = event_ref(wx, menv, a->value);
        auto [rb, w2] = event_ref(w1, menv, b->value);
        auto lt = out_ty_of(wx.lx, peel(type_at(wx.lx, a->value.span)));
        auto rt = out_ty_of(wx.lx, peel(type_at(wx.lx, b->value.span)));
        auto [nm, w3] = fresh_name(w2, kind_word(kind));
        auto [id, w4] = combinator(w3, nm, t, kind, ra, rb, lt, rt);
        return std::tuple{ev_ref_of(w4, id), w4};
    }
    {
        return never_event(wx, t);
    }
}


/// MergeAllEvent: unbounded fn Wx, Env, [Arg], OutTy -> ((EvRef, Wx))
std::tuple<EvRef, Wx> merge_all_event(const Wx& wx, const Env& menv, const Array<ast::Arg>& args, const OutTy& t) {
    auto&& _m = index(args, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& a = prism_rtl::some_of(_m);
        auto&& _m = a->value.kind;
        if (prism_rtl::is<ast::ExprKind::EArray>(_m)) {
            auto&& es = prism_rtl::as<ast::ExprKind::EArray>(_m).a0;
            auto et = ({
                __label__ _done;
                prism_rtl::Slot<OutTy> _v;
                if (prism_rtl::is<OutTy::OutArray>(t)) {
                    auto&& x = prism_rtl::as<OutTy::OutArray>(t).a0;
                    _v.set(x);
                    goto _done;
                }
                {
                    _v.set(OutTy(OutTy::OutUnit{}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [nm, w1] = fresh_name(wx, Text::lit("merged"));
            auto [id, w2] = add_gn(w1, nm, t, GnKind(GnKind::GnMergeAll{}), Nat(1u));
            auto ins = each(check_errors::range0(len(es)), [&](const Nat& i) { return prism_rtl::cat(nm, "_", i); });
            auto w3 = fold(ins, w2, [&](const Wx& w, const Text& f) { return add_field_last(w, f, OutTy(OutTy::OutStamped{prism_rtl::rc(et)}), Text::lit("an input of `!MergeAll`"), Ex(Ex::XCall{Text::lit("Stamped::new"), Array<Ex>{}})); });
            auto w4 = ({
                Wx this_ = w3;
                this_.gns = each(this_.gns, [&](const Gn& n) { return n.id == id ? with_inputs(n, ins) : n; });
                this_;
            });
            auto w5 = run_to_end(fold_job(check_errors::range0(len(es)), w4, ({
                auto menv_1 = menv;
                auto es_2 = es;
                auto a_3 = a;
                auto id_4 = id;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Wx>(std::tuple<Wx, Nat>)>>(prism_rtl::rc([=](std::tuple<Wx, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto menv_1_5 = menv_1;
                    auto es_2_5 = es_2;
                    auto a_3_5 = a_3;
                    auto id_4_5 = id_4;
                    entered(once_job([=]() {
                    return ({
                        auto w = p0;
                        auto i = p1;
                        call_then(start_event_ref(w, menv_1_5, or_(index(es_2_5, i), a_3_5->value)), [=](std::tuple<EvRef, Wx> event_ref_258936) {
                        return ({
                            auto [r, w6] = event_ref_258936;
                            (prism_rtl::finished(connect(w6, r, Sk(Sk::SkIn{id_4_5, i}))));
                        });
                    });
                    });
                }));
                });
            })));
            })));
            return std::tuple{ev_ref_of(w5, id), w5};
        }
        {
            auto [r, w1] = never_event(wx, t);
            auto w2 = ({
                Wx this_ = w1;
                this_.build = prelude::push(this_.build, refusal_do(Text::lit("`!MergeAll` of a list that is not a literal")));
                this_;
            });
            return std::tuple{r, w2};
        }
    }
    if (prism_rtl::is_none(_m)) {
        return never_event(wx, t);
    }
    prism_rtl::unreachable("no arm matched");
}


/// UpdatedEvent: unbounded fn Wx, Env, [Arg], OutTy -> ((EvRef, Wx))
std::tuple<EvRef, Wx> updated_event(const Wx& wx, const Env& menv, const Array<ast::Arg>& args, const OutTy& t) {
    auto&& _m = index(args, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& a = prism_rtl::some_of(_m);
        auto [ex, reads] = dynamic_expr(wx, menv, a->value);
        auto [nm, w1] = fresh_name(wx, Text::lit("updated"));
        auto [id, w2] = add_gn(w1, nm, t, GnKind(GnKind::GnUpdated{}), Nat(1u));
        auto w3 = add_field_last(w2, prism_rtl::cat(nm, "_moved"), OutTy(OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{OutTy(OutTy::OutBool{})})}), prism_rtl::cat("a hold `!", nm, "`'s dynamic reads was written this tick"), Ex(Ex::XCall{Text::lit("Cell::new"), Array(std::vector{Ex(Ex::XBool{false})})}));
        auto w4 = ({
            Wx this_ = w3;
            this_.gns = each(this_.gns, [&](const Gn& n) { return n.id == id ? with_reads(n, reads) : n; });
            this_.getters = prelude::push(this_.getters, MethDef{.name = prism_rtl::cat(nm, "_value"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = t, .body = Array<Do>{}, .tail = ex, .doc = prism_rtl::cat("The dynamic `!", nm, "` is the event half of, which the wake reads after the tick.")});
            this_;
        });
        return std::tuple{ev_ref_of(w4, id), w4};
    }
    if (prism_rtl::is_none(_m)) {
        return never_event(wx, t);
    }
    prism_rtl::unreachable("no arm matched");
}


/// FilterEvent: unbounded fn Wx, Env, [Arg], Bool -> ((EvRef, Wx))
std::tuple<EvRef, Wx> filter_event(const Wx& wx, const Env& menv, const Array<ast::Arg>& args, const bool& is_unit) {
    auto&& _m = index(args, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return never_event(wx, OutTy(OutTy::OutUnit{}));
    }
    if (prism_rtl::is_some(_m)) {
        auto&& a = prism_rtl::some_of(_m);
        auto [r, w1] = event_ref(wx, menv, a->value);
        auto bound = is_unit ? Pa(Pa::PaWild{}) : Pa(Pa::PaBind{Text::lit("w")});
        auto pipe = ({
            auto r_1 = r;
            auto bound_2 = bound;
            auto is_unit_3 = is_unit;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>)>>(prism_rtl::rc([=](std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto r_1_4 = r_1;
                auto bound_2_4 = bound_2;
                auto is_unit_3_4 = is_unit_3;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    auto k_fn = p1;
                    r_1_4.pipe(std::tuple{x, ({
                    auto bound_2_4_4 = bound_2_4;
                    auto k_fn_4 = k_fn;
                    auto is_unit_3_4_5 = is_unit_3_4;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>(prism_rtl::rc([=](Ex p0) {
                    return ({
                        auto bound_2_4_4_5 = bound_2_4_4;
                        auto k_fn_4_5 = k_fn_4;
                        auto is_unit_3_4_5_5 = is_unit_3_4_5;
                        entered(once_job([=]() {
                        return ({
                            auto y = p0;
                            call_value(k_fn_4_5(is_unit_3_4_5_5 ? Ex(Ex::XUnit{}) : Ex(Ex::XVar{Text::lit("w")})), [=](Array<Do> k_261298) { return prism_rtl::finished(Array(std::vector{Do(Do::DoIfLet{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{bound_2_4_4_5})}), y, k_261298, Array<Do>{}})})); });
                        });
                    }));
                    });
                })));
                })})->cycle();
                });
            }));
            });
        })));
        });
        return std::tuple{EvRef{.node_ = r.node_, .owner = r.owner, .pipe = pipe}, w1};
    }
    prism_rtl::unreachable("no arm matched");
}


/// GateEvent: unbounded fn Wx, Env, [Arg] -> ((EvRef, Wx))
std::tuple<EvRef, Wx> gate_event(const Wx& wx, const Env& menv, const Array<ast::Arg>& args) {
    auto&& _m = index(args, Nat(1u));
    if (prism_rtl::is_none(_m)) {
        return never_event(wx, OutTy(OutTy::OutUnit{}));
    }
    if (prism_rtl::is_some(_m)) {
        auto&& a = prism_rtl::some_of(_m);
        auto [r, w1] = event_ref(wx, menv, a->value);
        auto cond = ({
            __label__ _done;
            prism_rtl::Slot<Ex> _v;
            auto&& _m = index(args, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                _v.set(as_bool(value_of(wx.lx, menv, b->value)));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Ex(Ex::XBool{false}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto pipe = ({
            auto r_1 = r;
            auto cond_2 = cond;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>)>>(prism_rtl::rc([=](std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto r_1_3 = r_1;
                auto cond_2_3 = cond_2;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    auto k_fn = p1;
                    r_1_3.pipe(std::tuple{x, ({
                    auto cond_2_3_3 = cond_2_3;
                    auto k_fn_3 = k_fn;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>(prism_rtl::rc([=](Ex p0) {
                    return ({
                        auto cond_2_3_3_4 = cond_2_3_3;
                        auto k_fn_3_4 = k_fn_3;
                        entered(once_job([=]() {
                        return ({
                            auto y = p0;
                            call_value(k_fn_3_4(y), [=](Array<Do> k_261831) { return prism_rtl::finished(Array(std::vector{Do(Do::DoIf{cond_2_3_3_4, k_261831, Array<Do>{}})})); });
                        });
                    }));
                    });
                })));
                })})->cycle();
                });
            }));
            });
        })));
        });
        return std::tuple{EvRef{.node_ = r.node_, .owner = r.owner, .pipe = pipe}, w1};
    }
    prism_rtl::unreachable("no arm matched");
}


/// EventMap: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
std::tuple<EvRef, Wx> event_map(const Wx& wx, const Env& menv, const ast::Expr& e) {
    auto lx = wx.lx;
    auto t = out_ty_of(lx, peel(type_at(lx, e.span)));
    auto evs = filter(operands(e), [&](const ast::Expr& x) { return layer_of(type_at(lx, x.span)) == Layer(Layer::LyEv{}); });
    {
        auto&& m262313_0 = evs;
        if (m262313_0.size() == 1u) {
            {
                auto&& _c1 = index(m262313_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one = prism_rtl::some_of(_c1);
                    auto [r, w1] = event_ref(wx, menv, one);
                    auto et = out_ty_of(lx, peel(type_at(lx, one.span)));
                    auto k = place_key(lx, one.span);
                    auto pipe = ({
                        auto r_1 = r;
                        auto lx_2 = lx;
                        auto menv_3 = menv;
                        auto k_4 = k;
                        auto et_5 = et;
                        auto e_6 = e;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>)>>(prism_rtl::rc([=](std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto r_1_7 = r_1;
                            auto lx_2_7 = lx_2;
                            auto menv_3_7 = menv_3;
                            auto k_4_7 = k_4;
                            auto et_5_7 = et_5;
                            auto e_6_7 = e_6;
                            entered(once_job([=]() {
                            return ({
                                auto x = p0;
                                auto k_fn = p1;
                                r_1_7.pipe(std::tuple{x, ({
                                auto k_fn_7 = k_fn;
                                auto lx_2_7_8 = lx_2_7;
                                auto menv_3_7_8 = menv_3_7;
                                auto k_4_7_8 = k_4_7;
                                auto et_5_7_8 = et_5_7;
                                auto e_6_7_8 = e_6_7;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>(prism_rtl::rc([=](Ex p0) {
                                return ({
                                    auto k_fn_7_8 = k_fn_7;
                                    auto lx_2_7_8_8 = lx_2_7_8;
                                    auto menv_3_7_8_8 = menv_3_7_8;
                                    auto k_4_7_8_8 = k_4_7_8;
                                    auto et_5_7_8_8 = et_5_7_8;
                                    auto e_6_7_8_8 = e_6_7_8;
                                    entered(once_job([=]() {
                                    return ({
                                        auto y = p0;
                                        call_then(start_value_of(lx_2_7_8_8, bind_span(menv_3_7_8_8, k_4_7_8_8, firing_value(y, et_5_7_8_8)), e_6_7_8_8), [=](Vl value_of_262550) { return k_fn_7_8(own(value_of_262550))->cycle(); });
                                    });
                                }));
                                });
                            })));
                            })})->cycle();
                            });
                        }));
                        });
                    })));
                    });
                    return std::tuple{EvRef{.node_ = r.node_, .owner = r.owner, .pipe = pipe}, w1};
                }
            }
        }
    }
    {
        return never_event(wx, t);
    }
}


/// FiringValue: fn Ex, OutTy -> Vl
Vl firing_value(const Ex& ex0, const OutTy& t) {
    if (prism_rtl::is<Ex::XVar>(ex0)) {
        auto&& n = prism_rtl::as<Ex::XVar>(ex0).a0;
        return Vl(Vl::VlPlace{Ex(Ex::XVar{n}), Holding(Holding::Owned{}), t});
    }
    if (prism_rtl::is<Ex::XUnit>(ex0)) {
        return Vl(Vl::VlPlace{Ex(Ex::XUnit{}), Holding(Holding::Owned{}), t});
    }
    {
        auto&& x = ex0;
        return Vl(Vl::VlOwned{x, t});
    }
}


/// Operands: fn Expr -> [Expr]
Array<ast::Expr> operands(const ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
        return append(Array(std::vector{c}), each(args, [&](const ast::Arg& a) { return a->value; }));
    }
    if (prism_rtl::is<ast::ExprKind::EMethod>(_m)) {
        auto&& r = prism_rtl::as<ast::ExprKind::EMethod>(_m).a0;
        auto&& args = prism_rtl::as<ast::ExprKind::EMethod>(_m).a2;
        return append(Array(std::vector{r}), each(args, [&](const ast::Arg& a) { return a->value; }));
    }
    if (prism_rtl::is<ast::ExprKind::EBinary>(_m)) {
        auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
        return Array(std::vector{l, r});
    }
    if (prism_rtl::is<ast::ExprKind::EUnary>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EUnary>(_m).a1;
        return Array(std::vector{x});
    }
    if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
        return Array(std::vector{x});
    }
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        return Array(std::vector{x});
    }
    if (prism_rtl::is<ast::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
        return Array(std::vector{r});
    }
    if (prism_rtl::is<ast::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
        auto&& i = prism_rtl::as<ast::ExprKind::EIndex>(_m).a1;
        return Array(std::vector{r, i});
    }
    if (prism_rtl::is<ast::ExprKind::ETuple>(_m)) {
        auto&& es = prism_rtl::as<ast::ExprKind::ETuple>(_m).a0;
        return es;
    }
    if (prism_rtl::is<ast::ExprKind::EArray>(_m)) {
        auto&& es = prism_rtl::as<ast::ExprKind::EArray>(_m).a0;
        return es;
    }
    if (prism_rtl::is<ast::ExprKind::EMap>(_m)) {
        auto&& kvs = prism_rtl::as<ast::ExprKind::EMap>(_m).a0;
        return fold(kvs, Array<ast::Expr>{}, [&](const Array<ast::Expr>& acc, const std::tuple<ast::Expr, ast::Expr>& _p1) {
            auto&& k = std::get<0>(_p1);
            auto&& v_ = std::get<1>(_p1);
            return append(acc, Array(std::vector{k, v_}));
        });
    }
    if (prism_rtl::is<ast::ExprKind::ELit>(_m)) {
        auto&& l = prism_rtl::as<ast::ExprKind::ELit>(_m).a0;
        auto&& _m = l.kind;
        if (prism_rtl::is<ast::LitKind::LText>(_m)) {
            auto&& segs = prism_rtl::as<ast::LitKind::LText>(_m).a0;
            return fold(segs, Array<ast::Expr>{}, [&](const Array<ast::Expr>& acc, const ast::TextSeg& sg) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<ast::Expr>> _v;
                    if (prism_rtl::is<ast::TextSeg::SegPlaceholder>(sg)) {
                        auto&& x = prism_rtl::as<ast::TextSeg::SegPlaceholder>(sg).a0;
                        _v.set(prelude::push(acc, x));
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
        }
        {
            return Array<ast::Expr>{};
        }
    }
    {
        return Array<ast::Expr>{};
    }
}


/// Merge: fn Wx, Text, OutTy, EvRef, EvRef -> ((Nat, Wx))
std::tuple<Nat, Wx> merge(const Wx& wx, const Text& name, const OutTy& t, const EvRef& l, const EvRef& r) {
    return combinator(wx, name, t, GnKind(GnKind::GnMerge{}), l, r, t, t);
}


/// Combinator: fn Wx, Text, OutTy, GnKind, EvRef, EvRef, OutTy, OutTy -> ((Nat, Wx))
std::tuple<Nat, Wx> combinator(const Wx& wx, const Text& name, const OutTy& t, const GnKind& kind, const EvRef& l, const EvRef& r, const OutTy& lt, const OutTy& rt) {
    auto [id, wx1] = add_gn(wx, name, t, kind, Nat(1u));
    auto wx2 = add_field_last(wx1, prism_rtl::cat(name, "_left"), OutTy(OutTy::OutStamped{prism_rtl::rc(lt)}), prism_rtl::cat("`", name, "`'s left input"), Ex(Ex::XCall{Text::lit("Stamped::new"), Array<Ex>{}}));
    auto wx3 = add_field_last(wx2, prism_rtl::cat(name, "_right"), OutTy(OutTy::OutStamped{prism_rtl::rc(rt)}), Text::lit("its right input"), Ex(Ex::XCall{Text::lit("Stamped::new"), Array<Ex>{}}));
    auto wx4 = ({
        Wx this_ = wx3;
        this_.gns = each(this_.gns, [&](const Gn& n) {
            return n.id == id
                ? with_inputs(n, Array(std::vector{prism_rtl::cat(name, "_left"), prism_rtl::cat(name, "_right")}))
                : n;
        });
        this_;
    });
    return std::tuple{id, connect(connect(wx4, l, Sk(Sk::SkIn{id, Nat(0u)})), r, Sk(Sk::SkIn{id, Nat(1u)}))};
}


/// WithInputs: fn Gn, [Text] -> Gn
Gn with_inputs(const Gn& n, const Array<Text>& ins) {
    Gn this_ = n;
    this_.inputs = ins;
    return this_;
}


/// WithReads: fn Gn, [Read] -> Gn
Gn with_reads(const Gn& n, const Array<Read>& reads) {
    Gn this_ = n;
    this_.reads = reads;
    return this_;
}


/// Heights: fn [Gn] -> [Gn]
Array<Gn> heights(const Array<Gn>& gns) {
    return fold(gns, gns, [&](const Array<Gn>& cur, const Gn& _p1) { return each(cur, [&](const Gn& n) { return height_step(cur, n); }); });
}


/// HeightStep: fn [Gn], Gn -> Gn
Gn height_step(const Array<Gn>& gns, const Gn& n) {
    auto feeders = filter(gns, [&](const Gn& m) { return fold(m.outs, false, [&](const bool& f, const Out& o) { return f || feeds(o.sink, n); }); });
    auto top = fold(feeders, Nat(0u), [&](const Nat& hi, const Gn& m) { return prelude::max(hi, m.height); });
    auto h = ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = n.kind;
        if (prism_rtl::is<GnKind::GnNamed>(_m)) {
            _v.set(top);
            goto _done;
        }
        {
            auto&& kind = _m;
            _v.set(is_comb(kind) ? prelude::max(top + Nat(1u), n.floor) : n.height);
            goto _done;
        }
    _done:
        _v.take();
    });
    Gn this_ = n;
    this_.height = h;
    return this_;
}


/// IsComb: fn GnKind -> Bool
bool is_comb(const GnKind& k) {
    if (prism_rtl::is<GnKind::GnMerge>(k)) {
        return true;
    }
    if (prism_rtl::is<GnKind::GnUnion>(k)) {
        return true;
    }
    if (prism_rtl::is<GnKind::GnBoth>(k)) {
        return true;
    }
    if (prism_rtl::is<GnKind::GnExcept>(k)) {
        return true;
    }
    if (prism_rtl::is<GnKind::GnMergeAll>(k)) {
        return true;
    }
    if (prism_rtl::is<GnKind::GnUpdated>(k)) {
        return true;
    }
    {
        return false;
    }
}


/// Feeds: fn Sk, Gn -> Bool
bool feeds(const Sk& sk0, const Gn& n) {
    if (prism_rtl::is<Sk::SkNode>(sk0)) {
        auto&& m = prism_rtl::as<Sk::SkNode>(sk0).a0;
        return m == n.id;
    }
    if (prism_rtl::is<Sk::SkIn>(sk0)) {
        auto&& m = prism_rtl::as<Sk::SkIn>(sk0).a0;
        return m == n.id;
    }
    if (prism_rtl::is<Sk::SkCycle>(sk0)) {
        auto&& m = prism_rtl::as<Sk::SkCycle>(sk0).a2;
        return m == n.id;
    }
    if (prism_rtl::is<Sk::SkMachine>(sk0)) {
        auto&& f = prism_rtl::as<Sk::SkMachine>(sk0).a0;
        auto&& m = prism_rtl::as<Sk::SkMachine>(sk0).a2;
        return (m == n.id) || writes(f, n);
    }
    if (prism_rtl::is<Sk::SkHold>(sk0)) {
        auto&& f = prism_rtl::as<Sk::SkHold>(sk0).a0;
        return writes(f, n);
    }
    {
        auto&& other = sk0;
        return false;
    }
}


/// Writes: fn Text, Gn -> Bool
bool writes(const Text& f, const Gn& n) {
    return moves(Read(Read::OwnRead{f}), n);
}


/// Moves: fn Read, Gn -> Bool
bool moves(const Read& r, const Gn& n) {
    return (n.kind == GnKind(GnKind::GnUpdated{})) && has_read(n.reads, r);
}


/// ReadsClosed: fn (Text ==> [Read]), [Read] -> [Read]
Array<Read> reads_closed(const Map<Text, Array<Read>>& dyn_, const Array<Read>& reads) {
    return fold(check_errors::range0(Nat(4u)), reads, [&](const Array<Read>& acc, const Nat& _p1) { return fold(acc, acc, [&](const Array<Read>& a, const Read& r) { return union_reads(a, getter_reads(dyn_, r)); }); });
}


/// GetterReads: fn (Text ==> [Read]), Read -> [Read]
Array<Read> getter_reads(const Map<Text, Array<Read>>& dyn_, const Read& read1) {
    if (prism_rtl::is<Read::OwnRead>(read1)) {
        auto&& n = prism_rtl::as<Read::OwnRead>(read1).a0;
        return or_(prelude::get(dyn_, n), Array<Read>{});
    }
    if (prism_rtl::is<Read::ParentRead>(read1)) {
        return Array<Read>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ReachesSnap: fn [Text], [Read] -> Bool
bool reaches_snap(const Array<Text>& roots, const Array<Read>& reads) {
    return fold(reads, false, [&](const bool& f, const Read& r) {
        return f || ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is<Read::OwnRead>(r)) {
                auto&& n = prism_rtl::as<Read::OwnRead>(r).a0;
                _v.set(check_types::has_text(roots, n));
                goto _done;
            }
            if (prism_rtl::is<Read::ParentRead>(r)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// SnapNames: fn Wx -> [Text]
Array<Text> snap_names(const Wx& wx) {
    return each(wx.snaps, [&](const SnapDef& sn) { return sn.name; });
}


/// WakeConst: fn [Nat], Nat -> Text
Text wake_const(const Array<Nat>& heights_, const Nat& h) {
    return len(heights_) <= Nat(1u) ? Text::lit("WAKE") : prism_rtl::cat("WAKE_", h);
}


/// SelfCall: fn Text, [Ex] -> Do
Do self_call(const Text& m, const Array<Ex>& args) {
    return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), m, prelude::push(args, Ex(Ex::XCx{}))})});
}


/// SinkCode: fn Sinks, Sk, Ex -> [Do]
Array<Do> sink_code(const Sinks& sk, const Sk& target, const Ex& y) {
    if (prism_rtl::is<Sk::SkNode>(target)) {
        auto&& m = prism_rtl::as<Sk::SkNode>(target).a0;
        return Array(std::vector{self_call(gn_of(sk.wx, m).name, Array(std::vector{y}))});
    }
    if (prism_rtl::is<Sk::SkIn>(target)) {
        auto&& m = prism_rtl::as<Sk::SkIn>(target).a0;
        auto&& i = prism_rtl::as<Sk::SkIn>(target).a1;
        auto g = gn_of(sk.wx, m);
        return append(Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, i), Text::lit("")))})), Text::lit("set"), Array(std::vector{y, Ex(Ex::XCx{})})})})}), ask_wake(sk, g.height));
    }
    if (prism_rtl::is<Sk::SkHold>(target)) {
        auto&& f = prism_rtl::as<Sk::SkHold>(target).a0;
        return append(Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("set"), Array(std::vector{y, Ex(Ex::XCx{})})})})}), hold_written(sk, f));
    }
    if (prism_rtl::is<Sk::SkRequest>(target)) {
        auto&& pos = prism_rtl::as<Sk::SkRequest>(target).a0;
        auto&& field = prism_rtl::as<Sk::SkRequest>(target).a1;
        auto field_ex = field == Text::lit("")
            ? Ex(Ex::XNone{})
            : Ex(Ex::XCtor{Text::lit("Some"), Array(std::vector{Ex(Ex::XStr{field})})});
        return emits(sk.wx, pos)
            ? Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("request"), Array(std::vector{place_at(sk.wx, Text::lit("self"), pos), field_ex, Ex(Ex::XMethod{prism_rtl::rc(y), Text::lit("to_pod"), Array<Ex>{}})})})})})
            : Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text::lit("requested")}), Ex(Ex::XMethod{prism_rtl::rc(host_field_ex(sk.wx, pos)), Text::lit("request"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(place_at(sk.wx, Text::lit("self"), pos))}), field_ex, Ex(Ex::XMethod{prism_rtl::rc(y), Text::lit("to_pod"), Array<Ex>{}}), Ex(Ex::XCx{})})})}), Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("keep"), Array(std::vector{Ex(Ex::XVar{Text::lit("requested")})})})})});
    }
    if (prism_rtl::is<Sk::SkResult>(target)) {
        return Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("result"), Array(std::vector{Ex(Ex::XCtor{Text::lit("Outcome::Fired"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(y), Text::lit("to_pod"), Array<Ex>{}})})})})})})});
    }
    if (prism_rtl::is<Sk::SkArm>(target)) {
        auto&& f = prism_rtl::as<Sk::SkArm>(target).a0;
        return Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("arm"), Array(std::vector{y, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))}), Ex(Ex::XCx{})})})})});
    }
    if (prism_rtl::is<Sk::SkMachine>(target)) {
        auto&& f = prism_rtl::as<Sk::SkMachine>(target).a0;
        auto&& step_ = prism_rtl::as<Sk::SkMachine>(target).a1;
        auto&& out = prism_rtl::as<Sk::SkMachine>(target).a2;
        auto stepped = Ex(Ex::XCall{step_, Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), f})), Text::lit("get"), Array(std::vector{Ex(Ex::XCx{})})}))}), Ex(Ex::XRef{prism_rtl::rc(y)})})});
        return append(Array(std::vector{Do(Do::DoLet{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{Text::lit("machine_s")}), Pa(Pa::PaBind{Text::lit("machine_b")})})}), stepped}), Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("set"), Array(std::vector{Ex(Ex::XVar{Text::lit("machine_s")}), Ex(Ex::XCx{})})})}), Do(Do::DoIfLet{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("machine_b")})})}), Ex(Ex::XVar{Text::lit("machine_b")}), Array(std::vector{self_call(gn_of(sk.wx, out).name, Array(std::vector{Ex(Ex::XVar{Text::lit("machine_b")})}))}), Array<Do>{}})}), moved_marks(sk, f));
    }
    if (prism_rtl::is<Sk::SkPort>(target)) {
        auto&& f = prism_rtl::as<Sk::SkPort>(target).a0;
        return Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f, "_port")})), Text::lit("fire"), Array(std::vector{y, Ex(Ex::XCx{})})})), Text::lit("ok"), Array<Ex>{}})})});
    }
    if (prism_rtl::is<Sk::SkUp>(target)) {
        auto&& m = prism_rtl::as<Sk::SkUp>(target).a0;
        auto keyed = len(filter(sk.wx.fields, [&](const std::tuple<Text, OutTy, Text>& _p0) {
            auto&& f = std::get<0>(_p0);
            return f == Text::lit("key");
        })) > Nat(0u);
        auto args = keyed
            ? Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text::lit("key")}))}), y, Ex(Ex::XCx{})})
            : Array(std::vector{y, Ex(Ex::XCx{})});
        return Array(std::vector{Do(Do::DoIfLet{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("parent")})})}), Ex(Ex::XUpgrade{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text::lit("parent")}))}), Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("parent")})), m, args})})}), Array<Do>{}})});
    }
    if (prism_rtl::is<Sk::SkCycle>(target)) {
        auto&& job = prism_rtl::as<Sk::SkCycle>(target).a0;
        auto&& again = prism_rtl::as<Sk::SkCycle>(target).a1;
        auto&& res = prism_rtl::as<Sk::SkCycle>(target).a2;
        auto more = Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(job)})), Text::lit("set"), Array(std::vector{Ex(Ex::XVar{Text::lit("next")}), Ex(Ex::XCx{})})})}), Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(again)})), Text::lit("arm"), Array(std::vector{Ex(Ex::XUnit{}), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))}), Ex(Ex::XCx{})})})})});
        auto fin = Array(std::vector{self_call(gn_of(sk.wx, res).name, Array(std::vector{Ex(Ex::XVar{Text::lit("b")})}))});
        return Array(std::vector{Do(Do::DoMatch{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(job)})), Text::lit("get"), Array(std::vector{Ex(Ex::XCx{})})})), Text::lit("cycle"), Array<Ex>{}}), Array(std::vector{std::tuple{Pa(Pa::PaCtor{Text::lit("prism_rtl::Turn::More"), Array(std::vector{Pa(Pa::PaBind{Text::lit("next")})})}), more}, std::tuple{Pa(Pa::PaCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{Pa(Pa::PaBind{Text::lit("b")})})}), fin}})})});
    }
    prism_rtl::unreachable("no arm matched");
}


/// HoldWritten: fn Sinks, Text -> [Do]
Array<Do> hold_written(const Sinks& sk, const Text& f) {
    auto r = Read(Read::OwnRead{f});
    auto read_by_place = has_read(sk.dirty, r);
    auto [dirty, told] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<Do>, Array<Do>>> _v;
        auto&& _m = sk.wx.hosted_by;
        if (prism_rtl::is_some(_m)) {
            _v.set(std::tuple{Array<Do>{}, read_by_place
                ? Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), Text::lit("document_moved"), Array(std::vector{Ex(Ex::XCx{})})})})})
                : Array<Do>{}});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{read_by_place
                ? Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("dirty"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))})})})})})
                : Array<Do>{}, Array<Do>{}});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto stales = fold(sk.wx.gen_holds, Array<Do>{}, [&](const Array<Do>& acc, const std::tuple<Text, Array<Read>>& _p1) {
        auto&& gname = std::get<0>(_p1);
        auto&& hs = std::get<1>(_p1);
        return has_read(reads_closed(sk.wx.dyn_reads, hs), r)
            ? prelude::push(acc, Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(gname, "_stale")})), Text::lit("set"), Array(std::vector{Ex(Ex::XBool{true})})})}))
            : acc;
    });
    auto row_marks = fold(sk.wx.row_marks, Array<Do>{}, [&](const Array<Do>& acc, const RowMarks& rm) { return append(acc, row_written(sk.wx, rm, r)); });
    auto builds = has_read(sk.builds, r) || (len(stales) > Nat(0u));
    auto rebuild_it = builds && (!lists_build(sk, r))
        ? append(stales, Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("build_later"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))})})})})}))
        : stales;
    auto gathered = ({
        __label__ _done;
        prism_rtl::Slot<Array<Do>> _v;
        auto&& _m = sk.wx.result_moved;
        if (prism_rtl::is_some(_m)) {
            auto&& m = std::get<0>(prism_rtl::some_of(_m));
            auto&& rds = std::get<1>(prism_rtl::some_of(_m));
            _v.set(has_read(rds, r)
                ? Array(std::vector{Do(Do::DoIfLet{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("parent")})})}), Ex(Ex::XUpgrade{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text::lit("parent")}))}), Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("parent")})), m, Array(std::vector{Ex(Ex::XCx{})})})})}), Array<Do>{}})})
                : Array<Do>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Do>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return append(append(append(append(append(dirty, told), rebuild_it), row_marks), gathered), moved_marks(sk, f));
}


/// HostFieldEx: fn Wx, Pos -> Ex
Ex host_field_ex(const Wx& wx, const Pos_& pos) {
    return Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), host_local(wx, pos)});
}


/// MovedMarks: fn Sinks, Text -> [Do]
Array<Do> moved_marks(const Sinks& sk, const Text& f) {
    return moved_by(sk, Read(Read::OwnRead{f}));
}


/// MovedBy: fn Sinks, Read -> [Do]
Array<Do> moved_by(const Sinks& sk, const Read& r) {
    auto moved = filter(sk.wx.gns, [&](const Gn& g) { return moves(r, g); });
    auto flags = each(moved, [&](const Gn& g) { return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(g.name, "_moved")})), Text::lit("set"), Array(std::vector{Ex(Ex::XBool{true})})})}); });
    auto heights_ = sort_nats(fold(moved, Array<Nat>{}, [&](const Array<Nat>& acc, const Gn& g) { return check_types::add_nat(acc, g.height); }));
    auto marks = each(snaps_behind(sk.wx, r), [&](const SnapDef& sn) { return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text::lit("mark"), Array(std::vector{Ex(Ex::XCx{})})})}); });
    auto listed = lists_build(sk, r)
        ? Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("build_later"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))})})})})})
        : Array<Do>{};
    auto answers = each(filter(sk.wx.dyn_answers, [&](const std::tuple<Text, Array<Read>>& _p0) {
        auto&& rds = std::get<1>(_p0);
        return has_read(reads_closed(sk.wx.dyn_reads, rds), r);
    }), [&](const std::tuple<Text, Array<Read>>& _p0) {
        auto&& name = std::get<0>(_p0);
        return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(name, "_port")})), Text::lit("fire"), Array(std::vector{Ex(Ex::XUnit{}), Ex(Ex::XCx{})})})), Text::lit("ok"), Array<Ex>{}})});
    });
    auto adoptions = each(filter(sk.wx.flattens, [&](const FlatDef& fl) { return r == Read(Read::OwnRead{fl.outer}); }), [&](const FlatDef& fl) { return Do(Do::DoScope{adoption(fl)}); });
    return append(append(append(append(append(fold(heights_, flags, [&](const Array<Do>& acc, const Nat& h) { return append(acc, ask_wake(sk, h)); }), marks), listed), answers), adoptions), source_marks(sk.wx, r));
}


/// SourceMarks: fn Wx, Read -> [Do]
Array<Do> source_marks(const Wx& wx, const Read& r) {
    return fold(wx.builders, Array<Do>{}, [&](const Array<Do>& acc, const ForDef& b) {
        return has_read(reads_closed(wx.dyn_reads, or_(prelude::get(wx.dyn_reads, b->source), Array<Read>{})), r)
            ? prelude::push(acc, Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(b->source, "_cache")})), Text::lit("mark"), Array(std::vector{Ex(Ex::XCx{})})})}))
            : acc;
    });
}


/// SnapsBehind: fn Wx, Read -> [SnapDef]
Array<SnapDef> snaps_behind(const Wx& wx, const Read& r) {
    return filter(wx.snaps, [&](const SnapDef& sn) { return (r == Read(Read::OwnRead{sn.live})) || has_read(reads_closed(wx.dyn_reads, Array(std::vector{Read(Read::OwnRead{sn.live})})), r); });
}


/// ListsBuild: fn Sinks, Read -> Bool
bool lists_build(const Sinks& sk, const Read& r) {
    return len(snaps_behind(sk.wx, r)) > Nat(0u);
}


/// FiringCode: unbounded fn Sinks, Gn, Ex -> [Do]
Array<Do> firing_code(const Sinks& sk, const Gn& g, const Ex& x) {
    auto many = (len(g.outs) > Nat(1u)) && (!is_copy(g.ty));
    auto xv = many ? Ex(Ex::XClone{prism_rtl::rc(x)}) : x;
    return run_to_end(fold_job(g.outs, Array<Do>{}, ({
        auto xv_1 = xv;
        auto sk_2 = sk;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Array<Do>, Out>)>>(prism_rtl::rc([=](std::tuple<Array<Do>, Out> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xv_1_3 = xv_1;
            auto sk_2_3 = sk_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto o = p1;
                call_value(o.pipe(std::tuple{xv_1_3, ({
                auto sk_2_3_3 = sk_2_3;
                auto o_3 = o;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>(prism_rtl::rc([=](Ex p0) {
                return ({
                    auto sk_2_3_3_4 = sk_2_3_3;
                    auto o_3_4 = o_3;
                    once_job([=]() {
                    return ({
                        auto y = p0;
                        (prism_rtl::finished(sink_code(sk_2_3_3_4, o_3_4.sink, y)));
                    });
                });
                });
            })));
            })}), [=](Array<Do> call_275924) { return prism_rtl::finished(append(acc, call_275924)); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Do>> FiringCode::cycle() const {
    const auto& sk = this->sk;
    const auto& g = this->g;
    const auto& x = this->x;
    auto many = (len(g.outs) > Nat(1u)) && (!is_copy(g.ty));
    auto xv = many ? Ex(Ex::XClone{prism_rtl::rc(x)}) : x;
    return fold_job(g.outs, Array<Do>{}, ({
        auto xv_1 = xv;
        auto sk_2 = sk;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Array<Do>, Out>)>>(prism_rtl::rc([=](std::tuple<Array<Do>, Out> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xv_1_3 = xv_1;
            auto sk_2_3 = sk_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto o = p1;
                call_value(o.pipe(std::tuple{xv_1_3, ({
                auto sk_2_3_3 = sk_2_3;
                auto o_3 = o;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>(prism_rtl::rc([=](Ex p0) {
                return ({
                    auto sk_2_3_3_4 = sk_2_3_3;
                    auto o_3_4 = o_3;
                    once_job([=]() {
                    return ({
                        auto y = p0;
                        (prism_rtl::finished(sink_code(sk_2_3_3_4, o_3_4.sink, y)));
                    });
                });
                });
            })));
            })}), [=](Array<Do> call_275924) { return prism_rtl::finished(append(acc, call_275924)); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start FiringCode, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Do>> start_firing_code(Sinks sk, Gn g, Ex x) {
    return prism_rtl::make_rc<FiringCode>(sk, g, x);
}


/// FinishNode: unbounded fn Wx, Text, [((Text, OutTy))], Bool -> NodeDef
NodeDef finish_node(const Wx& wx0, const Text& qk, const Array<std::tuple<Text, OutTy>>& params, const bool& is_row) {
    auto closed_gns = each(wx0.gns, [&](const Gn& g) {
        return g.kind == GnKind(GnKind::GnUpdated{})
            ? with_reads(g, reads_closed(wx0.dyn_reads, g.reads))
            : g;
    });
    auto [row_defs, gns2] = finish_pending(wx0, heights(closed_gns));
    auto is_gen = is_row && (len(filter(wx0.fields, [&](const std::tuple<Text, OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f == Text::lit("key");
    })) == Nat(0u));
    auto wx = ({
        Wx this_ = wx0;
        this_.gns = heights(gns2);
        this_.build = append(this_.build, updated_gaps(wx0, closed_gns, is_gen));
        this_.rows = fold(row_defs, this_.rows, [&](const Array<NodeDef>& acc, const NodeDef& rd) { return append(prelude::push(acc, rd), rd.children); });
        this_;
    });
    auto combs = filter(wx.gns, [&](const Gn& g) { return is_comb(g.kind) || (g.kind == GnKind(GnKind::GnGather{})); });
    auto heights_ = sort_nats(fold(combs, Array<Nat>{}, [&](const Array<Nat>& acc, const Gn& g) { return check_types::add_nat(acc, g.height); }));
    auto many = len(heights_) > Nat(1u);
    auto consts = each(heights_, [&](const Nat& h) { return std::tuple{wake_const(heights_, h), h, Text::lit("merges' height above the node's inputs")}; });
    auto live = filter(wx.places, [&](const Place& p_) { return p_.getter != Text::lit(""); });
    auto root_reads = ({
        __label__ _done;
        prism_rtl::Slot<Array<Read>> _v;
        auto&& _m = wx.root_dyn;
        if (prism_rtl::is_some(_m)) {
            auto&& rds = std::get<1>(prism_rtl::some_of(_m));
            _v.set(reads_closed(wx.dyn_reads, rds));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Read>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto dirty_holds = fold(live, root_reads, [&](const Array<Read>& acc, const Place& p_) { return union_reads(acc, reads_closed(wx.dyn_reads, p_.reads)); });
    auto build_holds = reads_closed(wx.dyn_reads, wx.build_holds);
    auto sinks = Sinks{.wx = wx, .dirty = dirty_holds, .builds = build_holds, .heights = heights_, .many = many};
    auto ev_methods = run_to_end(each_job(filter(wx.gns, [&](const Gn& g) { return g.kind != GnKind(GnKind::GnNever{}); }), ({
        auto sinks_1 = sinks;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<MethDef>(Gn)>>(prism_rtl::rc([=](Gn p0) {
        return ({
            auto sinks_1_2 = sinks_1;
            entered(once_job([=]() {
            return ({
                auto g = p0;
                call_then(start_firing_code(sinks_1_2, g, Ex(Ex::XVar{Text::lit("v")})), [=](Array<Do> firing_code_277716) { return prism_rtl::finished(MethDef{.name = g.name, .recv = Recv(Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("v"), g.ty}}), .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = firing_code_277716, .tail = Ex(Ex::XUnit{}), .doc = gn_doc(g)}); });
            });
        }));
        });
    })));
    })));
    auto gather_ins = each(filter(wx.gns, [&](const Gn& g) { return g.kind == GnKind(GnKind::GnGather{}); }), [&](const Gn& g) { return gather_in(sinks, g); });
    auto place_getters = each(live, [&](const Place& p_) { return MethDef{.name = p_.getter, .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = elem_ty(), .body = Array<Do>{}, .tail = p_.level, .doc = prism_rtl::cat("Place ", place_text(p_.pos), "'s level, read at the read point.")}; });
    auto wake_body = many
        ? Array(std::vector{wake_by_height(combs, heights_)})
        : each(combs, [&](const Gn& g) { return decide(g); });
    auto started_body = each(wx->started, [&](const Nat& st) { return self_call(gn_of(wx, st).name, Array(std::vector{Ex(Ex::XUnit{})})); });
    auto deferred_body = each(wx.defers, [&](const std::tuple<Text, Nat>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& id = std::get<1>(_p0);
        return Do(Do::DoIfLet{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("v")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("fired"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{self_call(gn_of(wx, id).name, Array(std::vector{Ex(Ex::XVar{Text::lit("v")})}))}), Array<Do>{}});
    });
    auto patch_body0 = fold(filter(live, [&](const Place& p_) { return emits(wx, p_.pos); }), Array<Do>{}, [&](const Array<Do>& acc, const Place& p_) { return append(acc, patch_place(wx, p_)); });
    auto patch_body = append(patch_body0, root_dyn_patch(wx));
    auto build_body = build_steps(sinks, false);
    auto push_body = each(filter(wx.dyn_places, [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return emits(wx, pos);
    }), [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return Do(Do::DoIf{Ex(Ex::XBin{Text::lit("=="), prism_rtl::rc(Ex(Ex::XVar{Text::lit("element")})), prism_rtl::rc(Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f, "_element")}))}))}), dyn_place_write(sinks, f, Ex(Ex::XDecode{t, prism_rtl::rc(Ex(Ex::XVar{Text::lit("v")}))})), Array<Do>{}});
    });
    auto hooks = filter(Array(std::vector{std::tuple{Text::lit("wake"), wake_body}, std::tuple{Text::lit("started"), started_body}, std::tuple{Text::lit("deferred"), deferred_body}, std::tuple{Text::lit("build"), build_body}, std::tuple{Text::lit("push"), push_body}, std::tuple{Text::lit("patch"), patch_body}}), [&](const std::tuple<Text, Array<Do>>& _p0) {
        auto&& b = std::get<1>(_p0);
        return len(b) > Nat(0u);
    });
    auto started_reg = len(wx->started) > Nat(0u)
        ? Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("on_started"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")}))})})})})})
        : Array<Do>{};
    auto links = each(wx.hosts, [&](const HostDef& h) { return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")})), prism_rtl::cat(h.name)})), Text::lit("link"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")}))})})})}); });
    auto rows_built = append(links, build_steps(sinks, true));
    auto subscribed = each(wx.subs, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return Do(Do::DoExpr{Ex(Ex::XCall{Text::lit("subscribe_row"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")}))}), Ex(Ex::XUpgrade{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")})), Text::lit("parent")}))}), Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaBind{Text::lit("p")})}), prism_rtl::rc(Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text::lit("p")})), prism_rtl::cat(ev, "_port")}))}))}), Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaBind{Text::lit("n")}), Pa(Pa::PaBind{Text::lit("v")}), Pa(Pa::PaBind{Text::lit("cx")})}), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("n")})), m, Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text::lit("v")}))}), Ex(Ex::XCx{})})}))}), Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")})), prism_rtl::cat(m, "_sub")}))})})})});
    });
    auto answers = append(each(filter(wx.answers, [&](const std::tuple<Pos_, Nat, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return emits(wx, pos);
    }), [&](const std::tuple<Pos_, Nat, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& id = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return answer_arm(wx, pos, id, t);
    }), each(filter(wx.dyn_places, [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return emits(wx, pos);
    }), [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return dyn_answer_arm(sinks, pos, f, t);
    }));
    auto forwards = append(each(filter(wx.builders, [&](const ForDef& b) { return emits(wx, b.pos); }), [&](const ForDef& b) { return std::tuple{pos_pat(b.pos, key_tail()), forward_answer(b)}; }), fold(filter(wx.gens, [&](const GenDef& gd) { return emits(wx, gd.pos); }), Array<std::tuple<Pa, Ex>>{}, [&](const Array<std::tuple<Pa, Ex>>& acc, const GenDef& gd) { return append(acc, gen_forwards(gd)); }));
    auto host_methods = fold(wx.hosts, Array<MethDef>{}, [&](const Array<MethDef>& acc, const HostDef& h) { return append(acc, Array(std::vector{typed_dispatch(sinks, prism_rtl::cat(h.name, "_answer"), h.scope), host_moved(sinks, h)})); });
    auto gathered = filter(wx.snaps, [&](const SnapDef& sn) { return !(sn.before || is_generation(wx, sn.builder)); });
    auto gathered_moved_ = append(append(each(gathered, [&](const SnapDef& sn) { return gathered_moved(sn); }), each(wx.snaps, [&](const SnapDef& sn) { return snap_publish(sinks, sn); })), flatten_methods(sinks));
    auto hosted_methods = ({
        __label__ _done;
        prism_rtl::Slot<Array<MethDef>> _v;
        auto&& _m = wx.hosted_by;
        if (prism_rtl::is_some(_m)) {
            _v.set(Array(std::vector{typed_dispatch(sinks, Text::lit("deliver"), Nat(0u)), document_getter(wx)}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<MethDef>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto moved_method = ({
        __label__ _done;
        prism_rtl::Slot<Array<MethDef>> _v;
        auto&& _m = wx.hosted_by;
        if (prism_rtl::is_some(_m)) {
            auto&& m = prism_rtl::some_of(_m);
            _v.set(Array(std::vector{lower::document_moved(m)}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<MethDef>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto row_methods_ = is_row ? row_methods(wx) : Array<MethDef>{};
    auto heard = each(row_hears(wx), [&](const Text& m) { return MethDef{.name = prism_rtl::cat("parent_wrote_", m), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = append(moved_by(sinks, Read(Read::ParentRead{m})), fold(wx.row_marks, Array<Do>{}, [&](const Array<Do>& acc, const RowMarks& rm) { return append(acc, row_written(wx, rm, Read(Read::ParentRead{m}))); })), .tail = Ex(Ex::XUnit{}), .doc = prism_rtl::cat("The block wrote behind its `", m, "`, which this row reads through the parent: the `!Updated` nodes over it are told and the wake asked at their heights; the rows of this row's own `for`s that read it are marked.")}; });
    auto top = fold(wx.gns, Nat(0u), [&](const Nat& hi, const Gn& g) { return prelude::max(hi, g.height); });
    auto wakes_field = many
        ? Array(std::vector{std::tuple{Text::lit("wakes"), OutTy(OutTy::OutWakes{}), Text::lit("the heights asked for this tick, lowest first")}})
        : Array<std::tuple<Text, OutTy, Text>>{};
    auto wakes_init = many
        ? Array(std::vector{std::tuple{Text::lit("wakes"), Ex(Ex::XCall{Text::lit("Wakes::default"), Array<Ex>{}})}})
        : Array<std::tuple<Text, Ex>>{};
    auto gen_fields = fold(wx.gens, Array<std::tuple<Text, OutTy, Text>>{}, [&](const Array<std::tuple<Text, OutTy, Text>>& acc, const GenDef& gd) { return append(acc, Array(std::vector{std::tuple{gd.name, OutTy(OutTy::OutCell{prism_rtl::rc(OutTy(OutTy::OutOpt{prism_rtl::rc(OutTy(OutTy::OutObj{prism_rtl::rc(OutTy(OutTy::OutNamed{Text::lit("Row"), Array<OutTy>{}}))}))}))}), prism_rtl::cat("the current generation of the `rebuild` at place ", place_text(gd.pos))}, std::tuple{prism_rtl::cat(gd.name, "_count"), OutTy(OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{OutTy(OutTy::OutCount{})})}), Text::lit("how many generations it has built")}, std::tuple{prism_rtl::cat(gd.name, "_stale"), OutTy(OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{OutTy(OutTy::OutBool{})})}), Text::lit("its source changed since it was built")}})); });
    auto gen_inits = fold(wx.gens, Array<std::tuple<Text, Ex>>{}, [&](const Array<std::tuple<Text, Ex>>& acc, const GenDef& gd) { return append(acc, Array(std::vector{std::tuple{gd.name, Ex(Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{Ex(Ex::XNone{})})})}, std::tuple{prism_rtl::cat(gd.name, "_count"), Ex(Ex::XCall{Text::lit("Cell::new"), Array(std::vector{Ex(Ex::XIndex{Nat(0u)})})})}, std::tuple{prism_rtl::cat(gd.name, "_stale"), Ex(Ex::XCall{Text::lit("Cell::new"), Array(std::vector{Ex(Ex::XBool{false})})})}})); });
    auto port_fields = each(wx.ports, [&](const Text& pn) { return std::tuple{prism_rtl::cat(pn, "_port"), OutTy(OutTy::OutPort{prism_rtl::rc(gn_ty_named(wx, pn))}), prism_rtl::cat("`!", pn, "`, which rows subscribe to")}; });
    auto port_inits = each(wx.ports, [&](const Text& pn) { return std::tuple{prism_rtl::cat(pn, "_port"), Ex(Ex::XCall{Text::lit("Port::new"), Array<Ex>{}})}; });
    auto sub_fields = each(wx.subs, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return std::tuple{prism_rtl::cat(m, "_sub"), OutTy(OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{OutTy(OutTy::OutOpt{prism_rtl::rc(OutTy(OutTy::OutNamed{Text::lit("Handle"), Array<OutTy>{}}))})})}), prism_rtl::cat("the subscription to the parent's `!", ev, "`")};
    });
    auto sub_inits = each(wx.subs, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return std::tuple{prism_rtl::cat(m, "_sub"), Ex(Ex::XCall{Text::lit("Cell::new"), Array(std::vector{Ex(Ex::XNone{})})})};
    });
    auto fallible = ((wx.fallible || is_row) || (len(wx.builders) > Nat(0u))) || (len(wx.gens) > Nat(0u));
    return NodeDef{.name = wx.node_, .prism = check_types::bare_name(qk), .doc = definition_text(wx.lx, qk), .params = params, .fields = append(append(append(append(wx.fields, wakes_field), gen_fields), port_fields), sub_fields), .consts = consts, .lets = wx.lets, .inits = append(wx.inits, append(append(append(append(wx.moves, wakes_init), gen_inits), port_inits), sub_inits)), .build = append(append(append(rows_built, wx->build), subscribed), started_reg), .fallible = fallible, .methods = append(append(append(append(append(append(append(append(ev_methods, gather_ins), place_getters), wx.getters), row_methods_), heard), host_methods), gathered_moved_), moved_method), .answers = append(answers, forwards), .hooks = hooks, .builders = wx.builders, .wakes = many, .children = wx->rows, .gens = wx.gens, .subs = wx.subs, .top = top, .row_kind = is_row
        ? is_gen ? RowKind(RowKind::GenerationRow{}) : RowKind(RowKind::ForRow{})
        : RowKind(RowKind::NotARow{}), .hosted = hosted_methods};
}


prism_rtl::Turn<NodeDef> FinishNode::cycle() const {
    const auto& wx0 = this->wx0;
    const auto& qk = this->qk;
    const auto& params = this->params;
    const auto& is_row = this->is_row;
    auto closed_gns = each(wx0.gns, [&](const Gn& g) {
        return g.kind == GnKind(GnKind::GnUpdated{})
            ? with_reads(g, reads_closed(wx0.dyn_reads, g.reads))
            : g;
    });
    auto is_row_1 = is_row;
    auto params_2 = params;
    auto qk_3 = qk;
    auto wx0_4 = wx0;
    return call_then(start_finish_pending(wx0_4, heights(closed_gns)), [=](std::tuple<Array<NodeDef>, Array<Gn>> finish_pending_276481) {
        return ({
            auto [row_defs, gns2] = finish_pending_276481;
            auto is_gen = is_row_1 && (len(filter(wx0_4.fields, [&](const std::tuple<Text, OutTy, Text>& _p0) {
                auto&& f = std::get<0>(_p0);
                return f == Text::lit("key");
            })) == Nat(0u));
            auto wx = ({
                Wx this_ = wx0_4;
                this_.gns = heights(gns2);
                this_.build = append(this_.build, updated_gaps(wx0_4, closed_gns, is_gen));
                this_.rows = fold(row_defs, this_.rows, [&](const Array<NodeDef>& acc, const NodeDef& rd) { return append(prelude::push(acc, rd), rd.children); });
                this_;
            });
            auto combs = filter(wx.gns, [&](const Gn& g) { return is_comb(g.kind) || (g.kind == GnKind(GnKind::GnGather{})); });
            auto heights_ = sort_nats(fold(combs, Array<Nat>{}, [&](const Array<Nat>& acc, const Gn& g) { return check_types::add_nat(acc, g.height); }));
            auto many = len(heights_) > Nat(1u);
            auto consts = each(heights_, [&](const Nat& h) { return std::tuple{wake_const(heights_, h), h, Text::lit("merges' height above the node's inputs")}; });
            auto live = filter(wx.places, [&](const Place& p_) { return p_.getter != Text::lit(""); });
            auto root_reads = ({
                __label__ _done;
                prism_rtl::Slot<Array<Read>> _v;
                auto&& _m = wx.root_dyn;
                if (prism_rtl::is_some(_m)) {
                    auto&& rds = std::get<1>(prism_rtl::some_of(_m));
                    _v.set(reads_closed(wx.dyn_reads, rds));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Array<Read>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto dirty_holds = fold(live, root_reads, [&](const Array<Read>& acc, const Place& p_) { return union_reads(acc, reads_closed(wx.dyn_reads, p_.reads)); });
            auto build_holds = reads_closed(wx.dyn_reads, wx.build_holds);
            auto sinks = Sinks{.wx = wx, .dirty = dirty_holds, .builds = build_holds, .heights = heights_, .many = many};
            call_value(each_job(filter(wx.gns, [&](const Gn& g) { return g.kind != GnKind(GnKind::GnNever{}); }), ({
            auto sinks_5 = sinks;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<MethDef>(Gn)>>(prism_rtl::rc([=](Gn p0) {
            return ({
                auto sinks_5_6 = sinks_5;
                entered(once_job([=]() {
                return ({
                    auto g = p0;
                    call_then(start_firing_code(sinks_5_6, g, Ex(Ex::XVar{Text::lit("v")})), [=](Array<Do> firing_code_277716) { return prism_rtl::finished(MethDef{.name = g.name, .recv = Recv(Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("v"), g.ty}}), .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = firing_code_277716, .tail = Ex(Ex::XUnit{}), .doc = gn_doc(g)}); });
                });
            }));
            });
        })));
        })), [=](Array<MethDef> each_277576) {
            return ({
                auto ev_methods = each_277576;
                auto gather_ins = each(filter(wx.gns, [&](const Gn& g) { return g.kind == GnKind(GnKind::GnGather{}); }), [&](const Gn& g) { return gather_in(sinks, g); });
                auto place_getters = each(live, [&](const Place& p_) { return MethDef{.name = p_.getter, .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = elem_ty(), .body = Array<Do>{}, .tail = p_.level, .doc = prism_rtl::cat("Place ", place_text(p_.pos), "'s level, read at the read point.")}; });
                auto wake_body = many
                    ? Array(std::vector{wake_by_height(combs, heights_)})
                    : each(combs, [&](const Gn& g) { return decide(g); });
                auto started_body = each(wx->started, [&](const Nat& st) { return self_call(gn_of(wx, st).name, Array(std::vector{Ex(Ex::XUnit{})})); });
                auto deferred_body = each(wx.defers, [&](const std::tuple<Text, Nat>& _p0) {
                    auto&& f = std::get<0>(_p0);
                    auto&& id = std::get<1>(_p0);
                    return Do(Do::DoIfLet{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("v")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("fired"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{self_call(gn_of(wx, id).name, Array(std::vector{Ex(Ex::XVar{Text::lit("v")})}))}), Array<Do>{}});
                });
                auto patch_body0 = fold(filter(live, [&](const Place& p_) { return emits(wx, p_.pos); }), Array<Do>{}, [&](const Array<Do>& acc, const Place& p_) { return append(acc, patch_place(wx, p_)); });
                auto patch_body = append(patch_body0, root_dyn_patch(wx));
                auto build_body = build_steps(sinks, false);
                auto push_body = each(filter(wx.dyn_places, [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    return emits(wx, pos);
                }), [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    auto&& f = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return Do(Do::DoIf{Ex(Ex::XBin{Text::lit("=="), prism_rtl::rc(Ex(Ex::XVar{Text::lit("element")})), prism_rtl::rc(Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f, "_element")}))}))}), dyn_place_write(sinks, f, Ex(Ex::XDecode{t, prism_rtl::rc(Ex(Ex::XVar{Text::lit("v")}))})), Array<Do>{}});
                });
                auto hooks = filter(Array(std::vector{std::tuple{Text::lit("wake"), wake_body}, std::tuple{Text::lit("started"), started_body}, std::tuple{Text::lit("deferred"), deferred_body}, std::tuple{Text::lit("build"), build_body}, std::tuple{Text::lit("push"), push_body}, std::tuple{Text::lit("patch"), patch_body}}), [&](const std::tuple<Text, Array<Do>>& _p0) {
                    auto&& b = std::get<1>(_p0);
                    return len(b) > Nat(0u);
                });
                auto started_reg = len(wx->started) > Nat(0u)
                    ? Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("on_started"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")}))})})})})})
                    : Array<Do>{};
                auto links = each(wx.hosts, [&](const HostDef& h) { return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")})), prism_rtl::cat(h.name)})), Text::lit("link"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")}))})})})}); });
                auto rows_built = append(links, build_steps(sinks, true));
                auto subscribed = each(wx.subs, [&](const std::tuple<Text, Text, OutTy>& _p0) {
                    auto&& ev = std::get<0>(_p0);
                    auto&& m = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return Do(Do::DoExpr{Ex(Ex::XCall{Text::lit("subscribe_row"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")}))}), Ex(Ex::XUpgrade{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")})), Text::lit("parent")}))}), Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaBind{Text::lit("p")})}), prism_rtl::rc(Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text::lit("p")})), prism_rtl::cat(ev, "_port")}))}))}), Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaBind{Text::lit("n")}), Pa(Pa::PaBind{Text::lit("v")}), Pa(Pa::PaBind{Text::lit("cx")})}), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("n")})), m, Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text::lit("v")}))}), Ex(Ex::XCx{})})}))}), Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")})), prism_rtl::cat(m, "_sub")}))})})})});
                });
                auto answers = append(each(filter(wx.answers, [&](const std::tuple<Pos_, Nat, OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    return emits(wx, pos);
                }), [&](const std::tuple<Pos_, Nat, OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    auto&& id = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return answer_arm(wx, pos, id, t);
                }), each(filter(wx.dyn_places, [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    return emits(wx, pos);
                }), [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    auto&& f = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return dyn_answer_arm(sinks, pos, f, t);
                }));
                auto forwards = append(each(filter(wx.builders, [&](const ForDef& b) { return emits(wx, b.pos); }), [&](const ForDef& b) { return std::tuple{pos_pat(b.pos, key_tail()), forward_answer(b)}; }), fold(filter(wx.gens, [&](const GenDef& gd) { return emits(wx, gd.pos); }), Array<std::tuple<Pa, Ex>>{}, [&](const Array<std::tuple<Pa, Ex>>& acc, const GenDef& gd) { return append(acc, gen_forwards(gd)); }));
                auto host_methods = fold(wx.hosts, Array<MethDef>{}, [&](const Array<MethDef>& acc, const HostDef& h) { return append(acc, Array(std::vector{typed_dispatch(sinks, prism_rtl::cat(h.name, "_answer"), h.scope), host_moved(sinks, h)})); });
                auto gathered = filter(wx.snaps, [&](const SnapDef& sn) { return !(sn.before || is_generation(wx, sn.builder)); });
                auto gathered_moved_ = append(append(each(gathered, [&](const SnapDef& sn) { return gathered_moved(sn); }), each(wx.snaps, [&](const SnapDef& sn) { return snap_publish(sinks, sn); })), flatten_methods(sinks));
                auto hosted_methods = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<MethDef>> _v;
                    auto&& _m = wx.hosted_by;
                    if (prism_rtl::is_some(_m)) {
                        _v.set(Array(std::vector{typed_dispatch(sinks, Text::lit("deliver"), Nat(0u)), document_getter(wx)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<MethDef>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto moved_method = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<MethDef>> _v;
                    auto&& _m = wx.hosted_by;
                    if (prism_rtl::is_some(_m)) {
                        auto&& m = prism_rtl::some_of(_m);
                        _v.set(Array(std::vector{lower::document_moved(m)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<MethDef>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto row_methods_ = is_row_1 ? row_methods(wx) : Array<MethDef>{};
                auto heard = each(row_hears(wx), [&](const Text& m) { return MethDef{.name = prism_rtl::cat("parent_wrote_", m), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = append(moved_by(sinks, Read(Read::ParentRead{m})), fold(wx.row_marks, Array<Do>{}, [&](const Array<Do>& acc, const RowMarks& rm) { return append(acc, row_written(wx, rm, Read(Read::ParentRead{m}))); })), .tail = Ex(Ex::XUnit{}), .doc = prism_rtl::cat("The block wrote behind its `", m, "`, which this row reads through the parent: the `!Updated` nodes over it are told and the wake asked at their heights; the rows of this row's own `for`s that read it are marked.")}; });
                auto top = fold(wx.gns, Nat(0u), [&](const Nat& hi, const Gn& g) { return prelude::max(hi, g.height); });
                auto wakes_field = many
                    ? Array(std::vector{std::tuple{Text::lit("wakes"), OutTy(OutTy::OutWakes{}), Text::lit("the heights asked for this tick, lowest first")}})
                    : Array<std::tuple<Text, OutTy, Text>>{};
                auto wakes_init = many
                    ? Array(std::vector{std::tuple{Text::lit("wakes"), Ex(Ex::XCall{Text::lit("Wakes::default"), Array<Ex>{}})}})
                    : Array<std::tuple<Text, Ex>>{};
                auto gen_fields = fold(wx.gens, Array<std::tuple<Text, OutTy, Text>>{}, [&](const Array<std::tuple<Text, OutTy, Text>>& acc, const GenDef& gd) { return append(acc, Array(std::vector{std::tuple{gd.name, OutTy(OutTy::OutCell{prism_rtl::rc(OutTy(OutTy::OutOpt{prism_rtl::rc(OutTy(OutTy::OutObj{prism_rtl::rc(OutTy(OutTy::OutNamed{Text::lit("Row"), Array<OutTy>{}}))}))}))}), prism_rtl::cat("the current generation of the `rebuild` at place ", place_text(gd.pos))}, std::tuple{prism_rtl::cat(gd.name, "_count"), OutTy(OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{OutTy(OutTy::OutCount{})})}), Text::lit("how many generations it has built")}, std::tuple{prism_rtl::cat(gd.name, "_stale"), OutTy(OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{OutTy(OutTy::OutBool{})})}), Text::lit("its source changed since it was built")}})); });
                auto gen_inits = fold(wx.gens, Array<std::tuple<Text, Ex>>{}, [&](const Array<std::tuple<Text, Ex>>& acc, const GenDef& gd) { return append(acc, Array(std::vector{std::tuple{gd.name, Ex(Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{Ex(Ex::XNone{})})})}, std::tuple{prism_rtl::cat(gd.name, "_count"), Ex(Ex::XCall{Text::lit("Cell::new"), Array(std::vector{Ex(Ex::XIndex{Nat(0u)})})})}, std::tuple{prism_rtl::cat(gd.name, "_stale"), Ex(Ex::XCall{Text::lit("Cell::new"), Array(std::vector{Ex(Ex::XBool{false})})})}})); });
                auto port_fields = each(wx.ports, [&](const Text& pn) { return std::tuple{prism_rtl::cat(pn, "_port"), OutTy(OutTy::OutPort{prism_rtl::rc(gn_ty_named(wx, pn))}), prism_rtl::cat("`!", pn, "`, which rows subscribe to")}; });
                auto port_inits = each(wx.ports, [&](const Text& pn) { return std::tuple{prism_rtl::cat(pn, "_port"), Ex(Ex::XCall{Text::lit("Port::new"), Array<Ex>{}})}; });
                auto sub_fields = each(wx.subs, [&](const std::tuple<Text, Text, OutTy>& _p0) {
                    auto&& ev = std::get<0>(_p0);
                    auto&& m = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return std::tuple{prism_rtl::cat(m, "_sub"), OutTy(OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{OutTy(OutTy::OutOpt{prism_rtl::rc(OutTy(OutTy::OutNamed{Text::lit("Handle"), Array<OutTy>{}}))})})}), prism_rtl::cat("the subscription to the parent's `!", ev, "`")};
                });
                auto sub_inits = each(wx.subs, [&](const std::tuple<Text, Text, OutTy>& _p0) {
                    auto&& ev = std::get<0>(_p0);
                    auto&& m = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return std::tuple{prism_rtl::cat(m, "_sub"), Ex(Ex::XCall{Text::lit("Cell::new"), Array(std::vector{Ex(Ex::XNone{})})})};
                });
                auto fallible = ((wx.fallible || is_row_1) || (len(wx.builders) > Nat(0u))) || (len(wx.gens) > Nat(0u));
                (prism_rtl::finished(NodeDef{.name = wx.node_, .prism = check_types::bare_name(qk_3), .doc = definition_text(wx.lx, qk_3), .params = params_2, .fields = append(append(append(append(wx.fields, wakes_field), gen_fields), port_fields), sub_fields), .consts = consts, .lets = wx.lets, .inits = append(wx.inits, append(append(append(append(wx.moves, wakes_init), gen_inits), port_inits), sub_inits)), .build = append(append(append(rows_built, wx->build), subscribed), started_reg), .fallible = fallible, .methods = append(append(append(append(append(append(append(append(ev_methods, gather_ins), place_getters), wx.getters), row_methods_), heard), host_methods), gathered_moved_), moved_method), .answers = append(answers, forwards), .hooks = hooks, .builders = wx.builders, .wakes = many, .children = wx->rows, .gens = wx.gens, .subs = wx.subs, .top = top, .row_kind = is_row_1
                ? is_gen ? RowKind(RowKind::GenerationRow{}) : RowKind(RowKind::ForRow{})
                : RowKind(RowKind::NotARow{}), .hosted = hosted_methods}));
            });
        });
        });
    });
}


/// `Start FinishNode, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<NodeDef> start_finish_node(Wx wx0, Text qk, Array<std::tuple<Text, OutTy>> params, bool is_row) {
    return prism_rtl::make_rc<FinishNode>(wx0, qk, params, is_row);
}


/// IsGeneration: fn Wx, Text -> Bool
bool is_generation(const Wx& wx, const Text& name) {
    return len(filter(wx.gens, [&](const GenDef& gd) { return gd.name == name; })) > Nat(0u);
}


/// FlattenMethods: fn Sinks -> [MethDef]
Array<MethDef> flatten_methods(const Sinks& sk) {
    auto wx = sk.wx;
    auto adopts_1 = each(wx.flattens, [&](const FlatDef& fl) {
        return ({
            auto set_1 = Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(fl.name, "_inner")})), Text::lit("set"), Array(std::vector{Ex(Ex::XCtor{Text::lit("Some"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), fl.outer, Array(std::vector{Ex(Ex::XCx{})})})})}), Ex(Ex::XCx{})})})});
            MethDef{.name = prism_rtl::cat(fl.name, "_adopt"), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = append(Array(std::vector{set_1}), hold_written(sk, prism_rtl::cat(fl.name, "_inner"))), .tail = Ex(Ex::XUnit{}), .doc = Text::lit("`@Flatten` adopts the inner its `rebuild`'s dynamic held after the tick before, among this tick's first firings: from here on it reads that inner (Semantics ch. 7).")};
        });
    });
    auto dyn_gens = filter(wx.gens, [&](const GenDef& gd) { return len(filter(wx.snaps, [&](const SnapDef& sn) { return sn.builder == gd.name; })) > Nat(0u); });
    auto moved_2 = each(dyn_gens, [&](const GenDef& gd) {
        return ({
            auto marks = fold(filter(wx.flattens, [&](const FlatDef& fl) { return fl->generation == gd.name; }), Array<Do>{}, [&](const Array<Do>& acc, const FlatDef& fl) { return append(acc, hold_written(sk, prism_rtl::cat(fl.name, "_inner"))); });
            MethDef{.name = prism_rtl::cat(gd.name, "_result_moved"), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = marks, .tail = Ex(Ex::XUnit{}), .doc = Text::lit("The current generation's result moved: what reads a `@Flatten` over it reads it again.")};
        });
    });
    return append(adopts_1, moved_2);
}


/// HostMoved: fn Sinks, HostDef -> MethDef
MethDef host_moved(const Sinks& sk, const HostDef& h) {
    return MethDef{.name = prism_rtl::cat(h.name, "_moved"), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = hold_written(sk, prism_rtl::cat(h.name, "_doc_now")), .tail = Ex(Ex::XUnit{}), .doc = prism_rtl::cat("A node of the child hosted at place ", place_text(h.pos), " wrote behind its document: the structure is marked as for a write of a hold it reads (pick HO), the snapshot listed to be taken; the program's `$doc` moves when it is published, the tick after (pick ST).")};
}


/// BuildSteps: fn Sinks, Bool -> [Do]
Array<Do> build_steps(const Sinks& sk, const bool& at_build) {
    auto wx = sk.wx;
    auto recv = at_build ? Ex(Ex::XVar{Text::lit("node")}) : Ex(Ex::XSelf{});
    auto take_fn = ({
        auto at_build_1 = at_build;
        auto sk_2 = sk;
        (prism_rtl::rc([=](const SnapDef& sn) { return at_build_1 ? snap_take_at_build(sn) : snap_take(sk_2, sn); }));
    });
    auto builder_fn = ({
        auto wx_1 = wx;
        auto take_fn_2 = take_fn;
        auto recv_3 = recv;
        (prism_rtl::rc([=](const ForDef& b) {
        return ({
            auto before_ = each(filter(wx_1.snaps, [&](const SnapDef& sn) { return sn.before && (sn.builder == b.name); }), take_fn_2);
            auto after_ = each(filter(wx_1.snaps, [&](const SnapDef& sn) { return (!sn.before) && (sn.builder == b.name); }), take_fn_2);
            append(prelude::push(before_, Do(Do::DoExpr{try_of(Ex(Ex::XMethod{prism_rtl::rc(recv_3), prism_rtl::cat(b.name, "_build"), Array(std::vector{Ex(Ex::XCx{})})}))})), after_);
        });
    }));
    });
    auto gen__fn = ({
        auto at_build_1 = at_build;
        auto recv_2 = recv;
        auto wx_3 = wx;
        auto take_fn_4 = take_fn;
        (prism_rtl::rc([=](const GenDef& gd) {
        return ({
            auto built = at_build_1
                ? Do(Do::DoExpr{try_of(Ex(Ex::XMethod{prism_rtl::rc(recv_2), prism_rtl::cat(gd.name, "_build"), Array(std::vector{Ex(Ex::XCx{})})}))})
                : Do(Do::DoIf{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(gd.name, "_stale")})), Text::lit("replace"), Array(std::vector{Ex(Ex::XBool{false})})}), Array(std::vector{Do(Do::DoExpr{try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(gd.name, "_build"), Array(std::vector{Ex(Ex::XCx{})})}))})}), Array<Do>{}});
            append(Array(std::vector{built}), each(filter(wx_3.snaps, [&](const SnapDef& sn) { return (!sn.before) && (sn.builder == gd.name); }), take_fn_4));
        });
    }));
    });
    return fold(check_errors::range0(len(wx.scopes) + Nat(1u)), Array<Do>{}, [&](const Array<Do>& acc, const Nat& i) {
        return ({
            auto k = or_(len(wx.scopes).checked_sub(i), Nat(0u));
            auto builders = fold(filter(wx.builders, [&](const ForDef& b) { return b.pos.scope == k; }), Array<Do>{}, [&](const Array<Do>& a, const ForDef& b) { return append(a, builder_fn(b)); });
            append(append(acc, builders), fold(filter(wx.gens, [&](const GenDef& gd) { return gd.pos.scope == k; }), Array<Do>{}, [&](const Array<Do>& a, const GenDef& gd) { return append(a, gen__fn(gd)); }));
        });
    });
}


/// SnapTakeAtBuild: fn SnapDef -> Do
Do snap_take_at_build(const SnapDef& sn) {
    return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")})), prism_rtl::cat(sn.name, "_snap")})), Text::lit("take"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")})), prism_rtl::cat(sn.name, "_now"), Array(std::vector{Ex(Ex::XCx{})})}), Ex(Ex::XCx{})})})});
}


/// SnapTake: fn Sinks, SnapDef -> Do
Do snap_take(const Sinks& sk, const SnapDef& sn) {
    auto now = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(sn.name, "_now"), Array(std::vector{Ex(Ex::XCx{})})});
    auto take_ = Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), sn.eq ? Text::lit("take_compared") : Text::lit("take"), Array(std::vector{now, Ex(Ex::XCx{})})})});
    auto queue = Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("answer_later"), Array(std::vector{Ex(Ex::XLater{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")})), prism_rtl::cat(sn.name, "_publish"), Array(std::vector{Ex(Ex::XCx{})})}))})})})});
    auto queued = Do(Do::DoIf{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text::lit("queue"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text::lit("node")}), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))})}), queue}), Array<Do>{}});
    return Do(Do::DoIf{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text::lit("marked"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{take_, queued}), Array<Do>{}});
}


/// SnapPublish: fn Sinks, SnapDef -> MethDef
MethDef snap_publish(const Sinks& sk, const SnapDef& sn) {
    return MethDef{.name = prism_rtl::cat(sn.name, "_publish"), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = Array(std::vector{Do(Do::DoIf{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text::lit("published"), Array(std::vector{Ex(Ex::XCx{})})}), hold_written(sk, sn.name), Array<Do>{}})}), .tail = Ex(Ex::XUnit{}), .doc = prism_rtl::cat(sn.what, ", published: its snapshot of the tick before moved it, written as a hold is (pick ST).")};
}


/// GatheredMoved: fn SnapDef -> MethDef
MethDef gathered_moved(const SnapDef& sn) {
    return MethDef{.name = prism_rtl::cat(sn.name, "_moved"), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text::lit("mark"), Array(std::vector{Ex(Ex::XCx{})})})}), Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("build_later"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))})})})})}), .tail = Ex(Ex::XUnit{}), .doc = Text::lit("A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).")};
}


/// DocumentGetter: fn Wx -> MethDef
MethDef document_getter(const Wx& wx) {
    auto is_own_fn = prism_rtl::rc([=](const Pos_& p_) { return p_.scope == Nat(0u); });
    auto body = document_body(({
        auto f = prism_rtl::rc(vec_push);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Do>(std::tuple<Ex, Ex>)>>(prism_rtl::rc([=](std::tuple<Ex, Ex> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0, a1)); });
        });
    })));
    }), filter(wx.places, [&](const Place& pl) { return is_own_fn(pl.pos); }), filter(wx.builders, [&](const ForDef& b) { return is_own_fn(b.pos); }), filter(wx.gens, [&](const GenDef& gd) { return is_own_fn(gd.pos); }));
    return MethDef{.name = Text::lit("document"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = OutTy(OutTy::OutNamed{Text::lit("Vec"), Array(std::vector{OutTy(OutTy::OutTuple{Array(std::vector{OutTy(OutTy::OutPath{}), elem_ty()})})})}), .body = append(Array(std::vector{Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaMut{Text::lit("doc")})), OutTy(OutTy::OutNamed{Text::lit("Vec"), Array(std::vector{OutTy(OutTy::OutTuple{Array(std::vector{OutTy(OutTy::OutPath{}), elem_ty()})})})})}), Ex(Ex::XCall{Text::lit("Vec::new"), Array<Ex>{}})})}), body), .tail = Ex(Ex::XVar{Text::lit("doc")}), .doc = Text::lit("The row's own places, entries of its host's document, by their paths relative to the row (pick HO).")};
}


/// DocumentMoved: fn Text -> MethDef
MethDef document_moved(const Text& m) {
    return MethDef{.name = Text::lit("document_moved"), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = Array(std::vector{Do(Do::DoIfLet{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("parent")})})}), Ex(Ex::XUpgrade{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text::lit("parent")}))}), Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("parent")})), m, Array(std::vector{Ex(Ex::XCx{})})})})}), Array<Do>{}})}), .tail = Ex(Ex::XUnit{}), .doc = Text::lit("A place of this row may have moved: its host's document moved, and the host's readers and rows are marked (pick HO).")};
}


/// DocumentBody: fn (fn Ex, Ex -> Do), [Place], [ForDef], [GenDef] -> [Do]
Array<Do> document_body(const prism_rtl::Fn<prism_rtl::JobRef<Do>(std::tuple<Ex, Ex>)>& add_fn, const Array<Place>& places, const Array<ForDef>& builders, const Array<GenDef>& gens) {
    auto statics = run_to_end(each_job(places, ({
        auto add_fn_1 = add_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Do>(Place)>>(prism_rtl::rc([=](Place p0) {
        return ({
            auto add_fn_1_2 = add_fn_1;
            entered(once_job([=]() {
            return ({
                auto pl = p0;
                ({
                auto level = pl.getter == Text::lit("")
                    ? pl.level
                    : Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), pl.getter, Array(std::vector{Ex(Ex::XCx{})})});
                add_fn_1_2(std::tuple{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCall{Text::lit("Path::root"), Array<Ex>{}})), Text::lit("at"), Array(std::vector{Ex(Ex::XIndex{pl.pos.at})})}), level})->cycle();
            });
            });
        }));
        });
    })));
    })));
    auto rows = run_to_end(each_job(builders, ({
        auto add_fn_1 = add_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Do>(ForDef)>>(prism_rtl::rc([=](ForDef p0) {
        return ({
            auto add_fn_1_2 = add_fn_1;
            entered(once_job([=]() {
            return ({
                auto b = p0;
                call_value(add_fn_1_2(std::tuple{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCall{Text::lit("Path::root"), Array<Ex>{}})), Text::lit("at"), Array(std::vector{Ex(Ex::XIndex{b.pos.at})})})), Text::lit("child"), Array(std::vector{Ex(Ex::XCtor{Text::lit("Segment::Key"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("k")})), Text::lit("to_pod"), Array<Ex>{}})})})})})), Text::lit("join"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text::lit("p")}))})})}), Ex(Ex::XVar{Text::lit("e")})}), [=](Do add_293089) { return prism_rtl::finished(Do(Do::DoFor{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{Text::lit("k")}), Pa(Pa::PaBind{Text::lit("row")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), b.name})), Text::lit("borrow"), Array<Ex>{}})), Text::lit("iter"), Array<Ex>{}}), Array(std::vector{Do(Do::DoFor{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{Text::lit("p")}), Pa(Pa::PaBind{Text::lit("e")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("row")})), Text::lit("document"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{add_293089})})})})); });
            });
        }));
        });
    })));
    })));
    auto generations = run_to_end(each_job(gens, ({
        auto add_fn_1 = add_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Do>(GenDef)>>(prism_rtl::rc([=](GenDef p0) {
        return ({
            auto add_fn_1_2 = add_fn_1;
            entered(once_job([=]() {
            return ({
                auto gd = p0;
                call_value(add_fn_1_2(std::tuple{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCall{Text::lit("Path::root"), Array<Ex>{}})), Text::lit("at"), Array(std::vector{Ex(Ex::XIndex{gd.pos.at})})})), Text::lit("child"), Array(std::vector{Ex(Ex::XCtor{Text::lit("Segment::Gen"), Array(std::vector{Ex(Ex::XVar{Text::lit("g")})})})})})), Text::lit("join"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text::lit("p")}))})})}), Ex(Ex::XVar{Text::lit("e")})}), [=](Do add_293661) { return prism_rtl::finished(Do(Do::DoIfLet{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("row")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), gd.name})), Text::lit("borrow"), Array<Ex>{}})), Text::lit("as_ref"), Array<Ex>{}}), Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text::lit("g")}), Ex(Ex::XBin{Text::lit("-"), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(gd.name, "_count")})), Text::lit("get"), Array<Ex>{}})), prism_rtl::rc(Ex(Ex::XIndex{Nat(1u)}))})}), Do(Do::DoFor{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{Text::lit("p")}), Pa(Pa::PaBind{Text::lit("e")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("row")})), Text::lit("document"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{add_293661})})}), Array<Do>{}})); });
            });
        }));
        });
    })));
    })));
    return append(append(statics, rows), generations);
}


/// MapInsert: fn Ex, Ex -> Do
Do map_insert(const Ex& path_, const Ex& e) {
    return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("doc")})), Text::lit("insert"), Array(std::vector{path_, e})})});
}


/// VecPush: fn Ex, Ex -> Do
Do vec_push(const Ex& path_, const Ex& e) {
    return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("doc")})), Text::lit("push"), Array(std::vector{Ex(Ex::XTuple{Array(std::vector{path_, e})})})})});
}


/// DynAnswerArm: fn Sinks, Pos, Text, OutTy -> ((Pa, Ex))
std::tuple<Pa, Ex> dyn_answer_arm(const Sinks& sk, const Pos_& pos, const Text& f, const OutTy& t) {
    return std::tuple{pos_pat(pos, Array<Pa>{}), Ex(Ex::XBlock{dyn_place_write(sk, f, Ex(Ex::XDecode{t, prism_rtl::rc(Ex(Ex::XVar{Text::lit("v")}))})), prism_rtl::rc(Ex(Ex::XUnit{}))})};
}


/// DynPlaceWrite: fn Sinks, Text, Ex -> [Do]
Array<Do> dyn_place_write(const Sinks& sk, const Text& f, const Ex& value) {
    return append(Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("set"), Array(std::vector{value, Ex(Ex::XCx{})})})})}), hold_written(sk, f));
}


/// UpdatedGaps: fn Wx, [Gn], Bool -> [Do]
Array<Do> updated_gaps(const Wx& wx, const Array<Gn>& gns, const bool& is_gen) {
    auto holds = fold(wx.fields, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, OutTy, Text>& _p1) {
        auto&& f = std::get<0>(_p1);
        auto&& t = std::get<1>(_p1);
        return is_hold(t) ? prelude::push(acc, f) : acc;
    });
    auto derived = keys(wx.dyn_reads);
    auto roots = snap_names(wx);
    auto own_ = fold(filter(gns, [&](const Gn& g) { return g.kind == GnKind(GnKind::GnUpdated{}); }), Array<Do>{}, [&](const Array<Do>& acc, const Gn& g) {
        return fold(g.reads, acc, [&](const Array<Do>& a, const Read& r) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<Do>> _v;
                if (prism_rtl::is<Read::ParentRead>(r)) {
                    auto&& f = prism_rtl::as<Read::ParentRead>(r).a0;
                    _v.set(is_gen
                        ? prelude::push(a, refusal_do(prism_rtl::cat("`!Updated` of a dynamic in a generation that reads its block's `", f, "`, which the block does not tell a generation of (gap DY)")))
                        : a);
                    goto _done;
                }
                if (prism_rtl::is<Read::OwnRead>(r)) {
                    auto&& f = prism_rtl::as<Read::OwnRead>(r).a0;
                    _v.set((check_types::has_text(holds, f) || check_types::has_text(derived, f)) || check_types::has_text(roots, f)
                        ? a
                        : prelude::push(a, refusal_do(prism_rtl::cat("`!Updated` of a dynamic that reads `", f, "`, which no sink of this node writes (no height for its event)"))));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    });
    return fold(wx.pending, own_, [&](const Array<Do>& acc, const PendingRow& p_) {
        return fold(row_hears(p_.wx), acc, [&](const Array<Do>& a, const Text& m) {
            return ({
                auto behind = reads_closed(wx.dyn_reads, Array(std::vector{Read(Read::OwnRead{m})}));
                auto written = fold(behind, false, [&](const bool& w, const Read& r) {
                    return w || ({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        if (prism_rtl::is<Read::OwnRead>(r)) {
                            auto&& h = prism_rtl::as<Read::OwnRead>(r).a0;
                            _v.set(check_types::has_text(holds, h));
                            goto _done;
                        }
                        if (prism_rtl::is<Read::ParentRead>(r)) {
                            _v.set(true);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                });
                (check_types::has_text(roots, m) || reaches_snap(roots, behind)
                ? prelude::push(a, refusal_do(prism_rtl::cat("`!Updated` of a dynamic in a row that reads its block's `", m, "`, a structural dynamic the block publishes at the start of a tick, not lowered for a row's `!Updated` (gap SU)")))
                : written || check_types::has_text(derived, m)
                ? a
                : prelude::push(a, refusal_do(prism_rtl::cat("`!Updated` of a dynamic in a row that reads its block's `", m, "`, which no sink of the block writes (no height for its event)"))));
            });
        });
    });
}

}  // namespace crate::lower
