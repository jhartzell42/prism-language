// The module `Typed`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <typed/types.hpp>
#include "elem.types.hpp"
#include <check_types/types.hpp>
#include <ast/types.hpp>
#include <check_errors/types.hpp>
#include <lexer/types.hpp>

namespace crate {

using namespace prelude;

namespace typed {

TProgram empty_typed();

Text at_key(const SrcAt& a);

Text ty_sexp(const crate::check_types::Ty& t);

prism_rtl::JobRef<Text> start_ty_sexp(crate::check_types::Ty t);

Text col_sexp(const crate::check_types::Col& col0);

Text row_sexp(const crate::check_types::Rw& rw);

Text scheme_sexp(const crate::check_types::Scheme& sc);

prism_rtl::JobRef<Text> start_scheme_sexp(crate::check_types::Scheme sc);

Text at_text(const Array<crate::check_errors::Src>& srcs, const SrcAt& a);

Text pos_text(const crate::check_errors::Src& src, const Nat& offset);

Text typed_sexp(const Array<crate::check_errors::Src>& srcs, const Array<crate::ast::Module>& trees, const Nat& shown_, const TProgram& tp);

prism_rtl::JobRef<Text> start_typed_sexp(Array<crate::check_errors::Src> srcs, Array<crate::ast::Module> trees, Nat shown_, TProgram tp);

bool shown(const SrcAt& a, const Nat& shown_);

crate::ast::Module empty_mod();

Text quote(const Text& t);

Text layer_word(const Text& text0);

Text exprs_of_file(const Array<crate::check_errors::Src>& srcs, const Map<Text, crate::check_types::Ty>& tys, const Nat& file, const crate::ast::Module& m);

prism_rtl::JobRef<Text> start_exprs_of_file(Array<crate::check_errors::Src> srcs, Map<Text, crate::check_types::Ty> tys, Nat file, crate::ast::Module m);

Text expr_line(const Array<crate::check_errors::Src>& srcs, const Map<Text, crate::check_types::Ty>& tys, const SrcAt& a);

prism_rtl::JobRef<Text> start_expr_line(Array<crate::check_errors::Src> srcs, Map<Text, crate::check_types::Ty> tys, SrcAt a);

Array<crate::ast::Expr> decl_exprs(const crate::ast::Decl& d);

prism_rtl::JobRef<Array<crate::ast::Expr>> start_decl_exprs(crate::ast::Decl d);

Array<crate::ast::Expr> body_exprs(const crate::ast::FnBody& fn_body0);

prism_rtl::JobRef<Array<crate::ast::Expr>> start_body_exprs(crate::ast::FnBody fn_body0);

Array<crate::ast::Expr> stmts_exprs(const Array<crate::ast::Stmt>& stmts);

prism_rtl::JobRef<Array<crate::ast::Expr>> start_stmts_exprs(Array<crate::ast::Stmt> stmts);

Array<crate::ast::Expr> stmt_exprs(const crate::ast::Stmt& s);

prism_rtl::JobRef<Array<crate::ast::Expr>> start_stmt_exprs(crate::ast::Stmt s);

Array<crate::ast::Expr> cond_exprs(const crate::ast::Cond& cond0);

prism_rtl::JobRef<Array<crate::ast::Expr>> start_cond_exprs(crate::ast::Cond cond0);

Array<crate::ast::Expr> args_exprs(const Array<crate::ast::Arg>& args);

prism_rtl::JobRef<Array<crate::ast::Expr>> start_args_exprs(Array<crate::ast::Arg> args);

Array<crate::ast::Expr> block_exprs(const crate::ast::Block& b);

prism_rtl::JobRef<Array<crate::ast::Expr>> start_block_exprs(crate::ast::Block b);

Array<crate::ast::Expr> exprs_in(const crate::ast::Expr& e);

prism_rtl::JobRef<Array<crate::ast::Expr>> start_exprs_in(crate::ast::Expr e);

Array<crate::ast::Expr> template_exprs(const Array<crate::ast::TemplatePart>& parts);

prism_rtl::JobRef<Array<crate::ast::Expr>> start_template_exprs(Array<crate::ast::TemplatePart> parts);

Array<crate::ast::Expr> opt_parts(const std::optional<Array<crate::ast::TemplatePart>>& opt0);

prism_rtl::JobRef<Array<crate::ast::Expr>> start_opt_parts(std::optional<Array<crate::ast::TemplatePart>> opt0);

Array<crate::ast::Expr> opt_block_exprs(const std::optional<crate::ast::Block>& opt0);

prism_rtl::JobRef<Array<crate::ast::Expr>> start_opt_block_exprs(std::optional<crate::ast::Block> opt0);

Array<crate::ast::Expr> opt_exprs(const std::optional<crate::ast::Expr>& opt0);

prism_rtl::JobRef<Array<crate::ast::Expr>> start_opt_exprs(std::optional<crate::ast::Expr> opt0);

}  // namespace typed


namespace typed {

/// The step machine of `TySexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TySexp: unbounded fn Ty -> Text
struct TySexp : prism_rtl::Job<Text> {
    crate::check_types::Ty t;
    TySexp(crate::check_types::Ty t) : t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `SchemeSexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SchemeSexp: unbounded fn Scheme -> Text
struct SchemeSexp : prism_rtl::Job<Text> {
    crate::check_types::Scheme sc;
    SchemeSexp(crate::check_types::Scheme sc) : sc(std::move(sc)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TypedSexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypedSexp: unbounded fn [Src], [Module], Nat, TProgram -> Text
struct TypedSexp : prism_rtl::Job<Text> {
    Array<crate::check_errors::Src> srcs;
    Array<crate::ast::Module> trees;
    Nat shown_;
    TProgram tp;
    TypedSexp(Array<crate::check_errors::Src> srcs, Array<crate::ast::Module> trees, Nat shown_, TProgram tp) : srcs(std::move(srcs)), trees(std::move(trees)), shown_(std::move(shown_)), tp(std::move(tp)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ExprsOfFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExprsOfFile: unbounded fn [Src], (Text ==> Ty), Nat, Module -> Text
struct ExprsOfFile : prism_rtl::Job<Text> {
    Array<crate::check_errors::Src> srcs;
    Map<Text, crate::check_types::Ty> tys;
    Nat file;
    crate::ast::Module m;
    ExprsOfFile(Array<crate::check_errors::Src> srcs, Map<Text, crate::check_types::Ty> tys, Nat file, crate::ast::Module m) : srcs(std::move(srcs)), tys(std::move(tys)), file(std::move(file)), m(std::move(m)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ExprLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExprLine: unbounded fn [Src], (Text ==> Ty), SrcAt -> Text
struct ExprLine : prism_rtl::Job<Text> {
    Array<crate::check_errors::Src> srcs;
    Map<Text, crate::check_types::Ty> tys;
    SrcAt a;
    ExprLine(Array<crate::check_errors::Src> srcs, Map<Text, crate::check_types::Ty> tys, SrcAt a) : srcs(std::move(srcs)), tys(std::move(tys)), a(std::move(a)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `DeclExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DeclExprs: unbounded fn Decl -> [Expr]
struct DeclExprs : prism_rtl::Job<Array<crate::ast::Expr>> {
    crate::ast::Decl d;
    DeclExprs(crate::ast::Decl d) : d(std::move(d)) {}
    prism_rtl::Turn<Array<crate::ast::Expr>> cycle() const override;
};


/// The step machine of `BodyExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BodyExprs: unbounded fn FnBody -> [Expr]
struct BodyExprs : prism_rtl::Job<Array<crate::ast::Expr>> {
    crate::ast::FnBody fn_body0;
    BodyExprs(crate::ast::FnBody fn_body0) : fn_body0(std::move(fn_body0)) {}
    prism_rtl::Turn<Array<crate::ast::Expr>> cycle() const override;
};


/// The step machine of `StmtsExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtsExprs: unbounded fn [Stmt] -> [Expr]
struct StmtsExprs : prism_rtl::Job<Array<crate::ast::Expr>> {
    Array<crate::ast::Stmt> stmts;
    StmtsExprs(Array<crate::ast::Stmt> stmts) : stmts(std::move(stmts)) {}
    prism_rtl::Turn<Array<crate::ast::Expr>> cycle() const override;
};


/// The step machine of `StmtExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtExprs: unbounded fn Stmt -> [Expr]
struct StmtExprs : prism_rtl::Job<Array<crate::ast::Expr>> {
    crate::ast::Stmt s;
    StmtExprs(crate::ast::Stmt s) : s(std::move(s)) {}
    prism_rtl::Turn<Array<crate::ast::Expr>> cycle() const override;
};


/// The step machine of `CondExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondExprs: unbounded fn Cond -> [Expr]
struct CondExprs : prism_rtl::Job<Array<crate::ast::Expr>> {
    crate::ast::Cond cond0;
    CondExprs(crate::ast::Cond cond0) : cond0(std::move(cond0)) {}
    prism_rtl::Turn<Array<crate::ast::Expr>> cycle() const override;
};


/// The step machine of `ArgsExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArgsExprs: unbounded fn [Arg] -> [Expr]
struct ArgsExprs : prism_rtl::Job<Array<crate::ast::Expr>> {
    Array<crate::ast::Arg> args;
    ArgsExprs(Array<crate::ast::Arg> args) : args(std::move(args)) {}
    prism_rtl::Turn<Array<crate::ast::Expr>> cycle() const override;
};


/// The step machine of `BlockExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockExprs: unbounded fn Block -> [Expr]
struct BlockExprs : prism_rtl::Job<Array<crate::ast::Expr>> {
    crate::ast::Block b;
    BlockExprs(crate::ast::Block b) : b(std::move(b)) {}
    prism_rtl::Turn<Array<crate::ast::Expr>> cycle() const override;
};


/// The step machine of `ExprsIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExprsIn: unbounded fn Expr -> [Expr]
struct ExprsIn : prism_rtl::Job<Array<crate::ast::Expr>> {
    crate::ast::Expr e;
    ExprsIn(crate::ast::Expr e) : e(std::move(e)) {}
    prism_rtl::Turn<Array<crate::ast::Expr>> cycle() const override;
};


/// The step machine of `TemplateExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateExprs: unbounded fn [TemplatePart] -> [Expr]
struct TemplateExprs : prism_rtl::Job<Array<crate::ast::Expr>> {
    Array<crate::ast::TemplatePart> parts;
    TemplateExprs(Array<crate::ast::TemplatePart> parts) : parts(std::move(parts)) {}
    prism_rtl::Turn<Array<crate::ast::Expr>> cycle() const override;
};


/// The step machine of `OptParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptParts: unbounded fn ?[TemplatePart] -> [Expr]
struct OptParts : prism_rtl::Job<Array<crate::ast::Expr>> {
    std::optional<Array<crate::ast::TemplatePart>> opt0;
    OptParts(std::optional<Array<crate::ast::TemplatePart>> opt0) : opt0(std::move(opt0)) {}
    prism_rtl::Turn<Array<crate::ast::Expr>> cycle() const override;
};


/// The step machine of `OptBlockExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptBlockExprs: unbounded fn ?Block -> [Expr]
struct OptBlockExprs : prism_rtl::Job<Array<crate::ast::Expr>> {
    std::optional<crate::ast::Block> opt0;
    OptBlockExprs(std::optional<crate::ast::Block> opt0) : opt0(std::move(opt0)) {}
    prism_rtl::Turn<Array<crate::ast::Expr>> cycle() const override;
};


/// The step machine of `OptExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptExprs: unbounded fn ?Expr -> [Expr]
struct OptExprs : prism_rtl::Job<Array<crate::ast::Expr>> {
    std::optional<crate::ast::Expr> opt0;
    OptExprs(std::optional<crate::ast::Expr> opt0) : opt0(std::move(opt0)) {}
    prism_rtl::Turn<Array<crate::ast::Expr>> cycle() const override;
};


}  // namespace typed

}  // namespace crate
