// The root module, from `target/bootstrap/cpp-src/prismc/app.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include <program/module.hpp>
#include <syntax/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/env/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/passes/module.hpp>
#include <check/shrink/module.hpp>
#include <check/typed/module.hpp>
#include <check/types/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <process/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <lower/node_/generic.hpp>
#include <syntax/lexer/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::program {

prism_rtl::Turn<TreeAcc> WalkModule::cycle() const {
    const auto& has = this->has;
    const auto& texts = this->texts;
    const auto& acc = this->acc;
    const auto& main = this->main;
    const auto& name = this->name;
    auto dir = dir_of(main);
    auto text = or_(crate::prelude::get(texts, main), Text::lit(""));
    auto heads = header_lines(text);
    auto mods = filter(heads, [&](const HeadLine& h) { return (h.word == Text::lit("mod")) || (h.word == Text::lit("test mod")); });
    auto subs = filter(mods, [&](const HeadLine& h) { return (h.word == Text::lit("mod")) && crate::check::env::is_upper_text(h.arg); });
    auto files = filter(mods, [&](const HeadLine& h) { return !((h.word == Text::lit("mod")) && crate::check::env::is_upper_text(h.arg)); });
    auto named = name == Text::lit("")
        ? Text::lit("its path makes it the root")
        : prism_rtl::cat("its path names the module `", name, "`");
    auto acc1 = fold(filter(heads, [&](const HeadLine& h) { return h.word == Text::lit("module"); }), acc, [&](const TreeAcc& a, const HeadLine& h) { return add_tree_diag(a, main, h.span, Text::lit("module-line"), prism_rtl::cat("a main file has no `module` line: ", named), Text::lit("delete the line")); });
    auto acc2 = fold(subs, acc1, [&](const TreeAcc& a, const HeadLine& s) { return fold(filter(files, [&](const HeadLine& f) { return (f.word == Text::lit("mod")) && (f.arg == dir_name(s.arg)); }), a, [&](const TreeAcc& b, const HeadLine& f) { return add_tree_diag(b, main, s.span.start > f.span.start ? s.span : f.span, Text::lit("mod-clash"), prism_rtl::cat("`mod ", s.arg, "` and `mod ", f.arg, "` in one header: the section `", f.arg, ".prism` and the submodule `", dir_name(s.arg), "/` have one name"), Text::lit("rename the section or the submodule")); }); });
    auto acc3 = ({
        TreeAcc this_ = acc2;
        this_.declared = insert(this_.declared, main, true);
        this_;
    });
    auto [segs, acc4] = fold(files, std::tuple{Array(std::vector{Seg{.path_ = main, .text = text, .role = Text::lit("main")}}), acc3}, [&](const std::tuple<Array<Seg>, TreeAcc>& _p0, const HeadLine& h) {
        auto&& ss = std::get<0>(_p0);
        auto&& a = std::get<1>(_p0);
        return ({
            auto path_ = under(dir, prism_rtl::cat(h.arg, ".prism"));
            auto role = h.word == Text::lit("test mod") ? Text::lit("test") : Text::lit("section");
            (!crate::check::env::has_key(has, path_)
            ? std::tuple{ss, add_tree_diag(a, main, h.span, Text::lit("mod-missing"), prism_rtl::cat("`", h.word, " ", h.arg, "` declares `", h.arg, ".prism`, which is not in the directory"), prism_rtl::cat("create ", h.arg, ".prism, or delete the line"))}
            : ({
            auto body = or_(crate::prelude::get(texts, path_), Text::lit(""));
            auto a2 = ({
                TreeAcc this_ = a;
                this_.declared = insert(this_.declared, path_, true);
                this_;
            });
            auto what = role == Text::lit("test")
                ? Text::lit("a test module")
                : Text::lit("a section");
            auto a3 = ({
                __label__ _done;
                prism_rtl::Slot<TreeAcc> _v;
                auto&& _m = index(header_lines(body), Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& h2 = prism_rtl::some_of(_m);
                    _v.set(add_tree_diag(a2, path_, h2.span, Text::lit("section-header"), prism_rtl::cat(what, " has no header: `", h2.word, "` belongs in ", base_of(main), ", the main file of its module"), prism_rtl::cat("move the line to ", base_of(main))));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(a2);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            std::tuple{crate::prelude::push(ss, Seg{.path_ = path_, .text = body, .role = role}), a3};
        }));
        });
    });
    auto ordered = append(filter(segs, [&](const Seg& s) { return s.role != Text::lit("test"); }), filter(segs, [&](const Seg& s) { return s.role == Text::lit("test"); }));
    auto acc5 = ({
        TreeAcc this_ = acc4;
        this_.units = crate::prelude::push(this_.units, ModFiles{.name = name, .named = true, .segs = ordered});
        this_;
    });
    return fold_job(subs, acc5, ({
        auto has_1 = has;
        auto texts_2 = texts;
        auto main_3 = main;
        auto dir_4 = dir;
        auto name_5 = name;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<TreeAcc>(std::tuple<TreeAcc, HeadLine>)>>(prism_rtl::rc([=](std::tuple<TreeAcc, HeadLine> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto has_1_6 = has_1;
            auto texts_2_6 = texts_2;
            auto main_3_6 = main_3;
            auto dir_4_6 = dir_4;
            auto name_5_6 = name_5;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                auto h = p1;
                (prism_rtl::more(prism_rtl::rc(Submodule(has_1_6, texts_2_6, a, main_3_6, dir_4_6, h, name_5_6))));
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start WalkModule, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TreeAcc> start_walk_module(Map<Text, bool> has, Map<Text, Text> texts, TreeAcc acc, Text main, Text name) {
    return prism_rtl::make_rc<WalkModule>(has, texts, acc, main, name);
}


/// Submodule: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, HeadLine, Text -> TreeAcc
TreeAcc submodule(const Map<Text, bool>& has, const Map<Text, Text>& texts, const TreeAcc& acc, const Text& main, const Text& dir, const HeadLine& h, const Text& parent) {
    auto path_ = under(dir, prism_rtl::cat(dir_name(h.arg), "/mod.prism"));
    return crate::check::env::has_key(has, path_)
        ? walk_module(has, texts, acc, path_, parent == Text::lit("") ? h.arg : prism_rtl::cat(parent, ".", h.arg))
        : add_tree_diag(acc, main, h.span, Text::lit("mod-missing"), prism_rtl::cat("`mod ", h.arg, "` declares `", dir_name(h.arg), "/mod.prism`, which is not in the directory"), prism_rtl::cat("create ", dir_name(h.arg), "/mod.prism, or delete the line"));
}


prism_rtl::Turn<TreeAcc> Submodule::cycle() const {
    const auto& has = this->has;
    const auto& texts = this->texts;
    const auto& acc = this->acc;
    const auto& main = this->main;
    const auto& dir = this->dir;
    const auto& h = this->h;
    const auto& parent = this->parent;
    auto path_ = under(dir, prism_rtl::cat(dir_name(h.arg), "/mod.prism"));
    return crate::check::env::has_key(has, path_)
        ? prism_rtl::more(prism_rtl::rc(WalkModule(has, texts, acc, path_, parent == Text::lit("") ? h.arg : prism_rtl::cat(parent, ".", h.arg))))
        : prism_rtl::finished(add_tree_diag(acc, main, h.span, Text::lit("mod-missing"), prism_rtl::cat("`mod ", h.arg, "` declares `", dir_name(h.arg), "/mod.prism`, which is not in the directory"), prism_rtl::cat("create ", dir_name(h.arg), "/mod.prism, or delete the line")));
}


/// `Start Submodule, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TreeAcc> start_submodule(Map<Text, bool> has, Map<Text, Text> texts, TreeAcc acc, Text main, Text dir, HeadLine h, Text parent) {
    return prism_rtl::make_rc<Submodule>(has, texts, acc, main, dir, h, parent);
}


/// Stray: fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
TreeAcc stray(const Map<Text, bool>& has, const Map<Text, Text>& texts, const TreeAcc& acc, const Text& f) {
    auto text = or_(crate::prelude::get(texts, f), Text::lit(""));
    return crate::syntax::lexer::has_suffix(f, Text::lit(".prismtest"))
        ? add_tree_diag(acc, f, no_span(), Text::lit("mod-stray"), prism_rtl::cat("`", base_of(f), "` is a test script in a tree, where tests are in test modules"), Text::lit("put its declarations in a test module, declared by `test mod tests`"))
        : ({
        auto dir = dir_of(f);
        auto is_main = base_of(f) == Text::lit("mod.prism");
        auto home = is_main ? dir_of(dir) : dir;
        auto main = fold(Array(std::vector{Text::lit("mod.prism"), Text::lit("app.prism"), Text::lit("lib.prism")}), Text::lit(""), [&](const Text& m, const Text& n) {
            return (m == Text::lit("")) && crate::check::env::has_key(has, under(home, n))
                ? n
                : m;
        });
        auto line = is_main
            ? prism_rtl::cat("mod ", mod_of_dir(base_of(dir)))
            : prism_rtl::cat("mod ", or_(crate::syntax::lexer::before_suffix(base_of(f), Text::lit(".prism")), f));
        auto shown = is_main ? prism_rtl::cat(base_of(dir), "/mod.prism") : base_of(f);
        main == Text::lit("")
        ? add_tree_diag(acc, f, no_span(), Text::lit("mod-stray"), prism_rtl::cat("`", f, "` is in a tree, in no module's directory"), Text::lit("move it into a module's directory and declare it with a `mod` line"))
        : add_tree_diag(acc, f, no_span(), Text::lit("mod-stray"), prism_rtl::cat("`", shown, "` is in the directory of `", main, "`, which declares no `", line, "`"), prism_rtl::cat("declare it with `", line, "` in ", main, ", or move it out of the directory"));
    });
}


/// ReachTree: unbounded fn [ModFiles], Text -> [ModFiles]
Array<ModFiles> reach_tree(const Array<ModFiles>& units, const Text& main) {
    auto by_name = fold(units, Map<Text, ModFiles>{}, [&](const Map<Text, ModFiles>& m, const ModFiles& u) { return insert(m, unit_name(u), u); });
    auto start = fold(units, Array<Text>{}, [&](const Array<Text>& s, const ModFiles& u) { return main_path(u) == main ? Array(std::vector{unit_name(u)}) : s; });
    auto reached = reach_names(by_name, start, start);
    return filter(units, [&](const ModFiles& u) { return crate::check::types::has_text(reached, unit_name(u)); });
}


prism_rtl::Turn<Array<ModFiles>> ReachTree::cycle() const {
    const auto& units = this->units;
    const auto& main = this->main;
    auto by_name = fold(units, Map<Text, ModFiles>{}, [&](const Map<Text, ModFiles>& m, const ModFiles& u) { return insert(m, unit_name(u), u); });
    auto start = fold(units, Array<Text>{}, [&](const Array<Text>& s, const ModFiles& u) { return main_path(u) == main ? Array(std::vector{unit_name(u)}) : s; });
    auto units_1 = units;
    return call_then(start_reach_names(by_name, start, start), [=](Array<Text> reach_names_28157) {
        return ({
            auto reached = reach_names_28157;
            (prism_rtl::finished(filter(units_1, [&](const ModFiles& u) { return crate::check::types::has_text(reached, unit_name(u)); })));
        });
    });
}


/// `Start ReachTree, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<ModFiles>> start_reach_tree(Array<ModFiles> units, Text main) {
    return prism_rtl::make_rc<ReachTree>(units, main);
}


/// ReachNames: unbounded fn (Text ==> ModFiles), [Text], [Text] -> [Text]
Array<Text> reach_names(const Map<Text, ModFiles>& by_name, const Array<Text>& seen, const Array<Text>& todo) {
    auto&& _m = index(todo, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return seen;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        auto uses = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = crate::prelude::get(by_name, n);
            if (prism_rtl::is_some(_m)) {
                auto&& u = prism_rtl::some_of(_m);
                _v.set(each(filter(header_lines(main_text(u)), [&](const HeadLine& h) { return h.word == Text::lit("use"); }), [&](const HeadLine& h) { return h.arg; }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto fresh = filter(uses, [&](const Text& x) { return (!crate::check::types::has_text(seen, x)) && crate::check::env::has_key(by_name, x); });
        return reach_names(by_name, crate::check::types::union_texts(seen, fresh), append(drop(todo, Nat(1u)), fresh));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> ReachNames::cycle() const {
    const auto& by_name = this->by_name;
    const auto& seen = this->seen;
    const auto& todo = this->todo;
    return ({
        auto&& _m = index(todo, Nat(0u));
        prism_rtl::is_none(_m) ? prism_rtl::finished(seen)
        : prism_rtl::is_some(_m) ? ({
        auto&& n = prism_rtl::some_of(_m);
        ({
        auto uses = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = crate::prelude::get(by_name, n);
            if (prism_rtl::is_some(_m)) {
                auto&& u = prism_rtl::some_of(_m);
                _v.set(each(filter(header_lines(main_text(u)), [&](const HeadLine& h) { return h.word == Text::lit("use"); }), [&](const HeadLine& h) { return h.arg; }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto fresh = filter(uses, [&](const Text& x) { return (!crate::check::types::has_text(seen, x)) && crate::check::env::has_key(by_name, x); });
        (prism_rtl::more(prism_rtl::rc(ReachNames(by_name, crate::check::types::union_texts(seen, fresh), append(drop(todo, Nat(1u)), fresh)))));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ReachNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_reach_names(Map<Text, ModFiles> by_name, Array<Text> seen, Array<Text> todo) {
    return prism_rtl::make_rc<ReachNames>(by_name, seen, todo);
}


/// UnitName: fn ModFiles -> Text
Text unit_name(const ModFiles& u) {
    return u.named
        ? u.name
        : fold(header_lines(main_text(u)), Text::lit(""), [&](const Text& n, const HeadLine& h) { return h.word == Text::lit("module") ? h.arg : n; });
}


/// RenderTreeDiag: fn (Text ==> Text), TreeDiag -> Text
Text render_tree_diag(const Map<Text, Text>& texts, const TreeDiag& d) {
    return crate::check::errors::render_cdiag(Array(std::vector{crate::check::errors::mk_src(d->path_, or_(crate::prelude::get(texts, d->path_), Text::lit("")))}), crate::check::errors::CDiag{.code = d.code, .file = Nat(0u), .span = d.span, .message = d.message, .fix = d.fix});
}


/// TreeReport: fn ReadInput, [TreeDiag] -> Text
Text tree_report(const ReadInput& input, const Array<TreeDiag>& ds) {
    auto texts = map(input->texts);
    auto n = len(ds);
    return prism_rtl::cat(concat(each(ds, [&](const TreeDiag& d) { return render_tree_diag(texts, d); })), n, " error", n == Nat(1u) ? Text::lit("") : Text::lit("s"));
}


/// ParseUnit: unbounded fn ModFiles -> ((Src, Parsed))
std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed> parse_unit(const ModFiles& u) {
    auto src = crate::check::errors::mk_joined_src(each(u.segs, [&](const Seg& s) { return std::tuple{s->path_, s->text, s.role}; }));
    auto parsed = crate::syntax::parser::parse_file(src->text);
    auto t0 = parsed.tree;
    auto tree = !u.named
        ? t0
        : ({
        crate::syntax::Module this_ = t0;
        this_.name = u.name == Text::lit("")
            ? std::optional<crate::syntax::QualName>{}
            : std::optional(crate::syntax::QualName{.path_ = split(u.name, Text::lit(".")), .span = no_span()});
        this_;
    });
    return std::tuple{src, crate::syntax::parser::Parsed{.tree = tree, .diags = parsed.diags}};
}


prism_rtl::Turn<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> ParseUnit::cycle() const {
    const auto& u = this->u;
    auto src = crate::check::errors::mk_joined_src(each(u.segs, [&](const Seg& s) { return std::tuple{s->path_, s->text, s.role}; }));
    auto u_1 = u;
    return call_then(crate::syntax::parser::start_parse_file(src->text), [=](crate::syntax::parser::Parsed parse_file_29804) {
        return ({
            auto parsed = parse_file_29804;
            auto t0 = parsed.tree;
            auto tree = !u_1.named
                ? t0
                : ({
                crate::syntax::Module this_ = t0;
                this_.name = u_1.name == Text::lit("")
                    ? std::optional<crate::syntax::QualName>{}
                    : std::optional(crate::syntax::QualName{.path_ = split(u_1.name, Text::lit(".")), .span = no_span()});
                this_;
            });
            (prism_rtl::finished(std::tuple{src, crate::syntax::parser::Parsed{.tree = tree, .diags = parsed.diags}}));
        });
    });
}


/// `Start ParseUnit, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> start_parse_unit(ModFiles u) {
    return prism_rtl::make_rc<ParseUnit>(u);
}


/// ParseProgram: unbounded fn Assembled -> ParsedProgram
ParsedProgram parse_program(const Assembled& read) {
    auto parsed = run_to_end(each_job(read.units, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>>(ModFiles)>>(prism_rtl::rc([=](ModFiles p0) {
        return entered(once_job([=]() {
            return ({
                auto u = p0;
                (prism_rtl::more(prism_rtl::rc(ParseUnit(u))));
            });
        }));
    }))));
    auto user_mods = fold(parsed, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
        auto&& p_ = std::get<1>(_p1);
        return crate::prelude::push(acc, crate::check::env::mod_name(p_.tree));
    });
    auto user_fams = fold(parsed, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
        auto&& p_ = std::get<1>(_p1);
        return append(acc, tag_families(p_.tree));
    });
    auto pre_parsed = run_to_end(each_job(read->prelude, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>>(ModFiles)>>(prism_rtl::rc([=](ModFiles p0) {
        return entered(once_job([=]() {
            return ({
                auto u = p0;
                (prism_rtl::more(prism_rtl::rc(ParseUnit(u))));
            });
        }));
    }))));
    auto kept = filter(pre_parsed, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
        auto&& p_ = std::get<1>(_p0);
        return (!crate::check::types::has_text(user_mods, crate::check::env::mod_name(p_.tree))) && (!any_in(tag_families(p_.tree), user_fams));
    });
    auto all = append(parsed, kept);
    auto errors_1 = fold(all, Text::lit(""), [&](const Text& acc, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
        auto&& src = std::get<0>(_p1);
        auto&& p_ = std::get<1>(_p1);
        return any_errors(p_.diags)
            ? prism_rtl::cat(acc, render_parse(src, p_.diags))
            : acc;
    });
    return ParsedProgram{.srcs = each(all, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
        auto&& s = std::get<0>(_p0);
        return s;
    }), .trees = each(all, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
        auto&& p_ = std::get<1>(_p0);
        return p_.tree;
    }), .shown = len(parsed), .errors = errors_1};
}


prism_rtl::Turn<ParsedProgram> ParseProgram::cycle() const {
    const auto& read = this->read;
    auto read_1 = read;
    return call_value(each_job(read_1.units, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>>(ModFiles)>>(prism_rtl::rc([=](ModFiles p0) {
        return entered(once_job([=]() {
            return ({
                auto u = p0;
                (prism_rtl::more(prism_rtl::rc(ParseUnit(u))));
            });
        }));
    }))), [=](Array<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> each_30466) {
        return ({
            auto parsed = each_30466;
            auto user_mods = fold(parsed, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
                auto&& p_ = std::get<1>(_p1);
                return crate::prelude::push(acc, crate::check::env::mod_name(p_.tree));
            });
            auto user_fams = fold(parsed, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
                auto&& p_ = std::get<1>(_p1);
                return append(acc, tag_families(p_.tree));
            });
            call_value(each_job(read_1->prelude, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>>(ModFiles)>>(prism_rtl::rc([=](ModFiles p0) {
            return entered(once_job([=]() {
                return ({
                    auto u = p0;
                    (prism_rtl::more(prism_rtl::rc(ParseUnit(u))));
                });
            }));
        }))), [=](Array<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> each_30700) {
            return ({
                auto pre_parsed = each_30700;
                auto kept = filter(pre_parsed, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
                    auto&& p_ = std::get<1>(_p0);
                    return (!crate::check::types::has_text(user_mods, crate::check::env::mod_name(p_.tree))) && (!any_in(tag_families(p_.tree), user_fams));
                });
                auto all = append(parsed, kept);
                auto errors_2 = fold(all, Text::lit(""), [&](const Text& acc, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
                    auto&& src = std::get<0>(_p1);
                    auto&& p_ = std::get<1>(_p1);
                    return any_errors(p_.diags)
                        ? prism_rtl::cat(acc, render_parse(src, p_.diags))
                        : acc;
                });
                (prism_rtl::finished(ParsedProgram{.srcs = each(all, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
                auto&& s = std::get<0>(_p0);
                return s;
            }), .trees = each(all, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
                auto&& p_ = std::get<1>(_p0);
                return p_.tree;
            }), .shown = len(parsed), .errors = errors_2}));
            });
        });
        });
    });
}


/// `Start ParseProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<ParsedProgram> start_parse_program(Assembled read) {
    return prism_rtl::make_rc<ParseProgram>(read);
}


/// WarningDiags: fn [Src], [TreeDiag] -> [CDiag]
Array<crate::check::errors::CDiag> warning_diags(const Array<crate::check::errors::Src>& srcs, const Array<TreeDiag>& ws) {
    return fold(ws, Array<crate::check::errors::CDiag>{}, [&](const Array<crate::check::errors::CDiag>& acc, const TreeDiag& w) {
        return fold(crate::check::errors::range0(len(srcs)), acc, [&](const Array<crate::check::errors::CDiag>& a, const Nat& i) {
            return or_(index(srcs, i), crate::check::errors::mk_src(Text::lit(""), Text::lit("")))->path_ == w->path_
                ? crate::prelude::push(a, crate::check::errors::CDiag{.code = w.code, .file = i, .span = w.span, .message = w.message, .fix = w.fix})
                : a;
        });
    });
}


/// TreeDeclDiags: fn [Src], [Module], Nat -> [CDiag]
Array<crate::check::errors::CDiag> tree_decl_diags(const Array<crate::check::errors::Src>& srcs, const Array<crate::syntax::Module>& trees, const Nat& shown) {
    return fold(crate::check::errors::range0(shown), Array<crate::check::errors::CDiag>{}, [&](const Array<crate::check::errors::CDiag>& acc, const Nat& i) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::errors::CDiag>> _v;
            auto&& _m = index(srcs, i);
            if (prism_rtl::is_some(_m)) {
                auto&& src = prism_rtl::some_of(_m);
                _v.set(fold(or_(index(trees, i), crate::check::env::empty_module()).decls, acc, [&](const Array<crate::check::errors::CDiag>& a, const crate::syntax::Decl& d) { return append(a, decl_role_diags(src, i, d)); }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// DeclRoleDiags: fn Src, Nat, Decl -> [CDiag]
Array<crate::check::errors::CDiag> decl_role_diags(const crate::check::errors::Src& src, const Nat& i, const crate::syntax::Decl& d) {
    auto role = crate::check::errors::seg_at(src, d.span.start).role;
    auto main = base_of(src->path_);
    auto what = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = d.kind;
        if (prism_rtl::is<crate::syntax::DeclKind::DTest>(_m)) {
            _v.set(Text::lit("test"));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::DeclKind::DCheck>(_m)) {
            _v.set(Text::lit("check"));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::DeclKind::DTag>(_m)) {
            _v.set(Text::lit("tag"));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::DeclKind::DTrait>(_m)) {
            _v.set(Text::lit("trait"));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::DeclKind::DImpl>(_m)) {
            _v.set(Text::lit("impl"));
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    return ((role == Text::lit("main")) || (role == Text::lit("section"))) && ((what == Text::lit("test")) || (what == Text::lit("check")))
        ? Array(std::vector{crate::check::errors::CDiag{.code = Text::lit("test-outside"), .file = i, .span = d.span, .message = prism_rtl::cat("a `", what, "` in a tree stands only in a test module"), .fix = prism_rtl::cat("move it to a test module: `test mod tests` in ", main, ", and tests.prism")}})
        : (role == Text::lit("test")) && (((what == Text::lit("tag")) || (what == Text::lit("trait"))) || (what == Text::lit("impl")))
        ? Array(std::vector{crate::check::errors::CDiag{.code = Text::lit("test-declares"), .file = i, .span = d.span, .message = Text::lit("a test module declares no tag, trait or impl"), .fix = prism_rtl::cat("declare it in ", main, " or a section of the module")}})
        : Array<crate::check::errors::CDiag>{};
}


/// TagFamilies: fn Module -> [Text]
Array<Text> tag_families(const crate::syntax::Module& m) {
    return fold(m.decls, Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::Decl& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = d.kind;
            if (prism_rtl::is<crate::syntax::DeclKind::DTag>(_m)) {
                auto&& t = prism_rtl::as<crate::syntax::DeclKind::DTag>(_m).a0;
                _v.set(crate::prelude::push(acc, crate::syntax::lexer::join(take(t.name->path_, crate::syntax::lexer::dec(len(t.name->path_))), Text::lit("."))));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// AnyIn: fn [Text], [Text] -> Bool
bool any_in(const Array<Text>& xs, const Array<Text>& ys) {
    return fold(xs, false, [&](const bool& seen, const Text& x) { return seen || crate::check::types::has_text(ys, x); });
}


/// RenderParse: fn Src, [Diag] -> Text
Text render_parse(const crate::check::errors::Src& src, const Array<crate::syntax::Diag>& ds) {
    return concat(each(filter(ds, [&](const crate::syntax::Diag& d) { return d.stage != Text::lit("out"); }), [&](const crate::syntax::Diag& d) { return prism_rtl::cat(crate::check::errors::src_place(src, d.span.start), ":", crate::syntax::lexer::column_of(src->text, or_(index(src.starts, crate::check::errors::cline_of(src.starts, d.span.start)), Nat(0u)), d.span.start) + Nat(1u), ": ", d.message, "\n"); }));
}


/// CheckFiles: unbounded fn CheckJob -> Outcome
Outcome_ check_files(const CheckJob& job) {
    auto read = assemble(job.read);
    return len(read.errors) > Nat(0u)
        ? ({
        auto report = tree_report(job.read, read.errors);
        Outcome_{.text = prism_rtl::cat(report, "\n"), .failed = true, .report = report};
    })
        : ({
        auto pp = parse_program(read);
        pp.errors != Text::lit("")
        ? Outcome_{.text = prism_rtl::cat(pp.errors, "parse errors\n"), .failed = true, .report = prism_rtl::cat(pp.errors, "parse errors")}
        : ({
        auto pre = append(warning_diags(pp.srcs, read.warnings), tree_decl_diags(pp.srcs, pp.trees, pp.shown));
        auto checked = each(pp.trees, [&](const crate::syntax::Module& t) { return without_tests(t); });
        auto report = crate::check::check_program(pp.srcs, checked, job->world, pp.shown, job.typed, job.unused, pre);
        auto summary = report.errors == Nat(0u)
            ? Text::lit("no errors\n")
            : prism_rtl::cat(report.errors, " error", report.errors == Nat(1u) ? Text::lit("") : Text::lit("s"), "\n");
        auto shown = job.typed
            ? prism_rtl::cat(crate::check::typed::typed_sexp(pp.srcs, checked, pp.shown, report.typed), commented(prism_rtl::cat(report->text, summary)))
            : prism_rtl::cat(report->text, summary);
        Outcome_{.text = shown, .failed = report.errors > Nat(0u), .report = prism_rtl::cat(report->text, summary)};
    });
    });
}


prism_rtl::Turn<Outcome_> CheckFiles::cycle() const {
    const auto& job = this->job;
    auto job_1 = job;
    return call_then(start_assemble(job_1.read), [=](Assembled assemble_34102) {
        return ({
            auto read = assemble_34102;
            len(read.errors) > Nat(0u)
            ? ({
            auto report = tree_report(job_1.read, read.errors);
            (prism_rtl::finished(Outcome_{.text = prism_rtl::cat(report, "\n"), .failed = true, .report = report}));
        })
            : call_then(start_parse_program(read), [=](ParsedProgram parse_program_34294) {
            return ({
                auto pp = parse_program_34294;
                pp.errors != Text::lit("")
                ? prism_rtl::finished(Outcome_{.text = prism_rtl::cat(pp.errors, "parse errors\n"), .failed = true, .report = prism_rtl::cat(pp.errors, "parse errors")})
                : ({
                auto pre = append(warning_diags(pp.srcs, read.warnings), tree_decl_diags(pp.srcs, pp.trees, pp.shown));
                auto checked = each(pp.trees, [&](const crate::syntax::Module& t) { return without_tests(t); });
                call_then(crate::check::start_check_program(pp.srcs, checked, job_1->world, pp.shown, job_1.typed, job_1.unused, pre), [=](crate::check::Report_ check_program_34788) {
                return ({
                    auto report = check_program_34788;
                    auto summary = report.errors == Nat(0u)
                        ? Text::lit("no errors\n")
                        : prism_rtl::cat(report.errors, " error", report.errors == Nat(1u) ? Text::lit("") : Text::lit("s"), "\n");
                    auto shown = job_1.typed
                        ? prism_rtl::cat(crate::check::typed::typed_sexp(pp.srcs, checked, pp.shown, report.typed), commented(prism_rtl::cat(report->text, summary)))
                        : prism_rtl::cat(report->text, summary);
                    (prism_rtl::finished(Outcome_{.text = shown, .failed = report.errors > Nat(0u), .report = prism_rtl::cat(report->text, summary)}));
                });
            });
            });
            });
        });
        });
    });
}


/// `Start CheckFiles, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Outcome_> start_check_files(CheckJob job) {
    return prism_rtl::make_rc<CheckFiles>(job);
}


/// Commented: fn Text -> Text
Text commented(const Text& t) {
    return concat(each(filter(split(t, Text::lit("\n")), [&](const Text& l) { return l != Text::lit(""); }), [&](const Text& l) { return prism_rtl::cat("; ", l, "\n"); }));
}


// `@CheckMain` is inlined where it is applied.

/// let checkValued
Array<Text> check_valued() {
    return Array(std::vector{Text::lit("--prelude"), Text::lit("--out"), Text::lit("--world")});
}


// `@FinishCheck` is inlined where it is applied.

// `@WriteOut` is inlined where it is applied.

// `@CompileMain` is inlined where it is applied.

/// let compileValued
Array<Text> compile_valued() {
    return Array(std::vector{Text::lit("-o"), Text::lit("--prelude"), Text::lit("--name"), Text::lit("--runtime"), Text::lit("--target")});
}


/// RuntimeFor: fn Text -> Text
Text runtime_for(const Text& out) {
    auto parts = filter(split(out, Text::lit("/")), [&](const Text& p_) { return (p_ != Text::lit("")) && (p_ != Text::lit(".")); });
    return len(parts) == Nat(0u)
        ? Text::lit(".")
        : crate::syntax::lexer::join(each(parts, [&](const Text& _p0) { return Text::lit(".."); }), Text::lit("/"));
}


/// CompileProgram: unbounded fn CompileJob -> Compiled
Compiled compile_program(const CompileJob& job) {
    auto read = assemble(job.read);
    return len(read.errors) > Nat(0u)
        ? Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = tree_report(job.read, read.errors)}
        : ({
        auto pp = parse_program(read);
        pp.errors != Text::lit("")
        ? Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = prism_rtl::cat(pp.errors, "parse errors")}
        : ({
        auto pre = tree_decl_diags(pp.srcs, pp.trees, pp.shown);
        auto report = crate::check::check_program(pp.srcs, each(pp.trees, [&](const crate::syntax::Module& t) { return without_tests(t); }), Array<Text>{}, pp.shown, true, false, pre);
        report.errors > Nat(0u)
        ? Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = prism_rtl::cat(report->text, report.errors, " error", report.errors == Nat(1u) ? Text::lit("") : Text::lit("s"))}
        : ({
        auto model = crate::lower::lower_program(pp.srcs, pp.trees, pp.shown, report.typed, job.name);
        auto files = job->target == Text::lit("cpp")
            ? crate::emit::cpp::emit_cpp(model, job.runtime, read.scripts)
            : crate::emit::rust::emit_crate(model, job.runtime, read.scripts);
        auto refused = fold(files, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text>& _p1) {
            auto&& path_ = std::get<0>(_p1);
            auto&& text = std::get<1>(_p1);
            return fold(refusals(text), acc, [&](const Array<Text>& a, const Text& r) { return crate::check::types::add_text(a, prism_rtl::cat(path_, ": ", r)); });
        });
        len(refused) == Nat(0u)
        ? Compiled{.files = files, .failed = false, .report = Text::lit("")}
        : Compiled{.files = files, .failed = true, .report = prism_rtl::cat(concat(each(refused, [&](const Text& r) { return prism_rtl::cat("error[not-lowered]: ", r, "\n"); })), len(refused), " construct", len(refused) == Nat(1u) ? Text::lit("") : Text::lit("s"), " the back end does not lower (the crate is written, with a `compile_error!` at each)")};
    });
    });
    });
}


prism_rtl::Turn<Compiled> CompileProgram::cycle() const {
    const auto& job = this->job;
    auto job_1 = job;
    return call_then(start_assemble(job_1.read), [=](Assembled assemble_39790) {
        return ({
            auto read = assemble_39790;
            len(read.errors) > Nat(0u)
            ? prism_rtl::finished(Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = tree_report(job_1.read, read.errors)})
            : call_then(start_parse_program(read), [=](ParsedProgram parse_program_39942) {
            return ({
                auto pp = parse_program_39942;
                pp.errors != Text::lit("")
                ? prism_rtl::finished(Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = prism_rtl::cat(pp.errors, "parse errors")})
                : ({
                auto pre = tree_decl_diags(pp.srcs, pp.trees, pp.shown);
                call_then(crate::check::start_check_program(pp.srcs, each(pp.trees, [&](const crate::syntax::Module& t) { return without_tests(t); }), Array<Text>{}, pp.shown, true, false, pre), [=](crate::check::Report_ check_program_40159) {
                return ({
                    auto report = check_program_40159;
                    report.errors > Nat(0u)
                    ? prism_rtl::finished(Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = prism_rtl::cat(report->text, report.errors, " error", report.errors == Nat(1u) ? Text::lit("") : Text::lit("s"))})
                    : call_then(crate::lower::start_lower_program(pp.srcs, pp.trees, pp.shown, report.typed, job_1.name), [=](crate::lower::model::Model lower_program_40448) {
                    return ({
                        auto model = lower_program_40448;
                        auto files = job_1->target == Text::lit("cpp")
                            ? crate::emit::cpp::emit_cpp(model, job_1.runtime, read.scripts)
                            : crate::emit::rust::emit_crate(model, job_1.runtime, read.scripts);
                        auto refused = fold(files, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text>& _p1) {
                            auto&& path_ = std::get<0>(_p1);
                            auto&& text = std::get<1>(_p1);
                            return fold(refusals(text), acc, [&](const Array<Text>& a, const Text& r) { return crate::check::types::add_text(a, prism_rtl::cat(path_, ": ", r)); });
                        });
                        len(refused) == Nat(0u)
                        ? prism_rtl::finished(Compiled{.files = files, .failed = false, .report = Text::lit("")})
                        : prism_rtl::finished(Compiled{.files = files, .failed = true, .report = prism_rtl::cat(concat(each(refused, [&](const Text& r) { return prism_rtl::cat("error[not-lowered]: ", r, "\n"); })), len(refused), " construct", len(refused) == Nat(1u) ? Text::lit("") : Text::lit("s"), " the back end does not lower (the crate is written, with a `compile_error!` at each)")});
                    });
                });
                });
            });
            });
            });
        });
        });
    });
}


/// `Start CompileProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Compiled> start_compile_program(CompileJob job) {
    return prism_rtl::make_rc<CompileProgram>(job);
}


/// Refusals: fn Text -> [Text]
Array<Text> refusals(const Text& text) {
    auto marker = Text::lit("compile_error!(\"prismc does not lower ");
    auto parts = split(text, marker);
    return fold(drop(parts, Nat(1u)), Array<Text>{}, [&](const Array<Text>& acc, const Text& part) { return crate::check::types::add_text(acc, or_(index(split(part, Text::lit("\")")), Nat(0u)), part)); });
}


/// WithoutTests: fn Module -> Module
crate::syntax::Module without_tests(const crate::syntax::Module& m) {
    crate::syntax::Module this_ = m;
    this_.decls = each(filter(this_.decls, [&](const crate::syntax::Decl& d) { return !is_test_decl(d); }), [&](const crate::syntax::Decl& d) { return without_patterns(d); });
    return this_;
}


/// WithoutPatterns: fn Decl -> Decl
crate::syntax::Decl without_patterns(const crate::syntax::Decl& d) {
    auto&& _m = d.kind;
    if (prism_rtl::is<crate::syntax::DeclKind::DCheck>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::DeclKind::DCheck>(_m).a0;
        crate::syntax::Decl this_ = d;
        this_.kind = crate::syntax::DeclKind(crate::syntax::DeclKind::DCheck{check_without_patterns(c)});
        return this_;
    }
    {
        return d;
    }
}


/// CheckWithoutPatterns: fn CheckDecl -> CheckDecl
crate::syntax::CheckDecl check_without_patterns(const crate::syntax::CheckDecl& c) {
    crate::syntax::CheckDecl this_ = c;
    this_.lines = each(this_.lines, [&](const crate::syntax::CheckLine& l) { return line_without_pattern(l); });
    return this_;
}


/// LineWithoutPattern: fn CheckLine -> CheckLine
crate::syntax::CheckLine line_without_pattern(const crate::syntax::CheckLine& l) {
    crate::syntax::CheckLine this_ = l;
    this_.pattern = std::optional<crate::syntax::Pattern_>{};
    return this_;
}


/// IsTestDecl: fn Decl -> Bool
bool is_test_decl(const crate::syntax::Decl& d) {
    auto&& _m = d.kind;
    if (prism_rtl::is<crate::syntax::DeclKind::DTest>(_m)) {
        return true;
    }
    {
        return false;
    }
}


// `@FinishCompile` is inlined where it is applied.

}  // namespace crate::program
