// The root module, from `target/bootstrap/cpp-src/prismc/app.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include <program/module.hpp>
#include <syntax/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/env/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/passes/module.hpp>
#include <check/shrink/module.hpp>
#include <check/typed/module.hpp>
#include <check/types/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <process/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <lower/node_/generic.hpp>
#include <syntax/lexer/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::program {

void Assembled::show(Printer& p) const {
    p.record("Assembled", {{"units", units}, {"prelude", prelude}, {"scripts", scripts}, {"warnings", warnings}, {"errors", errors}});
}

Pod Assembled::to_pod() const {
    return Pod::record("Assembled", {{"units", prism_rtl::to_pod(units)}, {"prelude", prism_rtl::to_pod(prelude)}, {"scripts", prism_rtl::to_pod(scripts)}, {"warnings", prism_rtl::to_pod(warnings)}, {"errors", prism_rtl::to_pod(errors)}});
}

Result<Assembled> Assembled::from_pod(const Pod& whole) {
    return Assembled{.units = TRY(prism_rtl::from_pod<Array<ModFiles>>(TRY(crate::prelude::field(whole, "units")))), .prelude = TRY(prism_rtl::from_pod<Array<ModFiles>>(TRY(crate::prelude::field(whole, "prelude")))), .scripts = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "scripts")))), .warnings = TRY(prism_rtl::from_pod<Array<TreeDiag>>(TRY(crate::prelude::field(whole, "warnings")))), .errors = TRY(prism_rtl::from_pod<Array<TreeDiag>>(TRY(crate::prelude::field(whole, "errors"))))};
}


void CheckJob::show(Printer& p) const {
    p.record("CheckJob", {{"read", read}, {"world", world}, {"typed", typed}, {"unused", unused}});
}

Pod CheckJob::to_pod() const {
    return Pod::record("CheckJob", {{"read", prism_rtl::to_pod(read)}, {"world", prism_rtl::to_pod(world)}, {"typed", prism_rtl::to_pod(typed)}, {"unused", prism_rtl::to_pod(unused)}});
}

Result<CheckJob> CheckJob::from_pod(const Pod& whole) {
    return CheckJob{.read = TRY(prism_rtl::from_pod<ReadInput>(TRY(crate::prelude::field(whole, "read")))), .world = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "world")))), .typed = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "typed")))), .unused = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "unused"))))};
}


void CheckOpts::show(Printer& p) const {
    p.record("CheckOpts", {{"world", world}, {"out", out}, {"typed", typed}, {"unused", unused}});
}

Pod CheckOpts::to_pod() const {
    return Pod::record("CheckOpts", {{"world", prism_rtl::to_pod(world)}, {"out", prism_rtl::to_pod(out)}, {"typed", prism_rtl::to_pod(typed)}, {"unused", prism_rtl::to_pod(unused)}});
}

Result<CheckOpts> CheckOpts::from_pod(const Pod& whole) {
    return CheckOpts{.world = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "world")))), .out = TRY(prism_rtl::from_pod<std::optional<Text>>(TRY(crate::prelude::field(whole, "out")))), .typed = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "typed")))), .unused = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "unused"))))};
}


void CompileJob::show(Printer& p) const {
    p.record("CompileJob", {{"read", read}, {"name", name}, {"runtime", runtime}, {"target", target}});
}

Pod CompileJob::to_pod() const {
    return Pod::record("CompileJob", {{"read", prism_rtl::to_pod(read)}, {"name", prism_rtl::to_pod(name)}, {"runtime", prism_rtl::to_pod(runtime)}, {"target", prism_rtl::to_pod(target)}});
}

Result<CompileJob> CompileJob::from_pod(const Pod& whole) {
    return CompileJob{.read = TRY(prism_rtl::from_pod<ReadInput>(TRY(crate::prelude::field(whole, "read")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .runtime = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "runtime")))), .target = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "target"))))};
}


void CompileSettings::show(Printer& p) const {
    p.record("CompileSettings", {{"out", out}, {"prelude", prelude}, {"name", name}, {"runtime", runtime}, {"target", target}});
}

Pod CompileSettings::to_pod() const {
    return Pod::record("CompileSettings", {{"out", prism_rtl::to_pod(out)}, {"prelude", prism_rtl::to_pod(prelude)}, {"name", prism_rtl::to_pod(name)}, {"runtime", prism_rtl::to_pod(runtime)}, {"target", prism_rtl::to_pod(target)}});
}

Result<CompileSettings> CompileSettings::from_pod(const Pod& whole) {
    return CompileSettings{.out = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "out")))), .prelude = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prelude")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .runtime = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "runtime")))), .target = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "target"))))};
}


void Compiled::show(Printer& p) const {
    p.record("Compiled", {{"files", files}, {"failed", failed}, {"report", report}});
}

Pod Compiled::to_pod() const {
    return Pod::record("Compiled", {{"files", prism_rtl::to_pod(files)}, {"failed", prism_rtl::to_pod(failed)}, {"report", prism_rtl::to_pod(report)}});
}

Result<Compiled> Compiled::from_pod(const Pod& whole) {
    return Compiled{.files = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "files")))), .failed = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "failed")))), .report = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "report"))))};
}


void HeadLine::show(Printer& p) const {
    p.record("HeadLine", {{"word", word}, {"arg", arg}, {"span", span}});
}

Pod HeadLine::to_pod() const {
    return Pod::record("HeadLine", {{"word", prism_rtl::to_pod(word)}, {"arg", prism_rtl::to_pod(arg)}, {"span", prism_rtl::to_pod(span)}});
}

Result<HeadLine> HeadLine::from_pod(const Pod& whole) {
    return HeadLine{.word = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "word")))), .arg = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "arg")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Job_::show(Printer& p) const {
    p.record("Job", {{"tokens", tokens}, {"fragment", fragment}, {"text", text}});
}

Pod Job_::to_pod() const {
    return Pod::record("Job", {{"tokens", prism_rtl::to_pod(tokens)}, {"fragment", prism_rtl::to_pod(fragment)}, {"text", prism_rtl::to_pod(text)}});
}

Result<Job_> Job_::from_pod(const Pod& whole) {
    return Job_{.tokens = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "tokens")))), .fragment = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "fragment")))), .text = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "text"))))};
}


void ModFiles::show(Printer& p) const {
    p.record("ModFiles", {{"name", name}, {"named", named}, {"segs", segs}});
}

Pod ModFiles::to_pod() const {
    return Pod::record("ModFiles", {{"name", prism_rtl::to_pod(name)}, {"named", prism_rtl::to_pod(named)}, {"segs", prism_rtl::to_pod(segs)}});
}

Result<ModFiles> ModFiles::from_pod(const Pod& whole) {
    return ModFiles{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .named = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "named")))), .segs = TRY(prism_rtl::from_pod<Array<Seg>>(TRY(crate::prelude::field(whole, "segs"))))};
}


void Outcome_::show(Printer& p) const {
    p.record("Outcome", {{"text", text}, {"failed", failed}, {"report", report}});
}

Pod Outcome_::to_pod() const {
    return Pod::record("Outcome", {{"text", prism_rtl::to_pod(text)}, {"failed", prism_rtl::to_pod(failed)}, {"report", prism_rtl::to_pod(report)}});
}

Result<Outcome_> Outcome_::from_pod(const Pod& whole) {
    return Outcome_{.text = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "text")))), .failed = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "failed")))), .report = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "report"))))};
}


void ParsedProgram::show(Printer& p) const {
    p.record("ParsedProgram", {{"srcs", srcs}, {"trees", trees}, {"shown", shown}, {"errors", errors}});
}

Pod ParsedProgram::to_pod() const {
    return Pod::record("ParsedProgram", {{"srcs", prism_rtl::to_pod(srcs)}, {"trees", prism_rtl::to_pod(trees)}, {"shown", prism_rtl::to_pod(shown)}, {"errors", prism_rtl::to_pod(errors)}});
}

Result<ParsedProgram> ParsedProgram::from_pod(const Pod& whole) {
    return ParsedProgram{.srcs = TRY(prism_rtl::from_pod<Array<crate::check::errors::Src>>(TRY(crate::prelude::field(whole, "srcs")))), .trees = TRY(prism_rtl::from_pod<Array<crate::syntax::Module>>(TRY(crate::prelude::field(whole, "trees")))), .shown = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "shown")))), .errors = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "errors"))))};
}


void ReadInput::show(Printer& p) const {
    p.record("ReadInput", {{"args", args}, {"prelude", prelude}, {"listings", listings}, {"paths", paths}, {"texts", texts}, {"tests", tests}, {"compiling", compiling}});
}

Pod ReadInput::to_pod() const {
    return Pod::record("ReadInput", {{"args", prism_rtl::to_pod(args)}, {"prelude", prism_rtl::to_pod(prelude)}, {"listings", prism_rtl::to_pod(listings)}, {"paths", prism_rtl::to_pod(paths)}, {"texts", prism_rtl::to_pod(texts)}, {"tests", prism_rtl::to_pod(tests)}, {"compiling", prism_rtl::to_pod(compiling)}});
}

Result<ReadInput> ReadInput::from_pod(const Pod& whole) {
    return ReadInput{.args = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "args")))), .prelude = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prelude")))), .listings = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Array<Text>>>>(TRY(crate::prelude::field(whole, "listings")))), .paths = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "paths")))), .texts = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "texts")))), .tests = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "tests")))), .compiling = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "compiling"))))};
}


void ReadMode::show(Printer& p) const {
    p.record("ReadMode", {{"compiling", compiling}, {"checking", checking}, {"compile", compile}});
}

Pod ReadMode::to_pod() const {
    return Pod::record("ReadMode", {{"compiling", prism_rtl::to_pod(compiling)}, {"checking", prism_rtl::to_pod(checking)}, {"compile", prism_rtl::to_pod(compile)}});
}

Result<ReadMode> ReadMode::from_pod(const Pod& whole) {
    return ReadMode{.compiling = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "compiling")))), .checking = TRY(prism_rtl::from_pod<CheckOpts>(TRY(crate::prelude::field(whole, "checking")))), .compile = TRY(prism_rtl::from_pod<CompileSettings>(TRY(crate::prelude::field(whole, "compile"))))};
}


void Seg::show(Printer& p) const {
    p.record("Seg", {{"path", path_}, {"text", text}, {"role", role}});
}

Pod Seg::to_pod() const {
    return Pod::record("Seg", {{"path", prism_rtl::to_pod(path_)}, {"text", prism_rtl::to_pod(text)}, {"role", prism_rtl::to_pod(role)}});
}

Result<Seg> Seg::from_pod(const Pod& whole) {
    return Seg{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .text = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "text")))), .role = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "role"))))};
}


void TreeAcc::show(Printer& p) const {
    p.record("TreeAcc", {{"units", units}, {"declared", declared}, {"diags", diags}});
}

Pod TreeAcc::to_pod() const {
    return Pod::record("TreeAcc", {{"units", prism_rtl::to_pod(units)}, {"declared", prism_rtl::to_pod(declared)}, {"diags", prism_rtl::to_pod(diags)}});
}

Result<TreeAcc> TreeAcc::from_pod(const Pod& whole) {
    return TreeAcc{.units = TRY(prism_rtl::from_pod<Array<ModFiles>>(TRY(crate::prelude::field(whole, "units")))), .declared = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "declared")))), .diags = TRY(prism_rtl::from_pod<Array<TreeDiag>>(TRY(crate::prelude::field(whole, "diags"))))};
}


void TreeDiag::show(Printer& p) const {
    p.record("TreeDiag", {{"path", path_}, {"span", span}, {"code", code}, {"message", message}, {"fix", fix}});
}

Pod TreeDiag::to_pod() const {
    return Pod::record("TreeDiag", {{"path", prism_rtl::to_pod(path_)}, {"span", prism_rtl::to_pod(span)}, {"code", prism_rtl::to_pod(code)}, {"message", prism_rtl::to_pod(message)}, {"fix", prism_rtl::to_pod(fix)}});
}

Result<TreeDiag> TreeDiag::from_pod(const Pod& whole) {
    return TreeDiag{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .code = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "code")))), .message = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "message")))), .fix = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "fix"))))};
}


/// FrontEnd: unbounded fn Job -> Outcome
Outcome_ front_end(const Job_& job) {
    return job->tokens
        ? ({
        auto lexed = crate::syntax::lexer::lex_file(job->text);
        auto report = render_diags(job->text, lexed.diags);
        Outcome_{.text = prism_rtl::cat(crate::syntax::lexer::render_tokens(lexed->tokens), report, "\n"), .failed = any_errors(lexed.diags), .report = report};
    })
        : ({
        auto parsed = job->fragment
            ? crate::syntax::parser::parse_fragment(job->text)
            : crate::syntax::parser::parse_file(job->text);
        auto report = render_diags(job->text, parsed.diags);
        Outcome_{.text = prism_rtl::cat(crate::syntax::sexp::sexp_module(parsed.tree), report, "\n"), .failed = any_errors(parsed.diags), .report = report};
    });
}


prism_rtl::Turn<Outcome_> FrontEnd::cycle() const {
    const auto& job = this->job;
    return job->tokens
        ? ({
        auto job_1 = job;
        call_then(crate::syntax::lexer::start_lex_file(job_1->text), [=](crate::syntax::lexer::Lexed lex_file_2416) {
        return ({
            auto lexed = lex_file_2416;
            auto report = render_diags(job_1->text, lexed.diags);
            (prism_rtl::finished(Outcome_{.text = prism_rtl::cat(crate::syntax::lexer::render_tokens(lexed->tokens), report, "\n"), .failed = any_errors(lexed.diags), .report = report}));
        });
    });
    })
        : ({
        auto parsed = job->fragment
            ? crate::syntax::parser::parse_fragment(job->text)
            : crate::syntax::parser::parse_file(job->text);
        auto report = render_diags(job->text, parsed.diags);
        (prism_rtl::finished(Outcome_{.text = prism_rtl::cat(crate::syntax::sexp::sexp_module(parsed.tree), report, "\n"), .failed = any_errors(parsed.diags), .report = report}));
    });
}


/// `Start FrontEnd, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Outcome_> start_front_end(Job_ job) {
    return prism_rtl::make_rc<FrontEnd>(job);
}


/// AnyErrors: fn [Diag] -> Bool
bool any_errors(const Array<crate::syntax::Diag>& ds) {
    return fold(ds, false, [&](const bool& seen, const crate::syntax::Diag& d) { return seen || (d.stage != Text::lit("out")); });
}


/// RenderDiags: fn Text, [Diag] -> Text
Text render_diags(const Text& text, const Array<crate::syntax::Diag>& ds) {
    auto starts = line_starts(text);
    return crate::syntax::lexer::join(each(ds, [&](const crate::syntax::Diag& d) { return render_diag(text, starts, d); }), Text::lit("\n"));
}


/// RenderDiag: fn Text, [Nat], Diag -> Text
Text render_diag(const Text& text, const Array<Nat>& starts, const crate::syntax::Diag& d) {
    auto line = line_of(starts, d.span.start);
    auto col = crate::syntax::lexer::column_of(text, or_(index(starts, line), Nat(0u)), d.span.start) + Nat(1u);
    auto at_ = prism_rtl::cat(line + Nat(1u), ":", col);
    auto&& _m = d.feature;
    if (prism_rtl::is_some(_m)) {
        auto&& f = prism_rtl::some_of(_m);
        return prism_rtl::cat(at_, ": out of scope (", f, "): ", d.message);
    }
    if (prism_rtl::is_none(_m)) {
        return prism_rtl::cat(at_, ": ", d.message);
    }
    prism_rtl::unreachable("no arm matched");
}


/// LineStarts: fn Text -> [Nat]
Array<Nat> line_starts(const Text& text) {
    auto&& _starts = fold(split(text, Text::lit("\n")), std::tuple{Array<Nat>{}, Nat(0u)}, [&](const std::tuple<Array<Nat>, Nat>& _p0, const Text& line) {
        auto&& acc = std::get<0>(_p0);
        auto&& at_ = std::get<1>(_p0);
        return std::tuple{crate::prelude::push(acc, at_), (at_ + len_text(line)) + Nat(1u)};
    });
    auto&& starts = std::get<0>(_starts);
    return starts;
}


/// LineOf: fn [Nat], Nat -> Nat
Nat line_of(const Array<Nat>& starts, const Nat& offset) {
    return crate::syntax::lexer::dec(fold(starts, Nat(0u), [&](const Nat& n, const Nat& s) { return s <= offset ? n + Nat(1u) : n; }));
}


/// ?OptionValue: fn [Text], Text -> ?Text
std::optional<Text> option_value(const Array<Text>& args, const Text& name) {
    return fold(crate::check::errors::range0(len(args)), std::optional<Text>{}, [&](const std::optional<Text>& found_opt, const Nat& i) {
        return index(args, i) == std::optional(name)
            ? index(args, i + Nat(1u))
            : found_opt;
    });
}


/// BadOptions: fn [Text], [Text], [Text] -> [Text]
Array<Text> bad_options(const Array<Text>& args, const Array<Text>& flags, const Array<Text>& valued) {
    auto [bad, owed] = fold(args, std::tuple{Array<Text>{}, Text::lit("")}, [&](const std::tuple<Array<Text>, Text>& _p0, const Text& a) {
        auto&& acc = std::get<0>(_p0);
        auto&& owed = std::get<1>(_p0);
        return owed != Text::lit("")
            ? std::tuple{acc, Text::lit("")}
            : crate::check::types::has_text(valued, a)
            ? std::tuple{acc, a}
            : crate::syntax::lexer::has_prefix(a, Text::lit("-")) && (!crate::check::types::has_text(flags, a))
            ? std::tuple{crate::check::types::add_text(acc, prism_rtl::cat("unknown option ", a)), Text::lit("")}
            : std::tuple{acc, Text::lit("")};
    });
    return owed == Text::lit("")
        ? bad
        : crate::check::types::add_text(bad, prism_rtl::cat(owed, " takes a value"));
}


// `@Refuse` is inlined where it is applied.

/// PlainArgs: fn [Text], [Text] -> [Text]
Array<Text> plain_args(const Array<Text>& args, const Array<Text>& valued) {
    auto&& _kept = fold(args, std::tuple{Array<Text>{}, false}, [&](const std::tuple<Array<Text>, bool>& _p0, const Text& a) {
        auto&& acc = std::get<0>(_p0);
        auto&& skip = std::get<1>(_p0);
        return skip
            ? std::tuple{acc, false}
            : crate::check::types::has_text(valued, a)
            ? std::tuple{acc, true}
            : crate::syntax::lexer::has_prefix(a, Text::lit("-"))
            ? std::tuple{acc, false}
            : std::tuple{crate::prelude::push(acc, a), false};
    });
    auto&& kept = std::get<0>(_kept);
    return each(kept, [&](const Text& a) { return no_slash(a); });
}


/// NoSlash: fn Text -> Text
Text no_slash(const Text& a) {
    return (a != Text::lit("/")) && crate::syntax::lexer::has_suffix(a, Text::lit("/"))
        ? or_(crate::syntax::lexer::before_suffix(a, Text::lit("/")), a)
        : a;
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<Main>> Main::make(Path path, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::ProcessArgs{crate::process::ProcessArgs{}}))), Fault::answer("no first value for Process.Args")));
    auto args = TRY(prism_rtl::from_pod<Array<Text>>(first_0));
    auto checking = fold(args, false, [&](const bool& seen, const Text& a) { return (seen || (a == Text::lit("--check"))) || (a == Text::lit("--typed")); });
    auto compiling = or_(index(args, Nat(0u)), Text::lit("")) == Text::lit("compile");
    prism_rtl::RcPlace<Main> _place;
    auto node = _place.take(new (_place.at()) Main(path, args, checking, compiling, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    cx.added(node->path.at(0u), prism_rtl::to_pod(crate::Elem(crate::Elem::ProcessArgs{crate::process::ProcessArgs{}})));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit Main::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done Main::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Unit value = Unit{};
    prism_rtl::Rc<Row> row = this->compiling
    ? static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done Main::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done Main::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThen>> MainArmThen::make(Path path, Unit value, prism_rtl::Weak<Main> parent, Cx& cx) {
    auto opts = drop(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, Nat(1u));
    auto bad = bad_options(opts, Array(std::vector{Text::lit("--tests")}), compile_valued());
    auto target_1 = or_(option_value(opts, Text::lit("--target")), Text::lit("rust"));
    prism_rtl::RcPlace<MainArmThen> _place;
    auto node = _place.take(new (_place.at()) MainArmThen(path, value, parent, opts, bad, target_1, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit MainArmThen::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThen::remove_places(Cx& cx) const {
    if (auto&& _m = this->arm; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(0u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThen::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(0u).child(Segment::gen(g));
    Unit value = Unit{};
    prism_rtl::Rc<Row> row = len(this->bad) > Nat(0u)
    ? static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done MainArmThen::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done MainArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmThen>> MainArmThenArmThen::make(Path path, Unit value, prism_rtl::Weak<MainArmThen> parent, Cx& cx) {
    auto why = prism_rtl::cat(crate::syntax::lexer::join(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->bad, Text::lit("; ")), " (compile takes -o OUT, --name NAME, --prelude DIR, --runtime PATH, --target rust|cpp, --tests)");
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port = prism_rtl::make_new();
    prism_rtl::RcPlace<MainArmThenArmThen> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmThen(path, value, parent, why, started_2_v_port, gave_up_v_port));
    cx.added(node->path.at(1u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmThenArmThen::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->gave_up(unexpected(Error("Prismc.Refused", this->why)), cx);
    return Unit{};
}


/// `!gave_up`.
Unit MainArmThenArmThen::gave_up(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->gave_up_v_port->fire(v, cx));
    cx.request(this->path.at(1u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_1`: an answer at its place.
Unit MainArmThenArmThen::place_1(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmThen::remove_places(Cx& cx) const {
    cx.removed(this->path.at(1u));
    return Unit{};
}


Done MainArmThenArmThen::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmThenArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u) {
        this->place_1(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElse>> MainArmThenArmElse::make(Path path, Unit value, prism_rtl::Weak<MainArmThen> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmThenArmElse> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElse(path, value, parent, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit MainArmThenArmElse::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElse::remove_places(Cx& cx) const {
    if (auto&& _m = this->arm; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(0u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThenArmElse::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(0u).child(Segment::gen(g));
    Unit value = Unit{};
    prism_rtl::Rc<Row> row = (expect(prism_rtl::upgrade(this->parent), "the block outlives its rows")->target != Text::lit("rust")) && (expect(prism_rtl::upgrade(this->parent), "the block outlives its rows")->target != Text::lit("cpp"))
    ? static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done MainArmThenArmElse::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done MainArmThenArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmThen>> MainArmThenArmElseArmThen::make(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElse> parent, Cx& cx) {
    auto why = prism_rtl::cat("unknown target ", expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->target, " (rust, cpp)");
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port = prism_rtl::make_new();
    prism_rtl::RcPlace<MainArmThenArmElseArmThen> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmThen(path, value, parent, why, started_2_v_port, gave_up_v_port));
    cx.added(node->path.at(1u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmThenArmElseArmThen::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->gave_up(unexpected(Error("Prismc.Refused", this->why)), cx);
    return Unit{};
}


/// `!gave_up`.
Unit MainArmThenArmElseArmThen::gave_up(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->gave_up_v_port->fire(v, cx));
    cx.request(this->path.at(1u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_1`: an answer at its place.
Unit MainArmThenArmElseArmThen::place_1(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmThen::remove_places(Cx& cx) const {
    cx.removed(this->path.at(1u));
    return Unit{};
}


Done MainArmThenArmElseArmThen::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmThenArmElseArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u) {
        this->place_1(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElse>> MainArmThenArmElseArmElse::make(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElse> parent, Cx& cx) {
    auto out_1 = or_(option_value(expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->opts, Text::lit("-o")), Text::lit("prismc-out"));
    auto prelude_2 = no_slash(or_(option_value(expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->opts, Text::lit("--prelude")), Text::lit("prelude")));
    auto settings = CompileSettings{.out = out_1, .prelude = prelude_2, .name = or_(option_value(expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->opts, Text::lit("--name")), Text::lit("program")), .runtime = or_(option_value(expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->opts, Text::lit("--runtime")), runtime_for(out_1)), .target = expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->target};
    auto mode = ReadMode{.compiling = true, .checking = no_check_opts(), .compile = settings};
    auto args = plain_args(expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->opts, compile_valued());
    auto prelude_2_3 = prelude_2;
    auto tests_4 = crate::check::types::has_text(expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->opts, Text::lit("--tests"));
    auto dirs = crate::prelude::push(filter(args, [&](const Text& a) { return !is_source_path(a); }), prelude_2_3);
    prism_rtl::RcPlace<MainArmThenArmElseArmElse> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElse(path, value, parent, out_1, prelude_2, settings, mode, args, prelude_2_3, tests_4, dirs, {}, {}, snapshot("the dynamic gathered by the `for` at place 0"), std::nullopt, 0u, false));
    TRY(node->rows_build(cx));
    node->rows_all_snap.take(node->rows_all_now(cx), cx);
    TRY(node->generation_build(cx));
    return node;
}


/// `!generation_fired`.
Unit MainArmThenArmElseArmElse::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
Map<Nat, Text> MainArmThenArmElseArmElse::rows_source(const Cx& cx) const {
    return this->rows_source_cache.get(cx, [&]() { return indexed(this->dirs); });
}


/// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
Map<Nat, Array<Text>> MainArmThenArmElseArmElse::rows_all_now(const Cx& cx) const {
    return prism_rtl::fmap(this->rows, [&](const auto& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& row = std::get<1>(_p0);
        return std::tuple{k, row->result(cx)};
    });
}


/// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
Map<Nat, Array<Text>> MainArmThenArmElseArmElse::rows_all(const Cx& cx) const {
    return this->rows_all_snap.get(cx);
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmThenArmElseArmElse::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElse::remove_places(Cx& cx) const {
    prism_rtl::for_each(crate::prelude::values(this->rows), [&](auto&& row) { return row->leave_row(cx); });
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
Unit MainArmThenArmElseArmElse::rows_all_moved(Cx& cx) {
    this->rows_all_snap.mark(cx);
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
Unit MainArmThenArmElseArmElse::rows_all_publish(Cx& cx) {
    if (this->rows_all_snap.published(cx)) {
        this->generation_stale = true;
        cx.build_later(prism_rtl::share(this));
    }
    return Unit{};
}


/// The rows of the `for` at `this->path.at(0u)`: rows whose key left are torn down, new keys are
/// built under it at `[k]` from the values after the tick; kept rows keep reading their
/// entry out of the source.
Done MainArmThenArmElseArmElse::rows_build(Cx& cx) {
    Map<Nat, Text> items = rows_source(cx);
    auto old = deref(this->rows);
    for (auto&& [k, row] : old) {
        if (!items.contains(k)) {
            row->leave_row(cx);
            cx.leave_later(row);
        }
    }
    decltype(old) next;
    for (auto&& [k, v] : items) {
        if (auto row = old.get(k)) next.insert(k, *row);
        else next.insert(k, TRY(MainArmThenArmElseArmElseRow::make(this->path.at(0u).child(Segment::key(prism_rtl::to_pod(k))), k, v, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    }
    deref(this->rows) = next;
    // What the block reads of its rows (a `for` that gives a dynamic) moved.
    cx.dirty(prism_rtl::share(this));
    return {};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThenArmElseArmElse::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Map<Nat, Array<Text>> value = this->rows_all(cx);
    prism_rtl::Rc<Row> row = TRY(MainArmThenArmElseArmElseGen1::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx));
    this->generation = row;
    return {};
}


Done MainArmThenArmElseArmElse::build(Cx& cx) {
    TRY(this->rows_build(cx));
    if (this->rows_all_snap.marked(cx)) {
        this->rows_all_snap.take_compared(this->rows_all_now(cx), cx);
        if (this->rows_all_snap.queue(cx)) {
            auto node = prism_rtl::share(this);
            cx.answer_later([=](Cx& cx) -> Done { node->rows_all_publish(cx); return {}; });
        }
    }
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmThenArmElseArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Key>(at[1])) {
        auto&& k = prism_rtl::as<pat::Key>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = cloned(this->rows.get(TRY(prism_rtl::from_pod<Nat>(k))));
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(rest, v, cx));
            }
            Unit{};
        });
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1>> MainArmThenArmElseArmElseGen1::make(Path path, Map<Nat, Array<Text>> value, prism_rtl::Weak<MainArmThenArmElseArmElse> parent, Cx& cx) {
    auto mode = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->mode;
    auto args = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args;
    auto prelude = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->prelude_2;
    auto tests = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->tests;
    auto listings = pairs(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->dirs, value);
    auto ups = fold(listings, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& d = std::get<0>(_p1);
        auto&& files = std::get<1>(_p1);
        return is_module_dir(d, files)
            ? crate::check::types::union_texts(acc, ancestors(d))
            : acc;
    });
    prism_rtl::RcPlace<MainArmThenArmElseArmElseGen1> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseGen1(path, value, parent, mode, args, prelude, tests, listings, ups, {}, {}, snapshot("the dynamic gathered by the `for` at place 0"), std::nullopt, 0u, false));
    TRY(node->rows_build(cx));
    node->rows_all_snap.take(node->rows_all_now(cx), cx);
    TRY(node->generation_build(cx));
    return node;
}


/// `!generation_fired`.
Unit MainArmThenArmElseArmElseGen1::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
Map<Nat, Text> MainArmThenArmElseArmElseGen1::rows_source(const Cx& cx) const {
    return this->rows_source_cache.get(cx, [&]() { return indexed(this->ups); });
}


/// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
Map<Nat, Array<Text>> MainArmThenArmElseArmElseGen1::rows_all_now(const Cx& cx) const {
    return prism_rtl::fmap(this->rows, [&](const auto& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& row = std::get<1>(_p0);
        return std::tuple{k, row->result(cx)};
    });
}


/// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
Map<Nat, Array<Text>> MainArmThenArmElseArmElseGen1::rows_all(const Cx& cx) const {
    return this->rows_all_snap.get(cx);
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmThenArmElseArmElseGen1::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1::remove_places(Cx& cx) const {
    prism_rtl::for_each(crate::prelude::values(this->rows), [&](auto&& row) { return row->leave_row(cx); });
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
Unit MainArmThenArmElseArmElseGen1::rows_all_moved(Cx& cx) {
    this->rows_all_snap.mark(cx);
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
Unit MainArmThenArmElseArmElseGen1::rows_all_publish(Cx& cx) {
    if (this->rows_all_snap.published(cx)) {
        this->generation_stale = true;
        cx.build_later(prism_rtl::share(this));
    }
    return Unit{};
}


/// The rows of the `for` at `this->path.at(0u)`: rows whose key left are torn down, new keys are
/// built under it at `[k]` from the values after the tick; kept rows keep reading their
/// entry out of the source.
Done MainArmThenArmElseArmElseGen1::rows_build(Cx& cx) {
    Map<Nat, Text> items = rows_source(cx);
    auto old = deref(this->rows);
    for (auto&& [k, row] : old) {
        if (!items.contains(k)) {
            row->leave_row(cx);
            cx.leave_later(row);
        }
    }
    decltype(old) next;
    for (auto&& [k, v] : items) {
        if (auto row = old.get(k)) next.insert(k, *row);
        else next.insert(k, TRY(MainArmThenArmElseArmElseGen1Row::make(this->path.at(0u).child(Segment::key(prism_rtl::to_pod(k))), k, v, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    }
    deref(this->rows) = next;
    // What the block reads of its rows (a `for` that gives a dynamic) moved.
    cx.dirty(prism_rtl::share(this));
    return {};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThenArmElseArmElseGen1::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Map<Nat, Array<Text>> value = this->rows_all(cx);
    prism_rtl::Rc<Row> row = TRY(MainArmThenArmElseArmElseGen1Gen1::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx));
    this->generation = row;
    return {};
}


Done MainArmThenArmElseArmElseGen1::build(Cx& cx) {
    TRY(this->rows_build(cx));
    if (this->rows_all_snap.marked(cx)) {
        this->rows_all_snap.take_compared(this->rows_all_now(cx), cx);
        if (this->rows_all_snap.queue(cx)) {
            auto node = prism_rtl::share(this);
            cx.answer_later([=](Cx& cx) -> Done { node->rows_all_publish(cx); return {}; });
        }
    }
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Key>(at[1])) {
        auto&& k = prism_rtl::as<pat::Key>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = cloned(this->rows.get(TRY(prism_rtl::from_pod<Nat>(k))));
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(rest, v, cx));
            }
            Unit{};
        });
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseGen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1>> MainArmThenArmElseArmElseGen1Gen1::make(Path path, Map<Nat, Array<Text>> value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1> parent, Cx& cx) {
    auto mode = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->mode;
    auto args = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args;
    auto prelude = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->prelude;
    auto tests = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->tests;
    auto listings = append(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->listings, pairs(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->ups, value));
    auto paths = to_read(crate::prelude::push(args, prelude), map(listings));
    prism_rtl::RcPlace<MainArmThenArmElseArmElseGen1Gen1> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseGen1Gen1(path, value, parent, mode, args, prelude, tests, listings, paths, {}, {}, snapshot("the dynamic gathered by the `for` at place 0"), std::nullopt, 0u, false));
    TRY(node->rows_build(cx));
    node->rows_all_snap.take(node->rows_all_now(cx), cx);
    TRY(node->generation_build(cx));
    return node;
}


/// `!generation_fired`.
Unit MainArmThenArmElseArmElseGen1Gen1::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
Map<Nat, Text> MainArmThenArmElseArmElseGen1Gen1::rows_source(const Cx& cx) const {
    return this->rows_source_cache.get(cx, [&]() { return indexed(this->paths); });
}


/// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
Map<Nat, Fallible<crate::fs::Contents>> MainArmThenArmElseArmElseGen1Gen1::rows_all_now(const Cx& cx) const {
    return prism_rtl::fmap(this->rows, [&](const auto& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& row = std::get<1>(_p0);
        return std::tuple{k, row->result(cx)};
    });
}


/// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
Map<Nat, Fallible<crate::fs::Contents>> MainArmThenArmElseArmElseGen1Gen1::rows_all(const Cx& cx) const {
    return this->rows_all_snap.get(cx);
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmThenArmElseArmElseGen1Gen1::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1Gen1::remove_places(Cx& cx) const {
    prism_rtl::for_each(crate::prelude::values(this->rows), [&](auto&& row) { return row->leave_row(cx); });
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
Unit MainArmThenArmElseArmElseGen1Gen1::rows_all_moved(Cx& cx) {
    this->rows_all_snap.mark(cx);
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
Unit MainArmThenArmElseArmElseGen1Gen1::rows_all_publish(Cx& cx) {
    if (this->rows_all_snap.published(cx)) {
        this->generation_stale = true;
        cx.build_later(prism_rtl::share(this));
    }
    return Unit{};
}


/// The rows of the `for` at `this->path.at(0u)`: rows whose key left are torn down, new keys are
/// built under it at `[k]` from the values after the tick; kept rows keep reading their
/// entry out of the source.
Done MainArmThenArmElseArmElseGen1Gen1::rows_build(Cx& cx) {
    Map<Nat, Text> items = rows_source(cx);
    auto old = deref(this->rows);
    for (auto&& [k, row] : old) {
        if (!items.contains(k)) {
            row->leave_row(cx);
            cx.leave_later(row);
        }
    }
    decltype(old) next;
    for (auto&& [k, v] : items) {
        if (auto row = old.get(k)) next.insert(k, *row);
        else next.insert(k, TRY(MainArmThenArmElseArmElseGen1Gen1Row::make(this->path.at(0u).child(Segment::key(prism_rtl::to_pod(k))), k, v, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    }
    deref(this->rows) = next;
    // What the block reads of its rows (a `for` that gives a dynamic) moved.
    cx.dirty(prism_rtl::share(this));
    return {};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThenArmElseArmElseGen1Gen1::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Map<Nat, Fallible<crate::fs::Contents>> value = this->rows_all(cx);
    prism_rtl::Rc<Row> row = TRY(MainArmThenArmElseArmElseGen1Gen1Gen1::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx));
    this->generation = row;
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1::build(Cx& cx) {
    TRY(this->rows_build(cx));
    if (this->rows_all_snap.marked(cx)) {
        this->rows_all_snap.take_compared(this->rows_all_now(cx), cx);
        if (this->rows_all_snap.queue(cx)) {
            auto node = prism_rtl::share(this);
            cx.answer_later([=](Cx& cx) -> Done { node->rows_all_publish(cx); return {}; });
        }
    }
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Key>(at[1])) {
        auto&& k = prism_rtl::as<pat::Key>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = cloned(this->rows.get(TRY(prism_rtl::from_pod<Nat>(k))));
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(rest, v, cx));
            }
            Unit{};
        });
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseGen1Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1>> MainArmThenArmElseArmElseGen1Gen1Gen1::make(Path path, Map<Nat, Fallible<crate::fs::Contents>> value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1> parent, Cx& cx) {
    auto mode = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->mode;
    auto input = ReadInput{.args = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, .prelude = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->prelude, .listings = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->listings, .paths = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->paths, .texts = Array<std::tuple<Text, Text>>{}, .tests = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->tests, .compiling = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->mode->compiling};
    auto contents = value;
    auto failed = fold(crate::check::errors::range0(len(input->paths)), Array<Text>{}, [&](const Array<Text>& acc, const Nat& i) {
        return ({
            auto why = read_failure(crate::prelude::get(contents, i));
            why == Text::lit("")
            ? acc
            : crate::prelude::push(acc, prism_rtl::cat("cannot read ", or_(index(input->paths, i), Text::lit("")), ": ", why));
        });
    });
    auto texts = each(crate::check::errors::range0(len(input->paths)), [&](const Nat& i) { return std::tuple{or_(index(input->paths, i), Text::lit("")), contents_text(or_(crate::prelude::get(contents, i), crate::fs::Contents{.text = Text::lit("")}))}; });
    auto full = ({
        ReadInput this_ = input;
        this_.texts = texts;
        this_;
    });
    prism_rtl::RcPlace<MainArmThenArmElseArmElseGen1Gen1Gen1> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseGen1Gen1Gen1(path, value, parent, mode, input, contents, failed, texts, full, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1::remove_places(Cx& cx) const {
    if (auto&& _m = this->arm; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(0u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThenArmElseArmElseGen1Gen1Gen1::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(0u).child(Segment::gen(g));
    Unit value = Unit{};
    prism_rtl::Rc<Row> row = len(this->failed) > Nat(0u)
    ? static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseGen1Gen1Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen>> MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen::make(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1> parent, Cx& cx) {
    auto why = crate::syntax::lexer::join(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->failed, Text::lit("; "));
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port = prism_rtl::make_new();
    prism_rtl::RcPlace<MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen(path, value, parent, why, started_2_v_port, gave_up_v_port));
    cx.added(node->path.at(1u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->gave_up(unexpected(Error("Prismc.Refused", this->why)), cx);
    return Unit{};
}


/// `!gave_up`.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen::gave_up(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->gave_up_v_port->fire(v, cx));
    cx.request(this->path.at(1u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_1`: an answer at its place.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen::place_1(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen::remove_places(Cx& cx) const {
    cx.removed(this->path.at(1u));
    return Unit{};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u) {
        this->place_1(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse>> MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse::make(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse(path, value, parent, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse::remove_places(Cx& cx) const {
    if (auto&& _m = this->arm; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(0u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(0u).child(Segment::gen(g));
    Unit value = Unit{};
    prism_rtl::Rc<Row> row = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows")->mode->compiling
    ? static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen>> MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen::make(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse> parent, Cx& cx) {
    auto s = expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->mode.compile;
    auto input = expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->full;
    prism_rtl::Rc<Port<Compiled>> done_v_port = prism_rtl::make_new();
    std::optional<Compiled> outcome_init = std::optional<Compiled>{};
    prism_rtl::RcPlace<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen(path, value, parent, s, input, done_v_port, {start_compile_program(CompileJob{.read = input, .name = s.name, .runtime = s.runtime, .target = s->target}), cx}, {}, {}, {}, {outcome_init, cx}, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    cx.on_started(node);
    return node;
}


/// `!done`.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen::done(Compiled v, Cx& cx) {
    prism_rtl::ignore(this->done_v_port->fire(v, cx));
    this->outcome.set(std::optional(v), cx);
    this->generation_stale = true;
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// `@started`, the tick after the build.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen::run_started(Unit v, Cx& cx) {
    this->run_turn_left.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// An `@Defer` firing, the tick after it was armed.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen::run_again_(Unit v, Cx& cx) {
    this->run_turn_right.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// The merge `run_turn`, decided in the wake.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen::run_turn(Unit v, Cx& cx) {
    {
        auto&& _m = this->run_job.get(cx)->cycle();
        if (_m.if_more()) {
            auto&& next = _m.if_more()->next;
            this->run_job.set(next, cx);
            this->run_again.arm(Unit{}, prism_rtl::share(this), cx);
        } else if (_m.if_finished()) {
            auto&& b = _m.if_finished()->value;
            this->done(b, cx);
        }
    }
    return Unit{};
}


/// `!generation_fired`.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen::remove_places(Cx& cx) const {
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    std::optional<Compiled> value = this->outcome.get(cx);
    prism_rtl::Rc<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<prism_rtl::Rc<Row>> _v;
    auto&& _m = std::tuple{this->s.out, value};
    if (prism_rtl::is_none(std::get<1>(_m))) {
        auto&& out = std::get<0>(_m);
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0::make(path, out, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is_some(std::get<1>(_m))) {
        auto&& out = std::get<0>(_m);
        auto&& o = prism_rtl::some_of(std::get<1>(_m));
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1::make(path, out, o, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen::wake(Cx& cx) {
    {
        auto left = this->run_turn_left.take(cx);
        auto right = this->run_turn_right.take(cx);
        if (auto&& _m = left; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        } else if (auto&& _m = right; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        }
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen::started(Cx& cx) {
    this->run_started(Unit{}, cx);
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen::deferred(Cx& cx) {
    if (auto&& _m = this->run_again.fired(cx); prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        this->run_again_(v, cx);
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0>> MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0::make(Path path, Text out, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0(path, out, parent));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0::remove_places(Cx& cx) const {

    return Unit{};
}


void MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1>> MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1::make(Path path, Text out, Compiled o, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen> parent, Cx& cx) {
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port = prism_rtl::make_new();
    prism_rtl::RcPlace<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1(path, out, o, parent, started_2_v_port, verdict_v_port, {}, {}, snapshot("the dynamic gathered by the `for` at place 0")));
    TRY(node->rows_build(cx));
    node->rows_all_snap.take(node->rows_all_now(cx), cx);
    cx.added(node->path.at(2u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->verdict(this->o.failed
        ? unexpected(Error("Prismc.Refused", this->o.report))
        : Expected<std::decay_t<decltype(Unit{})>, std::decay_t<decltype(Error("Prismc.Refused", this->o.report))>>(Unit{}), cx);
    return Unit{};
}


/// `!verdict`.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1::verdict(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->verdict_v_port->fire(v, cx));
    cx.request(this->path.at(2u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_2`: an answer at its place.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1::place_2(Unit v, Cx& cx) {

    return Unit{};
}


/// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
Map<Nat, std::tuple<Text, Text>> MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1::rows_source(const Cx& cx) const {
    return this->rows_source_cache.get(cx, [&]() { return indexed(this->o.files); });
}


/// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
Map<Nat, crate::fs::WriteState> MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1::rows_all_now(const Cx& cx) const {
    return prism_rtl::fmap(this->rows, [&](const auto& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& row = std::get<1>(_p0);
        return std::tuple{k, row->result(cx)};
    });
}


/// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
Map<Nat, crate::fs::WriteState> MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1::rows_all(const Cx& cx) const {
    return this->rows_all_snap.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1::remove_places(Cx& cx) const {
    cx.removed(this->path.at(2u));
    prism_rtl::for_each(crate::prelude::values(this->rows), [&](auto&& row) { return row->leave_row(cx); });
    return Unit{};
}


/// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1::rows_all_moved(Cx& cx) {
    this->rows_all_snap.mark(cx);
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1::rows_all_publish(Cx& cx) {
    if (this->rows_all_snap.published(cx)) {
    }
    return Unit{};
}


/// The rows of the `for` at `this->path.at(0u)`: rows whose key left are torn down, new keys are
/// built under it at `[k]` from the values after the tick; kept rows keep reading their
/// entry out of the source.
Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1::rows_build(Cx& cx) {
    Map<Nat, std::tuple<Text, Text>> items = rows_source(cx);
    auto old = deref(this->rows);
    for (auto&& [k, row] : old) {
        if (!items.contains(k)) {
            row->leave_row(cx);
            cx.leave_later(row);
        }
    }
    decltype(old) next;
    for (auto&& [k, v] : items) {
        if (auto row = old.get(k)) next.insert(k, *row);
        else next.insert(k, TRY(MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::make(this->path.at(0u).child(Segment::key(prism_rtl::to_pod(k))), k, v, prism_rtl::weaken(prism_rtl::share(this)), this->out, cx)));
    }
    deref(this->rows) = next;
    // What the block reads of its rows (a `for` that gives a dynamic) moved.
    cx.dirty(prism_rtl::share(this));
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1::build(Cx& cx) {
    TRY(this->rows_build(cx));
    if (this->rows_all_snap.marked(cx)) {
        this->rows_all_snap.take_compared(this->rows_all_now(cx), cx);
        if (this->rows_all_snap.queue(cx)) {
            auto node = prism_rtl::share(this);
            cx.answer_later([=](Cx& cx) -> Done { node->rows_all_publish(cx); return {}; });
        }
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 2u) {
        this->place_2(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Key>(at[1])) {
        auto&& k = prism_rtl::as<pat::Key>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = cloned(this->rows.get(TRY(prism_rtl::from_pod<Nat>(k))));
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(rest, v, cx));
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row>> MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::make(Path path, Nat key, std::tuple<Text, Text> value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1> parent, Text out, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = prism_rtl::cat(out, "/", std::get<0>(value)), .text = std::get<1>(value)}}))), Fault::answer("no first value for Fs.Output")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = prism_rtl::cat(out, "/", std::get<0>(value)), .text = std::get<1>(value)}}));
    prism_rtl::RcPlace<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row(path, key, std::nullopt, parent, out, {TRY(prism_rtl::from_pod<crate::fs::WriteState>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(node->output(cx)));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// Place 0's level, read at the read point.
crate::Elem MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::output(const Cx& cx) const {
    return crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = prism_rtl::cat(this->out, "/", std::get<0>(this->entry(cx))), .text = std::get<1>(this->entry(cx))}});
}


/// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
std::tuple<Text, Text> MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::entry(const Cx& cx) const {
    if (auto&& _m = this->left_entry; prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    auto parent = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows");
    auto&& _m = cloned(parent->rows_source(cx).get(this->key));
    if (prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    if (prism_rtl::is_none(_m)) {
        return expect(cx.before([&](auto&& cx) { return cloned(parent->rows_source(cx).get(this->key)); }), "a row's key is in its source as its tick opened");
    }
    prism_rtl::unreachable("no arm matched");
}


/// The row's result, which the block gathers by key.
crate::fs::WriteState MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::result(const Cx& cx) const {
    return this->place_0.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<crate::fs::WriteState>(v)), cx);
        if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
            auto&& parent = prism_rtl::some_of(_m);
            parent->rows_all_moved(cx);
        }
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::patch(Cx& cx) {
    auto output = this->output(cx);
    cx.changed(this->path.at(0u), prism_rtl::to_pod(output));
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<crate::fs::WriteState>(v)), cx);
            if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
                auto&& parent = prism_rtl::some_of(_m);
                parent->rows_all_moved(cx);
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::leave_row(Cx& cx) {
    this->left_entry = entry(cx);
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse>> MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse::make(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse> parent, Cx& cx) {
    auto o = expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->mode->checking;
    auto input = expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->full;
    prism_rtl::Rc<Port<Outcome_>> done_v_port = prism_rtl::make_new();
    std::optional<Outcome_> outcome_init = std::optional<Outcome_>{};
    prism_rtl::RcPlace<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse(path, value, parent, o, input, done_v_port, {start_check_files(CheckJob{.read = input, .world = o->world, .typed = o.typed, .unused = o.unused}), cx}, {}, {}, {}, {outcome_init, cx}, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    cx.on_started(node);
    return node;
}


/// `!done`.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse::done(Outcome_ v, Cx& cx) {
    prism_rtl::ignore(this->done_v_port->fire(v, cx));
    this->outcome.set(std::optional(v), cx);
    this->generation_stale = true;
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// `@started`, the tick after the build.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse::run_started(Unit v, Cx& cx) {
    this->run_turn_left.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// An `@Defer` firing, the tick after it was armed.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse::run_again_(Unit v, Cx& cx) {
    this->run_turn_right.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// The merge `run_turn`, decided in the wake.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse::run_turn(Unit v, Cx& cx) {
    {
        auto&& _m = this->run_job.get(cx)->cycle();
        if (_m.if_more()) {
            auto&& next = _m.if_more()->next;
            this->run_job.set(next, cx);
            this->run_again.arm(Unit{}, prism_rtl::share(this), cx);
        } else if (_m.if_finished()) {
            auto&& b = _m.if_finished()->value;
            this->done(b, cx);
        }
    }
    return Unit{};
}


/// `!generation_fired`.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse::remove_places(Cx& cx) const {
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    std::optional<Outcome_> value = this->outcome.get(cx);
    prism_rtl::Rc<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<prism_rtl::Rc<Row>> _v;
    auto&& _m = std::tuple{this->o.out, value};
    if (prism_rtl::is_none(std::get<1>(_m))) {
        auto&& out_opt = std::get<0>(_m);
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0::make(path, out_opt, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is_some(std::get<1>(_m))) {
        auto&& out_opt = std::get<0>(_m);
        auto&& o = prism_rtl::some_of(std::get<1>(_m));
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1::make(path, out_opt, o, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse::wake(Cx& cx) {
    {
        auto left = this->run_turn_left.take(cx);
        auto right = this->run_turn_right.take(cx);
        if (auto&& _m = left; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        } else if (auto&& _m = right; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        }
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse::started(Cx& cx) {
    this->run_started(Unit{}, cx);
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse::deferred(Cx& cx) {
    if (auto&& _m = this->run_again.fired(cx); prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        this->run_again_(v, cx);
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0>> MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0::make(Path path, std::optional<Text> out, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0(path, out, parent));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0::remove_places(Cx& cx) const {

    return Unit{};
}


void MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1>> MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1::make(Path path, std::optional<Text> out, Outcome_ o, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse> parent, Cx& cx) {
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port = prism_rtl::make_new();
    prism_rtl::RcPlace<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1(path, out, o, parent, started_2_v_port, verdict_v_port, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    cx.added(node->path.at(2u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->verdict(this->o.failed
        ? unexpected(Error("Prismc.Refused", this->o.report))
        : Expected<std::decay_t<decltype(Unit{})>, std::decay_t<decltype(Error("Prismc.Refused", this->o.report))>>(Unit{}), cx);
    return Unit{};
}


/// `!verdict`.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1::verdict(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->verdict_v_port->fire(v, cx));
    cx.request(this->path.at(2u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `!generation_fired`.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1::generation_fired(prism_rtl::Blueprint<crate::Elem, crate::Answer> v, Cx& cx) {

    return Unit{};
}


/// `place_2`: an answer at its place.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1::place_2(Unit v, Cx& cx) {

    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1::generation_up(prism_rtl::Blueprint<crate::Elem, crate::Answer> v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1::remove_places(Cx& cx) const {
    cx.removed(this->path.at(2u));
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path` from the source after the tick.
Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path;
    std::optional<Text> value = this->out;
    prism_rtl::Rc<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<prism_rtl::Rc<Row>> _v;
    auto&& _m = std::tuple{this->out, this->o.text};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0::make(path, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& path_ = prism_rtl::some_of(std::get<0>(_m));
        auto&& text = std::get<1>(_m);
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1::make(path, path_, text, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 2u) {
        this->place_2(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else if (at.size() >= 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(at, v, cx));
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0>> MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0::make(Path path, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0(path, parent));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0::remove_places(Cx& cx) const {

    return Unit{};
}


void MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1>> MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1::make(Path path, Text path_, Text text, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1> parent, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = path_, .text = text}}))), Fault::answer("no first value for Fs.Output")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = path_, .text = text}}));
    prism_rtl::RcPlace<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1(path, path_, text, parent, {TRY(prism_rtl::from_pod<crate::fs::WriteState>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = path_, .text = text}})));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<crate::fs::WriteState>(v)), cx);
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<crate::fs::WriteState>(v)), cx);
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Row>> MainArmThenArmElseArmElseGen1Gen1Row::make(Path path, Nat key, Text value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1> parent, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsContents{crate::fs::FsContents{.path_ = value}}))), Fault::answer("no first value for Fs.Contents")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsContents{crate::fs::FsContents{.path_ = value}}));
    prism_rtl::RcPlace<MainArmThenArmElseArmElseGen1Gen1Row> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseGen1Gen1Row(path, key, std::nullopt, parent, {TRY(prism_rtl::from_pod<Fallible<crate::fs::Contents>>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(node->contents_(cx)));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// Place 0's level, read at the read point.
crate::Elem MainArmThenArmElseArmElseGen1Gen1Row::contents_(const Cx& cx) const {
    return crate::Elem(crate::Elem::FsContents{crate::fs::FsContents{.path_ = this->entry(cx)}});
}


/// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
Text MainArmThenArmElseArmElseGen1Gen1Row::entry(const Cx& cx) const {
    if (auto&& _m = this->left_entry; prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    auto parent = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows");
    auto&& _m = cloned(parent->rows_source(cx).get(this->key));
    if (prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    if (prism_rtl::is_none(_m)) {
        return expect(cx.before([&](auto&& cx) { return cloned(parent->rows_source(cx).get(this->key)); }), "a row's key is in its source as its tick opened");
    }
    prism_rtl::unreachable("no arm matched");
}


/// The row's result, which the block gathers by key.
Fallible<crate::fs::Contents> MainArmThenArmElseArmElseGen1Gen1Row::result(const Cx& cx) const {
    return this->place_0.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1Gen1Row::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmThenArmElseArmElseGen1Gen1Row::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<Fallible<crate::fs::Contents>>(v)), cx);
        if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
            auto&& parent = prism_rtl::some_of(_m);
            parent->rows_all_moved(cx);
        }
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Row::patch(Cx& cx) {
    auto contents = this->contents_(cx);
    cx.changed(this->path.at(0u), prism_rtl::to_pod(contents));
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Row::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<Fallible<crate::fs::Contents>>(v)), cx);
            if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
                auto&& parent = prism_rtl::some_of(_m);
                parent->rows_all_moved(cx);
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseGen1Gen1Row::leave_row(Cx& cx) {
    this->left_entry = entry(cx);
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Row>> MainArmThenArmElseArmElseGen1Row::make(Path path, Nat key, Text value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1> parent, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = value}}))), Fault::answer("no first value for Fs.List")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = value}}));
    prism_rtl::RcPlace<MainArmThenArmElseArmElseGen1Row> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseGen1Row(path, key, std::nullopt, parent, {TRY(prism_rtl::from_pod<Array<Text>>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(node->list(cx)));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// Place 0's level, read at the read point.
crate::Elem MainArmThenArmElseArmElseGen1Row::list(const Cx& cx) const {
    return crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = this->entry(cx)}});
}


/// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
Text MainArmThenArmElseArmElseGen1Row::entry(const Cx& cx) const {
    if (auto&& _m = this->left_entry; prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    auto parent = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows");
    auto&& _m = cloned(parent->rows_source(cx).get(this->key));
    if (prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    if (prism_rtl::is_none(_m)) {
        return expect(cx.before([&](auto&& cx) { return cloned(parent->rows_source(cx).get(this->key)); }), "a row's key is in its source as its tick opened");
    }
    prism_rtl::unreachable("no arm matched");
}


/// The row's result, which the block gathers by key.
Array<Text> MainArmThenArmElseArmElseGen1Row::result(const Cx& cx) const {
    return this->place_0.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1Row::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmThenArmElseArmElseGen1Row::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<Array<Text>>(v)), cx);
        if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
            auto&& parent = prism_rtl::some_of(_m);
            parent->rows_all_moved(cx);
        }
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1Row::patch(Cx& cx) {
    auto list = this->list(cx);
    cx.changed(this->path.at(0u), prism_rtl::to_pod(list));
    return {};
}


Done MainArmThenArmElseArmElseGen1Row::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<Array<Text>>(v)), cx);
            if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
                auto&& parent = prism_rtl::some_of(_m);
                parent->rows_all_moved(cx);
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseGen1Row::leave_row(Cx& cx) {
    this->left_entry = entry(cx);
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseRow>> MainArmThenArmElseArmElseRow::make(Path path, Nat key, Text value, prism_rtl::Weak<MainArmThenArmElseArmElse> parent, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = value}}))), Fault::answer("no first value for Fs.List")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = value}}));
    prism_rtl::RcPlace<MainArmThenArmElseArmElseRow> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseRow(path, key, std::nullopt, parent, {TRY(prism_rtl::from_pod<Array<Text>>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(node->list(cx)));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// Place 0's level, read at the read point.
crate::Elem MainArmThenArmElseArmElseRow::list(const Cx& cx) const {
    return crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = this->entry(cx)}});
}


/// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
Text MainArmThenArmElseArmElseRow::entry(const Cx& cx) const {
    if (auto&& _m = this->left_entry; prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    auto parent = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows");
    auto&& _m = cloned(parent->rows_source(cx).get(this->key));
    if (prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    if (prism_rtl::is_none(_m)) {
        return expect(cx.before([&](auto&& cx) { return cloned(parent->rows_source(cx).get(this->key)); }), "a row's key is in its source as its tick opened");
    }
    prism_rtl::unreachable("no arm matched");
}


/// The row's result, which the block gathers by key.
Array<Text> MainArmThenArmElseArmElseRow::result(const Cx& cx) const {
    return this->place_0.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseRow::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmThenArmElseArmElseRow::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<Array<Text>>(v)), cx);
        if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
            auto&& parent = prism_rtl::some_of(_m);
            parent->rows_all_moved(cx);
        }
    }
    return {};
}


Done MainArmThenArmElseArmElseRow::patch(Cx& cx) {
    auto list = this->list(cx);
    cx.changed(this->path.at(0u), prism_rtl::to_pod(list));
    return {};
}


Done MainArmThenArmElseArmElseRow::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<Array<Text>>(v)), cx);
            if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
                auto&& parent = prism_rtl::some_of(_m);
                parent->rows_all_moved(cx);
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseRow::leave_row(Cx& cx) {
    this->left_entry = entry(cx);
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElse>> MainArmElse::make(Path path, Unit value, prism_rtl::Weak<Main> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmElse> _place;
    auto node = _place.take(new (_place.at()) MainArmElse(path, value, parent, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit MainArmElse::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElse::remove_places(Cx& cx) const {
    if (auto&& _m = this->arm; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(0u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElse::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(0u).child(Segment::gen(g));
    Unit value = Unit{};
    prism_rtl::Rc<Row> row = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows")->checking
    ? static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done MainArmElse::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done MainArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThen>> MainArmElseArmThen::make(Path path, Unit value, prism_rtl::Weak<MainArmElse> parent, Cx& cx) {
    auto args = expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->args;
    auto bad = bad_options(args, Array(std::vector{Text::lit("--check"), Text::lit("--typed"), Text::lit("--unused"), Text::lit("--tests")}), check_valued());
    prism_rtl::RcPlace<MainArmElseArmThen> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThen(path, value, parent, args, bad, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit MainArmElseArmThen::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThen::remove_places(Cx& cx) const {
    if (auto&& _m = this->arm; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(0u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmThen::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(0u).child(Segment::gen(g));
    Unit value = Unit{};
    prism_rtl::Rc<Row> row = len(this->bad) > Nat(0u)
    ? static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done MainArmElseArmThen::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done MainArmElseArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmThen>> MainArmElseArmThenArmThen::make(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThen> parent, Cx& cx) {
    auto why = prism_rtl::cat(crate::syntax::lexer::join(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->bad, Text::lit("; ")), " (--check takes --typed, --unused, --tests, --prelude DIR, --out FILE, --world W,...)");
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port = prism_rtl::make_new();
    prism_rtl::RcPlace<MainArmElseArmThenArmThen> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmThen(path, value, parent, why, started_2_v_port, gave_up_v_port));
    cx.added(node->path.at(1u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmElseArmThenArmThen::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->gave_up(unexpected(Error("Prismc.Refused", this->why)), cx);
    return Unit{};
}


/// `!gave_up`.
Unit MainArmElseArmThenArmThen::gave_up(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->gave_up_v_port->fire(v, cx));
    cx.request(this->path.at(1u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_1`: an answer at its place.
Unit MainArmElseArmThenArmThen::place_1(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmThen::remove_places(Cx& cx) const {
    cx.removed(this->path.at(1u));
    return Unit{};
}


Done MainArmElseArmThenArmThen::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmElseArmThenArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u) {
        this->place_1(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElse>> MainArmElseArmThenArmElse::make(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThen> parent, Cx& cx) {
    auto world_1 = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = option_value(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, Text::lit("--world"));
        if (prism_rtl::is_some(_m)) {
            auto&& w = prism_rtl::some_of(_m);
            _v.set(split(w, Text::lit(",")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto opts = CheckOpts{.world = world_1, .out = option_value(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, Text::lit("--out")), .typed = crate::check::types::has_text(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, Text::lit("--typed")), .unused = crate::check::types::has_text(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, Text::lit("--unused"))};
    auto mode = ReadMode{.compiling = false, .checking = opts, .compile = no_compile_settings()};
    auto args = plain_args(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, check_valued());
    auto prelude_2 = no_slash(or_(option_value(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, Text::lit("--prelude")), Text::lit("prelude")));
    auto tests_3 = crate::check::types::has_text(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, Text::lit("--tests"));
    auto dirs = crate::prelude::push(filter(args, [&](const Text& a) { return !is_source_path(a); }), prelude_2);
    prism_rtl::RcPlace<MainArmElseArmThenArmElse> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElse(path, value, parent, world_1, opts, mode, args, prelude_2, tests_3, dirs, {}, {}, snapshot("the dynamic gathered by the `for` at place 0"), std::nullopt, 0u, false));
    TRY(node->rows_build(cx));
    node->rows_all_snap.take(node->rows_all_now(cx), cx);
    TRY(node->generation_build(cx));
    return node;
}


/// `!generation_fired`.
Unit MainArmElseArmThenArmElse::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
Map<Nat, Text> MainArmElseArmThenArmElse::rows_source(const Cx& cx) const {
    return this->rows_source_cache.get(cx, [&]() { return indexed(this->dirs); });
}


/// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
Map<Nat, Array<Text>> MainArmElseArmThenArmElse::rows_all_now(const Cx& cx) const {
    return prism_rtl::fmap(this->rows, [&](const auto& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& row = std::get<1>(_p0);
        return std::tuple{k, row->result(cx)};
    });
}


/// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
Map<Nat, Array<Text>> MainArmElseArmThenArmElse::rows_all(const Cx& cx) const {
    return this->rows_all_snap.get(cx);
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmThenArmElse::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElse::remove_places(Cx& cx) const {
    prism_rtl::for_each(crate::prelude::values(this->rows), [&](auto&& row) { return row->leave_row(cx); });
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
Unit MainArmElseArmThenArmElse::rows_all_moved(Cx& cx) {
    this->rows_all_snap.mark(cx);
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
Unit MainArmElseArmThenArmElse::rows_all_publish(Cx& cx) {
    if (this->rows_all_snap.published(cx)) {
        this->generation_stale = true;
        cx.build_later(prism_rtl::share(this));
    }
    return Unit{};
}


/// The rows of the `for` at `this->path.at(0u)`: rows whose key left are torn down, new keys are
/// built under it at `[k]` from the values after the tick; kept rows keep reading their
/// entry out of the source.
Done MainArmElseArmThenArmElse::rows_build(Cx& cx) {
    Map<Nat, Text> items = rows_source(cx);
    auto old = deref(this->rows);
    for (auto&& [k, row] : old) {
        if (!items.contains(k)) {
            row->leave_row(cx);
            cx.leave_later(row);
        }
    }
    decltype(old) next;
    for (auto&& [k, v] : items) {
        if (auto row = old.get(k)) next.insert(k, *row);
        else next.insert(k, TRY(MainArmElseArmThenArmElseRow::make(this->path.at(0u).child(Segment::key(prism_rtl::to_pod(k))), k, v, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    }
    deref(this->rows) = next;
    // What the block reads of its rows (a `for` that gives a dynamic) moved.
    cx.dirty(prism_rtl::share(this));
    return {};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmThenArmElse::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Map<Nat, Array<Text>> value = this->rows_all(cx);
    prism_rtl::Rc<Row> row = TRY(MainArmElseArmThenArmElseGen1::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx));
    this->generation = row;
    return {};
}


Done MainArmElseArmThenArmElse::build(Cx& cx) {
    TRY(this->rows_build(cx));
    if (this->rows_all_snap.marked(cx)) {
        this->rows_all_snap.take_compared(this->rows_all_now(cx), cx);
        if (this->rows_all_snap.queue(cx)) {
            auto node = prism_rtl::share(this);
            cx.answer_later([=](Cx& cx) -> Done { node->rows_all_publish(cx); return {}; });
        }
    }
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmThenArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Key>(at[1])) {
        auto&& k = prism_rtl::as<pat::Key>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = cloned(this->rows.get(TRY(prism_rtl::from_pod<Nat>(k))));
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(rest, v, cx));
            }
            Unit{};
        });
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1>> MainArmElseArmThenArmElseGen1::make(Path path, Map<Nat, Array<Text>> value, prism_rtl::Weak<MainArmElseArmThenArmElse> parent, Cx& cx) {
    auto mode = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->mode;
    auto args = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args;
    auto prelude = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->prelude;
    auto tests = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->tests;
    auto listings = pairs(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->dirs, value);
    auto ups = fold(listings, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& d = std::get<0>(_p1);
        auto&& files = std::get<1>(_p1);
        return is_module_dir(d, files)
            ? crate::check::types::union_texts(acc, ancestors(d))
            : acc;
    });
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1(path, value, parent, mode, args, prelude, tests, listings, ups, {}, {}, snapshot("the dynamic gathered by the `for` at place 0"), std::nullopt, 0u, false));
    TRY(node->rows_build(cx));
    node->rows_all_snap.take(node->rows_all_now(cx), cx);
    TRY(node->generation_build(cx));
    return node;
}


/// `!generation_fired`.
Unit MainArmElseArmThenArmElseGen1::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
Map<Nat, Text> MainArmElseArmThenArmElseGen1::rows_source(const Cx& cx) const {
    return this->rows_source_cache.get(cx, [&]() { return indexed(this->ups); });
}


/// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
Map<Nat, Array<Text>> MainArmElseArmThenArmElseGen1::rows_all_now(const Cx& cx) const {
    return prism_rtl::fmap(this->rows, [&](const auto& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& row = std::get<1>(_p0);
        return std::tuple{k, row->result(cx)};
    });
}


/// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
Map<Nat, Array<Text>> MainArmElseArmThenArmElseGen1::rows_all(const Cx& cx) const {
    return this->rows_all_snap.get(cx);
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmThenArmElseGen1::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1::remove_places(Cx& cx) const {
    prism_rtl::for_each(crate::prelude::values(this->rows), [&](auto&& row) { return row->leave_row(cx); });
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
Unit MainArmElseArmThenArmElseGen1::rows_all_moved(Cx& cx) {
    this->rows_all_snap.mark(cx);
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
Unit MainArmElseArmThenArmElseGen1::rows_all_publish(Cx& cx) {
    if (this->rows_all_snap.published(cx)) {
        this->generation_stale = true;
        cx.build_later(prism_rtl::share(this));
    }
    return Unit{};
}


/// The rows of the `for` at `this->path.at(0u)`: rows whose key left are torn down, new keys are
/// built under it at `[k]` from the values after the tick; kept rows keep reading their
/// entry out of the source.
Done MainArmElseArmThenArmElseGen1::rows_build(Cx& cx) {
    Map<Nat, Text> items = rows_source(cx);
    auto old = deref(this->rows);
    for (auto&& [k, row] : old) {
        if (!items.contains(k)) {
            row->leave_row(cx);
            cx.leave_later(row);
        }
    }
    decltype(old) next;
    for (auto&& [k, v] : items) {
        if (auto row = old.get(k)) next.insert(k, *row);
        else next.insert(k, TRY(MainArmElseArmThenArmElseGen1Row::make(this->path.at(0u).child(Segment::key(prism_rtl::to_pod(k))), k, v, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    }
    deref(this->rows) = next;
    // What the block reads of its rows (a `for` that gives a dynamic) moved.
    cx.dirty(prism_rtl::share(this));
    return {};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmThenArmElseGen1::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Map<Nat, Array<Text>> value = this->rows_all(cx);
    prism_rtl::Rc<Row> row = TRY(MainArmElseArmThenArmElseGen1Gen1::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx));
    this->generation = row;
    return {};
}


Done MainArmElseArmThenArmElseGen1::build(Cx& cx) {
    TRY(this->rows_build(cx));
    if (this->rows_all_snap.marked(cx)) {
        this->rows_all_snap.take_compared(this->rows_all_now(cx), cx);
        if (this->rows_all_snap.queue(cx)) {
            auto node = prism_rtl::share(this);
            cx.answer_later([=](Cx& cx) -> Done { node->rows_all_publish(cx); return {}; });
        }
    }
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Key>(at[1])) {
        auto&& k = prism_rtl::as<pat::Key>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = cloned(this->rows.get(TRY(prism_rtl::from_pod<Nat>(k))));
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(rest, v, cx));
            }
            Unit{};
        });
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1>> MainArmElseArmThenArmElseGen1Gen1::make(Path path, Map<Nat, Array<Text>> value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1> parent, Cx& cx) {
    auto mode = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->mode;
    auto args = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args;
    auto prelude = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->prelude;
    auto tests = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->tests;
    auto listings = append(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->listings, pairs(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->ups, value));
    auto paths = to_read(crate::prelude::push(args, prelude), map(listings));
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1(path, value, parent, mode, args, prelude, tests, listings, paths, {}, {}, snapshot("the dynamic gathered by the `for` at place 0"), std::nullopt, 0u, false));
    TRY(node->rows_build(cx));
    node->rows_all_snap.take(node->rows_all_now(cx), cx);
    TRY(node->generation_build(cx));
    return node;
}


/// `!generation_fired`.
Unit MainArmElseArmThenArmElseGen1Gen1::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
Map<Nat, Text> MainArmElseArmThenArmElseGen1Gen1::rows_source(const Cx& cx) const {
    return this->rows_source_cache.get(cx, [&]() { return indexed(this->paths); });
}


/// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
Map<Nat, Fallible<crate::fs::Contents>> MainArmElseArmThenArmElseGen1Gen1::rows_all_now(const Cx& cx) const {
    return prism_rtl::fmap(this->rows, [&](const auto& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& row = std::get<1>(_p0);
        return std::tuple{k, row->result(cx)};
    });
}


/// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
Map<Nat, Fallible<crate::fs::Contents>> MainArmElseArmThenArmElseGen1Gen1::rows_all(const Cx& cx) const {
    return this->rows_all_snap.get(cx);
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmThenArmElseGen1Gen1::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1::remove_places(Cx& cx) const {
    prism_rtl::for_each(crate::prelude::values(this->rows), [&](auto&& row) { return row->leave_row(cx); });
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
Unit MainArmElseArmThenArmElseGen1Gen1::rows_all_moved(Cx& cx) {
    this->rows_all_snap.mark(cx);
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
Unit MainArmElseArmThenArmElseGen1Gen1::rows_all_publish(Cx& cx) {
    if (this->rows_all_snap.published(cx)) {
        this->generation_stale = true;
        cx.build_later(prism_rtl::share(this));
    }
    return Unit{};
}


/// The rows of the `for` at `this->path.at(0u)`: rows whose key left are torn down, new keys are
/// built under it at `[k]` from the values after the tick; kept rows keep reading their
/// entry out of the source.
Done MainArmElseArmThenArmElseGen1Gen1::rows_build(Cx& cx) {
    Map<Nat, Text> items = rows_source(cx);
    auto old = deref(this->rows);
    for (auto&& [k, row] : old) {
        if (!items.contains(k)) {
            row->leave_row(cx);
            cx.leave_later(row);
        }
    }
    decltype(old) next;
    for (auto&& [k, v] : items) {
        if (auto row = old.get(k)) next.insert(k, *row);
        else next.insert(k, TRY(MainArmElseArmThenArmElseGen1Gen1Row::make(this->path.at(0u).child(Segment::key(prism_rtl::to_pod(k))), k, v, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    }
    deref(this->rows) = next;
    // What the block reads of its rows (a `for` that gives a dynamic) moved.
    cx.dirty(prism_rtl::share(this));
    return {};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmThenArmElseGen1Gen1::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Map<Nat, Fallible<crate::fs::Contents>> value = this->rows_all(cx);
    prism_rtl::Rc<Row> row = TRY(MainArmElseArmThenArmElseGen1Gen1Gen1::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx));
    this->generation = row;
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1::build(Cx& cx) {
    TRY(this->rows_build(cx));
    if (this->rows_all_snap.marked(cx)) {
        this->rows_all_snap.take_compared(this->rows_all_now(cx), cx);
        if (this->rows_all_snap.queue(cx)) {
            auto node = prism_rtl::share(this);
            cx.answer_later([=](Cx& cx) -> Done { node->rows_all_publish(cx); return {}; });
        }
    }
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Key>(at[1])) {
        auto&& k = prism_rtl::as<pat::Key>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = cloned(this->rows.get(TRY(prism_rtl::from_pod<Nat>(k))));
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(rest, v, cx));
            }
            Unit{};
        });
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1>> MainArmElseArmThenArmElseGen1Gen1Gen1::make(Path path, Map<Nat, Fallible<crate::fs::Contents>> value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1> parent, Cx& cx) {
    auto mode = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->mode;
    auto input = ReadInput{.args = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, .prelude = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->prelude, .listings = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->listings, .paths = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->paths, .texts = Array<std::tuple<Text, Text>>{}, .tests = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->tests, .compiling = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->mode->compiling};
    auto contents = value;
    auto failed = fold(crate::check::errors::range0(len(input->paths)), Array<Text>{}, [&](const Array<Text>& acc, const Nat& i) {
        return ({
            auto why = read_failure(crate::prelude::get(contents, i));
            why == Text::lit("")
            ? acc
            : crate::prelude::push(acc, prism_rtl::cat("cannot read ", or_(index(input->paths, i), Text::lit("")), ": ", why));
        });
    });
    auto texts = each(crate::check::errors::range0(len(input->paths)), [&](const Nat& i) { return std::tuple{or_(index(input->paths, i), Text::lit("")), contents_text(or_(crate::prelude::get(contents, i), crate::fs::Contents{.text = Text::lit("")}))}; });
    auto full = ({
        ReadInput this_ = input;
        this_.texts = texts;
        this_;
    });
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1(path, value, parent, mode, input, contents, failed, texts, full, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1::remove_places(Cx& cx) const {
    if (auto&& _m = this->arm; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(0u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmThenArmElseGen1Gen1Gen1::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(0u).child(Segment::gen(g));
    Unit value = Unit{};
    prism_rtl::Rc<Row> row = len(this->failed) > Nat(0u)
    ? static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen::make(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1> parent, Cx& cx) {
    auto why = crate::syntax::lexer::join(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->failed, Text::lit("; "));
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port = prism_rtl::make_new();
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen(path, value, parent, why, started_2_v_port, gave_up_v_port));
    cx.added(node->path.at(1u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->gave_up(unexpected(Error("Prismc.Refused", this->why)), cx);
    return Unit{};
}


/// `!gave_up`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen::gave_up(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->gave_up_v_port->fire(v, cx));
    cx.request(this->path.at(1u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_1`: an answer at its place.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen::place_1(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen::remove_places(Cx& cx) const {
    cx.removed(this->path.at(1u));
    return Unit{};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u) {
        this->place_1(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse::make(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse(path, value, parent, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse::remove_places(Cx& cx) const {
    if (auto&& _m = this->arm; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(0u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(0u).child(Segment::gen(g));
    Unit value = Unit{};
    prism_rtl::Rc<Row> row = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows")->mode->compiling
    ? static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen::make(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse> parent, Cx& cx) {
    auto s = expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->mode.compile;
    auto input = expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->full;
    prism_rtl::Rc<Port<Compiled>> done_v_port = prism_rtl::make_new();
    std::optional<Compiled> outcome_init = std::optional<Compiled>{};
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen(path, value, parent, s, input, done_v_port, {start_compile_program(CompileJob{.read = input, .name = s.name, .runtime = s.runtime, .target = s->target}), cx}, {}, {}, {}, {outcome_init, cx}, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    cx.on_started(node);
    return node;
}


/// `!done`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen::done(Compiled v, Cx& cx) {
    prism_rtl::ignore(this->done_v_port->fire(v, cx));
    this->outcome.set(std::optional(v), cx);
    this->generation_stale = true;
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// `@started`, the tick after the build.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen::run_started(Unit v, Cx& cx) {
    this->run_turn_left.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// An `@Defer` firing, the tick after it was armed.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen::run_again_(Unit v, Cx& cx) {
    this->run_turn_right.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// The merge `run_turn`, decided in the wake.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen::run_turn(Unit v, Cx& cx) {
    {
        auto&& _m = this->run_job.get(cx)->cycle();
        if (_m.if_more()) {
            auto&& next = _m.if_more()->next;
            this->run_job.set(next, cx);
            this->run_again.arm(Unit{}, prism_rtl::share(this), cx);
        } else if (_m.if_finished()) {
            auto&& b = _m.if_finished()->value;
            this->done(b, cx);
        }
    }
    return Unit{};
}


/// `!generation_fired`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen::remove_places(Cx& cx) const {
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    std::optional<Compiled> value = this->outcome.get(cx);
    prism_rtl::Rc<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<prism_rtl::Rc<Row>> _v;
    auto&& _m = std::tuple{this->s.out, value};
    if (prism_rtl::is_none(std::get<1>(_m))) {
        auto&& out = std::get<0>(_m);
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0::make(path, out, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is_some(std::get<1>(_m))) {
        auto&& out = std::get<0>(_m);
        auto&& o = prism_rtl::some_of(std::get<1>(_m));
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1::make(path, out, o, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen::wake(Cx& cx) {
    {
        auto left = this->run_turn_left.take(cx);
        auto right = this->run_turn_right.take(cx);
        if (auto&& _m = left; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        } else if (auto&& _m = right; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        }
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen::started(Cx& cx) {
    this->run_started(Unit{}, cx);
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen::deferred(Cx& cx) {
    if (auto&& _m = this->run_again.fired(cx); prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        this->run_again_(v, cx);
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0::make(Path path, Text out, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0(path, out, parent));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0::remove_places(Cx& cx) const {

    return Unit{};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1::make(Path path, Text out, Compiled o, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen> parent, Cx& cx) {
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port = prism_rtl::make_new();
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1(path, out, o, parent, started_2_v_port, verdict_v_port, {}, {}, snapshot("the dynamic gathered by the `for` at place 0")));
    TRY(node->rows_build(cx));
    node->rows_all_snap.take(node->rows_all_now(cx), cx);
    cx.added(node->path.at(2u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->verdict(this->o.failed
        ? unexpected(Error("Prismc.Refused", this->o.report))
        : Expected<std::decay_t<decltype(Unit{})>, std::decay_t<decltype(Error("Prismc.Refused", this->o.report))>>(Unit{}), cx);
    return Unit{};
}


/// `!verdict`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1::verdict(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->verdict_v_port->fire(v, cx));
    cx.request(this->path.at(2u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_2`: an answer at its place.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1::place_2(Unit v, Cx& cx) {

    return Unit{};
}


/// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
Map<Nat, std::tuple<Text, Text>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1::rows_source(const Cx& cx) const {
    return this->rows_source_cache.get(cx, [&]() { return indexed(this->o.files); });
}


/// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
Map<Nat, crate::fs::WriteState> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1::rows_all_now(const Cx& cx) const {
    return prism_rtl::fmap(this->rows, [&](const auto& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& row = std::get<1>(_p0);
        return std::tuple{k, row->result(cx)};
    });
}


/// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
Map<Nat, crate::fs::WriteState> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1::rows_all(const Cx& cx) const {
    return this->rows_all_snap.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1::remove_places(Cx& cx) const {
    cx.removed(this->path.at(2u));
    prism_rtl::for_each(crate::prelude::values(this->rows), [&](auto&& row) { return row->leave_row(cx); });
    return Unit{};
}


/// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1::rows_all_moved(Cx& cx) {
    this->rows_all_snap.mark(cx);
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1::rows_all_publish(Cx& cx) {
    if (this->rows_all_snap.published(cx)) {
    }
    return Unit{};
}


/// The rows of the `for` at `this->path.at(0u)`: rows whose key left are torn down, new keys are
/// built under it at `[k]` from the values after the tick; kept rows keep reading their
/// entry out of the source.
Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1::rows_build(Cx& cx) {
    Map<Nat, std::tuple<Text, Text>> items = rows_source(cx);
    auto old = deref(this->rows);
    for (auto&& [k, row] : old) {
        if (!items.contains(k)) {
            row->leave_row(cx);
            cx.leave_later(row);
        }
    }
    decltype(old) next;
    for (auto&& [k, v] : items) {
        if (auto row = old.get(k)) next.insert(k, *row);
        else next.insert(k, TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::make(this->path.at(0u).child(Segment::key(prism_rtl::to_pod(k))), k, v, prism_rtl::weaken(prism_rtl::share(this)), this->out, cx)));
    }
    deref(this->rows) = next;
    // What the block reads of its rows (a `for` that gives a dynamic) moved.
    cx.dirty(prism_rtl::share(this));
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1::build(Cx& cx) {
    TRY(this->rows_build(cx));
    if (this->rows_all_snap.marked(cx)) {
        this->rows_all_snap.take_compared(this->rows_all_now(cx), cx);
        if (this->rows_all_snap.queue(cx)) {
            auto node = prism_rtl::share(this);
            cx.answer_later([=](Cx& cx) -> Done { node->rows_all_publish(cx); return {}; });
        }
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 2u) {
        this->place_2(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Key>(at[1])) {
        auto&& k = prism_rtl::as<pat::Key>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = cloned(this->rows.get(TRY(prism_rtl::from_pod<Nat>(k))));
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(rest, v, cx));
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::make(Path path, Nat key, std::tuple<Text, Text> value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1> parent, Text out, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = prism_rtl::cat(out, "/", std::get<0>(value)), .text = std::get<1>(value)}}))), Fault::answer("no first value for Fs.Output")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = prism_rtl::cat(out, "/", std::get<0>(value)), .text = std::get<1>(value)}}));
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row(path, key, std::nullopt, parent, out, {TRY(prism_rtl::from_pod<crate::fs::WriteState>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(node->output(cx)));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// Place 0's level, read at the read point.
crate::Elem MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::output(const Cx& cx) const {
    return crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = prism_rtl::cat(this->out, "/", std::get<0>(this->entry(cx))), .text = std::get<1>(this->entry(cx))}});
}


/// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
std::tuple<Text, Text> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::entry(const Cx& cx) const {
    if (auto&& _m = this->left_entry; prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    auto parent = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows");
    auto&& _m = cloned(parent->rows_source(cx).get(this->key));
    if (prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    if (prism_rtl::is_none(_m)) {
        return expect(cx.before([&](auto&& cx) { return cloned(parent->rows_source(cx).get(this->key)); }), "a row's key is in its source as its tick opened");
    }
    prism_rtl::unreachable("no arm matched");
}


/// The row's result, which the block gathers by key.
crate::fs::WriteState MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::result(const Cx& cx) const {
    return this->place_0.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<crate::fs::WriteState>(v)), cx);
        if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
            auto&& parent = prism_rtl::some_of(_m);
            parent->rows_all_moved(cx);
        }
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::patch(Cx& cx) {
    auto output = this->output(cx);
    cx.changed(this->path.at(0u), prism_rtl::to_pod(output));
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<crate::fs::WriteState>(v)), cx);
            if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
                auto&& parent = prism_rtl::some_of(_m);
                parent->rows_all_moved(cx);
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::leave_row(Cx& cx) {
    this->left_entry = entry(cx);
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse::make(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse> parent, Cx& cx) {
    auto o = expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->mode->checking;
    auto input = expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->full;
    prism_rtl::Rc<Port<Outcome_>> done_v_port = prism_rtl::make_new();
    std::optional<Outcome_> outcome_init = std::optional<Outcome_>{};
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse(path, value, parent, o, input, done_v_port, {start_check_files(CheckJob{.read = input, .world = o->world, .typed = o.typed, .unused = o.unused}), cx}, {}, {}, {}, {outcome_init, cx}, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    cx.on_started(node);
    return node;
}


/// `!done`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse::done(Outcome_ v, Cx& cx) {
    prism_rtl::ignore(this->done_v_port->fire(v, cx));
    this->outcome.set(std::optional(v), cx);
    this->generation_stale = true;
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// `@started`, the tick after the build.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse::run_started(Unit v, Cx& cx) {
    this->run_turn_left.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// An `@Defer` firing, the tick after it was armed.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse::run_again_(Unit v, Cx& cx) {
    this->run_turn_right.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// The merge `run_turn`, decided in the wake.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse::run_turn(Unit v, Cx& cx) {
    {
        auto&& _m = this->run_job.get(cx)->cycle();
        if (_m.if_more()) {
            auto&& next = _m.if_more()->next;
            this->run_job.set(next, cx);
            this->run_again.arm(Unit{}, prism_rtl::share(this), cx);
        } else if (_m.if_finished()) {
            auto&& b = _m.if_finished()->value;
            this->done(b, cx);
        }
    }
    return Unit{};
}


/// `!generation_fired`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse::remove_places(Cx& cx) const {
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    std::optional<Outcome_> value = this->outcome.get(cx);
    prism_rtl::Rc<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<prism_rtl::Rc<Row>> _v;
    auto&& _m = std::tuple{this->o.out, value};
    if (prism_rtl::is_none(std::get<1>(_m))) {
        auto&& out_opt = std::get<0>(_m);
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0::make(path, out_opt, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is_some(std::get<1>(_m))) {
        auto&& out_opt = std::get<0>(_m);
        auto&& o = prism_rtl::some_of(std::get<1>(_m));
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1::make(path, out_opt, o, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse::wake(Cx& cx) {
    {
        auto left = this->run_turn_left.take(cx);
        auto right = this->run_turn_right.take(cx);
        if (auto&& _m = left; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        } else if (auto&& _m = right; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        }
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse::started(Cx& cx) {
    this->run_started(Unit{}, cx);
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse::deferred(Cx& cx) {
    if (auto&& _m = this->run_again.fired(cx); prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        this->run_again_(v, cx);
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0::make(Path path, std::optional<Text> out, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0(path, out, parent));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0::remove_places(Cx& cx) const {

    return Unit{};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1::make(Path path, std::optional<Text> out, Outcome_ o, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse> parent, Cx& cx) {
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port = prism_rtl::make_new();
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1(path, out, o, parent, started_2_v_port, verdict_v_port, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    cx.added(node->path.at(2u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->verdict(this->o.failed
        ? unexpected(Error("Prismc.Refused", this->o.report))
        : Expected<std::decay_t<decltype(Unit{})>, std::decay_t<decltype(Error("Prismc.Refused", this->o.report))>>(Unit{}), cx);
    return Unit{};
}


/// `!verdict`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1::verdict(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->verdict_v_port->fire(v, cx));
    cx.request(this->path.at(2u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `!generation_fired`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1::generation_fired(prism_rtl::Blueprint<crate::Elem, crate::Answer> v, Cx& cx) {

    return Unit{};
}


/// `place_2`: an answer at its place.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1::place_2(Unit v, Cx& cx) {

    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1::generation_up(prism_rtl::Blueprint<crate::Elem, crate::Answer> v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1::remove_places(Cx& cx) const {
    cx.removed(this->path.at(2u));
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path` from the source after the tick.
Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path;
    std::optional<Text> value = this->out;
    prism_rtl::Rc<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<prism_rtl::Rc<Row>> _v;
    auto&& _m = std::tuple{this->out, this->o.text};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0::make(path, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& path_ = prism_rtl::some_of(std::get<0>(_m));
        auto&& text = std::get<1>(_m);
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1::make(path, path_, text, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 2u) {
        this->place_2(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else if (at.size() >= 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(at, v, cx));
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0::make(Path path, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0(path, parent));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0::remove_places(Cx& cx) const {

    return Unit{};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1::make(Path path, Text path_, Text text, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1> parent, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = path_, .text = text}}))), Fault::answer("no first value for Fs.Output")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = path_, .text = text}}));
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1(path, path_, text, parent, {TRY(prism_rtl::from_pod<crate::fs::WriteState>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = path_, .text = text}})));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<crate::fs::WriteState>(v)), cx);
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<crate::fs::WriteState>(v)), cx);
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Row>> MainArmElseArmThenArmElseGen1Gen1Row::make(Path path, Nat key, Text value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1> parent, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsContents{crate::fs::FsContents{.path_ = value}}))), Fault::answer("no first value for Fs.Contents")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsContents{crate::fs::FsContents{.path_ = value}}));
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Row> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Row(path, key, std::nullopt, parent, {TRY(prism_rtl::from_pod<Fallible<crate::fs::Contents>>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(node->contents_(cx)));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// Place 0's level, read at the read point.
crate::Elem MainArmElseArmThenArmElseGen1Gen1Row::contents_(const Cx& cx) const {
    return crate::Elem(crate::Elem::FsContents{crate::fs::FsContents{.path_ = this->entry(cx)}});
}


/// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
Text MainArmElseArmThenArmElseGen1Gen1Row::entry(const Cx& cx) const {
    if (auto&& _m = this->left_entry; prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    auto parent = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows");
    auto&& _m = cloned(parent->rows_source(cx).get(this->key));
    if (prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    if (prism_rtl::is_none(_m)) {
        return expect(cx.before([&](auto&& cx) { return cloned(parent->rows_source(cx).get(this->key)); }), "a row's key is in its source as its tick opened");
    }
    prism_rtl::unreachable("no arm matched");
}


/// The row's result, which the block gathers by key.
Fallible<crate::fs::Contents> MainArmElseArmThenArmElseGen1Gen1Row::result(const Cx& cx) const {
    return this->place_0.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Row::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmElseArmThenArmElseGen1Gen1Row::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<Fallible<crate::fs::Contents>>(v)), cx);
        if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
            auto&& parent = prism_rtl::some_of(_m);
            parent->rows_all_moved(cx);
        }
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Row::patch(Cx& cx) {
    auto contents = this->contents_(cx);
    cx.changed(this->path.at(0u), prism_rtl::to_pod(contents));
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Row::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<Fallible<crate::fs::Contents>>(v)), cx);
            if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
                auto&& parent = prism_rtl::some_of(_m);
                parent->rows_all_moved(cx);
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1Row::leave_row(Cx& cx) {
    this->left_entry = entry(cx);
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Row>> MainArmElseArmThenArmElseGen1Row::make(Path path, Nat key, Text value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1> parent, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = value}}))), Fault::answer("no first value for Fs.List")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = value}}));
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Row> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Row(path, key, std::nullopt, parent, {TRY(prism_rtl::from_pod<Array<Text>>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(node->list(cx)));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// Place 0's level, read at the read point.
crate::Elem MainArmElseArmThenArmElseGen1Row::list(const Cx& cx) const {
    return crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = this->entry(cx)}});
}


/// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
Text MainArmElseArmThenArmElseGen1Row::entry(const Cx& cx) const {
    if (auto&& _m = this->left_entry; prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    auto parent = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows");
    auto&& _m = cloned(parent->rows_source(cx).get(this->key));
    if (prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    if (prism_rtl::is_none(_m)) {
        return expect(cx.before([&](auto&& cx) { return cloned(parent->rows_source(cx).get(this->key)); }), "a row's key is in its source as its tick opened");
    }
    prism_rtl::unreachable("no arm matched");
}


/// The row's result, which the block gathers by key.
Array<Text> MainArmElseArmThenArmElseGen1Row::result(const Cx& cx) const {
    return this->place_0.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Row::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmElseArmThenArmElseGen1Row::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<Array<Text>>(v)), cx);
        if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
            auto&& parent = prism_rtl::some_of(_m);
            parent->rows_all_moved(cx);
        }
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Row::patch(Cx& cx) {
    auto list = this->list(cx);
    cx.changed(this->path.at(0u), prism_rtl::to_pod(list));
    return {};
}


Done MainArmElseArmThenArmElseGen1Row::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<Array<Text>>(v)), cx);
            if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
                auto&& parent = prism_rtl::some_of(_m);
                parent->rows_all_moved(cx);
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Row::leave_row(Cx& cx) {
    this->left_entry = entry(cx);
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseRow>> MainArmElseArmThenArmElseRow::make(Path path, Nat key, Text value, prism_rtl::Weak<MainArmElseArmThenArmElse> parent, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = value}}))), Fault::answer("no first value for Fs.List")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = value}}));
    prism_rtl::RcPlace<MainArmElseArmThenArmElseRow> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseRow(path, key, std::nullopt, parent, {TRY(prism_rtl::from_pod<Array<Text>>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(node->list(cx)));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// Place 0's level, read at the read point.
crate::Elem MainArmElseArmThenArmElseRow::list(const Cx& cx) const {
    return crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = this->entry(cx)}});
}


/// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
Text MainArmElseArmThenArmElseRow::entry(const Cx& cx) const {
    if (auto&& _m = this->left_entry; prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    auto parent = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows");
    auto&& _m = cloned(parent->rows_source(cx).get(this->key));
    if (prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    if (prism_rtl::is_none(_m)) {
        return expect(cx.before([&](auto&& cx) { return cloned(parent->rows_source(cx).get(this->key)); }), "a row's key is in its source as its tick opened");
    }
    prism_rtl::unreachable("no arm matched");
}


/// The row's result, which the block gathers by key.
Array<Text> MainArmElseArmThenArmElseRow::result(const Cx& cx) const {
    return this->place_0.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseRow::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmElseArmThenArmElseRow::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<Array<Text>>(v)), cx);
        if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
            auto&& parent = prism_rtl::some_of(_m);
            parent->rows_all_moved(cx);
        }
    }
    return {};
}


Done MainArmElseArmThenArmElseRow::patch(Cx& cx) {
    auto list = this->list(cx);
    cx.changed(this->path.at(0u), prism_rtl::to_pod(list));
    return {};
}


Done MainArmElseArmThenArmElseRow::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<Array<Text>>(v)), cx);
            if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
                auto&& parent = prism_rtl::some_of(_m);
                parent->rows_all_moved(cx);
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseRow::leave_row(Cx& cx) {
    this->left_entry = entry(cx);
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmElse>> MainArmElseArmElse::make(Path path, Unit value, prism_rtl::Weak<MainArmElse> parent, Cx& cx) {
    auto args = expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->args;
    auto tokens_1 = fold(args, false, [&](const bool& seen, const Text& a) { return seen || (a == Text::lit("--tokens")); });
    auto fragment_2 = fold(args, false, [&](const bool& seen, const Text& a) { return seen || (a == Text::lit("--fragment")); });
    auto names = fold(args, Array<Text>{}, [&](const Array<Text>& acc, const Text& a) {
        return crate::syntax::lexer::has_prefix(a, Text::lit("--"))
            ? acc
            : crate::prelude::push(acc, a);
    });
    auto file = or_(index(names, Nat(0u)), Text::lit(""));
    auto out = or_(index(names, Nat(1u)), prism_rtl::cat(file, ".sexp"));
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsContents{crate::fs::FsContents{.path_ = file}}))), Fault::answer("no first value for Fs.Contents")));
    auto source_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsContents{crate::fs::FsContents{.path_ = file}}));
    prism_rtl::RcPlace<MainArmElseArmElse> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmElse(path, value, parent, args, tokens_1, fragment_2, names, file, out, {TRY(prism_rtl::from_pod<Fallible<crate::fs::Contents>>(first_0)), cx}, source_element, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    cx.added(node->path.at(0u), prism_rtl::to_pod(crate::Elem(crate::Elem::FsContents{crate::fs::FsContents{.path_ = file}})));
    cx.listen(node->source_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// `!generation_fired`.
Unit MainArmElseArmElse::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmElse::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmElse::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmElse::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Fallible<crate::fs::Contents> value = this->source.get(cx);
    prism_rtl::Rc<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<prism_rtl::Rc<Row>> _v;
    auto&& _m = std::tuple{Job_{.tokens = this->tokens, .fragment = this->fragment, .text = Text::lit("")}, this->file, this->out, value};
    if (prism_rtl::is_ok(std::get<3>(_m))) {
        auto&& job = std::get<0>(_m);
        auto&& file = std::get<1>(_m);
        auto&& out = std::get<2>(_m);
        auto&& c = *std::get<3>(_m);
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmElseGen0::make(path, job, file, out, c, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is_err(std::get<3>(_m))) {
        auto&& job = std::get<0>(_m);
        auto&& file = std::get<1>(_m);
        auto&& out = std::get<2>(_m);
        auto&& c3 = std::get<3>(_m).error();
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmElseGen1::make(path, job, file, out, c3.message, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmElseArmElse::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmElse::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->source_element) {
        this->source.set(TRY(prism_rtl::from_pod<Fallible<crate::fs::Contents>>(v)), cx);
        this->generation_stale = true;
        cx.build_later(prism_rtl::share(this));
    }
    return {};
}


Done MainArmElseArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->source.set(TRY(prism_rtl::from_pod<Fallible<crate::fs::Contents>>(v)), cx);
            this->generation_stale = true;
            cx.build_later(prism_rtl::share(this));
            Unit{};
        });
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmElseGen0>> MainArmElseArmElseGen0::make(Path path, Job_ job, Text file, Text out, crate::fs::Contents c, prism_rtl::Weak<MainArmElseArmElse> parent, Cx& cx) {
    prism_rtl::Rc<Port<Outcome_>> done_v_port = prism_rtl::make_new();
    auto full = ({
        Job_ this_ = job;
        this_.text = c->text;
        this_;
    });
    std::optional<Outcome_> outcome_init = std::optional<Outcome_>{};
    prism_rtl::RcPlace<MainArmElseArmElseGen0> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmElseGen0(path, job, file, out, c, parent, done_v_port, full, {start_front_end(full), cx}, {}, {}, {}, {outcome_init, cx}, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    cx.on_started(node);
    return node;
}


/// `!done`.
Unit MainArmElseArmElseGen0::done(Outcome_ v, Cx& cx) {
    prism_rtl::ignore(this->done_v_port->fire(v, cx));
    this->outcome.set(std::optional(v), cx);
    this->generation_stale = true;
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// `@started`, the tick after the build.
Unit MainArmElseArmElseGen0::run_started(Unit v, Cx& cx) {
    this->run_turn_left.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// An `@Defer` firing, the tick after it was armed.
Unit MainArmElseArmElseGen0::run_again_(Unit v, Cx& cx) {
    this->run_turn_right.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// The merge `run_turn`, decided in the wake.
Unit MainArmElseArmElseGen0::run_turn(Unit v, Cx& cx) {
    {
        auto&& _m = this->run_job.get(cx)->cycle();
        if (_m.if_more()) {
            auto&& next = _m.if_more()->next;
            this->run_job.set(next, cx);
            this->run_again.arm(Unit{}, prism_rtl::share(this), cx);
        } else if (_m.if_finished()) {
            auto&& b = _m.if_finished()->value;
            this->done(b, cx);
        }
    }
    return Unit{};
}


/// `!generation_fired`.
Unit MainArmElseArmElseGen0::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmElseGen0::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmElseGen0::remove_places(Cx& cx) const {
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmElseGen0::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    std::optional<Outcome_> value = this->outcome.get(cx);
    prism_rtl::Rc<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<prism_rtl::Rc<Row>> _v;
    auto&& _m = std::tuple{this->out, value};
    if (prism_rtl::is_none(std::get<1>(_m))) {
        auto&& out = std::get<0>(_m);
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmElseGen0Gen0::make(path, out, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is_some(std::get<1>(_m))) {
        auto&& out = std::get<0>(_m);
        auto&& o = prism_rtl::some_of(std::get<1>(_m));
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmElseGen0Gen1::make(path, out, o, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmElseArmElseGen0::wake(Cx& cx) {
    {
        auto left = this->run_turn_left.take(cx);
        auto right = this->run_turn_right.take(cx);
        if (auto&& _m = left; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        } else if (auto&& _m = right; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        }
    }
    return {};
}


Done MainArmElseArmElseGen0::started(Cx& cx) {
    this->run_started(Unit{}, cx);
    return {};
}


Done MainArmElseArmElseGen0::deferred(Cx& cx) {
    if (auto&& _m = this->run_again.fired(cx); prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        this->run_again_(v, cx);
    }
    return {};
}


Done MainArmElseArmElseGen0::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmElseGen0::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmElseGen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmElseGen0Gen0>> MainArmElseArmElseGen0Gen0::make(Path path, Text out, prism_rtl::Weak<MainArmElseArmElseGen0> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmElseArmElseGen0Gen0> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmElseGen0Gen0(path, out, parent));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmElseArmElseGen0Gen0::remove_places(Cx& cx) const {

    return Unit{};
}


void MainArmElseArmElseGen0Gen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmElseGen0Gen1>> MainArmElseArmElseGen0Gen1::make(Path path, Text out, Outcome_ o, prism_rtl::Weak<MainArmElseArmElseGen0> parent, Cx& cx) {
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port = prism_rtl::make_new();
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = out, .text = o->text}}))), Fault::answer("no first value for Fs.Output")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = out, .text = o->text}}));
    prism_rtl::RcPlace<MainArmElseArmElseGen0Gen1> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmElseGen0Gen1(path, out, o, parent, started_2_v_port, verdict_v_port, {TRY(prism_rtl::from_pod<crate::fs::WriteState>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = out, .text = o->text}})));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    cx.added(node->path.at(2u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmElseArmElseGen0Gen1::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->verdict(this->o.failed
        ? unexpected(Error("Prismc.Refused", this->o.report))
        : Expected<std::decay_t<decltype(Unit{})>, std::decay_t<decltype(Error("Prismc.Refused", this->o.report))>>(Unit{}), cx);
    return Unit{};
}


/// `!verdict`.
Unit MainArmElseArmElseGen0Gen1::verdict(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->verdict_v_port->fire(v, cx));
    cx.request(this->path.at(2u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_2`: an answer at its place.
Unit MainArmElseArmElseGen0Gen1::place_2(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmElseGen0Gen1::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    cx.removed(this->path.at(2u));
    return Unit{};
}


Done MainArmElseArmElseGen0Gen1::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmElseArmElseGen0Gen1::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<crate::fs::WriteState>(v)), cx);
    }
    return {};
}


Done MainArmElseArmElseGen0Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 2u) {
        this->place_2(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<crate::fs::WriteState>(v)), cx);
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmElseGen0Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmElseGen1>> MainArmElseArmElseGen1::make(Path path, Job_ job, Text file, Text out, Text m, prism_rtl::Weak<MainArmElseArmElse> parent, Cx& cx) {
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port = prism_rtl::make_new();
    prism_rtl::RcPlace<MainArmElseArmElseGen1> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmElseGen1(path, job, file, out, m, parent, started_2_v_port, gave_up_v_port));
    cx.added(node->path.at(1u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmElseArmElseGen1::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->gave_up(unexpected(Error("Prismc.Refused", prism_rtl::cat("cannot read ", this->file, ": ", this->m))), cx);
    return Unit{};
}


/// `!gave_up`.
Unit MainArmElseArmElseGen1::gave_up(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->gave_up_v_port->fire(v, cx));
    cx.request(this->path.at(1u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_1`: an answer at its place.
Unit MainArmElseArmElseGen1::place_1(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmElseGen1::remove_places(Cx& cx) const {
    cx.removed(this->path.at(1u));
    return Unit{};
}


Done MainArmElseArmElseGen1::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmElseArmElseGen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u) {
        this->place_1(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmElseGen1::leave_row(Cx& cx) {
    remove_places(cx);
}


// `@FrontMain` is inlined where it is applied.

// `@Compile` is inlined where it is applied.

// `@Finish` is inlined where it is applied.

/// let noCheckOpts
CheckOpts no_check_opts() {
    return CheckOpts{.world = Array<Text>{}, .out = std::optional<Text>{}, .typed = false, .unused = false};
}


/// let noCompileSettings
CompileSettings no_compile_settings() {
    return CompileSettings{.out = Text::lit(""), .prelude = Text::lit(""), .name = Text::lit(""), .runtime = Text::lit(""), .target = Text::lit("")};
}


// `@ReadSources` is inlined where it is applied.

// `@ReadUp` is inlined where it is applied.

// `@ReadTexts` is inlined where it is applied.

// `@ReadRun` is inlined where it is applied.

// `@CheckRun` is inlined where it is applied.

// `@CompileRun` is inlined where it is applied.

/// Pairs: fn [Text], (Nat ==> [Text]) -> [((Text, [Text]))]
Array<std::tuple<Text, Array<Text>>> pairs(const Array<Text>& ds, const Map<Nat, Array<Text>>& m) {
    return each(crate::check::errors::range0(len(ds)), [&](const Nat& i) { return std::tuple{or_(index(ds, i), Text::lit("")), or_(crate::prelude::get(m, i), Array<Text>{})}; });
}


/// ReadFailure: fn ?~Contents -> Text
Text read_failure(const std::optional<Fallible<crate::fs::Contents>>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& c_try = prism_rtl::some_of(opt0);
        return contents_failure(c_try);
    }
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("nothing was read");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ContentsFailure: fn ~Contents -> Text
Text contents_failure(const Fallible<crate::fs::Contents>& arg0) {
    if (prism_rtl::is_ok(arg0)) {
        auto&& c = *arg0;
        return Text::lit("");
    }
    if (prism_rtl::is_err(arg0)) {
        auto&& c1_0 = arg0.error();
        return c1_0.message;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ContentsText: fn ~Contents -> Text
Text contents_text(const Fallible<crate::fs::Contents>& arg0) {
    if (prism_rtl::is_ok(arg0)) {
        auto&& c = *arg0;
        return c->text;
    }
    if (prism_rtl::is_err(arg0)) {
        auto&& c1_0 = arg0.error();
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsSourcePath: fn Text -> Bool
bool is_source_path(const Text& f) {
    return crate::syntax::lexer::has_suffix(f, Text::lit(".prism")) || crate::syntax::lexer::has_suffix(f, Text::lit(".prismtest"));
}


/// DirOf: fn Text -> Text
Text dir_of(const Text& p_) {
    return crate::syntax::lexer::join(crate::syntax::lexer::pop(split(p_, Text::lit("/"))), Text::lit("/"));
}


/// BaseOf: fn Text -> Text
Text base_of(const Text& p_) {
    return or_(crate::syntax::lexer::last(split(p_, Text::lit("/"))), p_);
}


/// Under: fn Text, Text -> Text
Text under(const Text& d, const Text& n) {
    return (d == Text::lit("")) || (d == Text::lit("."))
        ? n
        : prism_rtl::cat(d, "/", n);
}


/// Ancestors: fn Text -> [Text]
Array<Text> ancestors(const Text& d) {
    auto parts = split(d, Text::lit("/"));
    auto n = len(parts);
    return filter(each(crate::check::errors::range0(crate::syntax::lexer::dec(n)), [&](const Nat& i) { return crate::syntax::lexer::join(take(parts, or_(crate::syntax::lexer::dec(n).checked_sub(i), Nat(0u))), Text::lit("/")); }), [&](const Text& a) { return (a != Text::lit("")) && (a != Text::lit(".")); });
}


/// DirName: fn Text -> Text
Text dir_name(const Text& name) {
    auto&& _out = crate::syntax::lexer::fold_chars(name, std::tuple{Text::lit(""), Text::lit("")}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(std::tuple<std::tuple<Text, Text>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Text, Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto [acc, prev] = p0;
                auto c = p1;
                ({
                auto sep = crate::syntax::lexer::is_upper(c) && (crate::syntax::lexer::is_lower(prev) || crate::syntax::lexer::is_digit(prev))
                    ? Text::lit("_")
                    : Text::lit("");
                (prism_rtl::finished(std::tuple{prism_rtl::cat(acc, sep, crate::syntax::lexer::is_upper(c) ? crate::prelude::lower(c) : c), c}));
            });
            });
        });
    })));
    auto&& out = std::get<0>(_out);
    return out;
}


/// ModOfDir: fn Text -> Text
Text mod_of_dir(const Text& d) {
    return concat(each(split(d, Text::lit("_")), [&](const Text& w) { return prism_rtl::cat(upper(crate::syntax::lexer::head(w)), crate::syntax::lexer::after_first(w)); }));
}


/// HeaderLines: fn Text -> [HeadLine]
Array<HeadLine> header_lines(const Text& text) {
    auto&& _lines = fold(split(text, Text::lit("\n")), std::tuple{Array<HeadLine>{}, Nat(0u), true}, [&](const std::tuple<Array<HeadLine>, Nat, bool>& _p0, const Text& line) {
        auto&& acc = std::get<0>(_p0);
        auto&& at_ = std::get<1>(_p0);
        auto&& open = std::get<2>(_p0);
        return ({
            auto next = (at_ + len_text(line)) + Nat(1u);
            !open
            ? std::tuple{acc, next, false}
            : ((crate::syntax::lexer::trim(line) == Text::lit("")) || crate::syntax::lexer::has_prefix(line, Text::lit("#"))) || crate::syntax::lexer::has_prefix(line, Text::lit(" "))
            ? std::tuple{acc, next, true}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<HeadLine>, Nat, bool>> _v;
            auto&& _m = head_line_of(line, at_);
            if (prism_rtl::is_some(_m)) {
                auto&& h = prism_rtl::some_of(_m);
                _v.set(std::tuple{crate::prelude::push(acc, h), next, true});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::tuple{acc, next, false});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    });
    auto&& lines = std::get<0>(_lines);
    return lines;
}


/// ?HeadLineOf: fn Text, Nat -> ?HeadLine
std::optional<HeadLine> head_line_of(const Text& line, const Nat& at_) {
    auto code = crate::syntax::lexer::trim_end(or_(index(split(line, Text::lit(" #")), Nat(0u)), line));
    auto words = filter(split(code, Text::lit(" ")), [&](const Text& w) { return w != Text::lit(""); });
    auto first_ = or_(index(words, Nat(0u)), Text::lit(""));
    auto second = or_(index(words, Nat(1u)), Text::lit(""));
    auto span = crate::syntax::Range{.start = at_, .end = at_ + len_text(code)};
    return (first_ == Text::lit("test")) && (second == Text::lit("mod"))
        ? std::optional(HeadLine{.word = Text::lit("test mod"), .arg = or_(index(words, Nat(2u)), Text::lit("")), .span = span})
        : crate::check::types::has_text(Array(std::vector{Text::lit("module"), Text::lit("emit"), Text::lit("mod"), Text::lit("use")}), first_)
        ? std::optional(HeadLine{.word = first_, .arg = or_(crate::syntax::lexer::before_suffix(second, Text::lit(".*")), second), .span = span})
        : std::optional<HeadLine>{};
}


/// ?FirstDeclLine: fn Text -> ?Range
std::optional<crate::syntax::Range> first_decl_line(const Text& text) {
    auto&& _found_opt = fold(split(text, Text::lit("\n")), std::tuple{std::optional<crate::syntax::Range>{}, Nat(0u)}, [&](const std::tuple<std::optional<crate::syntax::Range>, Nat>& _p0, const Text& line) {
        auto&& f_opt = std::get<0>(_p0);
        auto&& at_ = std::get<1>(_p0);
        return ({
            auto next = (at_ + len_text(line)) + Nat(1u);
            ((((f_opt != std::optional<crate::syntax::Range>{}) || (crate::syntax::lexer::trim(line) == Text::lit(""))) || crate::syntax::lexer::has_prefix(line, Text::lit("#"))) || crate::syntax::lexer::has_prefix(line, Text::lit(" "))) || (head_line_of(line, at_) != std::optional<HeadLine>{})
            ? std::tuple{f_opt, next}
            : std::tuple{std::optional(crate::syntax::Range{.start = at_, .end = at_ + len_text(crate::syntax::lexer::trim_end(line))}), next};
        });
    });
    auto&& found_opt = std::get<0>(_found_opt);
    return found_opt;
}


/// let noAssembly
Assembled no_assembly() {
    return Assembled{.units = Array<ModFiles>{}, .prelude = Array<ModFiles>{}, .scripts = Array<Text>{}, .warnings = Array<TreeDiag>{}, .errors = Array<TreeDiag>{}};
}


/// let noSpan
crate::syntax::Range no_span() {
    return crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)};
}


/// AddTreeDiag: fn TreeAcc, Text, Range, Text, Text, Text -> TreeAcc
TreeAcc add_tree_diag(const TreeAcc& acc, const Text& path_, const crate::syntax::Range& span, const Text& code, const Text& message, const Text& fix) {
    TreeAcc this_ = acc;
    this_.diags = crate::prelude::push(this_.diags, TreeDiag{.path_ = path_, .span = span, .code = code, .message = message, .fix = fix});
    return this_;
}


/// IsModuleDir: fn Text, [Text] -> Bool
bool is_module_dir(const Text& d, const Array<Text>& files) {
    return (crate::check::types::has_text(files, under(d, Text::lit("mod.prism"))) && (!crate::check::types::has_text(files, under(d, Text::lit("app.prism"))))) && (!crate::check::types::has_text(files, under(d, Text::lit("lib.prism"))));
}


/// IsRootDir: fn Text, [Text] -> Bool
bool is_root_dir(const Text& d, const Array<Text>& files) {
    return crate::check::types::has_text(files, under(d, Text::lit("app.prism"))) || crate::check::types::has_text(files, under(d, Text::lit("lib.prism")));
}


/// ?TreeRootOf: fn Text, (Text ==> [Text]) -> ?Text
std::optional<Text> tree_root_of(const Text& d, const Map<Text, Array<Text>>& listings) {
    auto files = or_(crate::prelude::get(listings, d), Array<Text>{});
    return is_root_dir(d, files)
        ? std::optional(d)
        : is_module_dir(d, files)
        ? fold(ancestors(d), std::optional<Text>{}, [&](const std::optional<Text>& found_opt, const Text& a) {
        return (found_opt == std::optional<Text>{}) && is_root_dir(a, or_(crate::prelude::get(listings, a), Array<Text>{}))
            ? std::optional(a)
            : found_opt;
    })
        : std::optional<Text>{};
}


/// ToRead: fn [Text], (Text ==> [Text]) -> [Text]
Array<Text> to_read(const Array<Text>& args, const Map<Text, Array<Text>>& listings) {
    return fold(args, Array<Text>{}, [&](const Array<Text>& acc, const Text& a) {
        return is_source_path(a)
            ? crate::check::types::add_text(acc, a)
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = tree_root_of(a, listings);
            if (prism_rtl::is_some(_m)) {
                auto&& root = prism_rtl::some_of(_m);
                _v.set(crate::check::types::union_texts(acc, or_(crate::prelude::get(listings, root), Array<Text>{})));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// Assemble: unbounded fn ReadInput -> Assembled
Assembled assemble(const ReadInput& input) {
    auto listings = map(input->listings);
    auto texts = map(input->texts);
    auto progs = run_to_end(fold_job(input->args, no_assembly(), ({
        auto listings_1 = listings;
        auto texts_2 = texts;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Assembled>(std::tuple<Assembled, Text>)>>(prism_rtl::rc([=](std::tuple<Assembled, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto listings_1_3 = listings_1;
            auto texts_2_3 = texts_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                (prism_rtl::more(prism_rtl::rc(AddArg(acc, listings_1_3, texts_2_3, a))));
            });
        }));
        });
    })));
    })));
    auto pre = add_arg(no_assembly(), listings, texts, input->prelude);
    auto units = each(progs.units, [&](const ModFiles& u) { return kept_segs(u, input->tests); });
    auto kept = fold(units, Array<Text>{}, [&](const Array<Text>& acc, const ModFiles& u) { return append(acc, each(u.segs, [&](const Seg& s) { return s->path_; })); });
    Assembled this_ = progs;
    this_.units = units;
    this_.prelude = each(pre.units, [&](const ModFiles& u) { return kept_segs(u, false); });
    this_.scripts = filter(this_.scripts, [&](const Text& p_) { return crate::check::types::has_text(kept, p_); });
    this_.warnings = append(this_.warnings, pre.warnings);
    this_.errors = append(this_.errors, pre.errors);
    return this_;
}


prism_rtl::Turn<Assembled> Assemble::cycle() const {
    const auto& input = this->input;
    auto listings = map(input->listings);
    auto texts = map(input->texts);
    auto input_1 = input;
    return call_value(fold_job(input_1->args, no_assembly(), ({
        auto listings_2 = listings;
        auto texts_3 = texts;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Assembled>(std::tuple<Assembled, Text>)>>(prism_rtl::rc([=](std::tuple<Assembled, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto listings_2_4 = listings_2;
            auto texts_3_4 = texts_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                (prism_rtl::more(prism_rtl::rc(AddArg(acc, listings_2_4, texts_3_4, a))));
            });
        }));
        });
    })));
    })), [=](Assembled fold_18802) {
        return ({
            auto progs = fold_18802;
            call_then(start_add_arg(no_assembly(), listings, texts, input_1->prelude), [=](Assembled add_arg_18886) {
            return ({
                auto pre = add_arg_18886;
                auto units = each(progs.units, [&](const ModFiles& u) { return kept_segs(u, input_1->tests); });
                auto kept = fold(units, Array<Text>{}, [&](const Array<Text>& acc, const ModFiles& u) { return append(acc, each(u.segs, [&](const Seg& s) { return s->path_; })); });
                (prism_rtl::finished(({
                Assembled this_ = progs;
                this_.units = units;
                this_.prelude = each(pre.units, [&](const ModFiles& u) { return kept_segs(u, false); });
                this_.scripts = filter(this_.scripts, [&](const Text& p_) { return crate::check::types::has_text(kept, p_); });
                this_.warnings = append(this_.warnings, pre.warnings);
                this_.errors = append(this_.errors, pre.errors);
                this_;
            })));
            });
        });
        });
    });
}


/// `Start Assemble, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Assembled> start_assemble(ReadInput input) {
    return prism_rtl::make_rc<Assemble>(input);
}


/// KeptSegs: fn ModFiles, Bool -> ModFiles
ModFiles kept_segs(const ModFiles& u, const bool& tests) {
    ModFiles this_ = u;
    this_.segs = filter(this_.segs, [&](const Seg& s) { return (s.role != Text::lit("test")) || tests; });
    return this_;
}


/// AddArg: unbounded fn Assembled, (Text ==> [Text]), (Text ==> Text), Text -> Assembled
Assembled add_arg(const Assembled& acc, const Map<Text, Array<Text>>& listings, const Map<Text, Text>& texts, const Text& a) {
    return crate::syntax::lexer::has_suffix(a, Text::lit(".prismtest"))
        ? ({
        Assembled this_ = acc;
        this_.errors = crate::prelude::push(this_.errors, TreeDiag{.path_ = a, .span = no_span(), .code = Text::lit("prismtest"), .message = prism_rtl::cat("`", a, "`: a `.prismtest` is not read: a module's tests are in its test modules, a loose file's inline"), .fix = Text::lit("move its declarations into a test module (`test mod tests`), or into the file it tests")});
        this_;
    })
        : crate::syntax::lexer::has_suffix(a, Text::lit(".prism"))
        ? ({
        Assembled this_ = acc;
        this_.units = crate::prelude::push(this_.units, ModFiles{.name = Text::lit(""), .named = false, .segs = Array(std::vector{Seg{.path_ = a, .text = or_(crate::prelude::get(texts, a), Text::lit("")), .role = Text::lit("loose")}})});
        this_;
    })
        : ({
        __label__ _done;
        prism_rtl::Slot<Assembled> _v;
        auto&& _m = tree_root_of(a, listings);
        if (prism_rtl::is_some(_m)) {
            auto&& root = prism_rtl::some_of(_m);
            _v.set(({
                auto tree = walk_tree(root, or_(crate::prelude::get(listings, root), Array<Text>{}), texts);
                auto units = root == a
                    ? tree.units
                    : reach_tree(tree.units, under(a, Text::lit("mod.prism")));
                auto scripts = root == a
                    ? fold(units, Array<Text>{}, [&](const Array<Text>& s, const ModFiles& u) { return append(s, test_paths(u)); })
                    : fold(filter(units, [&](const ModFiles& u) { return main_path(u) == under(a, Text::lit("mod.prism")); }), Array<Text>{}, [&](const Array<Text>& s, const ModFiles& u) { return append(s, test_paths(u)); });
                ({
                Assembled this_ = acc;
                this_.units = append(this_.units, units);
                this_.scripts = append(this_.scripts, scripts);
                this_.errors = append(this_.errors, tree.diags);
                this_;
            });
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                Assembled this_ = acc;
                this_.errors = crate::prelude::push(this_.errors, TreeDiag{.path_ = a, .span = no_span(), .code = Text::lit("no-root"), .message = prism_rtl::cat("`", a, "` holds no app.prism, lib.prism or mod.prism, and a directory argument is a tree"), .fix = Text::lit("give it a root, or name its files")});
                this_;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Assembled> AddArg::cycle() const {
    const auto& acc = this->acc;
    const auto& listings = this->listings;
    const auto& texts = this->texts;
    const auto& a = this->a;
    return crate::syntax::lexer::has_suffix(a, Text::lit(".prismtest"))
        ? prism_rtl::finished(({
        Assembled this_ = acc;
        this_.errors = crate::prelude::push(this_.errors, TreeDiag{.path_ = a, .span = no_span(), .code = Text::lit("prismtest"), .message = prism_rtl::cat("`", a, "`: a `.prismtest` is not read: a module's tests are in its test modules, a loose file's inline"), .fix = Text::lit("move its declarations into a test module (`test mod tests`), or into the file it tests")});
        this_;
    }))
        : crate::syntax::lexer::has_suffix(a, Text::lit(".prism"))
        ? prism_rtl::finished(({
        Assembled this_ = acc;
        this_.units = crate::prelude::push(this_.units, ModFiles{.name = Text::lit(""), .named = false, .segs = Array(std::vector{Seg{.path_ = a, .text = or_(crate::prelude::get(texts, a), Text::lit("")), .role = Text::lit("loose")}})});
        this_;
    }))
        : ({
        auto&& _m = tree_root_of(a, listings);
        prism_rtl::is_some(_m) ? ({
        auto&& root = prism_rtl::some_of(_m);
        ({
        auto a_1 = a;
        auto acc_2 = acc;
        auto listings_3 = listings;
        auto texts_4 = texts;
        call_then(start_walk_tree(root, or_(crate::prelude::get(listings_3, root), Array<Text>{}), texts_4), [=](TreeAcc walk_tree_20274) {
        return ({
            auto tree = walk_tree_20274;
            auto units = root == a_1
                ? tree.units
                : reach_tree(tree.units, under(a_1, Text::lit("mod.prism")));
            auto scripts = root == a_1
                ? fold(units, Array<Text>{}, [&](const Array<Text>& s, const ModFiles& u) { return append(s, test_paths(u)); })
                : fold(filter(units, [&](const ModFiles& u) { return main_path(u) == under(a_1, Text::lit("mod.prism")); }), Array<Text>{}, [&](const Array<Text>& s, const ModFiles& u) { return append(s, test_paths(u)); });
            (prism_rtl::finished(({
            Assembled this_ = acc_2;
            this_.units = append(this_.units, units);
            this_.scripts = append(this_.scripts, scripts);
            this_.errors = append(this_.errors, tree.diags);
            this_;
        })));
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(({
        Assembled this_ = acc;
        this_.errors = crate::prelude::push(this_.errors, TreeDiag{.path_ = a, .span = no_span(), .code = Text::lit("no-root"), .message = prism_rtl::cat("`", a, "` holds no app.prism, lib.prism or mod.prism, and a directory argument is a tree"), .fix = Text::lit("give it a root, or name its files")});
        this_;
    }))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start AddArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Assembled> start_add_arg(Assembled acc, Map<Text, Array<Text>> listings, Map<Text, Text> texts, Text a) {
    return prism_rtl::make_rc<AddArg>(acc, listings, texts, a);
}


/// MainPath: fn ModFiles -> Text
Text main_path(const ModFiles& u) {
    auto&& _m = index(u.segs, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& s = prism_rtl::some_of(_m);
        return s->path_;
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// MainText: fn ModFiles -> Text
Text main_text(const ModFiles& u) {
    auto&& _m = index(u.segs, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& s = prism_rtl::some_of(_m);
        return s->text;
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// TestPaths: fn ModFiles -> [Text]
Array<Text> test_paths(const ModFiles& u) {
    return each(filter(u.segs, [&](const Seg& s) { return s.role == Text::lit("test"); }), [&](const Seg& s) { return s->path_; });
}


/// WalkTree: unbounded fn Text, [Text], (Text ==> Text) -> TreeAcc
TreeAcc walk_tree(const Text& root, const Array<Text>& files, const Map<Text, Text>& texts) {
    auto has = fold(files, Map<Text, bool>{}, [&](const Map<Text, bool>& m, const Text& f) { return insert(m, f, true); });
    auto app_1 = under(root, Text::lit("app.prism"));
    auto lib_2 = under(root, Text::lit("lib.prism"));
    auto acc0 = TreeAcc{.units = Array<ModFiles>{}, .declared = Map<Text, bool>{}, .diags = Array<TreeDiag>{}};
    auto acc1 = crate::check::env::has_key(has, app_1) && crate::check::env::has_key(has, lib_2)
        ? add_tree_diag(acc0, lib_2, no_span(), Text::lit("two-roots"), Text::lit("`app.prism` and `lib.prism` in one directory: a tree has one root"), Text::lit("keep app.prism for a program or lib.prism for a library"))
        : acc0;
    auto acc2 = crate::check::env::has_key(has, app_1)
        ? walk_module(has, texts, acc1, app_1, Text::lit(""))
        : walk_lib(has, texts, acc1, lib_2);
    auto acc3 = ({
        TreeAcc this_ = acc2;
        this_.declared = insert(this_.declared, lib_2, true);
        this_;
    });
    return fold(files, acc3, [&](const TreeAcc& a, const Text& f) { return crate::check::env::has_key(a.declared, f) ? a : stray(has, texts, a, f); });
}


prism_rtl::Turn<TreeAcc> WalkTree::cycle() const {
    const auto& root = this->root;
    const auto& files = this->files;
    const auto& texts = this->texts;
    auto has = fold(files, Map<Text, bool>{}, [&](const Map<Text, bool>& m, const Text& f) { return insert(m, f, true); });
    auto app_1 = under(root, Text::lit("app.prism"));
    auto lib_2 = under(root, Text::lit("lib.prism"));
    auto acc0 = TreeAcc{.units = Array<ModFiles>{}, .declared = Map<Text, bool>{}, .diags = Array<TreeDiag>{}};
    auto acc1 = crate::check::env::has_key(has, app_1) && crate::check::env::has_key(has, lib_2)
        ? add_tree_diag(acc0, lib_2, no_span(), Text::lit("two-roots"), Text::lit("`app.prism` and `lib.prism` in one directory: a tree has one root"), Text::lit("keep app.prism for a program or lib.prism for a library"))
        : acc0;
    auto acc2 = crate::check::env::has_key(has, app_1)
        ? walk_module(has, texts, acc1, app_1, Text::lit(""))
        : walk_lib(has, texts, acc1, lib_2);
    auto acc3 = ({
        TreeAcc this_ = acc2;
        this_.declared = insert(this_.declared, lib_2, true);
        this_;
    });
    return prism_rtl::finished(fold(files, acc3, [&](const TreeAcc& a, const Text& f) { return crate::check::env::has_key(a.declared, f) ? a : stray(has, texts, a, f); }));
}


/// `Start WalkTree, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TreeAcc> start_walk_tree(Text root, Array<Text> files, Map<Text, Text> texts) {
    return prism_rtl::make_rc<WalkTree>(root, files, texts);
}


/// WalkLib: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
TreeAcc walk_lib(const Map<Text, bool>& has, const Map<Text, Text>& texts, const TreeAcc& acc, const Text& lib) {
    auto text = or_(crate::prelude::get(texts, lib), Text::lit(""));
    auto heads = header_lines(text);
    auto bad = filter(heads, [&](const HeadLine& h) { return !((h.word == Text::lit("mod")) && crate::check::env::is_upper_text(h.arg)); });
    auto acc1 = fold(bad, acc, [&](const TreeAcc& a, const HeadLine& h) { return add_tree_diag(a, lib, h.span, Text::lit("lib-header"), prism_rtl::cat("lib.prism holds only `mod Name` lines, the library's modules: `", h.word, "` belongs in a module"), Text::lit("move the line to a module's mod.prism")); });
    auto acc2 = ({
        __label__ _done;
        prism_rtl::Slot<TreeAcc> _v;
        auto&& _m = first_decl_line(text);
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(add_tree_diag(acc1, lib, r, Text::lit("lib-header"), Text::lit("lib.prism holds only `mod Name` lines, the library's modules"), Text::lit("move the declaration to a module")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(acc1);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto dir = dir_of(lib);
    return run_to_end(fold_job(filter(heads, [&](const HeadLine& h) { return (h.word == Text::lit("mod")) && crate::check::env::is_upper_text(h.arg); }), acc2, ({
        auto has_1 = has;
        auto texts_2 = texts;
        auto lib_3 = lib;
        auto dir_4 = dir;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<TreeAcc>(std::tuple<TreeAcc, HeadLine>)>>(prism_rtl::rc([=](std::tuple<TreeAcc, HeadLine> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto has_1_5 = has_1;
            auto texts_2_5 = texts_2;
            auto lib_3_5 = lib_3;
            auto dir_4_5 = dir_4;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                auto h = p1;
                (prism_rtl::more(prism_rtl::rc(Submodule(has_1_5, texts_2_5, a, lib_3_5, dir_4_5, h, Text::lit("")))));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<TreeAcc> WalkLib::cycle() const {
    const auto& has = this->has;
    const auto& texts = this->texts;
    const auto& acc = this->acc;
    const auto& lib = this->lib;
    auto text = or_(crate::prelude::get(texts, lib), Text::lit(""));
    auto heads = header_lines(text);
    auto bad = filter(heads, [&](const HeadLine& h) { return !((h.word == Text::lit("mod")) && crate::check::env::is_upper_text(h.arg)); });
    auto acc1 = fold(bad, acc, [&](const TreeAcc& a, const HeadLine& h) { return add_tree_diag(a, lib, h.span, Text::lit("lib-header"), prism_rtl::cat("lib.prism holds only `mod Name` lines, the library's modules: `", h.word, "` belongs in a module"), Text::lit("move the line to a module's mod.prism")); });
    auto acc2 = ({
        __label__ _done;
        prism_rtl::Slot<TreeAcc> _v;
        auto&& _m = first_decl_line(text);
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(add_tree_diag(acc1, lib, r, Text::lit("lib-header"), Text::lit("lib.prism holds only `mod Name` lines, the library's modules"), Text::lit("move the declaration to a module")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(acc1);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto dir = dir_of(lib);
    return fold_job(filter(heads, [&](const HeadLine& h) { return (h.word == Text::lit("mod")) && crate::check::env::is_upper_text(h.arg); }), acc2, ({
        auto has_1 = has;
        auto texts_2 = texts;
        auto lib_3 = lib;
        auto dir_4 = dir;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<TreeAcc>(std::tuple<TreeAcc, HeadLine>)>>(prism_rtl::rc([=](std::tuple<TreeAcc, HeadLine> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto has_1_5 = has_1;
            auto texts_2_5 = texts_2;
            auto lib_3_5 = lib_3;
            auto dir_4_5 = dir_4;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                auto h = p1;
                (prism_rtl::more(prism_rtl::rc(Submodule(has_1_5, texts_2_5, a, lib_3_5, dir_4_5, h, Text::lit("")))));
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start WalkLib, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TreeAcc> start_walk_lib(Map<Text, bool> has, Map<Text, Text> texts, TreeAcc acc, Text lib) {
    return prism_rtl::make_rc<WalkLib>(has, texts, acc, lib);
}


/// WalkModule: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text -> TreeAcc
TreeAcc walk_module(const Map<Text, bool>& has, const Map<Text, Text>& texts, const TreeAcc& acc, const Text& main, const Text& name) {
    auto dir = dir_of(main);
    auto text = or_(crate::prelude::get(texts, main), Text::lit(""));
    auto heads = header_lines(text);
    auto mods = filter(heads, [&](const HeadLine& h) { return (h.word == Text::lit("mod")) || (h.word == Text::lit("test mod")); });
    auto subs = filter(mods, [&](const HeadLine& h) { return (h.word == Text::lit("mod")) && crate::check::env::is_upper_text(h.arg); });
    auto files = filter(mods, [&](const HeadLine& h) { return !((h.word == Text::lit("mod")) && crate::check::env::is_upper_text(h.arg)); });
    auto named = name == Text::lit("")
        ? Text::lit("its path makes it the root")
        : prism_rtl::cat("its path names the module `", name, "`");
    auto acc1 = fold(filter(heads, [&](const HeadLine& h) { return h.word == Text::lit("module"); }), acc, [&](const TreeAcc& a, const HeadLine& h) { return add_tree_diag(a, main, h.span, Text::lit("module-line"), prism_rtl::cat("a main file has no `module` line: ", named), Text::lit("delete the line")); });
    auto acc2 = fold(subs, acc1, [&](const TreeAcc& a, const HeadLine& s) { return fold(filter(files, [&](const HeadLine& f) { return (f.word == Text::lit("mod")) && (f.arg == dir_name(s.arg)); }), a, [&](const TreeAcc& b, const HeadLine& f) { return add_tree_diag(b, main, s.span.start > f.span.start ? s.span : f.span, Text::lit("mod-clash"), prism_rtl::cat("`mod ", s.arg, "` and `mod ", f.arg, "` in one header: the section `", f.arg, ".prism` and the submodule `", dir_name(s.arg), "/` have one name"), Text::lit("rename the section or the submodule")); }); });
    auto acc3 = ({
        TreeAcc this_ = acc2;
        this_.declared = insert(this_.declared, main, true);
        this_;
    });
    auto [segs, acc4] = fold(files, std::tuple{Array(std::vector{Seg{.path_ = main, .text = text, .role = Text::lit("main")}}), acc3}, [&](const std::tuple<Array<Seg>, TreeAcc>& _p0, const HeadLine& h) {
        auto&& ss = std::get<0>(_p0);
        auto&& a = std::get<1>(_p0);
        return ({
            auto path_ = under(dir, prism_rtl::cat(h.arg, ".prism"));
            auto role = h.word == Text::lit("test mod") ? Text::lit("test") : Text::lit("section");
            (!crate::check::env::has_key(has, path_)
            ? std::tuple{ss, add_tree_diag(a, main, h.span, Text::lit("mod-missing"), prism_rtl::cat("`", h.word, " ", h.arg, "` declares `", h.arg, ".prism`, which is not in the directory"), prism_rtl::cat("create ", h.arg, ".prism, or delete the line"))}
            : ({
            auto body = or_(crate::prelude::get(texts, path_), Text::lit(""));
            auto a2 = ({
                TreeAcc this_ = a;
                this_.declared = insert(this_.declared, path_, true);
                this_;
            });
            auto what = role == Text::lit("test")
                ? Text::lit("a test module")
                : Text::lit("a section");
            auto a3 = ({
                __label__ _done;
                prism_rtl::Slot<TreeAcc> _v;
                auto&& _m = index(header_lines(body), Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& h2 = prism_rtl::some_of(_m);
                    _v.set(add_tree_diag(a2, path_, h2.span, Text::lit("section-header"), prism_rtl::cat(what, " has no header: `", h2.word, "` belongs in ", base_of(main), ", the main file of its module"), prism_rtl::cat("move the line to ", base_of(main))));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(a2);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            std::tuple{crate::prelude::push(ss, Seg{.path_ = path_, .text = body, .role = role}), a3};
        }));
        });
    });
    auto ordered = append(filter(segs, [&](const Seg& s) { return s.role != Text::lit("test"); }), filter(segs, [&](const Seg& s) { return s.role == Text::lit("test"); }));
    auto acc5 = ({
        TreeAcc this_ = acc4;
        this_.units = crate::prelude::push(this_.units, ModFiles{.name = name, .named = true, .segs = ordered});
        this_;
    });
    return run_to_end(fold_job(subs, acc5, ({
        auto has_1 = has;
        auto texts_2 = texts;
        auto main_3 = main;
        auto dir_4 = dir;
        auto name_5 = name;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<TreeAcc>(std::tuple<TreeAcc, HeadLine>)>>(prism_rtl::rc([=](std::tuple<TreeAcc, HeadLine> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto has_1_6 = has_1;
            auto texts_2_6 = texts_2;
            auto main_3_6 = main_3;
            auto dir_4_6 = dir_4;
            auto name_5_6 = name_5;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                auto h = p1;
                (prism_rtl::more(prism_rtl::rc(Submodule(has_1_6, texts_2_6, a, main_3_6, dir_4_6, h, name_5_6))));
            });
        }));
        });
    })));
    })));
}

}  // namespace crate::program
