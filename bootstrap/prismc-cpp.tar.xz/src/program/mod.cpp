// The root module, from `target/bootstrap/cpp-src/prismc/app.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::program {

void Job_::show(Printer& p) const {
    p.record("Job", {{"tokens", tokens}, {"fragment", fragment}, {"text", text}});
}

Pod Job_::to_pod() const {
    return Pod::record("Job", {{"tokens", prism_rtl::to_pod(tokens)}, {"fragment", prism_rtl::to_pod(fragment)}, {"text", prism_rtl::to_pod(text)}});
}

Result<Job_> Job_::from_pod(const Pod& whole) {
    return Job_{.tokens = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "tokens")))), .fragment = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "fragment")))), .text = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "text"))))};
}


void Outcome_::show(Printer& p) const {
    p.record("Outcome", {{"text", text}, {"failed", failed}, {"report", report}});
}

Pod Outcome_::to_pod() const {
    return Pod::record("Outcome", {{"text", prism_rtl::to_pod(text)}, {"failed", prism_rtl::to_pod(failed)}, {"report", prism_rtl::to_pod(report)}});
}

Result<Outcome_> Outcome_::from_pod(const Pod& whole) {
    return Outcome_{.text = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "text")))), .failed = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "failed")))), .report = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "report"))))};
}


/// FrontEnd: unbounded fn Job -> Outcome
Outcome_ front_end(const Job_& job) {
    return job->tokens
        ? ({
        auto lexed = crate::syntax::lexer::layout::lex_file(job->text);
        auto report = render_diags(job->text, lexed.diags);
        Outcome_{.text = prism_rtl::cat(crate::syntax::lexer::corpus::render_tokens(lexed->tokens), report, "\n"), .failed = any_errors(lexed.diags), .report = report};
    })
        : ({
        auto parsed = job->fragment
            ? crate::syntax::parser::parse_fragment(job->text)
            : crate::syntax::parser::parse_file(job->text);
        auto report = render_diags(job->text, parsed.diags);
        Outcome_{.text = prism_rtl::cat(crate::syntax::sexp::sexp_module(parsed.tree), report, "\n"), .failed = any_errors(parsed.diags), .report = report};
    });
}


prism_rtl::Turn<Outcome_> FrontEnd::cycle() const {
    const auto& job = this->job;
    return job->tokens
        ? ({
        auto job_1 = job;
        call_then(crate::syntax::lexer::layout::start_lex_file(job_1->text), [=](crate::syntax::lexer::Lexed lex_file_3181) {
        return ({
            auto lexed = lex_file_3181;
            auto report = render_diags(job_1->text, lexed.diags);
            (prism_rtl::finished(Outcome_{.text = prism_rtl::cat(crate::syntax::lexer::corpus::render_tokens(lexed->tokens), report, "\n"), .failed = any_errors(lexed.diags), .report = report}));
        });
    });
    })
        : ({
        auto parsed = job->fragment
            ? crate::syntax::parser::parse_fragment(job->text)
            : crate::syntax::parser::parse_file(job->text);
        auto report = render_diags(job->text, parsed.diags);
        (prism_rtl::finished(Outcome_{.text = prism_rtl::cat(crate::syntax::sexp::sexp_module(parsed.tree), report, "\n"), .failed = any_errors(parsed.diags), .report = report}));
    });
}


/// `Start FrontEnd, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Outcome_> start_front_end(Job_ job) {
    return prism_rtl::make_rc<FrontEnd>(job);
}


/// AnyErrors: fn [Diag] -> Bool
bool any_errors(const Array<crate::syntax::Diag>& ds) {
    return fold(ds, false, [&](const bool& seen, const crate::syntax::Diag& d) { return seen || (d.stage != Text::lit("out")); });
}


/// RenderDiags: fn Text, [Diag] -> Text
Text render_diags(const Text& text, const Array<crate::syntax::Diag>& ds) {
    auto starts = line_starts(text);
    return crate::syntax::lexer::chars::join(each(ds, [&](const crate::syntax::Diag& d) { return render_diag(text, starts, d); }), Text::lit("\n"));
}


/// RenderDiag: fn Text, [Nat], Diag -> Text
Text render_diag(const Text& text, const Array<Nat>& starts, const crate::syntax::Diag& d) {
    auto line = line_of(starts, d.span.start);
    auto col = crate::syntax::lexer::chars::column_of(text, or_(index(starts, line), Nat(0u)), d.span.start) + Nat(1u);
    auto at_ = prism_rtl::cat(line + Nat(1u), ":", col);
    auto&& _m = d.feature;
    if (prism_rtl::is_some(_m)) {
        auto&& f = prism_rtl::some_of(_m);
        return prism_rtl::cat(at_, ": out of scope (", f, "): ", d.message);
    }
    if (prism_rtl::is_none(_m)) {
        return prism_rtl::cat(at_, ": ", d.message);
    }
    prism_rtl::unreachable("no arm matched");
}


/// LineStarts: fn Text -> [Nat]
Array<Nat> line_starts(const Text& text) {
    auto&& _starts = fold(split_on(text, Text::lit("\n")), std::tuple{Array<Nat>{}, Nat(0u)}, [&](const std::tuple<Array<Nat>, Nat>& _p0, const Text& line) {
        auto&& acc = std::get<0>(_p0);
        auto&& at_ = std::get<1>(_p0);
        return std::tuple{crate::prelude::push(acc, at_), (at_ + len_text(line)) + Nat(1u)};
    });
    auto&& starts = std::get<0>(_starts);
    return starts;
}


/// LineOf: fn [Nat], Nat -> Nat
Nat line_of(const Array<Nat>& starts, const Nat& offset) {
    return crate::syntax::lexer::chars::dec(fold(starts, Nat(0u), [&](const Nat& n, const Nat& s) { return s <= offset ? n + Nat(1u) : n; }));
}


/// ?OptionValue: fn [Text], Text -> ?Text
std::optional<Text> option_value(const Array<Text>& args, const Text& name) {
    return fold(crate::check::errors::range0(len(args)), std::optional<Text>{}, [&](const std::optional<Text>& found_opt, const Nat& i) {
        return index(args, i) == std::optional(name)
            ? index(args, i + Nat(1u))
            : found_opt;
    });
}


/// BadOptions: fn [Text], [Text], [Text] -> [Text]
Array<Text> bad_options(const Array<Text>& args, const Array<Text>& flags, const Array<Text>& valued) {
    auto [bad, owed] = fold(args, std::tuple{Array<Text>{}, Text::lit("")}, [&](const std::tuple<Array<Text>, Text>& _p0, const Text& a) {
        auto&& acc = std::get<0>(_p0);
        auto&& owed = std::get<1>(_p0);
        return owed != Text::lit("")
            ? std::tuple{acc, Text::lit("")}
            : crate::check::types::has_text(valued, a)
            ? std::tuple{acc, a}
            : crate::syntax::lexer::chars::has_prefix(a, Text::lit("-")) && (!crate::check::types::has_text(flags, a))
            ? std::tuple{crate::check::types::add_text(acc, prism_rtl::cat("unknown option ", a)), Text::lit("")}
            : std::tuple{acc, Text::lit("")};
    });
    return owed == Text::lit("")
        ? bad
        : crate::check::types::add_text(bad, prism_rtl::cat(owed, " takes a value"));
}


// `@Refuse` is inlined where it is applied.

/// PlainArgs: fn [Text], [Text] -> [Text]
Array<Text> plain_args(const Array<Text>& args, const Array<Text>& valued) {
    auto&& _kept = fold(args, std::tuple{Array<Text>{}, false}, [&](const std::tuple<Array<Text>, bool>& _p0, const Text& a) {
        auto&& acc = std::get<0>(_p0);
        auto&& skip = std::get<1>(_p0);
        return skip
            ? std::tuple{acc, false}
            : crate::check::types::has_text(valued, a)
            ? std::tuple{acc, true}
            : crate::syntax::lexer::chars::has_prefix(a, Text::lit("-"))
            ? std::tuple{acc, false}
            : std::tuple{crate::prelude::push(acc, a), false};
    });
    auto&& kept = std::get<0>(_kept);
    return each(kept, [&](const Text& a) { return no_slash(a); });
}


/// NoSlash: fn Text -> Text
Text no_slash(const Text& a) {
    return (a != Text::lit("/")) && crate::syntax::lexer::chars::has_suffix(a, Text::lit("/"))
        ? or_(crate::syntax::lexer::chars::before_suffix(a, Text::lit("/")), a)
        : a;
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<Main>> Main::make(Path path, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::ProcessArgs{crate::process::ProcessArgs{}}))), Fault::answer("no first value for Process.Args")));
    auto args = TRY(prism_rtl::from_pod<Array<Text>>(first_0));
    auto checking = fold(args, false, [&](const bool& seen, const Text& a) { return (seen || (a == Text::lit("--check"))) || (a == Text::lit("--typed")); });
    auto compiling = or_(index(args, Nat(0u)), Text::lit("")) == Text::lit("compile");
    prism_rtl::RcPlace<Main> _place;
    auto node = _place.take(new (_place.at()) Main(path, args, checking, compiling, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    cx.added(node->path.at(0u), prism_rtl::to_pod(crate::Elem(crate::Elem::ProcessArgs{crate::process::ProcessArgs{}})));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit Main::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done Main::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Unit value = Unit{};
    prism_rtl::Rc<Row> row = this->compiling
    ? static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done Main::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done Main::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThen>> MainArmThen::make(Path path, Unit value, prism_rtl::Weak<Main> parent, Cx& cx) {
    auto opts = drop(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, Nat(1u));
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::ProcessEnv{crate::process::ProcessEnv{.name = Text::lit("PRISM_ROOT")}}))), Fault::answer("no first value for Process.Env")));
    auto root = TRY(prism_rtl::from_pod<std::optional<Text>>(first_0));
    auto bad = bad_options(opts, Array(std::vector{Text::lit("--tests")}), crate::compile::compile_valued());
    auto target_1 = or_(option_value(opts, Text::lit("--target")), Text::lit("rust"));
    auto out_2 = or_(option_value(opts, Text::lit("-o")), Text::lit("prismc-out"));
    auto runtime_3 = crate::compile::runtime_of(option_value(opts, Text::lit("--runtime")), root, out_2);
    prism_rtl::RcPlace<MainArmThen> _place;
    auto node = _place.take(new (_place.at()) MainArmThen(path, value, parent, opts, root, bad, target_1, out_2, runtime_3, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    cx.added(node->path.at(0u), prism_rtl::to_pod(crate::Elem(crate::Elem::ProcessEnv{crate::process::ProcessEnv{.name = Text::lit("PRISM_ROOT")}})));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit MainArmThen::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThen::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    if (auto&& _m = this->arm; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThen::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Unit value = Unit{};
    prism_rtl::Rc<Row> row = len(this->bad) > Nat(0u)
    ? static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done MainArmThen::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done MainArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmThen>> MainArmThenArmThen::make(Path path, Unit value, prism_rtl::Weak<MainArmThen> parent, Cx& cx) {
    auto why = prism_rtl::cat(crate::syntax::lexer::chars::join(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->bad, Text::lit("; ")), " (compile takes -o OUT, --name NAME, --prelude DIR, --runtime PATH, --target rust|cpp, --tests)");
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port = prism_rtl::make_new();
    prism_rtl::RcPlace<MainArmThenArmThen> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmThen(path, value, parent, why, started_2_v_port, gave_up_v_port));
    cx.added(node->path.at(1u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmThenArmThen::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->gave_up(unexpected(Error("Prismc.Refused", this->why)), cx);
    return Unit{};
}


/// `!gave_up`.
Unit MainArmThenArmThen::gave_up(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->gave_up_v_port->fire(v, cx));
    cx.request(this->path.at(1u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_1`: an answer at its place.
Unit MainArmThenArmThen::place_1(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmThen::remove_places(Cx& cx) const {
    cx.removed(this->path.at(1u));
    return Unit{};
}


Done MainArmThenArmThen::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmThenArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u) {
        this->place_1(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElse>> MainArmThenArmElse::make(Path path, Unit value, prism_rtl::Weak<MainArmThen> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmThenArmElse> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElse(path, value, parent, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit MainArmThenArmElse::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElse::remove_places(Cx& cx) const {
    if (auto&& _m = this->arm; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(0u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThenArmElse::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(0u).child(Segment::gen(g));
    Unit value = Unit{};
    prism_rtl::Rc<Row> row = (expect(prism_rtl::upgrade(this->parent), "the block outlives its rows")->target != Text::lit("rust")) && (expect(prism_rtl::upgrade(this->parent), "the block outlives its rows")->target != Text::lit("cpp"))
    ? static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done MainArmThenArmElse::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done MainArmThenArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmThen>> MainArmThenArmElseArmThen::make(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElse> parent, Cx& cx) {
    auto why = prism_rtl::cat("unknown target ", expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->target, " (rust, cpp)");
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port = prism_rtl::make_new();
    prism_rtl::RcPlace<MainArmThenArmElseArmThen> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmThen(path, value, parent, why, started_2_v_port, gave_up_v_port));
    cx.added(node->path.at(1u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmThenArmElseArmThen::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->gave_up(unexpected(Error("Prismc.Refused", this->why)), cx);
    return Unit{};
}


/// `!gave_up`.
Unit MainArmThenArmElseArmThen::gave_up(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->gave_up_v_port->fire(v, cx));
    cx.request(this->path.at(1u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_1`: an answer at its place.
Unit MainArmThenArmElseArmThen::place_1(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmThen::remove_places(Cx& cx) const {
    cx.removed(this->path.at(1u));
    return Unit{};
}


Done MainArmThenArmElseArmThen::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmThenArmElseArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u) {
        this->place_1(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElse>> MainArmThenArmElseArmElse::make(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElse> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmThenArmElseArmElse> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElse(path, value, parent, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit MainArmThenArmElseArmElse::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElse::remove_places(Cx& cx) const {
    if (auto&& _m = this->arm; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(0u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThenArmElseArmElse::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(0u).child(Segment::gen(g));
    Unit value = Unit{};
    prism_rtl::Rc<Row> row = expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(this->parent), "the block outlives its rows")->parent), "the block outlives its rows")->runtime == std::optional<Text>{}
    ? static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done MainArmThenArmElseArmElse::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done MainArmThenArmElseArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseArmThen>> MainArmThenArmElseArmElseArmThen::make(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElseArmElse> parent, Cx& cx) {
    auto why = prism_rtl::cat("an absolute -o needs --runtime PATH or PRISM_ROOT: the runtime's path from ", expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->parent), "the block outlives its rows")->out, " cannot be told from its segments");
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port = prism_rtl::make_new();
    prism_rtl::RcPlace<MainArmThenArmElseArmElseArmThen> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseArmThen(path, value, parent, why, started_2_v_port, gave_up_v_port));
    cx.added(node->path.at(1u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmThenArmElseArmElseArmThen::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->gave_up(unexpected(Error("Prismc.Refused", this->why)), cx);
    return Unit{};
}


/// `!gave_up`.
Unit MainArmThenArmElseArmElseArmThen::gave_up(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->gave_up_v_port->fire(v, cx));
    cx.request(this->path.at(1u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_1`: an answer at its place.
Unit MainArmThenArmElseArmElseArmThen::place_1(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseArmThen::remove_places(Cx& cx) const {
    cx.removed(this->path.at(1u));
    return Unit{};
}


Done MainArmThenArmElseArmElseArmThen::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmThenArmElseArmElseArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u) {
        this->place_1(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseArmElse>> MainArmThenArmElseArmElseArmElse::make(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElseArmElse> parent, Cx& cx) {
    auto prelude_1 = no_slash(or_(option_value(expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->parent), "the block outlives its rows")->opts, Text::lit("--prelude")), Text::lit("prelude")));
    auto settings = crate::reading::CompileSettings{.out = expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->parent), "the block outlives its rows")->out, .prelude = prelude_1, .name = or_(option_value(expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->parent), "the block outlives its rows")->opts, Text::lit("--name")), Text::lit("program")), .runtime = or_(expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->parent), "the block outlives its rows")->runtime, Text::lit("")), .target = expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->parent), "the block outlives its rows")->target};
    auto mode = crate::reading::ReadMode(crate::reading::ReadMode::Compiling{settings});
    auto args = plain_args(expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->parent), "the block outlives its rows")->opts, crate::compile::compile_valued());
    auto prelude_2 = prelude_1;
    auto tests_2 = crate::check::types::has_text(expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->parent), "the block outlives its rows")->opts, Text::lit("--tests"));
    auto dirs = crate::prelude::push(filter(args, [&](const Text& a) { return !crate::reading::is_source_path(a); }), prelude_2);
    prism_rtl::RcPlace<MainArmThenArmElseArmElseArmElse> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseArmElse(path, value, parent, prelude_1, settings, mode, args, prelude_2, tests_2, dirs, {}, {}, snapshot("the dynamic gathered by the `for` at place 0"), std::nullopt, 0u, false));
    TRY(node->rows_build(cx));
    node->rows_all_snap.take(node->rows_all_now(cx), cx);
    TRY(node->generation_build(cx));
    return node;
}


/// `!generation_fired`.
Unit MainArmThenArmElseArmElseArmElse::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
Map<Nat, Text> MainArmThenArmElseArmElseArmElse::rows_source(const Cx& cx) const {
    return this->rows_source_cache.get(cx, [&]() { return indexed(this->dirs); });
}


/// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
Map<Nat, Array<Text>> MainArmThenArmElseArmElseArmElse::rows_all_now(const Cx& cx) const {
    return prism_rtl::fmap(this->rows, [&](const auto& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& row = std::get<1>(_p0);
        return std::tuple{k, row->result(cx)};
    });
}


/// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
Map<Nat, Array<Text>> MainArmThenArmElseArmElseArmElse::rows_all(const Cx& cx) const {
    return this->rows_all_snap.get(cx);
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmThenArmElseArmElseArmElse::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseArmElse::remove_places(Cx& cx) const {
    prism_rtl::for_each(crate::prelude::values(this->rows), [&](auto&& row) { return row->leave_row(cx); });
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
Unit MainArmThenArmElseArmElseArmElse::rows_all_moved(Cx& cx) {
    this->rows_all_snap.mark(cx);
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
Unit MainArmThenArmElseArmElseArmElse::rows_all_publish(Cx& cx) {
    if (this->rows_all_snap.published(cx)) {
        this->generation_stale = true;
        cx.build_later(prism_rtl::share(this));
    }
    return Unit{};
}


/// The rows of the `for` at `this->path.at(0u)`: rows whose key left are torn down, new keys are
/// built under it at `[k]` from the values after the tick; kept rows keep reading their
/// entry out of the source.
Done MainArmThenArmElseArmElseArmElse::rows_build(Cx& cx) {
    Map<Nat, Text> items = rows_source(cx);
    auto old = deref(this->rows);
    for (auto&& [k, row] : old) {
        if (!items.contains(k)) {
            row->leave_row(cx);
            cx.leave_later(row);
        }
    }
    decltype(old) next;
    for (auto&& [k, v] : items) {
        if (auto row = old.get(k)) next.insert(k, *row);
        else next.insert(k, TRY(MainArmThenArmElseArmElseArmElseRow::make(this->path.at(0u).child(Segment::key(prism_rtl::to_pod(k))), k, v, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    }
    deref(this->rows) = next;
    // What the block reads of its rows (a `for` that gives a dynamic) moved.
    cx.dirty(prism_rtl::share(this));
    return {};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThenArmElseArmElseArmElse::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Map<Nat, Array<Text>> value = this->rows_all(cx);
    prism_rtl::Rc<Row> row = TRY(MainArmThenArmElseArmElseArmElseGen1::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx));
    this->generation = row;
    return {};
}


Done MainArmThenArmElseArmElseArmElse::build(Cx& cx) {
    TRY(this->rows_build(cx));
    if (this->rows_all_snap.marked(cx)) {
        this->rows_all_snap.take_compared(this->rows_all_now(cx), cx);
        if (this->rows_all_snap.queue(cx)) {
            auto node = prism_rtl::share(this);
            cx.answer_later([=](Cx& cx) -> Done { node->rows_all_publish(cx); return {}; });
        }
    }
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmThenArmElseArmElseArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Key>(at[1])) {
        auto&& k = prism_rtl::as<pat::Key>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = cloned(this->rows.get(TRY(prism_rtl::from_pod<Nat>(k))));
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(rest, v, cx));
            }
            Unit{};
        });
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseArmElseGen1>> MainArmThenArmElseArmElseArmElseGen1::make(Path path, Map<Nat, Array<Text>> value, prism_rtl::Weak<MainArmThenArmElseArmElseArmElse> parent, Cx& cx) {
    auto mode = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->mode;
    auto args = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args;
    auto prelude = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->prelude_2;
    auto tests = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->tests;
    auto listings = crate::reading::pairs(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->dirs, value);
    auto ups = fold(listings, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& d = std::get<0>(_p1);
        auto&& files = std::get<1>(_p1);
        return crate::reading::is_module_dir(d, files)
            ? crate::check::types::union_texts(acc, crate::reading::ancestors(d))
            : acc;
    });
    prism_rtl::RcPlace<MainArmThenArmElseArmElseArmElseGen1> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseArmElseGen1(path, value, parent, mode, args, prelude, tests, listings, ups, {}, {}, snapshot("the dynamic gathered by the `for` at place 0"), std::nullopt, 0u, false));
    TRY(node->rows_build(cx));
    node->rows_all_snap.take(node->rows_all_now(cx), cx);
    TRY(node->generation_build(cx));
    return node;
}


/// `!generation_fired`.
Unit MainArmThenArmElseArmElseArmElseGen1::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
Map<Nat, Text> MainArmThenArmElseArmElseArmElseGen1::rows_source(const Cx& cx) const {
    return this->rows_source_cache.get(cx, [&]() { return indexed(this->ups); });
}


/// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
Map<Nat, Array<Text>> MainArmThenArmElseArmElseArmElseGen1::rows_all_now(const Cx& cx) const {
    return prism_rtl::fmap(this->rows, [&](const auto& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& row = std::get<1>(_p0);
        return std::tuple{k, row->result(cx)};
    });
}


/// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
Map<Nat, Array<Text>> MainArmThenArmElseArmElseArmElseGen1::rows_all(const Cx& cx) const {
    return this->rows_all_snap.get(cx);
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmThenArmElseArmElseArmElseGen1::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseArmElseGen1::remove_places(Cx& cx) const {
    prism_rtl::for_each(crate::prelude::values(this->rows), [&](auto&& row) { return row->leave_row(cx); });
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
Unit MainArmThenArmElseArmElseArmElseGen1::rows_all_moved(Cx& cx) {
    this->rows_all_snap.mark(cx);
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
Unit MainArmThenArmElseArmElseArmElseGen1::rows_all_publish(Cx& cx) {
    if (this->rows_all_snap.published(cx)) {
        this->generation_stale = true;
        cx.build_later(prism_rtl::share(this));
    }
    return Unit{};
}


/// The rows of the `for` at `this->path.at(0u)`: rows whose key left are torn down, new keys are
/// built under it at `[k]` from the values after the tick; kept rows keep reading their
/// entry out of the source.
Done MainArmThenArmElseArmElseArmElseGen1::rows_build(Cx& cx) {
    Map<Nat, Text> items = rows_source(cx);
    auto old = deref(this->rows);
    for (auto&& [k, row] : old) {
        if (!items.contains(k)) {
            row->leave_row(cx);
            cx.leave_later(row);
        }
    }
    decltype(old) next;
    for (auto&& [k, v] : items) {
        if (auto row = old.get(k)) next.insert(k, *row);
        else next.insert(k, TRY(MainArmThenArmElseArmElseArmElseGen1Row::make(this->path.at(0u).child(Segment::key(prism_rtl::to_pod(k))), k, v, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    }
    deref(this->rows) = next;
    // What the block reads of its rows (a `for` that gives a dynamic) moved.
    cx.dirty(prism_rtl::share(this));
    return {};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThenArmElseArmElseArmElseGen1::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Map<Nat, Array<Text>> value = this->rows_all(cx);
    prism_rtl::Rc<Row> row = TRY(MainArmThenArmElseArmElseArmElseGen1Gen1::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx));
    this->generation = row;
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1::build(Cx& cx) {
    TRY(this->rows_build(cx));
    if (this->rows_all_snap.marked(cx)) {
        this->rows_all_snap.take_compared(this->rows_all_now(cx), cx);
        if (this->rows_all_snap.queue(cx)) {
            auto node = prism_rtl::share(this);
            cx.answer_later([=](Cx& cx) -> Done { node->rows_all_publish(cx); return {}; });
        }
    }
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Key>(at[1])) {
        auto&& k = prism_rtl::as<pat::Key>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = cloned(this->rows.get(TRY(prism_rtl::from_pod<Nat>(k))));
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(rest, v, cx));
            }
            Unit{};
        });
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseArmElseGen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseArmElseGen1Gen1>> MainArmThenArmElseArmElseArmElseGen1Gen1::make(Path path, Map<Nat, Array<Text>> value, prism_rtl::Weak<MainArmThenArmElseArmElseArmElseGen1> parent, Cx& cx) {
    auto mode = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->mode;
    auto args = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args;
    auto prelude = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->prelude;
    auto tests = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->tests;
    auto listings = append(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->listings, crate::reading::pairs(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->ups, value));
    auto paths = crate::reading::to_read(crate::prelude::push(args, prelude), map(listings));
    prism_rtl::RcPlace<MainArmThenArmElseArmElseArmElseGen1Gen1> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseArmElseGen1Gen1(path, value, parent, mode, args, prelude, tests, listings, paths, {}, {}, snapshot("the dynamic gathered by the `for` at place 0"), std::nullopt, 0u, false));
    TRY(node->rows_build(cx));
    node->rows_all_snap.take(node->rows_all_now(cx), cx);
    TRY(node->generation_build(cx));
    return node;
}


/// `!generation_fired`.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
Map<Nat, Text> MainArmThenArmElseArmElseArmElseGen1Gen1::rows_source(const Cx& cx) const {
    return this->rows_source_cache.get(cx, [&]() { return indexed(this->paths); });
}


/// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
Map<Nat, Fallible<crate::fs::Contents>> MainArmThenArmElseArmElseArmElseGen1Gen1::rows_all_now(const Cx& cx) const {
    return prism_rtl::fmap(this->rows, [&](const auto& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& row = std::get<1>(_p0);
        return std::tuple{k, row->result(cx)};
    });
}


/// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
Map<Nat, Fallible<crate::fs::Contents>> MainArmThenArmElseArmElseArmElseGen1Gen1::rows_all(const Cx& cx) const {
    return this->rows_all_snap.get(cx);
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1::remove_places(Cx& cx) const {
    prism_rtl::for_each(crate::prelude::values(this->rows), [&](auto&& row) { return row->leave_row(cx); });
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
Unit MainArmThenArmElseArmElseArmElseGen1Gen1::rows_all_moved(Cx& cx) {
    this->rows_all_snap.mark(cx);
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
Unit MainArmThenArmElseArmElseArmElseGen1Gen1::rows_all_publish(Cx& cx) {
    if (this->rows_all_snap.published(cx)) {
        this->generation_stale = true;
        cx.build_later(prism_rtl::share(this));
    }
    return Unit{};
}


/// The rows of the `for` at `this->path.at(0u)`: rows whose key left are torn down, new keys are
/// built under it at `[k]` from the values after the tick; kept rows keep reading their
/// entry out of the source.
Done MainArmThenArmElseArmElseArmElseGen1Gen1::rows_build(Cx& cx) {
    Map<Nat, Text> items = rows_source(cx);
    auto old = deref(this->rows);
    for (auto&& [k, row] : old) {
        if (!items.contains(k)) {
            row->leave_row(cx);
            cx.leave_later(row);
        }
    }
    decltype(old) next;
    for (auto&& [k, v] : items) {
        if (auto row = old.get(k)) next.insert(k, *row);
        else next.insert(k, TRY(MainArmThenArmElseArmElseArmElseGen1Gen1Row::make(this->path.at(0u).child(Segment::key(prism_rtl::to_pod(k))), k, v, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    }
    deref(this->rows) = next;
    // What the block reads of its rows (a `for` that gives a dynamic) moved.
    cx.dirty(prism_rtl::share(this));
    return {};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThenArmElseArmElseArmElseGen1Gen1::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Map<Nat, Fallible<crate::fs::Contents>> value = this->rows_all(cx);
    prism_rtl::Rc<Row> row = TRY(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx));
    this->generation = row;
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1::build(Cx& cx) {
    TRY(this->rows_build(cx));
    if (this->rows_all_snap.marked(cx)) {
        this->rows_all_snap.take_compared(this->rows_all_now(cx), cx);
        if (this->rows_all_snap.queue(cx)) {
            auto node = prism_rtl::share(this);
            cx.answer_later([=](Cx& cx) -> Done { node->rows_all_publish(cx); return {}; });
        }
    }
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Key>(at[1])) {
        auto&& k = prism_rtl::as<pat::Key>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = cloned(this->rows.get(TRY(prism_rtl::from_pod<Nat>(k))));
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(rest, v, cx));
            }
            Unit{};
        });
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseArmElseGen1Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1>> MainArmThenArmElseArmElseArmElseGen1Gen1Gen1::make(Path path, Map<Nat, Fallible<crate::fs::Contents>> value, prism_rtl::Weak<MainArmThenArmElseArmElseArmElseGen1Gen1> parent, Cx& cx) {
    auto mode = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->mode;
    auto input = crate::reading::ReadInput{.args = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, .prelude = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->prelude, .listings = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->listings, .paths = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->paths, .texts = Array<std::tuple<Text, Text>>{}, .tests = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->tests, .compiling = crate::reading::is_compiling(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->mode)};
    auto contents = value;
    auto failed = fold(crate::check::errors::range0(len(input->paths)), Array<Text>{}, [&](const Array<Text>& acc, const Nat& i) {
        return ({
            auto why = crate::reading::read_failure(crate::prelude::get(contents, i));
            why == Text::lit("")
            ? acc
            : crate::prelude::push(acc, prism_rtl::cat("cannot read ", or_(index(input->paths, i), Text::lit("")), ": ", why));
        });
    });
    auto texts = each(crate::check::errors::range0(len(input->paths)), [&](const Nat& i) { return std::tuple{or_(index(input->paths, i), Text::lit("")), crate::reading::contents_text(or_(crate::prelude::get(contents, i), crate::fs::Contents{.text = Text::lit("")}))}; });
    auto full = ({
        crate::reading::ReadInput this_ = input;
        this_.texts = texts;
        this_;
    });
    prism_rtl::RcPlace<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseArmElseGen1Gen1Gen1(path, value, parent, mode, input, contents, failed, texts, full, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1::remove_places(Cx& cx) const {
    if (auto&& _m = this->arm; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(0u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(0u).child(Segment::gen(g));
    Unit value = Unit{};
    prism_rtl::Rc<Row> row = len(this->failed) > Nat(0u)
    ? static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseArmElseGen1Gen1Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen>> MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen::make(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1> parent, Cx& cx) {
    auto why = crate::syntax::lexer::chars::join(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->failed, Text::lit("; "));
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port = prism_rtl::make_new();
    prism_rtl::RcPlace<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen(path, value, parent, why, started_2_v_port, gave_up_v_port));
    cx.added(node->path.at(1u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->gave_up(unexpected(Error("Prismc.Refused", this->why)), cx);
    return Unit{};
}


/// `!gave_up`.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen::gave_up(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->gave_up_v_port->fire(v, cx));
    cx.request(this->path.at(1u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_1`: an answer at its place.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen::place_1(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen::remove_places(Cx& cx) const {
    cx.removed(this->path.at(1u));
    return Unit{};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u) {
        this->place_1(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse>> MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse::make(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse(path, value, parent, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    return node;
}


/// `!generation_fired`.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse::generation_fired(Unit v, Cx& cx) {
    if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
        auto&& parent = prism_rtl::some_of(_m);
        parent->arm_up(v, cx);
    }
    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse::remove_places(Cx& cx) const {
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path` from the source after the tick.
Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path;
    crate::reading::ReadMode value = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows")->mode;
    prism_rtl::Rc<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<prism_rtl::Rc<Row>> _v;
    auto&& _m = std::tuple{expect(prism_rtl::upgrade(this->parent), "the block outlives its rows")->mode, expect(prism_rtl::upgrade(this->parent), "the block outlives its rows")->full};
    if (prism_rtl::is<crate::reading::ReadMode::Compiling>(std::get<0>(_m))) {
        auto&& s = prism_rtl::as<crate::reading::ReadMode::Compiling>(std::get<0>(_m)).a0;
        auto&& input = std::get<1>(_m);
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0::make(path, s, input, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is<crate::reading::ReadMode::Checking>(std::get<0>(_m))) {
        auto&& o = prism_rtl::as<crate::reading::ReadMode::Checking>(std::get<0>(_m)).a0;
        auto&& input = std::get<1>(_m);
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1::make(path, o, input, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(at, v, cx));
            }
            Unit{};
        });
    } else if (at.size() >= 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u) {
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(at, v, cx));
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0>> MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0::make(Path path, crate::reading::CompileSettings s, crate::reading::ReadInput input, prism_rtl::Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse> parent, Cx& cx) {
    auto s_2 = s;
    auto input_2 = input;
    prism_rtl::Rc<Port<crate::compile::Compiled>> done_v_port = prism_rtl::make_new();
    std::optional<crate::compile::Compiled> outcome_init = std::optional<crate::compile::Compiled>{};
    prism_rtl::RcPlace<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0(path, s, input, parent, s_2, input_2, done_v_port, {crate::compile::start_compile_program(crate::compile::CompileJob{.read = input_2, .name = s_2.name, .runtime = s_2->runtime, .target = s_2->target}), cx}, {}, {}, {}, {outcome_init, cx}, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    cx.on_started(node);
    return node;
}


/// `!done`.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0::done(crate::compile::Compiled v, Cx& cx) {
    prism_rtl::ignore(this->done_v_port->fire(v, cx));
    this->outcome.set(std::optional(v), cx);
    this->generation_stale = true;
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// `@started`, the tick after the build.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0::run_started(Unit v, Cx& cx) {
    this->run_turn_left.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// An `@Defer` firing, the tick after it was armed.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0::run_again_(Unit v, Cx& cx) {
    this->run_turn_right.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// The merge `run_turn`, decided in the wake.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0::run_turn(Unit v, Cx& cx) {
    {
        auto&& _m = this->run_job.get(cx)->cycle();
        if (_m.if_more()) {
            auto&& next = _m.if_more()->next;
            this->run_job.set(next, cx);
            this->run_again.arm(Unit{}, prism_rtl::share(this), cx);
        } else if (_m.if_finished()) {
            auto&& b = _m.if_finished()->value;
            this->done(b, cx);
        }
    }
    return Unit{};
}


/// `!generation_fired`.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0::remove_places(Cx& cx) const {
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    std::optional<crate::compile::Compiled> value = this->outcome.get(cx);
    prism_rtl::Rc<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<prism_rtl::Rc<Row>> _v;
    auto&& _m = std::tuple{this->s_2.out, value};
    if (prism_rtl::is_none(std::get<1>(_m))) {
        auto&& out = std::get<0>(_m);
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen0::make(path, out, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is_some(std::get<1>(_m))) {
        auto&& out = std::get<0>(_m);
        auto&& o = prism_rtl::some_of(std::get<1>(_m));
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1::make(path, out, o, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0::wake(Cx& cx) {
    {
        auto left = this->run_turn_left.take(cx);
        auto right = this->run_turn_right.take(cx);
        if (auto&& _m = left; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        } else if (auto&& _m = right; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        }
    }
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0::started(Cx& cx) {
    this->run_started(Unit{}, cx);
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0::deferred(Cx& cx) {
    if (auto&& _m = this->run_again.fired(cx); prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        this->run_again_(v, cx);
    }
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen0>> MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen0::make(Path path, Text out, prism_rtl::Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen0> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen0(path, out, parent));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen0::remove_places(Cx& cx) const {

    return Unit{};
}


void MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1>> MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1::make(Path path, Text out, crate::compile::Compiled o, prism_rtl::Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0> parent, Cx& cx) {
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port = prism_rtl::make_new();
    prism_rtl::RcPlace<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1(path, out, o, parent, started_2_v_port, verdict_v_port, {}, {}, snapshot("the dynamic gathered by the `for` at place 0")));
    TRY(node->rows_build(cx));
    node->rows_all_snap.take(node->rows_all_now(cx), cx);
    cx.added(node->path.at(2u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->verdict(this->o.failed
        ? unexpected(Error("Prismc.Refused", this->o.report))
        : Expected<std::decay_t<decltype(Unit{})>, std::decay_t<decltype(Error("Prismc.Refused", this->o.report))>>(Unit{}), cx);
    return Unit{};
}


/// `!verdict`.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1::verdict(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->verdict_v_port->fire(v, cx));
    cx.request(this->path.at(2u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_2`: an answer at its place.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1::place_2(Unit v, Cx& cx) {

    return Unit{};
}


/// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
Map<Nat, std::tuple<Text, Text>> MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1::rows_source(const Cx& cx) const {
    return this->rows_source_cache.get(cx, [&]() { return indexed(this->o.files); });
}


/// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
Map<Nat, crate::fs::WriteState> MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1::rows_all_now(const Cx& cx) const {
    return prism_rtl::fmap(this->rows, [&](const auto& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& row = std::get<1>(_p0);
        return std::tuple{k, row->result(cx)};
    });
}


/// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
Map<Nat, crate::fs::WriteState> MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1::rows_all(const Cx& cx) const {
    return this->rows_all_snap.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1::remove_places(Cx& cx) const {
    cx.removed(this->path.at(2u));
    prism_rtl::for_each(crate::prelude::values(this->rows), [&](auto&& row) { return row->leave_row(cx); });
    return Unit{};
}


/// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1::rows_all_moved(Cx& cx) {
    this->rows_all_snap.mark(cx);
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1::rows_all_publish(Cx& cx) {
    if (this->rows_all_snap.published(cx)) {
    }
    return Unit{};
}


/// The rows of the `for` at `this->path.at(0u)`: rows whose key left are torn down, new keys are
/// built under it at `[k]` from the values after the tick; kept rows keep reading their
/// entry out of the source.
Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1::rows_build(Cx& cx) {
    Map<Nat, std::tuple<Text, Text>> items = rows_source(cx);
    auto old = deref(this->rows);
    for (auto&& [k, row] : old) {
        if (!items.contains(k)) {
            row->leave_row(cx);
            cx.leave_later(row);
        }
    }
    decltype(old) next;
    for (auto&& [k, v] : items) {
        if (auto row = old.get(k)) next.insert(k, *row);
        else next.insert(k, TRY(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::make(this->path.at(0u).child(Segment::key(prism_rtl::to_pod(k))), k, v, prism_rtl::weaken(prism_rtl::share(this)), this->out, cx)));
    }
    deref(this->rows) = next;
    // What the block reads of its rows (a `for` that gives a dynamic) moved.
    cx.dirty(prism_rtl::share(this));
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1::build(Cx& cx) {
    TRY(this->rows_build(cx));
    if (this->rows_all_snap.marked(cx)) {
        this->rows_all_snap.take_compared(this->rows_all_now(cx), cx);
        if (this->rows_all_snap.queue(cx)) {
            auto node = prism_rtl::share(this);
            cx.answer_later([=](Cx& cx) -> Done { node->rows_all_publish(cx); return {}; });
        }
    }
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 2u) {
        this->place_2(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Key>(at[1])) {
        auto&& k = prism_rtl::as<pat::Key>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = cloned(this->rows.get(TRY(prism_rtl::from_pod<Nat>(k))));
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(rest, v, cx));
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row>> MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::make(Path path, Nat key, std::tuple<Text, Text> value, prism_rtl::Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1> parent, Text out, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = prism_rtl::cat(out, "/", std::get<0>(value)), .text = std::get<1>(value)}}))), Fault::answer("no first value for Fs.Output")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = prism_rtl::cat(out, "/", std::get<0>(value)), .text = std::get<1>(value)}}));
    prism_rtl::RcPlace<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row(path, key, std::nullopt, parent, out, {TRY(prism_rtl::from_pod<crate::fs::WriteState>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(node->output(cx)));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// Place 0's level, read at the read point.
crate::Elem MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::output(const Cx& cx) const {
    return crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = prism_rtl::cat(this->out, "/", std::get<0>(this->entry(cx))), .text = std::get<1>(this->entry(cx))}});
}


/// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
std::tuple<Text, Text> MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::entry(const Cx& cx) const {
    if (auto&& _m = this->left_entry; prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    auto parent = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows");
    auto&& _m = cloned(parent->rows_source(cx).get(this->key));
    if (prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    if (prism_rtl::is_none(_m)) {
        return expect(cx.before([&](auto&& cx) { return cloned(parent->rows_source(cx).get(this->key)); }), "a row's key is in its source as its tick opened");
    }
    prism_rtl::unreachable("no arm matched");
}


/// The row's result, which the block gathers by key.
crate::fs::WriteState MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::result(const Cx& cx) const {
    return this->place_0.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<crate::fs::WriteState>(v)), cx);
        if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
            auto&& parent = prism_rtl::some_of(_m);
            parent->rows_all_moved(cx);
        }
    }
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::patch(Cx& cx) {
    auto output = this->output(cx);
    cx.changed(this->path.at(0u), prism_rtl::to_pod(output));
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<crate::fs::WriteState>(v)), cx);
            if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
                auto&& parent = prism_rtl::some_of(_m);
                parent->rows_all_moved(cx);
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::leave_row(Cx& cx) {
    this->left_entry = entry(cx);
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1>> MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1::make(Path path, crate::reading::CheckOpts o, crate::reading::ReadInput input, prism_rtl::Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse> parent, Cx& cx) {
    auto o_2 = o;
    auto input_2 = input;
    prism_rtl::Rc<Port<Outcome_>> done_v_port = prism_rtl::make_new();
    std::optional<Outcome_> outcome_init = std::optional<Outcome_>{};
    prism_rtl::RcPlace<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1(path, o, input, parent, o_2, input_2, done_v_port, {crate::checking::start_check_files(crate::checking::CheckJob{.read = input_2, .world = o_2->world, .typed = o_2.typed, .unused = o_2.unused}), cx}, {}, {}, {}, {outcome_init, cx}, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    cx.on_started(node);
    return node;
}


/// `!done`.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1::done(Outcome_ v, Cx& cx) {
    prism_rtl::ignore(this->done_v_port->fire(v, cx));
    this->outcome.set(std::optional(v), cx);
    this->generation_stale = true;
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// `@started`, the tick after the build.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1::run_started(Unit v, Cx& cx) {
    this->run_turn_left.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// An `@Defer` firing, the tick after it was armed.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1::run_again_(Unit v, Cx& cx) {
    this->run_turn_right.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// The merge `run_turn`, decided in the wake.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1::run_turn(Unit v, Cx& cx) {
    {
        auto&& _m = this->run_job.get(cx)->cycle();
        if (_m.if_more()) {
            auto&& next = _m.if_more()->next;
            this->run_job.set(next, cx);
            this->run_again.arm(Unit{}, prism_rtl::share(this), cx);
        } else if (_m.if_finished()) {
            auto&& b = _m.if_finished()->value;
            this->done(b, cx);
        }
    }
    return Unit{};
}


/// `!generation_fired`.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1::remove_places(Cx& cx) const {
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    std::optional<Outcome_> value = this->outcome.get(cx);
    prism_rtl::Rc<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<prism_rtl::Rc<Row>> _v;
    auto&& _m = std::tuple{this->o_2.out, value};
    if (prism_rtl::is_none(std::get<1>(_m))) {
        auto&& out_opt = std::get<0>(_m);
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen0::make(path, out_opt, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is_some(std::get<1>(_m))) {
        auto&& out_opt = std::get<0>(_m);
        auto&& o = prism_rtl::some_of(std::get<1>(_m));
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1::make(path, out_opt, o, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1::wake(Cx& cx) {
    {
        auto left = this->run_turn_left.take(cx);
        auto right = this->run_turn_right.take(cx);
        if (auto&& _m = left; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        } else if (auto&& _m = right; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        }
    }
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1::started(Cx& cx) {
    this->run_started(Unit{}, cx);
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1::deferred(Cx& cx) {
    if (auto&& _m = this->run_again.fired(cx); prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        this->run_again_(v, cx);
    }
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen0>> MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen0::make(Path path, std::optional<Text> out, prism_rtl::Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen0> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen0(path, out, parent));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen0::remove_places(Cx& cx) const {

    return Unit{};
}


void MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1>> MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1::make(Path path, std::optional<Text> out, Outcome_ o, prism_rtl::Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1> parent, Cx& cx) {
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port = prism_rtl::make_new();
    prism_rtl::RcPlace<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1(path, out, o, parent, started_2_v_port, verdict_v_port, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    cx.added(node->path.at(2u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->verdict(this->o.failed
        ? unexpected(Error("Prismc.Refused", this->o.report))
        : Expected<std::decay_t<decltype(Unit{})>, std::decay_t<decltype(Error("Prismc.Refused", this->o.report))>>(Unit{}), cx);
    return Unit{};
}


/// `!verdict`.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1::verdict(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->verdict_v_port->fire(v, cx));
    cx.request(this->path.at(2u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `!generation_fired`.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// `place_2`: an answer at its place.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1::place_2(Unit v, Cx& cx) {

    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1::remove_places(Cx& cx) const {
    cx.removed(this->path.at(2u));
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path` from the source after the tick.
Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path;
    std::optional<Text> value = this->out;
    prism_rtl::Rc<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<prism_rtl::Rc<Row>> _v;
    auto&& _m = std::tuple{this->out, this->o.text};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0::make(path, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& path_ = prism_rtl::some_of(std::get<0>(_m));
        auto&& text = std::get<1>(_m);
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1::make(path, path_, text, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 2u) {
        this->place_2(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else if (at.size() >= 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(at, v, cx));
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0>> MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0::make(Path path, prism_rtl::Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0(path, parent));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0::remove_places(Cx& cx) const {

    return Unit{};
}


void MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1>> MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1::make(Path path, Text path_, Text text, prism_rtl::Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1> parent, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = path_, .text = text}}))), Fault::answer("no first value for Fs.Output")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = path_, .text = text}}));
    prism_rtl::RcPlace<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1(path, path_, text, parent, {TRY(prism_rtl::from_pod<crate::fs::WriteState>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = path_, .text = text}})));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<crate::fs::WriteState>(v)), cx);
    }
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<crate::fs::WriteState>(v)), cx);
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Row>> MainArmThenArmElseArmElseArmElseGen1Gen1Row::make(Path path, Nat key, Text value, prism_rtl::Weak<MainArmThenArmElseArmElseArmElseGen1Gen1> parent, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsContents{crate::fs::FsContents{.path_ = value}}))), Fault::answer("no first value for Fs.Contents")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsContents{crate::fs::FsContents{.path_ = value}}));
    prism_rtl::RcPlace<MainArmThenArmElseArmElseArmElseGen1Gen1Row> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseArmElseGen1Gen1Row(path, key, std::nullopt, parent, {TRY(prism_rtl::from_pod<Fallible<crate::fs::Contents>>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(node->contents_(cx)));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// Place 0's level, read at the read point.
crate::Elem MainArmThenArmElseArmElseArmElseGen1Gen1Row::contents_(const Cx& cx) const {
    return crate::Elem(crate::Elem::FsContents{crate::fs::FsContents{.path_ = this->entry(cx)}});
}


/// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
Text MainArmThenArmElseArmElseArmElseGen1Gen1Row::entry(const Cx& cx) const {
    if (auto&& _m = this->left_entry; prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    auto parent = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows");
    auto&& _m = cloned(parent->rows_source(cx).get(this->key));
    if (prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    if (prism_rtl::is_none(_m)) {
        return expect(cx.before([&](auto&& cx) { return cloned(parent->rows_source(cx).get(this->key)); }), "a row's key is in its source as its tick opened");
    }
    prism_rtl::unreachable("no arm matched");
}


/// The row's result, which the block gathers by key.
Fallible<crate::fs::Contents> MainArmThenArmElseArmElseArmElseGen1Gen1Row::result(const Cx& cx) const {
    return this->place_0.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseArmElseGen1Gen1Row::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Row::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<Fallible<crate::fs::Contents>>(v)), cx);
        if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
            auto&& parent = prism_rtl::some_of(_m);
            parent->rows_all_moved(cx);
        }
    }
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Row::patch(Cx& cx) {
    auto contents = this->contents_(cx);
    cx.changed(this->path.at(0u), prism_rtl::to_pod(contents));
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Gen1Row::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<Fallible<crate::fs::Contents>>(v)), cx);
            if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
                auto&& parent = prism_rtl::some_of(_m);
                parent->rows_all_moved(cx);
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseArmElseGen1Gen1Row::leave_row(Cx& cx) {
    this->left_entry = entry(cx);
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseArmElseGen1Row>> MainArmThenArmElseArmElseArmElseGen1Row::make(Path path, Nat key, Text value, prism_rtl::Weak<MainArmThenArmElseArmElseArmElseGen1> parent, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = value}}))), Fault::answer("no first value for Fs.List")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = value}}));
    prism_rtl::RcPlace<MainArmThenArmElseArmElseArmElseGen1Row> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseArmElseGen1Row(path, key, std::nullopt, parent, {TRY(prism_rtl::from_pod<Array<Text>>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(node->list(cx)));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// Place 0's level, read at the read point.
crate::Elem MainArmThenArmElseArmElseArmElseGen1Row::list(const Cx& cx) const {
    return crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = this->entry(cx)}});
}


/// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
Text MainArmThenArmElseArmElseArmElseGen1Row::entry(const Cx& cx) const {
    if (auto&& _m = this->left_entry; prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    auto parent = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows");
    auto&& _m = cloned(parent->rows_source(cx).get(this->key));
    if (prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    if (prism_rtl::is_none(_m)) {
        return expect(cx.before([&](auto&& cx) { return cloned(parent->rows_source(cx).get(this->key)); }), "a row's key is in its source as its tick opened");
    }
    prism_rtl::unreachable("no arm matched");
}


/// The row's result, which the block gathers by key.
Array<Text> MainArmThenArmElseArmElseArmElseGen1Row::result(const Cx& cx) const {
    return this->place_0.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseArmElseGen1Row::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmThenArmElseArmElseArmElseGen1Row::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<Array<Text>>(v)), cx);
        if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
            auto&& parent = prism_rtl::some_of(_m);
            parent->rows_all_moved(cx);
        }
    }
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Row::patch(Cx& cx) {
    auto list = this->list(cx);
    cx.changed(this->path.at(0u), prism_rtl::to_pod(list));
    return {};
}


Done MainArmThenArmElseArmElseArmElseGen1Row::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<Array<Text>>(v)), cx);
            if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
                auto&& parent = prism_rtl::some_of(_m);
                parent->rows_all_moved(cx);
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseArmElseGen1Row::leave_row(Cx& cx) {
    this->left_entry = entry(cx);
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmThenArmElseArmElseArmElseRow>> MainArmThenArmElseArmElseArmElseRow::make(Path path, Nat key, Text value, prism_rtl::Weak<MainArmThenArmElseArmElseArmElse> parent, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = value}}))), Fault::answer("no first value for Fs.List")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = value}}));
    prism_rtl::RcPlace<MainArmThenArmElseArmElseArmElseRow> _place;
    auto node = _place.take(new (_place.at()) MainArmThenArmElseArmElseArmElseRow(path, key, std::nullopt, parent, {TRY(prism_rtl::from_pod<Array<Text>>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(node->list(cx)));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// Place 0's level, read at the read point.
crate::Elem MainArmThenArmElseArmElseArmElseRow::list(const Cx& cx) const {
    return crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = this->entry(cx)}});
}


/// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
Text MainArmThenArmElseArmElseArmElseRow::entry(const Cx& cx) const {
    if (auto&& _m = this->left_entry; prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    auto parent = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows");
    auto&& _m = cloned(parent->rows_source(cx).get(this->key));
    if (prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    if (prism_rtl::is_none(_m)) {
        return expect(cx.before([&](auto&& cx) { return cloned(parent->rows_source(cx).get(this->key)); }), "a row's key is in its source as its tick opened");
    }
    prism_rtl::unreachable("no arm matched");
}


/// The row's result, which the block gathers by key.
Array<Text> MainArmThenArmElseArmElseArmElseRow::result(const Cx& cx) const {
    return this->place_0.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseArmElseRow::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmThenArmElseArmElseArmElseRow::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<Array<Text>>(v)), cx);
        if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
            auto&& parent = prism_rtl::some_of(_m);
            parent->rows_all_moved(cx);
        }
    }
    return {};
}


Done MainArmThenArmElseArmElseArmElseRow::patch(Cx& cx) {
    auto list = this->list(cx);
    cx.changed(this->path.at(0u), prism_rtl::to_pod(list));
    return {};
}


Done MainArmThenArmElseArmElseArmElseRow::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<Array<Text>>(v)), cx);
            if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
                auto&& parent = prism_rtl::some_of(_m);
                parent->rows_all_moved(cx);
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseArmElseRow::leave_row(Cx& cx) {
    this->left_entry = entry(cx);
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElse>> MainArmElse::make(Path path, Unit value, prism_rtl::Weak<Main> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmElse> _place;
    auto node = _place.take(new (_place.at()) MainArmElse(path, value, parent, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit MainArmElse::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElse::remove_places(Cx& cx) const {
    if (auto&& _m = this->arm; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(0u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElse::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(0u).child(Segment::gen(g));
    Unit value = Unit{};
    prism_rtl::Rc<Row> row = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows")->checking
    ? static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done MainArmElse::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done MainArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThen>> MainArmElseArmThen::make(Path path, Unit value, prism_rtl::Weak<MainArmElse> parent, Cx& cx) {
    auto args = expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->args;
    auto bad = bad_options(args, Array(std::vector{Text::lit("--check"), Text::lit("--typed"), Text::lit("--unused"), Text::lit("--tests")}), crate::checking::check_valued());
    prism_rtl::RcPlace<MainArmElseArmThen> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThen(path, value, parent, args, bad, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit MainArmElseArmThen::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThen::remove_places(Cx& cx) const {
    if (auto&& _m = this->arm; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(0u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmThen::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(0u).child(Segment::gen(g));
    Unit value = Unit{};
    prism_rtl::Rc<Row> row = len(this->bad) > Nat(0u)
    ? static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done MainArmElseArmThen::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done MainArmElseArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmThen>> MainArmElseArmThenArmThen::make(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThen> parent, Cx& cx) {
    auto why = prism_rtl::cat(crate::syntax::lexer::chars::join(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->bad, Text::lit("; ")), " (--check takes --typed, --unused, --tests, --prelude DIR, --out FILE, --world W,...)");
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port = prism_rtl::make_new();
    prism_rtl::RcPlace<MainArmElseArmThenArmThen> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmThen(path, value, parent, why, started_2_v_port, gave_up_v_port));
    cx.added(node->path.at(1u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmElseArmThenArmThen::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->gave_up(unexpected(Error("Prismc.Refused", this->why)), cx);
    return Unit{};
}


/// `!gave_up`.
Unit MainArmElseArmThenArmThen::gave_up(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->gave_up_v_port->fire(v, cx));
    cx.request(this->path.at(1u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_1`: an answer at its place.
Unit MainArmElseArmThenArmThen::place_1(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmThen::remove_places(Cx& cx) const {
    cx.removed(this->path.at(1u));
    return Unit{};
}


Done MainArmElseArmThenArmThen::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmElseArmThenArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u) {
        this->place_1(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElse>> MainArmElseArmThenArmElse::make(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThen> parent, Cx& cx) {
    auto world_1 = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = option_value(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, Text::lit("--world"));
        if (prism_rtl::is_some(_m)) {
            auto&& w = prism_rtl::some_of(_m);
            _v.set(split_on(w, Text::lit(",")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto opts = crate::reading::CheckOpts{.world = world_1, .out = option_value(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, Text::lit("--out")), .typed = crate::check::types::has_text(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, Text::lit("--typed")), .unused = crate::check::types::has_text(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, Text::lit("--unused"))};
    auto mode = crate::reading::ReadMode(crate::reading::ReadMode::Checking{opts});
    auto args = plain_args(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, crate::checking::check_valued());
    auto prelude_2 = no_slash(or_(option_value(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, Text::lit("--prelude")), Text::lit("prelude")));
    auto tests_3 = crate::check::types::has_text(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, Text::lit("--tests"));
    auto dirs = crate::prelude::push(filter(args, [&](const Text& a) { return !crate::reading::is_source_path(a); }), prelude_2);
    prism_rtl::RcPlace<MainArmElseArmThenArmElse> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElse(path, value, parent, world_1, opts, mode, args, prelude_2, tests_3, dirs, {}, {}, snapshot("the dynamic gathered by the `for` at place 0"), std::nullopt, 0u, false));
    TRY(node->rows_build(cx));
    node->rows_all_snap.take(node->rows_all_now(cx), cx);
    TRY(node->generation_build(cx));
    return node;
}


/// `!generation_fired`.
Unit MainArmElseArmThenArmElse::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
Map<Nat, Text> MainArmElseArmThenArmElse::rows_source(const Cx& cx) const {
    return this->rows_source_cache.get(cx, [&]() { return indexed(this->dirs); });
}


/// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
Map<Nat, Array<Text>> MainArmElseArmThenArmElse::rows_all_now(const Cx& cx) const {
    return prism_rtl::fmap(this->rows, [&](const auto& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& row = std::get<1>(_p0);
        return std::tuple{k, row->result(cx)};
    });
}


/// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
Map<Nat, Array<Text>> MainArmElseArmThenArmElse::rows_all(const Cx& cx) const {
    return this->rows_all_snap.get(cx);
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmThenArmElse::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElse::remove_places(Cx& cx) const {
    prism_rtl::for_each(crate::prelude::values(this->rows), [&](auto&& row) { return row->leave_row(cx); });
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
Unit MainArmElseArmThenArmElse::rows_all_moved(Cx& cx) {
    this->rows_all_snap.mark(cx);
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
Unit MainArmElseArmThenArmElse::rows_all_publish(Cx& cx) {
    if (this->rows_all_snap.published(cx)) {
        this->generation_stale = true;
        cx.build_later(prism_rtl::share(this));
    }
    return Unit{};
}


/// The rows of the `for` at `this->path.at(0u)`: rows whose key left are torn down, new keys are
/// built under it at `[k]` from the values after the tick; kept rows keep reading their
/// entry out of the source.
Done MainArmElseArmThenArmElse::rows_build(Cx& cx) {
    Map<Nat, Text> items = rows_source(cx);
    auto old = deref(this->rows);
    for (auto&& [k, row] : old) {
        if (!items.contains(k)) {
            row->leave_row(cx);
            cx.leave_later(row);
        }
    }
    decltype(old) next;
    for (auto&& [k, v] : items) {
        if (auto row = old.get(k)) next.insert(k, *row);
        else next.insert(k, TRY(MainArmElseArmThenArmElseRow::make(this->path.at(0u).child(Segment::key(prism_rtl::to_pod(k))), k, v, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    }
    deref(this->rows) = next;
    // What the block reads of its rows (a `for` that gives a dynamic) moved.
    cx.dirty(prism_rtl::share(this));
    return {};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmThenArmElse::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Map<Nat, Array<Text>> value = this->rows_all(cx);
    prism_rtl::Rc<Row> row = TRY(MainArmElseArmThenArmElseGen1::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx));
    this->generation = row;
    return {};
}


Done MainArmElseArmThenArmElse::build(Cx& cx) {
    TRY(this->rows_build(cx));
    if (this->rows_all_snap.marked(cx)) {
        this->rows_all_snap.take_compared(this->rows_all_now(cx), cx);
        if (this->rows_all_snap.queue(cx)) {
            auto node = prism_rtl::share(this);
            cx.answer_later([=](Cx& cx) -> Done { node->rows_all_publish(cx); return {}; });
        }
    }
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmThenArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Key>(at[1])) {
        auto&& k = prism_rtl::as<pat::Key>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = cloned(this->rows.get(TRY(prism_rtl::from_pod<Nat>(k))));
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(rest, v, cx));
            }
            Unit{};
        });
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1>> MainArmElseArmThenArmElseGen1::make(Path path, Map<Nat, Array<Text>> value, prism_rtl::Weak<MainArmElseArmThenArmElse> parent, Cx& cx) {
    auto mode = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->mode;
    auto args = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args;
    auto prelude = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->prelude;
    auto tests = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->tests;
    auto listings = crate::reading::pairs(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->dirs, value);
    auto ups = fold(listings, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& d = std::get<0>(_p1);
        auto&& files = std::get<1>(_p1);
        return crate::reading::is_module_dir(d, files)
            ? crate::check::types::union_texts(acc, crate::reading::ancestors(d))
            : acc;
    });
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1(path, value, parent, mode, args, prelude, tests, listings, ups, {}, {}, snapshot("the dynamic gathered by the `for` at place 0"), std::nullopt, 0u, false));
    TRY(node->rows_build(cx));
    node->rows_all_snap.take(node->rows_all_now(cx), cx);
    TRY(node->generation_build(cx));
    return node;
}


/// `!generation_fired`.
Unit MainArmElseArmThenArmElseGen1::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
Map<Nat, Text> MainArmElseArmThenArmElseGen1::rows_source(const Cx& cx) const {
    return this->rows_source_cache.get(cx, [&]() { return indexed(this->ups); });
}


/// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
Map<Nat, Array<Text>> MainArmElseArmThenArmElseGen1::rows_all_now(const Cx& cx) const {
    return prism_rtl::fmap(this->rows, [&](const auto& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& row = std::get<1>(_p0);
        return std::tuple{k, row->result(cx)};
    });
}


/// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
Map<Nat, Array<Text>> MainArmElseArmThenArmElseGen1::rows_all(const Cx& cx) const {
    return this->rows_all_snap.get(cx);
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmThenArmElseGen1::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1::remove_places(Cx& cx) const {
    prism_rtl::for_each(crate::prelude::values(this->rows), [&](auto&& row) { return row->leave_row(cx); });
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
Unit MainArmElseArmThenArmElseGen1::rows_all_moved(Cx& cx) {
    this->rows_all_snap.mark(cx);
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
Unit MainArmElseArmThenArmElseGen1::rows_all_publish(Cx& cx) {
    if (this->rows_all_snap.published(cx)) {
        this->generation_stale = true;
        cx.build_later(prism_rtl::share(this));
    }
    return Unit{};
}


/// The rows of the `for` at `this->path.at(0u)`: rows whose key left are torn down, new keys are
/// built under it at `[k]` from the values after the tick; kept rows keep reading their
/// entry out of the source.
Done MainArmElseArmThenArmElseGen1::rows_build(Cx& cx) {
    Map<Nat, Text> items = rows_source(cx);
    auto old = deref(this->rows);
    for (auto&& [k, row] : old) {
        if (!items.contains(k)) {
            row->leave_row(cx);
            cx.leave_later(row);
        }
    }
    decltype(old) next;
    for (auto&& [k, v] : items) {
        if (auto row = old.get(k)) next.insert(k, *row);
        else next.insert(k, TRY(MainArmElseArmThenArmElseGen1Row::make(this->path.at(0u).child(Segment::key(prism_rtl::to_pod(k))), k, v, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    }
    deref(this->rows) = next;
    // What the block reads of its rows (a `for` that gives a dynamic) moved.
    cx.dirty(prism_rtl::share(this));
    return {};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmThenArmElseGen1::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Map<Nat, Array<Text>> value = this->rows_all(cx);
    prism_rtl::Rc<Row> row = TRY(MainArmElseArmThenArmElseGen1Gen1::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx));
    this->generation = row;
    return {};
}


Done MainArmElseArmThenArmElseGen1::build(Cx& cx) {
    TRY(this->rows_build(cx));
    if (this->rows_all_snap.marked(cx)) {
        this->rows_all_snap.take_compared(this->rows_all_now(cx), cx);
        if (this->rows_all_snap.queue(cx)) {
            auto node = prism_rtl::share(this);
            cx.answer_later([=](Cx& cx) -> Done { node->rows_all_publish(cx); return {}; });
        }
    }
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Key>(at[1])) {
        auto&& k = prism_rtl::as<pat::Key>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = cloned(this->rows.get(TRY(prism_rtl::from_pod<Nat>(k))));
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(rest, v, cx));
            }
            Unit{};
        });
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1>> MainArmElseArmThenArmElseGen1Gen1::make(Path path, Map<Nat, Array<Text>> value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1> parent, Cx& cx) {
    auto mode = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->mode;
    auto args = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args;
    auto prelude = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->prelude;
    auto tests = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->tests;
    auto listings = append(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->listings, crate::reading::pairs(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->ups, value));
    auto paths = crate::reading::to_read(crate::prelude::push(args, prelude), map(listings));
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1(path, value, parent, mode, args, prelude, tests, listings, paths, {}, {}, snapshot("the dynamic gathered by the `for` at place 0"), std::nullopt, 0u, false));
    TRY(node->rows_build(cx));
    node->rows_all_snap.take(node->rows_all_now(cx), cx);
    TRY(node->generation_build(cx));
    return node;
}


/// `!generation_fired`.
Unit MainArmElseArmThenArmElseGen1Gen1::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
Map<Nat, Text> MainArmElseArmThenArmElseGen1Gen1::rows_source(const Cx& cx) const {
    return this->rows_source_cache.get(cx, [&]() { return indexed(this->paths); });
}


/// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
Map<Nat, Fallible<crate::fs::Contents>> MainArmElseArmThenArmElseGen1Gen1::rows_all_now(const Cx& cx) const {
    return prism_rtl::fmap(this->rows, [&](const auto& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& row = std::get<1>(_p0);
        return std::tuple{k, row->result(cx)};
    });
}


/// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
Map<Nat, Fallible<crate::fs::Contents>> MainArmElseArmThenArmElseGen1Gen1::rows_all(const Cx& cx) const {
    return this->rows_all_snap.get(cx);
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmThenArmElseGen1Gen1::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1::remove_places(Cx& cx) const {
    prism_rtl::for_each(crate::prelude::values(this->rows), [&](auto&& row) { return row->leave_row(cx); });
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
Unit MainArmElseArmThenArmElseGen1Gen1::rows_all_moved(Cx& cx) {
    this->rows_all_snap.mark(cx);
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
Unit MainArmElseArmThenArmElseGen1Gen1::rows_all_publish(Cx& cx) {
    if (this->rows_all_snap.published(cx)) {
        this->generation_stale = true;
        cx.build_later(prism_rtl::share(this));
    }
    return Unit{};
}


/// The rows of the `for` at `this->path.at(0u)`: rows whose key left are torn down, new keys are
/// built under it at `[k]` from the values after the tick; kept rows keep reading their
/// entry out of the source.
Done MainArmElseArmThenArmElseGen1Gen1::rows_build(Cx& cx) {
    Map<Nat, Text> items = rows_source(cx);
    auto old = deref(this->rows);
    for (auto&& [k, row] : old) {
        if (!items.contains(k)) {
            row->leave_row(cx);
            cx.leave_later(row);
        }
    }
    decltype(old) next;
    for (auto&& [k, v] : items) {
        if (auto row = old.get(k)) next.insert(k, *row);
        else next.insert(k, TRY(MainArmElseArmThenArmElseGen1Gen1Row::make(this->path.at(0u).child(Segment::key(prism_rtl::to_pod(k))), k, v, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    }
    deref(this->rows) = next;
    // What the block reads of its rows (a `for` that gives a dynamic) moved.
    cx.dirty(prism_rtl::share(this));
    return {};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmThenArmElseGen1Gen1::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Map<Nat, Fallible<crate::fs::Contents>> value = this->rows_all(cx);
    prism_rtl::Rc<Row> row = TRY(MainArmElseArmThenArmElseGen1Gen1Gen1::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx));
    this->generation = row;
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1::build(Cx& cx) {
    TRY(this->rows_build(cx));
    if (this->rows_all_snap.marked(cx)) {
        this->rows_all_snap.take_compared(this->rows_all_now(cx), cx);
        if (this->rows_all_snap.queue(cx)) {
            auto node = prism_rtl::share(this);
            cx.answer_later([=](Cx& cx) -> Done { node->rows_all_publish(cx); return {}; });
        }
    }
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Key>(at[1])) {
        auto&& k = prism_rtl::as<pat::Key>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = cloned(this->rows.get(TRY(prism_rtl::from_pod<Nat>(k))));
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(rest, v, cx));
            }
            Unit{};
        });
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1>> MainArmElseArmThenArmElseGen1Gen1Gen1::make(Path path, Map<Nat, Fallible<crate::fs::Contents>> value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1> parent, Cx& cx) {
    auto mode = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->mode;
    auto input = crate::reading::ReadInput{.args = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, .prelude = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->prelude, .listings = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->listings, .paths = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->paths, .texts = Array<std::tuple<Text, Text>>{}, .tests = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->tests, .compiling = crate::reading::is_compiling(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->mode)};
    auto contents = value;
    auto failed = fold(crate::check::errors::range0(len(input->paths)), Array<Text>{}, [&](const Array<Text>& acc, const Nat& i) {
        return ({
            auto why = crate::reading::read_failure(crate::prelude::get(contents, i));
            why == Text::lit("")
            ? acc
            : crate::prelude::push(acc, prism_rtl::cat("cannot read ", or_(index(input->paths, i), Text::lit("")), ": ", why));
        });
    });
    auto texts = each(crate::check::errors::range0(len(input->paths)), [&](const Nat& i) { return std::tuple{or_(index(input->paths, i), Text::lit("")), crate::reading::contents_text(or_(crate::prelude::get(contents, i), crate::fs::Contents{.text = Text::lit("")}))}; });
    auto full = ({
        crate::reading::ReadInput this_ = input;
        this_.texts = texts;
        this_;
    });
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1(path, value, parent, mode, input, contents, failed, texts, full, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1::remove_places(Cx& cx) const {
    if (auto&& _m = this->arm; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(0u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmThenArmElseGen1Gen1Gen1::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(0u).child(Segment::gen(g));
    Unit value = Unit{};
    prism_rtl::Rc<Row> row = len(this->failed) > Nat(0u)
    ? static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen::make(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1> parent, Cx& cx) {
    auto why = crate::syntax::lexer::chars::join(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->failed, Text::lit("; "));
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port = prism_rtl::make_new();
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen(path, value, parent, why, started_2_v_port, gave_up_v_port));
    cx.added(node->path.at(1u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->gave_up(unexpected(Error("Prismc.Refused", this->why)), cx);
    return Unit{};
}


/// `!gave_up`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen::gave_up(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->gave_up_v_port->fire(v, cx));
    cx.request(this->path.at(1u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_1`: an answer at its place.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen::place_1(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen::remove_places(Cx& cx) const {
    cx.removed(this->path.at(1u));
    return Unit{};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u) {
        this->place_1(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse::make(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse(path, value, parent, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    return node;
}


/// `!generation_fired`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse::generation_fired(Unit v, Cx& cx) {
    if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
        auto&& parent = prism_rtl::some_of(_m);
        parent->arm_up(v, cx);
    }
    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse::remove_places(Cx& cx) const {
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path` from the source after the tick.
Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path;
    crate::reading::ReadMode value = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows")->mode;
    prism_rtl::Rc<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<prism_rtl::Rc<Row>> _v;
    auto&& _m = std::tuple{expect(prism_rtl::upgrade(this->parent), "the block outlives its rows")->mode, expect(prism_rtl::upgrade(this->parent), "the block outlives its rows")->full};
    if (prism_rtl::is<crate::reading::ReadMode::Compiling>(std::get<0>(_m))) {
        auto&& s = prism_rtl::as<crate::reading::ReadMode::Compiling>(std::get<0>(_m)).a0;
        auto&& input = std::get<1>(_m);
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0::make(path, s, input, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is<crate::reading::ReadMode::Checking>(std::get<0>(_m))) {
        auto&& o = prism_rtl::as<crate::reading::ReadMode::Checking>(std::get<0>(_m)).a0;
        auto&& input = std::get<1>(_m);
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1::make(path, o, input, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(at, v, cx));
            }
            Unit{};
        });
    } else if (at.size() >= 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u) {
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(at, v, cx));
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0::make(Path path, crate::reading::CompileSettings s, crate::reading::ReadInput input, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse> parent, Cx& cx) {
    auto s_2 = s;
    auto input_2 = input;
    prism_rtl::Rc<Port<crate::compile::Compiled>> done_v_port = prism_rtl::make_new();
    std::optional<crate::compile::Compiled> outcome_init = std::optional<crate::compile::Compiled>{};
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0(path, s, input, parent, s_2, input_2, done_v_port, {crate::compile::start_compile_program(crate::compile::CompileJob{.read = input_2, .name = s_2.name, .runtime = s_2->runtime, .target = s_2->target}), cx}, {}, {}, {}, {outcome_init, cx}, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    cx.on_started(node);
    return node;
}


/// `!done`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0::done(crate::compile::Compiled v, Cx& cx) {
    prism_rtl::ignore(this->done_v_port->fire(v, cx));
    this->outcome.set(std::optional(v), cx);
    this->generation_stale = true;
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// `@started`, the tick after the build.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0::run_started(Unit v, Cx& cx) {
    this->run_turn_left.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// An `@Defer` firing, the tick after it was armed.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0::run_again_(Unit v, Cx& cx) {
    this->run_turn_right.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// The merge `run_turn`, decided in the wake.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0::run_turn(Unit v, Cx& cx) {
    {
        auto&& _m = this->run_job.get(cx)->cycle();
        if (_m.if_more()) {
            auto&& next = _m.if_more()->next;
            this->run_job.set(next, cx);
            this->run_again.arm(Unit{}, prism_rtl::share(this), cx);
        } else if (_m.if_finished()) {
            auto&& b = _m.if_finished()->value;
            this->done(b, cx);
        }
    }
    return Unit{};
}


/// `!generation_fired`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0::remove_places(Cx& cx) const {
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    std::optional<crate::compile::Compiled> value = this->outcome.get(cx);
    prism_rtl::Rc<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<prism_rtl::Rc<Row>> _v;
    auto&& _m = std::tuple{this->s_2.out, value};
    if (prism_rtl::is_none(std::get<1>(_m))) {
        auto&& out = std::get<0>(_m);
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen0::make(path, out, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is_some(std::get<1>(_m))) {
        auto&& out = std::get<0>(_m);
        auto&& o = prism_rtl::some_of(std::get<1>(_m));
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1::make(path, out, o, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0::wake(Cx& cx) {
    {
        auto left = this->run_turn_left.take(cx);
        auto right = this->run_turn_right.take(cx);
        if (auto&& _m = left; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        } else if (auto&& _m = right; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        }
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0::started(Cx& cx) {
    this->run_started(Unit{}, cx);
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0::deferred(Cx& cx) {
    if (auto&& _m = this->run_again.fired(cx); prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        this->run_again_(v, cx);
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen0>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen0::make(Path path, Text out, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen0> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen0(path, out, parent));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen0::remove_places(Cx& cx) const {

    return Unit{};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1::make(Path path, Text out, crate::compile::Compiled o, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0> parent, Cx& cx) {
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port = prism_rtl::make_new();
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1(path, out, o, parent, started_2_v_port, verdict_v_port, {}, {}, snapshot("the dynamic gathered by the `for` at place 0")));
    TRY(node->rows_build(cx));
    node->rows_all_snap.take(node->rows_all_now(cx), cx);
    cx.added(node->path.at(2u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->verdict(this->o.failed
        ? unexpected(Error("Prismc.Refused", this->o.report))
        : Expected<std::decay_t<decltype(Unit{})>, std::decay_t<decltype(Error("Prismc.Refused", this->o.report))>>(Unit{}), cx);
    return Unit{};
}


/// `!verdict`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1::verdict(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->verdict_v_port->fire(v, cx));
    cx.request(this->path.at(2u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_2`: an answer at its place.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1::place_2(Unit v, Cx& cx) {

    return Unit{};
}


/// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
Map<Nat, std::tuple<Text, Text>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1::rows_source(const Cx& cx) const {
    return this->rows_source_cache.get(cx, [&]() { return indexed(this->o.files); });
}


/// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
Map<Nat, crate::fs::WriteState> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1::rows_all_now(const Cx& cx) const {
    return prism_rtl::fmap(this->rows, [&](const auto& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& row = std::get<1>(_p0);
        return std::tuple{k, row->result(cx)};
    });
}


/// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
Map<Nat, crate::fs::WriteState> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1::rows_all(const Cx& cx) const {
    return this->rows_all_snap.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1::remove_places(Cx& cx) const {
    cx.removed(this->path.at(2u));
    prism_rtl::for_each(crate::prelude::values(this->rows), [&](auto&& row) { return row->leave_row(cx); });
    return Unit{};
}


/// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1::rows_all_moved(Cx& cx) {
    this->rows_all_snap.mark(cx);
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1::rows_all_publish(Cx& cx) {
    if (this->rows_all_snap.published(cx)) {
    }
    return Unit{};
}


/// The rows of the `for` at `this->path.at(0u)`: rows whose key left are torn down, new keys are
/// built under it at `[k]` from the values after the tick; kept rows keep reading their
/// entry out of the source.
Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1::rows_build(Cx& cx) {
    Map<Nat, std::tuple<Text, Text>> items = rows_source(cx);
    auto old = deref(this->rows);
    for (auto&& [k, row] : old) {
        if (!items.contains(k)) {
            row->leave_row(cx);
            cx.leave_later(row);
        }
    }
    decltype(old) next;
    for (auto&& [k, v] : items) {
        if (auto row = old.get(k)) next.insert(k, *row);
        else next.insert(k, TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::make(this->path.at(0u).child(Segment::key(prism_rtl::to_pod(k))), k, v, prism_rtl::weaken(prism_rtl::share(this)), this->out, cx)));
    }
    deref(this->rows) = next;
    // What the block reads of its rows (a `for` that gives a dynamic) moved.
    cx.dirty(prism_rtl::share(this));
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1::build(Cx& cx) {
    TRY(this->rows_build(cx));
    if (this->rows_all_snap.marked(cx)) {
        this->rows_all_snap.take_compared(this->rows_all_now(cx), cx);
        if (this->rows_all_snap.queue(cx)) {
            auto node = prism_rtl::share(this);
            cx.answer_later([=](Cx& cx) -> Done { node->rows_all_publish(cx); return {}; });
        }
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 2u) {
        this->place_2(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Key>(at[1])) {
        auto&& k = prism_rtl::as<pat::Key>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = cloned(this->rows.get(TRY(prism_rtl::from_pod<Nat>(k))));
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(rest, v, cx));
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::make(Path path, Nat key, std::tuple<Text, Text> value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1> parent, Text out, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = prism_rtl::cat(out, "/", std::get<0>(value)), .text = std::get<1>(value)}}))), Fault::answer("no first value for Fs.Output")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = prism_rtl::cat(out, "/", std::get<0>(value)), .text = std::get<1>(value)}}));
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row(path, key, std::nullopt, parent, out, {TRY(prism_rtl::from_pod<crate::fs::WriteState>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(node->output(cx)));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// Place 0's level, read at the read point.
crate::Elem MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::output(const Cx& cx) const {
    return crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = prism_rtl::cat(this->out, "/", std::get<0>(this->entry(cx))), .text = std::get<1>(this->entry(cx))}});
}


/// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
std::tuple<Text, Text> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::entry(const Cx& cx) const {
    if (auto&& _m = this->left_entry; prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    auto parent = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows");
    auto&& _m = cloned(parent->rows_source(cx).get(this->key));
    if (prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    if (prism_rtl::is_none(_m)) {
        return expect(cx.before([&](auto&& cx) { return cloned(parent->rows_source(cx).get(this->key)); }), "a row's key is in its source as its tick opened");
    }
    prism_rtl::unreachable("no arm matched");
}


/// The row's result, which the block gathers by key.
crate::fs::WriteState MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::result(const Cx& cx) const {
    return this->place_0.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<crate::fs::WriteState>(v)), cx);
        if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
            auto&& parent = prism_rtl::some_of(_m);
            parent->rows_all_moved(cx);
        }
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::patch(Cx& cx) {
    auto output = this->output(cx);
    cx.changed(this->path.at(0u), prism_rtl::to_pod(output));
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<crate::fs::WriteState>(v)), cx);
            if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
                auto&& parent = prism_rtl::some_of(_m);
                parent->rows_all_moved(cx);
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::leave_row(Cx& cx) {
    this->left_entry = entry(cx);
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1::make(Path path, crate::reading::CheckOpts o, crate::reading::ReadInput input, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse> parent, Cx& cx) {
    auto o_2 = o;
    auto input_2 = input;
    prism_rtl::Rc<Port<Outcome_>> done_v_port = prism_rtl::make_new();
    std::optional<Outcome_> outcome_init = std::optional<Outcome_>{};
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1(path, o, input, parent, o_2, input_2, done_v_port, {crate::checking::start_check_files(crate::checking::CheckJob{.read = input_2, .world = o_2->world, .typed = o_2.typed, .unused = o_2.unused}), cx}, {}, {}, {}, {outcome_init, cx}, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    cx.on_started(node);
    return node;
}


/// `!done`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1::done(Outcome_ v, Cx& cx) {
    prism_rtl::ignore(this->done_v_port->fire(v, cx));
    this->outcome.set(std::optional(v), cx);
    this->generation_stale = true;
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// `@started`, the tick after the build.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1::run_started(Unit v, Cx& cx) {
    this->run_turn_left.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// An `@Defer` firing, the tick after it was armed.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1::run_again_(Unit v, Cx& cx) {
    this->run_turn_right.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// The merge `run_turn`, decided in the wake.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1::run_turn(Unit v, Cx& cx) {
    {
        auto&& _m = this->run_job.get(cx)->cycle();
        if (_m.if_more()) {
            auto&& next = _m.if_more()->next;
            this->run_job.set(next, cx);
            this->run_again.arm(Unit{}, prism_rtl::share(this), cx);
        } else if (_m.if_finished()) {
            auto&& b = _m.if_finished()->value;
            this->done(b, cx);
        }
    }
    return Unit{};
}


/// `!generation_fired`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1::remove_places(Cx& cx) const {
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    std::optional<Outcome_> value = this->outcome.get(cx);
    prism_rtl::Rc<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<prism_rtl::Rc<Row>> _v;
    auto&& _m = std::tuple{this->o_2.out, value};
    if (prism_rtl::is_none(std::get<1>(_m))) {
        auto&& out_opt = std::get<0>(_m);
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen0::make(path, out_opt, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is_some(std::get<1>(_m))) {
        auto&& out_opt = std::get<0>(_m);
        auto&& o = prism_rtl::some_of(std::get<1>(_m));
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1::make(path, out_opt, o, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1::wake(Cx& cx) {
    {
        auto left = this->run_turn_left.take(cx);
        auto right = this->run_turn_right.take(cx);
        if (auto&& _m = left; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        } else if (auto&& _m = right; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        }
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1::started(Cx& cx) {
    this->run_started(Unit{}, cx);
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1::deferred(Cx& cx) {
    if (auto&& _m = this->run_again.fired(cx); prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        this->run_again_(v, cx);
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen0>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen0::make(Path path, std::optional<Text> out, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen0> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen0(path, out, parent));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen0::remove_places(Cx& cx) const {

    return Unit{};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1::make(Path path, std::optional<Text> out, Outcome_ o, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1> parent, Cx& cx) {
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port = prism_rtl::make_new();
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1(path, out, o, parent, started_2_v_port, verdict_v_port, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    cx.added(node->path.at(2u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->verdict(this->o.failed
        ? unexpected(Error("Prismc.Refused", this->o.report))
        : Expected<std::decay_t<decltype(Unit{})>, std::decay_t<decltype(Error("Prismc.Refused", this->o.report))>>(Unit{}), cx);
    return Unit{};
}


/// `!verdict`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1::verdict(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->verdict_v_port->fire(v, cx));
    cx.request(this->path.at(2u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `!generation_fired`.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// `place_2`: an answer at its place.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1::place_2(Unit v, Cx& cx) {

    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1::remove_places(Cx& cx) const {
    cx.removed(this->path.at(2u));
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path` from the source after the tick.
Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path;
    std::optional<Text> value = this->out;
    prism_rtl::Rc<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<prism_rtl::Rc<Row>> _v;
    auto&& _m = std::tuple{this->out, this->o.text};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0::make(path, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& path_ = prism_rtl::some_of(std::get<0>(_m));
        auto&& text = std::get<1>(_m);
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1::make(path, path_, text, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 2u) {
        this->place_2(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else if (at.size() >= 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(at, v, cx));
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0::make(Path path, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0(path, parent));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0::remove_places(Cx& cx) const {

    return Unit{};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1>> MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1::make(Path path, Text path_, Text text, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1> parent, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = path_, .text = text}}))), Fault::answer("no first value for Fs.Output")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = path_, .text = text}}));
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1(path, path_, text, parent, {TRY(prism_rtl::from_pod<crate::fs::WriteState>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = path_, .text = text}})));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<crate::fs::WriteState>(v)), cx);
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<crate::fs::WriteState>(v)), cx);
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Row>> MainArmElseArmThenArmElseGen1Gen1Row::make(Path path, Nat key, Text value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1> parent, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsContents{crate::fs::FsContents{.path_ = value}}))), Fault::answer("no first value for Fs.Contents")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsContents{crate::fs::FsContents{.path_ = value}}));
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Gen1Row> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Gen1Row(path, key, std::nullopt, parent, {TRY(prism_rtl::from_pod<Fallible<crate::fs::Contents>>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(node->contents_(cx)));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// Place 0's level, read at the read point.
crate::Elem MainArmElseArmThenArmElseGen1Gen1Row::contents_(const Cx& cx) const {
    return crate::Elem(crate::Elem::FsContents{crate::fs::FsContents{.path_ = this->entry(cx)}});
}


/// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
Text MainArmElseArmThenArmElseGen1Gen1Row::entry(const Cx& cx) const {
    if (auto&& _m = this->left_entry; prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    auto parent = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows");
    auto&& _m = cloned(parent->rows_source(cx).get(this->key));
    if (prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    if (prism_rtl::is_none(_m)) {
        return expect(cx.before([&](auto&& cx) { return cloned(parent->rows_source(cx).get(this->key)); }), "a row's key is in its source as its tick opened");
    }
    prism_rtl::unreachable("no arm matched");
}


/// The row's result, which the block gathers by key.
Fallible<crate::fs::Contents> MainArmElseArmThenArmElseGen1Gen1Row::result(const Cx& cx) const {
    return this->place_0.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Row::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmElseArmThenArmElseGen1Gen1Row::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<Fallible<crate::fs::Contents>>(v)), cx);
        if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
            auto&& parent = prism_rtl::some_of(_m);
            parent->rows_all_moved(cx);
        }
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Row::patch(Cx& cx) {
    auto contents = this->contents_(cx);
    cx.changed(this->path.at(0u), prism_rtl::to_pod(contents));
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Row::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<Fallible<crate::fs::Contents>>(v)), cx);
            if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
                auto&& parent = prism_rtl::some_of(_m);
                parent->rows_all_moved(cx);
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1Row::leave_row(Cx& cx) {
    this->left_entry = entry(cx);
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Row>> MainArmElseArmThenArmElseGen1Row::make(Path path, Nat key, Text value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1> parent, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = value}}))), Fault::answer("no first value for Fs.List")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = value}}));
    prism_rtl::RcPlace<MainArmElseArmThenArmElseGen1Row> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseGen1Row(path, key, std::nullopt, parent, {TRY(prism_rtl::from_pod<Array<Text>>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(node->list(cx)));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// Place 0's level, read at the read point.
crate::Elem MainArmElseArmThenArmElseGen1Row::list(const Cx& cx) const {
    return crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = this->entry(cx)}});
}


/// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
Text MainArmElseArmThenArmElseGen1Row::entry(const Cx& cx) const {
    if (auto&& _m = this->left_entry; prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    auto parent = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows");
    auto&& _m = cloned(parent->rows_source(cx).get(this->key));
    if (prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    if (prism_rtl::is_none(_m)) {
        return expect(cx.before([&](auto&& cx) { return cloned(parent->rows_source(cx).get(this->key)); }), "a row's key is in its source as its tick opened");
    }
    prism_rtl::unreachable("no arm matched");
}


/// The row's result, which the block gathers by key.
Array<Text> MainArmElseArmThenArmElseGen1Row::result(const Cx& cx) const {
    return this->place_0.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Row::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmElseArmThenArmElseGen1Row::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<Array<Text>>(v)), cx);
        if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
            auto&& parent = prism_rtl::some_of(_m);
            parent->rows_all_moved(cx);
        }
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Row::patch(Cx& cx) {
    auto list = this->list(cx);
    cx.changed(this->path.at(0u), prism_rtl::to_pod(list));
    return {};
}


Done MainArmElseArmThenArmElseGen1Row::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<Array<Text>>(v)), cx);
            if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
                auto&& parent = prism_rtl::some_of(_m);
                parent->rows_all_moved(cx);
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Row::leave_row(Cx& cx) {
    this->left_entry = entry(cx);
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmThenArmElseRow>> MainArmElseArmThenArmElseRow::make(Path path, Nat key, Text value, prism_rtl::Weak<MainArmElseArmThenArmElse> parent, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = value}}))), Fault::answer("no first value for Fs.List")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = value}}));
    prism_rtl::RcPlace<MainArmElseArmThenArmElseRow> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmThenArmElseRow(path, key, std::nullopt, parent, {TRY(prism_rtl::from_pod<Array<Text>>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(node->list(cx)));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// Place 0's level, read at the read point.
crate::Elem MainArmElseArmThenArmElseRow::list(const Cx& cx) const {
    return crate::Elem(crate::Elem::FsList_{crate::fs::FsList_{.dir = this->entry(cx)}});
}


/// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
Text MainArmElseArmThenArmElseRow::entry(const Cx& cx) const {
    if (auto&& _m = this->left_entry; prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    auto parent = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows");
    auto&& _m = cloned(parent->rows_source(cx).get(this->key));
    if (prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    if (prism_rtl::is_none(_m)) {
        return expect(cx.before([&](auto&& cx) { return cloned(parent->rows_source(cx).get(this->key)); }), "a row's key is in its source as its tick opened");
    }
    prism_rtl::unreachable("no arm matched");
}


/// The row's result, which the block gathers by key.
Array<Text> MainArmElseArmThenArmElseRow::result(const Cx& cx) const {
    return this->place_0.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseRow::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmElseArmThenArmElseRow::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<Array<Text>>(v)), cx);
        if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
            auto&& parent = prism_rtl::some_of(_m);
            parent->rows_all_moved(cx);
        }
    }
    return {};
}


Done MainArmElseArmThenArmElseRow::patch(Cx& cx) {
    auto list = this->list(cx);
    cx.changed(this->path.at(0u), prism_rtl::to_pod(list));
    return {};
}


Done MainArmElseArmThenArmElseRow::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<Array<Text>>(v)), cx);
            if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
                auto&& parent = prism_rtl::some_of(_m);
                parent->rows_all_moved(cx);
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseRow::leave_row(Cx& cx) {
    this->left_entry = entry(cx);
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmElse>> MainArmElseArmElse::make(Path path, Unit value, prism_rtl::Weak<MainArmElse> parent, Cx& cx) {
    auto args = expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->args;
    auto tokens_1 = fold(args, false, [&](const bool& seen, const Text& a) { return seen || (a == Text::lit("--tokens")); });
    auto fragment_2 = fold(args, false, [&](const bool& seen, const Text& a) { return seen || (a == Text::lit("--fragment")); });
    auto names = fold(args, Array<Text>{}, [&](const Array<Text>& acc, const Text& a) {
        return crate::syntax::lexer::chars::has_prefix(a, Text::lit("--"))
            ? acc
            : crate::prelude::push(acc, a);
    });
    auto file = or_(index(names, Nat(0u)), Text::lit(""));
    auto out = or_(index(names, Nat(1u)), prism_rtl::cat(file, ".sexp"));
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsContents{crate::fs::FsContents{.path_ = file}}))), Fault::answer("no first value for Fs.Contents")));
    auto source_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsContents{crate::fs::FsContents{.path_ = file}}));
    prism_rtl::RcPlace<MainArmElseArmElse> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmElse(path, value, parent, args, tokens_1, fragment_2, names, file, out, {TRY(prism_rtl::from_pod<Fallible<crate::fs::Contents>>(first_0)), cx}, source_element, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    cx.added(node->path.at(0u), prism_rtl::to_pod(crate::Elem(crate::Elem::FsContents{crate::fs::FsContents{.path_ = file}})));
    cx.listen(node->source_element, static_cast<prism_rtl::Rc<Node>>(node));
    return node;
}


/// `!generation_fired`.
Unit MainArmElseArmElse::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmElse::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmElse::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmElse::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Fallible<crate::fs::Contents> value = this->source.get(cx);
    prism_rtl::Rc<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<prism_rtl::Rc<Row>> _v;
    auto&& _m = std::tuple{Job_{.tokens = this->tokens, .fragment = this->fragment, .text = Text::lit("")}, this->file, this->out, value};
    if (prism_rtl::is_ok(std::get<3>(_m))) {
        auto&& job = std::get<0>(_m);
        auto&& file = std::get<1>(_m);
        auto&& out = std::get<2>(_m);
        auto&& c = *std::get<3>(_m);
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmElseGen0::make(path, job, file, out, c, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is_err(std::get<3>(_m))) {
        auto&& job = std::get<0>(_m);
        auto&& file = std::get<1>(_m);
        auto&& out = std::get<2>(_m);
        auto&& c3 = std::get<3>(_m).error();
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmElseGen1::make(path, job, file, out, c3.message, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmElseArmElse::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmElse::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->source_element) {
        this->source.set(TRY(prism_rtl::from_pod<Fallible<crate::fs::Contents>>(v)), cx);
        this->generation_stale = true;
        cx.build_later(prism_rtl::share(this));
    }
    return {};
}


Done MainArmElseArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->source.set(TRY(prism_rtl::from_pod<Fallible<crate::fs::Contents>>(v)), cx);
            this->generation_stale = true;
            cx.build_later(prism_rtl::share(this));
            Unit{};
        });
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmElseGen0>> MainArmElseArmElseGen0::make(Path path, Job_ job, Text file, Text out, crate::fs::Contents c, prism_rtl::Weak<MainArmElseArmElse> parent, Cx& cx) {
    prism_rtl::Rc<Port<Outcome_>> done_v_port = prism_rtl::make_new();
    auto full = ({
        Job_ this_ = job;
        this_.text = c->text;
        this_;
    });
    std::optional<Outcome_> outcome_init = std::optional<Outcome_>{};
    prism_rtl::RcPlace<MainArmElseArmElseGen0> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmElseGen0(path, job, file, out, c, parent, done_v_port, full, {start_front_end(full), cx}, {}, {}, {}, {outcome_init, cx}, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    cx.on_started(node);
    return node;
}


/// `!done`.
Unit MainArmElseArmElseGen0::done(Outcome_ v, Cx& cx) {
    prism_rtl::ignore(this->done_v_port->fire(v, cx));
    this->outcome.set(std::optional(v), cx);
    this->generation_stale = true;
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// `@started`, the tick after the build.
Unit MainArmElseArmElseGen0::run_started(Unit v, Cx& cx) {
    this->run_turn_left.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// An `@Defer` firing, the tick after it was armed.
Unit MainArmElseArmElseGen0::run_again_(Unit v, Cx& cx) {
    this->run_turn_right.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// The merge `run_turn`, decided in the wake.
Unit MainArmElseArmElseGen0::run_turn(Unit v, Cx& cx) {
    {
        auto&& _m = this->run_job.get(cx)->cycle();
        if (_m.if_more()) {
            auto&& next = _m.if_more()->next;
            this->run_job.set(next, cx);
            this->run_again.arm(Unit{}, prism_rtl::share(this), cx);
        } else if (_m.if_finished()) {
            auto&& b = _m.if_finished()->value;
            this->done(b, cx);
        }
    }
    return Unit{};
}


/// `!generation_fired`.
Unit MainArmElseArmElseGen0::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmElseGen0::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmElseGen0::remove_places(Cx& cx) const {
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmElseGen0::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    std::optional<Outcome_> value = this->outcome.get(cx);
    prism_rtl::Rc<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<prism_rtl::Rc<Row>> _v;
    auto&& _m = std::tuple{this->out, value};
    if (prism_rtl::is_none(std::get<1>(_m))) {
        auto&& out = std::get<0>(_m);
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmElseGen0Gen0::make(path, out, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is_some(std::get<1>(_m))) {
        auto&& out = std::get<0>(_m);
        auto&& o = prism_rtl::some_of(std::get<1>(_m));
        _v.set(static_cast<prism_rtl::Rc<Row>>(TRY(MainArmElseArmElseGen0Gen1::make(path, out, o, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmElseArmElseGen0::wake(Cx& cx) {
    {
        auto left = this->run_turn_left.take(cx);
        auto right = this->run_turn_right.take(cx);
        if (auto&& _m = left; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        } else if (auto&& _m = right; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        }
    }
    return {};
}


Done MainArmElseArmElseGen0::started(Cx& cx) {
    this->run_started(Unit{}, cx);
    return {};
}


Done MainArmElseArmElseGen0::deferred(Cx& cx) {
    if (auto&& _m = this->run_again.fired(cx); prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        this->run_again_(v, cx);
    }
    return {};
}


Done MainArmElseArmElseGen0::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmElseGen0::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmElseGen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmElseGen0Gen0>> MainArmElseArmElseGen0Gen0::make(Path path, Text out, prism_rtl::Weak<MainArmElseArmElseGen0> parent, Cx& cx) {
    prism_rtl::RcPlace<MainArmElseArmElseGen0Gen0> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmElseGen0Gen0(path, out, parent));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmElseArmElseGen0Gen0::remove_places(Cx& cx) const {

    return Unit{};
}


void MainArmElseArmElseGen0Gen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmElseGen0Gen1>> MainArmElseArmElseGen0Gen1::make(Path path, Text out, Outcome_ o, prism_rtl::Weak<MainArmElseArmElseGen0> parent, Cx& cx) {
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port = prism_rtl::make_new();
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = out, .text = o->text}}))), Fault::answer("no first value for Fs.Output")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = out, .text = o->text}}));
    prism_rtl::RcPlace<MainArmElseArmElseGen0Gen1> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmElseGen0Gen1(path, out, o, parent, started_2_v_port, verdict_v_port, {TRY(prism_rtl::from_pod<crate::fs::WriteState>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{crate::fs::FsOutput{.path_ = out, .text = o->text}})));
    cx.listen(node->place_0_element, static_cast<prism_rtl::Rc<Node>>(node));
    cx.added(node->path.at(2u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmElseArmElseGen0Gen1::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->verdict(this->o.failed
        ? unexpected(Error("Prismc.Refused", this->o.report))
        : Expected<std::decay_t<decltype(Unit{})>, std::decay_t<decltype(Error("Prismc.Refused", this->o.report))>>(Unit{}), cx);
    return Unit{};
}


/// `!verdict`.
Unit MainArmElseArmElseGen0Gen1::verdict(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->verdict_v_port->fire(v, cx));
    cx.request(this->path.at(2u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_2`: an answer at its place.
Unit MainArmElseArmElseGen0Gen1::place_2(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmElseGen0Gen1::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    cx.removed(this->path.at(2u));
    return Unit{};
}


Done MainArmElseArmElseGen0Gen1::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmElseArmElseGen0Gen1::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<crate::fs::WriteState>(v)), cx);
    }
    return {};
}


Done MainArmElseArmElseGen0Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 2u) {
        this->place_2(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<crate::fs::WriteState>(v)), cx);
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmElseGen0Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<prism_rtl::Rc<MainArmElseArmElseGen1>> MainArmElseArmElseGen1::make(Path path, Job_ job, Text file, Text out, Text m, prism_rtl::Weak<MainArmElseArmElse> parent, Cx& cx) {
    prism_rtl::Rc<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port = prism_rtl::make_new();
    prism_rtl::RcPlace<MainArmElseArmElseGen1> _place;
    auto node = _place.take(new (_place.at()) MainArmElseArmElseGen1(path, job, file, out, m, parent, started_2_v_port, gave_up_v_port));
    cx.added(node->path.at(1u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmElseArmElseGen1::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->gave_up(unexpected(Error("Prismc.Refused", prism_rtl::cat("cannot read ", this->file, ": ", this->m))), cx);
    return Unit{};
}


/// `!gave_up`.
Unit MainArmElseArmElseGen1::gave_up(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->gave_up_v_port->fire(v, cx));
    cx.request(this->path.at(1u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_1`: an answer at its place.
Unit MainArmElseArmElseGen1::place_1(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmElseGen1::remove_places(Cx& cx) const {
    cx.removed(this->path.at(1u));
    return Unit{};
}


Done MainArmElseArmElseGen1::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmElseArmElseGen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u) {
        this->place_1(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmElseGen1::leave_row(Cx& cx) {
    remove_places(cx);
}


// `@FrontMain` is inlined where it is applied.

// `@Compile` is inlined where it is applied.

// `@Finish` is inlined where it is applied.

}  // namespace crate::program
