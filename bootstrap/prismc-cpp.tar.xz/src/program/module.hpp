// The root module: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <program/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/env/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/passes/types.hpp>
#include <check/shrink/types.hpp>
#include <check/typed/types.hpp>
#include <check/types/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <process/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace program {

Outcome_ front_end(const Job_& job);

prism_rtl::JobRef<Outcome_> start_front_end(Job_ job);

bool any_errors(const Array<crate::syntax::Diag>& ds);

Text render_diags(const Text& text, const Array<crate::syntax::Diag>& ds);

Text render_diag(const Text& text, const Array<Nat>& starts, const crate::syntax::Diag& d);

Array<Nat> line_starts(const Text& text);

Nat line_of(const Array<Nat>& starts, const Nat& offset);

std::optional<Text> option_value(const Array<Text>& args, const Text& name);

Array<Text> bad_options(const Array<Text>& args, const Array<Text>& flags, const Array<Text>& valued);

Array<Text> plain_args(const Array<Text>& args, const Array<Text>& valued);

Text no_slash(const Text& a);

CheckOpts no_check_opts();

CompileSettings no_compile_settings();

Array<std::tuple<Text, Array<Text>>> pairs(const Array<Text>& ds, const Map<Nat, Array<Text>>& m);

Text read_failure(const std::optional<Fallible<crate::fs::Contents>>& opt0);

Text contents_failure(const Fallible<crate::fs::Contents>& arg0);

Text contents_text(const Fallible<crate::fs::Contents>& arg0);

bool is_source_path(const Text& f);

Text dir_of(const Text& p_);

Text base_of(const Text& p_);

Text under(const Text& d, const Text& n);

Array<Text> ancestors(const Text& d);

Text dir_name(const Text& name);

Text mod_of_dir(const Text& d);

Array<HeadLine> header_lines(const Text& text);

std::optional<HeadLine> head_line_of(const Text& line, const Nat& at_);

std::optional<crate::syntax::Range> first_decl_line(const Text& text);

Assembled no_assembly();

crate::syntax::Range no_span();

TreeAcc add_tree_diag(const TreeAcc& acc, const Text& path_, const crate::syntax::Range& span, const Text& code, const Text& message, const Text& fix);

bool is_module_dir(const Text& d, const Array<Text>& files);

bool is_root_dir(const Text& d, const Array<Text>& files);

std::optional<Text> tree_root_of(const Text& d, const Map<Text, Array<Text>>& listings);

Array<Text> to_read(const Array<Text>& args, const Map<Text, Array<Text>>& listings);

Assembled assemble(const ReadInput& input);

prism_rtl::JobRef<Assembled> start_assemble(ReadInput input);

ModFiles kept_segs(const ModFiles& u, const bool& tests);

Assembled add_arg(const Assembled& acc, const Map<Text, Array<Text>>& listings, const Map<Text, Text>& texts, const Text& a);

prism_rtl::JobRef<Assembled> start_add_arg(Assembled acc, Map<Text, Array<Text>> listings, Map<Text, Text> texts, Text a);

Text main_path(const ModFiles& u);

Text main_text(const ModFiles& u);

Array<Text> test_paths(const ModFiles& u);

TreeAcc walk_tree(const Text& root, const Array<Text>& files, const Map<Text, Text>& texts);

prism_rtl::JobRef<TreeAcc> start_walk_tree(Text root, Array<Text> files, Map<Text, Text> texts);

TreeAcc walk_lib(const Map<Text, bool>& has, const Map<Text, Text>& texts, const TreeAcc& acc, const Text& lib);

prism_rtl::JobRef<TreeAcc> start_walk_lib(Map<Text, bool> has, Map<Text, Text> texts, TreeAcc acc, Text lib);

TreeAcc walk_module(const Map<Text, bool>& has, const Map<Text, Text>& texts, const TreeAcc& acc, const Text& main, const Text& name);

prism_rtl::JobRef<TreeAcc> start_walk_module(Map<Text, bool> has, Map<Text, Text> texts, TreeAcc acc, Text main, Text name);

TreeAcc submodule(const Map<Text, bool>& has, const Map<Text, Text>& texts, const TreeAcc& acc, const Text& main, const Text& dir, const HeadLine& h, const Text& parent);

prism_rtl::JobRef<TreeAcc> start_submodule(Map<Text, bool> has, Map<Text, Text> texts, TreeAcc acc, Text main, Text dir, HeadLine h, Text parent);

TreeAcc stray(const Map<Text, bool>& has, const Map<Text, Text>& texts, const TreeAcc& acc, const Text& f);

Array<ModFiles> reach_tree(const Array<ModFiles>& units, const Text& main);

prism_rtl::JobRef<Array<ModFiles>> start_reach_tree(Array<ModFiles> units, Text main);

Array<Text> reach_names(const Map<Text, ModFiles>& by_name, const Array<Text>& seen, const Array<Text>& todo);

prism_rtl::JobRef<Array<Text>> start_reach_names(Map<Text, ModFiles> by_name, Array<Text> seen, Array<Text> todo);

Text unit_name(const ModFiles& u);

Text render_tree_diag(const Map<Text, Text>& texts, const TreeDiag& d);

Text tree_report(const ReadInput& input, const Array<TreeDiag>& ds);

std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed> parse_unit(const ModFiles& u);

prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> start_parse_unit(ModFiles u);

ParsedProgram parse_program(const Assembled& read);

prism_rtl::JobRef<ParsedProgram> start_parse_program(Assembled read);

Array<crate::check::errors::CDiag> warning_diags(const Array<crate::check::errors::Src>& srcs, const Array<TreeDiag>& ws);

Array<crate::check::errors::CDiag> tree_decl_diags(const Array<crate::check::errors::Src>& srcs, const Array<crate::syntax::Module>& trees, const Nat& shown);

Array<crate::check::errors::CDiag> decl_role_diags(const crate::check::errors::Src& src, const Nat& i, const crate::syntax::Decl& d);

Array<Text> tag_families(const crate::syntax::Module& m);

bool any_in(const Array<Text>& xs, const Array<Text>& ys);

Text render_parse(const crate::check::errors::Src& src, const Array<crate::syntax::Diag>& ds);

Outcome_ check_files(const CheckJob& job);

prism_rtl::JobRef<Outcome_> start_check_files(CheckJob job);

Text commented(const Text& t);

Array<Text> check_valued();

Array<Text> compile_valued();

Text runtime_for(const Text& out);

Compiled compile_program(const CompileJob& job);

prism_rtl::JobRef<Compiled> start_compile_program(CompileJob job);

Array<Text> refusals(const Text& text);

crate::syntax::Module without_tests(const crate::syntax::Module& m);

crate::syntax::Decl without_patterns(const crate::syntax::Decl& d);

crate::syntax::CheckDecl check_without_patterns(const crate::syntax::CheckDecl& c);

crate::syntax::CheckLine line_without_pattern(const crate::syntax::CheckLine& l);

bool is_test_decl(const crate::syntax::Decl& d);

}  // namespace program


namespace program {

/// The step machine of `FrontEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FrontEnd: unbounded fn Job -> Outcome
struct FrontEnd : prism_rtl::Job<Outcome_> {
    Job_ job;
    FrontEnd(Job_ job) : job(std::move(job)) {}
    prism_rtl::Turn<Outcome_> cycle() const override;
};


/// `@main`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
/// @main:
///     args <- Process.Args
///     let checking = Fold args, False, \|seen, a| seen or a == "--check" or a == "--typed"
///     let compiling = (Or args[0], "") == "compile"
///     if compiling: @CompileMain (Drop args, 1)
///     else: if checking: @CheckMain args
///     else: @FrontMain args
/// ```
class Main : public Node {
public:
    Path path;
    /// place 0's answer, its first value
    Array<Text> args;
    /// `checking`
    bool checking;
    /// `compiling`
    bool compiling;
    /// the current generation of the `rebuild` at place 1
    std::optional<prism_rtl::Rc<Row>> arm;
    /// how many generations it has built
    std::uint32_t arm_count;
    /// its source changed since it was built
    bool arm_stale;
    Main(Path path, Array<Text> args, bool checking, bool compiling, std::optional<prism_rtl::Rc<Row>> arm, std::uint32_t arm_count, bool arm_stale) : path(std::move(path)), args(std::move(args)), checking(std::move(checking)), compiling(std::move(compiling)), arm(std::move(arm)), arm_count(std::move(arm_count)), arm_stale(std::move(arm_stale)) {}
    Main(const Main&) = delete;
    static Result<prism_rtl::Rc<Main>> make(Path path, Cx& cx);
    Unit arm_up(Unit v, Cx& cx);
    Done arm_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
};


/// `MainArmThen`: a node of its own (docs/backend.md, "A widget block").
class MainArmThen : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<Main> parent;
    /// `opts`
    Array<Text> opts;
    /// `bad`
    Array<Text> bad;
    /// `target`
    Text target;
    /// the current generation of the `rebuild` at place 0
    std::optional<prism_rtl::Rc<Row>> arm;
    /// how many generations it has built
    std::uint32_t arm_count;
    /// its source changed since it was built
    bool arm_stale;
    MainArmThen(Path path, Unit value, prism_rtl::Weak<Main> parent, Array<Text> opts, Array<Text> bad, Text target, std::optional<prism_rtl::Rc<Row>> arm, std::uint32_t arm_count, bool arm_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), opts(std::move(opts)), bad(std::move(bad)), target(std::move(target)), arm(std::move(arm)), arm_count(std::move(arm_count)), arm_stale(std::move(arm_stale)) {}
    MainArmThen(const MainArmThen&) = delete;
    static Result<prism_rtl::Rc<MainArmThen>> make(Path path, Unit value, prism_rtl::Weak<Main> parent, Cx& cx);
    Unit arm_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done arm_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmThen`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmThen : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThen> parent;
    /// `why`
    Text why;
    /// `!started` as a value: the port it fires
    prism_rtl::Rc<Port<Unit>> started_2_v_port;
    /// `!~gaveUp` as a value: the port it fires
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port;
    MainArmThenArmThen(Path path, Unit value, prism_rtl::Weak<MainArmThen> parent, Text why, prism_rtl::Rc<Port<Unit>> started_2_v_port, prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), why(std::move(why)), started_2_v_port(std::move(started_2_v_port)), gave_up_v_port(std::move(gave_up_v_port)) {}
    MainArmThenArmThen(const MainArmThenArmThen&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmThen>> make(Path path, Unit value, prism_rtl::Weak<MainArmThen> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit gave_up(Fallible<Unit> v, Cx& cx);
    Unit place_1(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done started(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElse`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElse : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThen> parent;
    /// the current generation of the `rebuild` at place 0
    std::optional<prism_rtl::Rc<Row>> arm;
    /// how many generations it has built
    std::uint32_t arm_count;
    /// its source changed since it was built
    bool arm_stale;
    MainArmThenArmElse(Path path, Unit value, prism_rtl::Weak<MainArmThen> parent, std::optional<prism_rtl::Rc<Row>> arm, std::uint32_t arm_count, bool arm_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), arm(std::move(arm)), arm_count(std::move(arm_count)), arm_stale(std::move(arm_stale)) {}
    MainArmThenArmElse(const MainArmThenArmElse&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElse>> make(Path path, Unit value, prism_rtl::Weak<MainArmThen> parent, Cx& cx);
    Unit arm_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done arm_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmThen`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmThen : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThenArmElse> parent;
    /// `why`
    Text why;
    /// `!started` as a value: the port it fires
    prism_rtl::Rc<Port<Unit>> started_2_v_port;
    /// `!~gaveUp` as a value: the port it fires
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port;
    MainArmThenArmElseArmThen(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElse> parent, Text why, prism_rtl::Rc<Port<Unit>> started_2_v_port, prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), why(std::move(why)), started_2_v_port(std::move(started_2_v_port)), gave_up_v_port(std::move(gave_up_v_port)) {}
    MainArmThenArmElseArmThen(const MainArmThenArmElseArmThen&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmThen>> make(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElse> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit gave_up(Fallible<Unit> v, Cx& cx);
    Unit place_1(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done started(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElse`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElse : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThenArmElse> parent;
    /// `out`
    Text out;
    /// `prelude`
    Text prelude;
    /// `settings`
    CompileSettings settings;
    /// `mode`
    ReadMode mode;
    /// `args`
    Array<Text> args;
    /// `prelude`
    Text prelude_2;
    /// `tests`
    bool tests;
    /// `dirs`
    Array<Text> dirs;
    /// the source of the `for` at place 0, cached (gap SR)
    Cache<Map<Nat, Text>> rows_source_cache;
    /// the rows of the `for` at place 0
    Map<Nat, prism_rtl::Rc<MainArmThenArmElseArmElseRow>> rows;
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    Snapshot<Map<Nat, Array<Text>>> rows_all_snap;
    /// the current generation of the `rebuild` at place 1
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    MainArmThenArmElseArmElse(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElse> parent, Text out, Text prelude, CompileSettings settings, ReadMode mode, Array<Text> args, Text prelude_2, bool tests, Array<Text> dirs, Cache<Map<Nat, Text>> rows_source_cache, Map<Nat, prism_rtl::Rc<MainArmThenArmElseArmElseRow>> rows, Snapshot<Map<Nat, Array<Text>>> rows_all_snap, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), out(std::move(out)), prelude(std::move(prelude)), settings(std::move(settings)), mode(std::move(mode)), args(std::move(args)), prelude_2(std::move(prelude_2)), tests(std::move(tests)), dirs(std::move(dirs)), rows_source_cache(std::move(rows_source_cache)), rows(std::move(rows)), rows_all_snap(std::move(rows_all_snap)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmThenArmElseArmElse(const MainArmThenArmElseArmElse&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElse>> make(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElse> parent, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Map<Nat, Text> rows_source(const Cx& cx) const;
    Map<Nat, Array<Text>> rows_all_now(const Cx& cx) const;
    Map<Nat, Array<Text>> rows_all(const Cx& cx) const;
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Unit rows_all_moved(Cx& cx);
    Unit rows_all_publish(Cx& cx);
    Done rows_build(Cx& cx);
    Done generation_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1 : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Map<Nat, Array<Text>> value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThenArmElseArmElse> parent;
    /// `mode`
    ReadMode mode;
    /// `args`
    Array<Text> args;
    /// `prelude`
    Text prelude;
    /// `tests`
    bool tests;
    /// `listings`
    Array<std::tuple<Text, Array<Text>>> listings;
    /// `ups`
    Array<Text> ups;
    /// the source of the `for` at place 0, cached (gap SR)
    Cache<Map<Nat, Text>> rows_source_cache;
    /// the rows of the `for` at place 0
    Map<Nat, prism_rtl::Rc<MainArmThenArmElseArmElseGen1Row>> rows;
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    Snapshot<Map<Nat, Array<Text>>> rows_all_snap;
    /// the current generation of the `rebuild` at place 1
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    MainArmThenArmElseArmElseGen1(Path path, Map<Nat, Array<Text>> value, prism_rtl::Weak<MainArmThenArmElseArmElse> parent, ReadMode mode, Array<Text> args, Text prelude, bool tests, Array<std::tuple<Text, Array<Text>>> listings, Array<Text> ups, Cache<Map<Nat, Text>> rows_source_cache, Map<Nat, prism_rtl::Rc<MainArmThenArmElseArmElseGen1Row>> rows, Snapshot<Map<Nat, Array<Text>>> rows_all_snap, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), mode(std::move(mode)), args(std::move(args)), prelude(std::move(prelude)), tests(std::move(tests)), listings(std::move(listings)), ups(std::move(ups)), rows_source_cache(std::move(rows_source_cache)), rows(std::move(rows)), rows_all_snap(std::move(rows_all_snap)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmThenArmElseArmElseGen1(const MainArmThenArmElseArmElseGen1&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1>> make(Path path, Map<Nat, Array<Text>> value, prism_rtl::Weak<MainArmThenArmElseArmElse> parent, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Map<Nat, Text> rows_source(const Cx& cx) const;
    Map<Nat, Array<Text>> rows_all_now(const Cx& cx) const;
    Map<Nat, Array<Text>> rows_all(const Cx& cx) const;
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Unit rows_all_moved(Cx& cx);
    Unit rows_all_publish(Cx& cx);
    Done rows_build(Cx& cx);
    Done generation_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1 : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Map<Nat, Array<Text>> value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThenArmElseArmElseGen1> parent;
    /// `mode`
    ReadMode mode;
    /// `args`
    Array<Text> args;
    /// `prelude`
    Text prelude;
    /// `tests`
    bool tests;
    /// `listings`
    Array<std::tuple<Text, Array<Text>>> listings;
    /// `paths`
    Array<Text> paths;
    /// the source of the `for` at place 0, cached (gap SR)
    Cache<Map<Nat, Text>> rows_source_cache;
    /// the rows of the `for` at place 0
    Map<Nat, prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Row>> rows;
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    Snapshot<Map<Nat, Fallible<crate::fs::Contents>>> rows_all_snap;
    /// the current generation of the `rebuild` at place 1
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    MainArmThenArmElseArmElseGen1Gen1(Path path, Map<Nat, Array<Text>> value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1> parent, ReadMode mode, Array<Text> args, Text prelude, bool tests, Array<std::tuple<Text, Array<Text>>> listings, Array<Text> paths, Cache<Map<Nat, Text>> rows_source_cache, Map<Nat, prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Row>> rows, Snapshot<Map<Nat, Fallible<crate::fs::Contents>>> rows_all_snap, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), mode(std::move(mode)), args(std::move(args)), prelude(std::move(prelude)), tests(std::move(tests)), listings(std::move(listings)), paths(std::move(paths)), rows_source_cache(std::move(rows_source_cache)), rows(std::move(rows)), rows_all_snap(std::move(rows_all_snap)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmThenArmElseArmElseGen1Gen1(const MainArmThenArmElseArmElseGen1Gen1&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1>> make(Path path, Map<Nat, Array<Text>> value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1> parent, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Map<Nat, Text> rows_source(const Cx& cx) const;
    Map<Nat, Fallible<crate::fs::Contents>> rows_all_now(const Cx& cx) const;
    Map<Nat, Fallible<crate::fs::Contents>> rows_all(const Cx& cx) const;
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Unit rows_all_moved(Cx& cx);
    Unit rows_all_publish(Cx& cx);
    Done rows_build(Cx& cx);
    Done generation_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1Gen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1Gen1 : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Map<Nat, Fallible<crate::fs::Contents>> value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1> parent;
    /// `mode`
    ReadMode mode;
    /// `input`
    ReadInput input;
    /// `contents`
    Map<Nat, Fallible<crate::fs::Contents>> contents;
    /// `failed`
    Array<Text> failed;
    /// `texts`
    Array<std::tuple<Text, Text>> texts;
    /// `full`
    ReadInput full;
    /// the current generation of the `rebuild` at place 0
    std::optional<prism_rtl::Rc<Row>> arm;
    /// how many generations it has built
    std::uint32_t arm_count;
    /// its source changed since it was built
    bool arm_stale;
    MainArmThenArmElseArmElseGen1Gen1Gen1(Path path, Map<Nat, Fallible<crate::fs::Contents>> value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1> parent, ReadMode mode, ReadInput input, Map<Nat, Fallible<crate::fs::Contents>> contents, Array<Text> failed, Array<std::tuple<Text, Text>> texts, ReadInput full, std::optional<prism_rtl::Rc<Row>> arm, std::uint32_t arm_count, bool arm_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), mode(std::move(mode)), input(std::move(input)), contents(std::move(contents)), failed(std::move(failed)), texts(std::move(texts)), full(std::move(full)), arm(std::move(arm)), arm_count(std::move(arm_count)), arm_stale(std::move(arm_stale)) {}
    MainArmThenArmElseArmElseGen1Gen1Gen1(const MainArmThenArmElseArmElseGen1Gen1Gen1&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1>> make(Path path, Map<Nat, Fallible<crate::fs::Contents>> value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1> parent, Cx& cx);
    Unit arm_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done arm_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1> parent;
    /// `why`
    Text why;
    /// `!started` as a value: the port it fires
    prism_rtl::Rc<Port<Unit>> started_2_v_port;
    /// `!~gaveUp` as a value: the port it fires
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port;
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1> parent, Text why, prism_rtl::Rc<Port<Unit>> started_2_v_port, prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), why(std::move(why)), started_2_v_port(std::move(started_2_v_port)), gave_up_v_port(std::move(gave_up_v_port)) {}
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen(const MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen>> make(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit gave_up(Fallible<Unit> v, Cx& cx);
    Unit place_1(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done started(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1> parent;
    /// the current generation of the `rebuild` at place 0
    std::optional<prism_rtl::Rc<Row>> arm;
    /// how many generations it has built
    std::uint32_t arm_count;
    /// its source changed since it was built
    bool arm_stale;
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1> parent, std::optional<prism_rtl::Rc<Row>> arm, std::uint32_t arm_count, bool arm_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), arm(std::move(arm)), arm_count(std::move(arm_count)), arm_stale(std::move(arm_stale)) {}
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse(const MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse>> make(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1> parent, Cx& cx);
    Unit arm_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done arm_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse> parent;
    /// `s`
    CompileSettings s;
    /// `input`
    ReadInput input;
    /// `!done` as a value: the port it fires
    prism_rtl::Rc<Port<Compiled>> done_v_port;
    /// `@Run`'s job (`@Machine`'s state)
    Hold<prism_rtl::JobRef<Compiled>> run_job;
    /// `@Run`'s `!again`
    Defer<Unit> run_again;
    /// `run_turn`'s left input
    Stamped<Unit> run_turn_left;
    /// its right input
    Stamped<Unit> run_turn_right;
    /// `$?outcome`
    Hold<std::optional<Compiled>> outcome;
    /// the current generation of the `rebuild` at place 1
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    /// The merges' height above the node's inputs.
    static constexpr std::uint32_t WAKE = 1;
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse> parent, CompileSettings s, ReadInput input, prism_rtl::Rc<Port<Compiled>> done_v_port, Hold<prism_rtl::JobRef<Compiled>> run_job, Defer<Unit> run_again, Stamped<Unit> run_turn_left, Stamped<Unit> run_turn_right, Hold<std::optional<Compiled>> outcome, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), s(std::move(s)), input(std::move(input)), done_v_port(std::move(done_v_port)), run_job(std::move(run_job)), run_again(std::move(run_again)), run_turn_left(std::move(run_turn_left)), run_turn_right(std::move(run_turn_right)), outcome(std::move(outcome)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen(const MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen>> make(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse> parent, Cx& cx);
    Unit done(Compiled v, Cx& cx);
    Unit run_started(Unit v, Cx& cx);
    Unit run_again_(Unit v, Cx& cx);
    Unit run_turn(Unit v, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done generation_build(Cx& cx);
    Done wake(Cx& cx) override;
    Done started(Cx& cx) override;
    Done deferred(Cx& cx) override;
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0 : public Row {
public:
    Path path;
    /// `out`
    Text out;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen> parent;
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0(Path path, Text out, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen> parent) : path(std::move(path)), out(std::move(out)), parent(std::move(parent)) {}
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0(const MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0>> make(Path path, Text out, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen> parent, Cx& cx);
    Unit remove_places(Cx& cx) const;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1 : public Row {
public:
    Path path;
    /// `out`
    Text out;
    /// `o`
    Compiled o;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen> parent;
    /// `!started` as a value: the port it fires
    prism_rtl::Rc<Port<Unit>> started_2_v_port;
    /// `!~verdict` as a value: the port it fires
    prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port;
    /// the source of the `for` at place 0, cached (gap SR)
    Cache<Map<Nat, std::tuple<Text, Text>>> rows_source_cache;
    /// the rows of the `for` at place 0
    Map<Nat, prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row>> rows;
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    Snapshot<Map<Nat, crate::fs::WriteState>> rows_all_snap;
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1(Path path, Text out, Compiled o, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen> parent, prism_rtl::Rc<Port<Unit>> started_2_v_port, prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port, Cache<Map<Nat, std::tuple<Text, Text>>> rows_source_cache, Map<Nat, prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row>> rows, Snapshot<Map<Nat, crate::fs::WriteState>> rows_all_snap) : path(std::move(path)), out(std::move(out)), o(std::move(o)), parent(std::move(parent)), started_2_v_port(std::move(started_2_v_port)), verdict_v_port(std::move(verdict_v_port)), rows_source_cache(std::move(rows_source_cache)), rows(std::move(rows)), rows_all_snap(std::move(rows_all_snap)) {}
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1(const MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1>> make(Path path, Text out, Compiled o, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit verdict(Fallible<Unit> v, Cx& cx);
    Unit place_2(Unit v, Cx& cx);
    Map<Nat, std::tuple<Text, Text>> rows_source(const Cx& cx) const;
    Map<Nat, crate::fs::WriteState> rows_all_now(const Cx& cx) const;
    Map<Nat, crate::fs::WriteState> rows_all(const Cx& cx) const;
    Unit remove_places(Cx& cx) const;
    Unit rows_all_moved(Cx& cx);
    Unit rows_all_publish(Cx& cx);
    Done rows_build(Cx& cx);
    Done started(Cx& cx) override;
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row : public Row {
public:
    Path path;
    /// the row's key
    Nat key;
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    std::optional<std::tuple<Text, Text>> left_entry;
    /// the node of the `for`
    prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1> parent;
    /// `out`, the block's
    Text out;
    /// pushed to place 0
    Hold<crate::fs::WriteState> place_0;
    /// place 0's element, which pushes are keyed by
    Pod place_0_element;
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row(Path path, Nat key, std::optional<std::tuple<Text, Text>> left_entry, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1> parent, Text out, Hold<crate::fs::WriteState> place_0, Pod place_0_element) : path(std::move(path)), key(std::move(key)), left_entry(std::move(left_entry)), parent(std::move(parent)), out(std::move(out)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row(const MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row>> make(Path path, Nat key, std::tuple<Text, Text> value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1> parent, Text out, Cx& cx);
    crate::Elem output(const Cx& cx) const;
    std::tuple<Text, Text> entry(const Cx& cx) const;
    crate::fs::WriteState result(const Cx& cx) const;
    Unit remove_places(Cx& cx) const;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done patch(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse> parent;
    /// `o`
    CheckOpts o;
    /// `input`
    ReadInput input;
    /// `!done` as a value: the port it fires
    prism_rtl::Rc<Port<Outcome_>> done_v_port;
    /// `@Run`'s job (`@Machine`'s state)
    Hold<prism_rtl::JobRef<Outcome_>> run_job;
    /// `@Run`'s `!again`
    Defer<Unit> run_again;
    /// `run_turn`'s left input
    Stamped<Unit> run_turn_left;
    /// its right input
    Stamped<Unit> run_turn_right;
    /// `$?outcome`
    Hold<std::optional<Outcome_>> outcome;
    /// the current generation of the `rebuild` at place 1
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    /// The merges' height above the node's inputs.
    static constexpr std::uint32_t WAKE = 1;
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse> parent, CheckOpts o, ReadInput input, prism_rtl::Rc<Port<Outcome_>> done_v_port, Hold<prism_rtl::JobRef<Outcome_>> run_job, Defer<Unit> run_again, Stamped<Unit> run_turn_left, Stamped<Unit> run_turn_right, Hold<std::optional<Outcome_>> outcome, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), o(std::move(o)), input(std::move(input)), done_v_port(std::move(done_v_port)), run_job(std::move(run_job)), run_again(std::move(run_again)), run_turn_left(std::move(run_turn_left)), run_turn_right(std::move(run_turn_right)), outcome(std::move(outcome)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse(const MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse>> make(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse> parent, Cx& cx);
    Unit done(Outcome_ v, Cx& cx);
    Unit run_started(Unit v, Cx& cx);
    Unit run_again_(Unit v, Cx& cx);
    Unit run_turn(Unit v, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done generation_build(Cx& cx);
    Done wake(Cx& cx) override;
    Done started(Cx& cx) override;
    Done deferred(Cx& cx) override;
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0 : public Row {
public:
    Path path;
    /// `?out`
    std::optional<Text> out;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse> parent;
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0(Path path, std::optional<Text> out, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse> parent) : path(std::move(path)), out(std::move(out)), parent(std::move(parent)) {}
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0(const MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0>> make(Path path, std::optional<Text> out, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse> parent, Cx& cx);
    Unit remove_places(Cx& cx) const;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1 : public Row {
public:
    Path path;
    /// `?out`
    std::optional<Text> out;
    /// `o`
    Outcome_ o;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse> parent;
    /// `!started` as a value: the port it fires
    prism_rtl::Rc<Port<Unit>> started_2_v_port;
    /// `!~verdict` as a value: the port it fires
    prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port;
    /// the current generation of the `rebuild` at place 0
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1(Path path, std::optional<Text> out, Outcome_ o, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse> parent, prism_rtl::Rc<Port<Unit>> started_2_v_port, prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), out(std::move(out)), o(std::move(o)), parent(std::move(parent)), started_2_v_port(std::move(started_2_v_port)), verdict_v_port(std::move(verdict_v_port)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1(const MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1>> make(Path path, std::optional<Text> out, Outcome_ o, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit verdict(Fallible<Unit> v, Cx& cx);
    Unit generation_fired(prism_rtl::Blueprint<crate::Elem, crate::Answer> v, Cx& cx);
    Unit place_2(Unit v, Cx& cx);
    Unit generation_up(prism_rtl::Blueprint<crate::Elem, crate::Answer> v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done generation_build(Cx& cx);
    Done started(Cx& cx) override;
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0 : public Row {
public:
    Path path;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1> parent;
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0(Path path, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1> parent) : path(std::move(path)), parent(std::move(parent)) {}
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0(const MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0>> make(Path path, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1> parent, Cx& cx);
    Unit remove_places(Cx& cx) const;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1 : public Row {
public:
    Path path;
    /// `path`
    Text path_;
    /// `text`
    Text text;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1> parent;
    /// pushed to place 0
    Hold<crate::fs::WriteState> place_0;
    /// place 0's element, which pushes are keyed by
    Pod place_0_element;
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1(Path path, Text path_, Text text, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1> parent, Hold<crate::fs::WriteState> place_0, Pod place_0_element) : path(std::move(path)), path_(std::move(path_)), text(std::move(text)), parent(std::move(parent)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1(const MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1>> make(Path path, Text path_, Text text, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1> parent, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1Row`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1Row : public Row {
public:
    Path path;
    /// the row's key
    Nat key;
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    std::optional<Text> left_entry;
    /// the node of the `for`
    prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1> parent;
    /// pushed to place 0
    Hold<Fallible<crate::fs::Contents>> place_0;
    /// place 0's element, which pushes are keyed by
    Pod place_0_element;
    MainArmThenArmElseArmElseGen1Gen1Row(Path path, Nat key, std::optional<Text> left_entry, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1> parent, Hold<Fallible<crate::fs::Contents>> place_0, Pod place_0_element) : path(std::move(path)), key(std::move(key)), left_entry(std::move(left_entry)), parent(std::move(parent)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmThenArmElseArmElseGen1Gen1Row(const MainArmThenArmElseArmElseGen1Gen1Row&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Row>> make(Path path, Nat key, Text value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1> parent, Cx& cx);
    crate::Elem contents_(const Cx& cx) const;
    Text entry(const Cx& cx) const;
    Fallible<crate::fs::Contents> result(const Cx& cx) const;
    Unit remove_places(Cx& cx) const;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done patch(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Row`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Row : public Row {
public:
    Path path;
    /// the row's key
    Nat key;
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    std::optional<Text> left_entry;
    /// the node of the `for`
    prism_rtl::Weak<MainArmThenArmElseArmElseGen1> parent;
    /// pushed to place 0
    Hold<Array<Text>> place_0;
    /// place 0's element, which pushes are keyed by
    Pod place_0_element;
    MainArmThenArmElseArmElseGen1Row(Path path, Nat key, std::optional<Text> left_entry, prism_rtl::Weak<MainArmThenArmElseArmElseGen1> parent, Hold<Array<Text>> place_0, Pod place_0_element) : path(std::move(path)), key(std::move(key)), left_entry(std::move(left_entry)), parent(std::move(parent)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmThenArmElseArmElseGen1Row(const MainArmThenArmElseArmElseGen1Row&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Row>> make(Path path, Nat key, Text value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1> parent, Cx& cx);
    crate::Elem list(const Cx& cx) const;
    Text entry(const Cx& cx) const;
    Array<Text> result(const Cx& cx) const;
    Unit remove_places(Cx& cx) const;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done patch(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseRow`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseRow : public Row {
public:
    Path path;
    /// the row's key
    Nat key;
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    std::optional<Text> left_entry;
    /// the node of the `for`
    prism_rtl::Weak<MainArmThenArmElseArmElse> parent;
    /// pushed to place 0
    Hold<Array<Text>> place_0;
    /// place 0's element, which pushes are keyed by
    Pod place_0_element;
    MainArmThenArmElseArmElseRow(Path path, Nat key, std::optional<Text> left_entry, prism_rtl::Weak<MainArmThenArmElseArmElse> parent, Hold<Array<Text>> place_0, Pod place_0_element) : path(std::move(path)), key(std::move(key)), left_entry(std::move(left_entry)), parent(std::move(parent)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmThenArmElseArmElseRow(const MainArmThenArmElseArmElseRow&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseRow>> make(Path path, Nat key, Text value, prism_rtl::Weak<MainArmThenArmElseArmElse> parent, Cx& cx);
    crate::Elem list(const Cx& cx) const;
    Text entry(const Cx& cx) const;
    Array<Text> result(const Cx& cx) const;
    Unit remove_places(Cx& cx) const;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done patch(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElse`: a node of its own (docs/backend.md, "A widget block").
class MainArmElse : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<Main> parent;
    /// the current generation of the `rebuild` at place 0
    std::optional<prism_rtl::Rc<Row>> arm;
    /// how many generations it has built
    std::uint32_t arm_count;
    /// its source changed since it was built
    bool arm_stale;
    MainArmElse(Path path, Unit value, prism_rtl::Weak<Main> parent, std::optional<prism_rtl::Rc<Row>> arm, std::uint32_t arm_count, bool arm_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), arm(std::move(arm)), arm_count(std::move(arm_count)), arm_stale(std::move(arm_stale)) {}
    MainArmElse(const MainArmElse&) = delete;
    static Result<prism_rtl::Rc<MainArmElse>> make(Path path, Unit value, prism_rtl::Weak<Main> parent, Cx& cx);
    Unit arm_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done arm_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThen`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThen : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElse> parent;
    /// `args`
    Array<Text> args;
    /// `bad`
    Array<Text> bad;
    /// the current generation of the `rebuild` at place 0
    std::optional<prism_rtl::Rc<Row>> arm;
    /// how many generations it has built
    std::uint32_t arm_count;
    /// its source changed since it was built
    bool arm_stale;
    MainArmElseArmThen(Path path, Unit value, prism_rtl::Weak<MainArmElse> parent, Array<Text> args, Array<Text> bad, std::optional<prism_rtl::Rc<Row>> arm, std::uint32_t arm_count, bool arm_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), args(std::move(args)), bad(std::move(bad)), arm(std::move(arm)), arm_count(std::move(arm_count)), arm_stale(std::move(arm_stale)) {}
    MainArmElseArmThen(const MainArmElseArmThen&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThen>> make(Path path, Unit value, prism_rtl::Weak<MainArmElse> parent, Cx& cx);
    Unit arm_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done arm_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmThen`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmThen : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThen> parent;
    /// `why`
    Text why;
    /// `!started` as a value: the port it fires
    prism_rtl::Rc<Port<Unit>> started_2_v_port;
    /// `!~gaveUp` as a value: the port it fires
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port;
    MainArmElseArmThenArmThen(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThen> parent, Text why, prism_rtl::Rc<Port<Unit>> started_2_v_port, prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), why(std::move(why)), started_2_v_port(std::move(started_2_v_port)), gave_up_v_port(std::move(gave_up_v_port)) {}
    MainArmElseArmThenArmThen(const MainArmElseArmThenArmThen&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmThen>> make(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThen> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit gave_up(Fallible<Unit> v, Cx& cx);
    Unit place_1(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done started(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElse`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElse : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThen> parent;
    /// `world`
    Array<Text> world;
    /// `opts`
    CheckOpts opts;
    /// `mode`
    ReadMode mode;
    /// `args`
    Array<Text> args;
    /// `prelude`
    Text prelude;
    /// `tests`
    bool tests;
    /// `dirs`
    Array<Text> dirs;
    /// the source of the `for` at place 0, cached (gap SR)
    Cache<Map<Nat, Text>> rows_source_cache;
    /// the rows of the `for` at place 0
    Map<Nat, prism_rtl::Rc<MainArmElseArmThenArmElseRow>> rows;
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    Snapshot<Map<Nat, Array<Text>>> rows_all_snap;
    /// the current generation of the `rebuild` at place 1
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    MainArmElseArmThenArmElse(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThen> parent, Array<Text> world, CheckOpts opts, ReadMode mode, Array<Text> args, Text prelude, bool tests, Array<Text> dirs, Cache<Map<Nat, Text>> rows_source_cache, Map<Nat, prism_rtl::Rc<MainArmElseArmThenArmElseRow>> rows, Snapshot<Map<Nat, Array<Text>>> rows_all_snap, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), world(std::move(world)), opts(std::move(opts)), mode(std::move(mode)), args(std::move(args)), prelude(std::move(prelude)), tests(std::move(tests)), dirs(std::move(dirs)), rows_source_cache(std::move(rows_source_cache)), rows(std::move(rows)), rows_all_snap(std::move(rows_all_snap)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmElseArmThenArmElse(const MainArmElseArmThenArmElse&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElse>> make(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThen> parent, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Map<Nat, Text> rows_source(const Cx& cx) const;
    Map<Nat, Array<Text>> rows_all_now(const Cx& cx) const;
    Map<Nat, Array<Text>> rows_all(const Cx& cx) const;
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Unit rows_all_moved(Cx& cx);
    Unit rows_all_publish(Cx& cx);
    Done rows_build(Cx& cx);
    Done generation_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1 : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Map<Nat, Array<Text>> value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThenArmElse> parent;
    /// `mode`
    ReadMode mode;
    /// `args`
    Array<Text> args;
    /// `prelude`
    Text prelude;
    /// `tests`
    bool tests;
    /// `listings`
    Array<std::tuple<Text, Array<Text>>> listings;
    /// `ups`
    Array<Text> ups;
    /// the source of the `for` at place 0, cached (gap SR)
    Cache<Map<Nat, Text>> rows_source_cache;
    /// the rows of the `for` at place 0
    Map<Nat, prism_rtl::Rc<MainArmElseArmThenArmElseGen1Row>> rows;
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    Snapshot<Map<Nat, Array<Text>>> rows_all_snap;
    /// the current generation of the `rebuild` at place 1
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    MainArmElseArmThenArmElseGen1(Path path, Map<Nat, Array<Text>> value, prism_rtl::Weak<MainArmElseArmThenArmElse> parent, ReadMode mode, Array<Text> args, Text prelude, bool tests, Array<std::tuple<Text, Array<Text>>> listings, Array<Text> ups, Cache<Map<Nat, Text>> rows_source_cache, Map<Nat, prism_rtl::Rc<MainArmElseArmThenArmElseGen1Row>> rows, Snapshot<Map<Nat, Array<Text>>> rows_all_snap, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), mode(std::move(mode)), args(std::move(args)), prelude(std::move(prelude)), tests(std::move(tests)), listings(std::move(listings)), ups(std::move(ups)), rows_source_cache(std::move(rows_source_cache)), rows(std::move(rows)), rows_all_snap(std::move(rows_all_snap)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmElseArmThenArmElseGen1(const MainArmElseArmThenArmElseGen1&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1>> make(Path path, Map<Nat, Array<Text>> value, prism_rtl::Weak<MainArmElseArmThenArmElse> parent, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Map<Nat, Text> rows_source(const Cx& cx) const;
    Map<Nat, Array<Text>> rows_all_now(const Cx& cx) const;
    Map<Nat, Array<Text>> rows_all(const Cx& cx) const;
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Unit rows_all_moved(Cx& cx);
    Unit rows_all_publish(Cx& cx);
    Done rows_build(Cx& cx);
    Done generation_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen1 : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Map<Nat, Array<Text>> value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThenArmElseGen1> parent;
    /// `mode`
    ReadMode mode;
    /// `args`
    Array<Text> args;
    /// `prelude`
    Text prelude;
    /// `tests`
    bool tests;
    /// `listings`
    Array<std::tuple<Text, Array<Text>>> listings;
    /// `paths`
    Array<Text> paths;
    /// the source of the `for` at place 0, cached (gap SR)
    Cache<Map<Nat, Text>> rows_source_cache;
    /// the rows of the `for` at place 0
    Map<Nat, prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Row>> rows;
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    Snapshot<Map<Nat, Fallible<crate::fs::Contents>>> rows_all_snap;
    /// the current generation of the `rebuild` at place 1
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    MainArmElseArmThenArmElseGen1Gen1(Path path, Map<Nat, Array<Text>> value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1> parent, ReadMode mode, Array<Text> args, Text prelude, bool tests, Array<std::tuple<Text, Array<Text>>> listings, Array<Text> paths, Cache<Map<Nat, Text>> rows_source_cache, Map<Nat, prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Row>> rows, Snapshot<Map<Nat, Fallible<crate::fs::Contents>>> rows_all_snap, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), mode(std::move(mode)), args(std::move(args)), prelude(std::move(prelude)), tests(std::move(tests)), listings(std::move(listings)), paths(std::move(paths)), rows_source_cache(std::move(rows_source_cache)), rows(std::move(rows)), rows_all_snap(std::move(rows_all_snap)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmElseArmThenArmElseGen1Gen1(const MainArmElseArmThenArmElseGen1Gen1&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1>> make(Path path, Map<Nat, Array<Text>> value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1> parent, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Map<Nat, Text> rows_source(const Cx& cx) const;
    Map<Nat, Fallible<crate::fs::Contents>> rows_all_now(const Cx& cx) const;
    Map<Nat, Fallible<crate::fs::Contents>> rows_all(const Cx& cx) const;
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Unit rows_all_moved(Cx& cx);
    Unit rows_all_publish(Cx& cx);
    Done rows_build(Cx& cx);
    Done generation_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen1Gen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen1Gen1 : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Map<Nat, Fallible<crate::fs::Contents>> value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1> parent;
    /// `mode`
    ReadMode mode;
    /// `input`
    ReadInput input;
    /// `contents`
    Map<Nat, Fallible<crate::fs::Contents>> contents;
    /// `failed`
    Array<Text> failed;
    /// `texts`
    Array<std::tuple<Text, Text>> texts;
    /// `full`
    ReadInput full;
    /// the current generation of the `rebuild` at place 0
    std::optional<prism_rtl::Rc<Row>> arm;
    /// how many generations it has built
    std::uint32_t arm_count;
    /// its source changed since it was built
    bool arm_stale;
    MainArmElseArmThenArmElseGen1Gen1Gen1(Path path, Map<Nat, Fallible<crate::fs::Contents>> value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1> parent, ReadMode mode, ReadInput input, Map<Nat, Fallible<crate::fs::Contents>> contents, Array<Text> failed, Array<std::tuple<Text, Text>> texts, ReadInput full, std::optional<prism_rtl::Rc<Row>> arm, std::uint32_t arm_count, bool arm_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), mode(std::move(mode)), input(std::move(input)), contents(std::move(contents)), failed(std::move(failed)), texts(std::move(texts)), full(std::move(full)), arm(std::move(arm)), arm_count(std::move(arm_count)), arm_stale(std::move(arm_stale)) {}
    MainArmElseArmThenArmElseGen1Gen1Gen1(const MainArmElseArmThenArmElseGen1Gen1Gen1&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1>> make(Path path, Map<Nat, Fallible<crate::fs::Contents>> value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1> parent, Cx& cx);
    Unit arm_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done arm_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1> parent;
    /// `why`
    Text why;
    /// `!started` as a value: the port it fires
    prism_rtl::Rc<Port<Unit>> started_2_v_port;
    /// `!~gaveUp` as a value: the port it fires
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port;
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1> parent, Text why, prism_rtl::Rc<Port<Unit>> started_2_v_port, prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), why(std::move(why)), started_2_v_port(std::move(started_2_v_port)), gave_up_v_port(std::move(gave_up_v_port)) {}
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen(const MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen>> make(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit gave_up(Fallible<Unit> v, Cx& cx);
    Unit place_1(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done started(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1> parent;
    /// the current generation of the `rebuild` at place 0
    std::optional<prism_rtl::Rc<Row>> arm;
    /// how many generations it has built
    std::uint32_t arm_count;
    /// its source changed since it was built
    bool arm_stale;
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1> parent, std::optional<prism_rtl::Rc<Row>> arm, std::uint32_t arm_count, bool arm_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), arm(std::move(arm)), arm_count(std::move(arm_count)), arm_stale(std::move(arm_stale)) {}
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse(const MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse>> make(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1> parent, Cx& cx);
    Unit arm_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done arm_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse> parent;
    /// `s`
    CompileSettings s;
    /// `input`
    ReadInput input;
    /// `!done` as a value: the port it fires
    prism_rtl::Rc<Port<Compiled>> done_v_port;
    /// `@Run`'s job (`@Machine`'s state)
    Hold<prism_rtl::JobRef<Compiled>> run_job;
    /// `@Run`'s `!again`
    Defer<Unit> run_again;
    /// `run_turn`'s left input
    Stamped<Unit> run_turn_left;
    /// its right input
    Stamped<Unit> run_turn_right;
    /// `$?outcome`
    Hold<std::optional<Compiled>> outcome;
    /// the current generation of the `rebuild` at place 1
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    /// The merges' height above the node's inputs.
    static constexpr std::uint32_t WAKE = 1;
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse> parent, CompileSettings s, ReadInput input, prism_rtl::Rc<Port<Compiled>> done_v_port, Hold<prism_rtl::JobRef<Compiled>> run_job, Defer<Unit> run_again, Stamped<Unit> run_turn_left, Stamped<Unit> run_turn_right, Hold<std::optional<Compiled>> outcome, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), s(std::move(s)), input(std::move(input)), done_v_port(std::move(done_v_port)), run_job(std::move(run_job)), run_again(std::move(run_again)), run_turn_left(std::move(run_turn_left)), run_turn_right(std::move(run_turn_right)), outcome(std::move(outcome)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen(const MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen>> make(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse> parent, Cx& cx);
    Unit done(Compiled v, Cx& cx);
    Unit run_started(Unit v, Cx& cx);
    Unit run_again_(Unit v, Cx& cx);
    Unit run_turn(Unit v, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done generation_build(Cx& cx);
    Done wake(Cx& cx) override;
    Done started(Cx& cx) override;
    Done deferred(Cx& cx) override;
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0 : public Row {
public:
    Path path;
    /// `out`
    Text out;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen> parent;
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0(Path path, Text out, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen> parent) : path(std::move(path)), out(std::move(out)), parent(std::move(parent)) {}
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0(const MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0>> make(Path path, Text out, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen> parent, Cx& cx);
    Unit remove_places(Cx& cx) const;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1 : public Row {
public:
    Path path;
    /// `out`
    Text out;
    /// `o`
    Compiled o;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen> parent;
    /// `!started` as a value: the port it fires
    prism_rtl::Rc<Port<Unit>> started_2_v_port;
    /// `!~verdict` as a value: the port it fires
    prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port;
    /// the source of the `for` at place 0, cached (gap SR)
    Cache<Map<Nat, std::tuple<Text, Text>>> rows_source_cache;
    /// the rows of the `for` at place 0
    Map<Nat, prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row>> rows;
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    Snapshot<Map<Nat, crate::fs::WriteState>> rows_all_snap;
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1(Path path, Text out, Compiled o, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen> parent, prism_rtl::Rc<Port<Unit>> started_2_v_port, prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port, Cache<Map<Nat, std::tuple<Text, Text>>> rows_source_cache, Map<Nat, prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row>> rows, Snapshot<Map<Nat, crate::fs::WriteState>> rows_all_snap) : path(std::move(path)), out(std::move(out)), o(std::move(o)), parent(std::move(parent)), started_2_v_port(std::move(started_2_v_port)), verdict_v_port(std::move(verdict_v_port)), rows_source_cache(std::move(rows_source_cache)), rows(std::move(rows)), rows_all_snap(std::move(rows_all_snap)) {}
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1(const MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1>> make(Path path, Text out, Compiled o, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit verdict(Fallible<Unit> v, Cx& cx);
    Unit place_2(Unit v, Cx& cx);
    Map<Nat, std::tuple<Text, Text>> rows_source(const Cx& cx) const;
    Map<Nat, crate::fs::WriteState> rows_all_now(const Cx& cx) const;
    Map<Nat, crate::fs::WriteState> rows_all(const Cx& cx) const;
    Unit remove_places(Cx& cx) const;
    Unit rows_all_moved(Cx& cx);
    Unit rows_all_publish(Cx& cx);
    Done rows_build(Cx& cx);
    Done started(Cx& cx) override;
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row : public Row {
public:
    Path path;
    /// the row's key
    Nat key;
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    std::optional<std::tuple<Text, Text>> left_entry;
    /// the node of the `for`
    prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1> parent;
    /// `out`, the block's
    Text out;
    /// pushed to place 0
    Hold<crate::fs::WriteState> place_0;
    /// place 0's element, which pushes are keyed by
    Pod place_0_element;
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row(Path path, Nat key, std::optional<std::tuple<Text, Text>> left_entry, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1> parent, Text out, Hold<crate::fs::WriteState> place_0, Pod place_0_element) : path(std::move(path)), key(std::move(key)), left_entry(std::move(left_entry)), parent(std::move(parent)), out(std::move(out)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row(const MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row>> make(Path path, Nat key, std::tuple<Text, Text> value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1> parent, Text out, Cx& cx);
    crate::Elem output(const Cx& cx) const;
    std::tuple<Text, Text> entry(const Cx& cx) const;
    crate::fs::WriteState result(const Cx& cx) const;
    Unit remove_places(Cx& cx) const;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done patch(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse> parent;
    /// `o`
    CheckOpts o;
    /// `input`
    ReadInput input;
    /// `!done` as a value: the port it fires
    prism_rtl::Rc<Port<Outcome_>> done_v_port;
    /// `@Run`'s job (`@Machine`'s state)
    Hold<prism_rtl::JobRef<Outcome_>> run_job;
    /// `@Run`'s `!again`
    Defer<Unit> run_again;
    /// `run_turn`'s left input
    Stamped<Unit> run_turn_left;
    /// its right input
    Stamped<Unit> run_turn_right;
    /// `$?outcome`
    Hold<std::optional<Outcome_>> outcome;
    /// the current generation of the `rebuild` at place 1
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    /// The merges' height above the node's inputs.
    static constexpr std::uint32_t WAKE = 1;
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse> parent, CheckOpts o, ReadInput input, prism_rtl::Rc<Port<Outcome_>> done_v_port, Hold<prism_rtl::JobRef<Outcome_>> run_job, Defer<Unit> run_again, Stamped<Unit> run_turn_left, Stamped<Unit> run_turn_right, Hold<std::optional<Outcome_>> outcome, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), o(std::move(o)), input(std::move(input)), done_v_port(std::move(done_v_port)), run_job(std::move(run_job)), run_again(std::move(run_again)), run_turn_left(std::move(run_turn_left)), run_turn_right(std::move(run_turn_right)), outcome(std::move(outcome)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse(const MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse>> make(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse> parent, Cx& cx);
    Unit done(Outcome_ v, Cx& cx);
    Unit run_started(Unit v, Cx& cx);
    Unit run_again_(Unit v, Cx& cx);
    Unit run_turn(Unit v, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done generation_build(Cx& cx);
    Done wake(Cx& cx) override;
    Done started(Cx& cx) override;
    Done deferred(Cx& cx) override;
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0 : public Row {
public:
    Path path;
    /// `?out`
    std::optional<Text> out;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse> parent;
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0(Path path, std::optional<Text> out, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse> parent) : path(std::move(path)), out(std::move(out)), parent(std::move(parent)) {}
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0(const MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0>> make(Path path, std::optional<Text> out, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse> parent, Cx& cx);
    Unit remove_places(Cx& cx) const;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1 : public Row {
public:
    Path path;
    /// `?out`
    std::optional<Text> out;
    /// `o`
    Outcome_ o;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse> parent;
    /// `!started` as a value: the port it fires
    prism_rtl::Rc<Port<Unit>> started_2_v_port;
    /// `!~verdict` as a value: the port it fires
    prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port;
    /// the current generation of the `rebuild` at place 0
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1(Path path, std::optional<Text> out, Outcome_ o, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse> parent, prism_rtl::Rc<Port<Unit>> started_2_v_port, prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), out(std::move(out)), o(std::move(o)), parent(std::move(parent)), started_2_v_port(std::move(started_2_v_port)), verdict_v_port(std::move(verdict_v_port)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1(const MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1>> make(Path path, std::optional<Text> out, Outcome_ o, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit verdict(Fallible<Unit> v, Cx& cx);
    Unit generation_fired(prism_rtl::Blueprint<crate::Elem, crate::Answer> v, Cx& cx);
    Unit place_2(Unit v, Cx& cx);
    Unit generation_up(prism_rtl::Blueprint<crate::Elem, crate::Answer> v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done generation_build(Cx& cx);
    Done started(Cx& cx) override;
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0 : public Row {
public:
    Path path;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1> parent;
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0(Path path, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1> parent) : path(std::move(path)), parent(std::move(parent)) {}
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0(const MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0>> make(Path path, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1> parent, Cx& cx);
    Unit remove_places(Cx& cx) const;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1 : public Row {
public:
    Path path;
    /// `path`
    Text path_;
    /// `text`
    Text text;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1> parent;
    /// pushed to place 0
    Hold<crate::fs::WriteState> place_0;
    /// place 0's element, which pushes are keyed by
    Pod place_0_element;
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1(Path path, Text path_, Text text, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1> parent, Hold<crate::fs::WriteState> place_0, Pod place_0_element) : path(std::move(path)), path_(std::move(path_)), text(std::move(text)), parent(std::move(parent)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1(const MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1>> make(Path path, Text path_, Text text, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1> parent, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen1Row`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen1Row : public Row {
public:
    Path path;
    /// the row's key
    Nat key;
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    std::optional<Text> left_entry;
    /// the node of the `for`
    prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1> parent;
    /// pushed to place 0
    Hold<Fallible<crate::fs::Contents>> place_0;
    /// place 0's element, which pushes are keyed by
    Pod place_0_element;
    MainArmElseArmThenArmElseGen1Gen1Row(Path path, Nat key, std::optional<Text> left_entry, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1> parent, Hold<Fallible<crate::fs::Contents>> place_0, Pod place_0_element) : path(std::move(path)), key(std::move(key)), left_entry(std::move(left_entry)), parent(std::move(parent)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmElseArmThenArmElseGen1Gen1Row(const MainArmElseArmThenArmElseGen1Gen1Row&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Row>> make(Path path, Nat key, Text value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1> parent, Cx& cx);
    crate::Elem contents_(const Cx& cx) const;
    Text entry(const Cx& cx) const;
    Fallible<crate::fs::Contents> result(const Cx& cx) const;
    Unit remove_places(Cx& cx) const;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done patch(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Row`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Row : public Row {
public:
    Path path;
    /// the row's key
    Nat key;
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    std::optional<Text> left_entry;
    /// the node of the `for`
    prism_rtl::Weak<MainArmElseArmThenArmElseGen1> parent;
    /// pushed to place 0
    Hold<Array<Text>> place_0;
    /// place 0's element, which pushes are keyed by
    Pod place_0_element;
    MainArmElseArmThenArmElseGen1Row(Path path, Nat key, std::optional<Text> left_entry, prism_rtl::Weak<MainArmElseArmThenArmElseGen1> parent, Hold<Array<Text>> place_0, Pod place_0_element) : path(std::move(path)), key(std::move(key)), left_entry(std::move(left_entry)), parent(std::move(parent)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmElseArmThenArmElseGen1Row(const MainArmElseArmThenArmElseGen1Row&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Row>> make(Path path, Nat key, Text value, prism_rtl::Weak<MainArmElseArmThenArmElseGen1> parent, Cx& cx);
    crate::Elem list(const Cx& cx) const;
    Text entry(const Cx& cx) const;
    Array<Text> result(const Cx& cx) const;
    Unit remove_places(Cx& cx) const;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done patch(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseRow`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseRow : public Row {
public:
    Path path;
    /// the row's key
    Nat key;
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    std::optional<Text> left_entry;
    /// the node of the `for`
    prism_rtl::Weak<MainArmElseArmThenArmElse> parent;
    /// pushed to place 0
    Hold<Array<Text>> place_0;
    /// place 0's element, which pushes are keyed by
    Pod place_0_element;
    MainArmElseArmThenArmElseRow(Path path, Nat key, std::optional<Text> left_entry, prism_rtl::Weak<MainArmElseArmThenArmElse> parent, Hold<Array<Text>> place_0, Pod place_0_element) : path(std::move(path)), key(std::move(key)), left_entry(std::move(left_entry)), parent(std::move(parent)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmElseArmThenArmElseRow(const MainArmElseArmThenArmElseRow&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseRow>> make(Path path, Nat key, Text value, prism_rtl::Weak<MainArmElseArmThenArmElse> parent, Cx& cx);
    crate::Elem list(const Cx& cx) const;
    Text entry(const Cx& cx) const;
    Array<Text> result(const Cx& cx) const;
    Unit remove_places(Cx& cx) const;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done patch(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmElse`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmElse : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElse> parent;
    /// `args`
    Array<Text> args;
    /// `tokens`
    bool tokens;
    /// `fragment`
    bool fragment;
    /// `names`
    Array<Text> names;
    /// `file`
    Text file;
    /// `out`
    Text out;
    /// pushed to place 0
    Hold<Fallible<crate::fs::Contents>> source;
    /// place 0's element, which pushes are keyed by
    Pod source_element;
    /// the current generation of the `rebuild` at place 1
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    MainArmElseArmElse(Path path, Unit value, prism_rtl::Weak<MainArmElse> parent, Array<Text> args, bool tokens, bool fragment, Array<Text> names, Text file, Text out, Hold<Fallible<crate::fs::Contents>> source, Pod source_element, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), args(std::move(args)), tokens(std::move(tokens)), fragment(std::move(fragment)), names(std::move(names)), file(std::move(file)), out(std::move(out)), source(std::move(source)), source_element(std::move(source_element)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmElseArmElse(const MainArmElseArmElse&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmElse>> make(Path path, Unit value, prism_rtl::Weak<MainArmElse> parent, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done generation_build(Cx& cx);
    Done build(Cx& cx) override;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmElseGen0`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmElseGen0 : public Row {
public:
    Path path;
    /// `job`
    Job_ job;
    /// `file`
    Text file;
    /// `out`
    Text out;
    /// `c`
    crate::fs::Contents c;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmElse> parent;
    /// `!done` as a value: the port it fires
    prism_rtl::Rc<Port<Outcome_>> done_v_port;
    /// `full`
    Job_ full;
    /// `@Run`'s job (`@Machine`'s state)
    Hold<prism_rtl::JobRef<Outcome_>> run_job;
    /// `@Run`'s `!again`
    Defer<Unit> run_again;
    /// `run_turn`'s left input
    Stamped<Unit> run_turn_left;
    /// its right input
    Stamped<Unit> run_turn_right;
    /// `$?outcome`
    Hold<std::optional<Outcome_>> outcome;
    /// the current generation of the `rebuild` at place 1
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    /// The merges' height above the node's inputs.
    static constexpr std::uint32_t WAKE = 1;
    MainArmElseArmElseGen0(Path path, Job_ job, Text file, Text out, crate::fs::Contents c, prism_rtl::Weak<MainArmElseArmElse> parent, prism_rtl::Rc<Port<Outcome_>> done_v_port, Job_ full, Hold<prism_rtl::JobRef<Outcome_>> run_job, Defer<Unit> run_again, Stamped<Unit> run_turn_left, Stamped<Unit> run_turn_right, Hold<std::optional<Outcome_>> outcome, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), job(std::move(job)), file(std::move(file)), out(std::move(out)), c(std::move(c)), parent(std::move(parent)), done_v_port(std::move(done_v_port)), full(std::move(full)), run_job(std::move(run_job)), run_again(std::move(run_again)), run_turn_left(std::move(run_turn_left)), run_turn_right(std::move(run_turn_right)), outcome(std::move(outcome)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmElseArmElseGen0(const MainArmElseArmElseGen0&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmElseGen0>> make(Path path, Job_ job, Text file, Text out, crate::fs::Contents c, prism_rtl::Weak<MainArmElseArmElse> parent, Cx& cx);
    Unit done(Outcome_ v, Cx& cx);
    Unit run_started(Unit v, Cx& cx);
    Unit run_again_(Unit v, Cx& cx);
    Unit run_turn(Unit v, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done generation_build(Cx& cx);
    Done wake(Cx& cx) override;
    Done started(Cx& cx) override;
    Done deferred(Cx& cx) override;
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmElseGen0Gen0`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmElseGen0Gen0 : public Row {
public:
    Path path;
    /// `out`
    Text out;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmElseGen0> parent;
    MainArmElseArmElseGen0Gen0(Path path, Text out, prism_rtl::Weak<MainArmElseArmElseGen0> parent) : path(std::move(path)), out(std::move(out)), parent(std::move(parent)) {}
    MainArmElseArmElseGen0Gen0(const MainArmElseArmElseGen0Gen0&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmElseGen0Gen0>> make(Path path, Text out, prism_rtl::Weak<MainArmElseArmElseGen0> parent, Cx& cx);
    Unit remove_places(Cx& cx) const;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmElseGen0Gen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmElseGen0Gen1 : public Row {
public:
    Path path;
    /// `out`
    Text out;
    /// `o`
    Outcome_ o;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmElseGen0> parent;
    /// `!started` as a value: the port it fires
    prism_rtl::Rc<Port<Unit>> started_2_v_port;
    /// `!~verdict` as a value: the port it fires
    prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port;
    /// pushed to place 0
    Hold<crate::fs::WriteState> place_0;
    /// place 0's element, which pushes are keyed by
    Pod place_0_element;
    MainArmElseArmElseGen0Gen1(Path path, Text out, Outcome_ o, prism_rtl::Weak<MainArmElseArmElseGen0> parent, prism_rtl::Rc<Port<Unit>> started_2_v_port, prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port, Hold<crate::fs::WriteState> place_0, Pod place_0_element) : path(std::move(path)), out(std::move(out)), o(std::move(o)), parent(std::move(parent)), started_2_v_port(std::move(started_2_v_port)), verdict_v_port(std::move(verdict_v_port)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmElseArmElseGen0Gen1(const MainArmElseArmElseGen0Gen1&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmElseGen0Gen1>> make(Path path, Text out, Outcome_ o, prism_rtl::Weak<MainArmElseArmElseGen0> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit verdict(Fallible<Unit> v, Cx& cx);
    Unit place_2(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done started(Cx& cx) override;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmElseGen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmElseGen1 : public Row {
public:
    Path path;
    /// `job`
    Job_ job;
    /// `file`
    Text file;
    /// `out`
    Text out;
    /// `m`
    Text m;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmElse> parent;
    /// `!started` as a value: the port it fires
    prism_rtl::Rc<Port<Unit>> started_2_v_port;
    /// `!~gaveUp` as a value: the port it fires
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port;
    MainArmElseArmElseGen1(Path path, Job_ job, Text file, Text out, Text m, prism_rtl::Weak<MainArmElseArmElse> parent, prism_rtl::Rc<Port<Unit>> started_2_v_port, prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port) : path(std::move(path)), job(std::move(job)), file(std::move(file)), out(std::move(out)), m(std::move(m)), parent(std::move(parent)), started_2_v_port(std::move(started_2_v_port)), gave_up_v_port(std::move(gave_up_v_port)) {}
    MainArmElseArmElseGen1(const MainArmElseArmElseGen1&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmElseGen1>> make(Path path, Job_ job, Text file, Text out, Text m, prism_rtl::Weak<MainArmElseArmElse> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit gave_up(Fallible<Unit> v, Cx& cx);
    Unit place_1(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done started(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// The step machine of `Assemble`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Assemble: unbounded fn ReadInput -> Assembled
struct Assemble : prism_rtl::Job<Assembled> {
    ReadInput input;
    Assemble(ReadInput input) : input(std::move(input)) {}
    prism_rtl::Turn<Assembled> cycle() const override;
};


/// The step machine of `AddArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AddArg: unbounded fn Assembled, (Text ==> [Text]), (Text ==> Text), Text -> Assembled
struct AddArg : prism_rtl::Job<Assembled> {
    Assembled acc;
    Map<Text, Array<Text>> listings;
    Map<Text, Text> texts;
    Text a;
    AddArg(Assembled acc, Map<Text, Array<Text>> listings, Map<Text, Text> texts, Text a) : acc(std::move(acc)), listings(std::move(listings)), texts(std::move(texts)), a(std::move(a)) {}
    prism_rtl::Turn<Assembled> cycle() const override;
};


/// The step machine of `WalkTree`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WalkTree: unbounded fn Text, [Text], (Text ==> Text) -> TreeAcc
struct WalkTree : prism_rtl::Job<TreeAcc> {
    Text root;
    Array<Text> files;
    Map<Text, Text> texts;
    WalkTree(Text root, Array<Text> files, Map<Text, Text> texts) : root(std::move(root)), files(std::move(files)), texts(std::move(texts)) {}
    prism_rtl::Turn<TreeAcc> cycle() const override;
};


/// The step machine of `WalkLib`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WalkLib: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
struct WalkLib : prism_rtl::Job<TreeAcc> {
    Map<Text, bool> has;
    Map<Text, Text> texts;
    TreeAcc acc;
    Text lib;
    WalkLib(Map<Text, bool> has, Map<Text, Text> texts, TreeAcc acc, Text lib) : has(std::move(has)), texts(std::move(texts)), acc(std::move(acc)), lib(std::move(lib)) {}
    prism_rtl::Turn<TreeAcc> cycle() const override;
};


/// The step machine of `WalkModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WalkModule: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text -> TreeAcc
struct WalkModule : prism_rtl::Job<TreeAcc> {
    Map<Text, bool> has;
    Map<Text, Text> texts;
    TreeAcc acc;
    Text main;
    Text name;
    WalkModule(Map<Text, bool> has, Map<Text, Text> texts, TreeAcc acc, Text main, Text name) : has(std::move(has)), texts(std::move(texts)), acc(std::move(acc)), main(std::move(main)), name(std::move(name)) {}
    prism_rtl::Turn<TreeAcc> cycle() const override;
};


/// The step machine of `Submodule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Submodule: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, HeadLine, Text -> TreeAcc
struct Submodule : prism_rtl::Job<TreeAcc> {
    Map<Text, bool> has;
    Map<Text, Text> texts;
    TreeAcc acc;
    Text main;
    Text dir;
    HeadLine h;
    Text parent;
    Submodule(Map<Text, bool> has, Map<Text, Text> texts, TreeAcc acc, Text main, Text dir, HeadLine h, Text parent) : has(std::move(has)), texts(std::move(texts)), acc(std::move(acc)), main(std::move(main)), dir(std::move(dir)), h(std::move(h)), parent(std::move(parent)) {}
    prism_rtl::Turn<TreeAcc> cycle() const override;
};


/// The step machine of `ReachTree`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReachTree: unbounded fn [ModFiles], Text -> [ModFiles]
struct ReachTree : prism_rtl::Job<Array<ModFiles>> {
    Array<ModFiles> units;
    Text main;
    ReachTree(Array<ModFiles> units, Text main) : units(std::move(units)), main(std::move(main)) {}
    prism_rtl::Turn<Array<ModFiles>> cycle() const override;
};


/// The step machine of `ReachNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReachNames: unbounded fn (Text ==> ModFiles), [Text], [Text] -> [Text]
struct ReachNames : prism_rtl::Job<Array<Text>> {
    Map<Text, ModFiles> by_name;
    Array<Text> seen;
    Array<Text> todo;
    ReachNames(Map<Text, ModFiles> by_name, Array<Text> seen, Array<Text> todo) : by_name(std::move(by_name)), seen(std::move(seen)), todo(std::move(todo)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ParseUnit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseUnit: unbounded fn ModFiles -> ((Src, Parsed))
struct ParseUnit : prism_rtl::Job<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> {
    ModFiles u;
    ParseUnit(ModFiles u) : u(std::move(u)) {}
    prism_rtl::Turn<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> cycle() const override;
};


/// The step machine of `ParseProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseProgram: unbounded fn Assembled -> ParsedProgram
struct ParseProgram : prism_rtl::Job<ParsedProgram> {
    Assembled read;
    ParseProgram(Assembled read) : read(std::move(read)) {}
    prism_rtl::Turn<ParsedProgram> cycle() const override;
};


/// The step machine of `CheckFiles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckFiles: unbounded fn CheckJob -> Outcome
struct CheckFiles : prism_rtl::Job<Outcome_> {
    CheckJob job;
    CheckFiles(CheckJob job) : job(std::move(job)) {}
    prism_rtl::Turn<Outcome_> cycle() const override;
};


/// The step machine of `CompileProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CompileProgram: unbounded fn CompileJob -> Compiled
struct CompileProgram : prism_rtl::Job<Compiled> {
    CompileJob job;
    CompileProgram(CompileJob job) : job(std::move(job)) {}
    prism_rtl::Turn<Compiled> cycle() const override;
};


}  // namespace program

}  // namespace crate
