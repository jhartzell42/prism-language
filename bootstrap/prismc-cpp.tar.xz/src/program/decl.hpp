// The root module: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace program {

struct Assembled;

struct CheckJob;

struct CheckOpts;

struct CompileJob;

struct CompileSettings;

struct Compiled;

struct HeadLine;

struct Job_;

struct ModFiles;

struct Outcome_;

struct ParsedProgram;

struct ReadInput;

struct ReadMode;

struct Seg;

struct TreeAcc;

struct TreeDiag;

struct FrontEnd;

class Main;

class MainArmThen;

class MainArmThenArmThen;

class MainArmThenArmElse;

class MainArmThenArmElseArmThen;

class MainArmThenArmElseArmElse;

class MainArmThenArmElseArmElseArmThen;

class MainArmThenArmElseArmElseArmElse;

class MainArmThenArmElseArmElseArmElseGen1;

class MainArmThenArmElseArmElseArmElseGen1Gen1;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseArmThen;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseArmElse;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1;

class MainArmThenArmElseArmElseArmElseGen1Gen1Row;

class MainArmThenArmElseArmElseArmElseGen1Row;

class MainArmThenArmElseArmElseArmElseRow;

class MainArmElse;

class MainArmElseArmThen;

class MainArmElseArmThenArmThen;

class MainArmElseArmThenArmElse;

class MainArmElseArmThenArmElseGen1;

class MainArmElseArmThenArmElseGen1Gen1;

class MainArmElseArmThenArmElseGen1Gen1Gen1;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1;

class MainArmElseArmThenArmElseGen1Gen1Row;

class MainArmElseArmThenArmElseGen1Row;

class MainArmElseArmThenArmElseRow;

class MainArmElseArmElse;

class MainArmElseArmElseGen0;

class MainArmElseArmElseGen0Gen0;

class MainArmElseArmElseGen0Gen1;

class MainArmElseArmElseGen1;

struct Assemble;

struct AddArg;

struct WalkTree;

struct WalkLib;

struct WalkModule;

struct Child;

struct ReachTree;

struct ReachNames;

struct ParseUnit;

struct ParseProgram;

struct CheckFiles;

struct CompileProgram;

}  // namespace program


}  // namespace crate
