// The root module: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace program {

struct Job_;

struct Outcome_;

struct FrontEnd;

class Main;

class MainArmThen;

class MainArmThenArmThen;

class MainArmThenArmElse;

class MainArmThenArmElseArmThen;

class MainArmThenArmElseArmElse;

class MainArmThenArmElseArmElseArmThen;

class MainArmThenArmElseArmElseArmElse;

class MainArmThenArmElseArmElseArmElseGen1;

class MainArmThenArmElseArmElseArmElseGen1Gen1;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen0;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen0;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0;

class MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1;

class MainArmThenArmElseArmElseArmElseGen1Gen1Row;

class MainArmThenArmElseArmElseArmElseGen1Row;

class MainArmThenArmElseArmElseArmElseRow;

class MainArmElse;

class MainArmElseArmThen;

class MainArmElseArmThenArmThen;

class MainArmElseArmThenArmElse;

class MainArmElseArmThenArmElseGen1;

class MainArmElseArmThenArmElseGen1Gen1;

class MainArmElseArmThenArmElseGen1Gen1Gen1;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen0;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen0;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1;

class MainArmElseArmThenArmElseGen1Gen1Row;

class MainArmElseArmThenArmElseGen1Row;

class MainArmElseArmThenArmElseRow;

class MainArmElseArmElse;

class MainArmElseArmElseGen0;

class MainArmElseArmElseGen0Gen0;

class MainArmElseArmElseGen0Gen1;

class MainArmElseArmElseGen1;

}  // namespace program

}  // namespace crate
