// The root module: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace program {

struct Assembled;

struct CheckJob;

struct CheckOpts;

struct CompileJob;

struct CompileSettings;

struct Compiled;

struct HeadLine;

struct Job_;

struct ModFiles;

struct Outcome_;

struct ParsedProgram;

struct ReadInput;

struct ReadMode;

struct Seg;

struct TreeAcc;

struct TreeDiag;

struct FrontEnd;

class Main;

class MainArmThen;

class MainArmThenArmThen;

class MainArmThenArmElse;

class MainArmThenArmElseArmThen;

class MainArmThenArmElseArmElse;

class MainArmThenArmElseArmElseGen1;

class MainArmThenArmElseArmElseGen1Gen1;

class MainArmThenArmElseArmElseGen1Gen1Gen1;

class MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen;

class MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse;

class MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen;

class MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0;

class MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1;

class MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row;

class MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse;

class MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0;

class MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1;

class MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0;

class MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1;

class MainArmThenArmElseArmElseGen1Gen1Row;

class MainArmThenArmElseArmElseGen1Row;

class MainArmThenArmElseArmElseRow;

class MainArmElse;

class MainArmElseArmThen;

class MainArmElseArmThenArmThen;

class MainArmElseArmThenArmElse;

class MainArmElseArmThenArmElseGen1;

class MainArmElseArmThenArmElseGen1Gen1;

class MainArmElseArmThenArmElseGen1Gen1Gen1;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0;

class MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1;

class MainArmElseArmThenArmElseGen1Gen1Row;

class MainArmElseArmThenArmElseGen1Row;

class MainArmElseArmThenArmElseRow;

class MainArmElseArmElse;

class MainArmElseArmElseGen0;

class MainArmElseArmElseGen0Gen0;

class MainArmElseArmElseGen0Gen1;

class MainArmElseArmElseGen1;

struct Assemble;

struct AddArg;

struct WalkTree;

struct WalkLib;

struct WalkModule;

struct Submodule;

struct ReachTree;

struct ReachNames;

struct ParseUnit;

struct ParseProgram;

struct CheckFiles;

struct CompileProgram;

}  // namespace program


}  // namespace crate
