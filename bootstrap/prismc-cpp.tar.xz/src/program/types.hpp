// The root module: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <program/decl.hpp>
#include "elem.decl.hpp"
#include <check_blocks/decl.hpp>
#include <check_env/decl.hpp>
#include <check_errors/decl.hpp>
#include <check_expr/decl.hpp>
#include <check_passes/decl.hpp>
#include <check_types/decl.hpp>
#include <cpp_prelude_template/decl.hpp>
#include <cpp_templates/decl.hpp>
#include <emit/decl.hpp>
#include <emit_cpp/decl.hpp>
#include <fs/decl.hpp>
#include <lexer/decl.hpp>
#include <lower/decl.hpp>
#include <parser/decl.hpp>
#include <prelude_template/decl.hpp>
#include <process/decl.hpp>
#include <rust_templates/decl.hpp>
#include <sexp/decl.hpp>
#include <typed/decl.hpp>
#include <ast/types.hpp>

namespace crate {

using namespace prelude;

namespace program {

/// `Assembled`:
///
/// ```prism
/// type Assembled = record:
/// ```
struct Assembled {
    using prism_value = void;
    Array<ModFiles> units;
    Array<ModFiles> prelude;
    Array<Text> scripts;
    Array<TreeDiag> warnings;
    Array<TreeDiag> errors;
    const Assembled* operator->() const { return this; }
    Assembled* operator->() { return this; }
    bool operator==(const Assembled&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Assembled> from_pod(const Pod& whole);
};


}  // namespace program

namespace program {

/// `CheckOpts`:
///
/// ```prism
/// type CheckOpts = record:
/// ```
struct CheckOpts {
    using prism_value = void;
    Array<Text> world;
    std::optional<Text> out;
    bool typed;
    bool unused;
    const CheckOpts* operator->() const { return this; }
    CheckOpts* operator->() { return this; }
    bool operator==(const CheckOpts&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CheckOpts> from_pod(const Pod& whole);
};


}  // namespace program

namespace program {

/// `CompileSettings`:
///
/// ```prism
/// type CompileSettings = record:
/// ```
struct CompileSettings {
    using prism_value = void;
    Text out;
    Text prelude;
    Text name;
    Text runtime;
    Text target;
    const CompileSettings* operator->() const { return this; }
    CompileSettings* operator->() { return this; }
    bool operator==(const CompileSettings&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CompileSettings> from_pod(const Pod& whole);
};


}  // namespace program

namespace program {

/// `Compiled`:
///
/// ```prism
/// type Compiled = record:
/// ```
struct Compiled {
    using prism_value = void;
    Array<std::tuple<Text, Text>> files;
    bool failed;
    Text report;
    const Compiled* operator->() const { return this; }
    Compiled* operator->() { return this; }
    bool operator==(const Compiled&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Compiled> from_pod(const Pod& whole);
};


}  // namespace program

namespace program {

/// `HeadLine`:
///
/// ```prism
/// type HeadLine = record:
/// ```
struct HeadLine {
    using prism_value = void;
    Text word;
    Text arg;
    crate::ast::Range span;
    const HeadLine* operator->() const { return this; }
    HeadLine* operator->() { return this; }
    bool operator==(const HeadLine&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<HeadLine> from_pod(const Pod& whole);
};


}  // namespace program

namespace program {

/// `Job`:
///
/// ```prism
/// type Job = record:
/// ```
struct Job_ {
    using prism_value = void;
    bool tokens;
    bool fragment;
    Text text;
    const Job_* operator->() const { return this; }
    Job_* operator->() { return this; }
    bool operator==(const Job_&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Job_> from_pod(const Pod& whole);
};


}  // namespace program

namespace program {

/// `ModFiles`:
///
/// ```prism
/// type ModFiles = record:
/// ```
struct ModFiles {
    using prism_value = void;
    Text name;
    bool named;
    Array<Seg> segs;
    const ModFiles* operator->() const { return this; }
    ModFiles* operator->() { return this; }
    bool operator==(const ModFiles&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ModFiles> from_pod(const Pod& whole);
};


}  // namespace program

namespace program {

/// `Outcome`:
///
/// ```prism
/// type Outcome = record:
/// ```
struct Outcome_ {
    using prism_value = void;
    Text text;
    bool failed;
    Text report;
    const Outcome_* operator->() const { return this; }
    Outcome_* operator->() { return this; }
    bool operator==(const Outcome_&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Outcome_> from_pod(const Pod& whole);
};


}  // namespace program

namespace program {

/// `ParsedProgram`:
///
/// ```prism
/// type ParsedProgram = record:
/// ```
struct ParsedProgram {
    using prism_value = void;
    Array<crate::check_errors::Src> srcs;
    Array<crate::ast::Module> trees;
    Nat shown;
    Text errors;
    const ParsedProgram* operator->() const { return this; }
    ParsedProgram* operator->() { return this; }
    bool operator==(const ParsedProgram&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ParsedProgram> from_pod(const Pod& whole);
};


}  // namespace program

namespace program {

/// `ReadInput`:
///
/// ```prism
/// type ReadInput = record:
/// ```
struct ReadInput {
    using prism_value = void;
    Array<Text> args;
    Text prelude;
    Array<std::tuple<Text, Array<Text>>> listings;
    Array<Text> paths;
    Array<std::tuple<Text, Text>> texts;
    bool tests;
    bool compiling;
    const ReadInput* operator->() const { return this; }
    ReadInput* operator->() { return this; }
    bool operator==(const ReadInput&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ReadInput> from_pod(const Pod& whole);
};


}  // namespace program

namespace program {

/// `Seg`:
///
/// ```prism
/// type Seg = record:
/// ```
struct Seg {
    using prism_value = void;
    Text path_;
    Text text;
    Text role;
    const Seg* operator->() const { return this; }
    Seg* operator->() { return this; }
    bool operator==(const Seg&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Seg> from_pod(const Pod& whole);
};


}  // namespace program

namespace program {

/// `TreeAcc`:
///
/// ```prism
/// type TreeAcc = record:
/// ```
struct TreeAcc {
    using prism_value = void;
    Array<ModFiles> units;
    Map<Text, bool> declared;
    Array<TreeDiag> diags;
    const TreeAcc* operator->() const { return this; }
    TreeAcc* operator->() { return this; }
    bool operator==(const TreeAcc&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TreeAcc> from_pod(const Pod& whole);
};


}  // namespace program

namespace program {

/// `TreeDiag`:
///
/// ```prism
/// type TreeDiag = record:
/// ```
struct TreeDiag {
    using prism_value = void;
    Text path_;
    crate::ast::Range span;
    Text code;
    Text message;
    Text fix;
    const TreeDiag* operator->() const { return this; }
    TreeDiag* operator->() { return this; }
    bool operator==(const TreeDiag&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TreeDiag> from_pod(const Pod& whole);
};


}  // namespace program

namespace program {

/// `CheckJob`:
///
/// ```prism
/// type CheckJob = record:
/// ```
struct CheckJob {
    using prism_value = void;
    ReadInput read;
    Array<Text> world;
    bool typed;
    bool unused;
    const CheckJob* operator->() const { return this; }
    CheckJob* operator->() { return this; }
    bool operator==(const CheckJob&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CheckJob> from_pod(const Pod& whole);
};


}  // namespace program

namespace program {

/// `CompileJob`:
///
/// ```prism
/// type CompileJob = record:
/// ```
struct CompileJob {
    using prism_value = void;
    ReadInput read;
    Text name;
    Text runtime;
    Text target;
    const CompileJob* operator->() const { return this; }
    CompileJob* operator->() { return this; }
    bool operator==(const CompileJob&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CompileJob> from_pod(const Pod& whole);
};


}  // namespace program

namespace program {

/// `ReadMode`:
///
/// ```prism
/// type ReadMode = record:
/// ```
struct ReadMode {
    using prism_value = void;
    bool compiling;
    CheckOpts checking;
    CompileSettings compile;
    const ReadMode* operator->() const { return this; }
    ReadMode* operator->() { return this; }
    bool operator==(const ReadMode&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ReadMode> from_pod(const Pod& whole);
};


}  // namespace program


}  // namespace crate
