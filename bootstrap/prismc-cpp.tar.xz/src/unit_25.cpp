// The modules `Check.Types`, `Check.Types.Colors`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/types/module.hpp>
#include <syntax/module.hpp>
#include <check/typed/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Types`, from `target/bootstrap/cpp-src/prismc/check/types/mod.prism`.
namespace crate::check::types {

void CLeq::show(Printer& p) const {
    p.record("CLeq", {{"lo", lo}, {"hi", hi}, {"file", file}, {"span", span}, {"kind", kind}, {"name", name}, {"why", why}});
}

Pod CLeq::to_pod() const {
    return Pod::record("CLeq", {{"lo", prism_rtl::to_pod(lo)}, {"hi", prism_rtl::to_pod(hi)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}, {"kind", prism_rtl::to_pod(kind)}, {"name", prism_rtl::to_pod(name)}, {"why", prism_rtl::to_pod(why)}});
}

Result<CLeq> CLeq::from_pod(const Pod& whole) {
    return CLeq{.lo = TRY(prism_rtl::from_pod<Col>(TRY(crate::prelude::field(whole, "lo")))), .hi = TRY(prism_rtl::from_pod<Col>(TRY(crate::prelude::field(whole, "hi")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .kind = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "kind")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .why = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "why"))))};
}


void Col::show(Printer& p) const {
    if (auto c = std::get_if<CBound>(&cases())) p.choice("CBound", {});
    else if (auto c = std::get_if<CUnbound>(&cases())) p.choice("CUnbound", {});
    else if (auto c = std::get_if<CRigid>(&cases())) p.choice("CRigid", {c->a0});
    else if (auto c = std::get_if<CQ>(&cases())) p.choice("CQ", {c->a0});
    else if (auto c = std::get_if<CFlex>(&cases())) p.choice("CFlex", {c->a0});
}

Pod Col::to_pod() const {
    return std::holds_alternative<CBound>(cases()) ? Pod::choice("CBound", {})
        : std::holds_alternative<CUnbound>(cases()) ? Pod::choice("CUnbound", {})
        : std::holds_alternative<CRigid>(cases()) ? Pod::choice("CRigid", {prism_rtl::to_pod(std::get<CRigid>(cases()).a0)})
        : std::holds_alternative<CQ>(cases()) ? Pod::choice("CQ", {prism_rtl::to_pod(std::get<CQ>(cases()).a0)})
        : std::holds_alternative<CFlex>(cases()) ? Pod::choice("CFlex", {prism_rtl::to_pod(std::get<CFlex>(cases()).a0)})
        : Pod();
}

Result<Col> Col::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "CBound" && c->args.size() == 0) return Col(CBound{});
        if (c->ctor == "CUnbound" && c->args.size() == 0) return Col(CUnbound{});
        if (c->ctor == "CRigid" && c->args.size() == 1) return Col(CRigid{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "CQ" && c->args.size() == 1) return Col(CQ{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "CFlex" && c->args.size() == 1) return Col(CFlex{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
    }
    return mismatch<Col>("a Col", p);
}


void Incl::show(Printer& p) const {
    p.record("Incl", {{"sub", sub}, {"sup", sup}, {"file", file}, {"span", span}, {"what", what}, {"forward", forward}});
}

Pod Incl::to_pod() const {
    return Pod::record("Incl", {{"sub", prism_rtl::to_pod(sub)}, {"sup", prism_rtl::to_pod(sup)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}, {"what", prism_rtl::to_pod(what)}, {"forward", prism_rtl::to_pod(forward)}});
}

Result<Incl> Incl::from_pod(const Pod& whole) {
    return Incl{.sub = TRY(prism_rtl::from_pod<Rw>(TRY(crate::prelude::field(whole, "sub")))), .sup = TRY(prism_rtl::from_pod<Rw>(TRY(crate::prelude::field(whole, "sup")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .what = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "what")))), .forward = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "forward"))))};
}


void Rw::show(Printer& p) const {
    p.record("Rw", {{"fams", fams}, {"minus", minus}, {"tail", tail}});
}

Pod Rw::to_pod() const {
    return Pod::record("Rw", {{"fams", prism_rtl::to_pod(fams)}, {"minus", prism_rtl::to_pod(minus)}, {"tail", prism_rtl::to_pod(tail)}});
}

Result<Rw> Rw::from_pod(const Pod& whole) {
    return Rw{.fams = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "fams")))), .minus = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "minus")))), .tail = TRY(prism_rtl::from_pod<Tail>(TRY(crate::prelude::field(whole, "tail"))))};
}


void Scheme::show(Printer& p) const {
    p.record("Scheme", {{"qs", qs}, {"plain_qs", plain_qs}, {"rqs", rqs}, {"cqs", cqs}, {"cjoins", cjoins}, {"bounds", bounds}, {"ty", ty}});
}

Pod Scheme::to_pod() const {
    return Pod::record("Scheme", {{"qs", prism_rtl::to_pod(qs)}, {"plain_qs", prism_rtl::to_pod(plain_qs)}, {"rqs", prism_rtl::to_pod(rqs)}, {"cqs", prism_rtl::to_pod(cqs)}, {"cjoins", prism_rtl::to_pod(cjoins)}, {"bounds", prism_rtl::to_pod(bounds)}, {"ty", prism_rtl::to_pod(ty)}});
}

Result<Scheme> Scheme::from_pod(const Pod& whole) {
    return Scheme{.qs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "qs")))), .plain_qs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "plain_qs")))), .rqs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "rqs")))), .cqs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "cqs")))), .cjoins = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "cjoins")))), .bounds = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "bounds")))), .ty = TRY(prism_rtl::from_pod<Ty>(TRY(crate::prelude::field(whole, "ty"))))};
}


bool St::operator==(const St& o) const { return next == o.next && tys == o.tys && infos == o.infos && rows == o.rows && lacks == o.lacks && wants == o.wants && incls == o.incls && diags == o.diags && level == o.level && file == o.file && color == o.color && color_why == o.color_why && color_flex == o.color_flex && cols == o.cols && cleqs == o.cleqs && col_q == o.col_q && col_up == o.col_up && deferred == o.deferred && binder_at == o.binder_at && row_names == o.row_names && layer_qs == o.layer_qs && field_qs == o.field_qs && recording == o.recording && typed == o.typed && choices == o.choices && size_tys == o.size_tys; }

void St::show(Printer& p) const {
    p.record("St", {{"next", next}, {"tys", tys}, {"infos", infos}, {"rows", rows}, {"lacks", lacks}, {"wants", wants}, {"incls", incls}, {"diags", diags}, {"level", level}, {"file", file}, {"color", color}, {"color_why", color_why}, {"color_flex", color_flex}, {"cols", cols}, {"cleqs", cleqs}, {"col_q", col_q}, {"col_up", col_up}, {"deferred", deferred}, {"binder_at", binder_at}, {"row_names", row_names}, {"layer_qs", layer_qs}, {"field_qs", field_qs}, {"recording", recording}, {"typed", typed}, {"choices", choices}, {"size_tys", size_tys}});
}

Pod St::to_pod() const {
    return Pod::record("St", {{"next", prism_rtl::to_pod(next)}, {"tys", prism_rtl::to_pod(tys)}, {"infos", prism_rtl::to_pod(infos)}, {"rows", prism_rtl::to_pod(rows)}, {"lacks", prism_rtl::to_pod(lacks)}, {"wants", prism_rtl::to_pod(wants)}, {"incls", prism_rtl::to_pod(incls)}, {"diags", prism_rtl::to_pod(diags)}, {"level", prism_rtl::to_pod(level)}, {"file", prism_rtl::to_pod(file)}, {"color", prism_rtl::to_pod(color)}, {"color_why", prism_rtl::to_pod(color_why)}, {"color_flex", prism_rtl::to_pod(color_flex)}, {"cols", prism_rtl::to_pod(cols)}, {"cleqs", prism_rtl::to_pod(cleqs)}, {"col_q", prism_rtl::to_pod(col_q)}, {"col_up", prism_rtl::to_pod(col_up)}, {"deferred", prism_rtl::to_pod(deferred)}, {"binder_at", prism_rtl::to_pod(binder_at)}, {"row_names", prism_rtl::to_pod(row_names)}, {"layer_qs", prism_rtl::to_pod(layer_qs)}, {"field_qs", prism_rtl::to_pod(field_qs)}, {"recording", prism_rtl::to_pod(recording)}, {"typed", prism_rtl::to_pod(typed)}, {"choices", prism_rtl::to_pod(choices)}, {"size_tys", prism_rtl::to_pod(size_tys)}});
}

Result<St> St::from_pod(const Pod& whole) {
    return St{.next = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "next")))), .tys = TRY(prism_rtl::from_pod<Map<Nat, Ty>>(TRY(crate::prelude::field(whole, "tys")))), .infos = TRY(prism_rtl::from_pod<Map<Nat, VInfo>>(TRY(crate::prelude::field(whole, "infos")))), .rows = TRY(prism_rtl::from_pod<Map<Nat, Rw>>(TRY(crate::prelude::field(whole, "rows")))), .lacks = TRY(prism_rtl::from_pod<Map<Nat, Array<Text>>>(TRY(crate::prelude::field(whole, "lacks")))), .wants = TRY(prism_rtl::from_pod<Array<Want>>(TRY(crate::prelude::field(whole, "wants")))), .incls = TRY(prism_rtl::from_pod<Array<Incl>>(TRY(crate::prelude::field(whole, "incls")))), .diags = TRY(prism_rtl::from_pod<Array<crate::check::errors::CDiag>>(TRY(crate::prelude::field(whole, "diags")))), .level = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "level")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .color = TRY(prism_rtl::from_pod<Col>(TRY(crate::prelude::field(whole, "color")))), .color_why = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "color_why")))), .color_flex = TRY(prism_rtl::from_pod<Array<std::tuple<Col, Text, crate::syntax::Range>>>(TRY(crate::prelude::field(whole, "color_flex")))), .cols = TRY(prism_rtl::from_pod<Map<Nat, Col>>(TRY(crate::prelude::field(whole, "cols")))), .cleqs = TRY(prism_rtl::from_pod<Array<CLeq>>(TRY(crate::prelude::field(whole, "cleqs")))), .col_q = TRY(prism_rtl::from_pod<Map<Nat, Text>>(TRY(crate::prelude::field(whole, "col_q")))), .col_up = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "col_up")))), .deferred = TRY(prism_rtl::from_pod<Array<std::tuple<Ty, Ty, crate::syntax::Range>>>(TRY(crate::prelude::field(whole, "deferred")))), .binder_at = TRY(prism_rtl::from_pod<Map<Nat, crate::syntax::Range>>(TRY(crate::prelude::field(whole, "binder_at")))), .row_names = TRY(prism_rtl::from_pod<Map<Nat, Text>>(TRY(crate::prelude::field(whole, "row_names")))), .layer_qs = TRY(prism_rtl::from_pod<Array<std::tuple<Ty, crate::syntax::Range, Text>>>(TRY(crate::prelude::field(whole, "layer_qs")))), .field_qs = TRY(prism_rtl::from_pod<Array<crate::check::types::unify::FieldQ>>(TRY(crate::prelude::field(whole, "field_qs")))), .recording = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "recording")))), .typed = TRY(prism_rtl::from_pod<crate::check::typed::TProgram>(TRY(crate::prelude::field(whole, "typed")))), .choices = TRY(prism_rtl::from_pod<Map<Text, Array<Text>>>(TRY(crate::prelude::field(whole, "choices")))), .size_tys = TRY(prism_rtl::from_pod<Map<Text, Ty>>(TRY(crate::prelude::field(whole, "size_tys"))))};
}


void Tail::show(Printer& p) const {
    if (auto c = std::get_if<TlClosed>(&cases())) p.choice("TlClosed", {});
    else if (auto c = std::get_if<TlFlex>(&cases())) p.choice("TlFlex", {c->a0});
    else if (auto c = std::get_if<TlRigid>(&cases())) p.choice("TlRigid", {c->a0});
    else if (auto c = std::get_if<TlQ>(&cases())) p.choice("TlQ", {c->a0});
}

Pod Tail::to_pod() const {
    return std::holds_alternative<TlClosed>(cases()) ? Pod::choice("TlClosed", {})
        : std::holds_alternative<TlFlex>(cases()) ? Pod::choice("TlFlex", {prism_rtl::to_pod(std::get<TlFlex>(cases()).a0)})
        : std::holds_alternative<TlRigid>(cases()) ? Pod::choice("TlRigid", {prism_rtl::to_pod(std::get<TlRigid>(cases()).a0)})
        : std::holds_alternative<TlQ>(cases()) ? Pod::choice("TlQ", {prism_rtl::to_pod(std::get<TlQ>(cases()).a0)})
        : Pod();
}

Result<Tail> Tail::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TlClosed" && c->args.size() == 0) return Tail(TlClosed{});
        if (c->ctor == "TlFlex" && c->args.size() == 1) return Tail(TlFlex{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "TlRigid" && c->args.size() == 1) return Tail(TlRigid{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TlQ" && c->args.size() == 1) return Tail(TlQ{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Tail>("a Tail", p);
}


bool Ty::TyCon::operator==(const TyCon& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ty::TyFn::operator==(const TyFn& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool Ty::TyTuple::operator==(const TyTuple& o) const { return a0 == o.a0; }

bool Ty::TyArray::operator==(const TyArray& o) const { return a0 == o.a0; }

bool Ty::TyMap::operator==(const TyMap& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ty::TySig::operator==(const TySig& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ty::TyAt::operator==(const TyAt& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ty::TyElem::operator==(const TyElem& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ty::TyAssoc::operator==(const TyAssoc& o) const { return a0 == o.a0 && a1 == o.a1; }

void Ty::show(Printer& p) const {
    if (auto c = std::get_if<TyFlex>(&cases())) p.choice("TyFlex", {c->a0});
    else if (auto c = std::get_if<TyRigid>(&cases())) p.choice("TyRigid", {c->a0});
    else if (auto c = std::get_if<TyQ>(&cases())) p.choice("TyQ", {c->a0});
    else if (auto c = std::get_if<TyCon>(&cases())) p.choice("TyCon", {c->a0, c->a1});
    else if (auto c = std::get_if<TyFn>(&cases())) p.choice("TyFn", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<TyTuple>(&cases())) p.choice("TyTuple", {c->a0});
    else if (auto c = std::get_if<TyArray>(&cases())) p.choice("TyArray", {c->a0});
    else if (auto c = std::get_if<TyMap>(&cases())) p.choice("TyMap", {c->a0, c->a1});
    else if (auto c = std::get_if<TySig>(&cases())) p.choice("TySig", {c->a0, c->a1});
    else if (auto c = std::get_if<TyAt>(&cases())) p.choice("TyAt", {c->a0, c->a1});
    else if (auto c = std::get_if<TyElem>(&cases())) p.choice("TyElem", {c->a0, c->a1});
    else if (auto c = std::get_if<TyElemAny>(&cases())) p.choice("TyElemAny", {c->a0});
    else if (auto c = std::get_if<TyAssoc>(&cases())) p.choice("TyAssoc", {c->a0, c->a1});
    else if (auto c = std::get_if<TyAny>(&cases())) p.choice("TyAny", {c->a0});
    else if (auto c = std::get_if<TyErr>(&cases())) p.choice("TyErr", {});
}

Pod Ty::to_pod() const {
    return std::holds_alternative<TyFlex>(cases()) ? Pod::choice("TyFlex", {prism_rtl::to_pod(std::get<TyFlex>(cases()).a0)})
        : std::holds_alternative<TyRigid>(cases()) ? Pod::choice("TyRigid", {prism_rtl::to_pod(std::get<TyRigid>(cases()).a0)})
        : std::holds_alternative<TyQ>(cases()) ? Pod::choice("TyQ", {prism_rtl::to_pod(std::get<TyQ>(cases()).a0)})
        : std::holds_alternative<TyCon>(cases()) ? Pod::choice("TyCon", {prism_rtl::to_pod(std::get<TyCon>(cases()).a0), prism_rtl::to_pod(std::get<TyCon>(cases()).a1)})
        : std::holds_alternative<TyFn>(cases()) ? Pod::choice("TyFn", {prism_rtl::to_pod(std::get<TyFn>(cases()).a0), prism_rtl::to_pod(std::get<TyFn>(cases()).a1), prism_rtl::to_pod(std::get<TyFn>(cases()).a2)})
        : std::holds_alternative<TyTuple>(cases()) ? Pod::choice("TyTuple", {prism_rtl::to_pod(std::get<TyTuple>(cases()).a0)})
        : std::holds_alternative<TyArray>(cases()) ? Pod::choice("TyArray", {prism_rtl::to_pod(std::get<TyArray>(cases()).a0)})
        : std::holds_alternative<TyMap>(cases()) ? Pod::choice("TyMap", {prism_rtl::to_pod(std::get<TyMap>(cases()).a0), prism_rtl::to_pod(std::get<TyMap>(cases()).a1)})
        : std::holds_alternative<TySig>(cases()) ? Pod::choice("TySig", {prism_rtl::to_pod(std::get<TySig>(cases()).a0), prism_rtl::to_pod(std::get<TySig>(cases()).a1)})
        : std::holds_alternative<TyAt>(cases()) ? Pod::choice("TyAt", {prism_rtl::to_pod(std::get<TyAt>(cases()).a0), prism_rtl::to_pod(std::get<TyAt>(cases()).a1)})
        : std::holds_alternative<TyElem>(cases()) ? Pod::choice("TyElem", {prism_rtl::to_pod(std::get<TyElem>(cases()).a0), prism_rtl::to_pod(std::get<TyElem>(cases()).a1)})
        : std::holds_alternative<TyElemAny>(cases()) ? Pod::choice("TyElemAny", {prism_rtl::to_pod(std::get<TyElemAny>(cases()).a0)})
        : std::holds_alternative<TyAssoc>(cases()) ? Pod::choice("TyAssoc", {prism_rtl::to_pod(std::get<TyAssoc>(cases()).a0), prism_rtl::to_pod(std::get<TyAssoc>(cases()).a1)})
        : std::holds_alternative<TyAny>(cases()) ? Pod::choice("TyAny", {prism_rtl::to_pod(std::get<TyAny>(cases()).a0)})
        : std::holds_alternative<TyErr>(cases()) ? Pod::choice("TyErr", {})
        : Pod();
}

Result<Ty> Ty::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TyFlex" && c->args.size() == 1) return Ty(TyFlex{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "TyRigid" && c->args.size() == 1) return Ty(TyRigid{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TyQ" && c->args.size() == 1) return Ty(TyQ{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TyCon" && c->args.size() == 2) return Ty(TyCon{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Ty>>(c->args[1]))});
        if (c->ctor == "TyFn" && c->args.size() == 3) return Ty(TyFn{TRY(prism_rtl::from_pod<Col>(c->args[0])), TRY(prism_rtl::from_pod<Array<Ty>>(c->args[1])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[2]))});
        if (c->ctor == "TyTuple" && c->args.size() == 1) return Ty(TyTuple{TRY(prism_rtl::from_pod<Array<Ty>>(c->args[0]))});
        if (c->ctor == "TyArray" && c->args.size() == 1) return Ty(TyArray{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[0]))});
        if (c->ctor == "TyMap" && c->args.size() == 2) return Ty(TyMap{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[1]))});
        if (c->ctor == "TySig" && c->args.size() == 2) return Ty(TySig{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[1]))});
        if (c->ctor == "TyAt" && c->args.size() == 2) return Ty(TyAt{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[0])), TRY(prism_rtl::from_pod<Rw>(c->args[1]))});
        if (c->ctor == "TyElem" && c->args.size() == 2) return Ty(TyElem{TRY(prism_rtl::from_pod<Rw>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[1]))});
        if (c->ctor == "TyElemAny" && c->args.size() == 1) return Ty(TyElemAny{TRY(prism_rtl::from_pod<Rw>(c->args[0]))});
        if (c->ctor == "TyAssoc" && c->args.size() == 2) return Ty(TyAssoc{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[1]))});
        if (c->ctor == "TyAny" && c->args.size() == 1) return Ty(TyAny{TRY(prism_rtl::from_pod<Array<Text>>(c->args[0]))});
        if (c->ctor == "TyErr" && c->args.size() == 0) return Ty(TyErr{});
    }
    return mismatch<Ty>("a Ty", p);
}


void VInfo::show(Printer& p) const {
    p.record("VInfo", {{"plain", plain}, {"level", level}, {"name", name}});
}

Pod VInfo::to_pod() const {
    return Pod::record("VInfo", {{"plain", prism_rtl::to_pod(plain)}, {"level", prism_rtl::to_pod(level)}, {"name", prism_rtl::to_pod(name)}});
}

Result<VInfo> VInfo::from_pod(const Pod& whole) {
    return VInfo{.plain = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "plain")))), .level = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "level")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name"))))};
}


void Want::show(Printer& p) const {
    p.record("Want", {{"cls", cls}, {"ty", ty}, {"file", file}, {"span", span}, {"level", level}});
}

Pod Want::to_pod() const {
    return Pod::record("Want", {{"cls", prism_rtl::to_pod(cls)}, {"ty", prism_rtl::to_pod(ty)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}, {"level", prism_rtl::to_pod(level)}});
}

Result<Want> Want::from_pod(const Pod& whole) {
    return Want{.cls = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "cls")))), .ty = TRY(prism_rtl::from_pod<Ty>(TRY(crate::prelude::field(whole, "ty")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .level = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "level"))))};
}


/// NewSt: fn Nat -> St
St new_st(const Nat& file) {
    return St{.next = Nat(0u), .tys = Map<Nat, Ty>{}, .infos = Map<Nat, VInfo>{}, .rows = Map<Nat, Rw>{}, .lacks = Map<Nat, Array<Text>>{}, .wants = Array<Want>{}, .incls = Array<Incl>{}, .diags = Array<crate::check::errors::CDiag>{}, .level = Nat(0u), .file = file, .color = Col(Col::CBound{}), .color_why = Text::lit(""), .color_flex = Array<std::tuple<Col, Text, crate::syntax::Range>>{}, .cols = Map<Nat, Col>{}, .cleqs = Array<CLeq>{}, .col_q = Map<Nat, Text>{}, .col_up = Map<Text, Text>{}, .deferred = Array<std::tuple<Ty, Ty, crate::syntax::Range>>{}, .binder_at = Map<Nat, crate::syntax::Range>{}, .row_names = Map<Nat, Text>{}, .layer_qs = Array<std::tuple<Ty, crate::syntax::Range, Text>>{}, .field_qs = Array<crate::check::types::unify::FieldQ>{}, .recording = false, .typed = crate::check::typed::empty_typed(), .choices = Map<Text, Array<Text>>{}, .size_tys = Map<Text, Ty>{}};
}


/// Closed: fn [Text] -> Rw
Rw closed(const Array<Text>& fs) {
    return Rw{.fams = sort_texts(fs), .minus = Array<Text>{}, .tail = Tail(Tail::TlClosed{})};
}


/// let emptyRow
Rw empty_row() {
    return Rw{.fams = Array<Text>{}, .minus = Array<Text>{}, .tail = Tail(Tail::TlClosed{})};
}


/// let tInt
Ty t_int() {
    return Ty(Ty::TyCon{Text::lit("Int"), Array<Ty>{}});
}


/// let tNat
Ty t_nat() {
    return Ty(Ty::TyCon{Text::lit("Nat"), Array<Ty>{}});
}


/// let tText
Ty t_text() {
    return Ty(Ty::TyCon{Text::lit("Text"), Array<Ty>{}});
}


/// let tBool
Ty t_bool() {
    return Ty(Ty::TyCon{Text::lit("Bool"), Array<Ty>{}});
}


/// let tUnit
Ty t_unit() {
    return Ty(Ty::TyCon{Text::lit("unit"), Array<Ty>{}});
}


/// let tChar
Ty t_char() {
    return Ty(Ty::TyCon{Text::lit("Char"), Array<Ty>{}});
}


/// let tFloat
Ty t_float() {
    return Ty(Ty::TyCon{Text::lit("Float"), Array<Ty>{}});
}


/// HasText: fn [Text], Text -> Bool
bool has_text(const Array<Text>& xs, const Text& x) {
    return fold(xs, false, [&](const bool& seen, const Text& y) { return prism_rtl::deref(seen) || (y == x); });
}


/// HasNat: fn [Nat], Nat -> Bool
bool has_nat(const Array<Nat>& xs, const Nat& x) {
    return fold(xs, false, [&](const bool& seen, const Nat& y) { return prism_rtl::deref(seen) || (y == x); });
}


/// AddText: fn [Text], Text -> [Text]
Array<Text> add_text(const Array<Text>& xs, const Text& x) {
    return has_text(xs, x) ? xs : crate::prelude::push(xs, x);
}


/// UnionTexts: fn [Text], [Text] -> [Text]
Array<Text> union_texts(const Array<Text>& xs, const Array<Text>& ys) {
    return fold(ys, xs, [&](const Array<Text>& acc, const Text& y) { return add_text(acc, y); });
}


/// MinusTexts: fn [Text], [Text] -> [Text]
Array<Text> minus_texts(const Array<Text>& xs, const Array<Text>& ys) {
    return filter(xs, [&](const Text& x) { return !has_text(ys, x); });
}


/// InterTexts: fn [Text], [Text] -> [Text]
Array<Text> inter_texts(const Array<Text>& xs, const Array<Text>& ys) {
    return filter(xs, [&](const Text& x) { return has_text(ys, x); });
}


/// AddNat: fn [Nat], Nat -> [Nat]
Array<Nat> add_nat(const Array<Nat>& xs, const Nat& x) {
    return has_nat(xs, x) ? xs : crate::prelude::push(xs, x);
}


/// SortTexts: fn [Text] -> [Text]
Array<Text> sort_texts(const Array<Text>& xs) {
    return fold(xs, Array<Text>{}, [&](const Array<Text>& acc, const Text& x) {
        return has_text(acc, x)
            ? acc
            : append(crate::prelude::push(filter(acc, [&](const Text& y) { return y < x; }), x), filter(acc, [&](const Text& y) { return !(y < x); }));
    });
}


/// BareName: fn Text -> Text
Text bare_name(const Text& q) {
    return or_(crate::syntax::lexer::chars::last(split_on(q, Text::lit("."))), q);
}


/// FreshVar: fn St, Bool, Text -> ((Ty, St))
std::tuple<Ty, St> fresh_var(const St& st, const bool& plain, const Text& name) {
    auto n = st.next;
    auto st2 = ({
        St this_ = st;
        this_.next = this_.next + Nat(1u);
        this_.infos = insert(this_.infos, n, VInfo{.plain = plain, .level = this_.level, .name = name});
        (std::move(this_));
    });
    return std::tuple{Ty(Ty::TyFlex{n}), st2};
}


/// FreshCol: fn St -> ((Col, St))
std::tuple<Col, St> fresh_col(const St& st) {
    auto n = st.next;
    auto st2 = ({
        St this_ = st;
        this_.next = this_.next + Nat(1u);
        this_.infos = insert(this_.infos, n, VInfo{.plain = false, .level = this_.level, .name = Text::lit("")});
        (std::move(this_));
    });
    return std::tuple{Col(Col::CFlex{n}), st2};
}


/// StackOf: unbounded fn St, Ty -> Text
Text stack_of(const St& st, const Ty& t) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<Ty::TySig>(_m)) {
        auto&& s = prism_rtl::as<Ty::TySig>(_m).a0;
        auto&& i = prism_rtl::as<Ty::TySig>(_m).a1;
        return prism_rtl::cat(s, stack_of(st, prism_rtl::deref(i)));
    }
    if (prism_rtl::is<Ty::TyAt>(_m)) {
        auto&& i = prism_rtl::as<Ty::TyAt>(_m).a0;
        return prism_rtl::cat("@", stack_of(st, prism_rtl::deref(i)));
    }
    {
        return Text::lit("");
    }
}


prism_rtl::Turn<Text> StackOf::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(crate::check::types::recording::start_walk(st_1, t_2), [=](Ty walk_7923) {
        return ({
            prism_rtl::is<Ty::TySig>(walk_7923) ? ({
            auto&& s = prism_rtl::as<Ty::TySig>(walk_7923).a0;
            auto&& i = prism_rtl::as<Ty::TySig>(walk_7923).a1;
            call_then(start_stack_of(st_1, prism_rtl::deref(i)), [=](Text stack_of_7956) { return prism_rtl::finished(prism_rtl::cat(s, stack_of_7956)); });
        })
            : prism_rtl::is<Ty::TyAt>(walk_7923) ? ({
            auto&& i = prism_rtl::as<Ty::TyAt>(walk_7923).a0;
            call_then(start_stack_of(st_1, prism_rtl::deref(i)), [=](Text stack_of_7995) { return prism_rtl::finished(prism_rtl::cat("@", stack_of_7995)); });
        })
            : prism_rtl::finished(Text::lit(""));
        });
    });
}


/// `Start StackOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_stack_of(St st, Ty t) {
    return prism_rtl::make_rc<StackOf>(st, t);
}


/// HeadSigil: unbounded fn St, Ty -> Text
Text head_sigil(const St& st, const Ty& t) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<Ty::TySig>(_m)) {
        auto&& s = prism_rtl::as<Ty::TySig>(_m).a0;
        return s;
    }
    if (prism_rtl::is<Ty::TyAt>(_m)) {
        return Text::lit("@");
    }
    {
        return Text::lit("");
    }
}


prism_rtl::Turn<Text> HeadSigil::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(crate::check::types::recording::start_walk(st_1, t_2), [=](Ty walk_8173) {
        return ({
            prism_rtl::is<Ty::TySig>(walk_8173) ? ({
            auto&& s = prism_rtl::as<Ty::TySig>(walk_8173).a0;
            prism_rtl::finished(s);
        })
            : prism_rtl::is<Ty::TyAt>(walk_8173) ? prism_rtl::finished(Text::lit("@"))
            : prism_rtl::finished(Text::lit(""));
        });
    });
}


/// `Start HeadSigil, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_head_sigil(St st, Ty t) {
    return prism_rtl::make_rc<HeadSigil>(st, t);
}


/// IsFlexVar: unbounded fn St, Ty -> Bool
bool is_flex_var(const St& st, const Ty& t) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<Ty::TyFlex>(_m)) {
        return true;
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsFlexVar::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(crate::check::types::recording::start_walk(st_1, t_2), [=](Ty walk_8322) {
        return ({
            prism_rtl::is<Ty::TyFlex>(walk_8322) ? prism_rtl::finished(true)
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsFlexVar, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_flex_var(St st, Ty t) {
    return prism_rtl::make_rc<IsFlexVar>(st, t);
}


/// IsFreeHeaded: unbounded fn St, Ty -> Bool
bool is_free_headed(const St& st, const Ty& t) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<Ty::TyFlex>(_m)) {
        auto&& n = prism_rtl::as<Ty::TyFlex>(_m).a0;
        return !prism_rtl::deref(crate::check::types::recording::info_of(st, n)).plain;
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsFreeHeaded::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(crate::check::types::recording::start_walk(st_1, t_2), [=](Ty walk_8530) {
        return ({
            prism_rtl::is<Ty::TyFlex>(walk_8530) ? ({
            auto&& n = prism_rtl::as<Ty::TyFlex>(walk_8530).a0;
            prism_rtl::finished(!prism_rtl::deref(crate::check::types::recording::info_of(st_1, n)).plain);
        })
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsFreeHeaded, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_free_headed(St st, Ty t) {
    return prism_rtl::make_rc<IsFreeHeaded>(st, t);
}


/// WithMarks: fn Text, Ty, Rw -> Ty
Ty with_marks(const Text& marks, const Ty& t, const Rw& rw) {
    return fold(reverse2(crate::syntax::lexer::chars::fold_chars(marks, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                (prism_rtl::finished(crate::prelude::push(acc, c)));
            });
        });
    })))), t, [&](const Ty& acc, const Text& m) {
        return m == Text::lit("@")
            ? Ty(Ty::TyAt{prism_rtl::rc(acc), rw})
            : Ty(Ty::TySig{m, prism_rtl::rc(acc)});
    });
}


/// Reverse2: fn [Text] -> [Text]
Array<Text> reverse2(const Array<Text>& xs) {
    return fold(xs, Array<Text>{}, [&](const Array<Text>& acc, const Text& x) { return append(Array(std::vector{x}), acc); });
}


/// ShowTy: unbounded fn St, Ty -> Text
Text show_ty(const St& st, const Ty& t) {
    return show_ty_in(st, crate::check::types::recording::zonk(st, t), false);
}


prism_rtl::Turn<Text> ShowTy::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(crate::check::types::recording::start_zonk(st_1, t_2), [=](Ty zonk_9256) { return prism_rtl::more(prism_rtl::rc(ShowTyIn(st_1, zonk_9256, false))); });
}


/// `Start ShowTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_ty(St st, Ty t) {
    return prism_rtl::make_rc<ShowTy>(st, t);
}


/// ShowTyIn: unbounded fn St, Ty, Bool -> Text
Text show_ty_in(const St& st, const Ty& t, const bool& nested) {
    if (prism_rtl::is<Ty::TyFlex>(t)) {
        auto&& n = prism_rtl::as<Ty::TyFlex>(t).a0;
        return prism_rtl::cat("t", n);
    }
    if (prism_rtl::is<Ty::TyRigid>(t)) {
        auto&& n = prism_rtl::as<Ty::TyRigid>(t).a0;
        return n;
    }
    if (prism_rtl::is<Ty::TyQ>(t)) {
        auto&& n = prism_rtl::as<Ty::TyQ>(t).a0;
        return n;
    }
    if (prism_rtl::is<Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<Ty::TyCon>(t).a0;
        auto&& m9418_3_1 = prism_rtl::as<Ty::TyCon>(t).a1;
        if (m9418_3_1.size() == 0u) {
            return bare_name(n);
        }
    }
    if (prism_rtl::is<Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<Ty::TyCon>(t).a1;
        auto inner = prism_rtl::cat(bare_name(n), concat(run_to_end(each_job(args, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](Ty p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
                return ({
                    auto a = p0;
                    call_then(start_show_ty_in(st_1_2, a, true), [=](Text show_ty_in_9588) { return prism_rtl::finished(prism_rtl::cat(" ", show_ty_in_9588)); });
                });
            }));
            });
        })));
        })))));
        return nested ? prism_rtl::cat("(", inner, ")") : inner;
    }
    if (prism_rtl::is<Ty::TyFn>(t)) {
        auto&& c = prism_rtl::as<Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<Ty::TyFn>(t).a2;
        auto inner = prism_rtl::cat(show_col(c), "fn ", crate::syntax::lexer::chars::join(run_to_end(each_job(ps, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](Ty p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
                return ({
                    auto p_ = p0;
                    (prism_rtl::more(prism_rtl::rc(ShowTyIn(st_1_2, p_, false))));
                });
            }));
            });
        })));
        }))), Text::lit(", ")), " -> ", show_ty_in(st, prism_rtl::deref(prism_rtl::deref(res)), false));
        return nested ? prism_rtl::cat("(", inner, ")") : inner;
    }
    if (prism_rtl::is<Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<Ty::TyTuple>(t).a0;
        return prism_rtl::cat("((", crate::syntax::lexer::chars::join(run_to_end(each_job(ts, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](Ty p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(ShowTyIn(st_1_2, a, false))));
                });
            }));
            });
        })));
        }))), Text::lit(", ")), "))");
    }
    if (prism_rtl::is<Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<Ty::TyArray>(t).a0;
        auto inner = show_ty_in(st, prism_rtl::deref(prism_rtl::deref(e)), false);
        return crate::syntax::lexer::chars::has_prefix(inner, Text::lit("["))
            ? prism_rtl::cat("[ ", inner, " ]")
            : prism_rtl::cat("[", inner, "]");
    }
    if (prism_rtl::is<Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<Ty::TyMap>(t).a1;
        auto inner = prism_rtl::cat(show_ty_in(st, prism_rtl::deref(prism_rtl::deref(k)), true), " ==> ", show_ty_in(st, prism_rtl::deref(prism_rtl::deref(v_)), true));
        return nested ? prism_rtl::cat("(", inner, ")") : inner;
    }
    if (prism_rtl::is<Ty::TySig>(t)) {
        auto&& s = prism_rtl::as<Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<Ty::TySig>(t).a1;
        return prism_rtl::cat(s, show_ty_in(st, prism_rtl::deref(prism_rtl::deref(i)), true));
    }
    if (prism_rtl::is<Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<Ty::TyAt>(t).a1;
        return prism_rtl::cat("@", show_ty_in(st, prism_rtl::deref(prism_rtl::deref(i)), true));
    }
    if (prism_rtl::is<Ty::TyElem>(t)) {
        auto&& rw = prism_rtl::as<Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<Ty::TyElem>(t).a1;
        auto inner = prism_rtl::cat("Element ", show_row_in(rw, true), " ", show_ty_in(st, prism_rtl::deref(prism_rtl::deref(o)), true));
        return nested ? prism_rtl::cat("(", inner, ")") : inner;
    }
    if (prism_rtl::is<Ty::TyElemAny>(t)) {
        auto&& rw = prism_rtl::as<Ty::TyElemAny>(t).a0;
        return nested
            ? prism_rtl::cat("(Elem ", show_row_in(rw, true), ")")
            : prism_rtl::cat("Elem ", show_row_in(rw, true));
    }
    if (prism_rtl::is<Ty::TyAssoc>(t)) {
        auto&& n = prism_rtl::as<Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<Ty::TyAssoc>(t).a1;
        return nested
            ? prism_rtl::cat("(", n, " ", show_ty_in(st, prism_rtl::deref(prism_rtl::deref(a)), true), ")")
            : prism_rtl::cat(n, " ", show_ty_in(st, prism_rtl::deref(prism_rtl::deref(a)), true));
    }
    if (prism_rtl::is<Ty::TyAny>(t)) {
        auto&& ts = prism_rtl::as<Ty::TyAny>(t).a0;
        return prism_rtl::cat("any ", crate::syntax::lexer::chars::join(each(ts, [&](const Text& x) { return prism_rtl::cat("^", bare_name(x)); }), Text::lit(" ")));
    }
    if (prism_rtl::is<Ty::TyErr>(t)) {
        return Text::lit("?");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> ShowTyIn::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& nested = this->nested;
    return ({
        prism_rtl::is<Ty::TyFlex>(t) ? ({
        auto&& n = prism_rtl::as<Ty::TyFlex>(t).a0;
        prism_rtl::finished(prism_rtl::cat("t", n));
    })
        : prism_rtl::is<Ty::TyRigid>(t) ? ({
        auto&& n = prism_rtl::as<Ty::TyRigid>(t).a0;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<Ty::TyQ>(t) ? ({
        auto&& n = prism_rtl::as<Ty::TyQ>(t).a0;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<Ty::TyCon>(t) && ({
        auto&& n = prism_rtl::as<Ty::TyCon>(t).a0;
        auto&& m9418_3_1 = prism_rtl::as<Ty::TyCon>(t).a1;
        (m9418_3_1.size() == 0u);
    }) ? ({
        auto&& n = prism_rtl::as<Ty::TyCon>(t).a0;
        auto&& m9418_3_1 = prism_rtl::as<Ty::TyCon>(t).a1;
        prism_rtl::finished(bare_name(n));
    })
        : prism_rtl::is<Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto n_2 = n;
        auto nested_3 = prism_rtl::deref(nested);
        auto st_4 = st;
        call_value(each_job(args_1, ({
        auto st_4_5 = st_4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=, st_4_5 = std::move(st_4_5)](Ty p0) {
        return ({
            auto st_4_5_5 = st_4_5;
            entered(once_job([=, st_4_5_5 = std::move(st_4_5_5)]() {
            return ({
                auto a = p0;
                call_then(start_show_ty_in(st_4_5_5, a, true), [=](Text show_ty_in_9588) { return prism_rtl::finished(prism_rtl::cat(" ", show_ty_in_9588)); });
            });
        }));
        });
    })));
    })), [=, n_2 = std::move(n_2), nested_3 = std::move(nested_3)](Array<Text> each_9569) {
        return ({
            auto inner = prism_rtl::cat(bare_name(n_2), concat(each_9569));
            nested_3
            ? prism_rtl::finished(prism_rtl::cat("(", inner, ")"))
            : prism_rtl::finished(inner);
        });
    });
    });
    })
        : prism_rtl::is<Ty::TyFn>(t) ? ({
        auto&& c = prism_rtl::as<Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<Ty::TyFn>(t).a2;
        ({
        auto c_1 = c;
        auto nested_2 = prism_rtl::deref(nested);
        auto ps_3 = ps;
        auto res_4 = prism_rtl::deref(prism_rtl::deref(res));
        auto st_5 = st;
        call_value(each_job(ps_3, ({
        auto st_5_6 = st_5;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=, st_5_6 = std::move(st_5_6)](Ty p0) {
        return ({
            auto st_5_6_6 = st_5_6;
            entered(once_job([=, st_5_6_6 = std::move(st_5_6_6)]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(ShowTyIn(st_5_6_6, p_, false))));
            });
        }));
        });
    })));
    })), [=, c_1 = std::move(c_1), nested_2 = std::move(nested_2), res_4 = std::move(res_4)](Array<Text> each_9720) {
        return call_then(start_show_ty_in(st_5, res_4, false), [=](Text show_ty_in_9768) {
            return ({
                auto inner = prism_rtl::cat(show_col(c_1), "fn ", crate::syntax::lexer::chars::join(each_9720, Text::lit(", ")), " -> ", show_ty_in_9768);
                nested_2
                ? prism_rtl::finished(prism_rtl::cat("(", inner, ")"))
                : prism_rtl::finished(inner);
            });
        });
    });
    });
    })
        : prism_rtl::is<Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<Ty::TyTuple>(t).a0;
        ({
        auto st_1 = st;
        auto ts_2 = ts;
        call_value(each_job(ts_2, ({
        auto st_1_3 = st_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=, st_1_3 = std::move(st_1_3)](Ty p0) {
        return ({
            auto st_1_3_3 = st_1_3;
            entered(once_job([=, st_1_3_3 = std::move(st_1_3_3)]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ShowTyIn(st_1_3_3, a, false))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_9863) { return prism_rtl::finished(prism_rtl::cat("((", crate::syntax::lexer::chars::join(each_9863, Text::lit(", ")), "))")); });
    });
    })
        : prism_rtl::is<Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<Ty::TyArray>(t).a0;
        ({
        auto e_1 = prism_rtl::deref(prism_rtl::deref(e));
        auto st_2 = st;
        call_then(start_show_ty_in(st_2, e_1, false), [=](Text show_ty_in_9945) {
        return ({
            auto inner = show_ty_in_9945;
            (crate::syntax::lexer::chars::has_prefix(inner, Text::lit("["))
            ? prism_rtl::finished(prism_rtl::cat("[ ", inner, " ]"))
            : prism_rtl::finished(prism_rtl::cat("[", inner, "]")));
        });
    });
    });
    })
        : prism_rtl::is<Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<Ty::TyMap>(t).a1;
        ({
        auto k_1 = prism_rtl::deref(prism_rtl::deref(k));
        auto nested_2 = prism_rtl::deref(nested);
        auto st_3 = st;
        auto v__4 = prism_rtl::deref(prism_rtl::deref(v_));
        call_then(start_show_ty_in(st_3, k_1, true), [=, nested_2 = std::move(nested_2), v__4 = std::move(v__4)](Text show_ty_in_10072) {
        return call_then(start_show_ty_in(st_3, v__4, true), [=](Text show_ty_in_10099) {
            return ({
                auto inner = prism_rtl::cat(show_ty_in_10072, " ==> ", show_ty_in_10099);
                nested_2
                ? prism_rtl::finished(prism_rtl::cat("(", inner, ")"))
                : prism_rtl::finished(inner);
            });
        });
    });
    });
    })
        : prism_rtl::is<Ty::TySig>(t) ? ({
        auto&& s = prism_rtl::as<Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<Ty::TySig>(t).a1;
        ({
        auto i_1 = prism_rtl::deref(prism_rtl::deref(i));
        auto s_2 = s;
        auto st_3 = st;
        call_then(start_show_ty_in(st_3, i_1, true), [=, s_2 = std::move(s_2)](Text show_ty_in_10186) { return prism_rtl::finished(prism_rtl::cat(s_2, show_ty_in_10186)); });
    });
    })
        : prism_rtl::is<Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<Ty::TyAt>(t).a1;
        ({
        auto i_1 = prism_rtl::deref(prism_rtl::deref(i));
        auto st_2 = st;
        call_then(start_show_ty_in(st_2, i_1, true), [=](Text show_ty_in_10228) { return prism_rtl::finished(prism_rtl::cat("@", show_ty_in_10228)); });
    });
    })
        : prism_rtl::is<Ty::TyElem>(t) ? ({
        auto&& rw = prism_rtl::as<Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<Ty::TyElem>(t).a1;
        ({
        auto nested_1 = prism_rtl::deref(nested);
        auto o_2 = prism_rtl::deref(prism_rtl::deref(o));
        auto rw_3 = rw;
        auto st_4 = st;
        call_then(start_show_ty_in(st_4, o_2, true), [=, nested_1 = std::move(nested_1), rw_3 = std::move(rw_3)](Text show_ty_in_10320) {
        return ({
            auto inner = prism_rtl::cat("Element ", show_row_in(rw_3, true), " ", show_ty_in_10320);
            nested_1
            ? prism_rtl::finished(prism_rtl::cat("(", inner, ")"))
            : prism_rtl::finished(inner);
        });
    });
    });
    })
        : prism_rtl::is<Ty::TyElemAny>(t) ? ({
        auto&& rw = prism_rtl::as<Ty::TyElemAny>(t).a0;
        prism_rtl::deref(nested)
        ? prism_rtl::finished(prism_rtl::cat("(Elem ", show_row_in(rw, true), ")"))
        : prism_rtl::finished(prism_rtl::cat("Elem ", show_row_in(rw, true)));
    })
        : prism_rtl::is<Ty::TyAssoc>(t) ? ({
        auto&& n = prism_rtl::as<Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<Ty::TyAssoc>(t).a1;
        prism_rtl::deref(nested)
        ? ({
        auto a_1 = prism_rtl::deref(prism_rtl::deref(a));
        auto n_2 = n;
        auto st_3 = st;
        call_then(start_show_ty_in(st_3, a_1, true), [=, n_2 = std::move(n_2)](Text show_ty_in_10515) { return prism_rtl::finished(prism_rtl::cat("(", n_2, " ", show_ty_in_10515, ")")); });
    })
        : ({
        auto a_1 = prism_rtl::deref(prism_rtl::deref(a));
        auto n_2 = n;
        auto st_3 = st;
        call_then(start_show_ty_in(st_3, a_1, true), [=, n_2 = std::move(n_2)](Text show_ty_in_10551) { return prism_rtl::finished(prism_rtl::cat(n_2, " ", show_ty_in_10551)); });
    });
    })
        : prism_rtl::is<Ty::TyAny>(t) ? ({
        auto&& ts = prism_rtl::as<Ty::TyAny>(t).a0;
        prism_rtl::finished(prism_rtl::cat("any ", crate::syntax::lexer::chars::join(each(ts, [&](const Text& x) { return prism_rtl::cat("^", bare_name(x)); }), Text::lit(" "))));
    })
        : prism_rtl::is<Ty::TyErr>(t) ? prism_rtl::finished(Text::lit("?"))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ShowTyIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_ty_in(St st, Ty t, bool nested) {
    return prism_rtl::make_rc<ShowTyIn>(st, t, nested);
}


/// ShowCol: fn Col -> Text
Text show_col(const Col& col0) {
    if (prism_rtl::is<Col::CBound>(col0)) {
        return Text::lit("");
    }
    if (prism_rtl::is<Col::CUnbound>(col0)) {
        return Text::lit("unbounded ");
    }
    if (prism_rtl::is<Col::CRigid>(col0)) {
        auto&& n = prism_rtl::as<Col::CRigid>(col0).a0;
        return prism_rtl::cat(n, " ");
    }
    if (prism_rtl::is<Col::CQ>(col0)) {
        auto&& n = prism_rtl::as<Col::CQ>(col0).a0;
        return prism_rtl::cat(n, " ");
    }
    if (prism_rtl::is<Col::CFlex>(col0)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ShowRow: fn Rw -> Text
Text show_row(const Rw& rw) {
    return show_row_in(rw, false);
}


/// ShowRowIn: fn Rw, Bool -> Text
Text show_row_in(const Rw& rw, const bool& nested) {
    auto fams = each(rw.fams, [&](const Text& f) { return prism_rtl::cat(f, ".*"); });
    auto tail = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = rw.tail;
        if (prism_rtl::is<Tail::TlClosed>(_m)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        if (prism_rtl::is<Tail::TlFlex>(_m)) {
            auto&& n = prism_rtl::as<Tail::TlFlex>(_m).a0;
            _v.set(Array(std::vector{prism_rtl::cat("r", n)}));
            goto _done;
        }
        if (prism_rtl::is<Tail::TlRigid>(_m)) {
            auto&& n = prism_rtl::as<Tail::TlRigid>(_m).a0;
            _v.set(Array(std::vector{n}));
            goto _done;
        }
        if (prism_rtl::is<Tail::TlQ>(_m)) {
            auto&& n = prism_rtl::as<Tail::TlQ>(_m).a0;
            _v.set(Array(std::vector{n}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto parts = append(tail, fams);
    auto minus = len(rw.minus) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" − {", crate::syntax::lexer::chars::join(rw.minus, Text::lit(", ")), "}");
    auto inner = len(parts) == Nat(0u)
        ? Text::lit("unit")
        : crate::syntax::lexer::chars::join(parts, Text::lit(" | "));
    return nested && ((len(parts) > Nat(1u)) || (minus != Text::lit("")))
        ? prism_rtl::cat("(", inner, minus, ")")
        : prism_rtl::cat(inner, minus);
}

}  // namespace crate::check::types


// The module `Check.Types.Colors`, from `target/bootstrap/cpp-src/prismc/check/types/colors.prism`.
namespace crate::check::types::colors {

/// JoinCol: fn Col, Col -> Col
crate::check::types::Col join_col(const crate::check::types::Col& col0, const crate::check::types::Col& col1) {
    auto&& _m = std::tuple{col0, col1};
    if (prism_rtl::is<crate::check::types::Col::CBound>(std::get<0>(_m))) {
        auto&& c = std::get<1>(_m);
        return c;
    }
    if (prism_rtl::is<crate::check::types::Col::CBound>(std::get<1>(_m))) {
        auto&& c = std::get<0>(_m);
        return c;
    }
    if (prism_rtl::is<crate::check::types::Col::CUnbound>(std::get<0>(_m))) {
        return crate::check::types::Col(crate::check::types::Col::CUnbound{});
    }
    if (prism_rtl::is<crate::check::types::Col::CUnbound>(std::get<1>(_m))) {
        return crate::check::types::Col(crate::check::types::Col::CUnbound{});
    }
    {
        auto&& a = std::get<0>(_m);
        auto&& b = std::get<1>(_m);
        return a == b ? a : crate::check::types::Col(crate::check::types::Col::CUnbound{});
    }
    prism_rtl::unreachable("no arm matched");
}


/// ColLeq: fn Col, Col -> Bool
bool col_leq(const crate::check::types::Col& a, const crate::check::types::Col& b) {
    return join_col(a, b) == b;
}


/// ColWord: fn Col -> Text
Text col_word(const crate::check::types::Col& col0) {
    if (prism_rtl::is<crate::check::types::Col::CBound>(col0)) {
        return Text::lit("bounded");
    }
    if (prism_rtl::is<crate::check::types::Col::CUnbound>(col0)) {
        return Text::lit("unbounded");
    }
    if (prism_rtl::is<crate::check::types::Col::CRigid>(col0)) {
        auto&& n = prism_rtl::as<crate::check::types::Col::CRigid>(col0).a0;
        return prism_rtl::cat("`", n, "`-colored");
    }
    if (prism_rtl::is<crate::check::types::Col::CQ>(col0)) {
        auto&& n = prism_rtl::as<crate::check::types::Col::CQ>(col0).a0;
        return prism_rtl::cat("`", n, "`-colored");
    }
    if (prism_rtl::is<crate::check::types::Col::CFlex>(col0)) {
        return Text::lit("bounded");
    }
    prism_rtl::unreachable("no arm matched");
}


/// UseColor: unbounded fn St, Col, Text, Range -> St
crate::check::types::St use_color(const crate::check::types::St& st, const crate::check::types::Col& c0, const Text& why, const crate::syntax::Range& span) {
    auto&& _m = walk_col(st, c0);
    if (prism_rtl::is<crate::check::types::Col::CFlex>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(_m).a0;
        crate::check::types::St this_ = st;
        this_.color_flex = crate::prelude::push(this_.color_flex, std::tuple{crate::check::types::Col(crate::check::types::Col::CFlex{n}), why, span});
        return this_;
    }
    {
        auto&& c = _m;
        return join_known(st, c, why);
    }
}


prism_rtl::Turn<crate::check::types::St> UseColor::cycle() const {
    const auto& st = this->st;
    const auto& c0 = this->c0;
    const auto& why = this->why;
    const auto& span = this->span;
    auto c0_1 = c0;
    auto span_2 = span;
    auto st_3 = st;
    auto why_4 = why;
    return call_then(start_walk_col(st_3, c0_1), [=](crate::check::types::Col walk_col_1582) {
        return ({
            prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_1582) ? ({
            auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_1582).a0;
            prism_rtl::finished(({
            crate::check::types::St this_ = st_3;
            this_.color_flex = crate::prelude::push(this_.color_flex, std::tuple{crate::check::types::Col(crate::check::types::Col::CFlex{n}), why_4, span_2});
            (std::move(this_));
        }));
        })
            : ({
            auto&& c = walk_col_1582;
            prism_rtl::finished(join_known(st_3, c, why_4));
        });
        });
    });
}


/// `Start UseColor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_use_color(crate::check::types::St st, crate::check::types::Col c0, Text why, crate::syntax::Range span) {
    return prism_rtl::make_rc<UseColor>(st, c0, why, span);
}


/// JoinKnown: fn St, Col, Text -> St
crate::check::types::St join_known(const crate::check::types::St& st, const crate::check::types::Col& c0, const Text& why) {
    auto c = up_col(st, c0);
    crate::check::types::St this_ = st;
    if (!col_leq(c, this_.color)) {
        this_.color_why = why;
    }
    this_.color = join_col(this_.color, c);
    return this_;
}


/// UpCol: fn St, Col -> Col
crate::check::types::Col up_col(const crate::check::types::St& st, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CRigid>(col1)) {
        auto&& n = prism_rtl::as<crate::check::types::Col::CRigid>(col1).a0;
        auto&& _m = crate::prelude::get(st.col_up, n);
        if (prism_rtl::is_some(_m)) {
            auto&& up = prism_rtl::some_of(_m);
            return crate::check::types::Col(crate::check::types::Col::CRigid{up});
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::Col(crate::check::types::Col::CRigid{n});
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        auto&& c = col1;
        return c;
    }
}


/// WalkCol: unbounded fn St, Col -> Col
crate::check::types::Col walk_col(const crate::check::types::St& st, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CFlex>(col1)) {
        auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(col1).a0;
        auto&& _m = crate::prelude::get(st.cols, n);
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            return walk_col(st, c);
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::Col(crate::check::types::Col::CFlex{n});
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        auto&& c = col1;
        return c;
    }
}


prism_rtl::Turn<crate::check::types::Col> WalkCol::cycle() const {
    const auto& st = this->st;
    const auto& col1 = this->col1;
    return ({
        prism_rtl::is<crate::check::types::Col::CFlex>(col1) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(col1).a0;
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(st).cols, n);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(WalkCol(st, c)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::Col(crate::check::types::Col::CFlex{n}))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : ({
        auto&& c = col1;
        prism_rtl::finished(c);
    });
    });
}


/// `Start WalkCol, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Col> start_walk_col(crate::check::types::St st, crate::check::types::Col col1) {
    return prism_rtl::make_rc<WalkCol>(st, col1);
}


/// IsRigidCol: fn Col -> Bool
bool is_rigid_col(const crate::check::types::Col& col0) {
    if (prism_rtl::is<crate::check::types::Col::CRigid>(col0)) {
        return true;
    }
    {
        return false;
    }
}


/// IsOwnCol: fn St, Col -> Bool
bool is_own_col(const crate::check::types::St& s, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CFlex>(col1)) {
        auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(col1).a0;
        return prism_rtl::deref(crate::check::types::recording::info_of(s, n)).level > s.level;
    }
    {
        return false;
    }
}


/// IsFlexCol: fn Col -> Bool
bool is_flex_col(const crate::check::types::Col& col0) {
    if (prism_rtl::is<crate::check::types::Col::CFlex>(col0)) {
        return true;
    }
    {
        return false;
    }
}


/// SettledCol: unbounded fn St, Col -> Col
crate::check::types::Col settled_col(const crate::check::types::St& st, const crate::check::types::Col& c) {
    auto&& _m = walk_col(st, c);
    if (prism_rtl::is<crate::check::types::Col::CFlex>(_m)) {
        return crate::check::types::Col(crate::check::types::Col::CBound{});
    }
    {
        auto&& other = _m;
        return other;
    }
}


prism_rtl::Turn<crate::check::types::Col> SettledCol::cycle() const {
    const auto& st = this->st;
    const auto& c = this->c;
    auto c_1 = c;
    auto st_2 = st;
    return call_then(start_walk_col(st_2, c_1), [=](crate::check::types::Col walk_col_2936) {
        return ({
            prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_2936) ? prism_rtl::finished(crate::check::types::Col(crate::check::types::Col::CBound{}))
            : ({
            auto&& other = walk_col_2936;
            prism_rtl::finished(other);
        });
        });
    });
}


/// `Start SettledCol, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Col> start_settled_col(crate::check::types::St st, crate::check::types::Col c) {
    return prism_rtl::make_rc<SettledCol>(st, c);
}


/// UnifyCol: unbounded fn St, Col, Col -> ((Text, St))
std::tuple<Text, crate::check::types::St> unify_col(const crate::check::types::St& st, const crate::check::types::Col& a0, const crate::check::types::Col& b0) {
    auto a = walk_col(st, a0);
    auto b = walk_col(st, b0);
    return a == b
        ? std::tuple{Text::lit(""), st}
        : ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, crate::check::types::St>> _v;
        auto&& _m = std::tuple{a, b};
        if (prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m))) {
            auto&& x = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
            auto&& other = std::get<1>(_m);
            _v.set(std::tuple{Text::lit(""), bind_col(st, x, other)});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m))) {
            auto&& other = std::get<0>(_m);
            auto&& y = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
            _v.set(std::tuple{Text::lit(""), bind_col(st, y, other)});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Col::CQ>(std::get<0>(_m))) {
            _v.set(std::tuple{Text::lit(""), st});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Col::CQ>(std::get<1>(_m))) {
            _v.set(std::tuple{Text::lit(""), st});
            goto _done;
        }
        {
            _v.set(std::tuple{Text::lit("mismatch"), st});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> UnifyCol::cycle() const {
    const auto& st = this->st;
    const auto& a0 = this->a0;
    const auto& b0 = this->b0;
    auto a0_1 = a0;
    auto b0_2 = b0;
    auto st_3 = st;
    return call_then(start_walk_col(st_3, a0_1), [=](crate::check::types::Col walk_col_3231) {
        return ({
            auto a = walk_col_3231;
            call_then(start_walk_col(st_3, b0_2), [=, a = std::move(a)](crate::check::types::Col walk_col_3258) {
            return ({
                auto b = walk_col_3258;
                a == b
                ? prism_rtl::finished(std::tuple{Text::lit(""), st_3})
                : ({
                auto&& _m = std::tuple{a, b};
                prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) ? ({
                auto&& x = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                auto&& other = std::get<1>(_m);
                prism_rtl::finished(std::tuple{Text::lit(""), bind_col(st_3, x, other)});
            })
                : prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                auto&& other = std::get<0>(_m);
                auto&& y = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                prism_rtl::finished(std::tuple{Text::lit(""), bind_col(st_3, y, other)});
            })
                : prism_rtl::is<crate::check::types::Col::CQ>(std::get<0>(_m)) ? prism_rtl::finished(std::tuple{Text::lit(""), st_3})
                : prism_rtl::is<crate::check::types::Col::CQ>(std::get<1>(_m)) ? prism_rtl::finished(std::tuple{Text::lit(""), st_3})
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_3});
            });
            });
        });
        });
    });
}


/// `Start UnifyCol, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_col(crate::check::types::St st, crate::check::types::Col a0, crate::check::types::Col b0) {
    return prism_rtl::make_rc<UnifyCol>(st, a0, b0);
}


/// BindCol: fn St, Nat, Col -> St
crate::check::types::St bind_col(const crate::check::types::St& st, const Nat& n, const crate::check::types::Col& c) {
    auto st2 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        if (prism_rtl::is<crate::check::types::Col::CFlex>(c)) {
            auto&& m = prism_rtl::as<crate::check::types::Col::CFlex>(c).a0;
            _v.set(crate::check::types::unify::lower_one(st, m, prism_rtl::deref(crate::check::types::recording::info_of(st, n)).level));
            goto _done;
        }
        {
            _v.set(st);
            goto _done;
        }
    _done:
        _v.take();
    });
    crate::check::types::St this_ = st2;
    this_.cols = insert(this_.cols, n, c);
    return this_;
}


/// FreeColVars: unbounded fn St, Ty -> [Nat]
Array<Nat> free_col_vars(const crate::check::types::St& st, const crate::check::types::Ty& t) {
    return free_cols_into(st, Array<Nat>{}, t);
}


prism_rtl::Turn<Array<Nat>> FreeColVars::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    return prism_rtl::more(prism_rtl::rc(FreeColsInto(st, Array<Nat>{}, t)));
}


/// `Start FreeColVars, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_free_col_vars(crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<FreeColVars>(st, t);
}


/// FreeColsInto: unbounded fn St, [Nat], Ty -> [Nat]
Array<Nat> free_cols_into(const crate::check::types::St& st, const Array<Nat>& acc, const crate::check::types::Ty& t) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        return run_to_end(fold_job(args, acc, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_1_2, a, x))));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        auto acc2 = ({
            __label__ _done;
            prism_rtl::Slot<Array<Nat>> _v;
            auto&& _m = walk_col(st, c);
            if (prism_rtl::is<crate::check::types::Col::CFlex>(_m)) {
                auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(_m).a0;
                _v.set(crate::check::types::add_nat(acc, n));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
        return free_cols_into(st, run_to_end(fold_job(ps, acc2, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_1_2, a, x))));
                });
            }));
            });
        })));
        }))), prism_rtl::deref(res));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return run_to_end(fold_job(ts, acc, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_1_2, a, x))));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        return free_cols_into(st, acc, prism_rtl::deref(e));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return free_cols_into(st, free_cols_into(st, acc, prism_rtl::deref(k)), prism_rtl::deref(v_));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return free_cols_into(st, acc, prism_rtl::deref(i));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
        return free_cols_into(st, acc, prism_rtl::deref(i));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
        return free_cols_into(st, acc, prism_rtl::deref(o));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(_m)) {
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(_m).a1;
        return free_cols_into(st, acc, prism_rtl::deref(a));
    }
    {
        return acc;
    }
}


prism_rtl::Turn<Array<Nat>> FreeColsInto::cycle() const {
    const auto& st = this->st;
    const auto& acc = this->acc;
    const auto& t = this->t;
    auto acc_1 = acc;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(crate::check::types::recording::start_walk(st_2, t_3), [=](crate::check::types::Ty walk_3992) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_3992) ? ({
            auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_3992).a1;
            fold_job(args, acc_1, ({
            auto st_2_4 = st_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_2_4 = std::move(st_2_4)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_2_4_4 = st_2_4;
                entered(once_job([=, st_2_4_4 = std::move(st_2_4_4)]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2_4_4, a, x))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::types::Ty::TyFn>(walk_3992) ? ({
            auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_3992).a0;
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_3992).a1;
            auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_3992).a2;
            call_then(start_walk_col(st_2, c), [=](crate::check::types::Col walk_col_4120) {
            return ({
                auto acc2 = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Nat>> _v;
                    if (prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_4120)) {
                        auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_4120).a0;
                        _v.set(crate::check::types::add_nat(acc_1, n));
                        goto _done;
                    }
                    {
                        _v.set(acc_1);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                call_value(fold_job(ps, acc2, ({
                auto st_2_4 = st_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_2_4 = std::move(st_2_4)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto st_2_4_4 = st_2_4;
                    entered(once_job([=, st_2_4_4 = std::move(st_2_4_4)]() {
                    return ({
                        auto a = p0;
                        auto x = p1;
                        (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2_4_4, a, x))));
                    });
                }));
                });
            })));
            })), [=](Array<Nat> fold_4223) { return prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2, fold_4223, prism_rtl::deref(res)))); });
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyTuple>(walk_3992) ? ({
            auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(walk_3992).a0;
            fold_job(ts, acc_1, ({
            auto st_2_4 = st_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_2_4 = std::move(st_2_4)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_2_4_4 = st_2_4;
                entered(once_job([=, st_2_4_4 = std::move(st_2_4_4)]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2_4_4, a, x))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::types::Ty::TyArray>(walk_3992) ? ({
            auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(walk_3992).a0;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2, acc_1, prism_rtl::deref(e))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyMap>(walk_3992) ? ({
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_3992).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_3992).a1;
            call_then(start_free_cols_into(st_2, acc_1, prism_rtl::deref(k)), [=](Array<Nat> free_cols_into_4407) { return prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2, free_cols_into_4407, prism_rtl::deref(v_)))); });
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_3992) ? ({
            auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(walk_3992).a1;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2, acc_1, prism_rtl::deref(i))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyAt>(walk_3992) ? ({
            auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_3992).a0;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2, acc_1, prism_rtl::deref(i))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyElem>(walk_3992) ? ({
            auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_3992).a1;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2, acc_1, prism_rtl::deref(o))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyAssoc>(walk_3992) ? ({
            auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(walk_3992).a1;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2, acc_1, prism_rtl::deref(a))));
        })
            : prism_rtl::finished(acc_1);
        });
    });
}


/// `Start FreeColsInto, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_free_cols_into(crate::check::types::St st, Array<Nat> acc, crate::check::types::Ty t) {
    return prism_rtl::make_rc<FreeColsInto>(st, acc, t);
}


/// AddLeq: unbounded fn St, Col, Col, Range, Text, Text, Text -> St
crate::check::types::St add_leq(const crate::check::types::St& st, const crate::check::types::Col& lo0, const crate::check::types::Col& hi0, const crate::syntax::Range& span, const Text& kind, const Text& name, const Text& why) {
    auto lo = walk_col(st, lo0);
    auto hi = walk_col(st, hi0);
    return ((lo == crate::check::types::Col(crate::check::types::Col::CBound{})) || (hi == crate::check::types::Col(crate::check::types::Col::CUnbound{}))) || (lo == hi)
        ? st
        : ({
        crate::check::types::St this_ = st;
        this_.cleqs = crate::prelude::push(this_.cleqs, crate::check::types::CLeq{.lo = lo, .hi = hi, .file = this_.file, .span = span, .kind = kind, .name = name, .why = why});
        (std::move(this_));
    });
}


prism_rtl::Turn<crate::check::types::St> AddLeq::cycle() const {
    const auto& st = this->st;
    const auto& lo0 = this->lo0;
    const auto& hi0 = this->hi0;
    const auto& span = this->span;
    const auto& kind = this->kind;
    const auto& name = this->name;
    const auto& why = this->why;
    auto hi0_1 = hi0;
    auto kind_2 = kind;
    auto lo0_3 = lo0;
    auto name_4 = name;
    auto span_5 = span;
    auto st_6 = st;
    auto why_7 = why;
    return call_then(start_walk_col(st_6, lo0_3), [=](crate::check::types::Col walk_col_4883) {
        return ({
            auto lo = walk_col_4883;
            call_then(start_walk_col(st_6, hi0_1), [=, lo = std::move(lo)](crate::check::types::Col walk_col_4912) {
            return ({
                auto hi = walk_col_4912;
                ((lo == crate::check::types::Col(crate::check::types::Col::CBound{})) || (hi == crate::check::types::Col(crate::check::types::Col::CUnbound{}))) || (lo == hi)
                ? prism_rtl::finished(st_6)
                : prism_rtl::finished(({
                crate::check::types::St this_ = st_6;
                this_.cleqs = crate::prelude::push(this_.cleqs, crate::check::types::CLeq{.lo = lo, .hi = hi, .file = this_.file, .span = span_5, .kind = kind_2, .name = name_4, .why = why_7});
                (std::move(this_));
            }));
            });
        });
        });
    });
}


/// `Start AddLeq, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_add_leq(crate::check::types::St st, crate::check::types::Col lo0, crate::check::types::Col hi0, crate::syntax::Range span, Text kind, Text name, Text why) {
    return prism_rtl::make_rc<AddLeq>(st, lo0, hi0, span, kind, name, why);
}


/// Propagate: unbounded fn St, Bool -> St
crate::check::types::St propagate(const crate::check::types::St& st, const bool& rigid) {
    auto [st2, changed] = run_to_end(fold_job(st.cleqs, std::tuple{st, false}, ({
        auto rigid_1 = rigid;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, bool>>(std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq>)>>(prism_rtl::rc([=, rigid_1 = std::move(rigid_1)](std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rigid_1_2 = rigid_1;
            entered(once_job([=, rigid_1_2 = std::move(rigid_1_2)]() {
            return ({
                auto [s, ch] = p0;
                auto c = p1;
                call_then(start_walk_col(s, prism_rtl::deref(c).lo), [=](crate::check::types::Col walk_col_5490) {
                return ({
                    auto lo = walk_col_5490;
                    call_then(start_walk_col(s, prism_rtl::deref(c).hi), [=, lo = std::move(lo)](crate::check::types::Col walk_col_5520) {
                    return ({
                        prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_5520) ? ({
                        auto&& h = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_5520).a0;
                        ({
                        auto forced = (lo == crate::check::types::Col(crate::check::types::Col::CUnbound{})) || (rigid_1_2 && is_rigid_col(lo));
                        (std::move(forced)
                        ? prism_rtl::finished(std::tuple{bind_col(s, h, lo), true})
                        : prism_rtl::finished(std::tuple{s, ch}));
                    });
                    })
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })));
    return changed ? propagate(st2, rigid) : st2;
}


prism_rtl::Turn<crate::check::types::St> Propagate::cycle() const {
    const auto& st = this->st;
    const auto& rigid = this->rigid;
    auto rigid_1 = prism_rtl::deref(rigid);
    auto st_2 = st;
    return call_value(fold_job(prism_rtl::deref(st_2).cleqs, std::tuple{st_2, false}, ({
        auto rigid_1_3 = std::move(rigid_1);
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, bool>>(std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq>)>>(prism_rtl::rc([=, rigid_1_3 = std::move(rigid_1_3)](std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rigid_1_3_3 = rigid_1_3;
            entered(once_job([=, rigid_1_3_3 = std::move(rigid_1_3_3)]() {
            return ({
                auto [s, ch] = p0;
                auto c = p1;
                call_then(start_walk_col(s, prism_rtl::deref(c).lo), [=](crate::check::types::Col walk_col_5490) {
                return ({
                    auto lo = walk_col_5490;
                    call_then(start_walk_col(s, prism_rtl::deref(c).hi), [=, lo = std::move(lo)](crate::check::types::Col walk_col_5520) {
                    return ({
                        prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_5520) ? ({
                        auto&& h = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_5520).a0;
                        ({
                        auto forced = (lo == crate::check::types::Col(crate::check::types::Col::CUnbound{})) || (rigid_1_3_3 && is_rigid_col(lo));
                        (std::move(forced)
                        ? prism_rtl::finished(std::tuple{bind_col(s, h, lo), true})
                        : prism_rtl::finished(std::tuple{s, ch}));
                    });
                    })
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<crate::check::types::St, bool> fold_5427) {
        return ({
            auto [st2, changed] = fold_5427;
            changed
            ? prism_rtl::more(prism_rtl::rc(Propagate(st2, rigid_1)))
            : prism_rtl::finished(st2);
        });
    });
}


/// `Start Propagate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_propagate(crate::check::types::St st, bool rigid) {
    return prism_rtl::make_rc<Propagate>(st, rigid);
}


/// GeneralizeCols: unbounded fn St -> St
crate::check::types::St generalize_cols(const crate::check::types::St& st0) {
    auto st1 = lower_joined(propagate(st0, false));
    auto st2 = run_to_end(fold_job(prism_rtl::deref(st1).cleqs, st1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto c = p1;
                call_then(start_walk_col(s, prism_rtl::deref(c).lo), [=](crate::check::types::Col walk_col_6260) {
                return ({
                    auto lo = walk_col_6260;
                    call_then(start_walk_col(s, prism_rtl::deref(c).hi), [=, lo = std::move(lo)](crate::check::types::Col walk_col_6293) {
                    return ({
                        auto hi = walk_col_6293;
                        ({
                        auto&& _m = std::tuple{lo, hi};
                        prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                        auto&& x = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                        auto&& y = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                        ((x != y) && is_own_col(s, lo)) && is_own_col(s, hi)
                        ? prism_rtl::finished(bind_col(s, x, hi))
                        : prism_rtl::finished(s);
                    })
                        : prism_rtl::finished(s);
                    });
                    });
                });
                });
            });
            });
        }));
    }))));
    return run_to_end(fold_job(prism_rtl::deref(st2).cleqs, st2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto c = p1;
                call_then(start_walk_col(s, prism_rtl::deref(c).lo), [=](crate::check::types::Col walk_col_6522) {
                return ({
                    auto lo = walk_col_6522;
                    call_then(start_walk_col(s, prism_rtl::deref(c).hi), [=, lo = std::move(lo)](crate::check::types::Col walk_col_6555) {
                    return ({
                        auto hi = walk_col_6555;
                        ({
                        auto&& _m = std::tuple{lo, hi};
                        prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? prism_rtl::finished(s)
                        : prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CUnbound>(std::get<1>(_m)) ? prism_rtl::finished(s)
                        : prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) ? ({
                        auto&& x = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                        auto&& other = std::get<1>(_m);
                        is_own_col(s, lo)
                        ? prism_rtl::finished(bind_col(s, x, other))
                        : prism_rtl::finished(s);
                    })
                        : prism_rtl::is<crate::check::types::Col::CRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                        auto&& r = prism_rtl::as<crate::check::types::Col::CRigid>(std::get<0>(_m)).a0;
                        auto&& y = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                        is_own_col(s, hi)
                        ? prism_rtl::finished(bind_col(s, y, lo))
                        : prism_rtl::finished(s);
                    })
                        : prism_rtl::finished(s);
                    });
                    });
                });
                });
            });
            });
        }));
    }))));
}


prism_rtl::Turn<crate::check::types::St> GeneralizeCols::cycle() const {
    const auto& st0 = this->st0;
    auto st0_1 = st0;
    return call_then(start_propagate(st0_1, false), [=](crate::check::types::St propagate_6178) {
        return call_then(start_lower_joined(propagate_6178), [=](crate::check::types::St lower_joined_6165) {
            return ({
                auto st1 = lower_joined_6165;
                call_value(fold_job(prism_rtl::deref(st1).cleqs, st1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto s = p0;
                        auto c = p1;
                        call_then(start_walk_col(s, prism_rtl::deref(c).lo), [=](crate::check::types::Col walk_col_6260) {
                        return ({
                            auto lo = walk_col_6260;
                            call_then(start_walk_col(s, prism_rtl::deref(c).hi), [=, lo = std::move(lo)](crate::check::types::Col walk_col_6293) {
                            return ({
                                auto hi = walk_col_6293;
                                ({
                                auto&& _m = std::tuple{lo, hi};
                                prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                                auto&& x = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                                auto&& y = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                                ((x != y) && is_own_col(s, lo)) && is_own_col(s, hi)
                                ? prism_rtl::finished(bind_col(s, x, hi))
                                : prism_rtl::finished(s);
                            })
                                : prism_rtl::finished(s);
                            });
                            });
                        });
                        });
                    });
                    });
                }));
            }))), [=](crate::check::types::St fold_6214) {
                return ({
                    auto st2 = fold_6214;
                    fold_job(prism_rtl::deref(st2).cleqs, st2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto s = p0;
                            auto c = p1;
                            call_then(start_walk_col(s, prism_rtl::deref(c).lo), [=](crate::check::types::Col walk_col_6522) {
                            return ({
                                auto lo = walk_col_6522;
                                call_then(start_walk_col(s, prism_rtl::deref(c).hi), [=, lo = std::move(lo)](crate::check::types::Col walk_col_6555) {
                                return ({
                                    auto hi = walk_col_6555;
                                    ({
                                    auto&& _m = std::tuple{lo, hi};
                                    prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? prism_rtl::finished(s)
                                    : prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CUnbound>(std::get<1>(_m)) ? prism_rtl::finished(s)
                                    : prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) ? ({
                                    auto&& x = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                                    auto&& other = std::get<1>(_m);
                                    is_own_col(s, lo)
                                    ? prism_rtl::finished(bind_col(s, x, other))
                                    : prism_rtl::finished(s);
                                })
                                    : prism_rtl::is<crate::check::types::Col::CRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                                    auto&& r = prism_rtl::as<crate::check::types::Col::CRigid>(std::get<0>(_m)).a0;
                                    auto&& y = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                                    is_own_col(s, hi)
                                    ? prism_rtl::finished(bind_col(s, y, lo))
                                    : prism_rtl::finished(s);
                                })
                                    : prism_rtl::finished(s);
                                });
                                });
                            });
                            });
                        });
                        });
                    }));
                })))->cycle();
                });
            });
            });
        });
    });
}


/// `Start GeneralizeCols, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_generalize_cols(crate::check::types::St st0) {
    return prism_rtl::make_rc<GeneralizeCols>(st0);
}


/// LowerJoined: unbounded fn St -> St
crate::check::types::St lower_joined(const crate::check::types::St& st) {
    auto [st2, changed] = run_to_end(fold_job(st.cleqs, std::tuple{st, false}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, bool>>(std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [s, ch] = p0;
                auto c = p1;
                call_then(start_walk_col(s, prism_rtl::deref(c).lo), [=](crate::check::types::Col walk_col_7100) {
                return call_then(start_walk_col(s, prism_rtl::deref(c).hi), [=](crate::check::types::Col walk_col_7119) {
                    return ({
                        auto&& _m = std::tuple{walk_col_7100, walk_col_7119};
                        prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                        auto&& x = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                        auto&& y = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                        ({
                        auto lx = prism_rtl::deref(crate::check::types::recording::info_of(s, x)).level;
                        auto ly = prism_rtl::deref(crate::check::types::recording::info_of(s, y)).level;
                        ((lx > prism_rtl::deref(s).level) && (ly <= prism_rtl::deref(s).level)) && (lx > ly)
                        ? prism_rtl::finished(std::tuple{crate::check::types::unify::lower_one(s, x, ly), true})
                        : ((ly > prism_rtl::deref(s).level) && (lx <= prism_rtl::deref(s).level)) && (ly > lx)
                        ? prism_rtl::finished(std::tuple{crate::check::types::unify::lower_one(s, y, lx), true})
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                    })
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                });
            });
            });
        }));
    }))));
    return changed ? lower_joined(st2) : st2;
}


prism_rtl::Turn<crate::check::types::St> LowerJoined::cycle() const {
    const auto& st = this->st;
    auto st_1 = st;
    return call_value(fold_job(prism_rtl::deref(st_1).cleqs, std::tuple{st_1, false}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, bool>>(std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [s, ch] = p0;
                auto c = p1;
                call_then(start_walk_col(s, prism_rtl::deref(c).lo), [=](crate::check::types::Col walk_col_7100) {
                return call_then(start_walk_col(s, prism_rtl::deref(c).hi), [=](crate::check::types::Col walk_col_7119) {
                    return ({
                        auto&& _m = std::tuple{walk_col_7100, walk_col_7119};
                        prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                        auto&& x = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                        auto&& y = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                        ({
                        auto lx = prism_rtl::deref(crate::check::types::recording::info_of(s, x)).level;
                        auto ly = prism_rtl::deref(crate::check::types::recording::info_of(s, y)).level;
                        ((lx > prism_rtl::deref(s).level) && (ly <= prism_rtl::deref(s).level)) && (lx > ly)
                        ? prism_rtl::finished(std::tuple{crate::check::types::unify::lower_one(s, x, ly), true})
                        : ((ly > prism_rtl::deref(s).level) && (lx <= prism_rtl::deref(s).level)) && (ly > lx)
                        ? prism_rtl::finished(std::tuple{crate::check::types::unify::lower_one(s, y, lx), true})
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                    })
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                });
            });
            });
        }));
    }))), [=](std::tuple<crate::check::types::St, bool> fold_7037) {
        return ({
            auto [st2, changed] = fold_7037;
            changed
            ? prism_rtl::more(prism_rtl::rc(LowerJoined(st2)))
            : prism_rtl::finished(st2);
        });
    });
}


/// `Start LowerJoined, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_lower_joined(crate::check::types::St st) {
    return prism_rtl::make_rc<LowerJoined>(st);
}


/// CheckColors: unbounded fn St -> St
crate::check::types::St check_colors(const crate::check::types::St& st0) {
    auto st = propagate(propagate(st0, false), true);
    auto st2 = run_to_end(fold_job(prism_rtl::deref(st).cleqs, st, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto c = p1;
                call_then(start_settled_col(s, prism_rtl::deref(c).lo), [=](crate::check::types::Col settled_col_7897) {
                return ({
                    auto lo = settled_col_7897;
                    call_then(start_settled_col(s, prism_rtl::deref(c).hi), [=, lo = std::move(lo)](crate::check::types::Col settled_col_7933) {
                    return ({
                        auto hi = settled_col_7933;
                        col_leq(lo, hi) || col_leq(up_col(s, lo), up_col(s, hi))
                        ? prism_rtl::finished(s)
                        : prism_rtl::finished(crate::check::types::recording::add_diag(s, leq_diag(c, lo, hi)));
                    });
                });
                });
            });
            });
        }));
    }))));
    crate::check::types::St this_ = st2;
    this_.cleqs = Array<crate::check::types::CLeq>{};
    this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
    this_.col_up = Map<Text, Text>{};
    return this_;
}


prism_rtl::Turn<crate::check::types::St> CheckColors::cycle() const {
    const auto& st0 = this->st0;
    auto st0_1 = st0;
    return call_then(start_propagate(st0_1, false), [=](crate::check::types::St propagate_7811) {
        return call_then(start_propagate(propagate_7811, true), [=](crate::check::types::St propagate_7800) {
            return ({
                auto st = propagate_7800;
                call_value(fold_job(prism_rtl::deref(st).cleqs, st, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto s = p0;
                        auto c = p1;
                        call_then(start_settled_col(s, prism_rtl::deref(c).lo), [=](crate::check::types::Col settled_col_7897) {
                        return ({
                            auto lo = settled_col_7897;
                            call_then(start_settled_col(s, prism_rtl::deref(c).hi), [=, lo = std::move(lo)](crate::check::types::Col settled_col_7933) {
                            return ({
                                auto hi = settled_col_7933;
                                col_leq(lo, hi) || col_leq(up_col(s, lo), up_col(s, hi))
                                ? prism_rtl::finished(s)
                                : prism_rtl::finished(crate::check::types::recording::add_diag(s, leq_diag(c, lo, hi)));
                            });
                        });
                        });
                    });
                    });
                }));
            }))), [=](crate::check::types::St fold_7853) {
                return ({
                    auto st2 = fold_7853;
                    (prism_rtl::finished(({
                    crate::check::types::St this_ = st2;
                    this_.cleqs = Array<crate::check::types::CLeq>{};
                    this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
                    this_.col_up = Map<Text, Text>{};
                    (std::move(this_));
                })));
                });
            });
            });
        });
    });
}


/// `Start CheckColors, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_colors(crate::check::types::St st0) {
    return prism_rtl::make_rc<CheckColors>(st0);
}


/// LeqDiag: fn CLeq, Col, Col -> CDiag
crate::check::errors::CDiag leq_diag(const crate::check::types::CLeq& c, const crate::check::types::Col& lo, const crate::check::types::Col& hi) {
    return c.kind == Text::lit("lifted")
        ? crate::check::errors::diag_fix(Text::lit("lifted-unbounded"), c.file, c.span, prism_rtl::cat(col_word(lo), " `", c.name, "` lifted over `", c.why, "`; use `@Run`"), prism_rtl::cat("run it through `!done <- @Run ", c.name, ", ...`"))
        : c.kind == Text::lit("arg")
        ? crate::check::errors::diag_fix(Text::lit("calls-unbounded"), c.file, c.span, prism_rtl::cat(col_word(hi), " `", c.name, "` takes a ", col_word(hi), " closure; this one is ", col_word(lo)), Text::lit("mark the parameter `unbounded fn`, or run the work through `@Run`"))
        : c.kind == Text::lit("lambda")
        ? crate::check::errors::diag_fix(Text::lit("calls-unbounded"), c.file, c.span, prism_rtl::cat("this ", col_word(hi), " lambda calls ", col_word(lo), " `", c.why, "`"), Text::lit("mark the function type it meets `unbounded fn`, or run the call through `@Run`"))
        : crate::check::errors::diag_fix(Text::lit("calls-unbounded"), c.file, c.span, prism_rtl::cat(col_word(hi), " `", c.name, "` calls ", col_word(lo), " `", c.why, "`"), prism_rtl::cat("mark `", c.name, "` `unbounded fn`, or run the call through `@Run`"));
}


/// SettleBody: unbounded fn St, Col, Text -> St
crate::check::types::St settle_body(const crate::check::types::St& st0, const crate::check::types::Col& col, const Text& name) {
    auto st = propagate(st0, false);
    auto waiting = prism_rtl::deref(st).color_flex;
    auto cleared = ({
        crate::check::types::St this_ = st;
        this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
        (std::move(this_));
    });
    return run_to_end(fold_job(waiting, cleared, ({
        auto col_1 = col;
        auto name_2 = name;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>)>>(prism_rtl::rc([=, col_1 = std::move(col_1), name_2 = std::move(name_2)](std::tuple<crate::check::types::St, std::tuple<crate::check::types::Col, Text, crate::syntax::Range>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto col_1_3 = col_1;
            auto name_2_3 = name_2;
            entered(once_job([=, col_1_3 = std::move(col_1_3), name_2_3 = std::move(name_2_3)]() {
            return ({
                auto s = p0;
                auto [c, why, span] = p1;
                call_then(start_walk_col(s, c), [=](crate::check::types::Col walk_col_9404) {
                return ({
                    prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_9404) ? ({
                    auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_9404).a0;
                    prism_rtl::more(prism_rtl::rc(AddLeq(s, crate::check::types::Col(crate::check::types::Col::CFlex{n}), col_1_3, span, name_2_3 == Text::lit("") ? Text::lit("lambda") : Text::lit("body"), name_2_3, why)));
                })
                    : ({
                    auto&& known = walk_col_9404;
                    prism_rtl::finished(join_known(s, known, why));
                });
                });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> SettleBody::cycle() const {
    const auto& st0 = this->st0;
    const auto& col = this->col;
    const auto& name = this->name;
    auto col_1 = col;
    auto name_2 = name;
    auto st0_3 = st0;
    return call_then(start_propagate(st0_3, false), [=](crate::check::types::St propagate_9238) {
        return ({
            auto st = propagate_9238;
            auto waiting = prism_rtl::deref(st).color_flex;
            auto cleared = ({
                crate::check::types::St this_ = st;
                this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
                (std::move(this_));
            });
            fold_job(waiting, cleared, ({
            auto col_1_4 = col_1;
            auto name_2_4 = name_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>)>>(prism_rtl::rc([=, col_1_4 = std::move(col_1_4), name_2_4 = std::move(name_2_4)](std::tuple<crate::check::types::St, std::tuple<crate::check::types::Col, Text, crate::syntax::Range>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto col_1_4_4 = col_1_4;
                auto name_2_4_4 = name_2_4;
                entered(once_job([=, col_1_4_4 = std::move(col_1_4_4), name_2_4_4 = std::move(name_2_4_4)]() {
                return ({
                    auto s = p0;
                    auto [c, why, span] = p1;
                    call_then(start_walk_col(s, c), [=](crate::check::types::Col walk_col_9404) {
                    return ({
                        prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_9404) ? ({
                        auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_9404).a0;
                        prism_rtl::more(prism_rtl::rc(AddLeq(s, crate::check::types::Col(crate::check::types::Col::CFlex{n}), col_1_4_4, span, name_2_4_4 == Text::lit("") ? Text::lit("lambda") : Text::lit("body"), name_2_4_4, why)));
                    })
                        : ({
                        auto&& known = walk_col_9404;
                        prism_rtl::finished(join_known(s, known, why));
                    });
                    });
                });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start SettleBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_settle_body(crate::check::types::St st0, crate::check::types::Col col, Text name) {
    return prism_rtl::make_rc<SettleBody>(st0, col, name);
}

}  // namespace crate::check::types::colors
