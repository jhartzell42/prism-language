// The module `Check.Shrink.Walk`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/shrink/walk/module.hpp>
#include <syntax/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Shrink.Walk`, from `target/bootstrap/cpp-src/prismc/check/shrink/walk.prism`.
namespace crate::check::shrink::walk {

bool Kid::KidExpr::operator==(const KidExpr& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Kid::KidStmts::operator==(const KidStmts& o) const { return a0 == o.a0 && a1 == o.a1; }

void Kid::show(Printer& p) const {
    if (auto c = std::get_if<KidExpr>(&cases())) p.choice("KidExpr", {c->a0, c->a1});
    else if (auto c = std::get_if<KidStmts>(&cases())) p.choice("KidStmts", {c->a0, c->a1});
}

Pod Kid::to_pod() const {
    return std::holds_alternative<KidExpr>(cases()) ? Pod::choice("KidExpr", {prism_rtl::to_pod(std::get<KidExpr>(cases()).a0), prism_rtl::to_pod(std::get<KidExpr>(cases()).a1)})
        : std::holds_alternative<KidStmts>(cases()) ? Pod::choice("KidStmts", {prism_rtl::to_pod(std::get<KidStmts>(cases()).a0), prism_rtl::to_pod(std::get<KidStmts>(cases()).a1)})
        : Pod();
}

Result<Kid> Kid::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "KidExpr" && c->args.size() == 2) return Kid(KidExpr{TRY(prism_rtl::from_pod<crate::syntax::Expr>(c->args[0])), TRY(prism_rtl::from_pod<Map<Text, crate::check::shrink::Rel>>(c->args[1]))});
        if (c->ctor == "KidStmts" && c->args.size() == 2) return Kid(KidStmts{TRY(prism_rtl::from_pod<Array<crate::syntax::Stmt>>(c->args[0])), TRY(prism_rtl::from_pod<Map<Text, crate::check::shrink::Rel>>(c->args[1]))});
    }
    return mismatch<Kid>("a Kid", p);
}


bool Site::operator==(const Site& o) const { return callee == o.callee && args == o.args && span == o.span && rels == o.rels; }

void Site::show(Printer& p) const {
    p.record("Site", {{"callee", callee}, {"args", args}, {"span", span}, {"rels", rels}});
}

Pod Site::to_pod() const {
    return Pod::record("Site", {{"callee", prism_rtl::to_pod(callee)}, {"args", prism_rtl::to_pod(args)}, {"span", prism_rtl::to_pod(span)}, {"rels", prism_rtl::to_pod(rels)}});
}

Result<Site> Site::from_pod(const Pod& whole) {
    return Site{.callee = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "callee")))), .args = TRY(prism_rtl::from_pod<Array<crate::syntax::Arg>>(TRY(crate::prelude::field(whole, "args")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .rels = TRY(prism_rtl::from_pod<Map<Text, crate::check::shrink::Rel>>(TRY(crate::prelude::field(whole, "rels"))))};
}


bool Spot::SpotExpr::operator==(const SpotExpr& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Spot::SpotStmt::operator==(const SpotStmt& o) const { return a0 == o.a0 && a1 == o.a1; }

void Spot::show(Printer& p) const {
    if (auto c = std::get_if<SpotExpr>(&cases())) p.choice("SpotExpr", {c->a0, c->a1});
    else if (auto c = std::get_if<SpotStmt>(&cases())) p.choice("SpotStmt", {c->a0, c->a1});
}

Pod Spot::to_pod() const {
    return std::holds_alternative<SpotExpr>(cases()) ? Pod::choice("SpotExpr", {prism_rtl::to_pod(std::get<SpotExpr>(cases()).a0), prism_rtl::to_pod(std::get<SpotExpr>(cases()).a1)})
        : std::holds_alternative<SpotStmt>(cases()) ? Pod::choice("SpotStmt", {prism_rtl::to_pod(std::get<SpotStmt>(cases()).a0), prism_rtl::to_pod(std::get<SpotStmt>(cases()).a1)})
        : Pod();
}

Result<Spot> Spot::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "SpotExpr" && c->args.size() == 2) return Spot(SpotExpr{TRY(prism_rtl::from_pod<crate::syntax::Expr>(c->args[0])), TRY(prism_rtl::from_pod<Map<Text, crate::check::shrink::Rel>>(c->args[1]))});
        if (c->ctor == "SpotStmt" && c->args.size() == 2) return Spot(SpotStmt{TRY(prism_rtl::from_pod<crate::syntax::Stmt>(c->args[0])), TRY(prism_rtl::from_pod<Map<Text, crate::check::shrink::Rel>>(c->args[1]))});
    }
    return mismatch<Spot>("a Spot", p);
}


/// ExprSpots: unbounded fn Expr, (Text ==> Rel) -> [Spot]
Array<Spot> expr_spots(const crate::syntax::Expr& e_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    return run_to_end(fold_job(expr_kids(e_p0, m_p1), Array(std::vector{Spot(Spot::SpotExpr{e_p0, m_p1})}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p2 = p0;
                auto k_p3 = p1;
                call_then(start_kid_spots(k_p3), [=, acc_p2 = std::move(acc_p2)](Array<Spot> kid_spots_2175) { return prism_rtl::finished(append(acc_p2, kid_spots_2175)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Spot>> ExprSpots::cycle() const {
    const auto& e_p0 = this->e_p0;
    const auto& m_p1 = this->m_p1;
    auto e_p0_1 = e_p0;
    auto m_p1_2 = m_p1;
    return call_then(start_expr_kids(e_p0_1, m_p1_2), [=](Array<Kid> expr_kids_2115) {
        return fold_job(expr_kids_2115, Array(std::vector{Spot(Spot::SpotExpr{e_p0_1, m_p1_2})}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p2 = p0;
                    auto k_p3 = p1;
                    call_then(start_kid_spots(k_p3), [=, acc_p2 = std::move(acc_p2)](Array<Spot> kid_spots_2175) { return prism_rtl::finished(append(acc_p2, kid_spots_2175)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start ExprSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_expr_spots(crate::syntax::Expr e_p0, Map<Text, crate::check::shrink::Rel> m_p1) {
    return prism_rtl::make_rc<ExprSpots>(e_p0, m_p1);
}


/// KidSpots: unbounded fn Kid -> [Spot]
Array<Spot> kid_spots(const Kid& kid0) {
    if (prism_rtl::is<Kid::KidExpr>(kid0)) {
        auto&& x_p0 = prism_rtl::as<Kid::KidExpr>(kid0).a0;
        auto&& m_p1 = prism_rtl::as<Kid::KidExpr>(kid0).a1;
        return expr_spots(x_p0, m_p1);
    }
    if (prism_rtl::is<Kid::KidStmts>(kid0)) {
        auto&& ss_p2 = prism_rtl::as<Kid::KidStmts>(kid0).a0;
        auto&& m_p3 = prism_rtl::as<Kid::KidStmts>(kid0).a1;
        return stmts_spots(ss_p2, m_p3);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Spot>> KidSpots::cycle() const {
    const auto& kid0 = this->kid0;
    return ({
        prism_rtl::is<Kid::KidExpr>(kid0) ? ({
        auto&& x_p0 = prism_rtl::as<Kid::KidExpr>(kid0).a0;
        auto&& m_p1 = prism_rtl::as<Kid::KidExpr>(kid0).a1;
        prism_rtl::more(prism_rtl::rc(ExprSpots(x_p0, m_p1)));
    })
        : prism_rtl::is<Kid::KidStmts>(kid0) ? ({
        auto&& ss_p2 = prism_rtl::as<Kid::KidStmts>(kid0).a0;
        auto&& m_p3 = prism_rtl::as<Kid::KidStmts>(kid0).a1;
        prism_rtl::more(prism_rtl::rc(StmtsSpots(ss_p2, m_p3)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start KidSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_kid_spots(Kid kid0) {
    return prism_rtl::make_rc<KidSpots>(kid0);
}


/// StmtsSpots: unbounded fn [Stmt], (Text ==> Rel) -> [Spot]
Array<Spot> stmts_spots(const Array<crate::syntax::Stmt>& stmts_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    auto bm_p2 = crate::check::shrink::relations::block_rels(stmts_p0, m_p1);
    return run_to_end(fold_job(stmts_p0, Array<Spot>{}, ({
        auto bm_p2_1 = bm_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, crate::syntax::Stmt>)>>(prism_rtl::rc([=, bm_p2_1 = std::move(bm_p2_1)](std::tuple<Array<Spot>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto bm_p2_1_2 = bm_p2_1;
            entered(once_job([=, bm_p2_1_2 = std::move(bm_p2_1_2)]() {
            return ({
                auto acc_p3 = p0;
                auto s_p4 = p1;
                call_then(start_stmt_spots(s_p4, bm_p2_1_2), [=, acc_p3 = std::move(acc_p3)](Array<Spot> stmt_spots_2562) { return prism_rtl::finished(append(acc_p3, stmt_spots_2562)); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Spot>> StmtsSpots::cycle() const {
    const auto& stmts_p0 = this->stmts_p0;
    const auto& m_p1 = this->m_p1;
    auto m_p1_1 = m_p1;
    auto stmts_p0_2 = stmts_p0;
    return call_then(crate::check::shrink::relations::start_block_rels(stmts_p0_2, m_p1_1), [=](Map<Text, crate::check::shrink::Rel> block_rels_2498) {
        return ({
            auto bm_p2 = block_rels_2498;
            fold_job(stmts_p0_2, Array<Spot>{}, ({
            auto bm_p2_3 = bm_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, crate::syntax::Stmt>)>>(prism_rtl::rc([=, bm_p2_3 = std::move(bm_p2_3)](std::tuple<Array<Spot>, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto bm_p2_3_4 = bm_p2_3;
                entered(once_job([=, bm_p2_3_4 = std::move(bm_p2_3_4)]() {
                return ({
                    auto acc_p3 = p0;
                    auto s_p4 = p1;
                    call_then(start_stmt_spots(s_p4, bm_p2_3_4), [=, acc_p3 = std::move(acc_p3)](Array<Spot> stmt_spots_2562) { return prism_rtl::finished(append(acc_p3, stmt_spots_2562)); });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start StmtsSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_stmts_spots(Array<crate::syntax::Stmt> stmts_p0, Map<Text, crate::check::shrink::Rel> m_p1) {
    return prism_rtl::make_rc<StmtsSpots>(stmts_p0, m_p1);
}


/// StmtSpots: unbounded fn Stmt, (Text ==> Rel) -> [Spot]
Array<Spot> stmt_spots(const crate::syntax::Stmt& s_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    return run_to_end(fold_job(stmt_kids(s_p0, m_p1), Array(std::vector{Spot(Spot::SpotStmt{s_p0, m_p1})}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p2 = p0;
                auto k_p3 = p1;
                call_then(start_kid_spots(k_p3), [=, acc_p2 = std::move(acc_p2)](Array<Spot> kid_spots_2721) { return prism_rtl::finished(append(acc_p2, kid_spots_2721)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Spot>> StmtSpots::cycle() const {
    const auto& s_p0 = this->s_p0;
    const auto& m_p1 = this->m_p1;
    auto m_p1_1 = m_p1;
    auto s_p0_2 = s_p0;
    return call_then(start_stmt_kids(s_p0_2, m_p1_1), [=](Array<Kid> stmt_kids_2661) {
        return fold_job(stmt_kids_2661, Array(std::vector{Spot(Spot::SpotStmt{s_p0_2, m_p1_1})}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p2 = p0;
                    auto k_p3 = p1;
                    call_then(start_kid_spots(k_p3), [=, acc_p2 = std::move(acc_p2)](Array<Spot> kid_spots_2721) { return prism_rtl::finished(append(acc_p2, kid_spots_2721)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start StmtSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_stmt_spots(crate::syntax::Stmt s_p0, Map<Text, crate::check::shrink::Rel> m_p1) {
    return prism_rtl::make_rc<StmtSpots>(s_p0, m_p1);
}


/// BodySpots: unbounded fn FnBody, (Text ==> Rel) -> [Spot]
Array<Spot> body_spots(const crate::syntax::decls::FnBody& fn_body0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body0)) {
        auto&& e_p0 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body0).a0;
        return expr_spots(e_p0, m_p1);
    }
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body0)) {
        auto&& b_p2 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body0).a0;
        return stmts_spots(prism_rtl::deref(b_p2).stmts, m_p1);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Spot>> BodySpots::cycle() const {
    const auto& fn_body0 = this->fn_body0;
    const auto& m_p1 = this->m_p1;
    return ({
        prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body0) ? ({
        auto&& e_p0 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body0).a0;
        prism_rtl::more(prism_rtl::rc(ExprSpots(e_p0, m_p1)));
    })
        : prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body0) ? ({
        auto&& b_p2 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body0).a0;
        prism_rtl::more(prism_rtl::rc(StmtsSpots(prism_rtl::deref(b_p2).stmts, m_p1)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BodySpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_body_spots(crate::syntax::decls::FnBody fn_body0, Map<Text, crate::check::shrink::Rel> m_p1) {
    return prism_rtl::make_rc<BodySpots>(fn_body0, m_p1);
}


/// ExprKids: unbounded fn Expr, (Text ==> Rel) -> [Kid]
Array<Kid> expr_kids(const crate::syntax::Expr& e_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    auto&& _m = prism_rtl::deref(e_p0.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_p2 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_p3 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return call_kids(prism_rtl::deref(prism_rtl::deref(c_p2)), args_p3, m_p1);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& r_p4 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& n_p5 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args_p6 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return call_kids(method_callee(n_p5), method_args(prism_rtl::deref(prism_rtl::deref(r_p4)), args_p6), m_p1);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& l_p7 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_p8 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return exprs_kids(Array(std::vector{prism_rtl::deref(prism_rtl::deref(l_p7)), prism_rtl::deref(prism_rtl::deref(r_p8))}), m_p1);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(_m)) {
        auto&& l_p9 = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a2;
        auto&& r_pa = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a3;
        return exprs_kids(Array(std::vector{prism_rtl::deref(prism_rtl::deref(l_p9)), prism_rtl::deref(prism_rtl::deref(r_pa))}), m_p1);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r_pb = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i_pc = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return exprs_kids(Array(std::vector{prism_rtl::deref(prism_rtl::deref(r_pb)), prism_rtl::deref(prism_rtl::deref(i_pc))}), m_p1);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& x_pd = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pd)), m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& x_pe = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pe)), m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r_pf = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(r_pf)), m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
        auto&& x_pg = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pg)), m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_ph = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_ph)), m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& x_pi = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pi)), m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
        auto&& x_pj = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pj)), m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(_m)) {
        auto&& x_pk = prism_rtl::as<crate::syntax::ExprKind::ENonEmpty>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pk)), m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
        auto&& x_pl = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pl)), m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es_pm = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        return exprs_kids(es_pm, m_p1);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& es_pn = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        return exprs_kids(es_pn, m_p1);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& kvs_po = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        return fold(kvs_po, Array<Kid>{}, [&](const Array<Kid>& acc_pp, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) {
            auto&& k_pq = std::get<0>(_p1);
            auto&& v_pr = std::get<1>(_p1);
            return append(acc_pp, exprs_kids(Array(std::vector{k_pq, v_pr}), m_p1));
        });
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l_ps = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        auto&& _m = prism_rtl::deref(l_ps).kind;
        if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
            auto&& segs_pt = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
            return fold(segs_pt, Array<Kid>{}, [&](const Array<Kid>& acc_pu, const crate::syntax::TextSeg& sg_pv) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Kid>> _v;
                    if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg_pv)) {
                        auto&& x_p10 = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg_pv).a0;
                        _v.set(crate::prelude::push(acc_pu, Kid(Kid::KidExpr{x_p10, m_p1})));
                        goto _done;
                    }
                    {
                        _v.set(acc_pu);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
        }
        {
            return Array<Kid>{};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        auto&& ps_o11 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body_p12 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        return Array(std::vector{lambda_kid(prism_rtl::deref(prism_rtl::deref(body_p12)), later(crate::check::shrink::relations::hide(m_p1, patterns_names(or_(ps_o11, Array<crate::syntax::Pattern_>{})))))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c_p13 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& t_p14 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& el_o15 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        auto with_then_p16 = crate::prelude::push(cond_kids(prism_rtl::deref(prism_rtl::deref(c_p13)), m_p1), Kid(Kid::KidStmts{prism_rtl::deref(t_p14).stmts, crate::check::shrink::relations::cond_rels(prism_rtl::deref(prism_rtl::deref(c_p13)), m_p1)}));
        if (prism_rtl::is_some(el_o15)) {
            auto&& b_p17 = prism_rtl::some_of(el_o15);
            return crate::prelude::push(with_then_p16, Kid(Kid::KidStmts{prism_rtl::deref(b_p17).stmts, m_p1}));
        }
        if (prism_rtl::is_none(el_o15)) {
            return with_then_p16;
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& s_p18 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p19 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return run_to_end(fold_job(arms_p19, Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(s_p18)), m_p1})}), ({
            auto s_p18_1 = prism_rtl::deref(prism_rtl::deref(s_p18));
            auto m_p1_2 = m_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, crate::syntax::Arm>)>>(prism_rtl::rc([=, s_p18_1 = std::move(s_p18_1), m_p1_2 = std::move(m_p1_2)](std::tuple<Array<Kid>, crate::syntax::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto s_p18_1_3 = s_p18_1;
                auto m_p1_2_3 = m_p1_2;
                entered(once_job([=, s_p18_1_3 = std::move(s_p18_1_3), m_p1_2_3 = std::move(m_p1_2_3)]() {
                return ({
                    auto acc_p1a = p0;
                    auto a_p1b = p1;
                    call_then(crate::check::shrink::relations::start_arm_pat_rels(s_p18_1_3, a_p1b, m_p1_2_3), [=, acc_p1a = std::move(acc_p1a)](Map<Text, crate::check::shrink::Rel> arm_pat_rels_4324) {
                    return ({
                        auto am_p1c = arm_pat_rels_4324;
                        (prism_rtl::finished(crate::prelude::push(append(acc_p1a, opt_kids(prism_rtl::deref(a_p1b).guard, am_p1c)), Kid(Kid::KidStmts{prism_rtl::deref(prism_rtl::deref(a_p1b).body).stmts, am_p1c}))));
                    });
                });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
        auto&& s_p1d = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& b_p1e = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(s_p1d)), m_p1}), Kid(Kid::KidStmts{prism_rtl::deref(b_p1e).stmts, later(m_p1)})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
        auto&& s_p1f = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& b_p1g = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(s_p1f)), m_p1}), Kid(Kid::KidStmts{prism_rtl::deref(b_p1g).stmts, m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m)) {
        auto&& s_p1h = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a0;
        auto&& b_p1i = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(s_p1h)), m_p1}), Kid(Kid::KidStmts{prism_rtl::deref(b_p1i).stmts, m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
        auto&& fb_o1j = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& s_p1k = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& b_p1l = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        auto names_p1m = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is_some(fb_o1j)) {
                auto&& fb_p1o = prism_rtl::some_of(fb_o1j);
                _v.set(crate::check::types::union_texts(crate::check::env::names::pattern_names(prism_rtl::deref(fb_p1o).first), crate::check::shrink::summaries::opt_names(prism_rtl::deref(fb_p1o).second)));
                goto _done;
            }
            if (prism_rtl::is_none(fb_o1j)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto in_body_p1n = ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
            if (prism_rtl::is_some(fb_o1j)) {
                auto&& fb_p1p = prism_rtl::some_of(fb_o1j);
                _v.set(({
                    auto with_first_p1q = crate::check::shrink::relations::bind_rels(prism_rtl::deref(fb_p1p).first, part_of(prism_rtl::deref(prism_rtl::deref(s_p1k))), crate::check::shrink::relations::hide(m_p1, names_p1m), false);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
                    auto&& _m = prism_rtl::deref(fb_p1p).second;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p2_p1r = prism_rtl::some_of(_m);
                        _v.set(crate::check::shrink::relations::bind_rels(p2_p1r, part_of(prism_rtl::deref(prism_rtl::deref(s_p1k))), with_first_p1q, false));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(with_first_p1q);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(fb_o1j)) {
                _v.set(crate::check::shrink::relations::hide(m_p1, names_p1m));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(s_p1k)), m_p1}), Kid(Kid::KidStmts{prism_rtl::deref(b_p1l).stmts, in_body_p1n})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
        auto&& b_p1s = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        return Array(std::vector{Kid(Kid::KidStmts{prism_rtl::deref(b_p1s).stmts, m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        auto&& b_p1t = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        return Array(std::vector{Kid(Kid::KidStmts{prism_rtl::deref(b_p1t).stmts, later(m_p1)})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m)) {
        auto&& t_p1u = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        return template_kids(prism_rtl::deref(t_p1u).parts, m_p1);
    }
    {
        return Array<Kid>{};
    }
}


prism_rtl::Turn<Array<Kid>> ExprKids::cycle() const {
    const auto& e_p0 = this->e_p0;
    const auto& m_p1 = this->m_p1;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p0).kind);
        prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& c_p2 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_p3 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        prism_rtl::more(prism_rtl::rc(CallKids(prism_rtl::deref(prism_rtl::deref(c_p2)), args_p3, m_p1)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m) ? ({
        auto&& r_p4 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& n_p5 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args_p6 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        prism_rtl::more(prism_rtl::rc(CallKids(method_callee(n_p5), method_args(prism_rtl::deref(prism_rtl::deref(r_p4)), args_p6), m_p1)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) ? ({
        auto&& l_p7 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_p8 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        prism_rtl::finished(exprs_kids(Array(std::vector{prism_rtl::deref(prism_rtl::deref(l_p7)), prism_rtl::deref(prism_rtl::deref(r_p8))}), m_p1));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(_m) ? ({
        auto&& l_p9 = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a2;
        auto&& r_pa = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a3;
        prism_rtl::finished(exprs_kids(Array(std::vector{prism_rtl::deref(prism_rtl::deref(l_p9)), prism_rtl::deref(prism_rtl::deref(r_pa))}), m_p1));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& r_pb = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i_pc = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        prism_rtl::finished(exprs_kids(Array(std::vector{prism_rtl::deref(prism_rtl::deref(r_pb)), prism_rtl::deref(prism_rtl::deref(i_pc))}), m_p1));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) ? ({
        auto&& x_pd = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pd)), m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) ? ({
        auto&& x_pe = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pe)), m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& r_pf = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(r_pf)), m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m) ? ({
        auto&& x_pg = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pg)), m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_ph = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_ph)), m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m) ? ({
        auto&& x_pi = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pi)), m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECast>(_m) ? ({
        auto&& x_pj = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pj)), m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(_m) ? ({
        auto&& x_pk = prism_rtl::as<crate::syntax::ExprKind::ENonEmpty>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pk)), m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EAny>(_m) ? ({
        auto&& x_pl = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pl)), m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m) ? ({
        auto&& es_pm = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        prism_rtl::finished(exprs_kids(es_pm, m_p1));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) ? ({
        auto&& es_pn = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        prism_rtl::finished(exprs_kids(es_pn, m_p1));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMap>(_m) ? ({
        auto&& kvs_po = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        prism_rtl::finished(fold(kvs_po, Array<Kid>{}, [&](const Array<Kid>& acc_pp, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) {
        auto&& k_pq = std::get<0>(_p1);
        auto&& v_pr = std::get<1>(_p1);
        return append(acc_pp, exprs_kids(Array(std::vector{k_pq, v_pr}), m_p1));
    }));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
        auto&& l_ps = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        ({
        auto&& _m = prism_rtl::deref(l_ps).kind;
        prism_rtl::is<crate::syntax::LitKind::LText>(_m) ? ({
        auto&& segs_pt = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
        prism_rtl::finished(fold(segs_pt, Array<Kid>{}, [&](const Array<Kid>& acc_pu, const crate::syntax::TextSeg& sg_pv) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Kid>> _v;
            if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg_pv)) {
                auto&& x_p10 = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg_pv).a0;
                _v.set(crate::prelude::push(acc_pu, Kid(Kid::KidExpr{x_p10, m_p1})));
                goto _done;
            }
            {
                _v.set(acc_pu);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
    })
        : prism_rtl::finished(Array<Kid>{});
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto&& ps_o11 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body_p12 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto ps_o11_1 = ps_o11;
        auto body_p12_2 = prism_rtl::deref(prism_rtl::deref(body_p12));
        auto m_p1_3 = m_p1;
        call_then(start_patterns_names(or_(ps_o11_1, Array<crate::syntax::Pattern_>{})), [=, body_p12_2 = std::move(body_p12_2), m_p1_3 = std::move(m_p1_3)](Array<Text> patterns_names_4012) { return prism_rtl::finished(Array(std::vector{lambda_kid(body_p12_2, later(crate::check::shrink::relations::hide(m_p1_3, patterns_names_4012)))})); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c_p13 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& t_p14 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& el_o15 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        ({
        auto el_o15_1 = el_o15;
        auto c_p13_2 = prism_rtl::deref(prism_rtl::deref(c_p13));
        auto m_p1_3 = m_p1;
        auto t_p14_4 = t_p14;
        call_then(start_cond_kids(c_p13_2, m_p1_3), [=, el_o15_1 = std::move(el_o15_1), t_p14_4 = std::move(t_p14_4)](Array<Kid> cond_kids_4095) {
        return call_then(crate::check::shrink::relations::start_cond_rels(c_p13_2, m_p1_3), [=](Map<Text, crate::check::shrink::Rel> cond_rels_4131) {
            return ({
                auto with_then_p16 = crate::prelude::push(cond_kids_4095, Kid(Kid::KidStmts{prism_rtl::deref(t_p14_4).stmts, cond_rels_4131}));
                ({
                prism_rtl::is_some(el_o15_1) ? ({
                auto&& b_p17 = prism_rtl::some_of(el_o15_1);
                prism_rtl::finished(crate::prelude::push(with_then_p16, Kid(Kid::KidStmts{prism_rtl::deref(b_p17).stmts, m_p1_3})));
            })
                : prism_rtl::is_none(el_o15_1) ? prism_rtl::finished(with_then_p16)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& s_p18 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p19 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        fold_job(arms_p19, Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(s_p18)), m_p1})}), ({
        auto s_p18_1 = prism_rtl::deref(prism_rtl::deref(s_p18));
        auto m_p1_2 = m_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, crate::syntax::Arm>)>>(prism_rtl::rc([=, s_p18_1 = std::move(s_p18_1), m_p1_2 = std::move(m_p1_2)](std::tuple<Array<Kid>, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto s_p18_1_3 = s_p18_1;
            auto m_p1_2_3 = m_p1_2;
            entered(once_job([=, s_p18_1_3 = std::move(s_p18_1_3), m_p1_2_3 = std::move(m_p1_2_3)]() {
            return ({
                auto acc_p1a = p0;
                auto a_p1b = p1;
                call_then(crate::check::shrink::relations::start_arm_pat_rels(s_p18_1_3, a_p1b, m_p1_2_3), [=, acc_p1a = std::move(acc_p1a)](Map<Text, crate::check::shrink::Rel> arm_pat_rels_4324) {
                return ({
                    auto am_p1c = arm_pat_rels_4324;
                    (prism_rtl::finished(crate::prelude::push(append(acc_p1a, opt_kids(prism_rtl::deref(a_p1b).guard, am_p1c)), Kid(Kid::KidStmts{prism_rtl::deref(prism_rtl::deref(a_p1b).body).stmts, am_p1c}))));
                });
            });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m) ? ({
        auto&& s_p1d = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& b_p1e = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(s_p1d)), m_p1}), Kid(Kid::KidStmts{prism_rtl::deref(b_p1e).stmts, later(m_p1)})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m) ? ({
        auto&& s_p1f = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& b_p1g = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(s_p1f)), m_p1}), Kid(Kid::KidStmts{prism_rtl::deref(b_p1g).stmts, m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m) ? ({
        auto&& s_p1h = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a0;
        auto&& b_p1i = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(s_p1h)), m_p1}), Kid(Kid::KidStmts{prism_rtl::deref(b_p1i).stmts, m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& fb_o1j = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& s_p1k = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& b_p1l = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        ({
        auto names_p1m = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is_some(fb_o1j)) {
                auto&& fb_p1o = prism_rtl::some_of(fb_o1j);
                _v.set(crate::check::types::union_texts(crate::check::env::names::pattern_names(prism_rtl::deref(fb_p1o).first), crate::check::shrink::summaries::opt_names(prism_rtl::deref(fb_p1o).second)));
                goto _done;
            }
            if (prism_rtl::is_none(fb_o1j)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto in_body_p1n = ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
            if (prism_rtl::is_some(fb_o1j)) {
                auto&& fb_p1p = prism_rtl::some_of(fb_o1j);
                _v.set(({
                    auto with_first_p1q = crate::check::shrink::relations::bind_rels(prism_rtl::deref(fb_p1p).first, part_of(prism_rtl::deref(prism_rtl::deref(s_p1k))), crate::check::shrink::relations::hide(m_p1, names_p1m), false);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
                    auto&& _m = prism_rtl::deref(fb_p1p).second;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p2_p1r = prism_rtl::some_of(_m);
                        _v.set(crate::check::shrink::relations::bind_rels(p2_p1r, part_of(prism_rtl::deref(prism_rtl::deref(s_p1k))), with_first_p1q, false));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(with_first_p1q);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(fb_o1j)) {
                _v.set(crate::check::shrink::relations::hide(m_p1, names_p1m));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(s_p1k)), m_p1}), Kid(Kid::KidStmts{prism_rtl::deref(b_p1l).stmts, in_body_p1n})})));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m) ? ({
        auto&& b_p1s = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidStmts{prism_rtl::deref(b_p1s).stmts, m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m) ? ({
        auto&& b_p1t = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidStmts{prism_rtl::deref(b_p1t).stmts, later(m_p1)})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m) ? ({
        auto&& t_p1u = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TemplateKids(prism_rtl::deref(t_p1u).parts, m_p1)));
    })
        : prism_rtl::finished(Array<Kid>{});
    });
}


/// `Start ExprKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_expr_kids(crate::syntax::Expr e_p0, Map<Text, crate::check::shrink::Rel> m_p1) {
    return prism_rtl::make_rc<ExprKids>(e_p0, m_p1);
}


/// StmtKids: unbounded fn Stmt, (Text ==> Rel) -> [Kid]
Array<Kid> stmt_kids(const crate::syntax::Stmt& s_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    auto&& _m = s_p0.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
        auto&& e_p2 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& t_o3 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2;
        return append(Array(std::vector{Kid(Kid::KidExpr{e_p2, m_p1})}), opt_kids(t_o3, m_p1));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m)) {
        auto&& e_p4 = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{e_p4, m_p1})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& e_p5 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        return Array(std::vector{Kid(Kid::KidExpr{e_p5, m_p1})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f_p6 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return Array(std::vector{body_kid(prism_rtl::deref(f_p6).body, later(crate::check::shrink::relations::hide(m_p1, patterns_names(prism_rtl::deref(f_p6).params))))});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        auto&& w_p7 = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        return Array(std::vector{Kid(Kid::KidStmts{prism_rtl::deref(prism_rtl::deref(w_p7).body).stmts, later(m_p1)})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
        auto&& t_p8 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& v_p9 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        return exprs_kids(Array(std::vector{t_p8, v_p9}), m_p1);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
        auto&& t_pa = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& v_pb = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        return exprs_kids(Array(std::vector{t_pa, v_pb}), m_p1);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m)) {
        auto&& c_pc = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{c_pc, m_p1})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m)) {
        auto&& c_pd = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{c_pd, m_p1})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SReturn>(_m)) {
        auto&& e_pe = prism_rtl::as<crate::syntax::StmtKind::SReturn>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{e_pe, m_p1})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& c_pf = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& b_pg = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        return crate::prelude::push(cond_kids(c_pf, m_p1), Kid(Kid::KidStmts{prism_rtl::deref(b_pg).stmts, crate::check::shrink::relations::cond_rels(c_pf, m_p1)}));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e_ph = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{e_ph, m_p1})});
    }
    {
        return Array<Kid>{};
    }
}


prism_rtl::Turn<Array<Kid>> StmtKids::cycle() const {
    const auto& s_p0 = this->s_p0;
    const auto& m_p1 = this->m_p1;
    return ({
        auto&& _m = prism_rtl::deref(s_p0).kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
        auto&& e_p2 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& t_o3 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2;
        prism_rtl::finished(append(Array(std::vector{Kid(Kid::KidExpr{e_p2, m_p1})}), opt_kids(t_o3, m_p1)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m) ? ({
        auto&& e_p4 = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e_p4, m_p1})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& e_p5 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e_p5, m_p1})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f_p6 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        ({
        auto f_p6_1 = f_p6;
        auto m_p1_2 = m_p1;
        call_then(start_patterns_names(prism_rtl::deref(f_p6_1).params), [=, m_p1_2 = std::move(m_p1_2)](Array<Text> patterns_names_5759) { return prism_rtl::finished(Array(std::vector{body_kid(prism_rtl::deref(f_p6_1).body, later(crate::check::shrink::relations::hide(m_p1_2, patterns_names_5759)))})); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
        auto&& w_p7 = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidStmts{prism_rtl::deref(prism_rtl::deref(w_p7).body).stmts, later(m_p1)})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& t_p8 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& v_p9 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        prism_rtl::finished(exprs_kids(Array(std::vector{t_p8, v_p9}), m_p1));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& t_pa = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& v_pb = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        prism_rtl::finished(exprs_kids(Array(std::vector{t_pa, v_pb}), m_p1));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m) ? ({
        auto&& c_pc = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{c_pc, m_p1})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m) ? ({
        auto&& c_pd = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{c_pd, m_p1})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SReturn>(_m) ? ({
        auto&& e_pe = prism_rtl::as<crate::syntax::StmtKind::SReturn>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e_pe, m_p1})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
        auto&& c_pf = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& b_pg = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        ({
        auto b_pg_1 = b_pg;
        auto c_pf_2 = c_pf;
        auto m_p1_3 = m_p1;
        call_then(start_cond_kids(c_pf_2, m_p1_3), [=, b_pg_1 = std::move(b_pg_1)](Array<Kid> cond_kids_6052) { return call_then(crate::check::shrink::relations::start_cond_rels(c_pf_2, m_p1_3), [=](Map<Text, crate::check::shrink::Rel> cond_rels_6088) { return prism_rtl::finished(crate::prelude::push(cond_kids_6052, Kid(Kid::KidStmts{prism_rtl::deref(b_pg_1).stmts, cond_rels_6088}))); }); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& e_ph = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e_ph, m_p1})}));
    })
        : prism_rtl::finished(Array<Kid>{});
    });
}


/// `Start StmtKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_stmt_kids(crate::syntax::Stmt s_p0, Map<Text, crate::check::shrink::Rel> m_p1) {
    return prism_rtl::make_rc<StmtKids>(s_p0, m_p1);
}


/// CondKids: unbounded fn Cond, (Text ==> Rel) -> [Kid]
Array<Kid> cond_kids(const crate::syntax::Cond& c_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p0)) {
        auto&& x_p2 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p0).a0;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_p2)), m_p1})});
    }
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(c_p0)) {
        auto&& x_p3 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p0).a1;
        auto&& g_o4 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p0).a2;
        return append(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_p3)), m_p1})}), opt_kids(prism_rtl::deref(prism_rtl::deref(g_o4)), crate::check::shrink::relations::cond_rels(c_p0, m_p1)));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Kid>> CondKids::cycle() const {
    const auto& c_p0 = this->c_p0;
    const auto& m_p1 = this->m_p1;
    return ({
        prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p0) ? ({
        auto&& x_p2 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p0).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_p2)), m_p1})}));
    })
        : prism_rtl::is<crate::syntax::Cond::CondBind>(c_p0) ? ({
        auto&& x_p3 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p0).a1;
        auto&& g_o4 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p0).a2;
        ({
        auto g_o4_1 = prism_rtl::deref(prism_rtl::deref(g_o4));
        auto c_p0_2 = c_p0;
        auto m_p1_3 = m_p1;
        auto x_p3_4 = prism_rtl::deref(prism_rtl::deref(x_p3));
        call_then(crate::check::shrink::relations::start_cond_rels(c_p0_2, m_p1_3), [=, g_o4_1 = std::move(g_o4_1), x_p3_4 = std::move(x_p3_4)](Map<Text, crate::check::shrink::Rel> cond_rels_6428) { return prism_rtl::finished(append(Array(std::vector{Kid(Kid::KidExpr{x_p3_4, m_p1_3})}), opt_kids(g_o4_1, cond_rels_6428))); });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_cond_kids(crate::syntax::Cond c_p0, Map<Text, crate::check::shrink::Rel> m_p1) {
    return prism_rtl::make_rc<CondKids>(c_p0, m_p1);
}


/// CallKids: unbounded fn Expr, [Arg], (Text ==> Rel) -> [Kid]
Array<Kid> call_kids(const crate::syntax::Expr& c_p0, const Array<crate::syntax::Arg>& args_p1, const Map<Text, crate::check::shrink::Rel>& m_p2) {
    auto callee_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        auto&& _m = callee_name(c_p0);
        if (prism_rtl::is_some(_m)) {
            _v.set(Array<Kid>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array(std::vector{Kid(Kid::KidExpr{c_p0, m_p2})}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _m = traversal_of(m_p2, c_p0, args_p1);
    if (prism_rtl::is_none(_m)) {
        auto&& _m = acc_callee(m_p2, c_p0, args_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& cn_p4 = prism_rtl::some_of(_m);
            return append(callee_p3, run_to_end(fold_job(crate::check::errors::range0(len(args_p1)), Array<Kid>{}, ({
                auto m_p2_1 = m_p2;
                auto cn_p4_2 = cn_p4;
                auto args_p1_3 = args_p1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, Nat>)>>(prism_rtl::rc([=, m_p2_1 = std::move(m_p2_1), cn_p4_2 = std::move(cn_p4_2), args_p1_3 = std::move(args_p1_3)](std::tuple<Array<Kid>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_p2_1_4 = m_p2_1;
                    auto cn_p4_2_4 = cn_p4_2;
                    auto args_p1_3_4 = args_p1_3;
                    entered(once_job([=, m_p2_1_4 = std::move(m_p2_1_4), cn_p4_2_4 = std::move(cn_p4_2_4), args_p1_3_4 = std::move(args_p1_3_4)]() {
                    return ({
                        auto acc_p5 = p0;
                        auto i_p6 = p1;
                        call_then(start_acc_kids(m_p2_1_4, cn_p4_2_4, args_p1_3_4, i_p6), [=, acc_p5 = std::move(acc_p5)](Array<Kid> acc_kids_7288) { return prism_rtl::finished(append(acc_p5, acc_kids_7288)); });
                    });
                }));
                });
            })));
            }))));
        }
        if (prism_rtl::is_none(_m)) {
            return append(callee_p3, exprs_kids(each(args_p1, [&](const crate::syntax::Arg& a_p7) { return a_p7->value; }), m_p2));
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_some(_m)) {
        auto&& coll_p8 = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_p9 = std::get<1>(prism_rtl::some_of(_m));
        auto&& at_pa = std::get<2>(prism_rtl::some_of(_m));
        auto others_pb = fold(crate::check::errors::range0(len(args_p1)), callee_p3, [&](const Array<Kid>& acc_pc, const Nat& i_pd) {
            return i_pd == (at_pa + Nat(1u))
                ? acc_pc
                : ({
                __label__ _done;
                prism_rtl::Slot<Array<Kid>> _v;
                auto&& _m = index(args_p1, i_pd);
                if (prism_rtl::is_some(_m)) {
                    auto&& a_pe = prism_rtl::some_of(_m);
                    _v.set(crate::prelude::push(acc_pc, Kid(Kid::KidExpr{a_pe->value, m_p2})));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(acc_pc);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
        auto&& _m = prism_rtl::deref(prism_rtl::deref(step_p9).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
            auto&& ps_pf = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
            auto&& body_pg = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            return crate::prelude::push(others_pb, lambda_kid(prism_rtl::deref(prism_rtl::deref(body_pg)), crate::check::shrink::relations::step_rels(m_p2, coll_p8, ps_pf, at_pa)));
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            return others_pb;
        }
        {
            return crate::prelude::push(others_pb, Kid(Kid::KidExpr{step_p9, m_p2}));
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Kid>> CallKids::cycle() const {
    const auto& c_p0 = this->c_p0;
    const auto& args_p1 = this->args_p1;
    const auto& m_p2 = this->m_p2;
    auto callee_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        auto&& _m = callee_name(c_p0);
        if (prism_rtl::is_some(_m)) {
            _v.set(Array<Kid>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array(std::vector{Kid(Kid::KidExpr{c_p0, m_p2})}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        auto&& _m = traversal_of(m_p2, c_p0, args_p1);
        prism_rtl::is_none(_m) ? ({
        auto&& _m = acc_callee(m_p2, c_p0, args_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& cn_p4 = prism_rtl::some_of(_m);
        ({
        auto args_p1_1 = args_p1;
        auto m_p2_2 = m_p2;
        call_value(fold_job(crate::check::errors::range0(len(args_p1_1)), Array<Kid>{}, ({
        auto m_p2_2_3 = m_p2_2;
        auto cn_p4_3 = cn_p4;
        auto args_p1_1_4 = args_p1_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, Nat>)>>(prism_rtl::rc([=, m_p2_2_3 = std::move(m_p2_2_3), cn_p4_3 = std::move(cn_p4_3), args_p1_1_4 = std::move(args_p1_1_4)](std::tuple<Array<Kid>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_p2_2_3_4 = m_p2_2_3;
            auto cn_p4_3_4 = cn_p4_3;
            auto args_p1_1_4_4 = args_p1_1_4;
            entered(once_job([=, m_p2_2_3_4 = std::move(m_p2_2_3_4), cn_p4_3_4 = std::move(cn_p4_3_4), args_p1_1_4_4 = std::move(args_p1_1_4_4)]() {
            return ({
                auto acc_p5 = p0;
                auto i_p6 = p1;
                call_then(start_acc_kids(m_p2_2_3_4, cn_p4_3_4, args_p1_1_4_4, i_p6), [=, acc_p5 = std::move(acc_p5)](Array<Kid> acc_kids_7288) { return prism_rtl::finished(append(acc_p5, acc_kids_7288)); });
            });
        }));
        });
    })));
    })), [=](Array<Kid> fold_7233) { return prism_rtl::finished(append(callee_p3, fold_7233)); });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(append(callee_p3, exprs_kids(each(args_p1, [&](const crate::syntax::Arg& a_p7) { return a_p7->value; }), m_p2)))
        : throw prism_rtl::Panic("no arm matched");
    })
        : prism_rtl::is_some(_m) ? ({
        auto&& coll_p8 = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_p9 = std::get<1>(prism_rtl::some_of(_m));
        auto&& at_pa = std::get<2>(prism_rtl::some_of(_m));
        ({
        auto others_pb = fold(crate::check::errors::range0(len(args_p1)), callee_p3, [&](const Array<Kid>& acc_pc, const Nat& i_pd) {
            return i_pd == (at_pa + Nat(1u))
                ? acc_pc
                : ({
                __label__ _done;
                prism_rtl::Slot<Array<Kid>> _v;
                auto&& _m = index(args_p1, i_pd);
                if (prism_rtl::is_some(_m)) {
                    auto&& a_pe = prism_rtl::some_of(_m);
                    _v.set(crate::prelude::push(acc_pc, Kid(Kid::KidExpr{a_pe->value, m_p2})));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(acc_pc);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(step_p9).kind);
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0) ? ({
        auto&& ps_pf = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
        auto&& body_pg = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto body_pg_1 = prism_rtl::deref(prism_rtl::deref(body_pg));
        auto m_p2_2 = m_p2;
        auto ps_pf_3 = ps_pf;
        call_then(crate::check::shrink::relations::start_step_rels(m_p2_2, coll_p8, ps_pf_3, at_pa), [=, body_pg_1 = std::move(body_pg_1)](Map<Text, crate::check::shrink::Rel> step_rels_7701) { return prism_rtl::finished(crate::prelude::push(others_pb, lambda_kid(body_pg_1, step_rels_7701))); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? prism_rtl::finished(others_pb)
        : prism_rtl::finished(crate::prelude::push(others_pb, Kid(Kid::KidExpr{step_p9, m_p2})));
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_call_kids(crate::syntax::Expr c_p0, Array<crate::syntax::Arg> args_p1, Map<Text, crate::check::shrink::Rel> m_p2) {
    return prism_rtl::make_rc<CallKids>(c_p0, args_p1, m_p2);
}


/// Later: fn (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> later(const Map<Text, crate::check::shrink::Rel>& m_p0) {
    return insert(m_p0, Text::lit("lam:"), crate::check::shrink::relations::no_rel());
}


/// ?AccCallee: fn (Text ==> Rel), Expr, [Arg] -> ?Text
std::optional<Text> acc_callee(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& c_p1, const Array<crate::syntax::Arg>& args_p2) {
    auto&& _m = callee_name(c_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& cn_p3 = prism_rtl::some_of(_m);
        return crate::check::shrink::relations::is_local(m_p0, cn_p3)
            ? std::optional<Text>{}
            : !fold(args_p2, true, [&](const bool& ok_p4, const crate::syntax::Arg& a_p5) { return prism_rtl::deref(ok_p4) && (prism_rtl::deref(a_p5).name == std::optional<crate::syntax::Ident>{}); })
            ? std::optional<Text>{}
            : fold(crate::check::errors::range0(len(args_p2)), false, [&](const bool& seen_p6, const Nat& i_p7) { return prism_rtl::deref(seen_p6) || crate::check::env::has_key(m_p0, prism_rtl::cat("acc:", cn_p3, ":", i_p7)); })
            ? std::optional(cn_p3)
            : std::optional<Text>{};
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// AccKids: unbounded fn (Text ==> Rel), Text, [Arg], Nat -> [Kid]
Array<Kid> acc_kids(const Map<Text, crate::check::shrink::Rel>& m_p0, const Text& cn_p1, const Array<crate::syntax::Arg>& args_p2, const Nat& i_p3) {
    auto a_p4 = or_(index(args_p2, i_p3), crate::check::shrink::summaries::dummy_arg());
    return !crate::check::env::has_key(m_p0, prism_rtl::cat("acc:", cn_p1, ":", i_p3))
        ? Array(std::vector{Kid(Kid::KidExpr{a_p4->value, m_p0})})
        : ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(a_p4->value).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
            auto&& ps_o5 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
            auto&& body_p6 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(Array(std::vector{lambda_kid(prism_rtl::deref(prism_rtl::deref(body_p6)), acc_lambda_rels(m_p0, cn_p1, i_p3, or_(ps_o5, Array<crate::syntax::Pattern_>{}), args_p2))}));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            _v.set(Array<Kid>{});
            goto _done;
        }
        {
            _v.set(Array(std::vector{Kid(Kid::KidExpr{a_p4->value, m_p0})}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Kid>> AccKids::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& cn_p1 = this->cn_p1;
    const auto& args_p2 = this->args_p2;
    const auto& i_p3 = this->i_p3;
    auto a_p4 = or_(index(args_p2, i_p3), crate::check::shrink::summaries::dummy_arg());
    return !crate::check::env::has_key(m_p0, prism_rtl::cat("acc:", cn_p1, ":", i_p3))
        ? prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{a_p4->value, m_p0})}))
        : ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(a_p4->value).kind);
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto&& ps_o5 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body_p6 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        prism_rtl::finished(Array(std::vector{lambda_kid(prism_rtl::deref(prism_rtl::deref(body_p6)), acc_lambda_rels(m_p0, cn_p1, i_p3, or_(ps_o5, Array<crate::syntax::Pattern_>{}), args_p2))}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? prism_rtl::finished(Array<Kid>{})
        : prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{a_p4->value, m_p0})}));
    });
}


/// `Start AccKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_acc_kids(Map<Text, crate::check::shrink::Rel> m_p0, Text cn_p1, Array<crate::syntax::Arg> args_p2, Nat i_p3) {
    return prism_rtl::make_rc<AccKids>(m_p0, cn_p1, args_p2, i_p3);
}


/// AccLambdaRels: unbounded fn (Text ==> Rel), Text, Nat, [Pattern], [Arg] -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> acc_lambda_rels(const Map<Text, crate::check::shrink::Rel>& m_p0, const Text& cn_p1, const Nat& j_p2, const Array<crate::syntax::Pattern_>& ps_p3, const Array<crate::syntax::Arg>& args_p4) {
    auto h_p5 = crate::check::shrink::relations::hide(m_p0, patterns_names(ps_p3));
    return run_to_end(fold_job(crate::check::errors::range0(len(ps_p3)), h_p5, ({
        auto m_p0_1 = m_p0;
        auto cn_p1_2 = cn_p1;
        auto j_p2_3 = j_p2;
        auto ps_p3_4 = ps_p3;
        auto args_p4_5 = args_p4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Nat>)>>(prism_rtl::rc([=, m_p0_1 = std::move(m_p0_1), cn_p1_2 = std::move(cn_p1_2), j_p2_3 = std::move(j_p2_3), ps_p3_4 = std::move(ps_p3_4), args_p4_5 = std::move(args_p4_5)](std::tuple<Map<Text, crate::check::shrink::Rel>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_p0_1_6 = m_p0_1;
            auto cn_p1_2_6 = cn_p1_2;
            auto j_p2_3_6 = j_p2_3;
            auto ps_p3_4_6 = ps_p3_4;
            auto args_p4_5_6 = args_p4_5;
            entered(once_job([=, m_p0_1_6 = std::move(m_p0_1_6), cn_p1_2_6 = std::move(cn_p1_2_6), j_p2_3_6 = std::move(j_p2_3_6), ps_p3_4_6 = std::move(ps_p3_4_6), args_p4_5_6 = std::move(args_p4_5_6)]() {
            return ({
                auto m2_p6 = p0;
                auto q_p7 = p1;
                ({
                auto&& _m = std::tuple{crate::prelude::get(m_p0_1_6, prism_rtl::cat("sum:", cn_p1_2_6, ":", j_p2_3_6, ":", q_p7)), index(ps_p3_4_6, q_p7)};
                prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m)) ? ({
                auto&& s_p8 = prism_rtl::some_of(std::get<0>(_m));
                auto&& p_p9 = prism_rtl::some_of(std::get<1>(_m));
                prism_rtl::deref(s_p8).param == top_param()
                ? prism_rtl::finished(m2_p6)
                : ({
                auto&& _m = index(args_p4_5_6, prism_rtl::deref(s_p8).param);
                prism_rtl::is_some(_m) ? ({
                auto&& a_pa = prism_rtl::some_of(_m);
                call_then(start_rel_of(m_p0_1_6, a_pa->value), [=](std::optional<crate::check::shrink::Rel> rel_of_9689) {
                return ({
                    prism_rtl::is_some(rel_of_9689) ? ({
                    auto&& r_pb = prism_rtl::some_of(rel_of_9689);
                    ({
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p9).kind);
                    prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                    auto&& n_pc = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                    prism_rtl::finished(insert(m2_p6, crate::check::env::sname_key(n_pc), crate::check::shrink::Rel{.param = prism_rtl::deref(r_pb).param, .strict = prism_rtl::deref(r_pb).strict || prism_rtl::deref(s_p8).strict}));
                })
                    : call_then(crate::check::env::names::start_pattern_names(p_p9), [=](Array<Text> pattern_names_9884) { return prism_rtl::finished(fold(pattern_names_9884, m2_p6, [&](const Map<Text, crate::check::shrink::Rel>& m3_pd, const Text& n_pe) { return insert(m3_pd, n_pe, crate::check::shrink::Rel{.param = prism_rtl::deref(r_pb).param, .strict = true}); })); });
                });
                })
                    : prism_rtl::is_none(rel_of_9689) ? prism_rtl::finished(m2_p6)
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m2_p6)
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : prism_rtl::finished(m2_p6);
            });
            });
        }));
        });
    }));
    })));
}


/// let topParam
Nat top_param() {
    return Nat(9999u);
}


/// TemplateKids: unbounded fn [TemplatePart], (Text ==> Rel) -> [Kid]
Array<Kid> template_kids(const Array<crate::syntax::TemplatePart>& parts_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    return fold(parts_p0, Array<Kid>{}, [&](const Array<Kid>& acc_p2, const crate::syntax::TemplatePart& p_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Kid>> _v;
            if (prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(p_p3)) {
                auto&& x_p4 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(p_p3).a0;
                _v.set(crate::prelude::push(acc_p2, Kid(Kid::KidExpr{x_p4, m_p1})));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(p_p3)) {
                auto&& b_p5 = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(p_p3).a0;
                _v.set(crate::prelude::push(acc_p2, Kid(Kid::KidStmts{prism_rtl::deref(b_p5).stmts, m_p1})));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::TemplatePart::TpCall>(p_p3)) {
                auto&& n_p6 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p3).a0;
                auto&& args_p7 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p3).a1;
                auto&& ps_o8 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p3).a2;
                auto&& span_p9 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p3).a3;
                _v.set(crate::prelude::push(acc_p2, Kid(Kid::KidExpr{template_call_expr(n_p6, args_p7, ps_o8, span_p9), m_p1})));
                goto _done;
            }
            {
                _v.set(acc_p2);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Kid>> TemplateKids::cycle() const {
    const auto& parts_p0 = this->parts_p0;
    const auto& m_p1 = this->m_p1;
    return prism_rtl::finished(fold(parts_p0, Array<Kid>{}, [&](const Array<Kid>& acc_p2, const crate::syntax::TemplatePart& p_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Kid>> _v;
            if (prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(p_p3)) {
                auto&& x_p4 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(p_p3).a0;
                _v.set(crate::prelude::push(acc_p2, Kid(Kid::KidExpr{x_p4, m_p1})));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(p_p3)) {
                auto&& b_p5 = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(p_p3).a0;
                _v.set(crate::prelude::push(acc_p2, Kid(Kid::KidStmts{prism_rtl::deref(b_p5).stmts, m_p1})));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::TemplatePart::TpCall>(p_p3)) {
                auto&& n_p6 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p3).a0;
                auto&& args_p7 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p3).a1;
                auto&& ps_o8 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p3).a2;
                auto&& span_p9 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p3).a3;
                _v.set(crate::prelude::push(acc_p2, Kid(Kid::KidExpr{template_call_expr(n_p6, args_p7, ps_o8, span_p9), m_p1})));
                goto _done;
            }
            {
                _v.set(acc_p2);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start TemplateKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_template_kids(Array<crate::syntax::TemplatePart> parts_p0, Map<Text, crate::check::shrink::Rel> m_p1) {
    return prism_rtl::make_rc<TemplateKids>(parts_p0, m_p1);
}


/// TemplateCallExpr: fn SName, [Arg], ?[TemplatePart], Range -> Expr
crate::syntax::Expr template_call_expr(const crate::syntax::SName& n_p0, const Array<crate::syntax::Arg>& args_p1, const std::optional<Array<crate::syntax::TemplatePart>>& ps_o2, const crate::syntax::Range& span_p3) {
    auto body_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Arg>> _v;
        if (prism_rtl::is_some(ps_o2)) {
            auto&& ps_p5 = prism_rtl::some_of(ps_o2);
            _v.set(Array(std::vector{crate::syntax::Arg{.name = std::optional(crate::syntax::Ident{.name = Text::lit("#body"), .span = span_p3}), .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETemplate{crate::syntax::Template{.keyword = Text::lit("InlineText"), .lang = Text::lit(""), .delims = Text::lit("double"), .parts = ps_p5, .span = span_p3}})), .span = span_p3}, .span = span_p3}}));
            goto _done;
        }
        if (prism_rtl::is_none(ps_o2)) {
            _v.set(Array<crate::syntax::Arg>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{n_p0})), .span = n_p0.span}), append(args_p1, body_p4), false, false})), .span = span_p3};
}


/// ArgOf: fn Expr -> Arg
crate::syntax::Arg arg_of(const crate::syntax::Expr& x_p0) {
    return crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = x_p0, .span = x_p0.span};
}


/// ExprsKids: fn [Expr], (Text ==> Rel) -> [Kid]
Array<Kid> exprs_kids(const Array<crate::syntax::Expr>& xs_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    return each(xs_p0, [&](const crate::syntax::Expr& x_p2) { return Kid(Kid::KidExpr{x_p2, m_p1}); });
}


/// OptKids: fn ?Expr, (Text ==> Rel) -> [Kid]
Array<Kid> opt_kids(const std::optional<crate::syntax::Expr>& opt0, const Map<Text, crate::check::shrink::Rel>& map1) {
    auto&& _m = std::tuple{opt0, map1};
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& x_p0 = prism_rtl::some_of(std::get<0>(_m));
        auto&& m_p1 = std::get<1>(_m);
        return Array(std::vector{Kid(Kid::KidExpr{x_p0, m_p1})});
    }
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Array<Kid>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// LambdaKid: fn LambdaBody, (Text ==> Rel) -> Kid
Kid lambda_kid(const crate::syntax::LambdaBody& lambda_body0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body0)) {
        auto&& x_p0 = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body0).a0;
        return Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_p0)), m_p1});
    }
    if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body0)) {
        auto&& b_p2 = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body0).a0;
        return Kid(Kid::KidStmts{prism_rtl::deref(b_p2).stmts, m_p1});
    }
    prism_rtl::unreachable("no arm matched");
}


/// BodyKid: fn FnBody, (Text ==> Rel) -> Kid
Kid body_kid(const crate::syntax::decls::FnBody& fn_body0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body0)) {
        auto&& x_p0 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body0).a0;
        return Kid(Kid::KidExpr{x_p0, m_p1});
    }
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body0)) {
        auto&& b_p2 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body0).a0;
        return Kid(Kid::KidStmts{prism_rtl::deref(b_p2).stmts, m_p1});
    }
    prism_rtl::unreachable("no arm matched");
}


/// PatternsNames: unbounded fn [Pattern] -> [Text]
Array<Text> patterns_names(const Array<crate::syntax::Pattern_>& ps_p0) {
    return run_to_end(fold_job(ps_p0, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a_p1 = p0;
                auto p_p2 = p1;
                call_then(crate::check::env::names::start_pattern_names(p_p2), [=, a_p1 = std::move(a_p1)](Array<Text> pattern_names_11843) { return prism_rtl::finished(crate::check::types::union_texts(a_p1, pattern_names_11843)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> PatternsNames::cycle() const {
    const auto& ps_p0 = this->ps_p0;
    return fold_job(ps_p0, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a_p1 = p0;
                auto p_p2 = p1;
                call_then(crate::check::env::names::start_pattern_names(p_p2), [=, a_p1 = std::move(a_p1)](Array<Text> pattern_names_11843) { return prism_rtl::finished(crate::check::types::union_texts(a_p1, pattern_names_11843)); });
            });
        }));
    })))->cycle();
}


/// `Start PatternsNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_patterns_names(Array<crate::syntax::Pattern_> ps_p0) {
    return prism_rtl::make_rc<PatternsNames>(ps_p0);
}


/// ?CalleeName: fn Expr -> ?Text
std::optional<Text> callee_name(const crate::syntax::Expr& c_p0) {
    auto&& _m = prism_rtl::deref(c_p0.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return std::optional(crate::check::env::sname_key(n_p1));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& t_p2 = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p2).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return std::optional(crate::check::env::sname_key(n_p3));
        }
        {
            return std::optional<Text>{};
        }
    }
    {
        return std::optional<Text>{};
    }
}


/// MethodCallee: fn SName -> Expr
crate::syntax::Expr method_callee(const crate::syntax::SName& n_p0) {
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{n_p0})), .span = n_p0.span};
}


/// MethodArgs: fn Expr, [Arg] -> [Arg]
Array<crate::syntax::Arg> method_args(const crate::syntax::Expr& r_p0, const Array<crate::syntax::Arg>& args_p1) {
    return append(Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = r_p0, .span = r_p0.span}}), args_p1);
}


/// BodySites: unbounded fn FnBody, (Text ==> Rel) -> [Site]
Array<Site> body_sites(const crate::syntax::decls::FnBody& body_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    return run_to_end(fold_job(body_spots(body_p0, m_p1), Array<Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p2 = p0;
                auto sp_p3 = p1;
                call_then(start_spot_sites(sp_p3), [=, acc_p2 = std::move(acc_p2)](Array<Site> spot_sites_12800) { return prism_rtl::finished(append(acc_p2, spot_sites_12800)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Site>> BodySites::cycle() const {
    const auto& body_p0 = this->body_p0;
    const auto& m_p1 = this->m_p1;
    auto body_p0_1 = body_p0;
    auto m_p1_2 = m_p1;
    return call_then(start_body_spots(body_p0_1, m_p1_2), [=](Array<Spot> body_spots_12750) {
        return fold_job(body_spots_12750, Array<Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p2 = p0;
                    auto sp_p3 = p1;
                    call_then(start_spot_sites(sp_p3), [=, acc_p2 = std::move(acc_p2)](Array<Site> spot_sites_12800) { return prism_rtl::finished(append(acc_p2, spot_sites_12800)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start BodySites, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Site>> start_body_sites(crate::syntax::decls::FnBody body_p0, Map<Text, crate::check::shrink::Rel> m_p1) {
    return prism_rtl::make_rc<BodySites>(body_p0, m_p1);
}


/// SpotSites: unbounded fn Spot -> [Site]
Array<Site> spot_sites(const Spot& spot0) {
    if (prism_rtl::is<Spot::SpotStmt>(spot0)) {
        return Array<Site>{};
    }
    if (prism_rtl::is<Spot::SpotExpr>(spot0)) {
        auto&& e_p0 = prism_rtl::as<Spot::SpotExpr>(spot0).a0;
        auto&& m_p1 = prism_rtl::as<Spot::SpotExpr>(spot0).a1;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p0).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_p2 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return Array(std::vector{Site{.callee = crate::check::env::sname_key(n_p2), .args = Array<crate::syntax::Arg>{}, .span = prism_rtl::deref(e_p0).span, .rels = m_p1}});
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c_p3 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args_p4 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            return call_sites(prism_rtl::deref(prism_rtl::deref(c_p3)), args_p4, prism_rtl::deref(e_p0).span, m_p1);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
            auto&& r_p5 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
            auto&& n_p6 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
            auto&& args_p7 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
            return call_sites(method_callee(n_p6), method_args(prism_rtl::deref(prism_rtl::deref(r_p5)), args_p7), prism_rtl::deref(e_p0).span, m_p1);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
            auto&& op_p8 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l_p9 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r_pa = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            return is_called_op(op_p8)
                ? Array(std::vector{Site{.callee = op_p8, .args = Array(std::vector{arg_of(prism_rtl::deref(prism_rtl::deref(l_p9))), arg_of(prism_rtl::deref(prism_rtl::deref(r_pa)))}), .span = prism_rtl::deref(e_p0).span, .rels = m_p1}})
                : Array<Site>{};
        }
        {
            return Array<Site>{};
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Site>> SpotSites::cycle() const {
    const auto& spot0 = this->spot0;
    return ({
        prism_rtl::is<Spot::SpotStmt>(spot0) ? prism_rtl::finished(Array<Site>{})
        : prism_rtl::is<Spot::SpotExpr>(spot0) ? ({
        auto&& e_p0 = prism_rtl::as<Spot::SpotExpr>(spot0).a0;
        auto&& m_p1 = prism_rtl::as<Spot::SpotExpr>(spot0).a1;
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p0).kind);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p2 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        prism_rtl::finished(Array(std::vector{Site{.callee = crate::check::env::sname_key(n_p2), .args = Array<crate::syntax::Arg>{}, .span = prism_rtl::deref(e_p0).span, .rels = m_p1}}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& c_p3 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_p4 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        prism_rtl::more(prism_rtl::rc(CallSites(prism_rtl::deref(prism_rtl::deref(c_p3)), args_p4, prism_rtl::deref(e_p0).span, m_p1)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m) ? ({
        auto&& r_p5 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& n_p6 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args_p7 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        prism_rtl::more(prism_rtl::rc(CallSites(method_callee(n_p6), method_args(prism_rtl::deref(prism_rtl::deref(r_p5)), args_p7), prism_rtl::deref(e_p0).span, m_p1)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) ? ({
        auto&& op_p8 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l_p9 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_pa = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        is_called_op(op_p8)
        ? prism_rtl::finished(Array(std::vector{Site{.callee = op_p8, .args = Array(std::vector{arg_of(prism_rtl::deref(prism_rtl::deref(l_p9))), arg_of(prism_rtl::deref(prism_rtl::deref(r_pa)))}), .span = prism_rtl::deref(e_p0).span, .rels = m_p1}}))
        : prism_rtl::finished(Array<Site>{});
    })
        : prism_rtl::finished(Array<Site>{});
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotSites, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Site>> start_spot_sites(Spot spot0) {
    return prism_rtl::make_rc<SpotSites>(spot0);
}


/// IsCalledOp: fn Text -> Bool
bool is_called_op(const Text& op_p0) {
    return !crate::check::types::has_text(Array(std::vector{Text::lit("and"), Text::lit("or"), Text::lit("on"), Text::lit("<|"), Text::lit("mod")}), op_p0);
}


/// CallSites: unbounded fn Expr, [Arg], Range, (Text ==> Rel) -> [Site]
Array<Site> call_sites(const crate::syntax::Expr& c_p0, const Array<crate::syntax::Arg>& args_p1, const crate::syntax::Range& span_p2, const Map<Text, crate::check::shrink::Rel>& m_p3) {
    auto direct_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Array<Site>> _v;
        auto&& _m = callee_name(c_p0);
        if (prism_rtl::is_some(_m)) {
            auto&& n_p5 = prism_rtl::some_of(_m);
            _v.set(Array(std::vector{Site{.callee = n_p5, .args = args_p1, .span = span_p2, .rels = m_p3}}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Site>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _m = traversal_of(m_p3, c_p0, args_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& coll_p6 = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_p7 = std::get<1>(prism_rtl::some_of(_m));
        auto&& at_p8 = std::get<2>(prism_rtl::some_of(_m));
        auto&& _m = prism_rtl::deref(prism_rtl::deref(step_p7).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_p9 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            auto call_args_pa = at_p8 == Nat(1u)
                ? Array(std::vector{or_(index(args_p1, Nat(1u)), crate::check::shrink::summaries::dummy_arg()), arg_of(part_of(coll_p6))})
                : Array(std::vector{arg_of(part_of(coll_p6))});
            return crate::prelude::push(direct_p4, Site{.callee = crate::check::env::sname_key(n_p9), .args = call_args_pa, .span = prism_rtl::deref(step_p7).span, .rels = m_p3});
        }
        {
            return direct_p4;
        }
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = acc_callee(m_p3, c_p0, args_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& cn_pb = prism_rtl::some_of(_m);
            return append(direct_p4, acc_sites(m_p3, cn_pb, args_p1));
        }
        if (prism_rtl::is_none(_m)) {
            return direct_p4;
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Site>> CallSites::cycle() const {
    const auto& c_p0 = this->c_p0;
    const auto& args_p1 = this->args_p1;
    const auto& span_p2 = this->span_p2;
    const auto& m_p3 = this->m_p3;
    auto direct_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Array<Site>> _v;
        auto&& _m = callee_name(c_p0);
        if (prism_rtl::is_some(_m)) {
            auto&& n_p5 = prism_rtl::some_of(_m);
            _v.set(Array(std::vector{Site{.callee = n_p5, .args = args_p1, .span = span_p2, .rels = m_p3}}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Site>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        auto&& _m = traversal_of(m_p3, c_p0, args_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& coll_p6 = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_p7 = std::get<1>(prism_rtl::some_of(_m));
        auto&& at_p8 = std::get<2>(prism_rtl::some_of(_m));
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(step_p7).kind);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p9 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto call_args_pa = at_p8 == Nat(1u)
            ? Array(std::vector{or_(index(args_p1, Nat(1u)), crate::check::shrink::summaries::dummy_arg()), arg_of(part_of(coll_p6))})
            : Array(std::vector{arg_of(part_of(coll_p6))});
        (prism_rtl::finished(crate::prelude::push(direct_p4, Site{.callee = crate::check::env::sname_key(n_p9), .args = call_args_pa, .span = prism_rtl::deref(step_p7).span, .rels = m_p3})));
    });
    })
        : prism_rtl::finished(direct_p4);
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = acc_callee(m_p3, c_p0, args_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& cn_pb = prism_rtl::some_of(_m);
        prism_rtl::finished(append(direct_p4, acc_sites(m_p3, cn_pb, args_p1)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(direct_p4)
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallSites, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Site>> start_call_sites(crate::syntax::Expr c_p0, Array<crate::syntax::Arg> args_p1, crate::syntax::Range span_p2, Map<Text, crate::check::shrink::Rel> m_p3) {
    return prism_rtl::make_rc<CallSites>(c_p0, args_p1, span_p2, m_p3);
}


/// PartOf: fn Expr -> Expr
crate::syntax::Expr part_of(const crate::syntax::Expr& x_p0) {
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(x_p0), Text::lit(""), crate::syntax::Ident{.name = Text::lit("element"), .span = x_p0.span}})), .span = x_p0.span};
}


/// AccSites: fn (Text ==> Rel), Text, [Arg] -> [Site]
Array<Site> acc_sites(const Map<Text, crate::check::shrink::Rel>& m_p0, const Text& cn_p1, const Array<crate::syntax::Arg>& args_p2) {
    return fold(crate::check::errors::range0(len(args_p2)), Array<Site>{}, [&](const Array<Site>& acc_p3, const Nat& j_p4) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Site>> _v;
            auto&& _m = std::tuple{crate::prelude::get(m_p0, prism_rtl::cat("acc:", cn_p1, ":", j_p4)), index(args_p2, j_p4)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& ar_p5 = prism_rtl::some_of(std::get<0>(_m));
                auto&& a_p6 = prism_rtl::some_of(std::get<1>(_m));
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Site>> _v;
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(a_p6->value).kind);
                    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                        auto&& f_p7 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                        _v.set(crate::prelude::push(acc_p3, Site{.callee = crate::check::env::sname_key(f_p7), .args = each(crate::check::errors::range0(prism_rtl::deref(ar_p5).param), [&](const Nat& q_p8) { return acc_arg(m_p0, cn_p1, j_p4, q_p8, args_p2); }), .span = prism_rtl::deref(a_p6->value).span, .rels = m_p0}));
                        goto _done;
                    }
                    {
                        _v.set(acc_p3);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc_p3);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// AccArg: fn (Text ==> Rel), Text, Nat, Nat, [Arg] -> Arg
crate::syntax::Arg acc_arg(const Map<Text, crate::check::shrink::Rel>& m_p0, const Text& cn_p1, const Nat& j_p2, const Nat& q_p3, const Array<crate::syntax::Arg>& args_p4) {
    auto&& _m = crate::prelude::get(m_p0, prism_rtl::cat("sum:", cn_p1, ":", j_p2, ":", q_p3));
    if (prism_rtl::is_some(_m)) {
        auto&& s_p5 = prism_rtl::some_of(_m);
        return prism_rtl::deref(s_p5).param == top_param()
            ? arg_of(top_expr())
            : ({
            __label__ _done;
            prism_rtl::Slot<crate::syntax::Arg> _v;
            auto&& _m = index(args_p4, prism_rtl::deref(s_p5).param);
            if (prism_rtl::is_some(_m)) {
                auto&& a_p6 = prism_rtl::some_of(_m);
                _v.set(arg_of(prism_rtl::deref(s_p5).strict ? part_of(a_p6->value) : a_p6->value));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::check::shrink::summaries::dummy_arg());
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return crate::check::shrink::summaries::dummy_arg();
    }
    prism_rtl::unreachable("no arm matched");
}


/// let topExpr
crate::syntax::Expr top_expr() {
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{crate::syntax::SName{.sigils = Text::lit(""), .path_ = Array(std::vector{Text::lit("⊤")}), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// SpotsNames: unbounded fn [Spot] -> [Text]
Array<Text> spots_names(const Array<Spot>& spots_p0) {
    return run_to_end(fold_job(spots_p0, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p1 = p0;
                auto sp_p2 = p1;
                call_then(start_spot_names(sp_p2), [=, acc_p1 = std::move(acc_p1)](Array<Text> spot_names_16141) { return prism_rtl::finished(crate::check::types::union_texts(acc_p1, spot_names_16141)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> SpotsNames::cycle() const {
    const auto& spots_p0 = this->spots_p0;
    return fold_job(spots_p0, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p1 = p0;
                auto sp_p2 = p1;
                call_then(start_spot_names(sp_p2), [=, acc_p1 = std::move(acc_p1)](Array<Text> spot_names_16141) { return prism_rtl::finished(crate::check::types::union_texts(acc_p1, spot_names_16141)); });
            });
        }));
    })))->cycle();
}


/// `Start SpotsNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spots_names(Array<Spot> spots_p0) {
    return prism_rtl::make_rc<SpotsNames>(spots_p0);
}


/// SpotNames: unbounded fn Spot -> [Text]
Array<Text> spot_names(const Spot& sp_p0) {
    auto called_p1 = each(spot_sites(sp_p0), [&](const Site& s_p2) { return prism_rtl::deref(s_p2).callee; });
    if (prism_rtl::is<Spot::SpotExpr>(sp_p0)) {
        return called_p1;
    }
    if (prism_rtl::is<Spot::SpotStmt>(sp_p0)) {
        auto&& s_p3 = prism_rtl::as<Spot::SpotStmt>(sp_p0).a0;
        auto&& _m = prism_rtl::deref(s_p3).kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
            auto&& w_p4 = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
            return crate::check::types::add_text(called_p1, crate::check::env::sname_key(prism_rtl::deref(w_p4).name));
        }
        {
            return called_p1;
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> SpotNames::cycle() const {
    const auto& sp_p0 = this->sp_p0;
    auto sp_p0_1 = sp_p0;
    return call_then(start_spot_sites(sp_p0_1), [=](Array<Site> spot_sites_16235) {
        return ({
            auto called_p1 = each(spot_sites_16235, [&](const Site& s_p2) { return prism_rtl::deref(s_p2).callee; });
            ({
            prism_rtl::is<Spot::SpotExpr>(sp_p0_1) ? prism_rtl::finished(called_p1)
            : prism_rtl::is<Spot::SpotStmt>(sp_p0_1) ? ({
            auto&& s_p3 = prism_rtl::as<Spot::SpotStmt>(sp_p0_1).a0;
            ({
            auto&& _m = prism_rtl::deref(s_p3).kind;
            prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
            auto&& w_p4 = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
            prism_rtl::finished(crate::check::types::add_text(called_p1, crate::check::env::sname_key(prism_rtl::deref(w_p4).name)));
        })
            : prism_rtl::finished(called_p1);
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start SpotNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spot_names(Spot sp_p0) {
    return prism_rtl::make_rc<SpotNames>(sp_p0);
}


/// ?TraversalOf: fn (Text ==> Rel), Expr, [Arg] -> ?((Expr, Expr, Nat))
std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>> traversal_of(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& c_p1, const Array<crate::syntax::Arg>& args_p2) {
    auto&& _m = prism_rtl::deref(c_p1.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto name_p4 = crate::check::env::sname_key(n_p3);
        return crate::check::shrink::relations::pre_is(m_p0, name_p4, Text::lit("Fold")) && (len(args_p2) == Nat(3u))
            ? ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>> _v;
            auto&& _m = std::tuple{index(args_p2, Nat(0u)), index(args_p2, Nat(2u))};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& a_p5 = prism_rtl::some_of(std::get<0>(_m));
                auto&& s_p6 = prism_rtl::some_of(std::get<1>(_m));
                _v.set(std::optional(std::tuple{a_p5->value, s_p6->value, Nat(1u)}));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>{});
                goto _done;
            }
        _done:
            _v.take();
        })
            : (crate::check::shrink::relations::pre_is(m_p0, name_p4, Text::lit("Each")) || crate::check::shrink::relations::pre_is(m_p0, name_p4, Text::lit("Filter"))) && (len(args_p2) == Nat(2u))
            ? ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>> _v;
            auto&& _m = std::tuple{index(args_p2, Nat(0u)), index(args_p2, Nat(1u))};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& a_p7 = prism_rtl::some_of(std::get<0>(_m));
                auto&& s_p8 = prism_rtl::some_of(std::get<1>(_m));
                _v.set(std::optional(std::tuple{a_p7->value, s_p8->value, Nat(0u)}));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>{});
                goto _done;
            }
        _done:
            _v.take();
        })
            : std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>{};
    }
    {
        return std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>{};
    }
}


/// ?LastExpr: fn Block -> ?Expr
std::optional<crate::syntax::Expr> last_expr(const crate::syntax::Block& b_p0) {
    auto&& _m = crate::syntax::lexer::chars::last(b_p0.stmts);
    if (prism_rtl::is_some(_m)) {
        auto&& s_p1 = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::deref(s_p1).kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
            auto&& x_p2 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
            return std::optional(x_p2);
        }
        {
            return std::optional<crate::syntax::Expr>{};
        }
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<crate::syntax::Expr>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?RelOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
std::optional<crate::check::shrink::Rel> rel_of(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& e_p1) {
    auto&& _m = prism_rtl::deref(e_p1.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::prelude::get(m_p0, crate::check::env::sname_key(n_p2));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r_p3 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& _m = rel_of(m_p0, prism_rtl::deref(prism_rtl::deref(r_p3)));
        if (prism_rtl::is_some(_m)) {
            auto&& x_p4 = prism_rtl::some_of(_m);
            return std::optional(crate::check::shrink::Rel{.param = prism_rtl::deref(x_p4).param, .strict = true});
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::check::shrink::Rel>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r_p5 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        return rel_of(m_p0, prism_rtl::deref(prism_rtl::deref(r_p5)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p6 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return rel_of(m_p0, prism_rtl::deref(prism_rtl::deref(x_p6)));
    }
    {
        auto&& _m = call_of(e_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& c_p7 = std::get<0>(prism_rtl::some_of(_m));
            auto&& args_p8 = std::get<1>(prism_rtl::some_of(_m));
            return is_non_nat_min(m_p0, e_p1, c_p7)
                ? std::optional<crate::check::shrink::Rel>{}
                : rel_of_call(m_p0, c_p7, args_p8);
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::check::shrink::Rel>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<std::optional<crate::check::shrink::Rel>> RelOf::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& e_p1 = this->e_p1;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p1).kind);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p2 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        prism_rtl::finished(crate::prelude::get(m_p0, crate::check::env::sname_key(n_p2)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& r_p3 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        ({
        auto m_p0_1 = m_p0;
        auto r_p3_2 = prism_rtl::deref(prism_rtl::deref(r_p3));
        call_then(start_rel_of(m_p0_1, r_p3_2), [=](std::optional<crate::check::shrink::Rel> rel_of_18351) {
        return ({
            prism_rtl::is_some(rel_of_18351) ? ({
            auto&& x_p4 = prism_rtl::some_of(rel_of_18351);
            prism_rtl::finished(std::optional(crate::check::shrink::Rel{.param = prism_rtl::deref(x_p4).param, .strict = true}));
        })
            : prism_rtl::is_none(rel_of_18351) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& r_p5 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RelOf(m_p0, prism_rtl::deref(prism_rtl::deref(r_p5)))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p6 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RelOf(m_p0, prism_rtl::deref(prism_rtl::deref(x_p6)))));
    })
        : ({
        auto&& _m = call_of(e_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& c_p7 = std::get<0>(prism_rtl::some_of(_m));
        auto&& args_p8 = std::get<1>(prism_rtl::some_of(_m));
        is_non_nat_min(m_p0, e_p1, c_p7)
        ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
        : prism_rtl::more(prism_rtl::rc(RelOfCall(m_p0, c_p7, args_p8)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start RelOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>> start_rel_of(Map<Text, crate::check::shrink::Rel> m_p0, crate::syntax::Expr e_p1) {
    return prism_rtl::make_rc<RelOf>(m_p0, e_p1);
}


/// IsNonNatMin: fn (Text ==> Rel), Expr, Expr -> Bool
bool is_non_nat_min(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& e_p1, const crate::syntax::Expr& c_p2) {
    auto&& _m = callee_name(c_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& n_p3 = prism_rtl::some_of(_m);
        return crate::check::shrink::relations::pre_is(m_p0, n_p3, Text::lit("Min"))
            ? !is_nat_at(m_p0, e_p1)
            : false;
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsNatAt: fn (Text ==> Rel), Expr -> Bool
bool is_nat_at(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& e_p1) {
    auto&& _m = crate::prelude::get(m_p0, Text::lit("file:"));
    if (prism_rtl::is_some(_m)) {
        auto&& f_p2 = prism_rtl::some_of(_m);
        return crate::check::env::has_key(m_p0, prism_rtl::cat("nat:", prism_rtl::deref(f_p2).param, ":", prism_rtl::deref(e_p1.span).start, ":", prism_rtl::deref(e_p1.span).end));
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?RelOfCall: unbounded fn (Text ==> Rel), Expr, [Arg] -> ?Rel
std::optional<crate::check::shrink::Rel> rel_of_call(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& c_p1, const Array<crate::syntax::Arg>& args_p2) {
    auto&& _m = prism_rtl::deref(c_p1.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto name_p4 = crate::check::env::sname_key(n_p3);
        return (crate::check::shrink::relations::pre_is(m_p0, name_p4, Text::lit("Drop")) && (len(args_p2) == Nat(2u))) && crate::check::shrink::summaries::is_positive_lit(or_(index(args_p2, Nat(1u)), crate::check::shrink::summaries::dummy_arg())->value)
            ? ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::check::shrink::Rel>> _v;
            auto&& _m = index(args_p2, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& a_p5 = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<crate::check::shrink::Rel>> _v;
                    auto&& _m = rel_of(m_p0, a_p5->value);
                    if (prism_rtl::is_some(_m)) {
                        auto&& x_p6 = prism_rtl::some_of(_m);
                        _v.set(std::optional(crate::check::shrink::Rel{.param = prism_rtl::deref(x_p6).param, .strict = prism_rtl::deref(x_p6).strict || known_non_empty(m_p0, a_p5->value)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::optional<crate::check::shrink::Rel>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<crate::check::shrink::Rel>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        })
            : (crate::check::shrink::relations::pre_is(m_p0, name_p4, Text::lit("Values")) || crate::check::shrink::relations::pre_is(m_p0, name_p4, Text::lit("Keys"))) && (len(args_p2) == Nat(1u))
            ? rel_of(m_p0, or_(index(args_p2, Nat(0u)), crate::check::shrink::summaries::dummy_arg())->value)
            : ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::check::shrink::Rel>> _v;
            auto&& _m = no_larger_arg(m_p0, c_p1, args_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& a_p7 = prism_rtl::some_of(_m);
                _v.set(rel_of(m_p0, a_p7));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<crate::check::shrink::Rel>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    {
        return std::optional<crate::check::shrink::Rel>{};
    }
}


prism_rtl::Turn<std::optional<crate::check::shrink::Rel>> RelOfCall::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& c_p1 = this->c_p1;
    const auto& args_p2 = this->args_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(c_p1).kind);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto name_p4 = crate::check::env::sname_key(n_p3);
        (crate::check::shrink::relations::pre_is(m_p0, name_p4, Text::lit("Drop")) && (len(args_p2) == Nat(2u))) && crate::check::shrink::summaries::is_positive_lit(or_(index(args_p2, Nat(1u)), crate::check::shrink::summaries::dummy_arg())->value)
        ? ({
        auto&& _m = index(args_p2, Nat(0u));
        prism_rtl::is_some(_m) ? ({
        auto&& a_p5 = prism_rtl::some_of(_m);
        ({
        auto m_p0_1 = m_p0;
        call_then(start_rel_of(m_p0_1, a_p5->value), [=](std::optional<crate::check::shrink::Rel> rel_of_19508) {
        return ({
            prism_rtl::is_some(rel_of_19508) ? ({
            auto&& x_p6 = prism_rtl::some_of(rel_of_19508);
            prism_rtl::finished(std::optional(crate::check::shrink::Rel{.param = prism_rtl::deref(x_p6).param, .strict = prism_rtl::deref(x_p6).strict || known_non_empty(m_p0_1, a_p5->value)}));
        })
            : prism_rtl::is_none(rel_of_19508) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    })
        : (crate::check::shrink::relations::pre_is(m_p0, name_p4, Text::lit("Values")) || crate::check::shrink::relations::pre_is(m_p0, name_p4, Text::lit("Keys"))) && (len(args_p2) == Nat(1u))
        ? prism_rtl::more(prism_rtl::rc(RelOf(m_p0, or_(index(args_p2, Nat(0u)), crate::check::shrink::summaries::dummy_arg())->value)))
        : ({
        auto&& _m = no_larger_arg(m_p0, c_p1, args_p2);
        prism_rtl::is_some(_m) ? ({
        auto&& a_p7 = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(RelOf(m_p0, a_p7)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::finished(std::optional<crate::check::shrink::Rel>{});
    });
}


/// `Start RelOfCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>> start_rel_of_call(Map<Text, crate::check::shrink::Rel> m_p0, crate::syntax::Expr c_p1, Array<crate::syntax::Arg> args_p2) {
    return prism_rtl::make_rc<RelOfCall>(m_p0, c_p1, args_p2);
}


/// KnownNonEmpty: fn (Text ==> Rel), Expr -> Bool
bool known_non_empty(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& e_p1) {
    auto&& _m = crate::check::shrink::relations::name_of(e_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& n_p2 = prism_rtl::some_of(_m);
        return crate::check::env::has_key(m_p0, prism_rtl::cat("ne:", n_p2));
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?CallOf: fn Expr -> ?((Expr, [Arg]))
std::optional<std::tuple<crate::syntax::Expr, Array<crate::syntax::Arg>>> call_of(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_p1 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_p2 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return std::optional(std::tuple{prism_rtl::deref(prism_rtl::deref(c_p1)), args_p2});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& r_p3 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& n_p4 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args_p5 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return std::optional(std::tuple{method_callee(n_p4), method_args(prism_rtl::deref(prism_rtl::deref(r_p3)), args_p5)});
    }
    {
        return std::optional<std::tuple<crate::syntax::Expr, Array<crate::syntax::Arg>>>{};
    }
}


/// ?NoLargerArg: fn (Text ==> Rel), Expr, [Arg] -> ?Expr
std::optional<crate::syntax::Expr> no_larger_arg(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& c_p1, const Array<crate::syntax::Arg>& args_p2) {
    auto&& _m = callee_name(c_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& n_p3 = prism_rtl::some_of(_m);
        return crate::check::shrink::relations::is_local(m_p0, n_p3)
            ? std::optional<crate::syntax::Expr>{}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
            auto&& _m = crate::prelude::get(m_p0, prism_rtl::cat("fn:", n_p3));
            if (prism_rtl::is_some(_m)) {
                auto&& s_p4 = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                    auto&& _m = index(args_p2, prism_rtl::deref(s_p4).param);
                    if (prism_rtl::is_some(_m)) {
                        auto&& a_p5 = prism_rtl::some_of(_m);
                        _v.set(std::optional(a_p5->value));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::optional<crate::syntax::Expr>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<crate::syntax::Expr>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<crate::syntax::Expr>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsNoLargerPrelude: fn G, Text -> Bool
bool is_no_larger_prelude(const crate::check::env::G& g_p0, const Text& k_p1) {
    return crate::check::types::has_text(Array(std::vector{Text::lit("Prelude.Take"), Text::lit("Prelude.Drop"), Text::lit("Prelude.Filter"), Text::lit("Prelude.Remove"), Text::lit("Prelude.Min"), Text::lit("Prelude.@Flatten")}), k_p1) && crate::check::shrink::relations::is_prelude_key(g_p0, k_p1);
}

}  // namespace crate::check::shrink::walk
