// The module `Check.Shrink.Walk`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/shrink/walk/module.hpp>
#include <syntax/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Shrink.Walk`, from `target/bootstrap/cpp-src/prismc/check/shrink/walk.prism`.
namespace crate::check::shrink::walk {

bool Kid::KidExpr::operator==(const KidExpr& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Kid::KidStmts::operator==(const KidStmts& o) const { return a0 == o.a0 && a1 == o.a1; }

void Kid::show(Printer& p) const {
    if (auto c = std::get_if<KidExpr>(&cases())) p.choice("KidExpr", {c->a0, c->a1});
    else if (auto c = std::get_if<KidStmts>(&cases())) p.choice("KidStmts", {c->a0, c->a1});
}

Pod Kid::to_pod() const {
    return std::holds_alternative<KidExpr>(cases()) ? Pod::choice("KidExpr", {prism_rtl::to_pod(std::get<KidExpr>(cases()).a0), prism_rtl::to_pod(std::get<KidExpr>(cases()).a1)})
        : std::holds_alternative<KidStmts>(cases()) ? Pod::choice("KidStmts", {prism_rtl::to_pod(std::get<KidStmts>(cases()).a0), prism_rtl::to_pod(std::get<KidStmts>(cases()).a1)})
        : Pod();
}

Result<Kid> Kid::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "KidExpr" && c->args.size() == 2) return Kid(KidExpr{TRY(prism_rtl::from_pod<crate::syntax::Expr>(c->args[0])), TRY(prism_rtl::from_pod<Map<Text, crate::check::shrink::Rel>>(c->args[1]))});
        if (c->ctor == "KidStmts" && c->args.size() == 2) return Kid(KidStmts{TRY(prism_rtl::from_pod<Array<crate::syntax::Stmt>>(c->args[0])), TRY(prism_rtl::from_pod<Map<Text, crate::check::shrink::Rel>>(c->args[1]))});
    }
    return mismatch<Kid>("a Kid", p);
}


bool Site::operator==(const Site& o) const { return callee_p == o.callee_p && args_p == o.args_p && span_p == o.span_p && rels_p == o.rels_p; }

void Site::show(Printer& p) const {
    p.record("Site", {{"callee", callee_p}, {"args", args_p}, {"span", span_p}, {"rels", rels_p}});
}

Pod Site::to_pod() const {
    return Pod::record("Site", {{"callee", prism_rtl::to_pod(callee_p)}, {"args", prism_rtl::to_pod(args_p)}, {"span", prism_rtl::to_pod(span_p)}, {"rels", prism_rtl::to_pod(rels_p)}});
}

Result<Site> Site::from_pod(const Pod& whole) {
    return Site{.callee_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "callee")))), .args_p = TRY(prism_rtl::from_pod<Array<crate::syntax::Arg>>(TRY(crate::prelude::field(whole, "args")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .rels_p = TRY(prism_rtl::from_pod<Map<Text, crate::check::shrink::Rel>>(TRY(crate::prelude::field(whole, "rels"))))};
}


bool Spot::SpotExpr::operator==(const SpotExpr& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Spot::SpotStmt::operator==(const SpotStmt& o) const { return a0 == o.a0 && a1 == o.a1; }

void Spot::show(Printer& p) const {
    if (auto c = std::get_if<SpotExpr>(&cases())) p.choice("SpotExpr", {c->a0, c->a1});
    else if (auto c = std::get_if<SpotStmt>(&cases())) p.choice("SpotStmt", {c->a0, c->a1});
}

Pod Spot::to_pod() const {
    return std::holds_alternative<SpotExpr>(cases()) ? Pod::choice("SpotExpr", {prism_rtl::to_pod(std::get<SpotExpr>(cases()).a0), prism_rtl::to_pod(std::get<SpotExpr>(cases()).a1)})
        : std::holds_alternative<SpotStmt>(cases()) ? Pod::choice("SpotStmt", {prism_rtl::to_pod(std::get<SpotStmt>(cases()).a0), prism_rtl::to_pod(std::get<SpotStmt>(cases()).a1)})
        : Pod();
}

Result<Spot> Spot::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "SpotExpr" && c->args.size() == 2) return Spot(SpotExpr{TRY(prism_rtl::from_pod<crate::syntax::Expr>(c->args[0])), TRY(prism_rtl::from_pod<Map<Text, crate::check::shrink::Rel>>(c->args[1]))});
        if (c->ctor == "SpotStmt" && c->args.size() == 2) return Spot(SpotStmt{TRY(prism_rtl::from_pod<crate::syntax::Stmt>(c->args[0])), TRY(prism_rtl::from_pod<Map<Text, crate::check::shrink::Rel>>(c->args[1]))});
    }
    return mismatch<Spot>("a Spot", p);
}


/// ExprSpots: unbounded fn Expr, (Text ==> Rel) -> [Spot]
Array<Spot> expr_spots_f(const crate::syntax::Expr& e_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(expr_kids_f(e_p0, m_p1), Array(std::vector{Spot(Spot::SpotExpr{e_p0, m_p1})}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p2 = p0;
                auto k_p3 = p1;
                (crate::prelude::call_then(start_kid_spots_f(k_p3), [=, acc_p2 = std::move(acc_p2)](Array<Spot> kid_spots_f_2175) { return prism_rtl::finished(crate::prelude::append(acc_p2, kid_spots_f_2175)); }));
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Spot>> ExprSpots::cycle() const {
    const auto& e_p0 = this->e_p0;
    const auto& m_p1 = this->m_p1;
    auto e_p0x = e_p0;
    auto m_p1x = m_p1;
    return crate::prelude::call_then(start_expr_kids_f(e_p0x, m_p1x), [=](Array<Kid> expr_kids_f_2115) {
        return crate::prelude::fold_job(expr_kids_f_2115, Array(std::vector{Spot(Spot::SpotExpr{e_p0x, m_p1x})}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p2 = p0;
                    auto k_p3 = p1;
                    (crate::prelude::call_then(start_kid_spots_f(k_p3), [=, acc_p2 = std::move(acc_p2)](Array<Spot> kid_spots_f_2175) { return prism_rtl::finished(crate::prelude::append(acc_p2, kid_spots_f_2175)); }));
                });
            }));
        })))->cycle();
    });
}


/// `Start ExprSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_expr_spots_f(crate::syntax::Expr e_p0, Map<Text, crate::check::shrink::Rel> m_p1) {
    return prism_rtl::make_rc<ExprSpots>(e_p0, m_p1);
}


/// KidSpots: unbounded fn Kid -> [Spot]
Array<Spot> kid_spots_f(const Kid& kid0) {
    if (prism_rtl::is<Kid::KidExpr>(kid0)) {
        auto&& x_p0 = prism_rtl::as<Kid::KidExpr>(kid0).a0;
        auto&& m_p1 = prism_rtl::as<Kid::KidExpr>(kid0).a1;
        return expr_spots_f(x_p0, m_p1);
    }
    if (prism_rtl::is<Kid::KidStmts>(kid0)) {
        auto&& ss_p2 = prism_rtl::as<Kid::KidStmts>(kid0).a0;
        auto&& m_p3 = prism_rtl::as<Kid::KidStmts>(kid0).a1;
        return stmts_spots_f(ss_p2, m_p3);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Spot>> KidSpots::cycle() const {
    const auto& kid0 = this->kid0;
    return ({
        prism_rtl::is<Kid::KidExpr>(kid0) ? ({
        auto&& x_p0 = prism_rtl::as<Kid::KidExpr>(kid0).a0;
        auto&& m_p1 = prism_rtl::as<Kid::KidExpr>(kid0).a1;
        prism_rtl::more(prism_rtl::rc(ExprSpots(x_p0, m_p1)));
    })
        : prism_rtl::is<Kid::KidStmts>(kid0) ? ({
        auto&& ss_p2 = prism_rtl::as<Kid::KidStmts>(kid0).a0;
        auto&& m_p3 = prism_rtl::as<Kid::KidStmts>(kid0).a1;
        prism_rtl::more(prism_rtl::rc(StmtsSpots(ss_p2, m_p3)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start KidSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_kid_spots_f(Kid kid0) {
    return prism_rtl::make_rc<KidSpots>(kid0);
}


/// StmtsSpots: unbounded fn [Stmt], (Text ==> Rel) -> [Spot]
Array<Spot> stmts_spots_f(const Array<crate::syntax::Stmt>& stmts_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    auto bm_p2 = crate::check::shrink::relations::block_rels_f(stmts_p0, m_p1);
    return crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p0, Array<Spot>{}, ({
        auto bm_p2x = bm_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, crate::syntax::Stmt>)>>(prism_rtl::rc([=, bm_p2x = std::move(bm_p2x)](std::tuple<Array<Spot>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto bm_p2xy = bm_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, bm_p2xy = std::move(bm_p2xy)]() {
            return ({
                auto acc_p3 = p0;
                auto s_p4 = p1;
                (crate::prelude::call_then(start_stmt_spots_f(s_p4, bm_p2xy), [=, acc_p3 = std::move(acc_p3)](Array<Spot> stmt_spots_f_2562) { return prism_rtl::finished(crate::prelude::append(acc_p3, stmt_spots_f_2562)); }));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Spot>> StmtsSpots::cycle() const {
    const auto& stmts_p0 = this->stmts_p0;
    const auto& m_p1 = this->m_p1;
    auto m_p1x = m_p1;
    auto stmts_p0x = stmts_p0;
    return crate::prelude::call_then(crate::check::shrink::relations::start_block_rels_f(stmts_p0x, m_p1x), [=](Map<Text, crate::check::shrink::Rel> block_rels_f_2498) {
        return ({
            auto bm_p2 = block_rels_f_2498;
            (crate::prelude::fold_job(stmts_p0x, Array<Spot>{}, ({
            auto bm_p2x = bm_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, crate::syntax::Stmt>)>>(prism_rtl::rc([=, bm_p2x = std::move(bm_p2x)](std::tuple<Array<Spot>, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto bm_p2xy = bm_p2x;
                (crate::prelude::entered(crate::prelude::once_job([=, bm_p2xy = std::move(bm_p2xy)]() {
                return ({
                    auto acc_p3 = p0;
                    auto s_p4 = p1;
                    (crate::prelude::call_then(start_stmt_spots_f(s_p4, bm_p2xy), [=, acc_p3 = std::move(acc_p3)](Array<Spot> stmt_spots_f_2562) { return prism_rtl::finished(crate::prelude::append(acc_p3, stmt_spots_f_2562)); }));
                });
            })));
            });
        })));
        }))->cycle());
        });
    });
}


/// `Start StmtsSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_stmts_spots_f(Array<crate::syntax::Stmt> stmts_p0, Map<Text, crate::check::shrink::Rel> m_p1) {
    return prism_rtl::make_rc<StmtsSpots>(stmts_p0, m_p1);
}


/// StmtSpots: unbounded fn Stmt, (Text ==> Rel) -> [Spot]
Array<Spot> stmt_spots_f(const crate::syntax::Stmt& s_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(stmt_kids_f(s_p0, m_p1), Array(std::vector{Spot(Spot::SpotStmt{s_p0, m_p1})}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p2 = p0;
                auto k_p3 = p1;
                (crate::prelude::call_then(start_kid_spots_f(k_p3), [=, acc_p2 = std::move(acc_p2)](Array<Spot> kid_spots_f_2721) { return prism_rtl::finished(crate::prelude::append(acc_p2, kid_spots_f_2721)); }));
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Spot>> StmtSpots::cycle() const {
    const auto& s_p0 = this->s_p0;
    const auto& m_p1 = this->m_p1;
    auto m_p1x = m_p1;
    auto s_p0x = s_p0;
    return crate::prelude::call_then(start_stmt_kids_f(s_p0x, m_p1x), [=](Array<Kid> stmt_kids_f_2661) {
        return crate::prelude::fold_job(stmt_kids_f_2661, Array(std::vector{Spot(Spot::SpotStmt{s_p0x, m_p1x})}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p2 = p0;
                    auto k_p3 = p1;
                    (crate::prelude::call_then(start_kid_spots_f(k_p3), [=, acc_p2 = std::move(acc_p2)](Array<Spot> kid_spots_f_2721) { return prism_rtl::finished(crate::prelude::append(acc_p2, kid_spots_f_2721)); }));
                });
            }));
        })))->cycle();
    });
}


/// `Start StmtSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_stmt_spots_f(crate::syntax::Stmt s_p0, Map<Text, crate::check::shrink::Rel> m_p1) {
    return prism_rtl::make_rc<StmtSpots>(s_p0, m_p1);
}


/// BodySpots: unbounded fn FnBody, (Text ==> Rel) -> [Spot]
Array<Spot> body_spots_f(const crate::syntax::decls::FnBody& fn_body0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body0)) {
        auto&& e_p0 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body0).a0;
        return expr_spots_f(e_p0, m_p1);
    }
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body0)) {
        auto&& b_p2 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body0).a0;
        return stmts_spots_f(prism_rtl::deref(b_p2).stmts_p, m_p1);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Spot>> BodySpots::cycle() const {
    const auto& fn_body0 = this->fn_body0;
    const auto& m_p1 = this->m_p1;
    return ({
        prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body0) ? ({
        auto&& e_p0 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body0).a0;
        prism_rtl::more(prism_rtl::rc(ExprSpots(e_p0, m_p1)));
    })
        : prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body0) ? ({
        auto&& b_p2 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body0).a0;
        prism_rtl::more(prism_rtl::rc(StmtsSpots(prism_rtl::deref(b_p2).stmts_p, m_p1)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BodySpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_body_spots_f(crate::syntax::decls::FnBody fn_body0, Map<Text, crate::check::shrink::Rel> m_p1) {
    return prism_rtl::make_rc<BodySpots>(fn_body0, m_p1);
}


/// ExprKids: unbounded fn Expr, (Text ==> Rel) -> [Kid]
Array<Kid> expr_kids_f(const crate::syntax::Expr& e_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    auto&& _m = prism_rtl::deref(e_p0.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_p2 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_p3 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return call_kids_f(prism_rtl::deref(prism_rtl::deref(c_p2)), args_p3, m_p1);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& r_p4 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& n_p5 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args_p6 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return call_kids_f(method_callee_f(n_p5), method_args_f(prism_rtl::deref(prism_rtl::deref(r_p4)), args_p6), m_p1);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& l_p7 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_p8 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return exprs_kids_f(Array(std::vector{prism_rtl::deref(prism_rtl::deref(l_p7)), prism_rtl::deref(prism_rtl::deref(r_p8))}), m_p1);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(_m)) {
        auto&& l_p9 = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a2;
        auto&& r_pa = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a3;
        return exprs_kids_f(Array(std::vector{prism_rtl::deref(prism_rtl::deref(l_p9)), prism_rtl::deref(prism_rtl::deref(r_pa))}), m_p1);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r_pb = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i_pc = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return exprs_kids_f(Array(std::vector{prism_rtl::deref(prism_rtl::deref(r_pb)), prism_rtl::deref(prism_rtl::deref(i_pc))}), m_p1);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& x_pd = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pd)), m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& x_pe = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pe)), m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r_pf = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(r_pf)), m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
        auto&& x_pg = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pg)), m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_ph = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_ph)), m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& x_pi = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pi)), m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
        auto&& x_pj = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pj)), m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(_m)) {
        auto&& x_pk = prism_rtl::as<crate::syntax::ExprKind::ENonEmpty>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pk)), m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
        auto&& x_pl = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pl)), m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es_pm = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        return exprs_kids_f(es_pm, m_p1);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& es_pn = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        return exprs_kids_f(es_pn, m_p1);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& kvs_po = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        return crate::prelude::fold(kvs_po, Array<Kid>{}, [&](const Array<Kid>& acc_pp, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) {
            auto&& k_pq = std::get<0>(_p1);
            auto&& v_pr = std::get<1>(_p1);
            return crate::prelude::append(acc_pp, exprs_kids_f(Array(std::vector{k_pq, v_pr}), m_p1));
        });
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l_ps = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        auto&& _m = prism_rtl::deref(l_ps).kind_p;
        if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
            auto&& segs_pt = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
            return crate::prelude::fold(segs_pt, Array<Kid>{}, [&](const Array<Kid>& acc_pu, const crate::syntax::TextSeg& sg_pv) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Kid>> _v;
                    if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg_pv)) {
                        auto&& x_p10 = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg_pv).a0;
                        _v.set(crate::prelude::push(acc_pu, Kid(Kid::KidExpr{x_p10, m_p1})));
                        goto _done;
                    }
                    {
                        _v.set(acc_pu);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
        }
        {
            return Array<Kid>{};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        auto&& ps_o11 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body_p12 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        return Array(std::vector{lambda_kid_f(prism_rtl::deref(prism_rtl::deref(body_p12)), later_f(crate::check::shrink::relations::hide_f(m_p1, patterns_names_f(crate::prelude::or_(ps_o11, Array<crate::syntax::Pattern_>{})))))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c_p13 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& t_p14 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& el_o15 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        auto with_then_p16 = crate::prelude::push(cond_kids_f(prism_rtl::deref(prism_rtl::deref(c_p13)), m_p1), Kid(Kid::KidStmts{prism_rtl::deref(t_p14).stmts_p, crate::check::shrink::relations::cond_rels_f(prism_rtl::deref(prism_rtl::deref(c_p13)), m_p1)}));
        if (prism_rtl::is_some(el_o15)) {
            auto&& b_p17 = prism_rtl::some_of(el_o15);
            return crate::prelude::push(with_then_p16, Kid(Kid::KidStmts{prism_rtl::deref(b_p17).stmts_p, m_p1}));
        }
        if (prism_rtl::is_none(el_o15)) {
            return with_then_p16;
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& s_p18 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p19 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(arms_p19, Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(s_p18)), m_p1})}), ({
            auto s_p18x = prism_rtl::deref(prism_rtl::deref(s_p18));
            auto m_p1x = m_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, crate::syntax::Arm>)>>(prism_rtl::rc([=, s_p18x = std::move(s_p18x), m_p1x = std::move(m_p1x)](std::tuple<Array<Kid>, crate::syntax::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto s_p18xy = s_p18x;
                auto m_p1xy = m_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, s_p18xy = std::move(s_p18xy), m_p1xy = std::move(m_p1xy)]() {
                return ({
                    auto acc_p1a = p0;
                    auto a_p1b = p1;
                    (crate::prelude::call_then(crate::check::shrink::relations::start_arm_pat_rels_f(s_p18xy, a_p1b, m_p1xy), [=, acc_p1a = std::move(acc_p1a)](Map<Text, crate::check::shrink::Rel> arm_pat_rels_f_4324) {
                    return ({
                        auto am_p1c = arm_pat_rels_f_4324;
                        (prism_rtl::finished(crate::prelude::push(crate::prelude::append(acc_p1a, opt_kids_f(prism_rtl::deref(a_p1b).guard_o, am_p1c)), Kid(Kid::KidStmts{prism_rtl::deref(prism_rtl::deref(a_p1b).body_p).stmts_p, am_p1c}))));
                    });
                }));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
        auto&& s_p1d = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& b_p1e = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(s_p1d)), m_p1}), Kid(Kid::KidStmts{prism_rtl::deref(b_p1e).stmts_p, later_f(m_p1)})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
        auto&& s_p1f = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& b_p1g = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(s_p1f)), m_p1}), Kid(Kid::KidStmts{prism_rtl::deref(b_p1g).stmts_p, m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m)) {
        auto&& s_p1h = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a0;
        auto&& b_p1i = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(s_p1h)), m_p1}), Kid(Kid::KidStmts{prism_rtl::deref(b_p1i).stmts_p, m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
        auto&& fb_o1j = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& s_p1k = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& b_p1l = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        auto names_p1m = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is_some(fb_o1j)) {
                auto&& fb_p1o = prism_rtl::some_of(fb_o1j);
                _v.set(crate::check::types::union_texts_f(crate::check::env::names::pattern_names_f(prism_rtl::deref(fb_p1o).first_p), crate::check::shrink::summaries::opt_names_f(prism_rtl::deref(fb_p1o).second_o)));
                goto _done;
            }
            if (prism_rtl::is_none(fb_o1j)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto in_body_p1n = ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
            if (prism_rtl::is_some(fb_o1j)) {
                auto&& fb_p1p = prism_rtl::some_of(fb_o1j);
                _v.set(({
                    auto with_first_p1q = crate::check::shrink::relations::bind_rels_f(prism_rtl::deref(fb_p1p).first_p, part_of_f(prism_rtl::deref(prism_rtl::deref(s_p1k))), crate::check::shrink::relations::hide_f(m_p1, names_p1m), false);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
                    auto&& _m = prism_rtl::deref(fb_p1p).second_o;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p2_p1r = prism_rtl::some_of(_m);
                        _v.set(crate::check::shrink::relations::bind_rels_f(p2_p1r, part_of_f(prism_rtl::deref(prism_rtl::deref(s_p1k))), with_first_p1q, false));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(with_first_p1q);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(fb_o1j)) {
                _v.set(crate::check::shrink::relations::hide_f(m_p1, names_p1m));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(s_p1k)), m_p1}), Kid(Kid::KidStmts{prism_rtl::deref(b_p1l).stmts_p, in_body_p1n})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
        auto&& b_p1s = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        return Array(std::vector{Kid(Kid::KidStmts{prism_rtl::deref(b_p1s).stmts_p, m_p1})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        auto&& b_p1t = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        return Array(std::vector{Kid(Kid::KidStmts{prism_rtl::deref(b_p1t).stmts_p, later_f(m_p1)})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m)) {
        auto&& t_p1u = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        return template_kids_f(prism_rtl::deref(t_p1u).parts_p, m_p1);
    }
    {
        return Array<Kid>{};
    }
}


prism_rtl::Turn<Array<Kid>> ExprKids::cycle() const {
    const auto& e_p0 = this->e_p0;
    const auto& m_p1 = this->m_p1;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p0).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& c_p2 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_p3 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        prism_rtl::more(prism_rtl::rc(CallKids(prism_rtl::deref(prism_rtl::deref(c_p2)), args_p3, m_p1)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m) ? ({
        auto&& r_p4 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& n_p5 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args_p6 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        prism_rtl::more(prism_rtl::rc(CallKids(method_callee_f(n_p5), method_args_f(prism_rtl::deref(prism_rtl::deref(r_p4)), args_p6), m_p1)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) ? ({
        auto&& l_p7 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_p8 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        prism_rtl::finished(exprs_kids_f(Array(std::vector{prism_rtl::deref(prism_rtl::deref(l_p7)), prism_rtl::deref(prism_rtl::deref(r_p8))}), m_p1));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(_m) ? ({
        auto&& l_p9 = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a2;
        auto&& r_pa = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a3;
        prism_rtl::finished(exprs_kids_f(Array(std::vector{prism_rtl::deref(prism_rtl::deref(l_p9)), prism_rtl::deref(prism_rtl::deref(r_pa))}), m_p1));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& r_pb = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i_pc = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        prism_rtl::finished(exprs_kids_f(Array(std::vector{prism_rtl::deref(prism_rtl::deref(r_pb)), prism_rtl::deref(prism_rtl::deref(i_pc))}), m_p1));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) ? ({
        auto&& x_pd = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pd)), m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) ? ({
        auto&& x_pe = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pe)), m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& r_pf = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(r_pf)), m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m) ? ({
        auto&& x_pg = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pg)), m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_ph = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_ph)), m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m) ? ({
        auto&& x_pi = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pi)), m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECast>(_m) ? ({
        auto&& x_pj = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pj)), m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(_m) ? ({
        auto&& x_pk = prism_rtl::as<crate::syntax::ExprKind::ENonEmpty>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pk)), m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EAny>(_m) ? ({
        auto&& x_pl = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_pl)), m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m) ? ({
        auto&& es_pm = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        prism_rtl::finished(exprs_kids_f(es_pm, m_p1));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) ? ({
        auto&& es_pn = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        prism_rtl::finished(exprs_kids_f(es_pn, m_p1));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMap>(_m) ? ({
        auto&& kvs_po = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        prism_rtl::finished(crate::prelude::fold(kvs_po, Array<Kid>{}, [&](const Array<Kid>& acc_pp, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) {
        auto&& k_pq = std::get<0>(_p1);
        auto&& v_pr = std::get<1>(_p1);
        return crate::prelude::append(acc_pp, exprs_kids_f(Array(std::vector{k_pq, v_pr}), m_p1));
    }));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
        auto&& l_ps = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        ({
        auto&& _m = prism_rtl::deref(l_ps).kind_p;
        prism_rtl::is<crate::syntax::LitKind::LText>(_m) ? ({
        auto&& segs_pt = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
        prism_rtl::finished(crate::prelude::fold(segs_pt, Array<Kid>{}, [&](const Array<Kid>& acc_pu, const crate::syntax::TextSeg& sg_pv) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Kid>> _v;
            if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg_pv)) {
                auto&& x_p10 = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg_pv).a0;
                _v.set(crate::prelude::push(acc_pu, Kid(Kid::KidExpr{x_p10, m_p1})));
                goto _done;
            }
            {
                _v.set(acc_pu);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
    })
        : prism_rtl::finished(Array<Kid>{});
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto&& ps_o11 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body_p12 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto ps_o11x = ps_o11;
        auto body_p12x = prism_rtl::deref(prism_rtl::deref(body_p12));
        auto m_p1x = m_p1;
        (crate::prelude::call_then(start_patterns_names_f(crate::prelude::or_(ps_o11x, Array<crate::syntax::Pattern_>{})), [=, body_p12x = std::move(body_p12x), m_p1x = std::move(m_p1x)](Array<Text> patterns_names_f_4012) { return prism_rtl::finished(Array(std::vector{lambda_kid_f(body_p12x, later_f(crate::check::shrink::relations::hide_f(m_p1x, patterns_names_f_4012)))})); }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c_p13 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& t_p14 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& el_o15 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        ({
        auto el_o15x = el_o15;
        auto c_p13x = prism_rtl::deref(prism_rtl::deref(c_p13));
        auto m_p1x = m_p1;
        auto t_p14x = t_p14;
        (crate::prelude::call_then(start_cond_kids_f(c_p13x, m_p1x), [=, el_o15x = std::move(el_o15x), t_p14x = std::move(t_p14x)](Array<Kid> cond_kids_f_4095) {
        return crate::prelude::call_then(crate::check::shrink::relations::start_cond_rels_f(c_p13x, m_p1x), [=](Map<Text, crate::check::shrink::Rel> cond_rels_f_4131) {
            return ({
                auto with_then_p16 = crate::prelude::push(cond_kids_f_4095, Kid(Kid::KidStmts{prism_rtl::deref(t_p14x).stmts_p, cond_rels_f_4131}));
                ({
                prism_rtl::is_some(el_o15x) ? ({
                auto&& b_p17 = prism_rtl::some_of(el_o15x);
                prism_rtl::finished(crate::prelude::push(with_then_p16, Kid(Kid::KidStmts{prism_rtl::deref(b_p17).stmts_p, m_p1x})));
            })
                : prism_rtl::is_none(el_o15x) ? prism_rtl::finished(with_then_p16)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& s_p18 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p19 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        crate::prelude::fold_job(arms_p19, Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(s_p18)), m_p1})}), ({
        auto s_p18x = prism_rtl::deref(prism_rtl::deref(s_p18));
        auto m_p1x = m_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, crate::syntax::Arm>)>>(prism_rtl::rc([=, s_p18x = std::move(s_p18x), m_p1x = std::move(m_p1x)](std::tuple<Array<Kid>, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto s_p18xy = s_p18x;
            auto m_p1xy = m_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, s_p18xy = std::move(s_p18xy), m_p1xy = std::move(m_p1xy)]() {
            return ({
                auto acc_p1a = p0;
                auto a_p1b = p1;
                (crate::prelude::call_then(crate::check::shrink::relations::start_arm_pat_rels_f(s_p18xy, a_p1b, m_p1xy), [=, acc_p1a = std::move(acc_p1a)](Map<Text, crate::check::shrink::Rel> arm_pat_rels_f_4324) {
                return ({
                    auto am_p1c = arm_pat_rels_f_4324;
                    (prism_rtl::finished(crate::prelude::push(crate::prelude::append(acc_p1a, opt_kids_f(prism_rtl::deref(a_p1b).guard_o, am_p1c)), Kid(Kid::KidStmts{prism_rtl::deref(prism_rtl::deref(a_p1b).body_p).stmts_p, am_p1c}))));
                });
            }));
            });
        })));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m) ? ({
        auto&& s_p1d = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& b_p1e = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(s_p1d)), m_p1}), Kid(Kid::KidStmts{prism_rtl::deref(b_p1e).stmts_p, later_f(m_p1)})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m) ? ({
        auto&& s_p1f = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& b_p1g = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(s_p1f)), m_p1}), Kid(Kid::KidStmts{prism_rtl::deref(b_p1g).stmts_p, m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m) ? ({
        auto&& s_p1h = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a0;
        auto&& b_p1i = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(s_p1h)), m_p1}), Kid(Kid::KidStmts{prism_rtl::deref(b_p1i).stmts_p, m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& fb_o1j = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& s_p1k = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& b_p1l = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        ({
        auto names_p1m = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is_some(fb_o1j)) {
                auto&& fb_p1o = prism_rtl::some_of(fb_o1j);
                _v.set(crate::check::types::union_texts_f(crate::check::env::names::pattern_names_f(prism_rtl::deref(fb_p1o).first_p), crate::check::shrink::summaries::opt_names_f(prism_rtl::deref(fb_p1o).second_o)));
                goto _done;
            }
            if (prism_rtl::is_none(fb_o1j)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto in_body_p1n = ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
            if (prism_rtl::is_some(fb_o1j)) {
                auto&& fb_p1p = prism_rtl::some_of(fb_o1j);
                _v.set(({
                    auto with_first_p1q = crate::check::shrink::relations::bind_rels_f(prism_rtl::deref(fb_p1p).first_p, part_of_f(prism_rtl::deref(prism_rtl::deref(s_p1k))), crate::check::shrink::relations::hide_f(m_p1, names_p1m), false);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
                    auto&& _m = prism_rtl::deref(fb_p1p).second_o;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p2_p1r = prism_rtl::some_of(_m);
                        _v.set(crate::check::shrink::relations::bind_rels_f(p2_p1r, part_of_f(prism_rtl::deref(prism_rtl::deref(s_p1k))), with_first_p1q, false));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(with_first_p1q);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(fb_o1j)) {
                _v.set(crate::check::shrink::relations::hide_f(m_p1, names_p1m));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(s_p1k)), m_p1}), Kid(Kid::KidStmts{prism_rtl::deref(b_p1l).stmts_p, in_body_p1n})})));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m) ? ({
        auto&& b_p1s = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidStmts{prism_rtl::deref(b_p1s).stmts_p, m_p1})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m) ? ({
        auto&& b_p1t = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidStmts{prism_rtl::deref(b_p1t).stmts_p, later_f(m_p1)})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m) ? ({
        auto&& t_p1u = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TemplateKids(prism_rtl::deref(t_p1u).parts_p, m_p1)));
    })
        : prism_rtl::finished(Array<Kid>{});
    });
}


/// `Start ExprKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_expr_kids_f(crate::syntax::Expr e_p0, Map<Text, crate::check::shrink::Rel> m_p1) {
    return prism_rtl::make_rc<ExprKids>(e_p0, m_p1);
}


/// StmtKids: unbounded fn Stmt, (Text ==> Rel) -> [Kid]
Array<Kid> stmt_kids_f(const crate::syntax::Stmt& s_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    auto&& _m = s_p0.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
        auto&& e_p2 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& t_o3 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2;
        return crate::prelude::append(Array(std::vector{Kid(Kid::KidExpr{e_p2, m_p1})}), opt_kids_f(t_o3, m_p1));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m)) {
        auto&& e_p4 = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{e_p4, m_p1})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& e_p5 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        return Array(std::vector{Kid(Kid::KidExpr{e_p5, m_p1})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f_p6 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return Array(std::vector{body_kid_f(prism_rtl::deref(f_p6).body_p, later_f(crate::check::shrink::relations::hide_f(m_p1, patterns_names_f(prism_rtl::deref(f_p6).params_p))))});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        auto&& w_p7 = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        return Array(std::vector{Kid(Kid::KidStmts{prism_rtl::deref(prism_rtl::deref(w_p7).body_p).stmts_p, later_f(m_p1)})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
        auto&& t_p8 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& v_p9 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        return exprs_kids_f(Array(std::vector{t_p8, v_p9}), m_p1);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
        auto&& t_pa = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& v_pb = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        return exprs_kids_f(Array(std::vector{t_pa, v_pb}), m_p1);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m)) {
        auto&& c_pc = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{c_pc, m_p1})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m)) {
        auto&& c_pd = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{c_pd, m_p1})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SReturn>(_m)) {
        auto&& e_pe = prism_rtl::as<crate::syntax::StmtKind::SReturn>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{e_pe, m_p1})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& c_pf = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& b_pg = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        return crate::prelude::push(cond_kids_f(c_pf, m_p1), Kid(Kid::KidStmts{prism_rtl::deref(b_pg).stmts_p, crate::check::shrink::relations::cond_rels_f(c_pf, m_p1)}));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e_ph = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{e_ph, m_p1})});
    }
    {
        return Array<Kid>{};
    }
}


prism_rtl::Turn<Array<Kid>> StmtKids::cycle() const {
    const auto& s_p0 = this->s_p0;
    const auto& m_p1 = this->m_p1;
    return ({
        auto&& _m = prism_rtl::deref(s_p0).kind_p;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
        auto&& e_p2 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& t_o3 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2;
        prism_rtl::finished(crate::prelude::append(Array(std::vector{Kid(Kid::KidExpr{e_p2, m_p1})}), opt_kids_f(t_o3, m_p1)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m) ? ({
        auto&& e_p4 = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e_p4, m_p1})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& e_p5 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e_p5, m_p1})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f_p6 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        ({
        auto f_p6x = f_p6;
        auto m_p1x = m_p1;
        (crate::prelude::call_then(start_patterns_names_f(prism_rtl::deref(f_p6x).params_p), [=, m_p1x = std::move(m_p1x)](Array<Text> patterns_names_f_5759) { return prism_rtl::finished(Array(std::vector{body_kid_f(prism_rtl::deref(f_p6x).body_p, later_f(crate::check::shrink::relations::hide_f(m_p1x, patterns_names_f_5759)))})); }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
        auto&& w_p7 = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidStmts{prism_rtl::deref(prism_rtl::deref(w_p7).body_p).stmts_p, later_f(m_p1)})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& t_p8 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& v_p9 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        prism_rtl::finished(exprs_kids_f(Array(std::vector{t_p8, v_p9}), m_p1));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& t_pa = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& v_pb = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        prism_rtl::finished(exprs_kids_f(Array(std::vector{t_pa, v_pb}), m_p1));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m) ? ({
        auto&& c_pc = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{c_pc, m_p1})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m) ? ({
        auto&& c_pd = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{c_pd, m_p1})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SReturn>(_m) ? ({
        auto&& e_pe = prism_rtl::as<crate::syntax::StmtKind::SReturn>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e_pe, m_p1})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
        auto&& c_pf = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& b_pg = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        ({
        auto b_pgx = b_pg;
        auto c_pfx = c_pf;
        auto m_p1x = m_p1;
        (crate::prelude::call_then(start_cond_kids_f(c_pfx, m_p1x), [=, b_pgx = std::move(b_pgx)](Array<Kid> cond_kids_f_6052) { return crate::prelude::call_then(crate::check::shrink::relations::start_cond_rels_f(c_pfx, m_p1x), [=](Map<Text, crate::check::shrink::Rel> cond_rels_f_6088) { return prism_rtl::finished(crate::prelude::push(cond_kids_f_6052, Kid(Kid::KidStmts{prism_rtl::deref(b_pgx).stmts_p, cond_rels_f_6088}))); }); }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& e_ph = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e_ph, m_p1})}));
    })
        : prism_rtl::finished(Array<Kid>{});
    });
}


/// `Start StmtKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_stmt_kids_f(crate::syntax::Stmt s_p0, Map<Text, crate::check::shrink::Rel> m_p1) {
    return prism_rtl::make_rc<StmtKids>(s_p0, m_p1);
}


/// CondKids: unbounded fn Cond, (Text ==> Rel) -> [Kid]
Array<Kid> cond_kids_f(const crate::syntax::Cond& c_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p0)) {
        auto&& x_p2 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p0).a0;
        return Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_p2)), m_p1})});
    }
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(c_p0)) {
        auto&& x_p3 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p0).a1;
        auto&& g_o4 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p0).a2;
        return crate::prelude::append(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_p3)), m_p1})}), opt_kids_f(prism_rtl::deref(prism_rtl::deref(g_o4)), crate::check::shrink::relations::cond_rels_f(c_p0, m_p1)));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Kid>> CondKids::cycle() const {
    const auto& c_p0 = this->c_p0;
    const auto& m_p1 = this->m_p1;
    return ({
        prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p0) ? ({
        auto&& x_p2 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p0).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_p2)), m_p1})}));
    })
        : prism_rtl::is<crate::syntax::Cond::CondBind>(c_p0) ? ({
        auto&& x_p3 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p0).a1;
        auto&& g_o4 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p0).a2;
        ({
        auto g_o4x = prism_rtl::deref(prism_rtl::deref(g_o4));
        auto c_p0x = c_p0;
        auto m_p1x = m_p1;
        auto x_p3x = prism_rtl::deref(prism_rtl::deref(x_p3));
        (crate::prelude::call_then(crate::check::shrink::relations::start_cond_rels_f(c_p0x, m_p1x), [=, g_o4x = std::move(g_o4x), x_p3x = std::move(x_p3x)](Map<Text, crate::check::shrink::Rel> cond_rels_f_6428) { return prism_rtl::finished(crate::prelude::append(Array(std::vector{Kid(Kid::KidExpr{x_p3x, m_p1x})}), opt_kids_f(g_o4x, cond_rels_f_6428))); }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_cond_kids_f(crate::syntax::Cond c_p0, Map<Text, crate::check::shrink::Rel> m_p1) {
    return prism_rtl::make_rc<CondKids>(c_p0, m_p1);
}


/// CallKids: unbounded fn Expr, [Arg], (Text ==> Rel) -> [Kid]
Array<Kid> call_kids_f(const crate::syntax::Expr& c_p0, const Array<crate::syntax::Arg>& args_p1, const Map<Text, crate::check::shrink::Rel>& m_p2) {
    auto callee_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        auto&& _m = callee_name_o(c_p0);
        if (prism_rtl::is_some(_m)) {
            _v.set(Array<Kid>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array(std::vector{Kid(Kid::KidExpr{c_p0, m_p2})}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _m = traversal_of_o(m_p2, c_p0, args_p1);
    if (prism_rtl::is_none(_m)) {
        auto&& _m = acc_callee_o(m_p2, c_p0, args_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& cn_p4 = prism_rtl::some_of(_m);
            return crate::prelude::append(callee_p3, crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(args_p1)), Array<Kid>{}, ({
                auto m_p2x = m_p2;
                auto cn_p4x = cn_p4;
                auto args_p1x = args_p1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, Nat>)>>(prism_rtl::rc([=, m_p2x = std::move(m_p2x), cn_p4x = std::move(cn_p4x), args_p1x = std::move(args_p1x)](std::tuple<Array<Kid>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_p2xy = m_p2x;
                    auto cn_p4xy = cn_p4x;
                    auto args_p1xy = args_p1x;
                    (crate::prelude::entered(crate::prelude::once_job([=, m_p2xy = std::move(m_p2xy), cn_p4xy = std::move(cn_p4xy), args_p1xy = std::move(args_p1xy)]() {
                    return ({
                        auto acc_p5 = p0;
                        auto i_p6 = p1;
                        (crate::prelude::call_then(start_acc_kids_f(m_p2xy, cn_p4xy, args_p1xy, i_p6), [=, acc_p5 = std::move(acc_p5)](Array<Kid> acc_kids_f_7288) { return prism_rtl::finished(crate::prelude::append(acc_p5, acc_kids_f_7288)); }));
                    });
                })));
                });
            })));
            }))));
        }
        if (prism_rtl::is_none(_m)) {
            return crate::prelude::append(callee_p3, exprs_kids_f(crate::prelude::each(args_p1, [&](const crate::syntax::Arg& a_p7) { return prism_rtl::deref(a_p7).value_p; }), m_p2));
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_some(_m)) {
        auto&& coll_p8 = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_p9 = std::get<1>(prism_rtl::some_of(_m));
        auto&& at_pa = std::get<2>(prism_rtl::some_of(_m));
        auto others_pb = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(args_p1)), callee_p3, [&](const Array<Kid>& acc_pc, const Nat& i_pd) {
            return i_pd == (at_pa + Nat(1u))
                ? acc_pc
                : ({
                __label__ _done;
                prism_rtl::Slot<Array<Kid>> _v;
                auto&& _m = crate::prelude::index(args_p1, i_pd);
                if (prism_rtl::is_some(_m)) {
                    auto&& a_pe = prism_rtl::some_of(_m);
                    _v.set(crate::prelude::push(acc_pc, Kid(Kid::KidExpr{prism_rtl::deref(a_pe).value_p, m_p2})));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(acc_pc);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
        auto&& _m = prism_rtl::deref(prism_rtl::deref(step_p9).kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
            auto&& ps_pf = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
            auto&& body_pg = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            return crate::prelude::push(others_pb, lambda_kid_f(prism_rtl::deref(prism_rtl::deref(body_pg)), crate::check::shrink::relations::step_rels_f(m_p2, coll_p8, ps_pf, at_pa)));
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            return others_pb;
        }
        {
            return crate::prelude::push(others_pb, Kid(Kid::KidExpr{step_p9, m_p2}));
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Kid>> CallKids::cycle() const {
    const auto& c_p0 = this->c_p0;
    const auto& args_p1 = this->args_p1;
    const auto& m_p2 = this->m_p2;
    auto callee_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        auto&& _m = callee_name_o(c_p0);
        if (prism_rtl::is_some(_m)) {
            _v.set(Array<Kid>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array(std::vector{Kid(Kid::KidExpr{c_p0, m_p2})}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        auto&& _m = traversal_of_o(m_p2, c_p0, args_p1);
        prism_rtl::is_none(_m) ? ({
        auto&& _m = acc_callee_o(m_p2, c_p0, args_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& cn_p4 = prism_rtl::some_of(_m);
        ({
        auto args_p1x = args_p1;
        auto m_p2x = m_p2;
        (crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(args_p1x)), Array<Kid>{}, ({
        auto m_p2xx = m_p2x;
        auto cn_p4x = cn_p4;
        auto args_p1xx = args_p1x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, Nat>)>>(prism_rtl::rc([=, m_p2xx = std::move(m_p2xx), cn_p4x = std::move(cn_p4x), args_p1xx = std::move(args_p1xx)](std::tuple<Array<Kid>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_p2xxy = m_p2xx;
            auto cn_p4xy = cn_p4x;
            auto args_p1xxy = args_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, m_p2xxy = std::move(m_p2xxy), cn_p4xy = std::move(cn_p4xy), args_p1xxy = std::move(args_p1xxy)]() {
            return ({
                auto acc_p5 = p0;
                auto i_p6 = p1;
                (crate::prelude::call_then(start_acc_kids_f(m_p2xxy, cn_p4xy, args_p1xxy, i_p6), [=, acc_p5 = std::move(acc_p5)](Array<Kid> acc_kids_f_7288) { return prism_rtl::finished(crate::prelude::append(acc_p5, acc_kids_f_7288)); }));
            });
        })));
        });
    })));
    })), [=](Array<Kid> fold_7233) { return prism_rtl::finished(crate::prelude::append(callee_p3, fold_7233)); }));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::prelude::append(callee_p3, exprs_kids_f(crate::prelude::each(args_p1, [&](const crate::syntax::Arg& a_p7) { return prism_rtl::deref(a_p7).value_p; }), m_p2)))
        : throw prism_rtl::Panic("no arm matched");
    })
        : prism_rtl::is_some(_m) ? ({
        auto&& coll_p8 = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_p9 = std::get<1>(prism_rtl::some_of(_m));
        auto&& at_pa = std::get<2>(prism_rtl::some_of(_m));
        ({
        auto others_pb = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(args_p1)), callee_p3, [&](const Array<Kid>& acc_pc, const Nat& i_pd) {
            return i_pd == (at_pa + Nat(1u))
                ? acc_pc
                : ({
                __label__ _done;
                prism_rtl::Slot<Array<Kid>> _v;
                auto&& _m = crate::prelude::index(args_p1, i_pd);
                if (prism_rtl::is_some(_m)) {
                    auto&& a_pe = prism_rtl::some_of(_m);
                    _v.set(crate::prelude::push(acc_pc, Kid(Kid::KidExpr{prism_rtl::deref(a_pe).value_p, m_p2})));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(acc_pc);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(step_p9).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0) ? ({
        auto&& ps_pf = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
        auto&& body_pg = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto body_pgx = prism_rtl::deref(prism_rtl::deref(body_pg));
        auto m_p2x = m_p2;
        auto ps_pfx = ps_pf;
        (crate::prelude::call_then(crate::check::shrink::relations::start_step_rels_f(m_p2x, coll_p8, ps_pfx, at_pa), [=, body_pgx = std::move(body_pgx)](Map<Text, crate::check::shrink::Rel> step_rels_f_7701) { return prism_rtl::finished(crate::prelude::push(others_pb, lambda_kid_f(body_pgx, step_rels_f_7701))); }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? prism_rtl::finished(others_pb)
        : prism_rtl::finished(crate::prelude::push(others_pb, Kid(Kid::KidExpr{step_p9, m_p2})));
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_call_kids_f(crate::syntax::Expr c_p0, Array<crate::syntax::Arg> args_p1, Map<Text, crate::check::shrink::Rel> m_p2) {
    return prism_rtl::make_rc<CallKids>(c_p0, args_p1, m_p2);
}


/// Later: fn (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> later_f(const Map<Text, crate::check::shrink::Rel>& m_p0) {
    return crate::prelude::insert(m_p0, Text::lit("lam:"), crate::check::shrink::relations::no_rel_p());
}


/// ?AccCallee: fn (Text ==> Rel), Expr, [Arg] -> ?Text
std::optional<Text> acc_callee_o(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& c_p1, const Array<crate::syntax::Arg>& args_p2) {
    auto&& _m = callee_name_o(c_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& cn_p3 = prism_rtl::some_of(_m);
        return crate::check::shrink::relations::is_local_f(m_p0, cn_p3)
            ? std::optional<Text>{}
            : !crate::prelude::fold(args_p2, true, [&](const bool& ok_p4, const crate::syntax::Arg& a_p5) { return prism_rtl::deref(ok_p4) && (prism_rtl::deref(a_p5).name_o == std::optional<crate::syntax::Ident>{}); })
            ? std::optional<Text>{}
            : crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(args_p2)), false, [&](const bool& seen_p6, const Nat& i_p7) { return prism_rtl::deref(seen_p6) || crate::check::env::has_key_f(m_p0, prism_rtl::cat("acc:", cn_p3, ":", i_p7)); })
            ? std::optional(cn_p3)
            : std::optional<Text>{};
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// AccKids: unbounded fn (Text ==> Rel), Text, [Arg], Nat -> [Kid]
Array<Kid> acc_kids_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Text& cn_p1, const Array<crate::syntax::Arg>& args_p2, const Nat& i_p3) {
    auto a_p4 = crate::prelude::or_(crate::prelude::index(args_p2, i_p3), crate::check::shrink::summaries::dummy_arg_p());
    return !crate::check::env::has_key_f(m_p0, prism_rtl::cat("acc:", cn_p1, ":", i_p3))
        ? Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(a_p4).value_p, m_p0})})
        : ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(a_p4).value_p).kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
            auto&& ps_o5 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
            auto&& body_p6 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(Array(std::vector{lambda_kid_f(prism_rtl::deref(prism_rtl::deref(body_p6)), acc_lambda_rels_f(m_p0, cn_p1, i_p3, crate::prelude::or_(ps_o5, Array<crate::syntax::Pattern_>{}), args_p2))}));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            _v.set(Array<Kid>{});
            goto _done;
        }
        {
            _v.set(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(a_p4).value_p, m_p0})}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Kid>> AccKids::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& cn_p1 = this->cn_p1;
    const auto& args_p2 = this->args_p2;
    const auto& i_p3 = this->i_p3;
    auto a_p4 = crate::prelude::or_(crate::prelude::index(args_p2, i_p3), crate::check::shrink::summaries::dummy_arg_p());
    return !crate::check::env::has_key_f(m_p0, prism_rtl::cat("acc:", cn_p1, ":", i_p3))
        ? prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(a_p4).value_p, m_p0})}))
        : ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(a_p4).value_p).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto&& ps_o5 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body_p6 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        prism_rtl::finished(Array(std::vector{lambda_kid_f(prism_rtl::deref(prism_rtl::deref(body_p6)), acc_lambda_rels_f(m_p0, cn_p1, i_p3, crate::prelude::or_(ps_o5, Array<crate::syntax::Pattern_>{}), args_p2))}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? prism_rtl::finished(Array<Kid>{})
        : prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{prism_rtl::deref(a_p4).value_p, m_p0})}));
    });
}


/// `Start AccKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_acc_kids_f(Map<Text, crate::check::shrink::Rel> m_p0, Text cn_p1, Array<crate::syntax::Arg> args_p2, Nat i_p3) {
    return prism_rtl::make_rc<AccKids>(m_p0, cn_p1, args_p2, i_p3);
}


/// AccLambdaRels: unbounded fn (Text ==> Rel), Text, Nat, [Pattern], [Arg] -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> acc_lambda_rels_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Text& cn_p1, const Nat& j_p2, const Array<crate::syntax::Pattern_>& ps_p3, const Array<crate::syntax::Arg>& args_p4) {
    auto h_p5 = crate::check::shrink::relations::hide_f(m_p0, patterns_names_f(ps_p3));
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(ps_p3)), h_p5, ({
        auto m_p0x = m_p0;
        auto cn_p1x = cn_p1;
        auto j_p2x = j_p2;
        auto ps_p3x = ps_p3;
        auto args_p4x = args_p4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Nat>)>>(prism_rtl::rc([=, m_p0x = std::move(m_p0x), cn_p1x = std::move(cn_p1x), j_p2x = std::move(j_p2x), ps_p3x = std::move(ps_p3x), args_p4x = std::move(args_p4x)](std::tuple<Map<Text, crate::check::shrink::Rel>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_p0xy = m_p0x;
            auto cn_p1xy = cn_p1x;
            auto j_p2xy = j_p2x;
            auto ps_p3xy = ps_p3x;
            auto args_p4xy = args_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, m_p0xy = std::move(m_p0xy), cn_p1xy = std::move(cn_p1xy), j_p2xy = std::move(j_p2xy), ps_p3xy = std::move(ps_p3xy), args_p4xy = std::move(args_p4xy)]() {
            return ({
                auto m2_p6 = p0;
                auto q_p7 = p1;
                ({
                auto&& _m = std::tuple{crate::prelude::get(m_p0xy, prism_rtl::cat("sum:", cn_p1xy, ":", j_p2xy, ":", q_p7)), crate::prelude::index(ps_p3xy, q_p7)};
                prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m)) ? ({
                auto&& s_p8 = prism_rtl::some_of(std::get<0>(_m));
                auto&& p_p9 = prism_rtl::some_of(std::get<1>(_m));
                prism_rtl::deref(s_p8).param_p == top_param_p()
                ? prism_rtl::finished(m2_p6)
                : ({
                auto&& _m = crate::prelude::index(args_p4xy, prism_rtl::deref(s_p8).param_p);
                prism_rtl::is_some(_m) ? ({
                auto&& a_pa = prism_rtl::some_of(_m);
                crate::prelude::call_then(start_rel_of_o(m_p0xy, prism_rtl::deref(a_pa).value_p), [=](std::optional<crate::check::shrink::Rel> rel_of_o_9689) {
                return ({
                    prism_rtl::is_some(rel_of_o_9689) ? ({
                    auto&& r_pb = prism_rtl::some_of(rel_of_o_9689);
                    ({
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p9).kind_p);
                    prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                    auto&& n_pc = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                    prism_rtl::finished(crate::prelude::insert(m2_p6, crate::check::env::sname_key_f(n_pc), crate::check::shrink::Rel{.param_p = prism_rtl::deref(r_pb).param_p, .strict_p = prism_rtl::deref(r_pb).strict_p || prism_rtl::deref(s_p8).strict_p}));
                })
                    : crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p9), [=](Array<Text> pattern_names_f_9884) { return prism_rtl::finished(crate::prelude::fold(pattern_names_f_9884, m2_p6, [&](const Map<Text, crate::check::shrink::Rel>& m3_pd, const Text& n_pe) { return crate::prelude::insert(m3_pd, n_pe, crate::check::shrink::Rel{.param_p = prism_rtl::deref(r_pb).param_p, .strict_p = true}); })); });
                });
                })
                    : prism_rtl::is_none(rel_of_o_9689) ? prism_rtl::finished(m2_p6)
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m2_p6)
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : prism_rtl::finished(m2_p6);
            });
            });
        })));
        });
    }));
    })));
}


/// let topParam
Nat top_param_p() {
    return Nat(9999u);
}


/// TemplateKids: unbounded fn [TemplatePart], (Text ==> Rel) -> [Kid]
Array<Kid> template_kids_f(const Array<crate::syntax::TemplatePart>& parts_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    return crate::prelude::fold(parts_p0, Array<Kid>{}, [&](const Array<Kid>& acc_p2, const crate::syntax::TemplatePart& p_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Kid>> _v;
            if (prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(p_p3)) {
                auto&& x_p4 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(p_p3).a0;
                _v.set(crate::prelude::push(acc_p2, Kid(Kid::KidExpr{x_p4, m_p1})));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(p_p3)) {
                auto&& b_p5 = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(p_p3).a0;
                _v.set(crate::prelude::push(acc_p2, Kid(Kid::KidStmts{prism_rtl::deref(b_p5).stmts_p, m_p1})));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::TemplatePart::TpCall>(p_p3)) {
                auto&& n_p6 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p3).a0;
                auto&& args_p7 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p3).a1;
                auto&& ps_o8 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p3).a2;
                auto&& span_p9 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p3).a3;
                _v.set(crate::prelude::push(acc_p2, Kid(Kid::KidExpr{template_call_expr_f(n_p6, args_p7, ps_o8, span_p9), m_p1})));
                goto _done;
            }
            {
                _v.set(acc_p2);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Kid>> TemplateKids::cycle() const {
    const auto& parts_p0 = this->parts_p0;
    const auto& m_p1 = this->m_p1;
    return prism_rtl::finished(crate::prelude::fold(parts_p0, Array<Kid>{}, [&](const Array<Kid>& acc_p2, const crate::syntax::TemplatePart& p_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Kid>> _v;
            if (prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(p_p3)) {
                auto&& x_p4 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(p_p3).a0;
                _v.set(crate::prelude::push(acc_p2, Kid(Kid::KidExpr{x_p4, m_p1})));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(p_p3)) {
                auto&& b_p5 = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(p_p3).a0;
                _v.set(crate::prelude::push(acc_p2, Kid(Kid::KidStmts{prism_rtl::deref(b_p5).stmts_p, m_p1})));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::TemplatePart::TpCall>(p_p3)) {
                auto&& n_p6 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p3).a0;
                auto&& args_p7 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p3).a1;
                auto&& ps_o8 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p3).a2;
                auto&& span_p9 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p3).a3;
                _v.set(crate::prelude::push(acc_p2, Kid(Kid::KidExpr{template_call_expr_f(n_p6, args_p7, ps_o8, span_p9), m_p1})));
                goto _done;
            }
            {
                _v.set(acc_p2);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start TemplateKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_template_kids_f(Array<crate::syntax::TemplatePart> parts_p0, Map<Text, crate::check::shrink::Rel> m_p1) {
    return prism_rtl::make_rc<TemplateKids>(parts_p0, m_p1);
}


/// TemplateCallExpr: fn SName, [Arg], ?[TemplatePart], Range -> Expr
crate::syntax::Expr template_call_expr_f(const crate::syntax::SName& n_p0, const Array<crate::syntax::Arg>& args_p1, const std::optional<Array<crate::syntax::TemplatePart>>& ps_o2, const crate::syntax::Range& span_p3) {
    auto body_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Arg>> _v;
        if (prism_rtl::is_some(ps_o2)) {
            auto&& ps_p5 = prism_rtl::some_of(ps_o2);
            _v.set(Array(std::vector{crate::syntax::Arg{.name_o = std::optional(crate::syntax::Ident{.name_p = Text::lit("#body"), .span_p = span_p3}), .value_p = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETemplate{crate::syntax::Template{.keyword_p = Text::lit("InlineText"), .lang_p = Text::lit(""), .delims_p = Text::lit("double"), .parts_p = ps_p5, .span_p = span_p3}})), .span_p = span_p3}, .span_p = span_p3}}));
            goto _done;
        }
        if (prism_rtl::is_none(ps_o2)) {
            _v.set(Array<crate::syntax::Arg>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{n_p0})), .span_p = n_p0.span_p}), crate::prelude::append(args_p1, body_p4), false, false})), .span_p = span_p3};
}


/// ArgOf: fn Expr -> Arg
crate::syntax::Arg arg_of_f(const crate::syntax::Expr& x_p0) {
    return crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = x_p0, .span_p = x_p0.span_p};
}


/// ExprsKids: fn [Expr], (Text ==> Rel) -> [Kid]
Array<Kid> exprs_kids_f(const Array<crate::syntax::Expr>& xs_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    return crate::prelude::each(xs_p0, [&](const crate::syntax::Expr& x_p2) { return Kid(Kid::KidExpr{x_p2, m_p1}); });
}


/// OptKids: fn ?Expr, (Text ==> Rel) -> [Kid]
Array<Kid> opt_kids_f(const std::optional<crate::syntax::Expr>& opt0, const Map<Text, crate::check::shrink::Rel>& map1) {
    auto&& _m = std::tuple{opt0, map1};
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& x_p0 = prism_rtl::some_of(std::get<0>(_m));
        auto&& m_p1 = std::get<1>(_m);
        return Array(std::vector{Kid(Kid::KidExpr{x_p0, m_p1})});
    }
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Array<Kid>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// LambdaKid: fn LambdaBody, (Text ==> Rel) -> Kid
Kid lambda_kid_f(const crate::syntax::LambdaBody& lambda_body0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body0)) {
        auto&& x_p0 = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body0).a0;
        return Kid(Kid::KidExpr{prism_rtl::deref(prism_rtl::deref(x_p0)), m_p1});
    }
    if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body0)) {
        auto&& b_p2 = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body0).a0;
        return Kid(Kid::KidStmts{prism_rtl::deref(b_p2).stmts_p, m_p1});
    }
    prism_rtl::unreachable("no arm matched");
}


/// BodyKid: fn FnBody, (Text ==> Rel) -> Kid
Kid body_kid_f(const crate::syntax::decls::FnBody& fn_body0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body0)) {
        auto&& x_p0 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body0).a0;
        return Kid(Kid::KidExpr{x_p0, m_p1});
    }
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body0)) {
        auto&& b_p2 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body0).a0;
        return Kid(Kid::KidStmts{prism_rtl::deref(b_p2).stmts_p, m_p1});
    }
    prism_rtl::unreachable("no arm matched");
}


/// PatternsNames: unbounded fn [Pattern] -> [Text]
Array<Text> patterns_names_f(const Array<crate::syntax::Pattern_>& ps_p0) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(ps_p0, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto a_p1 = p0;
                auto p_p2 = p1;
                (crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p2), [=, a_p1 = std::move(a_p1)](Array<Text> pattern_names_f_11843) { return prism_rtl::finished(crate::check::types::union_texts_f(a_p1, pattern_names_f_11843)); }));
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> PatternsNames::cycle() const {
    const auto& ps_p0 = this->ps_p0;
    return crate::prelude::fold_job(ps_p0, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto a_p1 = p0;
                auto p_p2 = p1;
                (crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p2), [=, a_p1 = std::move(a_p1)](Array<Text> pattern_names_f_11843) { return prism_rtl::finished(crate::check::types::union_texts_f(a_p1, pattern_names_f_11843)); }));
            });
        }));
    })))->cycle();
}


/// `Start PatternsNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_patterns_names_f(Array<crate::syntax::Pattern_> ps_p0) {
    return prism_rtl::make_rc<PatternsNames>(ps_p0);
}


/// ?CalleeName: fn Expr -> ?Text
std::optional<Text> callee_name_o(const crate::syntax::Expr& c_p0) {
    auto&& _m = prism_rtl::deref(c_p0.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return std::optional(crate::check::env::sname_key_f(n_p1));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& t_p2 = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p2).kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return std::optional(crate::check::env::sname_key_f(n_p3));
        }
        {
            return std::optional<Text>{};
        }
    }
    {
        return std::optional<Text>{};
    }
}


/// MethodCallee: fn SName -> Expr
crate::syntax::Expr method_callee_f(const crate::syntax::SName& n_p0) {
    return crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{n_p0})), .span_p = n_p0.span_p};
}


/// MethodArgs: fn Expr, [Arg] -> [Arg]
Array<crate::syntax::Arg> method_args_f(const crate::syntax::Expr& r_p0, const Array<crate::syntax::Arg>& args_p1) {
    return crate::prelude::append(Array(std::vector{crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = r_p0, .span_p = r_p0.span_p}}), args_p1);
}


/// BodySites: unbounded fn FnBody, (Text ==> Rel) -> [Site]
Array<Site> body_sites_f(const crate::syntax::decls::FnBody& body_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(body_spots_f(body_p0, m_p1), Array<Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p2 = p0;
                auto sp_p3 = p1;
                (crate::prelude::call_then(start_spot_sites_f(sp_p3), [=, acc_p2 = std::move(acc_p2)](Array<Site> spot_sites_f_12800) { return prism_rtl::finished(crate::prelude::append(acc_p2, spot_sites_f_12800)); }));
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Site>> BodySites::cycle() const {
    const auto& body_p0 = this->body_p0;
    const auto& m_p1 = this->m_p1;
    auto body_p0x = body_p0;
    auto m_p1x = m_p1;
    return crate::prelude::call_then(start_body_spots_f(body_p0x, m_p1x), [=](Array<Spot> body_spots_f_12750) {
        return crate::prelude::fold_job(body_spots_f_12750, Array<Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p2 = p0;
                    auto sp_p3 = p1;
                    (crate::prelude::call_then(start_spot_sites_f(sp_p3), [=, acc_p2 = std::move(acc_p2)](Array<Site> spot_sites_f_12800) { return prism_rtl::finished(crate::prelude::append(acc_p2, spot_sites_f_12800)); }));
                });
            }));
        })))->cycle();
    });
}


/// `Start BodySites, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Site>> start_body_sites_f(crate::syntax::decls::FnBody body_p0, Map<Text, crate::check::shrink::Rel> m_p1) {
    return prism_rtl::make_rc<BodySites>(body_p0, m_p1);
}


/// SpotSites: unbounded fn Spot -> [Site]
Array<Site> spot_sites_f(const Spot& spot0) {
    if (prism_rtl::is<Spot::SpotStmt>(spot0)) {
        return Array<Site>{};
    }
    if (prism_rtl::is<Spot::SpotExpr>(spot0)) {
        auto&& e_p0 = prism_rtl::as<Spot::SpotExpr>(spot0).a0;
        auto&& m_p1 = prism_rtl::as<Spot::SpotExpr>(spot0).a1;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p0).kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_p2 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return Array(std::vector{Site{.callee_p = crate::check::env::sname_key_f(n_p2), .args_p = Array<crate::syntax::Arg>{}, .span_p = prism_rtl::deref(e_p0).span_p, .rels_p = m_p1}});
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c_p3 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args_p4 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            return call_sites_f(prism_rtl::deref(prism_rtl::deref(c_p3)), args_p4, prism_rtl::deref(e_p0).span_p, m_p1);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
            auto&& r_p5 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
            auto&& n_p6 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
            auto&& args_p7 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
            return call_sites_f(method_callee_f(n_p6), method_args_f(prism_rtl::deref(prism_rtl::deref(r_p5)), args_p7), prism_rtl::deref(e_p0).span_p, m_p1);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
            auto&& op_p8 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l_p9 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r_pa = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            return is_called_op_f(op_p8)
                ? Array(std::vector{Site{.callee_p = op_p8, .args_p = Array(std::vector{arg_of_f(prism_rtl::deref(prism_rtl::deref(l_p9))), arg_of_f(prism_rtl::deref(prism_rtl::deref(r_pa)))}), .span_p = prism_rtl::deref(e_p0).span_p, .rels_p = m_p1}})
                : Array<Site>{};
        }
        {
            return Array<Site>{};
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Site>> SpotSites::cycle() const {
    const auto& spot0 = this->spot0;
    return ({
        prism_rtl::is<Spot::SpotStmt>(spot0) ? prism_rtl::finished(Array<Site>{})
        : prism_rtl::is<Spot::SpotExpr>(spot0) ? ({
        auto&& e_p0 = prism_rtl::as<Spot::SpotExpr>(spot0).a0;
        auto&& m_p1 = prism_rtl::as<Spot::SpotExpr>(spot0).a1;
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p0).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p2 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        prism_rtl::finished(Array(std::vector{Site{.callee_p = crate::check::env::sname_key_f(n_p2), .args_p = Array<crate::syntax::Arg>{}, .span_p = prism_rtl::deref(e_p0).span_p, .rels_p = m_p1}}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& c_p3 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_p4 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        prism_rtl::more(prism_rtl::rc(CallSites(prism_rtl::deref(prism_rtl::deref(c_p3)), args_p4, prism_rtl::deref(e_p0).span_p, m_p1)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m) ? ({
        auto&& r_p5 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& n_p6 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args_p7 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        prism_rtl::more(prism_rtl::rc(CallSites(method_callee_f(n_p6), method_args_f(prism_rtl::deref(prism_rtl::deref(r_p5)), args_p7), prism_rtl::deref(e_p0).span_p, m_p1)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) ? ({
        auto&& op_p8 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l_p9 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_pa = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        is_called_op_f(op_p8)
        ? prism_rtl::finished(Array(std::vector{Site{.callee_p = op_p8, .args_p = Array(std::vector{arg_of_f(prism_rtl::deref(prism_rtl::deref(l_p9))), arg_of_f(prism_rtl::deref(prism_rtl::deref(r_pa)))}), .span_p = prism_rtl::deref(e_p0).span_p, .rels_p = m_p1}}))
        : prism_rtl::finished(Array<Site>{});
    })
        : prism_rtl::finished(Array<Site>{});
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotSites, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Site>> start_spot_sites_f(Spot spot0) {
    return prism_rtl::make_rc<SpotSites>(spot0);
}


/// IsCalledOp: fn Text -> Bool
bool is_called_op_f(const Text& op_p0) {
    return !crate::check::types::has_text_f(Array(std::vector{Text::lit("and"), Text::lit("or"), Text::lit("on"), Text::lit("<|"), Text::lit("mod")}), op_p0);
}


/// CallSites: unbounded fn Expr, [Arg], Range, (Text ==> Rel) -> [Site]
Array<Site> call_sites_f(const crate::syntax::Expr& c_p0, const Array<crate::syntax::Arg>& args_p1, const crate::syntax::Range& span_p2, const Map<Text, crate::check::shrink::Rel>& m_p3) {
    auto direct_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Array<Site>> _v;
        auto&& _m = callee_name_o(c_p0);
        if (prism_rtl::is_some(_m)) {
            auto&& n_p5 = prism_rtl::some_of(_m);
            _v.set(Array(std::vector{Site{.callee_p = n_p5, .args_p = args_p1, .span_p = span_p2, .rels_p = m_p3}}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Site>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _m = traversal_of_o(m_p3, c_p0, args_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& coll_p6 = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_p7 = std::get<1>(prism_rtl::some_of(_m));
        auto&& at_p8 = std::get<2>(prism_rtl::some_of(_m));
        auto&& _m = prism_rtl::deref(prism_rtl::deref(step_p7).kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_p9 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            auto call_args_pa = at_p8 == Nat(1u)
                ? Array(std::vector{crate::prelude::or_(crate::prelude::index(args_p1, Nat(1u)), crate::check::shrink::summaries::dummy_arg_p()), arg_of_f(part_of_f(coll_p6))})
                : Array(std::vector{arg_of_f(part_of_f(coll_p6))});
            return crate::prelude::push(direct_p4, Site{.callee_p = crate::check::env::sname_key_f(n_p9), .args_p = call_args_pa, .span_p = prism_rtl::deref(step_p7).span_p, .rels_p = m_p3});
        }
        {
            return direct_p4;
        }
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = acc_callee_o(m_p3, c_p0, args_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& cn_pb = prism_rtl::some_of(_m);
            return crate::prelude::append(direct_p4, acc_sites_f(m_p3, cn_pb, args_p1));
        }
        if (prism_rtl::is_none(_m)) {
            return direct_p4;
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Site>> CallSites::cycle() const {
    const auto& c_p0 = this->c_p0;
    const auto& args_p1 = this->args_p1;
    const auto& span_p2 = this->span_p2;
    const auto& m_p3 = this->m_p3;
    auto direct_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Array<Site>> _v;
        auto&& _m = callee_name_o(c_p0);
        if (prism_rtl::is_some(_m)) {
            auto&& n_p5 = prism_rtl::some_of(_m);
            _v.set(Array(std::vector{Site{.callee_p = n_p5, .args_p = args_p1, .span_p = span_p2, .rels_p = m_p3}}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Site>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        auto&& _m = traversal_of_o(m_p3, c_p0, args_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& coll_p6 = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_p7 = std::get<1>(prism_rtl::some_of(_m));
        auto&& at_p8 = std::get<2>(prism_rtl::some_of(_m));
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(step_p7).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p9 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto call_args_pa = at_p8 == Nat(1u)
            ? Array(std::vector{crate::prelude::or_(crate::prelude::index(args_p1, Nat(1u)), crate::check::shrink::summaries::dummy_arg_p()), arg_of_f(part_of_f(coll_p6))})
            : Array(std::vector{arg_of_f(part_of_f(coll_p6))});
        (prism_rtl::finished(crate::prelude::push(direct_p4, Site{.callee_p = crate::check::env::sname_key_f(n_p9), .args_p = call_args_pa, .span_p = prism_rtl::deref(step_p7).span_p, .rels_p = m_p3})));
    });
    })
        : prism_rtl::finished(direct_p4);
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = acc_callee_o(m_p3, c_p0, args_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& cn_pb = prism_rtl::some_of(_m);
        prism_rtl::finished(crate::prelude::append(direct_p4, acc_sites_f(m_p3, cn_pb, args_p1)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(direct_p4)
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallSites, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Site>> start_call_sites_f(crate::syntax::Expr c_p0, Array<crate::syntax::Arg> args_p1, crate::syntax::Range span_p2, Map<Text, crate::check::shrink::Rel> m_p3) {
    return prism_rtl::make_rc<CallSites>(c_p0, args_p1, span_p2, m_p3);
}


/// PartOf: fn Expr -> Expr
crate::syntax::Expr part_of_f(const crate::syntax::Expr& x_p0) {
    return crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(x_p0), Text::lit(""), crate::syntax::Ident{.name_p = Text::lit("element"), .span_p = x_p0.span_p}})), .span_p = x_p0.span_p};
}


/// AccSites: fn (Text ==> Rel), Text, [Arg] -> [Site]
Array<Site> acc_sites_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Text& cn_p1, const Array<crate::syntax::Arg>& args_p2) {
    return crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(args_p2)), Array<Site>{}, [&](const Array<Site>& acc_p3, const Nat& j_p4) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Site>> _v;
            auto&& _m = std::tuple{crate::prelude::get(m_p0, prism_rtl::cat("acc:", cn_p1, ":", j_p4)), crate::prelude::index(args_p2, j_p4)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& ar_p5 = prism_rtl::some_of(std::get<0>(_m));
                auto&& a_p6 = prism_rtl::some_of(std::get<1>(_m));
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Site>> _v;
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(a_p6).value_p).kind_p);
                    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                        auto&& f_p7 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                        _v.set(crate::prelude::push(acc_p3, Site{.callee_p = crate::check::env::sname_key_f(f_p7), .args_p = crate::prelude::each(crate::check::errors::range0_f(prism_rtl::deref(ar_p5).param_p), [&](const Nat& q_p8) { return acc_arg_f(m_p0, cn_p1, j_p4, q_p8, args_p2); }), .span_p = prism_rtl::deref(prism_rtl::deref(a_p6).value_p).span_p, .rels_p = m_p0}));
                        goto _done;
                    }
                    {
                        _v.set(acc_p3);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc_p3);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// AccArg: fn (Text ==> Rel), Text, Nat, Nat, [Arg] -> Arg
crate::syntax::Arg acc_arg_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Text& cn_p1, const Nat& j_p2, const Nat& q_p3, const Array<crate::syntax::Arg>& args_p4) {
    auto&& _m = crate::prelude::get(m_p0, prism_rtl::cat("sum:", cn_p1, ":", j_p2, ":", q_p3));
    if (prism_rtl::is_some(_m)) {
        auto&& s_p5 = prism_rtl::some_of(_m);
        return prism_rtl::deref(s_p5).param_p == top_param_p()
            ? arg_of_f(top_expr_p())
            : ({
            __label__ _done;
            prism_rtl::Slot<crate::syntax::Arg> _v;
            auto&& _m = crate::prelude::index(args_p4, prism_rtl::deref(s_p5).param_p);
            if (prism_rtl::is_some(_m)) {
                auto&& a_p6 = prism_rtl::some_of(_m);
                _v.set(arg_of_f(prism_rtl::deref(s_p5).strict_p
                    ? part_of_f(prism_rtl::deref(a_p6).value_p)
                    : prism_rtl::deref(a_p6).value_p));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::check::shrink::summaries::dummy_arg_p());
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return crate::check::shrink::summaries::dummy_arg_p();
    }
    prism_rtl::unreachable("no arm matched");
}


/// let topExpr
crate::syntax::Expr top_expr_p() {
    return crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{crate::syntax::SName{.sigils_p = Text::lit(""), .path_p = Array(std::vector{Text::lit("⊤")}), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}}})), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}};
}


/// SpotsNames: unbounded fn [Spot] -> [Text]
Array<Text> spots_names_f(const Array<Spot>& spots_p0) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(spots_p0, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p1 = p0;
                auto sp_p2 = p1;
                (crate::prelude::call_then(start_spot_names_f(sp_p2), [=, acc_p1 = std::move(acc_p1)](Array<Text> spot_names_f_16141) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p1, spot_names_f_16141)); }));
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> SpotsNames::cycle() const {
    const auto& spots_p0 = this->spots_p0;
    return crate::prelude::fold_job(spots_p0, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p1 = p0;
                auto sp_p2 = p1;
                (crate::prelude::call_then(start_spot_names_f(sp_p2), [=, acc_p1 = std::move(acc_p1)](Array<Text> spot_names_f_16141) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p1, spot_names_f_16141)); }));
            });
        }));
    })))->cycle();
}


/// `Start SpotsNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spots_names_f(Array<Spot> spots_p0) {
    return prism_rtl::make_rc<SpotsNames>(spots_p0);
}


/// SpotNames: unbounded fn Spot -> [Text]
Array<Text> spot_names_f(const Spot& sp_p0) {
    auto called_p1 = crate::prelude::each(spot_sites_f(sp_p0), [&](const Site& s_p2) { return prism_rtl::deref(s_p2).callee_p; });
    if (prism_rtl::is<Spot::SpotExpr>(sp_p0)) {
        return called_p1;
    }
    if (prism_rtl::is<Spot::SpotStmt>(sp_p0)) {
        auto&& s_p3 = prism_rtl::as<Spot::SpotStmt>(sp_p0).a0;
        auto&& _m = prism_rtl::deref(s_p3).kind_p;
        if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
            auto&& w_p4 = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
            return crate::check::types::add_text_f(called_p1, crate::check::env::sname_key_f(prism_rtl::deref(w_p4).name_p));
        }
        {
            return called_p1;
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> SpotNames::cycle() const {
    const auto& sp_p0 = this->sp_p0;
    auto sp_p0x = sp_p0;
    return crate::prelude::call_then(start_spot_sites_f(sp_p0x), [=](Array<Site> spot_sites_f_16235) {
        return ({
            auto called_p1 = crate::prelude::each(spot_sites_f_16235, [&](const Site& s_p2) { return prism_rtl::deref(s_p2).callee_p; });
            ({
            prism_rtl::is<Spot::SpotExpr>(sp_p0x) ? prism_rtl::finished(called_p1)
            : prism_rtl::is<Spot::SpotStmt>(sp_p0x) ? ({
            auto&& s_p3 = prism_rtl::as<Spot::SpotStmt>(sp_p0x).a0;
            ({
            auto&& _m = prism_rtl::deref(s_p3).kind_p;
            prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
            auto&& w_p4 = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
            prism_rtl::finished(crate::check::types::add_text_f(called_p1, crate::check::env::sname_key_f(prism_rtl::deref(w_p4).name_p)));
        })
            : prism_rtl::finished(called_p1);
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start SpotNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spot_names_f(Spot sp_p0) {
    return prism_rtl::make_rc<SpotNames>(sp_p0);
}


/// ?TraversalOf: fn (Text ==> Rel), Expr, [Arg] -> ?((Expr, Expr, Nat))
std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>> traversal_of_o(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& c_p1, const Array<crate::syntax::Arg>& args_p2) {
    auto&& _m = prism_rtl::deref(c_p1.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto name_p4 = crate::check::env::sname_key_f(n_p3);
        return crate::check::shrink::relations::pre_is_f(m_p0, name_p4, Text::lit("Fold")) && (crate::prelude::len(args_p2) == Nat(3u))
            ? ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>> _v;
            auto&& _m = std::tuple{crate::prelude::index(args_p2, Nat(0u)), crate::prelude::index(args_p2, Nat(2u))};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& a_p5 = prism_rtl::some_of(std::get<0>(_m));
                auto&& s_p6 = prism_rtl::some_of(std::get<1>(_m));
                _v.set(std::optional(std::tuple{prism_rtl::deref(a_p5).value_p, prism_rtl::deref(s_p6).value_p, Nat(1u)}));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>{});
                goto _done;
            }
        _done:
            _v.take();
        })
            : (crate::check::shrink::relations::pre_is_f(m_p0, name_p4, Text::lit("Each")) || crate::check::shrink::relations::pre_is_f(m_p0, name_p4, Text::lit("Filter"))) && (crate::prelude::len(args_p2) == Nat(2u))
            ? ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>> _v;
            auto&& _m = std::tuple{crate::prelude::index(args_p2, Nat(0u)), crate::prelude::index(args_p2, Nat(1u))};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& a_p7 = prism_rtl::some_of(std::get<0>(_m));
                auto&& s_p8 = prism_rtl::some_of(std::get<1>(_m));
                _v.set(std::optional(std::tuple{prism_rtl::deref(a_p7).value_p, prism_rtl::deref(s_p8).value_p, Nat(0u)}));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>{});
                goto _done;
            }
        _done:
            _v.take();
        })
            : std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>{};
    }
    {
        return std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>{};
    }
}


/// ?LastExpr: fn Block -> ?Expr
std::optional<crate::syntax::Expr> last_expr_o(const crate::syntax::Block& b_p0) {
    auto&& _m = crate::syntax::lexer::chars::last_o(b_p0.stmts_p);
    if (prism_rtl::is_some(_m)) {
        auto&& s_p1 = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::deref(s_p1).kind_p;
        if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
            auto&& x_p2 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
            return std::optional(x_p2);
        }
        {
            return std::optional<crate::syntax::Expr>{};
        }
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<crate::syntax::Expr>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?RelOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
std::optional<crate::check::shrink::Rel> rel_of_o(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& e_p1) {
    auto&& _m = prism_rtl::deref(e_p1.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::prelude::get(m_p0, crate::check::env::sname_key_f(n_p2));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r_p3 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& _m = rel_of_o(m_p0, prism_rtl::deref(prism_rtl::deref(r_p3)));
        if (prism_rtl::is_some(_m)) {
            auto&& x_p4 = prism_rtl::some_of(_m);
            return std::optional(crate::check::shrink::Rel{.param_p = prism_rtl::deref(x_p4).param_p, .strict_p = true});
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::check::shrink::Rel>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r_p5 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        return rel_of_o(m_p0, prism_rtl::deref(prism_rtl::deref(r_p5)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p6 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return rel_of_o(m_p0, prism_rtl::deref(prism_rtl::deref(x_p6)));
    }
    {
        auto&& _m = call_of_o(e_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& c_p7 = std::get<0>(prism_rtl::some_of(_m));
            auto&& args_p8 = std::get<1>(prism_rtl::some_of(_m));
            return is_non_nat_min_f(m_p0, e_p1, c_p7)
                ? std::optional<crate::check::shrink::Rel>{}
                : rel_of_call_o(m_p0, c_p7, args_p8);
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::check::shrink::Rel>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<std::optional<crate::check::shrink::Rel>> RelOf::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& e_p1 = this->e_p1;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p1).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p2 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        prism_rtl::finished(crate::prelude::get(m_p0, crate::check::env::sname_key_f(n_p2)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& r_p3 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        ({
        auto m_p0x = m_p0;
        auto r_p3x = prism_rtl::deref(prism_rtl::deref(r_p3));
        (crate::prelude::call_then(start_rel_of_o(m_p0x, r_p3x), [=](std::optional<crate::check::shrink::Rel> rel_of_o_18351) {
        return ({
            prism_rtl::is_some(rel_of_o_18351) ? ({
            auto&& x_p4 = prism_rtl::some_of(rel_of_o_18351);
            prism_rtl::finished(std::optional(crate::check::shrink::Rel{.param_p = prism_rtl::deref(x_p4).param_p, .strict_p = true}));
        })
            : prism_rtl::is_none(rel_of_o_18351) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
            : throw prism_rtl::Panic("no arm matched");
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& r_p5 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RelOf(m_p0, prism_rtl::deref(prism_rtl::deref(r_p5)))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p6 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RelOf(m_p0, prism_rtl::deref(prism_rtl::deref(x_p6)))));
    })
        : ({
        auto&& _m = call_of_o(e_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& c_p7 = std::get<0>(prism_rtl::some_of(_m));
        auto&& args_p8 = std::get<1>(prism_rtl::some_of(_m));
        is_non_nat_min_f(m_p0, e_p1, c_p7)
        ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
        : prism_rtl::more(prism_rtl::rc(RelOfCall(m_p0, c_p7, args_p8)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start RelOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>> start_rel_of_o(Map<Text, crate::check::shrink::Rel> m_p0, crate::syntax::Expr e_p1) {
    return prism_rtl::make_rc<RelOf>(m_p0, e_p1);
}


/// IsNonNatMin: fn (Text ==> Rel), Expr, Expr -> Bool
bool is_non_nat_min_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& e_p1, const crate::syntax::Expr& c_p2) {
    auto&& _m = callee_name_o(c_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& n_p3 = prism_rtl::some_of(_m);
        return crate::check::shrink::relations::pre_is_f(m_p0, n_p3, Text::lit("Min"))
            ? !is_nat_at_f(m_p0, e_p1)
            : false;
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsNatAt: fn (Text ==> Rel), Expr -> Bool
bool is_nat_at_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& e_p1) {
    auto&& _m = crate::prelude::get(m_p0, Text::lit("file:"));
    if (prism_rtl::is_some(_m)) {
        auto&& f_p2 = prism_rtl::some_of(_m);
        return crate::check::env::has_key_f(m_p0, prism_rtl::cat("nat:", prism_rtl::deref(f_p2).param_p, ":", prism_rtl::deref(e_p1.span_p).start_p, ":", prism_rtl::deref(e_p1.span_p).end_p));
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?RelOfCall: unbounded fn (Text ==> Rel), Expr, [Arg] -> ?Rel
std::optional<crate::check::shrink::Rel> rel_of_call_o(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& c_p1, const Array<crate::syntax::Arg>& args_p2) {
    auto&& _m = prism_rtl::deref(c_p1.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto name_p4 = crate::check::env::sname_key_f(n_p3);
        return (crate::check::shrink::relations::pre_is_f(m_p0, name_p4, Text::lit("Drop")) && (crate::prelude::len(args_p2) == Nat(2u))) && crate::check::shrink::summaries::is_positive_lit_f(prism_rtl::deref(crate::prelude::or_(crate::prelude::index(args_p2, Nat(1u)), crate::check::shrink::summaries::dummy_arg_p())).value_p)
            ? ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::check::shrink::Rel>> _v;
            auto&& _m = crate::prelude::index(args_p2, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& a_p5 = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<crate::check::shrink::Rel>> _v;
                    auto&& _m = rel_of_o(m_p0, prism_rtl::deref(a_p5).value_p);
                    if (prism_rtl::is_some(_m)) {
                        auto&& x_p6 = prism_rtl::some_of(_m);
                        _v.set(std::optional(crate::check::shrink::Rel{.param_p = prism_rtl::deref(x_p6).param_p, .strict_p = prism_rtl::deref(x_p6).strict_p || known_non_empty_f(m_p0, prism_rtl::deref(a_p5).value_p)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::optional<crate::check::shrink::Rel>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<crate::check::shrink::Rel>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        })
            : (crate::check::shrink::relations::pre_is_f(m_p0, name_p4, Text::lit("Values")) || crate::check::shrink::relations::pre_is_f(m_p0, name_p4, Text::lit("Keys"))) && (crate::prelude::len(args_p2) == Nat(1u))
            ? rel_of_o(m_p0, prism_rtl::deref(crate::prelude::or_(crate::prelude::index(args_p2, Nat(0u)), crate::check::shrink::summaries::dummy_arg_p())).value_p)
            : ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::check::shrink::Rel>> _v;
            auto&& _m = no_larger_arg_o(m_p0, c_p1, args_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& a_p7 = prism_rtl::some_of(_m);
                _v.set(rel_of_o(m_p0, a_p7));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<crate::check::shrink::Rel>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    {
        return std::optional<crate::check::shrink::Rel>{};
    }
}


prism_rtl::Turn<std::optional<crate::check::shrink::Rel>> RelOfCall::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& c_p1 = this->c_p1;
    const auto& args_p2 = this->args_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(c_p1).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto name_p4 = crate::check::env::sname_key_f(n_p3);
        (crate::check::shrink::relations::pre_is_f(m_p0, name_p4, Text::lit("Drop")) && (crate::prelude::len(args_p2) == Nat(2u))) && crate::check::shrink::summaries::is_positive_lit_f(prism_rtl::deref(crate::prelude::or_(crate::prelude::index(args_p2, Nat(1u)), crate::check::shrink::summaries::dummy_arg_p())).value_p)
        ? ({
        auto&& _m = crate::prelude::index(args_p2, Nat(0u));
        prism_rtl::is_some(_m) ? ({
        auto&& a_p5 = prism_rtl::some_of(_m);
        ({
        auto m_p0x = m_p0;
        (crate::prelude::call_then(start_rel_of_o(m_p0x, prism_rtl::deref(a_p5).value_p), [=](std::optional<crate::check::shrink::Rel> rel_of_o_19508) {
        return ({
            prism_rtl::is_some(rel_of_o_19508) ? ({
            auto&& x_p6 = prism_rtl::some_of(rel_of_o_19508);
            prism_rtl::finished(std::optional(crate::check::shrink::Rel{.param_p = prism_rtl::deref(x_p6).param_p, .strict_p = prism_rtl::deref(x_p6).strict_p || known_non_empty_f(m_p0x, prism_rtl::deref(a_p5).value_p)}));
        })
            : prism_rtl::is_none(rel_of_o_19508) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
            : throw prism_rtl::Panic("no arm matched");
        });
    }));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    })
        : (crate::check::shrink::relations::pre_is_f(m_p0, name_p4, Text::lit("Values")) || crate::check::shrink::relations::pre_is_f(m_p0, name_p4, Text::lit("Keys"))) && (crate::prelude::len(args_p2) == Nat(1u))
        ? prism_rtl::more(prism_rtl::rc(RelOf(m_p0, prism_rtl::deref(crate::prelude::or_(crate::prelude::index(args_p2, Nat(0u)), crate::check::shrink::summaries::dummy_arg_p())).value_p)))
        : ({
        auto&& _m = no_larger_arg_o(m_p0, c_p1, args_p2);
        prism_rtl::is_some(_m) ? ({
        auto&& a_p7 = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(RelOf(m_p0, a_p7)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::finished(std::optional<crate::check::shrink::Rel>{});
    });
}


/// `Start RelOfCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>> start_rel_of_call_o(Map<Text, crate::check::shrink::Rel> m_p0, crate::syntax::Expr c_p1, Array<crate::syntax::Arg> args_p2) {
    return prism_rtl::make_rc<RelOfCall>(m_p0, c_p1, args_p2);
}


/// KnownNonEmpty: fn (Text ==> Rel), Expr -> Bool
bool known_non_empty_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& e_p1) {
    auto&& _m = crate::check::shrink::relations::name_of_o(e_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& n_p2 = prism_rtl::some_of(_m);
        return crate::check::env::has_key_f(m_p0, prism_rtl::cat("ne:", n_p2));
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?CallOf: fn Expr -> ?((Expr, [Arg]))
std::optional<std::tuple<crate::syntax::Expr, Array<crate::syntax::Arg>>> call_of_o(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_p1 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_p2 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return std::optional(std::tuple{prism_rtl::deref(prism_rtl::deref(c_p1)), args_p2});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& r_p3 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& n_p4 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args_p5 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return std::optional(std::tuple{method_callee_f(n_p4), method_args_f(prism_rtl::deref(prism_rtl::deref(r_p3)), args_p5)});
    }
    {
        return std::optional<std::tuple<crate::syntax::Expr, Array<crate::syntax::Arg>>>{};
    }
}


/// ?NoLargerArg: fn (Text ==> Rel), Expr, [Arg] -> ?Expr
std::optional<crate::syntax::Expr> no_larger_arg_o(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& c_p1, const Array<crate::syntax::Arg>& args_p2) {
    auto&& _m = callee_name_o(c_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& n_p3 = prism_rtl::some_of(_m);
        return crate::check::shrink::relations::is_local_f(m_p0, n_p3)
            ? std::optional<crate::syntax::Expr>{}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
            auto&& _m = crate::prelude::get(m_p0, prism_rtl::cat("fn:", n_p3));
            if (prism_rtl::is_some(_m)) {
                auto&& s_p4 = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                    auto&& _m = crate::prelude::index(args_p2, prism_rtl::deref(s_p4).param_p);
                    if (prism_rtl::is_some(_m)) {
                        auto&& a_p5 = prism_rtl::some_of(_m);
                        _v.set(std::optional(prism_rtl::deref(a_p5).value_p));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::optional<crate::syntax::Expr>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<crate::syntax::Expr>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<crate::syntax::Expr>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsNoLargerPrelude: fn G, Text -> Bool
bool is_no_larger_prelude_f(const crate::check::env::G& g_p0, const Text& k_p1) {
    return crate::check::types::has_text_f(Array(std::vector{Text::lit("Prelude.Take"), Text::lit("Prelude.Drop"), Text::lit("Prelude.Filter"), Text::lit("Prelude.Remove"), Text::lit("Prelude.Min"), Text::lit("Prelude.@Flatten")}), k_p1) && crate::check::shrink::relations::is_prelude_key_f(g_p0, k_p1);
}

}  // namespace crate::check::shrink::walk
