// The module `Fs`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "fs.types.hpp"
#include "elem.types.hpp"

namespace crate {

using namespace prelude;




}  // namespace crate
