// The module `CheckExpr`, from `target/bootstrap/cpp-src/prismc/check-expr.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include <check_expr/module.hpp>
#include <check_env/module.hpp>
#include <check_errors/module.hpp>
#include <check_types/module.hpp>
#include <ast/module.hpp>
#include <check_blocks/module.hpp>
#include <check_passes/module.hpp>
#include <lexer/module.hpp>
#include <typed/module.hpp>
#include <check_env/generic.hpp>
#include <lexer/generic.hpp>

namespace crate::check_expr {

/// `Start CtorApp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_ctor_app(Env env, crate::check_types::St st, crate::check_env::CtorInfo c, Array<crate::ast::Arg> args, crate::ast::Range span, crate::ast::Range cspan) {
    return prism_rtl::make_rc<CtorApp>(env, st, c, args, span, cspan);
}


/// TagApp: unbounded fn Env, St, Text, [Arg], Range, Range -> ((Ty, St))
std::tuple<crate::check_types::Ty, crate::check_types::St> tag_app(const Env& env, const crate::check_types::St& st, const Text& name, const Array<crate::ast::Arg>& args, const crate::ast::Range& span, const crate::ast::Range& cspan) {
    auto&& _m = prelude::get(env.g.tags, name);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{crate::check_types::Ty(crate::check_types::Ty::TyErr{}), crate::check_types::err(st, Text::lit("unknown-name"), span, prism_rtl::cat("no tag `", name, "`"))};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& tg = prism_rtl::some_of(_m);
        auto [out, st1, inst] = crate::check_types::instantiate_with(st, crate::check_types::Scheme{.qs = tg.qs, .plain_qs = Array<Text>{}, .rqs = tg.rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = tg.bounds, .ty = tg->out}, span, Array<crate::check_types::Ty>{});
        auto st2 = run_to_end(fold_job(args, st1, ({
            auto tg_1 = tg;
            auto env_2 = env;
            auto name_3 = name;
            auto inst_4 = inst;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::St>(std::tuple<crate::check_types::St, crate::ast::Arg>)>>(prism_rtl::rc([=](std::tuple<crate::check_types::St, crate::ast::Arg> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto tg_1_5 = tg_1;
                auto env_2_5 = env_2;
                auto name_3_5 = name_3;
                auto inst_4_5 = inst_4;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto a = p1;
                    ({
                    auto&& _m = a.name;
                    prism_rtl::is_some(_m) ? ({
                    auto&& id = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = field_of_tag(tg_1_5, id.name);
                    prism_rtl::is_some(_m) ? ({
                    auto&& ft = prism_rtl::some_of(_m);
                    ({
                    auto id_5 = id;
                    call_then(crate::check_types::start_subst_q(inst_4_5, ft), [=](crate::check_types::Ty subst_q_49625) { return prism_rtl::more(prism_rtl::rc(TagField(env_2_5, s, name_3_5, id_5.name, subst_q_49625, a))); });
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check_types::err(s, Text::lit("mismatch"), a.span, prism_rtl::cat("`", name_3_5, "` has no field `", id.name, "`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check_types::err(s, Text::lit("mismatch"), a.span, prism_rtl::cat("a tag's fields are named: `", name_3_5, "(field=...)`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })));
        auto missing = filter(tg.fields, [&](const std::tuple<Text, crate::check_types::Ty>& _p0) {
            auto&& f = std::get<0>(_p0);
            return !fold(args, false, [&](const bool& seen, const crate::ast::Arg& a) { return seen || arg_named(a, f); });
        });
        auto st3 = (len(missing) > Nat(0u)) && (!fold(args, false, [&](const bool& seen, const crate::ast::Arg& a) { return seen || (a->value.kind == crate::ast::ExprKind(crate::ast::ExprKind::ERest{})); }))
            ? crate::check_types::err(st2, Text::lit("mismatch"), span, prism_rtl::cat("`", name, "` needs ", crate::lexer::join(each(missing, [&](const std::tuple<Text, crate::check_types::Ty>& _p0) {
            auto&& f = std::get<0>(_p0);
            return prism_rtl::cat("`", f, "`");
        }), Text::lit(", "))))
            : st2;
        auto field_tys = run_to_end(each_job(tg.fields, ({
            auto inst_1 = inst;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::Ty>(std::tuple<Text, crate::check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, crate::check_types::Ty> p0) {
            return ({
                auto inst_1_2 = inst_1;
                entered(once_job([=]() {
                return ({
                    auto&& _ft = p0;
                    auto&& ft = std::get<1>(_ft);
                    (prism_rtl::more(prism_rtl::rc(crate::check_types::SubstQ(inst_1_2, ft))));
                });
            }));
            });
        })));
        })));
        return tg.kind == Text::lit("Element")
            ? ({
            auto [rw, st4] = crate::check_types::fresh_row(st3, Array(std::vector{tg.family}));
            auto et = crate::check_types::Ty(crate::check_types::Ty::TyElem{crate::check_types::Rw{.fams = Array(std::vector{tg.family}), .minus = Array<Text>{}, .tail = rw.tail}, prism_rtl::rc(out)});
            std::tuple{et, crate::check_types::note_ty(st4, cspan, crate::check_types::Ty(crate::check_types::Ty::TyFn{crate::check_types::Col(crate::check_types::Col::CBound{}), field_tys, prism_rtl::rc(et)}))};
        })
            : std::tuple{crate::check_types::Ty(crate::check_types::Ty::TyCon{tg.kind, Array<crate::check_types::Ty>{}}), crate::check_types::note_ty(st3, cspan, crate::check_types::Ty(crate::check_types::Ty::TyFn{crate::check_types::Col(crate::check_types::Col::CBound{}), field_tys, prism_rtl::rc(crate::check_types::Ty(crate::check_types::Ty::TyCon{tg.kind, Array<crate::check_types::Ty>{}}))}))};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> TagApp::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& name = this->name;
    const auto& args = this->args;
    const auto& span = this->span;
    const auto& cspan = this->cspan;
    return ({
        auto&& _m = prelude::get(env.g.tags, name);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check_types::Ty(crate::check_types::Ty::TyErr{}), crate::check_types::err(st, Text::lit("unknown-name"), span, prism_rtl::cat("no tag `", name, "`"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto cspan_2 = cspan;
        auto env_3 = env;
        auto name_4 = name;
        auto span_5 = span;
        auto st_6 = st;
        call_then(crate::check_types::start_instantiate_with(st_6, crate::check_types::Scheme{.qs = tg.qs, .plain_qs = Array<Text>{}, .rqs = tg.rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = tg.bounds, .ty = tg->out}, span_5, Array<crate::check_types::Ty>{}), [=](std::tuple<crate::check_types::Ty, crate::check_types::St, crate::check_types::Inst> instantiate_with_49335) {
        return ({
            auto [out, st1, inst] = instantiate_with_49335;
            call_value(fold_job(args_1, st1, ({
            auto tg_7 = tg;
            auto env_3_8 = env_3;
            auto name_4_8 = name_4;
            auto inst_8 = inst;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::St>(std::tuple<crate::check_types::St, crate::ast::Arg>)>>(prism_rtl::rc([=](std::tuple<crate::check_types::St, crate::ast::Arg> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto tg_7_9 = tg_7;
                auto env_3_8_9 = env_3_8;
                auto name_4_8_9 = name_4_8;
                auto inst_8_9 = inst_8;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto a = p1;
                    ({
                    auto&& _m = a.name;
                    prism_rtl::is_some(_m) ? ({
                    auto&& id = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = field_of_tag(tg_7_9, id.name);
                    prism_rtl::is_some(_m) ? ({
                    auto&& ft = prism_rtl::some_of(_m);
                    ({
                    auto id_9 = id;
                    call_then(crate::check_types::start_subst_q(inst_8_9, ft), [=](crate::check_types::Ty subst_q_49625) { return prism_rtl::more(prism_rtl::rc(TagField(env_3_8_9, s, name_4_8_9, id_9.name, subst_q_49625, a))); });
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check_types::err(s, Text::lit("mismatch"), a.span, prism_rtl::cat("`", name_4_8_9, "` has no field `", id.name, "`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check_types::err(s, Text::lit("mismatch"), a.span, prism_rtl::cat("a tag's fields are named: `", name_4_8_9, "(field=...)`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })), [=](crate::check_types::St fold_49482) {
            return ({
                auto st2 = fold_49482;
                auto missing = filter(tg.fields, [&](const std::tuple<Text, crate::check_types::Ty>& _p0) {
                    auto&& f = std::get<0>(_p0);
                    return !fold(args_1, false, [&](const bool& seen, const crate::ast::Arg& a) { return seen || arg_named(a, f); });
                });
                auto st3 = (len(missing) > Nat(0u)) && (!fold(args_1, false, [&](const bool& seen, const crate::ast::Arg& a) { return seen || (a->value.kind == crate::ast::ExprKind(crate::ast::ExprKind::ERest{})); }))
                    ? crate::check_types::err(st2, Text::lit("mismatch"), span_5, prism_rtl::cat("`", name_4, "` needs ", crate::lexer::join(each(missing, [&](const std::tuple<Text, crate::check_types::Ty>& _p0) {
                    auto&& f = std::get<0>(_p0);
                    return prism_rtl::cat("`", f, "`");
                }), Text::lit(", "))))
                    : st2;
                call_value(each_job(tg.fields, ({
                auto inst_7 = inst;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::Ty>(std::tuple<Text, crate::check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, crate::check_types::Ty> p0) {
                return ({
                    auto inst_7_8 = inst_7;
                    entered(once_job([=]() {
                    return ({
                        auto&& _ft = p0;
                        auto&& ft = std::get<1>(_ft);
                        (prism_rtl::more(prism_rtl::rc(crate::check_types::SubstQ(inst_7_8, ft))));
                    });
                }));
                });
            })));
            })), [=](Array<crate::check_types::Ty> each_50177) {
                return ({
                    auto field_tys = each_50177;
                    tg.kind == Text::lit("Element")
                    ? ({
                    auto [rw, st4] = crate::check_types::fresh_row(st3, Array(std::vector{tg.family}));
                    auto et = crate::check_types::Ty(crate::check_types::Ty::TyElem{crate::check_types::Rw{.fams = Array(std::vector{tg.family}), .minus = Array<Text>{}, .tail = rw.tail}, prism_rtl::rc(out)});
                    (prism_rtl::finished(std::tuple{et, crate::check_types::note_ty(st4, cspan_2, crate::check_types::Ty(crate::check_types::Ty::TyFn{crate::check_types::Col(crate::check_types::Col::CBound{}), field_tys, prism_rtl::rc(et)}))}));
                })
                    : prism_rtl::finished(std::tuple{crate::check_types::Ty(crate::check_types::Ty::TyCon{tg.kind, Array<crate::check_types::Ty>{}}), crate::check_types::note_ty(st3, cspan_2, crate::check_types::Ty(crate::check_types::Ty::TyFn{crate::check_types::Col(crate::check_types::Col::CBound{}), field_tys, prism_rtl::rc(crate::check_types::Ty(crate::check_types::Ty::TyCon{tg.kind, Array<crate::check_types::Ty>{}}))}))});
                });
            });
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TagApp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_tag_app(Env env, crate::check_types::St st, Text name, Array<crate::ast::Arg> args, crate::ast::Range span, crate::ast::Range cspan) {
    return prism_rtl::make_rc<TagApp>(env, st, name, args, span, cspan);
}


/// ?FieldOfTag: fn TagInfo, Text -> ?Ty
std::optional<crate::check_types::Ty> field_of_tag(const crate::check_env::TagInfo& tg, const Text& f) {
    return fold(tg.fields, std::optional<crate::check_types::Ty>{}, [&](const std::optional<crate::check_types::Ty>& found_opt, const std::tuple<Text, crate::check_types::Ty>& _p1) {
        auto&& n = std::get<0>(_p1);
        auto&& t = std::get<1>(_p1);
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::check_types::Ty>> _v;
            if (prism_rtl::is_some(found_opt)) {
                auto&& x = prism_rtl::some_of(found_opt);
                _v.set(std::optional(x));
                goto _done;
            }
            if (prism_rtl::is_none(found_opt)) {
                _v.set(n == f ? std::optional(t) : std::optional<crate::check_types::Ty>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// TagField: unbounded fn Env, St, Text, Text, Ty, Arg -> St
crate::check_types::St tag_field(const Env& env, const crate::check_types::St& st, const Text& tag_name, const Text& field, const crate::check_types::Ty& ft, const crate::ast::Arg& a) {
    return crate::check_types::head_sigil(st, ft) != Text::lit("")
        ? check(env, st, a->value, ft)
        : ({
        auto [at_, st2] = infer(env, st, a->value);
        auto head = crate::check_types::head_sigil(st2, at_);
        head == Text::lit("$")
        ? crate::check_types::err_fix(st2, Text::lit("identity-dynamic"), a->value.span, prism_rtl::cat("a dynamic in the identity field `", field, "`"), prism_rtl::cat("for a new element per value, write `rebuild ", src_text(env, a->value.span), ":` with `", tag_name, "(", field, "=_, ...)` inside"))
        : head == Text::lit("!")
        ? crate::check_types::err(st2, Text::lit("two-events"), a->value.span, prism_rtl::cat("an event in the plain field `", field, "`"))
        : crate::check_types::unify(st2, ft, at_, a->value.span);
    });
}


prism_rtl::Turn<crate::check_types::St> TagField::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& tag_name = this->tag_name;
    const auto& field = this->field;
    const auto& ft = this->ft;
    const auto& a = this->a;
    auto a_1 = a;
    auto env_2 = env;
    auto field_3 = field;
    auto ft_4 = ft;
    auto st_5 = st;
    auto tag_name_6 = tag_name;
    return call_then(crate::check_types::start_head_sigil(st_5, ft_4), [=](Text head_sigil_50993) {
        return head_sigil_50993 != Text::lit("")
            ? prism_rtl::more(prism_rtl::rc(Check(env_2, st_5, a_1->value, ft_4)))
            : call_then(start_infer(env_2, st_5, a_1->value), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_51081) {
            return ({
                auto [at_, st2] = infer_51081;
                call_then(crate::check_types::start_head_sigil(st2, at_), [=](Text head_sigil_51123) {
                return ({
                    auto head = head_sigil_51123;
                    head == Text::lit("$")
                    ? prism_rtl::finished(crate::check_types::err_fix(st2, Text::lit("identity-dynamic"), a_1->value.span, prism_rtl::cat("a dynamic in the identity field `", field_3, "`"), prism_rtl::cat("for a new element per value, write `rebuild ", src_text(env_2, a_1->value.span), ":` with `", tag_name_6, "(", field_3, "=_, ...)` inside")))
                    : head == Text::lit("!")
                    ? prism_rtl::finished(crate::check_types::err(st2, Text::lit("two-events"), a_1->value.span, prism_rtl::cat("an event in the plain field `", field_3, "`")))
                    : prism_rtl::more(prism_rtl::rc(crate::check_types::Unify(st2, ft_4, at_, a_1->value.span)));
                });
            });
            });
        });
    });
}


/// `Start TagField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::St> start_tag_field(Env env, crate::check_types::St st, Text tag_name, Text field, crate::check_types::Ty ft, crate::ast::Arg a) {
    return prism_rtl::make_rc<TagField>(env, st, tag_name, field, ft, a);
}


/// LambdaArity: fn Expr -> Nat
Nat lambda_arity(const crate::ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::ast::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a0)) {
        auto&& ps = prism_rtl::some_of(prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a0);
        return len(ps);
    }
    if (prism_rtl::is<crate::ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
        return lambda_arity(x);
    }
    {
        return Nat(2u);
    }
}


/// InferLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
std::tuple<crate::check_types::Ty, crate::check_types::St> infer_lambda(const Env& env, const crate::check_types::St& st, const crate::ast::Expr& e, const std::optional<crate::check_types::Ty>& expected_opt) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
        auto [t, st2] = infer_lambda(env, st, x, expected_opt);
        return std::tuple{t, crate::check_types::note_ty(st2, e.span, t)};
    }
    {
        return infer_bare_lambda(env, st, e, expected_opt);
    }
}


prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> InferLambda::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    const auto& expected_opt = this->expected_opt;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
        ({
        auto expected_opt_1 = expected_opt;
        auto e_2 = e;
        auto env_3 = env;
        auto st_4 = st;
        auto x_5 = x;
        call_then(start_infer_lambda(env_3, st_4, x_5, expected_opt_1), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_lambda_52351) {
        return ({
            auto [t, st2] = infer_lambda_52351;
            (prism_rtl::finished(std::tuple{t, crate::check_types::note_ty(st2, e_2.span, t)}));
        });
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(InferBareLambda(env, st, e, expected_opt)));
    });
}


/// `Start InferLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_lambda(Env env, crate::check_types::St st, crate::ast::Expr e, std::optional<crate::check_types::Ty> expected_opt) {
    return prism_rtl::make_rc<InferLambda>(env, st, e, expected_opt);
}


/// InferBareLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
std::tuple<crate::check_types::Ty, crate::check_types::St> infer_bare_lambda(const Env& env, const crate::check_types::St& st, const crate::ast::Expr& e, const std::optional<crate::check_types::Ty>& expected_opt) {
    auto [params, body] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::ast::Pattern_>, crate::ast::LambdaBody>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::ast::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a0)) {
            auto&& ps = prism_rtl::some_of(prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a0);
            auto&& b = prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a1;
            _v.set(std::tuple{ps, b});
            goto _done;
        }
        if (prism_rtl::is<crate::ast::ExprKind::ELambda>(_m) && prism_rtl::is_none(prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a0)) {
            auto&& b = prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a1;
            _v.set(std::tuple{Array(std::vector{topic_pat(e.span)}), b});
            goto _done;
        }
        if (prism_rtl::is<crate::ast::ExprKind::ETopicField>(_m)) {
            auto&& f = prism_rtl::as<crate::ast::ExprKind::ETopicField>(_m).a0;
            _v.set(std::tuple{Array(std::vector{topic_pat(e.span)}), crate::ast::LambdaBody(crate::ast::LambdaBody::LbExpr{prism_rtl::rc(topic_field_expr(e.span, f))})});
            goto _done;
        }
        if (prism_rtl::is<crate::ast::ExprKind::ETopicIndex>(_m)) {
            auto&& x = prism_rtl::as<crate::ast::ExprKind::ETopicIndex>(_m).a0;
            _v.set(std::tuple{Array(std::vector{topic_pat(e.span)}), crate::ast::LambdaBody(crate::ast::LambdaBody::LbExpr{prism_rtl::rc(topic_index_expr(e.span, x))})});
            goto _done;
        }
        {
            _v.set(std::tuple{Array<crate::ast::Pattern_>{}, crate::ast::LambdaBody(crate::ast::LambdaBody::LbExpr{prism_rtl::rc(e)})});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [exp_params, exp_res_opt, st0] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check_types::Ty>, std::optional<crate::check_types::Ty>, crate::check_types::St>> _v;
        if (prism_rtl::is_some(expected_opt)) {
            auto&& t = prism_rtl::some_of(expected_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::check_types::Ty>, std::optional<crate::check_types::Ty>, crate::check_types::St>> _v;
                auto&& _m = crate::check_types::walk(st, t);
                if (prism_rtl::is<crate::check_types::Ty::TyFn>(_m)) {
                    auto&& ps = prism_rtl::as<crate::check_types::Ty::TyFn>(_m).a1;
                    auto&& r = prism_rtl::as<crate::check_types::Ty::TyFn>(_m).a2;
                    _v.set(len(ps) == len(params)
                        ? std::tuple{ps, std::optional(r), st}
                        : std::tuple{Array<crate::check_types::Ty>{}, std::optional<crate::check_types::Ty>{}, crate::check_types::err(st, Text::lit("mismatch"), e.span, prism_rtl::cat("this lambda takes ", crate::check_errors::count_word(len(params)), " parameter", len(params) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here ", crate::check_errors::count_word(len(ps)), " ", len(ps) == Nat(1u) ? Text::lit("is") : Text::lit("are"), " wanted"))});
                    goto _done;
                }
                {
                    _v.set(std::tuple{Array<crate::check_types::Ty>{}, std::optional<crate::check_types::Ty>{}, st});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(expected_opt)) {
            _v.set(std::tuple{Array<crate::check_types::Ty>{}, std::optional<crate::check_types::Ty>{}, st});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [env2, ptys, st1] = run_to_end(fold_job(crate::check_errors::range0(len(params)), std::tuple{env, Array<crate::check_types::Ty>{}, st0}, ({
        auto params_1 = params;
        auto e_2 = e;
        auto exp_params_3 = exp_params;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, Array<crate::check_types::Ty>, crate::check_types::St>>(std::tuple<std::tuple<Env, Array<crate::check_types::Ty>, crate::check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, Array<crate::check_types::Ty>, crate::check_types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_1_4 = params_1;
            auto e_2_4 = e_2;
            auto exp_params_3_4 = exp_params_3;
            entered(once_job([=]() {
            return ({
                auto [en, acc, s] = p0;
                auto i = p1;
                ({
                auto p_ = or_(index(params_1_4, i), crate::ast::Pattern_{.kind = prism_rtl::rc(crate::ast::PatternKind(crate::ast::PatternKind::PIgnore{})), .span = e_2_4.span});
                auto [pt, s2] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check_types::Ty, crate::check_types::St>> _v;
                    auto&& _m = index(exp_params_3_4, i);
                    if (prism_rtl::is_some(_m)) {
                        auto&& t = prism_rtl::some_of(_m);
                        _v.set(std::tuple{t, s});
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(crate::check_types::fresh_var(s, true, Text::lit("")));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_bind_pattern(unpend(en), s2, p_, pt, false), [=](std::tuple<Env, crate::check_types::St> bind_pattern_53693) {
                return ({
                    auto [en2, s3] = bind_pattern_53693;
                    (prism_rtl::finished(std::tuple{en2, prelude::push(acc, pt), s3}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto outer_color = st1.color;
    auto outer_why = st1.color_why;
    auto outer_flex = st1.color_flex;
    auto [lcol, st1b] = crate::check_types::fresh_col(st1);
    auto st2 = ({
        crate::check_types::St this_ = st1b;
        this_.color = crate::check_types::Col(crate::check_types::Col::CBound{});
        this_.color_why = Text::lit("");
        this_.color_flex = Array<std::tuple<crate::check_types::Col, Text, crate::ast::Range>>{};
        this_;
    });
    auto [rt, st3] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check_types::Ty, crate::check_types::St>> _v;
        if (prism_rtl::is<crate::ast::LambdaBody::LbExpr>(body)) {
            auto&& x = prism_rtl::as<crate::ast::LambdaBody::LbExpr>(body).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check_types::Ty, crate::check_types::St>> _v;
                if (prism_rtl::is_some(exp_res_opt)) {
                    auto&& r = prism_rtl::some_of(exp_res_opt);
                    _v.set(({
                        auto s4 = check(env2, st2, x, r);
                        std::tuple{r, s4};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(exp_res_opt)) {
                    _v.set(infer(env2, st2, x));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::ast::LambdaBody::LbBlock>(body)) {
            auto&& b = prism_rtl::as<crate::ast::LambdaBody::LbBlock>(body).a0;
            _v.set(infer_body_block(env2, st2, b, exp_res_opt));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st3b = crate::check_types::settle_body(st3, lcol, Text::lit(""));
    auto st3c = crate::check_types::add_leq(st3b, st3b.color, lcol, e.span, Text::lit("lambda"), Text::lit(""), st3b.color_why);
    auto st4 = ({
        crate::check_types::St this_ = st3c;
        this_.color = outer_color;
        this_.color_why = outer_why;
        this_.color_flex = outer_flex;
        this_;
    });
    return std::tuple{crate::check_types::Ty(crate::check_types::Ty::TyFn{lcol, ptys, prism_rtl::rc(rt)}), crate::check_types::note_fn(st4, e.span, Text::lit("lambda"), lcol, lcol)};
}


prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> InferBareLambda::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    const auto& expected_opt = this->expected_opt;
    auto [params, body] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::ast::Pattern_>, crate::ast::LambdaBody>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::ast::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a0)) {
            auto&& ps = prism_rtl::some_of(prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a0);
            auto&& b = prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a1;
            _v.set(std::tuple{ps, b});
            goto _done;
        }
        if (prism_rtl::is<crate::ast::ExprKind::ELambda>(_m) && prism_rtl::is_none(prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a0)) {
            auto&& b = prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a1;
            _v.set(std::tuple{Array(std::vector{topic_pat(e.span)}), b});
            goto _done;
        }
        if (prism_rtl::is<crate::ast::ExprKind::ETopicField>(_m)) {
            auto&& f = prism_rtl::as<crate::ast::ExprKind::ETopicField>(_m).a0;
            _v.set(std::tuple{Array(std::vector{topic_pat(e.span)}), crate::ast::LambdaBody(crate::ast::LambdaBody::LbExpr{prism_rtl::rc(topic_field_expr(e.span, f))})});
            goto _done;
        }
        if (prism_rtl::is<crate::ast::ExprKind::ETopicIndex>(_m)) {
            auto&& x = prism_rtl::as<crate::ast::ExprKind::ETopicIndex>(_m).a0;
            _v.set(std::tuple{Array(std::vector{topic_pat(e.span)}), crate::ast::LambdaBody(crate::ast::LambdaBody::LbExpr{prism_rtl::rc(topic_index_expr(e.span, x))})});
            goto _done;
        }
        {
            _v.set(std::tuple{Array<crate::ast::Pattern_>{}, crate::ast::LambdaBody(crate::ast::LambdaBody::LbExpr{prism_rtl::rc(e)})});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [exp_params, exp_res_opt, st0] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check_types::Ty>, std::optional<crate::check_types::Ty>, crate::check_types::St>> _v;
        if (prism_rtl::is_some(expected_opt)) {
            auto&& t = prism_rtl::some_of(expected_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::check_types::Ty>, std::optional<crate::check_types::Ty>, crate::check_types::St>> _v;
                auto&& _m = crate::check_types::walk(st, t);
                if (prism_rtl::is<crate::check_types::Ty::TyFn>(_m)) {
                    auto&& ps = prism_rtl::as<crate::check_types::Ty::TyFn>(_m).a1;
                    auto&& r = prism_rtl::as<crate::check_types::Ty::TyFn>(_m).a2;
                    _v.set(len(ps) == len(params)
                        ? std::tuple{ps, std::optional(r), st}
                        : std::tuple{Array<crate::check_types::Ty>{}, std::optional<crate::check_types::Ty>{}, crate::check_types::err(st, Text::lit("mismatch"), e.span, prism_rtl::cat("this lambda takes ", crate::check_errors::count_word(len(params)), " parameter", len(params) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here ", crate::check_errors::count_word(len(ps)), " ", len(ps) == Nat(1u) ? Text::lit("is") : Text::lit("are"), " wanted"))});
                    goto _done;
                }
                {
                    _v.set(std::tuple{Array<crate::check_types::Ty>{}, std::optional<crate::check_types::Ty>{}, st});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(expected_opt)) {
            _v.set(std::tuple{Array<crate::check_types::Ty>{}, std::optional<crate::check_types::Ty>{}, st});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto e_1 = e;
    auto env_2 = env;
    return call_value(fold_job(crate::check_errors::range0(len(params)), std::tuple{env_2, Array<crate::check_types::Ty>{}, st0}, ({
        auto params_3 = params;
        auto e_1_4 = e_1;
        auto exp_params_4 = exp_params;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, Array<crate::check_types::Ty>, crate::check_types::St>>(std::tuple<std::tuple<Env, Array<crate::check_types::Ty>, crate::check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, Array<crate::check_types::Ty>, crate::check_types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_3_5 = params_3;
            auto e_1_4_5 = e_1_4;
            auto exp_params_4_5 = exp_params_4;
            entered(once_job([=]() {
            return ({
                auto [en, acc, s] = p0;
                auto i = p1;
                ({
                auto p_ = or_(index(params_3_5, i), crate::ast::Pattern_{.kind = prism_rtl::rc(crate::ast::PatternKind(crate::ast::PatternKind::PIgnore{})), .span = e_1_4_5.span});
                auto [pt, s2] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check_types::Ty, crate::check_types::St>> _v;
                    auto&& _m = index(exp_params_4_5, i);
                    if (prism_rtl::is_some(_m)) {
                        auto&& t = prism_rtl::some_of(_m);
                        _v.set(std::tuple{t, s});
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(crate::check_types::fresh_var(s, true, Text::lit("")));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_bind_pattern(unpend(en), s2, p_, pt, false), [=](std::tuple<Env, crate::check_types::St> bind_pattern_53693) {
                return ({
                    auto [en2, s3] = bind_pattern_53693;
                    (prism_rtl::finished(std::tuple{en2, prelude::push(acc, pt), s3}));
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Env, Array<crate::check_types::Ty>, crate::check_types::St> fold_53424) {
        return ({
            auto [env2, ptys, st1] = fold_53424;
            auto outer_color = st1.color;
            auto outer_why = st1.color_why;
            auto outer_flex = st1.color_flex;
            auto [lcol, st1b] = crate::check_types::fresh_col(st1);
            auto st2 = ({
                crate::check_types::St this_ = st1b;
                this_.color = crate::check_types::Col(crate::check_types::Col::CBound{});
                this_.color_why = Text::lit("");
                this_.color_flex = Array<std::tuple<crate::check_types::Col, Text, crate::ast::Range>>{};
                this_;
            });
            auto [rt, st3] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check_types::Ty, crate::check_types::St>> _v;
                if (prism_rtl::is<crate::ast::LambdaBody::LbExpr>(body)) {
                    auto&& x = prism_rtl::as<crate::ast::LambdaBody::LbExpr>(body).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<crate::check_types::Ty, crate::check_types::St>> _v;
                        if (prism_rtl::is_some(exp_res_opt)) {
                            auto&& r = prism_rtl::some_of(exp_res_opt);
                            _v.set(({
                                auto s4 = check(env2, st2, x, r);
                                std::tuple{r, s4};
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(exp_res_opt)) {
                            _v.set(infer(env2, st2, x));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::ast::LambdaBody::LbBlock>(body)) {
                    auto&& b = prism_rtl::as<crate::ast::LambdaBody::LbBlock>(body).a0;
                    _v.set(infer_body_block(env2, st2, b, exp_res_opt));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            call_then(crate::check_types::start_settle_body(st3, lcol, Text::lit("")), [=](crate::check_types::St settle_body_54279) {
            return ({
                auto st3b = settle_body_54279;
                call_then(crate::check_types::start_add_leq(st3b, st3b.color, lcol, e_1.span, Text::lit("lambda"), Text::lit(""), st3b.color_why), [=](crate::check_types::St add_leq_54319) {
                return ({
                    auto st3c = add_leq_54319;
                    auto st4 = ({
                        crate::check_types::St this_ = st3c;
                        this_.color = outer_color;
                        this_.color_why = outer_why;
                        this_.color_flex = outer_flex;
                        this_;
                    });
                    (prism_rtl::finished(std::tuple{crate::check_types::Ty(crate::check_types::Ty::TyFn{lcol, ptys, prism_rtl::rc(rt)}), crate::check_types::note_fn(st4, e_1.span, Text::lit("lambda"), lcol, lcol)}));
                });
            });
            });
        });
        });
    });
}


/// `Start InferBareLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_bare_lambda(Env env, crate::check_types::St st, crate::ast::Expr e, std::optional<crate::check_types::Ty> expected_opt) {
    return prism_rtl::make_rc<InferBareLambda>(env, st, e, expected_opt);
}


/// TopicPat: fn Range -> Pattern
crate::ast::Pattern_ topic_pat(const crate::ast::Range& span) {
    return crate::ast::Pattern_{.kind = prism_rtl::rc(crate::ast::PatternKind(crate::ast::PatternKind::PName{topic_sname(span)})), .span = span};
}


/// TopicSName: fn Range -> SName
crate::ast::SName topic_sname(const crate::ast::Range& span) {
    return crate::ast::SName{.sigils = Text::lit(""), .path_ = Array(std::vector{Text::lit("_")}), .span = span};
}


/// TopicExpr: fn Range -> Expr
crate::ast::Expr topic_expr(const crate::ast::Range& span) {
    return crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EName{topic_sname(span)})), .span = span};
}


/// TopicFieldExpr: fn Range, Ident -> Expr
crate::ast::Expr topic_field_expr(const crate::ast::Range& span, const crate::ast::Ident& f) {
    return crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EField{prism_rtl::rc(topic_expr(span)), Text::lit(""), f})), .span = span};
}


/// TopicIndexExpr: fn Range, Expr -> Expr
crate::ast::Expr topic_index_expr(const crate::ast::Range& span, const crate::ast::Expr& x) {
    return crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EIndex{prism_rtl::rc(topic_expr(span)), prism_rtl::rc(x)})), .span = span};
}


/// ArgNamed: fn Arg, Text -> Bool
bool arg_named(const crate::ast::Arg& a, const Text& f) {
    auto&& _m = a.name;
    if (prism_rtl::is_some(_m)) {
        auto&& id = prism_rtl::some_of(_m);
        return id.name == f;
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// InferBodyBlock: unbounded fn Env, St, Block, ?Ty -> ((Ty, St))
std::tuple<crate::check_types::Ty, crate::check_types::St> infer_body_block(const Env& env, const crate::check_types::St& st, const crate::ast::Block& b, const std::optional<crate::check_types::Ty>& expected_opt) {
    auto [t, st2] = infer_expr_block(env, st, b);
    if (prism_rtl::is_some(expected_opt)) {
        auto&& r = prism_rtl::some_of(expected_opt);
        return std::tuple{r, crate::check_types::unify(st2, r, t, b.span)};
    }
    if (prism_rtl::is_none(expected_opt)) {
        return std::tuple{t, st2};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> InferBodyBlock::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& b = this->b;
    const auto& expected_opt = this->expected_opt;
    auto expected_opt_1 = expected_opt;
    auto b_2 = b;
    auto env_3 = env;
    auto st_4 = st;
    return call_then(start_infer_expr_block(env_3, st_4, b_2), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_expr_block_55574) {
        return ({
            auto [t, st2] = infer_expr_block_55574;
            ({
            prism_rtl::is_some(expected_opt_1) ? ({
            auto&& r = prism_rtl::some_of(expected_opt_1);
            ({
            auto r_5 = r;
            call_then(crate::check_types::start_unify(st2, r_5, t, b_2.span), [=](crate::check_types::St unify_55640) { return prism_rtl::finished(std::tuple{r_5, unify_55640}); });
        });
        })
            : prism_rtl::is_none(expected_opt_1) ? prism_rtl::finished(std::tuple{t, st2})
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start InferBodyBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_body_block(Env env, crate::check_types::St st, crate::ast::Block b, std::optional<crate::check_types::Ty> expected_opt) {
    return prism_rtl::make_rc<InferBodyBlock>(env, st, b, expected_opt);
}


/// BindPattern: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
std::tuple<Env, crate::check_types::St> bind_pattern(const Env& env, const crate::check_types::St& st, const crate::ast::Pattern_& p_, const crate::check_types::Ty& t, const bool& refutable) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::ast::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
        auto bare = or_(index(n->path_, Nat(0u)), Text::lit(""));
        auto is_ctor = (crate::check_env::is_upper_text(bare) && (len_text(n.sigils) == Nat(0u))) && is_ctor_name(env, n);
        return is_ctor || (len(n->path_) > Nat(1u))
            ? bind_ctor(env, st, p_, n, Array<crate::ast::Pattern_>{}, t)
            : bind_name(env, st, n, t);
    }
    if (prism_rtl::is<crate::ast::PatternKind::PIgnore>(_m)) {
        return std::tuple{env, st};
    }
    if (prism_rtl::is<crate::ast::PatternKind::PLit>(_m)) {
        auto&& l = prism_rtl::as<crate::ast::PatternKind::PLit>(_m).a0;
        auto [lt, st2] = infer_lit(env, st, l, false, p_.span);
        return std::tuple{env, crate::check_types::unify(st2, t, lt, p_.span)};
    }
    if (prism_rtl::is<crate::ast::PatternKind::PNeg>(_m)) {
        auto&& l = prism_rtl::as<crate::ast::PatternKind::PNeg>(_m).a0;
        auto [lt, st2] = infer_lit(env, st, l, true, p_.span);
        return std::tuple{env, crate::check_types::unify(st2, t, lt, p_.span)};
    }
    if (prism_rtl::is<crate::ast::PatternKind::PUnit>(_m)) {
        return std::tuple{env, crate::check_types::unify(st, t, crate::check_types::t_unit(), p_.span)};
    }
    if (prism_rtl::is<crate::ast::PatternKind::PNil>(_m)) {
        auto [v_, st2] = crate::check_types::fresh_var(st, false, Text::lit(""));
        return std::tuple{env, crate::check_types::unify(st2, t, crate::check_types::Ty(crate::check_types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_)}), p_.span)};
    }
    if (prism_rtl::is<crate::ast::PatternKind::PCtor>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::PatternKind::PCtor>(_m).a0;
        auto&& args = prism_rtl::as<crate::ast::PatternKind::PCtor>(_m).a1;
        return bind_ctor(env, st, p_, n, args, t);
    }
    if (prism_rtl::is<crate::ast::PatternKind::PRecord>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::PatternKind::PRecord>(_m).a0;
        auto&& fields = prism_rtl::as<crate::ast::PatternKind::PRecord>(_m).a1;
        auto&& rest = prism_rtl::as<crate::ast::PatternKind::PRecord>(_m).a2;
        return bind_record(env, st, p_, n, fields, rest, t);
    }
    if (prism_rtl::is<crate::ast::PatternKind::PSigil>(_m)) {
        auto&& s = prism_rtl::as<crate::ast::PatternKind::PSigil>(_m).a0;
        auto&& inner = prism_rtl::as<crate::ast::PatternKind::PSigil>(_m).a1;
        return (s == Text::lit("?")) || (s == Text::lit("~"))
            ? ({
            auto [v_, st2] = crate::check_types::fresh_var(st, false, Text::lit(""));
            auto st3 = crate::check_types::unify(st2, t, crate::check_types::Ty(crate::check_types::Ty::TySig{s, prism_rtl::rc(v_)}), p_.span);
            bind_pattern(env, st3, inner, v_, refutable);
        })
            : ({
            auto [v_, st2] = crate::check_types::fresh_var(st, false, Text::lit(""));
            auto st3 = crate::check_types::unify(st2, t, crate::check_types::with_marks(s, v_, env.scope), p_.span);
            bind_pattern(env, st3, inner, v_, refutable);
        });
    }
    if (prism_rtl::is<crate::ast::PatternKind::PTuple>(_m)) {
        auto&& ps = prism_rtl::as<crate::ast::PatternKind::PTuple>(_m).a0;
        auto [vs, st2] = fold(ps, std::tuple{Array<crate::check_types::Ty>{}, st}, [&](const std::tuple<Array<crate::check_types::Ty>, crate::check_types::St>& _p0, const crate::ast::Pattern_& _p1) {
            auto&& acc = std::get<0>(_p0);
            auto&& s = std::get<1>(_p0);
            return ({
                auto [v_, s2] = crate::check_types::fresh_var(s, false, Text::lit(""));
                std::tuple{prelude::push(acc, v_), s2};
            });
        });
        auto st3 = crate::check_types::unify(st2, t, crate::check_types::Ty(crate::check_types::Ty::TyTuple{vs}), p_.span);
        return run_to_end(fold_job(crate::check_errors::range0(len(ps)), std::tuple{env, st3}, ({
            auto ps_1 = ps;
            auto p__2 = p_;
            auto vs_3 = vs;
            auto refutable_4 = refutable;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>>(std::tuple<std::tuple<Env, crate::check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, crate::check_types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto ps_1_5 = ps_1;
                auto p__2_5 = p__2;
                auto vs_3_5 = vs_3;
                auto refutable_4_5 = refutable_4;
                entered(once_job([=]() {
                return ({
                    auto [en, s] = p0;
                    auto i = p1;
                    (prism_rtl::more(prism_rtl::rc(BindPattern(en, s, or_(index(ps_1_5, i), crate::ast::Pattern_{.kind = prism_rtl::rc(crate::ast::PatternKind(crate::ast::PatternKind::PIgnore{})), .span = p__2_5.span}), or_(index(vs_3_5, i), crate::check_types::Ty(crate::check_types::Ty::TyErr{})), refutable_4_5))));
                });
            }));
            });
        }));
        })));
    }
    if (prism_rtl::is<crate::ast::PatternKind::PArray>(_m)) {
        auto&& ps = prism_rtl::as<crate::ast::PatternKind::PArray>(_m).a0;
        auto [v_, st2] = crate::check_types::fresh_var(st, false, Text::lit(""));
        auto st3 = crate::check_types::unify(st2, t, crate::check_types::Ty(crate::check_types::Ty::TyArray{prism_rtl::rc(v_)}), p_.span);
        return run_to_end(fold_job(ps, std::tuple{env, st3}, ({
            auto v__1 = v_;
            auto refutable_2 = refutable;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>>(std::tuple<std::tuple<Env, crate::check_types::St>, crate::ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, crate::check_types::St>, crate::ast::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__1_3 = v__1;
                auto refutable_2_3 = refutable_2;
                entered(once_job([=]() {
                return ({
                    auto [en, s] = p0;
                    auto q = p1;
                    (prism_rtl::more(prism_rtl::rc(BindPattern(en, s, q, v__1_3, refutable_2_3))));
                });
            }));
            });
        }));
        })));
    }
    if (prism_rtl::is<crate::ast::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::ast::PatternKind::PGroup>(_m).a0;
        return bind_pattern(env, st, q, t, refutable);
    }
    if (prism_rtl::is<crate::ast::PatternKind::PFamily>(_m)) {
        auto&& q = prism_rtl::as<crate::ast::PatternKind::PFamily>(_m).a0;
        return bind_family(env, st, crate::check_env::dotted(q->path_), t, p_.span);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> BindPattern::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& t = this->t;
    const auto& refutable = this->refutable;
    return ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::ast::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
        ({
        auto bare = or_(index(n->path_, Nat(0u)), Text::lit(""));
        auto is_ctor = (crate::check_env::is_upper_text(bare) && (len_text(n.sigils) == Nat(0u))) && is_ctor_name(env, n);
        is_ctor || (len(n->path_) > Nat(1u))
        ? prism_rtl::more(prism_rtl::rc(BindCtor(env, st, p_, n, Array<crate::ast::Pattern_>{}, t)))
        : prism_rtl::more(prism_rtl::rc(BindName(env, st, n, t)));
    });
    })
        : prism_rtl::is<crate::ast::PatternKind::PIgnore>(_m) ? prism_rtl::finished(std::tuple{env, st})
        : prism_rtl::is<crate::ast::PatternKind::PLit>(_m) ? ({
        auto&& l = prism_rtl::as<crate::ast::PatternKind::PLit>(_m).a0;
        ({
        auto env_1 = env;
        auto l_2 = l;
        auto p__3 = p_;
        auto st_4 = st;
        auto t_5 = t;
        call_then(start_infer_lit(env_1, st_4, l_2, false, p__3.span), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_lit_56487) {
        return ({
            auto [lt, st2] = infer_lit_56487;
            call_then(crate::check_types::start_unify(st2, t_5, lt, p__3.span), [=](crate::check_types::St unify_56538) { return prism_rtl::finished(std::tuple{env_1, unify_56538}); });
        });
    });
    });
    })
        : prism_rtl::is<crate::ast::PatternKind::PNeg>(_m) ? ({
        auto&& l = prism_rtl::as<crate::ast::PatternKind::PNeg>(_m).a0;
        ({
        auto env_1 = env;
        auto l_2 = l;
        auto p__3 = p_;
        auto st_4 = st;
        auto t_5 = t;
        call_then(start_infer_lit(env_1, st_4, l_2, true, p__3.span), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_lit_56604) {
        return ({
            auto [lt, st2] = infer_lit_56604;
            call_then(crate::check_types::start_unify(st2, t_5, lt, p__3.span), [=](crate::check_types::St unify_56654) { return prism_rtl::finished(std::tuple{env_1, unify_56654}); });
        });
    });
    });
    })
        : prism_rtl::is<crate::ast::PatternKind::PUnit>(_m) ? ({
        auto env_1 = env;
        auto p__2 = p_;
        auto st_3 = st;
        auto t_4 = t;
        call_then(crate::check_types::start_unify(st_3, t_4, crate::check_types::t_unit(), p__2.span), [=](crate::check_types::St unify_56701) { return prism_rtl::finished(std::tuple{env_1, unify_56701}); });
    })
        : prism_rtl::is<crate::ast::PatternKind::PNil>(_m) ? ({
        auto [v_, st2] = crate::check_types::fresh_var(st, false, Text::lit(""));
        auto env_1 = env;
        auto p__2 = p_;
        auto t_3 = t;
        call_then(crate::check_types::start_unify(st2, t_3, crate::check_types::Ty(crate::check_types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_)}), p__2.span), [=](crate::check_types::St unify_56805) { return prism_rtl::finished(std::tuple{env_1, unify_56805}); });
    })
        : prism_rtl::is<crate::ast::PatternKind::PCtor>(_m) ? ({
        auto&& n = prism_rtl::as<crate::ast::PatternKind::PCtor>(_m).a0;
        auto&& args = prism_rtl::as<crate::ast::PatternKind::PCtor>(_m).a1;
        prism_rtl::more(prism_rtl::rc(BindCtor(env, st, p_, n, args, t)));
    })
        : prism_rtl::is<crate::ast::PatternKind::PRecord>(_m) ? ({
        auto&& n = prism_rtl::as<crate::ast::PatternKind::PRecord>(_m).a0;
        auto&& fields = prism_rtl::as<crate::ast::PatternKind::PRecord>(_m).a1;
        auto&& rest = prism_rtl::as<crate::ast::PatternKind::PRecord>(_m).a2;
        prism_rtl::more(prism_rtl::rc(BindRecord(env, st, p_, n, fields, rest, t)));
    })
        : prism_rtl::is<crate::ast::PatternKind::PSigil>(_m) ? ({
        auto&& s = prism_rtl::as<crate::ast::PatternKind::PSigil>(_m).a0;
        auto&& inner = prism_rtl::as<crate::ast::PatternKind::PSigil>(_m).a1;
        (s == Text::lit("?")) || (s == Text::lit("~"))
        ? ({
        auto [v_, st2] = crate::check_types::fresh_var(st, false, Text::lit(""));
        auto env_1 = env;
        auto inner_2 = inner;
        auto p__3 = p_;
        auto refutable_4 = refutable;
        auto s_5 = s;
        auto t_6 = t;
        call_then(crate::check_types::start_unify(st2, t_6, crate::check_types::Ty(crate::check_types::Ty::TySig{s_5, prism_rtl::rc(v_)}), p__3.span), [=](crate::check_types::St unify_57095) {
        return ({
            auto st3 = unify_57095;
            (prism_rtl::more(prism_rtl::rc(BindPattern(env_1, st3, inner_2, v_, refutable_4))));
        });
    });
    })
        : ({
        auto [v_, st2] = crate::check_types::fresh_var(st, false, Text::lit(""));
        auto env_1 = env;
        auto inner_2 = inner;
        auto p__3 = p_;
        auto refutable_4 = refutable;
        auto s_5 = s;
        auto t_6 = t;
        call_then(crate::check_types::start_unify(st2, t_6, crate::check_types::with_marks(s_5, v_, env_1.scope), p__3.span), [=](crate::check_types::St unify_57272) {
        return ({
            auto st3 = unify_57272;
            (prism_rtl::more(prism_rtl::rc(BindPattern(env_1, st3, inner_2, v_, refutable_4))));
        });
    });
    });
    })
        : prism_rtl::is<crate::ast::PatternKind::PTuple>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::ast::PatternKind::PTuple>(_m).a0;
        ({
        auto [vs, st2] = fold(ps, std::tuple{Array<crate::check_types::Ty>{}, st}, [&](const std::tuple<Array<crate::check_types::Ty>, crate::check_types::St>& _p0, const crate::ast::Pattern_& _p1) {
            auto&& acc = std::get<0>(_p0);
            auto&& s = std::get<1>(_p0);
            return ({
                auto [v_, s2] = crate::check_types::fresh_var(s, false, Text::lit(""));
                std::tuple{prelude::push(acc, v_), s2};
            });
        });
        auto env_1 = env;
        auto p__2 = p_;
        auto ps_3 = ps;
        auto refutable_4 = refutable;
        auto t_5 = t;
        call_then(crate::check_types::start_unify(st2, t_5, crate::check_types::Ty(crate::check_types::Ty::TyTuple{vs}), p__2.span), [=](crate::check_types::St unify_57564) {
        return ({
            auto st3 = unify_57564;
            fold_job(crate::check_errors::range0(len(ps_3)), std::tuple{env_1, st3}, ({
            auto ps_3_6 = ps_3;
            auto p__2_6 = p__2;
            auto vs_6 = vs;
            auto refutable_4_7 = refutable_4;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>>(std::tuple<std::tuple<Env, crate::check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, crate::check_types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto ps_3_6_7 = ps_3_6;
                auto p__2_6_7 = p__2_6;
                auto vs_6_7 = vs_6;
                auto refutable_4_7_7 = refutable_4_7;
                entered(once_job([=]() {
                return ({
                    auto [en, s] = p0;
                    auto i = p1;
                    (prism_rtl::more(prism_rtl::rc(BindPattern(en, s, or_(index(ps_3_6_7, i), crate::ast::Pattern_{.kind = prism_rtl::rc(crate::ast::PatternKind(crate::ast::PatternKind::PIgnore{})), .span = p__2_6_7.span}), or_(index(vs_6_7, i), crate::check_types::Ty(crate::check_types::Ty::TyErr{})), refutable_4_7_7))));
                });
            }));
            });
        }));
        }))->cycle();
        });
    });
    });
    })
        : prism_rtl::is<crate::ast::PatternKind::PArray>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::ast::PatternKind::PArray>(_m).a0;
        ({
        auto [v_, st2] = crate::check_types::fresh_var(st, false, Text::lit(""));
        auto env_1 = env;
        auto p__2 = p_;
        auto ps_3 = ps;
        auto refutable_4 = refutable;
        auto t_5 = t;
        call_then(crate::check_types::start_unify(st2, t_5, crate::check_types::Ty(crate::check_types::Ty::TyArray{prism_rtl::rc(v_)}), p__2.span), [=](crate::check_types::St unify_57838) {
        return ({
            auto st3 = unify_57838;
            fold_job(ps_3, std::tuple{env_1, st3}, ({
            auto v__6 = v_;
            auto refutable_4_7 = refutable_4;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>>(std::tuple<std::tuple<Env, crate::check_types::St>, crate::ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, crate::check_types::St>, crate::ast::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__6_7 = v__6;
                auto refutable_4_7_7 = refutable_4_7;
                entered(once_job([=]() {
                return ({
                    auto [en, s] = p0;
                    auto q = p1;
                    (prism_rtl::more(prism_rtl::rc(BindPattern(en, s, q, v__6_7, refutable_4_7_7))));
                });
            }));
            });
        }));
        }))->cycle();
        });
    });
    });
    })
        : prism_rtl::is<crate::ast::PatternKind::PGroup>(_m) ? ({
        auto&& q = prism_rtl::as<crate::ast::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BindPattern(env, st, q, t, refutable)));
    })
        : prism_rtl::is<crate::ast::PatternKind::PFamily>(_m) ? ({
        auto&& q = prism_rtl::as<crate::ast::PatternKind::PFamily>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BindFamily(env, st, crate::check_env::dotted(q->path_), t, p_.span)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_pattern(Env env, crate::check_types::St st, crate::ast::Pattern_ p_, crate::check_types::Ty t, bool refutable) {
    return prism_rtl::make_rc<BindPattern>(env, st, p_, t, refutable);
}


/// IsCtorName: fn Env, SName -> Bool
bool is_ctor_name(const Env& env, const crate::ast::SName& n) {
    auto&& _qk_opt = crate::check_env::resolve_value(env.g, env.home, n);
    auto&& qk_opt = std::get<0>(_qk_opt);
    if (prism_rtl::is_some(qk_opt)) {
        auto&& qk = prism_rtl::some_of(qk_opt);
        return crate::check_env::has_key(env.g.ctors, qk);
    }
    if (prism_rtl::is_none(qk_opt)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// BindName: unbounded fn Env, St, SName, Ty -> ((Env, St))
std::tuple<Env, crate::check_types::St> bind_name(const Env& env, const crate::check_types::St& st, const crate::ast::SName& n, const crate::check_types::Ty& t) {
    auto name = crate::check_env::sname_key(n);
    return crate::check_types::has_text(env.pending, name)
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Env, crate::check_types::St>> _v;
        auto&& _m = prelude::get(env.locals, name);
        if (prism_rtl::is_some(_m)) {
            auto&& sc = prism_rtl::some_of(_m);
            _v.set(({
                auto [ok, st1] = crate::check_types::try_unify(st, sc.ty, t, n.span);
                auto marks_agree = (crate::check_types::stack_of(st, t) == type_marks(n.sigils)) || crate::check_types::is_flex_var(st, t);
                auto st_a = ok
                    ? st1
                    : marks_agree
                    ? crate::check_types::unify(st, sc.ty, t, n.span)
                    : crate::check_types::err_fix(st, Text::lit("mark-stack"), n.span, prism_rtl::cat("`", name, "` has type `", crate::check_types::show_ty(st, t), "`, whose stack is `", crate::check_types::stack_of(st, t), "`; the name shows `", type_marks(n.sigils), "`"), prism_rtl::cat("rename to `", ref_mark(n.sigils), crate::check_types::stack_of(st, t), crate::lexer::drop_prefix(name, n.sigils), "`"));
                std::tuple{env, crate::check_types::note_binder(st_a, n.span, name, t)};
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(bind_fresh(env, st, n, t));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    })
        : bind_fresh(env, st, n, t);
}


prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> BindName::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& t = this->t;
    auto name = crate::check_env::sname_key(n);
    return crate::check_types::has_text(env.pending, name)
        ? ({
        auto&& _m = prelude::get(env.locals, name);
        prism_rtl::is_some(_m) ? ({
        auto&& sc = prism_rtl::some_of(_m);
        ({
        auto env_1 = env;
        auto n_2 = n;
        auto st_3 = st;
        auto t_4 = t;
        call_then(crate::check_types::start_try_unify(st_3, sc.ty, t_4, n_2.span), [=](std::tuple<bool, crate::check_types::St> try_unify_58633) {
        return ({
            auto [ok, st1] = try_unify_58633;
            call_then(crate::check_types::start_stack_of(st_3, t_4), [=](Text stack_of_58697) {
            return ({
                auto marks_agree = (stack_of_58697 == type_marks(n_2.sigils)) || crate::check_types::is_flex_var(st_3, t_4);
                auto st_a = ok
                    ? st1
                    : marks_agree
                    ? crate::check_types::unify(st_3, sc.ty, t_4, n_2.span)
                    : crate::check_types::err_fix(st_3, Text::lit("mark-stack"), n_2.span, prism_rtl::cat("`", name, "` has type `", crate::check_types::show_ty(st_3, t_4), "`, whose stack is `", crate::check_types::stack_of(st_3, t_4), "`; the name shows `", type_marks(n_2.sigils), "`"), prism_rtl::cat("rename to `", ref_mark(n_2.sigils), crate::check_types::stack_of(st_3, t_4), crate::lexer::drop_prefix(name, n_2.sigils), "`"));
                (prism_rtl::finished(std::tuple{env_1, crate::check_types::note_binder(st_a, n_2.span, name, t_4)}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(BindFresh(env, st, n, t)))
        : throw prism_rtl::Panic("no arm matched");
    })
        : prism_rtl::more(prism_rtl::rc(BindFresh(env, st, n, t)));
}


/// `Start BindName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_name(Env env, crate::check_types::St st, crate::ast::SName n, crate::check_types::Ty t) {
    return prism_rtl::make_rc<BindName>(env, st, n, t);
}


/// BindFresh: unbounded fn Env, St, SName, Ty -> ((Env, St))
std::tuple<Env, crate::check_types::St> bind_fresh(const Env& env, const crate::check_types::St& st, const crate::ast::SName& n, const crate::check_types::Ty& t) {
    return bind_fresh_marked(env, st, n, type_marks(n.sigils), t);
}


prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> BindFresh::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& t = this->t;
    return prism_rtl::more(prism_rtl::rc(BindFreshMarked(env, st, n, type_marks(n.sigils), t)));
}


/// `Start BindFresh, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_fresh(Env env, crate::check_types::St st, crate::ast::SName n, crate::check_types::Ty t) {
    return prism_rtl::make_rc<BindFresh>(env, st, n, t);
}


/// BindFreshMarked: unbounded fn Env, St, SName, Text, Ty -> ((Env, St))
std::tuple<Env, crate::check_types::St> bind_fresh_marked(const Env& env, const crate::check_types::St& st, const crate::ast::SName& n, const Text& marks, const crate::check_types::Ty& t) {
    auto name = crate::check_env::sname_key(n);
    auto [v_, st2] = crate::check_types::fresh_var(st, true, name);
    auto [rw, st3] = crate::check_types::fresh_row(st2, Array<Text>{});
    auto marked = crate::check_types::with_marks(marks, v_, rw);
    auto [ok, st4] = crate::check_types::try_unify(st3, t, marked, n.span);
    auto st5 = ok
        ? st4
        : ({
        auto stack = crate::check_types::stack_of(st3, t);
        (crate::check_types::err_fix(st3, Text::lit("mark-stack"), n.span, prism_rtl::cat("`", name, "` has type `", crate::check_types::show_ty(st3, t), "`, whose stack is `", stack, "`; the name shows `", marks, "`"), prism_rtl::cat("rename to `", ref_mark(n.sigils), stack, crate::lexer::drop_prefix(name, n.sigils), "`")));
    });
    return std::tuple{with_local(env, name, crate::check_types::mono(t)), crate::check_types::note_binder(st5, n.span, name, t)};
}


prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> BindFreshMarked::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& marks = this->marks;
    const auto& t = this->t;
    auto name = crate::check_env::sname_key(n);
    auto [v_, st2] = crate::check_types::fresh_var(st, true, name);
    auto [rw, st3] = crate::check_types::fresh_row(st2, Array<Text>{});
    auto marked = crate::check_types::with_marks(marks, v_, rw);
    auto env_1 = env;
    auto marks_2 = marks;
    auto n_3 = n;
    auto t_4 = t;
    return call_then(crate::check_types::start_try_unify(st3, t_4, marked, n_3.span), [=](std::tuple<bool, crate::check_types::St> try_unify_59764) {
        return ({
            auto [ok, st4] = try_unify_59764;
            auto st5 = ok
                ? st4
                : ({
                auto stack = crate::check_types::stack_of(st3, t_4);
                (crate::check_types::err_fix(st3, Text::lit("mark-stack"), n_3.span, prism_rtl::cat("`", name, "` has type `", crate::check_types::show_ty(st3, t_4), "`, whose stack is `", stack, "`; the name shows `", marks_2, "`"), prism_rtl::cat("rename to `", ref_mark(n_3.sigils), stack, crate::lexer::drop_prefix(name, n_3.sigils), "`")));
            });
            (prism_rtl::finished(std::tuple{with_local(env_1, name, crate::check_types::mono(t_4)), crate::check_types::note_binder(st5, n_3.span, name, t_4)}));
        });
    });
}


/// `Start BindFreshMarked, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_fresh_marked(Env env, crate::check_types::St st, crate::ast::SName n, Text marks, crate::check_types::Ty t) {
    return prism_rtl::make_rc<BindFreshMarked>(env, st, n, marks, t);
}


/// BindField: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
std::tuple<Env, crate::check_types::St> bind_field(const Env& env, const crate::check_types::St& st, const crate::ast::Pattern_& p_, const crate::check_types::Ty& ft, const bool& snapshot) {
    auto&& _m = crate::check_types::walk(st, ft);
    if (prism_rtl::is<crate::check_types::Ty::TySig>(_m)) {
        auto&& s = prism_rtl::as<crate::check_types::Ty::TySig>(_m).a0;
        auto&& level = prism_rtl::as<crate::check_types::Ty::TySig>(_m).a1;
        if (snapshot && (s == Text::lit("$"))) {
            return bind_level(env, st, p_, level);
        }
    }
    {
        return bind_pattern(env, st, p_, ft, true);
    }
}


prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> BindField::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& ft = this->ft;
    const auto& snapshot = this->snapshot;
    auto env_1 = env;
    auto ft_2 = ft;
    auto p__3 = p_;
    auto snapshot_4 = snapshot;
    auto st_5 = st;
    return call_then(crate::check_types::start_walk(st_5, ft_2), [=](crate::check_types::Ty walk_60691) {
        return ({
            prism_rtl::is<crate::check_types::Ty::TySig>(walk_60691) && ({
            auto&& s = prism_rtl::as<crate::check_types::Ty::TySig>(walk_60691).a0;
            auto&& level = prism_rtl::as<crate::check_types::Ty::TySig>(walk_60691).a1;
            (snapshot_4 && (s == Text::lit("$")));
        }) ? ({
            auto&& s = prism_rtl::as<crate::check_types::Ty::TySig>(walk_60691).a0;
            auto&& level = prism_rtl::as<crate::check_types::Ty::TySig>(walk_60691).a1;
            prism_rtl::more(prism_rtl::rc(BindLevel(env_1, st_5, p__3, level)));
        })
            : prism_rtl::more(prism_rtl::rc(BindPattern(env_1, st_5, p__3, ft_2, true)));
        });
    });
}


/// `Start BindField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_field(Env env, crate::check_types::St st, crate::ast::Pattern_ p_, crate::check_types::Ty ft, bool snapshot) {
    return prism_rtl::make_rc<BindField>(env, st, p_, ft, snapshot);
}


/// BindLevel: unbounded fn Env, St, Pattern, Ty -> ((Env, St))
std::tuple<Env, crate::check_types::St> bind_level(const Env& env, const crate::check_types::St& st, const crate::ast::Pattern_& p_, const crate::check_types::Ty& level) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::ast::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
        return crate::lexer::has_prefix(n.sigils, Text::lit("$")) && (len(n->path_) == Nat(1u))
            ? bind_fresh_marked(env, st, n, crate::lexer::after_first(n.sigils), level)
            : bind_pattern(env, st, p_, level, true);
    }
    if (prism_rtl::is<crate::ast::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::ast::PatternKind::PGroup>(_m).a0;
        return bind_level(env, st, q, level);
    }
    {
        return bind_pattern(env, st, p_, level, true);
    }
}


prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> BindLevel::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& level = this->level;
    return ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::ast::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
        crate::lexer::has_prefix(n.sigils, Text::lit("$")) && (len(n->path_) == Nat(1u))
        ? prism_rtl::more(prism_rtl::rc(BindFreshMarked(env, st, n, crate::lexer::after_first(n.sigils), level)))
        : prism_rtl::more(prism_rtl::rc(BindPattern(env, st, p_, level, true)));
    })
        : prism_rtl::is<crate::ast::PatternKind::PGroup>(_m) ? ({
        auto&& q = prism_rtl::as<crate::ast::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BindLevel(env, st, q, level)));
    })
        : prism_rtl::more(prism_rtl::rc(BindPattern(env, st, p_, level, true)));
    });
}


/// `Start BindLevel, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_level(Env env, crate::check_types::St st, crate::ast::Pattern_ p_, crate::check_types::Ty level) {
    return prism_rtl::make_rc<BindLevel>(env, st, p_, level);
}


/// BindCtor: unbounded fn Env, St, Pattern, SName, [Pattern], Ty -> ((Env, St))
std::tuple<Env, crate::check_types::St> bind_ctor(const Env& env, const crate::check_types::St& st, const crate::ast::Pattern_& p_, const crate::ast::SName& n, const Array<crate::ast::Pattern_>& args, const crate::check_types::Ty& t) {
    auto [qk_opt, why] = crate::check_env::resolve_value(env.g, env.home, n);
    if (prism_rtl::is_none(qk_opt)) {
        return std::tuple{env, crate::check_types::err(st, Text::lit("unknown-name"), n.span, prism_rtl::cat("no constructor `", crate::check_env::sname_key(n), "`"))};
    }
    if (prism_rtl::is_some(qk_opt)) {
        auto&& qk = prism_rtl::some_of(qk_opt);
        return why == Text::lit("tag")
            ? bind_tag_pattern(env, st, p_, qk, Array<crate::ast::FieldPat>{}, true, t)
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Env, crate::check_types::St>> _v;
            auto&& _m = prelude::get(env.g.ctors, qk);
            if (prism_rtl::is_none(_m)) {
                _v.set(std::tuple{env, crate::check_types::err(st, Text::lit("unknown-name"), n.span, prism_rtl::cat("`", crate::check_env::sname_key(n), "` is not a constructor"))});
                goto _done;
            }
            if (prism_rtl::is_some(_m)) {
                auto&& c = prism_rtl::some_of(_m);
                _v.set(({
                    auto [self_, st1, inst] = crate::check_types::instantiate_with(st, crate::check_types::Scheme{.qs = c.params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = c.ty}, p_.span, Array<crate::check_types::Ty>{});
                    auto st2 = crate::check_types::unify(st1, t, self_, p_.span);
                    (len(args) != len(c->args)) && (!((len(args) == Nat(1u)) && (len(c->args) > Nat(1u))))
                    ? std::tuple{env, crate::check_types::err(st2, Text::lit("mismatch"), p_.span, prism_rtl::cat("`", crate::check_types::bare_name(c.name), "` takes ", crate::check_errors::count_word(len(c->args)), " argument", len(c->args) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; this pattern gives ", crate::check_errors::count_word(len(args))))}
                    : run_to_end(fold_job(crate::check_errors::range0(len(args)), std::tuple{env, st2}, ({
                    auto args_1 = args;
                    auto p__2 = p_;
                    auto inst_3 = inst;
                    auto c_4 = c;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>>(std::tuple<std::tuple<Env, crate::check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, crate::check_types::St>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto args_1_5 = args_1;
                        auto p__2_5 = p__2;
                        auto inst_3_5 = inst_3;
                        auto c_4_5 = c_4;
                        entered(once_job([=]() {
                        return ({
                            auto [en, s] = p0;
                            auto i = p1;
                            call_then(crate::check_types::start_subst_q(inst_3_5, or_(index(c_4_5->args, i), crate::check_types::Ty(crate::check_types::Ty::TyErr{}))), [=](crate::check_types::Ty subst_q_62413) { return prism_rtl::more(prism_rtl::rc(BindPattern(en, s, or_(index(args_1_5, i), crate::ast::Pattern_{.kind = prism_rtl::rc(crate::ast::PatternKind(crate::ast::PatternKind::PIgnore{})), .span = p__2_5.span}), subst_q_62413, true))); });
                        });
                    }));
                    });
                }));
                })));
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> BindCtor::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& n = this->n;
    const auto& args = this->args;
    const auto& t = this->t;
    auto [qk_opt, why] = crate::check_env::resolve_value(env.g, env.home, n);
    return ({
        prism_rtl::is_none(qk_opt) ? prism_rtl::finished(std::tuple{env, crate::check_types::err(st, Text::lit("unknown-name"), n.span, prism_rtl::cat("no constructor `", crate::check_env::sname_key(n), "`"))})
        : prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        why == Text::lit("tag")
        ? prism_rtl::more(prism_rtl::rc(BindTagPattern(env, st, p_, qk, Array<crate::ast::FieldPat>{}, true, t)))
        : ({
        auto&& _m = prelude::get(env.g.ctors, qk);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{env, crate::check_types::err(st, Text::lit("unknown-name"), n.span, prism_rtl::cat("`", crate::check_env::sname_key(n), "` is not a constructor"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto env_2 = env;
        auto p__3 = p_;
        auto st_4 = st;
        auto t_5 = t;
        call_then(crate::check_types::start_instantiate_with(st_4, crate::check_types::Scheme{.qs = c.params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = c.ty}, p__3.span, Array<crate::check_types::Ty>{}), [=](std::tuple<crate::check_types::Ty, crate::check_types::St, crate::check_types::Inst> instantiate_with_61776) {
        return ({
            auto [self_, st1, inst] = instantiate_with_61776;
            call_then(crate::check_types::start_unify(st1, t_5, self_, p__3.span), [=](crate::check_types::St unify_61931) {
            return ({
                auto st2 = unify_61931;
                (len(args_1) != len(c->args)) && (!((len(args_1) == Nat(1u)) && (len(c->args) > Nat(1u))))
                ? prism_rtl::finished(std::tuple{env_2, crate::check_types::err(st2, Text::lit("mismatch"), p__3.span, prism_rtl::cat("`", crate::check_types::bare_name(c.name), "` takes ", crate::check_errors::count_word(len(c->args)), " argument", len(c->args) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; this pattern gives ", crate::check_errors::count_word(len(args_1))))})
                : fold_job(crate::check_errors::range0(len(args_1)), std::tuple{env_2, st2}, ({
                auto args_1_6 = args_1;
                auto p__3_6 = p__3;
                auto inst_6 = inst;
                auto c_7 = c;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>>(std::tuple<std::tuple<Env, crate::check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, crate::check_types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto args_1_6_8 = args_1_6;
                    auto p__3_6_8 = p__3_6;
                    auto inst_6_8 = inst_6;
                    auto c_7_8 = c_7;
                    entered(once_job([=]() {
                    return ({
                        auto [en, s] = p0;
                        auto i = p1;
                        call_then(crate::check_types::start_subst_q(inst_6_8, or_(index(c_7_8->args, i), crate::check_types::Ty(crate::check_types::Ty::TyErr{}))), [=](crate::check_types::Ty subst_q_62413) { return prism_rtl::more(prism_rtl::rc(BindPattern(en, s, or_(index(args_1_6_8, i), crate::ast::Pattern_{.kind = prism_rtl::rc(crate::ast::PatternKind(crate::ast::PatternKind::PIgnore{})), .span = p__3_6_8.span}), subst_q_62413, true))); });
                    });
                }));
                });
            }));
            }))->cycle();
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindCtor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_ctor(Env env, crate::check_types::St st, crate::ast::Pattern_ p_, crate::ast::SName n, Array<crate::ast::Pattern_> args, crate::check_types::Ty t) {
    return prism_rtl::make_rc<BindCtor>(env, st, p_, n, args, t);
}


/// BindRecord: unbounded fn Env, St, Pattern, SName, [FieldPat], Bool, Ty -> ((Env, St))
std::tuple<Env, crate::check_types::St> bind_record(const Env& env, const crate::check_types::St& st, const crate::ast::Pattern_& p_, const crate::ast::SName& n, const Array<crate::ast::FieldPat>& fields, const bool& rest, const crate::check_types::Ty& t) {
    auto [qk_opt, why] = crate::check_env::resolve_value(env.g, env.home, n);
    if (prism_rtl::is_none(qk_opt)) {
        return std::tuple{env, crate::check_types::err(st, Text::lit("unknown-name"), n.span, prism_rtl::cat("no record or tag `", crate::check_env::sname_key(n), "`"))};
    }
    if (prism_rtl::is_some(qk_opt)) {
        auto&& qk = prism_rtl::some_of(qk_opt);
        return why == Text::lit("tag")
            ? bind_tag_pattern(env, st, p_, qk, fields, rest, t)
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Env, crate::check_types::St>> _v;
            auto&& _m = prelude::get(env.g.ctors, qk);
            if (prism_rtl::is_none(_m)) {
                _v.set(std::tuple{env, crate::check_types::err(st, Text::lit("unknown-name"), n.span, prism_rtl::cat("`", crate::check_env::sname_key(n), "` is not a record"))});
                goto _done;
            }
            if (prism_rtl::is_some(_m)) {
                auto&& c = prism_rtl::some_of(_m);
                _v.set(({
                    auto [self_, st1, inst] = crate::check_types::instantiate_with(st, crate::check_types::Scheme{.qs = c.params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = c.ty}, p_.span, Array<crate::check_types::Ty>{});
                    auto st2 = crate::check_types::unify(st1, t, self_, p_.span);
                    run_to_end(fold_job(crate::check_errors::range0(len(fields)), std::tuple{env, st2}, ({
                    auto fields_1 = fields;
                    auto p__2 = p_;
                    auto c_3 = c;
                    auto inst_4 = inst;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>>(std::tuple<std::tuple<Env, crate::check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, crate::check_types::St>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto fields_1_5 = fields_1;
                        auto p__2_5 = p__2;
                        auto c_3_5 = c_3;
                        auto inst_4_5 = inst_4;
                        entered(once_job([=]() {
                        return ({
                            auto [en, s] = p0;
                            auto i = p1;
                            ({
                            auto fp = or_(index(fields_1_5, i), crate::ast::FieldPat{.name = std::optional<crate::ast::Ident>{}, .pattern = crate::ast::Pattern_{.kind = prism_rtl::rc(crate::ast::PatternKind(crate::ast::PatternKind::PIgnore{})), .span = p__2_5.span}, .span = p__2_5.span});
                            auto fname = field_pat_name(fp, c_3_5.fields, i);
                            ({
                            auto&& _m = index_of(c_3_5.fields, fname);
                            prism_rtl::is_some(_m) ? ({
                            auto&& j = prism_rtl::some_of(_m);
                            call_then(crate::check_types::start_subst_q(inst_4_5, or_(index(c_3_5->args, j), crate::check_types::Ty(crate::check_types::Ty::TyErr{}))), [=](crate::check_types::Ty subst_q_63766) { return prism_rtl::more(prism_rtl::rc(BindPattern(en, s, fp.pattern, subst_q_63766, true))); });
                        })
                            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en, crate::check_types::err(s, Text::lit("mismatch"), fp.span, prism_rtl::cat("`", crate::check_types::bare_name(c_3_5.owner), "` has no field `", fname, "`"))})
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                        });
                    }));
                    });
                }));
                })));
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> BindRecord::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& n = this->n;
    const auto& fields = this->fields;
    const auto& rest = this->rest;
    const auto& t = this->t;
    auto [qk_opt, why] = crate::check_env::resolve_value(env.g, env.home, n);
    return ({
        prism_rtl::is_none(qk_opt) ? prism_rtl::finished(std::tuple{env, crate::check_types::err(st, Text::lit("unknown-name"), n.span, prism_rtl::cat("no record or tag `", crate::check_env::sname_key(n), "`"))})
        : prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        why == Text::lit("tag")
        ? prism_rtl::more(prism_rtl::rc(BindTagPattern(env, st, p_, qk, fields, rest, t)))
        : ({
        auto&& _m = prelude::get(env.g.ctors, qk);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{env, crate::check_types::err(st, Text::lit("unknown-name"), n.span, prism_rtl::cat("`", crate::check_env::sname_key(n), "` is not a record"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        ({
        auto env_1 = env;
        auto fields_2 = fields;
        auto p__3 = p_;
        auto st_4 = st;
        auto t_5 = t;
        call_then(crate::check_types::start_instantiate_with(st_4, crate::check_types::Scheme{.qs = c.params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = c.ty}, p__3.span, Array<crate::check_types::Ty>{}), [=](std::tuple<crate::check_types::Ty, crate::check_types::St, crate::check_types::Inst> instantiate_with_63197) {
        return ({
            auto [self_, st1, inst] = instantiate_with_63197;
            call_then(crate::check_types::start_unify(st1, t_5, self_, p__3.span), [=](crate::check_types::St unify_63352) {
            return ({
                auto st2 = unify_63352;
                fold_job(crate::check_errors::range0(len(fields_2)), std::tuple{env_1, st2}, ({
                auto fields_2_6 = fields_2;
                auto p__3_6 = p__3;
                auto c_6 = c;
                auto inst_7 = inst;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>>(std::tuple<std::tuple<Env, crate::check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, crate::check_types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto fields_2_6_8 = fields_2_6;
                    auto p__3_6_8 = p__3_6;
                    auto c_6_8 = c_6;
                    auto inst_7_8 = inst_7;
                    entered(once_job([=]() {
                    return ({
                        auto [en, s] = p0;
                        auto i = p1;
                        ({
                        auto fp = or_(index(fields_2_6_8, i), crate::ast::FieldPat{.name = std::optional<crate::ast::Ident>{}, .pattern = crate::ast::Pattern_{.kind = prism_rtl::rc(crate::ast::PatternKind(crate::ast::PatternKind::PIgnore{})), .span = p__3_6_8.span}, .span = p__3_6_8.span});
                        auto fname = field_pat_name(fp, c_6_8.fields, i);
                        ({
                        auto&& _m = index_of(c_6_8.fields, fname);
                        prism_rtl::is_some(_m) ? ({
                        auto&& j = prism_rtl::some_of(_m);
                        call_then(crate::check_types::start_subst_q(inst_7_8, or_(index(c_6_8->args, j), crate::check_types::Ty(crate::check_types::Ty::TyErr{}))), [=](crate::check_types::Ty subst_q_63766) { return prism_rtl::more(prism_rtl::rc(BindPattern(en, s, fp.pattern, subst_q_63766, true))); });
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en, crate::check_types::err(s, Text::lit("mismatch"), fp.span, prism_rtl::cat("`", crate::check_types::bare_name(c_6_8.owner), "` has no field `", fname, "`"))})
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                    });
                }));
                });
            }));
            }))->cycle();
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindRecord, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_record(Env env, crate::check_types::St st, crate::ast::Pattern_ p_, crate::ast::SName n, Array<crate::ast::FieldPat> fields, bool rest, crate::check_types::Ty t) {
    return prism_rtl::make_rc<BindRecord>(env, st, p_, n, fields, rest, t);
}


/// FieldPatName: fn FieldPat, [Text], Nat -> Text
Text field_pat_name(const crate::ast::FieldPat& fp, const Array<Text>& fields, const Nat& i) {
    auto&& _m = fp.name;
    if (prism_rtl::is_some(_m)) {
        auto&& id = prism_rtl::some_of(_m);
        return id.name;
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = fp.pattern.kind;
        if (prism_rtl::is<crate::ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
            return crate::check_types::has_text(fields, crate::check_env::sname_key(n))
                ? crate::check_env::sname_key(n)
                : or_(index(fields, i), Text::lit(""));
        }
        {
            return or_(index(fields, i), Text::lit(""));
        }
    }
    prism_rtl::unreachable("no arm matched");
}


/// BindTagPattern: unbounded fn Env, St, Pattern, Text, [FieldPat], Bool, Ty -> ((Env, St))
std::tuple<Env, crate::check_types::St> bind_tag_pattern(const Env& env, const crate::check_types::St& st, const crate::ast::Pattern_& p_, const Text& name, const Array<crate::ast::FieldPat>& fields, const bool& rest, const crate::check_types::Ty& t) {
    auto&& _m = prelude::get(env.g.tags, name);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{env, crate::check_types::err(st, Text::lit("unknown-name"), p_.span, prism_rtl::cat("no tag `", name, "`"))};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& tg = prism_rtl::some_of(_m);
        auto st1 = tg.kind == Text::lit("Element")
            ? tag_in_row(env, st, tg, t, p_.span)
            : crate::check_types::unify(st, t, crate::check_types::Ty(crate::check_types::Ty::TyCon{tg.kind, Array<crate::check_types::Ty>{}}), p_.span);
        auto snapshot = is_snapshot(st1, t);
        auto&& _st2 = crate::check_types::instantiate_with(st1, crate::check_types::Scheme{.qs = tg.qs, .plain_qs = Array<Text>{}, .rqs = tg.rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = tg->out}, p_.span, Array<crate::check_types::Ty>{});
        auto&& st2 = std::get<1>(_st2);
        auto&& inst = std::get<2>(_st2);
        auto names = each(tg.fields, [&](const std::tuple<Text, crate::check_types::Ty>& _p0) {
            auto&& f = std::get<0>(_p0);
            return f;
        });
        return run_to_end(fold_job(crate::check_errors::range0(len(fields)), std::tuple{env, st2}, ({
            auto fields_1 = fields;
            auto p__2 = p_;
            auto names_3 = names;
            auto tg_4 = tg;
            auto inst_5 = inst;
            auto snapshot_6 = snapshot;
            auto name_7 = name;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>>(std::tuple<std::tuple<Env, crate::check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, crate::check_types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto fields_1_8 = fields_1;
                auto p__2_8 = p__2;
                auto names_3_8 = names_3;
                auto tg_4_8 = tg_4;
                auto inst_5_8 = inst_5;
                auto snapshot_6_8 = snapshot_6;
                auto name_7_8 = name_7;
                entered(once_job([=]() {
                return ({
                    auto [en, s] = p0;
                    auto i = p1;
                    ({
                    auto fp = or_(index(fields_1_8, i), crate::ast::FieldPat{.name = std::optional<crate::ast::Ident>{}, .pattern = crate::ast::Pattern_{.kind = prism_rtl::rc(crate::ast::PatternKind(crate::ast::PatternKind::PIgnore{})), .span = p__2_8.span}, .span = p__2_8.span});
                    auto fname = field_pat_name(fp, names_3_8, i);
                    ({
                    auto&& _m = field_of_tag(tg_4_8, fname);
                    prism_rtl::is_some(_m) ? ({
                    auto&& ft = prism_rtl::some_of(_m);
                    call_then(crate::check_types::start_subst_q(inst_5_8, ft), [=](crate::check_types::Ty subst_q_65452) { return prism_rtl::more(prism_rtl::rc(BindField(en, s, fp.pattern, subst_q_65452, snapshot_6_8))); });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en, crate::check_types::err(s, Text::lit("mismatch"), fp.span, prism_rtl::cat("`", name_7_8, "` has no field `", fname, "`"))})
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
                });
            }));
            });
        }));
        })));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> BindTagPattern::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& name = this->name;
    const auto& fields = this->fields;
    const auto& rest = this->rest;
    const auto& t = this->t;
    return ({
        auto&& _m = prelude::get(env.g.tags, name);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{env, crate::check_types::err(st, Text::lit("unknown-name"), p_.span, prism_rtl::cat("no tag `", name, "`"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        ({
        auto st1 = tg.kind == Text::lit("Element")
            ? tag_in_row(env, st, tg, t, p_.span)
            : crate::check_types::unify(st, t, crate::check_types::Ty(crate::check_types::Ty::TyCon{tg.kind, Array<crate::check_types::Ty>{}}), p_.span);
        auto env_1 = env;
        auto fields_2 = fields;
        auto name_3 = name;
        auto p__4 = p_;
        auto t_5 = t;
        call_then(start_is_snapshot(st1, t_5), [=](bool is_snapshot_64896) {
        return ({
            auto snapshot = is_snapshot_64896;
            call_then(crate::check_types::start_instantiate_with(st1, crate::check_types::Scheme{.qs = tg.qs, .plain_qs = Array<Text>{}, .rqs = tg.rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = tg->out}, p__4.span, Array<crate::check_types::Ty>{}), [=](std::tuple<crate::check_types::Ty, crate::check_types::St, crate::check_types::Inst> instantiate_with_64950) {
            return ({
                auto&& _st2 = instantiate_with_64950;
                auto&& st2 = std::get<1>(_st2);
                auto&& inst = std::get<2>(_st2);
                auto names = each(tg.fields, [&](const std::tuple<Text, crate::check_types::Ty>& _p0) {
                    auto&& f = std::get<0>(_p0);
                    return f;
                });
                fold_job(crate::check_errors::range0(len(fields_2)), std::tuple{env_1, st2}, ({
                auto fields_2_6 = fields_2;
                auto p__4_6 = p__4;
                auto names_6 = names;
                auto tg_7 = tg;
                auto inst_8 = inst;
                auto snapshot_9 = snapshot;
                auto name_3_10 = name_3;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>>(std::tuple<std::tuple<Env, crate::check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, crate::check_types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto fields_2_6_10 = fields_2_6;
                    auto p__4_6_10 = p__4_6;
                    auto names_6_10 = names_6;
                    auto tg_7_10 = tg_7;
                    auto inst_8_10 = inst_8;
                    auto snapshot_9_10 = snapshot_9;
                    auto name_3_10_10 = name_3_10;
                    entered(once_job([=]() {
                    return ({
                        auto [en, s] = p0;
                        auto i = p1;
                        ({
                        auto fp = or_(index(fields_2_6_10, i), crate::ast::FieldPat{.name = std::optional<crate::ast::Ident>{}, .pattern = crate::ast::Pattern_{.kind = prism_rtl::rc(crate::ast::PatternKind(crate::ast::PatternKind::PIgnore{})), .span = p__4_6_10.span}, .span = p__4_6_10.span});
                        auto fname = field_pat_name(fp, names_6_10, i);
                        ({
                        auto&& _m = field_of_tag(tg_7_10, fname);
                        prism_rtl::is_some(_m) ? ({
                        auto&& ft = prism_rtl::some_of(_m);
                        call_then(crate::check_types::start_subst_q(inst_8_10, ft), [=](crate::check_types::Ty subst_q_65452) { return prism_rtl::more(prism_rtl::rc(BindField(en, s, fp.pattern, subst_q_65452, snapshot_9_10))); });
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en, crate::check_types::err(s, Text::lit("mismatch"), fp.span, prism_rtl::cat("`", name_3_10_10, "` has no field `", fname, "`"))})
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                    });
                }));
                });
            }));
            }))->cycle();
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindTagPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_tag_pattern(Env env, crate::check_types::St st, crate::ast::Pattern_ p_, Text name, Array<crate::ast::FieldPat> fields, bool rest, crate::check_types::Ty t) {
    return prism_rtl::make_rc<BindTagPattern>(env, st, p_, name, fields, rest, t);
}


/// IsSnapshot: unbounded fn St, Ty -> Bool
bool is_snapshot(const crate::check_types::St& st, const crate::check_types::Ty& t) {
    auto&& _m = crate::check_types::walk(st, t);
    if (prism_rtl::is<crate::check_types::Ty::TyElemAny>(_m)) {
        return true;
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsSnapshot::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(crate::check_types::start_walk(st_1, t_2), [=](crate::check_types::Ty walk_65789) {
        return ({
            prism_rtl::is<crate::check_types::Ty::TyElemAny>(walk_65789) ? prism_rtl::finished(true)
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsSnapshot, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_snapshot(crate::check_types::St st, crate::check_types::Ty t) {
    return prism_rtl::make_rc<IsSnapshot>(st, t);
}


/// TagInRow: unbounded fn Env, St, TagInfo, Ty, Range -> St
crate::check_types::St tag_in_row(const Env& env, const crate::check_types::St& st, const crate::check_env::TagInfo& tg, const crate::check_types::Ty& t, const crate::ast::Range& span) {
    auto&& _m = crate::check_types::walk(st, t);
    if (prism_rtl::is<crate::check_types::Ty::TyElem>(_m)) {
        auto&& rw = prism_rtl::as<crate::check_types::Ty::TyElem>(_m).a0;
        auto w = crate::check_types::walk_row(st, rw);
        return crate::check_types::has_text(w.fams, tg.family)
            ? st
            : crate::check_types::err_fix(st, Text::lit("row-not-here"), span, prism_rtl::cat("`", tg.name, "` is not in this row, `", crate::check_types::show_row(w), "`"), prism_rtl::cat("add `", tg.family, ".*` to the row, or answer the tag elsewhere"));
    }
    if (prism_rtl::is<crate::check_types::Ty::TyElemAny>(_m)) {
        auto&& rw = prism_rtl::as<crate::check_types::Ty::TyElemAny>(_m).a0;
        auto w = crate::check_types::walk_row(st, rw);
        return crate::check_types::has_text(w.fams, tg.family)
            ? st
            : crate::check_types::err_fix(st, Text::lit("row-not-here"), span, prism_rtl::cat("`", tg.name, "` is not in this row, `", crate::check_types::show_row(w), "`"), prism_rtl::cat("add `", tg.family, ".*` to the row, or answer the tag elsewhere"));
    }
    if (prism_rtl::is<crate::check_types::Ty::TyFlex>(_m)) {
        auto [rw, st2] = crate::check_types::fresh_row(st, Array(std::vector{tg.family}));
        auto [o, st3] = crate::check_types::fresh_var(st2, false, Text::lit(""));
        return crate::check_types::unify(st3, t, crate::check_types::Ty(crate::check_types::Ty::TyElem{crate::check_types::Rw{.fams = Array(std::vector{tg.family}), .minus = Array<Text>{}, .tail = rw.tail}, prism_rtl::rc(o)}), span);
    }
    if (prism_rtl::is<crate::check_types::Ty::TyErr>(_m)) {
        return st;
    }
    {
        auto&& other = _m;
        return crate::check_types::err(st, Text::lit("mismatch"), span, prism_rtl::cat("a tag pattern matches an element; this is `", crate::check_types::show_ty(st, other), "`"));
    }
}


prism_rtl::Turn<crate::check_types::St> TagInRow::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& tg = this->tg;
    const auto& t = this->t;
    const auto& span = this->span;
    auto span_1 = span;
    auto st_2 = st;
    auto t_3 = t;
    auto tg_4 = tg;
    return call_then(crate::check_types::start_walk(st_2, t_3), [=](crate::check_types::Ty walk_65948) {
        return ({
            prism_rtl::is<crate::check_types::Ty::TyElem>(walk_65948) ? ({
            auto&& rw = prism_rtl::as<crate::check_types::Ty::TyElem>(walk_65948).a0;
            call_then(crate::check_types::start_walk_row(st_2, rw), [=](crate::check_types::Rw walk_row_65999) {
            return ({
                auto w = walk_row_65999;
                (crate::check_types::has_text(w.fams, tg_4.family)
                ? prism_rtl::finished(st_2)
                : prism_rtl::finished(crate::check_types::err_fix(st_2, Text::lit("row-not-here"), span_1, prism_rtl::cat("`", tg_4.name, "` is not in this row, `", crate::check_types::show_row(w), "`"), prism_rtl::cat("add `", tg_4.family, ".*` to the row, or answer the tag elsewhere"))));
            });
        });
        })
            : prism_rtl::is<crate::check_types::Ty::TyElemAny>(walk_65948) ? ({
            auto&& rw = prism_rtl::as<crate::check_types::Ty::TyElemAny>(walk_65948).a0;
            call_then(crate::check_types::start_walk_row(st_2, rw), [=](crate::check_types::Rw walk_row_66247) {
            return ({
                auto w = walk_row_66247;
                (crate::check_types::has_text(w.fams, tg_4.family)
                ? prism_rtl::finished(st_2)
                : prism_rtl::finished(crate::check_types::err_fix(st_2, Text::lit("row-not-here"), span_1, prism_rtl::cat("`", tg_4.name, "` is not in this row, `", crate::check_types::show_row(w), "`"), prism_rtl::cat("add `", tg_4.family, ".*` to the row, or answer the tag elsewhere"))));
            });
        });
        })
            : prism_rtl::is<crate::check_types::Ty::TyFlex>(walk_65948) ? ({
            auto [rw, st2] = crate::check_types::fresh_row(st_2, Array(std::vector{tg_4.family}));
            auto [o, st3] = crate::check_types::fresh_var(st2, false, Text::lit(""));
            (prism_rtl::more(prism_rtl::rc(crate::check_types::Unify(st3, t_3, crate::check_types::Ty(crate::check_types::Ty::TyElem{crate::check_types::Rw{.fams = Array(std::vector{tg_4.family}), .minus = Array<Text>{}, .tail = rw.tail}, prism_rtl::rc(o)}), span_1))));
        })
            : prism_rtl::is<crate::check_types::Ty::TyErr>(walk_65948) ? prism_rtl::finished(st_2)
            : ({
            auto&& other = walk_65948;
            call_then(crate::check_types::start_show_ty(st_2, other), [=](Text show_ty_66769) { return prism_rtl::finished(crate::check_types::err(st_2, Text::lit("mismatch"), span_1, prism_rtl::cat("a tag pattern matches an element; this is `", show_ty_66769, "`"))); });
        });
        });
    });
}


/// `Start TagInRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::St> start_tag_in_row(Env env, crate::check_types::St st, crate::check_env::TagInfo tg, crate::check_types::Ty t, crate::ast::Range span) {
    return prism_rtl::make_rc<TagInRow>(env, st, tg, t, span);
}


/// BindFamily: unbounded fn Env, St, Text, Ty, Range -> ((Env, St))
std::tuple<Env, crate::check_types::St> bind_family(const Env& env, const crate::check_types::St& st, const Text& fam, const crate::check_types::Ty& t, const crate::ast::Range& span) {
    auto&& _m = crate::check_types::walk(st, t);
    if (prism_rtl::is<crate::check_types::Ty::TyElem>(_m)) {
        auto&& rw = prism_rtl::as<crate::check_types::Ty::TyElem>(_m).a0;
        auto w = crate::check_types::walk_row(st, rw);
        return crate::check_types::has_text(w.fams, fam)
            ? std::tuple{env, st}
            : std::tuple{env, crate::check_types::err_fix(st, Text::lit("row-not-here"), span, prism_rtl::cat("`", fam, ".*` is not in this row, `", crate::check_types::show_row(w), "`"), prism_rtl::cat("add `", fam, ".*` to the row"))};
    }
    {
        return std::tuple{env, st};
    }
}


prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> BindFamily::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& fam = this->fam;
    const auto& t = this->t;
    const auto& span = this->span;
    auto env_1 = env;
    auto fam_2 = fam;
    auto span_3 = span;
    auto st_4 = st;
    auto t_5 = t;
    return call_then(crate::check_types::start_walk(st_4, t_5), [=](crate::check_types::Ty walk_66899) {
        return ({
            prism_rtl::is<crate::check_types::Ty::TyElem>(walk_66899) ? ({
            auto&& rw = prism_rtl::as<crate::check_types::Ty::TyElem>(walk_66899).a0;
            call_then(crate::check_types::start_walk_row(st_4, rw), [=](crate::check_types::Rw walk_row_66950) {
            return ({
                auto w = walk_row_66950;
                (crate::check_types::has_text(w.fams, fam_2)
                ? prism_rtl::finished(std::tuple{env_1, st_4})
                : prism_rtl::finished(std::tuple{env_1, crate::check_types::err_fix(st_4, Text::lit("row-not-here"), span_3, prism_rtl::cat("`", fam_2, ".*` is not in this row, `", crate::check_types::show_row(w), "`"), prism_rtl::cat("add `", fam_2, ".*` to the row"))}));
            });
        });
        })
            : prism_rtl::finished(std::tuple{env_1, st_4});
        });
    });
}


/// `Start BindFamily, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_family(Env env, crate::check_types::St st, Text fam, crate::check_types::Ty t, crate::ast::Range span) {
    return prism_rtl::make_rc<BindFamily>(env, st, fam, t, span);
}


/// InferMatch: unbounded fn Env, St, Expr, [Arm], Range, ?Ty -> ((Ty, St))
std::tuple<crate::check_types::Ty, crate::check_types::St> infer_match(const Env& env, const crate::check_types::St& st, const crate::ast::Expr& scrut, const Array<crate::ast::Arm>& arms, const crate::ast::Range& span, const std::optional<crate::check_types::Ty>& expected_opt) {
    auto [st_ty, st1] = infer(env, st, scrut);
    auto sh = crate::check_types::head_sigil(st1, st_ty);
    auto plain_scrut = is_time_sigil(sh) ? inner_of(st1, st_ty) : st_ty;
    auto st2 = sh == Text::lit("@")
        ? crate::check_types::err(st1, Text::lit("blueprint-operand"), scrut.span, Text::lit("`match` over a blueprint; bind it first"))
        : st1;
    auto rigid_out_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        auto&& _m = crate::check_types::walk(st2, plain_scrut);
        if (prism_rtl::is<crate::check_types::Ty::TyElem>(_m)) {
            auto&& o = prism_rtl::as<crate::check_types::Ty::TyElem>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<Text>> _v;
                auto&& _m = crate::check_types::walk(st2, o);
                if (prism_rtl::is<crate::check_types::Ty::TyRigid>(_m)) {
                    auto&& name = prism_rtl::as<crate::check_types::Ty::TyRigid>(_m).a0;
                    _v.set(std::optional(name));
                    goto _done;
                }
                {
                    _v.set(std::optional<Text>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [res, st3] = crate::check_types::fresh_var(st2, false, Text::lit(""));
    auto checking = (expected_opt != std::optional<crate::check_types::Ty>{}) && (!is_time_sigil(sh));
    auto scrut_name = crate::check_passes::expr_name(scrut);
    auto&& _layers = run_to_end(fold_job(arms, std::tuple{Array<std::tuple<Text, crate::ast::Range>>{}, st3, Array<Text>{}}, ({
        auto env_1 = env;
        auto scrut_name_2 = scrut_name;
        auto plain_scrut_3 = plain_scrut;
        auto res_4 = res;
        auto checking_5 = checking;
        auto expected_opt_6 = expected_opt;
        auto rigid_out_opt_7 = rigid_out_opt;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St, Array<Text>>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St, Array<Text>>, crate::ast::Arm>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St, Array<Text>>, crate::ast::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_8 = env_1;
            auto scrut_name_2_8 = scrut_name_2;
            auto plain_scrut_3_8 = plain_scrut_3;
            auto res_4_8 = res_4;
            auto checking_5_8 = checking_5;
            auto expected_opt_6_8 = expected_opt_6;
            auto rigid_out_opt_7_8 = rigid_out_opt_7;
            entered(once_job([=]() {
            return ({
                auto [acc, s, taken] = p0;
                auto arm = p1;
                call_then(start_narrowed(env_1_8, s, arm, scrut_name_2_8, plain_scrut_3_8, taken), [=](Env narrowed_68498) {
                return ({
                    auto env_arm = narrowed_68498;
                    call_then(start_infer_arm(env_arm, s, arm, plain_scrut_3_8, res_4_8, checking_5_8 ? expected_opt_6_8 : std::optional<crate::check_types::Ty>{}, rigid_out_opt_7_8, acc), [=](std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St> infer_arm_68576) {
                    return ({
                        auto [acc2, s2] = infer_arm_68576;
                        (prism_rtl::finished(std::tuple{acc2, s2, taken_by(env_1_8, arm, taken)}));
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })));
    auto&& layers = std::get<0>(_layers);
    auto&& st4 = std::get<1>(_layers);
    auto st5 = crate::check_passes::match_coverage(env, st4, plain_scrut, arms, span);
    if (prism_rtl::is_some(expected_opt)) {
        auto&& want = prism_rtl::some_of(expected_opt);
        return checking
            ? std::tuple{want, st5}
            : match_result(env, st5, sh, layers, res, span);
    }
    if (prism_rtl::is_none(expected_opt)) {
        return match_result(env, st5, sh, layers, res, span);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> InferMatch::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& scrut = this->scrut;
    const auto& arms = this->arms;
    const auto& span = this->span;
    const auto& expected_opt = this->expected_opt;
    auto expected_opt_1 = expected_opt;
    auto arms_2 = arms;
    auto env_3 = env;
    auto scrut_4 = scrut;
    auto span_5 = span;
    auto st_6 = st;
    return call_then(start_infer(env_3, st_6, scrut_4), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_67821) {
        return ({
            auto [st_ty, st1] = infer_67821;
            call_then(crate::check_types::start_head_sigil(st1, st_ty), [=](Text head_sigil_67855) {
            return ({
                auto sh = head_sigil_67855;
                auto plain_scrut = is_time_sigil(sh) ? inner_of(st1, st_ty) : st_ty;
                auto st2 = sh == Text::lit("@")
                    ? crate::check_types::err(st1, Text::lit("blueprint-operand"), scrut_4.span, Text::lit("`match` over a blueprint; bind it first"))
                    : st1;
                call_then(crate::check_types::start_walk(st2, plain_scrut), [=](crate::check_types::Ty walk_68092) {
                return ({
                    auto rigid_out_opt = ({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<Text>> _v;
                        if (prism_rtl::is<crate::check_types::Ty::TyElem>(walk_68092)) {
                            auto&& o = prism_rtl::as<crate::check_types::Ty::TyElem>(walk_68092).a1;
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<std::optional<Text>> _v;
                                auto&& _m = crate::check_types::walk(st2, o);
                                if (prism_rtl::is<crate::check_types::Ty::TyRigid>(_m)) {
                                    auto&& name = prism_rtl::as<crate::check_types::Ty::TyRigid>(_m).a0;
                                    _v.set(std::optional(name));
                                    goto _done;
                                }
                                {
                                    _v.set(std::optional<Text>{});
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::optional<Text>{});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    auto [res, st3] = crate::check_types::fresh_var(st2, false, Text::lit(""));
                    auto checking = (expected_opt_1 != std::optional<crate::check_types::Ty>{}) && (!is_time_sigil(sh));
                    auto scrut_name = crate::check_passes::expr_name(scrut_4);
                    call_value(fold_job(arms_2, std::tuple{Array<std::tuple<Text, crate::ast::Range>>{}, st3, Array<Text>{}}, ({
                    auto env_3_7 = env_3;
                    auto scrut_name_7 = scrut_name;
                    auto plain_scrut_8 = plain_scrut;
                    auto res_9 = res;
                    auto checking_10 = checking;
                    auto expected_opt_1_11 = expected_opt_1;
                    auto rigid_out_opt_11 = rigid_out_opt;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St, Array<Text>>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St, Array<Text>>, crate::ast::Arm>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St, Array<Text>>, crate::ast::Arm> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_3_7_12 = env_3_7;
                        auto scrut_name_7_12 = scrut_name_7;
                        auto plain_scrut_8_12 = plain_scrut_8;
                        auto res_9_12 = res_9;
                        auto checking_10_12 = checking_10;
                        auto expected_opt_1_11_12 = expected_opt_1_11;
                        auto rigid_out_opt_11_12 = rigid_out_opt_11;
                        entered(once_job([=]() {
                        return ({
                            auto [acc, s, taken] = p0;
                            auto arm = p1;
                            call_then(start_narrowed(env_3_7_12, s, arm, scrut_name_7_12, plain_scrut_8_12, taken), [=](Env narrowed_68498) {
                            return ({
                                auto env_arm = narrowed_68498;
                                call_then(start_infer_arm(env_arm, s, arm, plain_scrut_8_12, res_9_12, checking_10_12
                                ? expected_opt_1_11_12
                                : std::optional<crate::check_types::Ty>{}, rigid_out_opt_11_12, acc), [=](std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St> infer_arm_68576) {
                                return ({
                                    auto [acc2, s2] = infer_arm_68576;
                                    (prism_rtl::finished(std::tuple{acc2, s2, taken_by(env_3_7_12, arm, taken)}));
                                });
                            });
                            });
                        });
                        });
                    }));
                    });
                }));
                })), [=](std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St, Array<Text>> fold_68419) {
                    return ({
                        auto&& _layers = fold_68419;
                        auto&& layers = std::get<0>(_layers);
                        auto&& st4 = std::get<1>(_layers);
                        call_then(crate::check_passes::start_match_coverage(env_3, st4, plain_scrut, arms_2, span_5), [=](crate::check_types::St match_coverage_68731) {
                        return ({
                            auto st5 = match_coverage_68731;
                            ({
                            prism_rtl::is_some(expected_opt_1) ? ({
                            auto&& want = prism_rtl::some_of(expected_opt_1);
                            checking
                            ? prism_rtl::finished(std::tuple{want, st5})
                            : prism_rtl::more(prism_rtl::rc(MatchResult(env_3, st5, sh, layers, res, span_5)));
                        })
                            : prism_rtl::is_none(expected_opt_1) ? prism_rtl::more(prism_rtl::rc(MatchResult(env_3, st5, sh, layers, res, span_5)))
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start InferMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_match(Env env, crate::check_types::St st, crate::ast::Expr scrut, Array<crate::ast::Arm> arms, crate::ast::Range span, std::optional<crate::check_types::Ty> expected_opt) {
    return prism_rtl::make_rc<InferMatch>(env, st, scrut, arms, span, expected_opt);
}


/// TakenBy: fn Env, Arm, [Text] -> [Text]
Array<Text> taken_by(const Env& env, const crate::ast::Arm& arm, const Array<Text>& taken) {
    return arm.guard != std::optional<crate::ast::Expr>{}
        ? taken
        : ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = arm.pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                auto&& _m = p_.kind;
                if (prism_rtl::is<crate::ast::PatternKind::PFamily>(_m)) {
                    auto&& q = prism_rtl::as<crate::ast::PatternKind::PFamily>(_m).a0;
                    _v.set(crate::check_types::union_texts(taken, or_(prelude::get(env.g.families, crate::check_env::dotted(q->path_)), Array<Text>{})));
                    goto _done;
                }
                {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        auto&& _m = tag_of_pattern(env, p_);
                        if (prism_rtl::is_some(_m)) {
                            auto&& tg = prism_rtl::some_of(_m);
                            _v.set(crate::check_types::add_text(taken, tg.name));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(taken);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(taken);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// Narrowed: unbounded fn Env, St, Arm, Text, Ty, [Text] -> Env
Env narrowed(const Env& env, const crate::check_types::St& st, const crate::ast::Arm& arm, const Text& name, const crate::check_types::Ty& t, const Array<Text>& taken) {
    auto forwards = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = arm.pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = p_.kind;
                if (prism_rtl::is<crate::ast::PatternKind::PFamily>(_m)) {
                    _v.set(true);
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(true);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ((!forwards) || (name == Text::lit(""))) || (len(taken) == Nat(0u))
        ? env
        : ({
        __label__ _done;
        prism_rtl::Slot<Env> _v;
        auto&& _m = crate::check_types::walk(st, t);
        if (prism_rtl::is<crate::check_types::Ty::TyElem>(_m)) {
            auto&& rw = prism_rtl::as<crate::check_types::Ty::TyElem>(_m).a0;
            auto&& o = prism_rtl::as<crate::check_types::Ty::TyElem>(_m).a1;
            _v.set(({
                auto w = crate::check_types::walk_row(st, rw);
                with_local(env, name, crate::check_types::mono(crate::check_types::Ty(crate::check_types::Ty::TyElem{crate::check_types::Rw{.fams = w.fams, .minus = crate::check_types::union_texts(w.minus, taken), .tail = w.tail}, prism_rtl::rc(o)})));
            }));
            goto _done;
        }
        {
            _v.set(env);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Env> Narrowed::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& arm = this->arm;
    const auto& name = this->name;
    const auto& t = this->t;
    const auto& taken = this->taken;
    auto forwards = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = arm.pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = p_.kind;
                if (prism_rtl::is<crate::ast::PatternKind::PFamily>(_m)) {
                    _v.set(true);
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(true);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ((!forwards) || (name == Text::lit(""))) || (len(taken) == Nat(0u))
        ? prism_rtl::finished(env)
        : ({
        auto arm_1 = arm;
        auto env_2 = env;
        auto name_3 = name;
        auto st_4 = st;
        auto t_5 = t;
        auto taken_6 = taken;
        call_then(crate::check_types::start_walk(st_4, t_5), [=](crate::check_types::Ty walk_69916) {
        return ({
            prism_rtl::is<crate::check_types::Ty::TyElem>(walk_69916) ? ({
            auto&& rw = prism_rtl::as<crate::check_types::Ty::TyElem>(walk_69916).a0;
            auto&& o = prism_rtl::as<crate::check_types::Ty::TyElem>(walk_69916).a1;
            call_then(crate::check_types::start_walk_row(st_4, rw), [=](crate::check_types::Rw walk_row_69970) {
            return ({
                auto w = walk_row_69970;
                (prism_rtl::finished(with_local(env_2, name_3, crate::check_types::mono(crate::check_types::Ty(crate::check_types::Ty::TyElem{crate::check_types::Rw{.fams = w.fams, .minus = crate::check_types::union_texts(w.minus, taken_6), .tail = w.tail}, prism_rtl::rc(o)})))));
            });
        });
        })
            : prism_rtl::finished(env_2);
        });
    });
    });
}


/// `Start Narrowed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Env> start_narrowed(Env env, crate::check_types::St st, crate::ast::Arm arm, Text name, crate::check_types::Ty t, Array<Text> taken) {
    return prism_rtl::make_rc<Narrowed>(env, st, arm, name, t, taken);
}


/// InferArm: unbounded fn Env, St, Arm, Ty, Ty, ?Ty, ?Text, [((Text, Range))] -> (([((Text, Range))], St))
std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St> infer_arm(const Env& env, const crate::check_types::St& st, const crate::ast::Arm& arm, const crate::check_types::Ty& scrut_ty, const crate::check_types::Ty& res, const std::optional<crate::check_types::Ty>& expected_opt, const std::optional<Text>& rigid_out_opt, const Array<std::tuple<Text, crate::ast::Range>>& acc) {
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Env, crate::check_types::St>> _v;
        auto&& _m = arm.pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            _v.set(bind_pattern(env, st, p_, scrut_ty, true));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{env, st});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto refined_out_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<std::tuple<Text, crate::check_types::Ty>>> _v;
        if (prism_rtl::is_some(rigid_out_opt)) {
            auto&& o = prism_rtl::some_of(rigid_out_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<std::tuple<Text, crate::check_types::Ty>>> _v;
                auto&& _m = arm.pattern;
                if (prism_rtl::is_some(_m)) {
                    auto&& p_ = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<std::tuple<Text, crate::check_types::Ty>>> _v;
                        auto&& _m = tag_of_pattern(env, p_);
                        if (prism_rtl::is_some(_m)) {
                            auto&& tg = prism_rtl::some_of(_m);
                            _v.set(std::optional(std::tuple{o, tg->out}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<std::tuple<Text, crate::check_types::Ty>>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional<std::tuple<Text, crate::check_types::Ty>>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(rigid_out_opt)) {
            _v.set(std::optional<std::tuple<Text, crate::check_types::Ty>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check_types::St> _v;
        auto&& _m = arm.guard;
        if (prism_rtl::is_some(_m)) {
            auto&& gd = prism_rtl::some_of(_m);
            _v.set(check_cond(env2, st1, gd));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st1);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is_some(expected_opt)) {
        auto&& want = prism_rtl::some_of(expected_opt);
        auto refined = ({
            __label__ _done;
            prism_rtl::Slot<crate::check_types::Ty> _v;
            if (prism_rtl::is_some(refined_out_opt)) {
                auto&& o = std::get<0>(prism_rtl::some_of(refined_out_opt));
                auto&& out = std::get<1>(prism_rtl::some_of(refined_out_opt));
                _v.set(subst_rigid(o, out, crate::check_types::zonk(st2, want)));
                goto _done;
            }
            if (prism_rtl::is_none(refined_out_opt)) {
                _v.set(want);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto [bt, st3] = infer_expr_block(env2, st2, arm.body);
        return std::tuple{acc, arm_against(st3, refined, bt, arm.body.span, (arm.pattern == std::optional<crate::ast::Pattern_>{}) || is_family_arm(arm))};
    }
    if (prism_rtl::is_none(expected_opt)) {
        auto [bt, st3] = infer_expr_block(env2, st2, arm.body);
        auto head = crate::check_types::head_sigil(st3, bt);
        auto plain_bt = is_time_sigil(head) ? inner_of(st3, bt) : bt;
        auto st4 = unify_arm(st3, res, plain_bt, arm.body.span);
        auto acc2 = is_time_sigil(head)
            ? prelude::push(acc, std::tuple{head, arm.body.span})
            : prelude::push(acc, std::tuple{Text::lit(""), arm.body.span});
        auto acc3 = head == Text::lit("@")
            ? prelude::push(acc2, std::tuple{Text::lit("@"), arm.body.span})
            : acc2;
        return std::tuple{acc3, st4};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St>> InferArm::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& arm = this->arm;
    const auto& scrut_ty = this->scrut_ty;
    const auto& res = this->res;
    const auto& expected_opt = this->expected_opt;
    const auto& rigid_out_opt = this->rigid_out_opt;
    const auto& acc = this->acc;
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Env, crate::check_types::St>> _v;
        auto&& _m = arm.pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            _v.set(bind_pattern(env, st, p_, scrut_ty, true));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{env, st});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto refined_out_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<std::tuple<Text, crate::check_types::Ty>>> _v;
        if (prism_rtl::is_some(rigid_out_opt)) {
            auto&& o = prism_rtl::some_of(rigid_out_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<std::tuple<Text, crate::check_types::Ty>>> _v;
                auto&& _m = arm.pattern;
                if (prism_rtl::is_some(_m)) {
                    auto&& p_ = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<std::tuple<Text, crate::check_types::Ty>>> _v;
                        auto&& _m = tag_of_pattern(env, p_);
                        if (prism_rtl::is_some(_m)) {
                            auto&& tg = prism_rtl::some_of(_m);
                            _v.set(std::optional(std::tuple{o, tg->out}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<std::tuple<Text, crate::check_types::Ty>>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional<std::tuple<Text, crate::check_types::Ty>>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(rigid_out_opt)) {
            _v.set(std::optional<std::tuple<Text, crate::check_types::Ty>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check_types::St> _v;
        auto&& _m = arm.guard;
        if (prism_rtl::is_some(_m)) {
            auto&& gd = prism_rtl::some_of(_m);
            _v.set(check_cond(env2, st1, gd));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st1);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        prism_rtl::is_some(expected_opt) ? ({
        auto&& want = prism_rtl::some_of(expected_opt);
        ({
        auto refined = ({
            __label__ _done;
            prism_rtl::Slot<crate::check_types::Ty> _v;
            if (prism_rtl::is_some(refined_out_opt)) {
                auto&& o = std::get<0>(prism_rtl::some_of(refined_out_opt));
                auto&& out = std::get<1>(prism_rtl::some_of(refined_out_opt));
                _v.set(subst_rigid(o, out, crate::check_types::zonk(st2, want)));
                goto _done;
            }
            if (prism_rtl::is_none(refined_out_opt)) {
                _v.set(want);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto acc_1 = acc;
        auto arm_2 = arm;
        call_then(start_infer_expr_block(env2, st2, arm_2.body), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_expr_block_71066) {
        return ({
            auto [bt, st3] = infer_expr_block_71066;
            call_then(start_arm_against(st3, refined, bt, arm_2.body.span, (arm_2.pattern == std::optional<crate::ast::Pattern_>{}) || is_family_arm(arm_2)), [=](crate::check_types::St arm_against_71121) { return prism_rtl::finished(std::tuple{acc_1, arm_against_71121}); });
        });
    });
    });
    })
        : prism_rtl::is_none(expected_opt) ? ({
        auto acc_1 = acc;
        auto arm_2 = arm;
        auto res_3 = res;
        call_then(start_infer_expr_block(env2, st2, arm_2.body), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_expr_block_71254) {
        return ({
            auto [bt, st3] = infer_expr_block_71254;
            call_then(crate::check_types::start_head_sigil(st3, bt), [=](Text head_sigil_71312) {
            return ({
                auto head = head_sigil_71312;
                auto plain_bt = is_time_sigil(head) ? inner_of(st3, bt) : bt;
                call_then(start_unify_arm(st3, res_3, plain_bt, arm_2.body.span), [=](crate::check_types::St unify_arm_71424) {
                return ({
                    auto st4 = unify_arm_71424;
                    auto acc2 = is_time_sigil(head)
                        ? prelude::push(acc_1, std::tuple{head, arm_2.body.span})
                        : prelude::push(acc_1, std::tuple{Text::lit(""), arm_2.body.span});
                    auto acc3 = head == Text::lit("@")
                        ? prelude::push(acc2, std::tuple{Text::lit("@"), arm_2.body.span})
                        : acc2;
                    (prism_rtl::finished(std::tuple{acc3, st4}));
                });
            });
            });
        });
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St>> start_infer_arm(Env env, crate::check_types::St st, crate::ast::Arm arm, crate::check_types::Ty scrut_ty, crate::check_types::Ty res, std::optional<crate::check_types::Ty> expected_opt, std::optional<Text> rigid_out_opt, Array<std::tuple<Text, crate::ast::Range>> acc) {
    return prism_rtl::make_rc<InferArm>(env, st, arm, scrut_ty, res, expected_opt, rigid_out_opt, acc);
}


/// ArmAgainst: unbounded fn St, Ty, Ty, Range, Bool -> St
crate::check_types::St arm_against(const crate::check_types::St& st, const crate::check_types::Ty& want, const crate::check_types::Ty& bt, const crate::ast::Range& span, const bool& forwards) {
    auto&& _m = std::tuple{crate::check_types::walk(st, want), crate::check_types::walk(st, bt)};
    if (prism_rtl::is<crate::check_types::Ty::TyAt>(std::get<0>(_m)) && prism_rtl::is<crate::check_types::Ty::TyAt>(std::get<1>(_m))) {
        auto&& w1 = prism_rtl::as<crate::check_types::Ty::TyAt>(std::get<0>(_m)).a0;
        auto&& r1 = prism_rtl::as<crate::check_types::Ty::TyAt>(std::get<0>(_m)).a1;
        auto&& b1 = prism_rtl::as<crate::check_types::Ty::TyAt>(std::get<1>(_m)).a0;
        auto&& r2 = prism_rtl::as<crate::check_types::Ty::TyAt>(std::get<1>(_m)).a1;
        auto st2 = crate::check_types::unify(st, w1, b1, span);
        crate::check_types::St this_ = st2;
        this_.incls = prelude::push(this_.incls, crate::check_types::Incl{.sub = r2, .sup = r1, .file = this_.file, .span = span, .what = Text::lit("arm"), .forward = forwards});
        return this_;
    }
    {
        return crate::check_types::unify(st, want, bt, span);
    }
}


prism_rtl::Turn<crate::check_types::St> ArmAgainst::cycle() const {
    const auto& st = this->st;
    const auto& want = this->want;
    const auto& bt = this->bt;
    const auto& span = this->span;
    const auto& forwards = this->forwards;
    auto bt_1 = bt;
    auto forwards_2 = forwards;
    auto span_3 = span;
    auto st_4 = st;
    auto want_5 = want;
    return call_then(crate::check_types::start_walk(st_4, want_5), [=](crate::check_types::Ty walk_71978) {
        return call_then(crate::check_types::start_walk(st_4, bt_1), [=](crate::check_types::Ty walk_71995) {
            return ({
                auto&& _m = std::tuple{walk_71978, walk_71995};
                prism_rtl::is<crate::check_types::Ty::TyAt>(std::get<0>(_m)) && prism_rtl::is<crate::check_types::Ty::TyAt>(std::get<1>(_m)) ? ({
                auto&& w1 = prism_rtl::as<crate::check_types::Ty::TyAt>(std::get<0>(_m)).a0;
                auto&& r1 = prism_rtl::as<crate::check_types::Ty::TyAt>(std::get<0>(_m)).a1;
                auto&& b1 = prism_rtl::as<crate::check_types::Ty::TyAt>(std::get<1>(_m)).a0;
                auto&& r2 = prism_rtl::as<crate::check_types::Ty::TyAt>(std::get<1>(_m)).a1;
                call_then(crate::check_types::start_unify(st_4, w1, b1, span_3), [=](crate::check_types::St unify_72067) {
                return ({
                    auto st2 = unify_72067;
                    (prism_rtl::finished(({
                    crate::check_types::St this_ = st2;
                    this_.incls = prelude::push(this_.incls, crate::check_types::Incl{.sub = r2, .sup = r1, .file = this_.file, .span = span_3, .what = Text::lit("arm"), .forward = forwards_2});
                    this_;
                })));
                });
            });
            })
                : prism_rtl::more(prism_rtl::rc(crate::check_types::Unify(st_4, want_5, bt_1, span_3)));
            });
        });
    });
}


/// `Start ArmAgainst, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::St> start_arm_against(crate::check_types::St st, crate::check_types::Ty want, crate::check_types::Ty bt, crate::ast::Range span, bool forwards) {
    return prism_rtl::make_rc<ArmAgainst>(st, want, bt, span, forwards);
}


/// IsFamilyArm: fn Arm -> Bool
bool is_family_arm(const crate::ast::Arm& arm) {
    auto&& _m = arm.pattern;
    if (prism_rtl::is_some(_m)) {
        auto&& p_ = prism_rtl::some_of(_m);
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::ast::PatternKind::PFamily>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CheckCond: unbounded fn Env, St, Expr -> St
crate::check_types::St check_cond(const Env& env, const crate::check_types::St& st, const crate::ast::Expr& e) {
    auto [t, st2] = infer(env, st, e);
    auto inner = is_time_sigil(crate::check_types::head_sigil(st2, t))
        ? inner_of(st2, t)
        : t;
    return crate::check_types::unify(st2, crate::check_types::t_bool(), inner, e.span);
}


prism_rtl::Turn<crate::check_types::St> CheckCond::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    auto e_1 = e;
    auto env_2 = env;
    auto st_3 = st;
    return call_then(start_infer(env_2, st_3, e_1), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_72604) {
        return ({
            auto [t, st2] = infer_72604;
            call_then(crate::check_types::start_head_sigil(st2, t), [=](Text head_sigil_72653) {
            return ({
                auto inner = is_time_sigil(head_sigil_72653) ? inner_of(st2, t) : t;
                (prism_rtl::more(prism_rtl::rc(crate::check_types::Unify(st2, crate::check_types::t_bool(), inner, e_1.span))));
            });
        });
        });
    });
}


/// `Start CheckCond, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::St> start_check_cond(Env env, crate::check_types::St st, crate::ast::Expr e) {
    return prism_rtl::make_rc<CheckCond>(env, st, e);
}


/// ?TagOfPattern: fn Env, Pattern -> ?TagInfo
std::optional<crate::check_env::TagInfo> tag_of_pattern(const Env& env, const crate::ast::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::ast::PatternKind::PRecord>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::PatternKind::PRecord>(_m).a0;
        return prelude::get(env.g.tags, crate::check_env::dotted(n->path_));
    }
    if (prism_rtl::is<crate::ast::PatternKind::PCtor>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::PatternKind::PCtor>(_m).a0;
        return prelude::get(env.g.tags, crate::check_env::dotted(n->path_));
    }
    if (prism_rtl::is<crate::ast::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
        return prelude::get(env.g.tags, crate::check_env::dotted(n->path_));
    }
    if (prism_rtl::is<crate::ast::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::ast::PatternKind::PGroup>(_m).a0;
        return tag_of_pattern(env, q);
    }
    {
        return std::optional<crate::check_env::TagInfo>{};
    }
}


/// SubstRigid: unbounded fn Text, Ty, Ty -> Ty
crate::check_types::Ty subst_rigid(const Text& name, const crate::check_types::Ty& by, const crate::check_types::Ty& t) {
    if (prism_rtl::is<crate::check_types::Ty::TyRigid>(t)) {
        auto&& n = prism_rtl::as<crate::check_types::Ty::TyRigid>(t).a0;
        return n == name ? by : t;
    }
    if (prism_rtl::is<crate::check_types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check_types::Ty::TyCon>(t).a1;
        return crate::check_types::Ty(crate::check_types::Ty::TyCon{n, run_to_end(each_job(args, ({
            auto name_1 = name;
            auto by_2 = by;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::Ty>(crate::check_types::Ty)>>(prism_rtl::rc([=](crate::check_types::Ty p0) {
            return ({
                auto name_1_3 = name_1;
                auto by_2_3 = by_2;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstRigid(name_1_3, by_2_3, a))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check_types::Ty::TyFn>(t)) {
        auto&& c = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a1;
        auto&& r = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a2;
        return crate::check_types::Ty(crate::check_types::Ty::TyFn{c, run_to_end(each_job(ps, ({
            auto name_1 = name;
            auto by_2 = by;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::Ty>(crate::check_types::Ty)>>(prism_rtl::rc([=](crate::check_types::Ty p0) {
            return ({
                auto name_1_3 = name_1;
                auto by_2_3 = by_2;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstRigid(name_1_3, by_2_3, a))));
                });
            }));
            });
        })));
        }))), prism_rtl::rc(subst_rigid(name, by, r))});
    }
    if (prism_rtl::is<crate::check_types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check_types::Ty::TyTuple>(t).a0;
        return crate::check_types::Ty(crate::check_types::Ty::TyTuple{run_to_end(each_job(ts, ({
            auto name_1 = name;
            auto by_2 = by;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::Ty>(crate::check_types::Ty)>>(prism_rtl::rc([=](crate::check_types::Ty p0) {
            return ({
                auto name_1_3 = name_1;
                auto by_2_3 = by_2;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstRigid(name_1_3, by_2_3, a))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check_types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check_types::Ty::TyArray>(t).a0;
        return crate::check_types::Ty(crate::check_types::Ty::TyArray{prism_rtl::rc(subst_rigid(name, by, e))});
    }
    if (prism_rtl::is<crate::check_types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check_types::Ty::TyMap>(t).a1;
        return crate::check_types::Ty(crate::check_types::Ty::TyMap{prism_rtl::rc(subst_rigid(name, by, k)), prism_rtl::rc(subst_rigid(name, by, v_))});
    }
    if (prism_rtl::is<crate::check_types::Ty::TySig>(t)) {
        auto&& s = prism_rtl::as<crate::check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check_types::Ty::TySig>(t).a1;
        return crate::check_types::Ty(crate::check_types::Ty::TySig{s, prism_rtl::rc(subst_rigid(name, by, i))});
    }
    if (prism_rtl::is<crate::check_types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check_types::Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<crate::check_types::Ty::TyAt>(t).a1;
        return crate::check_types::Ty(crate::check_types::Ty::TyAt{prism_rtl::rc(subst_rigid(name, by, i)), rw});
    }
    if (prism_rtl::is<crate::check_types::Ty::TyElem>(t)) {
        auto&& rw = prism_rtl::as<crate::check_types::Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<crate::check_types::Ty::TyElem>(t).a1;
        return crate::check_types::Ty(crate::check_types::Ty::TyElem{rw, prism_rtl::rc(subst_rigid(name, by, o))});
    }
    {
        auto&& other = t;
        return other;
    }
}


prism_rtl::Turn<crate::check_types::Ty> SubstRigid::cycle() const {
    const auto& name = this->name;
    const auto& by = this->by;
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check_types::Ty::TyRigid>(t) ? ({
        auto&& n = prism_rtl::as<crate::check_types::Ty::TyRigid>(t).a0;
        n == name ? prism_rtl::finished(by) : prism_rtl::finished(t);
    })
        : prism_rtl::is<crate::check_types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<crate::check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check_types::Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto by_2 = by;
        auto n_3 = n;
        auto name_4 = name;
        call_value(each_job(args_1, ({
        auto name_4_5 = name_4;
        auto by_2_5 = by_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::Ty>(crate::check_types::Ty)>>(prism_rtl::rc([=](crate::check_types::Ty p0) {
        return ({
            auto name_4_5_5 = name_4_5;
            auto by_2_5_5 = by_2_5;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(SubstRigid(name_4_5_5, by_2_5_5, a))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check_types::Ty> each_73240) { return prism_rtl::finished(crate::check_types::Ty(crate::check_types::Ty::TyCon{n_3, each_73240})); });
    });
    })
        : prism_rtl::is<crate::check_types::Ty::TyFn>(t) ? ({
        auto&& c = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a1;
        auto&& r = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a2;
        ({
        auto by_1 = by;
        auto c_2 = c;
        auto name_3 = name;
        auto ps_4 = ps;
        auto r_5 = r;
        call_value(each_job(ps_4, ({
        auto name_3_6 = name_3;
        auto by_1_6 = by_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::Ty>(crate::check_types::Ty)>>(prism_rtl::rc([=](crate::check_types::Ty p0) {
        return ({
            auto name_3_6_6 = name_3_6;
            auto by_1_6_6 = by_1_6;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(SubstRigid(name_3_6_6, by_1_6_6, a))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check_types::Ty> each_73308) { return call_then(start_subst_rigid(name_3, by_1, r_5), [=](crate::check_types::Ty subst_rigid_73348) { return prism_rtl::finished(crate::check_types::Ty(crate::check_types::Ty::TyFn{c_2, each_73308, prism_rtl::rc(subst_rigid_73348)})); }); });
    });
    })
        : prism_rtl::is<crate::check_types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check_types::Ty::TyTuple>(t).a0;
        ({
        auto by_1 = by;
        auto name_2 = name;
        auto ts_3 = ts;
        call_value(each_job(ts_3, ({
        auto name_2_4 = name_2;
        auto by_1_4 = by_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::Ty>(crate::check_types::Ty)>>(prism_rtl::rc([=](crate::check_types::Ty p0) {
        return ({
            auto name_2_4_4 = name_2_4;
            auto by_1_4_4 = by_1_4;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(SubstRigid(name_2_4_4, by_1_4_4, a))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check_types::Ty> each_73397) { return prism_rtl::finished(crate::check_types::Ty(crate::check_types::Ty::TyTuple{each_73397})); });
    });
    })
        : prism_rtl::is<crate::check_types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check_types::Ty::TyArray>(t).a0;
        ({
        auto by_1 = by;
        auto e_2 = e;
        auto name_3 = name;
        call_then(start_subst_rigid(name_3, by_1, e_2), [=](crate::check_types::Ty subst_rigid_73459) { return prism_rtl::finished(crate::check_types::Ty(crate::check_types::Ty::TyArray{prism_rtl::rc(subst_rigid_73459)})); });
    });
    })
        : prism_rtl::is<crate::check_types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check_types::Ty::TyMap>(t).a1;
        ({
        auto by_1 = by;
        auto k_2 = k;
        auto name_3 = name;
        auto v__4 = v_;
        call_then(start_subst_rigid(name_3, by_1, k_2), [=](crate::check_types::Ty subst_rigid_73506) { return call_then(start_subst_rigid(name_3, by_1, v__4), [=](crate::check_types::Ty subst_rigid_73532) { return prism_rtl::finished(crate::check_types::Ty(crate::check_types::Ty::TyMap{prism_rtl::rc(subst_rigid_73506), prism_rtl::rc(subst_rigid_73532)})); }); });
    });
    })
        : prism_rtl::is<crate::check_types::Ty::TySig>(t) ? ({
        auto&& s = prism_rtl::as<crate::check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check_types::Ty::TySig>(t).a1;
        ({
        auto by_1 = by;
        auto i_2 = i;
        auto name_3 = name;
        auto s_4 = s;
        call_then(start_subst_rigid(name_3, by_1, i_2), [=](crate::check_types::Ty subst_rigid_73582) { return prism_rtl::finished(crate::check_types::Ty(crate::check_types::Ty::TySig{s_4, prism_rtl::rc(subst_rigid_73582)})); });
    });
    })
        : prism_rtl::is<crate::check_types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<crate::check_types::Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<crate::check_types::Ty::TyAt>(t).a1;
        ({
        auto by_1 = by;
        auto i_2 = i;
        auto name_3 = name;
        auto rw_4 = rw;
        call_then(start_subst_rigid(name_3, by_1, i_2), [=](crate::check_types::Ty subst_rigid_73628) { return prism_rtl::finished(crate::check_types::Ty(crate::check_types::Ty::TyAt{prism_rtl::rc(subst_rigid_73628), rw_4})); });
    });
    })
        : prism_rtl::is<crate::check_types::Ty::TyElem>(t) ? ({
        auto&& rw = prism_rtl::as<crate::check_types::Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<crate::check_types::Ty::TyElem>(t).a1;
        ({
        auto by_1 = by;
        auto name_2 = name;
        auto o_3 = o;
        auto rw_4 = rw;
        call_then(start_subst_rigid(name_2, by_1, o_3), [=](crate::check_types::Ty subst_rigid_73686) { return prism_rtl::finished(crate::check_types::Ty(crate::check_types::Ty::TyElem{rw_4, prism_rtl::rc(subst_rigid_73686)})); });
    });
    })
        : ({
        auto&& other = t;
        prism_rtl::finished(other);
    });
    });
}


/// `Start SubstRigid, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::Ty> start_subst_rigid(Text name, crate::check_types::Ty by, crate::check_types::Ty t) {
    return prism_rtl::make_rc<SubstRigid>(name, by, t);
}


/// MatchResult: unbounded fn Env, St, Text, [((Text, Range))], Ty, Range -> ((Ty, St))
std::tuple<crate::check_types::Ty, crate::check_types::St> match_result(const Env& env, const crate::check_types::St& st, const Text& sh, const Array<std::tuple<Text, crate::ast::Range>>& layers, const crate::check_types::Ty& res, const crate::ast::Range& span) {
    auto events = filter(layers, [&](const std::tuple<Text, crate::ast::Range>& _p0) {
        auto&& h = std::get<0>(_p0);
        return h == Text::lit("!");
    });
    auto dyns = filter(layers, [&](const std::tuple<Text, crate::ast::Range>& _p0) {
        auto&& h = std::get<0>(_p0);
        return h == Text::lit("$");
    });
    auto blue = filter(layers, [&](const std::tuple<Text, crate::ast::Range>& _p0) {
        auto&& h = std::get<0>(_p0);
        return h == Text::lit("@");
    });
    auto st2 = (len(blue) > Nat(0u)) && is_time_sigil(sh)
        ? crate::check_types::err_fix(st, Text::lit("building-match"), span, Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), Text::lit("write `rebuild` over the scrutinee, with `match _:` inside"))
        : st;
    auto st3 = (sh == Text::lit("!")) && (len(events) > Nat(0u))
        ? crate::check_types::err_fix(st2, Text::lit("two-events"), span, Text::lit("two events in one operation"), Text::lit("an arm over an event's scrutinee fires with the scrutinee; read a dynamic in the arm, not an event"))
        : st2;
    return len(events) > Nat(0u)
        ? std::tuple{crate::check_types::Ty(crate::check_types::Ty::TySig{Text::lit("!"), prism_rtl::rc(res)}), elab(st3, span, Text::lit("match"), Text::lit("gate"), Text::lit("!"))}
        : (sh == Text::lit("$")) || (len(dyns) > Nat(0u))
        ? std::tuple{crate::check_types::Ty(crate::check_types::Ty::TySig{Text::lit("$"), prism_rtl::rc(res)}), elab(st3, span, Text::lit("match"), Text::lit("map"), Text::lit("$"))}
        : sh == Text::lit("!")
        ? std::tuple{crate::check_types::Ty(crate::check_types::Ty::TySig{Text::lit("!"), prism_rtl::rc(res)}), elab(st3, span, Text::lit("match"), Text::lit("map"), Text::lit("!"))}
        : std::tuple{res, st3};
}


prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> MatchResult::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& sh = this->sh;
    const auto& layers = this->layers;
    const auto& res = this->res;
    const auto& span = this->span;
    auto events = filter(layers, [&](const std::tuple<Text, crate::ast::Range>& _p0) {
        auto&& h = std::get<0>(_p0);
        return h == Text::lit("!");
    });
    auto dyns = filter(layers, [&](const std::tuple<Text, crate::ast::Range>& _p0) {
        auto&& h = std::get<0>(_p0);
        return h == Text::lit("$");
    });
    auto blue = filter(layers, [&](const std::tuple<Text, crate::ast::Range>& _p0) {
        auto&& h = std::get<0>(_p0);
        return h == Text::lit("@");
    });
    auto st2 = (len(blue) > Nat(0u)) && is_time_sigil(sh)
        ? crate::check_types::err_fix(st, Text::lit("building-match"), span, Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), Text::lit("write `rebuild` over the scrutinee, with `match _:` inside"))
        : st;
    auto st3 = (sh == Text::lit("!")) && (len(events) > Nat(0u))
        ? crate::check_types::err_fix(st2, Text::lit("two-events"), span, Text::lit("two events in one operation"), Text::lit("an arm over an event's scrutinee fires with the scrutinee; read a dynamic in the arm, not an event"))
        : st2;
    return len(events) > Nat(0u)
        ? prism_rtl::finished(std::tuple{crate::check_types::Ty(crate::check_types::Ty::TySig{Text::lit("!"), prism_rtl::rc(res)}), elab(st3, span, Text::lit("match"), Text::lit("gate"), Text::lit("!"))})
        : (sh == Text::lit("$")) || (len(dyns) > Nat(0u))
        ? prism_rtl::finished(std::tuple{crate::check_types::Ty(crate::check_types::Ty::TySig{Text::lit("$"), prism_rtl::rc(res)}), elab(st3, span, Text::lit("match"), Text::lit("map"), Text::lit("$"))})
        : sh == Text::lit("!")
        ? prism_rtl::finished(std::tuple{crate::check_types::Ty(crate::check_types::Ty::TySig{Text::lit("!"), prism_rtl::rc(res)}), elab(st3, span, Text::lit("match"), Text::lit("map"), Text::lit("!"))})
        : prism_rtl::finished(std::tuple{res, st3});
}


/// `Start MatchResult, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_match_result(Env env, crate::check_types::St st, Text sh, Array<std::tuple<Text, crate::ast::Range>> layers, crate::check_types::Ty res, crate::ast::Range span) {
    return prism_rtl::make_rc<MatchResult>(env, st, sh, layers, res, span);
}


/// InferIf: unbounded fn Env, St, Cond, Block, ?Block, Range, ?Ty -> ((Ty, St))
std::tuple<crate::check_types::Ty, crate::check_types::St> infer_if(const Env& env, const crate::check_types::St& st, const crate::ast::Cond& c, const crate::ast::Block& then_b, const std::optional<crate::ast::Block>& else_b_opt, const crate::ast::Range& span, const std::optional<crate::check_types::Ty>& expected_opt) {
    if (prism_rtl::is<crate::ast::Cond::CondExpr>(c)) {
        auto&& e = prism_rtl::as<crate::ast::Cond::CondExpr>(c).a0;
        auto [ct, st1] = infer(env, st, e);
        auto sh = crate::check_types::head_sigil(st1, ct);
        auto inner = is_time_sigil(sh) ? inner_of(st1, ct) : ct;
        auto st2 = crate::check_types::unify(st1, crate::check_types::t_bool(), inner, e.span);
        auto [res, st3] = crate::check_types::fresh_var(st2, false, Text::lit(""));
        auto [layers, st4] = if_branches(env, st3, env, then_b, else_b_opt, res);
        return match_result(env, st4, sh, layers, res, span);
    }
    if (prism_rtl::is<crate::ast::Cond::CondBind>(c)) {
        auto&& p_ = prism_rtl::as<crate::ast::Cond::CondBind>(c).a0;
        auto&& e = prism_rtl::as<crate::ast::Cond::CondBind>(c).a1;
        auto&& gd_opt = prism_rtl::as<crate::ast::Cond::CondBind>(c).a2;
        auto [et, st1] = infer(env, st, e);
        auto [env2, st2] = bind_pattern(env, st1, p_, et, true);
        auto st3 = ({
            __label__ _done;
            prism_rtl::Slot<crate::check_types::St> _v;
            auto&& _m = gd_opt;
            if (prism_rtl::is_some(_m)) {
                auto&& g = prism_rtl::some_of(_m);
                _v.set(check_cond(env2, st2, g));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(st2);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto [res, st4] = crate::check_types::fresh_var(st3, false, Text::lit(""));
        auto [layers, st5] = if_branches(env2, st4, env, then_b, else_b_opt, res);
        return match_result(env, st5, Text::lit(""), layers, res, span);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> InferIf::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& then_b = this->then_b;
    const auto& else_b_opt = this->else_b_opt;
    const auto& span = this->span;
    const auto& expected_opt = this->expected_opt;
    return ({
        prism_rtl::is<crate::ast::Cond::CondExpr>(c) ? ({
        auto&& e = prism_rtl::as<crate::ast::Cond::CondExpr>(c).a0;
        ({
        auto else_b_opt_1 = else_b_opt;
        auto e_2 = e;
        auto env_3 = env;
        auto span_4 = span;
        auto st_5 = st;
        auto then_b_6 = then_b;
        call_then(start_infer(env_3, st_5, e_2), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_75019) {
        return ({
            auto [ct, st1] = infer_75019;
            call_then(crate::check_types::start_head_sigil(st1, ct), [=](Text head_sigil_75053) {
            return ({
                auto sh = head_sigil_75053;
                auto inner = is_time_sigil(sh) ? inner_of(st1, ct) : ct;
                call_then(crate::check_types::start_unify(st1, crate::check_types::t_bool(), inner, e_2.span), [=](crate::check_types::St unify_75153) {
                return ({
                    auto st2 = unify_75153;
                    auto [res, st3] = crate::check_types::fresh_var(st2, false, Text::lit(""));
                    call_then(start_if_branches(env_3, st3, env_3, then_b_6, else_b_opt_1, res), [=](std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St> if_branches_75266) {
                    return ({
                        auto [layers, st4] = if_branches_75266;
                        (prism_rtl::more(prism_rtl::rc(MatchResult(env_3, st4, sh, layers, res, span_4))));
                    });
                });
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::ast::Cond::CondBind>(c) ? ({
        auto&& p_ = prism_rtl::as<crate::ast::Cond::CondBind>(c).a0;
        auto&& e = prism_rtl::as<crate::ast::Cond::CondBind>(c).a1;
        auto&& gd_opt = prism_rtl::as<crate::ast::Cond::CondBind>(c).a2;
        ({
        auto else_b_opt_1 = else_b_opt;
        auto gd_opt_2 = gd_opt;
        auto c_3 = c;
        auto e_4 = e;
        auto env_5 = env;
        auto p__6 = p_;
        auto span_7 = span;
        auto st_8 = st;
        auto then_b_9 = then_b;
        call_then(start_infer(env_5, st_8, e_4), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_75413) {
        return ({
            auto [et, st1] = infer_75413;
            call_then(start_bind_pattern(env_5, st1, p__6, et, true), [=](std::tuple<Env, crate::check_types::St> bind_pattern_75458) {
            return ({
                auto [env2, st2] = bind_pattern_75458;
                auto st3 = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check_types::St> _v;
                    if (prism_rtl::is_some(gd_opt)) {
                        auto&& g = prism_rtl::some_of(gd_opt);
                        _v.set(check_cond(env2, st2, g));
                        goto _done;
                    }
                    if (prism_rtl::is_none(gd_opt)) {
                        _v.set(st2);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto [res, st4] = crate::check_types::fresh_var(st3, false, Text::lit(""));
                call_then(start_if_branches(env2, st4, env_5, then_b_9, else_b_opt_1, res), [=](std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St> if_branches_75663) {
                return ({
                    auto [layers, st5] = if_branches_75663;
                    (prism_rtl::more(prism_rtl::rc(MatchResult(env_5, st5, Text::lit(""), layers, res, span_7))));
                });
            });
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_if(Env env, crate::check_types::St st, crate::ast::Cond c, crate::ast::Block then_b, std::optional<crate::ast::Block> else_b_opt, crate::ast::Range span, std::optional<crate::check_types::Ty> expected_opt) {
    return prism_rtl::make_rc<InferIf>(env, st, c, then_b, else_b_opt, span, expected_opt);
}


/// UnifyArm: unbounded fn St, Ty, Ty, Range -> St
crate::check_types::St unify_arm(const crate::check_types::St& st, const crate::check_types::Ty& res, const crate::check_types::Ty& t, const crate::ast::Range& span) {
    return crate::check_types::is_flex_var(st, res) && (crate::check_types::walk(st, t) == crate::check_types::Ty(crate::check_types::Ty::TyCon{Text::lit("Prelude.Error"), Array<crate::check_types::Ty>{}}))
        ? crate::check_types::defer(st, res, t, span)
        : crate::check_types::unify(st, res, t, span);
}


prism_rtl::Turn<crate::check_types::St> UnifyArm::cycle() const {
    const auto& st = this->st;
    const auto& res = this->res;
    const auto& t = this->t;
    const auto& span = this->span;
    auto res_1 = res;
    auto span_2 = span;
    auto st_3 = st;
    auto t_4 = t;
    return call_then(crate::check_types::start_is_flex_var(st_3, res_1), [=](bool is_flex_var_76000) {
        return is_flex_var_76000 && (crate::check_types::walk(st_3, t_4) == crate::check_types::Ty(crate::check_types::Ty::TyCon{Text::lit("Prelude.Error"), Array<crate::check_types::Ty>{}}))
            ? prism_rtl::finished(crate::check_types::defer(st_3, res_1, t_4, span_2))
            : prism_rtl::more(prism_rtl::rc(crate::check_types::Unify(st_3, res_1, t_4, span_2)));
    });
}


/// `Start UnifyArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::St> start_unify_arm(crate::check_types::St st, crate::check_types::Ty res, crate::check_types::Ty t, crate::ast::Range span) {
    return prism_rtl::make_rc<UnifyArm>(st, res, t, span);
}


/// LayerHead: fn Text -> Text
Text layer_head(const Text& h) {
    return is_time_sigil(h) ? h : h == Text::lit("@") ? Text::lit("@") : Text::lit("");
}


/// IfBranches: unbounded fn Env, St, Env, Block, ?Block, Ty -> (([((Text, Range))], St))
std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St> if_branches(const Env& then_env, const crate::check_types::St& st, const Env& else_env, const crate::ast::Block& then_b, const std::optional<crate::ast::Block>& else_b_opt, const crate::check_types::Ty& res) {
    auto [t1, st1] = infer_expr_block(then_env, st, then_b);
    auto h1 = crate::check_types::head_sigil(st1, t1);
    auto st2 = unify_arm(st1, res, is_time_sigil(h1) ? inner_of(st1, t1) : t1, then_b.span);
    auto l1 = Array(std::vector{std::tuple{layer_head(h1), then_b.span}});
    if (prism_rtl::is_some(else_b_opt)) {
        auto&& b = prism_rtl::some_of(else_b_opt);
        auto [t2, st3] = infer_expr_block(else_env, st2, b);
        auto h2 = crate::check_types::head_sigil(st3, t2);
        auto st4 = unify_arm(st3, res, is_time_sigil(h2) ? inner_of(st3, t2) : t2, b.span);
        return std::tuple{prelude::push(l1, std::tuple{layer_head(h2), b.span}), st4};
    }
    if (prism_rtl::is_none(else_b_opt)) {
        return std::tuple{l1, crate::check_types::unify(st2, res, crate::check_types::t_unit(), then_b.span)};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St>> IfBranches::cycle() const {
    const auto& then_env = this->then_env;
    const auto& st = this->st;
    const auto& else_env = this->else_env;
    const auto& then_b = this->then_b;
    const auto& else_b_opt = this->else_b_opt;
    const auto& res = this->res;
    auto else_b_opt_1 = else_b_opt;
    auto else_env_2 = else_env;
    auto res_3 = res;
    auto st_4 = st;
    auto then_b_5 = then_b;
    auto then_env_6 = then_env;
    return call_then(start_infer_expr_block(then_env_6, st_4, then_b_5), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_expr_block_76384) {
        return ({
            auto [t1, st1] = infer_expr_block_76384;
            call_then(crate::check_types::start_head_sigil(st1, t1), [=](Text head_sigil_76431) {
            return ({
                auto h1 = head_sigil_76431;
                call_then(start_unify_arm(st1, res_3, is_time_sigil(h1) ? inner_of(st1, t1) : t1, then_b_5.span), [=](crate::check_types::St unify_arm_76463) {
                return ({
                    auto st2 = unify_arm_76463;
                    auto l1 = Array(std::vector{std::tuple{layer_head(h1), then_b_5.span}});
                    ({
                    prism_rtl::is_some(else_b_opt_1) ? ({
                    auto&& b = prism_rtl::some_of(else_b_opt_1);
                    ({
                    auto b_7 = b;
                    call_then(start_infer_expr_block(else_env_2, st2, b_7), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_expr_block_76649) {
                    return ({
                        auto [t2, st3] = infer_expr_block_76649;
                        call_then(crate::check_types::start_head_sigil(st3, t2), [=](Text head_sigil_76701) {
                        return ({
                            auto h2 = head_sigil_76701;
                            call_then(start_unify_arm(st3, res_3, is_time_sigil(h2) ? inner_of(st3, t2) : t2, b_7.span), [=](crate::check_types::St unify_arm_76741) {
                            return ({
                                auto st4 = unify_arm_76741;
                                (prism_rtl::finished(std::tuple{prelude::push(l1, std::tuple{layer_head(h2), b_7.span}), st4}));
                            });
                        });
                        });
                    });
                    });
                });
                });
                })
                    : prism_rtl::is_none(else_b_opt_1) ? call_then(crate::check_types::start_unify(st2, res_3, crate::check_types::t_unit(), then_b_5.span), [=](crate::check_types::St unify_76893) { return prism_rtl::finished(std::tuple{l1, unify_76893}); })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
        });
        });
    });
}


/// `Start IfBranches, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St>> start_if_branches(Env then_env, crate::check_types::St st, Env else_env, crate::ast::Block then_b, std::optional<crate::ast::Block> else_b_opt, crate::check_types::Ty res) {
    return prism_rtl::make_rc<IfBranches>(then_env, st, else_env, then_b, else_b_opt, res);
}


/// InferExprBlock: unbounded fn Env, St, Block -> ((Ty, St))
std::tuple<crate::check_types::Ty, crate::check_types::St> infer_expr_block(const Env& env, const crate::check_types::St& st, const crate::ast::Block& b) {
    return is_widgetish(b.stmts)
        ? crate::check_blocks::infer_widget_block(env, st, b)
        : ({
        auto [env2, st2] = bind_group(env, st, b.stmts);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check_types::Ty, crate::check_types::St>> _v;
        auto&& _m = crate::lexer::last(b.stmts);
        if (prism_rtl::is_some(_m)) {
            auto&& s = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check_types::Ty, crate::check_types::St>> _v;
                auto&& _m = s.kind;
                if (prism_rtl::is<crate::ast::StmtKind::SExpr>(_m)) {
                    auto&& e = prism_rtl::as<crate::ast::StmtKind::SExpr>(_m).a0;
                    _v.set(infer(env2, st2, e));
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::check_types::t_unit(), st2});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{crate::check_types::t_unit(), st2});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> InferExprBlock::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& b = this->b;
    return is_widgetish(b.stmts)
        ? prism_rtl::more(prism_rtl::rc(crate::check_blocks::InferWidgetBlock(env, st, b)))
        : ({
        auto b_1 = b;
        auto env_2 = env;
        auto st_3 = st;
        call_then(start_bind_group(env_2, st_3, b_1.stmts), [=](std::tuple<Env, crate::check_types::St> bind_group_77547) {
        return ({
            auto [env2, st2] = bind_group_77547;
            ({
            auto&& _m = crate::lexer::last(b_1.stmts);
            prism_rtl::is_some(_m) ? ({
            auto&& s = prism_rtl::some_of(_m);
            ({
            auto&& _m = s.kind;
            prism_rtl::is<crate::ast::StmtKind::SExpr>(_m) ? ({
            auto&& e = prism_rtl::as<crate::ast::StmtKind::SExpr>(_m).a0;
            prism_rtl::more(prism_rtl::rc(Infer(env2, st2, e)));
        })
            : prism_rtl::finished(std::tuple{crate::check_types::t_unit(), st2});
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check_types::t_unit(), st2})
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    });
}


/// `Start InferExprBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_expr_block(Env env, crate::check_types::St st, crate::ast::Block b) {
    return prism_rtl::make_rc<InferExprBlock>(env, st, b);
}


/// IsWidgetish: fn [Stmt] -> Bool
bool is_widgetish(const Array<crate::ast::Stmt>& stmts) {
    return fold(stmts, false, [&](const bool& seen, const crate::ast::Stmt& s) { return seen || builds(s); });
}


/// Builds: fn Stmt -> Bool
bool builds(const crate::ast::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::ast::StmtKind::SBind>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::ast::StmtKind::SIgnore>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::ast::StmtKind::SEmit>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::ast::StmtKind::SWidget>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// BindGroup: unbounded fn Env, St, [Stmt] -> ((Env, St))
std::tuple<Env, crate::check_types::St> bind_group(const Env& env, const crate::check_types::St& st, const Array<crate::ast::Stmt>& stmts) {
    auto order = crate::check_blocks::group_order(stmts);
    auto [env1, st1] = run_to_end(fold_job(order, std::tuple{env, st}, ({
        auto stmts_1 = stmts;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>>(std::tuple<std::tuple<Env, crate::check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, crate::check_types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto stmts_1_2 = stmts_1;
            entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto i = p1;
                (prism_rtl::more(prism_rtl::rc(PreBind(en, s, or_(index(stmts_1_2, i), dummy_stmt())))));
            });
        }));
        });
    }));
    })));
    auto st2 = st1.recording && (len(stmts) > Nat(1u))
        ? crate::check_types::note_group(st1, stmts_span(stmts), Text::lit("expr"), crate::check_blocks::dep_order(stmts))
        : st1;
    return run_to_end(fold_job(order, std::tuple{env1, st2}, ({
        auto stmts_1 = stmts;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>>(std::tuple<std::tuple<Env, crate::check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, crate::check_types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto stmts_1_2 = stmts_1;
            entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto i = p1;
                (prism_rtl::more(prism_rtl::rc(CheckGroupStmt(en, s, or_(index(stmts_1_2, i), dummy_stmt()), is_last(stmts_1_2, i)))));
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> BindGroup::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& stmts = this->stmts;
    auto order = crate::check_blocks::group_order(stmts);
    auto env_1 = env;
    auto st_2 = st;
    auto stmts_3 = stmts;
    return call_value(fold_job(order, std::tuple{env_1, st_2}, ({
        auto stmts_3_4 = stmts_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>>(std::tuple<std::tuple<Env, crate::check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, crate::check_types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto stmts_3_4_4 = stmts_3_4;
            entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto i = p1;
                (prism_rtl::more(prism_rtl::rc(PreBind(en, s, or_(index(stmts_3_4_4, i), dummy_stmt())))));
            });
        }));
        });
    }));
    })), [=](std::tuple<Env, crate::check_types::St> fold_78575) {
        return ({
            auto [env1, st1] = fold_78575;
            auto st2 = st1.recording && (len(stmts_3) > Nat(1u))
                ? crate::check_types::note_group(st1, stmts_span(stmts_3), Text::lit("expr"), crate::check_blocks::dep_order(stmts_3))
                : st1;
            fold_job(order, std::tuple{env1, st2}, ({
            auto stmts_3_4 = stmts_3;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>>(std::tuple<std::tuple<Env, crate::check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, crate::check_types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto stmts_3_4_4 = stmts_3_4;
                entered(once_job([=]() {
                return ({
                    auto [en, s] = p0;
                    auto i = p1;
                    (prism_rtl::more(prism_rtl::rc(CheckGroupStmt(en, s, or_(index(stmts_3_4_4, i), dummy_stmt()), is_last(stmts_3_4_4, i)))));
                });
            }));
            });
        }));
        }))->cycle();
        });
    });
}


/// `Start BindGroup, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_group(Env env, crate::check_types::St st, Array<crate::ast::Stmt> stmts) {
    return prism_rtl::make_rc<BindGroup>(env, st, stmts);
}


/// StmtsSpan: fn [Stmt] -> Range
crate::ast::Range stmts_span(const Array<crate::ast::Stmt>& stmts) {
    return crate::ast::Range{.start = or_(index(stmts, Nat(0u)), dummy_stmt()).span.start, .end = or_(crate::lexer::last(stmts), dummy_stmt()).span.end};
}


/// let dummyStmt
crate::ast::Stmt dummy_stmt() {
    return crate::ast::Stmt{.kind = crate::ast::StmtKind(crate::ast::StmtKind::SExpr{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EError{})), .span = crate::ast::Range{.start = Nat(0u), .end = Nat(0u)}}}), .span = crate::ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// IsLast: fn [Stmt], Nat -> Bool
bool is_last(const Array<crate::ast::Stmt>& stmts, const Nat& i) {
    return (i + Nat(1u)) == len(stmts);
}


/// PreBind: unbounded fn Env, St, Stmt -> ((Env, St))
std::tuple<Env, crate::check_types::St> pre_bind(const Env& env, const crate::check_types::St& st, const crate::ast::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::ast::StmtKind::SSignature>(_m)) {
        auto&& sg = prism_rtl::as<crate::ast::StmtKind::SSignature>(_m).a0;
        auto [sc, st2] = crate::check_env::sig_scheme(env_cx(env), st, sg.ty, sg.bounds);
        return std::tuple{with_local(env, crate::check_env::def_name_text(sg.name), sc), st2};
    }
    if (prism_rtl::is<crate::ast::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<crate::ast::StmtKind::SFn>(_m).a0;
        auto name = crate::check_env::def_name_text(f.name);
        auto&& _m = prelude::get(env.locals, name);
        if (prism_rtl::is_some(_m)) {
            return std::tuple{env, st};
        }
        if (prism_rtl::is_none(_m)) {
            auto [v_, st2] = crate::check_types::fresh_var(st, false, Text::lit(""));
            return std::tuple{with_local(env, name, crate::check_types::mono(v_)), st2};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::ast::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::ast::StmtKind::SLet>(_m).a0;
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
            auto [v_, st1] = crate::check_types::fresh_var(st, true, crate::check_env::sname_key(n));
            auto st2 = crate::check_types::at_binder(st1, v_, n.span);
            auto [rw, st3] = crate::check_types::fresh_row(st2, Array<Text>{});
            return std::tuple{with_local(env, crate::check_env::sname_key(n), crate::check_types::mono(crate::check_types::with_marks(type_marks(n.sigils), v_, rw))), st3};
        }
        {
            return std::tuple{env, st};
        }
    }
    {
        return std::tuple{env, st};
    }
}


prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> PreBind::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::ast::StmtKind::SSignature>(_m) ? ({
        auto&& sg = prism_rtl::as<crate::ast::StmtKind::SSignature>(_m).a0;
        ({
        auto env_1 = env;
        auto sg_2 = sg;
        auto st_3 = st;
        call_then(crate::check_env::start_sig_scheme(env_cx(env_1), st_3, sg_2.ty, sg_2.bounds), [=](std::tuple<crate::check_types::Scheme, crate::check_types::St> sig_scheme_79480) {
        return ({
            auto [sc, st2] = sig_scheme_79480;
            (prism_rtl::finished(std::tuple{with_local(env_1, crate::check_env::def_name_text(sg_2.name), sc), st2}));
        });
    });
    });
    })
        : prism_rtl::is<crate::ast::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<crate::ast::StmtKind::SFn>(_m).a0;
        ({
        auto name = crate::check_env::def_name_text(f.name);
        ({
        auto&& _m = prelude::get(env.locals, name);
        prism_rtl::is_some(_m) ? prism_rtl::finished(std::tuple{env, st})
        : prism_rtl::is_none(_m) ? ({
        auto [v_, st2] = crate::check_types::fresh_var(st, false, Text::lit(""));
        (prism_rtl::finished(std::tuple{with_local(env, name, crate::check_types::mono(v_)), st2}));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::is<crate::ast::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::ast::StmtKind::SLet>(_m).a0;
        ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::ast::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
        ({
        auto [v_, st1] = crate::check_types::fresh_var(st, true, crate::check_env::sname_key(n));
        auto st2 = crate::check_types::at_binder(st1, v_, n.span);
        auto [rw, st3] = crate::check_types::fresh_row(st2, Array<Text>{});
        (prism_rtl::finished(std::tuple{with_local(env, crate::check_env::sname_key(n), crate::check_types::mono(crate::check_types::with_marks(type_marks(n.sigils), v_, rw))), st3}));
    });
    })
        : prism_rtl::finished(std::tuple{env, st});
    });
    })
        : prism_rtl::finished(std::tuple{env, st});
    });
}


/// `Start PreBind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_pre_bind(Env env, crate::check_types::St st, crate::ast::Stmt s) {
    return prism_rtl::make_rc<PreBind>(env, st, s);
}


/// CheckGroupStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St))
std::tuple<Env, crate::check_types::St> check_group_stmt(const Env& env, const crate::check_types::St& st, const crate::ast::Stmt& s, const bool& last) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::ast::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::ast::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<crate::ast::StmtKind::SLet>(_m).a1;
        auto&& e = prism_rtl::as<crate::ast::StmtKind::SLet>(_m).a2;
        return check_let(env, st, p_, ty_opt, e, s.span);
    }
    if (prism_rtl::is<crate::ast::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<crate::ast::StmtKind::SFn>(_m).a0;
        return check_local_fn(env, st, f, s.span);
    }
    if (prism_rtl::is<crate::ast::StmtKind::SSignature>(_m)) {
        return std::tuple{env, st};
    }
    if (prism_rtl::is<crate::ast::StmtKind::SExpr>(_m)) {
        auto&& e = prism_rtl::as<crate::ast::StmtKind::SExpr>(_m).a0;
        return last
            ? std::tuple{env, st}
            : ({
            auto [t, st2] = infer(env, st, e);
            std::tuple{env, st2};
        });
    }
    {
        return std::tuple{env, crate::check_types::err(st, Text::lit("mismatch"), s.span, Text::lit("this statement belongs in a widget, `given:` or `update` block"))};
    }
}


prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> CheckGroupStmt::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& s = this->s;
    const auto& last = this->last;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::ast::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::ast::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<crate::ast::StmtKind::SLet>(_m).a1;
        auto&& e = prism_rtl::as<crate::ast::StmtKind::SLet>(_m).a2;
        prism_rtl::more(prism_rtl::rc(CheckLet(env, st, p_, ty_opt, e, s.span)));
    })
        : prism_rtl::is<crate::ast::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<crate::ast::StmtKind::SFn>(_m).a0;
        prism_rtl::more(prism_rtl::rc(CheckLocalFn(env, st, f, s.span)));
    })
        : prism_rtl::is<crate::ast::StmtKind::SSignature>(_m) ? prism_rtl::finished(std::tuple{env, st})
        : prism_rtl::is<crate::ast::StmtKind::SExpr>(_m) ? ({
        auto&& e = prism_rtl::as<crate::ast::StmtKind::SExpr>(_m).a0;
        last
        ? prism_rtl::finished(std::tuple{env, st})
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto st_3 = st;
        call_then(start_infer(env_2, st_3, e_1), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_80536) {
        return ({
            auto [t, st2] = infer_80536;
            (prism_rtl::finished(std::tuple{env_2, st2}));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{env, crate::check_types::err(st, Text::lit("mismatch"), s.span, Text::lit("this statement belongs in a widget, `given:` or `update` block"))});
    });
}


/// `Start CheckGroupStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_check_group_stmt(Env env, crate::check_types::St st, crate::ast::Stmt s, bool last) {
    return prism_rtl::make_rc<CheckGroupStmt>(env, st, s, last);
}


/// CheckLet: unbounded fn Env, St, Pattern, ?Type, Expr, Range -> ((Env, St))
std::tuple<Env, crate::check_types::St> check_let(const Env& env, const crate::check_types::St& st, const crate::ast::Pattern_& p_, const std::optional<crate::ast::Type>& ty_opt, const crate::ast::Expr& e, const crate::ast::Range& span) {
    auto st0 = crate::check_types::enter_level(st);
    auto [annot_opt, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<crate::check_types::Ty>, crate::check_types::St>> _v;
        if (prism_rtl::is_some(ty_opt)) {
            auto&& t = prism_rtl::some_of(ty_opt);
            _v.set(({
                auto [at_, s2] = crate::check_env::conv_type(env_cx(env), st0, t);
                std::tuple{std::optional(at_), s2};
            }));
            goto _done;
        }
        if (prism_rtl::is_none(ty_opt)) {
            _v.set(std::tuple{std::optional<crate::check_types::Ty>{}, st0});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [pre, st2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check_types::Ty, crate::check_types::St>> _v;
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check_types::Ty, crate::check_types::St>> _v;
                auto&& _m = prelude::get(env.locals, crate::check_env::sname_key(n));
                if (prism_rtl::is_some(_m)) {
                    auto&& sc = prism_rtl::some_of(_m);
                    _v.set((n.sigils == Text::lit("")) && crate::check_types::is_flex_var(st1, sc.ty)
                        ? ({
                        auto [v_, s2] = crate::check_types::fresh_var(st1, true, crate::check_env::sname_key(n));
                        std::tuple{v_, crate::check_types::at_binder(s2, v_, n.span)};
                    })
                        : std::tuple{sc.ty, st1});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::check_types::fresh_var(st1, true, crate::check_env::sname_key(n)));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(crate::check_types::fresh_var(st1, false, Text::lit("")));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto st3 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check_types::St> _v;
        if (prism_rtl::is_some(annot_opt)) {
            auto&& at_ = prism_rtl::some_of(annot_opt);
            _v.set(check(env, st2, e, at_));
            goto _done;
        }
        if (prism_rtl::is_none(annot_opt)) {
            _v.set(check(env, st2, e, pre));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st4 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check_types::St> _v;
        if (prism_rtl::is_some(annot_opt)) {
            auto&& at_ = prism_rtl::some_of(annot_opt);
            _v.set(crate::check_types::unify(st3, pre, at_, span));
            goto _done;
        }
        if (prism_rtl::is_none(annot_opt)) {
            _v.set(st3);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st5 = crate::check_env::solve_wants(env.g, st4, env.givens, false);
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::ast::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
        auto name = crate::check_env::sname_key(n);
        auto t = crate::check_types::zonk(st5, pre);
        auto [env2, st7a] = bind_name(env, st5, n, t);
        auto st7 = crate::check_types::leave_level(st7a);
        auto ahead_fn = ({
            auto env_1 = env;
            auto name_2 = name;
            auto pre_3 = pre;
            auto t_4 = t;
            auto span_5 = span;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::St>(crate::check_types::St)>>(prism_rtl::rc([=](crate::check_types::St p0) {
            return ({
                auto env_1_6 = env_1;
                auto name_2_6 = name_2;
                auto pre_3_6 = pre_3;
                auto t_4_6 = t_4;
                auto span_5_6 = span_5;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    (prism_rtl::more(prism_rtl::rc(AheadUnify(env_1_6, s, name_2_6, pre_3_6, t_4_6, span_5_6))));
                });
            }));
            });
        })));
        });
        return crate::check_types::holds_node(st7, t) || is_topic_name(name)
            ? std::tuple{env2, run_to_end(ahead_fn(st7))}
            : ({
            auto lambda = is_lambda(e);
            auto [keep, bounds, st8] = wants_above(st7, t, lambda);
            auto [sc, st9] = crate::check_types::generalize(st8, t, keep, bounds);
            std::tuple{with_local(env2, name, sc), run_to_end(ahead_fn(crate::check_types::note_gen(st9, n.span, name, sc)))};
        });
    }
    {
        auto st6 = crate::check_types::leave_level(st5);
        return bind_pattern(env, st6, p_, crate::check_types::zonk(st6, pre), false);
    }
}


prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> CheckLet::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& ty_opt = this->ty_opt;
    const auto& e = this->e;
    const auto& span = this->span;
    auto st0 = crate::check_types::enter_level(st);
    auto [annot_opt, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<crate::check_types::Ty>, crate::check_types::St>> _v;
        if (prism_rtl::is_some(ty_opt)) {
            auto&& t = prism_rtl::some_of(ty_opt);
            _v.set(({
                auto [at_, s2] = crate::check_env::conv_type(env_cx(env), st0, t);
                std::tuple{std::optional(at_), s2};
            }));
            goto _done;
        }
        if (prism_rtl::is_none(ty_opt)) {
            _v.set(std::tuple{std::optional<crate::check_types::Ty>{}, st0});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [pre, st2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check_types::Ty, crate::check_types::St>> _v;
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check_types::Ty, crate::check_types::St>> _v;
                auto&& _m = prelude::get(env.locals, crate::check_env::sname_key(n));
                if (prism_rtl::is_some(_m)) {
                    auto&& sc = prism_rtl::some_of(_m);
                    _v.set((n.sigils == Text::lit("")) && crate::check_types::is_flex_var(st1, sc.ty)
                        ? ({
                        auto [v_, s2] = crate::check_types::fresh_var(st1, true, crate::check_env::sname_key(n));
                        std::tuple{v_, crate::check_types::at_binder(s2, v_, n.span)};
                    })
                        : std::tuple{sc.ty, st1});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::check_types::fresh_var(st1, true, crate::check_env::sname_key(n)));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(crate::check_types::fresh_var(st1, false, Text::lit("")));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto st3 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check_types::St> _v;
        if (prism_rtl::is_some(annot_opt)) {
            auto&& at_ = prism_rtl::some_of(annot_opt);
            _v.set(check(env, st2, e, at_));
            goto _done;
        }
        if (prism_rtl::is_none(annot_opt)) {
            _v.set(check(env, st2, e, pre));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st4 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check_types::St> _v;
        if (prism_rtl::is_some(annot_opt)) {
            auto&& at_ = prism_rtl::some_of(annot_opt);
            _v.set(crate::check_types::unify(st3, pre, at_, span));
            goto _done;
        }
        if (prism_rtl::is_none(annot_opt)) {
            _v.set(st3);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto e_1 = e;
    auto env_2 = env;
    auto p__3 = p_;
    auto span_4 = span;
    return call_then(crate::check_env::start_solve_wants(env_2.g, st4, env_2.givens, false), [=](crate::check_types::St solve_wants_82047) {
        return ({
            auto st5 = solve_wants_82047;
            ({
            auto&& _m = p__3.kind;
            prism_rtl::is<crate::ast::PatternKind::PName>(_m) ? ({
            auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
            ({
            auto name = crate::check_env::sname_key(n);
            auto n_5 = n;
            call_then(crate::check_types::start_zonk(st5, pre), [=](crate::check_types::Ty zonk_82338) {
            return ({
                auto t = zonk_82338;
                call_then(start_bind_name(env_2, st5, n_5, t), [=](std::tuple<Env, crate::check_types::St> bind_name_82385) {
                return ({
                    auto [env2, st7a] = bind_name_82385;
                    auto st7 = crate::check_types::leave_level(st7a);
                    auto ahead_fn = ({
                        auto env_2_6 = env_2;
                        auto name_6 = name;
                        auto pre_7 = pre;
                        auto t_8 = t;
                        auto span_4_9 = span_4;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::St>(crate::check_types::St)>>(prism_rtl::rc([=](crate::check_types::St p0) {
                        return ({
                            auto env_2_6_9 = env_2_6;
                            auto name_6_9 = name_6;
                            auto pre_7_9 = pre_7;
                            auto t_8_9 = t_8;
                            auto span_4_9_9 = span_4_9;
                            entered(once_job([=]() {
                            return ({
                                auto s = p0;
                                (prism_rtl::more(prism_rtl::rc(AheadUnify(env_2_6_9, s, name_6_9, pre_7_9, t_8_9, span_4_9_9))));
                            });
                        }));
                        });
                    })));
                    });
                    call_then(crate::check_types::start_holds_node(st7, t), [=](bool holds_node_82658) {
                    return holds_node_82658 || is_topic_name(name)
                        ? call_value(ahead_fn(st7), [=](crate::check_types::St ahead_82708) { return prism_rtl::finished(std::tuple{env2, ahead_82708}); })
                        : ({
                        auto lambda = is_lambda(e_1);
                        call_then(start_wants_above(st7, t, lambda), [=](std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check_types::St> wants_above_82823) {
                        return ({
                            auto [keep, bounds, st8] = wants_above_82823;
                            call_then(crate::check_types::start_generalize(st8, t, keep, bounds), [=](std::tuple<crate::check_types::Scheme, crate::check_types::St> generalize_82883) {
                            return ({
                                auto [sc, st9] = generalize_82883;
                                call_value(ahead_fn(crate::check_types::note_gen(st9, n_5.span, name, sc)), [=](crate::check_types::St ahead_82962) { return prism_rtl::finished(std::tuple{with_local(env2, name, sc), ahead_82962}); });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
        })
            : ({
            auto st6 = crate::check_types::leave_level(st5);
            call_then(crate::check_types::start_zonk(st6, pre), [=](crate::check_types::Ty zonk_83097) { return prism_rtl::more(prism_rtl::rc(BindPattern(env_2, st6, p__3, zonk_83097, false))); });
        });
        });
        });
    });
}


/// `Start CheckLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_check_let(Env env, crate::check_types::St st, crate::ast::Pattern_ p_, std::optional<crate::ast::Type> ty_opt, crate::ast::Expr e, crate::ast::Range span) {
    return prism_rtl::make_rc<CheckLet>(env, st, p_, ty_opt, e, span);
}


/// AheadUnify: unbounded fn Env, St, Text, Ty, Ty, Range -> St
crate::check_types::St ahead_unify(const Env& env, const crate::check_types::St& st, const Text& name, const crate::check_types::Ty& pre, const crate::check_types::Ty& t, const crate::ast::Range& span) {
    auto&& _m = prelude::get(env.locals, name);
    if (prism_rtl::is_some(_m)) {
        auto&& sc0 = prism_rtl::some_of(_m);
        return sc0.ty != pre ? crate::check_types::unify(st, sc0.ty, t, span) : st;
    }
    if (prism_rtl::is_none(_m)) {
        return st;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check_types::St> AheadUnify::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& name = this->name;
    const auto& pre = this->pre;
    const auto& t = this->t;
    const auto& span = this->span;
    return ({
        auto&& _m = prelude::get(env.locals, name);
        prism_rtl::is_some(_m) ? ({
        auto&& sc0 = prism_rtl::some_of(_m);
        sc0.ty != pre
        ? prism_rtl::more(prism_rtl::rc(crate::check_types::Unify(st, sc0.ty, t, span)))
        : prism_rtl::finished(st);
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(st)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start AheadUnify, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::St> start_ahead_unify(Env env, crate::check_types::St st, Text name, crate::check_types::Ty pre, crate::check_types::Ty t, crate::ast::Range span) {
    return prism_rtl::make_rc<AheadUnify>(env, st, name, pre, t, span);
}


/// TypeMarks: fn Text -> Text
Text type_marks(const Text& marks) {
    return crate::lexer::has_prefix(marks, Text::lit("&"))
        ? crate::lexer::after_first(marks)
        : marks;
}


/// RefMark: fn Text -> Text
Text ref_mark(const Text& marks) {
    return crate::lexer::has_prefix(marks, Text::lit("&"))
        ? Text::lit("&")
        : Text::lit("");
}


/// Unpend: fn Env -> Env
Env unpend(const Env& env) {
    Env this_ = env;
    this_.pending = Array<Text>{};
    return this_;
}


/// IsTopicName: fn Text -> Bool
bool is_topic_name(const Text& n) {
    return (n == Text::lit("_")) || (crate::lexer::drop_prefix(n, crate::check_types::marks_of(n)) == Text::lit("_"));
}


/// WantsAbove: unbounded fn St, Ty, Bool -> (([Nat], [((Nat, Text))], St))
std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check_types::St> wants_above(const crate::check_types::St& st, const crate::check_types::Ty& t, const bool& lambda) {
    auto vs = filter(crate::check_types::free_vars(st, t), [&](const Nat& v_) { return crate::check_types::info_of(st, v_).level > st.level; });
    auto mine = run_to_end(filter_job(st.wants, ({
        auto st_1 = st;
        auto vs_2 = vs;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check_types::Want)>>(prism_rtl::rc([=](crate::check_types::Want p0) {
        return ({
            auto st_1_3 = st_1;
            auto vs_2_3 = vs_2;
            entered(once_job([=]() {
            return ({
                auto w = p0;
                call_then(crate::check_types::start_walk(st_1_3, w.ty), [=](crate::check_types::Ty walk_84198) {
                return ({
                    prism_rtl::is<crate::check_types::Ty::TyFlex>(walk_84198) ? ({
                    auto&& n = prism_rtl::as<crate::check_types::Ty::TyFlex>(walk_84198).a0;
                    prism_rtl::finished(crate::check_types::has_nat(vs_2_3, n));
                })
                    : prism_rtl::finished(false);
                });
            });
            });
        }));
        });
    })));
    })));
    auto others = filter(st.wants, [&](const crate::check_types::Want& w) { return !crate::check_types::has_text(each(mine, [&](const crate::check_types::Want& m) { return show_text(m); }), show_text(w)); });
    auto constrained = run_to_end(fold_job(mine, Array<Nat>{}, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check_types::Want>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::check_types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto w = p1;
                call_then(crate::check_types::start_walk(st_1_2, w.ty), [=](crate::check_types::Ty walk_84412) {
                return ({
                    prism_rtl::is<crate::check_types::Ty::TyFlex>(walk_84412) ? ({
                    auto&& n = prism_rtl::as<crate::check_types::Ty::TyFlex>(walk_84412).a0;
                    prism_rtl::finished(crate::check_types::add_nat(acc, n));
                })
                    : prism_rtl::finished(acc);
                });
            });
            });
        }));
        });
    })));
    })));
    return lambda
        ? ({
        auto bounds = run_to_end(fold_job(mine, Array<std::tuple<Nat, Text>>{}, ({
            auto st_1 = st;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Nat, Text>>>(std::tuple<Array<std::tuple<Nat, Text>>, crate::check_types::Want>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Nat, Text>>, crate::check_types::Want> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto w = p1;
                    call_then(crate::check_types::start_walk(st_1_2, w.ty), [=](crate::check_types::Ty walk_84551) {
                    return ({
                        prism_rtl::is<crate::check_types::Ty::TyFlex>(walk_84551) ? ({
                        auto&& n = prism_rtl::as<crate::check_types::Ty::TyFlex>(walk_84551).a0;
                        crate::lexer::has_prefix(w.cls, Text::lit("Range "))
                        ? prism_rtl::finished(acc)
                        : prism_rtl::finished(prelude::push(acc, std::tuple{n, w.cls}));
                    })
                        : prism_rtl::finished(acc);
                    });
                });
                });
            }));
            });
        }));
        })));
        auto st1 = fold(mine, st, [&](const crate::check_types::St& s, const crate::check_types::Want& w) { return crate::check_types::note_choice(crate::check_types::note_impl(s, w->file, w.span, w.cls, w.ty, Text::lit("quantified")), w->file, w.span, w.cls, Text::lit("any")); });
        auto st2 = ({
            crate::check_types::St this_ = st1;
            this_.wants = others;
            this_;
        });
        std::tuple{Array<Nat>{}, bounds, st2};
    })
        : ({
        auto st2 = crate::check_types::lower_levels(st, constrained, st.level);
        std::tuple{constrained, Array<std::tuple<Nat, Text>>{}, st2};
    });
}


prism_rtl::Turn<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check_types::St>> WantsAbove::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& lambda = this->lambda;
    auto lambda_1 = lambda;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(crate::check_types::start_free_vars(st_2, t_3), [=](Array<Nat> free_vars_84101) {
        return ({
            auto vs = filter(free_vars_84101, [&](const Nat& v_) { return crate::check_types::info_of(st_2, v_).level > st_2.level; });
            call_value(filter_job(st_2.wants, ({
            auto st_2_4 = st_2;
            auto vs_4 = vs;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check_types::Want)>>(prism_rtl::rc([=](crate::check_types::Want p0) {
            return ({
                auto st_2_4_5 = st_2_4;
                auto vs_4_5 = vs_4;
                entered(once_job([=]() {
                return ({
                    auto w = p0;
                    call_then(crate::check_types::start_walk(st_2_4_5, w.ty), [=](crate::check_types::Ty walk_84198) {
                    return ({
                        prism_rtl::is<crate::check_types::Ty::TyFlex>(walk_84198) ? ({
                        auto&& n = prism_rtl::as<crate::check_types::Ty::TyFlex>(walk_84198).a0;
                        prism_rtl::finished(crate::check_types::has_nat(vs_4_5, n));
                    })
                        : prism_rtl::finished(false);
                    });
                });
                });
            }));
            });
        })));
        })), [=](Array<crate::check_types::Want> filter_84170) {
            return ({
                auto mine = filter_84170;
                auto others = filter(st_2.wants, [&](const crate::check_types::Want& w) { return !crate::check_types::has_text(each(mine, [&](const crate::check_types::Want& m) { return show_text(m); }), show_text(w)); });
                call_value(fold_job(mine, Array<Nat>{}, ({
                auto st_2_4 = st_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check_types::Want>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::check_types::Want> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto st_2_4_4 = st_2_4;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto w = p1;
                        call_then(crate::check_types::start_walk(st_2_4_4, w.ty), [=](crate::check_types::Ty walk_84412) {
                        return ({
                            prism_rtl::is<crate::check_types::Ty::TyFlex>(walk_84412) ? ({
                            auto&& n = prism_rtl::as<crate::check_types::Ty::TyFlex>(walk_84412).a0;
                            prism_rtl::finished(crate::check_types::add_nat(acc, n));
                        })
                            : prism_rtl::finished(acc);
                        });
                    });
                    });
                }));
                });
            })));
            })), [=](Array<Nat> fold_84379) {
                return ({
                    auto constrained = fold_84379;
                    lambda_1
                    ? call_value(fold_job(mine, Array<std::tuple<Nat, Text>>{}, ({
                    auto st_2_4 = st_2;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Nat, Text>>>(std::tuple<Array<std::tuple<Nat, Text>>, crate::check_types::Want>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Nat, Text>>, crate::check_types::Want> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto st_2_4_4 = st_2_4;
                        entered(once_job([=]() {
                        return ({
                            auto acc = p0;
                            auto w = p1;
                            call_then(crate::check_types::start_walk(st_2_4_4, w.ty), [=](crate::check_types::Ty walk_84551) {
                            return ({
                                prism_rtl::is<crate::check_types::Ty::TyFlex>(walk_84551) ? ({
                                auto&& n = prism_rtl::as<crate::check_types::Ty::TyFlex>(walk_84551).a0;
                                crate::lexer::has_prefix(w.cls, Text::lit("Range "))
                                ? prism_rtl::finished(acc)
                                : prism_rtl::finished(prelude::push(acc, std::tuple{n, w.cls}));
                            })
                                : prism_rtl::finished(acc);
                            });
                        });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Nat, Text>> fold_84518) {
                    return ({
                        auto bounds = fold_84518;
                        auto st1 = fold(mine, st_2, [&](const crate::check_types::St& s, const crate::check_types::Want& w) { return crate::check_types::note_choice(crate::check_types::note_impl(s, w->file, w.span, w.cls, w.ty, Text::lit("quantified")), w->file, w.span, w.cls, Text::lit("any")); });
                        auto st2 = ({
                            crate::check_types::St this_ = st1;
                            this_.wants = others;
                            this_;
                        });
                        (prism_rtl::finished(std::tuple{Array<Nat>{}, bounds, st2}));
                    });
                })
                    : ({
                    auto st2 = crate::check_types::lower_levels(st_2, constrained, st_2.level);
                    (prism_rtl::finished(std::tuple{constrained, Array<std::tuple<Nat, Text>>{}, st2}));
                });
                });
            });
            });
        });
        });
    });
}


/// `Start WantsAbove, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check_types::St>> start_wants_above(crate::check_types::St st, crate::check_types::Ty t, bool lambda) {
    return prism_rtl::make_rc<WantsAbove>(st, t, lambda);
}


/// CheckLocalFn: unbounded fn Env, St, FnClause, Range -> ((Env, St))
std::tuple<Env, crate::check_types::St> check_local_fn(const Env& env, const crate::check_types::St& st, const crate::ast::FnClause& f, const crate::ast::Range& span) {
    auto name = crate::check_env::def_name_text(f.name);
    auto&& _m = prelude::get(env.locals, name);
    if (prism_rtl::is_some(_m)) {
        auto&& sc = prism_rtl::some_of(_m);
        return ((len(sc.qs) > Nat(0u)) || (len(sc.cqs) > Nat(0u))) || (!crate::check_types::is_flex_var(st, sc.ty))
            ? ({
            auto st2 = check_clauses(env, st, name, Array(std::vector{f}), sc, span);
            std::tuple{env, st2};
        })
            : ({
            auto st0 = crate::check_types::enter_level(st);
            auto [lt, st1] = clause_lambda(env, st0, f);
            auto st2 = crate::check_types::unify(st1, sc.ty, lt, span);
            auto st3 = crate::check_env::solve_wants(env.g, st2, env.givens, false);
            auto st4 = crate::check_types::leave_level(st3);
            auto t = crate::check_types::zonk(st4, sc.ty);
            (crate::check_types::holds_node(st4, t)
            ? std::tuple{env, st4}
            : ({
            auto [keep, bounds, st5] = wants_above(st4, t, true);
            auto [sc2, st6] = crate::check_types::generalize(st5, t, keep, bounds);
            std::tuple{with_local(env, name, sc2), st6};
        }));
        });
    }
    if (prism_rtl::is_none(_m)) {
        return std::tuple{env, st};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> CheckLocalFn::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& f = this->f;
    const auto& span = this->span;
    auto name = crate::check_env::def_name_text(f.name);
    return ({
        auto&& _m = prelude::get(env.locals, name);
        prism_rtl::is_some(_m) ? ({
        auto&& sc = prism_rtl::some_of(_m);
        ((len(sc.qs) > Nat(0u)) || (len(sc.cqs) > Nat(0u))) || (!crate::check_types::is_flex_var(st, sc.ty))
        ? ({
        auto env_1 = env;
        auto f_2 = f;
        auto span_3 = span;
        auto st_4 = st;
        call_then(start_check_clauses(env_1, st_4, name, Array(std::vector{f_2}), sc, span_3), [=](crate::check_types::St check_clauses_85439) {
        return ({
            auto st2 = check_clauses_85439;
            (prism_rtl::finished(std::tuple{env_1, st2}));
        });
    });
    })
        : ({
        auto st0 = crate::check_types::enter_level(st);
        auto env_1 = env;
        auto f_2 = f;
        auto span_3 = span;
        call_then(start_clause_lambda(env_1, st0, f_2), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> clause_lambda_85604) {
        return ({
            auto [lt, st1] = clause_lambda_85604;
            call_then(crate::check_types::start_unify(st1, sc.ty, lt, span_3), [=](crate::check_types::St unify_85655) {
            return ({
                auto st2 = unify_85655;
                call_then(crate::check_env::start_solve_wants(env_1.g, st2, env_1.givens, false), [=](crate::check_types::St solve_wants_85708) {
                return ({
                    auto st3 = solve_wants_85708;
                    auto st4 = crate::check_types::leave_level(st3);
                    call_then(crate::check_types::start_zonk(st4, sc.ty), [=](crate::check_types::Ty zonk_85814) {
                    return ({
                        auto t = zonk_85814;
                        call_then(crate::check_types::start_holds_node(st4, t), [=](bool holds_node_85849) {
                        return holds_node_85849
                            ? prism_rtl::finished(std::tuple{env_1, st4})
                            : call_then(start_wants_above(st4, t, true), [=](std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check_types::St> wants_above_85950) {
                            return ({
                                auto [keep, bounds, st5] = wants_above_85950;
                                call_then(crate::check_types::start_generalize(st5, t, keep, bounds), [=](std::tuple<crate::check_types::Scheme, crate::check_types::St> generalize_86013) {
                                return ({
                                    auto [sc2, st6] = generalize_86013;
                                    (prism_rtl::finished(std::tuple{with_local(env_1, name, sc2), st6}));
                                });
                            });
                            });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{env, st})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CheckLocalFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_check_local_fn(Env env, crate::check_types::St st, crate::ast::FnClause f, crate::ast::Range span) {
    return prism_rtl::make_rc<CheckLocalFn>(env, st, f, span);
}


/// ClauseLambda: unbounded fn Env, St, FnClause -> ((Ty, St))
std::tuple<crate::check_types::Ty, crate::check_types::St> clause_lambda(const Env& env, const crate::check_types::St& st, const crate::ast::FnClause& f) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<crate::ast::LambdaBody> _v;
        auto&& _m = f.body;
        if (prism_rtl::is<crate::ast::FnBody::BodyExpr>(_m)) {
            auto&& e = prism_rtl::as<crate::ast::FnBody::BodyExpr>(_m).a0;
            _v.set(crate::ast::LambdaBody(crate::ast::LambdaBody::LbExpr{prism_rtl::rc(e)}));
            goto _done;
        }
        if (prism_rtl::is<crate::ast::FnBody::BodyBlock>(_m)) {
            auto&& b = prism_rtl::as<crate::ast::FnBody::BodyBlock>(_m).a0;
            _v.set(crate::ast::LambdaBody(crate::ast::LambdaBody::LbBlock{b}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return infer_lambda(env, st, crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ELambda{std::optional(f.params), prism_rtl::rc(body)})), .span = f.span}, std::optional<crate::check_types::Ty>{});
}


prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> ClauseLambda::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& f = this->f;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<crate::ast::LambdaBody> _v;
        auto&& _m = f.body;
        if (prism_rtl::is<crate::ast::FnBody::BodyExpr>(_m)) {
            auto&& e = prism_rtl::as<crate::ast::FnBody::BodyExpr>(_m).a0;
            _v.set(crate::ast::LambdaBody(crate::ast::LambdaBody::LbExpr{prism_rtl::rc(e)}));
            goto _done;
        }
        if (prism_rtl::is<crate::ast::FnBody::BodyBlock>(_m)) {
            auto&& b = prism_rtl::as<crate::ast::FnBody::BodyBlock>(_m).a0;
            _v.set(crate::ast::LambdaBody(crate::ast::LambdaBody::LbBlock{b}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::more(prism_rtl::rc(InferLambda(env, st, crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ELambda{std::optional(f.params), prism_rtl::rc(body)})), .span = f.span}, std::optional<crate::check_types::Ty>{})));
}


/// `Start ClauseLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_clause_lambda(Env env, crate::check_types::St st, crate::ast::FnClause f) {
    return prism_rtl::make_rc<ClauseLambda>(env, st, f);
}


/// CheckClauses: unbounded fn Env, St, Text, [FnClause], Scheme, Range -> St
crate::check_types::St check_clauses(const Env& env, const crate::check_types::St& st, const Text& name, const Array<crate::ast::FnClause>& clauses, const crate::check_types::Scheme& sc, const crate::ast::Range& span) {
    auto t = crate::check_types::skolemize(sc);
    auto givens = append(env.givens, sc.bounds);
    auto env2 = ({
        Env this_ = env;
        this_.givens = givens;
        this_.mark = crate::lexer::head(crate::check_types::marks_of(name));
        this_.def_name = name;
        this_;
    });
    if (prism_rtl::is<crate::check_types::Ty::TyFn>(t)) {
        auto&& col = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a0;
        auto&& params = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a2;
        auto outer_color = st.color;
        auto outer_flex = st.color_flex;
        auto st0 = ({
            crate::check_types::St this_ = st;
            this_.color = crate::check_types::Col(crate::check_types::Col::CBound{});
            this_.color_why = Text::lit("");
            this_.color_flex = Array<std::tuple<crate::check_types::Col, Text, crate::ast::Range>>{};
            this_.col_up = fold(sc.cjoins, this_.col_up, [&](const Map<Text, Text>& m, const std::tuple<Text, Text>& _p1) {
                auto&& lo = std::get<0>(_p1);
                auto&& hi = std::get<1>(_p1);
                return insert(m, lo, hi);
            });
            this_;
        });
        auto st1 = run_to_end(fold_job(clauses, st0, ({
            auto env2_1 = env2;
            auto params_2 = params;
            auto res_3 = res;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::St>(std::tuple<crate::check_types::St, crate::ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<crate::check_types::St, crate::ast::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env2_1_4 = env2_1;
                auto params_2_4 = params_2;
                auto res_3_4 = res_3;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto c = p1;
                    (prism_rtl::more(prism_rtl::rc(CheckClause(env2_1_4, s, c, params_2_4, res_3_4))));
                });
            }));
            });
        })));
        })));
        auto st1b = crate::check_types::settle_body(crate::check_env::solve_wants(env.g, st1, givens, false), col, name);
        auto st2 = crate::check_passes::clause_coverage(env2, st1b, clauses, params, span);
        auto st3 = crate::check_types::col_leq(st2.color, col)
            ? st2
            : crate::check_types::err_fix(st2, Text::lit("calls-unbounded"), span, prism_rtl::cat(crate::check_types::col_word(col), " `", name, "` calls ", crate::check_types::col_word(st2.color), " `", st2.color_why, "`"), prism_rtl::cat("mark `", name, "` `unbounded fn`, or run the call through `@Run`"));
        auto st4 = crate::check_types::note_fn(st3, span, name, col, st2.color);
        crate::check_types::St this_ = st4;
        this_.color = outer_color;
        this_.color_flex = outer_flex;
        return this_;
    }
    {
        auto&& other = t;
        auto st1 = run_to_end(fold_job(clauses, st, ({
            auto env2_1 = env2;
            auto other_2 = other;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::St>(std::tuple<crate::check_types::St, crate::ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<crate::check_types::St, crate::ast::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env2_1_3 = env2_1;
                auto other_2_3 = other_2;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto c = p1;
                    (prism_rtl::more(prism_rtl::rc(CheckClause(env2_1_3, s, c, Array<crate::check_types::Ty>{}, other_2_3))));
                });
            }));
            });
        })));
        })));
        return st1;
    }
}


prism_rtl::Turn<crate::check_types::St> CheckClauses::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& name = this->name;
    const auto& clauses = this->clauses;
    const auto& sc = this->sc;
    const auto& span = this->span;
    auto clauses_1 = clauses;
    auto env_2 = env;
    auto name_3 = name;
    auto sc_4 = sc;
    auto span_5 = span;
    auto st_6 = st;
    return call_then(crate::check_types::start_skolemize(sc_4), [=](crate::check_types::Ty skolemize_86981) {
        return ({
            auto t = skolemize_86981;
            auto givens = append(env_2.givens, sc_4.bounds);
            auto env2 = ({
                Env this_ = env_2;
                this_.givens = givens;
                this_.mark = crate::lexer::head(crate::check_types::marks_of(name_3));
                this_.def_name = name_3;
                this_;
            });
            ({
            prism_rtl::is<crate::check_types::Ty::TyFn>(t) ? ({
            auto&& col = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a0;
            auto&& params = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a1;
            auto&& res = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a2;
            ({
            auto outer_color = st_6.color;
            auto outer_flex = st_6.color_flex;
            auto st0 = ({
                crate::check_types::St this_ = st_6;
                this_.color = crate::check_types::Col(crate::check_types::Col::CBound{});
                this_.color_why = Text::lit("");
                this_.color_flex = Array<std::tuple<crate::check_types::Col, Text, crate::ast::Range>>{};
                this_.col_up = fold(sc_4.cjoins, this_.col_up, [&](const Map<Text, Text>& m, const std::tuple<Text, Text>& _p1) {
                    auto&& lo = std::get<0>(_p1);
                    auto&& hi = std::get<1>(_p1);
                    return insert(m, lo, hi);
                });
                this_;
            });
            auto col_7 = col;
            auto params_8 = params;
            auto res_9 = res;
            call_value(fold_job(clauses_1, st0, ({
            auto env2_10 = env2;
            auto params_8_11 = params_8;
            auto res_9_11 = res_9;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::St>(std::tuple<crate::check_types::St, crate::ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<crate::check_types::St, crate::ast::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env2_10_11 = env2_10;
                auto params_8_11_11 = params_8_11;
                auto res_9_11_11 = res_9_11;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto c = p1;
                    (prism_rtl::more(prism_rtl::rc(CheckClause(env2_10_11, s, c, params_8_11_11, res_9_11_11))));
                });
            }));
            });
        })));
        })), [=](crate::check_types::St fold_87533) {
            return ({
                auto st1 = fold_87533;
                call_then(crate::check_env::start_solve_wants(env_2.g, st1, givens, false), [=](crate::check_types::St solve_wants_87631) {
                return call_then(crate::check_types::start_settle_body(solve_wants_87631, col_7, name_3), [=](crate::check_types::St settle_body_87619) {
                    return ({
                        auto st1b = settle_body_87619;
                        call_then(crate::check_passes::start_clause_coverage(env2, st1b, clauses_1, params_8, span_5), [=](crate::check_types::St clause_coverage_87702) {
                        return ({
                            auto st2 = clause_coverage_87702;
                            auto st3 = crate::check_types::col_leq(st2.color, col_7)
                                ? st2
                                : crate::check_types::err_fix(st2, Text::lit("calls-unbounded"), span_5, prism_rtl::cat(crate::check_types::col_word(col_7), " `", name_3, "` calls ", crate::check_types::col_word(st2.color), " `", st2.color_why, "`"), prism_rtl::cat("mark `", name_3, "` `unbounded fn`, or run the call through `@Run`"));
                            auto st4 = crate::check_types::note_fn(st3, span_5, name_3, col_7, st2.color);
                            (prism_rtl::finished(({
                            crate::check_types::St this_ = st4;
                            this_.color = outer_color;
                            this_.color_flex = outer_flex;
                            this_;
                        })));
                        });
                    });
                    });
                });
            });
            });
        });
        });
        })
            : ({
            auto&& other = t;
            ({
            auto other_7 = other;
            call_value(fold_job(clauses_1, st_6, ({
            auto env2_8 = env2;
            auto other_7_9 = other_7;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::St>(std::tuple<crate::check_types::St, crate::ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<crate::check_types::St, crate::ast::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env2_8_9 = env2_8;
                auto other_7_9_9 = other_7_9;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto c = p1;
                    (prism_rtl::more(prism_rtl::rc(CheckClause(env2_8_9, s, c, Array<crate::check_types::Ty>{}, other_7_9_9))));
                });
            }));
            });
        })));
        })), [=](crate::check_types::St fold_88197) {
            return ({
                auto st1 = fold_88197;
                (prism_rtl::finished(st1));
            });
        });
        });
        });
        });
        });
    });
}


/// `Start CheckClauses, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::St> start_check_clauses(Env env, crate::check_types::St st, Text name, Array<crate::ast::FnClause> clauses, crate::check_types::Scheme sc, crate::ast::Range span) {
    return prism_rtl::make_rc<CheckClauses>(env, st, name, clauses, sc, span);
}


/// CheckClause: unbounded fn Env, St, FnClause, [Ty], Ty -> St
crate::check_types::St check_clause(const Env& env, const crate::check_types::St& st, const crate::ast::FnClause& c, const Array<crate::check_types::Ty>& params, const crate::check_types::Ty& res) {
    return len(c.params) != len(params)
        ? crate::check_types::err(st, Text::lit("mismatch"), c.span, prism_rtl::cat("this clause takes ", crate::check_errors::count_word(len(c.params)), " parameter", len(c.params) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; the signature has ", crate::check_errors::count_word(len(params))))
        : ({
        auto [env2, st1] = run_to_end(fold_job(crate::check_errors::range0(len(params)), std::tuple{env, st}, ({
            auto c_1 = c;
            auto params_2 = params;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>>(std::tuple<std::tuple<Env, crate::check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, crate::check_types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto c_1_3 = c_1;
                auto params_2_3 = params_2;
                entered(once_job([=]() {
                return ({
                    auto [en, s] = p0;
                    auto i = p1;
                    (prism_rtl::more(prism_rtl::rc(BindPattern(en, s, or_(index(c_1_3.params, i), crate::ast::Pattern_{.kind = prism_rtl::rc(crate::ast::PatternKind(crate::ast::PatternKind::PIgnore{})), .span = c_1_3.span}), or_(index(params_2_3, i), crate::check_types::Ty(crate::check_types::Ty::TyErr{})), true))));
                });
            }));
            });
        }));
        })));
        check_body(env2, st1, c.body, res);
    });
}


prism_rtl::Turn<crate::check_types::St> CheckClause::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& params = this->params;
    const auto& res = this->res;
    return len(c.params) != len(params)
        ? prism_rtl::finished(crate::check_types::err(st, Text::lit("mismatch"), c.span, prism_rtl::cat("this clause takes ", crate::check_errors::count_word(len(c.params)), " parameter", len(c.params) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; the signature has ", crate::check_errors::count_word(len(params)))))
        : ({
        auto c_1 = c;
        auto env_2 = env;
        auto params_3 = params;
        auto res_4 = res;
        auto st_5 = st;
        call_value(fold_job(crate::check_errors::range0(len(params_3)), std::tuple{env_2, st_5}, ({
        auto c_1_6 = c_1;
        auto params_3_6 = params_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>>(std::tuple<std::tuple<Env, crate::check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, crate::check_types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto c_1_6_6 = c_1_6;
            auto params_3_6_6 = params_3_6;
            entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto i = p1;
                (prism_rtl::more(prism_rtl::rc(BindPattern(en, s, or_(index(c_1_6_6.params, i), crate::ast::Pattern_{.kind = prism_rtl::rc(crate::ast::PatternKind(crate::ast::PatternKind::PIgnore{})), .span = c_1_6_6.span}), or_(index(params_3_6_6, i), crate::check_types::Ty(crate::check_types::Ty::TyErr{})), true))));
            });
        }));
        });
    }));
    })), [=](std::tuple<Env, crate::check_types::St> fold_88628) {
        return ({
            auto [env2, st1] = fold_88628;
            (prism_rtl::more(prism_rtl::rc(CheckBody(env2, st1, c_1.body, res_4))));
        });
    });
    });
}


/// `Start CheckClause, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::St> start_check_clause(Env env, crate::check_types::St st, crate::ast::FnClause c, Array<crate::check_types::Ty> params, crate::check_types::Ty res) {
    return prism_rtl::make_rc<CheckClause>(env, st, c, params, res);
}


/// CheckBody: unbounded fn Env, St, FnBody, Ty -> St
crate::check_types::St check_body(const Env& env, const crate::check_types::St& st, const crate::ast::FnBody& body, const crate::check_types::Ty& res) {
    if (prism_rtl::is<crate::ast::FnBody::BodyExpr>(body)) {
        auto&& e = prism_rtl::as<crate::ast::FnBody::BodyExpr>(body).a0;
        return check(env, st, e, res);
    }
    if (prism_rtl::is<crate::ast::FnBody::BodyBlock>(body)) {
        auto&& b = prism_rtl::as<crate::ast::FnBody::BodyBlock>(body).a0;
        return env.mark == Text::lit("@")
            ? ({
            __label__ _done;
            prism_rtl::Slot<crate::check_types::St> _v;
            auto&& _m = crate::check_types::walk(st, res);
            if (prism_rtl::is<crate::check_types::Ty::TyAt>(_m)) {
                auto&& inner = prism_rtl::as<crate::check_types::Ty::TyAt>(_m).a0;
                auto&& rw = prism_rtl::as<crate::check_types::Ty::TyAt>(_m).a1;
                _v.set(({
                    auto env2 = ({
                        Env this_ = env;
                        this_.scope = rw;
                        this_;
                    });
                    auto [t, st2] = crate::check_blocks::infer_widget_block(env2, st, b);
                    (crate::check_types::unify(st2, inner, t, b.span));
                }));
                goto _done;
            }
            {
                auto&& other = _m;
                _v.set(crate::check_types::err(st, Text::lit("mismatch"), b.span, prism_rtl::cat("a widget block builds a blueprint; the signature says `", crate::check_types::show_ty(st, other), "`")));
                goto _done;
            }
        _done:
            _v.take();
        })
            : (env.mark == Text::lit("?")) || (env.mark == Text::lit("~"))
            ? ({
            auto [t, st2] = crate::check_blocks::infer_given_block(env, st, b, env.mark);
            (crate::check_types::unify(st2, res, t, b.span));
        })
            : ({
            auto [t, st2] = infer_expr_block(env, st, b);
            (crate::check_types::unify(st2, res, t, b.span));
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check_types::St> CheckBody::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& body = this->body;
    const auto& res = this->res;
    return ({
        prism_rtl::is<crate::ast::FnBody::BodyExpr>(body) ? ({
        auto&& e = prism_rtl::as<crate::ast::FnBody::BodyExpr>(body).a0;
        prism_rtl::more(prism_rtl::rc(Check(env, st, e, res)));
    })
        : prism_rtl::is<crate::ast::FnBody::BodyBlock>(body) ? ({
        auto&& b = prism_rtl::as<crate::ast::FnBody::BodyBlock>(body).a0;
        env.mark == Text::lit("@")
        ? ({
        auto b_1 = b;
        auto env_2 = env;
        auto res_3 = res;
        auto st_4 = st;
        call_then(crate::check_types::start_walk(st_4, res_3), [=](crate::check_types::Ty walk_89198) {
        return ({
            prism_rtl::is<crate::check_types::Ty::TyAt>(walk_89198) ? ({
            auto&& inner = prism_rtl::as<crate::check_types::Ty::TyAt>(walk_89198).a0;
            auto&& rw = prism_rtl::as<crate::check_types::Ty::TyAt>(walk_89198).a1;
            ({
            auto env2 = ({
                Env this_ = env_2;
                this_.scope = rw;
                this_;
            });
            call_then(crate::check_blocks::start_infer_widget_block(env2, st_4, b_1), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_widget_block_89363) {
            return ({
                auto [t, st2] = infer_widget_block_89363;
                (prism_rtl::more(prism_rtl::rc(crate::check_types::Unify(st2, inner, t, b_1.span))));
            });
        });
        });
        })
            : ({
            auto&& other = walk_89198;
            call_then(crate::check_types::start_show_ty(st_4, other), [=](Text show_ty_89548) { return prism_rtl::finished(crate::check_types::err(st_4, Text::lit("mismatch"), b_1.span, prism_rtl::cat("a widget block builds a blueprint; the signature says `", show_ty_89548, "`"))); });
        });
        });
    });
    })
        : (env.mark == Text::lit("?")) || (env.mark == Text::lit("~"))
        ? ({
        auto b_1 = b;
        auto env_2 = env;
        auto res_3 = res;
        auto st_4 = st;
        call_then(crate::check_blocks::start_infer_given_block(env_2, st_4, b_1, env_2.mark), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_given_block_89650) {
        return ({
            auto [t, st2] = infer_given_block_89650;
            (prism_rtl::more(prism_rtl::rc(crate::check_types::Unify(st2, res_3, t, b_1.span))));
        });
    });
    })
        : ({
        auto b_1 = b;
        auto env_2 = env;
        auto res_3 = res;
        auto st_4 = st;
        call_then(start_infer_expr_block(env_2, st_4, b_1), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_expr_block_89768) {
        return ({
            auto [t, st2] = infer_expr_block_89768;
            (prism_rtl::more(prism_rtl::rc(crate::check_types::Unify(st2, res_3, t, b_1.span))));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CheckBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::St> start_check_body(Env env, crate::check_types::St st, crate::ast::FnBody body, crate::check_types::Ty res) {
    return prism_rtl::make_rc<CheckBody>(env, st, body, res);
}


/// InferTemplate: unbounded fn Env, St, Template -> ((Ty, St))
std::tuple<crate::check_types::Ty, crate::check_types::St> infer_template(const Env& env, const crate::check_types::St& st, const crate::ast::Template& t) {
    auto st2 = run_to_end(fold_job(t.parts, st, ({
        auto env_1 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::St>(std::tuple<crate::check_types::St, crate::ast::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<crate::check_types::St, crate::ast::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_2 = env_1;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto part = p1;
                (prism_rtl::more(prism_rtl::rc(TemplatePartCheck(env_1_2, s, part))));
            });
        }));
        });
    })));
    })));
    return std::tuple{crate::check_types::t_text(), st2};
}

}  // namespace crate::check_expr
