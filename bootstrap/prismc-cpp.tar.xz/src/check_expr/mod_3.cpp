// The module `CheckExpr`, from `target/bootstrap/cpp-src/prismc/check-expr.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include <check_expr/module.hpp>
#include <check_env/module.hpp>
#include <check_errors/module.hpp>
#include <check_types/module.hpp>
#include <ast/module.hpp>
#include <check_blocks/module.hpp>
#include <check_passes/module.hpp>
#include <lexer/module.hpp>
#include <typed/module.hpp>
#include <check_env/generic.hpp>
#include <lexer/generic.hpp>

namespace crate::check_expr {

prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> InferTemplate::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    auto env_1 = env;
    auto st_2 = st;
    auto t_3 = t;
    return call_value(fold_job(t_3.parts, st_2, ({
        auto env_1_4 = env_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::St>(std::tuple<crate::check_types::St, crate::ast::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<crate::check_types::St, crate::ast::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_4_4 = env_1_4;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto part = p1;
                (prism_rtl::more(prism_rtl::rc(TemplatePartCheck(env_1_4_4, s, part))));
            });
        }));
        });
    })));
    })), [=](crate::check_types::St fold_90206) {
        return ({
            auto st2 = fold_90206;
            (prism_rtl::finished(std::tuple{crate::check_types::t_text(), st2}));
        });
    });
}


/// `Start InferTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_template(Env env, crate::check_types::St st, crate::ast::Template t) {
    return prism_rtl::make_rc<InferTemplate>(env, st, t);
}


/// TemplatePartCheck: unbounded fn Env, St, TemplatePart -> St
crate::check_types::St template_part_check(const Env& env, const crate::check_types::St& st, const crate::ast::TemplatePart& part) {
    if (prism_rtl::is<crate::ast::TemplatePart::TpText>(part)) {
        return st;
    }
    if (prism_rtl::is<crate::ast::TemplatePart::TpPlaceholder>(part)) {
        auto&& x = prism_rtl::as<crate::ast::TemplatePart::TpPlaceholder>(part).a0;
        auto [t, st2] = infer(env, st, x);
        return show_want(st2, is_time_sigil(crate::check_types::head_sigil(st2, t))
            ? inner_of(st2, t)
            : t, x.span);
    }
    if (prism_rtl::is<crate::ast::TemplatePart::TpBlock>(part)) {
        auto&& b = prism_rtl::as<crate::ast::TemplatePart::TpBlock>(part).a0;
        auto [t, st2] = infer_expr_block(env, st, b);
        return st2;
    }
    if (prism_rtl::is<crate::ast::TemplatePart::TpCall>(part)) {
        auto&& n = prism_rtl::as<crate::ast::TemplatePart::TpCall>(part).a0;
        auto&& args = prism_rtl::as<crate::ast::TemplatePart::TpCall>(part).a1;
        auto&& parts_opt = prism_rtl::as<crate::ast::TemplatePart::TpCall>(part).a2;
        auto&& span = prism_rtl::as<crate::ast::TemplatePart::TpCall>(part).a3;
        return template_call_check(env, st, n, args, parts_opt, span);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check_types::St> TemplatePartCheck::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& part = this->part;
    return ({
        prism_rtl::is<crate::ast::TemplatePart::TpText>(part) ? prism_rtl::finished(st)
        : prism_rtl::is<crate::ast::TemplatePart::TpPlaceholder>(part) ? ({
        auto&& x = prism_rtl::as<crate::ast::TemplatePart::TpPlaceholder>(part).a0;
        ({
        auto env_1 = env;
        auto st_2 = st;
        auto x_3 = x;
        call_then(start_infer(env_1, st_2, x_3), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_90471) {
        return ({
            auto [t, st2] = infer_90471;
            call_then(crate::check_types::start_head_sigil(st2, t), [=](Text head_sigil_90527) { return prism_rtl::more(prism_rtl::rc(ShowWant(st2, is_time_sigil(head_sigil_90527) ? inner_of(st2, t) : t, x_3.span))); });
        });
    });
    });
    })
        : prism_rtl::is<crate::ast::TemplatePart::TpBlock>(part) ? ({
        auto&& b = prism_rtl::as<crate::ast::TemplatePart::TpBlock>(part).a0;
        ({
        auto b_1 = b;
        auto env_2 = env;
        auto st_3 = st;
        call_then(start_infer_expr_block(env_2, st_3, b_1), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_expr_block_90618) {
        return ({
            auto [t, st2] = infer_expr_block_90618;
            (prism_rtl::finished(st2));
        });
    });
    });
    })
        : prism_rtl::is<crate::ast::TemplatePart::TpCall>(part) ? ({
        auto&& n = prism_rtl::as<crate::ast::TemplatePart::TpCall>(part).a0;
        auto&& args = prism_rtl::as<crate::ast::TemplatePart::TpCall>(part).a1;
        auto&& parts_opt = prism_rtl::as<crate::ast::TemplatePart::TpCall>(part).a2;
        auto&& span = prism_rtl::as<crate::ast::TemplatePart::TpCall>(part).a3;
        prism_rtl::more(prism_rtl::rc(TemplateCallCheck(env, st, n, args, parts_opt, span)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplatePartCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::St> start_template_part_check(Env env, crate::check_types::St st, crate::ast::TemplatePart part) {
    return prism_rtl::make_rc<TemplatePartCheck>(env, st, part);
}


/// TemplateCallCheck: unbounded fn Env, St, SName, [Arg], ?[TemplatePart], Range -> St
crate::check_types::St template_call_check(const Env& env, const crate::check_types::St& st, const crate::ast::SName& n, const Array<crate::ast::Arg>& args, const std::optional<Array<crate::ast::TemplatePart>>& parts_opt, const crate::ast::Range& span) {
    auto plain = crate::ast::SName{.sigils = crate::lexer::after_first(n.sigils), .path_ = n->path_, .span = n.span};
    auto&& _qk1_opt = crate::check_env::resolve_value(env.g, env.home, n);
    auto&& qk1_opt = std::get<0>(_qk1_opt);
    auto callee = qk1_opt != std::optional<Text>{} ? n : plain;
    auto [qk_opt, ignore2] = crate::check_env::resolve_value(env.g, env.home, callee);
    auto cname = crate::check_env::sname_key(plain);
    if (prism_rtl::is_none(qk_opt)) {
        auto [ignore3, st2] = call_global(env, st, callee, Array<crate::ast::Arg>{}, span, Array<crate::check_types::Ty>{}, callee.span);
        return st2;
    }
    if (prism_rtl::is_some(qk_opt)) {
        auto&& qk = prism_rtl::some_of(qk_opt);
        auto clauses = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::ast::FnClause>> _v;
            auto&& _m = prelude::get(env.g.fn_at, qk);
            if (prism_rtl::is_some(_m)) {
                auto&& i = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::ast::FnClause>> _v;
                    auto&& _m = index(env.g.defs, i);
                    if (prism_rtl::is_some(_m)) {
                        auto&& d = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<crate::ast::FnClause>> _v;
                            auto&& _m = d.body;
                            if (prism_rtl::is<crate::check_env::DefBody::DbFn>(_m)) {
                                auto&& cs = prism_rtl::as<crate::check_env::DefBody::DbFn>(_m).a0;
                                _v.set(cs);
                                goto _done;
                            }
                            {
                                _v.set(Array<crate::ast::FnClause>{});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<crate::ast::FnClause>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::ast::FnClause>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arity = ({
            __label__ _done;
            prism_rtl::Slot<Nat> _v;
            auto&& _m = index(clauses, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& c = prism_rtl::some_of(_m);
                _v.set(len(c.params));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Nat(0u));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return len(clauses) == Nat(0u)
            ? crate::check_types::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`<@", cname, ">` calls a function without clauses, which name no parameters for its attributes"))
            : ({
            auto [slots, st1] = run_to_end(fold_job(args, std::tuple{Map<Text, crate::ast::Expr>{}, st}, ({
                auto clauses_1 = clauses;
                auto cname_2 = cname;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, crate::ast::Expr>, crate::check_types::St>>(std::tuple<std::tuple<Map<Text, crate::ast::Expr>, crate::check_types::St>, crate::ast::Arg>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, crate::ast::Expr>, crate::check_types::St>, crate::ast::Arg> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto clauses_1_3 = clauses_1;
                    auto cname_2_3 = cname_2;
                    entered(once_job([=]() {
                    return ({
                        auto [m, s] = p0;
                        auto a = p1;
                        ({
                        auto&& _m = a.name;
                        prism_rtl::is_some(_m) ? ({
                        auto&& id = prism_rtl::some_of(_m);
                        ({
                        auto id_3 = id;
                        call_then(start_template_slot(clauses_1_3, id_3.name), [=](std::optional<Nat> template_slot_92417) {
                        return ({
                            prism_rtl::is_some(template_slot_92417) ? ({
                            auto&& j = prism_rtl::some_of(template_slot_92417);
                            crate::check_env::has_key(m, prism_rtl::cat(j))
                            ? prism_rtl::finished(std::tuple{m, crate::check_types::err(s, Text::lit("mismatch"), a.span, prism_rtl::cat("`", id_3.name, "` is given twice"))})
                            : prism_rtl::finished(std::tuple{insert(m, prism_rtl::cat(j), a->value), s});
                        })
                            : prism_rtl::is_none(template_slot_92417) ? prism_rtl::finished(std::tuple{m, crate::check_types::err(s, Text::lit("mismatch"), a.span, prism_rtl::cat("`", cname_2_3, "` has no parameter `", id_3.name, "`"))})
                            : throw prism_rtl::Panic("no arm matched");
                        });
                    });
                    });
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{m, crate::check_types::err(s, Text::lit("mismatch"), a.span, Text::lit("a template call names each argument: `name={{value}}`"))})
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            }));
            })));
            auto body_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::ast::Expr>> _v;
                if (prism_rtl::is_some(parts_opt)) {
                    auto&& ps = prism_rtl::some_of(parts_opt);
                    _v.set(std::optional(crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ETemplate{crate::ast::Template{.keyword = Text::lit("InlineText"), .lang = Text::lit(""), .delims = Text::lit("double"), .parts = ps, .span = span}})), .span = span}));
                    goto _done;
                }
                if (prism_rtl::is_none(parts_opt)) {
                    _v.set(std::optional<crate::ast::Expr>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto last = crate::lexer::dec(arity);
            auto st2 = ({
                __label__ _done;
                prism_rtl::Slot<crate::check_types::St> _v;
                if (prism_rtl::is_some(body_opt)) {
                    auto&& ignore4 = prism_rtl::some_of(body_opt);
                    _v.set((arity == Nat(0u)) || crate::check_env::has_key(slots, prism_rtl::cat(last))
                        ? crate::check_types::err(st1, Text::lit("mismatch"), span, prism_rtl::cat("`", cname, "` has no parameter left for the call's body"))
                        : st1);
                    goto _done;
                }
                if (prism_rtl::is_none(body_opt)) {
                    _v.set(st1);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto quiet = len(st1.diags) > len(st.diags);
            auto [positional_, st3] = run_to_end(fold_job(crate::check_errors::range0(arity), std::tuple{Array<crate::ast::Arg>{}, st2}, ({
                auto slots_1 = slots;
                auto body_opt_2 = body_opt;
                auto last_3 = last;
                auto span_4 = span;
                auto clauses_5 = clauses;
                auto cname_6 = cname;
                auto quiet_7 = quiet;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::ast::Arg>, crate::check_types::St>>(std::tuple<std::tuple<Array<crate::ast::Arg>, crate::check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::ast::Arg>, crate::check_types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto slots_1_8 = slots_1;
                    auto body_opt_2_8 = body_opt_2;
                    auto last_3_8 = last_3;
                    auto span_4_8 = span_4;
                    auto clauses_5_8 = clauses_5;
                    auto cname_6_8 = cname_6;
                    auto quiet_7_8 = quiet_7;
                    entered(once_job([=]() {
                    return ({
                        auto [acc, s] = p0;
                        auto j = p1;
                        ({
                        auto&& _m = prelude::get(slots_1_8, prism_rtl::cat(j));
                        prism_rtl::is_some(_m) ? ({
                        auto&& v_ = prism_rtl::some_of(_m);
                        prism_rtl::finished(std::tuple{prelude::push(acc, crate::ast::Arg{.name = std::optional<crate::ast::Ident>{}, .value = v_, .span = v_.span}), s});
                    })
                        : prism_rtl::is_none(_m) ? ({
                        prism_rtl::is_some(body_opt_2_8) ? ({
                        auto&& b = prism_rtl::some_of(body_opt_2_8);
                        j == last_3_8
                        ? prism_rtl::finished(std::tuple{prelude::push(acc, crate::ast::Arg{.name = std::optional<crate::ast::Ident>{}, .value = b, .span = span_4_8}), s})
                        : prism_rtl::more(prism_rtl::rc(TemplateMissing(acc, s, clauses_5_8, j, cname_6_8, span_4_8, quiet_7_8)));
                    })
                        : prism_rtl::is_none(body_opt_2_8) ? prism_rtl::more(prism_rtl::rc(TemplateMissing(acc, s, clauses_5_8, j, cname_6_8, span_4_8, quiet_7_8)))
                        : throw prism_rtl::Panic("no arm matched");
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            }));
            })));
            auto [t, st4] = call_global(env, st3, callee, positional_, span, Array<crate::check_types::Ty>{}, callee.span);
            (crate::check_types::unify(st4, crate::check_types::t_text(), t, span));
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check_types::St> TemplateCallCheck::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& args = this->args;
    const auto& parts_opt = this->parts_opt;
    const auto& span = this->span;
    auto plain = crate::ast::SName{.sigils = crate::lexer::after_first(n.sigils), .path_ = n->path_, .span = n.span};
    auto&& _qk1_opt = crate::check_env::resolve_value(env.g, env.home, n);
    auto&& qk1_opt = std::get<0>(_qk1_opt);
    auto callee = qk1_opt != std::optional<Text>{} ? n : plain;
    auto [qk_opt, ignore2] = crate::check_env::resolve_value(env.g, env.home, callee);
    auto cname = crate::check_env::sname_key(plain);
    return ({
        prism_rtl::is_none(qk_opt) ? ({
        auto env_1 = env;
        auto span_2 = span;
        auto st_3 = st;
        call_then(start_call_global(env_1, st_3, callee, Array<crate::ast::Arg>{}, span_2, Array<crate::check_types::Ty>{}, callee.span), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> call_global_91675) {
        return ({
            auto [ignore3, st2] = call_global_91675;
            (prism_rtl::finished(st2));
        });
    });
    })
        : prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        ({
        auto clauses = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::ast::FnClause>> _v;
            auto&& _m = prelude::get(env.g.fn_at, qk);
            if (prism_rtl::is_some(_m)) {
                auto&& i = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::ast::FnClause>> _v;
                    auto&& _m = index(env.g.defs, i);
                    if (prism_rtl::is_some(_m)) {
                        auto&& d = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<crate::ast::FnClause>> _v;
                            auto&& _m = d.body;
                            if (prism_rtl::is<crate::check_env::DefBody::DbFn>(_m)) {
                                auto&& cs = prism_rtl::as<crate::check_env::DefBody::DbFn>(_m).a0;
                                _v.set(cs);
                                goto _done;
                            }
                            {
                                _v.set(Array<crate::ast::FnClause>{});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<crate::ast::FnClause>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::ast::FnClause>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arity = ({
            __label__ _done;
            prism_rtl::Slot<Nat> _v;
            auto&& _m = index(clauses, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& c = prism_rtl::some_of(_m);
                _v.set(len(c.params));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Nat(0u));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        len(clauses) == Nat(0u)
        ? prism_rtl::finished(crate::check_types::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`<@", cname, ">` calls a function without clauses, which name no parameters for its attributes")))
        : ({
        auto parts_opt_1 = parts_opt;
        auto args_2 = args;
        auto env_3 = env;
        auto span_4 = span;
        auto st_5 = st;
        call_value(fold_job(args_2, std::tuple{Map<Text, crate::ast::Expr>{}, st_5}, ({
        auto clauses_6 = clauses;
        auto cname_7 = cname;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, crate::ast::Expr>, crate::check_types::St>>(std::tuple<std::tuple<Map<Text, crate::ast::Expr>, crate::check_types::St>, crate::ast::Arg>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, crate::ast::Expr>, crate::check_types::St>, crate::ast::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto clauses_6_8 = clauses_6;
            auto cname_7_8 = cname_7;
            entered(once_job([=]() {
            return ({
                auto [m, s] = p0;
                auto a = p1;
                ({
                auto&& _m = a.name;
                prism_rtl::is_some(_m) ? ({
                auto&& id = prism_rtl::some_of(_m);
                ({
                auto id_8 = id;
                call_then(start_template_slot(clauses_6_8, id_8.name), [=](std::optional<Nat> template_slot_92417) {
                return ({
                    prism_rtl::is_some(template_slot_92417) ? ({
                    auto&& j = prism_rtl::some_of(template_slot_92417);
                    crate::check_env::has_key(m, prism_rtl::cat(j))
                    ? prism_rtl::finished(std::tuple{m, crate::check_types::err(s, Text::lit("mismatch"), a.span, prism_rtl::cat("`", id_8.name, "` is given twice"))})
                    : prism_rtl::finished(std::tuple{insert(m, prism_rtl::cat(j), a->value), s});
                })
                    : prism_rtl::is_none(template_slot_92417) ? prism_rtl::finished(std::tuple{m, crate::check_types::err(s, Text::lit("mismatch"), a.span, prism_rtl::cat("`", cname_7_8, "` has no parameter `", id_8.name, "`"))})
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{m, crate::check_types::err(s, Text::lit("mismatch"), a.span, Text::lit("a template call names each argument: `name={{value}}`"))})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Map<Text, crate::ast::Expr>, crate::check_types::St> fold_92332) {
        return ({
            auto [slots, st1] = fold_92332;
            auto body_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::ast::Expr>> _v;
                if (prism_rtl::is_some(parts_opt)) {
                    auto&& ps = prism_rtl::some_of(parts_opt);
                    _v.set(std::optional(crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ETemplate{crate::ast::Template{.keyword = Text::lit("InlineText"), .lang = Text::lit(""), .delims = Text::lit("double"), .parts = ps, .span = span_4}})), .span = span_4}));
                    goto _done;
                }
                if (prism_rtl::is_none(parts_opt)) {
                    _v.set(std::optional<crate::ast::Expr>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto last = crate::lexer::dec(arity);
            auto st2 = ({
                __label__ _done;
                prism_rtl::Slot<crate::check_types::St> _v;
                if (prism_rtl::is_some(body_opt)) {
                    auto&& ignore4 = prism_rtl::some_of(body_opt);
                    _v.set((arity == Nat(0u)) || crate::check_env::has_key(slots, prism_rtl::cat(last))
                        ? crate::check_types::err(st1, Text::lit("mismatch"), span_4, prism_rtl::cat("`", cname, "` has no parameter left for the call's body"))
                        : st1);
                    goto _done;
                }
                if (prism_rtl::is_none(body_opt)) {
                    _v.set(st1);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto quiet = len(st1.diags) > len(st_5.diags);
            call_value(fold_job(crate::check_errors::range0(arity), std::tuple{Array<crate::ast::Arg>{}, st2}, ({
            auto slots_6 = slots;
            auto body_opt_7 = body_opt;
            auto last_8 = last;
            auto span_4_9 = span_4;
            auto clauses_9 = clauses;
            auto cname_10 = cname;
            auto quiet_11 = quiet;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::ast::Arg>, crate::check_types::St>>(std::tuple<std::tuple<Array<crate::ast::Arg>, crate::check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::ast::Arg>, crate::check_types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto slots_6_12 = slots_6;
                auto body_opt_7_12 = body_opt_7;
                auto last_8_12 = last_8;
                auto span_4_9_12 = span_4_9;
                auto clauses_9_12 = clauses_9;
                auto cname_10_12 = cname_10;
                auto quiet_11_12 = quiet_11;
                entered(once_job([=]() {
                return ({
                    auto [acc, s] = p0;
                    auto j = p1;
                    ({
                    auto&& _m = prelude::get(slots_6_12, prism_rtl::cat(j));
                    prism_rtl::is_some(_m) ? ({
                    auto&& v_ = prism_rtl::some_of(_m);
                    prism_rtl::finished(std::tuple{prelude::push(acc, crate::ast::Arg{.name = std::optional<crate::ast::Ident>{}, .value = v_, .span = v_.span}), s});
                })
                    : prism_rtl::is_none(_m) ? ({
                    prism_rtl::is_some(body_opt_7_12) ? ({
                    auto&& b = prism_rtl::some_of(body_opt_7_12);
                    j == last_8_12
                    ? prism_rtl::finished(std::tuple{prelude::push(acc, crate::ast::Arg{.name = std::optional<crate::ast::Ident>{}, .value = b, .span = span_4_9_12}), s})
                    : prism_rtl::more(prism_rtl::rc(TemplateMissing(acc, s, clauses_9_12, j, cname_10_12, span_4_9_12, quiet_11_12)));
                })
                    : prism_rtl::is_none(body_opt_7_12) ? prism_rtl::more(prism_rtl::rc(TemplateMissing(acc, s, clauses_9_12, j, cname_10_12, span_4_9_12, quiet_11_12)))
                    : throw prism_rtl::Panic("no arm matched");
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        }));
        })), [=](std::tuple<Array<crate::ast::Arg>, crate::check_types::St> fold_93416) {
            return ({
                auto [positional_, st3] = fold_93416;
                call_then(start_call_global(env_3, st3, callee, positional_, span_4, Array<crate::check_types::Ty>{}, callee.span), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> call_global_93881) {
                return ({
                    auto [t, st4] = call_global_93881;
                    (prism_rtl::more(prism_rtl::rc(crate::check_types::Unify(st4, crate::check_types::t_text(), t, span_4))));
                });
            });
            });
        });
        });
    });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplateCallCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::St> start_template_call_check(Env env, crate::check_types::St st, crate::ast::SName n, Array<crate::ast::Arg> args, std::optional<Array<crate::ast::TemplatePart>> parts_opt, crate::ast::Range span) {
    return prism_rtl::make_rc<TemplateCallCheck>(env, st, n, args, parts_opt, span);
}


/// TemplateMissing: unbounded fn [Arg], St, [FnClause], Nat, Text, Range, Bool -> (([Arg], St))
std::tuple<Array<crate::ast::Arg>, crate::check_types::St> template_missing(const Array<crate::ast::Arg>& acc, const crate::check_types::St& st, const Array<crate::ast::FnClause>& clauses, const Nat& j, const Text& cname, const crate::ast::Range& span, const bool& quiet) {
    auto pname = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(clauses, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = index(c.params, j);
                if (prism_rtl::is_some(_m)) {
                    auto&& p_ = prism_rtl::some_of(_m);
                    _v.set(crate::check_passes::param_name_of(p_));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2 = quiet
        ? st
        : crate::check_types::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`<@", cname, ">` needs `", pname, "=`"));
    return std::tuple{prelude::push(acc, crate::ast::Arg{.name = std::optional<crate::ast::Ident>{}, .value = crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EError{})), .span = span}, .span = span}), st2};
}


prism_rtl::Turn<std::tuple<Array<crate::ast::Arg>, crate::check_types::St>> TemplateMissing::cycle() const {
    const auto& acc = this->acc;
    const auto& st = this->st;
    const auto& clauses = this->clauses;
    const auto& j = this->j;
    const auto& cname = this->cname;
    const auto& span = this->span;
    const auto& quiet = this->quiet;
    auto pname = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(clauses, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = index(c.params, j);
                if (prism_rtl::is_some(_m)) {
                    auto&& p_ = prism_rtl::some_of(_m);
                    _v.set(crate::check_passes::param_name_of(p_));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2 = quiet
        ? st
        : crate::check_types::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`<@", cname, ">` needs `", pname, "=`"));
    return prism_rtl::finished(std::tuple{prelude::push(acc, crate::ast::Arg{.name = std::optional<crate::ast::Ident>{}, .value = crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EError{})), .span = span}, .span = span}), st2});
}


/// `Start TemplateMissing, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::ast::Arg>, crate::check_types::St>> start_template_missing(Array<crate::ast::Arg> acc, crate::check_types::St st, Array<crate::ast::FnClause> clauses, Nat j, Text cname, crate::ast::Range span, bool quiet) {
    return prism_rtl::make_rc<TemplateMissing>(acc, st, clauses, j, cname, span, quiet);
}


/// ?TemplateSlot: unbounded fn [FnClause], Text -> ?Nat
std::optional<Nat> template_slot(const Array<crate::ast::FnClause>& clauses, const Text& name) {
    auto found = run_to_end(fold_job(clauses, Array<Nat>{}, ({
        auto name_1 = name;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto name_1_2 = name_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                fold_job(crate::check_errors::range0(len(c.params)), acc, ({
                auto c_2 = c;
                auto name_1_2_3 = name_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_2_3 = c_2;
                    auto name_1_2_3_3 = name_1_2_3;
                    entered(once_job([=]() {
                    return ({
                        auto a2 = p0;
                        auto i = p1;
                        ({
                        auto&& _m = index(c_2_3.params, i);
                        prism_rtl::is_some(_m) ? ({
                        auto&& p_ = prism_rtl::some_of(_m);
                        crate::check_passes::param_name_of(p_) == name_1_2_3_3
                        ? prism_rtl::finished(crate::check_types::add_nat(a2, i))
                        : prism_rtl::finished(a2);
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(a2)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
    return len(found) == Nat(1u) ? index(found, Nat(0u)) : std::optional<Nat>{};
}


prism_rtl::Turn<std::optional<Nat>> TemplateSlot::cycle() const {
    const auto& clauses = this->clauses;
    const auto& name = this->name;
    auto clauses_1 = clauses;
    auto name_2 = name;
    return call_value(fold_job(clauses_1, Array<Nat>{}, ({
        auto name_2_3 = name_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto name_2_3_3 = name_2_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                fold_job(crate::check_errors::range0(len(c.params)), acc, ({
                auto c_3 = c;
                auto name_2_3_3_4 = name_2_3_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_3_4 = c_3;
                    auto name_2_3_3_4_4 = name_2_3_3_4;
                    entered(once_job([=]() {
                    return ({
                        auto a2 = p0;
                        auto i = p1;
                        ({
                        auto&& _m = index(c_3_4.params, i);
                        prism_rtl::is_some(_m) ? ({
                        auto&& p_ = prism_rtl::some_of(_m);
                        crate::check_passes::param_name_of(p_) == name_2_3_3_4_4
                        ? prism_rtl::finished(crate::check_types::add_nat(a2, i))
                        : prism_rtl::finished(a2);
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(a2)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })), [=](Array<Nat> fold_94775) {
        return ({
            auto found = fold_94775;
            len(found) == Nat(1u)
            ? prism_rtl::finished(index(found, Nat(0u)))
            : prism_rtl::finished(std::optional<Nat>{});
        });
    });
}


/// `Start TemplateSlot, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Nat>> start_template_slot(Array<crate::ast::FnClause> clauses, Text name) {
    return prism_rtl::make_rc<TemplateSlot>(clauses, name);
}

}  // namespace crate::check_expr
