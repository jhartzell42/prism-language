// The module `CheckExpr`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check_expr/types.hpp>
#include "elem.types.hpp"
#include <check_env/types.hpp>
#include <check_errors/types.hpp>
#include <check_types/types.hpp>
#include <ast/types.hpp>
#include <check_blocks/types.hpp>
#include <check_passes/types.hpp>
#include <lexer/types.hpp>
#include <typed/types.hpp>

namespace crate {

using namespace prelude;

namespace check_expr {

Env with_local(const Env& env, const Text& name, const crate::check_types::Scheme& sc);

Text src_text(const Env& env, const crate::ast::Range& r);

bool is_comparison(const Text& n);

bool has_time_mark(const Text& marks);

bool is_time_sigil(const Text& s);

bool is_plain_sigil(const Text& s);

crate::check_types::Ty inner_of(const crate::check_types::St& st, const crate::check_types::Ty& t);

prism_rtl::JobRef<crate::check_types::Ty> start_inner_of(crate::check_types::St st, crate::check_types::Ty t);

bool is_lambda(const crate::ast::Expr& e);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer(const Env& env, const crate::check_types::St& st, const crate::ast::Expr& e);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer(Env env, crate::check_types::St st, crate::ast::Expr e);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_kind(const Env& env, const crate::check_types::St& st, const crate::ast::Expr& e);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_kind(Env env, crate::check_types::St st, crate::ast::Expr e);

std::tuple<Array<crate::check_types::Ty>, crate::check_types::St> infer_all(const Env& env, const crate::check_types::St& st, const Array<crate::ast::Expr>& es);

prism_rtl::JobRef<std::tuple<Array<crate::check_types::Ty>, crate::check_types::St>> start_infer_all(Env env, crate::check_types::St st, Array<crate::ast::Expr> es);

crate::check_types::St check(const Env& env, const crate::check_types::St& st, const crate::ast::Expr& e, const crate::check_types::Ty& expected);

prism_rtl::JobRef<crate::check_types::St> start_check(Env env, crate::check_types::St st, crate::ast::Expr e, crate::check_types::Ty expected);

crate::check_types::St check_any(const Env& env, const crate::check_types::St& st, const crate::ast::Expr& x, const crate::check_types::Ty& expected, const crate::ast::Range& span);

prism_rtl::JobRef<crate::check_types::St> start_check_any(Env env, crate::check_types::St st, crate::ast::Expr x, crate::check_types::Ty expected, crate::ast::Range span);

crate::check_types::St add_want(const crate::check_types::St& st, const Text& cls, const crate::check_types::Ty& t, const crate::ast::Range& span);

crate::check_env::Cx_ env_cx(const Env& env);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_name(const Env& env, const crate::check_types::St& st, const crate::ast::SName& n, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_name(Env env, crate::check_types::St st, crate::ast::SName n, crate::ast::Range span);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_name_in(const Env& env, const crate::check_types::St& st, const crate::ast::SName& n, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_name_in(Env env, crate::check_types::St st, crate::ast::SName n, crate::ast::Range span);

std::tuple<crate::check_types::Ty, crate::check_types::St> instantiate_local(const crate::check_types::St& st, const crate::check_types::Scheme& sc, const crate::ast::Range& span, const Text& name);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_instantiate_local(crate::check_types::St st, crate::check_types::Scheme sc, crate::ast::Range span, Text name);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_global(const Env& env, const crate::check_types::St& st0, const crate::ast::SName& n, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_global(Env env, crate::check_types::St st0, crate::ast::SName n, crate::ast::Range span);

crate::check_types::St collision_at(const Env& env, const crate::check_types::St& st, const Text& why, const Text& name, const crate::ast::Range& span);

std::tuple<crate::check_types::Ty, crate::check_types::St> ctor_value(const Env& env, const crate::check_types::St& st, const crate::check_env::CtorInfo& c, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_ctor_value(Env env, crate::check_types::St st, crate::check_env::CtorInfo c, crate::ast::Range span);

std::tuple<crate::check_types::Ty, crate::check_types::St> tag_value(const Env& env, const crate::check_types::St& st, const Text& name, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_tag_value(Env env, crate::check_types::St st, Text name, crate::ast::Range span);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_bound(const Env& env, const crate::check_types::St& st, const Text& b, const crate::ast::Range& span);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_lit(const Env& env, const crate::check_types::St& st, const crate::ast::Literal& l, const bool& negative, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_lit(Env env, crate::check_types::St st, crate::ast::Literal l, bool negative, crate::ast::Range span);

crate::check_types::St add_range(const crate::check_types::St& st, const crate::check_types::Ty& v_, const Text& digits, const bool& signed_, const crate::ast::Range& span);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_text(const Env& env, const crate::check_types::St& st, const Array<crate::ast::TextSeg>& segs, const bool& dollar, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_text(Env env, crate::check_types::St st, Array<crate::ast::TextSeg> segs, bool dollar, crate::ast::Range span);

crate::check_types::St show_want(const crate::check_types::St& st, const crate::check_types::Ty& t, const crate::ast::Range& span);

prism_rtl::JobRef<crate::check_types::St> start_show_want(crate::check_types::St st, crate::check_types::Ty t, crate::ast::Range span);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_array(const Env& env, const crate::check_types::St& st, const Array<crate::ast::Expr>& es, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_array(Env env, crate::check_types::St st, Array<crate::ast::Expr> es, crate::ast::Range span);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_map(const Env& env, const crate::check_types::St& st, const Array<std::tuple<crate::ast::Expr, crate::ast::Expr>>& entries, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_map(Env env, crate::check_types::St st, Array<std::tuple<crate::ast::Expr, crate::ast::Expr>> entries, crate::ast::Range span);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_binary(const Env& env, const crate::check_types::St& st, const Text& op, const crate::ast::Expr& lhs, const crate::ast::Expr& rhs, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_binary(Env env, crate::check_types::St st, Text op, crate::ast::Expr lhs, crate::ast::Expr rhs, crate::ast::Range span);

crate::check_types::Ty quotient_of(const crate::check_types::St& st, const crate::check_types::Ty& t);

prism_rtl::JobRef<crate::check_types::Ty> start_quotient_of(crate::check_types::St st, crate::check_types::Ty t);

crate::check_types::St sub_want(const crate::check_types::St& st, const crate::check_types::Ty& t, const crate::ast::Range& span);

prism_rtl::JobRef<crate::check_types::St> start_sub_want(crate::check_types::St st, crate::check_types::Ty t, crate::ast::Range span);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_on(const Env& env, const crate::check_types::St& st, const crate::ast::Expr& lhs, const crate::ast::Expr& rhs, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_on(Env env, crate::check_types::St st, crate::ast::Expr lhs, crate::ast::Expr rhs, crate::ast::Range span);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_unary(const Env& env, const crate::check_types::St& st, const Text& op, const crate::ast::Expr& x, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_unary(Env env, crate::check_types::St st, Text op, crate::ast::Expr x, crate::ast::Range span);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_free_sigil(const Env& env, const crate::check_types::St& st, const Text& s, const crate::ast::Expr& x, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_free_sigil(Env env, crate::check_types::St st, Text s, crate::ast::Expr x, crate::ast::Range span);

bool is_blueprint_expr(const Env& env, const crate::check_types::St& st, const crate::ast::Expr& x);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_field(const Env& env, const crate::check_types::St& st, const crate::ast::Expr& recv, const Text& sigils, const crate::ast::Ident& name, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_field(Env env, crate::check_types::St st, crate::ast::Expr recv, Text sigils, crate::ast::Ident name, crate::ast::Range span);

std::tuple<crate::check_types::Ty, crate::check_types::St> field_type(const Env& env, const crate::check_types::St& st, const crate::check_types::Ty& t, const Text& field, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_field_type(Env env, crate::check_types::St st, crate::check_types::Ty t, Text field, crate::ast::Range span);

std::optional<Nat> index_of(const Array<Text>& xs, const Text& x);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_index(const Env& env, const crate::check_types::St& st, const crate::ast::Expr& recv, const crate::ast::Expr& idx, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_index(Env env, crate::check_types::St st, crate::ast::Expr recv, crate::ast::Expr idx, crate::ast::Range span);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_call(const Env& env, const crate::check_types::St& st, const crate::ast::Expr& callee, const Array<crate::ast::Arg>& args, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_call(Env env, crate::check_types::St st, crate::ast::Expr callee, Array<crate::ast::Arg> args, crate::ast::Range span);

Array<crate::ast::Arg> positional(const Array<crate::ast::Arg>& args);

std::tuple<crate::check_types::Ty, crate::check_types::St> call_global(const Env& env, const crate::check_types::St& st0, const crate::ast::SName& n, const Array<crate::ast::Arg>& args, const crate::ast::Range& span, const Array<crate::check_types::Ty>& explicit_, const crate::ast::Range& cspan);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_call_global(Env env, crate::check_types::St st0, crate::ast::SName n, Array<crate::ast::Arg> args, crate::ast::Range span, Array<crate::check_types::Ty> explicit_, crate::ast::Range cspan);

std::tuple<Array<Text>, crate::check_types::St> rank_two(const crate::check_types::St& st, const crate::check_types::Scheme& sc, const crate::check_types::Inst& inst, const Nat& n_explicit, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<Array<Text>, crate::check_types::St>> start_rank_two(crate::check_types::St st, crate::check_types::Scheme sc, crate::check_types::Inst inst, Nat n_explicit, crate::ast::Range span);

bool is_rank_two(const Text& q, const crate::check_types::Ty& t);

bool qoccurs(const Text& q, const crate::check_types::Ty& t);

bool elem_out_q(const Text& q, const crate::check_types::Ty& t);

crate::check_types::St escaped(const Env& env, const crate::check_types::St& st, const Array<Text>& rigids, const crate::check_types::Ty& rt, const Text& fname, const crate::ast::Range& span);

prism_rtl::JobRef<crate::check_types::St> start_escaped(Env env, crate::check_types::St st, Array<Text> rigids, crate::check_types::Ty rt, Text fname, crate::ast::Range span);

bool has_rigid(const crate::check_types::St& st, const Text& r, const crate::check_types::Ty& t);

prism_rtl::JobRef<bool> start_has_rigid(crate::check_types::St st, Text r, crate::check_types::Ty t);

bool rigid_in(const Text& r, const crate::check_types::Ty& t);

bool is_local_maker(const Text& qk);

crate::check_types::St local_outside(const crate::check_types::St& st, const Text& qk, const crate::ast::Range& span);

crate::check_types::St note_callee(const crate::check_types::St& st, const crate::ast::Range& at_, const crate::ast::Range& cspan, const crate::check_types::Ty& t);

crate::check_types::St note_method_use(const crate::check_types::St& st, const crate::check_env::ValInfo& v_, const crate::ast::Range& span);

std::tuple<crate::check_types::Ty, crate::check_types::St> fold_app(const Env& env, const crate::check_types::St& st, const crate::check_types::Ty& t, const Array<crate::ast::Arg>& args, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_fold_app(Env env, crate::check_types::St st, crate::check_types::Ty t, Array<crate::ast::Arg> args, crate::ast::Range span);

std::tuple<crate::check_types::Ty, crate::check_types::St> apply_fn(const Env& env, const crate::check_types::St& st, const Text& fname, const crate::check_types::Ty& fty, const Array<crate::ast::Arg>& args, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_apply_fn(Env env, crate::check_types::St st, Text fname, crate::check_types::Ty fty, Array<crate::ast::Arg> args, crate::ast::Range span);

Peeled broken(const Peeled& p_, const bool& b);

std::tuple<crate::check_types::Ty, crate::check_types::St> apply_rule(const Env& env, const crate::check_types::St& st, const Text& fname, const crate::check_types::Col& col, const Array<crate::check_types::Ty>& params, const crate::check_types::Ty& res, const Array<crate::ast::Arg>& args, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_apply_rule(Env env, crate::check_types::St st, Text fname, crate::check_types::Col col, Array<crate::check_types::Ty> params, crate::check_types::Ty res, Array<crate::ast::Arg> args, crate::ast::Range span);

bool has_range(const Array<crate::ast::Range>& rs, const crate::ast::Range& r);

crate::check_types::St elab(const crate::check_types::St& st, const crate::ast::Range& span, const Text& what, const Text& kind, const Text& layer);

crate::check_types::St plain_arg(const Env& env, const crate::check_types::St& st, const Text& fname, const crate::check_types::Ty& param, const crate::check_types::Ty& at_, const crate::ast::Arg& a);

prism_rtl::JobRef<crate::check_types::St> start_plain_arg(Env env, crate::check_types::St st, Text fname, crate::check_types::Ty param, crate::check_types::Ty at_, crate::ast::Arg a);

std::tuple<Peeled, crate::check_types::St> layered_arg(const Env& env, const crate::check_types::St& st, const Peeled& acc, const Text& fname, const bool& cmp, const crate::check_types::Ty& param, const crate::check_types::Ty& at_, const crate::ast::Arg& a);

prism_rtl::JobRef<std::tuple<Peeled, crate::check_types::St>> start_layered_arg(Env env, crate::check_types::St st, Peeled acc, Text fname, bool cmp, crate::check_types::Ty param, crate::check_types::Ty at_, crate::ast::Arg a);

std::tuple<Peeled, crate::check_types::St> peel_time_only(const Env& env, const crate::check_types::St& st, const Peeled& acc, const Text& fname, const crate::check_types::Ty& p_, const crate::check_types::Ty& at_, const crate::ast::Arg& a);

prism_rtl::JobRef<std::tuple<Peeled, crate::check_types::St>> start_peel_time_only(Env env, crate::check_types::St st, Peeled acc, Text fname, crate::check_types::Ty p_, crate::check_types::Ty at_, crate::ast::Arg a);

std::tuple<crate::check_types::Ty, crate::check_types::St> ctor_app(const Env& env, const crate::check_types::St& st, const crate::check_env::CtorInfo& c, const Array<crate::ast::Arg>& args, const crate::ast::Range& span, const crate::ast::Range& cspan);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_ctor_app(Env env, crate::check_types::St st, crate::check_env::CtorInfo c, Array<crate::ast::Arg> args, crate::ast::Range span, crate::ast::Range cspan);

std::tuple<crate::check_types::Ty, crate::check_types::St> tag_app(const Env& env, const crate::check_types::St& st, const Text& name, const Array<crate::ast::Arg>& args, const crate::ast::Range& span, const crate::ast::Range& cspan);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_tag_app(Env env, crate::check_types::St st, Text name, Array<crate::ast::Arg> args, crate::ast::Range span, crate::ast::Range cspan);

std::optional<crate::check_types::Ty> field_of_tag(const crate::check_env::TagInfo& tg, const Text& f);

crate::check_types::St tag_field(const Env& env, const crate::check_types::St& st, const Text& tag_name, const Text& field, const crate::check_types::Ty& ft, const crate::ast::Arg& a);

prism_rtl::JobRef<crate::check_types::St> start_tag_field(Env env, crate::check_types::St st, Text tag_name, Text field, crate::check_types::Ty ft, crate::ast::Arg a);

Nat lambda_arity(const crate::ast::Expr& e);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_lambda(const Env& env, const crate::check_types::St& st, const crate::ast::Expr& e, const std::optional<crate::check_types::Ty>& expected_opt);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_lambda(Env env, crate::check_types::St st, crate::ast::Expr e, std::optional<crate::check_types::Ty> expected_opt);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_bare_lambda(const Env& env, const crate::check_types::St& st, const crate::ast::Expr& e, const std::optional<crate::check_types::Ty>& expected_opt);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_bare_lambda(Env env, crate::check_types::St st, crate::ast::Expr e, std::optional<crate::check_types::Ty> expected_opt);

crate::ast::Pattern_ topic_pat(const crate::ast::Range& span);

crate::ast::SName topic_sname(const crate::ast::Range& span);

crate::ast::Expr topic_expr(const crate::ast::Range& span);

crate::ast::Expr topic_field_expr(const crate::ast::Range& span, const crate::ast::Ident& f);

crate::ast::Expr topic_index_expr(const crate::ast::Range& span, const crate::ast::Expr& x);

bool arg_named(const crate::ast::Arg& a, const Text& f);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_body_block(const Env& env, const crate::check_types::St& st, const crate::ast::Block& b, const std::optional<crate::check_types::Ty>& expected_opt);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_body_block(Env env, crate::check_types::St st, crate::ast::Block b, std::optional<crate::check_types::Ty> expected_opt);

std::tuple<Env, crate::check_types::St> bind_pattern(const Env& env, const crate::check_types::St& st, const crate::ast::Pattern_& p_, const crate::check_types::Ty& t, const bool& refutable);

prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_pattern(Env env, crate::check_types::St st, crate::ast::Pattern_ p_, crate::check_types::Ty t, bool refutable);

bool is_ctor_name(const Env& env, const crate::ast::SName& n);

std::tuple<Env, crate::check_types::St> bind_name(const Env& env, const crate::check_types::St& st, const crate::ast::SName& n, const crate::check_types::Ty& t);

prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_name(Env env, crate::check_types::St st, crate::ast::SName n, crate::check_types::Ty t);

std::tuple<Env, crate::check_types::St> bind_fresh(const Env& env, const crate::check_types::St& st, const crate::ast::SName& n, const crate::check_types::Ty& t);

prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_fresh(Env env, crate::check_types::St st, crate::ast::SName n, crate::check_types::Ty t);

std::tuple<Env, crate::check_types::St> bind_fresh_marked(const Env& env, const crate::check_types::St& st, const crate::ast::SName& n, const Text& marks, const crate::check_types::Ty& t);

prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_fresh_marked(Env env, crate::check_types::St st, crate::ast::SName n, Text marks, crate::check_types::Ty t);

std::tuple<Env, crate::check_types::St> bind_field(const Env& env, const crate::check_types::St& st, const crate::ast::Pattern_& p_, const crate::check_types::Ty& ft, const bool& snapshot);

prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_field(Env env, crate::check_types::St st, crate::ast::Pattern_ p_, crate::check_types::Ty ft, bool snapshot);

std::tuple<Env, crate::check_types::St> bind_level(const Env& env, const crate::check_types::St& st, const crate::ast::Pattern_& p_, const crate::check_types::Ty& level);

prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_level(Env env, crate::check_types::St st, crate::ast::Pattern_ p_, crate::check_types::Ty level);

std::tuple<Env, crate::check_types::St> bind_ctor(const Env& env, const crate::check_types::St& st, const crate::ast::Pattern_& p_, const crate::ast::SName& n, const Array<crate::ast::Pattern_>& args, const crate::check_types::Ty& t);

prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_ctor(Env env, crate::check_types::St st, crate::ast::Pattern_ p_, crate::ast::SName n, Array<crate::ast::Pattern_> args, crate::check_types::Ty t);

std::tuple<Env, crate::check_types::St> bind_record(const Env& env, const crate::check_types::St& st, const crate::ast::Pattern_& p_, const crate::ast::SName& n, const Array<crate::ast::FieldPat>& fields, const bool& rest, const crate::check_types::Ty& t);

prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_record(Env env, crate::check_types::St st, crate::ast::Pattern_ p_, crate::ast::SName n, Array<crate::ast::FieldPat> fields, bool rest, crate::check_types::Ty t);

Text field_pat_name(const crate::ast::FieldPat& fp, const Array<Text>& fields, const Nat& i);

std::tuple<Env, crate::check_types::St> bind_tag_pattern(const Env& env, const crate::check_types::St& st, const crate::ast::Pattern_& p_, const Text& name, const Array<crate::ast::FieldPat>& fields, const bool& rest, const crate::check_types::Ty& t);

prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_tag_pattern(Env env, crate::check_types::St st, crate::ast::Pattern_ p_, Text name, Array<crate::ast::FieldPat> fields, bool rest, crate::check_types::Ty t);

bool is_snapshot(const crate::check_types::St& st, const crate::check_types::Ty& t);

prism_rtl::JobRef<bool> start_is_snapshot(crate::check_types::St st, crate::check_types::Ty t);

crate::check_types::St tag_in_row(const Env& env, const crate::check_types::St& st, const crate::check_env::TagInfo& tg, const crate::check_types::Ty& t, const crate::ast::Range& span);

prism_rtl::JobRef<crate::check_types::St> start_tag_in_row(Env env, crate::check_types::St st, crate::check_env::TagInfo tg, crate::check_types::Ty t, crate::ast::Range span);

std::tuple<Env, crate::check_types::St> bind_family(const Env& env, const crate::check_types::St& st, const Text& fam, const crate::check_types::Ty& t, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_family(Env env, crate::check_types::St st, Text fam, crate::check_types::Ty t, crate::ast::Range span);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_match(const Env& env, const crate::check_types::St& st, const crate::ast::Expr& scrut, const Array<crate::ast::Arm>& arms, const crate::ast::Range& span, const std::optional<crate::check_types::Ty>& expected_opt);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_match(Env env, crate::check_types::St st, crate::ast::Expr scrut, Array<crate::ast::Arm> arms, crate::ast::Range span, std::optional<crate::check_types::Ty> expected_opt);

Array<Text> taken_by(const Env& env, const crate::ast::Arm& arm, const Array<Text>& taken);

Env narrowed(const Env& env, const crate::check_types::St& st, const crate::ast::Arm& arm, const Text& name, const crate::check_types::Ty& t, const Array<Text>& taken);

prism_rtl::JobRef<Env> start_narrowed(Env env, crate::check_types::St st, crate::ast::Arm arm, Text name, crate::check_types::Ty t, Array<Text> taken);

std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St> infer_arm(const Env& env, const crate::check_types::St& st, const crate::ast::Arm& arm, const crate::check_types::Ty& scrut_ty, const crate::check_types::Ty& res, const std::optional<crate::check_types::Ty>& expected_opt, const std::optional<Text>& rigid_out_opt, const Array<std::tuple<Text, crate::ast::Range>>& acc);

prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St>> start_infer_arm(Env env, crate::check_types::St st, crate::ast::Arm arm, crate::check_types::Ty scrut_ty, crate::check_types::Ty res, std::optional<crate::check_types::Ty> expected_opt, std::optional<Text> rigid_out_opt, Array<std::tuple<Text, crate::ast::Range>> acc);

crate::check_types::St arm_against(const crate::check_types::St& st, const crate::check_types::Ty& want, const crate::check_types::Ty& bt, const crate::ast::Range& span, const bool& forwards);

prism_rtl::JobRef<crate::check_types::St> start_arm_against(crate::check_types::St st, crate::check_types::Ty want, crate::check_types::Ty bt, crate::ast::Range span, bool forwards);

bool is_family_arm(const crate::ast::Arm& arm);

crate::check_types::St check_cond(const Env& env, const crate::check_types::St& st, const crate::ast::Expr& e);

prism_rtl::JobRef<crate::check_types::St> start_check_cond(Env env, crate::check_types::St st, crate::ast::Expr e);

std::optional<crate::check_env::TagInfo> tag_of_pattern(const Env& env, const crate::ast::Pattern_& p_);

crate::check_types::Ty subst_rigid(const Text& name, const crate::check_types::Ty& by, const crate::check_types::Ty& t);

prism_rtl::JobRef<crate::check_types::Ty> start_subst_rigid(Text name, crate::check_types::Ty by, crate::check_types::Ty t);

std::tuple<crate::check_types::Ty, crate::check_types::St> match_result(const Env& env, const crate::check_types::St& st, const Text& sh, const Array<std::tuple<Text, crate::ast::Range>>& layers, const crate::check_types::Ty& res, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_match_result(Env env, crate::check_types::St st, Text sh, Array<std::tuple<Text, crate::ast::Range>> layers, crate::check_types::Ty res, crate::ast::Range span);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_if(const Env& env, const crate::check_types::St& st, const crate::ast::Cond& c, const crate::ast::Block& then_b, const std::optional<crate::ast::Block>& else_b_opt, const crate::ast::Range& span, const std::optional<crate::check_types::Ty>& expected_opt);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_if(Env env, crate::check_types::St st, crate::ast::Cond c, crate::ast::Block then_b, std::optional<crate::ast::Block> else_b_opt, crate::ast::Range span, std::optional<crate::check_types::Ty> expected_opt);

crate::check_types::St unify_arm(const crate::check_types::St& st, const crate::check_types::Ty& res, const crate::check_types::Ty& t, const crate::ast::Range& span);

prism_rtl::JobRef<crate::check_types::St> start_unify_arm(crate::check_types::St st, crate::check_types::Ty res, crate::check_types::Ty t, crate::ast::Range span);

Text layer_head(const Text& h);

std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St> if_branches(const Env& then_env, const crate::check_types::St& st, const Env& else_env, const crate::ast::Block& then_b, const std::optional<crate::ast::Block>& else_b_opt, const crate::check_types::Ty& res);

prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St>> start_if_branches(Env then_env, crate::check_types::St st, Env else_env, crate::ast::Block then_b, std::optional<crate::ast::Block> else_b_opt, crate::check_types::Ty res);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_expr_block(const Env& env, const crate::check_types::St& st, const crate::ast::Block& b);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_expr_block(Env env, crate::check_types::St st, crate::ast::Block b);

bool is_widgetish(const Array<crate::ast::Stmt>& stmts);

bool builds(const crate::ast::Stmt& s);

std::tuple<Env, crate::check_types::St> bind_group(const Env& env, const crate::check_types::St& st, const Array<crate::ast::Stmt>& stmts);

prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_bind_group(Env env, crate::check_types::St st, Array<crate::ast::Stmt> stmts);

crate::ast::Range stmts_span(const Array<crate::ast::Stmt>& stmts);

crate::ast::Stmt dummy_stmt();

bool is_last(const Array<crate::ast::Stmt>& stmts, const Nat& i);

std::tuple<Env, crate::check_types::St> pre_bind(const Env& env, const crate::check_types::St& st, const crate::ast::Stmt& s);

prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_pre_bind(Env env, crate::check_types::St st, crate::ast::Stmt s);

std::tuple<Env, crate::check_types::St> check_group_stmt(const Env& env, const crate::check_types::St& st, const crate::ast::Stmt& s, const bool& last);

prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_check_group_stmt(Env env, crate::check_types::St st, crate::ast::Stmt s, bool last);

std::tuple<Env, crate::check_types::St> check_let(const Env& env, const crate::check_types::St& st, const crate::ast::Pattern_& p_, const std::optional<crate::ast::Type>& ty_opt, const crate::ast::Expr& e, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_check_let(Env env, crate::check_types::St st, crate::ast::Pattern_ p_, std::optional<crate::ast::Type> ty_opt, crate::ast::Expr e, crate::ast::Range span);

crate::check_types::St ahead_unify(const Env& env, const crate::check_types::St& st, const Text& name, const crate::check_types::Ty& pre, const crate::check_types::Ty& t, const crate::ast::Range& span);

prism_rtl::JobRef<crate::check_types::St> start_ahead_unify(Env env, crate::check_types::St st, Text name, crate::check_types::Ty pre, crate::check_types::Ty t, crate::ast::Range span);

Text type_marks(const Text& marks);

Text ref_mark(const Text& marks);

Env unpend(const Env& env);

bool is_topic_name(const Text& n);

std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check_types::St> wants_above(const crate::check_types::St& st, const crate::check_types::Ty& t, const bool& lambda);

prism_rtl::JobRef<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check_types::St>> start_wants_above(crate::check_types::St st, crate::check_types::Ty t, bool lambda);

std::tuple<Env, crate::check_types::St> check_local_fn(const Env& env, const crate::check_types::St& st, const crate::ast::FnClause& f, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<Env, crate::check_types::St>> start_check_local_fn(Env env, crate::check_types::St st, crate::ast::FnClause f, crate::ast::Range span);

std::tuple<crate::check_types::Ty, crate::check_types::St> clause_lambda(const Env& env, const crate::check_types::St& st, const crate::ast::FnClause& f);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_clause_lambda(Env env, crate::check_types::St st, crate::ast::FnClause f);

crate::check_types::St check_clauses(const Env& env, const crate::check_types::St& st, const Text& name, const Array<crate::ast::FnClause>& clauses, const crate::check_types::Scheme& sc, const crate::ast::Range& span);

prism_rtl::JobRef<crate::check_types::St> start_check_clauses(Env env, crate::check_types::St st, Text name, Array<crate::ast::FnClause> clauses, crate::check_types::Scheme sc, crate::ast::Range span);

crate::check_types::St check_clause(const Env& env, const crate::check_types::St& st, const crate::ast::FnClause& c, const Array<crate::check_types::Ty>& params, const crate::check_types::Ty& res);

prism_rtl::JobRef<crate::check_types::St> start_check_clause(Env env, crate::check_types::St st, crate::ast::FnClause c, Array<crate::check_types::Ty> params, crate::check_types::Ty res);

crate::check_types::St check_body(const Env& env, const crate::check_types::St& st, const crate::ast::FnBody& body, const crate::check_types::Ty& res);

prism_rtl::JobRef<crate::check_types::St> start_check_body(Env env, crate::check_types::St st, crate::ast::FnBody body, crate::check_types::Ty res);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_template(const Env& env, const crate::check_types::St& st, const crate::ast::Template& t);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_template(Env env, crate::check_types::St st, crate::ast::Template t);

crate::check_types::St template_part_check(const Env& env, const crate::check_types::St& st, const crate::ast::TemplatePart& part);

prism_rtl::JobRef<crate::check_types::St> start_template_part_check(Env env, crate::check_types::St st, crate::ast::TemplatePart part);

crate::check_types::St template_call_check(const Env& env, const crate::check_types::St& st, const crate::ast::SName& n, const Array<crate::ast::Arg>& args, const std::optional<Array<crate::ast::TemplatePart>>& parts_opt, const crate::ast::Range& span);

prism_rtl::JobRef<crate::check_types::St> start_template_call_check(Env env, crate::check_types::St st, crate::ast::SName n, Array<crate::ast::Arg> args, std::optional<Array<crate::ast::TemplatePart>> parts_opt, crate::ast::Range span);

std::tuple<Array<crate::ast::Arg>, crate::check_types::St> template_missing(const Array<crate::ast::Arg>& acc, const crate::check_types::St& st, const Array<crate::ast::FnClause>& clauses, const Nat& j, const Text& cname, const crate::ast::Range& span, const bool& quiet);

prism_rtl::JobRef<std::tuple<Array<crate::ast::Arg>, crate::check_types::St>> start_template_missing(Array<crate::ast::Arg> acc, crate::check_types::St st, Array<crate::ast::FnClause> clauses, Nat j, Text cname, crate::ast::Range span, bool quiet);

std::optional<Nat> template_slot(const Array<crate::ast::FnClause>& clauses, const Text& name);

prism_rtl::JobRef<std::optional<Nat>> start_template_slot(Array<crate::ast::FnClause> clauses, Text name);

}  // namespace check_expr


namespace check_expr {

/// The step machine of `InnerOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InnerOf: unbounded fn St, Ty -> Ty
struct InnerOf : prism_rtl::Job<crate::check_types::Ty> {
    crate::check_types::St st;
    crate::check_types::Ty t;
    InnerOf(crate::check_types::St st, crate::check_types::Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<crate::check_types::Ty> cycle() const override;
};


/// The step machine of `Infer`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Infer: unbounded fn Env, St, Expr -> ((Ty, St))
struct Infer : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Expr e;
    Infer(Env env, crate::check_types::St st, crate::ast::Expr e) : env(std::move(env)), st(std::move(st)), e(std::move(e)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferKind: unbounded fn Env, St, Expr -> ((Ty, St))
struct InferKind : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Expr e;
    InferKind(Env env, crate::check_types::St st, crate::ast::Expr e) : env(std::move(env)), st(std::move(st)), e(std::move(e)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferAll: unbounded fn Env, St, [Expr] -> (([Ty], St))
struct InferAll : prism_rtl::Job<std::tuple<Array<crate::check_types::Ty>, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    Array<crate::ast::Expr> es;
    InferAll(Env env, crate::check_types::St st, Array<crate::ast::Expr> es) : env(std::move(env)), st(std::move(st)), es(std::move(es)) {}
    prism_rtl::Turn<std::tuple<Array<crate::check_types::Ty>, crate::check_types::St>> cycle() const override;
};


/// The step machine of `Check`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Check: unbounded fn Env, St, Expr, Ty -> St
struct Check : prism_rtl::Job<crate::check_types::St> {
    Env env;
    crate::check_types::St st;
    crate::ast::Expr e;
    crate::check_types::Ty expected;
    Check(Env env, crate::check_types::St st, crate::ast::Expr e, crate::check_types::Ty expected) : env(std::move(env)), st(std::move(st)), e(std::move(e)), expected(std::move(expected)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `CheckAny`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckAny: unbounded fn Env, St, Expr, Ty, Range -> St
struct CheckAny : prism_rtl::Job<crate::check_types::St> {
    Env env;
    crate::check_types::St st;
    crate::ast::Expr x;
    crate::check_types::Ty expected;
    crate::ast::Range span;
    CheckAny(Env env, crate::check_types::St st, crate::ast::Expr x, crate::check_types::Ty expected, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), x(std::move(x)), expected(std::move(expected)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `InferName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferName: unbounded fn Env, St, SName, Range -> ((Ty, St))
struct InferName : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::SName n;
    crate::ast::Range span;
    InferName(Env env, crate::check_types::St st, crate::ast::SName n, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), n(std::move(n)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferNameIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferNameIn: unbounded fn Env, St, SName, Range -> ((Ty, St))
struct InferNameIn : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::SName n;
    crate::ast::Range span;
    InferNameIn(Env env, crate::check_types::St st, crate::ast::SName n, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), n(std::move(n)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InstantiateLocal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InstantiateLocal: unbounded fn St, Scheme, Range, Text -> ((Ty, St))
struct InstantiateLocal : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    crate::check_types::St st;
    crate::check_types::Scheme sc;
    crate::ast::Range span;
    Text name;
    InstantiateLocal(crate::check_types::St st, crate::check_types::Scheme sc, crate::ast::Range span, Text name) : st(std::move(st)), sc(std::move(sc)), span(std::move(span)), name(std::move(name)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferGlobal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferGlobal: unbounded fn Env, St, SName, Range -> ((Ty, St))
struct InferGlobal : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st0;
    crate::ast::SName n;
    crate::ast::Range span;
    InferGlobal(Env env, crate::check_types::St st0, crate::ast::SName n, crate::ast::Range span) : env(std::move(env)), st0(std::move(st0)), n(std::move(n)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `CtorValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorValue: unbounded fn Env, St, CtorInfo, Range -> ((Ty, St))
struct CtorValue : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::check_env::CtorInfo c;
    crate::ast::Range span;
    CtorValue(Env env, crate::check_types::St st, crate::check_env::CtorInfo c, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), c(std::move(c)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `TagValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagValue: unbounded fn Env, St, Text, Range -> ((Ty, St))
struct TagValue : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    Text name;
    crate::ast::Range span;
    TagValue(Env env, crate::check_types::St st, Text name, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), name(std::move(name)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferLit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferLit: unbounded fn Env, St, Literal, Bool, Range -> ((Ty, St))
struct InferLit : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Literal l;
    bool negative;
    crate::ast::Range span;
    InferLit(Env env, crate::check_types::St st, crate::ast::Literal l, bool negative, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), l(std::move(l)), negative(std::move(negative)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferText`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferText: unbounded fn Env, St, [TextSeg], Bool, Range -> ((Ty, St))
struct InferText : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    Array<crate::ast::TextSeg> segs;
    bool dollar;
    crate::ast::Range span;
    InferText(Env env, crate::check_types::St st, Array<crate::ast::TextSeg> segs, bool dollar, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), segs(std::move(segs)), dollar(std::move(dollar)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `ShowWant`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShowWant: unbounded fn St, Ty, Range -> St
struct ShowWant : prism_rtl::Job<crate::check_types::St> {
    crate::check_types::St st;
    crate::check_types::Ty t;
    crate::ast::Range span;
    ShowWant(crate::check_types::St st, crate::check_types::Ty t, crate::ast::Range span) : st(std::move(st)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `InferArray`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferArray: unbounded fn Env, St, [Expr], Range -> ((Ty, St))
struct InferArray : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    Array<crate::ast::Expr> es;
    crate::ast::Range span;
    InferArray(Env env, crate::check_types::St st, Array<crate::ast::Expr> es, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), es(std::move(es)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferMap`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferMap: unbounded fn Env, St, [((Expr, Expr))], Range -> ((Ty, St))
struct InferMap : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    Array<std::tuple<crate::ast::Expr, crate::ast::Expr>> entries;
    crate::ast::Range span;
    InferMap(Env env, crate::check_types::St st, Array<std::tuple<crate::ast::Expr, crate::ast::Expr>> entries, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), entries(std::move(entries)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferBinary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferBinary: unbounded fn Env, St, Text, Expr, Expr, Range -> ((Ty, St))
struct InferBinary : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    Text op;
    crate::ast::Expr lhs;
    crate::ast::Expr rhs;
    crate::ast::Range span;
    InferBinary(Env env, crate::check_types::St st, Text op, crate::ast::Expr lhs, crate::ast::Expr rhs, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), op(std::move(op)), lhs(std::move(lhs)), rhs(std::move(rhs)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `QuotientOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// QuotientOf: unbounded fn St, Ty -> Ty
struct QuotientOf : prism_rtl::Job<crate::check_types::Ty> {
    crate::check_types::St st;
    crate::check_types::Ty t;
    QuotientOf(crate::check_types::St st, crate::check_types::Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<crate::check_types::Ty> cycle() const override;
};


/// The step machine of `SubWant`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SubWant: unbounded fn St, Ty, Range -> St
struct SubWant : prism_rtl::Job<crate::check_types::St> {
    crate::check_types::St st;
    crate::check_types::Ty t;
    crate::ast::Range span;
    SubWant(crate::check_types::St st, crate::check_types::Ty t, crate::ast::Range span) : st(std::move(st)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `InferOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferOn: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
struct InferOn : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Expr lhs;
    crate::ast::Expr rhs;
    crate::ast::Range span;
    InferOn(Env env, crate::check_types::St st, crate::ast::Expr lhs, crate::ast::Expr rhs, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), lhs(std::move(lhs)), rhs(std::move(rhs)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferUnary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferUnary: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
struct InferUnary : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    Text op;
    crate::ast::Expr x;
    crate::ast::Range span;
    InferUnary(Env env, crate::check_types::St st, Text op, crate::ast::Expr x, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), op(std::move(op)), x(std::move(x)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferFreeSigil`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferFreeSigil: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
struct InferFreeSigil : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    Text s;
    crate::ast::Expr x;
    crate::ast::Range span;
    InferFreeSigil(Env env, crate::check_types::St st, Text s, crate::ast::Expr x, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), s(std::move(s)), x(std::move(x)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferField: unbounded fn Env, St, Expr, Text, Ident, Range -> ((Ty, St))
struct InferField : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Expr recv;
    Text sigils;
    crate::ast::Ident name;
    crate::ast::Range span;
    InferField(Env env, crate::check_types::St st, crate::ast::Expr recv, Text sigils, crate::ast::Ident name, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), recv(std::move(recv)), sigils(std::move(sigils)), name(std::move(name)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `FieldType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldType: unbounded fn Env, St, Ty, Text, Range -> ((Ty, St))
struct FieldType : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::check_types::Ty t;
    Text field;
    crate::ast::Range span;
    FieldType(Env env, crate::check_types::St st, crate::check_types::Ty t, Text field, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), t(std::move(t)), field(std::move(field)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferIndex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferIndex: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
struct InferIndex : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Expr recv;
    crate::ast::Expr idx;
    crate::ast::Range span;
    InferIndex(Env env, crate::check_types::St st, crate::ast::Expr recv, crate::ast::Expr idx, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), recv(std::move(recv)), idx(std::move(idx)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferCall: unbounded fn Env, St, Expr, [Arg], Range -> ((Ty, St))
struct InferCall : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Expr callee;
    Array<crate::ast::Arg> args;
    crate::ast::Range span;
    InferCall(Env env, crate::check_types::St st, crate::ast::Expr callee, Array<crate::ast::Arg> args, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), callee(std::move(callee)), args(std::move(args)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `CallGlobal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CallGlobal: unbounded fn Env, St, SName, [Arg], Range, [Ty], Range -> ((Ty, St))
struct CallGlobal : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st0;
    crate::ast::SName n;
    Array<crate::ast::Arg> args;
    crate::ast::Range span;
    Array<crate::check_types::Ty> explicit_;
    crate::ast::Range cspan;
    CallGlobal(Env env, crate::check_types::St st0, crate::ast::SName n, Array<crate::ast::Arg> args, crate::ast::Range span, Array<crate::check_types::Ty> explicit_, crate::ast::Range cspan) : env(std::move(env)), st0(std::move(st0)), n(std::move(n)), args(std::move(args)), span(std::move(span)), explicit_(std::move(explicit_)), cspan(std::move(cspan)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `RankTwo`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RankTwo: unbounded fn St, Scheme, Inst, Nat, Range -> (([Text], St))
struct RankTwo : prism_rtl::Job<std::tuple<Array<Text>, crate::check_types::St>> {
    crate::check_types::St st;
    crate::check_types::Scheme sc;
    crate::check_types::Inst inst;
    Nat n_explicit;
    crate::ast::Range span;
    RankTwo(crate::check_types::St st, crate::check_types::Scheme sc, crate::check_types::Inst inst, Nat n_explicit, crate::ast::Range span) : st(std::move(st)), sc(std::move(sc)), inst(std::move(inst)), n_explicit(std::move(n_explicit)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<Array<Text>, crate::check_types::St>> cycle() const override;
};


/// The step machine of `Escaped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Escaped: unbounded fn Env, St, [Text], Ty, Text, Range -> St
struct Escaped : prism_rtl::Job<crate::check_types::St> {
    Env env;
    crate::check_types::St st;
    Array<Text> rigids;
    crate::check_types::Ty rt;
    Text fname;
    crate::ast::Range span;
    Escaped(Env env, crate::check_types::St st, Array<Text> rigids, crate::check_types::Ty rt, Text fname, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), rigids(std::move(rigids)), rt(std::move(rt)), fname(std::move(fname)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `HasRigid`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HasRigid: unbounded fn St, Text, Ty -> Bool
struct HasRigid : prism_rtl::Job<bool> {
    crate::check_types::St st;
    Text r;
    crate::check_types::Ty t;
    HasRigid(crate::check_types::St st, Text r, crate::check_types::Ty t) : st(std::move(st)), r(std::move(r)), t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `FoldApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FoldApp: unbounded fn Env, St, Ty, [Arg], Range -> ((Ty, St))
struct FoldApp : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::check_types::Ty t;
    Array<crate::ast::Arg> args;
    crate::ast::Range span;
    FoldApp(Env env, crate::check_types::St st, crate::check_types::Ty t, Array<crate::ast::Arg> args, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), t(std::move(t)), args(std::move(args)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `ApplyFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ApplyFn: unbounded fn Env, St, Text, Ty, [Arg], Range -> ((Ty, St))
struct ApplyFn : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    Text fname;
    crate::check_types::Ty fty;
    Array<crate::ast::Arg> args;
    crate::ast::Range span;
    ApplyFn(Env env, crate::check_types::St st, Text fname, crate::check_types::Ty fty, Array<crate::ast::Arg> args, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), fname(std::move(fname)), fty(std::move(fty)), args(std::move(args)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `ApplyRule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ApplyRule: unbounded fn Env, St, Text, Col, [Ty], Ty, [Arg], Range -> ((Ty, St))
struct ApplyRule : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    Text fname;
    crate::check_types::Col col;
    Array<crate::check_types::Ty> params;
    crate::check_types::Ty res;
    Array<crate::ast::Arg> args;
    crate::ast::Range span;
    ApplyRule(Env env, crate::check_types::St st, Text fname, crate::check_types::Col col, Array<crate::check_types::Ty> params, crate::check_types::Ty res, Array<crate::ast::Arg> args, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), fname(std::move(fname)), col(std::move(col)), params(std::move(params)), res(std::move(res)), args(std::move(args)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `PlainArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainArg: unbounded fn Env, St, Text, Ty, Ty, Arg -> St
struct PlainArg : prism_rtl::Job<crate::check_types::St> {
    Env env;
    crate::check_types::St st;
    Text fname;
    crate::check_types::Ty param;
    crate::check_types::Ty at_;
    crate::ast::Arg a;
    PlainArg(Env env, crate::check_types::St st, Text fname, crate::check_types::Ty param, crate::check_types::Ty at_, crate::ast::Arg a) : env(std::move(env)), st(std::move(st)), fname(std::move(fname)), param(std::move(param)), at_(std::move(at_)), a(std::move(a)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `LayeredArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LayeredArg: unbounded fn Env, St, Peeled, Text, Bool, Ty, Ty, Arg -> ((Peeled, St))
struct LayeredArg : prism_rtl::Job<std::tuple<Peeled, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    Peeled acc;
    Text fname;
    bool cmp;
    crate::check_types::Ty param;
    crate::check_types::Ty at_;
    crate::ast::Arg a;
    LayeredArg(Env env, crate::check_types::St st, Peeled acc, Text fname, bool cmp, crate::check_types::Ty param, crate::check_types::Ty at_, crate::ast::Arg a) : env(std::move(env)), st(std::move(st)), acc(std::move(acc)), fname(std::move(fname)), cmp(std::move(cmp)), param(std::move(param)), at_(std::move(at_)), a(std::move(a)) {}
    prism_rtl::Turn<std::tuple<Peeled, crate::check_types::St>> cycle() const override;
};


/// The step machine of `PeelTimeOnly`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PeelTimeOnly: unbounded fn Env, St, Peeled, Text, Ty, Ty, Arg -> ((Peeled, St))
struct PeelTimeOnly : prism_rtl::Job<std::tuple<Peeled, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    Peeled acc;
    Text fname;
    crate::check_types::Ty p_;
    crate::check_types::Ty at_;
    crate::ast::Arg a;
    PeelTimeOnly(Env env, crate::check_types::St st, Peeled acc, Text fname, crate::check_types::Ty p_, crate::check_types::Ty at_, crate::ast::Arg a) : env(std::move(env)), st(std::move(st)), acc(std::move(acc)), fname(std::move(fname)), p_(std::move(p_)), at_(std::move(at_)), a(std::move(a)) {}
    prism_rtl::Turn<std::tuple<Peeled, crate::check_types::St>> cycle() const override;
};


/// The step machine of `CtorApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorApp: unbounded fn Env, St, CtorInfo, [Arg], Range, Range -> ((Ty, St))
struct CtorApp : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::check_env::CtorInfo c;
    Array<crate::ast::Arg> args;
    crate::ast::Range span;
    crate::ast::Range cspan;
    CtorApp(Env env, crate::check_types::St st, crate::check_env::CtorInfo c, Array<crate::ast::Arg> args, crate::ast::Range span, crate::ast::Range cspan) : env(std::move(env)), st(std::move(st)), c(std::move(c)), args(std::move(args)), span(std::move(span)), cspan(std::move(cspan)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `TagApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagApp: unbounded fn Env, St, Text, [Arg], Range, Range -> ((Ty, St))
struct TagApp : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    Text name;
    Array<crate::ast::Arg> args;
    crate::ast::Range span;
    crate::ast::Range cspan;
    TagApp(Env env, crate::check_types::St st, Text name, Array<crate::ast::Arg> args, crate::ast::Range span, crate::ast::Range cspan) : env(std::move(env)), st(std::move(st)), name(std::move(name)), args(std::move(args)), span(std::move(span)), cspan(std::move(cspan)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `TagField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagField: unbounded fn Env, St, Text, Text, Ty, Arg -> St
struct TagField : prism_rtl::Job<crate::check_types::St> {
    Env env;
    crate::check_types::St st;
    Text tag_name;
    Text field;
    crate::check_types::Ty ft;
    crate::ast::Arg a;
    TagField(Env env, crate::check_types::St st, Text tag_name, Text field, crate::check_types::Ty ft, crate::ast::Arg a) : env(std::move(env)), st(std::move(st)), tag_name(std::move(tag_name)), field(std::move(field)), ft(std::move(ft)), a(std::move(a)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `InferLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
struct InferLambda : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Expr e;
    std::optional<crate::check_types::Ty> expected_opt;
    InferLambda(Env env, crate::check_types::St st, crate::ast::Expr e, std::optional<crate::check_types::Ty> expected_opt) : env(std::move(env)), st(std::move(st)), e(std::move(e)), expected_opt(std::move(expected_opt)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferBareLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferBareLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
struct InferBareLambda : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Expr e;
    std::optional<crate::check_types::Ty> expected_opt;
    InferBareLambda(Env env, crate::check_types::St st, crate::ast::Expr e, std::optional<crate::check_types::Ty> expected_opt) : env(std::move(env)), st(std::move(st)), e(std::move(e)), expected_opt(std::move(expected_opt)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferBodyBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferBodyBlock: unbounded fn Env, St, Block, ?Ty -> ((Ty, St))
struct InferBodyBlock : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Block b;
    std::optional<crate::check_types::Ty> expected_opt;
    InferBodyBlock(Env env, crate::check_types::St st, crate::ast::Block b, std::optional<crate::check_types::Ty> expected_opt) : env(std::move(env)), st(std::move(st)), b(std::move(b)), expected_opt(std::move(expected_opt)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `BindPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindPattern: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
struct BindPattern : prism_rtl::Job<std::tuple<Env, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Pattern_ p_;
    crate::check_types::Ty t;
    bool refutable;
    BindPattern(Env env, crate::check_types::St st, crate::ast::Pattern_ p_, crate::check_types::Ty t, bool refutable) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)), t(std::move(t)), refutable(std::move(refutable)) {}
    prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> cycle() const override;
};


/// The step machine of `BindName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindName: unbounded fn Env, St, SName, Ty -> ((Env, St))
struct BindName : prism_rtl::Job<std::tuple<Env, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::SName n;
    crate::check_types::Ty t;
    BindName(Env env, crate::check_types::St st, crate::ast::SName n, crate::check_types::Ty t) : env(std::move(env)), st(std::move(st)), n(std::move(n)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> cycle() const override;
};


/// The step machine of `BindFresh`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindFresh: unbounded fn Env, St, SName, Ty -> ((Env, St))
struct BindFresh : prism_rtl::Job<std::tuple<Env, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::SName n;
    crate::check_types::Ty t;
    BindFresh(Env env, crate::check_types::St st, crate::ast::SName n, crate::check_types::Ty t) : env(std::move(env)), st(std::move(st)), n(std::move(n)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> cycle() const override;
};


/// The step machine of `BindFreshMarked`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindFreshMarked: unbounded fn Env, St, SName, Text, Ty -> ((Env, St))
struct BindFreshMarked : prism_rtl::Job<std::tuple<Env, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::SName n;
    Text marks;
    crate::check_types::Ty t;
    BindFreshMarked(Env env, crate::check_types::St st, crate::ast::SName n, Text marks, crate::check_types::Ty t) : env(std::move(env)), st(std::move(st)), n(std::move(n)), marks(std::move(marks)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> cycle() const override;
};


/// The step machine of `BindField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindField: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
struct BindField : prism_rtl::Job<std::tuple<Env, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Pattern_ p_;
    crate::check_types::Ty ft;
    bool snapshot;
    BindField(Env env, crate::check_types::St st, crate::ast::Pattern_ p_, crate::check_types::Ty ft, bool snapshot) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)), ft(std::move(ft)), snapshot(std::move(snapshot)) {}
    prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> cycle() const override;
};


/// The step machine of `BindLevel`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindLevel: unbounded fn Env, St, Pattern, Ty -> ((Env, St))
struct BindLevel : prism_rtl::Job<std::tuple<Env, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Pattern_ p_;
    crate::check_types::Ty level;
    BindLevel(Env env, crate::check_types::St st, crate::ast::Pattern_ p_, crate::check_types::Ty level) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)), level(std::move(level)) {}
    prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> cycle() const override;
};


/// The step machine of `BindCtor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindCtor: unbounded fn Env, St, Pattern, SName, [Pattern], Ty -> ((Env, St))
struct BindCtor : prism_rtl::Job<std::tuple<Env, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Pattern_ p_;
    crate::ast::SName n;
    Array<crate::ast::Pattern_> args;
    crate::check_types::Ty t;
    BindCtor(Env env, crate::check_types::St st, crate::ast::Pattern_ p_, crate::ast::SName n, Array<crate::ast::Pattern_> args, crate::check_types::Ty t) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)), n(std::move(n)), args(std::move(args)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> cycle() const override;
};


/// The step machine of `BindRecord`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindRecord: unbounded fn Env, St, Pattern, SName, [FieldPat], Bool, Ty -> ((Env, St))
struct BindRecord : prism_rtl::Job<std::tuple<Env, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Pattern_ p_;
    crate::ast::SName n;
    Array<crate::ast::FieldPat> fields;
    bool rest;
    crate::check_types::Ty t;
    BindRecord(Env env, crate::check_types::St st, crate::ast::Pattern_ p_, crate::ast::SName n, Array<crate::ast::FieldPat> fields, bool rest, crate::check_types::Ty t) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)), n(std::move(n)), fields(std::move(fields)), rest(std::move(rest)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> cycle() const override;
};


/// The step machine of `BindTagPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindTagPattern: unbounded fn Env, St, Pattern, Text, [FieldPat], Bool, Ty -> ((Env, St))
struct BindTagPattern : prism_rtl::Job<std::tuple<Env, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Pattern_ p_;
    Text name;
    Array<crate::ast::FieldPat> fields;
    bool rest;
    crate::check_types::Ty t;
    BindTagPattern(Env env, crate::check_types::St st, crate::ast::Pattern_ p_, Text name, Array<crate::ast::FieldPat> fields, bool rest, crate::check_types::Ty t) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)), name(std::move(name)), fields(std::move(fields)), rest(std::move(rest)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> cycle() const override;
};


/// The step machine of `IsSnapshot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsSnapshot: unbounded fn St, Ty -> Bool
struct IsSnapshot : prism_rtl::Job<bool> {
    crate::check_types::St st;
    crate::check_types::Ty t;
    IsSnapshot(crate::check_types::St st, crate::check_types::Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `TagInRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagInRow: unbounded fn Env, St, TagInfo, Ty, Range -> St
struct TagInRow : prism_rtl::Job<crate::check_types::St> {
    Env env;
    crate::check_types::St st;
    crate::check_env::TagInfo tg;
    crate::check_types::Ty t;
    crate::ast::Range span;
    TagInRow(Env env, crate::check_types::St st, crate::check_env::TagInfo tg, crate::check_types::Ty t, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), tg(std::move(tg)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `BindFamily`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindFamily: unbounded fn Env, St, Text, Ty, Range -> ((Env, St))
struct BindFamily : prism_rtl::Job<std::tuple<Env, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    Text fam;
    crate::check_types::Ty t;
    crate::ast::Range span;
    BindFamily(Env env, crate::check_types::St st, Text fam, crate::check_types::Ty t, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), fam(std::move(fam)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferMatch: unbounded fn Env, St, Expr, [Arm], Range, ?Ty -> ((Ty, St))
struct InferMatch : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Expr scrut;
    Array<crate::ast::Arm> arms;
    crate::ast::Range span;
    std::optional<crate::check_types::Ty> expected_opt;
    InferMatch(Env env, crate::check_types::St st, crate::ast::Expr scrut, Array<crate::ast::Arm> arms, crate::ast::Range span, std::optional<crate::check_types::Ty> expected_opt) : env(std::move(env)), st(std::move(st)), scrut(std::move(scrut)), arms(std::move(arms)), span(std::move(span)), expected_opt(std::move(expected_opt)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `Narrowed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Narrowed: unbounded fn Env, St, Arm, Text, Ty, [Text] -> Env
struct Narrowed : prism_rtl::Job<Env> {
    Env env;
    crate::check_types::St st;
    crate::ast::Arm arm;
    Text name;
    crate::check_types::Ty t;
    Array<Text> taken;
    Narrowed(Env env, crate::check_types::St st, crate::ast::Arm arm, Text name, crate::check_types::Ty t, Array<Text> taken) : env(std::move(env)), st(std::move(st)), arm(std::move(arm)), name(std::move(name)), t(std::move(t)), taken(std::move(taken)) {}
    prism_rtl::Turn<Env> cycle() const override;
};


/// The step machine of `InferArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferArm: unbounded fn Env, St, Arm, Ty, Ty, ?Ty, ?Text, [((Text, Range))] -> (([((Text, Range))], St))
struct InferArm : prism_rtl::Job<std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Arm arm;
    crate::check_types::Ty scrut_ty;
    crate::check_types::Ty res;
    std::optional<crate::check_types::Ty> expected_opt;
    std::optional<Text> rigid_out_opt;
    Array<std::tuple<Text, crate::ast::Range>> acc;
    InferArm(Env env, crate::check_types::St st, crate::ast::Arm arm, crate::check_types::Ty scrut_ty, crate::check_types::Ty res, std::optional<crate::check_types::Ty> expected_opt, std::optional<Text> rigid_out_opt, Array<std::tuple<Text, crate::ast::Range>> acc) : env(std::move(env)), st(std::move(st)), arm(std::move(arm)), scrut_ty(std::move(scrut_ty)), res(std::move(res)), expected_opt(std::move(expected_opt)), rigid_out_opt(std::move(rigid_out_opt)), acc(std::move(acc)) {}
    prism_rtl::Turn<std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St>> cycle() const override;
};


/// The step machine of `ArmAgainst`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArmAgainst: unbounded fn St, Ty, Ty, Range, Bool -> St
struct ArmAgainst : prism_rtl::Job<crate::check_types::St> {
    crate::check_types::St st;
    crate::check_types::Ty want;
    crate::check_types::Ty bt;
    crate::ast::Range span;
    bool forwards;
    ArmAgainst(crate::check_types::St st, crate::check_types::Ty want, crate::check_types::Ty bt, crate::ast::Range span, bool forwards) : st(std::move(st)), want(std::move(want)), bt(std::move(bt)), span(std::move(span)), forwards(std::move(forwards)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `CheckCond`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckCond: unbounded fn Env, St, Expr -> St
struct CheckCond : prism_rtl::Job<crate::check_types::St> {
    Env env;
    crate::check_types::St st;
    crate::ast::Expr e;
    CheckCond(Env env, crate::check_types::St st, crate::ast::Expr e) : env(std::move(env)), st(std::move(st)), e(std::move(e)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `SubstRigid`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SubstRigid: unbounded fn Text, Ty, Ty -> Ty
struct SubstRigid : prism_rtl::Job<crate::check_types::Ty> {
    Text name;
    crate::check_types::Ty by;
    crate::check_types::Ty t;
    SubstRigid(Text name, crate::check_types::Ty by, crate::check_types::Ty t) : name(std::move(name)), by(std::move(by)), t(std::move(t)) {}
    prism_rtl::Turn<crate::check_types::Ty> cycle() const override;
};


/// The step machine of `MatchResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchResult: unbounded fn Env, St, Text, [((Text, Range))], Ty, Range -> ((Ty, St))
struct MatchResult : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    Text sh;
    Array<std::tuple<Text, crate::ast::Range>> layers;
    crate::check_types::Ty res;
    crate::ast::Range span;
    MatchResult(Env env, crate::check_types::St st, Text sh, Array<std::tuple<Text, crate::ast::Range>> layers, crate::check_types::Ty res, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), sh(std::move(sh)), layers(std::move(layers)), res(std::move(res)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferIf: unbounded fn Env, St, Cond, Block, ?Block, Range, ?Ty -> ((Ty, St))
struct InferIf : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Cond c;
    crate::ast::Block then_b;
    std::optional<crate::ast::Block> else_b_opt;
    crate::ast::Range span;
    std::optional<crate::check_types::Ty> expected_opt;
    InferIf(Env env, crate::check_types::St st, crate::ast::Cond c, crate::ast::Block then_b, std::optional<crate::ast::Block> else_b_opt, crate::ast::Range span, std::optional<crate::check_types::Ty> expected_opt) : env(std::move(env)), st(std::move(st)), c(std::move(c)), then_b(std::move(then_b)), else_b_opt(std::move(else_b_opt)), span(std::move(span)), expected_opt(std::move(expected_opt)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `UnifyArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnifyArm: unbounded fn St, Ty, Ty, Range -> St
struct UnifyArm : prism_rtl::Job<crate::check_types::St> {
    crate::check_types::St st;
    crate::check_types::Ty res;
    crate::check_types::Ty t;
    crate::ast::Range span;
    UnifyArm(crate::check_types::St st, crate::check_types::Ty res, crate::check_types::Ty t, crate::ast::Range span) : st(std::move(st)), res(std::move(res)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `IfBranches`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IfBranches: unbounded fn Env, St, Env, Block, ?Block, Ty -> (([((Text, Range))], St))
struct IfBranches : prism_rtl::Job<std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St>> {
    Env then_env;
    crate::check_types::St st;
    Env else_env;
    crate::ast::Block then_b;
    std::optional<crate::ast::Block> else_b_opt;
    crate::check_types::Ty res;
    IfBranches(Env then_env, crate::check_types::St st, Env else_env, crate::ast::Block then_b, std::optional<crate::ast::Block> else_b_opt, crate::check_types::Ty res) : then_env(std::move(then_env)), st(std::move(st)), else_env(std::move(else_env)), then_b(std::move(then_b)), else_b_opt(std::move(else_b_opt)), res(std::move(res)) {}
    prism_rtl::Turn<std::tuple<Array<std::tuple<Text, crate::ast::Range>>, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferExprBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferExprBlock: unbounded fn Env, St, Block -> ((Ty, St))
struct InferExprBlock : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Block b;
    InferExprBlock(Env env, crate::check_types::St st, crate::ast::Block b) : env(std::move(env)), st(std::move(st)), b(std::move(b)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `BindGroup`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindGroup: unbounded fn Env, St, [Stmt] -> ((Env, St))
struct BindGroup : prism_rtl::Job<std::tuple<Env, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    Array<crate::ast::Stmt> stmts;
    BindGroup(Env env, crate::check_types::St st, Array<crate::ast::Stmt> stmts) : env(std::move(env)), st(std::move(st)), stmts(std::move(stmts)) {}
    prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> cycle() const override;
};


/// The step machine of `PreBind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreBind: unbounded fn Env, St, Stmt -> ((Env, St))
struct PreBind : prism_rtl::Job<std::tuple<Env, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Stmt s;
    PreBind(Env env, crate::check_types::St st, crate::ast::Stmt s) : env(std::move(env)), st(std::move(st)), s(std::move(s)) {}
    prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> cycle() const override;
};


/// The step machine of `CheckGroupStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckGroupStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St))
struct CheckGroupStmt : prism_rtl::Job<std::tuple<Env, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Stmt s;
    bool last;
    CheckGroupStmt(Env env, crate::check_types::St st, crate::ast::Stmt s, bool last) : env(std::move(env)), st(std::move(st)), s(std::move(s)), last(std::move(last)) {}
    prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> cycle() const override;
};


/// The step machine of `CheckLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckLet: unbounded fn Env, St, Pattern, ?Type, Expr, Range -> ((Env, St))
struct CheckLet : prism_rtl::Job<std::tuple<Env, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Pattern_ p_;
    std::optional<crate::ast::Type> ty_opt;
    crate::ast::Expr e;
    crate::ast::Range span;
    CheckLet(Env env, crate::check_types::St st, crate::ast::Pattern_ p_, std::optional<crate::ast::Type> ty_opt, crate::ast::Expr e, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)), ty_opt(std::move(ty_opt)), e(std::move(e)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> cycle() const override;
};


/// The step machine of `AheadUnify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AheadUnify: unbounded fn Env, St, Text, Ty, Ty, Range -> St
struct AheadUnify : prism_rtl::Job<crate::check_types::St> {
    Env env;
    crate::check_types::St st;
    Text name;
    crate::check_types::Ty pre;
    crate::check_types::Ty t;
    crate::ast::Range span;
    AheadUnify(Env env, crate::check_types::St st, Text name, crate::check_types::Ty pre, crate::check_types::Ty t, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), name(std::move(name)), pre(std::move(pre)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `WantsAbove`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WantsAbove: unbounded fn St, Ty, Bool -> (([Nat], [((Nat, Text))], St))
struct WantsAbove : prism_rtl::Job<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check_types::St>> {
    crate::check_types::St st;
    crate::check_types::Ty t;
    bool lambda;
    WantsAbove(crate::check_types::St st, crate::check_types::Ty t, bool lambda) : st(std::move(st)), t(std::move(t)), lambda(std::move(lambda)) {}
    prism_rtl::Turn<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check_types::St>> cycle() const override;
};


/// The step machine of `CheckLocalFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckLocalFn: unbounded fn Env, St, FnClause, Range -> ((Env, St))
struct CheckLocalFn : prism_rtl::Job<std::tuple<Env, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::FnClause f;
    crate::ast::Range span;
    CheckLocalFn(Env env, crate::check_types::St st, crate::ast::FnClause f, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), f(std::move(f)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<Env, crate::check_types::St>> cycle() const override;
};


/// The step machine of `ClauseLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseLambda: unbounded fn Env, St, FnClause -> ((Ty, St))
struct ClauseLambda : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::FnClause f;
    ClauseLambda(Env env, crate::check_types::St st, crate::ast::FnClause f) : env(std::move(env)), st(std::move(st)), f(std::move(f)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `CheckClauses`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckClauses: unbounded fn Env, St, Text, [FnClause], Scheme, Range -> St
struct CheckClauses : prism_rtl::Job<crate::check_types::St> {
    Env env;
    crate::check_types::St st;
    Text name;
    Array<crate::ast::FnClause> clauses;
    crate::check_types::Scheme sc;
    crate::ast::Range span;
    CheckClauses(Env env, crate::check_types::St st, Text name, Array<crate::ast::FnClause> clauses, crate::check_types::Scheme sc, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), name(std::move(name)), clauses(std::move(clauses)), sc(std::move(sc)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `CheckClause`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckClause: unbounded fn Env, St, FnClause, [Ty], Ty -> St
struct CheckClause : prism_rtl::Job<crate::check_types::St> {
    Env env;
    crate::check_types::St st;
    crate::ast::FnClause c;
    Array<crate::check_types::Ty> params;
    crate::check_types::Ty res;
    CheckClause(Env env, crate::check_types::St st, crate::ast::FnClause c, Array<crate::check_types::Ty> params, crate::check_types::Ty res) : env(std::move(env)), st(std::move(st)), c(std::move(c)), params(std::move(params)), res(std::move(res)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `CheckBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckBody: unbounded fn Env, St, FnBody, Ty -> St
struct CheckBody : prism_rtl::Job<crate::check_types::St> {
    Env env;
    crate::check_types::St st;
    crate::ast::FnBody body;
    crate::check_types::Ty res;
    CheckBody(Env env, crate::check_types::St st, crate::ast::FnBody body, crate::check_types::Ty res) : env(std::move(env)), st(std::move(st)), body(std::move(body)), res(std::move(res)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `InferTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferTemplate: unbounded fn Env, St, Template -> ((Ty, St))
struct InferTemplate : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    Env env;
    crate::check_types::St st;
    crate::ast::Template t;
    InferTemplate(Env env, crate::check_types::St st, crate::ast::Template t) : env(std::move(env)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `TemplatePartCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplatePartCheck: unbounded fn Env, St, TemplatePart -> St
struct TemplatePartCheck : prism_rtl::Job<crate::check_types::St> {
    Env env;
    crate::check_types::St st;
    crate::ast::TemplatePart part;
    TemplatePartCheck(Env env, crate::check_types::St st, crate::ast::TemplatePart part) : env(std::move(env)), st(std::move(st)), part(std::move(part)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `TemplateCallCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateCallCheck: unbounded fn Env, St, SName, [Arg], ?[TemplatePart], Range -> St
struct TemplateCallCheck : prism_rtl::Job<crate::check_types::St> {
    Env env;
    crate::check_types::St st;
    crate::ast::SName n;
    Array<crate::ast::Arg> args;
    std::optional<Array<crate::ast::TemplatePart>> parts_opt;
    crate::ast::Range span;
    TemplateCallCheck(Env env, crate::check_types::St st, crate::ast::SName n, Array<crate::ast::Arg> args, std::optional<Array<crate::ast::TemplatePart>> parts_opt, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), n(std::move(n)), args(std::move(args)), parts_opt(std::move(parts_opt)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `TemplateMissing`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateMissing: unbounded fn [Arg], St, [FnClause], Nat, Text, Range, Bool -> (([Arg], St))
struct TemplateMissing : prism_rtl::Job<std::tuple<Array<crate::ast::Arg>, crate::check_types::St>> {
    Array<crate::ast::Arg> acc;
    crate::check_types::St st;
    Array<crate::ast::FnClause> clauses;
    Nat j;
    Text cname;
    crate::ast::Range span;
    bool quiet;
    TemplateMissing(Array<crate::ast::Arg> acc, crate::check_types::St st, Array<crate::ast::FnClause> clauses, Nat j, Text cname, crate::ast::Range span, bool quiet) : acc(std::move(acc)), st(std::move(st)), clauses(std::move(clauses)), j(std::move(j)), cname(std::move(cname)), span(std::move(span)), quiet(std::move(quiet)) {}
    prism_rtl::Turn<std::tuple<Array<crate::ast::Arg>, crate::check_types::St>> cycle() const override;
};


/// The step machine of `TemplateSlot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?TemplateSlot: unbounded fn [FnClause], Text -> ?Nat
struct TemplateSlot : prism_rtl::Job<std::optional<Nat>> {
    Array<crate::ast::FnClause> clauses;
    Text name;
    TemplateSlot(Array<crate::ast::FnClause> clauses, Text name) : clauses(std::move(clauses)), name(std::move(name)) {}
    prism_rtl::Turn<std::optional<Nat>> cycle() const override;
};


}  // namespace check_expr

}  // namespace crate
