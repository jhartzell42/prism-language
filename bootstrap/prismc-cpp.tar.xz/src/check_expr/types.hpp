// The module `CheckExpr`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check_expr/decl.hpp>
#include "elem.decl.hpp"
#include <ast/decl.hpp>
#include <check_blocks/decl.hpp>
#include <check_passes/decl.hpp>
#include <lexer/decl.hpp>
#include <typed/decl.hpp>
#include <check_env/types.hpp>
#include <check_errors/types.hpp>
#include <check_types/types.hpp>

namespace crate {

using namespace prelude;

namespace check_expr {

/// `Env`:
///
/// ```prism
/// type Env = record:
/// ```
struct Env {
    using prism_value = void;
    crate::check_env::G g;
    Text home;
    Nat file;
    crate::check_errors::Src src;
    Map<Text, crate::check_types::Scheme> locals;
    crate::check_types::Rw scope;
    Array<std::tuple<Text, Text>> givens;
    Text mark;
    bool in_update;
    Text def_name;
    Map<Text, crate::check_types::Ty> refine;
    Array<Text> pending;
    const Env* operator->() const { return this; }
    Env* operator->() { return this; }
    bool operator==(const Env&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Env> from_pod(const Pod& whole);
};


}  // namespace check_expr

namespace check_expr {

/// `Peeled`:
///
/// ```prism
/// type Peeled = record:
/// ```
struct Peeled {
    using prism_value = void;
    Array<crate::ast::Range> events;
    Array<crate::ast::Range> dyns;
    Array<Text> opts;
    Text lifted;
    bool broken;
    const Peeled* operator->() const { return this; }
    Peeled* operator->() { return this; }
    bool operator==(const Peeled&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Peeled> from_pod(const Pod& whole);
};


}  // namespace check_expr


}  // namespace crate
