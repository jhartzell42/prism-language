// The module `Check.Shrink.Relations`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/shrink/relations/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Shrink.Relations`, from `target/bootstrap/cpp-src/prismc/check/shrink/relations.prism`.
namespace crate::check::shrink::relations {

/// Hide: fn (Text ==> Rel), [Text] -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> hide(const Map<Text, crate::check::shrink::Rel>& m_p0, const Array<Text>& names_p1) {
    return fold(names_p1, m_p0, [&](const Map<Text, crate::check::shrink::Rel>& m2_p2, const Text& n_p3) { return insert(crate::prelude::remove(crate::prelude::remove(crate::prelude::remove(crate::prelude::remove(m2_p2, n_p3), prism_rtl::cat("ne:", n_p3)), prism_rtl::cat("lamlet:", n_p3)), prism_rtl::cat("lfn:", n_p3)), prism_rtl::cat("local:", n_p3), no_rel()); });
}


/// let noRel
crate::check::shrink::Rel no_rel() {
    return crate::check::shrink::Rel{.param = Nat(0u), .strict = false};
}


/// IsLocal: fn (Text ==> Rel), Text -> Bool
bool is_local(const Map<Text, crate::check::shrink::Rel>& m_p0, const Text& n_p1) {
    return crate::check::env::has_key(m_p0, prism_rtl::cat("local:", n_p1));
}


/// PreIs: fn (Text ==> Rel), Text, Text -> Bool
bool pre_is(const Map<Text, crate::check::shrink::Rel>& m_p0, const Text& n_p1, const Text& bare_p2) {
    return (((n_p1 == bare_p2) || (n_p1 == prism_rtl::cat("Prelude.", bare_p2))) && crate::check::env::has_key(m_p0, prism_rtl::cat("pre:", n_p1))) && (!is_local(m_p0, n_p1));
}


/// let preludeNames
Array<Text> prelude_names() {
    return Array(std::vector{Text::lit("Drop"), Text::lit("Take"), Text::lit("Filter"), Text::lit("Remove"), Text::lit("Min"), Text::lit("Values"), Text::lit("Keys"), Text::lit("?Step"), Text::lit("Fold"), Text::lit("Each"), Text::lit("Push"), Text::lit("Insert"), Text::lit("Append"), Text::lit("Freeze"), Text::lit("-?"), Text::lit("@Defer"), Text::lit("@Later"), Text::lit("@Run"), Text::lit("@Machine"), Text::lit("@started")});
}


/// PreludeSeeds: fn G, Text -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> prelude_seeds(const crate::check::env::G& g_p0, const Text& h_p1) {
    return fold(prelude_names(), Map<Text, crate::check::shrink::Rel>{}, [&](const Map<Text, crate::check::shrink::Rel>& m_p2, const Text& n_p3) {
        return ({
            auto q_p4 = prism_rtl::cat("Prelude.", n_p3);
            !is_prelude_key(g_p0, q_p4)
            ? m_p2
            : fold(Array(std::vector{n_p3, q_p4}), m_p2, [&](const Map<Text, crate::check::shrink::Rel>& m2_p5, const Text& sp_p6) {
            return crate::check::shrink::locals::resolve_callee(g_p0, h_p1, sp_p6) == std::optional(q_p4)
                ? insert(m2_p5, prism_rtl::cat("pre:", sp_p6), no_rel())
                : m2_p5;
        });
        });
    });
}


/// IsPreludeKey: fn G, Text -> Bool
bool is_prelude_key(const crate::check::env::G& g_p0, const Text& q_p1) {
    auto&& _m = crate::prelude::get(g_p0.vals, q_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& v_p2 = prism_rtl::some_of(_m);
        return (crate::syntax::lexer::chars::has_prefix(q_p1, Text::lit("Prelude.")) && (prism_rtl::deref(v_p2).home == Text::lit("Prelude"))) && (v_p2->file >= g_p0.prelude_from);
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// BlockRels: unbounded fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> block_rels(const Array<crate::syntax::Stmt>& stmts_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    return run_to_end(fold_job(stmts_p0, local_fn_marks(stmts_p0, hide(m_p1, stmts_binders(stmts_p0))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto m2_p2 = p0;
                auto s_p3 = p1;
                call_then(start_stmt_rels(s_p3, m2_p2), [=](Map<Text, crate::check::shrink::Rel> stmt_rels_4447) { return prism_rtl::finished(crate::check::passes::cycles::lam_let_rels(s_p3, stmt_rels_4447)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> BlockRels::cycle() const {
    const auto& stmts_p0 = this->stmts_p0;
    const auto& m_p1 = this->m_p1;
    auto m_p1_1 = m_p1;
    auto stmts_p0_2 = stmts_p0;
    return call_then(start_stmts_binders(stmts_p0_2), [=](Array<Text> stmts_binders_4400) {
        return fold_job(stmts_p0_2, local_fn_marks(stmts_p0_2, hide(m_p1_1, stmts_binders_4400)), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto m2_p2 = p0;
                    auto s_p3 = p1;
                    call_then(start_stmt_rels(s_p3, m2_p2), [=](Map<Text, crate::check::shrink::Rel> stmt_rels_4447) { return prism_rtl::finished(crate::check::passes::cycles::lam_let_rels(s_p3, stmt_rels_4447)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start BlockRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_block_rels(Array<crate::syntax::Stmt> stmts_p0, Map<Text, crate::check::shrink::Rel> m_p1) {
    return prism_rtl::make_rc<BlockRels>(stmts_p0, m_p1);
}


/// LocalFnMarks: fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> local_fn_marks(const Array<crate::syntax::Stmt>& stmts_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    return fold(stmts_p0, m_p1, [&](const Map<Text, crate::check::shrink::Rel>& m2_p2, const crate::syntax::Stmt& s_p3) {
        return ({
            auto n_o4 = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<Text>> _v;
                auto&& _m = prism_rtl::deref(s_p3).kind;
                if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
                    auto&& f_p5 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
                    _v.set(std::optional(crate::check::env::def_name_text(prism_rtl::deref(f_p5).name)));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
                    auto&& w_p6 = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
                    _v.set(std::optional(crate::check::env::sname_key(prism_rtl::deref(w_p6).name)));
                    goto _done;
                }
                {
                    _v.set(std::optional<Text>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
            if (prism_rtl::is_some(n_o4)) {
                auto&& n_p7 = prism_rtl::some_of(n_o4);
                _v.set(crate::check::env::has_key(m2_p2, prism_rtl::cat("lfn:", n_p7))
                    ? m2_p2
                    : insert(m2_p2, prism_rtl::cat("lfn:", n_p7), crate::check::shrink::Rel{.param = prism_rtl::deref(prism_rtl::deref(s_p3).span).start, .strict = false}));
                goto _done;
            }
            if (prism_rtl::is_none(n_o4)) {
                _v.set(m2_p2);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    });
}


/// StmtsBinders: unbounded fn [Stmt] -> [Text]
Array<Text> stmts_binders(const Array<crate::syntax::Stmt>& stmts_p0) {
    return run_to_end(fold_job(stmts_p0, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p1 = p0;
                auto s_p2 = p1;
                ({
                auto&& _m = prism_rtl::deref(s_p2).kind;
                prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
                auto&& p_p3 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                ({
                auto p_p3_1 = p_p3;
                call_then(crate::check::env::names::start_pattern_names(p_p3_1), [=](Array<Text> pattern_names_5121) { return prism_rtl::finished(crate::check::types::union_texts(acc_p1, pattern_names_5121)); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
                auto&& p_p4 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
                ({
                auto p_p4_1 = p_p4;
                call_then(crate::check::env::names::start_pattern_names(p_p4_1), [=](Array<Text> pattern_names_5183) { return prism_rtl::finished(crate::check::types::union_texts(acc_p1, pattern_names_5183)); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
                auto&& f_p5 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
                prism_rtl::finished(crate::check::types::add_text(acc_p1, crate::check::env::def_name_text(prism_rtl::deref(f_p5).name)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
                auto&& w_p6 = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
                prism_rtl::finished(crate::check::types::add_text(acc_p1, crate::check::env::sname_key(prism_rtl::deref(w_p6).name)));
            })
                : prism_rtl::finished(acc_p1);
            });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> StmtsBinders::cycle() const {
    const auto& stmts_p0 = this->stmts_p0;
    return fold_job(stmts_p0, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p1 = p0;
                auto s_p2 = p1;
                ({
                auto&& _m = prism_rtl::deref(s_p2).kind;
                prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
                auto&& p_p3 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                ({
                auto p_p3_1 = p_p3;
                call_then(crate::check::env::names::start_pattern_names(p_p3_1), [=](Array<Text> pattern_names_5121) { return prism_rtl::finished(crate::check::types::union_texts(acc_p1, pattern_names_5121)); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
                auto&& p_p4 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
                ({
                auto p_p4_1 = p_p4;
                call_then(crate::check::env::names::start_pattern_names(p_p4_1), [=](Array<Text> pattern_names_5183) { return prism_rtl::finished(crate::check::types::union_texts(acc_p1, pattern_names_5183)); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
                auto&& f_p5 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
                prism_rtl::finished(crate::check::types::add_text(acc_p1, crate::check::env::def_name_text(prism_rtl::deref(f_p5).name)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
                auto&& w_p6 = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
                prism_rtl::finished(crate::check::types::add_text(acc_p1, crate::check::env::sname_key(prism_rtl::deref(w_p6).name)));
            })
                : prism_rtl::finished(acc_p1);
            });
            });
        }));
    })))->cycle();
}


/// `Start StmtsBinders, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_stmts_binders(Array<crate::syntax::Stmt> stmts_p0) {
    return prism_rtl::make_rc<StmtsBinders>(stmts_p0);
}


/// StmtRels: unbounded fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> stmt_rels(const crate::syntax::Stmt& s_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    auto&& _m = s_p0.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_p2 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e_p3 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        return bind_rels(p_p2, e_p3, m_p1, false);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_p4 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e_p5 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        return bind_rels(p_p4, e_p5, m_p1, true);
    }
    {
        return m_p1;
    }
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> StmtRels::cycle() const {
    const auto& s_p0 = this->s_p0;
    const auto& m_p1 = this->m_p1;
    return ({
        auto&& _m = prism_rtl::deref(s_p0).kind;
        prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_p2 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e_p3 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        prism_rtl::more(prism_rtl::rc(BindRels(p_p2, e_p3, m_p1, false)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_p4 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e_p5 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        prism_rtl::more(prism_rtl::rc(BindRels(p_p4, e_p5, m_p1, true)));
    })
        : prism_rtl::finished(m_p1);
    });
}


/// `Start StmtRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_stmt_rels(crate::syntax::Stmt s_p0, Map<Text, crate::check::shrink::Rel> m_p1) {
    return prism_rtl::make_rc<StmtRels>(s_p0, m_p1);
}


/// BindRels: unbounded fn Pattern, Expr, (Text ==> Rel), Bool -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> bind_rels(const crate::syntax::Pattern_& p_p0, const crate::syntax::Expr& e_p1, const Map<Text, crate::check::shrink::Rel>& m_p2, const bool& refutable_p3) {
    auto base_o4 = crate::check::shrink::walk::rel_of(m_p2, e_p1);
    auto dec_o5 = crate::check::shrink::summaries::decrement_of(m_p2, e_p1);
    auto h_p6 = non_empty_rels(hide(m_p2, crate::check::env::names::pattern_names(p_p0)), p_p0, e_p1, refutable_p3);
    auto&& _m = prism_rtl::deref(p_p0.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p7 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        if (prism_rtl::is_some(base_o4)) {
            auto&& r_p8 = prism_rtl::some_of(base_o4);
            return insert(h_p6, crate::check::env::sname_key(n_p7), r_p8);
        }
        if (prism_rtl::is_none(base_o4)) {
            if (prism_rtl::is_some(dec_o5)) {
                auto&& r_p9 = prism_rtl::some_of(dec_o5);
                return refutable_p3
                    ? insert(h_p6, crate::check::env::sname_key(n_p7), r_p9)
                    : h_p6;
            }
            if (prism_rtl::is_none(dec_o5)) {
                return h_p6;
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& m5947_1_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& inner_pa = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        if (m5947_1_0 == Text::lit("?")) {
            if (prism_rtl::is_some(dec_o5)) {
                auto&& r_pb = prism_rtl::some_of(dec_o5);
                return fold(crate::check::env::names::pattern_names(prism_rtl::deref(prism_rtl::deref(inner_pa))), h_p6, [&](const Map<Text, crate::check::shrink::Rel>& m2_pc, const Text& n_pd) { return insert(m2_pc, n_pd, r_pb); });
            }
            if (prism_rtl::is_none(dec_o5)) {
                if (prism_rtl::is_some(base_o4)) {
                    auto&& r_pe = prism_rtl::some_of(base_o4);
                    return fold(crate::check::env::names::pattern_names(prism_rtl::deref(prism_rtl::deref(inner_pa))), h_p6, [&](const Map<Text, crate::check::shrink::Rel>& m2_pf, const Text& n_pg) { return insert(m2_pf, n_pg, crate::check::shrink::Rel{.param = prism_rtl::deref(r_pe).param, .strict = true}); });
                }
                if (prism_rtl::is_none(base_o4)) {
                    return h_p6;
                }
                prism_rtl::unreachable("no arm matched");
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    {
        if (prism_rtl::is_some(base_o4)) {
            auto&& r_ph = prism_rtl::some_of(base_o4);
            return fold(crate::check::env::names::pattern_names(p_p0), h_p6, [&](const Map<Text, crate::check::shrink::Rel>& m2_pi, const Text& n_pj) { return insert(m2_pi, n_pj, crate::check::shrink::Rel{.param = prism_rtl::deref(r_ph).param, .strict = true}); });
        }
        if (prism_rtl::is_none(base_o4)) {
            return h_p6;
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> BindRels::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& e_p1 = this->e_p1;
    const auto& m_p2 = this->m_p2;
    const auto& refutable_p3 = this->refutable_p3;
    auto e_p1_1 = e_p1;
    auto m_p2_2 = m_p2;
    auto p_p0_3 = p_p0;
    auto refutable_p3_4 = prism_rtl::deref(refutable_p3);
    return call_then(crate::check::shrink::walk::start_rel_of(m_p2_2, e_p1_1), [=](std::optional<crate::check::shrink::Rel> rel_of_5829) {
        return ({
            auto base_o4 = rel_of_5829;
            call_then(crate::check::shrink::summaries::start_decrement_of(m_p2_2, e_p1_1), [=, base_o4 = std::move(base_o4)](std::optional<crate::check::shrink::Rel> decrement_of_5856) {
            return ({
                auto dec_o5 = decrement_of_5856;
                call_then(crate::check::env::names::start_pattern_names(p_p0_3), [=, dec_o5 = std::move(dec_o5)](Array<Text> pattern_names_5909) {
                return call_then(start_non_empty_rels(hide(m_p2_2, pattern_names_5909), p_p0_3, e_p1_1, refutable_p3_4), [=](Map<Text, crate::check::shrink::Rel> non_empty_rels_5886) {
                    return ({
                        auto h_p6 = non_empty_rels_5886;
                        ({
                        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p0_3).kind);
                        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                        auto&& n_p7 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                        ({
                        prism_rtl::is_some(base_o4) ? ({
                        auto&& r_p8 = prism_rtl::some_of(base_o4);
                        prism_rtl::finished(insert(h_p6, crate::check::env::sname_key(n_p7), r_p8));
                    })
                        : prism_rtl::is_none(base_o4) ? ({
                        prism_rtl::is_some(dec_o5) ? ({
                        auto&& r_p9 = prism_rtl::some_of(dec_o5);
                        refutable_p3_4
                        ? prism_rtl::finished(insert(h_p6, crate::check::env::sname_key(n_p7), r_p9))
                        : prism_rtl::finished(h_p6);
                    })
                        : prism_rtl::is_none(dec_o5) ? prism_rtl::finished(h_p6)
                        : throw prism_rtl::Panic("no arm matched");
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    })
                        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) && ({
                        auto&& m5947_1_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
                        auto&& inner_pa = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
                        (m5947_1_0 == Text::lit("?"));
                    }) ? ({
                        auto&& m5947_1_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
                        auto&& inner_pa = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
                        ({
                        prism_rtl::is_some(dec_o5) ? ({
                        auto&& r_pb = prism_rtl::some_of(dec_o5);
                        ({
                        auto inner_pa_5 = prism_rtl::deref(prism_rtl::deref(inner_pa));
                        auto r_pb_6 = r_pb;
                        call_then(crate::check::env::names::start_pattern_names(inner_pa_5), [=, r_pb_6 = std::move(r_pb_6)](Array<Text> pattern_names_6217) { return prism_rtl::finished(fold(pattern_names_6217, h_p6, [&](const Map<Text, crate::check::shrink::Rel>& m2_pc, const Text& n_pd) { return insert(m2_pc, n_pd, r_pb_6); })); });
                    });
                    })
                        : prism_rtl::is_none(dec_o5) ? ({
                        prism_rtl::is_some(base_o4) ? ({
                        auto&& r_pe = prism_rtl::some_of(base_o4);
                        ({
                        auto inner_pa_5 = prism_rtl::deref(prism_rtl::deref(inner_pa));
                        auto r_pe_6 = r_pe;
                        call_then(crate::check::env::names::start_pattern_names(inner_pa_5), [=, r_pe_6 = std::move(r_pe_6)](Array<Text> pattern_names_6323) { return prism_rtl::finished(fold(pattern_names_6323, h_p6, [&](const Map<Text, crate::check::shrink::Rel>& m2_pf, const Text& n_pg) { return insert(m2_pf, n_pg, crate::check::shrink::Rel{.param = prism_rtl::deref(r_pe_6).param, .strict = true}); })); });
                    });
                    })
                        : prism_rtl::is_none(base_o4) ? prism_rtl::finished(h_p6)
                        : throw prism_rtl::Panic("no arm matched");
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    })
                        : ({
                        prism_rtl::is_some(base_o4) ? ({
                        auto&& r_ph = prism_rtl::some_of(base_o4);
                        ({
                        auto r_ph_5 = r_ph;
                        call_then(crate::check::env::names::start_pattern_names(p_p0_3), [=, r_ph_5 = std::move(r_ph_5)](Array<Text> pattern_names_6480) { return prism_rtl::finished(fold(pattern_names_6480, h_p6, [&](const Map<Text, crate::check::shrink::Rel>& m2_pi, const Text& n_pj) { return insert(m2_pi, n_pj, crate::check::shrink::Rel{.param = prism_rtl::deref(r_ph_5).param, .strict = true}); })); });
                    });
                    })
                        : prism_rtl::is_none(base_o4) ? prism_rtl::finished(h_p6)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start BindRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_bind_rels(crate::syntax::Pattern_ p_p0, crate::syntax::Expr e_p1, Map<Text, crate::check::shrink::Rel> m_p2, bool refutable_p3) {
    return prism_rtl::make_rc<BindRels>(p_p0, e_p1, m_p2, refutable_p3);
}


/// NonEmptyRels: unbounded fn (Text ==> Rel), Pattern, Expr, Bool -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> non_empty_rels(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Pattern_& p_p1, const crate::syntax::Expr& e_p2, const bool& refutable_p3) {
    return !refutable_p3
        ? m_p0
        : ({
        __label__ _done;
        prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
        auto&& _m = non_empty_name(p_p1, e_p2);
        if (prism_rtl::is_some(_m)) {
            auto&& n_p4 = prism_rtl::some_of(_m);
            _v.set(crate::check::types::has_text(crate::check::env::names::pattern_names(p_p1), n_p4)
                ? m_p0
                : insert(m_p0, prism_rtl::cat("ne:", n_p4), no_rel()));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(m_p0);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> NonEmptyRels::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& p_p1 = this->p_p1;
    const auto& e_p2 = this->e_p2;
    const auto& refutable_p3 = this->refutable_p3;
    return !prism_rtl::deref(refutable_p3)
        ? prism_rtl::finished(m_p0)
        : ({
        auto&& _m = non_empty_name(p_p1, e_p2);
        prism_rtl::is_some(_m) ? ({
        auto&& n_p4 = prism_rtl::some_of(_m);
        ({
        auto m_p0_1 = m_p0;
        auto p_p1_2 = p_p1;
        call_then(crate::check::env::names::start_pattern_names(p_p1_2), [=, m_p0_1 = std::move(m_p0_1)](Array<Text> pattern_names_7016) {
        return crate::check::types::has_text(pattern_names_7016, n_p4)
            ? prism_rtl::finished(m_p0_1)
            : prism_rtl::finished(insert(m_p0_1, prism_rtl::cat("ne:", n_p4), no_rel()));
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p0)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start NonEmptyRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_non_empty_rels(Map<Text, crate::check::shrink::Rel> m_p0, crate::syntax::Pattern_ p_p1, crate::syntax::Expr e_p2, bool refutable_p3) {
    return prism_rtl::make_rc<NonEmptyRels>(m_p0, p_p1, e_p2, refutable_p3);
}


/// ?NonEmptyName: fn Pattern, Expr -> ?Text
std::optional<Text> non_empty_name(const crate::syntax::Pattern_& p_p0, const crate::syntax::Expr& e_p1) {
    auto&& _m = prism_rtl::deref(e_p1.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p2 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return non_empty_name(p_p0, prism_rtl::deref(prism_rtl::deref(x_p2)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r_p3 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& _m = prism_rtl::deref(p_p0.kind);
        if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
            auto&& m7216_0_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
            if (m7216_0_0 == Text::lit("?")) {
                return name_of(prism_rtl::deref(prism_rtl::deref(r_p3)));
            }
        }
        if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
            auto&& q_p4 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
            return non_empty_name(prism_rtl::deref(prism_rtl::deref(q_p4)), e_p1);
        }
        {
            return std::optional<Text>{};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p5 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto&& _m = prism_rtl::deref(p_p0.kind);
        if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
            auto&& ps_p6 = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
            return len(ps_p6) > Nat(0u)
                ? std::optional(crate::check::env::sname_key(n_p5))
                : std::optional<Text>{};
        }
        if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
            auto&& q_p7 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
            return non_empty_name(prism_rtl::deref(prism_rtl::deref(q_p7)), e_p1);
        }
        {
            return std::optional<Text>{};
        }
    }
    {
        return std::optional<Text>{};
    }
}


/// ?NameOf: fn Expr -> ?Text
std::optional<Text> name_of(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return std::optional(crate::check::env::sname_key(n_p1));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p2 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return name_of(prism_rtl::deref(prism_rtl::deref(x_p2)));
    }
    {
        return std::optional<Text>{};
    }
}


/// ArmPatRels: unbounded fn Expr, Arm, (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> arm_pat_rels(const crate::syntax::Expr& s_p0, const crate::syntax::Arm& a_p1, const Map<Text, crate::check::shrink::Rel>& m_p2) {
    auto&& _m = a_p1.pattern;
    if (prism_rtl::is_some(_m)) {
        auto&& p_p3 = prism_rtl::some_of(_m);
        return bind_rels(p_p3, s_p0, m_p2, true);
    }
    if (prism_rtl::is_none(_m)) {
        return m_p2;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> ArmPatRels::cycle() const {
    const auto& s_p0 = this->s_p0;
    const auto& a_p1 = this->a_p1;
    const auto& m_p2 = this->m_p2;
    return ({
        auto&& _m = prism_rtl::deref(a_p1).pattern;
        prism_rtl::is_some(_m) ? ({
        auto&& p_p3 = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(BindRels(p_p3, s_p0, m_p2, true)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p2)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ArmPatRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_arm_pat_rels(crate::syntax::Expr s_p0, crate::syntax::Arm a_p1, Map<Text, crate::check::shrink::Rel> m_p2) {
    return prism_rtl::make_rc<ArmPatRels>(s_p0, a_p1, m_p2);
}


/// CondRels: unbounded fn Cond, (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> cond_rels(const crate::syntax::Cond& c_p0, const Map<Text, crate::check::shrink::Rel>& m_p1) {
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(c_p0)) {
        auto&& p_p2 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p0).a0;
        auto&& x_p3 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p0).a1;
        return bind_rels(p_p2, prism_rtl::deref(prism_rtl::deref(x_p3)), m_p1, true);
    }
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p0)) {
        return m_p1;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> CondRels::cycle() const {
    const auto& c_p0 = this->c_p0;
    const auto& m_p1 = this->m_p1;
    return ({
        prism_rtl::is<crate::syntax::Cond::CondBind>(c_p0) ? ({
        auto&& p_p2 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p0).a0;
        auto&& x_p3 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p0).a1;
        prism_rtl::more(prism_rtl::rc(BindRels(p_p2, prism_rtl::deref(prism_rtl::deref(x_p3)), m_p1, true)));
    })
        : prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p0) ? prism_rtl::finished(m_p1)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_cond_rels(crate::syntax::Cond c_p0, Map<Text, crate::check::shrink::Rel> m_p1) {
    return prism_rtl::make_rc<CondRels>(c_p0, m_p1);
}


/// StepRels: unbounded fn (Text ==> Rel), Expr, [Pattern], Nat -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> step_rels(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& coll_p1, const Array<crate::syntax::Pattern_>& ps_p2, const Nat& at_p3) {
    auto h_p4 = hide(m_p0, run_to_end(fold_job(ps_p2, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a_p5 = p0;
                auto p_p6 = p1;
                call_then(crate::check::env::names::start_pattern_names(p_p6), [=, a_p5 = std::move(a_p5)](Array<Text> pattern_names_8705) { return prism_rtl::finished(crate::check::types::union_texts(a_p5, pattern_names_8705)); });
            });
        }));
    })))));
    auto&& _m = crate::check::shrink::walk::rel_of(m_p0, coll_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& r_p7 = prism_rtl::some_of(_m);
        return run_to_end(fold_job(drop(ps_p2, at_p3), h_p4, ({
            auto r_p7_1 = r_p7;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=, r_p7_1 = std::move(r_p7_1)](std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto r_p7_1_2 = r_p7_1;
                entered(once_job([=, r_p7_1_2 = std::move(r_p7_1_2)]() {
                return ({
                    auto m2_p8 = p0;
                    auto p_p9 = p1;
                    call_then(crate::check::env::names::start_pattern_names(p_p9), [=, m2_p8 = std::move(m2_p8)](Array<Text> pattern_names_8799) { return prism_rtl::finished(fold(pattern_names_8799, m2_p8, [&](const Map<Text, crate::check::shrink::Rel>& m3_pa, const Text& n_pb) { return insert(m3_pa, n_pb, crate::check::shrink::Rel{.param = prism_rtl::deref(r_p7_1_2).param, .strict = true}); })); });
                });
            }));
            });
        }));
        })));
    }
    if (prism_rtl::is_none(_m)) {
        return h_p4;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> StepRels::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& coll_p1 = this->coll_p1;
    const auto& ps_p2 = this->ps_p2;
    const auto& at_p3 = this->at_p3;
    auto at_p3_1 = at_p3;
    auto coll_p1_2 = coll_p1;
    auto m_p0_3 = m_p0;
    auto ps_p2_4 = ps_p2;
    return call_value(fold_job(ps_p2_4, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a_p5 = p0;
                auto p_p6 = p1;
                call_then(crate::check::env::names::start_pattern_names(p_p6), [=, a_p5 = std::move(a_p5)](Array<Text> pattern_names_8705) { return prism_rtl::finished(crate::check::types::union_texts(a_p5, pattern_names_8705)); });
            });
        }));
    }))), [=](Array<Text> fold_8667) {
        return ({
            auto h_p4 = hide(m_p0_3, fold_8667);
            call_then(crate::check::shrink::walk::start_rel_of(m_p0_3, coll_p1_2), [=, h_p4 = std::move(h_p4)](std::optional<crate::check::shrink::Rel> rel_of_8732) {
            return ({
                prism_rtl::is_some(rel_of_8732) ? ({
                auto&& r_p7 = prism_rtl::some_of(rel_of_8732);
                fold_job(drop(ps_p2_4, at_p3_1), h_p4, ({
                auto r_p7_5 = r_p7;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=, r_p7_5 = std::move(r_p7_5)](std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Pattern_> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto r_p7_5_6 = r_p7_5;
                    entered(once_job([=, r_p7_5_6 = std::move(r_p7_5_6)]() {
                    return ({
                        auto m2_p8 = p0;
                        auto p_p9 = p1;
                        call_then(crate::check::env::names::start_pattern_names(p_p9), [=, m2_p8 = std::move(m2_p8)](Array<Text> pattern_names_8799) { return prism_rtl::finished(fold(pattern_names_8799, m2_p8, [&](const Map<Text, crate::check::shrink::Rel>& m3_pa, const Text& n_pb) { return insert(m3_pa, n_pb, crate::check::shrink::Rel{.param = prism_rtl::deref(r_p7_5_6).param, .strict = true}); })); });
                    });
                }));
                });
            }));
            }))->cycle();
            })
                : prism_rtl::is_none(rel_of_8732) ? prism_rtl::finished(h_p4)
                : throw prism_rtl::Panic("no arm matched");
            });
        });
        });
    });
}


/// `Start StepRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_step_rels(Map<Text, crate::check::shrink::Rel> m_p0, crate::syntax::Expr coll_p1, Array<crate::syntax::Pattern_> ps_p2, Nat at_p3) {
    return prism_rtl::make_rc<StepRels>(m_p0, coll_p1, ps_p2, at_p3);
}

}  // namespace crate::check::shrink::relations
