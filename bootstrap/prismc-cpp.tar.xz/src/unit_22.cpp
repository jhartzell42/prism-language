// The module `Check.Shrink.Types`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/shrink/types/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Shrink.Types`, from `target/bootstrap/cpp-src/prismc/check/shrink/types.prism`.
namespace crate::check::shrink::types {

/// NegativeTypes: unbounded fn G, St -> St
crate::check::types::St negative_types(const crate::check::env::G& g, const crate::check::types::St& st) {
    auto arrowy = arrowy_types(g);
    return run_to_end(fold_job(keys(g.types), st, ({
        auto g_1 = g;
        auto arrowy_2 = arrowy;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=, g_1 = std::move(g_1), arrowy_2 = std::move(arrowy_2)](std::tuple<crate::check::types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto arrowy_2_3 = arrowy_2;
            entered(once_job([=, g_1_3 = std::move(g_1_3), arrowy_2_3 = std::move(arrowy_2_3)]() {
            return ({
                auto s = p0;
                auto n = p1;
                (prism_rtl::more(prism_rtl::rc(NegativeType(g_1_3, s, arrowy_2_3, n))));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> NegativeTypes::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    auto g_1 = g;
    auto st_2 = st;
    return call_then(start_arrowy_types(g_1), [=](Map<Text, bool> arrowy_types_1927) {
        return ({
            auto arrowy = arrowy_types_1927;
            fold_job(keys(prism_rtl::deref(g_1).types), st_2, ({
            auto g_1_3 = g_1;
            auto arrowy_3 = arrowy;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=, g_1_3 = std::move(g_1_3), arrowy_3 = std::move(arrowy_3)](std::tuple<crate::check::types::St, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_1_3_4 = g_1_3;
                auto arrowy_3_4 = arrowy_3;
                entered(once_job([=, g_1_3_4 = std::move(g_1_3_4), arrowy_3_4 = std::move(arrowy_3_4)]() {
                return ({
                    auto s = p0;
                    auto n = p1;
                    (prism_rtl::more(prism_rtl::rc(NegativeType(g_1_3_4, s, arrowy_3_4, n))));
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start NegativeTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_negative_types(crate::check::env::G g, crate::check::types::St st) {
    return prism_rtl::make_rc<NegativeTypes>(g, st);
}


/// NegativeType: unbounded fn G, St, (Text ==> Bool), Text -> St
crate::check::types::St negative_type(const crate::check::env::G& g, const crate::check::types::St& s, const Map<Text, bool>& arrowy, const Text& n) {
    auto&& _m = crate::prelude::get(g.types, n);
    if (prism_rtl::is_some(_m)) {
        auto&& ti = prism_rtl::some_of(_m);
        auto&& _neg = (ti->file >= g.prelude_from) || (!crate::check::env::has_key(arrowy, n))
            ? std::tuple{false, Map<Text, bool>{}}
            : neg_walks(g, n, body_tys(ti), false, Map<Text, bool>{});
        auto&& neg = std::get<0>(_neg);
        return !neg
            ? s
            : ({
            auto s0 = ({
                crate::check::types::St this_ = s;
                this_.file = ti->file;
                (std::move(this_));
            });
            auto s1 = crate::check::types::recording::err_fix(s0, Text::lit("may-not-end"), prism_rtl::deref(ti).span, prism_rtl::cat("`", crate::check::types::bare_name(n), "` stands left of a function arrow in its own definition: a call through the function it holds is a cycle, and nothing in it shrinks"), prism_rtl::cat("keep `", crate::check::types::bare_name(n), "` right of the arrow, or make the arrow `unbounded fn`, which makes every call through it unbounded"));
            ({
            crate::check::types::St this_ = s1;
            this_.file = s.file;
            (std::move(this_));
        });
        });
    }
    if (prism_rtl::is_none(_m)) {
        return s;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> NegativeType::cycle() const {
    const auto& g = this->g;
    const auto& s = this->s;
    const auto& arrowy = this->arrowy;
    const auto& n = this->n;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g).types, n);
        prism_rtl::is_some(_m) ? ({
        auto&& ti = prism_rtl::some_of(_m);
        ({
        auto&& _neg = (ti->file >= prism_rtl::deref(g).prelude_from) || (!crate::check::env::has_key(arrowy, n))
            ? std::tuple{false, Map<Text, bool>{}}
            : neg_walks(g, n, body_tys(ti), false, Map<Text, bool>{});
        auto&& neg = std::get<0>(_neg);
        !neg
        ? prism_rtl::finished(s)
        : ({
        auto s0 = ({
            crate::check::types::St this_ = s;
            this_.file = ti->file;
            (std::move(this_));
        });
        auto s1 = crate::check::types::recording::err_fix(s0, Text::lit("may-not-end"), prism_rtl::deref(ti).span, prism_rtl::cat("`", crate::check::types::bare_name(n), "` stands left of a function arrow in its own definition: a call through the function it holds is a cycle, and nothing in it shrinks"), prism_rtl::cat("keep `", crate::check::types::bare_name(n), "` right of the arrow, or make the arrow `unbounded fn`, which makes every call through it unbounded"));
        (prism_rtl::finished(({
        crate::check::types::St this_ = s1;
        this_.file = s->file;
        (std::move(this_));
    })));
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(s)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start NegativeType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_negative_type(crate::check::env::G g, crate::check::types::St s, Map<Text, bool> arrowy, Text n) {
    return prism_rtl::make_rc<NegativeType>(g, s, arrowy, n);
}


/// ArrowyTypes: unbounded fn G -> (Text ==> Bool)
Map<Text, bool> arrowy_types(const crate::check::env::G& g) {
    auto names = run_to_end(fold_job(keys(g.types), Map<Text, Array<Text>>{}, ({
        auto g_1 = g;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=, g_1 = std::move(g_1)](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=, g_1_2 = std::move(g_1_2)]() {
            return ({
                auto m = p0;
                auto n = p1;
                ({
                auto&& _m = crate::prelude::get(g_1_2.types, n);
                prism_rtl::is_some(_m) ? ({
                auto&& ti = prism_rtl::some_of(_m);
                call_value(fold_job(body_tys(ti), Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto t = p1;
                        call_then(start_ty_names_in(t), [=, acc = std::move(acc)](Array<Text> ty_names_in_3223) { return prism_rtl::finished(crate::check::types::union_texts(acc, ty_names_in_3223)); });
                    });
                }));
            }))), [=](Array<Text> fold_3171) { return prism_rtl::finished(insert(m, n, fold_3171)); });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
    auto direct = run_to_end(fold_job(keys(g.types), Map<Text, bool>{}, ({
        auto g_1 = g;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, bool>>(std::tuple<Map<Text, bool>, Text>)>>(prism_rtl::rc([=, g_1 = std::move(g_1)](std::tuple<Map<Text, bool>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=, g_1_2 = std::move(g_1_2)]() {
            return ({
                auto m = p0;
                auto n = p1;
                ({
                auto&& _m = crate::prelude::get(g_1_2.types, n);
                prism_rtl::is_some(_m) ? ({
                auto&& ti = prism_rtl::some_of(_m);
                call_value(fold_job(body_tys(ti), false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto seen = p0;
                        auto t = p1;
                        (prism_rtl::finished(std::move(seen) || has_arrow(t)));
                    });
                }));
            }))), [=](bool fold_3337) {
                return fold_3337
                    ? prism_rtl::finished(insert(m, n, true))
                    : prism_rtl::finished(m);
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
    return arrowy_from(names, direct);
}


prism_rtl::Turn<Map<Text, bool>> ArrowyTypes::cycle() const {
    const auto& g = this->g;
    auto g_1 = g;
    return call_value(fold_job(keys(prism_rtl::deref(g_1).types), Map<Text, Array<Text>>{}, ({
        auto g_1_2 = g_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=, g_1_2 = std::move(g_1_2)](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2_2 = g_1_2;
            entered(once_job([=, g_1_2_2 = std::move(g_1_2_2)]() {
            return ({
                auto m = p0;
                auto n = p1;
                ({
                auto&& _m = crate::prelude::get(prism_rtl::deref(g_1_2_2).types, n);
                prism_rtl::is_some(_m) ? ({
                auto&& ti = prism_rtl::some_of(_m);
                call_value(fold_job(body_tys(ti), Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto t = p1;
                        call_then(start_ty_names_in(t), [=, acc = std::move(acc)](Array<Text> ty_names_in_3223) { return prism_rtl::finished(crate::check::types::union_texts(acc, ty_names_in_3223)); });
                    });
                }));
            }))), [=](Array<Text> fold_3171) { return prism_rtl::finished(insert(m, n, fold_3171)); });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=](Map<Text, Array<Text>> fold_3092) {
        return ({
            auto names = fold_3092;
            call_value(fold_job(keys(prism_rtl::deref(g_1).types), Map<Text, bool>{}, ({
            auto g_1_2 = g_1;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, bool>>(std::tuple<Map<Text, bool>, Text>)>>(prism_rtl::rc([=, g_1_2 = std::move(g_1_2)](std::tuple<Map<Text, bool>, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_1_2_2 = g_1_2;
                entered(once_job([=, g_1_2_2 = std::move(g_1_2_2)]() {
                return ({
                    auto m = p0;
                    auto n = p1;
                    ({
                    auto&& _m = crate::prelude::get(prism_rtl::deref(g_1_2_2).types, n);
                    prism_rtl::is_some(_m) ? ({
                    auto&& ti = prism_rtl::some_of(_m);
                    call_value(fold_job(body_tys(ti), false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto seen = p0;
                            auto t = p1;
                            (prism_rtl::finished(std::move(seen) || has_arrow(t)));
                        });
                    }));
                }))), [=](bool fold_3337) {
                    return fold_3337
                        ? prism_rtl::finished(insert(m, n, true))
                        : prism_rtl::finished(m);
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        }));
        })), [=, names = std::move(names)](Map<Text, bool> fold_3269) {
            return ({
                auto direct = fold_3269;
                (prism_rtl::more(prism_rtl::rc(ArrowyFrom(names, direct))));
            });
        });
        });
    });
}


/// `Start ArrowyTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, bool>> start_arrowy_types(crate::check::env::G g) {
    return prism_rtl::make_rc<ArrowyTypes>(g);
}


/// ArrowyFrom: unbounded fn (Text ==> [Text]), (Text ==> Bool) -> (Text ==> Bool)
Map<Text, bool> arrowy_from(const Map<Text, Array<Text>>& names, const Map<Text, bool>& got) {
    auto next_ = fold(keys(names), got, [&](const Map<Text, bool>& m, const Text& n) {
        return crate::check::env::has_key(m, n)
            ? m
            : fold(or_(crate::prelude::get(names, n), Array<Text>{}), false, [&](const bool& seen, const Text& r) { return prism_rtl::deref(seen) || crate::check::env::has_key(got, r); })
            ? insert(m, n, true)
            : m;
    });
    return len(keys(next_)) == len(keys(got)) ? got : arrowy_from(names, next_);
}


prism_rtl::Turn<Map<Text, bool>> ArrowyFrom::cycle() const {
    const auto& names = this->names;
    const auto& got = this->got;
    auto next_ = fold(keys(names), got, [&](const Map<Text, bool>& m, const Text& n) {
        return crate::check::env::has_key(m, n)
            ? m
            : fold(or_(crate::prelude::get(names, n), Array<Text>{}), false, [&](const bool& seen, const Text& r) { return prism_rtl::deref(seen) || crate::check::env::has_key(got, r); })
            ? insert(m, n, true)
            : m;
    });
    return len(keys(next_)) == len(keys(got))
        ? prism_rtl::finished(got)
        : prism_rtl::more(prism_rtl::rc(ArrowyFrom(names, next_)));
}


/// `Start ArrowyFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, bool>> start_arrowy_from(Map<Text, Array<Text>> names, Map<Text, bool> got) {
    return prism_rtl::make_rc<ArrowyFrom>(names, got);
}


/// TyNamesIn: unbounded fn Ty -> [Text]
Array<Text> ty_names_in(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return run_to_end(fold_job(args, Array(std::vector{c}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_ty_names_in(a), [=, acc = std::move(acc)](Array<Text> ty_names_in_4019) { return prism_rtl::finished(crate::check::types::union_texts(acc, ty_names_in_4019)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        return run_to_end(fold_job(ps, ty_names_in(prism_rtl::deref(prism_rtl::deref(res))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_ty_names_in(a), [=, acc = std::move(acc)](Array<Text> ty_names_in_4111) { return prism_rtl::finished(crate::check::types::union_texts(acc, ty_names_in_4111)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_ty_names_in(a), [=, acc = std::move(acc)](Array<Text> ty_names_in_4182) { return prism_rtl::finished(crate::check::types::union_texts(acc, ty_names_in_4182)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return ty_names_in(prism_rtl::deref(prism_rtl::deref(e)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return crate::check::types::union_texts(ty_names_in(prism_rtl::deref(prism_rtl::deref(k))), ty_names_in(prism_rtl::deref(prism_rtl::deref(v_))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return ty_names_in(prism_rtl::deref(prism_rtl::deref(i)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        return ty_names_in(prism_rtl::deref(prism_rtl::deref(i)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        return ty_names_in(prism_rtl::deref(prism_rtl::deref(i)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        return ty_names_in(prism_rtl::deref(prism_rtl::deref(i)));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> TyNamesIn::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        fold_job(args, Array(std::vector{c}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_ty_names_in(a), [=, acc = std::move(acc)](Array<Text> ty_names_in_4019) { return prism_rtl::finished(crate::check::types::union_texts(acc, ty_names_in_4019)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? ({
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        ({
        auto ps_1 = ps;
        auto res_2 = prism_rtl::deref(prism_rtl::deref(res));
        call_then(start_ty_names_in(res_2), [=, ps_1 = std::move(ps_1)](Array<Text> ty_names_in_4068) {
        return fold_job(ps_1, ty_names_in_4068, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_ty_names_in(a), [=, acc = std::move(acc)](Array<Text> ty_names_in_4111) { return prism_rtl::finished(crate::check::types::union_texts(acc, ty_names_in_4111)); });
                });
            }));
        })))->cycle();
    });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_ty_names_in(a), [=, acc = std::move(acc)](Array<Text> ty_names_in_4182) { return prism_rtl::finished(crate::check::types::union_texts(acc, ty_names_in_4182)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(prism_rtl::deref(prism_rtl::deref(e)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = prism_rtl::deref(prism_rtl::deref(k));
        auto v__2 = prism_rtl::deref(prism_rtl::deref(v_));
        call_then(start_ty_names_in(k_1), [=, v__2 = std::move(v__2)](Array<Text> ty_names_in_4250) { return call_then(start_ty_names_in(v__2), [=](Array<Text> ty_names_in_4265) { return prism_rtl::finished(crate::check::types::union_texts(ty_names_in_4250, ty_names_in_4265)); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(prism_rtl::deref(prism_rtl::deref(i)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(prism_rtl::deref(prism_rtl::deref(i)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(prism_rtl::deref(prism_rtl::deref(i)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(prism_rtl::deref(prism_rtl::deref(i)))));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start TyNamesIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_ty_names_in(crate::check::types::Ty t) {
    return prism_rtl::make_rc<TyNamesIn>(t);
}


/// HasArrow: unbounded fn Ty -> Bool
bool has_arrow(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        return true;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return run_to_end(fold_job(args, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto a = p1;
                    (prism_rtl::finished(std::move(seen) || has_arrow(a)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto a = p1;
                    (prism_rtl::finished(std::move(seen) || has_arrow(a)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return has_arrow(prism_rtl::deref(prism_rtl::deref(e)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return has_arrow(prism_rtl::deref(prism_rtl::deref(k))) || has_arrow(prism_rtl::deref(prism_rtl::deref(v_)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return has_arrow(prism_rtl::deref(prism_rtl::deref(i)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        return has_arrow(prism_rtl::deref(prism_rtl::deref(i)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        return has_arrow(prism_rtl::deref(prism_rtl::deref(i)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        return has_arrow(prism_rtl::deref(prism_rtl::deref(i)));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> HasArrow::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? prism_rtl::finished(true)
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        fold_job(args, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto a = p1;
                (prism_rtl::finished(std::move(seen) || has_arrow(a)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        fold_job(ts, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto a = p1;
                (prism_rtl::finished(std::move(seen) || has_arrow(a)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(HasArrow(prism_rtl::deref(prism_rtl::deref(e)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = prism_rtl::deref(prism_rtl::deref(k));
        auto v__2 = prism_rtl::deref(prism_rtl::deref(v_));
        call_then(start_has_arrow(k_1), [=, v__2 = std::move(v__2)](bool has_arrow_4707) { return prism_rtl::finished(has_arrow_4707 || has_arrow(v__2)); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(HasArrow(prism_rtl::deref(prism_rtl::deref(i)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        prism_rtl::more(prism_rtl::rc(HasArrow(prism_rtl::deref(prism_rtl::deref(i)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        prism_rtl::more(prism_rtl::rc(HasArrow(prism_rtl::deref(prism_rtl::deref(i)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        prism_rtl::more(prism_rtl::rc(HasArrow(prism_rtl::deref(prism_rtl::deref(i)))));
    })
        : prism_rtl::finished(false);
    });
}


/// `Start HasArrow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_has_arrow(crate::check::types::Ty t) {
    return prism_rtl::make_rc<HasArrow>(t);
}


/// BodyTys: fn TyInfo -> [Ty]
Array<crate::check::types::Ty> body_tys(const crate::check::env::TyInfo& ti) {
    auto&& _m = ti.body;
    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
        auto&& fields = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
        return each(fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& t = std::get<1>(_p0);
            return t;
        });
    }
    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
        auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
        return fold(cases, Array<crate::check::types::Ty>{}, [&](const Array<crate::check::types::Ty>& acc, const std::tuple<Text, Array<crate::check::types::Ty>>& _p1) {
            auto&& args = std::get<1>(_p1);
            return append(acc, args);
        });
    }
    if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
        auto&& t = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
        return Array(std::vector{t});
    }
    {
        return Array<crate::check::types::Ty>{};
    }
}


/// NegWalk: unbounded fn G, Text, Ty, Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
std::tuple<bool, Map<Text, bool>> neg_walk(const crate::check::env::G& g, const Text& target, const crate::check::types::Ty& t, const bool& b, const Map<Text, bool>& seen) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return c == target
            ? std::tuple{b, seen}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<bool, Map<Text, bool>>> _v;
            auto&& _m = crate::prelude::get(g.types, c);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(({
                    auto sk = prism_rtl::cat(b ? Text::lit("-") : Text::lit("+"), crate::check::types::show_ty(crate::check::types::new_st(Nat(0u)), t));
                    (crate::check::env::has_key(seen, sk)
                    ? std::tuple{false, seen}
                    : len(keys(seen)) > Nat(400u)
                    ? std::tuple{true, seen}
                    : neg_walks(g, target, run_to_end(each_job(body_tys(ti), ({
                    auto ti_1 = ti;
                    auto args_2 = args;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, ti_1 = std::move(ti_1), args_2 = std::move(args_2)](crate::check::types::Ty p0) {
                    return ({
                        auto ti_1_3 = ti_1;
                        auto args_2_3 = args_2;
                        entered(once_job([=, ti_1_3 = std::move(ti_1_3), args_2_3 = std::move(args_2_3)]() {
                        return ({
                            auto bt = p0;
                            (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(crate::check::env::reading::param_inst(prism_rtl::deref(ti_1_3).params, args_2_3), bt))));
                        });
                    }));
                    });
                })));
                }))), b, insert(seen, sk, true)));
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(neg_walks(g, target, args, b, seen));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& col = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        auto [bad, seen2] = neg_walks(g, target, ps, b || (col != crate::check::types::Col(crate::check::types::Col::CUnbound{})), seen);
        return bad
            ? std::tuple{true, seen2}
            : neg_walk(g, target, prism_rtl::deref(prism_rtl::deref(res)), b, seen2);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return neg_walks(g, target, ts, b, seen);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return neg_walk(g, target, prism_rtl::deref(prism_rtl::deref(e)), b, seen);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return neg_walks(g, target, Array(std::vector{prism_rtl::deref(prism_rtl::deref(k)), prism_rtl::deref(prism_rtl::deref(v_))}), b, seen);
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return neg_walk(g, target, prism_rtl::deref(prism_rtl::deref(i)), b, seen);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        return neg_walk(g, target, prism_rtl::deref(prism_rtl::deref(i)), b, seen);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        return neg_walk(g, target, prism_rtl::deref(prism_rtl::deref(i)), b, seen);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        return neg_walk(g, target, prism_rtl::deref(prism_rtl::deref(i)), b, seen);
    }
    {
        return std::tuple{false, seen};
    }
}


prism_rtl::Turn<std::tuple<bool, Map<Text, bool>>> NegWalk::cycle() const {
    const auto& g = this->g;
    const auto& target = this->target;
    const auto& t = this->t;
    const auto& b = this->b;
    const auto& seen = this->seen;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        c == target
        ? prism_rtl::finished(std::tuple{prism_rtl::deref(b), seen})
        : ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g).types, c);
        prism_rtl::is_some(_m) ? ({
        auto&& ti = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto b_2 = prism_rtl::deref(b);
        auto g_3 = g;
        auto seen_4 = seen;
        auto t_5 = t;
        auto target_6 = target;
        call_then(crate::check::types::start_show_ty(crate::check::types::new_st(Nat(0u)), t_5), [=, args_1 = std::move(args_1), b_2 = std::move(b_2), g_3 = std::move(g_3), seen_4 = std::move(seen_4), target_6 = std::move(target_6)](Text show_ty_5844) {
        return ({
            auto sk = prism_rtl::cat(b_2 ? Text::lit("-") : Text::lit("+"), show_ty_5844);
            (crate::check::env::has_key(seen_4, sk)
            ? prism_rtl::finished(std::tuple{false, seen_4})
            : len(keys(seen_4)) > Nat(400u)
            ? prism_rtl::finished(std::tuple{true, seen_4})
            : call_value(each_job(body_tys(ti), ({
            auto ti_7 = ti;
            auto args_1_8 = args_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, ti_7 = std::move(ti_7), args_1_8 = std::move(args_1_8)](crate::check::types::Ty p0) {
            return ({
                auto ti_7_8 = ti_7;
                auto args_1_8_8 = args_1_8;
                entered(once_job([=, ti_7_8 = std::move(ti_7_8), args_1_8_8 = std::move(args_1_8_8)]() {
                return ({
                    auto bt = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(crate::check::env::reading::param_inst(prism_rtl::deref(ti_7_8).params, args_1_8_8), bt))));
                });
            }));
            });
        })));
        })), [=](Array<crate::check::types::Ty> each_6026) { return prism_rtl::more(prism_rtl::rc(NegWalks(g_3, target_6, each_6026, b_2, insert(seen_4, sk, true)))); }));
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(NegWalks(g, target, args, prism_rtl::deref(b), seen)))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? ({
        auto&& col = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        ({
        auto b_1 = prism_rtl::deref(b);
        auto col_2 = col;
        auto g_3 = g;
        auto ps_4 = ps;
        auto res_5 = prism_rtl::deref(prism_rtl::deref(res));
        auto seen_6 = seen;
        auto target_7 = target;
        call_then(start_neg_walks(g_3, target_7, ps_4, std::move(b_1) || (col_2 != crate::check::types::Col(crate::check::types::Col::CUnbound{})), seen_6), [=, res_5 = std::move(res_5)](std::tuple<bool, Map<Text, bool>> neg_walks_6222) {
        return ({
            auto [bad, seen2] = neg_walks_6222;
            bad
            ? prism_rtl::finished(std::tuple{true, seen2})
            : prism_rtl::more(prism_rtl::rc(NegWalk(g_3, target_7, res_5, b_1, seen2)));
        });
    });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        prism_rtl::more(prism_rtl::rc(NegWalks(g, target, ts, prism_rtl::deref(b), seen)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(NegWalk(g, target, prism_rtl::deref(prism_rtl::deref(e)), prism_rtl::deref(b), seen)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        prism_rtl::more(prism_rtl::rc(NegWalks(g, target, Array(std::vector{prism_rtl::deref(prism_rtl::deref(k)), prism_rtl::deref(prism_rtl::deref(v_))}), prism_rtl::deref(b), seen)));
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(NegWalk(g, target, prism_rtl::deref(prism_rtl::deref(i)), prism_rtl::deref(b), seen)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        prism_rtl::more(prism_rtl::rc(NegWalk(g, target, prism_rtl::deref(prism_rtl::deref(i)), prism_rtl::deref(b), seen)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        prism_rtl::more(prism_rtl::rc(NegWalk(g, target, prism_rtl::deref(prism_rtl::deref(i)), prism_rtl::deref(b), seen)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        prism_rtl::more(prism_rtl::rc(NegWalk(g, target, prism_rtl::deref(prism_rtl::deref(i)), prism_rtl::deref(b), seen)));
    })
        : prism_rtl::finished(std::tuple{false, seen});
    });
}


/// `Start NegWalk, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>> start_neg_walk(crate::check::env::G g, Text target, crate::check::types::Ty t, bool b, Map<Text, bool> seen) {
    return prism_rtl::make_rc<NegWalk>(g, target, t, b, seen);
}


/// NegWalks: unbounded fn G, Text, [Ty], Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
std::tuple<bool, Map<Text, bool>> neg_walks(const crate::check::env::G& g, const Text& target, const Array<crate::check::types::Ty>& ts, const bool& b, const Map<Text, bool>& seen) {
    return run_to_end(fold_job(ts, std::tuple{false, seen}, ({
        auto g_1 = g;
        auto target_2 = target;
        auto b_3 = b;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>>(std::tuple<std::tuple<bool, Map<Text, bool>>, crate::check::types::Ty>)>>(prism_rtl::rc([=, g_1 = std::move(g_1), target_2 = std::move(target_2), b_3 = std::move(b_3)](std::tuple<std::tuple<bool, Map<Text, bool>>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_4 = g_1;
            auto target_2_4 = target_2;
            auto b_3_4 = b_3;
            entered(once_job([=, g_1_4 = std::move(g_1_4), target_2_4 = std::move(target_2_4), b_3_4 = std::move(b_3_4)]() {
            return ({
                auto [bad, sn] = p0;
                auto t = p1;
                bad
                ? prism_rtl::finished(std::tuple{true, sn})
                : prism_rtl::more(prism_rtl::rc(NegWalk(g_1_4, target_2_4, t, b_3_4, sn)));
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<bool, Map<Text, bool>>> NegWalks::cycle() const {
    const auto& g = this->g;
    const auto& target = this->target;
    const auto& ts = this->ts;
    const auto& b = this->b;
    const auto& seen = this->seen;
    return fold_job(ts, std::tuple{false, seen}, ({
        auto g_1 = g;
        auto target_2 = target;
        auto b_3 = prism_rtl::deref(b);
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>>(std::tuple<std::tuple<bool, Map<Text, bool>>, crate::check::types::Ty>)>>(prism_rtl::rc([=, g_1 = std::move(g_1), target_2 = std::move(target_2), b_3 = std::move(b_3)](std::tuple<std::tuple<bool, Map<Text, bool>>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_4 = g_1;
            auto target_2_4 = target_2;
            auto b_3_4 = b_3;
            entered(once_job([=, g_1_4 = std::move(g_1_4), target_2_4 = std::move(target_2_4), b_3_4 = std::move(b_3_4)]() {
            return ({
                auto [bad, sn] = p0;
                auto t = p1;
                bad
                ? prism_rtl::finished(std::tuple{true, sn})
                : prism_rtl::more(prism_rtl::rc(NegWalk(g_1_4, target_2_4, t, b_3_4, sn)));
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start NegWalks, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>> start_neg_walks(crate::check::env::G g, Text target, Array<crate::check::types::Ty> ts, bool b, Map<Text, bool> seen) {
    return prism_rtl::make_rc<NegWalks>(g, target, ts, b, seen);
}


/// NatMinusSeeds: unbounded fn St -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> nat_minus_seeds(const crate::check::types::St& st) {
    return run_to_end(fold_job(keys(st.size_tys), Map<Text, crate::check::shrink::Rel>{}, ({
        auto st_1 = st;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Text>)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](std::tuple<Map<Text, crate::check::shrink::Rel>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
            return ({
                auto m = p0;
                auto k = p1;
                ({
                auto&& _m = crate::prelude::get(st_1_2.size_tys, k);
                prism_rtl::is_some(_m) ? ({
                auto&& t = prism_rtl::some_of(_m);
                call_then(crate::check::types::recording::start_zonk(st_1_2, t), [=](crate::check::types::Ty zonk_7185) {
                return zonk_7185 == crate::check::types::t_nat()
                    ? prism_rtl::finished(insert(m, prism_rtl::cat("nat:", k), crate::check::shrink::relations::no_rel()))
                    : prism_rtl::finished(m);
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> NatMinusSeeds::cycle() const {
    const auto& st = this->st;
    return fold_job(keys(prism_rtl::deref(st).size_tys), Map<Text, crate::check::shrink::Rel>{}, ({
        auto st_1 = st;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Text>)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](std::tuple<Map<Text, crate::check::shrink::Rel>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
            return ({
                auto m = p0;
                auto k = p1;
                ({
                auto&& _m = crate::prelude::get(prism_rtl::deref(st_1_2).size_tys, k);
                prism_rtl::is_some(_m) ? ({
                auto&& t = prism_rtl::some_of(_m);
                call_then(crate::check::types::recording::start_zonk(st_1_2, t), [=](crate::check::types::Ty zonk_7185) {
                return zonk_7185 == crate::check::types::t_nat()
                    ? prism_rtl::finished(insert(m, prism_rtl::cat("nat:", k), crate::check::shrink::relations::no_rel()))
                    : prism_rtl::finished(m);
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start NatMinusSeeds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_nat_minus_seeds(crate::check::types::St st) {
    return prism_rtl::make_rc<NatMinusSeeds>(st);
}


/// DefClauses: fn Def -> [FnClause]
Array<crate::syntax::decls::FnClause> def_clauses(const crate::check::env::Def& d) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
        auto&& clauses = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
        return clauses;
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
        auto&& clauses = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a0;
        return clauses;
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbDefault>(_m)) {
        auto&& clauses = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a0;
        return clauses;
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
        auto&& w = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
        return Array(std::vector{crate::syntax::decls::FnClause{.name = crate::syntax::decls::DefName(crate::syntax::decls::DefName::DefSName{prism_rtl::deref(w).name}), .params = Array<crate::syntax::Pattern_>{}, .body = crate::syntax::decls::FnBody(crate::syntax::decls::FnBody::BodyBlock{prism_rtl::deref(w).body}), .span = prism_rtl::deref(w).span}});
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
        auto&& l = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
        return Array(std::vector{crate::syntax::decls::FnClause{.name = crate::syntax::decls::DefName(crate::syntax::decls::DefName::DefOp{d.name, prism_rtl::deref(l).span}), .params = Array<crate::syntax::Pattern_>{}, .body = crate::syntax::decls::FnBody(crate::syntax::decls::FnBody::BodyExpr{l->value}), .span = prism_rtl::deref(l).span}});
    }
    {
        return Array<crate::syntax::decls::FnClause>{};
    }
}


/// OwnKey: fn Def -> Def
crate::check::env::Def own_key(const crate::check::env::Def& d) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
        auto&& im = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a2;
        crate::check::env::Def this_ = d;
        this_.qk = prism_rtl::cat(d.qk, " #", im->file, ".", prism_rtl::deref(prism_rtl::deref(im).span).start);
        return this_;
    }
    {
        return d;
    }
}


/// ?MethodOf: fn G, Def -> ?Text
std::optional<Text> method_of(const crate::check::env::G& g, const crate::check::env::Def& d) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
        auto&& cls = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a1;
        return crate::check::method_key(g, cls, d.name);
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbDefault>(_m)) {
        auto&& cls = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a1;
        return crate::check::method_key(g, cls, d.name);
    }
    {
        return std::optional<Text>{};
    }
}


/// MethodTargets: fn G, [Def] -> (Text ==> [Text])
Map<Text, Array<Text>> method_targets(const crate::check::env::G& g, const Array<crate::check::env::Def>& fns) {
    return fold(fns, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m, const crate::check::env::Def& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = method_of(g, d);
            if (prism_rtl::is_some(_m)) {
                auto&& mk = prism_rtl::some_of(_m);
                _v.set(insert(m, mk, crate::check::types::add_text(or_(crate::prelude::get(m, mk), Array<Text>{}), prism_rtl::deref(d).qk)));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(m);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// ImplDefs: fn G, [Def] -> (Text ==> Text)
Map<Text, Text> impl_defs(const crate::check::env::G& g, const Array<crate::check::env::Def>& fns) {
    return fold(fns, Map<Text, Text>{}, [&](const Map<Text, Text>& m, const crate::check::env::Def& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Text>> _v;
            auto&& _m = prism_rtl::deref(d).body;
            if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
                auto&& im = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, Text>> _v;
                    auto&& _m = method_of(g, d);
                    if (prism_rtl::is_some(_m)) {
                        auto&& mk = prism_rtl::some_of(_m);
                        _v.set(insert(m, prism_rtl::cat(mk, "|", im->file, ".", prism_rtl::deref(prism_rtl::deref(im).span).start), prism_rtl::deref(d).qk));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(m);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(m);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// ?MethodClass: fn G, Text -> ?Text
std::optional<Text> method_class(const crate::check::env::G& g, const Text& k) {
    auto&& _m = crate::prelude::get(g.vals, k);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        return prism_rtl::deref(v_).sort != Text::lit("method")
            ? std::optional<Text>{}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            auto&& _m = index(prism_rtl::deref(prism_rtl::deref(v_).scheme).bounds, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& cls = std::get<1>(prism_rtl::some_of(_m));
                _v.set(std::optional(cls));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// DispatchTargets: unbounded fn Shrink, Def, Site, Text -> [Text]
Array<Text> dispatch_targets(const crate::check::shrink::Shrink& sk, const crate::check::env::Def& d, const crate::check::shrink::walk::Site& site, const Text& k) {
    auto all = targets_of(sk, k);
    auto&& _m = method_class(sk.g, k);
    if (prism_rtl::is_none(_m)) {
        return all;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& cls = prism_rtl::some_of(_m);
        auto ck = crate::check::types::recording::choice_key(d.file, site.span, cls);
        auto&& _m = crate::prelude::get(sk.choices, ck);
        if (prism_rtl::is_none(_m)) {
            return all;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& cs = prism_rtl::some_of(_m);
            return run_to_end(fold_job(cs, Array<Text>{}, ({
                auto sk_1 = sk;
                auto k_2 = k;
                auto cls_3 = cls;
                auto all_4 = all;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, sk_1 = std::move(sk_1), k_2 = std::move(k_2), cls_3 = std::move(cls_3), all_4 = std::move(all_4)](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto sk_1_5 = sk_1;
                    auto k_2_5 = k_2;
                    auto cls_3_5 = cls_3;
                    auto all_4_5 = all_4;
                    entered(once_job([=, sk_1_5 = std::move(sk_1_5), k_2_5 = std::move(k_2_5), cls_3_5 = std::move(cls_3_5), all_4_5 = std::move(all_4_5)]() {
                    return ({
                        auto acc = p0;
                        auto ch = p1;
                        call_then(start_choice_targets(sk_1_5, k_2_5, cls_3_5, all_4_5, ch, Array<Text>{}), [=, acc = std::move(acc)](Array<Text> choice_targets_10578) { return prism_rtl::finished(crate::check::types::union_texts(acc, choice_targets_10578)); });
                    });
                }));
                });
            })));
            })));
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> DispatchTargets::cycle() const {
    const auto& sk = this->sk;
    const auto& d = this->d;
    const auto& site = this->site;
    const auto& k = this->k;
    auto all = targets_of(sk, k);
    return ({
        auto&& _m = method_class(prism_rtl::deref(sk).g, k);
        prism_rtl::is_none(_m) ? prism_rtl::finished(all)
        : prism_rtl::is_some(_m) ? ({
        auto&& cls = prism_rtl::some_of(_m);
        ({
        auto ck = crate::check::types::recording::choice_key(d->file, prism_rtl::deref(site).span, cls);
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(sk).choices, ck);
        prism_rtl::is_none(_m) ? prism_rtl::finished(all)
        : prism_rtl::is_some(_m) ? ({
        auto&& cs = prism_rtl::some_of(_m);
        fold_job(cs, Array<Text>{}, ({
        auto sk_1 = sk;
        auto k_2 = k;
        auto cls_3 = cls;
        auto all_4 = all;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, sk_1 = std::move(sk_1), k_2 = std::move(k_2), cls_3 = std::move(cls_3), all_4 = std::move(all_4)](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_5 = sk_1;
            auto k_2_5 = k_2;
            auto cls_3_5 = cls_3;
            auto all_4_5 = all_4;
            entered(once_job([=, sk_1_5 = std::move(sk_1_5), k_2_5 = std::move(k_2_5), cls_3_5 = std::move(cls_3_5), all_4_5 = std::move(all_4_5)]() {
            return ({
                auto acc = p0;
                auto ch = p1;
                call_then(start_choice_targets(sk_1_5, k_2_5, cls_3_5, all_4_5, ch, Array<Text>{}), [=, acc = std::move(acc)](Array<Text> choice_targets_10578) { return prism_rtl::finished(crate::check::types::union_texts(acc, choice_targets_10578)); });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start DispatchTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_dispatch_targets(crate::check::shrink::Shrink sk, crate::check::env::Def d, crate::check::shrink::walk::Site site, Text k) {
    return prism_rtl::make_rc<DispatchTargets>(sk, d, site, k);
}


/// ChoiceTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
Array<Text> choice_targets(const crate::check::shrink::Shrink& sk, const Text& k, const Text& cls, const Array<Text>& all, const Text& ch, const Array<Text>& seen) {
    return ch == Text::lit("none")
        ? Array<Text>{}
        : crate::syntax::lexer::chars::has_prefix(ch, Text::lit("impl:"))
        ? ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = crate::prelude::get(sk.impl_defs, prism_rtl::cat(k, "|", crate::syntax::lexer::chars::drop_prefix(ch, Text::lit("impl:"))));
        if (prism_rtl::is_some(_m)) {
            auto&& q = prism_rtl::some_of(_m);
            _v.set(Array(std::vector{q}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(filter(all, [&](const Text& q) { return q == k; }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    })
        : crate::syntax::lexer::chars::has_prefix(ch, Text::lit("derived:"))
        ? derived_targets(sk, k, cls, all, crate::syntax::lexer::chars::drop_prefix(ch, Text::lit("derived:")), seen)
        : all;
}


prism_rtl::Turn<Array<Text>> ChoiceTargets::cycle() const {
    const auto& sk = this->sk;
    const auto& k = this->k;
    const auto& cls = this->cls;
    const auto& all = this->all;
    const auto& ch = this->ch;
    const auto& seen = this->seen;
    return ch == Text::lit("none")
        ? prism_rtl::finished(Array<Text>{})
        : crate::syntax::lexer::chars::has_prefix(ch, Text::lit("impl:"))
        ? ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(sk).impl_defs, prism_rtl::cat(k, "|", crate::syntax::lexer::chars::drop_prefix(ch, Text::lit("impl:"))));
        prism_rtl::is_some(_m) ? ({
        auto&& q = prism_rtl::some_of(_m);
        prism_rtl::finished(Array(std::vector{q}));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(filter(all, [&](const Text& q) { return q == k; }))
        : throw prism_rtl::Panic("no arm matched");
    })
        : crate::syntax::lexer::chars::has_prefix(ch, Text::lit("derived:"))
        ? prism_rtl::more(prism_rtl::rc(DerivedTargets(sk, k, cls, all, crate::syntax::lexer::chars::drop_prefix(ch, Text::lit("derived:")), seen)))
        : prism_rtl::finished(all);
}


/// `Start ChoiceTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_choice_targets(crate::check::shrink::Shrink sk, Text k, Text cls, Array<Text> all, Text ch, Array<Text> seen) {
    return prism_rtl::make_rc<ChoiceTargets>(sk, k, cls, all, ch, seen);
}


/// DerivedTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
Array<Text> derived_targets(const crate::check::shrink::Shrink& sk, const Text& k, const Text& cls, const Array<Text>& all, const Text& n, const Array<Text>& seen) {
    return crate::check::types::has_text(seen, n)
        ? Array<Text>{}
        : ({
        auto tys = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(sk.g).types, n);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
                    auto&& _m = prism_rtl::deref(ti).body;
                    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                        auto&& fields = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                        _v.set(each(fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                            auto&& t = std::get<1>(_p0);
                            return t;
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                        auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                        _v.set(fold(cases, Array<crate::check::types::Ty>{}, [&](const Array<crate::check::types::Ty>& acc, const std::tuple<Text, Array<crate::check::types::Ty>>& _p1) {
                            auto&& args = std::get<1>(_p1);
                            return append(acc, args);
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
                        auto&& t = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
                        _v.set(Array(std::vector{t}));
                        goto _done;
                    }
                    {
                        _v.set(Array<crate::check::types::Ty>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::check::types::Ty>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto heads = fold(tys, Array<Text>{}, [&](const Array<Text>& acc, const crate::check::types::Ty& t) { return crate::check::types::union_texts(acc, ty_heads(t)); });
        run_to_end(fold_job(heads, Array<Text>{}, ({
        auto sk_1 = sk;
        auto k_2 = k;
        auto cls_3 = cls;
        auto all_4 = all;
        auto seen_5 = seen;
        auto n_6 = n;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, sk_1 = std::move(sk_1), k_2 = std::move(k_2), cls_3 = std::move(cls_3), all_4 = std::move(all_4), seen_5 = std::move(seen_5), n_6 = std::move(n_6)](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_7 = sk_1;
            auto k_2_7 = k_2;
            auto cls_3_7 = cls_3;
            auto all_4_7 = all_4;
            auto seen_5_7 = seen_5;
            auto n_6_7 = n_6;
            entered(once_job([=, sk_1_7 = std::move(sk_1_7), k_2_7 = std::move(k_2_7), cls_3_7 = std::move(cls_3_7), all_4_7 = std::move(all_4_7), seen_5_7 = std::move(seen_5_7), n_6_7 = std::move(n_6_7)]() {
            return ({
                auto acc = p0;
                auto h = p1;
                (prism_rtl::finished(crate::check::types::union_texts(acc, head_targets(sk_1_7, k_2_7, cls_3_7, all_4_7, h, crate::prelude::push(seen_5_7, n_6_7)))));
            });
        }));
        });
    })));
    })));
    });
}


prism_rtl::Turn<Array<Text>> DerivedTargets::cycle() const {
    const auto& sk = this->sk;
    const auto& k = this->k;
    const auto& cls = this->cls;
    const auto& all = this->all;
    const auto& n = this->n;
    const auto& seen = this->seen;
    return crate::check::types::has_text(seen, n)
        ? prism_rtl::finished(Array<Text>{})
        : ({
        auto tys = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(sk).g).types, n);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
                    auto&& _m = prism_rtl::deref(ti).body;
                    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                        auto&& fields = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                        _v.set(each(fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                            auto&& t = std::get<1>(_p0);
                            return t;
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                        auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                        _v.set(fold(cases, Array<crate::check::types::Ty>{}, [&](const Array<crate::check::types::Ty>& acc, const std::tuple<Text, Array<crate::check::types::Ty>>& _p1) {
                            auto&& args = std::get<1>(_p1);
                            return append(acc, args);
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
                        auto&& t = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
                        _v.set(Array(std::vector{t}));
                        goto _done;
                    }
                    {
                        _v.set(Array<crate::check::types::Ty>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::check::types::Ty>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto heads = fold(tys, Array<Text>{}, [&](const Array<Text>& acc, const crate::check::types::Ty& t) { return crate::check::types::union_texts(acc, ty_heads(t)); });
        fold_job(heads, Array<Text>{}, ({
        auto sk_1 = sk;
        auto k_2 = k;
        auto cls_3 = cls;
        auto all_4 = all;
        auto seen_5 = seen;
        auto n_6 = n;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, sk_1 = std::move(sk_1), k_2 = std::move(k_2), cls_3 = std::move(cls_3), all_4 = std::move(all_4), seen_5 = std::move(seen_5), n_6 = std::move(n_6)](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_7 = sk_1;
            auto k_2_7 = k_2;
            auto cls_3_7 = cls_3;
            auto all_4_7 = all_4;
            auto seen_5_7 = seen_5;
            auto n_6_7 = n_6;
            entered(once_job([=, sk_1_7 = std::move(sk_1_7), k_2_7 = std::move(k_2_7), cls_3_7 = std::move(cls_3_7), all_4_7 = std::move(all_4_7), seen_5_7 = std::move(seen_5_7), n_6_7 = std::move(n_6_7)]() {
            return ({
                auto acc = p0;
                auto h = p1;
                (prism_rtl::finished(crate::check::types::union_texts(acc, head_targets(sk_1_7, k_2_7, cls_3_7, all_4_7, h, crate::prelude::push(seen_5_7, n_6_7)))));
            });
        }));
        });
    })));
    }))->cycle();
    });
}


/// `Start DerivedTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_derived_targets(crate::check::shrink::Shrink sk, Text k, Text cls, Array<Text> all, Text n, Array<Text> seen) {
    return prism_rtl::make_rc<DerivedTargets>(sk, k, cls, all, n, seen);
}


/// TyHeads: fn Ty -> [Text]
Array<Text> ty_heads(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return fold(args, Array(std::vector{n}), [&](const Array<Text>& acc, const crate::check::types::Ty& a) { return crate::check::types::union_texts(acc, ty_heads(a)); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return fold(ts, Array<Text>{}, [&](const Array<Text>& acc, const crate::check::types::Ty& a) { return crate::check::types::union_texts(acc, ty_heads(a)); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return ty_heads(prism_rtl::deref(prism_rtl::deref(e)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& b = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return crate::check::types::union_texts(ty_heads(prism_rtl::deref(prism_rtl::deref(a))), ty_heads(prism_rtl::deref(prism_rtl::deref(b))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return ty_heads(prism_rtl::deref(prism_rtl::deref(i)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(t)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t)) {
        return Array<Text>{};
    }
    {
        return Array(std::vector{Text::lit("?")});
    }
}


/// HeadTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
Array<Text> head_targets(const crate::check::shrink::Shrink& sk, const Text& k, const Text& cls, const Array<Text>& all, const Text& h, const Array<Text>& seen) {
    return h == Text::lit("?")
        ? all
        : crate::check::env::traits::builtin_has(cls, h) || crate::check::env::is_prim_type(h)
        ? Array<Text>{}
        : ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = index(filter(or_(crate::prelude::get(prism_rtl::deref(sk.g).impls, cls), Array<crate::check::env::ImplInfo>{}), [&](const crate::check::env::ImplInfo& im) { return head_key(prism_rtl::deref(im).head) == std::optional(h); }), Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& im = prism_rtl::some_of(_m);
            _v.set(choice_targets(sk, k, cls, all, crate::check::env::traits::impl_choice(im), seen));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(all);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// ?HeadKey: fn Ty -> ?Text
std::optional<Text> head_key(const crate::check::types::Ty& ty0) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(ty0)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(ty0).a0;
        return std::optional(n);
    }
    {
        return std::optional<Text>{};
    }
}


/// TargetsOf: fn Shrink, Text -> [Text]
Array<Text> targets_of(const crate::check::shrink::Shrink& sk, const Text& k) {
    return or_(crate::prelude::get(sk.targets, k), Array(std::vector{k}));
}


/// SigKeyOf: fn Shrink, Text -> Text
Text sig_key_of(const crate::check::shrink::Shrink& sk, const Text& k) {
    auto&& _m = crate::prelude::get(sk.by_key, k);
    if (prism_rtl::is_some(_m)) {
        auto&& d = prism_rtl::some_of(_m);
        return or_(method_of(sk.g, d), k);
    }
    if (prism_rtl::is_none(_m)) {
        return k;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ShownKey: fn Text -> Text
Text shown_key(const Text& k) {
    return crate::check::types::bare_name(or_(index(split_on(or_(crate::syntax::lexer::chars::last(split_on(k, Text::lit(" impl "))), k), Text::lit(" #")), Nat(0u)), k));
}


/// IsUnboundedKey: fn G, Text -> Bool
bool is_unbounded_key(const crate::check::env::G& g, const Text& k) {
    auto&& _m = crate::prelude::get(g.vals, k);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::deref(prism_rtl::deref(v_).scheme).ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CUnbound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::check::shrink::types
