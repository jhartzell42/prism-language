// The module `Check.Expr.Lets`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/expr/lets/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Expr.Lets`, from `target/bootstrap/cpp-src/prismc/check/expr/lets.prism`.
namespace crate::check::expr::lets {

/// InferExprBlock: unbounded fn Env, St, Block -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Block& b_p2) {
    return is_widgetish(b_p2.stmts)
        ? crate::check::blocks::infer_widget_block(env_p0, st_p1, b_p2)
        : ({
        auto [env2_p3, st2_p4] = bind_group(env_p0, st_p1, b_p2.stmts);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = crate::syntax::lexer::chars::last(b_p2.stmts);
        if (prism_rtl::is_some(_m)) {
            auto&& s_p5 = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                auto&& _m = prism_rtl::deref(s_p5).kind;
                if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
                    auto&& e_p6 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                    _v.set(crate::check::expr::infer(env2_p3, st2_p4, e_p6));
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::check::types::t_unit(), st2_p4});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{crate::check::types::t_unit(), st2_p4});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferExprBlock::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& b_p2 = this->b_p2;
    return is_widgetish(prism_rtl::deref(b_p2).stmts)
        ? prism_rtl::more(prism_rtl::rc(crate::check::blocks::InferWidgetBlock(env_p0, st_p1, b_p2)))
        : ({
        auto b_p2_1 = b_p2;
        auto env_p0_2 = env_p0;
        auto st_p1_3 = st_p1;
        call_then(start_bind_group(env_p0_2, st_p1_3, prism_rtl::deref(b_p2_1).stmts), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_group_1662) {
        return ({
            auto [env2_p3, st2_p4] = bind_group_1662;
            ({
            auto&& _m = crate::syntax::lexer::chars::last(prism_rtl::deref(b_p2_1).stmts);
            prism_rtl::is_some(_m) ? ({
            auto&& s_p5 = prism_rtl::some_of(_m);
            ({
            auto&& _m = prism_rtl::deref(s_p5).kind;
            prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
            auto&& e_p6 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
            prism_rtl::more(prism_rtl::rc(crate::check::expr::Infer(env2_p3, st2_p4, e_p6)));
        })
            : prism_rtl::finished(std::tuple{crate::check::types::t_unit(), st2_p4});
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::t_unit(), st2_p4})
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    });
}


/// `Start InferExprBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_expr_block(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2) {
    return prism_rtl::make_rc<InferExprBlock>(env_p0, st_p1, b_p2);
}


/// IsWidgetish: fn [Stmt] -> Bool
bool is_widgetish(const Array<crate::syntax::Stmt>& stmts_p0) {
    return fold(stmts_p0, false, [&](const bool& seen_p1, const crate::syntax::Stmt& s_p2) { return prism_rtl::deref(seen_p1) || builds(s_p2); });
}


/// Builds: fn Stmt -> Bool
bool builds(const crate::syntax::Stmt& s_p0) {
    auto&& _m = s_p0.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// BindGroup: unbounded fn Env, St, [Stmt] -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_group(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Stmt>& stmts_p2) {
    auto order_p3 = crate::check::blocks::group_order(stmts_p2);
    auto [env1_p8, st1_p9] = run_to_end(fold_job(order_p3, std::tuple{env_p0, st_p1}, ({
        auto stmts_p2_1 = stmts_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, stmts_p2_1 = std::move(stmts_p2_1)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto stmts_p2_1_2 = stmts_p2_1;
            entered(once_job([=, stmts_p2_1_2 = std::move(stmts_p2_1_2)]() {
            return ({
                auto [en_p5, s_p6] = p0;
                auto i_p7 = p1;
                (prism_rtl::more(prism_rtl::rc(PreBind(en_p5, s_p6, or_(index(stmts_p2_1_2, i_p7), dummy_stmt())))));
            });
        }));
        });
    }));
    })));
    auto st2_p4 = prism_rtl::deref(st1_p9).recording && (len(stmts_p2) > Nat(1u))
        ? crate::check::types::recording::note_group(st1_p9, stmts_span(stmts_p2), Text::lit("expr"), crate::check::blocks::dep_order(stmts_p2))
        : st1_p9;
    return run_to_end(fold_job(order_p3, std::tuple{env1_p8, st2_p4}, ({
        auto stmts_p2_1 = stmts_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, stmts_p2_1 = std::move(stmts_p2_1)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto stmts_p2_1_2 = stmts_p2_1;
            entered(once_job([=, stmts_p2_1_2 = std::move(stmts_p2_1_2)]() {
            return ({
                auto [en_pa, s_pb] = p0;
                auto i_pc = p1;
                (prism_rtl::more(prism_rtl::rc(CheckGroupStmt(en_pa, s_pb, or_(index(stmts_p2_1_2, i_pc), dummy_stmt()), is_last(stmts_p2_1_2, i_pc)))));
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindGroup::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& stmts_p2 = this->stmts_p2;
    auto env_p0_1 = env_p0;
    auto st_p1_2 = st_p1;
    auto stmts_p2_3 = stmts_p2;
    return call_then(crate::check::blocks::start_group_order(stmts_p2_3), [=](Array<Nat> group_order_2649) {
        return ({
            auto order_p3 = group_order_2649;
            call_value(fold_job(order_p3, std::tuple{env_p0_1, st_p1_2}, ({
            auto stmts_p2_3_4 = stmts_p2_3;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, stmts_p2_3_4 = std::move(stmts_p2_3_4)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto stmts_p2_3_4_4 = stmts_p2_3_4;
                entered(once_job([=, stmts_p2_3_4_4 = std::move(stmts_p2_3_4_4)]() {
                return ({
                    auto [en_p5, s_p6] = p0;
                    auto i_p7 = p1;
                    (prism_rtl::more(prism_rtl::rc(PreBind(en_p5, s_p6, or_(index(stmts_p2_3_4_4, i_p7), dummy_stmt())))));
                });
            }));
            });
        }));
        })), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> fold_2690) {
            return ({
                auto [env1_p8, st1_p9] = fold_2690;
                auto st2_p4 = prism_rtl::deref(st1_p9).recording && (len(stmts_p2_3) > Nat(1u))
                    ? crate::check::types::recording::note_group(st1_p9, stmts_span(stmts_p2_3), Text::lit("expr"), crate::check::blocks::dep_order(stmts_p2_3))
                    : st1_p9;
                fold_job(order_p3, std::tuple{env1_p8, st2_p4}, ({
                auto stmts_p2_3_4 = stmts_p2_3;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, stmts_p2_3_4 = std::move(stmts_p2_3_4)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto stmts_p2_3_4_4 = stmts_p2_3_4;
                    entered(once_job([=, stmts_p2_3_4_4 = std::move(stmts_p2_3_4_4)]() {
                    return ({
                        auto [en_pa, s_pb] = p0;
                        auto i_pc = p1;
                        (prism_rtl::more(prism_rtl::rc(CheckGroupStmt(en_pa, s_pb, or_(index(stmts_p2_3_4_4, i_pc), dummy_stmt()), is_last(stmts_p2_3_4_4, i_pc)))));
                    });
                }));
                });
            }));
            }))->cycle();
            });
        });
        });
    });
}


/// `Start BindGroup, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_group(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2) {
    return prism_rtl::make_rc<BindGroup>(env_p0, st_p1, stmts_p2);
}


/// StmtsSpan: fn [Stmt] -> Range
crate::syntax::Range stmts_span(const Array<crate::syntax::Stmt>& stmts_p0) {
    return crate::syntax::Range{.start = prism_rtl::deref(prism_rtl::deref(or_(index(stmts_p0, Nat(0u)), dummy_stmt())).span).start, .end = prism_rtl::deref(prism_rtl::deref(or_(crate::syntax::lexer::chars::last(stmts_p0), dummy_stmt())).span).end};
}


/// let dummyStmt
crate::syntax::Stmt dummy_stmt() {
    return crate::syntax::Stmt{.kind = crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}}), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// IsLast: fn [Stmt], Nat -> Bool
bool is_last(const Array<crate::syntax::Stmt>& stmts_p0, const Nat& i_p1) {
    return (i_p1 + Nat(1u)) == len(stmts_p0);
}


/// PreBind: unbounded fn Env, St, Stmt -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> pre_bind(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Stmt& s_p2) {
    auto&& _m = s_p2.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        auto&& sg_p3 = prism_rtl::as<crate::syntax::StmtKind::SSignature>(_m).a0;
        auto [sc_p4, st2_p5] = crate::check::env::reading::sig_scheme(crate::check::expr::env_cx(env_p0), st_p1, prism_rtl::deref(sg_p3).ty, prism_rtl::deref(sg_p3).bounds);
        return crate::check::expr::bind_local_id(crate::check::expr::with_local(env_p0, crate::check::env::def_name_text(prism_rtl::deref(sg_p3).name), sc_p4), st2_p5, crate::check::env::def_name_text(prism_rtl::deref(sg_p3).name), crate::check::env::def_name_span(prism_rtl::deref(sg_p3).name));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f_p6 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        auto name_p7 = crate::check::env::def_name_text(prism_rtl::deref(f_p6).name);
        auto&& _m = crate::prelude::get(env_p0.locals, name_p7);
        if (prism_rtl::is_some(_m)) {
            return std::tuple{env_p0, st_p1};
        }
        if (prism_rtl::is_none(_m)) {
            auto [v_p8, st2_p9] = crate::check::types::fresh_var(st_p1, false, Text::lit(""));
            return crate::check::expr::bind_local_id(crate::check::expr::with_local(env_p0, name_p7, crate::check::types::schemes::mono(v_p8)), st2_p9, name_p7, crate::check::env::def_name_span(prism_rtl::deref(f_p6).name));
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_pa = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_pa).kind);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n_pb = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            auto [v_pd, st1_pe] = crate::check::types::fresh_var(st_p1, true, crate::check::env::sname_key(n_pb));
            auto st2_pc = crate::check::types::recording::at_binder(st1_pe, v_pd, prism_rtl::deref(n_pb).span);
            auto [rw_pf, st3_pg] = crate::check::types::recording::fresh_row(st2_pc, Array<Text>{});
            return crate::check::expr::bind_local_id(crate::check::expr::with_local(env_p0, crate::check::env::sname_key(n_pb), crate::check::types::schemes::mono(crate::check::types::with_marks(type_marks(prism_rtl::deref(n_pb).sigils), v_pd, rw_pf))), st3_pg, crate::check::env::sname_key(n_pb), prism_rtl::deref(n_pb).span);
        }
        {
            return std::tuple{env_p0, st_p1};
        }
    }
    {
        return std::tuple{env_p0, st_p1};
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> PreBind::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& s_p2 = this->s_p2;
    return ({
        auto&& _m = prism_rtl::deref(s_p2).kind;
        prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? ({
        auto&& sg_p3 = prism_rtl::as<crate::syntax::StmtKind::SSignature>(_m).a0;
        ({
        auto env_p0_1 = env_p0;
        auto sg_p3_2 = sg_p3;
        auto st_p1_3 = st_p1;
        call_then(crate::check::env::reading::start_sig_scheme(crate::check::expr::env_cx(env_p0_1), st_p1_3, prism_rtl::deref(sg_p3_2).ty, prism_rtl::deref(sg_p3_2).bounds), [=](std::tuple<crate::check::types::Scheme, crate::check::types::St> sig_scheme_3595) {
        return ({
            auto [sc_p4, st2_p5] = sig_scheme_3595;
            (prism_rtl::finished(crate::check::expr::bind_local_id(crate::check::expr::with_local(env_p0_1, crate::check::env::def_name_text(prism_rtl::deref(sg_p3_2).name), sc_p4), st2_p5, crate::check::env::def_name_text(prism_rtl::deref(sg_p3_2).name), crate::check::env::def_name_span(prism_rtl::deref(sg_p3_2).name))));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f_p6 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        ({
        auto name_p7 = crate::check::env::def_name_text(prism_rtl::deref(f_p6).name);
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0).locals, name_p7);
        prism_rtl::is_some(_m) ? prism_rtl::finished(std::tuple{env_p0, st_p1})
        : prism_rtl::is_none(_m) ? ({
        auto [v_p8, st2_p9] = crate::check::types::fresh_var(st_p1, false, Text::lit(""));
        (prism_rtl::finished(crate::check::expr::bind_local_id(crate::check::expr::with_local(env_p0, name_p7, crate::check::types::schemes::mono(v_p8)), st2_p9, name_p7, crate::check::env::def_name_span(prism_rtl::deref(f_p6).name))));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_pa = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_pa).kind);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_pb = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto [v_pd, st1_pe] = crate::check::types::fresh_var(st_p1, true, crate::check::env::sname_key(n_pb));
        auto st2_pc = crate::check::types::recording::at_binder(st1_pe, v_pd, prism_rtl::deref(n_pb).span);
        auto [rw_pf, st3_pg] = crate::check::types::recording::fresh_row(st2_pc, Array<Text>{});
        (prism_rtl::finished(crate::check::expr::bind_local_id(crate::check::expr::with_local(env_p0, crate::check::env::sname_key(n_pb), crate::check::types::schemes::mono(crate::check::types::with_marks(type_marks(prism_rtl::deref(n_pb).sigils), v_pd, rw_pf))), st3_pg, crate::check::env::sname_key(n_pb), prism_rtl::deref(n_pb).span)));
    });
    })
        : prism_rtl::finished(std::tuple{env_p0, st_p1});
    });
    })
        : prism_rtl::finished(std::tuple{env_p0, st_p1});
    });
}


/// `Start PreBind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_pre_bind(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Stmt s_p2) {
    return prism_rtl::make_rc<PreBind>(env_p0, st_p1, s_p2);
}


/// CheckGroupStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> check_group_stmt(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Stmt& s_p2, const bool& last_p3) {
    auto&& _m = s_p2.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_p4 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_o5 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& e_p6 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        return check_let(env_p0, st_p1, p_p4, ty_o5, e_p6, s_p2.span);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f_p7 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return check_local_fn(env_p0, st_p1, f_p7, s_p2.span);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        return std::tuple{env_p0, st_p1};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e_p8 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return last_p3
            ? std::tuple{env_p0, st_p1}
            : ({
            auto [t_p9, st2_pa] = crate::check::expr::infer(env_p0, st_p1, e_p8);
            std::tuple{env_p0, st2_pa};
        });
    }
    {
        return std::tuple{env_p0, crate::check::types::recording::err(st_p1, Text::lit("mismatch"), s_p2.span, Text::lit("this statement belongs in a widget, `given:` or `update` block"))};
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> CheckGroupStmt::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& s_p2 = this->s_p2;
    const auto& last_p3 = this->last_p3;
    return ({
        auto&& _m = prism_rtl::deref(s_p2).kind;
        prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_p4 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_o5 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& e_p6 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        prism_rtl::more(prism_rtl::rc(CheckLet(env_p0, st_p1, p_p4, ty_o5, e_p6, prism_rtl::deref(s_p2).span)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f_p7 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        prism_rtl::more(prism_rtl::rc(CheckLocalFn(env_p0, st_p1, f_p7, prism_rtl::deref(s_p2).span)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? prism_rtl::finished(std::tuple{env_p0, st_p1})
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& e_p8 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        prism_rtl::deref(last_p3)
        ? prism_rtl::finished(std::tuple{env_p0, st_p1})
        : ({
        auto e_p8_1 = e_p8;
        auto env_p0_2 = env_p0;
        auto st_p1_3 = st_p1;
        call_then(crate::check::expr::start_infer(env_p0_2, st_p1_3, e_p8_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_4771) {
        return ({
            auto [t_p9, st2_pa] = infer_4771;
            (prism_rtl::finished(std::tuple{env_p0_2, st2_pa}));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{env_p0, crate::check::types::recording::err(st_p1, Text::lit("mismatch"), prism_rtl::deref(s_p2).span, Text::lit("this statement belongs in a widget, `given:` or `update` block"))});
    });
}


/// `Start CheckGroupStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_check_group_stmt(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Stmt s_p2, bool last_p3) {
    return prism_rtl::make_rc<CheckGroupStmt>(env_p0, st_p1, s_p2, last_p3);
}


/// CheckLet: unbounded fn Env, St, Pattern, ?Type, Expr, Range -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> check_let(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const std::optional<crate::syntax::Type>& ty_o3, const crate::syntax::Expr& e_p4, const crate::syntax::Range& span_p5) {
    auto st0_p6 = crate::check::types::schemes::enter_level(st_p1);
    auto [annot_od, st1_pe] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<crate::check::types::Ty>, crate::check::types::St>> _v;
        if (prism_rtl::is_some(ty_o3)) {
            auto&& t_pa = prism_rtl::some_of(ty_o3);
            _v.set(({
                auto [at_pb, s2_pc] = crate::check::env::reading::conv_type(crate::check::expr::env_cx(env_p0), st0_p6, t_pa);
                std::tuple{std::optional(at_pb), s2_pc};
            }));
            goto _done;
        }
        if (prism_rtl::is_none(ty_o3)) {
            _v.set(std::tuple{std::optional<crate::check::types::Ty>{}, st0_p6});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [pre_pj, st2_pk] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = prism_rtl::deref(p_p2.kind);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n_pf = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                auto&& _m = crate::prelude::get(env_p0.locals, crate::check::env::sname_key(n_pf));
                if (prism_rtl::is_some(_m)) {
                    auto&& sc_pg = prism_rtl::some_of(_m);
                    _v.set((prism_rtl::deref(n_pf).sigils == Text::lit("")) && crate::check::types::is_flex_var(st1_pe, prism_rtl::deref(sc_pg).ty)
                        ? ({
                        auto [v_ph, s2_pi] = crate::check::types::fresh_var(st1_pe, true, crate::check::env::sname_key(n_pf));
                        std::tuple{v_ph, crate::check::types::recording::at_binder(s2_pi, v_ph, prism_rtl::deref(n_pf).span)};
                    })
                        : std::tuple{prism_rtl::deref(sc_pg).ty, st1_pe});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::check::types::fresh_var(st1_pe, true, crate::check::env::sname_key(n_pf)));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(crate::check::types::fresh_var(st1_pe, false, Text::lit("")));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto st3_p7 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        if (prism_rtl::is_some(annot_od)) {
            auto&& at_pl = prism_rtl::some_of(annot_od);
            _v.set(crate::check::expr::check(env_p0, st2_pk, e_p4, at_pl));
            goto _done;
        }
        if (prism_rtl::is_none(annot_od)) {
            _v.set(crate::check::expr::check(env_p0, st2_pk, e_p4, pre_pj));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st4_p8 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        if (prism_rtl::is_some(annot_od)) {
            auto&& at_pm = prism_rtl::some_of(annot_od);
            _v.set(crate::check::types::unify::unify(st3_p7, pre_pj, at_pm, span_p5));
            goto _done;
        }
        if (prism_rtl::is_none(annot_od)) {
            _v.set(st3_p7);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st5_p9 = crate::check::env::traits::solve_wants(env_p0.g, st4_p8, env_p0.givens, false);
    auto&& _m = prism_rtl::deref(p_p2.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_pn = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto name_po = crate::check::env::sname_key(n_pn);
        auto t_pp = crate::check::types::recording::zonk(st5_p9, pre_pj);
        auto [env2_ps, st7a_pt] = crate::check::expr::patterns::bind_name(env_p0, st5_p9, n_pn, t_pp);
        auto st7_pq = crate::check::types::schemes::leave_level(st7a_pt);
        auto ahead_fr = ({
            auto env_p0_1 = env_p0;
            auto name_po_2 = name_po;
            auto pre_pj_3 = pre_pj;
            auto t_pp_4 = t_pp;
            auto span_p5_5 = span_p5;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1), name_po_2 = std::move(name_po_2), pre_pj_3 = std::move(pre_pj_3), t_pp_4 = std::move(t_pp_4), span_p5_5 = std::move(span_p5_5)](crate::check::types::St p0) {
            return ({
                auto env_p0_1_6 = env_p0_1;
                auto name_po_2_6 = name_po_2;
                auto pre_pj_3_6 = pre_pj_3;
                auto t_pp_4_6 = t_pp_4;
                auto span_p5_5_6 = span_p5_5;
                entered(once_job([=, env_p0_1_6 = std::move(env_p0_1_6), name_po_2_6 = std::move(name_po_2_6), pre_pj_3_6 = std::move(pre_pj_3_6), t_pp_4_6 = std::move(t_pp_4_6), span_p5_5_6 = std::move(span_p5_5_6)]() {
                return ({
                    auto s_pu = p0;
                    (prism_rtl::more(prism_rtl::rc(AheadUnify(env_p0_1_6, s_pu, name_po_2_6, pre_pj_3_6, t_pp_4_6, span_p5_5_6))));
                });
            }));
            });
        })));
        });
        return crate::check::types::schemes::holds_node(st7_pq, t_pp) || is_topic_name(name_po)
            ? std::tuple{env2_ps, run_to_end(ahead_fr(st7_pq))}
            : ({
            auto lambda_pv = crate::check::expr::is_lambda(e_p4);
            auto [keep_p10, bounds_p11, st8_p12] = wants_above(st7_pq, t_pp, lambda_pv);
            auto [sc_p13, st9_p14] = crate::check::types::schemes::generalize(st8_p12, t_pp, keep_p10, bounds_p11);
            std::tuple{crate::check::expr::with_local(env2_ps, name_po, sc_p13), run_to_end(ahead_fr(crate::check::types::recording::note_gen(st9_p14, prism_rtl::deref(n_pn).span, name_po, sc_p13)))};
        });
    }
    {
        auto st6_p15 = crate::check::types::schemes::leave_level(st5_p9);
        return crate::check::expr::patterns::bind_pattern(env_p0, st6_p15, p_p2, crate::check::types::recording::zonk(st6_p15, pre_pj), false);
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> CheckLet::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& p_p2 = this->p_p2;
    const auto& ty_o3 = this->ty_o3;
    const auto& e_p4 = this->e_p4;
    const auto& span_p5 = this->span_p5;
    auto st0_p6 = crate::check::types::schemes::enter_level(st_p1);
    auto [annot_od, st1_pe] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<crate::check::types::Ty>, crate::check::types::St>> _v;
        if (prism_rtl::is_some(ty_o3)) {
            auto&& t_pa = prism_rtl::some_of(ty_o3);
            _v.set(({
                auto [at_pb, s2_pc] = crate::check::env::reading::conv_type(crate::check::expr::env_cx(env_p0), st0_p6, t_pa);
                std::tuple{std::optional(at_pb), s2_pc};
            }));
            goto _done;
        }
        if (prism_rtl::is_none(ty_o3)) {
            _v.set(std::tuple{std::optional<crate::check::types::Ty>{}, st0_p6});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [pre_pj, st2_pk] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p2).kind);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n_pf = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0).locals, crate::check::env::sname_key(n_pf));
                if (prism_rtl::is_some(_m)) {
                    auto&& sc_pg = prism_rtl::some_of(_m);
                    _v.set((prism_rtl::deref(n_pf).sigils == Text::lit("")) && crate::check::types::is_flex_var(st1_pe, prism_rtl::deref(sc_pg).ty)
                        ? ({
                        auto [v_ph, s2_pi] = crate::check::types::fresh_var(st1_pe, true, crate::check::env::sname_key(n_pf));
                        std::tuple{v_ph, crate::check::types::recording::at_binder(s2_pi, v_ph, prism_rtl::deref(n_pf).span)};
                    })
                        : std::tuple{prism_rtl::deref(sc_pg).ty, st1_pe});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::check::types::fresh_var(st1_pe, true, crate::check::env::sname_key(n_pf)));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(crate::check::types::fresh_var(st1_pe, false, Text::lit("")));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto st3_p7 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        if (prism_rtl::is_some(annot_od)) {
            auto&& at_pl = prism_rtl::some_of(annot_od);
            _v.set(crate::check::expr::check(env_p0, st2_pk, e_p4, at_pl));
            goto _done;
        }
        if (prism_rtl::is_none(annot_od)) {
            _v.set(crate::check::expr::check(env_p0, st2_pk, e_p4, pre_pj));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st4_p8 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        if (prism_rtl::is_some(annot_od)) {
            auto&& at_pm = prism_rtl::some_of(annot_od);
            _v.set(crate::check::types::unify::unify(st3_p7, pre_pj, at_pm, span_p5));
            goto _done;
        }
        if (prism_rtl::is_none(annot_od)) {
            _v.set(st3_p7);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto e_p4_1 = e_p4;
    auto env_p0_2 = env_p0;
    auto p_p2_3 = p_p2;
    auto span_p5_4 = span_p5;
    return call_then(crate::check::env::traits::start_solve_wants(prism_rtl::deref(env_p0_2).g, st4_p8, prism_rtl::deref(env_p0_2).givens, false), [=](crate::check::types::St solve_wants_6282) {
        return ({
            auto st5_p9 = solve_wants_6282;
            ({
            auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p2_3).kind);
            prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
            auto&& n_pn = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            ({
            auto name_po = crate::check::env::sname_key(n_pn);
            auto n_pn_5 = n_pn;
            call_then(crate::check::types::recording::start_zonk(st5_p9, pre_pj), [=, name_po = std::move(name_po), n_pn_5 = std::move(n_pn_5)](crate::check::types::Ty zonk_6573) {
            return ({
                auto t_pp = zonk_6573;
                call_then(crate::check::expr::patterns::start_bind_name(env_p0_2, st5_p9, n_pn_5, t_pp), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_name_6620) {
                return ({
                    auto [env2_ps, st7a_pt] = bind_name_6620;
                    auto st7_pq = crate::check::types::schemes::leave_level(st7a_pt);
                    auto ahead_fr = ({
                        auto env_p0_2_6 = env_p0_2;
                        auto name_po_6 = name_po;
                        auto pre_pj_7 = pre_pj;
                        auto t_pp_8 = t_pp;
                        auto span_p5_4_9 = span_p5_4;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>>(prism_rtl::rc([=, env_p0_2_6 = std::move(env_p0_2_6), name_po_6 = std::move(name_po_6), pre_pj_7 = std::move(pre_pj_7), t_pp_8 = std::move(t_pp_8), span_p5_4_9 = std::move(span_p5_4_9)](crate::check::types::St p0) {
                        return ({
                            auto env_p0_2_6_9 = env_p0_2_6;
                            auto name_po_6_9 = name_po_6;
                            auto pre_pj_7_9 = pre_pj_7;
                            auto t_pp_8_9 = t_pp_8;
                            auto span_p5_4_9_9 = span_p5_4_9;
                            entered(once_job([=, env_p0_2_6_9 = std::move(env_p0_2_6_9), name_po_6_9 = std::move(name_po_6_9), pre_pj_7_9 = std::move(pre_pj_7_9), t_pp_8_9 = std::move(t_pp_8_9), span_p5_4_9_9 = std::move(span_p5_4_9_9)]() {
                            return ({
                                auto s_pu = p0;
                                (prism_rtl::more(prism_rtl::rc(AheadUnify(env_p0_2_6_9, s_pu, name_po_6_9, pre_pj_7_9, t_pp_8_9, span_p5_4_9_9))));
                            });
                        }));
                        });
                    })));
                    });
                    call_then(crate::check::types::schemes::start_holds_node(st7_pq, t_pp), [=, ahead_fr = std::move(ahead_fr)](bool holds_node_6893) {
                    return holds_node_6893 || is_topic_name(name_po)
                        ? call_value(ahead_fr(st7_pq), [=](crate::check::types::St ahead_6943) { return prism_rtl::finished(std::tuple{env2_ps, ahead_6943}); })
                        : ({
                        auto lambda_pv = crate::check::expr::is_lambda(e_p4_1);
                        call_then(start_wants_above(st7_pq, t_pp, std::move(lambda_pv)), [=](std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St> wants_above_7058) {
                        return ({
                            auto [keep_p10, bounds_p11, st8_p12] = wants_above_7058;
                            call_then(crate::check::types::schemes::start_generalize(st8_p12, t_pp, keep_p10, bounds_p11), [=](std::tuple<crate::check::types::Scheme, crate::check::types::St> generalize_7118) {
                            return ({
                                auto [sc_p13, st9_p14] = generalize_7118;
                                call_value(ahead_fr(crate::check::types::recording::note_gen(st9_p14, prism_rtl::deref(n_pn_5).span, name_po, sc_p13)), [=](crate::check::types::St ahead_7197) { return prism_rtl::finished(std::tuple{crate::check::expr::with_local(env2_ps, name_po, sc_p13), ahead_7197}); });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
        })
            : ({
            auto st6_p15 = crate::check::types::schemes::leave_level(st5_p9);
            call_then(crate::check::types::recording::start_zonk(st6_p15, pre_pj), [=](crate::check::types::Ty zonk_7332) { return prism_rtl::more(prism_rtl::rc(crate::check::expr::patterns::BindPattern(env_p0_2, st6_p15, p_p2_3, zonk_7332, false))); });
        });
        });
        });
    });
}


/// `Start CheckLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_check_let(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, std::optional<crate::syntax::Type> ty_o3, crate::syntax::Expr e_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<CheckLet>(env_p0, st_p1, p_p2, ty_o3, e_p4, span_p5);
}


/// AheadUnify: unbounded fn Env, St, Text, Ty, Ty, Range -> St
crate::check::types::St ahead_unify(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& name_p2, const crate::check::types::Ty& pre_p3, const crate::check::types::Ty& t_p4, const crate::syntax::Range& span_p5) {
    auto&& _m = crate::prelude::get(env_p0.locals, name_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& sc0_p6 = prism_rtl::some_of(_m);
        return prism_rtl::deref(sc0_p6).ty != pre_p3
            ? crate::check::types::unify::unify(st_p1, prism_rtl::deref(sc0_p6).ty, t_p4, span_p5)
            : st_p1;
    }
    if (prism_rtl::is_none(_m)) {
        return st_p1;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> AheadUnify::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& name_p2 = this->name_p2;
    const auto& pre_p3 = this->pre_p3;
    const auto& t_p4 = this->t_p4;
    const auto& span_p5 = this->span_p5;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0).locals, name_p2);
        prism_rtl::is_some(_m) ? ({
        auto&& sc0_p6 = prism_rtl::some_of(_m);
        prism_rtl::deref(sc0_p6).ty != pre_p3
        ? prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st_p1, prism_rtl::deref(sc0_p6).ty, t_p4, span_p5)))
        : prism_rtl::finished(st_p1);
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(st_p1)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start AheadUnify, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_ahead_unify(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text name_p2, crate::check::types::Ty pre_p3, crate::check::types::Ty t_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<AheadUnify>(env_p0, st_p1, name_p2, pre_p3, t_p4, span_p5);
}


/// TypeMarks: fn Text -> Text
Text type_marks(const Text& marks_p0) {
    return crate::syntax::lexer::chars::has_prefix(marks_p0, Text::lit("&"))
        ? crate::syntax::lexer::chars::after_first(marks_p0)
        : marks_p0;
}


/// RefMark: fn Text -> Text
Text ref_mark(const Text& marks_p0) {
    return crate::syntax::lexer::chars::has_prefix(marks_p0, Text::lit("&"))
        ? Text::lit("&")
        : Text::lit("");
}


/// Unpend: fn Env -> Env
crate::check::expr::Env unpend(const crate::check::expr::Env& env_p0) {
    crate::check::expr::Env this_ = env_p0;
    this_.pending = Array<Text>{};
    return this_;
}


/// IsTopicName: fn Text -> Bool
bool is_topic_name(const Text& n_p0) {
    return (n_p0 == Text::lit("_")) || (crate::syntax::lexer::chars::drop_prefix(n_p0, crate::check::types::unify::marks_of(n_p0)) == Text::lit("_"));
}


/// WantsAbove: unbounded fn St, Ty, Bool -> (([Nat], [((Nat, Text))], St))
std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St> wants_above(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1, const bool& lambda_p2) {
    auto vs_p3 = filter(crate::check::types::recording::free_vars(st_p0, t_p1), [&](const Nat& v_p7) { return prism_rtl::deref(crate::check::types::recording::info_of(st_p0, v_p7)).level > st_p0.level; });
    auto mine_p4 = run_to_end(filter_job(st_p0.wants, ({
        auto st_p0_1 = st_p0;
        auto vs_p3_2 = vs_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1), vs_p3_2 = std::move(vs_p3_2)](crate::check::types::Want p0) {
        return ({
            auto st_p0_1_3 = st_p0_1;
            auto vs_p3_2_3 = vs_p3_2;
            entered(once_job([=, st_p0_1_3 = std::move(st_p0_1_3), vs_p3_2_3 = std::move(vs_p3_2_3)]() {
            return ({
                auto w_p8 = p0;
                call_then(crate::check::types::recording::start_walk(st_p0_1_3, prism_rtl::deref(w_p8).ty), [=](crate::check::types::Ty walk_8433) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_8433) ? ({
                    auto&& n_p9 = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_8433).a0;
                    prism_rtl::finished(crate::check::types::has_nat(vs_p3_2_3, n_p9));
                })
                    : prism_rtl::finished(false);
                });
            });
            });
        }));
        });
    })));
    })));
    auto others_p5 = filter(st_p0.wants, [&](const crate::check::types::Want& w_pa) { return !crate::check::types::has_text(each(mine_p4, [&](const crate::check::types::Want& m_pb) { return show_text(m_pb); }), show_text(w_pa)); });
    auto constrained_p6 = run_to_end(fold_job(mine_p4, Array<Nat>{}, ({
        auto st_p0_1 = st_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Want>)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](std::tuple<Array<Nat>, crate::check::types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_p0_1_2 = st_p0_1;
            entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
            return ({
                auto acc_pc = p0;
                auto w_pd = p1;
                call_then(crate::check::types::recording::start_walk(st_p0_1_2, prism_rtl::deref(w_pd).ty), [=, acc_pc = std::move(acc_pc)](crate::check::types::Ty walk_8647) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_8647) ? ({
                    auto&& n_pe = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_8647).a0;
                    prism_rtl::finished(crate::check::types::add_nat(acc_pc, n_pe));
                })
                    : prism_rtl::finished(acc_pc);
                });
            });
            });
        }));
        });
    })));
    })));
    return lambda_p2
        ? ({
        auto bounds_pf = run_to_end(fold_job(mine_p4, Array<std::tuple<Nat, Text>>{}, ({
            auto st_p0_1 = st_p0;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Nat, Text>>>(std::tuple<Array<std::tuple<Nat, Text>>, crate::check::types::Want>)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](std::tuple<Array<std::tuple<Nat, Text>>, crate::check::types::Want> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto acc_pi = p0;
                    auto w_pj = p1;
                    call_then(crate::check::types::recording::start_walk(st_p0_1_2, prism_rtl::deref(w_pj).ty), [=, acc_pi = std::move(acc_pi)](crate::check::types::Ty walk_8786) {
                    return ({
                        prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_8786) ? ({
                        auto&& n_pk = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_8786).a0;
                        crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(w_pj).cls, Text::lit("Range "))
                        ? prism_rtl::finished(acc_pi)
                        : prism_rtl::finished(crate::prelude::push(acc_pi, std::tuple{n_pk, prism_rtl::deref(w_pj).cls}));
                    })
                        : prism_rtl::finished(acc_pi);
                    });
                });
                });
            }));
            });
        }));
        })));
        auto st1_pg = fold(mine_p4, st_p0, [&](const crate::check::types::St& s_pl, const crate::check::types::Want& w_pm) { return crate::check::types::recording::note_choice(crate::check::types::recording::note_impl(s_pl, w_pm->file, prism_rtl::deref(w_pm).span, prism_rtl::deref(w_pm).cls, prism_rtl::deref(w_pm).ty, Text::lit("quantified")), w_pm->file, prism_rtl::deref(w_pm).span, prism_rtl::deref(w_pm).cls, Text::lit("any")); });
        auto st2_ph = ({
            crate::check::types::St this_ = st1_pg;
            this_.wants = others_p5;
            (std::move(this_));
        });
        std::tuple{Array<Nat>{}, bounds_pf, st2_ph};
    })
        : ({
        auto st2_pn = crate::check::types::unify::lower_levels(st_p0, constrained_p6, st_p0.level);
        std::tuple{constrained_p6, Array<std::tuple<Nat, Text>>{}, st2_pn};
    });
}


prism_rtl::Turn<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St>> WantsAbove::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    const auto& lambda_p2 = this->lambda_p2;
    auto lambda_p2_1 = prism_rtl::deref(lambda_p2);
    auto st_p0_2 = st_p0;
    auto t_p1_3 = t_p1;
    return call_then(crate::check::types::recording::start_free_vars(st_p0_2, t_p1_3), [=](Array<Nat> free_vars_8336) {
        return ({
            auto vs_p3 = filter(free_vars_8336, [&](const Nat& v_p7) { return prism_rtl::deref(crate::check::types::recording::info_of(st_p0_2, v_p7)).level > prism_rtl::deref(st_p0_2).level; });
            call_value(filter_job(prism_rtl::deref(st_p0_2).wants, ({
            auto st_p0_2_4 = st_p0_2;
            auto vs_p3_4 = vs_p3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=, st_p0_2_4 = std::move(st_p0_2_4), vs_p3_4 = std::move(vs_p3_4)](crate::check::types::Want p0) {
            return ({
                auto st_p0_2_4_5 = st_p0_2_4;
                auto vs_p3_4_5 = vs_p3_4;
                entered(once_job([=, st_p0_2_4_5 = std::move(st_p0_2_4_5), vs_p3_4_5 = std::move(vs_p3_4_5)]() {
                return ({
                    auto w_p8 = p0;
                    call_then(crate::check::types::recording::start_walk(st_p0_2_4_5, prism_rtl::deref(w_p8).ty), [=](crate::check::types::Ty walk_8433) {
                    return ({
                        prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_8433) ? ({
                        auto&& n_p9 = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_8433).a0;
                        prism_rtl::finished(crate::check::types::has_nat(vs_p3_4_5, n_p9));
                    })
                        : prism_rtl::finished(false);
                    });
                });
                });
            }));
            });
        })));
        })), [=](Array<crate::check::types::Want> filter_8405) {
            return ({
                auto mine_p4 = filter_8405;
                auto others_p5 = filter(prism_rtl::deref(st_p0_2).wants, [&](const crate::check::types::Want& w_pa) { return !crate::check::types::has_text(each(mine_p4, [&](const crate::check::types::Want& m_pb) { return show_text(m_pb); }), show_text(w_pa)); });
                call_value(fold_job(mine_p4, Array<Nat>{}, ({
                auto st_p0_2_4 = st_p0_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Want>)>>(prism_rtl::rc([=, st_p0_2_4 = std::move(st_p0_2_4)](std::tuple<Array<Nat>, crate::check::types::Want> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto st_p0_2_4_4 = st_p0_2_4;
                    entered(once_job([=, st_p0_2_4_4 = std::move(st_p0_2_4_4)]() {
                    return ({
                        auto acc_pc = p0;
                        auto w_pd = p1;
                        call_then(crate::check::types::recording::start_walk(st_p0_2_4_4, prism_rtl::deref(w_pd).ty), [=, acc_pc = std::move(acc_pc)](crate::check::types::Ty walk_8647) {
                        return ({
                            prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_8647) ? ({
                            auto&& n_pe = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_8647).a0;
                            prism_rtl::finished(crate::check::types::add_nat(acc_pc, n_pe));
                        })
                            : prism_rtl::finished(acc_pc);
                        });
                    });
                    });
                }));
                });
            })));
            })), [=, others_p5 = std::move(others_p5)](Array<Nat> fold_8614) {
                return ({
                    auto constrained_p6 = fold_8614;
                    lambda_p2_1
                    ? call_value(fold_job(mine_p4, Array<std::tuple<Nat, Text>>{}, ({
                    auto st_p0_2_4 = st_p0_2;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Nat, Text>>>(std::tuple<Array<std::tuple<Nat, Text>>, crate::check::types::Want>)>>(prism_rtl::rc([=, st_p0_2_4 = std::move(st_p0_2_4)](std::tuple<Array<std::tuple<Nat, Text>>, crate::check::types::Want> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto st_p0_2_4_4 = st_p0_2_4;
                        entered(once_job([=, st_p0_2_4_4 = std::move(st_p0_2_4_4)]() {
                        return ({
                            auto acc_pi = p0;
                            auto w_pj = p1;
                            call_then(crate::check::types::recording::start_walk(st_p0_2_4_4, prism_rtl::deref(w_pj).ty), [=, acc_pi = std::move(acc_pi)](crate::check::types::Ty walk_8786) {
                            return ({
                                prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_8786) ? ({
                                auto&& n_pk = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_8786).a0;
                                crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(w_pj).cls, Text::lit("Range "))
                                ? prism_rtl::finished(acc_pi)
                                : prism_rtl::finished(crate::prelude::push(acc_pi, std::tuple{n_pk, prism_rtl::deref(w_pj).cls}));
                            })
                                : prism_rtl::finished(acc_pi);
                            });
                        });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Nat, Text>> fold_8753) {
                    return ({
                        auto bounds_pf = fold_8753;
                        auto st1_pg = fold(mine_p4, st_p0_2, [&](const crate::check::types::St& s_pl, const crate::check::types::Want& w_pm) { return crate::check::types::recording::note_choice(crate::check::types::recording::note_impl(s_pl, w_pm->file, prism_rtl::deref(w_pm).span, prism_rtl::deref(w_pm).cls, prism_rtl::deref(w_pm).ty, Text::lit("quantified")), w_pm->file, prism_rtl::deref(w_pm).span, prism_rtl::deref(w_pm).cls, Text::lit("any")); });
                        auto st2_ph = ({
                            crate::check::types::St this_ = st1_pg;
                            this_.wants = others_p5;
                            (std::move(this_));
                        });
                        (prism_rtl::finished(std::tuple{Array<Nat>{}, bounds_pf, st2_ph}));
                    });
                })
                    : ({
                    auto st2_pn = crate::check::types::unify::lower_levels(st_p0_2, constrained_p6, prism_rtl::deref(st_p0_2).level);
                    (prism_rtl::finished(std::tuple{constrained_p6, Array<std::tuple<Nat, Text>>{}, st2_pn}));
                });
                });
            });
            });
        });
        });
    });
}


/// `Start WantsAbove, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St>> start_wants_above(crate::check::types::St st_p0, crate::check::types::Ty t_p1, bool lambda_p2) {
    return prism_rtl::make_rc<WantsAbove>(st_p0, t_p1, lambda_p2);
}


/// CheckLocalFn: unbounded fn Env, St, FnClause, Range -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> check_local_fn(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::decls::FnClause& f_p2, const crate::syntax::Range& span_p3) {
    auto name_p4 = crate::check::env::def_name_text(f_p2.name);
    auto&& _m = crate::prelude::get(env_p0.locals, name_p4);
    if (prism_rtl::is_some(_m)) {
        auto&& sc_p5 = prism_rtl::some_of(_m);
        return ((len(prism_rtl::deref(sc_p5).qs) > Nat(0u)) || (len(prism_rtl::deref(sc_p5).cqs) > Nat(0u))) || (!crate::check::types::is_flex_var(st_p1, prism_rtl::deref(sc_p5).ty))
            ? ({
            auto st2_p6 = check_clauses(env_p0, st_p1, name_p4, Array(std::vector{f_p2}), sc_p5, span_p3);
            std::tuple{env_p0, st2_p6};
        })
            : ({
            auto st0_p7 = crate::check::types::schemes::enter_level(st_p1);
            auto [lt_pc, st1_pd] = clause_lambda(env_p0, st0_p7, f_p2);
            auto st2_p8 = crate::check::types::unify::unify(st1_pd, prism_rtl::deref(sc_p5).ty, lt_pc, span_p3);
            auto st3_p9 = crate::check::env::traits::solve_wants(env_p0.g, st2_p8, env_p0.givens, false);
            auto st4_pa = crate::check::types::schemes::leave_level(st3_p9);
            auto t_pb = crate::check::types::recording::zonk(st4_pa, prism_rtl::deref(sc_p5).ty);
            (crate::check::types::schemes::holds_node(st4_pa, t_pb)
            ? std::tuple{env_p0, st4_pa}
            : ({
            auto [keep_pe, bounds_pf, st5_pg] = wants_above(st4_pa, t_pb, true);
            auto [sc2_ph, st6_pi] = crate::check::types::schemes::generalize(st5_pg, t_pb, keep_pe, bounds_pf);
            std::tuple{crate::check::expr::with_local(env_p0, name_p4, sc2_ph), st6_pi};
        }));
        });
    }
    if (prism_rtl::is_none(_m)) {
        return std::tuple{env_p0, st_p1};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> CheckLocalFn::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& f_p2 = this->f_p2;
    const auto& span_p3 = this->span_p3;
    auto name_p4 = crate::check::env::def_name_text(prism_rtl::deref(f_p2).name);
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0).locals, name_p4);
        prism_rtl::is_some(_m) ? ({
        auto&& sc_p5 = prism_rtl::some_of(_m);
        ((len(prism_rtl::deref(sc_p5).qs) > Nat(0u)) || (len(prism_rtl::deref(sc_p5).cqs) > Nat(0u))) || (!crate::check::types::is_flex_var(st_p1, prism_rtl::deref(sc_p5).ty))
        ? ({
        auto env_p0_1 = env_p0;
        auto f_p2_2 = f_p2;
        auto span_p3_3 = span_p3;
        auto st_p1_4 = st_p1;
        call_then(start_check_clauses(env_p0_1, st_p1_4, name_p4, Array(std::vector{f_p2_2}), sc_p5, span_p3_3), [=](crate::check::types::St check_clauses_9674) {
        return ({
            auto st2_p6 = check_clauses_9674;
            (prism_rtl::finished(std::tuple{env_p0_1, st2_p6}));
        });
    });
    })
        : ({
        auto st0_p7 = crate::check::types::schemes::enter_level(st_p1);
        auto env_p0_1 = env_p0;
        auto f_p2_2 = f_p2;
        auto span_p3_3 = span_p3;
        call_then(start_clause_lambda(env_p0_1, st0_p7, f_p2_2), [=, span_p3_3 = std::move(span_p3_3)](std::tuple<crate::check::types::Ty, crate::check::types::St> clause_lambda_9839) {
        return ({
            auto [lt_pc, st1_pd] = clause_lambda_9839;
            call_then(crate::check::types::unify::start_unify(st1_pd, prism_rtl::deref(sc_p5).ty, lt_pc, span_p3_3), [=](crate::check::types::St unify_9890) {
            return ({
                auto st2_p8 = unify_9890;
                call_then(crate::check::env::traits::start_solve_wants(prism_rtl::deref(env_p0_1).g, st2_p8, prism_rtl::deref(env_p0_1).givens, false), [=](crate::check::types::St solve_wants_9943) {
                return ({
                    auto st3_p9 = solve_wants_9943;
                    auto st4_pa = crate::check::types::schemes::leave_level(st3_p9);
                    call_then(crate::check::types::recording::start_zonk(st4_pa, prism_rtl::deref(sc_p5).ty), [=](crate::check::types::Ty zonk_10049) {
                    return ({
                        auto t_pb = zonk_10049;
                        call_then(crate::check::types::schemes::start_holds_node(st4_pa, t_pb), [=](bool holds_node_10084) {
                        return holds_node_10084
                            ? prism_rtl::finished(std::tuple{env_p0_1, st4_pa})
                            : call_then(start_wants_above(st4_pa, t_pb, true), [=](std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St> wants_above_10185) {
                            return ({
                                auto [keep_pe, bounds_pf, st5_pg] = wants_above_10185;
                                call_then(crate::check::types::schemes::start_generalize(st5_pg, t_pb, keep_pe, bounds_pf), [=](std::tuple<crate::check::types::Scheme, crate::check::types::St> generalize_10248) {
                                return ({
                                    auto [sc2_ph, st6_pi] = generalize_10248;
                                    (prism_rtl::finished(std::tuple{crate::check::expr::with_local(env_p0_1, name_p4, sc2_ph), st6_pi}));
                                });
                            });
                            });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{env_p0, st_p1})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CheckLocalFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_check_local_fn(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::decls::FnClause f_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<CheckLocalFn>(env_p0, st_p1, f_p2, span_p3);
}


/// ClauseLambda: unbounded fn Env, St, FnClause -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> clause_lambda(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::decls::FnClause& f_p2) {
    auto body_p3 = ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::LambdaBody> _v;
        auto&& _m = f_p2.body;
        if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(_m)) {
            auto&& e_p4 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(_m).a0;
            _v.set(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(e_p4)}));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m)) {
            auto&& b_p5 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
            _v.set(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbBlock{b_p5}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::check::expr::calls::infer_lambda(env_p0, st_p1, crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELambda{std::optional(f_p2.params), prism_rtl::rc(body_p3)})), .span = f_p2.span}, std::optional<crate::check::types::Ty>{});
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> ClauseLambda::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& f_p2 = this->f_p2;
    auto body_p3 = ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::LambdaBody> _v;
        auto&& _m = prism_rtl::deref(f_p2).body;
        if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(_m)) {
            auto&& e_p4 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(_m).a0;
            _v.set(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(e_p4)}));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m)) {
            auto&& b_p5 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
            _v.set(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbBlock{b_p5}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::InferLambda(env_p0, st_p1, crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELambda{std::optional(prism_rtl::deref(f_p2).params), prism_rtl::rc(body_p3)})), .span = prism_rtl::deref(f_p2).span}, std::optional<crate::check::types::Ty>{})));
}


/// `Start ClauseLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_clause_lambda(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::decls::FnClause f_p2) {
    return prism_rtl::make_rc<ClauseLambda>(env_p0, st_p1, f_p2);
}


/// CheckClauses: unbounded fn Env, St, Text, [FnClause], Scheme, Range -> St
crate::check::types::St check_clauses(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& name_p2, const Array<crate::syntax::decls::FnClause>& clauses_p3, const crate::check::types::Scheme& sc_p4, const crate::syntax::Range& span_p5) {
    auto t_p6 = crate::check::types::schemes::skolemize(sc_p4);
    auto givens_p7 = append(env_p0.givens, sc_p4.bounds);
    auto env2_p8 = ({
        crate::check::expr::Env this_ = env_p0;
        this_.givens = givens_p7;
        this_.mark = crate::syntax::lexer::chars::head(crate::check::types::unify::marks_of(name_p2));
        this_.def_name = name_p2;
        (std::move(this_));
    });
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p6)) {
        auto&& col_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p6).a0;
        auto&& params_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p6).a1;
        auto&& res_pb = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p6).a2;
        auto outer_color_pc = st_p1.color;
        auto outer_flex_pd = st_p1.color_flex;
        auto st0_pe = ({
            crate::check::types::St this_ = st_p1;
            this_.color = crate::check::types::Col(crate::check::types::Col::CBound{});
            this_.color_why = Text::lit("");
            this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
            this_.col_up = fold(sc_p4.cjoins, this_.col_up, [&](const Map<Text, Text>& m_pk, const std::tuple<Text, Text>& _p1) {
                auto&& lo_pl = std::get<0>(_p1);
                auto&& hi_pm = std::get<1>(_p1);
                return insert(m_pk, lo_pl, hi_pm);
            });
            (std::move(this_));
        });
        auto st1_pf = run_to_end(fold_job(clauses_p3, st0_pe, ({
            auto env2_p8_1 = env2_p8;
            auto params_pa_2 = params_pa;
            auto res_pb_3 = prism_rtl::deref(prism_rtl::deref(res_pb));
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, env2_p8_1 = std::move(env2_p8_1), params_pa_2 = std::move(params_pa_2), res_pb_3 = std::move(res_pb_3)](std::tuple<crate::check::types::St, crate::syntax::decls::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env2_p8_1_4 = env2_p8_1;
                auto params_pa_2_4 = params_pa_2;
                auto res_pb_3_4 = res_pb_3;
                entered(once_job([=, env2_p8_1_4 = std::move(env2_p8_1_4), params_pa_2_4 = std::move(params_pa_2_4), res_pb_3_4 = std::move(res_pb_3_4)]() {
                return ({
                    auto s_pn = p0;
                    auto c_po = p1;
                    (prism_rtl::more(prism_rtl::rc(CheckClause(env2_p8_1_4, s_pn, c_po, params_pa_2_4, res_pb_3_4))));
                });
            }));
            });
        })));
        })));
        auto st1b_pg = crate::check::types::colors::settle_body(crate::check::env::traits::solve_wants(env_p0.g, st1_pf, givens_p7, false), col_p9, name_p2);
        auto st2_ph = crate::check::passes::clause_coverage(env2_p8, st1b_pg, clauses_p3, params_pa, span_p5);
        auto st3_pi = crate::check::types::colors::col_leq(prism_rtl::deref(st2_ph).color, col_p9)
            ? st2_ph
            : crate::check::types::recording::err_fix(st2_ph, Text::lit("calls-unbounded"), span_p5, prism_rtl::cat(crate::check::types::colors::col_word(col_p9), " `", name_p2, "` calls ", crate::check::types::colors::col_word(prism_rtl::deref(st2_ph).color), " `", prism_rtl::deref(st2_ph).color_why, "`"), prism_rtl::cat("mark `", name_p2, "` `unbounded fn`, or run the call through `@Run`"));
        auto st4_pj = crate::check::types::recording::note_fn(st3_pi, span_p5, name_p2, col_p9, prism_rtl::deref(st2_ph).color);
        crate::check::types::St this_ = st4_pj;
        this_.color = outer_color_pc;
        this_.color_flex = outer_flex_pd;
        return this_;
    }
    {
        auto&& other_pp = t_p6;
        auto st1_pq = run_to_end(fold_job(clauses_p3, st_p1, ({
            auto env2_p8_1 = env2_p8;
            auto other_pp_2 = other_pp;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, env2_p8_1 = std::move(env2_p8_1), other_pp_2 = std::move(other_pp_2)](std::tuple<crate::check::types::St, crate::syntax::decls::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env2_p8_1_3 = env2_p8_1;
                auto other_pp_2_3 = other_pp_2;
                entered(once_job([=, env2_p8_1_3 = std::move(env2_p8_1_3), other_pp_2_3 = std::move(other_pp_2_3)]() {
                return ({
                    auto s_pr = p0;
                    auto c_ps = p1;
                    (prism_rtl::more(prism_rtl::rc(CheckClause(env2_p8_1_3, s_pr, c_ps, Array<crate::check::types::Ty>{}, other_pp_2_3))));
                });
            }));
            });
        })));
        })));
        return st1_pq;
    }
}


prism_rtl::Turn<crate::check::types::St> CheckClauses::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& name_p2 = this->name_p2;
    const auto& clauses_p3 = this->clauses_p3;
    const auto& sc_p4 = this->sc_p4;
    const auto& span_p5 = this->span_p5;
    auto clauses_p3_1 = clauses_p3;
    auto env_p0_2 = env_p0;
    auto name_p2_3 = name_p2;
    auto sc_p4_4 = sc_p4;
    auto span_p5_5 = span_p5;
    auto st_p1_6 = st_p1;
    return call_then(crate::check::types::schemes::start_skolemize(sc_p4_4), [=](crate::check::types::Ty skolemize_11216) {
        return ({
            auto t_p6 = skolemize_11216;
            auto givens_p7 = append(prism_rtl::deref(env_p0_2).givens, prism_rtl::deref(sc_p4_4).bounds);
            auto env2_p8 = ({
                crate::check::expr::Env this_ = env_p0_2;
                this_.givens = givens_p7;
                this_.mark = crate::syntax::lexer::chars::head(crate::check::types::unify::marks_of(name_p2_3));
                this_.def_name = name_p2_3;
                (std::move(this_));
            });
            ({
            prism_rtl::is<crate::check::types::Ty::TyFn>(t_p6) ? ({
            auto&& col_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p6).a0;
            auto&& params_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p6).a1;
            auto&& res_pb = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p6).a2;
            ({
            auto outer_color_pc = prism_rtl::deref(st_p1_6).color;
            auto outer_flex_pd = prism_rtl::deref(st_p1_6).color_flex;
            auto st0_pe = ({
                crate::check::types::St this_ = st_p1_6;
                this_.color = crate::check::types::Col(crate::check::types::Col::CBound{});
                this_.color_why = Text::lit("");
                this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
                this_.col_up = fold(prism_rtl::deref(sc_p4_4).cjoins, this_.col_up, [&](const Map<Text, Text>& m_pk, const std::tuple<Text, Text>& _p1) {
                    auto&& lo_pl = std::get<0>(_p1);
                    auto&& hi_pm = std::get<1>(_p1);
                    return insert(m_pk, lo_pl, hi_pm);
                });
                (std::move(this_));
            });
            auto col_p9_7 = col_p9;
            auto params_pa_8 = params_pa;
            auto res_pb_9 = prism_rtl::deref(prism_rtl::deref(res_pb));
            call_value(fold_job(clauses_p3_1, st0_pe, ({
            auto env2_p8_10 = env2_p8;
            auto params_pa_8_11 = params_pa_8;
            auto res_pb_9_11 = res_pb_9;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, env2_p8_10 = std::move(env2_p8_10), params_pa_8_11 = std::move(params_pa_8_11), res_pb_9_11 = std::move(res_pb_9_11)](std::tuple<crate::check::types::St, crate::syntax::decls::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env2_p8_10_11 = env2_p8_10;
                auto params_pa_8_11_11 = params_pa_8_11;
                auto res_pb_9_11_11 = res_pb_9_11;
                entered(once_job([=, env2_p8_10_11 = std::move(env2_p8_10_11), params_pa_8_11_11 = std::move(params_pa_8_11_11), res_pb_9_11_11 = std::move(res_pb_9_11_11)]() {
                return ({
                    auto s_pn = p0;
                    auto c_po = p1;
                    (prism_rtl::more(prism_rtl::rc(CheckClause(env2_p8_10_11, s_pn, c_po, params_pa_8_11_11, res_pb_9_11_11))));
                });
            }));
            });
        })));
        })), [=, outer_color_pc = std::move(outer_color_pc), outer_flex_pd = std::move(outer_flex_pd), col_p9_7 = std::move(col_p9_7)](crate::check::types::St fold_11768) {
            return ({
                auto st1_pf = fold_11768;
                call_then(crate::check::env::traits::start_solve_wants(prism_rtl::deref(env_p0_2).g, st1_pf, givens_p7, false), [=](crate::check::types::St solve_wants_11866) {
                return call_then(crate::check::types::colors::start_settle_body(solve_wants_11866, col_p9_7, name_p2_3), [=](crate::check::types::St settle_body_11854) {
                    return ({
                        auto st1b_pg = settle_body_11854;
                        call_then(crate::check::passes::start_clause_coverage(env2_p8, st1b_pg, clauses_p3_1, params_pa_8, span_p5_5), [=](crate::check::types::St clause_coverage_11937) {
                        return ({
                            auto st2_ph = clause_coverage_11937;
                            auto st3_pi = crate::check::types::colors::col_leq(prism_rtl::deref(st2_ph).color, col_p9_7)
                                ? st2_ph
                                : crate::check::types::recording::err_fix(st2_ph, Text::lit("calls-unbounded"), span_p5_5, prism_rtl::cat(crate::check::types::colors::col_word(col_p9_7), " `", name_p2_3, "` calls ", crate::check::types::colors::col_word(prism_rtl::deref(st2_ph).color), " `", prism_rtl::deref(st2_ph).color_why, "`"), prism_rtl::cat("mark `", name_p2_3, "` `unbounded fn`, or run the call through `@Run`"));
                            auto st4_pj = crate::check::types::recording::note_fn(st3_pi, span_p5_5, name_p2_3, col_p9_7, prism_rtl::deref(st2_ph).color);
                            (prism_rtl::finished(({
                            crate::check::types::St this_ = st4_pj;
                            this_.color = outer_color_pc;
                            this_.color_flex = outer_flex_pd;
                            (std::move(this_));
                        })));
                        });
                    });
                    });
                });
            });
            });
        });
        });
        })
            : ({
            auto&& other_pp = t_p6;
            ({
            auto other_pp_7 = other_pp;
            call_value(fold_job(clauses_p3_1, st_p1_6, ({
            auto env2_p8_8 = env2_p8;
            auto other_pp_7_9 = other_pp_7;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, env2_p8_8 = std::move(env2_p8_8), other_pp_7_9 = std::move(other_pp_7_9)](std::tuple<crate::check::types::St, crate::syntax::decls::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env2_p8_8_9 = env2_p8_8;
                auto other_pp_7_9_9 = other_pp_7_9;
                entered(once_job([=, env2_p8_8_9 = std::move(env2_p8_8_9), other_pp_7_9_9 = std::move(other_pp_7_9_9)]() {
                return ({
                    auto s_pr = p0;
                    auto c_ps = p1;
                    (prism_rtl::more(prism_rtl::rc(CheckClause(env2_p8_8_9, s_pr, c_ps, Array<crate::check::types::Ty>{}, other_pp_7_9_9))));
                });
            }));
            });
        })));
        })), [=](crate::check::types::St fold_12432) {
            return ({
                auto st1_pq = fold_12432;
                (prism_rtl::finished(st1_pq));
            });
        });
        });
        });
        });
        });
    });
}


/// `Start CheckClauses, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_clauses(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text name_p2, Array<crate::syntax::decls::FnClause> clauses_p3, crate::check::types::Scheme sc_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<CheckClauses>(env_p0, st_p1, name_p2, clauses_p3, sc_p4, span_p5);
}


/// CheckClause: unbounded fn Env, St, FnClause, [Ty], Ty -> St
crate::check::types::St check_clause(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::decls::FnClause& c_p2, const Array<crate::check::types::Ty>& params_p3, const crate::check::types::Ty& res_p4) {
    return len(c_p2.params) != len(params_p3)
        ? crate::check::types::recording::err(st_p1, Text::lit("mismatch"), c_p2.span, prism_rtl::cat("this clause takes ", crate::check::errors::count_word(len(c_p2.params)), " parameter", len(c_p2.params) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; the signature has ", crate::check::errors::count_word(len(params_p3))))
        : ({
        auto [env2_p8, st1_p9] = run_to_end(fold_job(crate::check::errors::range0(len(params_p3)), std::tuple{env_p0, st_p1}, ({
            auto c_p2_1 = c_p2;
            auto params_p3_2 = params_p3;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, c_p2_1 = std::move(c_p2_1), params_p3_2 = std::move(params_p3_2)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto c_p2_1_3 = c_p2_1;
                auto params_p3_2_3 = params_p3_2;
                entered(once_job([=, c_p2_1_3 = std::move(c_p2_1_3), params_p3_2_3 = std::move(params_p3_2_3)]() {
                return ({
                    auto [en_p5, s_p6] = p0;
                    auto i_p7 = p1;
                    (prism_rtl::more(prism_rtl::rc(crate::check::expr::patterns::BindPattern(en_p5, s_p6, or_(index(c_p2_1_3.params, i_p7), crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = c_p2_1_3.span}), or_(index(params_p3_2_3, i_p7), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), true))));
                });
            }));
            });
        }));
        })));
        check_body(env2_p8, st1_p9, c_p2.body, res_p4);
    });
}


prism_rtl::Turn<crate::check::types::St> CheckClause::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& c_p2 = this->c_p2;
    const auto& params_p3 = this->params_p3;
    const auto& res_p4 = this->res_p4;
    return len(prism_rtl::deref(c_p2).params) != len(params_p3)
        ? prism_rtl::finished(crate::check::types::recording::err(st_p1, Text::lit("mismatch"), prism_rtl::deref(c_p2).span, prism_rtl::cat("this clause takes ", crate::check::errors::count_word(len(prism_rtl::deref(c_p2).params)), " parameter", len(prism_rtl::deref(c_p2).params) == Nat(1u)
        ? Text::lit("")
        : Text::lit("s"), "; the signature has ", crate::check::errors::count_word(len(params_p3)))))
        : ({
        auto c_p2_1 = c_p2;
        auto env_p0_2 = env_p0;
        auto params_p3_3 = params_p3;
        auto res_p4_4 = res_p4;
        auto st_p1_5 = st_p1;
        call_value(fold_job(crate::check::errors::range0(len(params_p3_3)), std::tuple{env_p0_2, st_p1_5}, ({
        auto c_p2_1_6 = c_p2_1;
        auto params_p3_3_6 = params_p3_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, c_p2_1_6 = std::move(c_p2_1_6), params_p3_3_6 = std::move(params_p3_3_6)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto c_p2_1_6_6 = c_p2_1_6;
            auto params_p3_3_6_6 = params_p3_3_6;
            entered(once_job([=, c_p2_1_6_6 = std::move(c_p2_1_6_6), params_p3_3_6_6 = std::move(params_p3_3_6_6)]() {
            return ({
                auto [en_p5, s_p6] = p0;
                auto i_p7 = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::expr::patterns::BindPattern(en_p5, s_p6, or_(index(prism_rtl::deref(c_p2_1_6_6).params, i_p7), crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = prism_rtl::deref(c_p2_1_6_6).span}), or_(index(params_p3_3_6_6, i_p7), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), true))));
            });
        }));
        });
    }));
    })), [=, res_p4_4 = std::move(res_p4_4)](std::tuple<crate::check::expr::Env, crate::check::types::St> fold_12863) {
        return ({
            auto [env2_p8, st1_p9] = fold_12863;
            (prism_rtl::more(prism_rtl::rc(CheckBody(env2_p8, st1_p9, prism_rtl::deref(c_p2_1).body, res_p4_4))));
        });
    });
    });
}


/// `Start CheckClause, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_clause(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::decls::FnClause c_p2, Array<crate::check::types::Ty> params_p3, crate::check::types::Ty res_p4) {
    return prism_rtl::make_rc<CheckClause>(env_p0, st_p1, c_p2, params_p3, res_p4);
}


/// CheckBody: unbounded fn Env, St, FnBody, Ty -> St
crate::check::types::St check_body(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::decls::FnBody& body_p2, const crate::check::types::Ty& res_p3) {
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(body_p2)) {
        auto&& e_p4 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(body_p2).a0;
        return crate::check::expr::check(env_p0, st_p1, e_p4, res_p3);
    }
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(body_p2)) {
        auto&& b_p5 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(body_p2).a0;
        return env_p0.mark == Text::lit("@")
            ? ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            auto&& _m = crate::check::types::recording::walk(st_p1, res_p3);
            if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
                auto&& inner_p6 = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
                auto&& rw_p7 = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a1;
                _v.set(({
                    auto env2_p8 = ({
                        crate::check::expr::Env this_ = env_p0;
                        this_.scope = rw_p7;
                        (std::move(this_));
                    });
                    auto [t_p9, st2_pa] = crate::check::blocks::infer_widget_block(env2_p8, st_p1, b_p5);
                    (crate::check::types::unify::unify(st2_pa, prism_rtl::deref(inner_p6), t_p9, prism_rtl::deref(b_p5).span));
                }));
                goto _done;
            }
            {
                auto&& other_pb = _m;
                _v.set(crate::check::types::recording::err(st_p1, Text::lit("mismatch"), prism_rtl::deref(b_p5).span, prism_rtl::cat("a widget block builds a blueprint; the signature says `", crate::check::types::show_ty(st_p1, other_pb), "`")));
                goto _done;
            }
        _done:
            _v.take();
        })
            : (env_p0.mark == Text::lit("?")) || (env_p0.mark == Text::lit("~"))
            ? ({
            auto [t_pc, st2_pd] = crate::check::blocks::structure::infer_given_block(env_p0, st_p1, b_p5, env_p0.mark);
            (crate::check::types::unify::unify(st2_pd, res_p3, t_pc, prism_rtl::deref(b_p5).span));
        })
            : ({
            auto [t_pe, st2_pf] = infer_expr_block(env_p0, st_p1, b_p5);
            (crate::check::types::unify::unify(st2_pf, res_p3, t_pe, prism_rtl::deref(b_p5).span));
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> CheckBody::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& body_p2 = this->body_p2;
    const auto& res_p3 = this->res_p3;
    return ({
        prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(body_p2) ? ({
        auto&& e_p4 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(body_p2).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env_p0, st_p1, e_p4, res_p3)));
    })
        : prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(body_p2) ? ({
        auto&& b_p5 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(body_p2).a0;
        prism_rtl::deref(env_p0).mark == Text::lit("@")
        ? ({
        auto b_p5_1 = b_p5;
        auto env_p0_2 = env_p0;
        auto res_p3_3 = res_p3;
        auto st_p1_4 = st_p1;
        call_then(crate::check::types::recording::start_walk(st_p1_4, res_p3_3), [=, b_p5_1 = std::move(b_p5_1), env_p0_2 = std::move(env_p0_2)](crate::check::types::Ty walk_13433) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyAt>(walk_13433) ? ({
            auto&& inner_p6 = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_13433).a0;
            auto&& rw_p7 = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_13433).a1;
            ({
            auto env2_p8 = ({
                crate::check::expr::Env this_ = env_p0_2;
                this_.scope = rw_p7;
                (std::move(this_));
            });
            call_then(crate::check::blocks::start_infer_widget_block(env2_p8, st_p1_4, b_p5_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block_13598) {
            return ({
                auto [t_p9, st2_pa] = infer_widget_block_13598;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st2_pa, prism_rtl::deref(inner_p6), t_p9, prism_rtl::deref(b_p5_1).span))));
            });
        });
        });
        })
            : ({
            auto&& other_pb = walk_13433;
            call_then(crate::check::types::start_show_ty(st_p1_4, other_pb), [=](Text show_ty_13783) { return prism_rtl::finished(crate::check::types::recording::err(st_p1_4, Text::lit("mismatch"), prism_rtl::deref(b_p5_1).span, prism_rtl::cat("a widget block builds a blueprint; the signature says `", show_ty_13783, "`"))); });
        });
        });
    });
    })
        : (prism_rtl::deref(env_p0).mark == Text::lit("?")) || (prism_rtl::deref(env_p0).mark == Text::lit("~"))
        ? ({
        auto b_p5_1 = b_p5;
        auto env_p0_2 = env_p0;
        auto res_p3_3 = res_p3;
        auto st_p1_4 = st_p1;
        call_then(crate::check::blocks::structure::start_infer_given_block(env_p0_2, st_p1_4, b_p5_1, prism_rtl::deref(env_p0_2).mark), [=, res_p3_3 = std::move(res_p3_3)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_given_block_13885) {
        return ({
            auto [t_pc, st2_pd] = infer_given_block_13885;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st2_pd, res_p3_3, t_pc, prism_rtl::deref(b_p5_1).span))));
        });
    });
    })
        : ({
        auto b_p5_1 = b_p5;
        auto env_p0_2 = env_p0;
        auto res_p3_3 = res_p3;
        auto st_p1_4 = st_p1;
        call_then(start_infer_expr_block(env_p0_2, st_p1_4, b_p5_1), [=, res_p3_3 = std::move(res_p3_3)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_14003) {
        return ({
            auto [t_pe, st2_pf] = infer_expr_block_14003;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st2_pf, res_p3_3, t_pe, prism_rtl::deref(b_p5_1).span))));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CheckBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_body(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::decls::FnBody body_p2, crate::check::types::Ty res_p3) {
    return prism_rtl::make_rc<CheckBody>(env_p0, st_p1, body_p2, res_p3);
}


/// InferTemplate: unbounded fn Env, St, Template -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_template(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Template& t_p2) {
    auto st2_p3 = run_to_end(fold_job(t_p2.parts, st_p1, ({
        auto env_p0_1 = env_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1)](std::tuple<crate::check::types::St, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0_1_2 = env_p0_1;
            entered(once_job([=, env_p0_1_2 = std::move(env_p0_1_2)]() {
            return ({
                auto s_p4 = p0;
                auto part_p5 = p1;
                (prism_rtl::more(prism_rtl::rc(TemplatePartCheck(env_p0_1_2, s_p4, part_p5))));
            });
        }));
        });
    })));
    })));
    return std::tuple{crate::check::types::t_text(), st2_p3};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferTemplate::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    auto env_p0_1 = env_p0;
    auto st_p1_2 = st_p1;
    auto t_p2_3 = t_p2;
    return call_value(fold_job(prism_rtl::deref(t_p2_3).parts, st_p1_2, ({
        auto env_p0_1_4 = env_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=, env_p0_1_4 = std::move(env_p0_1_4)](std::tuple<crate::check::types::St, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0_1_4_4 = env_p0_1_4;
            entered(once_job([=, env_p0_1_4_4 = std::move(env_p0_1_4_4)]() {
            return ({
                auto s_p4 = p0;
                auto part_p5 = p1;
                (prism_rtl::more(prism_rtl::rc(TemplatePartCheck(env_p0_1_4_4, s_p4, part_p5))));
            });
        }));
        });
    })));
    })), [=](crate::check::types::St fold_14441) {
        return ({
            auto st2_p3 = fold_14441;
            (prism_rtl::finished(std::tuple{crate::check::types::t_text(), st2_p3}));
        });
    });
}


/// `Start InferTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_template(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Template t_p2) {
    return prism_rtl::make_rc<InferTemplate>(env_p0, st_p1, t_p2);
}


/// TemplatePartCheck: unbounded fn Env, St, TemplatePart -> St
crate::check::types::St template_part_check(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::TemplatePart& part_p2) {
    if (prism_rtl::is<crate::syntax::TemplatePart::TpText>(part_p2)) {
        return st_p1;
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(part_p2)) {
        auto&& x_p3 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part_p2).a0;
        auto [t_p4, st2_p5] = crate::check::expr::infer(env_p0, st_p1, x_p3);
        return crate::check::expr::show_want(st2_p5, crate::check::expr::is_time_sigil(crate::check::types::head_sigil(st2_p5, t_p4))
            ? crate::check::expr::inner_of(st2_p5, t_p4)
            : t_p4, prism_rtl::deref(x_p3).span);
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(part_p2)) {
        auto&& b_p6 = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(part_p2).a0;
        auto [t_p7, st2_p8] = infer_expr_block(env_p0, st_p1, b_p6);
        return st2_p8;
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpCall>(part_p2)) {
        auto&& n_p9 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a0;
        auto&& args_pa = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a1;
        auto&& parts_ob = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a2;
        auto&& span_pc = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a3;
        return template_call_check(env_p0, st_p1, n_p9, args_pa, parts_ob, span_pc);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> TemplatePartCheck::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& part_p2 = this->part_p2;
    return ({
        prism_rtl::is<crate::syntax::TemplatePart::TpText>(part_p2) ? prism_rtl::finished(st_p1)
        : prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(part_p2) ? ({
        auto&& x_p3 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part_p2).a0;
        ({
        auto env_p0_1 = env_p0;
        auto st_p1_2 = st_p1;
        auto x_p3_3 = x_p3;
        call_then(crate::check::expr::start_infer(env_p0_1, st_p1_2, x_p3_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_14706) {
        return ({
            auto [t_p4, st2_p5] = infer_14706;
            call_then(crate::check::types::start_head_sigil(st2_p5, t_p4), [=](Text head_sigil_14762) {
            return prism_rtl::more(prism_rtl::rc(crate::check::expr::ShowWant(st2_p5, crate::check::expr::is_time_sigil(head_sigil_14762)
                ? crate::check::expr::inner_of(st2_p5, t_p4)
                : t_p4, prism_rtl::deref(x_p3_3).span)));
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(part_p2) ? ({
        auto&& b_p6 = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(part_p2).a0;
        ({
        auto b_p6_1 = b_p6;
        auto env_p0_2 = env_p0;
        auto st_p1_3 = st_p1;
        call_then(start_infer_expr_block(env_p0_2, st_p1_3, b_p6_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_14853) {
        return ({
            auto [t_p7, st2_p8] = infer_expr_block_14853;
            (prism_rtl::finished(st2_p8));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TemplatePart::TpCall>(part_p2) ? ({
        auto&& n_p9 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a0;
        auto&& args_pa = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a1;
        auto&& parts_ob = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a2;
        auto&& span_pc = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a3;
        prism_rtl::more(prism_rtl::rc(TemplateCallCheck(env_p0, st_p1, n_p9, args_pa, parts_ob, span_pc)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplatePartCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_template_part_check(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::TemplatePart part_p2) {
    return prism_rtl::make_rc<TemplatePartCheck>(env_p0, st_p1, part_p2);
}


/// TemplateCallCheck: unbounded fn Env, St, SName, [Arg], ?[TemplatePart], Range -> St
crate::check::types::St template_call_check(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::SName& n_p2, const Array<crate::syntax::Arg>& args_p3, const std::optional<Array<crate::syntax::TemplatePart>>& parts_o4, const crate::syntax::Range& span_p5) {
    auto plain_p6 = crate::syntax::SName{.sigils = crate::syntax::lexer::chars::after_first(n_p2.sigils), .path_ = n_p2.path_, .span = n_p2.span};
    auto&& _qk1_o9 = crate::check::env::names::resolve_value(env_p0.g, env_p0.home, n_p2);
    auto&& qk1_o9 = std::get<0>(_qk1_o9);
    auto callee_p7 = qk1_o9 != std::optional<Text>{} ? n_p2 : plain_p6;
    auto [qk_oa, ignore2_pb] = crate::check::env::names::resolve_value(env_p0.g, env_p0.home, callee_p7);
    auto cname_p8 = crate::check::env::sname_key(plain_p6);
    if (prism_rtl::is_none(qk_oa)) {
        auto [ignore3_pc, st2_pd] = crate::check::expr::calls::call_global(env_p0, st_p1, callee_p7, Array<crate::syntax::Arg>{}, span_p5, Array<crate::check::types::Ty>{}, prism_rtl::deref(callee_p7).span);
        return st2_pd;
    }
    if (prism_rtl::is_some(qk_oa)) {
        auto&& qk_pe = prism_rtl::some_of(qk_oa);
        auto clauses_pf = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g).fn_at, qk_pe);
            if (prism_rtl::is_some(_m)) {
                auto&& i_ph = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
                    auto&& _m = index(prism_rtl::deref(env_p0.g).defs, i_ph);
                    if (prism_rtl::is_some(_m)) {
                        auto&& d_pi = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
                            auto&& _m = prism_rtl::deref(d_pi).body;
                            if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
                                auto&& cs_pj = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
                                _v.set(cs_pj);
                                goto _done;
                            }
                            {
                                _v.set(Array<crate::syntax::decls::FnClause>{});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<crate::syntax::decls::FnClause>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::syntax::decls::FnClause>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arity_pg = ({
            __label__ _done;
            prism_rtl::Slot<Nat> _v;
            auto&& _m = index(clauses_pf, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& c_pk = prism_rtl::some_of(_m);
                _v.set(len(prism_rtl::deref(c_pk).params));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Nat(0u));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return len(clauses_pf) == Nat(0u)
            ? crate::check::types::recording::err(st_p1, Text::lit("mismatch"), span_p5, prism_rtl::cat("`<@", cname_p8, ">` calls a function without clauses, which name no parameters for its attributes"))
            : ({
            auto [slots_pu, st1_pv] = run_to_end(fold_job(args_p3, std::tuple{Map<Text, crate::syntax::Expr>{}, st_p1}, ({
                auto clauses_pf_1 = clauses_pf;
                auto cname_p8_2 = cname_p8;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>, crate::syntax::Arg>)>>(prism_rtl::rc([=, clauses_pf_1 = std::move(clauses_pf_1), cname_p8_2 = std::move(cname_p8_2)](std::tuple<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>, crate::syntax::Arg> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto clauses_pf_1_3 = clauses_pf_1;
                    auto cname_p8_2_3 = cname_p8_2;
                    entered(once_job([=, clauses_pf_1_3 = std::move(clauses_pf_1_3), cname_p8_2_3 = std::move(cname_p8_2_3)]() {
                    return ({
                        auto [m_pp, s_pq] = p0;
                        auto a_pr = p1;
                        ({
                        auto&& _m = prism_rtl::deref(a_pr).name;
                        prism_rtl::is_some(_m) ? ({
                        auto&& id_ps = prism_rtl::some_of(_m);
                        ({
                        auto id_ps_3 = id_ps;
                        call_then(start_template_slot(clauses_pf_1_3, prism_rtl::deref(id_ps_3).name), [=](std::optional<Nat> template_slot_16652) {
                        return ({
                            prism_rtl::is_some(template_slot_16652) ? ({
                            auto&& j_pt = prism_rtl::some_of(template_slot_16652);
                            crate::check::env::has_key(m_pp, prism_rtl::cat(j_pt))
                            ? prism_rtl::finished(std::tuple{m_pp, crate::check::types::recording::err(s_pq, Text::lit("mismatch"), prism_rtl::deref(a_pr).span, prism_rtl::cat("`", prism_rtl::deref(id_ps_3).name, "` is given twice"))})
                            : prism_rtl::finished(std::tuple{insert(m_pp, prism_rtl::cat(j_pt), a_pr->value), s_pq});
                        })
                            : prism_rtl::is_none(template_slot_16652) ? prism_rtl::finished(std::tuple{m_pp, crate::check::types::recording::err(s_pq, Text::lit("mismatch"), prism_rtl::deref(a_pr).span, prism_rtl::cat("`", cname_p8_2_3, "` has no parameter `", prism_rtl::deref(id_ps_3).name, "`"))})
                            : throw prism_rtl::Panic("no arm matched");
                        });
                    });
                    });
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{m_pp, crate::check::types::recording::err(s_pq, Text::lit("mismatch"), prism_rtl::deref(a_pr).span, Text::lit("a template call names each argument: `name={{value}}`"))})
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            }));
            })));
            auto body_ol = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                if (prism_rtl::is_some(parts_o4)) {
                    auto&& ps_p10 = prism_rtl::some_of(parts_o4);
                    _v.set(std::optional(crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETemplate{crate::syntax::Template{.keyword = Text::lit("InlineText"), .lang = Text::lit(""), .delims = Text::lit("double"), .parts = ps_p10, .span = span_p5}})), .span = span_p5}));
                    goto _done;
                }
                if (prism_rtl::is_none(parts_o4)) {
                    _v.set(std::optional<crate::syntax::Expr>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto last_pm = crate::syntax::lexer::chars::dec(arity_pg);
            auto st2_pn = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                if (prism_rtl::is_some(body_ol)) {
                    auto&& ignore4_p11 = prism_rtl::some_of(body_ol);
                    _v.set((arity_pg == Nat(0u)) || crate::check::env::has_key(slots_pu, prism_rtl::cat(last_pm))
                        ? crate::check::types::recording::err(st1_pv, Text::lit("mismatch"), span_p5, prism_rtl::cat("`", cname_p8, "` has no parameter left for the call\'s body"))
                        : st1_pv);
                    goto _done;
                }
                if (prism_rtl::is_none(body_ol)) {
                    _v.set(st1_pv);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto quiet_po = len(prism_rtl::deref(st1_pv).diags) > len(st_p1.diags);
            auto [positional_p17, st3_p18] = run_to_end(fold_job(crate::check::errors::range0(arity_pg), std::tuple{Array<crate::syntax::Arg>{}, st2_pn}, ({
                auto slots_pu_1 = slots_pu;
                auto body_ol_2 = body_ol;
                auto last_pm_3 = last_pm;
                auto span_p5_4 = span_p5;
                auto clauses_pf_5 = clauses_pf;
                auto cname_p8_6 = cname_p8;
                auto quiet_po_7 = std::move(quiet_po);
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, slots_pu_1 = std::move(slots_pu_1), body_ol_2 = std::move(body_ol_2), last_pm_3 = std::move(last_pm_3), span_p5_4 = std::move(span_p5_4), clauses_pf_5 = std::move(clauses_pf_5), cname_p8_6 = std::move(cname_p8_6), quiet_po_7 = std::move(quiet_po_7)](std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto slots_pu_1_8 = slots_pu_1;
                    auto body_ol_2_8 = body_ol_2;
                    auto last_pm_3_8 = last_pm_3;
                    auto span_p5_4_8 = span_p5_4;
                    auto clauses_pf_5_8 = clauses_pf_5;
                    auto cname_p8_6_8 = cname_p8_6;
                    auto quiet_po_7_8 = quiet_po_7;
                    entered(once_job([=, slots_pu_1_8 = std::move(slots_pu_1_8), body_ol_2_8 = std::move(body_ol_2_8), last_pm_3_8 = std::move(last_pm_3_8), span_p5_4_8 = std::move(span_p5_4_8), clauses_pf_5_8 = std::move(clauses_pf_5_8), cname_p8_6_8 = std::move(cname_p8_6_8), quiet_po_7_8 = std::move(quiet_po_7_8)]() {
                    return ({
                        auto [acc_p12, s_p13] = p0;
                        auto j_p14 = p1;
                        ({
                        auto&& _m = crate::prelude::get(slots_pu_1_8, prism_rtl::cat(j_p14));
                        prism_rtl::is_some(_m) ? ({
                        auto&& v_p15 = prism_rtl::some_of(_m);
                        prism_rtl::finished(std::tuple{crate::prelude::push(acc_p12, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = v_p15, .span = prism_rtl::deref(v_p15).span}), s_p13});
                    })
                        : prism_rtl::is_none(_m) ? ({
                        prism_rtl::is_some(body_ol_2_8) ? ({
                        auto&& b_p16 = prism_rtl::some_of(body_ol_2_8);
                        j_p14 == last_pm_3_8
                        ? prism_rtl::finished(std::tuple{crate::prelude::push(acc_p12, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = b_p16, .span = span_p5_4_8}), s_p13})
                        : prism_rtl::more(prism_rtl::rc(TemplateMissing(acc_p12, s_p13, clauses_pf_5_8, j_p14, cname_p8_6_8, span_p5_4_8, quiet_po_7_8)));
                    })
                        : prism_rtl::is_none(body_ol_2_8) ? prism_rtl::more(prism_rtl::rc(TemplateMissing(acc_p12, s_p13, clauses_pf_5_8, j_p14, cname_p8_6_8, span_p5_4_8, quiet_po_7_8)))
                        : throw prism_rtl::Panic("no arm matched");
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            }));
            })));
            auto [t_p19, st4_p1a] = crate::check::expr::calls::call_global(env_p0, st3_p18, callee_p7, positional_p17, span_p5, Array<crate::check::types::Ty>{}, prism_rtl::deref(callee_p7).span);
            (crate::check::types::unify::unify(st4_p1a, crate::check::types::t_text(), t_p19, span_p5));
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> TemplateCallCheck::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& n_p2 = this->n_p2;
    const auto& args_p3 = this->args_p3;
    const auto& parts_o4 = this->parts_o4;
    const auto& span_p5 = this->span_p5;
    auto plain_p6 = crate::syntax::SName{.sigils = crate::syntax::lexer::chars::after_first(prism_rtl::deref(n_p2).sigils), .path_ = n_p2->path_, .span = prism_rtl::deref(n_p2).span};
    auto&& _qk1_o9 = crate::check::env::names::resolve_value(prism_rtl::deref(env_p0).g, prism_rtl::deref(env_p0).home, n_p2);
    auto&& qk1_o9 = std::get<0>(_qk1_o9);
    auto callee_p7 = qk1_o9 != std::optional<Text>{} ? n_p2 : plain_p6;
    auto [qk_oa, ignore2_pb] = crate::check::env::names::resolve_value(prism_rtl::deref(env_p0).g, prism_rtl::deref(env_p0).home, callee_p7);
    auto cname_p8 = crate::check::env::sname_key(plain_p6);
    return ({
        prism_rtl::is_none(qk_oa) ? ({
        auto env_p0_1 = env_p0;
        auto span_p5_2 = span_p5;
        auto st_p1_3 = st_p1;
        call_then(crate::check::expr::calls::start_call_global(env_p0_1, st_p1_3, callee_p7, Array<crate::syntax::Arg>{}, span_p5_2, Array<crate::check::types::Ty>{}, prism_rtl::deref(callee_p7).span), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> call_global_15910) {
        return ({
            auto [ignore3_pc, st2_pd] = call_global_15910;
            (prism_rtl::finished(st2_pd));
        });
    });
    })
        : prism_rtl::is_some(qk_oa) ? ({
        auto&& qk_pe = prism_rtl::some_of(qk_oa);
        ({
        auto clauses_pf = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g).fn_at, qk_pe);
            if (prism_rtl::is_some(_m)) {
                auto&& i_ph = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
                    auto&& _m = index(prism_rtl::deref(prism_rtl::deref(env_p0).g).defs, i_ph);
                    if (prism_rtl::is_some(_m)) {
                        auto&& d_pi = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
                            auto&& _m = prism_rtl::deref(d_pi).body;
                            if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
                                auto&& cs_pj = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
                                _v.set(cs_pj);
                                goto _done;
                            }
                            {
                                _v.set(Array<crate::syntax::decls::FnClause>{});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<crate::syntax::decls::FnClause>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::syntax::decls::FnClause>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arity_pg = ({
            __label__ _done;
            prism_rtl::Slot<Nat> _v;
            auto&& _m = index(clauses_pf, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& c_pk = prism_rtl::some_of(_m);
                _v.set(len(prism_rtl::deref(c_pk).params));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Nat(0u));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        len(clauses_pf) == Nat(0u)
        ? prism_rtl::finished(crate::check::types::recording::err(st_p1, Text::lit("mismatch"), span_p5, prism_rtl::cat("`<@", cname_p8, ">` calls a function without clauses, which name no parameters for its attributes")))
        : ({
        auto parts_o4_1 = parts_o4;
        auto args_p3_2 = args_p3;
        auto env_p0_3 = env_p0;
        auto span_p5_4 = span_p5;
        auto st_p1_5 = st_p1;
        call_value(fold_job(args_p3_2, std::tuple{Map<Text, crate::syntax::Expr>{}, st_p1_5}, ({
        auto clauses_pf_6 = clauses_pf;
        auto cname_p8_7 = cname_p8;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>, crate::syntax::Arg>)>>(prism_rtl::rc([=, clauses_pf_6 = std::move(clauses_pf_6), cname_p8_7 = std::move(cname_p8_7)](std::tuple<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>, crate::syntax::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto clauses_pf_6_8 = clauses_pf_6;
            auto cname_p8_7_8 = cname_p8_7;
            entered(once_job([=, clauses_pf_6_8 = std::move(clauses_pf_6_8), cname_p8_7_8 = std::move(cname_p8_7_8)]() {
            return ({
                auto [m_pp, s_pq] = p0;
                auto a_pr = p1;
                ({
                auto&& _m = prism_rtl::deref(a_pr).name;
                prism_rtl::is_some(_m) ? ({
                auto&& id_ps = prism_rtl::some_of(_m);
                ({
                auto id_ps_8 = id_ps;
                call_then(start_template_slot(clauses_pf_6_8, prism_rtl::deref(id_ps_8).name), [=](std::optional<Nat> template_slot_16652) {
                return ({
                    prism_rtl::is_some(template_slot_16652) ? ({
                    auto&& j_pt = prism_rtl::some_of(template_slot_16652);
                    crate::check::env::has_key(m_pp, prism_rtl::cat(j_pt))
                    ? prism_rtl::finished(std::tuple{m_pp, crate::check::types::recording::err(s_pq, Text::lit("mismatch"), prism_rtl::deref(a_pr).span, prism_rtl::cat("`", prism_rtl::deref(id_ps_8).name, "` is given twice"))})
                    : prism_rtl::finished(std::tuple{insert(m_pp, prism_rtl::cat(j_pt), a_pr->value), s_pq});
                })
                    : prism_rtl::is_none(template_slot_16652) ? prism_rtl::finished(std::tuple{m_pp, crate::check::types::recording::err(s_pq, Text::lit("mismatch"), prism_rtl::deref(a_pr).span, prism_rtl::cat("`", cname_p8_7_8, "` has no parameter `", prism_rtl::deref(id_ps_8).name, "`"))})
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{m_pp, crate::check::types::recording::err(s_pq, Text::lit("mismatch"), prism_rtl::deref(a_pr).span, Text::lit("a template call names each argument: `name={{value}}`"))})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=, parts_o4_1 = std::move(parts_o4_1), env_p0_3 = std::move(env_p0_3), span_p5_4 = std::move(span_p5_4)](std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St> fold_16567) {
        return ({
            auto [slots_pu, st1_pv] = fold_16567;
            auto body_ol = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                if (prism_rtl::is_some(parts_o4_1)) {
                    auto&& ps_p10 = prism_rtl::some_of(parts_o4_1);
                    _v.set(std::optional(crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETemplate{crate::syntax::Template{.keyword = Text::lit("InlineText"), .lang = Text::lit(""), .delims = Text::lit("double"), .parts = ps_p10, .span = span_p5_4}})), .span = span_p5_4}));
                    goto _done;
                }
                if (prism_rtl::is_none(parts_o4_1)) {
                    _v.set(std::optional<crate::syntax::Expr>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto last_pm = crate::syntax::lexer::chars::dec(arity_pg);
            auto st2_pn = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                if (prism_rtl::is_some(body_ol)) {
                    auto&& ignore4_p11 = prism_rtl::some_of(body_ol);
                    _v.set((arity_pg == Nat(0u)) || crate::check::env::has_key(slots_pu, prism_rtl::cat(last_pm))
                        ? crate::check::types::recording::err(st1_pv, Text::lit("mismatch"), span_p5_4, prism_rtl::cat("`", cname_p8, "` has no parameter left for the call\'s body"))
                        : st1_pv);
                    goto _done;
                }
                if (prism_rtl::is_none(body_ol)) {
                    _v.set(st1_pv);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto quiet_po = len(prism_rtl::deref(st1_pv).diags) > len(prism_rtl::deref(st_p1_5).diags);
            call_value(fold_job(crate::check::errors::range0(arity_pg), std::tuple{Array<crate::syntax::Arg>{}, st2_pn}, ({
            auto slots_pu_6 = slots_pu;
            auto body_ol_7 = body_ol;
            auto last_pm_8 = last_pm;
            auto span_p5_4_9 = span_p5_4;
            auto clauses_pf_9 = clauses_pf;
            auto cname_p8_10 = cname_p8;
            auto quiet_po_11 = std::move(quiet_po);
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, slots_pu_6 = std::move(slots_pu_6), body_ol_7 = std::move(body_ol_7), last_pm_8 = std::move(last_pm_8), span_p5_4_9 = std::move(span_p5_4_9), clauses_pf_9 = std::move(clauses_pf_9), cname_p8_10 = std::move(cname_p8_10), quiet_po_11 = std::move(quiet_po_11)](std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto slots_pu_6_12 = slots_pu_6;
                auto body_ol_7_12 = body_ol_7;
                auto last_pm_8_12 = last_pm_8;
                auto span_p5_4_9_12 = span_p5_4_9;
                auto clauses_pf_9_12 = clauses_pf_9;
                auto cname_p8_10_12 = cname_p8_10;
                auto quiet_po_11_12 = quiet_po_11;
                entered(once_job([=, slots_pu_6_12 = std::move(slots_pu_6_12), body_ol_7_12 = std::move(body_ol_7_12), last_pm_8_12 = std::move(last_pm_8_12), span_p5_4_9_12 = std::move(span_p5_4_9_12), clauses_pf_9_12 = std::move(clauses_pf_9_12), cname_p8_10_12 = std::move(cname_p8_10_12), quiet_po_11_12 = std::move(quiet_po_11_12)]() {
                return ({
                    auto [acc_p12, s_p13] = p0;
                    auto j_p14 = p1;
                    ({
                    auto&& _m = crate::prelude::get(slots_pu_6_12, prism_rtl::cat(j_p14));
                    prism_rtl::is_some(_m) ? ({
                    auto&& v_p15 = prism_rtl::some_of(_m);
                    prism_rtl::finished(std::tuple{crate::prelude::push(acc_p12, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = v_p15, .span = prism_rtl::deref(v_p15).span}), s_p13});
                })
                    : prism_rtl::is_none(_m) ? ({
                    prism_rtl::is_some(body_ol_7_12) ? ({
                    auto&& b_p16 = prism_rtl::some_of(body_ol_7_12);
                    j_p14 == last_pm_8_12
                    ? prism_rtl::finished(std::tuple{crate::prelude::push(acc_p12, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = b_p16, .span = span_p5_4_9_12}), s_p13})
                    : prism_rtl::more(prism_rtl::rc(TemplateMissing(acc_p12, s_p13, clauses_pf_9_12, j_p14, cname_p8_10_12, span_p5_4_9_12, quiet_po_11_12)));
                })
                    : prism_rtl::is_none(body_ol_7_12) ? prism_rtl::more(prism_rtl::rc(TemplateMissing(acc_p12, s_p13, clauses_pf_9_12, j_p14, cname_p8_10_12, span_p5_4_9_12, quiet_po_11_12)))
                    : throw prism_rtl::Panic("no arm matched");
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        }));
        })), [=](std::tuple<Array<crate::syntax::Arg>, crate::check::types::St> fold_17651) {
            return ({
                auto [positional_p17, st3_p18] = fold_17651;
                call_then(crate::check::expr::calls::start_call_global(env_p0_3, st3_p18, callee_p7, positional_p17, span_p5_4, Array<crate::check::types::Ty>{}, prism_rtl::deref(callee_p7).span), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> call_global_18116) {
                return ({
                    auto [t_p19, st4_p1a] = call_global_18116;
                    (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st4_p1a, crate::check::types::t_text(), t_p19, span_p5_4))));
                });
            });
            });
        });
        });
    });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplateCallCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_template_call_check(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, Array<crate::syntax::Arg> args_p3, std::optional<Array<crate::syntax::TemplatePart>> parts_o4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<TemplateCallCheck>(env_p0, st_p1, n_p2, args_p3, parts_o4, span_p5);
}


/// TemplateMissing: unbounded fn [Arg], St, [FnClause], Nat, Text, Range, Bool -> (([Arg], St))
std::tuple<Array<crate::syntax::Arg>, crate::check::types::St> template_missing(const Array<crate::syntax::Arg>& acc_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::decls::FnClause>& clauses_p2, const Nat& j_p3, const Text& cname_p4, const crate::syntax::Range& span_p5, const bool& quiet_p6) {
    auto pname_p7 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(clauses_p2, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c_p9 = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = index(prism_rtl::deref(c_p9).params, j_p3);
                if (prism_rtl::is_some(_m)) {
                    auto&& p_pa = prism_rtl::some_of(_m);
                    _v.set(crate::check::shrink::locals::param_name_of(p_pa));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2_p8 = quiet_p6
        ? st_p1
        : crate::check::types::recording::err(st_p1, Text::lit("mismatch"), span_p5, prism_rtl::cat("`<@", cname_p4, ">` needs `", pname_p7, "=`"));
    return std::tuple{crate::prelude::push(acc_p0, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_p5}, .span = span_p5}), st2_p8};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>> TemplateMissing::cycle() const {
    const auto& acc_p0 = this->acc_p0;
    const auto& st_p1 = this->st_p1;
    const auto& clauses_p2 = this->clauses_p2;
    const auto& j_p3 = this->j_p3;
    const auto& cname_p4 = this->cname_p4;
    const auto& span_p5 = this->span_p5;
    const auto& quiet_p6 = this->quiet_p6;
    auto pname_p7 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(clauses_p2, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c_p9 = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = index(prism_rtl::deref(c_p9).params, j_p3);
                if (prism_rtl::is_some(_m)) {
                    auto&& p_pa = prism_rtl::some_of(_m);
                    _v.set(crate::check::shrink::locals::param_name_of(p_pa));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2_p8 = prism_rtl::deref(quiet_p6)
        ? st_p1
        : crate::check::types::recording::err(st_p1, Text::lit("mismatch"), span_p5, prism_rtl::cat("`<@", cname_p4, ">` needs `", pname_p7, "=`"));
    return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p0, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_p5}, .span = span_p5}), st2_p8});
}


/// `Start TemplateMissing, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>> start_template_missing(Array<crate::syntax::Arg> acc_p0, crate::check::types::St st_p1, Array<crate::syntax::decls::FnClause> clauses_p2, Nat j_p3, Text cname_p4, crate::syntax::Range span_p5, bool quiet_p6) {
    return prism_rtl::make_rc<TemplateMissing>(acc_p0, st_p1, clauses_p2, j_p3, cname_p4, span_p5, quiet_p6);
}


/// ?TemplateSlot: unbounded fn [FnClause], Text -> ?Nat
std::optional<Nat> template_slot(const Array<crate::syntax::decls::FnClause>& clauses_p0, const Text& name_p1) {
    auto found_p7 = run_to_end(fold_job(clauses_p0, Array<Nat>{}, ({
        auto name_p1_1 = name_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, name_p1_1 = std::move(name_p1_1)](std::tuple<Array<Nat>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto name_p1_1_2 = name_p1_1;
            entered(once_job([=, name_p1_1_2 = std::move(name_p1_1_2)]() {
            return ({
                auto acc_p2 = p0;
                auto c_p3 = p1;
                fold_job(crate::check::errors::range0(len(prism_rtl::deref(c_p3).params)), acc_p2, ({
                auto c_p3_2 = c_p3;
                auto name_p1_1_2_3 = name_p1_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Nat>)>>(prism_rtl::rc([=, c_p3_2 = std::move(c_p3_2), name_p1_1_2_3 = std::move(name_p1_1_2_3)](std::tuple<Array<Nat>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_p3_2_3 = c_p3_2;
                    auto name_p1_1_2_3_3 = name_p1_1_2_3;
                    entered(once_job([=, c_p3_2_3 = std::move(c_p3_2_3), name_p1_1_2_3_3 = std::move(name_p1_1_2_3_3)]() {
                    return ({
                        auto a2_p4 = p0;
                        auto i_p5 = p1;
                        ({
                        auto&& _m = index(prism_rtl::deref(c_p3_2_3).params, i_p5);
                        prism_rtl::is_some(_m) ? ({
                        auto&& p_p6 = prism_rtl::some_of(_m);
                        crate::check::shrink::locals::param_name_of(p_p6) == name_p1_1_2_3_3
                        ? prism_rtl::finished(crate::check::types::add_nat(a2_p4, i_p5))
                        : prism_rtl::finished(a2_p4);
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(a2_p4)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
    return len(found_p7) == Nat(1u) ? index(found_p7, Nat(0u)) : std::optional<Nat>{};
}


prism_rtl::Turn<std::optional<Nat>> TemplateSlot::cycle() const {
    const auto& clauses_p0 = this->clauses_p0;
    const auto& name_p1 = this->name_p1;
    auto clauses_p0_1 = clauses_p0;
    auto name_p1_2 = name_p1;
    return call_value(fold_job(clauses_p0_1, Array<Nat>{}, ({
        auto name_p1_2_3 = name_p1_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, name_p1_2_3 = std::move(name_p1_2_3)](std::tuple<Array<Nat>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto name_p1_2_3_3 = name_p1_2_3;
            entered(once_job([=, name_p1_2_3_3 = std::move(name_p1_2_3_3)]() {
            return ({
                auto acc_p2 = p0;
                auto c_p3 = p1;
                fold_job(crate::check::errors::range0(len(prism_rtl::deref(c_p3).params)), acc_p2, ({
                auto c_p3_3 = c_p3;
                auto name_p1_2_3_3_4 = name_p1_2_3_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Nat>)>>(prism_rtl::rc([=, c_p3_3 = std::move(c_p3_3), name_p1_2_3_3_4 = std::move(name_p1_2_3_3_4)](std::tuple<Array<Nat>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_p3_3_4 = c_p3_3;
                    auto name_p1_2_3_3_4_4 = name_p1_2_3_3_4;
                    entered(once_job([=, c_p3_3_4 = std::move(c_p3_3_4), name_p1_2_3_3_4_4 = std::move(name_p1_2_3_3_4_4)]() {
                    return ({
                        auto a2_p4 = p0;
                        auto i_p5 = p1;
                        ({
                        auto&& _m = index(prism_rtl::deref(c_p3_3_4).params, i_p5);
                        prism_rtl::is_some(_m) ? ({
                        auto&& p_p6 = prism_rtl::some_of(_m);
                        crate::check::shrink::locals::param_name_of(p_p6) == name_p1_2_3_3_4_4
                        ? prism_rtl::finished(crate::check::types::add_nat(a2_p4, i_p5))
                        : prism_rtl::finished(a2_p4);
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(a2_p4)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })), [=](Array<Nat> fold_19010) {
        return ({
            auto found_p7 = fold_19010;
            len(found_p7) == Nat(1u)
            ? prism_rtl::finished(index(found_p7, Nat(0u)))
            : prism_rtl::finished(std::optional<Nat>{});
        });
    });
}


/// `Start TemplateSlot, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Nat>> start_template_slot(Array<crate::syntax::decls::FnClause> clauses_p0, Text name_p1) {
    return prism_rtl::make_rc<TemplateSlot>(clauses_p0, name_p1);
}

}  // namespace crate::check::expr::lets
