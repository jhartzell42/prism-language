// The module `Check.Expr.Lets`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/expr/lets/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Expr.Lets`, from `target/bootstrap/cpp-src/prismc/check/expr/lets.prism`.
namespace crate::check::expr::lets {

/// InferExprBlock: unbounded fn Env, St, Block -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Block& b_p2) {
    return is_widgetish_f(b_p2.stmts_p)
        ? crate::check::blocks::infer_widget_block_f(env_p0, st_p1, b_p2)
        : ({
        auto [env2_p3, st2_p4] = bind_group_f(env_p0, st_p1, b_p2.stmts_p);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = crate::syntax::lexer::chars::last_o(b_p2.stmts_p);
        if (prism_rtl::is_some(_m)) {
            auto&& s_p5 = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                auto&& _m = prism_rtl::deref(s_p5).kind_p;
                if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
                    auto&& e_p6 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                    _v.set(crate::check::expr::infer_f(env2_p3, st2_p4, e_p6));
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::check::types::t_unit_p(), st2_p4});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{crate::check::types::t_unit_p(), st2_p4});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferExprBlock::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& b_p2 = this->b_p2;
    return is_widgetish_f(prism_rtl::deref(b_p2).stmts_p)
        ? prism_rtl::more(prism_rtl::rc(crate::check::blocks::InferWidgetBlock(env_p0, st_p1, b_p2)))
        : ({
        auto b_p2x = b_p2;
        auto env_p0x = env_p0;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_bind_group_f(env_p0x, st_p1x, prism_rtl::deref(b_p2x).stmts_p), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_group_f_1662) {
        return ({
            auto [env2_p3, st2_p4] = bind_group_f_1662;
            ({
            auto&& _m = crate::syntax::lexer::chars::last_o(prism_rtl::deref(b_p2x).stmts_p);
            prism_rtl::is_some(_m) ? ({
            auto&& s_p5 = prism_rtl::some_of(_m);
            ({
            auto&& _m = prism_rtl::deref(s_p5).kind_p;
            prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
            auto&& e_p6 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
            prism_rtl::more(prism_rtl::rc(crate::check::expr::Infer(env2_p3, st2_p4, e_p6)));
        })
            : prism_rtl::finished(std::tuple{crate::check::types::t_unit_p(), st2_p4});
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::t_unit_p(), st2_p4})
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    }));
    });
}


/// `Start InferExprBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_expr_block_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2) {
    return prism_rtl::make_rc<InferExprBlock>(env_p0, st_p1, b_p2);
}


/// IsWidgetish: fn [Stmt] -> Bool
bool is_widgetish_f(const Array<crate::syntax::Stmt>& stmts_p0) {
    return crate::prelude::fold(stmts_p0, false, [&](const bool& seen_p1, const crate::syntax::Stmt& s_p2) { return prism_rtl::deref(seen_p1) || builds_f(s_p2); });
}


/// Builds: fn Stmt -> Bool
bool builds_f(const crate::syntax::Stmt& s_p0) {
    auto&& _m = s_p0.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// BindGroup: unbounded fn Env, St, [Stmt] -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_group_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Stmt>& stmts_p2) {
    auto order_p3 = crate::check::blocks::group_order_f(stmts_p2);
    auto [env1_p8, st1_p9] = crate::prelude::run_to_end(crate::prelude::fold_job(order_p3, std::tuple{env_p0, st_p1}, ({
        auto stmts_p2x = stmts_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, stmts_p2x = std::move(stmts_p2x)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto stmts_p2xy = stmts_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, stmts_p2xy = std::move(stmts_p2xy)]() {
            return ({
                auto [en_p5, s_p6] = p0;
                auto i_p7 = p1;
                (prism_rtl::more(prism_rtl::rc(PreBind(en_p5, s_p6, crate::prelude::or_(crate::prelude::index(stmts_p2xy, i_p7), dummy_stmt_p())))));
            });
        })));
        });
    }));
    })));
    auto st2_p4 = prism_rtl::deref(st1_p9).recording_p && (crate::prelude::len(stmts_p2) > Nat(1u))
        ? crate::check::types::recording::note_group_f(st1_p9, stmts_span_f(stmts_p2), Text::lit("expr"), crate::check::blocks::dep_order_f(stmts_p2))
        : st1_p9;
    return crate::prelude::run_to_end(crate::prelude::fold_job(order_p3, std::tuple{env1_p8, st2_p4}, ({
        auto stmts_p2x = stmts_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, stmts_p2x = std::move(stmts_p2x)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto stmts_p2xy = stmts_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, stmts_p2xy = std::move(stmts_p2xy)]() {
            return ({
                auto [en_pa, s_pb] = p0;
                auto i_pc = p1;
                (prism_rtl::more(prism_rtl::rc(CheckGroupStmt(en_pa, s_pb, crate::prelude::or_(crate::prelude::index(stmts_p2xy, i_pc), dummy_stmt_p()), is_last_f(stmts_p2xy, i_pc)))));
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindGroup::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& stmts_p2 = this->stmts_p2;
    auto env_p0x = env_p0;
    auto st_p1x = st_p1;
    auto stmts_p2x = stmts_p2;
    return crate::prelude::call_then(crate::check::blocks::start_group_order_f(stmts_p2x), [=](Array<Nat> group_order_f_2649) {
        return ({
            auto order_p3 = group_order_f_2649;
            (crate::prelude::call_value(crate::prelude::fold_job(order_p3, std::tuple{env_p0x, st_p1x}, ({
            auto stmts_p2xx = stmts_p2x;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, stmts_p2xx = std::move(stmts_p2xx)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto stmts_p2xxy = stmts_p2xx;
                (crate::prelude::entered(crate::prelude::once_job([=, stmts_p2xxy = std::move(stmts_p2xxy)]() {
                return ({
                    auto [en_p5, s_p6] = p0;
                    auto i_p7 = p1;
                    (prism_rtl::more(prism_rtl::rc(PreBind(en_p5, s_p6, crate::prelude::or_(crate::prelude::index(stmts_p2xxy, i_p7), dummy_stmt_p())))));
                });
            })));
            });
        }));
        })), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> fold_2690) {
            return ({
                auto [env1_p8, st1_p9] = fold_2690;
                auto st2_p4 = prism_rtl::deref(st1_p9).recording_p && (crate::prelude::len(stmts_p2x) > Nat(1u))
                    ? crate::check::types::recording::note_group_f(st1_p9, stmts_span_f(stmts_p2x), Text::lit("expr"), crate::check::blocks::dep_order_f(stmts_p2x))
                    : st1_p9;
                (crate::prelude::fold_job(order_p3, std::tuple{env1_p8, st2_p4}, ({
                auto stmts_p2xx = stmts_p2x;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, stmts_p2xx = std::move(stmts_p2xx)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto stmts_p2xxy = stmts_p2xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, stmts_p2xxy = std::move(stmts_p2xxy)]() {
                    return ({
                        auto [en_pa, s_pb] = p0;
                        auto i_pc = p1;
                        (prism_rtl::more(prism_rtl::rc(CheckGroupStmt(en_pa, s_pb, crate::prelude::or_(crate::prelude::index(stmts_p2xxy, i_pc), dummy_stmt_p()), is_last_f(stmts_p2xxy, i_pc)))));
                    });
                })));
                });
            }));
            }))->cycle());
            });
        }));
        });
    });
}


/// `Start BindGroup, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_group_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2) {
    return prism_rtl::make_rc<BindGroup>(env_p0, st_p1, stmts_p2);
}


/// StmtsSpan: fn [Stmt] -> Range
crate::syntax::Range stmts_span_f(const Array<crate::syntax::Stmt>& stmts_p0) {
    return crate::syntax::Range{.start_p = prism_rtl::deref(prism_rtl::deref(crate::prelude::or_(crate::prelude::index(stmts_p0, Nat(0u)), dummy_stmt_p())).span_p).start_p, .end_p = prism_rtl::deref(prism_rtl::deref(crate::prelude::or_(crate::syntax::lexer::chars::last_o(stmts_p0), dummy_stmt_p())).span_p).end_p};
}


/// let dummyStmt
crate::syntax::Stmt dummy_stmt_p() {
    return crate::syntax::Stmt{.kind_p = crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}}}), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}};
}


/// IsLast: fn [Stmt], Nat -> Bool
bool is_last_f(const Array<crate::syntax::Stmt>& stmts_p0, const Nat& i_p1) {
    return (i_p1 + Nat(1u)) == crate::prelude::len(stmts_p0);
}


/// PreBind: unbounded fn Env, St, Stmt -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> pre_bind_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Stmt& s_p2) {
    auto&& _m = s_p2.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        auto&& sg_p3 = prism_rtl::as<crate::syntax::StmtKind::SSignature>(_m).a0;
        auto [sc_p4, st2_p5] = crate::check::env::reading::sig_scheme_f(crate::check::expr::env_cx_f(env_p0), st_p1, prism_rtl::deref(sg_p3).ty_p, prism_rtl::deref(sg_p3).bounds_p);
        return crate::check::expr::bind_local_id_f(crate::check::expr::with_local_f(env_p0, crate::check::env::def_name_text_f(prism_rtl::deref(sg_p3).name_p), sc_p4), st2_p5, crate::check::env::def_name_text_f(prism_rtl::deref(sg_p3).name_p), crate::check::env::def_name_span_f(prism_rtl::deref(sg_p3).name_p));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f_p6 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        auto name_p7 = crate::check::env::def_name_text_f(prism_rtl::deref(f_p6).name_p);
        auto&& _m = crate::prelude::get(env_p0.locals_p, name_p7);
        if (prism_rtl::is_some(_m)) {
            return std::tuple{env_p0, st_p1};
        }
        if (prism_rtl::is_none(_m)) {
            auto [v_p8, st2_p9] = crate::check::types::fresh_var_f(st_p1, false, Text::lit(""));
            return crate::check::expr::bind_local_id_f(crate::check::expr::with_local_f(env_p0, name_p7, crate::check::types::schemes::mono_f(v_p8)), st2_p9, name_p7, crate::check::env::def_name_span_f(prism_rtl::deref(f_p6).name_p));
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_pa = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_pa).kind_p);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n_pb = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            auto [v_pd, st1_pe] = crate::check::types::fresh_var_f(st_p1, true, crate::check::env::sname_key_f(n_pb));
            auto st2_pc = crate::check::types::recording::at_binder_f(st1_pe, v_pd, prism_rtl::deref(n_pb).span_p);
            auto [rw_pf, st3_pg] = crate::check::types::recording::fresh_row_f(st2_pc, Array<Text>{});
            return crate::check::expr::bind_local_id_f(crate::check::expr::with_local_f(env_p0, crate::check::env::sname_key_f(n_pb), crate::check::types::schemes::mono_f(crate::check::types::with_marks_f(type_marks_f(prism_rtl::deref(n_pb).sigils_p), v_pd, rw_pf))), st3_pg, crate::check::env::sname_key_f(n_pb), prism_rtl::deref(n_pb).span_p);
        }
        {
            return std::tuple{env_p0, st_p1};
        }
    }
    {
        return std::tuple{env_p0, st_p1};
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> PreBind::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& s_p2 = this->s_p2;
    return ({
        auto&& _m = prism_rtl::deref(s_p2).kind_p;
        prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? ({
        auto&& sg_p3 = prism_rtl::as<crate::syntax::StmtKind::SSignature>(_m).a0;
        ({
        auto env_p0x = env_p0;
        auto sg_p3x = sg_p3;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::env::reading::start_sig_scheme_f(crate::check::expr::env_cx_f(env_p0x), st_p1x, prism_rtl::deref(sg_p3x).ty_p, prism_rtl::deref(sg_p3x).bounds_p), [=](std::tuple<crate::check::types::Scheme, crate::check::types::St> sig_scheme_f_3595) {
        return ({
            auto [sc_p4, st2_p5] = sig_scheme_f_3595;
            (prism_rtl::finished(crate::check::expr::bind_local_id_f(crate::check::expr::with_local_f(env_p0x, crate::check::env::def_name_text_f(prism_rtl::deref(sg_p3x).name_p), sc_p4), st2_p5, crate::check::env::def_name_text_f(prism_rtl::deref(sg_p3x).name_p), crate::check::env::def_name_span_f(prism_rtl::deref(sg_p3x).name_p))));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f_p6 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        ({
        auto name_p7 = crate::check::env::def_name_text_f(prism_rtl::deref(f_p6).name_p);
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0).locals_p, name_p7);
        prism_rtl::is_some(_m) ? prism_rtl::finished(std::tuple{env_p0, st_p1})
        : prism_rtl::is_none(_m) ? ({
        auto [v_p8, st2_p9] = crate::check::types::fresh_var_f(st_p1, false, Text::lit(""));
        (prism_rtl::finished(crate::check::expr::bind_local_id_f(crate::check::expr::with_local_f(env_p0, name_p7, crate::check::types::schemes::mono_f(v_p8)), st2_p9, name_p7, crate::check::env::def_name_span_f(prism_rtl::deref(f_p6).name_p))));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_pa = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_pa).kind_p);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_pb = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto [v_pd, st1_pe] = crate::check::types::fresh_var_f(st_p1, true, crate::check::env::sname_key_f(n_pb));
        auto st2_pc = crate::check::types::recording::at_binder_f(st1_pe, v_pd, prism_rtl::deref(n_pb).span_p);
        auto [rw_pf, st3_pg] = crate::check::types::recording::fresh_row_f(st2_pc, Array<Text>{});
        (prism_rtl::finished(crate::check::expr::bind_local_id_f(crate::check::expr::with_local_f(env_p0, crate::check::env::sname_key_f(n_pb), crate::check::types::schemes::mono_f(crate::check::types::with_marks_f(type_marks_f(prism_rtl::deref(n_pb).sigils_p), v_pd, rw_pf))), st3_pg, crate::check::env::sname_key_f(n_pb), prism_rtl::deref(n_pb).span_p)));
    });
    })
        : prism_rtl::finished(std::tuple{env_p0, st_p1});
    });
    })
        : prism_rtl::finished(std::tuple{env_p0, st_p1});
    });
}


/// `Start PreBind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_pre_bind_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Stmt s_p2) {
    return prism_rtl::make_rc<PreBind>(env_p0, st_p1, s_p2);
}


/// CheckGroupStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> check_group_stmt_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Stmt& s_p2, const bool& last_p3) {
    auto&& _m = s_p2.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_p4 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_o5 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& e_p6 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        return check_let_f(env_p0, st_p1, p_p4, ty_o5, e_p6, s_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f_p7 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return check_local_fn_f(env_p0, st_p1, f_p7, s_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        return std::tuple{env_p0, st_p1};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e_p8 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return last_p3
            ? std::tuple{env_p0, st_p1}
            : ({
            auto [t_p9, st2_pa] = crate::check::expr::infer_f(env_p0, st_p1, e_p8);
            std::tuple{env_p0, st2_pa};
        });
    }
    {
        return std::tuple{env_p0, crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), s_p2.span_p, Text::lit("this statement belongs in a widget, `given:` or `update` block"))};
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> CheckGroupStmt::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& s_p2 = this->s_p2;
    const auto& last_p3 = this->last_p3;
    return ({
        auto&& _m = prism_rtl::deref(s_p2).kind_p;
        prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_p4 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_o5 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& e_p6 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        prism_rtl::more(prism_rtl::rc(CheckLet(env_p0, st_p1, p_p4, ty_o5, e_p6, prism_rtl::deref(s_p2).span_p)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f_p7 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        prism_rtl::more(prism_rtl::rc(CheckLocalFn(env_p0, st_p1, f_p7, prism_rtl::deref(s_p2).span_p)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? prism_rtl::finished(std::tuple{env_p0, st_p1})
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& e_p8 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        prism_rtl::deref(last_p3)
        ? prism_rtl::finished(std::tuple{env_p0, st_p1})
        : ({
        auto e_p8x = e_p8;
        auto env_p0x = env_p0;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, e_p8x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_4771) {
        return ({
            auto [t_p9, st2_pa] = infer_f_4771;
            (prism_rtl::finished(std::tuple{env_p0x, st2_pa}));
        });
    }));
    });
    })
        : prism_rtl::finished(std::tuple{env_p0, crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), prism_rtl::deref(s_p2).span_p, Text::lit("this statement belongs in a widget, `given:` or `update` block"))});
    });
}


/// `Start CheckGroupStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_check_group_stmt_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Stmt s_p2, bool last_p3) {
    return prism_rtl::make_rc<CheckGroupStmt>(env_p0, st_p1, s_p2, last_p3);
}


/// CheckLet: unbounded fn Env, St, Pattern, ?Type, Expr, Range -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> check_let_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const std::optional<crate::syntax::Type>& ty_o3, const crate::syntax::Expr& e_p4, const crate::syntax::Range& span_p5) {
    auto st0_p6 = crate::check::types::schemes::enter_level_f(st_p1);
    auto [annot_od, st1_pe] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<crate::check::types::Ty>, crate::check::types::St>> _v;
        if (prism_rtl::is_some(ty_o3)) {
            auto&& t_pa = prism_rtl::some_of(ty_o3);
            _v.set(({
                auto [at_pb, s2_pc] = crate::check::env::reading::conv_type_f(crate::check::expr::env_cx_f(env_p0), st0_p6, t_pa);
                std::tuple{std::optional(at_pb), s2_pc};
            }));
            goto _done;
        }
        if (prism_rtl::is_none(ty_o3)) {
            _v.set(std::tuple{std::optional<crate::check::types::Ty>{}, st0_p6});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [pre_pj, st2_pk] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = prism_rtl::deref(p_p2.kind_p);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n_pf = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                auto&& _m = crate::prelude::get(env_p0.locals_p, crate::check::env::sname_key_f(n_pf));
                if (prism_rtl::is_some(_m)) {
                    auto&& sc_pg = prism_rtl::some_of(_m);
                    _v.set((prism_rtl::deref(n_pf).sigils_p == Text::lit("")) && crate::check::types::is_flex_var_f(st1_pe, prism_rtl::deref(sc_pg).ty_p)
                        ? ({
                        auto [v_ph, s2_pi] = crate::check::types::fresh_var_f(st1_pe, true, crate::check::env::sname_key_f(n_pf));
                        std::tuple{v_ph, crate::check::types::recording::at_binder_f(s2_pi, v_ph, prism_rtl::deref(n_pf).span_p)};
                    })
                        : std::tuple{prism_rtl::deref(sc_pg).ty_p, st1_pe});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::check::types::fresh_var_f(st1_pe, true, crate::check::env::sname_key_f(n_pf)));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(crate::check::types::fresh_var_f(st1_pe, false, Text::lit("")));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto st3_p7 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        if (prism_rtl::is_some(annot_od)) {
            auto&& at_pl = prism_rtl::some_of(annot_od);
            _v.set(crate::check::expr::check_f(env_p0, st2_pk, e_p4, at_pl));
            goto _done;
        }
        if (prism_rtl::is_none(annot_od)) {
            _v.set(crate::check::expr::check_f(env_p0, st2_pk, e_p4, pre_pj));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st4_p8 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        if (prism_rtl::is_some(annot_od)) {
            auto&& at_pm = prism_rtl::some_of(annot_od);
            _v.set(crate::check::types::unify::unify_f(st3_p7, pre_pj, at_pm, span_p5));
            goto _done;
        }
        if (prism_rtl::is_none(annot_od)) {
            _v.set(st3_p7);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st5_p9 = crate::check::env::traits::solve_wants_f(env_p0.g_p, st4_p8, env_p0.givens_p, false);
    auto&& _m = prism_rtl::deref(p_p2.kind_p);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_pn = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto name_po = crate::check::env::sname_key_f(n_pn);
        auto t_pp = crate::check::types::recording::zonk_f(st5_p9, pre_pj);
        auto [env2_ps, st7a_pt] = crate::check::expr::patterns::bind_name_f(env_p0, st5_p9, n_pn, t_pp);
        auto st7_pq = crate::check::types::schemes::leave_level_f(st7a_pt);
        auto ahead_fr = ({
            auto env_p0x = env_p0;
            auto name_pox = name_po;
            auto pre_pjx = pre_pj;
            auto t_ppx = t_pp;
            auto span_p5x = span_p5;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x), name_pox = std::move(name_pox), pre_pjx = std::move(pre_pjx), t_ppx = std::move(t_ppx), span_p5x = std::move(span_p5x)](crate::check::types::St p0) {
            return ({
                auto env_p0xy = env_p0x;
                auto name_poxy = name_pox;
                auto pre_pjxy = pre_pjx;
                auto t_ppxy = t_ppx;
                auto span_p5xy = span_p5x;
                (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy), name_poxy = std::move(name_poxy), pre_pjxy = std::move(pre_pjxy), t_ppxy = std::move(t_ppxy), span_p5xy = std::move(span_p5xy)]() {
                return ({
                    auto s_pu = p0;
                    (prism_rtl::more(prism_rtl::rc(AheadUnify(env_p0xy, s_pu, name_poxy, pre_pjxy, t_ppxy, span_p5xy))));
                });
            })));
            });
        })));
        });
        return crate::check::types::schemes::holds_node_f(st7_pq, t_pp) || is_topic_name_f(name_po)
            ? std::tuple{env2_ps, crate::prelude::run_to_end(ahead_fr(st7_pq))}
            : ({
            auto lambda_pv = crate::check::expr::is_lambda_f(e_p4);
            auto [keep_p10, bounds_p11, st8_p12] = wants_above_f(st7_pq, t_pp, lambda_pv);
            auto [sc_p13, st9_p14] = crate::check::types::schemes::generalize_f(st8_p12, t_pp, keep_p10, bounds_p11);
            std::tuple{crate::check::expr::with_local_f(env2_ps, name_po, sc_p13), crate::prelude::run_to_end(ahead_fr(crate::check::types::recording::note_gen_f(st9_p14, prism_rtl::deref(n_pn).span_p, name_po, sc_p13)))};
        });
    }
    {
        auto st6_p15 = crate::check::types::schemes::leave_level_f(st5_p9);
        return crate::check::expr::patterns::bind_pattern_f(env_p0, st6_p15, p_p2, crate::check::types::recording::zonk_f(st6_p15, pre_pj), false);
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> CheckLet::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& p_p2 = this->p_p2;
    const auto& ty_o3 = this->ty_o3;
    const auto& e_p4 = this->e_p4;
    const auto& span_p5 = this->span_p5;
    auto st0_p6 = crate::check::types::schemes::enter_level_f(st_p1);
    auto [annot_od, st1_pe] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<crate::check::types::Ty>, crate::check::types::St>> _v;
        if (prism_rtl::is_some(ty_o3)) {
            auto&& t_pa = prism_rtl::some_of(ty_o3);
            _v.set(({
                auto [at_pb, s2_pc] = crate::check::env::reading::conv_type_f(crate::check::expr::env_cx_f(env_p0), st0_p6, t_pa);
                std::tuple{std::optional(at_pb), s2_pc};
            }));
            goto _done;
        }
        if (prism_rtl::is_none(ty_o3)) {
            _v.set(std::tuple{std::optional<crate::check::types::Ty>{}, st0_p6});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [pre_pj, st2_pk] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p2).kind_p);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n_pf = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0).locals_p, crate::check::env::sname_key_f(n_pf));
                if (prism_rtl::is_some(_m)) {
                    auto&& sc_pg = prism_rtl::some_of(_m);
                    _v.set((prism_rtl::deref(n_pf).sigils_p == Text::lit("")) && crate::check::types::is_flex_var_f(st1_pe, prism_rtl::deref(sc_pg).ty_p)
                        ? ({
                        auto [v_ph, s2_pi] = crate::check::types::fresh_var_f(st1_pe, true, crate::check::env::sname_key_f(n_pf));
                        std::tuple{v_ph, crate::check::types::recording::at_binder_f(s2_pi, v_ph, prism_rtl::deref(n_pf).span_p)};
                    })
                        : std::tuple{prism_rtl::deref(sc_pg).ty_p, st1_pe});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::check::types::fresh_var_f(st1_pe, true, crate::check::env::sname_key_f(n_pf)));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(crate::check::types::fresh_var_f(st1_pe, false, Text::lit("")));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto st3_p7 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        if (prism_rtl::is_some(annot_od)) {
            auto&& at_pl = prism_rtl::some_of(annot_od);
            _v.set(crate::check::expr::check_f(env_p0, st2_pk, e_p4, at_pl));
            goto _done;
        }
        if (prism_rtl::is_none(annot_od)) {
            _v.set(crate::check::expr::check_f(env_p0, st2_pk, e_p4, pre_pj));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st4_p8 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        if (prism_rtl::is_some(annot_od)) {
            auto&& at_pm = prism_rtl::some_of(annot_od);
            _v.set(crate::check::types::unify::unify_f(st3_p7, pre_pj, at_pm, span_p5));
            goto _done;
        }
        if (prism_rtl::is_none(annot_od)) {
            _v.set(st3_p7);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto e_p4x = e_p4;
    auto env_p0x = env_p0;
    auto p_p2x = p_p2;
    auto span_p5x = span_p5;
    return crate::prelude::call_then(crate::check::env::traits::start_solve_wants_f(prism_rtl::deref(env_p0x).g_p, st4_p8, prism_rtl::deref(env_p0x).givens_p, false), [=](crate::check::types::St solve_wants_f_6282) {
        return ({
            auto st5_p9 = solve_wants_f_6282;
            ({
            auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p2x).kind_p);
            prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
            auto&& n_pn = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            ({
            auto name_po = crate::check::env::sname_key_f(n_pn);
            auto n_pnx = n_pn;
            (crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st5_p9, pre_pj), [=, name_po = std::move(name_po), n_pnx = std::move(n_pnx)](crate::check::types::Ty zonk_f_6573) {
            return ({
                auto t_pp = zonk_f_6573;
                (crate::prelude::call_then(crate::check::expr::patterns::start_bind_name_f(env_p0x, st5_p9, n_pnx, t_pp), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_name_f_6620) {
                return ({
                    auto [env2_ps, st7a_pt] = bind_name_f_6620;
                    auto st7_pq = crate::check::types::schemes::leave_level_f(st7a_pt);
                    auto ahead_fr = ({
                        auto env_p0xx = env_p0x;
                        auto name_pox = name_po;
                        auto pre_pjx = pre_pj;
                        auto t_ppx = t_pp;
                        auto span_p5xx = span_p5x;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>>(prism_rtl::rc([=, env_p0xx = std::move(env_p0xx), name_pox = std::move(name_pox), pre_pjx = std::move(pre_pjx), t_ppx = std::move(t_ppx), span_p5xx = std::move(span_p5xx)](crate::check::types::St p0) {
                        return ({
                            auto env_p0xxy = env_p0xx;
                            auto name_poxy = name_pox;
                            auto pre_pjxy = pre_pjx;
                            auto t_ppxy = t_ppx;
                            auto span_p5xxy = span_p5xx;
                            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xxy = std::move(env_p0xxy), name_poxy = std::move(name_poxy), pre_pjxy = std::move(pre_pjxy), t_ppxy = std::move(t_ppxy), span_p5xxy = std::move(span_p5xxy)]() {
                            return ({
                                auto s_pu = p0;
                                (prism_rtl::more(prism_rtl::rc(AheadUnify(env_p0xxy, s_pu, name_poxy, pre_pjxy, t_ppxy, span_p5xxy))));
                            });
                        })));
                        });
                    })));
                    });
                    (crate::prelude::call_then(crate::check::types::schemes::start_holds_node_f(st7_pq, t_pp), [=, ahead_fr = std::move(ahead_fr)](bool holds_node_f_6893) {
                    return holds_node_f_6893 || is_topic_name_f(name_po)
                        ? crate::prelude::call_value(ahead_fr(st7_pq), [=](crate::check::types::St ahead_6943) { return prism_rtl::finished(std::tuple{env2_ps, ahead_6943}); })
                        : ({
                        auto lambda_pv = crate::check::expr::is_lambda_f(e_p4x);
                        (crate::prelude::call_then(start_wants_above_f(st7_pq, t_pp, std::move(lambda_pv)), [=](std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St> wants_above_f_7058) {
                        return ({
                            auto [keep_p10, bounds_p11, st8_p12] = wants_above_f_7058;
                            (crate::prelude::call_then(crate::check::types::schemes::start_generalize_f(st8_p12, t_pp, keep_p10, bounds_p11), [=](std::tuple<crate::check::types::Scheme, crate::check::types::St> generalize_f_7118) {
                            return ({
                                auto [sc_p13, st9_p14] = generalize_f_7118;
                                (crate::prelude::call_value(ahead_fr(crate::check::types::recording::note_gen_f(st9_p14, prism_rtl::deref(n_pnx).span_p, name_po, sc_p13)), [=](crate::check::types::St ahead_7197) { return prism_rtl::finished(std::tuple{crate::check::expr::with_local_f(env2_ps, name_po, sc_p13), ahead_7197}); }));
                            });
                        }));
                        });
                    }));
                    });
                }));
                });
            }));
            });
        }));
        });
        })
            : ({
            auto st6_p15 = crate::check::types::schemes::leave_level_f(st5_p9);
            (crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st6_p15, pre_pj), [=](crate::check::types::Ty zonk_f_7332) { return prism_rtl::more(prism_rtl::rc(crate::check::expr::patterns::BindPattern(env_p0x, st6_p15, p_p2x, zonk_f_7332, false))); }));
        });
        });
        });
    });
}


/// `Start CheckLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_check_let_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, std::optional<crate::syntax::Type> ty_o3, crate::syntax::Expr e_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<CheckLet>(env_p0, st_p1, p_p2, ty_o3, e_p4, span_p5);
}


/// AheadUnify: unbounded fn Env, St, Text, Ty, Ty, Range -> St
crate::check::types::St ahead_unify_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& name_p2, const crate::check::types::Ty& pre_p3, const crate::check::types::Ty& t_p4, const crate::syntax::Range& span_p5) {
    auto&& _m = crate::prelude::get(env_p0.locals_p, name_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& sc0_p6 = prism_rtl::some_of(_m);
        return prism_rtl::deref(sc0_p6).ty_p != pre_p3
            ? crate::check::types::unify::unify_f(st_p1, prism_rtl::deref(sc0_p6).ty_p, t_p4, span_p5)
            : st_p1;
    }
    if (prism_rtl::is_none(_m)) {
        return st_p1;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> AheadUnify::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& name_p2 = this->name_p2;
    const auto& pre_p3 = this->pre_p3;
    const auto& t_p4 = this->t_p4;
    const auto& span_p5 = this->span_p5;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0).locals_p, name_p2);
        prism_rtl::is_some(_m) ? ({
        auto&& sc0_p6 = prism_rtl::some_of(_m);
        prism_rtl::deref(sc0_p6).ty_p != pre_p3
        ? prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st_p1, prism_rtl::deref(sc0_p6).ty_p, t_p4, span_p5)))
        : prism_rtl::finished(st_p1);
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(st_p1)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start AheadUnify, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_ahead_unify_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text name_p2, crate::check::types::Ty pre_p3, crate::check::types::Ty t_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<AheadUnify>(env_p0, st_p1, name_p2, pre_p3, t_p4, span_p5);
}


/// TypeMarks: fn Text -> Text
Text type_marks_f(const Text& marks_p0) {
    return crate::syntax::lexer::chars::has_prefix_f(marks_p0, Text::lit("&"))
        ? crate::syntax::lexer::chars::after_first_f(marks_p0)
        : marks_p0;
}


/// RefMark: fn Text -> Text
Text ref_mark_f(const Text& marks_p0) {
    return crate::syntax::lexer::chars::has_prefix_f(marks_p0, Text::lit("&"))
        ? Text::lit("&")
        : Text::lit("");
}


/// Unpend: fn Env -> Env
crate::check::expr::Env unpend_f(const crate::check::expr::Env& env_p0) {
    crate::check::expr::Env this_ = env_p0;
    this_.pending_p = Array<Text>{};
    return this_;
}


/// IsTopicName: fn Text -> Bool
bool is_topic_name_f(const Text& n_p0) {
    return (n_p0 == Text::lit("_")) || (crate::syntax::lexer::chars::drop_prefix_f(n_p0, crate::check::types::unify::marks_of_f(n_p0)) == Text::lit("_"));
}


/// WantsAbove: unbounded fn St, Ty, Bool -> (([Nat], [((Nat, Text))], St))
std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St> wants_above_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1, const bool& lambda_p2) {
    auto vs_p3 = crate::prelude::filter(crate::check::types::recording::free_vars_f(st_p0, t_p1), [&](const Nat& v_p7) { return prism_rtl::deref(crate::check::types::recording::info_of_f(st_p0, v_p7)).level_p > st_p0.level_p; });
    auto mine_p4 = crate::prelude::run_to_end(crate::prelude::filter_job(st_p0.wants_p, ({
        auto st_p0x = st_p0;
        auto vs_p3x = vs_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x), vs_p3x = std::move(vs_p3x)](crate::check::types::Want p0) {
        return ({
            auto st_p0xy = st_p0x;
            auto vs_p3xy = vs_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy), vs_p3xy = std::move(vs_p3xy)]() {
            return ({
                auto w_p8 = p0;
                (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0xy, prism_rtl::deref(w_p8).ty_p), [=](crate::check::types::Ty walk_f_8433) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_f_8433) ? ({
                    auto&& n_p9 = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_f_8433).a0;
                    prism_rtl::finished(crate::check::types::has_nat_f(vs_p3xy, n_p9));
                })
                    : prism_rtl::finished(false);
                });
            }));
            });
        })));
        });
    })));
    })));
    auto others_p5 = crate::prelude::filter(st_p0.wants_p, [&](const crate::check::types::Want& w_pa) { return !crate::check::types::has_text_f(crate::prelude::each(mine_p4, [&](const crate::check::types::Want& m_pb) { return crate::prelude::show_text(m_pb); }), crate::prelude::show_text(w_pa)); });
    auto constrained_p6 = crate::prelude::run_to_end(crate::prelude::fold_job(mine_p4, Array<Nat>{}, ({
        auto st_p0x = st_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Want>)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](std::tuple<Array<Nat>, crate::check::types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_p0xy = st_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
            return ({
                auto acc_pc = p0;
                auto w_pd = p1;
                (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0xy, prism_rtl::deref(w_pd).ty_p), [=, acc_pc = std::move(acc_pc)](crate::check::types::Ty walk_f_8647) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_f_8647) ? ({
                    auto&& n_pe = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_f_8647).a0;
                    prism_rtl::finished(crate::check::types::add_nat_f(acc_pc, n_pe));
                })
                    : prism_rtl::finished(acc_pc);
                });
            }));
            });
        })));
        });
    })));
    })));
    return lambda_p2
        ? ({
        auto bounds_pf = crate::prelude::run_to_end(crate::prelude::fold_job(mine_p4, Array<std::tuple<Nat, Text>>{}, ({
            auto st_p0x = st_p0;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Nat, Text>>>(std::tuple<Array<std::tuple<Nat, Text>>, crate::check::types::Want>)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](std::tuple<Array<std::tuple<Nat, Text>>, crate::check::types::Want> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto acc_pi = p0;
                    auto w_pj = p1;
                    (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0xy, prism_rtl::deref(w_pj).ty_p), [=, acc_pi = std::move(acc_pi)](crate::check::types::Ty walk_f_8786) {
                    return ({
                        prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_f_8786) ? ({
                        auto&& n_pk = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_f_8786).a0;
                        crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(w_pj).cls_p, Text::lit("Range "))
                        ? prism_rtl::finished(acc_pi)
                        : prism_rtl::finished(crate::prelude::push(acc_pi, std::tuple{n_pk, prism_rtl::deref(w_pj).cls_p}));
                    })
                        : prism_rtl::finished(acc_pi);
                    });
                }));
                });
            })));
            });
        }));
        })));
        auto st1_pg = crate::prelude::fold(mine_p4, st_p0, [&](const crate::check::types::St& s_pl, const crate::check::types::Want& w_pm) { return crate::check::types::recording::note_choice_f(crate::check::types::recording::note_impl_f(s_pl, prism_rtl::deref(w_pm).file_p, prism_rtl::deref(w_pm).span_p, prism_rtl::deref(w_pm).cls_p, prism_rtl::deref(w_pm).ty_p, Text::lit("quantified")), prism_rtl::deref(w_pm).file_p, prism_rtl::deref(w_pm).span_p, prism_rtl::deref(w_pm).cls_p, Text::lit("any")); });
        auto st2_ph = ({
            crate::check::types::St this_ = st1_pg;
            this_.wants_p = others_p5;
            (std::move(this_));
        });
        std::tuple{Array<Nat>{}, bounds_pf, st2_ph};
    })
        : ({
        auto st2_pn = crate::check::types::unify::lower_levels_f(st_p0, constrained_p6, st_p0.level_p);
        std::tuple{constrained_p6, Array<std::tuple<Nat, Text>>{}, st2_pn};
    });
}


prism_rtl::Turn<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St>> WantsAbove::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    const auto& lambda_p2 = this->lambda_p2;
    auto lambda_p2x = prism_rtl::deref(lambda_p2);
    auto st_p0x = st_p0;
    auto t_p1x = t_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_free_vars_f(st_p0x, t_p1x), [=](Array<Nat> free_vars_f_8336) {
        return ({
            auto vs_p3 = crate::prelude::filter(free_vars_f_8336, [&](const Nat& v_p7) { return prism_rtl::deref(crate::check::types::recording::info_of_f(st_p0x, v_p7)).level_p > prism_rtl::deref(st_p0x).level_p; });
            (crate::prelude::call_value(crate::prelude::filter_job(prism_rtl::deref(st_p0x).wants_p, ({
            auto st_p0xx = st_p0x;
            auto vs_p3x = vs_p3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx), vs_p3x = std::move(vs_p3x)](crate::check::types::Want p0) {
            return ({
                auto st_p0xxy = st_p0xx;
                auto vs_p3xy = vs_p3x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy), vs_p3xy = std::move(vs_p3xy)]() {
                return ({
                    auto w_p8 = p0;
                    (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0xxy, prism_rtl::deref(w_p8).ty_p), [=](crate::check::types::Ty walk_f_8433) {
                    return ({
                        prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_f_8433) ? ({
                        auto&& n_p9 = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_f_8433).a0;
                        prism_rtl::finished(crate::check::types::has_nat_f(vs_p3xy, n_p9));
                    })
                        : prism_rtl::finished(false);
                    });
                }));
                });
            })));
            });
        })));
        })), [=](Array<crate::check::types::Want> filter_8405) {
            return ({
                auto mine_p4 = filter_8405;
                auto others_p5 = crate::prelude::filter(prism_rtl::deref(st_p0x).wants_p, [&](const crate::check::types::Want& w_pa) { return !crate::check::types::has_text_f(crate::prelude::each(mine_p4, [&](const crate::check::types::Want& m_pb) { return crate::prelude::show_text(m_pb); }), crate::prelude::show_text(w_pa)); });
                (crate::prelude::call_value(crate::prelude::fold_job(mine_p4, Array<Nat>{}, ({
                auto st_p0xx = st_p0x;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Want>)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](std::tuple<Array<Nat>, crate::check::types::Want> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto st_p0xxy = st_p0xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
                    return ({
                        auto acc_pc = p0;
                        auto w_pd = p1;
                        (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0xxy, prism_rtl::deref(w_pd).ty_p), [=, acc_pc = std::move(acc_pc)](crate::check::types::Ty walk_f_8647) {
                        return ({
                            prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_f_8647) ? ({
                            auto&& n_pe = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_f_8647).a0;
                            prism_rtl::finished(crate::check::types::add_nat_f(acc_pc, n_pe));
                        })
                            : prism_rtl::finished(acc_pc);
                        });
                    }));
                    });
                })));
                });
            })));
            })), [=, others_p5 = std::move(others_p5)](Array<Nat> fold_8614) {
                return ({
                    auto constrained_p6 = fold_8614;
                    lambda_p2x
                    ? crate::prelude::call_value(crate::prelude::fold_job(mine_p4, Array<std::tuple<Nat, Text>>{}, ({
                    auto st_p0xx = st_p0x;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Nat, Text>>>(std::tuple<Array<std::tuple<Nat, Text>>, crate::check::types::Want>)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](std::tuple<Array<std::tuple<Nat, Text>>, crate::check::types::Want> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto st_p0xxy = st_p0xx;
                        (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
                        return ({
                            auto acc_pi = p0;
                            auto w_pj = p1;
                            (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0xxy, prism_rtl::deref(w_pj).ty_p), [=, acc_pi = std::move(acc_pi)](crate::check::types::Ty walk_f_8786) {
                            return ({
                                prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_f_8786) ? ({
                                auto&& n_pk = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_f_8786).a0;
                                crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(w_pj).cls_p, Text::lit("Range "))
                                ? prism_rtl::finished(acc_pi)
                                : prism_rtl::finished(crate::prelude::push(acc_pi, std::tuple{n_pk, prism_rtl::deref(w_pj).cls_p}));
                            })
                                : prism_rtl::finished(acc_pi);
                            });
                        }));
                        });
                    })));
                    });
                }));
                })), [=](Array<std::tuple<Nat, Text>> fold_8753) {
                    return ({
                        auto bounds_pf = fold_8753;
                        auto st1_pg = crate::prelude::fold(mine_p4, st_p0x, [&](const crate::check::types::St& s_pl, const crate::check::types::Want& w_pm) { return crate::check::types::recording::note_choice_f(crate::check::types::recording::note_impl_f(s_pl, prism_rtl::deref(w_pm).file_p, prism_rtl::deref(w_pm).span_p, prism_rtl::deref(w_pm).cls_p, prism_rtl::deref(w_pm).ty_p, Text::lit("quantified")), prism_rtl::deref(w_pm).file_p, prism_rtl::deref(w_pm).span_p, prism_rtl::deref(w_pm).cls_p, Text::lit("any")); });
                        auto st2_ph = ({
                            crate::check::types::St this_ = st1_pg;
                            this_.wants_p = others_p5;
                            (std::move(this_));
                        });
                        (prism_rtl::finished(std::tuple{Array<Nat>{}, bounds_pf, st2_ph}));
                    });
                })
                    : ({
                    auto st2_pn = crate::check::types::unify::lower_levels_f(st_p0x, constrained_p6, prism_rtl::deref(st_p0x).level_p);
                    (prism_rtl::finished(std::tuple{constrained_p6, Array<std::tuple<Nat, Text>>{}, st2_pn}));
                });
                });
            }));
            });
        }));
        });
    });
}


/// `Start WantsAbove, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St>> start_wants_above_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1, bool lambda_p2) {
    return prism_rtl::make_rc<WantsAbove>(st_p0, t_p1, lambda_p2);
}


/// CheckLocalFn: unbounded fn Env, St, FnClause, Range -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> check_local_fn_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::decls::FnClause& f_p2, const crate::syntax::Range& span_p3) {
    auto name_p4 = crate::check::env::def_name_text_f(f_p2.name_p);
    auto&& _m = crate::prelude::get(env_p0.locals_p, name_p4);
    if (prism_rtl::is_some(_m)) {
        auto&& sc_p5 = prism_rtl::some_of(_m);
        return ((crate::prelude::len(prism_rtl::deref(sc_p5).qs_p) > Nat(0u)) || (crate::prelude::len(prism_rtl::deref(sc_p5).cqs_p) > Nat(0u))) || (!crate::check::types::is_flex_var_f(st_p1, prism_rtl::deref(sc_p5).ty_p))
            ? ({
            auto st2_p6 = check_clauses_f(env_p0, st_p1, name_p4, Array(std::vector{f_p2}), sc_p5, span_p3);
            std::tuple{env_p0, st2_p6};
        })
            : ({
            auto st0_p7 = crate::check::types::schemes::enter_level_f(st_p1);
            auto [lt_pc, st1_pd] = clause_lambda_f(env_p0, st0_p7, f_p2);
            auto st2_p8 = crate::check::types::unify::unify_f(st1_pd, prism_rtl::deref(sc_p5).ty_p, lt_pc, span_p3);
            auto st3_p9 = crate::check::env::traits::solve_wants_f(env_p0.g_p, st2_p8, env_p0.givens_p, false);
            auto st4_pa = crate::check::types::schemes::leave_level_f(st3_p9);
            auto t_pb = crate::check::types::recording::zonk_f(st4_pa, prism_rtl::deref(sc_p5).ty_p);
            (crate::check::types::schemes::holds_node_f(st4_pa, t_pb)
            ? std::tuple{env_p0, st4_pa}
            : ({
            auto [keep_pe, bounds_pf, st5_pg] = wants_above_f(st4_pa, t_pb, true);
            auto [sc2_ph, st6_pi] = crate::check::types::schemes::generalize_f(st5_pg, t_pb, keep_pe, bounds_pf);
            std::tuple{crate::check::expr::with_local_f(env_p0, name_p4, sc2_ph), st6_pi};
        }));
        });
    }
    if (prism_rtl::is_none(_m)) {
        return std::tuple{env_p0, st_p1};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> CheckLocalFn::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& f_p2 = this->f_p2;
    const auto& span_p3 = this->span_p3;
    auto name_p4 = crate::check::env::def_name_text_f(prism_rtl::deref(f_p2).name_p);
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0).locals_p, name_p4);
        prism_rtl::is_some(_m) ? ({
        auto&& sc_p5 = prism_rtl::some_of(_m);
        ((crate::prelude::len(prism_rtl::deref(sc_p5).qs_p) > Nat(0u)) || (crate::prelude::len(prism_rtl::deref(sc_p5).cqs_p) > Nat(0u))) || (!crate::check::types::is_flex_var_f(st_p1, prism_rtl::deref(sc_p5).ty_p))
        ? ({
        auto env_p0x = env_p0;
        auto f_p2x = f_p2;
        auto span_p3x = span_p3;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_check_clauses_f(env_p0x, st_p1x, name_p4, Array(std::vector{f_p2x}), sc_p5, span_p3x), [=](crate::check::types::St check_clauses_f_9674) {
        return ({
            auto st2_p6 = check_clauses_f_9674;
            (prism_rtl::finished(std::tuple{env_p0x, st2_p6}));
        });
    }));
    })
        : ({
        auto st0_p7 = crate::check::types::schemes::enter_level_f(st_p1);
        auto env_p0x = env_p0;
        auto f_p2x = f_p2;
        auto span_p3x = span_p3;
        (crate::prelude::call_then(start_clause_lambda_f(env_p0x, st0_p7, f_p2x), [=, span_p3x = std::move(span_p3x)](std::tuple<crate::check::types::Ty, crate::check::types::St> clause_lambda_f_9839) {
        return ({
            auto [lt_pc, st1_pd] = clause_lambda_f_9839;
            (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st1_pd, prism_rtl::deref(sc_p5).ty_p, lt_pc, span_p3x), [=](crate::check::types::St unify_f_9890) {
            return ({
                auto st2_p8 = unify_f_9890;
                (crate::prelude::call_then(crate::check::env::traits::start_solve_wants_f(prism_rtl::deref(env_p0x).g_p, st2_p8, prism_rtl::deref(env_p0x).givens_p, false), [=](crate::check::types::St solve_wants_f_9943) {
                return ({
                    auto st3_p9 = solve_wants_f_9943;
                    auto st4_pa = crate::check::types::schemes::leave_level_f(st3_p9);
                    (crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st4_pa, prism_rtl::deref(sc_p5).ty_p), [=](crate::check::types::Ty zonk_f_10049) {
                    return ({
                        auto t_pb = zonk_f_10049;
                        (crate::prelude::call_then(crate::check::types::schemes::start_holds_node_f(st4_pa, t_pb), [=](bool holds_node_f_10084) {
                        return holds_node_f_10084
                            ? prism_rtl::finished(std::tuple{env_p0x, st4_pa})
                            : crate::prelude::call_then(start_wants_above_f(st4_pa, t_pb, true), [=](std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St> wants_above_f_10185) {
                            return ({
                                auto [keep_pe, bounds_pf, st5_pg] = wants_above_f_10185;
                                (crate::prelude::call_then(crate::check::types::schemes::start_generalize_f(st5_pg, t_pb, keep_pe, bounds_pf), [=](std::tuple<crate::check::types::Scheme, crate::check::types::St> generalize_f_10248) {
                                return ({
                                    auto [sc2_ph, st6_pi] = generalize_f_10248;
                                    (prism_rtl::finished(std::tuple{crate::check::expr::with_local_f(env_p0x, name_p4, sc2_ph), st6_pi}));
                                });
                            }));
                            });
                        });
                    }));
                    });
                }));
                });
            }));
            });
        }));
        });
    }));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{env_p0, st_p1})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CheckLocalFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_check_local_fn_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::decls::FnClause f_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<CheckLocalFn>(env_p0, st_p1, f_p2, span_p3);
}


/// ClauseLambda: unbounded fn Env, St, FnClause -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> clause_lambda_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::decls::FnClause& f_p2) {
    auto body_p3 = ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::LambdaBody> _v;
        auto&& _m = f_p2.body_p;
        if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(_m)) {
            auto&& e_p4 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(_m).a0;
            _v.set(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(e_p4)}));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m)) {
            auto&& b_p5 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
            _v.set(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbBlock{b_p5}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::check::expr::calls::infer_lambda_f(env_p0, st_p1, crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELambda{std::optional(f_p2.params_p), prism_rtl::rc(body_p3)})), .span_p = f_p2.span_p}, std::optional<crate::check::types::Ty>{});
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> ClauseLambda::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& f_p2 = this->f_p2;
    auto body_p3 = ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::LambdaBody> _v;
        auto&& _m = prism_rtl::deref(f_p2).body_p;
        if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(_m)) {
            auto&& e_p4 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(_m).a0;
            _v.set(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(e_p4)}));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m)) {
            auto&& b_p5 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
            _v.set(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbBlock{b_p5}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::InferLambda(env_p0, st_p1, crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELambda{std::optional(prism_rtl::deref(f_p2).params_p), prism_rtl::rc(body_p3)})), .span_p = prism_rtl::deref(f_p2).span_p}, std::optional<crate::check::types::Ty>{})));
}


/// `Start ClauseLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_clause_lambda_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::decls::FnClause f_p2) {
    return prism_rtl::make_rc<ClauseLambda>(env_p0, st_p1, f_p2);
}


/// CheckClauses: unbounded fn Env, St, Text, [FnClause], Scheme, Range -> St
crate::check::types::St check_clauses_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& name_p2, const Array<crate::syntax::decls::FnClause>& clauses_p3, const crate::check::types::Scheme& sc_p4, const crate::syntax::Range& span_p5) {
    auto t_p6 = crate::check::types::schemes::skolemize_f(sc_p4);
    auto givens_p7 = crate::prelude::append(env_p0.givens_p, sc_p4.bounds_p);
    auto env2_p8 = ({
        crate::check::expr::Env this_ = env_p0;
        this_.givens_p = givens_p7;
        this_.mark_p = crate::syntax::lexer::chars::head_f(crate::check::types::unify::marks_of_f(name_p2));
        this_.def_name_p = name_p2;
        (std::move(this_));
    });
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p6)) {
        auto&& col_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p6).a0;
        auto&& params_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p6).a1;
        auto&& res_pb = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p6).a2;
        auto outer_color_pc = st_p1.color_p;
        auto outer_flex_pd = st_p1.color_flex_p;
        auto st0_pe = ({
            crate::check::types::St this_ = st_p1;
            this_.color_p = crate::check::types::Col(crate::check::types::Col::CBound{});
            this_.color_why_p = Text::lit("");
            this_.color_flex_p = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
            this_.col_up_p = crate::prelude::fold(sc_p4.cjoins_p, this_.col_up_p, [&](const Map<Text, Text>& m_pk, const std::tuple<Text, Text>& _p1) {
                auto&& lo_pl = std::get<0>(_p1);
                auto&& hi_pm = std::get<1>(_p1);
                return crate::prelude::insert(m_pk, lo_pl, hi_pm);
            });
            (std::move(this_));
        });
        auto st1_pf = crate::prelude::run_to_end(crate::prelude::fold_job(clauses_p3, st0_pe, ({
            auto env2_p8x = env2_p8;
            auto params_pax = params_pa;
            auto res_pbx = prism_rtl::deref(prism_rtl::deref(res_pb));
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, env2_p8x = std::move(env2_p8x), params_pax = std::move(params_pax), res_pbx = std::move(res_pbx)](std::tuple<crate::check::types::St, crate::syntax::decls::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env2_p8xy = env2_p8x;
                auto params_paxy = params_pax;
                auto res_pbxy = res_pbx;
                (crate::prelude::entered(crate::prelude::once_job([=, env2_p8xy = std::move(env2_p8xy), params_paxy = std::move(params_paxy), res_pbxy = std::move(res_pbxy)]() {
                return ({
                    auto s_pn = p0;
                    auto c_po = p1;
                    (prism_rtl::more(prism_rtl::rc(CheckClause(env2_p8xy, s_pn, c_po, params_paxy, res_pbxy))));
                });
            })));
            });
        })));
        })));
        auto st1b_pg = crate::check::types::colors::settle_body_f(crate::check::env::traits::solve_wants_f(env_p0.g_p, st1_pf, givens_p7, false), col_p9, name_p2);
        auto st2_ph = crate::check::passes::clause_coverage_f(env2_p8, st1b_pg, clauses_p3, params_pa, span_p5);
        auto st3_pi = crate::check::types::colors::col_leq_f(prism_rtl::deref(st2_ph).color_p, col_p9)
            ? st2_ph
            : crate::check::types::recording::err_fix_f(st2_ph, Text::lit("calls-unbounded"), span_p5, prism_rtl::cat(crate::check::types::colors::col_word_f(col_p9), " `", name_p2, "` calls ", crate::check::types::colors::col_word_f(prism_rtl::deref(st2_ph).color_p), " `", prism_rtl::deref(st2_ph).color_why_p, "`"), prism_rtl::cat("mark `", name_p2, "` `unbounded fn`, or run the call through `@Run`"));
        auto st4_pj = crate::check::types::recording::note_fn_f(st3_pi, span_p5, name_p2, col_p9, prism_rtl::deref(st2_ph).color_p);
        crate::check::types::St this_ = st4_pj;
        this_.color_p = outer_color_pc;
        this_.color_flex_p = outer_flex_pd;
        return this_;
    }
    {
        auto&& other_pp = t_p6;
        auto st1_pq = crate::prelude::run_to_end(crate::prelude::fold_job(clauses_p3, st_p1, ({
            auto env2_p8x = env2_p8;
            auto other_ppx = other_pp;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, env2_p8x = std::move(env2_p8x), other_ppx = std::move(other_ppx)](std::tuple<crate::check::types::St, crate::syntax::decls::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env2_p8xy = env2_p8x;
                auto other_ppxy = other_ppx;
                (crate::prelude::entered(crate::prelude::once_job([=, env2_p8xy = std::move(env2_p8xy), other_ppxy = std::move(other_ppxy)]() {
                return ({
                    auto s_pr = p0;
                    auto c_ps = p1;
                    (prism_rtl::more(prism_rtl::rc(CheckClause(env2_p8xy, s_pr, c_ps, Array<crate::check::types::Ty>{}, other_ppxy))));
                });
            })));
            });
        })));
        })));
        return st1_pq;
    }
}


prism_rtl::Turn<crate::check::types::St> CheckClauses::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& name_p2 = this->name_p2;
    const auto& clauses_p3 = this->clauses_p3;
    const auto& sc_p4 = this->sc_p4;
    const auto& span_p5 = this->span_p5;
    auto clauses_p3x = clauses_p3;
    auto env_p0x = env_p0;
    auto name_p2x = name_p2;
    auto sc_p4x = sc_p4;
    auto span_p5x = span_p5;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(crate::check::types::schemes::start_skolemize_f(sc_p4x), [=](crate::check::types::Ty skolemize_f_11216) {
        return ({
            auto t_p6 = skolemize_f_11216;
            auto givens_p7 = crate::prelude::append(prism_rtl::deref(env_p0x).givens_p, prism_rtl::deref(sc_p4x).bounds_p);
            auto env2_p8 = ({
                crate::check::expr::Env this_ = env_p0x;
                this_.givens_p = givens_p7;
                this_.mark_p = crate::syntax::lexer::chars::head_f(crate::check::types::unify::marks_of_f(name_p2x));
                this_.def_name_p = name_p2x;
                (std::move(this_));
            });
            ({
            prism_rtl::is<crate::check::types::Ty::TyFn>(t_p6) ? ({
            auto&& col_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p6).a0;
            auto&& params_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p6).a1;
            auto&& res_pb = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p6).a2;
            ({
            auto outer_color_pc = prism_rtl::deref(st_p1x).color_p;
            auto outer_flex_pd = prism_rtl::deref(st_p1x).color_flex_p;
            auto st0_pe = ({
                crate::check::types::St this_ = st_p1x;
                this_.color_p = crate::check::types::Col(crate::check::types::Col::CBound{});
                this_.color_why_p = Text::lit("");
                this_.color_flex_p = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
                this_.col_up_p = crate::prelude::fold(prism_rtl::deref(sc_p4x).cjoins_p, this_.col_up_p, [&](const Map<Text, Text>& m_pk, const std::tuple<Text, Text>& _p1) {
                    auto&& lo_pl = std::get<0>(_p1);
                    auto&& hi_pm = std::get<1>(_p1);
                    return crate::prelude::insert(m_pk, lo_pl, hi_pm);
                });
                (std::move(this_));
            });
            auto col_p9x = col_p9;
            auto params_pax = params_pa;
            auto res_pbx = prism_rtl::deref(prism_rtl::deref(res_pb));
            (crate::prelude::call_value(crate::prelude::fold_job(clauses_p3x, st0_pe, ({
            auto env2_p8x = env2_p8;
            auto params_paxx = params_pax;
            auto res_pbxx = res_pbx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, env2_p8x = std::move(env2_p8x), params_paxx = std::move(params_paxx), res_pbxx = std::move(res_pbxx)](std::tuple<crate::check::types::St, crate::syntax::decls::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env2_p8xy = env2_p8x;
                auto params_paxxy = params_paxx;
                auto res_pbxxy = res_pbxx;
                (crate::prelude::entered(crate::prelude::once_job([=, env2_p8xy = std::move(env2_p8xy), params_paxxy = std::move(params_paxxy), res_pbxxy = std::move(res_pbxxy)]() {
                return ({
                    auto s_pn = p0;
                    auto c_po = p1;
                    (prism_rtl::more(prism_rtl::rc(CheckClause(env2_p8xy, s_pn, c_po, params_paxxy, res_pbxxy))));
                });
            })));
            });
        })));
        })), [=, outer_color_pc = std::move(outer_color_pc), outer_flex_pd = std::move(outer_flex_pd), col_p9x = std::move(col_p9x)](crate::check::types::St fold_11768) {
            return ({
                auto st1_pf = fold_11768;
                (crate::prelude::call_then(crate::check::env::traits::start_solve_wants_f(prism_rtl::deref(env_p0x).g_p, st1_pf, givens_p7, false), [=](crate::check::types::St solve_wants_f_11866) {
                return crate::prelude::call_then(crate::check::types::colors::start_settle_body_f(solve_wants_f_11866, col_p9x, name_p2x), [=](crate::check::types::St settle_body_f_11854) {
                    return ({
                        auto st1b_pg = settle_body_f_11854;
                        (crate::prelude::call_then(crate::check::passes::start_clause_coverage_f(env2_p8, st1b_pg, clauses_p3x, params_pax, span_p5x), [=](crate::check::types::St clause_coverage_f_11937) {
                        return ({
                            auto st2_ph = clause_coverage_f_11937;
                            auto st3_pi = crate::check::types::colors::col_leq_f(prism_rtl::deref(st2_ph).color_p, col_p9x)
                                ? st2_ph
                                : crate::check::types::recording::err_fix_f(st2_ph, Text::lit("calls-unbounded"), span_p5x, prism_rtl::cat(crate::check::types::colors::col_word_f(col_p9x), " `", name_p2x, "` calls ", crate::check::types::colors::col_word_f(prism_rtl::deref(st2_ph).color_p), " `", prism_rtl::deref(st2_ph).color_why_p, "`"), prism_rtl::cat("mark `", name_p2x, "` `unbounded fn`, or run the call through `@Run`"));
                            auto st4_pj = crate::check::types::recording::note_fn_f(st3_pi, span_p5x, name_p2x, col_p9x, prism_rtl::deref(st2_ph).color_p);
                            (prism_rtl::finished(({
                            crate::check::types::St this_ = st4_pj;
                            this_.color_p = outer_color_pc;
                            this_.color_flex_p = outer_flex_pd;
                            (std::move(this_));
                        })));
                        });
                    }));
                    });
                });
            }));
            });
        }));
        });
        })
            : ({
            auto&& other_pp = t_p6;
            ({
            auto other_ppx = other_pp;
            (crate::prelude::call_value(crate::prelude::fold_job(clauses_p3x, st_p1x, ({
            auto env2_p8x = env2_p8;
            auto other_ppxx = other_ppx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, env2_p8x = std::move(env2_p8x), other_ppxx = std::move(other_ppxx)](std::tuple<crate::check::types::St, crate::syntax::decls::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env2_p8xy = env2_p8x;
                auto other_ppxxy = other_ppxx;
                (crate::prelude::entered(crate::prelude::once_job([=, env2_p8xy = std::move(env2_p8xy), other_ppxxy = std::move(other_ppxxy)]() {
                return ({
                    auto s_pr = p0;
                    auto c_ps = p1;
                    (prism_rtl::more(prism_rtl::rc(CheckClause(env2_p8xy, s_pr, c_ps, Array<crate::check::types::Ty>{}, other_ppxxy))));
                });
            })));
            });
        })));
        })), [=](crate::check::types::St fold_12432) {
            return ({
                auto st1_pq = fold_12432;
                (prism_rtl::finished(st1_pq));
            });
        }));
        });
        });
        });
        });
    });
}


/// `Start CheckClauses, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_clauses_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text name_p2, Array<crate::syntax::decls::FnClause> clauses_p3, crate::check::types::Scheme sc_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<CheckClauses>(env_p0, st_p1, name_p2, clauses_p3, sc_p4, span_p5);
}


/// CheckClause: unbounded fn Env, St, FnClause, [Ty], Ty -> St
crate::check::types::St check_clause_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::decls::FnClause& c_p2, const Array<crate::check::types::Ty>& params_p3, const crate::check::types::Ty& res_p4) {
    return crate::prelude::len(c_p2.params_p) != crate::prelude::len(params_p3)
        ? crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), c_p2.span_p, prism_rtl::cat("this clause takes ", crate::check::errors::count_word_f(crate::prelude::len(c_p2.params_p)), " parameter", crate::prelude::len(c_p2.params_p) == Nat(1u)
        ? Text::lit("")
        : Text::lit("s"), "; the signature has ", crate::check::errors::count_word_f(crate::prelude::len(params_p3))))
        : ({
        auto [env2_p8, st1_p9] = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(params_p3)), std::tuple{env_p0, st_p1}, ({
            auto c_p2x = c_p2;
            auto params_p3x = params_p3;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, c_p2x = std::move(c_p2x), params_p3x = std::move(params_p3x)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto c_p2xy = c_p2x;
                auto params_p3xy = params_p3x;
                (crate::prelude::entered(crate::prelude::once_job([=, c_p2xy = std::move(c_p2xy), params_p3xy = std::move(params_p3xy)]() {
                return ({
                    auto [en_p5, s_p6] = p0;
                    auto i_p7 = p1;
                    (prism_rtl::more(prism_rtl::rc(crate::check::expr::patterns::BindPattern(en_p5, s_p6, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p2xy).params_p, i_p7), crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span_p = prism_rtl::deref(c_p2xy).span_p}), crate::prelude::or_(crate::prelude::index(params_p3xy, i_p7), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), true))));
                });
            })));
            });
        }));
        })));
        check_body_f(env2_p8, st1_p9, c_p2.body_p, res_p4);
    });
}


prism_rtl::Turn<crate::check::types::St> CheckClause::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& c_p2 = this->c_p2;
    const auto& params_p3 = this->params_p3;
    const auto& res_p4 = this->res_p4;
    return crate::prelude::len(prism_rtl::deref(c_p2).params_p) != crate::prelude::len(params_p3)
        ? prism_rtl::finished(crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), prism_rtl::deref(c_p2).span_p, prism_rtl::cat("this clause takes ", crate::check::errors::count_word_f(crate::prelude::len(prism_rtl::deref(c_p2).params_p)), " parameter", crate::prelude::len(prism_rtl::deref(c_p2).params_p) == Nat(1u)
        ? Text::lit("")
        : Text::lit("s"), "; the signature has ", crate::check::errors::count_word_f(crate::prelude::len(params_p3)))))
        : ({
        auto c_p2x = c_p2;
        auto env_p0x = env_p0;
        auto params_p3x = params_p3;
        auto res_p4x = res_p4;
        auto st_p1x = st_p1;
        (crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(params_p3x)), std::tuple{env_p0x, st_p1x}, ({
        auto c_p2xx = c_p2x;
        auto params_p3xx = params_p3x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, c_p2xx = std::move(c_p2xx), params_p3xx = std::move(params_p3xx)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto c_p2xxy = c_p2xx;
            auto params_p3xxy = params_p3xx;
            (crate::prelude::entered(crate::prelude::once_job([=, c_p2xxy = std::move(c_p2xxy), params_p3xxy = std::move(params_p3xxy)]() {
            return ({
                auto [en_p5, s_p6] = p0;
                auto i_p7 = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::expr::patterns::BindPattern(en_p5, s_p6, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p2xxy).params_p, i_p7), crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span_p = prism_rtl::deref(c_p2xxy).span_p}), crate::prelude::or_(crate::prelude::index(params_p3xxy, i_p7), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), true))));
            });
        })));
        });
    }));
    })), [=, res_p4x = std::move(res_p4x)](std::tuple<crate::check::expr::Env, crate::check::types::St> fold_12863) {
        return ({
            auto [env2_p8, st1_p9] = fold_12863;
            (prism_rtl::more(prism_rtl::rc(CheckBody(env2_p8, st1_p9, prism_rtl::deref(c_p2x).body_p, res_p4x))));
        });
    }));
    });
}


/// `Start CheckClause, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_clause_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::decls::FnClause c_p2, Array<crate::check::types::Ty> params_p3, crate::check::types::Ty res_p4) {
    return prism_rtl::make_rc<CheckClause>(env_p0, st_p1, c_p2, params_p3, res_p4);
}


/// CheckBody: unbounded fn Env, St, FnBody, Ty -> St
crate::check::types::St check_body_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::decls::FnBody& body_p2, const crate::check::types::Ty& res_p3) {
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(body_p2)) {
        auto&& e_p4 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(body_p2).a0;
        return crate::check::expr::check_f(env_p0, st_p1, e_p4, res_p3);
    }
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(body_p2)) {
        auto&& b_p5 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(body_p2).a0;
        return env_p0.mark_p == Text::lit("@")
            ? ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            auto&& _m = crate::check::types::recording::walk_f(st_p1, res_p3);
            if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
                auto&& inner_p6 = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
                auto&& rw_p7 = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a1;
                _v.set(({
                    auto env2_p8 = ({
                        crate::check::expr::Env this_ = env_p0;
                        this_.scope_p = rw_p7;
                        (std::move(this_));
                    });
                    auto [t_p9, st2_pa] = crate::check::blocks::infer_widget_block_f(env2_p8, st_p1, b_p5);
                    (crate::check::types::unify::unify_f(st2_pa, prism_rtl::deref(inner_p6), t_p9, prism_rtl::deref(b_p5).span_p));
                }));
                goto _done;
            }
            {
                auto&& other_pb = _m;
                _v.set(crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), prism_rtl::deref(b_p5).span_p, prism_rtl::cat("a widget block builds a blueprint; the signature says `", crate::check::types::show_ty_f(st_p1, other_pb), "`")));
                goto _done;
            }
        _done:
            _v.take();
        })
            : (env_p0.mark_p == Text::lit("?")) || (env_p0.mark_p == Text::lit("~"))
            ? ({
            auto [t_pc, st2_pd] = crate::check::blocks::structure::infer_given_block_f(env_p0, st_p1, b_p5, env_p0.mark_p);
            (crate::check::types::unify::unify_f(st2_pd, res_p3, t_pc, prism_rtl::deref(b_p5).span_p));
        })
            : ({
            auto [t_pe, st2_pf] = infer_expr_block_f(env_p0, st_p1, b_p5);
            (crate::check::types::unify::unify_f(st2_pf, res_p3, t_pe, prism_rtl::deref(b_p5).span_p));
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> CheckBody::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& body_p2 = this->body_p2;
    const auto& res_p3 = this->res_p3;
    return ({
        prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(body_p2) ? ({
        auto&& e_p4 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(body_p2).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env_p0, st_p1, e_p4, res_p3)));
    })
        : prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(body_p2) ? ({
        auto&& b_p5 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(body_p2).a0;
        prism_rtl::deref(env_p0).mark_p == Text::lit("@")
        ? ({
        auto b_p5x = b_p5;
        auto env_p0x = env_p0;
        auto res_p3x = res_p3;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x, res_p3x), [=, b_p5x = std::move(b_p5x), env_p0x = std::move(env_p0x)](crate::check::types::Ty walk_f_13433) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyAt>(walk_f_13433) ? ({
            auto&& inner_p6 = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_f_13433).a0;
            auto&& rw_p7 = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_f_13433).a1;
            ({
            auto env2_p8 = ({
                crate::check::expr::Env this_ = env_p0x;
                this_.scope_p = rw_p7;
                (std::move(this_));
            });
            (crate::prelude::call_then(crate::check::blocks::start_infer_widget_block_f(env2_p8, st_p1x, b_p5x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block_f_13598) {
            return ({
                auto [t_p9, st2_pa] = infer_widget_block_f_13598;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st2_pa, prism_rtl::deref(inner_p6), t_p9, prism_rtl::deref(b_p5x).span_p))));
            });
        }));
        });
        })
            : ({
            auto&& other_pb = walk_f_13433;
            crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x, other_pb), [=](Text show_ty_f_13783) { return prism_rtl::finished(crate::check::types::recording::err_f(st_p1x, Text::lit("mismatch"), prism_rtl::deref(b_p5x).span_p, prism_rtl::cat("a widget block builds a blueprint; the signature says `", show_ty_f_13783, "`"))); });
        });
        });
    }));
    })
        : (prism_rtl::deref(env_p0).mark_p == Text::lit("?")) || (prism_rtl::deref(env_p0).mark_p == Text::lit("~"))
        ? ({
        auto b_p5x = b_p5;
        auto env_p0x = env_p0;
        auto res_p3x = res_p3;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::blocks::structure::start_infer_given_block_f(env_p0x, st_p1x, b_p5x, prism_rtl::deref(env_p0x).mark_p), [=, res_p3x = std::move(res_p3x)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_given_block_f_13885) {
        return ({
            auto [t_pc, st2_pd] = infer_given_block_f_13885;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st2_pd, res_p3x, t_pc, prism_rtl::deref(b_p5x).span_p))));
        });
    }));
    })
        : ({
        auto b_p5x = b_p5;
        auto env_p0x = env_p0;
        auto res_p3x = res_p3;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_infer_expr_block_f(env_p0x, st_p1x, b_p5x), [=, res_p3x = std::move(res_p3x)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_f_14003) {
        return ({
            auto [t_pe, st2_pf] = infer_expr_block_f_14003;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st2_pf, res_p3x, t_pe, prism_rtl::deref(b_p5x).span_p))));
        });
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CheckBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_body_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::decls::FnBody body_p2, crate::check::types::Ty res_p3) {
    return prism_rtl::make_rc<CheckBody>(env_p0, st_p1, body_p2, res_p3);
}


/// InferTemplate: unbounded fn Env, St, Template -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_template_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Template& t_p2) {
    auto st2_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(t_p2.parts_p, st_p1, ({
        auto env_p0x = env_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x)](std::tuple<crate::check::types::St, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0xy = env_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy)]() {
            return ({
                auto s_p4 = p0;
                auto part_p5 = p1;
                (prism_rtl::more(prism_rtl::rc(TemplatePartCheck(env_p0xy, s_p4, part_p5))));
            });
        })));
        });
    })));
    })));
    return std::tuple{crate::check::types::t_text_p(), st2_p3};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferTemplate::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    auto env_p0x = env_p0;
    auto st_p1x = st_p1;
    auto t_p2x = t_p2;
    return crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(t_p2x).parts_p, st_p1x, ({
        auto env_p0xx = env_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=, env_p0xx = std::move(env_p0xx)](std::tuple<crate::check::types::St, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0xxy = env_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xxy = std::move(env_p0xxy)]() {
            return ({
                auto s_p4 = p0;
                auto part_p5 = p1;
                (prism_rtl::more(prism_rtl::rc(TemplatePartCheck(env_p0xxy, s_p4, part_p5))));
            });
        })));
        });
    })));
    })), [=](crate::check::types::St fold_14418) {
        return ({
            auto st2_p3 = fold_14418;
            (prism_rtl::finished(std::tuple{crate::check::types::t_text_p(), st2_p3}));
        });
    });
}


/// `Start InferTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_template_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Template t_p2) {
    return prism_rtl::make_rc<InferTemplate>(env_p0, st_p1, t_p2);
}


/// TemplatePartCheck: unbounded fn Env, St, TemplatePart -> St
crate::check::types::St template_part_check_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::TemplatePart& part_p2) {
    if (prism_rtl::is<crate::syntax::TemplatePart::TpText>(part_p2)) {
        return st_p1;
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(part_p2)) {
        auto&& x_p3 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part_p2).a0;
        auto [t_p4, st2_p5] = crate::check::expr::infer_f(env_p0, st_p1, x_p3);
        return crate::check::expr::show_want_f(st2_p5, crate::check::expr::is_time_sigil_f(crate::check::types::head_sigil_f(st2_p5, t_p4))
            ? crate::check::expr::inner_of_f(st2_p5, t_p4)
            : t_p4, prism_rtl::deref(x_p3).span_p);
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(part_p2)) {
        auto&& b_p6 = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(part_p2).a0;
        auto [t_p7, st2_p8] = infer_expr_block_f(env_p0, st_p1, b_p6);
        return st2_p8;
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpCall>(part_p2)) {
        auto&& n_p9 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a0;
        auto&& args_pa = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a1;
        auto&& parts_ob = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a2;
        auto&& span_pc = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a3;
        return template_call_check_f(env_p0, st_p1, n_p9, args_pa, parts_ob, span_pc);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> TemplatePartCheck::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& part_p2 = this->part_p2;
    return ({
        prism_rtl::is<crate::syntax::TemplatePart::TpText>(part_p2) ? prism_rtl::finished(st_p1)
        : prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(part_p2) ? ({
        auto&& x_p3 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part_p2).a0;
        ({
        auto env_p0x = env_p0;
        auto st_p1x = st_p1;
        auto x_p3x = x_p3;
        (crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, x_p3x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_14683) {
        return ({
            auto [t_p4, st2_p5] = infer_f_14683;
            (crate::prelude::call_then(crate::check::types::start_head_sigil_f(st2_p5, t_p4), [=](Text head_sigil_f_14739) {
            return prism_rtl::more(prism_rtl::rc(crate::check::expr::ShowWant(st2_p5, crate::check::expr::is_time_sigil_f(head_sigil_f_14739)
                ? crate::check::expr::inner_of_f(st2_p5, t_p4)
                : t_p4, prism_rtl::deref(x_p3x).span_p)));
        }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(part_p2) ? ({
        auto&& b_p6 = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(part_p2).a0;
        ({
        auto b_p6x = b_p6;
        auto env_p0x = env_p0;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_infer_expr_block_f(env_p0x, st_p1x, b_p6x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_f_14830) {
        return ({
            auto [t_p7, st2_p8] = infer_expr_block_f_14830;
            (prism_rtl::finished(st2_p8));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::TemplatePart::TpCall>(part_p2) ? ({
        auto&& n_p9 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a0;
        auto&& args_pa = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a1;
        auto&& parts_ob = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a2;
        auto&& span_pc = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a3;
        prism_rtl::more(prism_rtl::rc(TemplateCallCheck(env_p0, st_p1, n_p9, args_pa, parts_ob, span_pc)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplatePartCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_template_part_check_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::TemplatePart part_p2) {
    return prism_rtl::make_rc<TemplatePartCheck>(env_p0, st_p1, part_p2);
}


/// TemplateCallCheck: unbounded fn Env, St, SName, [Arg], ?[TemplatePart], Range -> St
crate::check::types::St template_call_check_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::SName& n_p2, const Array<crate::syntax::Arg>& args_p3, const std::optional<Array<crate::syntax::TemplatePart>>& parts_o4, const crate::syntax::Range& span_p5) {
    auto plain_p6 = crate::syntax::SName{.sigils_p = crate::syntax::lexer::chars::after_first_f(n_p2.sigils_p), .path_p = n_p2.path_p, .span_p = n_p2.span_p};
    auto&& _qk1_o9 = crate::check::env::names::resolve_value_f(env_p0.g_p, env_p0.home_p, n_p2);
    auto&& qk1_o9 = std::get<0>(_qk1_o9);
    auto callee_p7 = qk1_o9 != std::optional<Text>{} ? n_p2 : plain_p6;
    auto [qk_oa, ignore2_pb] = crate::check::env::names::resolve_value_f(env_p0.g_p, env_p0.home_p, callee_p7);
    auto cname_p8 = crate::check::env::sname_key_f(plain_p6);
    if (prism_rtl::is_none(qk_oa)) {
        auto [ignore3_pc, st2_pd] = crate::check::expr::calls::call_global_f(env_p0, st_p1, callee_p7, Array<crate::syntax::Arg>{}, span_p5, Array<crate::check::types::Ty>{}, prism_rtl::deref(callee_p7).span_p);
        return st2_pd;
    }
    if (prism_rtl::is_some(qk_oa)) {
        auto&& qk_pe = prism_rtl::some_of(qk_oa);
        auto clauses_pf = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g_p).fn_at_p, qk_pe);
            if (prism_rtl::is_some(_m)) {
                auto&& i_ph = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
                    auto&& _m = crate::prelude::index(prism_rtl::deref(env_p0.g_p).defs_p, i_ph);
                    if (prism_rtl::is_some(_m)) {
                        auto&& d_pi = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
                            auto&& _m = prism_rtl::deref(d_pi).body_p;
                            if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
                                auto&& cs_pj = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
                                _v.set(cs_pj);
                                goto _done;
                            }
                            {
                                _v.set(Array<crate::syntax::decls::FnClause>{});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<crate::syntax::decls::FnClause>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::syntax::decls::FnClause>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arity_pg = ({
            __label__ _done;
            prism_rtl::Slot<Nat> _v;
            auto&& _m = crate::prelude::index(clauses_pf, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& c_pk = prism_rtl::some_of(_m);
                _v.set(crate::prelude::len(prism_rtl::deref(c_pk).params_p));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Nat(0u));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return crate::prelude::len(clauses_pf) == Nat(0u)
            ? crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), span_p5, prism_rtl::cat("`<@", cname_p8, ">` calls a function without clauses, which name no parameters for its attributes"))
            : ({
            auto [slots_pu, st1_pv] = crate::prelude::run_to_end(crate::prelude::fold_job(args_p3, std::tuple{Map<Text, crate::syntax::Expr>{}, st_p1}, ({
                auto clauses_pfx = clauses_pf;
                auto cname_p8x = cname_p8;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>, crate::syntax::Arg>)>>(prism_rtl::rc([=, clauses_pfx = std::move(clauses_pfx), cname_p8x = std::move(cname_p8x)](std::tuple<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>, crate::syntax::Arg> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto clauses_pfxy = clauses_pfx;
                    auto cname_p8xy = cname_p8x;
                    (crate::prelude::entered(crate::prelude::once_job([=, clauses_pfxy = std::move(clauses_pfxy), cname_p8xy = std::move(cname_p8xy)]() {
                    return ({
                        auto [m_pp, s_pq] = p0;
                        auto a_pr = p1;
                        ({
                        auto&& _m = prism_rtl::deref(a_pr).name_o;
                        prism_rtl::is_some(_m) ? ({
                        auto&& id_ps = prism_rtl::some_of(_m);
                        ({
                        auto id_psx = id_ps;
                        (crate::prelude::call_then(start_template_slot_o(clauses_pfxy, prism_rtl::deref(id_psx).name_p), [=](std::optional<Nat> template_slot_o_16629) {
                        return ({
                            prism_rtl::is_some(template_slot_o_16629) ? ({
                            auto&& j_pt = prism_rtl::some_of(template_slot_o_16629);
                            crate::check::env::has_key_f(m_pp, prism_rtl::cat(j_pt))
                            ? prism_rtl::finished(std::tuple{m_pp, crate::check::types::recording::err_f(s_pq, Text::lit("mismatch"), prism_rtl::deref(a_pr).span_p, prism_rtl::cat("`", prism_rtl::deref(id_psx).name_p, "` is given twice"))})
                            : prism_rtl::finished(std::tuple{crate::prelude::insert(m_pp, prism_rtl::cat(j_pt), prism_rtl::deref(a_pr).value_p), s_pq});
                        })
                            : prism_rtl::is_none(template_slot_o_16629) ? prism_rtl::finished(std::tuple{m_pp, crate::check::types::recording::err_f(s_pq, Text::lit("mismatch"), prism_rtl::deref(a_pr).span_p, prism_rtl::cat("`", cname_p8xy, "` has no parameter `", prism_rtl::deref(id_psx).name_p, "`"))})
                            : throw prism_rtl::Panic("no arm matched");
                        });
                    }));
                    });
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{m_pp, crate::check::types::recording::err_f(s_pq, Text::lit("mismatch"), prism_rtl::deref(a_pr).span_p, Text::lit("a template call names each argument: `name={{value}}`"))})
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                })));
                });
            }));
            })));
            auto body_ol = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                if (prism_rtl::is_some(parts_o4)) {
                    auto&& ps_p10 = prism_rtl::some_of(parts_o4);
                    _v.set(std::optional(crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETemplate{crate::syntax::Template{.keyword_p = Text::lit("InlineText"), .lang_p = Text::lit(""), .delims_p = Text::lit("double"), .parts_p = ps_p10, .span_p = span_p5}})), .span_p = span_p5}));
                    goto _done;
                }
                if (prism_rtl::is_none(parts_o4)) {
                    _v.set(std::optional<crate::syntax::Expr>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto last_pm = crate::syntax::lexer::chars::dec_f(arity_pg);
            auto st2_pn = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                if (prism_rtl::is_some(body_ol)) {
                    auto&& ignore4_p11 = prism_rtl::some_of(body_ol);
                    _v.set((arity_pg == Nat(0u)) || crate::check::env::has_key_f(slots_pu, prism_rtl::cat(last_pm))
                        ? crate::check::types::recording::err_f(st1_pv, Text::lit("mismatch"), span_p5, prism_rtl::cat("`", cname_p8, "` has no parameter left for the call\'s body"))
                        : st1_pv);
                    goto _done;
                }
                if (prism_rtl::is_none(body_ol)) {
                    _v.set(st1_pv);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto quiet_po = crate::prelude::len(prism_rtl::deref(st1_pv).diags_p) > crate::prelude::len(st_p1.diags_p);
            auto [positional_p17, st3_p18] = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(arity_pg), std::tuple{Array<crate::syntax::Arg>{}, st2_pn}, ({
                auto slots_pux = slots_pu;
                auto body_olx = body_ol;
                auto last_pmx = last_pm;
                auto span_p5x = span_p5;
                auto clauses_pfx = clauses_pf;
                auto cname_p8x = cname_p8;
                auto quiet_pox = std::move(quiet_po);
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, slots_pux = std::move(slots_pux), body_olx = std::move(body_olx), last_pmx = std::move(last_pmx), span_p5x = std::move(span_p5x), clauses_pfx = std::move(clauses_pfx), cname_p8x = std::move(cname_p8x), quiet_pox = std::move(quiet_pox)](std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto slots_puxy = slots_pux;
                    auto body_olxy = body_olx;
                    auto last_pmxy = last_pmx;
                    auto span_p5xy = span_p5x;
                    auto clauses_pfxy = clauses_pfx;
                    auto cname_p8xy = cname_p8x;
                    auto quiet_poxy = quiet_pox;
                    (crate::prelude::entered(crate::prelude::once_job([=, slots_puxy = std::move(slots_puxy), body_olxy = std::move(body_olxy), last_pmxy = std::move(last_pmxy), span_p5xy = std::move(span_p5xy), clauses_pfxy = std::move(clauses_pfxy), cname_p8xy = std::move(cname_p8xy), quiet_poxy = std::move(quiet_poxy)]() {
                    return ({
                        auto [acc_p12, s_p13] = p0;
                        auto j_p14 = p1;
                        ({
                        auto&& _m = crate::prelude::get(slots_puxy, prism_rtl::cat(j_p14));
                        prism_rtl::is_some(_m) ? ({
                        auto&& v_p15 = prism_rtl::some_of(_m);
                        prism_rtl::finished(std::tuple{crate::prelude::push(acc_p12, crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = v_p15, .span_p = prism_rtl::deref(v_p15).span_p}), s_p13});
                    })
                        : prism_rtl::is_none(_m) ? ({
                        prism_rtl::is_some(body_olxy) ? ({
                        auto&& b_p16 = prism_rtl::some_of(body_olxy);
                        j_p14 == last_pmxy
                        ? prism_rtl::finished(std::tuple{crate::prelude::push(acc_p12, crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = b_p16, .span_p = span_p5xy}), s_p13})
                        : prism_rtl::more(prism_rtl::rc(TemplateMissing(acc_p12, s_p13, clauses_pfxy, j_p14, cname_p8xy, span_p5xy, quiet_poxy)));
                    })
                        : prism_rtl::is_none(body_olxy) ? prism_rtl::more(prism_rtl::rc(TemplateMissing(acc_p12, s_p13, clauses_pfxy, j_p14, cname_p8xy, span_p5xy, quiet_poxy)))
                        : throw prism_rtl::Panic("no arm matched");
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                })));
                });
            }));
            })));
            auto [t_p19, st4_p1a] = crate::check::expr::calls::call_global_f(env_p0, st3_p18, callee_p7, positional_p17, span_p5, Array<crate::check::types::Ty>{}, prism_rtl::deref(callee_p7).span_p);
            (crate::check::types::unify::unify_f(st4_p1a, crate::check::types::t_text_p(), t_p19, span_p5));
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> TemplateCallCheck::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& n_p2 = this->n_p2;
    const auto& args_p3 = this->args_p3;
    const auto& parts_o4 = this->parts_o4;
    const auto& span_p5 = this->span_p5;
    auto plain_p6 = crate::syntax::SName{.sigils_p = crate::syntax::lexer::chars::after_first_f(prism_rtl::deref(n_p2).sigils_p), .path_p = prism_rtl::deref(n_p2).path_p, .span_p = prism_rtl::deref(n_p2).span_p};
    auto&& _qk1_o9 = crate::check::env::names::resolve_value_f(prism_rtl::deref(env_p0).g_p, prism_rtl::deref(env_p0).home_p, n_p2);
    auto&& qk1_o9 = std::get<0>(_qk1_o9);
    auto callee_p7 = qk1_o9 != std::optional<Text>{} ? n_p2 : plain_p6;
    auto [qk_oa, ignore2_pb] = crate::check::env::names::resolve_value_f(prism_rtl::deref(env_p0).g_p, prism_rtl::deref(env_p0).home_p, callee_p7);
    auto cname_p8 = crate::check::env::sname_key_f(plain_p6);
    return ({
        prism_rtl::is_none(qk_oa) ? ({
        auto env_p0x = env_p0;
        auto span_p5x = span_p5;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::expr::calls::start_call_global_f(env_p0x, st_p1x, callee_p7, Array<crate::syntax::Arg>{}, span_p5x, Array<crate::check::types::Ty>{}, prism_rtl::deref(callee_p7).span_p), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> call_global_f_15887) {
        return ({
            auto [ignore3_pc, st2_pd] = call_global_f_15887;
            (prism_rtl::finished(st2_pd));
        });
    }));
    })
        : prism_rtl::is_some(qk_oa) ? ({
        auto&& qk_pe = prism_rtl::some_of(qk_oa);
        ({
        auto clauses_pf = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g_p).fn_at_p, qk_pe);
            if (prism_rtl::is_some(_m)) {
                auto&& i_ph = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
                    auto&& _m = crate::prelude::index(prism_rtl::deref(prism_rtl::deref(env_p0).g_p).defs_p, i_ph);
                    if (prism_rtl::is_some(_m)) {
                        auto&& d_pi = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
                            auto&& _m = prism_rtl::deref(d_pi).body_p;
                            if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
                                auto&& cs_pj = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
                                _v.set(cs_pj);
                                goto _done;
                            }
                            {
                                _v.set(Array<crate::syntax::decls::FnClause>{});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<crate::syntax::decls::FnClause>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::syntax::decls::FnClause>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arity_pg = ({
            __label__ _done;
            prism_rtl::Slot<Nat> _v;
            auto&& _m = crate::prelude::index(clauses_pf, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& c_pk = prism_rtl::some_of(_m);
                _v.set(crate::prelude::len(prism_rtl::deref(c_pk).params_p));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Nat(0u));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (crate::prelude::len(clauses_pf) == Nat(0u)
        ? prism_rtl::finished(crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), span_p5, prism_rtl::cat("`<@", cname_p8, ">` calls a function without clauses, which name no parameters for its attributes")))
        : ({
        auto parts_o4x = parts_o4;
        auto args_p3x = args_p3;
        auto env_p0x = env_p0;
        auto span_p5x = span_p5;
        auto st_p1x = st_p1;
        (crate::prelude::call_value(crate::prelude::fold_job(args_p3x, std::tuple{Map<Text, crate::syntax::Expr>{}, st_p1x}, ({
        auto clauses_pfx = clauses_pf;
        auto cname_p8x = cname_p8;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>, crate::syntax::Arg>)>>(prism_rtl::rc([=, clauses_pfx = std::move(clauses_pfx), cname_p8x = std::move(cname_p8x)](std::tuple<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>, crate::syntax::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto clauses_pfxy = clauses_pfx;
            auto cname_p8xy = cname_p8x;
            (crate::prelude::entered(crate::prelude::once_job([=, clauses_pfxy = std::move(clauses_pfxy), cname_p8xy = std::move(cname_p8xy)]() {
            return ({
                auto [m_pp, s_pq] = p0;
                auto a_pr = p1;
                ({
                auto&& _m = prism_rtl::deref(a_pr).name_o;
                prism_rtl::is_some(_m) ? ({
                auto&& id_ps = prism_rtl::some_of(_m);
                ({
                auto id_psx = id_ps;
                (crate::prelude::call_then(start_template_slot_o(clauses_pfxy, prism_rtl::deref(id_psx).name_p), [=](std::optional<Nat> template_slot_o_16629) {
                return ({
                    prism_rtl::is_some(template_slot_o_16629) ? ({
                    auto&& j_pt = prism_rtl::some_of(template_slot_o_16629);
                    crate::check::env::has_key_f(m_pp, prism_rtl::cat(j_pt))
                    ? prism_rtl::finished(std::tuple{m_pp, crate::check::types::recording::err_f(s_pq, Text::lit("mismatch"), prism_rtl::deref(a_pr).span_p, prism_rtl::cat("`", prism_rtl::deref(id_psx).name_p, "` is given twice"))})
                    : prism_rtl::finished(std::tuple{crate::prelude::insert(m_pp, prism_rtl::cat(j_pt), prism_rtl::deref(a_pr).value_p), s_pq});
                })
                    : prism_rtl::is_none(template_slot_o_16629) ? prism_rtl::finished(std::tuple{m_pp, crate::check::types::recording::err_f(s_pq, Text::lit("mismatch"), prism_rtl::deref(a_pr).span_p, prism_rtl::cat("`", cname_p8xy, "` has no parameter `", prism_rtl::deref(id_psx).name_p, "`"))})
                    : throw prism_rtl::Panic("no arm matched");
                });
            }));
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{m_pp, crate::check::types::recording::err_f(s_pq, Text::lit("mismatch"), prism_rtl::deref(a_pr).span_p, Text::lit("a template call names each argument: `name={{value}}`"))})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    })), [=, parts_o4x = std::move(parts_o4x), env_p0x = std::move(env_p0x), span_p5x = std::move(span_p5x)](std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St> fold_16544) {
        return ({
            auto [slots_pu, st1_pv] = fold_16544;
            auto body_ol = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                if (prism_rtl::is_some(parts_o4x)) {
                    auto&& ps_p10 = prism_rtl::some_of(parts_o4x);
                    _v.set(std::optional(crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETemplate{crate::syntax::Template{.keyword_p = Text::lit("InlineText"), .lang_p = Text::lit(""), .delims_p = Text::lit("double"), .parts_p = ps_p10, .span_p = span_p5x}})), .span_p = span_p5x}));
                    goto _done;
                }
                if (prism_rtl::is_none(parts_o4x)) {
                    _v.set(std::optional<crate::syntax::Expr>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto last_pm = crate::syntax::lexer::chars::dec_f(arity_pg);
            auto st2_pn = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                if (prism_rtl::is_some(body_ol)) {
                    auto&& ignore4_p11 = prism_rtl::some_of(body_ol);
                    _v.set((arity_pg == Nat(0u)) || crate::check::env::has_key_f(slots_pu, prism_rtl::cat(last_pm))
                        ? crate::check::types::recording::err_f(st1_pv, Text::lit("mismatch"), span_p5x, prism_rtl::cat("`", cname_p8, "` has no parameter left for the call\'s body"))
                        : st1_pv);
                    goto _done;
                }
                if (prism_rtl::is_none(body_ol)) {
                    _v.set(st1_pv);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto quiet_po = crate::prelude::len(prism_rtl::deref(st1_pv).diags_p) > crate::prelude::len(prism_rtl::deref(st_p1x).diags_p);
            (crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(arity_pg), std::tuple{Array<crate::syntax::Arg>{}, st2_pn}, ({
            auto slots_pux = slots_pu;
            auto body_olx = body_ol;
            auto last_pmx = last_pm;
            auto span_p5xx = span_p5x;
            auto clauses_pfx = clauses_pf;
            auto cname_p8x = cname_p8;
            auto quiet_pox = std::move(quiet_po);
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, slots_pux = std::move(slots_pux), body_olx = std::move(body_olx), last_pmx = std::move(last_pmx), span_p5xx = std::move(span_p5xx), clauses_pfx = std::move(clauses_pfx), cname_p8x = std::move(cname_p8x), quiet_pox = std::move(quiet_pox)](std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto slots_puxy = slots_pux;
                auto body_olxy = body_olx;
                auto last_pmxy = last_pmx;
                auto span_p5xxy = span_p5xx;
                auto clauses_pfxy = clauses_pfx;
                auto cname_p8xy = cname_p8x;
                auto quiet_poxy = quiet_pox;
                (crate::prelude::entered(crate::prelude::once_job([=, slots_puxy = std::move(slots_puxy), body_olxy = std::move(body_olxy), last_pmxy = std::move(last_pmxy), span_p5xxy = std::move(span_p5xxy), clauses_pfxy = std::move(clauses_pfxy), cname_p8xy = std::move(cname_p8xy), quiet_poxy = std::move(quiet_poxy)]() {
                return ({
                    auto [acc_p12, s_p13] = p0;
                    auto j_p14 = p1;
                    ({
                    auto&& _m = crate::prelude::get(slots_puxy, prism_rtl::cat(j_p14));
                    prism_rtl::is_some(_m) ? ({
                    auto&& v_p15 = prism_rtl::some_of(_m);
                    prism_rtl::finished(std::tuple{crate::prelude::push(acc_p12, crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = v_p15, .span_p = prism_rtl::deref(v_p15).span_p}), s_p13});
                })
                    : prism_rtl::is_none(_m) ? ({
                    prism_rtl::is_some(body_olxy) ? ({
                    auto&& b_p16 = prism_rtl::some_of(body_olxy);
                    j_p14 == last_pmxy
                    ? prism_rtl::finished(std::tuple{crate::prelude::push(acc_p12, crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = b_p16, .span_p = span_p5xxy}), s_p13})
                    : prism_rtl::more(prism_rtl::rc(TemplateMissing(acc_p12, s_p13, clauses_pfxy, j_p14, cname_p8xy, span_p5xxy, quiet_poxy)));
                })
                    : prism_rtl::is_none(body_olxy) ? prism_rtl::more(prism_rtl::rc(TemplateMissing(acc_p12, s_p13, clauses_pfxy, j_p14, cname_p8xy, span_p5xxy, quiet_poxy)))
                    : throw prism_rtl::Panic("no arm matched");
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            })));
            });
        }));
        })), [=](std::tuple<Array<crate::syntax::Arg>, crate::check::types::St> fold_17628) {
            return ({
                auto [positional_p17, st3_p18] = fold_17628;
                (crate::prelude::call_then(crate::check::expr::calls::start_call_global_f(env_p0x, st3_p18, callee_p7, positional_p17, span_p5x, Array<crate::check::types::Ty>{}, prism_rtl::deref(callee_p7).span_p), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> call_global_f_18093) {
                return ({
                    auto [t_p19, st4_p1a] = call_global_f_18093;
                    (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st4_p1a, crate::check::types::t_text_p(), t_p19, span_p5x))));
                });
            }));
            });
        }));
        });
    }));
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplateCallCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_template_call_check_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, Array<crate::syntax::Arg> args_p3, std::optional<Array<crate::syntax::TemplatePart>> parts_o4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<TemplateCallCheck>(env_p0, st_p1, n_p2, args_p3, parts_o4, span_p5);
}


/// TemplateMissing: unbounded fn [Arg], St, [FnClause], Nat, Text, Range, Bool -> (([Arg], St))
std::tuple<Array<crate::syntax::Arg>, crate::check::types::St> template_missing_f(const Array<crate::syntax::Arg>& acc_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::decls::FnClause>& clauses_p2, const Nat& j_p3, const Text& cname_p4, const crate::syntax::Range& span_p5, const bool& quiet_p6) {
    auto pname_p7 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::prelude::index(clauses_p2, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c_p9 = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = crate::prelude::index(prism_rtl::deref(c_p9).params_p, j_p3);
                if (prism_rtl::is_some(_m)) {
                    auto&& p_pa = prism_rtl::some_of(_m);
                    _v.set(crate::check::shrink::locals::param_name_of_f(p_pa));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2_p8 = quiet_p6
        ? st_p1
        : crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), span_p5, prism_rtl::cat("`<@", cname_p4, ">` needs `", pname_p7, "=`"));
    return std::tuple{crate::prelude::push(acc_p0, crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = span_p5}, .span_p = span_p5}), st2_p8};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>> TemplateMissing::cycle() const {
    const auto& acc_p0 = this->acc_p0;
    const auto& st_p1 = this->st_p1;
    const auto& clauses_p2 = this->clauses_p2;
    const auto& j_p3 = this->j_p3;
    const auto& cname_p4 = this->cname_p4;
    const auto& span_p5 = this->span_p5;
    const auto& quiet_p6 = this->quiet_p6;
    auto pname_p7 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::prelude::index(clauses_p2, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c_p9 = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = crate::prelude::index(prism_rtl::deref(c_p9).params_p, j_p3);
                if (prism_rtl::is_some(_m)) {
                    auto&& p_pa = prism_rtl::some_of(_m);
                    _v.set(crate::check::shrink::locals::param_name_of_f(p_pa));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2_p8 = prism_rtl::deref(quiet_p6)
        ? st_p1
        : crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), span_p5, prism_rtl::cat("`<@", cname_p4, ">` needs `", pname_p7, "=`"));
    return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p0, crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = span_p5}, .span_p = span_p5}), st2_p8});
}


/// `Start TemplateMissing, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>> start_template_missing_f(Array<crate::syntax::Arg> acc_p0, crate::check::types::St st_p1, Array<crate::syntax::decls::FnClause> clauses_p2, Nat j_p3, Text cname_p4, crate::syntax::Range span_p5, bool quiet_p6) {
    return prism_rtl::make_rc<TemplateMissing>(acc_p0, st_p1, clauses_p2, j_p3, cname_p4, span_p5, quiet_p6);
}


/// ?TemplateSlot: unbounded fn [FnClause], Text -> ?Nat
std::optional<Nat> template_slot_o(const Array<crate::syntax::decls::FnClause>& clauses_p0, const Text& name_p1) {
    auto found_p7 = crate::prelude::run_to_end(crate::prelude::fold_job(clauses_p0, Array<Nat>{}, ({
        auto name_p1x = name_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, name_p1x = std::move(name_p1x)](std::tuple<Array<Nat>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto name_p1xy = name_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, name_p1xy = std::move(name_p1xy)]() {
            return ({
                auto acc_p2 = p0;
                auto c_p3 = p1;
                (crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(c_p3).params_p)), acc_p2, ({
                auto c_p3x = c_p3;
                auto name_p1xyx = name_p1xy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Nat>)>>(prism_rtl::rc([=, c_p3x = std::move(c_p3x), name_p1xyx = std::move(name_p1xyx)](std::tuple<Array<Nat>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_p3xy = c_p3x;
                    auto name_p1xyxy = name_p1xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, c_p3xy = std::move(c_p3xy), name_p1xyxy = std::move(name_p1xyxy)]() {
                    return ({
                        auto a2_p4 = p0;
                        auto i_p5 = p1;
                        ({
                        auto&& _m = crate::prelude::index(prism_rtl::deref(c_p3xy).params_p, i_p5);
                        prism_rtl::is_some(_m) ? ({
                        auto&& p_p6 = prism_rtl::some_of(_m);
                        crate::check::shrink::locals::param_name_of_f(p_p6) == name_p1xyxy
                        ? prism_rtl::finished(crate::check::types::add_nat_f(a2_p4, i_p5))
                        : prism_rtl::finished(a2_p4);
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(a2_p4)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                })));
                });
            })));
            }))->cycle());
            });
        })));
        });
    })));
    })));
    return crate::prelude::len(found_p7) == Nat(1u)
        ? crate::prelude::index(found_p7, Nat(0u))
        : std::optional<Nat>{};
}


prism_rtl::Turn<std::optional<Nat>> TemplateSlot::cycle() const {
    const auto& clauses_p0 = this->clauses_p0;
    const auto& name_p1 = this->name_p1;
    auto clauses_p0x = clauses_p0;
    auto name_p1x = name_p1;
    return crate::prelude::call_value(crate::prelude::fold_job(clauses_p0x, Array<Nat>{}, ({
        auto name_p1xx = name_p1x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, name_p1xx = std::move(name_p1xx)](std::tuple<Array<Nat>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto name_p1xxy = name_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, name_p1xxy = std::move(name_p1xxy)]() {
            return ({
                auto acc_p2 = p0;
                auto c_p3 = p1;
                (crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(c_p3).params_p)), acc_p2, ({
                auto c_p3x = c_p3;
                auto name_p1xxyx = name_p1xxy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Nat>)>>(prism_rtl::rc([=, c_p3x = std::move(c_p3x), name_p1xxyx = std::move(name_p1xxyx)](std::tuple<Array<Nat>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_p3xy = c_p3x;
                    auto name_p1xxyxy = name_p1xxyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, c_p3xy = std::move(c_p3xy), name_p1xxyxy = std::move(name_p1xxyxy)]() {
                    return ({
                        auto a2_p4 = p0;
                        auto i_p5 = p1;
                        ({
                        auto&& _m = crate::prelude::index(prism_rtl::deref(c_p3xy).params_p, i_p5);
                        prism_rtl::is_some(_m) ? ({
                        auto&& p_p6 = prism_rtl::some_of(_m);
                        crate::check::shrink::locals::param_name_of_f(p_p6) == name_p1xxyxy
                        ? prism_rtl::finished(crate::check::types::add_nat_f(a2_p4, i_p5))
                        : prism_rtl::finished(a2_p4);
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(a2_p4)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                })));
                });
            })));
            }))->cycle());
            });
        })));
        });
    })));
    })), [=](Array<Nat> fold_18987) {
        return ({
            auto found_p7 = fold_18987;
            (crate::prelude::len(found_p7) == Nat(1u)
            ? prism_rtl::finished(crate::prelude::index(found_p7, Nat(0u)))
            : prism_rtl::finished(std::optional<Nat>{}));
        });
    });
}


/// `Start TemplateSlot, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Nat>> start_template_slot_o(Array<crate::syntax::decls::FnClause> clauses_p0, Text name_p1) {
    return prism_rtl::make_rc<TemplateSlot>(clauses_p0, name_p1);
}

}  // namespace crate::check::expr::lets
