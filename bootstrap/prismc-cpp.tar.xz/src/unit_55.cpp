// The modules `Syntax.Lexer`, `Syntax.Lexer.Chars`, `Syntax.Lexer.Corpus`, `Syntax.Lexer.Layout`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/lexer/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Syntax.Lexer`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/mod.prism`.
namespace crate::syntax::lexer {

void AttrTok::show(Printer& p) const {
    p.record("AttrTok", {{"name", name}, {"tokens", tokens}, {"span", span}});
}

Pod AttrTok::to_pod() const {
    return Pod::record("AttrTok", {{"name", prism_rtl::to_pod(name)}, {"tokens", prism_rtl::to_pod(tokens)}, {"span", prism_rtl::to_pod(span)}});
}

Result<AttrTok> AttrTok::from_pod(const Pod& whole) {
    return AttrTok{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .tokens = TRY(prism_rtl::from_pod<Array<Tok>>(TRY(crate::prelude::field(whole, "tokens")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Lex::show(Printer& p) const {
    p.record("Lex", {{"src", src}, {"pos", pos}, {"diags", diags}, {"mode", mode}, {"tokens", tokens}, {"layout", layout}, {"frames", frames}, {"last_ws", last_ws}, {"lambda_open", lambda_open}, {"pending_open", pending_open}, {"pending_span", pending_span}, {"line_first", line_first}, {"mark_line_start", mark_line_start}, {"first_line", first_line}, {"test_pending", test_pending}, {"test_depth", test_depth}, {"check_depth", check_depth}, {"path_next", path_next}});
}

Pod Lex::to_pod() const {
    return Pod::record("Lex", {{"src", prism_rtl::to_pod(src)}, {"pos", prism_rtl::to_pod(pos)}, {"diags", prism_rtl::to_pod(diags)}, {"mode", prism_rtl::to_pod(mode)}, {"tokens", prism_rtl::to_pod(tokens)}, {"layout", prism_rtl::to_pod(layout)}, {"frames", prism_rtl::to_pod(frames)}, {"last_ws", prism_rtl::to_pod(last_ws)}, {"lambda_open", prism_rtl::to_pod(lambda_open)}, {"pending_open", prism_rtl::to_pod(pending_open)}, {"pending_span", prism_rtl::to_pod(pending_span)}, {"line_first", prism_rtl::to_pod(line_first)}, {"mark_line_start", prism_rtl::to_pod(mark_line_start)}, {"first_line", prism_rtl::to_pod(first_line)}, {"test_pending", prism_rtl::to_pod(test_pending)}, {"test_depth", prism_rtl::to_pod(test_depth)}, {"check_depth", prism_rtl::to_pod(check_depth)}, {"path_next", prism_rtl::to_pod(path_next)}});
}

Result<Lex> Lex::from_pod(const Pod& whole) {
    return Lex{.src = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "src")))), .pos = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "pos")))), .diags = TRY(prism_rtl::from_pod<Array<crate::syntax::Diag>>(TRY(crate::prelude::field(whole, "diags")))), .mode = TRY(prism_rtl::from_pod<Mode>(TRY(crate::prelude::field(whole, "mode")))), .tokens = TRY(prism_rtl::from_pod<Array<Tok>>(TRY(crate::prelude::field(whole, "tokens")))), .layout = TRY(prism_rtl::from_pod<Array<Nat>>(TRY(crate::prelude::field(whole, "layout")))), .frames = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "frames")))), .last_ws = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "last_ws")))), .lambda_open = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "lambda_open")))), .pending_open = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "pending_open")))), .pending_span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "pending_span")))), .line_first = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "line_first")))), .mark_line_start = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "mark_line_start")))), .first_line = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "first_line")))), .test_pending = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "test_pending")))), .test_depth = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(crate::prelude::field(whole, "test_depth")))), .check_depth = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(crate::prelude::field(whole, "check_depth")))), .path_next = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "path_next"))))};
}


void Lexed::show(Printer& p) const {
    p.record("Lexed", {{"tokens", tokens}, {"diags", diags}});
}

Pod Lexed::to_pod() const {
    return Pod::record("Lexed", {{"tokens", prism_rtl::to_pod(tokens)}, {"diags", prism_rtl::to_pod(diags)}});
}

Result<Lexed> Lexed::from_pod(const Pod& whole) {
    return Lexed{.tokens = TRY(prism_rtl::from_pod<Array<Tok>>(TRY(crate::prelude::field(whole, "tokens")))), .diags = TRY(prism_rtl::from_pod<Array<crate::syntax::Diag>>(TRY(crate::prelude::field(whole, "diags"))))};
}


void Mode::show(Printer& p) const {
    if (auto c = std::get_if<MFile>(&cases())) p.choice("MFile", {});
    else if (auto c = std::get_if<MBrace>(&cases())) p.choice("MBrace", {c->a0});
    else if (auto c = std::get_if<MPlaceholder>(&cases())) p.choice("MPlaceholder", {c->a0});
    else if (auto c = std::get_if<MPathKey>(&cases())) p.choice("MPathKey", {});
}

Pod Mode::to_pod() const {
    return std::holds_alternative<MFile>(cases()) ? Pod::choice("MFile", {})
        : std::holds_alternative<MBrace>(cases()) ? Pod::choice("MBrace", {prism_rtl::to_pod(std::get<MBrace>(cases()).a0)})
        : std::holds_alternative<MPlaceholder>(cases()) ? Pod::choice("MPlaceholder", {prism_rtl::to_pod(std::get<MPlaceholder>(cases()).a0)})
        : std::holds_alternative<MPathKey>(cases()) ? Pod::choice("MPathKey", {})
        : Pod();
}

Result<Mode> Mode::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "MFile" && c->args.size() == 0) return Mode(MFile{});
        if (c->ctor == "MBrace" && c->args.size() == 1) return Mode(MBrace{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "MPlaceholder" && c->args.size() == 1) return Mode(MPlaceholder{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "MPathKey" && c->args.size() == 0) return Mode(MPathKey{});
    }
    return mismatch<Mode>("a Mode", p);
}


void NameCase::show(Printer& p) const {
    if (auto c = std::get_if<CaseLower>(&cases())) p.choice("CaseLower", {});
    else if (auto c = std::get_if<CaseUpper>(&cases())) p.choice("CaseUpper", {});
    else if (auto c = std::get_if<CaseTopic>(&cases())) p.choice("CaseTopic", {});
    else if (auto c = std::get_if<CaseHole>(&cases())) p.choice("CaseHole", {});
    else if (auto c = std::get_if<CaseReserved>(&cases())) p.choice("CaseReserved", {});
}

Pod NameCase::to_pod() const {
    return std::holds_alternative<CaseLower>(cases()) ? Pod::choice("CaseLower", {})
        : std::holds_alternative<CaseUpper>(cases()) ? Pod::choice("CaseUpper", {})
        : std::holds_alternative<CaseTopic>(cases()) ? Pod::choice("CaseTopic", {})
        : std::holds_alternative<CaseHole>(cases()) ? Pod::choice("CaseHole", {})
        : std::holds_alternative<CaseReserved>(cases()) ? Pod::choice("CaseReserved", {})
        : Pod();
}

Result<NameCase> NameCase::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "CaseLower" && c->args.size() == 0) return NameCase(CaseLower{});
        if (c->ctor == "CaseUpper" && c->args.size() == 0) return NameCase(CaseUpper{});
        if (c->ctor == "CaseTopic" && c->args.size() == 0) return NameCase(CaseTopic{});
        if (c->ctor == "CaseHole" && c->args.size() == 0) return NameCase(CaseHole{});
        if (c->ctor == "CaseReserved" && c->args.size() == 0) return NameCase(CaseReserved{});
    }
    return mismatch<NameCase>("a NameCase", p);
}


void NameTok::show(Printer& p) const {
    p.record("NameTok", {{"sigils", sigils}, {"path", path_}, {"case", case_}});
}

Pod NameTok::to_pod() const {
    return Pod::record("NameTok", {{"sigils", prism_rtl::to_pod(sigils)}, {"path", prism_rtl::to_pod(path_)}, {"case", prism_rtl::to_pod(case_)}});
}

Result<NameTok> NameTok::from_pod(const Pod& whole) {
    return NameTok{.sigils = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "sigils")))), .path_ = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "path")))), .case_ = TRY(prism_rtl::from_pod<NameCase>(TRY(crate::prelude::field(whole, "case"))))};
}


void PathSegTok::show(Printer& p) const {
    if (auto c = std::get_if<PstNum>(&cases())) p.choice("PstNum", {c->a0});
    else if (auto c = std::get_if<PstGen>(&cases())) p.choice("PstGen", {c->a0});
    else if (auto c = std::get_if<PstKey>(&cases())) p.choice("PstKey", {c->a0});
}

Pod PathSegTok::to_pod() const {
    return std::holds_alternative<PstNum>(cases()) ? Pod::choice("PstNum", {prism_rtl::to_pod(std::get<PstNum>(cases()).a0)})
        : std::holds_alternative<PstGen>(cases()) ? Pod::choice("PstGen", {prism_rtl::to_pod(std::get<PstGen>(cases()).a0)})
        : std::holds_alternative<PstKey>(cases()) ? Pod::choice("PstKey", {prism_rtl::to_pod(std::get<PstKey>(cases()).a0)})
        : Pod();
}

Result<PathSegTok> PathSegTok::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "PstNum" && c->args.size() == 1) return PathSegTok(PstNum{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "PstGen" && c->args.size() == 1) return PathSegTok(PstGen{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "PstKey" && c->args.size() == 1) return PathSegTok(PstKey{TRY(prism_rtl::from_pod<Array<Tok>>(c->args[0]))});
    }
    return mismatch<PathSegTok>("a PathSegTok", p);
}


void TPartTok::show(Printer& p) const {
    if (auto c = std::get_if<TptText>(&cases())) p.choice("TptText", {c->a0});
    else if (auto c = std::get_if<TptPlaceholder>(&cases())) p.choice("TptPlaceholder", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<TptBlock>(&cases())) p.choice("TptBlock", {c->a0, c->a1});
    else if (auto c = std::get_if<TptCall>(&cases())) p.choice("TptCall", {c->a0, c->a1, c->a2, c->a3});
}

Pod TPartTok::to_pod() const {
    return std::holds_alternative<TptText>(cases()) ? Pod::choice("TptText", {prism_rtl::to_pod(std::get<TptText>(cases()).a0)})
        : std::holds_alternative<TptPlaceholder>(cases()) ? Pod::choice("TptPlaceholder", {prism_rtl::to_pod(std::get<TptPlaceholder>(cases()).a0), prism_rtl::to_pod(std::get<TptPlaceholder>(cases()).a1), prism_rtl::to_pod(std::get<TptPlaceholder>(cases()).a2)})
        : std::holds_alternative<TptBlock>(cases()) ? Pod::choice("TptBlock", {prism_rtl::to_pod(std::get<TptBlock>(cases()).a0), prism_rtl::to_pod(std::get<TptBlock>(cases()).a1)})
        : std::holds_alternative<TptCall>(cases()) ? Pod::choice("TptCall", {prism_rtl::to_pod(std::get<TptCall>(cases()).a0), prism_rtl::to_pod(std::get<TptCall>(cases()).a1), prism_rtl::to_pod(std::get<TptCall>(cases()).a2), prism_rtl::to_pod(std::get<TptCall>(cases()).a3)})
        : Pod();
}

Result<TPartTok> TPartTok::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TptText" && c->args.size() == 1) return TPartTok(TptText{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TptPlaceholder" && c->args.size() == 3) return TPartTok(TptPlaceholder{TRY(prism_rtl::from_pod<Array<Tok>>(c->args[0])), TRY(prism_rtl::from_pod<std::optional<Nat>>(c->args[1])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[2]))});
        if (c->ctor == "TptBlock" && c->args.size() == 2) return TPartTok(TptBlock{TRY(prism_rtl::from_pod<Array<Tok>>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[1]))});
        if (c->ctor == "TptCall" && c->args.size() == 4) return TPartTok(TptCall{TRY(prism_rtl::from_pod<NameTok>(c->args[0])), TRY(prism_rtl::from_pod<Array<AttrTok>>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Array<TPartTok>>>(c->args[2])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[3]))});
    }
    return mismatch<TPartTok>("a TPartTok", p);
}


void TemplateTok::show(Printer& p) const {
    p.record("TemplateTok", {{"keyword", keyword}, {"lang", lang}, {"delims", delims}, {"parts", parts}});
}

Pod TemplateTok::to_pod() const {
    return Pod::record("TemplateTok", {{"keyword", prism_rtl::to_pod(keyword)}, {"lang", prism_rtl::to_pod(lang)}, {"delims", prism_rtl::to_pod(delims)}, {"parts", prism_rtl::to_pod(parts)}});
}

Result<TemplateTok> TemplateTok::from_pod(const Pod& whole) {
    return TemplateTok{.keyword = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "keyword")))), .lang = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "lang")))), .delims = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "delims")))), .parts = TRY(prism_rtl::from_pod<Array<TPartTok>>(TRY(crate::prelude::field(whole, "parts"))))};
}


void TextSegTok::show(Printer& p) const {
    if (auto c = std::get_if<TsPlain>(&cases())) p.choice("TsPlain", {c->a0});
    else if (auto c = std::get_if<TsPlaceholder>(&cases())) p.choice("TsPlaceholder", {c->a0, c->a1});
}

Pod TextSegTok::to_pod() const {
    return std::holds_alternative<TsPlain>(cases()) ? Pod::choice("TsPlain", {prism_rtl::to_pod(std::get<TsPlain>(cases()).a0)})
        : std::holds_alternative<TsPlaceholder>(cases()) ? Pod::choice("TsPlaceholder", {prism_rtl::to_pod(std::get<TsPlaceholder>(cases()).a0), prism_rtl::to_pod(std::get<TsPlaceholder>(cases()).a1)})
        : Pod();
}

Result<TextSegTok> TextSegTok::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TsPlain" && c->args.size() == 1) return TextSegTok(TsPlain{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TsPlaceholder" && c->args.size() == 2) return TextSegTok(TsPlaceholder{TRY(prism_rtl::from_pod<Array<Tok>>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[1]))});
    }
    return mismatch<TextSegTok>("a TextSegTok", p);
}


void Tok::show(Printer& p) const {
    p.record("Tok", {{"kind", kind}, {"span", span}, {"touches", touches}, {"line_start", line_start}});
}

Pod Tok::to_pod() const {
    return Pod::record("Tok", {{"kind", prism_rtl::to_pod(kind)}, {"span", prism_rtl::to_pod(span)}, {"touches", prism_rtl::to_pod(touches)}, {"line_start", prism_rtl::to_pod(line_start)}});
}

Result<Tok> Tok::from_pod(const Pod& whole) {
    return Tok{.kind = TRY(prism_rtl::from_pod<TokKind>(TRY(crate::prelude::field(whole, "kind")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .touches = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "touches")))), .line_start = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "line_start"))))};
}


void TokKind::show(Printer& p) const {
    if (auto c = std::get_if<KName>(&cases())) p.choice("KName", {c->a0});
    else if (auto c = std::get_if<KFamily>(&cases())) p.choice("KFamily", {c->a0});
    else if (auto c = std::get_if<KTrait>(&cases())) p.choice("KTrait", {c->a0});
    else if (auto c = std::get_if<KKw>(&cases())) p.choice("KKw", {c->a0, c->a1});
    else if (auto c = std::get_if<KFree>(&cases())) p.choice("KFree", {c->a0});
    else if (auto c = std::get_if<KLensDot>(&cases())) p.choice("KLensDot", {});
    else if (auto c = std::get_if<KInt>(&cases())) p.choice("KInt", {c->a0, c->a1});
    else if (auto c = std::get_if<KFloat>(&cases())) p.choice("KFloat", {c->a0, c->a1});
    else if (auto c = std::get_if<KDuration>(&cases())) p.choice("KDuration", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<KChar>(&cases())) p.choice("KChar", {c->a0, c->a1});
    else if (auto c = std::get_if<KText>(&cases())) p.choice("KText", {c->a0, c->a1});
    else if (auto c = std::get_if<KRegex>(&cases())) p.choice("KRegex", {c->a0, c->a1});
    else if (auto c = std::get_if<KTemplate>(&cases())) p.choice("KTemplate", {c->a0});
    else if (auto c = std::get_if<KOp>(&cases())) p.choice("KOp", {c->a0, c->a1});
    else if (auto c = std::get_if<KSuffixed>(&cases())) p.choice("KSuffixed", {c->a0, c->a1});
    else if (auto c = std::get_if<KDot>(&cases())) p.choice("KDot", {c->a0});
    else if (auto c = std::get_if<KDotDot>(&cases())) p.choice("KDotDot", {});
    else if (auto c = std::get_if<KComma>(&cases())) p.choice("KComma", {});
    else if (auto c = std::get_if<KColon>(&cases())) p.choice("KColon", {});
    else if (auto c = std::get_if<KSemi>(&cases())) p.choice("KSemi", {});
    else if (auto c = std::get_if<KBackslash>(&cases())) p.choice("KBackslash", {});
    else if (auto c = std::get_if<KLambdaBar>(&cases())) p.choice("KLambdaBar", {c->a0});
    else if (auto c = std::get_if<KBar>(&cases())) p.choice("KBar", {});
    else if (auto c = std::get_if<KLtLt>(&cases())) p.choice("KLtLt", {});
    else if (auto c = std::get_if<KGtGt>(&cases())) p.choice("KGtGt", {});
    else if (auto c = std::get_if<KOpen>(&cases())) p.choice("KOpen", {c->a0, c->a1});
    else if (auto c = std::get_if<KClose>(&cases())) p.choice("KClose", {c->a0});
    else if (auto c = std::get_if<KAbsent>(&cases())) p.choice("KAbsent", {});
    else if (auto c = std::get_if<KNonEmpty>(&cases())) p.choice("KNonEmpty", {});
    else if (auto c = std::get_if<KPath>(&cases())) p.choice("KPath", {c->a0});
    else if (auto c = std::get_if<KLayOpen>(&cases())) p.choice("KLayOpen", {});
    else if (auto c = std::get_if<KLaySep>(&cases())) p.choice("KLaySep", {});
    else if (auto c = std::get_if<KLayClose>(&cases())) p.choice("KLayClose", {});
    else if (auto c = std::get_if<KEof>(&cases())) p.choice("KEof", {});
}

Pod TokKind::to_pod() const {
    return std::holds_alternative<KName>(cases()) ? Pod::choice("KName", {prism_rtl::to_pod(std::get<KName>(cases()).a0)})
        : std::holds_alternative<KFamily>(cases()) ? Pod::choice("KFamily", {prism_rtl::to_pod(std::get<KFamily>(cases()).a0)})
        : std::holds_alternative<KTrait>(cases()) ? Pod::choice("KTrait", {prism_rtl::to_pod(std::get<KTrait>(cases()).a0)})
        : std::holds_alternative<KKw>(cases()) ? Pod::choice("KKw", {prism_rtl::to_pod(std::get<KKw>(cases()).a0), prism_rtl::to_pod(std::get<KKw>(cases()).a1)})
        : std::holds_alternative<KFree>(cases()) ? Pod::choice("KFree", {prism_rtl::to_pod(std::get<KFree>(cases()).a0)})
        : std::holds_alternative<KLensDot>(cases()) ? Pod::choice("KLensDot", {})
        : std::holds_alternative<KInt>(cases()) ? Pod::choice("KInt", {prism_rtl::to_pod(std::get<KInt>(cases()).a0), prism_rtl::to_pod(std::get<KInt>(cases()).a1)})
        : std::holds_alternative<KFloat>(cases()) ? Pod::choice("KFloat", {prism_rtl::to_pod(std::get<KFloat>(cases()).a0), prism_rtl::to_pod(std::get<KFloat>(cases()).a1)})
        : std::holds_alternative<KDuration>(cases()) ? Pod::choice("KDuration", {prism_rtl::to_pod(std::get<KDuration>(cases()).a0), prism_rtl::to_pod(std::get<KDuration>(cases()).a1), prism_rtl::to_pod(std::get<KDuration>(cases()).a2)})
        : std::holds_alternative<KChar>(cases()) ? Pod::choice("KChar", {prism_rtl::to_pod(std::get<KChar>(cases()).a0), prism_rtl::to_pod(std::get<KChar>(cases()).a1)})
        : std::holds_alternative<KText>(cases()) ? Pod::choice("KText", {prism_rtl::to_pod(std::get<KText>(cases()).a0), prism_rtl::to_pod(std::get<KText>(cases()).a1)})
        : std::holds_alternative<KRegex>(cases()) ? Pod::choice("KRegex", {prism_rtl::to_pod(std::get<KRegex>(cases()).a0), prism_rtl::to_pod(std::get<KRegex>(cases()).a1)})
        : std::holds_alternative<KTemplate>(cases()) ? Pod::choice("KTemplate", {prism_rtl::to_pod(std::get<KTemplate>(cases()).a0)})
        : std::holds_alternative<KOp>(cases()) ? Pod::choice("KOp", {prism_rtl::to_pod(std::get<KOp>(cases()).a0), prism_rtl::to_pod(std::get<KOp>(cases()).a1)})
        : std::holds_alternative<KSuffixed>(cases()) ? Pod::choice("KSuffixed", {prism_rtl::to_pod(std::get<KSuffixed>(cases()).a0), prism_rtl::to_pod(std::get<KSuffixed>(cases()).a1)})
        : std::holds_alternative<KDot>(cases()) ? Pod::choice("KDot", {prism_rtl::to_pod(std::get<KDot>(cases()).a0)})
        : std::holds_alternative<KDotDot>(cases()) ? Pod::choice("KDotDot", {})
        : std::holds_alternative<KComma>(cases()) ? Pod::choice("KComma", {})
        : std::holds_alternative<KColon>(cases()) ? Pod::choice("KColon", {})
        : std::holds_alternative<KSemi>(cases()) ? Pod::choice("KSemi", {})
        : std::holds_alternative<KBackslash>(cases()) ? Pod::choice("KBackslash", {})
        : std::holds_alternative<KLambdaBar>(cases()) ? Pod::choice("KLambdaBar", {prism_rtl::to_pod(std::get<KLambdaBar>(cases()).a0)})
        : std::holds_alternative<KBar>(cases()) ? Pod::choice("KBar", {})
        : std::holds_alternative<KLtLt>(cases()) ? Pod::choice("KLtLt", {})
        : std::holds_alternative<KGtGt>(cases()) ? Pod::choice("KGtGt", {})
        : std::holds_alternative<KOpen>(cases()) ? Pod::choice("KOpen", {prism_rtl::to_pod(std::get<KOpen>(cases()).a0), prism_rtl::to_pod(std::get<KOpen>(cases()).a1)})
        : std::holds_alternative<KClose>(cases()) ? Pod::choice("KClose", {prism_rtl::to_pod(std::get<KClose>(cases()).a0)})
        : std::holds_alternative<KAbsent>(cases()) ? Pod::choice("KAbsent", {})
        : std::holds_alternative<KNonEmpty>(cases()) ? Pod::choice("KNonEmpty", {})
        : std::holds_alternative<KPath>(cases()) ? Pod::choice("KPath", {prism_rtl::to_pod(std::get<KPath>(cases()).a0)})
        : std::holds_alternative<KLayOpen>(cases()) ? Pod::choice("KLayOpen", {})
        : std::holds_alternative<KLaySep>(cases()) ? Pod::choice("KLaySep", {})
        : std::holds_alternative<KLayClose>(cases()) ? Pod::choice("KLayClose", {})
        : std::holds_alternative<KEof>(cases()) ? Pod::choice("KEof", {})
        : Pod();
}

Result<TokKind> TokKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "KName" && c->args.size() == 1) return TokKind(KName{TRY(prism_rtl::from_pod<NameTok>(c->args[0]))});
        if (c->ctor == "KFamily" && c->args.size() == 1) return TokKind(KFamily{TRY(prism_rtl::from_pod<Array<Text>>(c->args[0]))});
        if (c->ctor == "KTrait" && c->args.size() == 1) return TokKind(KTrait{TRY(prism_rtl::from_pod<Array<Text>>(c->args[0]))});
        if (c->ctor == "KKw" && c->args.size() == 2) return TokKind(KKw{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "KFree" && c->args.size() == 1) return TokKind(KFree{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "KLensDot" && c->args.size() == 0) return TokKind(KLensDot{});
        if (c->ctor == "KInt" && c->args.size() == 2) return TokKind(KInt{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "KFloat" && c->args.size() == 2) return TokKind(KFloat{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "KDuration" && c->args.size() == 3) return TokKind(KDuration{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Text>(c->args[2]))});
        if (c->ctor == "KChar" && c->args.size() == 2) return TokKind(KChar{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "KText" && c->args.size() == 2) return TokKind(KText{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<TextSegTok>>(c->args[1]))});
        if (c->ctor == "KRegex" && c->args.size() == 2) return TokKind(KRegex{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::RegexLit>(c->args[1]))});
        if (c->ctor == "KTemplate" && c->args.size() == 1) return TokKind(KTemplate{TRY(prism_rtl::from_pod<TemplateTok>(c->args[0]))});
        if (c->ctor == "KOp" && c->args.size() == 2) return TokKind(KOp{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<bool>(c->args[1]))});
        if (c->ctor == "KSuffixed" && c->args.size() == 2) return TokKind(KSuffixed{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Text>>(c->args[1]))});
        if (c->ctor == "KDot" && c->args.size() == 1) return TokKind(KDot{TRY(prism_rtl::from_pod<bool>(c->args[0]))});
        if (c->ctor == "KDotDot" && c->args.size() == 0) return TokKind(KDotDot{});
        if (c->ctor == "KComma" && c->args.size() == 0) return TokKind(KComma{});
        if (c->ctor == "KColon" && c->args.size() == 0) return TokKind(KColon{});
        if (c->ctor == "KSemi" && c->args.size() == 0) return TokKind(KSemi{});
        if (c->ctor == "KBackslash" && c->args.size() == 0) return TokKind(KBackslash{});
        if (c->ctor == "KLambdaBar" && c->args.size() == 1) return TokKind(KLambdaBar{TRY(prism_rtl::from_pod<bool>(c->args[0]))});
        if (c->ctor == "KBar" && c->args.size() == 0) return TokKind(KBar{});
        if (c->ctor == "KLtLt" && c->args.size() == 0) return TokKind(KLtLt{});
        if (c->ctor == "KGtGt" && c->args.size() == 0) return TokKind(KGtGt{});
        if (c->ctor == "KOpen" && c->args.size() == 2) return TokKind(KOpen{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<bool>(c->args[1]))});
        if (c->ctor == "KClose" && c->args.size() == 1) return TokKind(KClose{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "KAbsent" && c->args.size() == 0) return TokKind(KAbsent{});
        if (c->ctor == "KNonEmpty" && c->args.size() == 0) return TokKind(KNonEmpty{});
        if (c->ctor == "KPath" && c->args.size() == 1) return TokKind(KPath{TRY(prism_rtl::from_pod<Array<PathSegTok>>(c->args[0]))});
        if (c->ctor == "KLayOpen" && c->args.size() == 0) return TokKind(KLayOpen{});
        if (c->ctor == "KLaySep" && c->args.size() == 0) return TokKind(KLaySep{});
        if (c->ctor == "KLayClose" && c->args.size() == 0) return TokKind(KLayClose{});
        if (c->ctor == "KEof" && c->args.size() == 0) return TokKind(KEof{});
    }
    return mismatch<TokKind>("a TokKind", p);
}


/// Fresh: fn Lex, Mode -> Lex
Lex fresh(const Lex& l, const Mode& mode) {
    return Lex{.src = l.src, .pos = l.pos, .diags = l.diags, .mode = mode, .tokens = Array<Tok>{}, .layout = Array<Nat>{}, .frames = Array<Text>{}, .last_ws = true, .lambda_open = false, .pending_open = false, .pending_span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}, .line_first = Nat(0u), .mark_line_start = false, .first_line = true, .test_pending = Text::lit(""), .test_depth = std::optional<Nat>{}, .check_depth = std::optional<Nat>{}, .path_next = false};
}


/// IsLayoutOrEof: fn TokKind -> Bool
bool is_layout_or_eof(const TokKind& tok_kind0) {
    if (prism_rtl::is<TokKind::KLayOpen>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KLaySep>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KLayClose>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KEof>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// IsLayout: fn TokKind -> Bool
bool is_layout(const TokKind& tok_kind0) {
    if (prism_rtl::is<TokKind::KLayOpen>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KLaySep>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KLayClose>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// EndsOperand: fn TokKind -> Bool
bool ends_operand(const TokKind& tok_kind0) {
    if (prism_rtl::is<TokKind::KName>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KFamily>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KInt>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KFloat>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KDuration>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KChar>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KText>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KRegex>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KTemplate>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KClose>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KGtGt>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KNonEmpty>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KAbsent>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KKw>(tok_kind0)) {
        auto&& w = prism_rtl::as<TokKind::KKw>(tok_kind0).a0;
        return is_value_word(w);
    }
    {
        return false;
    }
}


/// IsValueWord: fn Text -> Bool
bool is_value_word(const Text& w) {
    return ((w == Text::lit("unit")) || (w == Text::lit("nil"))) || is_bound_word(w);
}


/// IsBoundWord: fn Text -> Bool
bool is_bound_word(const Text& w) {
    return (((w == Text::lit("key")) || (w == Text::lit("ix"))) || (w == Text::lit("jx"))) || (w == Text::lit("kx"));
}


/// let keywordList
Array<Text> keyword_list() {
    return Array(std::vector{Text::lit("module"), Text::lit("emit"), Text::lit("use"), Text::lit("type"), Text::lit("record"), Text::lit("choice"), Text::lit("row"), Text::lit("tag"), Text::lit("of"), Text::lit("derive"), Text::lit("trait"), Text::lit("impl"), Text::lit("where"), Text::lit("any"), Text::lit("let"), Text::lit("fn"), Text::lit("test"), Text::lit("check"), Text::lit("widget"), Text::lit("rebuild"), Text::lit("for"), Text::lit("given"), Text::lit("monad"), Text::lit("update"), Text::lit("while"), Text::lit("match"), Text::lit("if"), Text::lit("else"), Text::lit("otherwise"), Text::lit("require"), Text::lit("forbid"), Text::lit("return"), Text::lit("ignore"), Text::lit("then"), Text::lit("on"), Text::lit("not"), Text::lit("and"), Text::lit("or"), Text::lit("mod"), Text::lit("as"), Text::lit("output"), Text::lit("inline_text"), Text::lit("raw"), Text::lit("unbounded"), Text::lit("unit"), Text::lit("nil"), Text::lit("key"), Text::lit("ix"), Text::lit("jx"), Text::lit("kx")});
}


/// let keywordSet
Map<Text, bool> keyword_set() {
    return map(each(keyword_list(), [&](const Text& w) { return std::tuple{w, true}; }));
}


/// IsKeyword: fn Text -> Bool
bool is_keyword(const Text& w) {
    return crate::prelude::get(keyword_set(), w) != std::optional<bool>{};
}


/// TakesSuffix: fn Text -> Bool
bool takes_suffix(const Text& op) {
    return fold(Array(std::vector{Text::lit("<="), Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit(">"), Text::lit(">="), Text::lit("+"), Text::lit("-"), Text::lit("*"), Text::lit("/"), Text::lit("+?"), Text::lit("-?"), Text::lit("*?")}), false, [&](const bool& seen, const Text& o) { return seen || (o == op); });
}


/// CloseChar: fn Text -> Text
Text close_char(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("(")) {
            return Text::lit(")");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("[")) {
            return Text::lit("]");
        }
    }
    {
        return Text::lit("}");
    }
}


/// OpenOf: fn Text -> Text
Text open_of(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit(")")) {
            return Text::lit("(");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("]")) {
            return Text::lit("[");
        }
    }
    {
        return Text::lit("{");
    }
}


/// PrefixPosition: fn Lex -> Bool
bool prefix_position(const Lex& l) {
    return l.last_ws || no_operand_before(crate::syntax::lexer::chars::last(l->tokens));
}


/// NoOperandBefore: fn ?Tok -> Bool
bool no_operand_before(const std::optional<Tok>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return true;
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& t = prism_rtl::some_of(opt0);
        return !ends_operand(t.kind);
    }
    prism_rtl::unreachable("no arm matched");
}


/// TestWordOf: fn TokKind -> Text
Text test_word_of(const TokKind& tok_kind0) {
    if (prism_rtl::is<TokKind::KKw>(tok_kind0)) {
        auto&& c0_0_0 = prism_rtl::as<TokKind::KKw>(tok_kind0).a0;
        if (c0_0_0 == Text::lit("test")) {
            return Text::lit("test");
        }
    }
    if (prism_rtl::is<TokKind::KKw>(tok_kind0)) {
        auto&& c1_0_0 = prism_rtl::as<TokKind::KKw>(tok_kind0).a0;
        if (c1_0_0 == Text::lit("check")) {
            return Text::lit("check");
        }
    }
    {
        return Text::lit("");
    }
}


/// AllLayout: fn [Tok] -> Bool
bool all_layout(const Array<Tok>& ts) {
    return fold(ts, true, [&](const bool& ok_, const Tok& t) { return ok_ && is_layout(t.kind); });
}


/// PushTok: fn Lex, TokKind, Nat, Nat -> Lex
Lex push_tok(const Lex& l, const TokKind& kind, const Nat& start, const Nat& end) {
    Lex this_ = l;
    auto layout = is_layout_or_eof(kind);
    auto touches = ((!this_.last_ws) && (len(this_.tokens) > Nat(0u))) && (!layout);
    auto line_start = (!layout) && this_.mark_line_start;
    if (!layout) {
        this_.mark_line_start = false;
    }
    auto word = test_word_of(kind);
    if ((((word != Text::lit("")) && (this_.mode == Mode(Mode::MFile{}))) && (len(this_.layout) == Nat(1u))) && all_layout(drop(this_.tokens, this_.line_first))) {
        this_.test_pending = word;
    }
    this_.tokens = crate::prelude::push(this_.tokens, Tok{.kind = kind, .span = crate::syntax::Range{.start = start, .end = end}, .touches = touches, .line_start = line_start});
    this_.last_ws = false;
    return this_;
}


/// LayoutOn: fn Mode -> Bool
bool layout_on(const Mode& mode0) {
    if (prism_rtl::is<Mode::MFile>(mode0)) {
        return true;
    }
    if (prism_rtl::is<Mode::MBrace>(mode0)) {
        return true;
    }
    {
        return false;
    }
}


/// LayoutActive: fn Lex -> Bool
bool layout_active(const Lex& l) {
    return layout_on(l->mode) && (len(l.frames) == Nat(0u));
}


/// FatArrowOn: fn Lex -> Bool
bool fat_arrow_on(const Lex& l) {
    return (l.test_depth != std::optional<Nat>{}) || (l.check_depth != std::optional<Nat>{});
}

}  // namespace crate::syntax::lexer


// The module `Syntax.Lexer.Chars`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/chars.prism`.
namespace crate::syntax::lexer::chars {

/// Dec: fn Nat -> Nat
Nat dec(const Nat& n) {
    return or_(n.checked_sub(Nat(1u)), Nat(0u));
}


/// Join: fn [Text], Text -> Text
Text join(const Array<Text>& xs, const Text& sep) {
    auto&& _m = index(xs, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& first_ = prism_rtl::some_of(_m);
        return concat(fold(drop(xs, Nat(1u)), Array(std::vector{first_}), [&](const Array<Text>& acc, const Text& x) { return crate::prelude::push(crate::prelude::push(acc, sep), x); }));
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// CharAt: fn Cursor -> Text
Text char_at(const Cursor& c) {
    auto&& _m = step(front(after(c)));
    if (prism_rtl::is_some(_m)) {
        auto&& one = std::get<1>(prism_rtl::some_of(_m));
        return before(one);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Head: fn Text -> Text
Text head(const Text& t) {
    return char_at(front(t));
}


/// AfterFirst: fn Text -> Text
Text after_first(const Text& t) {
    auto&& _m = step(front(t));
    if (prism_rtl::is_some(_m)) {
        auto&& c = std::get<1>(prism_rtl::some_of(_m));
        return after(c);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// LastChar: fn Text -> Text
Text last_char(const Text& t) {
    auto&& _m = step_back(back(t));
    if (prism_rtl::is_some(_m)) {
        auto&& c = std::get<1>(prism_rtl::some_of(_m));
        return after(c);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// BeforeLast: fn Text -> Text
Text before_last(const Text& t) {
    auto&& _m = step_back(back(t));
    if (prism_rtl::is_some(_m)) {
        auto&& c = std::get<1>(prism_rtl::some_of(_m));
        return before(c);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Between: fn Text, Nat, Nat -> Text
Text between(const Text& t, const Nat& a, const Nat& b) {
    auto&& _m = cursor_at(t, b);
    if (prism_rtl::is_some(_m)) {
        auto&& cb = prism_rtl::some_of(_m);
        auto&& _m = cursor_at(before(cb), a);
        if (prism_rtl::is_some(_m)) {
            auto&& ca = prism_rtl::some_of(_m);
            return after(ca);
        }
        if (prism_rtl::is_none(_m)) {
            return Text::lit("");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?AfterPrefix: fn Text, Text -> ?Text
std::optional<Text> after_prefix(const Text& t, const Text& p_) {
    auto&& _m = cursor_at(t, len_text(p_));
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        return before(c) == p_ ? std::optional(after(c)) : std::optional<Text>{};
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// HasPrefix: fn Text, Text -> Bool
bool has_prefix(const Text& t, const Text& p_) {
    return after_prefix(t, p_) != std::optional<Text>{};
}


/// DropPrefix: fn Text, Text -> Text
Text drop_prefix(const Text& t, const Text& p_) {
    return or_(after_prefix(t, p_), t);
}


/// ?BeforeSuffix: fn Text, Text -> ?Text
std::optional<Text> before_suffix(const Text& t, const Text& s) {
    auto&& _m = len_text(t).checked_sub(len_text(s));
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        auto&& _m = cursor_at(t, n);
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            return after(c) == s ? std::optional(before(c)) : std::optional<Text>{};
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<Text>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// HasSuffix: fn Text, Text -> Bool
bool has_suffix(const Text& t, const Text& s) {
    return before_suffix(t, s) != std::optional<Text>{};
}


/// MapChars: fn Text, (fn Text -> Text) -> Text
Text map_chars(const Text& t, const prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>& f_fn) {
    return concat(fold_chars(t, Array<Text>{}, ({
        auto f_fn_1 = f_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto f_fn_1_2 = f_fn_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                call_value(f_fn_1_2(c), [=](Text f_3224) { return prism_rtl::finished(crate::prelude::push(acc, f_3224)); });
            });
        }));
        });
    })));
    })));
}


/// CountChars: fn Text -> Nat
Nat count_chars(const Text& t) {
    return fold_chars(t, Nat(0u), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=](std::tuple<Nat, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto n = p0;
                static_cast<void>(p1);
                (prism_rtl::finished(n + Nat(1u)));
            });
        });
    })));
}


/// ColumnOf: fn Text, Nat, Nat -> Nat
Nat column_of(const Text& text_, const Nat& from, const Nat& offset) {
    return count_chars(between(text_, from, offset));
}


/// AllChars: fn Text, (fn Text -> Bool) -> Bool
bool all_chars(const Text& t, const prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>& p__fn) {
    return fold_chars(t, true, ({
        auto p__fn_1 = p__fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=](std::tuple<bool, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto p__fn_1_2 = p__fn_1;
            entered(once_job([=]() {
            return ({
                auto ok_ = p0;
                auto c = p1;
                (prism_rtl::finished(ok_ && run_to_end(p__fn_1_2(c))));
            });
        }));
        });
    })));
    }));
}


/// TrimLeading: fn Text, Text -> Text
Text trim_leading(const Text& t, const Text& set) {
    auto c = ({
        Cursor this_ = front(t);
        while (true) {
            auto&& _m = step(this_);
            if (!(prism_rtl::is_some(_m))) break;
            auto&& next_ = std::get<1>(prism_rtl::some_of(_m));
            if (!contains(set, char_at(this_))) {
                break;
            }
            this_ = next_;
        }
        this_;
    });
    return after(c);
}


/// TrimTrailing: fn Text, Text -> Text
Text trim_trailing(const Text& t, const Text& set) {
    auto c = ({
        Cursor this_ = back(t);
        Nat fuel = len_text(t);
        while (true) {
            auto&& _m = fuel.checked_sub(Nat(1u));
            if (!(prism_rtl::is_some(_m))) break;
            auto&& left = prism_rtl::some_of(_m);
            fuel = left;
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = step_back(this_);
                if (prism_rtl::is_some(_m)) {
                    auto&& prev = std::get<1>(prism_rtl::some_of(_m));
                    if (contains(set, char_at(prev))) {
                        _v.set(({
                            this_ = prev;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        fuel = Nat(0u);
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
        }
        this_;
    });
    return before(c);
}


/// TrimStart: fn Text -> Text
Text trim_start(const Text& t) {
    return trim_leading(t, Text::lit(" \r"));
}


/// TrimEnd: fn Text -> Text
Text trim_end(const Text& t) {
    return trim_trailing(t, Text::lit(" \r"));
}


/// Trim: fn Text -> Text
Text trim(const Text& t) {
    return trim_end(trim_start(t));
}


/// LeadingIn: fn Text, Text -> Nat
Nat leading_in(const Text& t, const Text& set) {
    return or_(len_text(t).checked_sub(len_text(trim_leading(t, set))), Nat(0u));
}


/// Contains: fn Text, Text -> Bool
bool contains(const Text& set, const Text& c) {
    return (c != Text::lit("")) && (len(split_on(set, c)) > Nat(1u));
}


/// IsDigit: fn Text -> Bool
bool is_digit(const Text& c) {
    return (Text::lit("0") <= c) && (c <= Text::lit("9"));
}


/// IsUpper: fn Text -> Bool
bool is_upper(const Text& c) {
    return (Text::lit("A") <= c) && (c <= Text::lit("Z"));
}


/// IsLower: fn Text -> Bool
bool is_lower(const Text& c) {
    return (Text::lit("a") <= c) && (c <= Text::lit("z"));
}


/// IsIdentStart: fn Text -> Bool
bool is_ident_start(const Text& c) {
    return (is_lower(c) || is_upper(c)) || (c == Text::lit("_"));
}


/// IsIdentChar: fn Text -> Bool
bool is_ident_char(const Text& c) {
    return is_ident_start(c) || is_digit(c);
}


/// IsHexDigit: fn Text -> Bool
bool is_hex_digit(const Text& c) {
    return (is_digit(c) || ((Text::lit("a") <= c) && (c <= Text::lit("f")))) || ((Text::lit("A") <= c) && (c <= Text::lit("F")));
}


/// IsNonAscii: fn Text -> Bool
bool is_non_ascii(const Text& c) {
    return c > Text::lit("");
}


/// IsSigilChar: fn Text -> Bool
bool is_sigil_char(const Text& c) {
    return contains(Text::lit("$!@?~&"), c);
}


/// IsSpaceChar: fn Text -> Bool
bool is_space_char(const Text& c) {
    return (((c == Text::lit(" ")) || (c == Text::lit("\n"))) || (c == Text::lit("\r"))) || (c == Text::lit("\t"));
}


/// IsReservedCtor: fn Text -> Bool
bool is_reserved_ctor(const Text& w) {
    return (w == Text::lit("templatetext")) || (w == Text::lit("templateplaceholder"));
}


/// let asciiText
Text ascii_text() {
    return Text::lit("\000\t\n\r !\"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"sv);
}


/// let hexDigits
Text hex_digits() {
    return Text::lit("0123456789abcdef");
}


/// CharAtByte: fn Text, Nat -> Text
Text char_at_byte(const Text& t, const Nat& n) {
    auto&& _m = cursor_at(t, n);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        return char_at(c);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// HexValue: fn Text -> Nat
Nat hex_value(const Text& c) {
    auto l = crate::prelude::lower(c);
    return l == Text::lit("")
        ? Nat(16u)
        : len_text(or_(index(split_on(hex_digits(), l), Nat(0u)), hex_digits()));
}


/// ?ParseHex: fn Text -> ?Nat
std::optional<Nat> parse_hex(const Text& t) {
    return ({
        __label__ g7309;
        prism_rtl::Slot<std::optional<Nat>> g7309_v;
        {
            if (!((t != Text::lit("")) && all_chars(t, ({
                auto f = prism_rtl::rc(is_hex_digit);
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text a0) {
                return ({
                    auto f_1 = f;
                    once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                });
            })));
            })))) {
                { g7309_v.set(std::nullopt); goto g7309; }
            }
            g7309_v.set(std::optional(fold_chars(t, Nat(0u), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=](std::tuple<Nat, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return once_job([=]() {
                    return ({
                        auto n = p0;
                        auto c = p1;
                        (prism_rtl::finished((n * Nat(16u)) + hex_value(c)));
                    });
                });
            })))));
        }
    g7309:
        g7309_v.take();
    });
}


/// ?AsciiChar: fn Nat -> ?Text
std::optional<Text> ascii_char(const Nat& n) {
    return n < Nat(128u)
        ? std::optional(char_at_byte(ascii_text(), n))
        : std::optional<Text>{};
}


/// Rest: fn Lex -> Text
Text rest(const crate::syntax::lexer::Lex& l) {
    auto&& _m = cursor_at(l.src, l.pos);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        return after(c);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Peek: fn Lex -> Text
Text peek(const crate::syntax::lexer::Lex& l) {
    return char_at_byte(l.src, l.pos);
}


/// PeekAt: fn Lex, Nat -> Text
Text peek_at(const crate::syntax::lexer::Lex& l, const Nat& n) {
    auto rest_ = ({
        Text this_ = rest(l);
        Nat k = n;
        while (true) {
            auto&& _m = k.checked_sub(Nat(1u));
            if (!(prism_rtl::is_some(_m))) break;
            auto&& left = prism_rtl::some_of(_m);
            k = left;
            this_ = after_first(this_);
        }
        this_;
    });
    return head(rest_);
}


/// StartsWith: fn Lex, Text -> Bool
bool starts_with(const crate::syntax::lexer::Lex& l, const Text& s) {
    return has_prefix(rest(l), s);
}


/// Slice: fn Lex, Nat, Nat -> Text
Text slice(const crate::syntax::lexer::Lex& l, const Nat& a, const Nat& b) {
    return between(l.src, a, b);
}


/// Bump: fn Lex -> Lex
crate::syntax::lexer::Lex bump(const crate::syntax::lexer::Lex& l) {
    crate::syntax::lexer::Lex this_ = l;
    this_.pos = this_.pos + len_text(peek(this_));
    return this_;
}


/// Forward: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex forward(const crate::syntax::lexer::Lex& l, const Nat& n) {
    crate::syntax::lexer::Lex this_ = l;
    Nat k = n;
    while (true) {
        auto&& _m = k.checked_sub(Nat(1u));
        if (!(prism_rtl::is_some(_m))) break;
        auto&& left = prism_rtl::some_of(_m);
        k = left;
        this_.pos = this_.pos + len_text(peek(this_));
    }
    return this_;
}


/// NextIsSpace: fn Lex, Nat -> Bool
bool next_is_space(const crate::syntax::lexer::Lex& l, const Nat& n) {
    auto c = peek_at(l, n);
    return (c == Text::lit("")) || is_space_char(c);
}


/// MatchEnd: fn Regex, Text, Nat -> Nat
Nat match_end(const Regex& r, const Text& src, const Nat& at_) {
    auto&& _m = cursor_at(src, at_);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        auto&& _m = match_(r, c);
        if (prism_rtl::is_some(_m)) {
            auto&& m = prism_rtl::some_of(_m);
            return at(m.back);
        }
        if (prism_rtl::is_none(_m)) {
            return at_;
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return at_;
    }
    prism_rtl::unreachable("no arm matched");
}


/// MatchHere: fn Regex, Lex -> Text
Text match_here(const Regex& r, const crate::syntax::lexer::Lex& l) {
    return between(l.src, l.pos, match_end(r, l.src, l.pos));
}


/// LineEnd: fn Lex -> Nat
Nat line_end(const crate::syntax::lexer::Lex& l) {
    return match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[^\\n]*", ""); return r; }()), l.src, l.pos);
}


/// RestOfLine: unbounded fn Lex -> Text
Text rest_of_line(const crate::syntax::lexer::Lex& l) {
    return slice(l, l.pos, line_end(l));
}


prism_rtl::Turn<Text> RestOfLine::cycle() const {
    const auto& l = this->l;
    return prism_rtl::finished(slice(l, l.pos, line_end(l)));
}


/// `Start RestOfLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rest_of_line(crate::syntax::lexer::Lex l) {
    return prism_rtl::make_rc<RestOfLine>(l);
}


/// LexErr: fn Lex, Nat, Nat, Text -> Lex
crate::syntax::lexer::Lex lex_err(const crate::syntax::lexer::Lex& l, const Nat& start, const Nat& end, const Text& message) {
    crate::syntax::lexer::Lex this_ = l;
    this_.diags = crate::prelude::push(this_.diags, lex_diag(crate::syntax::Range{.start = start, .end = crate::prelude::max(end, start)}, message));
    return this_;
}


/// LexDiag: fn Range, Text -> Diag
crate::syntax::Diag lex_diag(const crate::syntax::Range& span, const Text& message) {
    return crate::syntax::Diag{.stage = Text::lit("lex"), .span = span, .message = message, .feature = std::optional<Text>{}};
}

}  // namespace crate::syntax::lexer::chars


// The module `Syntax.Lexer.Corpus`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/corpus.prism`.
namespace crate::syntax::lexer::corpus {

/// RenderTokens: fn [Tok] -> Text
Text render_tokens(const Array<crate::syntax::lexer::Tok>& tokens) {
    auto&& _out = fold(tokens, std::tuple{Text::lit(""), std::optional<crate::syntax::lexer::Tok>{}}, [&](const std::tuple<Text, std::optional<crate::syntax::lexer::Tok>>& _p0, const crate::syntax::lexer::Tok& t) {
        auto&& acc = std::get<0>(_p0);
        auto&& prev_opt = std::get<1>(_p0);
        return render_step(acc, prev_opt, t);
    });
    auto&& out = std::get<0>(_out);
    return prism_rtl::cat(out, "\n");
}


/// RenderStep: fn Text, ?Tok, Tok -> ((Text, ?Tok))
std::tuple<Text, std::optional<crate::syntax::lexer::Tok>> render_step(const Text& acc, const std::optional<crate::syntax::lexer::Tok>& prev_opt, const crate::syntax::lexer::Tok& t) {
    auto gap = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_none(prev_opt)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        if (prism_rtl::is_some(prev_opt)) {
            auto&& p_ = prism_rtl::some_of(prev_opt);
            _v.set(crate::syntax::lexer::is_layout(t.kind)
                ? Text::lit("\n")
                : (is_bracket(p_.kind) && is_bracket(t.kind)) && t.touches
                ? Text::lit("·")
                : Text::lit(" "));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return t.kind == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{})
        ? std::tuple{acc, std::optional(t)}
        : std::tuple{prism_rtl::cat(acc, gap, token_text(t.kind)), std::optional(t)};
}


/// IsBracket: fn TokKind -> Bool
bool is_bracket(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KClose>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// RenderInner: fn [Tok] -> Text
Text render_inner(const Array<crate::syntax::lexer::Tok>& tokens) {
    return crate::syntax::lexer::chars::join(split_on(crate::syntax::lexer::chars::trim_end(trim_newlines(render_tokens(tokens))), Text::lit("\n")), Text::lit(" "));
}


/// TrimNewlines: fn Text -> Text
Text trim_newlines(const Text& t) {
    return crate::syntax::lexer::chars::trim_trailing(t, Text::lit("\n \t"));
}


/// TokenText: fn TokKind -> Text
Text token_text(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(tok_kind0)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(tok_kind0).a0;
        return prism_rtl::cat(n.sigils, crate::syntax::lexer::chars::join(n->path_, Text::lit(".")));
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(tok_kind0)) {
        auto&& p_ = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(tok_kind0).a0;
        return prism_rtl::cat(crate::syntax::lexer::chars::join(p_, Text::lit(".")), ".*");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTrait>(tok_kind0)) {
        auto&& p_ = prism_rtl::as<crate::syntax::lexer::TokKind::KTrait>(tok_kind0).a0;
        return prism_rtl::cat("^", crate::syntax::lexer::chars::join(p_, Text::lit(".")));
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(tok_kind0)) {
        auto&& w = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(tok_kind0).a0;
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(tok_kind0).a1;
        return prism_rtl::cat(s, w);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(tok_kind0)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(tok_kind0).a0;
        return prism_rtl::cat("free", s);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLensDot>(tok_kind0)) {
        return Text::lit("&.");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(tok_kind0)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(tok_kind0).a0;
        auto&& t = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(tok_kind0).a1;
        return prism_rtl::cat(s, t);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(tok_kind0)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFloat>(tok_kind0).a0;
        auto&& t = prism_rtl::as<crate::syntax::lexer::TokKind::KFloat>(tok_kind0).a1;
        return prism_rtl::cat(s, t);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(tok_kind0)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KDuration>(tok_kind0).a0;
        auto&& t = prism_rtl::as<crate::syntax::lexer::TokKind::KDuration>(tok_kind0).a1;
        auto&& u = prism_rtl::as<crate::syntax::lexer::TokKind::KDuration>(tok_kind0).a2;
        return prism_rtl::cat(s, t, u);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(tok_kind0)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KChar>(tok_kind0).a0;
        auto&& c = prism_rtl::as<crate::syntax::lexer::TokKind::KChar>(tok_kind0).a1;
        return prism_rtl::cat(s, debug_char(c));
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(tok_kind0)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(tok_kind0).a0;
        auto&& segs = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(tok_kind0).a1;
        return prism_rtl::cat(s, "TEXT(", concat(each(segs, seg_text)), ")");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KRegex>(tok_kind0)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KRegex>(tok_kind0).a0;
        auto&& r = prism_rtl::as<crate::syntax::lexer::TokKind::KRegex>(tok_kind0).a1;
        return prism_rtl::cat(s, "REGEX(", debug_text(r.pattern), "/", replacement_text(r.replacement), r.flags, ")");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTemplate>(tok_kind0)) {
        auto&& t = prism_rtl::as<crate::syntax::lexer::TokKind::KTemplate>(tok_kind0).a0;
        return prism_rtl::cat("TEMPLATE<", t.lang, ">(", concat(each(t.parts, part_text)), ")");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(tok_kind0) && prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(tok_kind0).a1) {
        auto&& op = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(tok_kind0).a0;
        return prism_rtl::cat(op, "pre");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(tok_kind0) && !prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(tok_kind0).a1) {
        auto&& op = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(tok_kind0).a0;
        return op;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KSuffixed>(tok_kind0)) {
        auto&& op = prism_rtl::as<crate::syntax::lexer::TokKind::KSuffixed>(tok_kind0).a0;
        auto&& ty = prism_rtl::as<crate::syntax::lexer::TokKind::KSuffixed>(tok_kind0).a1;
        return prism_rtl::cat(op, crate::syntax::lexer::chars::join(ty, Text::lit(".")));
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(tok_kind0) && prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(tok_kind0).a0) {
        return Text::lit(".pre");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(tok_kind0) && !prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(tok_kind0).a0) {
        return Text::lit(".");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDotDot>(tok_kind0)) {
        return Text::lit("..");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KComma>(tok_kind0)) {
        return Text::lit(",");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KColon>(tok_kind0)) {
        return Text::lit(":");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KSemi>(tok_kind0)) {
        return Text::lit(";");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KBackslash>(tok_kind0)) {
        return Text::lit("\\");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLambdaBar>(tok_kind0)) {
        return Text::lit("|");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KBar>(tok_kind0)) {
        return Text::lit("|");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLtLt>(tok_kind0)) {
        return Text::lit("<<");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KGtGt>(tok_kind0)) {
        return Text::lit(">>");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(tok_kind0)) {
        auto&& k = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(tok_kind0).a0;
        return k;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KClose>(tok_kind0)) {
        auto&& k = prism_rtl::as<crate::syntax::lexer::TokKind::KClose>(tok_kind0).a0;
        return crate::syntax::lexer::close_char(k);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KAbsent>(tok_kind0)) {
        return Text::lit("absent");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KNonEmpty>(tok_kind0)) {
        return Text::lit("nonempty");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KPath>(tok_kind0)) {
        auto&& segs = prism_rtl::as<crate::syntax::lexer::TokKind::KPath>(tok_kind0).a0;
        return prism_rtl::cat("PATH(", crate::syntax::lexer::chars::join(each(segs, path_seg_text), Text::lit("/")), ")");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayOpen>(tok_kind0)) {
        return Text::lit("open");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(tok_kind0)) {
        return Text::lit("sep");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(tok_kind0)) {
        return Text::lit("close");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(tok_kind0)) {
        return Text::lit("eof");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ReplacementText: fn ?Text -> Text
Text replacement_text(const std::optional<Text>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& t = prism_rtl::some_of(opt0);
        return prism_rtl::cat(debug_text(t), "/");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SegText: fn TextSegTok -> Text
Text seg_text(const crate::syntax::lexer::TextSegTok& text_seg_tok0) {
    if (prism_rtl::is<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok0)) {
        auto&& p_ = prism_rtl::as<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok0).a0;
        return escape_braces(escape_debug(p_, true, true));
    }
    if (prism_rtl::is<crate::syntax::lexer::TextSegTok::TsPlaceholder>(text_seg_tok0)) {
        auto&& toks = prism_rtl::as<crate::syntax::lexer::TextSegTok::TsPlaceholder>(text_seg_tok0).a0;
        return prism_rtl::cat("{", render_inner(toks), "}");
    }
    prism_rtl::unreachable("no arm matched");
}


/// EscapeBraces: fn Text -> Text
Text escape_braces(const Text& t) {
    return crate::syntax::lexer::chars::map_chars(t, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return once_job([=]() {
            return ({
                auto c = p0;
                (c == Text::lit("{")) || (c == Text::lit("}"))
                ? prism_rtl::finished(prism_rtl::cat("\\", c))
                : prism_rtl::finished(c);
            });
        });
    })));
}


/// PathSegText: fn PathSegTok -> Text
Text path_seg_text(const crate::syntax::lexer::PathSegTok& path_seg_tok0) {
    if (prism_rtl::is<crate::syntax::lexer::PathSegTok::PstNum>(path_seg_tok0)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::PathSegTok::PstNum>(path_seg_tok0).a0;
        return prism_rtl::cat(n);
    }
    if (prism_rtl::is<crate::syntax::lexer::PathSegTok::PstGen>(path_seg_tok0)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::PathSegTok::PstGen>(path_seg_tok0).a0;
        return prism_rtl::cat("#", n);
    }
    if (prism_rtl::is<crate::syntax::lexer::PathSegTok::PstKey>(path_seg_tok0)) {
        auto&& toks = prism_rtl::as<crate::syntax::lexer::PathSegTok::PstKey>(path_seg_tok0).a0;
        return prism_rtl::cat("[", render_inner(toks), "]");
    }
    prism_rtl::unreachable("no arm matched");
}


/// PartText: fn TPartTok -> Text
Text part_text(const crate::syntax::lexer::TPartTok& tpart_tok0) {
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(tpart_tok0)) {
        auto&& t = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(tpart_tok0).a0;
        return debug_text(t);
    }
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok0)) {
        auto&& toks = prism_rtl::as<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok0).a0;
        auto&& col_opt = prism_rtl::as<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok0).a1;
        return prism_rtl::cat("{{", render_inner(toks), "}}", col_text(col_opt));
    }
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptBlock>(tpart_tok0)) {
        auto&& toks = prism_rtl::as<crate::syntax::lexer::TPartTok::TptBlock>(tpart_tok0).a0;
        return prism_rtl::cat("BLOCK{ ", render_inner(toks), " }");
    }
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok0)) {
        auto&& name = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok0).a0;
        auto&& attrs = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok0).a1;
        auto&& body_opt = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok0).a2;
        return prism_rtl::cat("<", name.sigils, crate::syntax::lexer::chars::join(name->path_, Text::lit(".")), concat(each(attrs, attr_text)), call_body(name, body_opt));
    }
    prism_rtl::unreachable("no arm matched");
}


/// ColText: fn ?Nat -> Text
Text col_text(const std::optional<Nat>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& c = prism_rtl::some_of(opt0);
        return prism_rtl::cat("@col", c);
    }
    prism_rtl::unreachable("no arm matched");
}


/// AttrText: fn AttrTok -> Text
Text attr_text(const crate::syntax::lexer::AttrTok& a) {
    return prism_rtl::cat(" ", a.name, "={", render_inner(a->tokens), "}");
}


/// CallBody: fn NameTok, ?[TPartTok] -> Text
Text call_body(const crate::syntax::lexer::NameTok& name_tok0, const std::optional<Array<crate::syntax::lexer::TPartTok>>& opt1) {
    auto&& _m = std::tuple{name_tok0, opt1};
    if (prism_rtl::is_none(std::get<1>(_m))) {
        return Text::lit("/>");
    }
    if (prism_rtl::is_some(std::get<1>(_m))) {
        auto&& name = std::get<0>(_m);
        auto&& parts = prism_rtl::some_of(std::get<1>(_m));
        return prism_rtl::cat(">", concat(each(parts, part_text)), "</", name.sigils, crate::syntax::lexer::chars::join(name->path_, Text::lit(".")), ">");
    }
    prism_rtl::unreachable("no arm matched");
}


/// DebugText: fn Text -> Text
Text debug_text(const Text& t) {
    return prism_rtl::cat("\"", escape_debug(t, false, true), "\"");
}


/// DebugChar: fn Text -> Text
Text debug_char(const Text& c) {
    return prism_rtl::cat("\'", escape_debug(c, true, false), "\'");
}


/// EscapeDebug: fn Text, Bool, Bool -> Text
Text escape_debug(const Text& t, const bool& single, const bool& double_) {
    return crate::syntax::lexer::chars::map_chars(t, ({
        auto single_1 = single;
        auto double__2 = double_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto single_1_3 = single_1;
            auto double__2_3 = double__2;
            once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::finished(escape_char(c, single_1_3, double__2_3)));
            });
        });
        });
    })));
    }));
}


/// EscapeChar: fn Text, Bool, Bool -> Text
Text escape_char(const Text& c, const bool& single, const bool& double_) {
    {
        auto&& m5021_0 = c;
        if (m5021_0 == Text::lit("\000"sv)) {
            return Text::lit("\\0");
        }
    }
    {
        auto&& m5021_1 = c;
        if (m5021_1 == Text::lit("\t")) {
            return Text::lit("\\t");
        }
    }
    {
        auto&& m5021_2 = c;
        if (m5021_2 == Text::lit("\r")) {
            return Text::lit("\\r");
        }
    }
    {
        auto&& m5021_3 = c;
        if (m5021_3 == Text::lit("\n")) {
            return Text::lit("\\n");
        }
    }
    {
        auto&& m5021_4 = c;
        if (m5021_4 == Text::lit("\\")) {
            return Text::lit("\\\\");
        }
    }
    {
        auto&& m5021_5 = c;
        if (m5021_5 == Text::lit("\'")) {
            if (single) {
                return Text::lit("\\\'");
            }
        }
    }
    {
        auto&& m5021_6 = c;
        if (m5021_6 == Text::lit("\"")) {
            if (double_) {
                return Text::lit("\\\"");
            }
        }
    }
    {
        if ((c < Text::lit(" ")) || (c == Text::lit(""))) {
            return prism_rtl::cat("\\u{", hex_of(code_of(c)), "}");
        }
    }
    {
        return c;
    }
}


/// CodeOf: fn Text -> Nat
Nat code_of(const Text& c) {
    return c == Text::lit("")
        ? Nat(128u)
        : len_text(or_(index(split_on(crate::syntax::lexer::chars::ascii_text(), c), Nat(0u)), crate::syntax::lexer::chars::ascii_text()));
}


/// HexOf: fn Nat -> Text
Text hex_of(const Nat& n) {
    return hex_digits(n, n);
}


/// HexDigits: fn Nat, Nat -> Text
Text hex_digits(const Nat& n, const Nat& fuel) {
    auto&& _m = fuel.checked_sub(Nat(1u));
    if (prism_rtl::is_some(_m)) {
        auto&& left = prism_rtl::some_of(_m);
        if (n >= Nat(16u)) {
            return prism_rtl::cat(hex_digits(or_(div(n, Nat(16u)), Nat(0u)), left), crate::syntax::lexer::chars::char_at_byte(crate::syntax::lexer::chars::hex_digits(), or_(mod_(n, Nat(16u)), Nat(0u))));
        }
    }
    {
        return n < Nat(16u)
            ? crate::syntax::lexer::chars::char_at_byte(crate::syntax::lexer::chars::hex_digits(), n)
            : Text::lit("0");
    }
}

}  // namespace crate::syntax::lexer::corpus


// The module `Syntax.Lexer.Layout`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/layout.prism`.
namespace crate::syntax::lexer::layout {

/// LexFile: unbounded fn Text -> Lexed
crate::syntax::lexer::Lexed lex_file(const Text& src) {
    auto start = crate::syntax::lexer::Lex{.src = src, .pos = Nat(0u), .diags = Array<crate::syntax::Diag>{}, .mode = crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MFile{}), .tokens = Array<crate::syntax::lexer::Tok>{}, .layout = Array<Nat>{}, .frames = Array<Text>{}, .last_ws = true, .lambda_open = false, .pending_open = false, .pending_span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}, .line_first = Nat(0u), .mark_line_start = false, .first_line = true, .test_pending = Text::lit(""), .test_depth = std::optional<Nat>{}, .check_depth = std::optional<Nat>{}, .path_next = false};
    auto skipped = skip_blank_and_comment_lines(start);
    auto opened = (crate::syntax::lexer::chars::peek(skipped) == Text::lit("<")) && (crate::syntax::lexer::templates::template_tag_ahead(skipped) != Text::lit(""));
    auto [head, l] = opened
        ? template_head(skipped)
        : std::tuple{Array<crate::syntax::lexer::Tok>{}, start};
    auto body = lex_stream(crate::syntax::lexer::fresh(l, crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MFile{})));
    return crate::syntax::lexer::Lexed{.tokens = append(head, body->tokens), .diags = body.diags};
}


prism_rtl::Turn<crate::syntax::lexer::Lexed> LexFile::cycle() const {
    const auto& src = this->src;
    auto start = crate::syntax::lexer::Lex{.src = src, .pos = Nat(0u), .diags = Array<crate::syntax::Diag>{}, .mode = crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MFile{}), .tokens = Array<crate::syntax::lexer::Tok>{}, .layout = Array<Nat>{}, .frames = Array<Text>{}, .last_ws = true, .lambda_open = false, .pending_open = false, .pending_span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}, .line_first = Nat(0u), .mark_line_start = false, .first_line = true, .test_pending = Text::lit(""), .test_depth = std::optional<Nat>{}, .check_depth = std::optional<Nat>{}, .path_next = false};
    return call_then(start_skip_blank_and_comment_lines(start), [=](crate::syntax::lexer::Lex skip_blank_and_comment_lines_1051) {
        return ({
            auto skipped = skip_blank_and_comment_lines_1051;
            auto opened = (crate::syntax::lexer::chars::peek(skipped) == Text::lit("<")) && (crate::syntax::lexer::templates::template_tag_ahead(skipped) != Text::lit(""));
            auto [head, l] = opened
                ? template_head(skipped)
                : std::tuple{Array<crate::syntax::lexer::Tok>{}, start};
            call_then(start_lex_stream(crate::syntax::lexer::fresh(l, crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MFile{}))), [=](crate::syntax::lexer::Lex lex_stream_1249) {
            return ({
                auto body = lex_stream_1249;
                (prism_rtl::finished(crate::syntax::lexer::Lexed{.tokens = append(head, body->tokens), .diags = body.diags}));
            });
        });
        });
    });
}


/// `Start LexFile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lexed> start_lex_file(Text src) {
    return prism_rtl::make_rc<LexFile>(src);
}


/// TemplateHead: unbounded fn Lex -> (([Tok], Lex))
std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> template_head(const crate::syntax::lexer::Lex& l0) {
    auto [kind, l] = crate::syntax::lexer::templates::lex_template(l0, Text::lit("File"), l0.pos);
    auto tok = crate::syntax::lexer::Tok{.kind = kind, .span = crate::syntax::Range{.start = l0.pos, .end = l.pos}, .touches = false, .line_start = false};
    return std::tuple{Array(std::vector{tok}), l};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex>> TemplateHead::cycle() const {
    const auto& l0 = this->l0;
    auto l0_1 = l0;
    return call_then(crate::syntax::lexer::templates::start_lex_template(l0_1, Text::lit("File"), l0_1.pos), [=](std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_template_1501) {
        return ({
            auto [kind, l] = lex_template_1501;
            auto tok = crate::syntax::lexer::Tok{.kind = kind, .span = crate::syntax::Range{.start = l0_1.pos, .end = l.pos}, .touches = false, .line_start = false};
            (prism_rtl::finished(std::tuple{Array(std::vector{tok}), l}));
        });
    });
}


/// `Start TemplateHead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex>> start_template_head(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<TemplateHead>(l0);
}


/// SkipBlankAndCommentLines: unbounded fn Lex -> Lex
crate::syntax::lexer::Lex skip_blank_and_comment_lines(const crate::syntax::lexer::Lex& l) {
    crate::syntax::lexer::Lex this_ = l;
    bool going = true;
    while (going) {
        auto line = crate::syntax::lexer::chars::rest_of_line(this_);
        auto t = crate::syntax::lexer::chars::trim_start(line);
        if (((t == Text::lit("")) || (crate::syntax::lexer::chars::head(t) == Text::lit("#"))) && ((this_.pos + len_text(line)) < len_text(this_.src))) {
            this_.pos = this_.pos + (len_text(line) + Nat(1u));
        } else  {
            going = false;
        }
    }
    return this_;
}


prism_rtl::Turn<crate::syntax::lexer::Lex> SkipBlankAndCommentLines::cycle() const {
    const auto& l = this->l;
    crate::syntax::lexer::Lex this_ = l;
    bool going = true;
    return call_then(loop_job(std::tuple{this_, going}, [=](std::tuple<crate::syntax::lexer::Lex, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        return going
            ? ({
            auto line = crate::syntax::lexer::chars::rest_of_line(this_);
            auto t = crate::syntax::lexer::chars::trim_start(line);
            if (((t == Text::lit("")) || (crate::syntax::lexer::chars::head(t) == Text::lit("#"))) && ((this_.pos + len_text(line)) < len_text(this_.src))) {
                this_.pos = this_.pos + (len_text(line) + Nat(1u));
            } else  {
                going = false;
            }
            Expected<std::tuple<crate::syntax::lexer::Lex, bool>, std::tuple<crate::syntax::lexer::Lex, bool>>(std::tuple{this_, going});
        })
            : Expected<std::tuple<crate::syntax::lexer::Lex, bool>, std::tuple<crate::syntax::lexer::Lex, bool>>(unexpected(std::tuple{this_, going}));
    }), [=](std::tuple<crate::syntax::lexer::Lex, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        return prism_rtl::finished(this_);
    });
}


/// `Start SkipBlankAndCommentLines, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_skip_blank_and_comment_lines(crate::syntax::lexer::Lex l) {
    return prism_rtl::make_rc<SkipBlankAndCommentLines>(l);
}


/// Nested: unbounded fn Lex, Mode -> (([Tok], Lex))
std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> nested(const crate::syntax::lexer::Lex& l, const crate::syntax::lexer::Mode& mode) {
    auto inner = lex_stream(crate::syntax::lexer::fresh(l, mode));
    auto back_ = ({
        crate::syntax::lexer::Lex this_ = l;
        this_.pos = inner.pos;
        this_.diags = inner.diags;
        this_;
    });
    return std::tuple{inner->tokens, back_};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex>> Nested::cycle() const {
    const auto& l = this->l;
    const auto& mode = this->mode;
    auto l_1 = l;
    auto mode_2 = mode;
    return call_then(start_lex_stream(crate::syntax::lexer::fresh(l_1, mode_2)), [=](crate::syntax::lexer::Lex lex_stream_2224) {
        return ({
            auto inner = lex_stream_2224;
            auto back_ = ({
                crate::syntax::lexer::Lex this_ = l_1;
                this_.pos = inner.pos;
                this_.diags = inner.diags;
                this_;
            });
            (prism_rtl::finished(std::tuple{inner->tokens, back_}));
        });
    });
}


/// `Start Nested, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex>> start_nested(crate::syntax::lexer::Lex l, crate::syntax::lexer::Mode mode) {
    return prism_rtl::make_rc<Nested>(l, mode);
}


/// LexStream: unbounded fn Lex -> Lex
crate::syntax::lexer::Lex lex_stream(const crate::syntax::lexer::Lex& l0) {
    crate::syntax::lexer::Lex this_ = l0;
    bool at_line_start = crate::syntax::lexer::layout_on(this_.mode);
    bool done = false;
    while (!done) {
        bool go = true;
        if (at_line_start && crate::syntax::lexer::layout_active(this_)) {
            at_line_start = false;
            auto [l, verdict] = begin_line(this_);
            this_ = l;
            if (verdict == Text::lit("skip")) {
                at_line_start = true;
                go = false;
            }
            if (verdict == Text::lit("end")) {
                done = true;
                go = false;
            }
        }
        if (go) {
            auto c = crate::syntax::lexer::chars::peek(this_);
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                {
                    auto&& u3052_0 = c;
                    if (u3052_0 == Text::lit("")) {
                        _v.set(({
                            this_ = unclosed_stream(this_);
                            done = true;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u3052_1 = c;
                    if (u3052_1 == Text::lit("\n")) {
                        _v.set(({
                            this_.pos = this_.pos + Nat(1u);
                            this_.last_ws = true;
                            if (this_.lambda_open) {
                                this_ = crate::syntax::lexer::chars::lex_err(this_, crate::syntax::lexer::chars::dec(this_.pos), this_.pos, Text::lit("a lambda\'s parameter list closes with `|` on its own line"));
                                this_.lambda_open = false;
                            }
                            if (crate::syntax::lexer::layout_active(this_)) {
                                this_ = end_line(this_);
                                at_line_start = true;
                            }
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u3052_2 = c;
                    if (u3052_2 == Text::lit(" ")) {
                        _v.set(({
                            this_.pos = this_.pos + Nat(1u);
                            this_.last_ws = true;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u3052_3 = c;
                    if (u3052_3 == Text::lit("\r")) {
                        _v.set(({
                            this_.pos = this_.pos + Nat(1u);
                            this_.last_ws = true;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u3052_4 = c;
                    if (u3052_4 == Text::lit("\t")) {
                        _v.set(({
                            this_.pos = this_.pos + Nat(1u);
                            this_.last_ws = true;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u3052_5 = c;
                    if (u3052_5 == Text::lit("#")) {
                        _v.set(({
                            this_.pos = crate::syntax::lexer::chars::line_end(this_);
                            this_.last_ws = true;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        auto [ends, l] = stream_ends_here(this_);
                        this_ = l;
                        if (ends) {
                            done = true;
                        } else  {
                            this_ = crate::syntax::lexer::words::lex_token(this_);
                        }
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
        }
    }
    if (crate::syntax::lexer::layout_on(this_.mode)) {
        while (len(this_.layout) > Nat(1u)) {
            this_.layout = crate::syntax::lexer::chars::pop(this_.layout);
            this_ = crate::syntax::lexer::push_tok(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayClose{}), this_.pos, this_.pos);
        }
    }
    if (this_.mode == crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MFile{})) {
        this_ = crate::syntax::lexer::push_tok(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), this_.pos, this_.pos);
    }
    return this_;
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexStream::cycle() const {
    const auto& l0 = this->l0;
    crate::syntax::lexer::Lex this_ = l0;
    bool at_line_start = crate::syntax::lexer::layout_on(this_.mode);
    bool done = false;
    return call_then(loop_job(std::tuple{this_, at_line_start, done}, [=](std::tuple<crate::syntax::lexer::Lex, bool, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto at_line_start = std::get<1>(_p0);
        auto done = std::get<2>(_p0);
        return !done
            ? ({
            bool go = true;
            if (at_line_start && crate::syntax::lexer::layout_active(this_)) {
                at_line_start = false;
                auto [l, verdict] = begin_line(this_);
                this_ = l;
                if (verdict == Text::lit("skip")) {
                    at_line_start = true;
                    go = false;
                }
                if (verdict == Text::lit("end")) {
                    done = true;
                    go = false;
                }
            }
            if (go) {
                auto c = crate::syntax::lexer::chars::peek(this_);
                ({
                    __label__ _done;
                    prism_rtl::Slot<Unit> _v;
                    {
                        auto&& u3052_0 = c;
                        if (u3052_0 == Text::lit("")) {
                            _v.set(({
                                this_ = unclosed_stream(this_);
                                done = true;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u3052_1 = c;
                        if (u3052_1 == Text::lit("\n")) {
                            _v.set(({
                                this_.pos = this_.pos + Nat(1u);
                                this_.last_ws = true;
                                if (this_.lambda_open) {
                                    this_ = crate::syntax::lexer::chars::lex_err(this_, crate::syntax::lexer::chars::dec(this_.pos), this_.pos, Text::lit("a lambda\'s parameter list closes with `|` on its own line"));
                                    this_.lambda_open = false;
                                }
                                if (crate::syntax::lexer::layout_active(this_)) {
                                    this_ = end_line(this_);
                                    at_line_start = true;
                                }
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u3052_2 = c;
                        if (u3052_2 == Text::lit(" ")) {
                            _v.set(({
                                this_.pos = this_.pos + Nat(1u);
                                this_.last_ws = true;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u3052_3 = c;
                        if (u3052_3 == Text::lit("\r")) {
                            _v.set(({
                                this_.pos = this_.pos + Nat(1u);
                                this_.last_ws = true;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u3052_4 = c;
                        if (u3052_4 == Text::lit("\t")) {
                            _v.set(({
                                this_.pos = this_.pos + Nat(1u);
                                this_.last_ws = true;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u3052_5 = c;
                        if (u3052_5 == Text::lit("#")) {
                            _v.set(({
                                this_.pos = crate::syntax::lexer::chars::line_end(this_);
                                this_.last_ws = true;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        _v.set(({
                            auto [ends, l] = stream_ends_here(this_);
                            this_ = l;
                            if (ends) {
                                done = true;
                            } else  {
                                this_ = crate::syntax::lexer::words::lex_token(this_);
                            }
                            Unit{};
                        }));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            }
            Expected<std::tuple<crate::syntax::lexer::Lex, bool, bool>, std::tuple<crate::syntax::lexer::Lex, bool, bool>>(std::tuple{this_, at_line_start, done});
        })
            : Expected<std::tuple<crate::syntax::lexer::Lex, bool, bool>, std::tuple<crate::syntax::lexer::Lex, bool, bool>>(unexpected(std::tuple{this_, at_line_start, done}));
    }), [=](std::tuple<crate::syntax::lexer::Lex, bool, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto at_line_start = std::get<1>(_p0);
        auto done = std::get<2>(_p0);
        return ({
            auto k_if4442 = [=](std::tuple<crate::syntax::lexer::Lex, bool, bool> _p0) {
                auto this_ = std::get<0>(_p0);
                auto at_line_start = std::get<1>(_p0);
                auto done = std::get<2>(_p0);
                return ({
                    if (this_->mode == crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MFile{})) {
                        this_ = crate::syntax::lexer::push_tok(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), this_.pos, this_.pos);
                    }
                    (prism_rtl::finished(this_));
                });
            };
            (crate::syntax::lexer::layout_on(this_->mode)
            ? call_then(loop_job(std::tuple{this_, at_line_start, done}, [=](std::tuple<crate::syntax::lexer::Lex, bool, bool> _p0) {
            auto this_ = std::get<0>(_p0);
            auto at_line_start = std::get<1>(_p0);
            auto done = std::get<2>(_p0);
            return len(this_.layout) > Nat(1u)
                ? ({
                this_.layout = crate::syntax::lexer::chars::pop(this_.layout);
                this_ = crate::syntax::lexer::push_tok(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayClose{}), this_.pos, this_.pos);
                Expected<std::tuple<crate::syntax::lexer::Lex, bool, bool>, std::tuple<crate::syntax::lexer::Lex, bool, bool>>(std::tuple{this_, at_line_start, done});
            })
                : Expected<std::tuple<crate::syntax::lexer::Lex, bool, bool>, std::tuple<crate::syntax::lexer::Lex, bool, bool>>(unexpected(std::tuple{this_, at_line_start, done}));
        }), [=](std::tuple<crate::syntax::lexer::Lex, bool, bool> _p0) {
            auto this_ = std::get<0>(_p0);
            auto at_line_start = std::get<1>(_p0);
            auto done = std::get<2>(_p0);
            return k_if4442(std::tuple{this_, at_line_start, done});
        })
            : k_if4442(std::tuple{this_, at_line_start, done}));
        });
    });
}


/// `Start LexStream, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_stream(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexStream>(l0);
}


/// UnclosedStream: fn Lex -> Lex
crate::syntax::lexer::Lex unclosed_stream(const crate::syntax::lexer::Lex& l) {
    auto&& _m = l->mode;
    if (prism_rtl::is<crate::syntax::lexer::Mode::MFile>(_m)) {
        return l;
    }
    if (prism_rtl::is<crate::syntax::lexer::Mode::MBrace>(_m)) {
        return crate::syntax::lexer::chars::lex_err(l, l.pos, l.pos, Text::lit("a brace block never closes: expected its closing delimiter alone on a line"));
    }
    if (prism_rtl::is<crate::syntax::lexer::Mode::MPlaceholder>(_m)) {
        auto&& m4718_2_0 = prism_rtl::as<crate::syntax::lexer::Mode::MPlaceholder>(_m).a0;
        if (m4718_2_0 == Text::lit("single")) {
            return crate::syntax::lexer::chars::lex_err(l, l.pos, l.pos, Text::lit("a placeholder never closes: expected `}`"));
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::Mode::MPlaceholder>(_m)) {
        return crate::syntax::lexer::chars::lex_err(l, l.pos, l.pos, Text::lit("a placeholder never closes: expected `}}`"));
    }
    if (prism_rtl::is<crate::syntax::lexer::Mode::MPathKey>(_m)) {
        return crate::syntax::lexer::chars::lex_err(l, l.pos, l.pos, Text::lit("a path key never closes: expected `]`"));
    }
    prism_rtl::unreachable("no arm matched");
}


/// StreamEndsHere: fn Lex -> ((Bool, Lex))
std::tuple<bool, crate::syntax::lexer::Lex> stream_ends_here(const crate::syntax::lexer::Lex& l) {
    auto c = crate::syntax::lexer::chars::peek(l);
    auto closes = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = l->mode;
        if (prism_rtl::is<crate::syntax::lexer::Mode::MPlaceholder>(_m)) {
            auto&& m5318_0_0 = prism_rtl::as<crate::syntax::lexer::Mode::MPlaceholder>(_m).a0;
            if (m5318_0_0 == Text::lit("single")) {
                _v.set(c == Text::lit("}"));
                goto _done;
            }
        }
        if (prism_rtl::is<crate::syntax::lexer::Mode::MPlaceholder>(_m)) {
            auto&& m5318_1_0 = prism_rtl::as<crate::syntax::lexer::Mode::MPlaceholder>(_m).a0;
            if (m5318_1_0 == Text::lit("double")) {
                _v.set(crate::syntax::lexer::chars::starts_with(l, Text::lit("}}")));
                goto _done;
            }
        }
        if (prism_rtl::is<crate::syntax::lexer::Mode::MPathKey>(_m)) {
            _v.set(c == Text::lit("]"));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto width = l->mode == crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{Text::lit("double")})
        ? Nat(2u)
        : Nat(1u);
    return (len(l.frames) == Nat(0u)) && closes
        ? std::tuple{true, crate::syntax::lexer::chars::forward(l, width)}
        : std::tuple{false, l};
}


/// EndLine: fn Lex -> Lex
crate::syntax::lexer::Lex end_line(const crate::syntax::lexer::Lex& l) {
    auto&& _m = crate::syntax::lexer::chars::last(l->tokens);
    if (prism_rtl::is_some(_m)) {
        auto&& t = prism_rtl::some_of(_m);
        if ((len(l->tokens) > l.line_first) && opens_block(t.kind)) {
            crate::syntax::lexer::Lex this_ = l;
            this_.pending_open = true;
            this_.pending_span = t.span;
            return this_;
        }
    }
    {
        return l;
    }
}


/// OpensBlock: fn TokKind -> Bool
bool opens_block(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KColon>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLambdaBar>(tok_kind0) && !prism_rtl::as<crate::syntax::lexer::TokKind::KLambdaBar>(tok_kind0).a0) {
        return true;
    }
    {
        return false;
    }
}


/// BeginLine: unbounded fn Lex -> ((Lex, Text))
std::tuple<crate::syntax::lexer::Lex, Text> begin_line(const crate::syntax::lexer::Lex& l0) {
    auto line_begin = l0.pos;
    auto [l1, col] = indentation(l0);
    auto&& _m = crate::syntax::lexer::chars::peek(l1);
    {
        auto&& m6669_0 = _m;
        if (m6669_0 == Text::lit("")) {
            return std::tuple{l1, Text::lit("end")};
        }
    }
    {
        auto&& m6669_1 = _m;
        if (m6669_1 == Text::lit("\n")) {
            return std::tuple{crate::syntax::lexer::chars::bump(l1), Text::lit("skip")};
        }
    }
    {
        auto&& m6669_2 = _m;
        if (m6669_2 == Text::lit("#")) {
            auto l2 = ({
                crate::syntax::lexer::Lex this_ = l1;
                this_.pos = crate::syntax::lexer::chars::line_end(this_);
                this_;
            });
            return crate::syntax::lexer::chars::peek(l2) == Text::lit("\n")
                ? std::tuple{crate::syntax::lexer::chars::bump(l2), Text::lit("skip")}
                : std::tuple{l2, Text::lit("end")};
        }
    }
    {
        return closes_brace_block(l1)
            ? std::tuple{skip_line(l1), Text::lit("end")}
            : ({
            auto l2 = indented_line(l1, col, line_begin);
            std::tuple{l2, Text::lit("tokens")};
        });
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::Lex, Text>> BeginLine::cycle() const {
    const auto& l0 = this->l0;
    auto line_begin = l0.pos;
    auto l0_1 = l0;
    return call_then(start_indentation(l0_1), [=](std::tuple<crate::syntax::lexer::Lex, Nat> indentation_6650) {
        return ({
            auto [l1, col] = indentation_6650;
            ({
            auto&& _m = crate::syntax::lexer::chars::peek(l1);
            ({
            auto&& m6669_0 = _m;
            (m6669_0 == Text::lit(""));
        }) ? ({
            auto&& m6669_0 = _m;
            prism_rtl::finished(std::tuple{l1, Text::lit("end")});
        })
            : ({
            auto&& m6669_1 = _m;
            (m6669_1 == Text::lit("\n"));
        }) ? ({
            auto&& m6669_1 = _m;
            prism_rtl::finished(std::tuple{crate::syntax::lexer::chars::bump(l1), Text::lit("skip")});
        })
            : ({
            auto&& m6669_2 = _m;
            (m6669_2 == Text::lit("#"));
        }) ? ({
            auto&& m6669_2 = _m;
            ({
            auto l2 = ({
                crate::syntax::lexer::Lex this_ = l1;
                this_.pos = crate::syntax::lexer::chars::line_end(this_);
                this_;
            });
            (crate::syntax::lexer::chars::peek(l2) == Text::lit("\n")
            ? prism_rtl::finished(std::tuple{crate::syntax::lexer::chars::bump(l2), Text::lit("skip")})
            : prism_rtl::finished(std::tuple{l2, Text::lit("end")}));
        });
        })
            : call_then(start_closes_brace_block(l1), [=](bool closes_brace_block_7024) {
            return closes_brace_block_7024
                ? call_then(start_skip_line(l1), [=](crate::syntax::lexer::Lex skip_line_7047) { return prism_rtl::finished(std::tuple{skip_line_7047, Text::lit("end")}); })
                : call_then(start_indented_line(l1, col, line_begin), [=](crate::syntax::lexer::Lex indented_line_7111) {
                return ({
                    auto l2 = indented_line_7111;
                    (prism_rtl::finished(std::tuple{l2, Text::lit("tokens")}));
                });
            });
        });
        });
        });
    });
}


/// `Start BeginLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::Lex, Text>> start_begin_line(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<BeginLine>(l0);
}


/// Indentation: unbounded fn Lex -> ((Lex, Nat))
std::tuple<crate::syntax::lexer::Lex, Nat> indentation(const crate::syntax::lexer::Lex& l0) {
    std::tuple<crate::syntax::lexer::Lex, Nat> this_ = std::tuple{l0, Nat(0u)};
    crate::syntax::lexer::Lex l = l0;
    Nat col = Nat(0u);
    bool going = true;
    while (going) {
        ({
            __label__ _done;
            prism_rtl::Slot<Unit> _v;
            auto&& _m = crate::syntax::lexer::chars::peek(l);
            {
                auto&& u7432_0 = _m;
                if (u7432_0 == Text::lit(" ")) {
                    _v.set(({
                        l = crate::syntax::lexer::chars::bump(l);
                        col = col + Nat(1u);
                        Unit{};
                    }));
                    goto _done;
                }
            }
            {
                auto&& u7432_1 = _m;
                if (u7432_1 == Text::lit("\t")) {
                    _v.set(({
                        l = crate::syntax::lexer::chars::lex_err(crate::syntax::lexer::chars::bump(l), l.pos, l.pos + Nat(1u), Text::lit("a tab in leading whitespace is an error: indent with spaces"));
                        col = col + Nat(1u);
                        Unit{};
                    }));
                    goto _done;
                }
            }
            {
                auto&& u7432_2 = _m;
                if (u7432_2 == Text::lit("\r")) {
                    _v.set(({
                        l = crate::syntax::lexer::chars::bump(l);
                        Unit{};
                    }));
                    goto _done;
                }
            }
            {
                _v.set(({
                    going = false;
                    Unit{};
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    this_ = std::tuple{l, col};
    return this_;
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::Lex, Nat>> Indentation::cycle() const {
    const auto& l0 = this->l0;
    std::tuple<crate::syntax::lexer::Lex, Nat> this_ = std::tuple{l0, Nat(0u)};
    crate::syntax::lexer::Lex l = l0;
    Nat col = Nat(0u);
    bool going = true;
    return call_then(loop_job(std::tuple{this_, col, going, l}, [=](std::tuple<std::tuple<crate::syntax::lexer::Lex, Nat>, Nat, bool, crate::syntax::lexer::Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        auto col = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto l = std::get<3>(_p0);
        return going
            ? ({
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = crate::syntax::lexer::chars::peek(l);
                {
                    auto&& u7432_0 = _m;
                    if (u7432_0 == Text::lit(" ")) {
                        _v.set(({
                            l = crate::syntax::lexer::chars::bump(l);
                            col = col + Nat(1u);
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u7432_1 = _m;
                    if (u7432_1 == Text::lit("\t")) {
                        _v.set(({
                            l = crate::syntax::lexer::chars::lex_err(crate::syntax::lexer::chars::bump(l), l.pos, l.pos + Nat(1u), Text::lit("a tab in leading whitespace is an error: indent with spaces"));
                            col = col + Nat(1u);
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u7432_2 = _m;
                    if (u7432_2 == Text::lit("\r")) {
                        _v.set(({
                            l = crate::syntax::lexer::chars::bump(l);
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        going = false;
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            Expected<std::tuple<std::tuple<crate::syntax::lexer::Lex, Nat>, Nat, bool, crate::syntax::lexer::Lex>, std::tuple<std::tuple<crate::syntax::lexer::Lex, Nat>, Nat, bool, crate::syntax::lexer::Lex>>(std::tuple{this_, col, going, l});
        })
            : Expected<std::tuple<std::tuple<crate::syntax::lexer::Lex, Nat>, Nat, bool, crate::syntax::lexer::Lex>, std::tuple<std::tuple<crate::syntax::lexer::Lex, Nat>, Nat, bool, crate::syntax::lexer::Lex>>(unexpected(std::tuple{this_, col, going, l}));
    }), [=](std::tuple<std::tuple<crate::syntax::lexer::Lex, Nat>, Nat, bool, crate::syntax::lexer::Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        auto col = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto l = std::get<3>(_p0);
        return ({
            this_ = std::tuple{l, col};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start Indentation, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::Lex, Nat>> start_indentation(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<Indentation>(l0);
}


/// ClosesBraceBlock: unbounded fn Lex -> Bool
bool closes_brace_block(const crate::syntax::lexer::Lex& l) {
    auto&& _m = l->mode;
    if (prism_rtl::is<crate::syntax::lexer::Mode::MBrace>(_m)) {
        auto&& m7910_0_0 = prism_rtl::as<crate::syntax::lexer::Mode::MBrace>(_m).a0;
        if (m7910_0_0 == Text::lit("double")) {
            return crate::syntax::lexer::chars::trim_end(crate::syntax::lexer::chars::rest_of_line(l)) == Text::lit("}}");
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::Mode::MBrace>(_m)) {
        return crate::syntax::lexer::chars::trim_end(crate::syntax::lexer::chars::rest_of_line(l)) == Text::lit("}");
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> ClosesBraceBlock::cycle() const {
    const auto& l = this->l;
    return ({
        auto&& _m = l->mode;
        prism_rtl::is<crate::syntax::lexer::Mode::MBrace>(_m) && ({
        auto&& m7910_0_0 = prism_rtl::as<crate::syntax::lexer::Mode::MBrace>(_m).a0;
        (m7910_0_0 == Text::lit("double"));
    }) ? ({
        auto&& m7910_0_0 = prism_rtl::as<crate::syntax::lexer::Mode::MBrace>(_m).a0;
        ({
        auto l_1 = l;
        call_then(crate::syntax::lexer::chars::start_rest_of_line(l_1), [=](Text rest_of_line_7955) { return prism_rtl::finished(crate::syntax::lexer::chars::trim_end(rest_of_line_7955) == Text::lit("}}")); });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::Mode::MBrace>(_m) ? ({
        auto l_1 = l;
        call_then(crate::syntax::lexer::chars::start_rest_of_line(l_1), [=](Text rest_of_line_8009) { return prism_rtl::finished(crate::syntax::lexer::chars::trim_end(rest_of_line_8009) == Text::lit("}")); });
    })
        : prism_rtl::finished(false);
    });
}


/// `Start ClosesBraceBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_closes_brace_block(crate::syntax::lexer::Lex l) {
    return prism_rtl::make_rc<ClosesBraceBlock>(l);
}


/// SkipLine: unbounded fn Lex -> Lex
crate::syntax::lexer::Lex skip_line(const crate::syntax::lexer::Lex& l0) {
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = crate::syntax::lexer::chars::line_end(this_);
        this_;
    });
    return crate::syntax::lexer::chars::peek(l) == Text::lit("\n")
        ? crate::syntax::lexer::chars::bump(l)
        : l;
}


prism_rtl::Turn<crate::syntax::lexer::Lex> SkipLine::cycle() const {
    const auto& l0 = this->l0;
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = crate::syntax::lexer::chars::line_end(this_);
        this_;
    });
    return crate::syntax::lexer::chars::peek(l) == Text::lit("\n")
        ? prism_rtl::finished(crate::syntax::lexer::chars::bump(l))
        : prism_rtl::finished(l);
}


/// `Start SkipLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_skip_line(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<SkipLine>(l0);
}


/// IndentedLine: unbounded fn Lex, Nat, Nat -> Lex
crate::syntax::lexer::Lex indented_line(const crate::syntax::lexer::Lex& l0, const Nat& col, const Nat& line_begin) {
    auto here = l0.pos;
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.line_first = len(this_.tokens);
        this_.last_ws = true;
        this_;
    });
    return l.first_line
        ? first_line(l, col, line_begin, here)
        : layout_line(l, col, line_begin, here);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> IndentedLine::cycle() const {
    const auto& l0 = this->l0;
    const auto& col = this->col;
    const auto& line_begin = this->line_begin;
    auto here = l0.pos;
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.line_first = len(this_.tokens);
        this_.last_ws = true;
        this_;
    });
    return l.first_line
        ? prism_rtl::finished(first_line(l, col, line_begin, here))
        : prism_rtl::finished(layout_line(l, col, line_begin, here));
}


/// `Start IndentedLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_indented_line(crate::syntax::lexer::Lex l0, Nat col, Nat line_begin) {
    return prism_rtl::make_rc<IndentedLine>(l0, col, line_begin);
}


/// FirstLine: fn Lex, Nat, Nat, Nat -> Lex
crate::syntax::lexer::Lex first_line(const crate::syntax::lexer::Lex& l0, const Nat& col, const Nat& line_begin, const Nat& here) {
    crate::syntax::lexer::Lex this_ = l0;
    this_.first_line = false;
    if (this_.mode == crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MFile{})) {
        this_.layout = Array(std::vector{Nat(0u)});
        if (col != Nat(0u)) {
            this_ = crate::syntax::lexer::chars::lex_err(this_, line_begin, here, Text::lit("the first line of a file starts at column 0"));
            this_.layout = Array(std::vector{col});
        }
    } else  {
        this_.layout = crate::prelude::push(this_.layout, col);
    }
    return this_;
}


/// Below: fn ?Nat, Nat -> Bool
bool below(const std::optional<Nat>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return false;
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& d = prism_rtl::some_of(std::get<0>(_m));
        auto&& depth = std::get<1>(_m);
        return depth < d;
    }
    prism_rtl::unreachable("no arm matched");
}


/// LayoutLine: fn Lex, Nat, Nat, Nat -> Lex
crate::syntax::lexer::Lex layout_line(const crate::syntax::lexer::Lex& l0, const Nat& col, const Nat& line_begin, const Nat& here) {
    crate::syntax::lexer::Lex this_ = l0;
    auto top = or_(crate::syntax::lexer::chars::last(this_.layout), Nat(0u));
    auto fat = crate::syntax::lexer::chars::starts_with(this_, Text::lit("=>"));
    bool opened = false;
    Nat fuel = len(this_.layout);
    if (this_.pending_open) {
        this_.pending_open = false;
        if (col > top) {
            this_.layout = crate::prelude::push(this_.layout, col);
            this_ = crate::syntax::lexer::push_tok(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{}), here, here);
            if (this_.test_pending == Text::lit("test")) {
                this_.test_depth = std::optional(len(this_.layout));
            }
            if (this_.test_pending == Text::lit("check")) {
                this_.check_depth = std::optional(len(this_.layout));
            }
            this_.test_pending = Text::lit("");
            opened = true;
        } else  {
            this_.diags = crate::prelude::push(this_.diags, crate::syntax::lexer::chars::lex_diag(this_.pending_span, Text::lit("expected an indented block after `:`")));
        }
    }
    if (!opened) {
        if (((col > top) && fat) && (this_.test_depth == std::optional(len(this_.layout)))) {
            this_.layout = crate::prelude::push(this_.layout, col);
            this_ = crate::syntax::lexer::push_tok(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{}), here, here);
        } else if (col == top) {
            this_ = crate::syntax::lexer::push_tok(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLaySep{}), here, here);
            if (len(this_.layout) == Nat(1u)) {
                this_.test_pending = Text::lit("");
            }
        } else if (col > top) {
            this_.mark_line_start = true;
        } else  {
            while (true) {
                auto&& _m = fuel.checked_sub(Nat(1u));
                if (!(prism_rtl::is_some(_m))) break;
                auto&& left = prism_rtl::some_of(_m);
                if (!((len(this_.layout) > Nat(1u)) && (col < or_(crate::syntax::lexer::chars::last(this_.layout), Nat(0u))))) {
                    break;
                }
                fuel = left;
                this_.layout = crate::syntax::lexer::chars::pop(this_.layout);
                this_ = crate::syntax::lexer::push_tok(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayClose{}), here, here);
                auto depth = len(this_.layout);
                if (below(this_.test_depth, depth)) {
                    this_.test_depth = std::optional<Nat>{};
                }
                if (below(this_.check_depth, depth)) {
                    this_.check_depth = std::optional<Nat>{};
                }
            }
            if (col != or_(crate::syntax::lexer::chars::last(this_.layout), Nat(0u))) {
                this_ = crate::syntax::lexer::chars::lex_err(this_, line_begin, here, Text::lit("unindent does not match any open block"));
            }
            this_ = crate::syntax::lexer::push_tok(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLaySep{}), here, here);
            if (len(this_.layout) == Nat(1u)) {
                this_.test_pending = Text::lit("");
            }
        }
    }
    return this_;
}

}  // namespace crate::syntax::lexer::layout
