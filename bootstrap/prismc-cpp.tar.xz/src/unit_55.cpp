// The module `Lower.Patterns`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/patterns/module.hpp>
#include <lower/model/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Patterns`, from `target/bootstrap/cpp-src/prismc/lower/patterns.prism`.
namespace crate::lower::patterns {



/// PatOnly: fn Pa -> PatOut
PatOut pat_only(const crate::lower::model::Pa& pa_p0) {
    return PatOut{.pa = pa_p0, .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
}


/// RustPat: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
PatOut rust_pat(const crate::lower::Lx& lx_p0, const crate::syntax::Pattern_& p_p1, const crate::check::types::Ty& ty_p2, const crate::lower::types::Holding& mode_p3, const Text& fresh_p4) {
    auto&& _m = prism_rtl::deref(p_p1.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p5 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto nkey_p6 = crate::check::env::sname_key(n_p5);
        auto [qk_o9, why_pa] = crate::check::env::names::resolve_value(lx_p0.g, lx_p0.home, n_p5);
        auto is_ctor_p7 = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is_some(qk_o9)) {
                auto&& qk_pb = prism_rtl::some_of(qk_o9);
                _v.set(crate::check::env::has_key(prism_rtl::deref(lx_p0.g).ctors, qk_pb) && ((crate::check::env::is_upper_text(crate::lower::base(nkey_p6)) || (len(n_p5->path_) > Nat(1u))) || is_unit_ctor(lx_p0, qk_pb)));
                goto _done;
            }
            if (prism_rtl::is_none(qk_o9)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto tagged_o8 = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::check::env::TagInfo>> _v;
            if (prism_rtl::is_some(qk_o9)) {
                auto&& qk_pc = prism_rtl::some_of(qk_o9);
                _v.set(crate::prelude::get(prism_rtl::deref(lx_p0.g).tags, qk_pc));
                goto _done;
            }
            if (prism_rtl::is_none(qk_o9)) {
                _v.set(std::optional<crate::check::env::TagInfo>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return std::move(is_ctor_p7)
            ? ctor_pat(lx_p0, n_p5, Array<crate::syntax::Pattern_>{}, ty_p2, mode_p3, fresh_p4)
            : (why_pa == Text::lit("tag")) && (tagged_o8 != std::optional<crate::check::env::TagInfo>{})
            ? tag_pat(lx_p0, or_(tagged_o8, dummy_tag_info()), Array<crate::syntax::FieldPat>{}, true, ty_p2, mode_p3, fresh_p4)
            : ({
            auto rs_pd = crate::lower::local_name_at(lx_p0, nkey_p6, prism_rtl::deref(n_p5).span);
            auto bt_pe = crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::binder_ty(lx_p0, prism_rtl::deref(n_p5).span)));
            PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs_pd}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array(std::vector{std::tuple{nkey_p6, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_pd}), mode_p3, bt_pe})}})};
        });
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
        return pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m)) {
        return pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNil>(_m)) {
        return pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PLit>(_m)) {
        auto&& l_pf = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        return lit_pat(lx_p0, l_pf, ty_p2, mode_p3, fresh_p4, false);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m)) {
        auto&& l_pg = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        return lit_pat(lx_p0, l_pg, ty_p2, mode_p3, fresh_p4, true);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& m1652_6_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q_ph = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        if (m1652_6_0 == Text::lit("?")) {
            return wrap_pat(lx_p0, Text::lit("Some"), prism_rtl::deref(prism_rtl::deref(q_ph)), inner_ty(ty_p2), mode_p3, fresh_p4);
        }
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& m1652_7_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q_pi = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        if (m1652_7_0 == Text::lit("~")) {
            return wrap_pat(lx_p0, Text::lit("Ok"), prism_rtl::deref(prism_rtl::deref(q_pi)), inner_ty(ty_p2), mode_p3, fresh_p4);
        }
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& q_pj = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        return rust_pat(lx_p0, prism_rtl::deref(prism_rtl::deref(q_pj)), ty_p2, mode_p3, fresh_p4);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_pk = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return rust_pat(lx_p0, prism_rtl::deref(prism_rtl::deref(q_pk)), ty_p2, mode_p3, fresh_p4);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& n_pl = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& ps_pm = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        return ctor_pat(lx_p0, n_pl, ps_pm, ty_p2, mode_p3, fresh_p4);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& n_pn = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fps_po = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        auto&& rest_pp = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a2;
        return record_pat(lx_p0, n_pn, fps_po, rest_pp, ty_p2, mode_p3, fresh_p4);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps_pq = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        auto ts_pr = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
            auto&& _m = crate::lower::types::peel(ty_p2);
            if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
                auto&& xs_pt = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
                _v.set(xs_pt);
                goto _done;
            }
            {
                _v.set(Array<crate::check::types::Ty>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subs_ps = run_to_end(each_job(crate::check::errors::range0(len(ps_pq)), ({
            auto lx_p0_1 = lx_p0;
            auto ps_pq_2 = ps_pq;
            auto ts_pr_3 = ts_pr;
            auto mode_p3_4 = mode_p3;
            auto fresh_p4_5 = fresh_p4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), ps_pq_2 = std::move(ps_pq_2), ts_pr_3 = std::move(ts_pr_3), mode_p3_4 = std::move(mode_p3_4), fresh_p4_5 = std::move(fresh_p4_5)](Nat p0) {
            return ({
                auto lx_p0_1_6 = lx_p0_1;
                auto ps_pq_2_6 = ps_pq_2;
                auto ts_pr_3_6 = ts_pr_3;
                auto mode_p3_4_6 = mode_p3_4;
                auto fresh_p4_5_6 = fresh_p4_5;
                entered(once_job([=, lx_p0_1_6 = std::move(lx_p0_1_6), ps_pq_2_6 = std::move(ps_pq_2_6), ts_pr_3_6 = std::move(ts_pr_3_6), mode_p3_4_6 = std::move(mode_p3_4_6), fresh_p4_5_6 = std::move(fresh_p4_5_6)]() {
                return ({
                    auto i_pu = p0;
                    (prism_rtl::more(prism_rtl::rc(RustPat(lx_p0_1_6, or_(index(ps_pq_2_6, i_pu), dummy_pat()), or_(index(ts_pr_3_6, i_pu), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), mode_p3_4_6, prism_rtl::cat(fresh_p4_5_6, "_", i_pu)))));
                });
            }));
            });
        })));
        })));
        return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(subs_ps, [&](const PatOut& o_pv) { return prism_rtl::deref(o_pv).pa; })}), .conds = fold(subs_ps, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_p10, const PatOut& o_p11) { return append(acc_p10, prism_rtl::deref(o_p11).conds); }), .binds = fold(subs_ps, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_p12, const PatOut& o_p13) { return append(acc_p12, prism_rtl::deref(o_p13).binds); })};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
        auto&& ps_p14 = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        return array_pat(lx_p0, ps_p14, ty_p2, mode_p3, fresh_p4);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
        auto&& q_p15 = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        return family_pat(lx_p0, q_p15, ty_p2, fresh_p4);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<PatOut> RustPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& p_p1 = this->p_p1;
    const auto& ty_p2 = this->ty_p2;
    const auto& mode_p3 = this->mode_p3;
    const auto& fresh_p4 = this->fresh_p4;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p1).kind);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_p5 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto nkey_p6 = crate::check::env::sname_key(n_p5);
        auto [qk_o9, why_pa] = crate::check::env::names::resolve_value(prism_rtl::deref(lx_p0).g, prism_rtl::deref(lx_p0).home, n_p5);
        auto is_ctor_p7 = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is_some(qk_o9)) {
                auto&& qk_pb = prism_rtl::some_of(qk_o9);
                _v.set(crate::check::env::has_key(prism_rtl::deref(prism_rtl::deref(lx_p0).g).ctors, qk_pb) && ((crate::check::env::is_upper_text(crate::lower::base(nkey_p6)) || (len(n_p5->path_) > Nat(1u))) || is_unit_ctor(lx_p0, qk_pb)));
                goto _done;
            }
            if (prism_rtl::is_none(qk_o9)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto tagged_o8 = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::check::env::TagInfo>> _v;
            if (prism_rtl::is_some(qk_o9)) {
                auto&& qk_pc = prism_rtl::some_of(qk_o9);
                _v.set(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g).tags, qk_pc));
                goto _done;
            }
            if (prism_rtl::is_none(qk_o9)) {
                _v.set(std::optional<crate::check::env::TagInfo>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (std::move(is_ctor_p7)
        ? prism_rtl::more(prism_rtl::rc(CtorPat(lx_p0, n_p5, Array<crate::syntax::Pattern_>{}, ty_p2, mode_p3, fresh_p4)))
        : (why_pa == Text::lit("tag")) && (tagged_o8 != std::optional<crate::check::env::TagInfo>{})
        ? prism_rtl::more(prism_rtl::rc(TagPat(lx_p0, or_(tagged_o8, dummy_tag_info()), Array<crate::syntax::FieldPat>{}, true, ty_p2, mode_p3, fresh_p4)))
        : ({
        auto lx_p0_1 = lx_p0;
        auto mode_p3_2 = mode_p3;
        auto n_p5_3 = n_p5;
        call_then(crate::lower::start_local_name_at(lx_p0_1, nkey_p6, prism_rtl::deref(n_p5_3).span), [=, mode_p3_2 = std::move(mode_p3_2)](Text local_name_at_2230) {
        return ({
            auto rs_pd = local_name_at_2230;
            call_then(crate::lower::types::start_out_ty_of(lx_p0_1, crate::lower::types::peel(crate::lower::binder_ty(lx_p0_1, prism_rtl::deref(n_p5_3).span))), [=, rs_pd = std::move(rs_pd)](crate::lower::model::OutTy out_ty_of_2280) {
            return ({
                auto bt_pe = out_ty_of_2280;
                (prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs_pd}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array(std::vector{std::tuple{nkey_p6, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_pd}), mode_p3_2, bt_pe})}})}));
            });
        });
        });
    });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})))
        : prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m) ? prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})))
        : prism_rtl::is<crate::syntax::PatternKind::PNil>(_m) ? prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")})))
        : prism_rtl::is<crate::syntax::PatternKind::PLit>(_m) ? ({
        auto&& l_pf = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        prism_rtl::more(prism_rtl::rc(LitPat(lx_p0, l_pf, ty_p2, mode_p3, fresh_p4, false)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m) ? ({
        auto&& l_pg = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        prism_rtl::more(prism_rtl::rc(LitPat(lx_p0, l_pg, ty_p2, mode_p3, fresh_p4, true)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) && ({
        auto&& m1652_6_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q_ph = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        (m1652_6_0 == Text::lit("?"));
    }) ? ({
        auto&& m1652_6_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q_ph = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(WrapPat(lx_p0, Text::lit("Some"), prism_rtl::deref(prism_rtl::deref(q_ph)), inner_ty(ty_p2), mode_p3, fresh_p4)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) && ({
        auto&& m1652_7_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q_pi = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        (m1652_7_0 == Text::lit("~"));
    }) ? ({
        auto&& m1652_7_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q_pi = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(WrapPat(lx_p0, Text::lit("Ok"), prism_rtl::deref(prism_rtl::deref(q_pi)), inner_ty(ty_p2), mode_p3, fresh_p4)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) ? ({
        auto&& q_pj = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(RustPat(lx_p0, prism_rtl::deref(prism_rtl::deref(q_pj)), ty_p2, mode_p3, fresh_p4)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q_pk = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RustPat(lx_p0, prism_rtl::deref(prism_rtl::deref(q_pk)), ty_p2, mode_p3, fresh_p4)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m) ? ({
        auto&& n_pl = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& ps_pm = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        prism_rtl::more(prism_rtl::rc(CtorPat(lx_p0, n_pl, ps_pm, ty_p2, mode_p3, fresh_p4)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m) ? ({
        auto&& n_pn = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fps_po = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        auto&& rest_pp = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a2;
        prism_rtl::more(prism_rtl::rc(RecordPat(lx_p0, n_pn, fps_po, prism_rtl::deref(rest_pp), ty_p2, mode_p3, fresh_p4)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m) ? ({
        auto&& ps_pq = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        ({
        auto ts_pr = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
            auto&& _m = crate::lower::types::peel(ty_p2);
            if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
                auto&& xs_pt = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
                _v.set(xs_pt);
                goto _done;
            }
            {
                _v.set(Array<crate::check::types::Ty>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto fresh_p4_1 = fresh_p4;
        auto lx_p0_2 = lx_p0;
        auto mode_p3_3 = mode_p3;
        auto ps_pq_4 = ps_pq;
        call_value(each_job(crate::check::errors::range0(len(ps_pq_4)), ({
        auto lx_p0_2_5 = lx_p0_2;
        auto ps_pq_4_5 = ps_pq_4;
        auto ts_pr_5 = ts_pr;
        auto mode_p3_3_6 = mode_p3_3;
        auto fresh_p4_1_6 = fresh_p4_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0_2_5 = std::move(lx_p0_2_5), ps_pq_4_5 = std::move(ps_pq_4_5), ts_pr_5 = std::move(ts_pr_5), mode_p3_3_6 = std::move(mode_p3_3_6), fresh_p4_1_6 = std::move(fresh_p4_1_6)](Nat p0) {
        return ({
            auto lx_p0_2_5_6 = lx_p0_2_5;
            auto ps_pq_4_5_6 = ps_pq_4_5;
            auto ts_pr_5_6 = ts_pr_5;
            auto mode_p3_3_6_6 = mode_p3_3_6;
            auto fresh_p4_1_6_6 = fresh_p4_1_6;
            entered(once_job([=, lx_p0_2_5_6 = std::move(lx_p0_2_5_6), ps_pq_4_5_6 = std::move(ps_pq_4_5_6), ts_pr_5_6 = std::move(ts_pr_5_6), mode_p3_3_6_6 = std::move(mode_p3_3_6_6), fresh_p4_1_6_6 = std::move(fresh_p4_1_6_6)]() {
            return ({
                auto i_pu = p0;
                (prism_rtl::more(prism_rtl::rc(RustPat(lx_p0_2_5_6, or_(index(ps_pq_4_5_6, i_pu), dummy_pat()), or_(index(ts_pr_5_6, i_pu), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), mode_p3_3_6_6, prism_rtl::cat(fresh_p4_1_6_6, "_", i_pu)))));
            });
        }));
        });
    })));
    })), [=](Array<PatOut> each_3079) {
        return ({
            auto subs_ps = each_3079;
            (prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(subs_ps, [&](const PatOut& o_pv) { return prism_rtl::deref(o_pv).pa; })}), .conds = fold(subs_ps, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_p10, const PatOut& o_p11) { return append(acc_p10, prism_rtl::deref(o_p11).conds); }), .binds = fold(subs_ps, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_p12, const PatOut& o_p13) { return append(acc_p12, prism_rtl::deref(o_p13).binds); })}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PArray>(_m) ? ({
        auto&& ps_p14 = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ArrayPat(lx_p0, ps_p14, ty_p2, mode_p3, fresh_p4)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m) ? ({
        auto&& q_p15 = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FamilyPat(lx_p0, q_p15, ty_p2, fresh_p4)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RustPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_rust_pat(crate::lower::Lx lx_p0, crate::syntax::Pattern_ p_p1, crate::check::types::Ty ty_p2, crate::lower::types::Holding mode_p3, Text fresh_p4) {
    return prism_rtl::make_rc<RustPat>(lx_p0, p_p1, ty_p2, mode_p3, fresh_p4);
}


/// let dummyPat
crate::syntax::Pattern_ dummy_pat() {
    return crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// InnerTy: fn Ty -> Ty
crate::check::types::Ty inner_ty(const crate::check::types::Ty& t_p0) {
    auto&& _m = crate::lower::types::peel(t_p0);
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& m3538_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i_p1 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (m3538_0_0 == Text::lit("?")) {
            return prism_rtl::deref(i_p1);
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& m3538_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i_p2 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (m3538_1_0 == Text::lit("~")) {
            return prism_rtl::deref(i_p2);
        }
    }
    {
        return crate::check::types::Ty(crate::check::types::Ty::TyErr{});
    }
}


/// IsUnitCtor: fn Lx, Text -> Bool
bool is_unit_ctor(const crate::lower::Lx& lx_p0, const Text& qk_p1) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).ctors, qk_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& c_p2 = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::deref(or_(crate::prelude::get(prism_rtl::deref(lx_p0.g).types, prism_rtl::deref(c_p2).owner), crate::check::env::names::dummy_ty_info())).body;
        if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
            auto&& m3791_0_0 = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
            if (m3791_0_0.size() == 1u) {
                {
                    auto&& _c2 = index(m3791_0_0, Nat(0u));
                    if (prism_rtl::is_some(_c2)) {
                        auto&& m3791_0_0_0_1 = std::get<1>(prism_rtl::some_of(_c2));
                        if (m3791_0_0_0_1.size() == 0u) {
                            return crate::check::env::is_lower_text(crate::check::types::bare_name(qk_p1));
                        }
                    }
                }
            }
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// WrapPat: unbounded fn Lx, Text, Pattern, Ty, Holding, Text -> PatOut
PatOut wrap_pat(const crate::lower::Lx& lx_p0, const Text& ctor_p1, const crate::syntax::Pattern_& q_p2, const crate::check::types::Ty& inner_p3, const crate::lower::types::Holding& mode_p4, const Text& fresh_p5) {
    auto o_p6 = rust_pat(lx_p0, q_p2, inner_p3, mode_p4, fresh_p5);
    PatOut this_ = o_p6;
    this_.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{ctor_p1, Array(std::vector{this_.pa})});
    return this_;
}


prism_rtl::Turn<PatOut> WrapPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& ctor_p1 = this->ctor_p1;
    const auto& q_p2 = this->q_p2;
    const auto& inner_p3 = this->inner_p3;
    const auto& mode_p4 = this->mode_p4;
    const auto& fresh_p5 = this->fresh_p5;
    auto ctor_p1_1 = ctor_p1;
    auto fresh_p5_2 = fresh_p5;
    auto inner_p3_3 = inner_p3;
    auto lx_p0_4 = lx_p0;
    auto mode_p4_5 = mode_p4;
    auto q_p2_6 = q_p2;
    return call_then(start_rust_pat(lx_p0_4, q_p2_6, inner_p3_3, mode_p4_5, fresh_p5_2), [=](PatOut rust_pat_4071) {
        return ({
            auto o_p6 = rust_pat_4071;
            (prism_rtl::finished(({
            PatOut this_ = o_p6;
            this_.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{ctor_p1_1, Array(std::vector{this_.pa})});
            (std::move(this_));
        })));
        });
    });
}


/// `Start WrapPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_wrap_pat(crate::lower::Lx lx_p0, Text ctor_p1, crate::syntax::Pattern_ q_p2, crate::check::types::Ty inner_p3, crate::lower::types::Holding mode_p4, Text fresh_p5) {
    return prism_rtl::make_rc<WrapPat>(lx_p0, ctor_p1, q_p2, inner_p3, mode_p4, fresh_p5);
}


/// LitPat: unbounded fn Lx, Literal, Ty, Holding, Text, Bool -> PatOut
PatOut lit_pat(const crate::lower::Lx& lx_p0, const crate::syntax::Literal& l_p1, const crate::check::types::Ty& ty_p2, const crate::lower::types::Holding& mode_p3, const Text& fresh_p4, const bool& neg_p5) {
    auto t_p6 = crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(ty_p2));
    auto&& _m = l_p1.kind;
    if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
        auto&& c_p7 = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
        return pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaChar{c_p7}));
    }
    {
        auto lit_p8 = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::types::Vl> _v;
            auto&& _m = l_p1.kind;
            if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
                auto&& d_pb = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
                _v.set((((t_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})) || (t_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutInt{}))) || (t_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutU8{}))) || (t_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{}))
                    ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::expr::number(t_p6, d_pb, neg_p5), t_p6})
                    : crate::lower::expr::literal_value(lx_p0, crate::lower::types::empty_env(), l_p1, l_p1.span, neg_p5));
                goto _done;
            }
            {
                _v.set(crate::lower::expr::literal_value(lx_p0, crate::lower::types::empty_env(), l_p1, l_p1.span, neg_p5));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto lv_p9 = crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::types::own(lit_p8), t_p6});
        auto b_pa = crate::lower::types::local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4}), mode_p3, t_p6);
        return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p4}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::types::ref_(b_pa)), prism_rtl::rc(crate::lower::types::ref_(lv_p9))})})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
    }
}


prism_rtl::Turn<PatOut> LitPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& l_p1 = this->l_p1;
    const auto& ty_p2 = this->ty_p2;
    const auto& mode_p3 = this->mode_p3;
    const auto& fresh_p4 = this->fresh_p4;
    const auto& neg_p5 = this->neg_p5;
    auto fresh_p4_1 = fresh_p4;
    auto l_p1_2 = l_p1;
    auto lx_p0_3 = lx_p0;
    auto mode_p3_4 = mode_p3;
    auto neg_p5_5 = prism_rtl::deref(neg_p5);
    auto ty_p2_6 = ty_p2;
    return call_then(crate::lower::types::start_out_ty_of(lx_p0_3, crate::lower::types::peel(ty_p2_6)), [=](crate::lower::model::OutTy out_ty_of_4383) {
        return ({
            auto t_p6 = out_ty_of_4383;
            ({
            auto&& _m = prism_rtl::deref(l_p1_2).kind;
            prism_rtl::is<crate::syntax::LitKind::LChar>(_m) ? ({
            auto&& c_p7 = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
            prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaChar{c_p7})));
        })
            : ({
            auto lit_p8 = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::types::Vl> _v;
                auto&& _m = prism_rtl::deref(l_p1_2).kind;
                if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
                    auto&& d_pb = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
                    _v.set((((t_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})) || (t_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutInt{}))) || (t_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutU8{}))) || (t_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{}))
                        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::expr::number(t_p6, d_pb, neg_p5_5), t_p6})
                        : crate::lower::expr::literal_value(lx_p0_3, crate::lower::types::empty_env(), l_p1_2, prism_rtl::deref(l_p1_2).span, neg_p5_5));
                    goto _done;
                }
                {
                    _v.set(crate::lower::expr::literal_value(lx_p0_3, crate::lower::types::empty_env(), l_p1_2, prism_rtl::deref(l_p1_2).span, neg_p5_5));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto lv_p9 = crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::types::own(lit_p8), t_p6});
            auto b_pa = crate::lower::types::local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4_1}), mode_p3_4, t_p6);
            (prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p4_1}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::types::ref_(b_pa)), prism_rtl::rc(crate::lower::types::ref_(lv_p9))})})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}}));
        });
        });
        });
    });
}


/// `Start LitPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_lit_pat(crate::lower::Lx lx_p0, crate::syntax::Literal l_p1, crate::check::types::Ty ty_p2, crate::lower::types::Holding mode_p3, Text fresh_p4, bool neg_p5) {
    return prism_rtl::make_rc<LitPat>(lx_p0, l_p1, ty_p2, mode_p3, fresh_p4, neg_p5);
}


/// CtorPat: unbounded fn Lx, SName, [Pattern], Ty, Holding, Text -> PatOut
PatOut ctor_pat(const crate::lower::Lx& lx_p0, const crate::syntax::SName& n_p1, const Array<crate::syntax::Pattern_>& ps_p2, const crate::check::types::Ty& ty_p3, const crate::lower::types::Holding& mode_p4, const Text& fresh_p5) {
    auto&& _qk_o6 = crate::check::env::names::resolve_value(lx_p0.g, lx_p0.home, n_p1);
    auto&& qk_o6 = std::get<0>(_qk_o6);
    if (prism_rtl::is_some(qk_o6)) {
        auto&& m5426_0 = prism_rtl::some_of(qk_o6);
        if (m5426_0 == Text::lit("True")) {
            return pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaBool{true}));
        }
    }
    if (prism_rtl::is_some(qk_o6)) {
        auto&& m5426_1 = prism_rtl::some_of(qk_o6);
        if (m5426_1 == Text::lit("False")) {
            return pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaBool{false}));
        }
    }
    if (prism_rtl::is_some(qk_o6)) {
        auto&& qk_p7 = prism_rtl::some_of(qk_o6);
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).ctors, qk_p7);
        if (prism_rtl::is_some(_m)) {
            auto&& c_p8 = prism_rtl::some_of(_m);
            auto owner_p9 = or_(crate::prelude::get(prism_rtl::deref(lx_p0.g).types, prism_rtl::deref(c_p8).owner), crate::check::env::names::dummy_ty_info());
            auto ty_path_pa = crate::lower::path_in(lx_p0, prism_rtl::deref(owner_p9).home, crate::lower::camel(crate::check::types::bare_name(prism_rtl::deref(c_p8).owner)));
            auto args_pb = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
                auto&& _m = crate::lower::types::peel(ty_p3);
                if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                    auto&& xs_pg = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
                    _v.set(xs_pg);
                    goto _done;
                }
                {
                    _v.set(Array<crate::check::types::Ty>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto subs_pc = run_to_end(each_job(crate::check::errors::range0(len(ps_p2)), ({
                auto lx_p0_1 = lx_p0;
                auto c_p8_2 = c_p8;
                auto ps_p2_3 = ps_p2;
                auto args_pb_4 = args_pb;
                auto mode_p4_5 = mode_p4;
                auto fresh_p5_6 = fresh_p5;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), c_p8_2 = std::move(c_p8_2), ps_p2_3 = std::move(ps_p2_3), args_pb_4 = std::move(args_pb_4), mode_p4_5 = std::move(mode_p4_5), fresh_p5_6 = std::move(fresh_p5_6)](Nat p0) {
                return ({
                    auto lx_p0_1_7 = lx_p0_1;
                    auto c_p8_2_7 = c_p8_2;
                    auto ps_p2_3_7 = ps_p2_3;
                    auto args_pb_4_7 = args_pb_4;
                    auto mode_p4_5_7 = mode_p4_5;
                    auto fresh_p5_6_7 = fresh_p5_6;
                    entered(once_job([=, lx_p0_1_7 = std::move(lx_p0_1_7), c_p8_2_7 = std::move(c_p8_2_7), ps_p2_3_7 = std::move(ps_p2_3_7), args_pb_4_7 = std::move(args_pb_4_7), mode_p4_5_7 = std::move(mode_p4_5_7), fresh_p5_6_7 = std::move(fresh_p5_6_7)]() {
                    return ({
                        auto i_ph = p0;
                        call_then(crate::lower::expr::start_instantiated(or_(index(c_p8_2_7->args, i_ph), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), prism_rtl::deref(c_p8_2_7).params, args_pb_4_7), [=](crate::check::types::Ty instantiated_5930) { return prism_rtl::more(prism_rtl::rc(SubPat(lx_p0_1_7, c_p8_2_7, i_ph, or_(index(ps_p2_3_7, i_ph), dummy_pat()), instantiated_5930, mode_p4_5_7, prism_rtl::cat(fresh_p5_6_7, "_", i_ph)))); });
                    });
                }));
                });
            })));
            })));
            auto conds_pd = fold(subs_pc, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_pi, const PatOut& o_pj) { return append(acc_pi, prism_rtl::deref(o_pj).conds); });
            auto binds_pe = fold(subs_pc, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_pk, const PatOut& o_pl) { return append(acc_pk, prism_rtl::deref(o_pl).binds); });
            auto pas_pf = each(subs_pc, [&](const PatOut& o_pm) { return prism_rtl::deref(o_pm).pa; });
            auto&& _m = prism_rtl::deref(owner_p9).body;
            if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                auto&& fs_pn = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{ty_path_pa, each(crate::check::errors::range0(len(pas_pf)), [&](const Nat& i_po) { return std::tuple{crate::lower::snake(or_(index(prism_rtl::deref(c_p8).fields, i_po), Text::lit(""))), or_(index(pas_pf, i_po), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}))}; }), len(pas_pf) < len(prism_rtl::deref(c_p8).fields)}), .conds = conds_pd, .binds = binds_pe};
            }
            {
                auto is_unit_type_pp = (len(c_p8->args) == Nat(0u)) && is_unit_ctor(lx_p0, qk_p7);
                auto is_newtype_pq = (crate::check::types::bare_name(prism_rtl::deref(c_p8).name) == crate::check::types::bare_name(prism_rtl::deref(c_p8).owner)) && ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = prism_rtl::deref(owner_p9).body;
                    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                        auto&& cases_ps = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                        _v.set(len(cases_ps) == Nat(1u));
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto path_pr = std::move(is_unit_type_pp) || std::move(is_newtype_pq)
                    ? ty_path_pa
                    : prism_rtl::cat(ty_path_pa, "::", crate::lower::camel(crate::check::types::bare_name(prism_rtl::deref(c_p8).name)));
                return len(c_p8->args) == Nat(0u)
                    ? PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{path_pr}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}}
                    : PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{path_pr, pas_pf}), .conds = conds_pd, .binds = binds_pe};
            }
        }
        if (prism_rtl::is_none(_m)) {
            return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal(prism_rtl::cat("a pattern of ", qk_p7))})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(qk_o6)) {
        return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal(Text::lit("a pattern of an unknown constructor"))})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<PatOut> CtorPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& n_p1 = this->n_p1;
    const auto& ps_p2 = this->ps_p2;
    const auto& ty_p3 = this->ty_p3;
    const auto& mode_p4 = this->mode_p4;
    const auto& fresh_p5 = this->fresh_p5;
    auto&& _qk_o6 = crate::check::env::names::resolve_value(prism_rtl::deref(lx_p0).g, prism_rtl::deref(lx_p0).home, n_p1);
    auto&& qk_o6 = std::get<0>(_qk_o6);
    return ({
        prism_rtl::is_some(qk_o6) && ({
        auto&& m5426_0 = prism_rtl::some_of(qk_o6);
        (m5426_0 == Text::lit("True"));
    }) ? ({
        auto&& m5426_0 = prism_rtl::some_of(qk_o6);
        prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaBool{true})));
    })
        : prism_rtl::is_some(qk_o6) && ({
        auto&& m5426_1 = prism_rtl::some_of(qk_o6);
        (m5426_1 == Text::lit("False"));
    }) ? ({
        auto&& m5426_1 = prism_rtl::some_of(qk_o6);
        prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaBool{false})));
    })
        : prism_rtl::is_some(qk_o6) ? ({
        auto&& qk_p7 = prism_rtl::some_of(qk_o6);
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g).ctors, qk_p7);
        prism_rtl::is_some(_m) ? ({
        auto&& c_p8 = prism_rtl::some_of(_m);
        ({
        auto owner_p9 = or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g).types, prism_rtl::deref(c_p8).owner), crate::check::env::names::dummy_ty_info());
        auto ty_path_pa = crate::lower::path_in(lx_p0, prism_rtl::deref(owner_p9).home, crate::lower::camel(crate::check::types::bare_name(prism_rtl::deref(c_p8).owner)));
        auto args_pb = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
            auto&& _m = crate::lower::types::peel(ty_p3);
            if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                auto&& xs_pg = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
                _v.set(xs_pg);
                goto _done;
            }
            {
                _v.set(Array<crate::check::types::Ty>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto fresh_p5_1 = fresh_p5;
        auto lx_p0_2 = lx_p0;
        auto mode_p4_3 = mode_p4;
        auto ps_p2_4 = ps_p2;
        auto qk_p7_5 = qk_p7;
        call_value(each_job(crate::check::errors::range0(len(ps_p2_4)), ({
        auto lx_p0_2_6 = lx_p0_2;
        auto c_p8_6 = c_p8;
        auto ps_p2_4_7 = ps_p2_4;
        auto args_pb_7 = args_pb;
        auto mode_p4_3_8 = mode_p4_3;
        auto fresh_p5_1_8 = fresh_p5_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0_2_6 = std::move(lx_p0_2_6), c_p8_6 = std::move(c_p8_6), ps_p2_4_7 = std::move(ps_p2_4_7), args_pb_7 = std::move(args_pb_7), mode_p4_3_8 = std::move(mode_p4_3_8), fresh_p5_1_8 = std::move(fresh_p5_1_8)](Nat p0) {
        return ({
            auto lx_p0_2_6_8 = lx_p0_2_6;
            auto c_p8_6_8 = c_p8_6;
            auto ps_p2_4_7_8 = ps_p2_4_7;
            auto args_pb_7_8 = args_pb_7;
            auto mode_p4_3_8_8 = mode_p4_3_8;
            auto fresh_p5_1_8_8 = fresh_p5_1_8;
            entered(once_job([=, lx_p0_2_6_8 = std::move(lx_p0_2_6_8), c_p8_6_8 = std::move(c_p8_6_8), ps_p2_4_7_8 = std::move(ps_p2_4_7_8), args_pb_7_8 = std::move(args_pb_7_8), mode_p4_3_8_8 = std::move(mode_p4_3_8_8), fresh_p5_1_8_8 = std::move(fresh_p5_1_8_8)]() {
            return ({
                auto i_ph = p0;
                call_then(crate::lower::expr::start_instantiated(or_(index(c_p8_6_8->args, i_ph), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), prism_rtl::deref(c_p8_6_8).params, args_pb_7_8), [=](crate::check::types::Ty instantiated_5930) { return prism_rtl::more(prism_rtl::rc(SubPat(lx_p0_2_6_8, c_p8_6_8, i_ph, or_(index(ps_p2_4_7_8, i_ph), dummy_pat()), instantiated_5930, mode_p4_3_8_8, prism_rtl::cat(fresh_p5_1_8_8, "_", i_ph)))); });
            });
        }));
        });
    })));
    })), [=, owner_p9 = std::move(owner_p9), ty_path_pa = std::move(ty_path_pa), qk_p7_5 = std::move(qk_p7_5)](Array<PatOut> each_5861) {
        return ({
            auto subs_pc = each_5861;
            auto conds_pd = fold(subs_pc, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_pi, const PatOut& o_pj) { return append(acc_pi, prism_rtl::deref(o_pj).conds); });
            auto binds_pe = fold(subs_pc, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_pk, const PatOut& o_pl) { return append(acc_pk, prism_rtl::deref(o_pl).binds); });
            auto pas_pf = each(subs_pc, [&](const PatOut& o_pm) { return prism_rtl::deref(o_pm).pa; });
            ({
            auto&& _m = prism_rtl::deref(owner_p9).body;
            prism_rtl::is<crate::check::env::TyBody::BRecord>(_m) ? ({
            auto&& fs_pn = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
            prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{ty_path_pa, each(crate::check::errors::range0(len(pas_pf)), [&](const Nat& i_po) { return std::tuple{crate::lower::snake(or_(index(prism_rtl::deref(c_p8).fields, i_po), Text::lit(""))), or_(index(pas_pf, i_po), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}))}; }), len(pas_pf) < len(prism_rtl::deref(c_p8).fields)}), .conds = conds_pd, .binds = binds_pe});
        })
            : ({
            auto is_unit_type_pp = (len(c_p8->args) == Nat(0u)) && is_unit_ctor(lx_p0_2, qk_p7_5);
            auto is_newtype_pq = (crate::check::types::bare_name(prism_rtl::deref(c_p8).name) == crate::check::types::bare_name(prism_rtl::deref(c_p8).owner)) && ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = prism_rtl::deref(owner_p9).body;
                if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                    auto&& cases_ps = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                    _v.set(len(cases_ps) == Nat(1u));
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto path_pr = std::move(is_unit_type_pp) || std::move(is_newtype_pq)
                ? ty_path_pa
                : prism_rtl::cat(ty_path_pa, "::", crate::lower::camel(crate::check::types::bare_name(prism_rtl::deref(c_p8).name)));
            len(c_p8->args) == Nat(0u)
            ? prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{path_pr}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}})
            : prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{path_pr, pas_pf}), .conds = conds_pd, .binds = binds_pe});
        });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal(prism_rtl::cat("a pattern of ", qk_p7))})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(qk_o6) ? prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal(Text::lit("a pattern of an unknown constructor"))})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CtorPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_ctor_pat(crate::lower::Lx lx_p0, crate::syntax::SName n_p1, Array<crate::syntax::Pattern_> ps_p2, crate::check::types::Ty ty_p3, crate::lower::types::Holding mode_p4, Text fresh_p5) {
    return prism_rtl::make_rc<CtorPat>(lx_p0, n_p1, ps_p2, ty_p3, mode_p4, fresh_p5);
}


/// SubPat: unbounded fn Lx, CtorInfo, Nat, Pattern, Ty, Holding, Text -> PatOut
PatOut sub_pat(const crate::lower::Lx& lx_p0, const crate::check::env::CtorInfo& c_p1, const Nat& i_p2, const crate::syntax::Pattern_& p_p3, const crate::check::types::Ty& ty_p4, const crate::lower::types::Holding& mode_p5, const Text& fresh_p6) {
    return !crate::lower::types::rc_field(lx_p0, c_p1.name, i_p2)
        ? rust_pat(lx_p0, p_p3, ty_p4, mode_p5, fresh_p6)
        : ({
        auto rc_mode_p7 = mode_p5 == crate::lower::types::Holding(crate::lower::types::Holding::Owned{})
            ? crate::lower::types::Holding(crate::lower::types::Holding::RcOwned{})
            : crate::lower::types::Holding(crate::lower::types::Holding::RcRef{});
        ({
        __label__ _done;
        prism_rtl::Slot<PatOut> _v;
        auto&& _m = prism_rtl::deref(p_p3.kind);
        if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
            _v.set(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n_p8 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            _v.set(({
                auto o_p9 = rust_pat(lx_p0, p_p3, ty_p4, rc_mode_p7, fresh_p6);
                ({
                __label__ _done;
                prism_rtl::Slot<PatOut> _v;
                auto&& _m = prism_rtl::deref(o_p9).pa;
                if (prism_rtl::is<crate::lower::model::Pa::PaBind>(_m)) {
                    _v.set(o_p9);
                    goto _done;
                }
                {
                    _v.set(behind_rc(lx_p0, p_p3, ty_p4, rc_mode_p7, fresh_p6));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        {
            _v.set(behind_rc(lx_p0, p_p3, ty_p4, rc_mode_p7, fresh_p6));
            goto _done;
        }
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<PatOut> SubPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& c_p1 = this->c_p1;
    const auto& i_p2 = this->i_p2;
    const auto& p_p3 = this->p_p3;
    const auto& ty_p4 = this->ty_p4;
    const auto& mode_p5 = this->mode_p5;
    const auto& fresh_p6 = this->fresh_p6;
    return !crate::lower::types::rc_field(lx_p0, prism_rtl::deref(c_p1).name, i_p2)
        ? prism_rtl::more(prism_rtl::rc(RustPat(lx_p0, p_p3, ty_p4, mode_p5, fresh_p6)))
        : ({
        auto rc_mode_p7 = mode_p5 == crate::lower::types::Holding(crate::lower::types::Holding::Owned{})
            ? crate::lower::types::Holding(crate::lower::types::Holding::RcOwned{})
            : crate::lower::types::Holding(crate::lower::types::Holding::RcRef{});
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p3).kind);
        prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})))
        : prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_p8 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto fresh_p6_1 = fresh_p6;
        auto lx_p0_2 = lx_p0;
        auto p_p3_3 = p_p3;
        auto ty_p4_4 = ty_p4;
        call_then(start_rust_pat(lx_p0_2, p_p3_3, ty_p4_4, rc_mode_p7, fresh_p6_1), [=](PatOut rust_pat_7824) {
        return ({
            auto o_p9 = rust_pat_7824;
            ({
            auto&& _m = prism_rtl::deref(o_p9).pa;
            prism_rtl::is<crate::lower::model::Pa::PaBind>(_m) ? prism_rtl::finished(o_p9)
            : prism_rtl::more(prism_rtl::rc(BehindRc(lx_p0_2, p_p3_3, ty_p4_4, rc_mode_p7, fresh_p6_1)));
        });
        });
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(BehindRc(lx_p0, p_p3, ty_p4, rc_mode_p7, fresh_p6)));
    });
    });
}


/// `Start SubPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_sub_pat(crate::lower::Lx lx_p0, crate::check::env::CtorInfo c_p1, Nat i_p2, crate::syntax::Pattern_ p_p3, crate::check::types::Ty ty_p4, crate::lower::types::Holding mode_p5, Text fresh_p6) {
    return prism_rtl::make_rc<SubPat>(lx_p0, c_p1, i_p2, p_p3, ty_p4, mode_p5, fresh_p6);
}


/// BehindRc: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
PatOut behind_rc(const crate::lower::Lx& lx_p0, const crate::syntax::Pattern_& p_p1, const crate::check::types::Ty& ty_p2, const crate::lower::types::Holding& rc_mode_p3, const Text& fresh_p4) {
    auto inner_p5 = rust_pat(lx_p0, p_p1, ty_p2, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(fresh_p4, "_r"));
    auto place_p6 = crate::lower::types::ref_(crate::lower::types::local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4}), rc_mode_p3, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("a payload")})));
    return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p4}), .conds = append(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcLet{prism_rtl::deref(inner_p5).pa, place_p6})}), prism_rtl::deref(inner_p5).conds), .binds = prism_rtl::deref(inner_p5).binds};
}


prism_rtl::Turn<PatOut> BehindRc::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& p_p1 = this->p_p1;
    const auto& ty_p2 = this->ty_p2;
    const auto& rc_mode_p3 = this->rc_mode_p3;
    const auto& fresh_p4 = this->fresh_p4;
    auto fresh_p4_1 = fresh_p4;
    auto lx_p0_2 = lx_p0;
    auto p_p1_3 = p_p1;
    auto rc_mode_p3_4 = rc_mode_p3;
    auto ty_p2_5 = ty_p2;
    return call_then(start_rust_pat(lx_p0_2, p_p1_3, ty_p2_5, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(fresh_p4_1, "_r")), [=](PatOut rust_pat_8163) {
        return ({
            auto inner_p5 = rust_pat_8163;
            auto place_p6 = crate::lower::types::ref_(crate::lower::types::local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4_1}), rc_mode_p3_4, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("a payload")})));
            (prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p4_1}), .conds = append(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcLet{prism_rtl::deref(inner_p5).pa, place_p6})}), prism_rtl::deref(inner_p5).conds), .binds = prism_rtl::deref(inner_p5).binds}));
        });
    });
}


/// `Start BehindRc, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_behind_rc(crate::lower::Lx lx_p0, crate::syntax::Pattern_ p_p1, crate::check::types::Ty ty_p2, crate::lower::types::Holding rc_mode_p3, Text fresh_p4) {
    return prism_rtl::make_rc<BehindRc>(lx_p0, p_p1, ty_p2, rc_mode_p3, fresh_p4);
}


/// RecordPat: unbounded fn Lx, SName, [FieldPat], Bool, Ty, Holding, Text -> PatOut
PatOut record_pat(const crate::lower::Lx& lx_p0, const crate::syntax::SName& n_p1, const Array<crate::syntax::FieldPat>& fps_p2, const bool& rest_p3, const crate::check::types::Ty& ty_p4, const crate::lower::types::Holding& mode_p5, const Text& fresh_p6) {
    auto [qk_o8, why_p9] = crate::check::env::names::resolve_value(lx_p0.g, lx_p0.home, n_p1);
    auto qk_p7 = or_(qk_o8, Text::lit(""));
    return qk_p7 == Text::lit("Prelude.Error")
        ? error_pat(lx_p0, fps_p2, ty_p4, mode_p5, fresh_p6)
        : (why_p9 == Text::lit("tag")) && crate::check::env::has_key(prism_rtl::deref(lx_p0.g).tags, qk_p7)
        ? tag_pat(lx_p0, or_(crate::prelude::get(prism_rtl::deref(lx_p0.g).tags, qk_p7), dummy_tag_info()), fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6)
        : ({
        __label__ _done;
        prism_rtl::Slot<PatOut> _v;
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).ctors, qk_p7);
        if (prism_rtl::is_some(_m)) {
            auto&& c_pa = prism_rtl::some_of(_m);
            _v.set(({
                auto owner_pb = or_(crate::prelude::get(prism_rtl::deref(lx_p0.g).types, prism_rtl::deref(c_pa).owner), crate::check::env::names::dummy_ty_info());
                auto ty_path_pc = crate::lower::path_in(lx_p0, prism_rtl::deref(owner_pb).home, crate::lower::camel(crate::check::types::bare_name(prism_rtl::deref(c_pa).owner)));
                ({
                __label__ _done;
                prism_rtl::Slot<PatOut> _v;
                auto&& _m = prism_rtl::deref(owner_pb).body;
                if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                    auto&& cases_pd = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                    if (len(fps_p2) == Nat(0u)) {
                        _v.set(rest_case_pat(c_pa, cases_pd, ty_path_pc));
                        goto _done;
                    }
                }
                {
                    _v.set(fields_pat(lx_p0, c_pa, fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6, ty_path_pc));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<PatOut> _v;
                auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).tags, qk_p7);
                if (prism_rtl::is_some(_m)) {
                    auto&& tg_pe = prism_rtl::some_of(_m);
                    _v.set(tag_pat(lx_p0, tg_pe, fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal(prism_rtl::cat("a pattern of ", qk_p7))})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<PatOut> RecordPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& n_p1 = this->n_p1;
    const auto& fps_p2 = this->fps_p2;
    const auto& rest_p3 = this->rest_p3;
    const auto& ty_p4 = this->ty_p4;
    const auto& mode_p5 = this->mode_p5;
    const auto& fresh_p6 = this->fresh_p6;
    auto [qk_o8, why_p9] = crate::check::env::names::resolve_value(prism_rtl::deref(lx_p0).g, prism_rtl::deref(lx_p0).home, n_p1);
    auto qk_p7 = or_(qk_o8, Text::lit(""));
    return qk_p7 == Text::lit("Prelude.Error")
        ? prism_rtl::more(prism_rtl::rc(ErrorPat(lx_p0, fps_p2, ty_p4, mode_p5, fresh_p6)))
        : (why_p9 == Text::lit("tag")) && crate::check::env::has_key(prism_rtl::deref(prism_rtl::deref(lx_p0).g).tags, qk_p7)
        ? prism_rtl::more(prism_rtl::rc(TagPat(lx_p0, or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g).tags, qk_p7), dummy_tag_info()), fps_p2, prism_rtl::deref(rest_p3), ty_p4, mode_p5, fresh_p6)))
        : ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g).ctors, qk_p7);
        prism_rtl::is_some(_m) ? ({
        auto&& c_pa = prism_rtl::some_of(_m);
        ({
        auto owner_pb = or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g).types, prism_rtl::deref(c_pa).owner), crate::check::env::names::dummy_ty_info());
        auto ty_path_pc = crate::lower::path_in(lx_p0, prism_rtl::deref(owner_pb).home, crate::lower::camel(crate::check::types::bare_name(prism_rtl::deref(c_pa).owner)));
        ({
        auto&& _m = prism_rtl::deref(owner_pb).body;
        prism_rtl::is<crate::check::env::TyBody::BChoice>(_m) && ({
        auto&& cases_pd = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
        (len(fps_p2) == Nat(0u));
    }) ? ({
        auto&& cases_pd = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
        prism_rtl::finished(rest_case_pat(c_pa, cases_pd, ty_path_pc));
    })
        : prism_rtl::more(prism_rtl::rc(FieldsPat(lx_p0, c_pa, fps_p2, prism_rtl::deref(rest_p3), ty_p4, mode_p5, fresh_p6, ty_path_pc)));
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g).tags, qk_p7);
        prism_rtl::is_some(_m) ? ({
        auto&& tg_pe = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(TagPat(lx_p0, tg_pe, fps_p2, prism_rtl::deref(rest_p3), ty_p4, mode_p5, fresh_p6)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal(prism_rtl::cat("a pattern of ", qk_p7))})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}})
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RecordPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_record_pat(crate::lower::Lx lx_p0, crate::syntax::SName n_p1, Array<crate::syntax::FieldPat> fps_p2, bool rest_p3, crate::check::types::Ty ty_p4, crate::lower::types::Holding mode_p5, Text fresh_p6) {
    return prism_rtl::make_rc<RecordPat>(lx_p0, n_p1, fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6);
}


/// RestCasePat: fn CtorInfo, [((Text, [Ty]))], Text -> PatOut
PatOut rest_case_pat(const crate::check::env::CtorInfo& c_p0, const Array<std::tuple<Text, Array<crate::check::types::Ty>>>& cases_p1, const Text& ty_path_p2) {
    auto is_newtype_p3 = (len(cases_p1) == Nat(1u)) && (crate::check::types::bare_name(c_p0.name) == crate::check::types::bare_name(c_p0.owner));
    auto path_p4 = std::move(is_newtype_p3)
        ? ty_path_p2
        : prism_rtl::cat(ty_path_p2, "::", crate::lower::camel(crate::check::types::bare_name(c_p0.name)));
    return len(c_p0.args) == Nat(0u)
        ? PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{path_p4}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}}
        : PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{path_p4, each(c_p0.args, [&](const crate::check::types::Ty& _p0) { return crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}); })}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
}


/// FieldsPat: unbounded fn Lx, CtorInfo, [FieldPat], Bool, Ty, Holding, Text, Text -> PatOut
PatOut fields_pat(const crate::lower::Lx& lx_p0, const crate::check::env::CtorInfo& c_p1, const Array<crate::syntax::FieldPat>& fps_p2, const bool& rest_p3, const crate::check::types::Ty& ty_p4, const crate::lower::types::Holding& mode_p5, const Text& fresh_p6, const Text& ty_path_p7) {
    auto args_p8 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = crate::lower::types::peel(ty_p4);
        if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
            auto&& xs_pc = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
            _v.set(xs_pc);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto subs_p9 = run_to_end(each_job(crate::check::errors::range0(len(fps_p2)), ({
        auto fps_p2_1 = fps_p2;
        auto c_p1_2 = c_p1;
        auto lx_p0_3 = lx_p0;
        auto args_p8_4 = args_p8;
        auto mode_p5_5 = mode_p5;
        auto fresh_p6_6 = fresh_p6;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, PatOut>>(Nat)>>(prism_rtl::rc([=, fps_p2_1 = std::move(fps_p2_1), c_p1_2 = std::move(c_p1_2), lx_p0_3 = std::move(lx_p0_3), args_p8_4 = std::move(args_p8_4), mode_p5_5 = std::move(mode_p5_5), fresh_p6_6 = std::move(fresh_p6_6)](Nat p0) {
        return ({
            auto fps_p2_1_7 = fps_p2_1;
            auto c_p1_2_7 = c_p1_2;
            auto lx_p0_3_7 = lx_p0_3;
            auto args_p8_4_7 = args_p8_4;
            auto mode_p5_5_7 = mode_p5_5;
            auto fresh_p6_6_7 = fresh_p6_6;
            entered(once_job([=, fps_p2_1_7 = std::move(fps_p2_1_7), c_p1_2_7 = std::move(c_p1_2_7), lx_p0_3_7 = std::move(lx_p0_3_7), args_p8_4_7 = std::move(args_p8_4_7), mode_p5_5_7 = std::move(mode_p5_5_7), fresh_p6_6_7 = std::move(fresh_p6_6_7)]() {
            return ({
                auto i_pd = p0;
                ({
                auto fp_pe = or_(index(fps_p2_1_7, i_pd), dummy_field_pat());
                auto fname_pf = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = prism_rtl::deref(fp_pe).name;
                    if (prism_rtl::is_some(_m)) {
                        auto&& id_ph = prism_rtl::some_of(_m);
                        _v.set(prism_rtl::deref(id_ph).name);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(or_(index(c_p1_2_7.fields, i_pd), Text::lit("")));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto fix_pg = fold(crate::check::errors::range0(len(c_p1_2_7.fields)), i_pd, [&](const Nat& found_pi, const Nat& j_pj) {
                    return or_(index(c_p1_2_7.fields, j_pj), Text::lit("")) == fname_pf
                        ? j_pj
                        : found_pi;
                });
                call_then(crate::lower::expr::start_instantiated(or_(index(c_p1_2_7.args, fix_pg), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), c_p1_2_7.params, args_p8_4_7), [=, fp_pe = std::move(fp_pe), fname_pf = std::move(fname_pf)](crate::check::types::Ty instantiated_10670) { return call_then(start_sub_pat(lx_p0_3_7, c_p1_2_7, fix_pg, prism_rtl::deref(fp_pe).pattern, instantiated_10670, mode_p5_5_7, prism_rtl::cat(fresh_p6_6_7, "_", i_pd)), [=](PatOut sub_pat_10638) { return prism_rtl::finished(std::tuple{crate::lower::snake(fname_pf), sub_pat_10638}); }); });
            });
            });
        }));
        });
    }));
    })));
    auto conds_pa = fold(subs_p9, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_pk, const std::tuple<Text, PatOut>& _p1) {
        auto&& o_pl = std::get<1>(_p1);
        return append(acc_pk, prism_rtl::deref(o_pl).conds);
    });
    auto binds_pb = fold(subs_p9, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_pm, const std::tuple<Text, PatOut>& _p1) {
        auto&& o_pn = std::get<1>(_p1);
        return append(acc_pm, prism_rtl::deref(o_pn).binds);
    });
    return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{ty_path_p7, each(subs_p9, [&](const std::tuple<Text, PatOut>& _p0) {
        auto&& f_po = std::get<0>(_p0);
        auto&& o_pp = std::get<1>(_p0);
        return std::tuple{f_po, prism_rtl::deref(o_pp).pa};
    }), rest_p3 || (len(subs_p9) < len(c_p1.fields))}), .conds = conds_pa, .binds = binds_pb};
}


prism_rtl::Turn<PatOut> FieldsPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& c_p1 = this->c_p1;
    const auto& fps_p2 = this->fps_p2;
    const auto& rest_p3 = this->rest_p3;
    const auto& ty_p4 = this->ty_p4;
    const auto& mode_p5 = this->mode_p5;
    const auto& fresh_p6 = this->fresh_p6;
    const auto& ty_path_p7 = this->ty_path_p7;
    auto args_p8 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = crate::lower::types::peel(ty_p4);
        if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
            auto&& xs_pc = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
            _v.set(xs_pc);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto c_p1_1 = c_p1;
    auto fps_p2_2 = fps_p2;
    auto fresh_p6_3 = fresh_p6;
    auto lx_p0_4 = lx_p0;
    auto mode_p5_5 = mode_p5;
    auto rest_p3_6 = prism_rtl::deref(rest_p3);
    auto ty_path_p7_7 = ty_path_p7;
    return call_value(each_job(crate::check::errors::range0(len(fps_p2_2)), ({
        auto fps_p2_2_8 = fps_p2_2;
        auto c_p1_1_8 = c_p1_1;
        auto lx_p0_4_8 = lx_p0_4;
        auto args_p8_8 = args_p8;
        auto mode_p5_5_9 = mode_p5_5;
        auto fresh_p6_3_9 = fresh_p6_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, PatOut>>(Nat)>>(prism_rtl::rc([=, fps_p2_2_8 = std::move(fps_p2_2_8), c_p1_1_8 = std::move(c_p1_1_8), lx_p0_4_8 = std::move(lx_p0_4_8), args_p8_8 = std::move(args_p8_8), mode_p5_5_9 = std::move(mode_p5_5_9), fresh_p6_3_9 = std::move(fresh_p6_3_9)](Nat p0) {
        return ({
            auto fps_p2_2_8_9 = fps_p2_2_8;
            auto c_p1_1_8_9 = c_p1_1_8;
            auto lx_p0_4_8_9 = lx_p0_4_8;
            auto args_p8_8_9 = args_p8_8;
            auto mode_p5_5_9_9 = mode_p5_5_9;
            auto fresh_p6_3_9_9 = fresh_p6_3_9;
            entered(once_job([=, fps_p2_2_8_9 = std::move(fps_p2_2_8_9), c_p1_1_8_9 = std::move(c_p1_1_8_9), lx_p0_4_8_9 = std::move(lx_p0_4_8_9), args_p8_8_9 = std::move(args_p8_8_9), mode_p5_5_9_9 = std::move(mode_p5_5_9_9), fresh_p6_3_9_9 = std::move(fresh_p6_3_9_9)]() {
            return ({
                auto i_pd = p0;
                ({
                auto fp_pe = or_(index(fps_p2_2_8_9, i_pd), dummy_field_pat());
                auto fname_pf = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = prism_rtl::deref(fp_pe).name;
                    if (prism_rtl::is_some(_m)) {
                        auto&& id_ph = prism_rtl::some_of(_m);
                        _v.set(prism_rtl::deref(id_ph).name);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(or_(index(prism_rtl::deref(c_p1_1_8_9).fields, i_pd), Text::lit("")));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto fix_pg = fold(crate::check::errors::range0(len(prism_rtl::deref(c_p1_1_8_9).fields)), i_pd, [&](const Nat& found_pi, const Nat& j_pj) {
                    return or_(index(prism_rtl::deref(c_p1_1_8_9).fields, j_pj), Text::lit("")) == fname_pf
                        ? j_pj
                        : found_pi;
                });
                call_then(crate::lower::expr::start_instantiated(or_(index(c_p1_1_8_9->args, fix_pg), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), prism_rtl::deref(c_p1_1_8_9).params, args_p8_8_9), [=, fp_pe = std::move(fp_pe), fname_pf = std::move(fname_pf)](crate::check::types::Ty instantiated_10670) { return call_then(start_sub_pat(lx_p0_4_8_9, c_p1_1_8_9, fix_pg, prism_rtl::deref(fp_pe).pattern, instantiated_10670, mode_p5_5_9_9, prism_rtl::cat(fresh_p6_3_9_9, "_", i_pd)), [=](PatOut sub_pat_10638) { return prism_rtl::finished(std::tuple{crate::lower::snake(fname_pf), sub_pat_10638}); }); });
            });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Text, PatOut>> each_10285) {
        return ({
            auto subs_p9 = each_10285;
            auto conds_pa = fold(subs_p9, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_pk, const std::tuple<Text, PatOut>& _p1) {
                auto&& o_pl = std::get<1>(_p1);
                return append(acc_pk, prism_rtl::deref(o_pl).conds);
            });
            auto binds_pb = fold(subs_p9, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_pm, const std::tuple<Text, PatOut>& _p1) {
                auto&& o_pn = std::get<1>(_p1);
                return append(acc_pm, prism_rtl::deref(o_pn).binds);
            });
            (prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{ty_path_p7_7, each(subs_p9, [&](const std::tuple<Text, PatOut>& _p0) {
            auto&& f_po = std::get<0>(_p0);
            auto&& o_pp = std::get<1>(_p0);
            return std::tuple{f_po, prism_rtl::deref(o_pp).pa};
        }), rest_p3_6 || (len(subs_p9) < len(prism_rtl::deref(c_p1_1).fields))}), .conds = conds_pa, .binds = binds_pb}));
        });
    });
}


/// `Start FieldsPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_fields_pat(crate::lower::Lx lx_p0, crate::check::env::CtorInfo c_p1, Array<crate::syntax::FieldPat> fps_p2, bool rest_p3, crate::check::types::Ty ty_p4, crate::lower::types::Holding mode_p5, Text fresh_p6, Text ty_path_p7) {
    return prism_rtl::make_rc<FieldsPat>(lx_p0, c_p1, fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6, ty_path_p7);
}


/// let dummyFieldPat
crate::syntax::FieldPat dummy_field_pat() {
    return crate::syntax::FieldPat{.name = std::optional<crate::syntax::Ident>{}, .pattern = dummy_pat(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// let dummyTagInfo
crate::check::env::TagInfo dummy_tag_info() {
    return crate::check::env::TagInfo{.name = Text::lit(""), .family = Text::lit(""), .kind = Text::lit(""), .out = crate::check::types::Ty(crate::check::types::Ty::TyErr{}), .qs = Array<Text>{}, .rqs = Array<Text>{}, .bounds = Array<std::tuple<Text, Text>>{}, .fields = Array<std::tuple<Text, crate::check::types::Ty>>{}, .home = Text::lit(""), .file = Nat(0u), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// IsLive: fn Ty -> Bool
bool is_live(const crate::check::types::Ty& t_p0) {
    auto&& _m = crate::lower::types::peel(t_p0);
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// TagFieldName: fn FieldPat, [Text], Nat -> Text
Text tag_field_name(const crate::syntax::FieldPat& fp_p0, const Array<Text>& names_p1, const Nat& i_p2) {
    auto&& _m = fp_p0.name;
    if (prism_rtl::is_some(_m)) {
        auto&& id_p3 = prism_rtl::some_of(_m);
        return prism_rtl::deref(id_p3).name;
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = prism_rtl::deref(prism_rtl::deref(fp_p0.pattern).kind);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n_p4 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return crate::check::types::has_text(names_p1, crate::check::env::sname_key(n_p4))
                ? crate::check::env::sname_key(n_p4)
                : or_(index(names_p1, i_p2), Text::lit(""));
        }
        {
            return or_(index(names_p1, i_p2), Text::lit(""));
        }
    }
    prism_rtl::unreachable("no arm matched");
}


/// TagPat: unbounded fn Lx, TagInfo, [FieldPat], Bool, Ty, Holding, Text -> PatOut
PatOut tag_pat(const crate::lower::Lx& lx_p0, const crate::check::env::TagInfo& tg_p1, const Array<crate::syntax::FieldPat>& fps_p2, const bool& rest_p3, const crate::check::types::Ty& ty_p4, const crate::lower::types::Holding& mode_p5, const Text& fresh_p6) {
    auto [variant_pg, struct_path_ph] = crate::lower::program::tag_paths(lx_p0, tg_p1);
    auto live_p7 = is_live(ty_p4);
    auto names_p8 = each(tg_p1.fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& f_pi = std::get<0>(_p0);
        return f_pi;
    });
    auto sub_mode_p9 = std::move(live_p7)
        ? crate::lower::types::Holding(crate::lower::types::Holding::ByRef{})
        : mode_p5;
    auto parts_pa = run_to_end(each_job(crate::check::errors::range0(len(fps_p2)), ({
        auto fps_p2_1 = fps_p2;
        auto names_p8_2 = names_p8;
        auto tg_p1_3 = tg_p1;
        auto live_p7_4 = std::move(live_p7);
        auto lx_p0_5 = lx_p0;
        auto variant_pg_6 = variant_pg;
        auto fresh_p6_7 = fresh_p6;
        auto sub_mode_p9_8 = sub_mode_p9;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<std::optional<Text>, PatOut>>(Nat)>>(prism_rtl::rc([=, fps_p2_1 = std::move(fps_p2_1), names_p8_2 = std::move(names_p8_2), tg_p1_3 = std::move(tg_p1_3), live_p7_4 = std::move(live_p7_4), lx_p0_5 = std::move(lx_p0_5), variant_pg_6 = std::move(variant_pg_6), fresh_p6_7 = std::move(fresh_p6_7), sub_mode_p9_8 = std::move(sub_mode_p9_8)](Nat p0) {
        return ({
            auto fps_p2_1_9 = fps_p2_1;
            auto names_p8_2_9 = names_p8_2;
            auto tg_p1_3_9 = tg_p1_3;
            auto live_p7_4_9 = live_p7_4;
            auto lx_p0_5_9 = lx_p0_5;
            auto variant_pg_6_9 = variant_pg_6;
            auto fresh_p6_7_9 = fresh_p6_7;
            auto sub_mode_p9_8_9 = sub_mode_p9_8;
            entered(once_job([=, fps_p2_1_9 = std::move(fps_p2_1_9), names_p8_2_9 = std::move(names_p8_2_9), tg_p1_3_9 = std::move(tg_p1_3_9), live_p7_4_9 = std::move(live_p7_4_9), lx_p0_5_9 = std::move(lx_p0_5_9), variant_pg_6_9 = std::move(variant_pg_6_9), fresh_p6_7_9 = std::move(fresh_p6_7_9), sub_mode_p9_8_9 = std::move(sub_mode_p9_8_9)]() {
            return ({
                auto i_pj = p0;
                ({
                auto fp_pk = or_(index(fps_p2_1_9, i_pj), dummy_field_pat());
                auto fname_pl = tag_field_name(fp_pk, names_p8_2_9, i_pj);
                auto ft_pm = fold(tg_p1_3_9.fields, crate::check::types::Ty(crate::check::types::Ty::TyErr{}), [&](const crate::check::types::Ty& found_pn, const std::tuple<Text, crate::check::types::Ty>& _p1) {
                    auto&& f_po = std::get<0>(_p1);
                    auto&& t_pp = std::get<1>(_p1);
                    return f_po == fname_pl ? t_pp : found_pn;
                });
                ({
                auto&& _m = crate::lower::types::layer_of(ft_pm);
                prism_rtl::is<crate::lower::types::Layer::LyEv>(_m) ? prism_rtl::finished(std::tuple{std::optional<Text>{}, PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal(prism_rtl::cat("an event field in an element pattern (", tg_p1_3_9.name, ".", fname_pl, ")"))})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}}})
                : prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m) && ({
                live_p7_4_9;
            }) ? call_then(start_live_field_pat(lx_p0_5_9, prism_rtl::deref(fp_pk).pattern, variant_pg_6_9, fname_pl, ft_pm, fresh_p6_7_9), [=](PatOut live_field_pat_13045) { return prism_rtl::finished(std::tuple{std::optional<Text>{}, live_field_pat_13045}); })
                : call_then(start_rust_pat(lx_p0_5_9, prism_rtl::deref(fp_pk).pattern, crate::lower::types::peel(ft_pm), sub_mode_p9_8_9, prism_rtl::cat(fresh_p6_7_9, "_", i_pj)), [=](PatOut rust_pat_13150) {
                return ({
                    auto o_pq = rust_pat_13150;
                    (prism_rtl::finished(std::tuple{std::optional(crate::lower::snake(fname_pl)), o_pq}));
                });
            });
            });
            });
            });
        }));
        });
    }));
    })));
    auto field_pas_pb = fold(parts_pa, Array<std::tuple<Text, crate::lower::model::Pa>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Pa>>& acc_pr, const std::tuple<std::optional<Text>, PatOut>& _p1) {
        auto&& f_os = std::get<0>(_p1);
        auto&& o_pt = std::get<1>(_p1);
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::Pa>>> _v;
            if (prism_rtl::is_some(f_os)) {
                auto&& f_pu = prism_rtl::some_of(f_os);
                _v.set(crate::prelude::push(acc_pr, std::tuple{f_pu, prism_rtl::deref(o_pt).pa}));
                goto _done;
            }
            if (prism_rtl::is_none(f_os)) {
                _v.set(acc_pr);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto conds_pc = fold(parts_pa, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_pv, const std::tuple<std::optional<Text>, PatOut>& _p1) {
        auto&& o_p10 = std::get<1>(_p1);
        return append(acc_pv, prism_rtl::deref(o_p10).conds);
    });
    auto binds_pd = fold(parts_pa, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_p11, const std::tuple<std::optional<Text>, PatOut>& _p1) {
        auto&& o_p12 = std::get<1>(_p1);
        return append(acc_p11, prism_rtl::deref(o_p12).binds);
    });
    auto level_pe = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{variant_pg, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{struct_path_ph, field_pas_pb, true})})});
    auto tagged_pf = crate::prelude::push(binds_pd, std::tuple{Text::lit("#tag"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::node_::elements::answer_variant(tg_p1)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})})});
    return std::move(live_p7)
        ? PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p6}), .conds = append(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcLet{level_pe, crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p6})), Text::lit("identity")}))})})}), conds_pc), .binds = tagged_pf}
        : PatOut{.pa = level_pe, .conds = conds_pc, .binds = binds_pd};
}


prism_rtl::Turn<PatOut> TagPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& tg_p1 = this->tg_p1;
    const auto& fps_p2 = this->fps_p2;
    const auto& rest_p3 = this->rest_p3;
    const auto& ty_p4 = this->ty_p4;
    const auto& mode_p5 = this->mode_p5;
    const auto& fresh_p6 = this->fresh_p6;
    auto [variant_pg, struct_path_ph] = crate::lower::program::tag_paths(lx_p0, tg_p1);
    auto live_p7 = is_live(ty_p4);
    auto names_p8 = each(prism_rtl::deref(tg_p1).fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& f_pi = std::get<0>(_p0);
        return f_pi;
    });
    auto sub_mode_p9 = std::move(live_p7)
        ? crate::lower::types::Holding(crate::lower::types::Holding::ByRef{})
        : mode_p5;
    auto fps_p2_1 = fps_p2;
    auto fresh_p6_2 = fresh_p6;
    auto lx_p0_3 = lx_p0;
    auto tg_p1_4 = tg_p1;
    return call_value(each_job(crate::check::errors::range0(len(fps_p2_1)), ({
        auto fps_p2_1_5 = fps_p2_1;
        auto names_p8_5 = names_p8;
        auto tg_p1_4_6 = tg_p1_4;
        auto live_p7_6 = std::move(live_p7);
        auto lx_p0_3_7 = lx_p0_3;
        auto variant_pg_7 = variant_pg;
        auto fresh_p6_2_8 = fresh_p6_2;
        auto sub_mode_p9_8 = sub_mode_p9;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<std::optional<Text>, PatOut>>(Nat)>>(prism_rtl::rc([=, fps_p2_1_5 = std::move(fps_p2_1_5), names_p8_5 = std::move(names_p8_5), tg_p1_4_6 = std::move(tg_p1_4_6), live_p7_6 = std::move(live_p7_6), lx_p0_3_7 = std::move(lx_p0_3_7), variant_pg_7 = std::move(variant_pg_7), fresh_p6_2_8 = std::move(fresh_p6_2_8), sub_mode_p9_8 = std::move(sub_mode_p9_8)](Nat p0) {
        return ({
            auto fps_p2_1_5_9 = fps_p2_1_5;
            auto names_p8_5_9 = names_p8_5;
            auto tg_p1_4_6_9 = tg_p1_4_6;
            auto live_p7_6_9 = live_p7_6;
            auto lx_p0_3_7_9 = lx_p0_3_7;
            auto variant_pg_7_9 = variant_pg_7;
            auto fresh_p6_2_8_9 = fresh_p6_2_8;
            auto sub_mode_p9_8_9 = sub_mode_p9_8;
            entered(once_job([=, fps_p2_1_5_9 = std::move(fps_p2_1_5_9), names_p8_5_9 = std::move(names_p8_5_9), tg_p1_4_6_9 = std::move(tg_p1_4_6_9), live_p7_6_9 = std::move(live_p7_6_9), lx_p0_3_7_9 = std::move(lx_p0_3_7_9), variant_pg_7_9 = std::move(variant_pg_7_9), fresh_p6_2_8_9 = std::move(fresh_p6_2_8_9), sub_mode_p9_8_9 = std::move(sub_mode_p9_8_9)]() {
            return ({
                auto i_pj = p0;
                ({
                auto fp_pk = or_(index(fps_p2_1_5_9, i_pj), dummy_field_pat());
                auto fname_pl = tag_field_name(fp_pk, names_p8_5_9, i_pj);
                auto ft_pm = fold(prism_rtl::deref(tg_p1_4_6_9).fields, crate::check::types::Ty(crate::check::types::Ty::TyErr{}), [&](const crate::check::types::Ty& found_pn, const std::tuple<Text, crate::check::types::Ty>& _p1) {
                    auto&& f_po = std::get<0>(_p1);
                    auto&& t_pp = std::get<1>(_p1);
                    return f_po == fname_pl ? t_pp : found_pn;
                });
                ({
                auto&& _m = crate::lower::types::layer_of(ft_pm);
                prism_rtl::is<crate::lower::types::Layer::LyEv>(_m) ? prism_rtl::finished(std::tuple{std::optional<Text>{}, PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal(prism_rtl::cat("an event field in an element pattern (", prism_rtl::deref(tg_p1_4_6_9).name, ".", fname_pl, ")"))})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}}})
                : prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m) && ({
                live_p7_6_9;
            }) ? call_then(start_live_field_pat(lx_p0_3_7_9, prism_rtl::deref(fp_pk).pattern, variant_pg_7_9, fname_pl, ft_pm, fresh_p6_2_8_9), [=](PatOut live_field_pat_13045) { return prism_rtl::finished(std::tuple{std::optional<Text>{}, live_field_pat_13045}); })
                : call_then(start_rust_pat(lx_p0_3_7_9, prism_rtl::deref(fp_pk).pattern, crate::lower::types::peel(ft_pm), sub_mode_p9_8_9, prism_rtl::cat(fresh_p6_2_8_9, "_", i_pj)), [=](PatOut rust_pat_13150) {
                return ({
                    auto o_pq = rust_pat_13150;
                    (prism_rtl::finished(std::tuple{std::optional(crate::lower::snake(fname_pl)), o_pq}));
                });
            });
            });
            });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<std::optional<Text>, PatOut>> each_12634) {
        return ({
            auto parts_pa = each_12634;
            auto field_pas_pb = fold(parts_pa, Array<std::tuple<Text, crate::lower::model::Pa>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Pa>>& acc_pr, const std::tuple<std::optional<Text>, PatOut>& _p1) {
                auto&& f_os = std::get<0>(_p1);
                auto&& o_pt = std::get<1>(_p1);
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::Pa>>> _v;
                    if (prism_rtl::is_some(f_os)) {
                        auto&& f_pu = prism_rtl::some_of(f_os);
                        _v.set(crate::prelude::push(acc_pr, std::tuple{f_pu, prism_rtl::deref(o_pt).pa}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(f_os)) {
                        _v.set(acc_pr);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
            });
            auto conds_pc = fold(parts_pa, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_pv, const std::tuple<std::optional<Text>, PatOut>& _p1) {
                auto&& o_p10 = std::get<1>(_p1);
                return append(acc_pv, prism_rtl::deref(o_p10).conds);
            });
            auto binds_pd = fold(parts_pa, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_p11, const std::tuple<std::optional<Text>, PatOut>& _p1) {
                auto&& o_p12 = std::get<1>(_p1);
                return append(acc_p11, prism_rtl::deref(o_p12).binds);
            });
            auto level_pe = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{variant_pg, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{struct_path_ph, field_pas_pb, true})})});
            auto tagged_pf = crate::prelude::push(binds_pd, std::tuple{Text::lit("#tag"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::node_::elements::answer_variant(tg_p1_4)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})})});
            live_p7
            ? prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p6_2}), .conds = append(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcLet{level_pe, crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p6_2})), Text::lit("identity")}))})})}), conds_pc), .binds = tagged_pf})
            : prism_rtl::finished(PatOut{.pa = level_pe, .conds = conds_pc, .binds = binds_pd});
        });
    });
}


/// `Start TagPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_tag_pat(crate::lower::Lx lx_p0, crate::check::env::TagInfo tg_p1, Array<crate::syntax::FieldPat> fps_p2, bool rest_p3, crate::check::types::Ty ty_p4, crate::lower::types::Holding mode_p5, Text fresh_p6) {
    return prism_rtl::make_rc<TagPat>(lx_p0, tg_p1, fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6);
}


/// LiveFieldPat: unbounded fn Lx, Pattern, Text, Text, Ty, Text -> PatOut
PatOut live_field_pat(const crate::lower::Lx& lx_p0, const crate::syntax::Pattern_& p_p1, const Text& variant_p2, const Text& fname_p3, const crate::check::types::Ty& ft_p4, const Text& fresh_p5) {
    auto&& _m = prism_rtl::deref(p_p1.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
        return pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p6 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto rs_p7 = lx_p0.in_node
            ? live_projection(fresh_p5, variant_p2, fname_p3, crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(ft_p4)))
            : crate::lower::expr::refusal(prism_rtl::cat("a live element\'s `$` field (", fname_p3, ") in a plain function, which has no read point (gap LE)"));
        return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array(std::vector{std::tuple{crate::check::env::sname_key(n_p6), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{rs_p7, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(ft_p4)))})})}})};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_p8 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return live_field_pat(lx_p0, prism_rtl::deref(prism_rtl::deref(q_p8)), variant_p2, fname_p3, ft_p4, fresh_p5);
    }
    {
        return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal(prism_rtl::cat("a pattern inside a live element\'s `$` field (", fname_p3, ")"))})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
    }
}


prism_rtl::Turn<PatOut> LiveFieldPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& p_p1 = this->p_p1;
    const auto& variant_p2 = this->variant_p2;
    const auto& fname_p3 = this->fname_p3;
    const auto& ft_p4 = this->ft_p4;
    const auto& fresh_p5 = this->fresh_p5;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p1).kind);
        prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})))
        : prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_p6 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto rs_p7 = prism_rtl::deref(lx_p0).in_node
            ? live_projection(fresh_p5, variant_p2, fname_p3, crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(ft_p4)))
            : crate::lower::expr::refusal(prism_rtl::cat("a live element\'s `$` field (", fname_p3, ") in a plain function, which has no read point (gap LE)"));
        auto ft_p4_1 = ft_p4;
        auto lx_p0_2 = lx_p0;
        auto n_p6_3 = n_p6;
        call_then(crate::lower::types::start_out_ty_of(lx_p0_2, crate::lower::types::peel(ft_p4_1)), [=, rs_p7 = std::move(rs_p7), n_p6_3 = std::move(n_p6_3)](crate::lower::model::OutTy out_ty_of_14762) { return prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array(std::vector{std::tuple{crate::check::env::sname_key(n_p6_3), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{rs_p7, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(out_ty_of_14762)})})}})}); });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q_p8 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(LiveFieldPat(lx_p0, prism_rtl::deref(prism_rtl::deref(q_p8)), variant_p2, fname_p3, ft_p4, fresh_p5)));
    })
        : prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal(prism_rtl::cat("a pattern inside a live element\'s `$` field (", fname_p3, ")"))})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
    });
}


/// `Start LiveFieldPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_live_field_pat(crate::lower::Lx lx_p0, crate::syntax::Pattern_ p_p1, Text variant_p2, Text fname_p3, crate::check::types::Ty ft_p4, Text fresh_p5) {
    return prism_rtl::make_rc<LiveFieldPat>(lx_p0, p_p1, variant_p2, fname_p3, ft_p4, fresh_p5);
}


/// LiveProjection: fn Text, Text, Text, OutTy -> Ex
crate::lower::model::Ex live_projection(const Text& fresh_p0, const Text& variant_p1, const Text& fname_p2, const crate::lower::model::OutTy& ft_p3) {
    auto arm_p4 = crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{variant_p1, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("x")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("x")})), crate::lower::snake(fname_p2)}))})};
    auto other_p5 = crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XUnreachable{})};
    return crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p0})), Text::lit("level")})), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("l")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("l")})), Array(std::vector{arm_p4, other_p5}), false, ft_p3}))})})});
}


/// FamilyPat: unbounded fn Lx, QualName, Ty, Text -> PatOut
PatOut family_pat(const crate::lower::Lx& lx_p0, const crate::syntax::QualName& q_p1, const crate::check::types::Ty& ty_p2, const Text& fresh_p3) {
    auto fam_p4 = crate::check::env::dotted(filter(q_p1.path_, [&](const Text& x_p8) { return x_p8 != Text::lit("*"); }));
    auto kind_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::lower::types::peel(ty_p2);
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            _v.set(Text::lit("Element"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
            _v.set(Text::lit("Element"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
            auto&& k_p9 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
            _v.set(k_p9);
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto tags_p6 = filter(crate::lower::program::kind_tags(lx_p0, kind_p5, keys(lx_p0.rs_mods)), [&](const crate::check::env::TagInfo& tg_pa) { return prism_rtl::deref(tg_pa).family == fam_p4; });
    auto place_p7 = is_live(ty_p2)
        ? crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p3})), Text::lit("identity")})
        : crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p3});
    return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p3}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XIsCase{prism_rtl::rc(place_p7), each(tags_p6, [&](const crate::check::env::TagInfo& tg_pb) { return crate::lower::program::variant_of(lx_p0, tg_pb); })})})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
}


prism_rtl::Turn<PatOut> FamilyPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& q_p1 = this->q_p1;
    const auto& ty_p2 = this->ty_p2;
    const auto& fresh_p3 = this->fresh_p3;
    auto fam_p4 = crate::check::env::dotted(filter(q_p1->path_, [&](const Text& x_p8) { return x_p8 != Text::lit("*"); }));
    auto kind_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::lower::types::peel(ty_p2);
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            _v.set(Text::lit("Element"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
            _v.set(Text::lit("Element"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
            auto&& k_p9 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
            _v.set(k_p9);
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto tags_p6 = filter(crate::lower::program::kind_tags(lx_p0, kind_p5, keys(prism_rtl::deref(lx_p0).rs_mods)), [&](const crate::check::env::TagInfo& tg_pa) { return prism_rtl::deref(tg_pa).family == fam_p4; });
    auto place_p7 = is_live(ty_p2)
        ? crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p3})), Text::lit("identity")})
        : crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p3});
    return prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p3}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XIsCase{prism_rtl::rc(place_p7), each(tags_p6, [&](const crate::check::env::TagInfo& tg_pb) { return crate::lower::program::variant_of(lx_p0, tg_pb); })})})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
}


/// `Start FamilyPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_family_pat(crate::lower::Lx lx_p0, crate::syntax::QualName q_p1, crate::check::types::Ty ty_p2, Text fresh_p3) {
    return prism_rtl::make_rc<FamilyPat>(lx_p0, q_p1, ty_p2, fresh_p3);
}


/// ErrorPat: unbounded fn Lx, [FieldPat], Ty, Holding, Text -> PatOut
PatOut error_pat(const crate::lower::Lx& lx_p0, const Array<crate::syntax::FieldPat>& fps_p1, const crate::check::types::Ty& ty_p2, const crate::lower::types::Holding& mode_p3, const Text& fresh_p4) {
    auto e_p5 = crate::lower::types::local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4}), mode_p3, crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{}));
    auto parts_p6 = each(fps_p1, [&](const crate::syntax::FieldPat& fp_p8) {
        return ({
            auto fname_p9 = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = prism_rtl::deref(fp_p8).name;
                if (prism_rtl::is_some(_m)) {
                    auto&& id_pa = prism_rtl::some_of(_m);
                    _v.set(prism_rtl::deref(id_pa).name);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
            {
                auto&& m16377_0 = fname_p9;
                if (m16377_0 == Text::lit("kind")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
                        auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(fp_p8).pattern).kind);
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& k_pb = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(({
                                auto&& _kq_oc = crate::check::env::names::resolve_value(lx_p0.g, lx_p0.home, k_pb);
                                auto&& kq_oc = std::get<0>(_kq_oc);
                                ({
                                __label__ _done;
                                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
                                if (prism_rtl::is_some(kq_oc)) {
                                    auto&& kq_pd = prism_rtl::some_of(kq_oc);
                                    _v.set(crate::check::env::has_key(prism_rtl::deref(lx_p0.g).tags, kq_pd)
                                        ? std::tuple{Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4})), Text::lit("kind")}))}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XStr{kq_pd}))})})}), Array<std::tuple<Text, crate::lower::types::Bn>>{}}
                                        : std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key(k_pb), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4})), Text::lit("kind")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                                    goto _done;
                                }
                                if (prism_rtl::is_none(kq_oc)) {
                                    _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key(k_pb), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4})), Text::lit("kind")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                auto&& m16377_1 = fname_p9;
                if (m16377_1 == Text::lit("message")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
                        auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(fp_p8).pattern).kind);
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& m_pe = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key(m_pe), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4})), Text::lit("message")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                goto _done;
            }
        _done:
            _v.take();
        });
        });
    });
    auto wrapped_p7 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Pa> _v;
        auto&& _m = crate::lower::types::peel(ty_p2);
        if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
            auto&& m17214_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
            if (m17214_0_0 == Text::lit("~")) {
                _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p4})})}));
                goto _done;
            }
        }
        {
            _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p4}));
            goto _done;
        }
    _done:
        _v.take();
    });
    return PatOut{.pa = wrapped_p7, .conds = fold(parts_p6, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_pf, const std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>& _p1) {
        auto&& cs_pg = std::get<0>(_p1);
        return append(acc_pf, cs_pg);
    }), .binds = fold(parts_p6, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_ph, const std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>& _p1) {
        auto&& bs_pi = std::get<1>(_p1);
        return append(acc_ph, bs_pi);
    })};
}


prism_rtl::Turn<PatOut> ErrorPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& fps_p1 = this->fps_p1;
    const auto& ty_p2 = this->ty_p2;
    const auto& mode_p3 = this->mode_p3;
    const auto& fresh_p4 = this->fresh_p4;
    auto e_p5 = crate::lower::types::local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4}), mode_p3, crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{}));
    auto parts_p6 = each(fps_p1, [&](const crate::syntax::FieldPat& fp_p8) {
        return ({
            auto fname_p9 = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = prism_rtl::deref(fp_p8).name;
                if (prism_rtl::is_some(_m)) {
                    auto&& id_pa = prism_rtl::some_of(_m);
                    _v.set(prism_rtl::deref(id_pa).name);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
            {
                auto&& m16377_0 = fname_p9;
                if (m16377_0 == Text::lit("kind")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
                        auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(fp_p8).pattern).kind);
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& k_pb = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(({
                                auto&& _kq_oc = crate::check::env::names::resolve_value(prism_rtl::deref(lx_p0).g, prism_rtl::deref(lx_p0).home, k_pb);
                                auto&& kq_oc = std::get<0>(_kq_oc);
                                ({
                                __label__ _done;
                                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
                                if (prism_rtl::is_some(kq_oc)) {
                                    auto&& kq_pd = prism_rtl::some_of(kq_oc);
                                    _v.set(crate::check::env::has_key(prism_rtl::deref(prism_rtl::deref(lx_p0).g).tags, kq_pd)
                                        ? std::tuple{Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4})), Text::lit("kind")}))}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XStr{kq_pd}))})})}), Array<std::tuple<Text, crate::lower::types::Bn>>{}}
                                        : std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key(k_pb), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4})), Text::lit("kind")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                                    goto _done;
                                }
                                if (prism_rtl::is_none(kq_oc)) {
                                    _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key(k_pb), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4})), Text::lit("kind")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                auto&& m16377_1 = fname_p9;
                if (m16377_1 == Text::lit("message")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
                        auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(fp_p8).pattern).kind);
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& m_pe = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key(m_pe), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4})), Text::lit("message")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                goto _done;
            }
        _done:
            _v.take();
        });
        });
    });
    auto wrapped_p7 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Pa> _v;
        auto&& _m = crate::lower::types::peel(ty_p2);
        if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
            auto&& m17214_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
            if (m17214_0_0 == Text::lit("~")) {
                _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p4})})}));
                goto _done;
            }
        }
        {
            _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p4}));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(PatOut{.pa = wrapped_p7, .conds = fold(parts_p6, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_pf, const std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>& _p1) {
        auto&& cs_pg = std::get<0>(_p1);
        return append(acc_pf, cs_pg);
    }), .binds = fold(parts_p6, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_ph, const std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>& _p1) {
        auto&& bs_pi = std::get<1>(_p1);
        return append(acc_ph, bs_pi);
    })});
}


/// `Start ErrorPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_error_pat(crate::lower::Lx lx_p0, Array<crate::syntax::FieldPat> fps_p1, crate::check::types::Ty ty_p2, crate::lower::types::Holding mode_p3, Text fresh_p4) {
    return prism_rtl::make_rc<ErrorPat>(lx_p0, fps_p1, ty_p2, mode_p3, fresh_p4);
}


/// ArrayPat: unbounded fn Lx, [Pattern], Ty, Holding, Text -> PatOut
PatOut array_pat(const crate::lower::Lx& lx_p0, const Array<crate::syntax::Pattern_>& ps_p1, const crate::check::types::Ty& ty_p2, const crate::lower::types::Holding& mode_p3, const Text& fresh_p4) {
    auto et_p5 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        auto&& _m = crate::lower::types::peel(ty_p2);
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
            auto&& x_pb = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
            _v.set(prism_rtl::deref(x_pb));
            goto _done;
        }
        {
            _v.set(crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto arr_p6 = crate::lower::types::local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4}), mode_p3, crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(ty_p2)));
    auto len_cond_p7 = crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::ref_(arr_p6)), Text::lit("len"), Array<crate::lower::model::Ex>{}})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XIndex{len(ps_p1)}))})});
    auto subs_p8 = run_to_end(each_job(crate::check::errors::range0(len(ps_p1)), ({
        auto lx_p0_1 = lx_p0;
        auto ps_p1_2 = ps_p1;
        auto et_p5_3 = et_p5;
        auto fresh_p4_4 = fresh_p4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Nat, PatOut>>(Nat)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), ps_p1_2 = std::move(ps_p1_2), et_p5_3 = std::move(et_p5_3), fresh_p4_4 = std::move(fresh_p4_4)](Nat p0) {
        return ({
            auto lx_p0_1_5 = lx_p0_1;
            auto ps_p1_2_5 = ps_p1_2;
            auto et_p5_3_5 = et_p5_3;
            auto fresh_p4_4_5 = fresh_p4_4;
            entered(once_job([=, lx_p0_1_5 = std::move(lx_p0_1_5), ps_p1_2_5 = std::move(ps_p1_2_5), et_p5_3_5 = std::move(et_p5_3_5), fresh_p4_4_5 = std::move(fresh_p4_4_5)]() {
            return ({
                auto i_pc = p0;
                call_then(start_rust_pat(lx_p0_1_5, or_(index(ps_p1_2_5, i_pc), dummy_pat()), et_p5_3_5, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat(fresh_p4_4_5, "_", i_pc)), [=](PatOut rust_pat_17911) { return prism_rtl::finished(std::tuple{i_pc, rust_pat_17911}); });
            });
        }));
        });
    }));
    })));
    auto conds_p9 = fold(subs_p8, Array(std::vector{len_cond_p7}), [&](const Array<crate::lower::model::Cc>& acc_pd, const std::tuple<Nat, PatOut>& _p1) {
        auto&& i_pe = std::get<0>(_p1);
        auto&& o_pf = std::get<1>(_p1);
        return append(crate::prelude::push(acc_pd, crate::lower::model::Cc(crate::lower::model::Cc::CcLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{prism_rtl::deref(o_pf).pa})}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("index"), Array(std::vector{crate::lower::types::ref_(arr_p6), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNat{prism_rtl::cat(i_pe)}))})})})})), prism_rtl::deref(o_pf).conds);
    });
    auto binds_pa = fold(subs_p8, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_pg, const std::tuple<Nat, PatOut>& _p1) {
        auto&& o_ph = std::get<1>(_p1);
        return append(acc_pg, prism_rtl::deref(o_ph).binds);
    });
    return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p4}), .conds = conds_p9, .binds = binds_pa};
}


prism_rtl::Turn<PatOut> ArrayPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& ps_p1 = this->ps_p1;
    const auto& ty_p2 = this->ty_p2;
    const auto& mode_p3 = this->mode_p3;
    const auto& fresh_p4 = this->fresh_p4;
    auto et_p5 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        auto&& _m = crate::lower::types::peel(ty_p2);
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
            auto&& x_pb = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
            _v.set(prism_rtl::deref(x_pb));
            goto _done;
        }
        {
            _v.set(crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto fresh_p4_1 = fresh_p4;
    auto lx_p0_2 = lx_p0;
    auto mode_p3_3 = mode_p3;
    auto ps_p1_4 = ps_p1;
    auto ty_p2_5 = ty_p2;
    return call_then(crate::lower::types::start_out_ty_of(lx_p0_2, crate::lower::types::peel(ty_p2_5)), [=](crate::lower::model::OutTy out_ty_of_17750) {
        return ({
            auto arr_p6 = crate::lower::types::local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_p4_1}), mode_p3_3, out_ty_of_17750);
            auto len_cond_p7 = crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::ref_(arr_p6)), Text::lit("len"), Array<crate::lower::model::Ex>{}})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XIndex{len(ps_p1_4)}))})});
            call_value(each_job(crate::check::errors::range0(len(ps_p1_4)), ({
            auto lx_p0_2_6 = lx_p0_2;
            auto ps_p1_4_6 = ps_p1_4;
            auto et_p5_6 = et_p5;
            auto fresh_p4_1_7 = fresh_p4_1;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Nat, PatOut>>(Nat)>>(prism_rtl::rc([=, lx_p0_2_6 = std::move(lx_p0_2_6), ps_p1_4_6 = std::move(ps_p1_4_6), et_p5_6 = std::move(et_p5_6), fresh_p4_1_7 = std::move(fresh_p4_1_7)](Nat p0) {
            return ({
                auto lx_p0_2_6_7 = lx_p0_2_6;
                auto ps_p1_4_6_7 = ps_p1_4_6;
                auto et_p5_6_7 = et_p5_6;
                auto fresh_p4_1_7_7 = fresh_p4_1_7;
                entered(once_job([=, lx_p0_2_6_7 = std::move(lx_p0_2_6_7), ps_p1_4_6_7 = std::move(ps_p1_4_6_7), et_p5_6_7 = std::move(et_p5_6_7), fresh_p4_1_7_7 = std::move(fresh_p4_1_7_7)]() {
                return ({
                    auto i_pc = p0;
                    call_then(start_rust_pat(lx_p0_2_6_7, or_(index(ps_p1_4_6_7, i_pc), dummy_pat()), et_p5_6_7, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat(fresh_p4_1_7_7, "_", i_pc)), [=](PatOut rust_pat_17911) { return prism_rtl::finished(std::tuple{i_pc, rust_pat_17911}); });
                });
            }));
            });
        }));
        })), [=, arr_p6 = std::move(arr_p6), len_cond_p7 = std::move(len_cond_p7)](Array<std::tuple<Nat, PatOut>> each_17876) {
            return ({
                auto subs_p8 = each_17876;
                auto conds_p9 = fold(subs_p8, Array(std::vector{len_cond_p7}), [&](const Array<crate::lower::model::Cc>& acc_pd, const std::tuple<Nat, PatOut>& _p1) {
                    auto&& i_pe = std::get<0>(_p1);
                    auto&& o_pf = std::get<1>(_p1);
                    return append(crate::prelude::push(acc_pd, crate::lower::model::Cc(crate::lower::model::Cc::CcLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{prism_rtl::deref(o_pf).pa})}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("index"), Array(std::vector{crate::lower::types::ref_(arr_p6), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNat{prism_rtl::cat(i_pe)}))})})})})), prism_rtl::deref(o_pf).conds);
                });
                auto binds_pa = fold(subs_p8, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_pg, const std::tuple<Nat, PatOut>& _p1) {
                    auto&& o_ph = std::get<1>(_p1);
                    return append(acc_pg, prism_rtl::deref(o_ph).binds);
                });
                (prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_p4_1}), .conds = conds_p9, .binds = binds_pa}));
            });
        });
        });
    });
}


/// `Start ArrayPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_array_pat(crate::lower::Lx lx_p0, Array<crate::syntax::Pattern_> ps_p1, crate::check::types::Ty ty_p2, crate::lower::types::Holding mode_p3, Text fresh_p4) {
    return prism_rtl::make_rc<ArrayPat>(lx_p0, ps_p1, ty_p2, mode_p3, fresh_p4);
}

}  // namespace crate::lower::patterns
