// The module `Lower.Node.Static`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/node_/static_/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Lower.Node.Static`, from `target/bootstrap/cpp-src/prismc/lower/node/static.prism`.
namespace crate::lower::node_::static_ {

void HostForm::show(Printer& p) const {
    if (auto c = std::get_if<HostEach>(&cases())) p.choice("HostEach", {});
    else if (auto c = std::get_if<HostSome>(&cases())) p.choice("HostSome", {});
}

Pod HostForm::to_pod() const {
    return std::holds_alternative<HostEach>(cases()) ? Pod::choice("HostEach", {})
        : std::holds_alternative<HostSome>(cases()) ? Pod::choice("HostSome", {})
        : Pod();
}

Result<HostForm> HostForm::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "HostEach" && c->args.size() == 0) return HostForm(HostEach{});
        if (c->ctor == "HostSome" && c->args.size() == 0) return HostForm(HostSome{});
    }
    return mismatch<HostForm>("a HostForm", p);
}


/// WidgetLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> widget_line_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Expr& e_p3, const std::optional<crate::lower::types::Bn>& bound_o4) {
    auto lx_p5 = wx_p0.lx_p;
    auto [callee_pb, args_pc] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::syntax::Expr, Array<crate::syntax::Arg>>> _v;
        auto&& _m = prism_rtl::deref(e_p3.kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c_p9 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& xs_pa = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{prism_rtl::deref(prism_rtl::deref(c_p9)), xs_pa});
            goto _done;
        }
        {
            _v.set(std::tuple{e_p3, Array<crate::syntax::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto qk_p6 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(callee_pb).kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_pd = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _q_oe = crate::check::env::names::resolve_value_f(prism_rtl::deref(lx_p5).g_p, prism_rtl::deref(lx_p5).home_p, n_pd);
                auto&& q_oe = std::get<0>(_q_oe);
                (crate::prelude::or_(q_oe, Text::lit("")));
            }));
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto target_o7 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Nat>> _v;
        if (prism_rtl::is_some(bound_o4) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o4))) {
            auto&& er_pf = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o4)).a0;
            _v.set(std::optional(prism_rtl::deref(er_pf).node_p));
            goto _done;
        }
        {
            _v.set(std::optional<Nat>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto param_o8 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::lower::types::Bn>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(callee_pb).kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_pg = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(crate::prelude::len(prism_rtl::deref(n_pg).path_p) == Nat(1u)
                ? crate::prelude::get(menv_p2.names_p, crate::check::env::sname_key_f(n_pg))
                : std::optional<crate::lower::types::Bn>{});
            goto _done;
        }
        {
            _v.set(std::optional<crate::lower::types::Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    if (prism_rtl::is_some(param_o8) && prism_rtl::is<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_o8))) {
        auto&& x_ph = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_o8)).a0;
        auto&& cbenv_pi = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_o8)).a1;
        auto&& cmenv_pj = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_o8)).a2;
        auto&& clx_pk = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_o8)).a3;
        return apply_widget_param_f(wx_p0, x_ph, cbenv_pi, cmenv_pj, clx_pk, crate::prelude::len(args_pc));
    }
    {
        return widget_call_f(wx_p0, benv_p1, menv_p2, e_p3, bound_o4, qk_p6, args_pc, target_o7);
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> WidgetLine::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& benv_p1 = this->benv_p1;
    const auto& menv_p2 = this->menv_p2;
    const auto& e_p3 = this->e_p3;
    const auto& bound_o4 = this->bound_o4;
    auto lx_p5 = prism_rtl::deref(wx_p0).lx_p;
    auto [callee_pb, args_pc] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::syntax::Expr, Array<crate::syntax::Arg>>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p3).kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c_p9 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& xs_pa = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{prism_rtl::deref(prism_rtl::deref(c_p9)), xs_pa});
            goto _done;
        }
        {
            _v.set(std::tuple{e_p3, Array<crate::syntax::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto qk_p6 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(callee_pb).kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_pd = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _q_oe = crate::check::env::names::resolve_value_f(prism_rtl::deref(lx_p5).g_p, prism_rtl::deref(lx_p5).home_p, n_pd);
                auto&& q_oe = std::get<0>(_q_oe);
                (crate::prelude::or_(q_oe, Text::lit("")));
            }));
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto target_o7 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Nat>> _v;
        if (prism_rtl::is_some(bound_o4) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o4))) {
            auto&& er_pf = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o4)).a0;
            _v.set(std::optional(prism_rtl::deref(er_pf).node_p));
            goto _done;
        }
        {
            _v.set(std::optional<Nat>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto param_o8 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::lower::types::Bn>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(callee_pb).kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_pg = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(crate::prelude::len(prism_rtl::deref(n_pg).path_p) == Nat(1u)
                ? crate::prelude::get(prism_rtl::deref(menv_p2).names_p, crate::check::env::sname_key_f(n_pg))
                : std::optional<crate::lower::types::Bn>{});
            goto _done;
        }
        {
            _v.set(std::optional<crate::lower::types::Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return ({
        prism_rtl::is_some(param_o8) && prism_rtl::is<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_o8)) ? ({
        auto&& x_ph = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_o8)).a0;
        auto&& cbenv_pi = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_o8)).a1;
        auto&& cmenv_pj = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_o8)).a2;
        auto&& clx_pk = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_o8)).a3;
        prism_rtl::finished(apply_widget_param_f(wx_p0, x_ph, cbenv_pi, cmenv_pj, clx_pk, crate::prelude::len(args_pc)));
    })
        : prism_rtl::finished(widget_call_f(wx_p0, benv_p1, menv_p2, e_p3, bound_o4, qk_p6, args_pc, target_o7));
    });
}


/// `Start WidgetLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_widget_line_f(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Expr e_p3, std::optional<crate::lower::types::Bn> bound_o4) {
    return prism_rtl::make_rc<WidgetLine>(wx_p0, benv_p1, menv_p2, e_p3, bound_o4);
}


/// ApplyWidgetParam: unbounded fn Wx, Expr, Env, Env, Lx, Nat -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> apply_widget_param_f(const crate::lower::node_::Wx& wx_p0, const crate::syntax::Expr& x_p1, const crate::lower::types::Env& cbenv_p2, const crate::lower::types::Env& cmenv_p3, const crate::lower::Lx& clx_p4, const Nat& nargs_p5) {
    return nargs_p5 > Nat(0u)
        ? ({
        auto wx2_p6 = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.build_p = crate::prelude::push(this_.build_p, crate::lower::expr::refusal_do_f(Text::lit("a widget parameter applied to arguments")));
            (std::move(this_));
        });
        std::tuple{wx2_p6, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    })
        : ({
        auto lx_p7 = wx_p0.lx_p;
        auto inner_p8 = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.lx_p = clx_p4;
            (std::move(this_));
        });
        auto [done_pa, res_pb] = crate::lower::node_::def::build_line_f(inner_p8, cbenv_p2, cmenv_p3, x_p1, std::optional<crate::lower::types::Bn>{});
        auto back_p9 = ({
            crate::lower::node_::Wx this_ = done_pa;
            this_.lx_p = lx_p7;
            (std::move(this_));
        });
        std::tuple{back_p9, res_pb};
    });
}


/// InlineBlock: unbounded fn Wx, Env, Env, Block, Lx -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> inline_block_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Block& b_p3, const crate::lower::Lx& lx_p4) {
    auto inner_p5 = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.result_p = crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{});
        (std::move(this_));
    });
    auto done_p6 = crate::lower::node_::def::block_into_f(inner_p5, benv_p1, menv_p2, b_p3);
    auto back_p7 = ({
        crate::lower::node_::Wx this_ = done_p6;
        this_.result_p = wx_p0.result_p;
        (std::move(this_));
    });
    return std::tuple{back_p7, prism_rtl::deref(done_p6).result_p};
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> InlineBlock::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& benv_p1 = this->benv_p1;
    const auto& menv_p2 = this->menv_p2;
    const auto& b_p3 = this->b_p3;
    const auto& lx_p4 = this->lx_p4;
    auto inner_p5 = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.result_p = crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{});
        (std::move(this_));
    });
    auto b_p3x = b_p3;
    auto benv_p1x = benv_p1;
    auto menv_p2x = menv_p2;
    auto wx_p0x = wx_p0;
    return crate::prelude::call_then(crate::lower::node_::def::start_block_into_f(inner_p5, benv_p1x, menv_p2x, b_p3x), [=](crate::lower::node_::Wx block_into_f_3395) {
        return ({
            auto done_p6 = block_into_f_3395;
            auto back_p7 = ({
                crate::lower::node_::Wx this_ = done_p6;
                this_.result_p = prism_rtl::deref(wx_p0x).result_p;
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{back_p7, prism_rtl::deref(done_p6).result_p}));
        });
    });
}


/// `Start InlineBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_inline_block_f(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Block b_p3, crate::lower::Lx lx_p4) {
    return prism_rtl::make_rc<InlineBlock>(wx_p0, benv_p1, menv_p2, b_p3, lx_p4);
}


/// WidgetCall: unbounded fn Wx, Env, Env, Expr, ?Bn, Text, [Arg], ?Nat -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> widget_call_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Expr& e_p3, const std::optional<crate::lower::types::Bn>& bound_o4, const Text& qk_p5, const Array<crate::syntax::Arg>& args_p6, const std::optional<Nat>& target_o7) {
    auto lx_p8 = wx_p0.lx_p;
    {
        auto&& m3679_0 = qk_p5;
        if (m3679_0 == Text::lit("Prelude.@started")) {
            return started_line_f(wx_p0, bound_o4);
        }
    }
    {
        auto&& m3679_1 = qk_p5;
        if (m3679_1 == Text::lit("Prelude.@Switch")) {
            return crate::lower::node_::switch_::switch_line_f(wx_p0, menv_p2, args_p6);
        }
    }
    {
        auto&& m3679_2 = qk_p5;
        if (m3679_2 == Text::lit("Prelude.@Flatten")) {
            return crate::lower::node_::switch_::flatten_line_f(wx_p0, menv_p2, args_p6, bound_o4);
        }
    }
    {
        auto&& m3679_3 = qk_p5;
        if (m3679_3 == Text::lit("Prelude.@Defer")) {
            return defer_line_f(wx_p0, menv_p2, args_p6, e_p3, target_o7);
        }
    }
    {
        auto&& m3679_4 = qk_p5;
        if (m3679_4 == Text::lit("Prelude.@Distinct")) {
            return distinct_line_f(wx_p0, menv_p2, args_p6, e_p3, bound_o4);
        }
    }
    {
        auto&& m3679_5 = qk_p5;
        if (m3679_5 == Text::lit("Prelude.@PerKey")) {
            return per_key_line_f(wx_p0, menv_p2, args_p6, bound_o4);
        }
    }
    {
        auto&& m3679_6 = qk_p5;
        if (m3679_6 == Text::lit("Prelude.@Run")) {
            return run_line_f(wx_p0, benv_p1, args_p6, e_p3, target_o7);
        }
    }
    {
        auto&& m3679_7 = qk_p5;
        if (m3679_7 == Text::lit("Prelude.@Machine")) {
            return machine_line_f(wx_p0, benv_p1, menv_p2, args_p6, e_p3, target_o7);
        }
    }
    {
        auto&& m3679_8 = qk_p5;
        if (m3679_8 == Text::lit("Prelude.@HostDocument")) {
            return host_line_f(wx_p0, benv_p1, menv_p2, HostForm(HostForm::HostEach{}), args_p6, bound_o4);
        }
    }
    {
        auto&& m3679_9 = qk_p5;
        if (m3679_9 == Text::lit("Prelude.@HostSome")) {
            return host_line_f(wx_p0, benv_p1, menv_p2, HostForm(HostForm::HostSome{}), args_p6, bound_o4);
        }
    }
    {
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p8).g_p).vals_p, qk_p5);
        if (prism_rtl::is_some(_m)) {
            auto&& v_p9 = prism_rtl::some_of(_m);
            return inline_widget_f(wx_p0, benv_p1, menv_p2, qk_p5, v_p9, args_p6, e_p3);
        }
        if (prism_rtl::is_none(_m)) {
            auto wx2_pa = ({
                crate::lower::node_::Wx this_ = wx_p0;
                this_.build_p = crate::prelude::push(this_.build_p, crate::lower::expr::refusal_do_f(Text::lit("a widget this back end does not lower yet")));
                (std::move(this_));
            });
            return std::tuple{wx2_pa, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
        }
        prism_rtl::unreachable("no arm matched");
    }
}


/// HostLine: unbounded fn Wx, Env, Env, HostForm, [Arg], ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> host_line_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const HostForm& form_p3, const Array<crate::syntax::Arg>& args_p4, const std::optional<crate::lower::types::Bn>& bound_o5) {
    auto lx_p6 = wx_p0.lx_p;
    auto pos_p7 = wx_p0.pos_p;
    auto k_p8 = crate::prelude::len(wx_p0.scopes_p) + Nat(1u);
    auto hf_p9 = prism_rtl::cat("host_", k_p8);
    auto rows_name_pa = prism_rtl::cat(hf_p9, "_rows");
    auto doc_getter_pb = prism_rtl::cat(hf_p9, "_doc");
    auto wx1_pc = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.taken_p = crate::prelude::append(this_.taken_p, Array(std::vector{hf_p9, rows_name_pa, doc_getter_pb, prism_rtl::cat(doc_getter_pb, "_now"), prism_rtl::cat(doc_getter_pb, "_snap"), prism_rtl::cat(doc_getter_pb, "_direct"), prism_rtl::cat(doc_getter_pb, "_publish"), prism_rtl::cat(hf_p9, "_answer"), prism_rtl::cat(hf_p9, "_moved")}));
        (std::move(this_));
    });
    auto named_pd = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::prelude::index(args_p4, Nat(1u));
        if (prism_rtl::is_some(_m)) {
            auto&& sup_pe = prism_rtl::some_of(_m);
            _v.set(is_widget_name_f(prism_rtl::deref(sup_pe).value_p));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _m = std::tuple{crate::prelude::index(args_p4, Nat(0u)), crate::prelude::index(args_p4, Nat(1u))};
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        if (std::move(named_pd)) {
            auto wx2_pf = ({
                crate::lower::node_::Wx this_ = wx1_pc;
                this_.pos_p = crate::lower::model::next_pos_f(this_.pos_p);
                this_.build_p = crate::prelude::push(this_.build_p, crate::lower::expr::refusal_do_f(Text::lit("a named widget function as a host\'s supplier (gap NS): a lambda supplier is lowered, a widget function is not a value")));
                (std::move(this_));
            });
            return std::tuple{wx2_pf, crate::lower::node_::Wres(crate::lower::node_::Wres::WrHosted{prism_rtl::rc(crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})})})};
        }
    }
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        auto&& child_pg = prism_rtl::some_of(std::get<0>(_m));
        auto&& sup_ph = prism_rtl::some_of(std::get<1>(_m));
        auto [wxd_p13, dyn_env_p14, dyn_lets_p15] = dynamic_answers_f(wx1_pc, benv_p1, menv_p2, hf_p9, prism_rtl::deref(sup_ph).value_p);
        auto offered_pi = crate::lower::types::own_f(crate::lower::expr::value_of_f(lx_p6, dyn_env_p14, prism_rtl::deref(sup_ph).value_p));
        auto supplier0_pj = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::Ex> _v;
            if (prism_rtl::is<HostForm::HostEach>(form_p3)) {
                _v.set(offered_pi);
                goto _done;
            }
            if (prism_rtl::is<HostForm::HostSome>(form_p3)) {
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::forward_on_none"), Array(std::vector{offered_pi})}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto supplier_pk = crate::prelude::len(dyn_lets_p15) == Nat(0u)
            ? supplier0_pj
            : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dyn_lets_p15, prism_rtl::rc(supplier0_pj)});
        auto enclosing_pl = crate::lower::node_::finish::emits_f(wx_p0, pos_p7)
            ? crate::lower::model::Ex(crate::lower::model::Ex::XNone{})
            : crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::node_::elements::host_local_f(wx_p0, pos_p7)}))})), crate::lower::types::host_of_ty_p()})})});
        auto made_pm = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Host::new"), Array(std::vector{crate::lower::node_::finish::place_at_f(wx_p0, Text::lit(""), pos_p7), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{rows_name_pa}))}), supplier_pk, enclosing_pl, crate::lower::model::Ex(crate::lower::model::Ex::XPath{prism_rtl::cat(wx_p0.node_p, "::", hf_p9, "_answer")})})});
        auto host_ty_pn = crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Host"), Array(std::vector{crate::lower::types::elem_ty_p(), crate::lower::types::answer_ty_p(), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{wx_p0.node_p, Array<crate::lower::model::OutTy>{}})})}))});
        auto rows_ty_po = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Rows"), Array(std::vector{crate::lower::types::elem_ty_p(), crate::lower::types::answer_ty_p()})});
        auto doc_ty_pp = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{})), prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(crate::lower::types::elem_ty_p())}))});
        auto direct_ty_pq = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{})), prism_rtl::rc(crate::lower::types::entry_ty_p())});
        auto what_pr = prism_rtl::cat("the document of the child hosted at place ", crate::lower::model::place_text_f(pos_p7));
        auto wx2_ps = ({
            crate::lower::node_::Wx this_ = wxd_p13;
            this_.pos_p = crate::lower::model::next_pos_f(this_.pos_p);
            this_.lets_p = crate::prelude::append(this_.lets_p, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rows_name_pa})), rows_ty_po}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Map::new"), Array<crate::lower::model::Ex>{}})})})})})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{hf_p9}), made_pm})}));
            this_.fields_p = crate::prelude::append(this_.fields_p, Array(std::vector{std::tuple{hf_p9, host_ty_pn, prism_rtl::cat("the host at place ", crate::lower::model::place_text_f(pos_p7), ": its supplier, its rows, and the way back into its child (pick HO)")}, std::tuple{rows_name_pa, rows_ty_po, prism_rtl::cat("the rows of the host at place ", crate::lower::model::place_text_f(pos_p7), ": `for p, e <- $doc`, one supplier blueprint per child place")}, std::tuple{prism_rtl::cat(rows_name_pa, "_from"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(direct_ty_pq)}), prism_rtl::cat("the places the rows of the host at place ", crate::lower::model::place_text_f(pos_p7), " were last built from")}, std::tuple{prism_rtl::cat(doc_getter_pb, "_snap"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutSnapshot{prism_rtl::rc(crate::lower::types::host_doc_ty_p())}), prism_rtl::cat("`$doc` of the host at place ", crate::lower::model::place_text_f(pos_p7), ", its outer, a structural dynamic: its snapshots, the places and the lagged dynamic (pick ST)")}}));
            this_.moves_p = crate::prelude::append(this_.moves_p, Array(std::vector{std::tuple{hf_p9, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{hf_p9}))})}, std::tuple{rows_name_pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{rows_name_pa}))})}}));
            this_.inits_p = crate::prelude::append(this_.inits_p, Array(std::vector{std::tuple{prism_rtl::cat(doc_getter_pb, "_snap"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Snapshot::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{what_pr})})})}, std::tuple{prism_rtl::cat(rows_name_pa, "_from"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Map::new"), Array<crate::lower::model::Ex>{}})})})}}));
            this_.hosts_p = crate::prelude::push(this_.hosts_p, crate::lower::node_::HostDef{.pos_p = pos_p7, .name_p = hf_p9, .scope_p = k_p8});
            this_.snaps_p = crate::prelude::push(this_.snaps_p, crate::lower::node_::SnapDef{.name_p = doc_getter_pb, .live_p = prism_rtl::cat(doc_getter_pb, "_now"), .ty_p = crate::lower::types::host_doc_ty_p(), .eq_p = true, .builder_p = rows_name_pa, .before_p = true, .what_p = what_pr});
            this_.getters_p = crate::prelude::append(this_.getters_p, Array(std::vector{crate::lower::model::MethDef{.name_p = doc_getter_pb, .recv_p = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_p = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret_p = doc_ty_pp, .body_p = Array<crate::lower::model::Do>{}, .tail_p = crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(doc_getter_pb, "_snap")})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("doc")}), .doc_p = prism_rtl::cat("The document of the child hosted at place ", crate::lower::model::place_text_f(pos_p7), ", `$doc`, its outer a structural dynamic (pick ST): one tick behind the child\'s places, the snapshot of the tick before the tick the read point is after; each entry the place\'s own dynamic.")}, crate::lower::model::MethDef{.name_p = prism_rtl::cat(doc_getter_pb, "_direct"), .recv_p = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_p = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret_p = direct_ty_pq, .body_p = Array<crate::lower::model::Do>{}, .tail_p = crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(doc_getter_pb, "_snap")})), Text::lit("current"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("places")}), .doc_p = prism_rtl::cat("The places of the child hosted at place ", crate::lower::model::place_text_f(pos_p7), ", not the lagged `$doc`: the snapshot taken in this tick\'s construction step, the places as the tick opened during propagation. The host\'s own `for` reads it, so a newborn child place gets its row in the tick it is born (pick ST).")}}));
            this_.scopes_p = crate::prelude::push(this_.scopes_p, hf_p9);
            this_.builders_p = crate::prelude::push(this_.builders_p, crate::lower::model::ForDef{.name_p = rows_name_pa, .pos_p = pos_p7, .at_p = crate::lower::node_::finish::place_at_f(wx_p0, Text::lit("self"), pos_p7), .key_ty_p = crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{}), .value_ty_p = crate::lower::types::entry_ty_p(), .row_node_p = Text::lit("prism_rtl::HostRow::<crate::Elem, crate::Answer>"), .keyed_p = true, .source_p = prism_rtl::cat(doc_getter_pb, "_direct"), .parent_p = crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), hf_p9}))}), .passed_p = Array<crate::lower::model::Ex>{}, .moved_p = crate::prelude::or_(crate::lower::node_::finish::hosted_rows_o(wx_p0), Text::lit("")), .replaced_p = Array<Text>{}});
            this_.build_holds_p = crate::lower::node_::add_read_f(this_.build_holds_p, crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{prism_rtl::cat(doc_getter_pb, "_now")}));
            this_.fallible_p = true;
            (std::move(this_));
        });
        auto inner_pt = ({
            crate::lower::node_::Wx this_ = wx2_ps;
            this_.pos_p = crate::lower::model::scope_pos_f(k_p8);
            this_.result_p = crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{});
            (std::move(this_));
        });
        auto [done_p16, res_p17] = crate::lower::node_::def::build_line_f(inner_pt, benv_p1, menv_p2, prism_rtl::deref(child_pg).value_p, std::optional<crate::lower::types::Bn>{});
        auto child_places_pu = crate::prelude::drop(prism_rtl::deref(done_p16).places_p, crate::prelude::len(prism_rtl::deref(wx2_ps).places_p));
        auto in_scope_fv = ({
            auto k_p8x = k_p8;
            static_cast<Fn<bool(const crate::lower::model::Pos_&)>>(prism_rtl::rc([=, k_p8x = std::move(k_p8x)](const crate::lower::model::Pos_& p_p18) { return prism_rtl::deref(p_p18).scope_p == k_p8x; }));
        });
        auto getter_p10 = host_doc_getter_f(prism_rtl::cat(doc_getter_pb, "_now"), pos_p7, crate::prelude::filter(child_places_pu, [&](const crate::lower::node_::Place& pl_p19) { return in_scope_fv(prism_rtl::deref(pl_p19).pos_p); }), crate::prelude::filter(crate::prelude::drop(prism_rtl::deref(done_p16).builders_p, crate::prelude::len(prism_rtl::deref(wx2_ps).builders_p)), [&](const crate::lower::model::ForDef& b_p1a) { return in_scope_fv(prism_rtl::deref(b_p1a).pos_p); }), crate::prelude::filter(crate::prelude::drop(prism_rtl::deref(done_p16).gens_p, crate::prelude::len(prism_rtl::deref(wx2_ps).gens_p)), [&](const crate::lower::model::GenDef& gd_p1b) { return in_scope_fv(prism_rtl::deref(gd_p1b).pos_p); }));
        auto back_p11 = ({
            crate::lower::node_::Wx this_ = done_p16;
            this_.pos_p = prism_rtl::deref(wx2_ps).pos_p;
            this_.result_p = wx_p0.result_p;
            this_.getters_p = crate::prelude::push(this_.getters_p, getter_p10);
            this_.dyn_reads_p = crate::prelude::insert(this_.dyn_reads_p, prism_rtl::cat(doc_getter_pb, "_now"), Array<crate::lower::node_::Read>{});
            (std::move(this_));
        });
        auto doc_bn_p12 = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), doc_getter_pb, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{doc_getter_pb})}), doc_ty_pp});
        return std::tuple{back_p11, crate::lower::node_::Wres(crate::lower::node_::Wres::WrHosted{prism_rtl::rc(res_p17), doc_bn_p12})};
    }
    {
        auto wx2_p1c = ({
            crate::lower::node_::Wx this_ = wx1_pc;
            this_.pos_p = crate::lower::model::next_pos_f(this_.pos_p);
            this_.build_p = crate::prelude::push(this_.build_p, crate::lower::expr::refusal_do_f(Text::lit("a host without its child or its supplier")));
            (std::move(this_));
        });
        return std::tuple{wx2_p1c, crate::lower::node_::Wres(crate::lower::node_::Wres::WrHosted{prism_rtl::rc(crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})})})};
    }
}


/// IsWidgetName: fn Expr -> Bool
bool is_widget_name_f(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix_f(crate::check::env::sname_key_f(n_p1), Text::lit("@"));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p2 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_widget_name_f(prism_rtl::deref(prism_rtl::deref(x_p2)));
    }
    {
        return false;
    }
}


/// DynamicAnswers: unbounded fn Wx, Env, Env, Text, Expr -> ((Wx, Env, [Do]))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>> dynamic_answers_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const Text& hf_p3, const crate::syntax::Expr& sup_p4) {
    auto lx_p5 = wx_p0.lx_p;
    auto dyns_p6 = crate::prelude::fold(crate::check::typed::print::exprs_in_f(sup_p4), Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>{}, [&](const Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>& acc_p7, const crate::syntax::Expr& x_p8) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p8).kind_p);
            if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
                auto&& m14204_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
                auto&& y_p9 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
                if (m14204_0_0 == Text::lit("@")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>> _v;
                        auto&& _m = dynamic_answer_o(lx_p5, prism_rtl::deref(prism_rtl::deref(y_p9)));
                        if (prism_rtl::is_some(_m)) {
                            auto&& d_pa = prism_rtl::some_of(_m);
                            _v.set(crate::prelude::push(acc_p7, std::tuple{prism_rtl::deref(prism_rtl::deref(y_p9)), d_pa}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(acc_p7);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                _v.set(acc_p7);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return crate::prelude::len(dyns_p6) == Nat(0u)
        ? std::tuple{wx_p0, benv_p1, Array<crate::lower::model::Do>{}}
        : ({
        auto owner_pb = prism_rtl::cat(hf_p3, "_owner");
        auto wx1_pc = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.taken_p = crate::prelude::push(this_.taken_p, owner_pb);
            this_.lets_p = crate::prelude::push(this_.lets_p, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{owner_pb}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat("prism_rtl::Link::<", wx_p0.node_p, ">::new"), Array<crate::lower::model::Ex>{}})}));
            this_.build_p = crate::prelude::push(this_.build_p, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{owner_pb})), Text::lit("link"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})})})}));
            (std::move(this_));
        });
        auto env0_pd = crate::lower::types::bind_f(benv_p1, Text::lit("#owner"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(owner_pb, "x")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
        auto lets0_pe = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(owner_pb, "x")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{owner_pb}))})})});
        (crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(dyns_p6)), std::tuple{wx1_pc, env0_pd, lets0_pe}, ({
        auto dyns_p6x = dyns_p6;
        auto hf_p3x = hf_p3;
        auto menv_p2x = menv_p2;
        auto lx_p5x = lx_p5;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>>, Nat>)>>(prism_rtl::rc([=, dyns_p6x = std::move(dyns_p6x), hf_p3x = std::move(hf_p3x), menv_p2x = std::move(menv_p2x), lx_p5x = std::move(lx_p5x)](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto dyns_p6xy = dyns_p6x;
            auto hf_p3xy = hf_p3x;
            auto menv_p2xy = menv_p2x;
            auto lx_p5xy = lx_p5x;
            (crate::prelude::entered(crate::prelude::once_job([=, dyns_p6xy = std::move(dyns_p6xy), hf_p3xy = std::move(hf_p3xy), menv_p2xy = std::move(menv_p2xy), lx_p5xy = std::move(lx_p5xy)]() {
            return ({
                auto [w_pf, en_pg, ls_ph] = p0;
                auto j_pi = p1;
                ({
                auto&& _m = crate::prelude::index(dyns_p6xy, j_pi);
                prism_rtl::is_some(_m) ? ({
                auto&& y_pj = std::get<0>(prism_rtl::some_of(_m));
                auto&& d_pk = std::get<1>(prism_rtl::some_of(_m));
                ({
                auto name_pl = prism_rtl::cat(hf_p3xy, "_dyn_", j_pi + Nat(1u));
                auto port_pm = prism_rtl::cat(name_pl, "_port");
                (crate::prelude::call_then(crate::lower::node_::dynamics::start_dynamic_expr_f(w_pf, menv_p2xy, d_pk), [=, name_pl = std::move(name_pl), port_pm = std::move(port_pm)](std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>> dynamic_expr_f_15204) {
                return ({
                    auto [ex_po, reads_pp] = dynamic_expr_f_15204;
                    (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p5xy, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p5xy, prism_rtl::deref(d_pk).span_p))), [=](crate::lower::model::OutTy out_ty_of_f_15251) {
                    return ({
                        auto t_pn = out_ty_of_f_15251;
                        (!crate::lower::node_::def::all_inited_f(w_pf, reads_pp)
                        ? prism_rtl::finished(std::tuple{w_pf, en_pg, ls_ph})
                        : ({
                        auto w2_pq = ({
                            crate::lower::node_::Wx this_ = w_pf;
                            this_.taken_p = crate::prelude::append(this_.taken_p, Array(std::vector{name_pl, port_pm}));
                            this_.getters_p = crate::prelude::push(this_.getters_p, crate::lower::model::MethDef{.name_p = name_pl, .recv_p = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_p = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret_p = t_pn, .body_p = Array<crate::lower::model::Do>{}, .tail_p = ex_po, .doc_p = prism_rtl::cat("The host at `", hf_p3xy, "`\'s dynamic answer `", crate::lower::functions::src_text_f(lx_p5xy, prism_rtl::deref(lx_p5xy).file_p, prism_rtl::deref(y_pj).span_p), "`, read at the read point (round 3 DY).")});
                            this_.lets_p = crate::prelude::push(this_.lets_p, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{port_pm})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPort{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))}))})}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Port::new"), Array<crate::lower::model::Ex>{}})})})}));
                            this_.fields_p = crate::prelude::push(this_.fields_p, std::tuple{port_pm, crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPort{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))}))}), prism_rtl::cat("the dynamic answer `", name_pl, "` moved: its blueprints push the child\'s place next tick")});
                            this_.moves_p = crate::prelude::push(this_.moves_p, std::tuple{port_pm, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{port_pm}))})});
                            this_.dyn_answers_p = crate::prelude::push(this_.dyn_answers_p, std::tuple{name_pl, reads_pp});
                            (std::move(this_));
                        });
                        (prism_rtl::finished(std::tuple{w2_pq, crate::lower::types::bind_f(en_pg, prism_rtl::cat("#dyn", dyn_key_f(y_pj)), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{name_pl}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_pn})), crate::prelude::push(ls_ph, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(port_pm, "x")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{port_pm}))})}))}));
                    }));
                    });
                }));
                });
            }));
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{w_pf, en_pg, ls_ph})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    }))));
    });
}


/// ?DynamicAnswer: fn Lx, Expr -> ?Expr
std::optional<crate::syntax::Expr> dynamic_answer_o(const crate::lower::Lx& lx_p0, const crate::syntax::Expr& x_p1) {
    return crate::lower::types::layer_of_f(crate::lower::type_at_f(lx_p0, x_p1.span_p)) != crate::lower::types::Layer(crate::lower::types::Layer::LyDyn{})
        ? std::optional<crate::syntax::Expr>{}
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
        auto&& _m = prism_rtl::deref(x_p1.kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
            auto&& m16686_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& inner_p2 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            if (m16686_0_0 == Text::lit("$")) {
                _v.set(crate::lower::types::layer_of_f(crate::lower::type_at_f(lx_p0, prism_rtl::deref(inner_p2).span_p)) == crate::lower::types::Layer(crate::lower::types::Layer::LyDyn{})
                    ? std::optional(prism_rtl::deref(prism_rtl::deref(inner_p2)))
                    : std::optional<crate::syntax::Expr>{});
                goto _done;
            }
        }
        {
            _v.set(std::optional(x_p1));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// DynKey: fn Expr -> Text
Text dyn_key_f(const crate::syntax::Expr& x_p0) {
    return prism_rtl::cat(prism_rtl::deref(x_p0.span_p).start_p, ":", prism_rtl::deref(x_p0.span_p).end_p);
}


/// HostDocGetter: fn Text, Pos, [Place], [ForDef], [GenDef] -> MethDef
crate::lower::model::MethDef host_doc_getter_f(const Text& name_p0, const crate::lower::model::Pos_& pos_p1, const Array<crate::lower::node_::Place>& places_p2, const Array<crate::lower::model::ForDef>& builders_p3, const Array<crate::lower::model::GenDef>& gens_p4) {
    auto start_p5 = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("doc")})), crate::lower::types::host_doc_ty_p()}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::HostDoc::new"), Array<crate::lower::model::Ex>{}})});
    auto body_p6 = crate::lower::node_::finish::document_body_f(({
        auto f = prism_rtl::rc(crate::lower::node_::finish::map_insert_f);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(std::tuple<crate::lower::model::Ex, crate::lower::model::Ex>)>>(prism_rtl::rc([=, f = std::move(f)](std::tuple<crate::lower::model::Ex, crate::lower::model::Ex> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        return ({
            auto fy = f;
            (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0, a1)); }));
        });
    })));
    }), places_p2, builders_p3, gens_p4);
    return crate::lower::model::MethDef{.name_p = name_p0, .recv_p = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_p = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret_p = crate::lower::types::host_doc_ty_p(), .body_p = crate::prelude::append(Array(std::vector{start_p5}), body_p6), .tail_p = crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("doc")}), .doc_p = prism_rtl::cat("The places of the child hosted at place ", crate::lower::model::place_text_f(pos_p1), ": each place\'s entry by its path relative to the child (pick HO). Read only by the snapshot of `$doc`\'s outer (pick ST).")};
}


/// SnapGetter: fn Text, OutTy, Text -> MethDef
crate::lower::model::MethDef snap_getter_f(const Text& name_p0, const crate::lower::model::OutTy& t_p1, const Text& doc_p2) {
    return crate::lower::model::MethDef{.name_p = name_p0, .recv_p = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_p = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret_p = t_p1, .body_p = Array<crate::lower::model::Do>{}, .tail_p = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(name_p0, "_snap")})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), .doc_p = doc_p2};
}


/// StartedLine: fn Wx, ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> started_line_f(const crate::lower::node_::Wx& wx_p0, const std::optional<crate::lower::types::Bn>& bound_o1) {
    auto wx1_p2 = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.pos_p = crate::lower::model::next_pos_f(this_.pos_p);
        (std::move(this_));
    });
    auto [id_p7, wx2_p8] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
        if (prism_rtl::is_some(bound_o1) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o1))) {
            auto&& er_p4 = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o1)).a0;
            _v.set(std::tuple{prism_rtl::deref(er_p4).node_p, wx1_p2});
            goto _done;
        }
        {
            _v.set(({
                auto [nm_p5, w_p6] = crate::lower::node_::fresh_name_f(wx1_p2, Text::lit("started"));
                (crate::lower::node_::add_gn_f(w_p6, nm_p5, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnStarted{}), Nat(0u)));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto wx3_p3 = ({
        crate::lower::node_::Wx this_ = wx2_p8;
        this_.started_p = crate::prelude::push(this_.started_p, id_p7);
        (std::move(this_));
    });
    return std::tuple{wx3_p3, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of_f(wx3_p3, id_p7)})};
}


/// DeferLine: unbounded fn Wx, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> defer_line_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2, const crate::syntax::Expr& e_p3, const std::optional<Nat>& target_o4) {
    auto lx_p5 = wx_p0.lx_p;
    auto t_p6 = crate::lower::types::out_ty_of_f(lx_p5, crate::lower::types::out_of_f(crate::lower::type_at_f(lx_p5, e_p3.span_p)));
    auto [field_p9, wx1_pa] = crate::lower::node_::fresh_name_f(wx_p0, Text::lit("deferred"));
    auto [id_pc, wx2_pd] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
        if (prism_rtl::is_some(target_o4)) {
            auto&& n_pb = prism_rtl::some_of(target_o4);
            _v.set(std::tuple{n_pb, wx1_pa});
            goto _done;
        }
        if (prism_rtl::is_none(target_o4)) {
            _v.set(crate::lower::node_::add_gn_f(wx1_pa, prism_rtl::cat(field_p9, "_fired"), t_p6, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnDeferred{}), Nat(0u)));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto wx3_p7 = crate::lower::node_::add_field_last_f(wx2_pd, field_p9, crate::lower::model::OutTy(crate::lower::model::OutTy::OutDefer{prism_rtl::rc(t_p6)}), Text::lit("`@Defer`"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Defer::new"), Array<crate::lower::model::Ex>{}}));
    auto wx4_p8 = ({
        crate::lower::node_::Wx this_ = wx3_p7;
        this_.defers_p = crate::prelude::push(this_.defers_p, std::tuple{field_p9, id_pc});
        (std::move(this_));
    });
    auto&& _m = crate::prelude::index(args_p2, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& a_pe = prism_rtl::some_of(_m);
        auto [r_pf, wx5_pg] = crate::lower::node_::dynamics::event_ref_f(wx4_p8, menv_p1, prism_rtl::deref(a_pe).value_p);
        return std::tuple{crate::lower::node_::connect_f(wx5_pg, r_pf, crate::lower::node_::Sk(crate::lower::node_::Sk::SkArm{field_p9})), crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of_f(wx5_pg, id_pc)})};
    }
    if (prism_rtl::is_none(_m)) {
        return std::tuple{wx4_p8, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of_f(wx4_p8, id_pc)})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// DistinctLine: unbounded fn Wx, Env, [Arg], Expr, ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> distinct_line_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2, const crate::syntax::Expr& e_p3, const std::optional<crate::lower::types::Bn>& bound_o4) {
    auto lx_p5 = wx_p0.lx_p;
    auto&& _m = crate::prelude::index(args_p2, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        auto wx2_p6 = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.build_p = crate::prelude::push(this_.build_p, crate::lower::expr::refusal_do_f(Text::lit("an `@Distinct` without its dynamic")));
            (std::move(this_));
        });
        return std::tuple{wx2_p6, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& a_p7 = prism_rtl::some_of(_m);
        auto t_p8 = crate::lower::types::out_ty_of_f(lx_p5, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p5, prism_rtl::deref(prism_rtl::deref(a_p7).value_p).span_p)));
        auto [name_pg, wx1_ph] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, crate::lower::node_::Wx>> _v;
            if (prism_rtl::is_some(bound_o4) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_o4))) {
                auto&& f_pe = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_o4)).a0;
                _v.set(std::tuple{f_pe, wx_p0});
                goto _done;
            }
            if (prism_rtl::is_some(bound_o4) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o4)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o4)).a0)) {
                auto&& m20489_1_0_0 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o4)).a0).a0;
                auto&& f_pf = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o4)).a0).a1;
                if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m20489_1_0_0)))) {
                    _v.set(std::tuple{f_pf, wx_p0});
                    goto _done;
                }
            }
            {
                _v.set(crate::lower::node_::fresh_name_f(wx_p0, Text::lit("distinct")));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto kept_p9 = prism_rtl::cat(name_pg, "_kept");
        auto source_pa = prism_rtl::cat(name_pg, "_source");
        auto [ex_pi, reads_pj] = crate::lower::node_::dynamics::dynamic_expr_f(wx1_ph, menv_p1, prism_rtl::deref(a_p7).value_p);
        auto first_pb = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), kept_p9})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), source_pa, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
        auto sample_pc = crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), kept_p9})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Array(std::vector{crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}, crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), source_pa, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}}), false, t_p8});
        auto wx2_pd = ({
            crate::lower::node_::Wx this_ = wx1_ph;
            this_.taken_p = crate::prelude::append(this_.taken_p, Array(std::vector{kept_p9, source_pa}));
            this_.fields_p = crate::prelude::push(this_.fields_p, std::tuple{kept_p9, crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(t_p8)}))}), Text::lit("`@Distinct`\'s value: its source\'s, written only when it changes")});
            this_.moves_p = crate::prelude::push(this_.moves_p, std::tuple{kept_p9, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
            this_.build_p = crate::prelude::push(this_.build_p, first_pb);
            this_.getters_p = crate::prelude::append(this_.getters_p, Array(std::vector{crate::lower::model::MethDef{.name_p = source_pa, .recv_p = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_p = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret_p = t_p8, .body_p = Array<crate::lower::model::Do>{}, .tail_p = ex_pi, .doc_p = Text::lit("`@Distinct`\'s source, read at the build.")}, crate::lower::model::MethDef{.name_p = name_pg, .recv_p = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_p = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret_p = t_p8, .body_p = Array<crate::lower::model::Do>{}, .tail_p = sample_pc, .doc_p = Text::lit("`@Distinct`\'s dynamic: the value it holds at the read point.")}}));
            this_.dyn_reads_p = crate::prelude::insert(crate::prelude::insert(this_.dyn_reads_p, name_pg, Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{kept_p9})})), source_pa, reads_pj);
            (std::move(this_));
        });
        auto [r_pk, wx3_pl] = crate::lower::node_::dynamics::updated_event_f(wx2_pd, menv_p1, args_p2, t_p8);
        return std::tuple{crate::lower::node_::connect_f(wx3_pl, r_pk, crate::lower::node_::Sk(crate::lower::node_::Sk::SkDistinct{kept_p9})), crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), name_pg, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{kept_p9})}), t_p8})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// PerKeyLine: unbounded fn Wx, Env, [Arg], ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> per_key_line_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2, const std::optional<crate::lower::types::Bn>& bound_o3) {
    auto lx_p4 = wx_p0.lx_p;
    auto&& _m = crate::prelude::index(args_p2, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        auto wx2_p5 = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.build_p = crate::prelude::push(this_.build_p, crate::lower::expr::refusal_do_f(Text::lit("an `@PerKey` without its dynamic")));
            (std::move(this_));
        });
        return std::tuple{wx2_p5, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& a_p6 = prism_rtl::some_of(_m);
        auto [kt_pg, vt_ph] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy>> _v;
            auto&& _m = crate::lower::types::peel_f(crate::lower::type_at_f(lx_p4, prism_rtl::deref(prism_rtl::deref(a_p6).value_p).span_p));
            if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
                auto&& k_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
                auto&& v_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
                _v.set(std::tuple{crate::lower::types::out_ty_of_f(lx_p4, prism_rtl::deref(k_pe)), crate::lower::types::out_ty_of_f(lx_p4, prism_rtl::deref(v_pf))});
                goto _done;
            }
            {
                _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto src_ty_p7 = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt_pg), prism_rtl::rc(vt_ph)});
        auto t_p8 = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt_pg), prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(vt_ph)}))});
        auto [name_pk, wx1_pl] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, crate::lower::node_::Wx>> _v;
            if (prism_rtl::is_some(bound_o3) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_o3))) {
                auto&& f_pi = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_o3)).a0;
                _v.set(std::tuple{f_pi, wx_p0});
                goto _done;
            }
            if (prism_rtl::is_some(bound_o3) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o3)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o3)).a0)) {
                auto&& m23801_1_0_0 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o3)).a0).a0;
                auto&& f_pj = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o3)).a0).a1;
                if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m23801_1_0_0)))) {
                    _v.set(std::tuple{f_pj, wx_p0});
                    goto _done;
                }
            }
            {
                _v.set(crate::lower::node_::fresh_name_f(wx_p0, Text::lit("per_key")));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto kept_p9 = prism_rtl::cat(name_pk, "_kept");
        auto source_pa = prism_rtl::cat(name_pk, "_source");
        auto [ex_pm, reads_pn] = crate::lower::node_::dynamics::dynamic_expr_f(wx1_pl, menv_p1, prism_rtl::deref(a_p6).value_p);
        auto first_pb = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), kept_p9})), Text::lit("start"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), source_pa, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
        auto sample_pc = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), kept_p9})), Text::lit("outer"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array<crate::lower::model::Pa>{}, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), source_pa, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})})});
        auto wx2_pd = ({
            crate::lower::node_::Wx this_ = wx1_pl;
            this_.taken_p = crate::prelude::append(this_.taken_p, Array(std::vector{kept_p9, source_pa}));
            this_.fields_p = crate::prelude::push(this_.fields_p, std::tuple{kept_p9, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::PerKey"), Array(std::vector{kt_pg, vt_ph})}), Text::lit("`@PerKey`\'s outer and each key\'s inner")});
            this_.moves_p = crate::prelude::push(this_.moves_p, std::tuple{kept_p9, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::PerKey::new"), Array<crate::lower::model::Ex>{}})});
            this_.build_p = crate::prelude::push(this_.build_p, first_pb);
            this_.getters_p = crate::prelude::append(this_.getters_p, Array(std::vector{crate::lower::model::MethDef{.name_p = source_pa, .recv_p = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_p = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret_p = src_ty_p7, .body_p = Array<crate::lower::model::Do>{}, .tail_p = ex_pm, .doc_p = Text::lit("`@PerKey`\'s source, read at the build.")}, crate::lower::model::MethDef{.name_p = name_pk, .recv_p = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_p = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret_p = t_p8, .body_p = Array<crate::lower::model::Do>{}, .tail_p = sample_pc, .doc_p = Text::lit("`@PerKey`\'s outer: each key\'s inner by key, at the read point.")}}));
            this_.dyn_reads_p = crate::prelude::insert(crate::prelude::insert(this_.dyn_reads_p, name_pk, Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{kept_p9})})), source_pa, reads_pn);
            (std::move(this_));
        });
        auto [r_po, wx3_pp] = crate::lower::node_::dynamics::updated_event_f(wx2_pd, menv_p1, args_p2, src_ty_p7);
        return std::tuple{crate::lower::node_::connect_f(wx3_pp, r_po, crate::lower::node_::Sk(crate::lower::node_::Sk::SkPerKey{kept_p9})), crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), name_pk, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{kept_p9})}), t_p8})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// RunLine: unbounded fn Wx, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> run_line_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const Array<crate::syntax::Arg>& args_p2, const crate::syntax::Expr& e_p3, const std::optional<Nat>& target_o4) {
    auto lx_p5 = wx_p0.lx_p;
    auto t_p6 = crate::lower::types::out_ty_of_f(lx_p5, crate::lower::types::out_of_f(crate::lower::type_at_f(lx_p5, e_p3.span_p)));
    auto [p_pd, wx1_pe] = crate::lower::node_::fresh_name_f(wx_p0, Text::lit("run"));
    auto wx2_p7 = ({
        crate::lower::node_::Wx this_ = wx1_pe;
        this_.pos_p = crate::lower::model::next_pos_f(this_.pos_p);
        this_.taken_p = crate::prelude::append(this_.taken_p, Array(std::vector{prism_rtl::cat(p_pd, "_job"), prism_rtl::cat(p_pd, "_again"), prism_rtl::cat(p_pd, "_started"), prism_rtl::cat(p_pd, "_turn")}));
        (std::move(this_));
    });
    auto start_p8 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        auto&& _m = crate::prelude::index(args_p2, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a_pf = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::Ex> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(a_pf).value_p).kind_p);
                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                    auto&& n_pg = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                    _v.set(({
                        auto&& _q_oh = crate::check::env::names::resolve_value_f(prism_rtl::deref(lx_p5).g_p, prism_rtl::deref(lx_p5).home_p, n_pg);
                        auto&& q_oh = std::get<0>(_q_oh);
                        (crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::expr::start_path_f(lx_p5, crate::prelude::or_(q_oh, Text::lit("")))}));
                    }));
                    goto _done;
                }
                {
                    _v.set(crate::lower::expr::refusal_f(Text::lit("an `@Run` of a function value that is not a name")));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::expr::refusal_f(Text::lit("an `@Run` without its function")));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto x_p9 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        auto&& _m = crate::prelude::index(args_p2, Nat(1u));
        if (prism_rtl::is_some(_m)) {
            auto&& a_pi = prism_rtl::some_of(_m);
            _v.set(crate::lower::types::own_f(crate::lower::expr::value_of_f(lx_p5, benv_p1, prism_rtl::deref(a_pi).value_p)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto wx3_pa = crate::lower::node_::add_field_f(wx2_p7, prism_rtl::cat(p_pd, "_job"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutJob{prism_rtl::rc(t_p6)}))}), Text::lit("`@Run`\'s job (`@Machine`\'s state)"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(start_p8), Array(std::vector{x_p9})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}));
    auto wx4_pb = crate::lower::node_::add_field_last_f(wx3_pa, prism_rtl::cat(p_pd, "_again"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutDefer{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))}), Text::lit("`@Run`\'s `!again`"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Defer::new"), Array<crate::lower::model::Ex>{}}));
    auto [s_pj, wx5_pk] = crate::lower::node_::add_gn_f(wx4_pb, prism_rtl::cat(p_pd, "_started"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnStarted{}), Nat(0u));
    auto [a_pl, wx6_pm] = crate::lower::node_::add_gn_f(wx5_pk, prism_rtl::cat(p_pd, "_again"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnDeferred{}), Nat(0u));
    auto [m_pn, wx7_po] = crate::lower::node_::dynamics::merge_f(wx6_pm, prism_rtl::cat(p_pd, "_turn"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::node_::ev_ref_of_f(wx6_pm, s_pj), crate::lower::node_::ev_ref_of_f(wx6_pm, a_pl));
    auto [res_pq, wx8_pr] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
        if (prism_rtl::is_some(target_o4)) {
            auto&& n_pp = prism_rtl::some_of(target_o4);
            _v.set(std::tuple{n_pp, wx7_po});
            goto _done;
        }
        if (prism_rtl::is_none(target_o4)) {
            _v.set(crate::lower::node_::add_gn_f(wx7_po, prism_rtl::cat(p_pd, "_done"), t_p6, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNamed{}), Nat(0u)));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto wx9_pc = ({
        crate::lower::node_::Wx this_ = crate::lower::node_::connect_f(wx8_pr, crate::lower::node_::ev_ref_of_f(wx8_pr, m_pn), crate::lower::node_::Sk(crate::lower::node_::Sk::SkCycle{prism_rtl::cat(p_pd, "_job"), prism_rtl::cat(p_pd, "_again"), res_pq}));
        this_.started_p = crate::prelude::push(this_.started_p, s_pj);
        this_.defers_p = crate::prelude::push(this_.defers_p, std::tuple{prism_rtl::cat(p_pd, "_again"), a_pl});
        (std::move(this_));
    });
    return std::tuple{wx9_pc, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of_f(wx9_pc, res_pq)})};
}


/// MachineLine: unbounded fn Wx, Env, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> machine_line_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Expr& e_p4, const std::optional<Nat>& target_o5) {
    auto lx_p6 = wx_p0.lx_p;
    auto t_p7 = crate::lower::types::out_ty_of_f(lx_p6, crate::lower::types::out_of_f(crate::lower::type_at_f(lx_p6, e_p4.span_p)));
    auto [f_p9, wx1_pa] = crate::lower::node_::fresh_name_f(wx_p0, Text::lit("machine"));
    auto step_p8 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::prelude::index(args_p3, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a_pb = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(a_pb).value_p).kind_p);
                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                    auto&& n_pc = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                    _v.set(({
                        auto&& _q_od = crate::check::env::names::resolve_value_f(prism_rtl::deref(lx_p6).g_p, prism_rtl::deref(lx_p6).home_p, n_pc);
                        auto&& q_od = std::get<0>(_q_od);
                        ({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        if (prism_rtl::is_some(q_od)) {
                            auto&& q_pe = prism_rtl::some_of(q_od);
                            _v.set(crate::lower::value_path_f(lx_p6, q_pe));
                            goto _done;
                        }
                        if (prism_rtl::is_none(q_od)) {
                            _v.set(Text::lit(""));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                {
                    _v.set(Text::lit(""));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _m = std::tuple{step_p8, crate::prelude::index(args_p3, Nat(1u)), crate::prelude::index(args_p3, Nat(2u))};
    if (prism_rtl::is_some(std::get<1>(_m)) && prism_rtl::is_some(std::get<2>(_m))) {
        auto&& sp_pf = std::get<0>(_m);
        auto&& init_pg = prism_rtl::some_of(std::get<1>(_m));
        auto&& ev_ph = prism_rtl::some_of(std::get<2>(_m));
        if (sp_pf != Text::lit("")) {
            auto st_pi = crate::lower::types::out_ty_of_f(lx_p6, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p6, prism_rtl::deref(prism_rtl::deref(init_pg).value_p).span_p)));
            auto x_pj = crate::lower::types::own_f(crate::lower::expr::value_of_f(lx_p6, benv_p1, prism_rtl::deref(init_pg).value_p));
            auto wx2_pk = crate::lower::node_::add_field_f(wx1_pa, prism_rtl::cat(f_p9, "_state"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(st_pi)}), Text::lit("`@Machine`\'s state"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{x_pj, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}));
            auto [out_pm, wx3_pn] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
                if (prism_rtl::is_some(target_o5)) {
                    auto&& n_pl = prism_rtl::some_of(target_o5);
                    _v.set(std::tuple{n_pl, wx2_pk});
                    goto _done;
                }
                if (prism_rtl::is_none(target_o5)) {
                    _v.set(crate::lower::node_::add_gn_f(wx2_pk, prism_rtl::cat(f_p9, "_fired"), t_p7, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNamed{}), Nat(0u)));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto [r_po, wx4_pp] = crate::lower::node_::dynamics::event_ref_f(wx3_pn, menv_p2, prism_rtl::deref(ev_ph).value_p);
            return std::tuple{crate::lower::node_::connect_f(wx4_pp, r_po, crate::lower::node_::Sk(crate::lower::node_::Sk::SkMachine{prism_rtl::cat(f_p9, "_state"), sp_pf, out_pm})), crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of_f(wx4_pp, out_pm)})};
        }
    }
    {
        auto wx2_pq = ({
            crate::lower::node_::Wx this_ = wx1_pa;
            this_.build_p = crate::prelude::push(this_.build_p, crate::lower::expr::refusal_do_f(Text::lit("an `@Machine` whose step is not a named function")));
            (std::move(this_));
        });
        return std::tuple{wx2_pq, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    }
}


/// InlineWidget: unbounded fn Wx, Env, Env, Text, ValInfo, [Arg], Expr -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> inline_widget_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const Text& qk_p3, const crate::check::env::ValInfo& v_p4, const Array<crate::syntax::Arg>& args_p5, const crate::syntax::Expr& e_p6) {
    auto lx_p7 = wx_p0.lx_p;
    auto clauses_p8 = crate::lower::jobs::clauses_of_f(prism_rtl::deref(lx_p7).g_p, qk_p3);
    auto w_o9 = widget_decl_of_o(prism_rtl::deref(lx_p7).g_p, qk_p3);
    auto [params_pe, body_of] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::syntax::Pattern_>, std::optional<crate::syntax::Block>>> _v;
        if (prism_rtl::is_some(w_o9)) {
            auto&& wd_pa = prism_rtl::some_of(w_o9);
            _v.set(std::tuple{Array<crate::syntax::Pattern_>{}, std::optional(prism_rtl::deref(wd_pa).body_p)});
            goto _done;
        }
        if (prism_rtl::is_none(w_o9)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::syntax::Pattern_>, std::optional<crate::syntax::Block>>> _v;
                {
                    auto&& m29508_0 = clauses_p8;
                    if (m29508_0.size() == 1u) {
                        {
                            auto&& _c1 = crate::prelude::index(m29508_0, Nat(0u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& c_pb = prism_rtl::some_of(_c1);
                                _v.set(({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<Array<crate::syntax::Pattern_>, std::optional<crate::syntax::Block>>> _v;
                                    auto&& _m = prism_rtl::deref(c_pb).body_p;
                                    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m)) {
                                        auto&& b_pc = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
                                        _v.set(std::tuple{prism_rtl::deref(c_pb).params_p, std::optional(b_pc)});
                                        goto _done;
                                    }
                                    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(_m)) {
                                        auto&& x_pd = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(_m).a0;
                                        _v.set(std::tuple{prism_rtl::deref(c_pb).params_p, std::optional(crate::syntax::Block{.stmts_p = Array(std::vector{crate::syntax::Stmt{.kind_p = crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{x_pd}), .span_p = prism_rtl::deref(x_pd).span_p}}), .inline_p = true, .span_p = prism_rtl::deref(x_pd).span_p})});
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                }));
                                goto _done;
                            }
                        }
                    }
                }
                {
                    _v.set(std::tuple{Array<crate::syntax::Pattern_>{}, std::optional<crate::syntax::Block>{}});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is_none(body_of)) {
        return crate::prelude::len(clauses_p8) == Nat(0u)
            ? ({
            auto wx2_pg = ({
                crate::lower::node_::Wx this_ = wx_p0;
                this_.build_p = crate::prelude::push(this_.build_p, crate::lower::expr::refusal_do_f(prism_rtl::cat("the builtin widget ", crate::check::types::bare_name_f(qk_p3))));
                (std::move(this_));
            });
            std::tuple{wx2_pg, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
        })
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> _v;
            auto&& _m = crate::prelude::index(args_p5, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& a_ph = prism_rtl::some_of(_m);
                _v.set(({
                    auto call_pi = crate::syntax::Block{.stmts_p = Array(std::vector{crate::syntax::Stmt{.kind_p = crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e_p6}), .span_p = e_p6.span_p}}), .inline_p = true, .span_p = e_p6.span_p};
                    (crate::lower::node_::switch_::clause_widget_line_f(wx_p0, menv_p2, prism_rtl::deref(a_ph).value_p, call_pi, qk_p3, v_p4, e_p6));
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    auto wx2_pj = ({
                        crate::lower::node_::Wx this_ = wx_p0;
                        this_.build_p = crate::prelude::push(this_.build_p, crate::lower::expr::refusal_do_f(Text::lit("a widget of several clauses that takes no arguments")));
                        (std::move(this_));
                    });
                    std::tuple{wx2_pj, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_some(body_of)) {
        auto&& body_pk = prism_rtl::some_of(body_of);
        return recursion_f(wx_p0.inlining_p, qk_p3) > Nat(16u)
            ? too_deep_f(wx_p0, qk_p3, e_p6)
            : ({
            auto lxc_pl = crate::lower::program::in_module_at_f(lx_p7, v_p4.file_p, v_p4.home_p, prism_rtl::deref(lx_p7).site_p);
            auto ptys_pm = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
                auto&& _m = prism_rtl::deref(v_p4.scheme_p).ty_p;
                if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                    auto&& ps_ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
                    _v.set(ps_ps);
                    goto _done;
                }
                {
                    _v.set(Array<crate::check::types::Ty>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [wx1_p15, be1_p16, me1_p17] = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(params_pe)), std::tuple{wx_p0, crate::lower::types::empty_env_p(), crate::lower::types::empty_env_p()}, ({
                auto params_pex = params_pe;
                auto lxc_plx = lxc_pl;
                auto ptys_pmx = ptys_pm;
                auto args_p5x = args_p5;
                auto benv_p1x = benv_p1;
                auto menv_p2x = menv_p2;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, params_pex = std::move(params_pex), lxc_plx = std::move(lxc_plx), ptys_pmx = std::move(ptys_pmx), args_p5x = std::move(args_p5x), benv_p1x = std::move(benv_p1x), menv_p2x = std::move(menv_p2x)](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto params_pexy = params_pex;
                    auto lxc_plxy = lxc_plx;
                    auto ptys_pmxy = ptys_pmx;
                    auto args_p5xy = args_p5x;
                    auto benv_p1xy = benv_p1x;
                    auto menv_p2xy = menv_p2x;
                    (crate::prelude::entered(crate::prelude::once_job([=, params_pexy = std::move(params_pexy), lxc_plxy = std::move(lxc_plxy), ptys_pmxy = std::move(ptys_pmxy), args_p5xy = std::move(args_p5xy), benv_p1xy = std::move(benv_p1xy), menv_p2xy = std::move(menv_p2xy)]() {
                    return ({
                        auto [w_pt, be_pu, me_pv] = p0;
                        auto i_p10 = p1;
                        ({
                        auto p_p11 = crate::prelude::or_(crate::prelude::index(params_pexy, i_p10), crate::lower::patterns::dummy_pat_p());
                        auto nkey_p12 = crate::lower::functions::plain_binder_f(lxc_plxy, p_p11);
                        auto pty_p13 = crate::prelude::or_(crate::prelude::index(ptys_pmxy, i_p10), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                        ({
                        auto&& _m = crate::prelude::index(args_p5xy, i_p10);
                        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{w_pt, be_pu, me_pv})
                        : prism_rtl::is_some(_m) ? ({
                        auto&& a_p14 = prism_rtl::some_of(_m);
                        prism_rtl::finished(bind_param_f(w_pt, benv_p1xy, menv_p2xy, be_pu, me_pv, nkey_p12, pty_p13, prism_rtl::deref(a_p14).value_p));
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                    });
                })));
                });
            }));
            })));
            auto call_span_pn = ({
                __label__ _done;
                prism_rtl::Slot<crate::syntax::Range> _v;
                auto&& _m = prism_rtl::deref(e_p6.kind_p);
                if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                    auto&& c_p18 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                    _v.set(prism_rtl::deref(c_p18).span_p);
                    goto _done;
                }
                {
                    _v.set(e_p6.span_p);
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto lxi_po = ({
                crate::lower::Lx this_ = lxc_pl;
                this_.inlined_p = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p7).call_ids_p, crate::lower::place_key_f(lx_p7, call_span_pn));
                    if (prism_rtl::is_some(_m)) {
                        auto&& id_p19 = prism_rtl::some_of(_m);
                        _v.set(prism_rtl::cat(prism_rtl::deref(lx_p7).inlined_p, "_", crate::lower::base32_f(id_p19)));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(prism_rtl::deref(lx_p7).inlined_p);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (std::move(this_));
            });
            auto inner_pp = ({
                crate::lower::node_::Wx this_ = wx1_p15;
                this_.lx_p = lxi_po;
                this_.inlining_p = crate::prelude::push(this_.inlining_p, qk_p3);
                this_.result_p = crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{});
                (std::move(this_));
            });
            auto done_pq = crate::lower::node_::def::block_into_f(inner_pp, be1_p16, me1_p17, body_pk);
            auto back_pr = ({
                crate::lower::node_::Wx this_ = done_pq;
                this_.lx_p = lx_p7;
                this_.inlining_p = wx_p0.inlining_p;
                this_.result_p = wx_p0.result_p;
                (std::move(this_));
            });
            std::tuple{back_pr, prism_rtl::deref(done_pq).result_p};
        });
    }
    prism_rtl::unreachable("no arm matched");
}


/// Recursion: fn [Text], Text -> Nat
Nat recursion_f(const Array<Text>& inlining_p0, const Text& qk_p1) {
    return crate::prelude::fold(inlining_p0, Nat(0u), [&](const Nat& n_p2, const Text& k_p3) { return k_p3 == qk_p1 ? n_p2 + Nat(1u) : n_p2; });
}


/// TooDeep: unbounded fn Wx, Text, Expr -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> too_deep_f(const crate::lower::node_::Wx& wx_p0, const Text& qk_p1, const crate::syntax::Expr& e_p2) {
    auto lx_p3 = wx_p0.lx_p;
    auto what_p4 = prism_rtl::cat("`", crate::check::types::bare_name_f(qk_p1), "` recurses deeper than the compiler inlines it (16 levels)");
    auto wx1_p5 = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.build_p = crate::prelude::push(this_.build_p, crate::lower::model::Do(crate::lower::model::Do::DoReturn{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Fault::too_deep"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{what_p4})})})})})}));
        this_.fallible_p = true;
        (std::move(this_));
    });
    auto t_p6 = crate::lower::types::out_ty_of_f(lx_p3, crate::lower::types::out_of_f(crate::lower::type_at_f(lx_p3, e_p2.span_p)));
    auto called_p7 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        auto&& _m = crate::lower::type_at_f(lx_p3, e_p2.span_p);
        if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
            auto&& i_p8 = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
            _v.set(prism_rtl::deref(i_p8));
            goto _done;
        }
        {
            auto&& other_p9 = _m;
            _v.set(other_p9);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto&& _m = crate::lower::types::layer_of_f(called_p7);
    if (prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m)) {
        return std::tuple{wx1_p5, crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XUnreachable{}), Array<crate::lower::node_::Read>{}, t_p6})};
    }
    if (prism_rtl::is<crate::lower::types::Layer::LyEv>(_m)) {
        auto [id_pa, wx2_pb] = crate::lower::node_::add_gn_f(wx1_p5, Text::lit("too_deep"), t_p6, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNever{}), Nat(0u));
        return std::tuple{wx2_pb, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of_f(wx2_pb, id_pa)})};
    }
    {
        return t_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
            ? std::tuple{wx1_p5, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})}
            : ({
            auto wx2_pc = ({
                crate::lower::node_::Wx this_ = wx1_p5;
                this_.lets_p = crate::prelude::push(this_.lets_p, crate::lower::model::Do(crate::lower::model::Do::DoReturn{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Fault::too_deep"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{what_p4})})})})})}));
                (std::move(this_));
            });
            std::tuple{wx2_pc, crate::lower::node_::Wres(crate::lower::node_::Wres::WrPlain{crate::lower::model::Ex(crate::lower::model::Ex::XUnreachable{}), t_p6})};
        });
    }
}


/// ?WidgetDeclOf: fn G, Text -> ?WidgetDecl
std::optional<crate::syntax::decls::WidgetDecl> widget_decl_of_o(const crate::check::env::G& g_p0, const Text& qk_p1) {
    return crate::prelude::fold(g_p0.defs_p, std::optional<crate::syntax::decls::WidgetDecl>{}, [&](const std::optional<crate::syntax::decls::WidgetDecl>& found_o2, const crate::check::env::Def& d_p3) {
        return prism_rtl::deref(d_p3).qk_p == qk_p1
            ? def_widget_o(d_p3, found_o2)
            : found_o2;
    });
}


/// ?DefWidget: fn Def, ?WidgetDecl -> ?WidgetDecl
std::optional<crate::syntax::decls::WidgetDecl> def_widget_o(const crate::check::env::Def& d_p0, const std::optional<crate::syntax::decls::WidgetDecl>& other_o1) {
    auto&& _m = d_p0.body_p;
    if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
        auto&& w_p2 = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
        return std::optional(w_p2);
    }
    {
        return other_o1;
    }
}


/// BindParam: unbounded fn Wx, Env, Env, Env, Env, Text, Ty, Expr -> ((Wx, Env, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> bind_param_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& cbenv_p1, const crate::lower::types::Env& cmenv_p2, const crate::lower::types::Env& be_p3, const crate::lower::types::Env& me_p4, const Text& nkey_p5, const crate::check::types::Ty& pty_p6, const crate::syntax::Expr& arg_p7) {
    auto lx_p8 = wx_p0.lx_p;
    auto t_p9 = crate::lower::types::out_ty_of_f(lx_p8, crate::lower::types::peel_f(pty_p6));
    auto&& _m = crate::lower::types::layer_of_f(pty_p6);
    if (prism_rtl::is<crate::lower::types::Layer::LyBlueprint>(_m)) {
        auto b_pa = crate::lower::types::Bn(crate::lower::types::Bn::BnWidget{arg_p7, cbenv_p1, cmenv_p2, lx_p8});
        return std::tuple{wx_p0, crate::lower::types::bind_f(be_p3, nkey_p5, b_pa), crate::lower::types::bind_f(me_p4, nkey_p5, b_pa)};
    }
    if (prism_rtl::is<crate::lower::types::Layer::LyEv>(_m)) {
        auto [r_pc, wx2_pd] = crate::lower::node_::dynamics::event_ref_f(wx_p0, cmenv_p2, arg_p7);
        auto b_pb = crate::lower::types::Bn(crate::lower::types::Bn::BnEv{r_pc, t_p9});
        return std::tuple{wx2_pd, crate::lower::types::bind_f(be_p3, nkey_p5, b_pb), crate::lower::types::bind_f(me_p4, nkey_p5, b_pb)};
    }
    if (prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m)) {
        auto [ex_pf, reads_pg] = crate::lower::node_::dynamics::dynamic_expr_f(wx_p0, cmenv_p2, arg_p7);
        auto b_pe = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{ex_pf, reads_pg, t_p9});
        auto [wx0_pk, be0_pl] = crate::lower::node_::def::all_inited_f(wx_p0, reads_pg) && crate::lower::node_::def::names_inited_f(cbenv_p1, arg_p7)
            ? ({
            auto [rsi_pi, wxi_pj] = crate::lower::node_::fresh_name_f(wx_p0, prism_rtl::cat(crate::lower::snake_f(nkey_p5), "_arg"));
            auto wxj_ph = ({
                crate::lower::node_::Wx this_ = wxi_pj;
                this_.lets_p = crate::prelude::push(this_.lets_p, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(rsi_pi, "_init")})), t_p9}), crate::lower::types::own_f(crate::lower::expr::value_of_f(lx_p8, crate::lower::node_::def::init_env_f(cbenv_p1), arg_p7))}));
                this_.inited_p = crate::prelude::push(this_.inited_p, rsi_pi);
                (std::move(this_));
            });
            std::tuple{wxj_ph, crate::lower::types::bind_f(be_p3, prism_rtl::cat(nkey_p5, "#init"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(rsi_pi, "_init")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_p9}))};
        })
            : std::tuple{wx_p0, be_p3};
        if (prism_rtl::is<crate::lower::model::Ex::XMethod>(ex_pf)) {
            auto&& m36215_0_0 = prism_rtl::as<crate::lower::model::Ex::XMethod>(ex_pf).a0;
            if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m36215_0_0)))) {
                return std::tuple{wx0_pk, crate::lower::types::bind_f(be0_pl, nkey_p5, b_pe), crate::lower::types::bind_f(me_p4, nkey_p5, b_pe)};
            }
        }
        {
            auto [rs_pp, wx2_pq] = crate::lower::node_::fresh_name_f(wx0_pk, crate::lower::snake_f(nkey_p5));
            auto getter_pm = crate::lower::model::MethDef{.name_p = rs_pp, .recv_p = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_p = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret_p = t_p9, .body_p = Array<crate::lower::model::Do>{}, .tail_p = ex_pf, .doc_p = prism_rtl::cat("`", nkey_p5, "`, a widget\'s parameter, as its rows read it")};
            auto wx3_pn = ({
                crate::lower::node_::Wx this_ = wx2_pq;
                this_.getters_p = crate::prelude::push(this_.getters_p, getter_pm);
                this_.dyn_reads_p = crate::prelude::insert(this_.dyn_reads_p, rs_pp, reads_pg);
                (std::move(this_));
            });
            auto rb_po = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs_pp, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{rs_pp})}), t_p9});
            return std::tuple{wx3_pn, crate::lower::types::bind_f(crate::lower::types::bind_f(be0_pl, nkey_p5, b_pe), prism_rtl::cat(nkey_p5, "#row"), rb_po), crate::lower::types::bind_f(crate::lower::types::bind_f(me_p4, nkey_p5, b_pe), prism_rtl::cat(nkey_p5, "#row"), rb_po)};
        }
    }
    {
        auto [rs_pt, wx2_pu] = crate::lower::node_::fresh_name_f(wx_p0, crate::lower::snake_f(nkey_p5));
        auto v_pr = crate::lower::types::own_f(crate::lower::expr::value_of_f(lx_p8, cbenv_p1, arg_p7));
        auto wx3_ps = ({
            crate::lower::node_::Wx this_ = wx2_pu;
            this_.lets_p = crate::prelude::push(this_.lets_p, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs_pt}), v_pr}));
            this_.fields_p = crate::prelude::push(this_.fields_p, std::tuple{rs_pt, t_p9, prism_rtl::cat("`", nkey_p5, "`")});
            this_.inits_p = crate::prelude::push(this_.inits_p, std::tuple{rs_pt, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_pt}))})});
            (std::move(this_));
        });
        auto [be2_pv, me2_p10] = crate::lower::node_::bind_plain_f(be_p3, me_p4, nkey_p5, rs_pt, t_p9);
        return std::tuple{wx3_ps, be2_pv, me2_p10};
    }
}

}  // namespace crate::lower::node_::static_
