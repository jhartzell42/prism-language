// The module `Lexer`, from `target/bootstrap/cpp-src/prismc/lexer.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include "lexer.hpp"
#include "ast.hpp"
#include "lexer.generic.hpp"

namespace crate::lexer {

void AttrTok::show(Printer& p) const {
    p.record("AttrTok", {{"name", name}, {"tokens", tokens}, {"span", span}});
}

Pod AttrTok::to_pod() const {
    return Pod::record("AttrTok", {{"name", prism_rtl::to_pod(name)}, {"tokens", prism_rtl::to_pod(tokens)}, {"span", prism_rtl::to_pod(span)}});
}

Result<AttrTok> AttrTok::from_pod(const Pod& whole) {
    return AttrTok{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .tokens = TRY(prism_rtl::from_pod<Array<Tok>>(TRY(prelude::field(whole, "tokens")))), .span = TRY(prism_rtl::from_pod<ast::Range>(TRY(prelude::field(whole, "span"))))};
}


void CallRead::show(Printer& p) const {
    p.record("CallRead", {{"l", l}, {"attrs", attrs}, {"body", body}, {"going", going}});
}

Pod CallRead::to_pod() const {
    return Pod::record("CallRead", {{"l", prism_rtl::to_pod(l)}, {"attrs", prism_rtl::to_pod(attrs)}, {"body", prism_rtl::to_pod(body)}, {"going", prism_rtl::to_pod(going)}});
}

Result<CallRead> CallRead::from_pod(const Pod& whole) {
    return CallRead{.l = TRY(prism_rtl::from_pod<Lex>(TRY(prelude::field(whole, "l")))), .attrs = TRY(prism_rtl::from_pod<Array<AttrTok>>(TRY(prelude::field(whole, "attrs")))), .body = TRY(prism_rtl::from_pod<std::optional<Array<TPartTok>>>(TRY(prelude::field(whole, "body")))), .going = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "going"))))};
}


void Lex::show(Printer& p) const {
    p.record("Lex", {{"src", src}, {"pos", pos}, {"diags", diags}, {"mode", mode}, {"tokens", tokens}, {"layout", layout}, {"frames", frames}, {"last_ws", last_ws}, {"lambda_open", lambda_open}, {"pending_open", pending_open}, {"pending_span", pending_span}, {"line_first", line_first}, {"mark_line_start", mark_line_start}, {"first_line", first_line}, {"test_pending", test_pending}, {"test_depth", test_depth}, {"check_depth", check_depth}, {"path_next", path_next}});
}

Pod Lex::to_pod() const {
    return Pod::record("Lex", {{"src", prism_rtl::to_pod(src)}, {"pos", prism_rtl::to_pod(pos)}, {"diags", prism_rtl::to_pod(diags)}, {"mode", prism_rtl::to_pod(mode)}, {"tokens", prism_rtl::to_pod(tokens)}, {"layout", prism_rtl::to_pod(layout)}, {"frames", prism_rtl::to_pod(frames)}, {"last_ws", prism_rtl::to_pod(last_ws)}, {"lambda_open", prism_rtl::to_pod(lambda_open)}, {"pending_open", prism_rtl::to_pod(pending_open)}, {"pending_span", prism_rtl::to_pod(pending_span)}, {"line_first", prism_rtl::to_pod(line_first)}, {"mark_line_start", prism_rtl::to_pod(mark_line_start)}, {"first_line", prism_rtl::to_pod(first_line)}, {"test_pending", prism_rtl::to_pod(test_pending)}, {"test_depth", prism_rtl::to_pod(test_depth)}, {"check_depth", prism_rtl::to_pod(check_depth)}, {"path_next", prism_rtl::to_pod(path_next)}});
}

Result<Lex> Lex::from_pod(const Pod& whole) {
    return Lex{.src = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "src")))), .pos = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "pos")))), .diags = TRY(prism_rtl::from_pod<Array<ast::Diag>>(TRY(prelude::field(whole, "diags")))), .mode = TRY(prism_rtl::from_pod<Mode>(TRY(prelude::field(whole, "mode")))), .tokens = TRY(prism_rtl::from_pod<Array<Tok>>(TRY(prelude::field(whole, "tokens")))), .layout = TRY(prism_rtl::from_pod<Array<Nat>>(TRY(prelude::field(whole, "layout")))), .frames = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "frames")))), .last_ws = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "last_ws")))), .lambda_open = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "lambda_open")))), .pending_open = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "pending_open")))), .pending_span = TRY(prism_rtl::from_pod<ast::Range>(TRY(prelude::field(whole, "pending_span")))), .line_first = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "line_first")))), .mark_line_start = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "mark_line_start")))), .first_line = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "first_line")))), .test_pending = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "test_pending")))), .test_depth = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(prelude::field(whole, "test_depth")))), .check_depth = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(prelude::field(whole, "check_depth")))), .path_next = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "path_next"))))};
}


void Lexed::show(Printer& p) const {
    p.record("Lexed", {{"tokens", tokens}, {"diags", diags}});
}

Pod Lexed::to_pod() const {
    return Pod::record("Lexed", {{"tokens", prism_rtl::to_pod(tokens)}, {"diags", prism_rtl::to_pod(diags)}});
}

Result<Lexed> Lexed::from_pod(const Pod& whole) {
    return Lexed{.tokens = TRY(prism_rtl::from_pod<Array<Tok>>(TRY(prelude::field(whole, "tokens")))), .diags = TRY(prism_rtl::from_pod<Array<ast::Diag>>(TRY(prelude::field(whole, "diags"))))};
}


void Mode::show(Printer& p) const {
    if (auto c = std::get_if<MFile>(&cases())) p.choice("MFile", {});
    else if (auto c = std::get_if<MBrace>(&cases())) p.choice("MBrace", {c->a0});
    else if (auto c = std::get_if<MPlaceholder>(&cases())) p.choice("MPlaceholder", {c->a0});
    else if (auto c = std::get_if<MPathKey>(&cases())) p.choice("MPathKey", {});
}

Pod Mode::to_pod() const {
    return std::holds_alternative<MFile>(cases()) ? Pod::choice("MFile", {})
        : std::holds_alternative<MBrace>(cases()) ? Pod::choice("MBrace", {prism_rtl::to_pod(std::get<MBrace>(cases()).a0)})
        : std::holds_alternative<MPlaceholder>(cases()) ? Pod::choice("MPlaceholder", {prism_rtl::to_pod(std::get<MPlaceholder>(cases()).a0)})
        : std::holds_alternative<MPathKey>(cases()) ? Pod::choice("MPathKey", {})
        : Pod();
}

Result<Mode> Mode::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "MFile" && c->args.size() == 0) return Mode(MFile{});
        if (c->ctor == "MBrace" && c->args.size() == 1) return Mode(MBrace{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "MPlaceholder" && c->args.size() == 1) return Mode(MPlaceholder{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "MPathKey" && c->args.size() == 0) return Mode(MPathKey{});
    }
    return mismatch<Mode>("a Mode", p);
}


void NameCase::show(Printer& p) const {
    if (auto c = std::get_if<CaseLower>(&cases())) p.choice("CaseLower", {});
    else if (auto c = std::get_if<CaseUpper>(&cases())) p.choice("CaseUpper", {});
    else if (auto c = std::get_if<CaseTopic>(&cases())) p.choice("CaseTopic", {});
    else if (auto c = std::get_if<CaseHole>(&cases())) p.choice("CaseHole", {});
    else if (auto c = std::get_if<CaseReserved>(&cases())) p.choice("CaseReserved", {});
}

Pod NameCase::to_pod() const {
    return std::holds_alternative<CaseLower>(cases()) ? Pod::choice("CaseLower", {})
        : std::holds_alternative<CaseUpper>(cases()) ? Pod::choice("CaseUpper", {})
        : std::holds_alternative<CaseTopic>(cases()) ? Pod::choice("CaseTopic", {})
        : std::holds_alternative<CaseHole>(cases()) ? Pod::choice("CaseHole", {})
        : std::holds_alternative<CaseReserved>(cases()) ? Pod::choice("CaseReserved", {})
        : Pod();
}

Result<NameCase> NameCase::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "CaseLower" && c->args.size() == 0) return NameCase(CaseLower{});
        if (c->ctor == "CaseUpper" && c->args.size() == 0) return NameCase(CaseUpper{});
        if (c->ctor == "CaseTopic" && c->args.size() == 0) return NameCase(CaseTopic{});
        if (c->ctor == "CaseHole" && c->args.size() == 0) return NameCase(CaseHole{});
        if (c->ctor == "CaseReserved" && c->args.size() == 0) return NameCase(CaseReserved{});
    }
    return mismatch<NameCase>("a NameCase", p);
}


void NameTok::show(Printer& p) const {
    p.record("NameTok", {{"sigils", sigils}, {"path", path_}, {"case", case_}});
}

Pod NameTok::to_pod() const {
    return Pod::record("NameTok", {{"sigils", prism_rtl::to_pod(sigils)}, {"path", prism_rtl::to_pod(path_)}, {"case", prism_rtl::to_pod(case_)}});
}

Result<NameTok> NameTok::from_pod(const Pod& whole) {
    return NameTok{.sigils = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "sigils")))), .path_ = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "path")))), .case_ = TRY(prism_rtl::from_pod<NameCase>(TRY(prelude::field(whole, "case"))))};
}


void PathSegTok::show(Printer& p) const {
    if (auto c = std::get_if<PstNum>(&cases())) p.choice("PstNum", {c->a0});
    else if (auto c = std::get_if<PstGen>(&cases())) p.choice("PstGen", {c->a0});
    else if (auto c = std::get_if<PstKey>(&cases())) p.choice("PstKey", {c->a0});
}

Pod PathSegTok::to_pod() const {
    return std::holds_alternative<PstNum>(cases()) ? Pod::choice("PstNum", {prism_rtl::to_pod(std::get<PstNum>(cases()).a0)})
        : std::holds_alternative<PstGen>(cases()) ? Pod::choice("PstGen", {prism_rtl::to_pod(std::get<PstGen>(cases()).a0)})
        : std::holds_alternative<PstKey>(cases()) ? Pod::choice("PstKey", {prism_rtl::to_pod(std::get<PstKey>(cases()).a0)})
        : Pod();
}

Result<PathSegTok> PathSegTok::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "PstNum" && c->args.size() == 1) return PathSegTok(PstNum{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "PstGen" && c->args.size() == 1) return PathSegTok(PstGen{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "PstKey" && c->args.size() == 1) return PathSegTok(PstKey{TRY(prism_rtl::from_pod<Array<Tok>>(c->args[0]))});
    }
    return mismatch<PathSegTok>("a PathSegTok", p);
}


void RawItem::show(Printer& p) const {
    if (auto c = std::get_if<RiText>(&cases())) p.choice("RiText", {c->a0});
    else if (auto c = std::get_if<RiPlaceholder>(&cases())) p.choice("RiPlaceholder", {c->a0, c->a1});
    else if (auto c = std::get_if<RiBlock>(&cases())) p.choice("RiBlock", {c->a0, c->a1});
    else if (auto c = std::get_if<RiCall>(&cases())) p.choice("RiCall", {c->a0, c->a1, c->a2, c->a3});
}

Pod RawItem::to_pod() const {
    return std::holds_alternative<RiText>(cases()) ? Pod::choice("RiText", {prism_rtl::to_pod(std::get<RiText>(cases()).a0)})
        : std::holds_alternative<RiPlaceholder>(cases()) ? Pod::choice("RiPlaceholder", {prism_rtl::to_pod(std::get<RiPlaceholder>(cases()).a0), prism_rtl::to_pod(std::get<RiPlaceholder>(cases()).a1)})
        : std::holds_alternative<RiBlock>(cases()) ? Pod::choice("RiBlock", {prism_rtl::to_pod(std::get<RiBlock>(cases()).a0), prism_rtl::to_pod(std::get<RiBlock>(cases()).a1)})
        : std::holds_alternative<RiCall>(cases()) ? Pod::choice("RiCall", {prism_rtl::to_pod(std::get<RiCall>(cases()).a0), prism_rtl::to_pod(std::get<RiCall>(cases()).a1), prism_rtl::to_pod(std::get<RiCall>(cases()).a2), prism_rtl::to_pod(std::get<RiCall>(cases()).a3)})
        : Pod();
}

Result<RawItem> RawItem::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "RiText" && c->args.size() == 1) return RawItem(RiText{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "RiPlaceholder" && c->args.size() == 2) return RawItem(RiPlaceholder{TRY(prism_rtl::from_pod<Array<Tok>>(c->args[0])), TRY(prism_rtl::from_pod<ast::Range>(c->args[1]))});
        if (c->ctor == "RiBlock" && c->args.size() == 2) return RawItem(RiBlock{TRY(prism_rtl::from_pod<Array<Tok>>(c->args[0])), TRY(prism_rtl::from_pod<ast::Range>(c->args[1]))});
        if (c->ctor == "RiCall" && c->args.size() == 4) return RawItem(RiCall{TRY(prism_rtl::from_pod<NameTok>(c->args[0])), TRY(prism_rtl::from_pod<Array<AttrTok>>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Array<TPartTok>>>(c->args[2])), TRY(prism_rtl::from_pod<ast::Range>(c->args[3]))});
    }
    return mismatch<RawItem>("a RawItem", p);
}


void RawLine::show(Printer& p) const {
    p.record("RawLine", {{"items", items}, {"newline", newline}, {"block", block}});
}

Pod RawLine::to_pod() const {
    return Pod::record("RawLine", {{"items", prism_rtl::to_pod(items)}, {"newline", prism_rtl::to_pod(newline)}, {"block", prism_rtl::to_pod(block)}});
}

Result<RawLine> RawLine::from_pod(const Pod& whole) {
    return RawLine{.items = TRY(prism_rtl::from_pod<Array<RawItem>>(TRY(prelude::field(whole, "items")))), .newline = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "newline")))), .block = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "block"))))};
}


void TPartTok::show(Printer& p) const {
    if (auto c = std::get_if<TptText>(&cases())) p.choice("TptText", {c->a0});
    else if (auto c = std::get_if<TptPlaceholder>(&cases())) p.choice("TptPlaceholder", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<TptBlock>(&cases())) p.choice("TptBlock", {c->a0, c->a1});
    else if (auto c = std::get_if<TptCall>(&cases())) p.choice("TptCall", {c->a0, c->a1, c->a2, c->a3});
}

Pod TPartTok::to_pod() const {
    return std::holds_alternative<TptText>(cases()) ? Pod::choice("TptText", {prism_rtl::to_pod(std::get<TptText>(cases()).a0)})
        : std::holds_alternative<TptPlaceholder>(cases()) ? Pod::choice("TptPlaceholder", {prism_rtl::to_pod(std::get<TptPlaceholder>(cases()).a0), prism_rtl::to_pod(std::get<TptPlaceholder>(cases()).a1), prism_rtl::to_pod(std::get<TptPlaceholder>(cases()).a2)})
        : std::holds_alternative<TptBlock>(cases()) ? Pod::choice("TptBlock", {prism_rtl::to_pod(std::get<TptBlock>(cases()).a0), prism_rtl::to_pod(std::get<TptBlock>(cases()).a1)})
        : std::holds_alternative<TptCall>(cases()) ? Pod::choice("TptCall", {prism_rtl::to_pod(std::get<TptCall>(cases()).a0), prism_rtl::to_pod(std::get<TptCall>(cases()).a1), prism_rtl::to_pod(std::get<TptCall>(cases()).a2), prism_rtl::to_pod(std::get<TptCall>(cases()).a3)})
        : Pod();
}

Result<TPartTok> TPartTok::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TptText" && c->args.size() == 1) return TPartTok(TptText{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TptPlaceholder" && c->args.size() == 3) return TPartTok(TptPlaceholder{TRY(prism_rtl::from_pod<Array<Tok>>(c->args[0])), TRY(prism_rtl::from_pod<std::optional<Nat>>(c->args[1])), TRY(prism_rtl::from_pod<ast::Range>(c->args[2]))});
        if (c->ctor == "TptBlock" && c->args.size() == 2) return TPartTok(TptBlock{TRY(prism_rtl::from_pod<Array<Tok>>(c->args[0])), TRY(prism_rtl::from_pod<ast::Range>(c->args[1]))});
        if (c->ctor == "TptCall" && c->args.size() == 4) return TPartTok(TptCall{TRY(prism_rtl::from_pod<NameTok>(c->args[0])), TRY(prism_rtl::from_pod<Array<AttrTok>>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Array<TPartTok>>>(c->args[2])), TRY(prism_rtl::from_pod<ast::Range>(c->args[3]))});
    }
    return mismatch<TPartTok>("a TPartTok", p);
}


void TemplateTok::show(Printer& p) const {
    p.record("TemplateTok", {{"keyword", keyword}, {"lang", lang}, {"delims", delims}, {"parts", parts}});
}

Pod TemplateTok::to_pod() const {
    return Pod::record("TemplateTok", {{"keyword", prism_rtl::to_pod(keyword)}, {"lang", prism_rtl::to_pod(lang)}, {"delims", prism_rtl::to_pod(delims)}, {"parts", prism_rtl::to_pod(parts)}});
}

Result<TemplateTok> TemplateTok::from_pod(const Pod& whole) {
    return TemplateTok{.keyword = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "keyword")))), .lang = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "lang")))), .delims = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "delims")))), .parts = TRY(prism_rtl::from_pod<Array<TPartTok>>(TRY(prelude::field(whole, "parts"))))};
}


void TextSegTok::show(Printer& p) const {
    if (auto c = std::get_if<TsPlain>(&cases())) p.choice("TsPlain", {c->a0});
    else if (auto c = std::get_if<TsPlaceholder>(&cases())) p.choice("TsPlaceholder", {c->a0, c->a1});
}

Pod TextSegTok::to_pod() const {
    return std::holds_alternative<TsPlain>(cases()) ? Pod::choice("TsPlain", {prism_rtl::to_pod(std::get<TsPlain>(cases()).a0)})
        : std::holds_alternative<TsPlaceholder>(cases()) ? Pod::choice("TsPlaceholder", {prism_rtl::to_pod(std::get<TsPlaceholder>(cases()).a0), prism_rtl::to_pod(std::get<TsPlaceholder>(cases()).a1)})
        : Pod();
}

Result<TextSegTok> TextSegTok::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TsPlain" && c->args.size() == 1) return TextSegTok(TsPlain{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TsPlaceholder" && c->args.size() == 2) return TextSegTok(TsPlaceholder{TRY(prism_rtl::from_pod<Array<Tok>>(c->args[0])), TRY(prism_rtl::from_pod<ast::Range>(c->args[1]))});
    }
    return mismatch<TextSegTok>("a TextSegTok", p);
}


void Tok::show(Printer& p) const {
    p.record("Tok", {{"kind", kind}, {"span", span}, {"touches", touches}, {"line_start", line_start}});
}

Pod Tok::to_pod() const {
    return Pod::record("Tok", {{"kind", prism_rtl::to_pod(kind)}, {"span", prism_rtl::to_pod(span)}, {"touches", prism_rtl::to_pod(touches)}, {"line_start", prism_rtl::to_pod(line_start)}});
}

Result<Tok> Tok::from_pod(const Pod& whole) {
    return Tok{.kind = TRY(prism_rtl::from_pod<TokKind>(TRY(prelude::field(whole, "kind")))), .span = TRY(prism_rtl::from_pod<ast::Range>(TRY(prelude::field(whole, "span")))), .touches = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "touches")))), .line_start = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "line_start"))))};
}


void TokKind::show(Printer& p) const {
    if (auto c = std::get_if<KName>(&cases())) p.choice("KName", {c->a0});
    else if (auto c = std::get_if<KFamily>(&cases())) p.choice("KFamily", {c->a0});
    else if (auto c = std::get_if<KTrait>(&cases())) p.choice("KTrait", {c->a0});
    else if (auto c = std::get_if<KKw>(&cases())) p.choice("KKw", {c->a0, c->a1});
    else if (auto c = std::get_if<KFree>(&cases())) p.choice("KFree", {c->a0});
    else if (auto c = std::get_if<KLensDot>(&cases())) p.choice("KLensDot", {});
    else if (auto c = std::get_if<KInt>(&cases())) p.choice("KInt", {c->a0, c->a1});
    else if (auto c = std::get_if<KFloat>(&cases())) p.choice("KFloat", {c->a0, c->a1});
    else if (auto c = std::get_if<KDuration>(&cases())) p.choice("KDuration", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<KChar>(&cases())) p.choice("KChar", {c->a0, c->a1});
    else if (auto c = std::get_if<KText>(&cases())) p.choice("KText", {c->a0, c->a1});
    else if (auto c = std::get_if<KTemplate>(&cases())) p.choice("KTemplate", {c->a0});
    else if (auto c = std::get_if<KOp>(&cases())) p.choice("KOp", {c->a0, c->a1});
    else if (auto c = std::get_if<KSuffixed>(&cases())) p.choice("KSuffixed", {c->a0, c->a1});
    else if (auto c = std::get_if<KDot>(&cases())) p.choice("KDot", {c->a0});
    else if (auto c = std::get_if<KDotDot>(&cases())) p.choice("KDotDot", {});
    else if (auto c = std::get_if<KComma>(&cases())) p.choice("KComma", {});
    else if (auto c = std::get_if<KColon>(&cases())) p.choice("KColon", {});
    else if (auto c = std::get_if<KSemi>(&cases())) p.choice("KSemi", {});
    else if (auto c = std::get_if<KBackslash>(&cases())) p.choice("KBackslash", {});
    else if (auto c = std::get_if<KLambdaBar>(&cases())) p.choice("KLambdaBar", {c->a0});
    else if (auto c = std::get_if<KBar>(&cases())) p.choice("KBar", {});
    else if (auto c = std::get_if<KLtLt>(&cases())) p.choice("KLtLt", {});
    else if (auto c = std::get_if<KGtGt>(&cases())) p.choice("KGtGt", {});
    else if (auto c = std::get_if<KOpen>(&cases())) p.choice("KOpen", {c->a0, c->a1});
    else if (auto c = std::get_if<KClose>(&cases())) p.choice("KClose", {c->a0});
    else if (auto c = std::get_if<KAbsent>(&cases())) p.choice("KAbsent", {});
    else if (auto c = std::get_if<KNonEmpty>(&cases())) p.choice("KNonEmpty", {});
    else if (auto c = std::get_if<KPath>(&cases())) p.choice("KPath", {c->a0});
    else if (auto c = std::get_if<KLayOpen>(&cases())) p.choice("KLayOpen", {});
    else if (auto c = std::get_if<KLaySep>(&cases())) p.choice("KLaySep", {});
    else if (auto c = std::get_if<KLayClose>(&cases())) p.choice("KLayClose", {});
    else if (auto c = std::get_if<KEof>(&cases())) p.choice("KEof", {});
}

Pod TokKind::to_pod() const {
    return std::holds_alternative<KName>(cases()) ? Pod::choice("KName", {prism_rtl::to_pod(std::get<KName>(cases()).a0)})
        : std::holds_alternative<KFamily>(cases()) ? Pod::choice("KFamily", {prism_rtl::to_pod(std::get<KFamily>(cases()).a0)})
        : std::holds_alternative<KTrait>(cases()) ? Pod::choice("KTrait", {prism_rtl::to_pod(std::get<KTrait>(cases()).a0)})
        : std::holds_alternative<KKw>(cases()) ? Pod::choice("KKw", {prism_rtl::to_pod(std::get<KKw>(cases()).a0), prism_rtl::to_pod(std::get<KKw>(cases()).a1)})
        : std::holds_alternative<KFree>(cases()) ? Pod::choice("KFree", {prism_rtl::to_pod(std::get<KFree>(cases()).a0)})
        : std::holds_alternative<KLensDot>(cases()) ? Pod::choice("KLensDot", {})
        : std::holds_alternative<KInt>(cases()) ? Pod::choice("KInt", {prism_rtl::to_pod(std::get<KInt>(cases()).a0), prism_rtl::to_pod(std::get<KInt>(cases()).a1)})
        : std::holds_alternative<KFloat>(cases()) ? Pod::choice("KFloat", {prism_rtl::to_pod(std::get<KFloat>(cases()).a0), prism_rtl::to_pod(std::get<KFloat>(cases()).a1)})
        : std::holds_alternative<KDuration>(cases()) ? Pod::choice("KDuration", {prism_rtl::to_pod(std::get<KDuration>(cases()).a0), prism_rtl::to_pod(std::get<KDuration>(cases()).a1), prism_rtl::to_pod(std::get<KDuration>(cases()).a2)})
        : std::holds_alternative<KChar>(cases()) ? Pod::choice("KChar", {prism_rtl::to_pod(std::get<KChar>(cases()).a0), prism_rtl::to_pod(std::get<KChar>(cases()).a1)})
        : std::holds_alternative<KText>(cases()) ? Pod::choice("KText", {prism_rtl::to_pod(std::get<KText>(cases()).a0), prism_rtl::to_pod(std::get<KText>(cases()).a1)})
        : std::holds_alternative<KTemplate>(cases()) ? Pod::choice("KTemplate", {prism_rtl::to_pod(std::get<KTemplate>(cases()).a0)})
        : std::holds_alternative<KOp>(cases()) ? Pod::choice("KOp", {prism_rtl::to_pod(std::get<KOp>(cases()).a0), prism_rtl::to_pod(std::get<KOp>(cases()).a1)})
        : std::holds_alternative<KSuffixed>(cases()) ? Pod::choice("KSuffixed", {prism_rtl::to_pod(std::get<KSuffixed>(cases()).a0), prism_rtl::to_pod(std::get<KSuffixed>(cases()).a1)})
        : std::holds_alternative<KDot>(cases()) ? Pod::choice("KDot", {prism_rtl::to_pod(std::get<KDot>(cases()).a0)})
        : std::holds_alternative<KDotDot>(cases()) ? Pod::choice("KDotDot", {})
        : std::holds_alternative<KComma>(cases()) ? Pod::choice("KComma", {})
        : std::holds_alternative<KColon>(cases()) ? Pod::choice("KColon", {})
        : std::holds_alternative<KSemi>(cases()) ? Pod::choice("KSemi", {})
        : std::holds_alternative<KBackslash>(cases()) ? Pod::choice("KBackslash", {})
        : std::holds_alternative<KLambdaBar>(cases()) ? Pod::choice("KLambdaBar", {prism_rtl::to_pod(std::get<KLambdaBar>(cases()).a0)})
        : std::holds_alternative<KBar>(cases()) ? Pod::choice("KBar", {})
        : std::holds_alternative<KLtLt>(cases()) ? Pod::choice("KLtLt", {})
        : std::holds_alternative<KGtGt>(cases()) ? Pod::choice("KGtGt", {})
        : std::holds_alternative<KOpen>(cases()) ? Pod::choice("KOpen", {prism_rtl::to_pod(std::get<KOpen>(cases()).a0), prism_rtl::to_pod(std::get<KOpen>(cases()).a1)})
        : std::holds_alternative<KClose>(cases()) ? Pod::choice("KClose", {prism_rtl::to_pod(std::get<KClose>(cases()).a0)})
        : std::holds_alternative<KAbsent>(cases()) ? Pod::choice("KAbsent", {})
        : std::holds_alternative<KNonEmpty>(cases()) ? Pod::choice("KNonEmpty", {})
        : std::holds_alternative<KPath>(cases()) ? Pod::choice("KPath", {prism_rtl::to_pod(std::get<KPath>(cases()).a0)})
        : std::holds_alternative<KLayOpen>(cases()) ? Pod::choice("KLayOpen", {})
        : std::holds_alternative<KLaySep>(cases()) ? Pod::choice("KLaySep", {})
        : std::holds_alternative<KLayClose>(cases()) ? Pod::choice("KLayClose", {})
        : std::holds_alternative<KEof>(cases()) ? Pod::choice("KEof", {})
        : Pod();
}

Result<TokKind> TokKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "KName" && c->args.size() == 1) return TokKind(KName{TRY(prism_rtl::from_pod<NameTok>(c->args[0]))});
        if (c->ctor == "KFamily" && c->args.size() == 1) return TokKind(KFamily{TRY(prism_rtl::from_pod<Array<Text>>(c->args[0]))});
        if (c->ctor == "KTrait" && c->args.size() == 1) return TokKind(KTrait{TRY(prism_rtl::from_pod<Array<Text>>(c->args[0]))});
        if (c->ctor == "KKw" && c->args.size() == 2) return TokKind(KKw{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "KFree" && c->args.size() == 1) return TokKind(KFree{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "KLensDot" && c->args.size() == 0) return TokKind(KLensDot{});
        if (c->ctor == "KInt" && c->args.size() == 2) return TokKind(KInt{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "KFloat" && c->args.size() == 2) return TokKind(KFloat{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "KDuration" && c->args.size() == 3) return TokKind(KDuration{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Text>(c->args[2]))});
        if (c->ctor == "KChar" && c->args.size() == 2) return TokKind(KChar{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "KText" && c->args.size() == 2) return TokKind(KText{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<TextSegTok>>(c->args[1]))});
        if (c->ctor == "KTemplate" && c->args.size() == 1) return TokKind(KTemplate{TRY(prism_rtl::from_pod<TemplateTok>(c->args[0]))});
        if (c->ctor == "KOp" && c->args.size() == 2) return TokKind(KOp{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<bool>(c->args[1]))});
        if (c->ctor == "KSuffixed" && c->args.size() == 2) return TokKind(KSuffixed{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Text>>(c->args[1]))});
        if (c->ctor == "KDot" && c->args.size() == 1) return TokKind(KDot{TRY(prism_rtl::from_pod<bool>(c->args[0]))});
        if (c->ctor == "KDotDot" && c->args.size() == 0) return TokKind(KDotDot{});
        if (c->ctor == "KComma" && c->args.size() == 0) return TokKind(KComma{});
        if (c->ctor == "KColon" && c->args.size() == 0) return TokKind(KColon{});
        if (c->ctor == "KSemi" && c->args.size() == 0) return TokKind(KSemi{});
        if (c->ctor == "KBackslash" && c->args.size() == 0) return TokKind(KBackslash{});
        if (c->ctor == "KLambdaBar" && c->args.size() == 1) return TokKind(KLambdaBar{TRY(prism_rtl::from_pod<bool>(c->args[0]))});
        if (c->ctor == "KBar" && c->args.size() == 0) return TokKind(KBar{});
        if (c->ctor == "KLtLt" && c->args.size() == 0) return TokKind(KLtLt{});
        if (c->ctor == "KGtGt" && c->args.size() == 0) return TokKind(KGtGt{});
        if (c->ctor == "KOpen" && c->args.size() == 2) return TokKind(KOpen{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<bool>(c->args[1]))});
        if (c->ctor == "KClose" && c->args.size() == 1) return TokKind(KClose{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "KAbsent" && c->args.size() == 0) return TokKind(KAbsent{});
        if (c->ctor == "KNonEmpty" && c->args.size() == 0) return TokKind(KNonEmpty{});
        if (c->ctor == "KPath" && c->args.size() == 1) return TokKind(KPath{TRY(prism_rtl::from_pod<Array<PathSegTok>>(c->args[0]))});
        if (c->ctor == "KLayOpen" && c->args.size() == 0) return TokKind(KLayOpen{});
        if (c->ctor == "KLaySep" && c->args.size() == 0) return TokKind(KLaySep{});
        if (c->ctor == "KLayClose" && c->args.size() == 0) return TokKind(KLayClose{});
        if (c->ctor == "KEof" && c->args.size() == 0) return TokKind(KEof{});
    }
    return mismatch<TokKind>("a TokKind", p);
}


void TplHow::show(Printer& p) const {
    p.record("TplHow", {{"close", close}, {"delims", delims}, {"open", open}, {"is_raw", is_raw}, {"first_continues", first_continues}});
}

Pod TplHow::to_pod() const {
    return Pod::record("TplHow", {{"close", prism_rtl::to_pod(close)}, {"delims", prism_rtl::to_pod(delims)}, {"open", prism_rtl::to_pod(open)}, {"is_raw", prism_rtl::to_pod(is_raw)}, {"first_continues", prism_rtl::to_pod(first_continues)}});
}

Result<TplHow> TplHow::from_pod(const Pod& whole) {
    return TplHow{.close = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "close")))), .delims = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "delims")))), .open = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "open")))), .is_raw = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "is_raw")))), .first_continues = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "first_continues"))))};
}


void TplRead::show(Printer& p) const {
    p.record("TplRead", {{"l", l}, {"lines", lines}, {"cur", cur}, {"closing_col", closing_col}, {"closed", closed}, {"at_line_start", at_line_start}, {"going", going}});
}

Pod TplRead::to_pod() const {
    return Pod::record("TplRead", {{"l", prism_rtl::to_pod(l)}, {"lines", prism_rtl::to_pod(lines)}, {"cur", prism_rtl::to_pod(cur)}, {"closing_col", prism_rtl::to_pod(closing_col)}, {"closed", prism_rtl::to_pod(closed)}, {"at_line_start", prism_rtl::to_pod(at_line_start)}, {"going", prism_rtl::to_pod(going)}});
}

Result<TplRead> TplRead::from_pod(const Pod& whole) {
    return TplRead{.l = TRY(prism_rtl::from_pod<Lex>(TRY(prelude::field(whole, "l")))), .lines = TRY(prism_rtl::from_pod<Array<RawLine>>(TRY(prelude::field(whole, "lines")))), .cur = TRY(prism_rtl::from_pod<RawLine>(TRY(prelude::field(whole, "cur")))), .closing_col = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(prelude::field(whole, "closing_col")))), .closed = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "closed")))), .at_line_start = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "at_line_start")))), .going = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "going"))))};
}


/// Fresh: fn Lex, Mode -> Lex
Lex fresh(const Lex& l, const Mode& mode) {
    return Lex{.src = l.src, .pos = l.pos, .diags = l.diags, .mode = mode, .tokens = Array<Tok>{}, .layout = Array<Nat>{}, .frames = Array<Text>{}, .last_ws = true, .lambda_open = false, .pending_open = false, .pending_span = ast::Range{.start = Nat(0u), .end = Nat(0u)}, .line_first = Nat(0u), .mark_line_start = false, .first_line = true, .test_pending = Text::lit(""), .test_depth = std::optional<Nat>{}, .check_depth = std::optional<Nat>{}, .path_next = false};
}


/// Dec: fn Nat -> Nat
Nat dec(const Nat& n) {
    return or_(n.checked_sub(Nat(1u)), Nat(0u));
}


/// Join: fn [Text], Text -> Text
Text join(const Array<Text>& xs, const Text& sep) {
    auto&& _m = index(xs, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& first_ = prism_rtl::some_of(_m);
        return concat(fold(drop(xs, Nat(1u)), Array(std::vector{first_}), [&](const Array<Text>& acc, const Text& x) { return prelude::push(prelude::push(acc, sep), x); }));
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// CharAt: fn Cursor -> Text
Text char_at(const Cursor& c) {
    auto&& _m = step(front(after(c)));
    if (prism_rtl::is_some(_m)) {
        auto&& one = std::get<1>(prism_rtl::some_of(_m));
        return before(one);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Head: fn Text -> Text
Text head(const Text& t) {
    return char_at(front(t));
}


/// AfterFirst: fn Text -> Text
Text after_first(const Text& t) {
    auto&& _m = step(front(t));
    if (prism_rtl::is_some(_m)) {
        auto&& c = std::get<1>(prism_rtl::some_of(_m));
        return after(c);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// LastChar: fn Text -> Text
Text last_char(const Text& t) {
    auto&& _m = step_back(back(t));
    if (prism_rtl::is_some(_m)) {
        auto&& c = std::get<1>(prism_rtl::some_of(_m));
        return after(c);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// BeforeLast: fn Text -> Text
Text before_last(const Text& t) {
    auto&& _m = step_back(back(t));
    if (prism_rtl::is_some(_m)) {
        auto&& c = std::get<1>(prism_rtl::some_of(_m));
        return before(c);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Between: fn Text, Nat, Nat -> Text
Text between(const Text& t, const Nat& a, const Nat& b) {
    auto&& _m = cursor_at(t, b);
    if (prism_rtl::is_some(_m)) {
        auto&& cb = prism_rtl::some_of(_m);
        auto&& _m = cursor_at(before(cb), a);
        if (prism_rtl::is_some(_m)) {
            auto&& ca = prism_rtl::some_of(_m);
            return after(ca);
        }
        if (prism_rtl::is_none(_m)) {
            return Text::lit("");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?AfterPrefix: fn Text, Text -> ?Text
std::optional<Text> after_prefix(const Text& t, const Text& p_) {
    auto&& _m = cursor_at(t, len_text(p_));
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        return before(c) == p_ ? std::optional(after(c)) : std::optional<Text>{};
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// HasPrefix: fn Text, Text -> Bool
bool has_prefix(const Text& t, const Text& p_) {
    return after_prefix(t, p_) != std::optional<Text>{};
}


/// DropPrefix: fn Text, Text -> Text
Text drop_prefix(const Text& t, const Text& p_) {
    return or_(after_prefix(t, p_), t);
}


/// ?BeforeSuffix: fn Text, Text -> ?Text
std::optional<Text> before_suffix(const Text& t, const Text& s) {
    auto&& _m = len_text(t).checked_sub(len_text(s));
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        auto&& _m = cursor_at(t, n);
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            return after(c) == s ? std::optional(before(c)) : std::optional<Text>{};
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<Text>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// HasSuffix: fn Text, Text -> Bool
bool has_suffix(const Text& t, const Text& s) {
    return before_suffix(t, s) != std::optional<Text>{};
}


/// MapChars: fn Text, (fn Text -> Text) -> Text
Text map_chars(const Text& t, const prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>& f_fn) {
    return concat(fold_chars(t, Array<Text>{}, ({
        auto f_fn_1 = f_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto f_fn_1_2 = f_fn_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                call_value(f_fn_1_2(c), [=](Text f_7681) { return prism_rtl::finished(prelude::push(acc, f_7681)); });
            });
        }));
        });
    })));
    })));
}


/// CountChars: fn Text -> Nat
Nat count_chars(const Text& t) {
    return fold_chars(t, Nat(0u), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=](std::tuple<Nat, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto n = p0;
                static_cast<void>(p1);
                (prism_rtl::finished(n + Nat(1u)));
            });
        });
    })));
}


/// ColumnOf: fn Text, Nat, Nat -> Nat
Nat column_of(const Text& text, const Nat& from, const Nat& offset) {
    return count_chars(between(text, from, offset));
}


/// AllChars: fn Text, (fn Text -> Bool) -> Bool
bool all_chars(const Text& t, const prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>& p__fn) {
    return fold_chars(t, true, ({
        auto p__fn_1 = p__fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=](std::tuple<bool, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto p__fn_1_2 = p__fn_1;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto c = p1;
                (prism_rtl::finished(ok && run_to_end(p__fn_1_2(c))));
            });
        }));
        });
    })));
    }));
}


/// TrimLeading: fn Text, Text -> Text
Text trim_leading(const Text& t, const Text& set) {
    auto c = ({
        Cursor this_ = front(t);
        while (true) {
            auto&& _m = step(this_);
            if (!(prism_rtl::is_some(_m))) break;
            auto&& next = std::get<1>(prism_rtl::some_of(_m));
            if (!contains(set, char_at(this_))) {
                break;
            }
            this_ = next;
        }
        this_;
    });
    return after(c);
}


/// TrimTrailing: fn Text, Text -> Text
Text trim_trailing(const Text& t, const Text& set) {
    auto c = ({
        Cursor this_ = back(t);
        Nat fuel = len_text(t);
        while (true) {
            auto&& _m = fuel.checked_sub(Nat(1u));
            if (!(prism_rtl::is_some(_m))) break;
            auto&& left = prism_rtl::some_of(_m);
            fuel = left;
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = step_back(this_);
                if (prism_rtl::is_some(_m)) {
                    auto&& prev = std::get<1>(prism_rtl::some_of(_m));
                    if (contains(set, char_at(prev))) {
                        _v.set(({
                            this_ = prev;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        fuel = Nat(0u);
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
        }
        this_;
    });
    return before(c);
}


/// TrimStart: fn Text -> Text
Text trim_start(const Text& t) {
    return trim_leading(t, Text::lit(" \r"));
}


/// TrimEnd: fn Text -> Text
Text trim_end(const Text& t) {
    return trim_trailing(t, Text::lit(" \r"));
}


/// Trim: fn Text -> Text
Text trim(const Text& t) {
    return trim_end(trim_start(t));
}


/// LeadingIn: fn Text, Text -> Nat
Nat leading_in(const Text& t, const Text& set) {
    return or_(len_text(t).checked_sub(len_text(trim_leading(t, set))), Nat(0u));
}


/// Contains: fn Text, Text -> Bool
bool contains(const Text& set, const Text& c) {
    return (c != Text::lit("")) && (len(split(set, c)) > Nat(1u));
}


/// IsDigit: fn Text -> Bool
bool is_digit(const Text& c) {
    return (Text::lit("0") <= c) && (c <= Text::lit("9"));
}


/// IsUpper: fn Text -> Bool
bool is_upper(const Text& c) {
    return (Text::lit("A") <= c) && (c <= Text::lit("Z"));
}


/// IsLower: fn Text -> Bool
bool is_lower(const Text& c) {
    return (Text::lit("a") <= c) && (c <= Text::lit("z"));
}


/// IsIdentStart: fn Text -> Bool
bool is_ident_start(const Text& c) {
    return (is_lower(c) || is_upper(c)) || (c == Text::lit("_"));
}


/// IsIdentChar: fn Text -> Bool
bool is_ident_char(const Text& c) {
    return is_ident_start(c) || is_digit(c);
}


/// IsHexDigit: fn Text -> Bool
bool is_hex_digit(const Text& c) {
    return (is_digit(c) || ((Text::lit("a") <= c) && (c <= Text::lit("f")))) || ((Text::lit("A") <= c) && (c <= Text::lit("F")));
}


/// IsNonAscii: fn Text -> Bool
bool is_non_ascii(const Text& c) {
    return c > Text::lit("");
}


/// IsSigilChar: fn Text -> Bool
bool is_sigil_char(const Text& c) {
    return contains(Text::lit("$!@?~&"), c);
}


/// IsSpaceChar: fn Text -> Bool
bool is_space_char(const Text& c) {
    return (((c == Text::lit(" ")) || (c == Text::lit("\n"))) || (c == Text::lit("\r"))) || (c == Text::lit("\t"));
}


/// IsReservedCtor: fn Text -> Bool
bool is_reserved_ctor(const Text& w) {
    return (w == Text::lit("templatetext")) || (w == Text::lit("templateplaceholder"));
}


/// let asciiText
Text ascii_text() {
    return Text::lit("\000\t\n\r !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"sv);
}


/// let hexDigits
Text hex_digits_value() {
    return Text::lit("0123456789abcdef");
}


/// CharAtByte: fn Text, Nat -> Text
Text char_at_byte(const Text& t, const Nat& n) {
    auto&& _m = cursor_at(t, n);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        return char_at(c);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// HexValue: fn Text -> Nat
Nat hex_value(const Text& c) {
    auto l = prelude::lower(c);
    return l == Text::lit("")
        ? Nat(16u)
        : len_text(or_(index(split(hex_digits_value(), l), Nat(0u)), hex_digits_value()));
}


/// ?ParseHex: fn Text -> ?Nat
std::optional<Nat> parse_hex(const Text& t) {
    return ({
        __label__ g11762;
        prism_rtl::Slot<std::optional<Nat>> g11762_v;
        {
            if (!((t != Text::lit("")) && all_chars(t, ({
                auto f = prism_rtl::rc(is_hex_digit);
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text a0) {
                return ({
                    auto f_1 = f;
                    once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                });
            })));
            })))) {
                { g11762_v.set(std::nullopt); goto g11762; }
            }
            g11762_v.set(std::optional(fold_chars(t, Nat(0u), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=](std::tuple<Nat, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return once_job([=]() {
                    return ({
                        auto n = p0;
                        auto c = p1;
                        (prism_rtl::finished((n * Nat(16u)) + hex_value(c)));
                    });
                });
            })))));
        }
    g11762:
        g11762_v.take();
    });
}


/// ?AsciiChar: fn Nat -> ?Text
std::optional<Text> ascii_char(const Nat& n) {
    return n < Nat(128u)
        ? std::optional(char_at_byte(ascii_text(), n))
        : std::optional<Text>{};
}


/// Rest: fn Lex -> Text
Text rest(const Lex& l) {
    auto&& _m = cursor_at(l.src, l.pos);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        return after(c);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Peek: fn Lex -> Text
Text peek(const Lex& l) {
    return char_at_byte(l.src, l.pos);
}


/// PeekAt: fn Lex, Nat -> Text
Text peek_at(const Lex& l, const Nat& n) {
    auto rest_ = ({
        Text this_ = rest(l);
        Nat k = n;
        while (true) {
            auto&& _m = k.checked_sub(Nat(1u));
            if (!(prism_rtl::is_some(_m))) break;
            auto&& left = prism_rtl::some_of(_m);
            k = left;
            this_ = after_first(this_);
        }
        this_;
    });
    return head(rest_);
}


/// StartsWith: fn Lex, Text -> Bool
bool starts_with(const Lex& l, const Text& s) {
    return has_prefix(rest(l), s);
}


/// Slice: fn Lex, Nat, Nat -> Text
Text slice(const Lex& l, const Nat& a, const Nat& b) {
    return between(l.src, a, b);
}


/// Bump: fn Lex -> Lex
Lex bump(const Lex& l) {
    Lex this_ = l;
    this_.pos = this_.pos + len_text(peek(this_));
    return this_;
}


/// Forward: fn Lex, Nat -> Lex
Lex forward(const Lex& l, const Nat& n) {
    Lex this_ = l;
    Nat k = n;
    while (true) {
        auto&& _m = k.checked_sub(Nat(1u));
        if (!(prism_rtl::is_some(_m))) break;
        auto&& left = prism_rtl::some_of(_m);
        k = left;
        this_.pos = this_.pos + len_text(peek(this_));
    }
    return this_;
}


/// NextIsSpace: fn Lex, Nat -> Bool
bool next_is_space(const Lex& l, const Nat& n) {
    auto c = peek_at(l, n);
    return (c == Text::lit("")) || is_space_char(c);
}


/// LineEnd: fn Lex -> Nat
Nat line_end(const Lex& l) {
    auto&& _m = cursor_at(l.src, l.pos);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        auto end = ({
            Cursor this_ = c;
            while (true) {
                auto&& _m = step(this_);
                if (!(prism_rtl::is_some(_m))) break;
                auto&& ch = std::get<0>(prism_rtl::some_of(_m));
                auto&& next = std::get<1>(prism_rtl::some_of(_m));
                if (!(ch != U'\n')) {
                    break;
                }
                this_ = next;
            }
            this_;
        });
        return at(end);
    }
    if (prism_rtl::is_none(_m)) {
        return l.pos;
    }
    prism_rtl::unreachable("no arm matched");
}


/// RestOfLine: unbounded fn Lex -> Text
Text rest_of_line(const Lex& l) {
    return slice(l, l.pos, line_end(l));
}


prism_rtl::Turn<Text> RestOfLine::cycle() const {
    const auto& l = this->l;
    return prism_rtl::finished(slice(l, l.pos, line_end(l)));
}


/// `Start RestOfLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rest_of_line(Lex l) {
    return prism_rtl::make_rc<RestOfLine>(l);
}


/// LexErr: fn Lex, Nat, Nat, Text -> Lex
Lex lex_err(const Lex& l, const Nat& start, const Nat& end, const Text& message) {
    Lex this_ = l;
    this_.diags = prelude::push(this_.diags, lex_diag(ast::Range{.start = start, .end = prelude::max(end, start)}, message));
    return this_;
}


/// LexDiag: fn Range, Text -> Diag
ast::Diag lex_diag(const ast::Range& span, const Text& message) {
    return ast::Diag{.stage = Text::lit("lex"), .span = span, .message = message, .feature = std::optional<Text>{}};
}


/// IsLayoutOrEof: fn TokKind -> Bool
bool is_layout_or_eof(const TokKind& tok_kind0) {
    if (prism_rtl::is<TokKind::KLayOpen>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KLaySep>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KLayClose>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KEof>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// IsLayout: fn TokKind -> Bool
bool is_layout(const TokKind& tok_kind0) {
    if (prism_rtl::is<TokKind::KLayOpen>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KLaySep>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KLayClose>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// EndsOperand: fn TokKind -> Bool
bool ends_operand(const TokKind& tok_kind0) {
    if (prism_rtl::is<TokKind::KName>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KFamily>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KInt>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KFloat>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KDuration>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KChar>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KText>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KTemplate>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KClose>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KGtGt>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KNonEmpty>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KAbsent>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KKw>(tok_kind0)) {
        auto&& w = prism_rtl::as<TokKind::KKw>(tok_kind0).a0;
        return is_value_word(w);
    }
    {
        return false;
    }
}


/// IsValueWord: fn Text -> Bool
bool is_value_word(const Text& w) {
    return ((w == Text::lit("unit")) || (w == Text::lit("nil"))) || is_bound_word(w);
}


/// IsBoundWord: fn Text -> Bool
bool is_bound_word(const Text& w) {
    return (((w == Text::lit("key")) || (w == Text::lit("ix"))) || (w == Text::lit("jx"))) || (w == Text::lit("kx"));
}


/// let keywordList
Array<Text> keyword_list() {
    return Array(std::vector{Text::lit("module"), Text::lit("emit"), Text::lit("use"), Text::lit("type"), Text::lit("record"), Text::lit("choice"), Text::lit("row"), Text::lit("tag"), Text::lit("of"), Text::lit("derive"), Text::lit("trait"), Text::lit("impl"), Text::lit("where"), Text::lit("any"), Text::lit("let"), Text::lit("fn"), Text::lit("test"), Text::lit("check"), Text::lit("widget"), Text::lit("rebuild"), Text::lit("for"), Text::lit("given"), Text::lit("monad"), Text::lit("update"), Text::lit("while"), Text::lit("match"), Text::lit("if"), Text::lit("else"), Text::lit("otherwise"), Text::lit("require"), Text::lit("forbid"), Text::lit("return"), Text::lit("ignore"), Text::lit("then"), Text::lit("on"), Text::lit("not"), Text::lit("and"), Text::lit("or"), Text::lit("mod"), Text::lit("as"), Text::lit("output"), Text::lit("inline_text"), Text::lit("raw"), Text::lit("unbounded"), Text::lit("unit"), Text::lit("nil"), Text::lit("key"), Text::lit("ix"), Text::lit("jx"), Text::lit("kx")});
}


/// let keywordSet
Map<Text, bool> keyword_set() {
    return map(each(keyword_list(), [&](const Text& w) { return std::tuple{w, true}; }));
}


/// IsKeyword: fn Text -> Bool
bool is_keyword(const Text& w) {
    return prelude::get(keyword_set(), w) != std::optional<bool>{};
}


/// let opTable
Array<Text> op_table() {
    return Array(std::vector{Text::lit("==>"), Text::lit("<-"), Text::lit("<="), Text::lit("<|"), Text::lit("->"), Text::lit("-="), Text::lit("-?"), Text::lit("+="), Text::lit("+?"), Text::lit("*="), Text::lit("*?"), Text::lit("/="), Text::lit("=="), Text::lit(">="), Text::lit("=>"), Text::lit("<"), Text::lit(">"), Text::lit("-"), Text::lit("+"), Text::lit("*"), Text::lit("/"), Text::lit("=")});
}


/// TakesSuffix: fn Text -> Bool
bool takes_suffix(const Text& op) {
    return fold(Array(std::vector{Text::lit("<="), Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit(">"), Text::lit(">="), Text::lit("+"), Text::lit("-"), Text::lit("*"), Text::lit("/"), Text::lit("+?"), Text::lit("-?"), Text::lit("*?")}), false, [&](const bool& seen, const Text& o) { return seen || (o == op); });
}


/// CloseChar: fn Text -> Text
Text close_char(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("(")) {
            return Text::lit(")");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("[")) {
            return Text::lit("]");
        }
    }
    {
        return Text::lit("}");
    }
}


/// OpenOf: fn Text -> Text
Text open_of(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit(")")) {
            return Text::lit("(");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("]")) {
            return Text::lit("[");
        }
    }
    {
        return Text::lit("{");
    }
}


/// PrefixPosition: fn Lex -> Bool
bool prefix_position(const Lex& l) {
    return l.last_ws || no_operand_before(last(l->tokens));
}


/// NoOperandBefore: fn ?Tok -> Bool
bool no_operand_before(const std::optional<Tok>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return true;
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& t = prism_rtl::some_of(opt0);
        return !ends_operand(t.kind);
    }
    prism_rtl::unreachable("no arm matched");
}


/// TestWordOf: fn TokKind -> Text
Text test_word_of(const TokKind& tok_kind0) {
    if (prism_rtl::is<TokKind::KKw>(tok_kind0)) {
        auto&& c0_0_0 = prism_rtl::as<TokKind::KKw>(tok_kind0).a0;
        if (c0_0_0 == Text::lit("test")) {
            return Text::lit("test");
        }
    }
    if (prism_rtl::is<TokKind::KKw>(tok_kind0)) {
        auto&& c1_0_0 = prism_rtl::as<TokKind::KKw>(tok_kind0).a0;
        if (c1_0_0 == Text::lit("check")) {
            return Text::lit("check");
        }
    }
    {
        return Text::lit("");
    }
}


/// AllLayout: fn [Tok] -> Bool
bool all_layout(const Array<Tok>& ts) {
    return fold(ts, true, [&](const bool& ok, const Tok& t) { return ok && is_layout(t.kind); });
}


/// PushTok: fn Lex, TokKind, Nat, Nat -> Lex
Lex push_tok(const Lex& l, const TokKind& kind, const Nat& start, const Nat& end) {
    Lex this_ = l;
    auto layout = is_layout_or_eof(kind);
    auto touches = ((!this_.last_ws) && (len(this_.tokens) > Nat(0u))) && (!layout);
    auto line_start = (!layout) && this_.mark_line_start;
    if (!layout) {
        this_.mark_line_start = false;
    }
    auto word = test_word_of(kind);
    if ((((word != Text::lit("")) && (this_.mode == Mode(Mode::MFile{}))) && (len(this_.layout) == Nat(1u))) && all_layout(drop(this_.tokens, this_.line_first))) {
        this_.test_pending = word;
    }
    this_.tokens = prelude::push(this_.tokens, Tok{.kind = kind, .span = ast::Range{.start = start, .end = end}, .touches = touches, .line_start = line_start});
    this_.last_ws = false;
    return this_;
}


/// LayoutOn: fn Mode -> Bool
bool layout_on(const Mode& mode0) {
    if (prism_rtl::is<Mode::MFile>(mode0)) {
        return true;
    }
    if (prism_rtl::is<Mode::MBrace>(mode0)) {
        return true;
    }
    {
        return false;
    }
}


/// LayoutActive: fn Lex -> Bool
bool layout_active(const Lex& l) {
    return layout_on(l.mode) && (len(l.frames) == Nat(0u));
}


/// FatArrowOn: fn Lex -> Bool
bool fat_arrow_on(const Lex& l) {
    return (l.test_depth != std::optional<Nat>{}) || (l.check_depth != std::optional<Nat>{});
}


/// LexFile: unbounded fn Text -> Lexed
Lexed lex_file(const Text& src) {
    auto start = Lex{.src = src, .pos = Nat(0u), .diags = Array<ast::Diag>{}, .mode = Mode(Mode::MFile{}), .tokens = Array<Tok>{}, .layout = Array<Nat>{}, .frames = Array<Text>{}, .last_ws = true, .lambda_open = false, .pending_open = false, .pending_span = ast::Range{.start = Nat(0u), .end = Nat(0u)}, .line_first = Nat(0u), .mark_line_start = false, .first_line = true, .test_pending = Text::lit(""), .test_depth = std::optional<Nat>{}, .check_depth = std::optional<Nat>{}, .path_next = false};
    auto skipped = skip_blank_and_comment_lines(start);
    auto opened = (peek(skipped) == Text::lit("<")) && (template_tag_ahead(skipped) != Text::lit(""));
    auto [head_, l] = opened ? template_head(skipped) : std::tuple{Array<Tok>{}, start};
    auto body = lex_stream(fresh(l, Mode(Mode::MFile{})));
    return Lexed{.tokens = append(head_, body->tokens), .diags = body.diags};
}


prism_rtl::Turn<Lexed> LexFile::cycle() const {
    const auto& src = this->src;
    auto start = Lex{.src = src, .pos = Nat(0u), .diags = Array<ast::Diag>{}, .mode = Mode(Mode::MFile{}), .tokens = Array<Tok>{}, .layout = Array<Nat>{}, .frames = Array<Text>{}, .last_ws = true, .lambda_open = false, .pending_open = false, .pending_span = ast::Range{.start = Nat(0u), .end = Nat(0u)}, .line_first = Nat(0u), .mark_line_start = false, .first_line = true, .test_pending = Text::lit(""), .test_depth = std::optional<Nat>{}, .check_depth = std::optional<Nat>{}, .path_next = false};
    return call_then(start_skip_blank_and_comment_lines(start), [=](Lex skip_blank_and_comment_lines_19470) {
        return ({
            auto skipped = skip_blank_and_comment_lines_19470;
            auto opened = (peek(skipped) == Text::lit("<")) && (template_tag_ahead(skipped) != Text::lit(""));
            auto [head_, l] = opened ? template_head(skipped) : std::tuple{Array<Tok>{}, start};
            call_then(start_lex_stream(fresh(l, Mode(Mode::MFile{}))), [=](Lex lex_stream_19668) {
            return ({
                auto body = lex_stream_19668;
                (prism_rtl::finished(Lexed{.tokens = append(head_, body->tokens), .diags = body.diags}));
            });
        });
        });
    });
}


/// `Start LexFile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lexed> start_lex_file(Text src) {
    return prism_rtl::make_rc<LexFile>(src);
}


/// TemplateHead: unbounded fn Lex -> (([Tok], Lex))
std::tuple<Array<Tok>, Lex> template_head(const Lex& l0) {
    auto [kind, l] = lex_template(l0, Text::lit("File"), l0.pos);
    auto tok = Tok{.kind = kind, .span = ast::Range{.start = l0.pos, .end = l.pos}, .touches = false, .line_start = false};
    return std::tuple{Array(std::vector{tok}), l};
}


prism_rtl::Turn<std::tuple<Array<Tok>, Lex>> TemplateHead::cycle() const {
    const auto& l0 = this->l0;
    auto l0_1 = l0;
    return call_then(start_lex_template(l0_1, Text::lit("File"), l0_1.pos), [=](std::tuple<TokKind, Lex> lex_template_19920) {
        return ({
            auto [kind, l] = lex_template_19920;
            auto tok = Tok{.kind = kind, .span = ast::Range{.start = l0_1.pos, .end = l.pos}, .touches = false, .line_start = false};
            (prism_rtl::finished(std::tuple{Array(std::vector{tok}), l}));
        });
    });
}


/// `Start TemplateHead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Tok>, Lex>> start_template_head(Lex l0) {
    return prism_rtl::make_rc<TemplateHead>(l0);
}


/// SkipBlankAndCommentLines: unbounded fn Lex -> Lex
Lex skip_blank_and_comment_lines(const Lex& l) {
    Lex this_ = l;
    bool going = true;
    while (going) {
        auto line = rest_of_line(this_);
        auto t = trim_start(line);
        if (((t == Text::lit("")) || (head(t) == Text::lit("#"))) && ((this_.pos + len_text(line)) < len_text(this_.src))) {
            this_.pos = this_.pos + (len_text(line) + Nat(1u));
        } else  {
            going = false;
        }
    }
    return this_;
}


prism_rtl::Turn<Lex> SkipBlankAndCommentLines::cycle() const {
    const auto& l = this->l;
    Lex this_ = l;
    bool going = true;
    return call_then(loop_job(std::tuple{this_, going}, [=](std::tuple<Lex, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        return going
            ? ({
            auto line = rest_of_line(this_);
            auto t = trim_start(line);
            if (((t == Text::lit("")) || (head(t) == Text::lit("#"))) && ((this_.pos + len_text(line)) < len_text(this_.src))) {
                this_.pos = this_.pos + (len_text(line) + Nat(1u));
            } else  {
                going = false;
            }
            Expected<std::tuple<Lex, bool>, std::tuple<Lex, bool>>(std::tuple{this_, going});
        })
            : Expected<std::tuple<Lex, bool>, std::tuple<Lex, bool>>(unexpected(std::tuple{this_, going}));
    }), [=](std::tuple<Lex, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        return prism_rtl::finished(this_);
    });
}


/// `Start SkipBlankAndCommentLines, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lex> start_skip_blank_and_comment_lines(Lex l) {
    return prism_rtl::make_rc<SkipBlankAndCommentLines>(l);
}


/// Nested: unbounded fn Lex, Mode -> (([Tok], Lex))
std::tuple<Array<Tok>, Lex> nested(const Lex& l, const Mode& mode) {
    auto inner = lex_stream(fresh(l, mode));
    auto back_ = ({
        Lex this_ = l;
        this_.pos = inner.pos;
        this_.diags = inner.diags;
        this_;
    });
    return std::tuple{inner->tokens, back_};
}


prism_rtl::Turn<std::tuple<Array<Tok>, Lex>> Nested::cycle() const {
    const auto& l = this->l;
    const auto& mode = this->mode;
    auto l_1 = l;
    auto mode_2 = mode;
    return call_then(start_lex_stream(fresh(l_1, mode_2)), [=](Lex lex_stream_20643) {
        return ({
            auto inner = lex_stream_20643;
            auto back_ = ({
                Lex this_ = l_1;
                this_.pos = inner.pos;
                this_.diags = inner.diags;
                this_;
            });
            (prism_rtl::finished(std::tuple{inner->tokens, back_}));
        });
    });
}


/// `Start Nested, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Tok>, Lex>> start_nested(Lex l, Mode mode) {
    return prism_rtl::make_rc<Nested>(l, mode);
}


/// LexStream: unbounded fn Lex -> Lex
Lex lex_stream(const Lex& l0) {
    Lex this_ = l0;
    bool at_line_start = layout_on(this_.mode);
    bool done = false;
    while (!done) {
        bool go = true;
        if (at_line_start && layout_active(this_)) {
            at_line_start = false;
            auto [l, verdict] = begin_line(this_);
            this_ = l;
            if (verdict == Text::lit("skip")) {
                at_line_start = true;
                go = false;
            }
            if (verdict == Text::lit("end")) {
                done = true;
                go = false;
            }
        }
        if (go) {
            auto c = peek(this_);
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                {
                    auto&& u21471_0 = c;
                    if (u21471_0 == Text::lit("")) {
                        _v.set(({
                            this_ = unclosed_stream(this_);
                            done = true;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u21471_1 = c;
                    if (u21471_1 == Text::lit("\n")) {
                        _v.set(({
                            this_.pos = this_.pos + Nat(1u);
                            this_.last_ws = true;
                            if (this_.lambda_open) {
                                this_ = lex_err(this_, dec(this_.pos), this_.pos, Text::lit("a lambda's parameter list closes with `|` on its own line"));
                                this_.lambda_open = false;
                            }
                            if (layout_active(this_)) {
                                this_ = end_line(this_);
                                at_line_start = true;
                            }
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u21471_2 = c;
                    if (u21471_2 == Text::lit(" ")) {
                        _v.set(({
                            this_.pos = this_.pos + Nat(1u);
                            this_.last_ws = true;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u21471_3 = c;
                    if (u21471_3 == Text::lit("\r")) {
                        _v.set(({
                            this_.pos = this_.pos + Nat(1u);
                            this_.last_ws = true;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u21471_4 = c;
                    if (u21471_4 == Text::lit("\t")) {
                        _v.set(({
                            this_.pos = this_.pos + Nat(1u);
                            this_.last_ws = true;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u21471_5 = c;
                    if (u21471_5 == Text::lit("#")) {
                        _v.set(({
                            this_.pos = line_end(this_);
                            this_.last_ws = true;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        auto [ends, l] = stream_ends_here(this_);
                        this_ = l;
                        if (ends) {
                            done = true;
                        } else  {
                            this_ = lex_token(this_);
                        }
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
        }
    }
    if (layout_on(this_.mode)) {
        while (len(this_.layout) > Nat(1u)) {
            this_.layout = pop(this_.layout);
            this_ = push_tok(this_, TokKind(TokKind::KLayClose{}), this_.pos, this_.pos);
        }
    }
    if (this_.mode == Mode(Mode::MFile{})) {
        this_ = push_tok(this_, TokKind(TokKind::KEof{}), this_.pos, this_.pos);
    }
    return this_;
}


prism_rtl::Turn<Lex> LexStream::cycle() const {
    const auto& l0 = this->l0;
    Lex this_ = l0;
    bool at_line_start = layout_on(this_.mode);
    bool done = false;
    return call_then(loop_job(std::tuple{this_, at_line_start, done}, [=](std::tuple<Lex, bool, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto at_line_start = std::get<1>(_p0);
        auto done = std::get<2>(_p0);
        return !done
            ? ({
            bool go = true;
            if (at_line_start && layout_active(this_)) {
                at_line_start = false;
                auto [l, verdict] = begin_line(this_);
                this_ = l;
                if (verdict == Text::lit("skip")) {
                    at_line_start = true;
                    go = false;
                }
                if (verdict == Text::lit("end")) {
                    done = true;
                    go = false;
                }
            }
            if (go) {
                auto c = peek(this_);
                ({
                    __label__ _done;
                    prism_rtl::Slot<Unit> _v;
                    {
                        auto&& u21471_0 = c;
                        if (u21471_0 == Text::lit("")) {
                            _v.set(({
                                this_ = unclosed_stream(this_);
                                done = true;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u21471_1 = c;
                        if (u21471_1 == Text::lit("\n")) {
                            _v.set(({
                                this_.pos = this_.pos + Nat(1u);
                                this_.last_ws = true;
                                if (this_.lambda_open) {
                                    this_ = lex_err(this_, dec(this_.pos), this_.pos, Text::lit("a lambda's parameter list closes with `|` on its own line"));
                                    this_.lambda_open = false;
                                }
                                if (layout_active(this_)) {
                                    this_ = end_line(this_);
                                    at_line_start = true;
                                }
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u21471_2 = c;
                        if (u21471_2 == Text::lit(" ")) {
                            _v.set(({
                                this_.pos = this_.pos + Nat(1u);
                                this_.last_ws = true;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u21471_3 = c;
                        if (u21471_3 == Text::lit("\r")) {
                            _v.set(({
                                this_.pos = this_.pos + Nat(1u);
                                this_.last_ws = true;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u21471_4 = c;
                        if (u21471_4 == Text::lit("\t")) {
                            _v.set(({
                                this_.pos = this_.pos + Nat(1u);
                                this_.last_ws = true;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u21471_5 = c;
                        if (u21471_5 == Text::lit("#")) {
                            _v.set(({
                                this_.pos = line_end(this_);
                                this_.last_ws = true;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        _v.set(({
                            auto [ends, l] = stream_ends_here(this_);
                            this_ = l;
                            if (ends) {
                                done = true;
                            } else  {
                                this_ = lex_token(this_);
                            }
                            Unit{};
                        }));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            }
            Expected<std::tuple<Lex, bool, bool>, std::tuple<Lex, bool, bool>>(std::tuple{this_, at_line_start, done});
        })
            : Expected<std::tuple<Lex, bool, bool>, std::tuple<Lex, bool, bool>>(unexpected(std::tuple{this_, at_line_start, done}));
    }), [=](std::tuple<Lex, bool, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto at_line_start = std::get<1>(_p0);
        auto done = std::get<2>(_p0);
        return ({
            auto k_if22861 = [=](std::tuple<Lex, bool, bool> _p0) {
                auto this_ = std::get<0>(_p0);
                auto at_line_start = std::get<1>(_p0);
                auto done = std::get<2>(_p0);
                return ({
                    if (this_.mode == Mode(Mode::MFile{})) {
                        this_ = push_tok(this_, TokKind(TokKind::KEof{}), this_.pos, this_.pos);
                    }
                    (prism_rtl::finished(this_));
                });
            };
            layout_on(this_.mode)
            ? call_then(loop_job(std::tuple{this_, at_line_start, done}, [=](std::tuple<Lex, bool, bool> _p0) {
            auto this_ = std::get<0>(_p0);
            auto at_line_start = std::get<1>(_p0);
            auto done = std::get<2>(_p0);
            return len(this_.layout) > Nat(1u)
                ? ({
                this_.layout = pop(this_.layout);
                this_ = push_tok(this_, TokKind(TokKind::KLayClose{}), this_.pos, this_.pos);
                Expected<std::tuple<Lex, bool, bool>, std::tuple<Lex, bool, bool>>(std::tuple{this_, at_line_start, done});
            })
                : Expected<std::tuple<Lex, bool, bool>, std::tuple<Lex, bool, bool>>(unexpected(std::tuple{this_, at_line_start, done}));
        }), [=](std::tuple<Lex, bool, bool> _p0) {
            auto this_ = std::get<0>(_p0);
            auto at_line_start = std::get<1>(_p0);
            auto done = std::get<2>(_p0);
            return k_if22861(std::tuple{this_, at_line_start, done});
        })
            : k_if22861(std::tuple{this_, at_line_start, done});
        });
    });
}


/// `Start LexStream, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lex> start_lex_stream(Lex l0) {
    return prism_rtl::make_rc<LexStream>(l0);
}


/// UnclosedStream: fn Lex -> Lex
Lex unclosed_stream(const Lex& l) {
    auto&& _m = l.mode;
    if (prism_rtl::is<Mode::MFile>(_m)) {
        return l;
    }
    if (prism_rtl::is<Mode::MBrace>(_m)) {
        return lex_err(l, l.pos, l.pos, Text::lit("a brace block never closes: expected its closing delimiter alone on a line"));
    }
    if (prism_rtl::is<Mode::MPlaceholder>(_m)) {
        auto&& m23137_2_0 = prism_rtl::as<Mode::MPlaceholder>(_m).a0;
        if (m23137_2_0 == Text::lit("single")) {
            return lex_err(l, l.pos, l.pos, Text::lit("a placeholder never closes: expected `}`"));
        }
    }
    if (prism_rtl::is<Mode::MPlaceholder>(_m)) {
        return lex_err(l, l.pos, l.pos, Text::lit("a placeholder never closes: expected `}}`"));
    }
    if (prism_rtl::is<Mode::MPathKey>(_m)) {
        return lex_err(l, l.pos, l.pos, Text::lit("a path key never closes: expected `]`"));
    }
    prism_rtl::unreachable("no arm matched");
}


/// StreamEndsHere: fn Lex -> ((Bool, Lex))
std::tuple<bool, Lex> stream_ends_here(const Lex& l) {
    auto c = peek(l);
    auto closes = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = l.mode;
        if (prism_rtl::is<Mode::MPlaceholder>(_m)) {
            auto&& m23737_0_0 = prism_rtl::as<Mode::MPlaceholder>(_m).a0;
            if (m23737_0_0 == Text::lit("single")) {
                _v.set(c == Text::lit("}"));
                goto _done;
            }
        }
        if (prism_rtl::is<Mode::MPlaceholder>(_m)) {
            auto&& m23737_1_0 = prism_rtl::as<Mode::MPlaceholder>(_m).a0;
            if (m23737_1_0 == Text::lit("double")) {
                _v.set(starts_with(l, Text::lit("}}")));
                goto _done;
            }
        }
        if (prism_rtl::is<Mode::MPathKey>(_m)) {
            _v.set(c == Text::lit("]"));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto width = l.mode == Mode(Mode::MPlaceholder{Text::lit("double")}) ? Nat(2u) : Nat(1u);
    return (len(l.frames) == Nat(0u)) && closes
        ? std::tuple{true, lexer::forward(l, width)}
        : std::tuple{false, l};
}


/// EndLine: fn Lex -> Lex
Lex end_line(const Lex& l) {
    auto&& _m = last(l->tokens);
    if (prism_rtl::is_some(_m)) {
        auto&& t = prism_rtl::some_of(_m);
        if ((len(l->tokens) > l.line_first) && opens_block(t.kind)) {
            Lex this_ = l;
            this_.pending_open = true;
            this_.pending_span = t.span;
            return this_;
        }
    }
    {
        return l;
    }
}


/// OpensBlock: fn TokKind -> Bool
bool opens_block(const TokKind& tok_kind0) {
    if (prism_rtl::is<TokKind::KColon>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KLambdaBar>(tok_kind0) && !prism_rtl::as<TokKind::KLambdaBar>(tok_kind0).a0) {
        return true;
    }
    {
        return false;
    }
}


/// BeginLine: unbounded fn Lex -> ((Lex, Text))
std::tuple<Lex, Text> begin_line(const Lex& l0) {
    auto line_begin = l0.pos;
    auto [l1, col] = indentation(l0);
    auto&& _m = peek(l1);
    {
        auto&& m25088_0 = _m;
        if (m25088_0 == Text::lit("")) {
            return std::tuple{l1, Text::lit("end")};
        }
    }
    {
        auto&& m25088_1 = _m;
        if (m25088_1 == Text::lit("\n")) {
            return std::tuple{bump(l1), Text::lit("skip")};
        }
    }
    {
        auto&& m25088_2 = _m;
        if (m25088_2 == Text::lit("#")) {
            auto l2 = ({
                Lex this_ = l1;
                this_.pos = line_end(this_);
                this_;
            });
            return peek(l2) == Text::lit("\n")
                ? std::tuple{bump(l2), Text::lit("skip")}
                : std::tuple{l2, Text::lit("end")};
        }
    }
    {
        return closes_brace_block(l1)
            ? std::tuple{skip_line(l1), Text::lit("end")}
            : ({
            auto l2 = indented_line(l1, col, line_begin);
            std::tuple{l2, Text::lit("tokens")};
        });
    }
}


prism_rtl::Turn<std::tuple<Lex, Text>> BeginLine::cycle() const {
    const auto& l0 = this->l0;
    auto line_begin = l0.pos;
    auto l0_1 = l0;
    return call_then(start_indentation(l0_1), [=](std::tuple<Lex, Nat> indentation_25069) {
        return ({
            auto [l1, col] = indentation_25069;
            ({
            auto&& _m = peek(l1);
            ({
            auto&& m25088_0 = _m;
            (m25088_0 == Text::lit(""));
        }) ? ({
            auto&& m25088_0 = _m;
            prism_rtl::finished(std::tuple{l1, Text::lit("end")});
        })
            : ({
            auto&& m25088_1 = _m;
            (m25088_1 == Text::lit("\n"));
        }) ? ({
            auto&& m25088_1 = _m;
            prism_rtl::finished(std::tuple{bump(l1), Text::lit("skip")});
        })
            : ({
            auto&& m25088_2 = _m;
            (m25088_2 == Text::lit("#"));
        }) ? ({
            auto&& m25088_2 = _m;
            ({
            auto l2 = ({
                Lex this_ = l1;
                this_.pos = line_end(this_);
                this_;
            });
            peek(l2) == Text::lit("\n")
            ? prism_rtl::finished(std::tuple{bump(l2), Text::lit("skip")})
            : prism_rtl::finished(std::tuple{l2, Text::lit("end")});
        });
        })
            : call_then(start_closes_brace_block(l1), [=](bool closes_brace_block_25443) {
            return closes_brace_block_25443
                ? call_then(start_skip_line(l1), [=](Lex skip_line_25466) { return prism_rtl::finished(std::tuple{skip_line_25466, Text::lit("end")}); })
                : call_then(start_indented_line(l1, col, line_begin), [=](Lex indented_line_25530) {
                return ({
                    auto l2 = indented_line_25530;
                    (prism_rtl::finished(std::tuple{l2, Text::lit("tokens")}));
                });
            });
        });
        });
        });
    });
}


/// `Start BeginLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Lex, Text>> start_begin_line(Lex l0) {
    return prism_rtl::make_rc<BeginLine>(l0);
}


/// Indentation: unbounded fn Lex -> ((Lex, Nat))
std::tuple<Lex, Nat> indentation(const Lex& l0) {
    std::tuple<Lex, Nat> this_ = std::tuple{l0, Nat(0u)};
    Lex l = l0;
    Nat col = Nat(0u);
    bool going = true;
    while (going) {
        ({
            __label__ _done;
            prism_rtl::Slot<Unit> _v;
            auto&& _m = peek(l);
            {
                auto&& u25851_0 = _m;
                if (u25851_0 == Text::lit(" ")) {
                    _v.set(({
                        l = bump(l);
                        col = col + Nat(1u);
                        Unit{};
                    }));
                    goto _done;
                }
            }
            {
                auto&& u25851_1 = _m;
                if (u25851_1 == Text::lit("\t")) {
                    _v.set(({
                        l = lex_err(bump(l), l.pos, l.pos + Nat(1u), Text::lit("a tab in leading whitespace is an error: indent with spaces"));
                        col = col + Nat(1u);
                        Unit{};
                    }));
                    goto _done;
                }
            }
            {
                auto&& u25851_2 = _m;
                if (u25851_2 == Text::lit("\r")) {
                    _v.set(({
                        l = bump(l);
                        Unit{};
                    }));
                    goto _done;
                }
            }
            {
                _v.set(({
                    going = false;
                    Unit{};
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    this_ = std::tuple{l, col};
    return this_;
}


prism_rtl::Turn<std::tuple<Lex, Nat>> Indentation::cycle() const {
    const auto& l0 = this->l0;
    std::tuple<Lex, Nat> this_ = std::tuple{l0, Nat(0u)};
    Lex l = l0;
    Nat col = Nat(0u);
    bool going = true;
    return call_then(loop_job(std::tuple{this_, col, going, l}, [=](std::tuple<std::tuple<Lex, Nat>, Nat, bool, Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        auto col = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto l = std::get<3>(_p0);
        return going
            ? ({
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = peek(l);
                {
                    auto&& u25851_0 = _m;
                    if (u25851_0 == Text::lit(" ")) {
                        _v.set(({
                            l = bump(l);
                            col = col + Nat(1u);
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u25851_1 = _m;
                    if (u25851_1 == Text::lit("\t")) {
                        _v.set(({
                            l = lex_err(bump(l), l.pos, l.pos + Nat(1u), Text::lit("a tab in leading whitespace is an error: indent with spaces"));
                            col = col + Nat(1u);
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u25851_2 = _m;
                    if (u25851_2 == Text::lit("\r")) {
                        _v.set(({
                            l = bump(l);
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        going = false;
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            Expected<std::tuple<std::tuple<Lex, Nat>, Nat, bool, Lex>, std::tuple<std::tuple<Lex, Nat>, Nat, bool, Lex>>(std::tuple{this_, col, going, l});
        })
            : Expected<std::tuple<std::tuple<Lex, Nat>, Nat, bool, Lex>, std::tuple<std::tuple<Lex, Nat>, Nat, bool, Lex>>(unexpected(std::tuple{this_, col, going, l}));
    }), [=](std::tuple<std::tuple<Lex, Nat>, Nat, bool, Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        auto col = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto l = std::get<3>(_p0);
        return ({
            this_ = std::tuple{l, col};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start Indentation, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Lex, Nat>> start_indentation(Lex l0) {
    return prism_rtl::make_rc<Indentation>(l0);
}


/// ClosesBraceBlock: unbounded fn Lex -> Bool
bool closes_brace_block(const Lex& l) {
    auto&& _m = l.mode;
    if (prism_rtl::is<Mode::MBrace>(_m)) {
        auto&& m26329_0_0 = prism_rtl::as<Mode::MBrace>(_m).a0;
        if (m26329_0_0 == Text::lit("double")) {
            return trim_end(rest_of_line(l)) == Text::lit("}}");
        }
    }
    if (prism_rtl::is<Mode::MBrace>(_m)) {
        return trim_end(rest_of_line(l)) == Text::lit("}");
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> ClosesBraceBlock::cycle() const {
    const auto& l = this->l;
    return ({
        auto&& _m = l.mode;
        prism_rtl::is<Mode::MBrace>(_m) && ({
        auto&& m26329_0_0 = prism_rtl::as<Mode::MBrace>(_m).a0;
        (m26329_0_0 == Text::lit("double"));
    }) ? ({
        auto&& m26329_0_0 = prism_rtl::as<Mode::MBrace>(_m).a0;
        ({
        auto l_1 = l;
        call_then(start_rest_of_line(l_1), [=](Text rest_of_line_26374) { return prism_rtl::finished(trim_end(rest_of_line_26374) == Text::lit("}}")); });
    });
    })
        : prism_rtl::is<Mode::MBrace>(_m) ? ({
        auto l_1 = l;
        call_then(start_rest_of_line(l_1), [=](Text rest_of_line_26428) { return prism_rtl::finished(trim_end(rest_of_line_26428) == Text::lit("}")); });
    })
        : prism_rtl::finished(false);
    });
}


/// `Start ClosesBraceBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_closes_brace_block(Lex l) {
    return prism_rtl::make_rc<ClosesBraceBlock>(l);
}


/// SkipLine: unbounded fn Lex -> Lex
Lex skip_line(const Lex& l0) {
    auto l = ({
        Lex this_ = l0;
        this_.pos = line_end(this_);
        this_;
    });
    return peek(l) == Text::lit("\n") ? bump(l) : l;
}


prism_rtl::Turn<Lex> SkipLine::cycle() const {
    const auto& l0 = this->l0;
    auto l = ({
        Lex this_ = l0;
        this_.pos = line_end(this_);
        this_;
    });
    return peek(l) == Text::lit("\n")
        ? prism_rtl::finished(bump(l))
        : prism_rtl::finished(l);
}


/// `Start SkipLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lex> start_skip_line(Lex l0) {
    return prism_rtl::make_rc<SkipLine>(l0);
}


/// IndentedLine: unbounded fn Lex, Nat, Nat -> Lex
Lex indented_line(const Lex& l0, const Nat& col, const Nat& line_begin) {
    auto here = l0.pos;
    auto l = ({
        Lex this_ = l0;
        this_.line_first = len(this_.tokens);
        this_.last_ws = true;
        this_;
    });
    return l.first_line
        ? first_line(l, col, line_begin, here)
        : layout_line(l, col, line_begin, here);
}


prism_rtl::Turn<Lex> IndentedLine::cycle() const {
    const auto& l0 = this->l0;
    const auto& col = this->col;
    const auto& line_begin = this->line_begin;
    auto here = l0.pos;
    auto l = ({
        Lex this_ = l0;
        this_.line_first = len(this_.tokens);
        this_.last_ws = true;
        this_;
    });
    return l.first_line
        ? prism_rtl::finished(first_line(l, col, line_begin, here))
        : prism_rtl::finished(layout_line(l, col, line_begin, here));
}


/// `Start IndentedLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lex> start_indented_line(Lex l0, Nat col, Nat line_begin) {
    return prism_rtl::make_rc<IndentedLine>(l0, col, line_begin);
}


/// FirstLine: fn Lex, Nat, Nat, Nat -> Lex
Lex first_line(const Lex& l0, const Nat& col, const Nat& line_begin, const Nat& here) {
    Lex this_ = l0;
    this_.first_line = false;
    if (this_.mode == Mode(Mode::MFile{})) {
        this_.layout = Array(std::vector{Nat(0u)});
        if (col != Nat(0u)) {
            this_ = lex_err(this_, line_begin, here, Text::lit("the first line of a file starts at column 0"));
            this_.layout = Array(std::vector{col});
        }
    } else  {
        this_.layout = prelude::push(this_.layout, col);
    }
    return this_;
}


/// Below: fn ?Nat, Nat -> Bool
bool below(const std::optional<Nat>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return false;
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& d = prism_rtl::some_of(std::get<0>(_m));
        auto&& depth = std::get<1>(_m);
        return depth < d;
    }
    prism_rtl::unreachable("no arm matched");
}


/// LayoutLine: fn Lex, Nat, Nat, Nat -> Lex
Lex layout_line(const Lex& l0, const Nat& col, const Nat& line_begin, const Nat& here) {
    Lex this_ = l0;
    auto top = or_(last(this_.layout), Nat(0u));
    auto fat = starts_with(this_, Text::lit("=>"));
    bool opened = false;
    Nat fuel = len(this_.layout);
    if (this_.pending_open) {
        this_.pending_open = false;
        if (col > top) {
            this_.layout = prelude::push(this_.layout, col);
            this_ = push_tok(this_, TokKind(TokKind::KLayOpen{}), here, here);
            if (this_.test_pending == Text::lit("test")) {
                this_.test_depth = std::optional(len(this_.layout));
            }
            if (this_.test_pending == Text::lit("check")) {
                this_.check_depth = std::optional(len(this_.layout));
            }
            this_.test_pending = Text::lit("");
            opened = true;
        } else  {
            this_.diags = prelude::push(this_.diags, lex_diag(this_.pending_span, Text::lit("expected an indented block after `:`")));
        }
    }
    if (!opened) {
        if (((col > top) && fat) && (this_.test_depth == std::optional(len(this_.layout)))) {
            this_.layout = prelude::push(this_.layout, col);
            this_ = push_tok(this_, TokKind(TokKind::KLayOpen{}), here, here);
        } else if (col == top) {
            this_ = push_tok(this_, TokKind(TokKind::KLaySep{}), here, here);
            if (len(this_.layout) == Nat(1u)) {
                this_.test_pending = Text::lit("");
            }
        } else if (col > top) {
            this_.mark_line_start = true;
        } else  {
            while (true) {
                auto&& _m = fuel.checked_sub(Nat(1u));
                if (!(prism_rtl::is_some(_m))) break;
                auto&& left = prism_rtl::some_of(_m);
                if (!((len(this_.layout) > Nat(1u)) && (col < or_(last(this_.layout), Nat(0u))))) {
                    break;
                }
                fuel = left;
                this_.layout = pop(this_.layout);
                this_ = push_tok(this_, TokKind(TokKind::KLayClose{}), here, here);
                auto depth = len(this_.layout);
                if (below(this_.test_depth, depth)) {
                    this_.test_depth = std::optional<Nat>{};
                }
                if (below(this_.check_depth, depth)) {
                    this_.check_depth = std::optional<Nat>{};
                }
            }
            if (col != or_(last(this_.layout), Nat(0u))) {
                this_ = lex_err(this_, line_begin, here, Text::lit("unindent does not match any open block"));
            }
            this_ = push_tok(this_, TokKind(TokKind::KLaySep{}), here, here);
            if (len(this_.layout) == Nat(1u)) {
                this_.test_pending = Text::lit("");
            }
        }
    }
    return this_;
}


/// LexToken: unbounded fn Lex -> Lex
Lex lex_token(const Lex& l0) {
    auto start = l0.pos;
    auto c = peek(l0);
    auto l = ({
        Lex this_ = l0;
        this_.path_next = false;
        this_;
    });
    return l0.path_next && ((is_digit(c) || (c == Text::lit("#"))) || (c == Text::lit("[")))
        ? lex_path_token(l, start)
        : lex_token_at(l, start, c);
}


prism_rtl::Turn<Lex> LexToken::cycle() const {
    const auto& l0 = this->l0;
    auto start = l0.pos;
    auto c = peek(l0);
    auto l = ({
        Lex this_ = l0;
        this_.path_next = false;
        this_;
    });
    return l0.path_next && ((is_digit(c) || (c == Text::lit("#"))) || (c == Text::lit("[")))
        ? prism_rtl::more(prism_rtl::rc(LexPathToken(l, start)))
        : prism_rtl::more(prism_rtl::rc(LexTokenAt(l, start, c)));
}


/// `Start LexToken, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lex> start_lex_token(Lex l0) {
    return prism_rtl::make_rc<LexToken>(l0);
}


/// LexPathToken: unbounded fn Lex, Nat -> Lex
Lex lex_path_token(const Lex& l, const Nat& start) {
    auto [segs, l2] = lex_path(l);
    return push_tok(l2, TokKind(TokKind::KPath{segs}), start, l2.pos);
}


prism_rtl::Turn<Lex> LexPathToken::cycle() const {
    const auto& l = this->l;
    const auto& start = this->start;
    auto l_1 = l;
    auto start_2 = start;
    return call_then(start_lex_path(l_1), [=](std::tuple<Array<PathSegTok>, Lex> lex_path_30683) {
        return ({
            auto [segs, l2] = lex_path_30683;
            (prism_rtl::finished(push_tok(l2, TokKind(TokKind::KPath{segs}), start_2, l2.pos)));
        });
    });
}


/// `Start LexPathToken, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lex> start_lex_path_token(Lex l, Nat start) {
    return prism_rtl::make_rc<LexPathToken>(l, start);
}


/// LexTokenAt: unbounded fn Lex, Nat, Text -> Lex
Lex lex_token_at(const Lex& l, const Nat& start, const Text& c) {
    {
        auto&& m30813_0 = c;
        if (m30813_0 == Text::lit("\"")) {
            auto [text, l2] = lex_text(l);
            return push_tok(l2, TokKind(TokKind::KText{Text::lit(""), text}), start, l2.pos);
        }
    }
    {
        auto&& m30813_1 = c;
        if (m30813_1 == Text::lit("'")) {
            auto [ch, l2] = lex_char(l);
            return push_tok(l2, TokKind(TokKind::KChar{Text::lit(""), ch}), start, l2.pos);
        }
    }
    {
        if (is_digit(c)) {
            auto [kind, l2] = lex_number(l, Text::lit(""));
            return push_tok(l2, kind, start, l2.pos);
        }
    }
    {
        if (is_ident_start(c)) {
            return lex_word_token(l, Text::lit(""), start);
        }
    }
    {
        if (contains(Text::lit("$@?~&^"), c)) {
            return lex_sigils(l);
        }
    }
    {
        auto&& m30813_5 = c;
        if (m30813_5 == Text::lit("!")) {
            return peek_at(l, Nat(1u)) == Text::lit("=")
                ? push_op_suffix(lexer::forward(l, Nat(2u)), Text::lit("!="), start)
                : lex_sigils(l);
        }
    }
    {
        if (contains(Text::lit("([{"), c)) {
            return lex_open(l, c, start);
        }
    }
    {
        if (contains(Text::lit(")]}"), c)) {
            return lex_close(l, c, start);
        }
    }
    {
        auto&& m30813_8 = c;
        if (m30813_8 == Text::lit(",")) {
            return push_tok(bump(l), TokKind(TokKind::KComma{}), start, start + Nat(1u));
        }
    }
    {
        auto&& m30813_9 = c;
        if (m30813_9 == Text::lit(":")) {
            return push_tok(bump(l), TokKind(TokKind::KColon{}), start, start + Nat(1u));
        }
    }
    {
        auto&& m30813_10 = c;
        if (m30813_10 == Text::lit(";")) {
            return push_tok(bump(l), TokKind(TokKind::KSemi{}), start, start + Nat(1u));
        }
    }
    {
        auto&& m30813_11 = c;
        if (m30813_11 == Text::lit("\\")) {
            return lex_backslash(l, start);
        }
    }
    {
        auto&& m30813_12 = c;
        if (m30813_12 == Text::lit("|")) {
            return lex_bar(l, start);
        }
    }
    {
        auto&& m30813_13 = c;
        if (m30813_13 == Text::lit(".")) {
            return lex_dot(l, start);
        }
    }
    {
        auto&& _m = lex_operator(l, start);
        if (prism_rtl::is_some(_m)) {
            auto&& l2 = prism_rtl::some_of(_m);
            return l2;
        }
        if (prism_rtl::is_none(_m)) {
            auto l1 = bump(l);
            auto l2 = lex_err(l1, start, l1.pos, prism_rtl::cat("unexpected character `", c, "`"));
            Lex this_ = l2;
            this_.last_ws = true;
            return this_;
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<Lex> LexTokenAt::cycle() const {
    const auto& l = this->l;
    const auto& start = this->start;
    const auto& c = this->c;
    return ({
        ({
        auto&& m30813_0 = c;
        (m30813_0 == Text::lit("\""));
    }) ? ({
        auto&& m30813_0 = c;
        ({
        auto l_1 = l;
        auto start_2 = start;
        call_then(start_lex_text(l_1), [=](std::tuple<Array<TextSegTok>, Lex> lex_text_30859) {
        return ({
            auto [text, l2] = lex_text_30859;
            (prism_rtl::finished(push_tok(l2, TokKind(TokKind::KText{Text::lit(""), text}), start_2, l2.pos)));
        });
    });
    });
    })
        : ({
        auto&& m30813_1 = c;
        (m30813_1 == Text::lit("'"));
    }) ? ({
        auto&& m30813_1 = c;
        ({
        auto l_1 = l;
        auto start_2 = start;
        call_then(start_lex_char(l_1), [=](std::tuple<Text, Lex> lex_char_30955) {
        return ({
            auto [ch, l2] = lex_char_30955;
            (prism_rtl::finished(push_tok(l2, TokKind(TokKind::KChar{Text::lit(""), ch}), start_2, l2.pos)));
        });
    });
    });
    })
        : ({
        is_digit(c);
    }) ? ({
        auto l_1 = l;
        auto start_2 = start;
        call_then(start_lex_number(l_1, Text::lit("")), [=](std::tuple<TokKind, Lex> lex_number_31067) {
        return ({
            auto [kind, l2] = lex_number_31067;
            (prism_rtl::finished(push_tok(l2, kind, start_2, l2.pos)));
        });
    });
    })
        : ({
        is_ident_start(c);
    }) ? prism_rtl::more(prism_rtl::rc(LexWordToken(l, Text::lit(""), start)))
        : ({
        contains(Text::lit("$@?~&^"), c);
    }) ? prism_rtl::more(prism_rtl::rc(LexSigils(l)))
        : ({
        auto&& m30813_5 = c;
        (m30813_5 == Text::lit("!"));
    }) ? ({
        auto&& m30813_5 = c;
        peek_at(l, Nat(1u)) == Text::lit("=")
        ? prism_rtl::more(prism_rtl::rc(PushOpSuffix(lexer::forward(l, Nat(2u)), Text::lit("!="), start)))
        : prism_rtl::more(prism_rtl::rc(LexSigils(l)));
    })
        : ({
        contains(Text::lit("([{"), c);
    }) ? prism_rtl::finished(lex_open(l, c, start))
        : ({
        contains(Text::lit(")]}"), c);
    }) ? prism_rtl::finished(lex_close(l, c, start))
        : ({
        auto&& m30813_8 = c;
        (m30813_8 == Text::lit(","));
    }) ? ({
        auto&& m30813_8 = c;
        prism_rtl::finished(push_tok(bump(l), TokKind(TokKind::KComma{}), start, start + Nat(1u)));
    })
        : ({
        auto&& m30813_9 = c;
        (m30813_9 == Text::lit(":"));
    }) ? ({
        auto&& m30813_9 = c;
        prism_rtl::finished(push_tok(bump(l), TokKind(TokKind::KColon{}), start, start + Nat(1u)));
    })
        : ({
        auto&& m30813_10 = c;
        (m30813_10 == Text::lit(";"));
    }) ? ({
        auto&& m30813_10 = c;
        prism_rtl::finished(push_tok(bump(l), TokKind(TokKind::KSemi{}), start, start + Nat(1u)));
    })
        : ({
        auto&& m30813_11 = c;
        (m30813_11 == Text::lit("\\"));
    }) ? ({
        auto&& m30813_11 = c;
        prism_rtl::finished(lex_backslash(l, start));
    })
        : ({
        auto&& m30813_12 = c;
        (m30813_12 == Text::lit("|"));
    }) ? ({
        auto&& m30813_12 = c;
        prism_rtl::finished(lex_bar(l, start));
    })
        : ({
        auto&& m30813_13 = c;
        (m30813_13 == Text::lit("."));
    }) ? ({
        auto&& m30813_13 = c;
        prism_rtl::finished(lex_dot(l, start));
    })
        : ({
        auto c_1 = c;
        auto l_2 = l;
        auto start_3 = start;
        call_then(start_lex_operator(l_2, start_3), [=](std::optional<Lex> lex_operator_31687) {
        return ({
            prism_rtl::is_some(lex_operator_31687) ? ({
            auto&& l2 = prism_rtl::some_of(lex_operator_31687);
            prism_rtl::finished(l2);
        })
            : prism_rtl::is_none(lex_operator_31687) ? ({
            auto l1 = bump(l_2);
            auto l2 = lex_err(l1, start_3, l1.pos, prism_rtl::cat("unexpected character `", c_1, "`"));
            (prism_rtl::finished(({
            Lex this_ = l2;
            this_.last_ws = true;
            this_;
        })));
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    });
}


/// `Start LexTokenAt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lex> start_lex_token_at(Lex l, Nat start, Text c) {
    return prism_rtl::make_rc<LexTokenAt>(l, start, c);
}


/// LexOpen: fn Lex, Text, Nat -> Lex
Lex lex_open(const Lex& l, const Text& c, const Nat& start) {
    auto prefix = ((c == Text::lit("[")) && prefix_position(l)) && (!next_is_space(l, Nat(1u)));
    auto l2 = ({
        Lex this_ = bump(l);
        this_.frames = prelude::push(this_.frames, c);
        this_;
    });
    return push_tok(l2, TokKind(TokKind::KOpen{c, prefix}), start, l2.pos);
}


/// LexClose: fn Lex, Text, Nat -> Lex
Lex lex_close(const Lex& l, const Text& c, const Nat& start) {
    auto kind = open_of(c);
    auto l1 = bump(l);
    auto l2 = ({
        __label__ _done;
        prism_rtl::Slot<Lex> _v;
        auto&& _m = last(l1.frames);
        if (prism_rtl::is_some(_m)) {
            auto&& k = prism_rtl::some_of(_m);
            if (k == kind) {
                _v.set(({
                    Lex this_ = l1;
                    this_.frames = pop(this_.frames);
                    this_;
                }));
                goto _done;
            }
        }
        if (prism_rtl::is_some(_m)) {
            auto&& m32364_1 = prism_rtl::some_of(_m);
            if (m32364_1 == Text::lit("<<")) {
                _v.set(lex_err(l1, start, l1.pos, prism_rtl::cat("`", c, "` inside `<<`: expected `>>`")));
                goto _done;
            }
        }
        if (prism_rtl::is_some(_m)) {
            auto&& k = prism_rtl::some_of(_m);
            _v.set(({
                auto l3 = lex_err(l1, start, l1.pos, prism_rtl::cat("`", c, "` closes a `", k, "`"));
                ({
                Lex this_ = l3;
                this_.frames = pop(this_.frames);
                this_;
            });
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(lex_err(l1, start, l1.pos, prism_rtl::cat("`", c, "` closes nothing")));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return push_tok(l2, TokKind(TokKind::KClose{kind}), start, l2.pos);
}


/// LexBackslash: fn Lex, Nat -> Lex
Lex lex_backslash(const Lex& l, const Nat& start) {
    auto l1 = push_tok(bump(l), TokKind(TokKind::KBackslash{}), start, start + Nat(1u));
    return peek(l1) == Text::lit("|")
        ? ({
        auto l2 = ({
            Lex this_ = bump(l1);
            this_.lambda_open = true;
            this_;
        });
        push_tok(l2, TokKind(TokKind::KLambdaBar{true}), l1.pos, l1.pos + Nat(1u));
    })
        : l1;
}


/// LexBar: fn Lex, Nat -> Lex
Lex lex_bar(const Lex& l, const Nat& start) {
    auto l1 = bump(l);
    return l1.lambda_open
        ? ({
        auto l2 = ({
            Lex this_ = l1;
            this_.lambda_open = false;
            this_;
        });
        push_tok(l2, TokKind(TokKind::KLambdaBar{false}), start, l2.pos);
    })
        : push_tok(l1, TokKind(TokKind::KBar{}), start, l1.pos);
}


/// LexDot: fn Lex, Nat -> Lex
Lex lex_dot(const Lex& l, const Nat& start) {
    return starts_with(l, Text::lit(".."))
        ? push_tok(lexer::forward(l, Nat(2u)), TokKind(TokKind::KDotDot{}), start, start + Nat(2u))
        : ({
        auto prefix = prefix_position(l) && (!next_is_space(l, Nat(1u)));
        auto l1 = prefix && is_digit(peek_at(l, Nat(1u)))
            ? lex_err(l, start, start + Nat(1u), Text::lit("a decimal literal has digits on both sides of its point: write `0.5`, not `.5`"))
            : l;
        push_tok(bump(l1), TokKind(TokKind::KDot{prefix}), start, start + Nat(1u));
    });
}


/// PushOpSuffix: unbounded fn Lex, Text, Nat -> Lex
Lex push_op_suffix(const Lex& l, const Text& op, const Nat& start) {
    return takes_suffix(op) && is_upper(peek(l))
        ? ({
        auto [path_, l2] = lex_qualified_path(l);
        push_tok(l2, TokKind(TokKind::KSuffixed{op, path_}), start, l2.pos);
    })
        : push_tok(l, TokKind(TokKind::KOp{op, false}), start, l.pos);
}


prism_rtl::Turn<Lex> PushOpSuffix::cycle() const {
    const auto& l = this->l;
    const auto& op = this->op;
    const auto& start = this->start;
    return takes_suffix(op) && is_upper(peek(l))
        ? ({
        auto l_1 = l;
        auto op_2 = op;
        auto start_3 = start;
        call_then(start_lex_qualified_path(l_1), [=](std::tuple<Array<Text>, Lex> lex_qualified_path_34228) {
        return ({
            auto [path_, l2] = lex_qualified_path_34228;
            (prism_rtl::finished(push_tok(l2, TokKind(TokKind::KSuffixed{op_2, path_}), start_3, l2.pos)));
        });
    });
    })
        : prism_rtl::finished(push_tok(l, TokKind(TokKind::KOp{op, false}), start, l.pos));
}


/// `Start PushOpSuffix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lex> start_push_op_suffix(Lex l, Text op, Nat start) {
    return prism_rtl::make_rc<PushOpSuffix>(l, op, start);
}


/// FirstOp: fn Lex -> Text
Text first_op(const Lex& l) {
    auto fat = fat_arrow_on(l);
    return fold(op_table(), Text::lit(""), [&](const Text& found, const Text& s) {
        return ((found == Text::lit("")) && ((s != Text::lit("=>")) || fat)) && starts_with(l, s)
            ? s
            : found;
    });
}


/// EndsMark: fn Text -> Bool
bool ends_mark(const Text& a) {
    return (a == Text::lit("")) || contains(Text::lit(" \n\r,)]}"), a);
}


/// ClosesSquareOrBrace: fn ?Tok -> Bool
bool closes_square_or_brace(const std::optional<Tok>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& t = prism_rtl::some_of(opt0);
        return (t.kind == TokKind(TokKind::KClose{Text::lit("[")})) || (t.kind == TokKind(TokKind::KClose{Text::lit("{")}));
    }
    if (prism_rtl::is_none(opt0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?LexOperator: unbounded fn Lex, Nat -> ?Lex
std::optional<Lex> lex_operator(const Lex& l, const Nat& start) {
    auto c = peek(l);
    auto after_ = peek_at(l, Nat(1u));
    auto non_empty = (((c == Text::lit("+")) && (!l.last_ws)) && closes_square_or_brace(last(l->tokens))) && (ends_mark(after_) || ((after_ == Text::lit("?")) && ends_mark(peek_at(l, Nat(2u)))));
    return (c == Text::lit("-")) && contains(Text::lit(",)]}"), after_)
        ? std::optional(push_tok(bump(l), TokKind(TokKind::KAbsent{}), start, start + Nat(1u)))
        : non_empty
        ? std::optional(non_empty_mark(l, start, after_))
        : starts_with(l, Text::lit("<<"))
        ? std::optional(open_type_args(l, start))
        : starts_with(l, Text::lit(">>")) && (last(l.frames) == std::optional(Text::lit("<<")))
        ? std::optional(close_type_args(l, start))
        : starts_with(l, Text::lit(">>"))
        ? std::optional(lex_err(push_tok(lexer::forward(l, Nat(2u)), TokKind(TokKind::KGtGt{}), start, start + Nat(2u)), start, start + Nat(2u), Text::lit("`>>` closes explicit type arguments, and none is open (Prism has no shift operators)")))
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Lex>> _v;
        auto&& _m = first_op(l);
        {
            auto&& m35893_0 = _m;
            if (m35893_0 == Text::lit("")) {
                _v.set(std::optional<Lex>{});
                goto _done;
            }
        }
        {
            auto&& op = _m;
            _v.set(std::optional(push_operator(l, op, start)));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::optional<Lex>> LexOperator::cycle() const {
    const auto& l = this->l;
    const auto& start = this->start;
    auto c = peek(l);
    auto after_ = peek_at(l, Nat(1u));
    auto non_empty = (((c == Text::lit("+")) && (!l.last_ws)) && closes_square_or_brace(last(l->tokens))) && (ends_mark(after_) || ((after_ == Text::lit("?")) && ends_mark(peek_at(l, Nat(2u)))));
    return (c == Text::lit("-")) && contains(Text::lit(",)]}"), after_)
        ? prism_rtl::finished(std::optional(push_tok(bump(l), TokKind(TokKind::KAbsent{}), start, start + Nat(1u))))
        : non_empty
        ? prism_rtl::finished(std::optional(non_empty_mark(l, start, after_)))
        : starts_with(l, Text::lit("<<"))
        ? prism_rtl::finished(std::optional(open_type_args(l, start)))
        : starts_with(l, Text::lit(">>")) && (last(l.frames) == std::optional(Text::lit("<<")))
        ? prism_rtl::finished(std::optional(close_type_args(l, start)))
        : starts_with(l, Text::lit(">>"))
        ? prism_rtl::finished(std::optional(lex_err(push_tok(lexer::forward(l, Nat(2u)), TokKind(TokKind::KGtGt{}), start, start + Nat(2u)), start, start + Nat(2u), Text::lit("`>>` closes explicit type arguments, and none is open (Prism has no shift operators)"))))
        : ({
        auto&& _m = first_op(l);
        ({
        auto&& m35893_0 = _m;
        (m35893_0 == Text::lit(""));
    }) ? ({
        auto&& m35893_0 = _m;
        prism_rtl::finished(std::optional<Lex>{});
    })
        : ({
        auto&& op = _m;
        prism_rtl::finished(std::optional(push_operator(l, op, start)));
    });
    });
}


/// `Start LexOperator, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Lex>> start_lex_operator(Lex l, Nat start) {
    return prism_rtl::make_rc<LexOperator>(l, start);
}


/// NonEmptyMark: fn Lex, Nat, Text -> Lex
Lex non_empty_mark(const Lex& l, const Nat& start, const Text& after_) {
    auto l1 = push_tok(bump(l), TokKind(TokKind::KNonEmpty{}), start, start + Nat(1u));
    return after_ == Text::lit("?")
        ? push_tok(bump(l1), TokKind(TokKind::KFree{Text::lit("?")}), l1.pos, l1.pos + Nat(1u))
        : l1;
}


/// OpenTypeArgs: fn Lex, Nat -> Lex
Lex open_type_args(const Lex& l, const Nat& start) {
    auto touching = (!l.last_ws) && is_name_tok(last(l->tokens));
    auto l1 = lexer::forward(l, Nat(2u));
    auto l2 = touching
        ? l1
        : lex_err(l1, start, l1.pos, Text::lit("`<<` opens explicit type arguments and must touch a name on its left (Prism has no shift operators)"));
    auto l3 = ({
        Lex this_ = l2;
        this_.frames = prelude::push(this_.frames, Text::lit("<<"));
        this_;
    });
    return push_tok(l3, TokKind(TokKind::KLtLt{}), start, l3.pos);
}


/// IsNameTok: fn ?Tok -> Bool
bool is_name_tok(const std::optional<Tok>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& t = prism_rtl::some_of(opt0);
        auto&& _m = t.kind;
        if (prism_rtl::is<TokKind::KName>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(opt0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CloseTypeArgs: fn Lex, Nat -> Lex
Lex close_type_args(const Lex& l, const Nat& start) {
    auto l1 = ({
        Lex this_ = lexer::forward(l, Nat(2u));
        this_.frames = pop(this_.frames);
        this_;
    });
    return push_tok(l1, TokKind(TokKind::KGtGt{}), start, l1.pos);
}


/// PushOperator: unbounded fn Lex, Text, Nat -> Lex
Lex push_operator(const Lex& l, const Text& op, const Nat& start) {
    auto l1 = lexer::forward(l, len_text(op));
    return (((op == Text::lit("+")) || (op == Text::lit("-"))) || (op == Text::lit("-?"))) && (!is_upper(peek(l1)))
        ? push_tok(l1, TokKind(TokKind::KOp{op, prefix_position(l1) && (!next_is_space(l1, Nat(0u)))}), start, l1.pos)
        : push_op_suffix(l1, op, start);
}


prism_rtl::Turn<Lex> PushOperator::cycle() const {
    const auto& l = this->l;
    const auto& op = this->op;
    const auto& start = this->start;
    auto l1 = lexer::forward(l, len_text(op));
    return (((op == Text::lit("+")) || (op == Text::lit("-"))) || (op == Text::lit("-?"))) && (!is_upper(peek(l1)))
        ? prism_rtl::finished(push_tok(l1, TokKind(TokKind::KOp{op, prefix_position(l1) && (!next_is_space(l1, Nat(0u)))}), start, l1.pos))
        : prism_rtl::more(prism_rtl::rc(PushOpSuffix(l1, op, start)));
}


/// `Start PushOperator, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lex> start_push_operator(Lex l, Text op, Nat start) {
    return prism_rtl::make_rc<PushOperator>(l, op, start);
}


/// LexSigils: unbounded fn Lex -> Lex
Lex lex_sigils(const Lex& l0) {
    auto start = l0.pos;
    auto [sigils, caret, l] = read_sigils(l0);
    auto next = peek(l);
    return caret
        ? lex_caret(l, start, sigils, next)
        : (is_ident_start(next) || is_digit(next)) || (next == Text::lit("\""))
        ? lex_attached(l, start, sigils, next)
        : ((sigils == Text::lit("&")) && (next == Text::lit("."))) && is_lower(peek_at(l, Nat(1u)))
        ? push_tok(bump(l), TokKind(TokKind::KLensDot{}), start, l.pos + Nat(1u))
        : free_sigils(l, start, sigils);
}


prism_rtl::Turn<Lex> LexSigils::cycle() const {
    const auto& l0 = this->l0;
    auto start = l0.pos;
    auto l0_1 = l0;
    return call_then(start_read_sigils(l0_1), [=](std::tuple<Text, bool, Lex> read_sigils_38133) {
        return ({
            auto [sigils, caret, l] = read_sigils_38133;
            auto next = peek(l);
            caret
            ? prism_rtl::more(prism_rtl::rc(LexCaret(l, start, sigils, next)))
            : (is_ident_start(next) || is_digit(next)) || (next == Text::lit("\""))
            ? prism_rtl::more(prism_rtl::rc(LexAttached(l, start, sigils, next)))
            : ((sigils == Text::lit("&")) && (next == Text::lit("."))) && is_lower(peek_at(l, Nat(1u)))
            ? prism_rtl::finished(push_tok(bump(l), TokKind(TokKind::KLensDot{}), start, l.pos + Nat(1u)))
            : prism_rtl::finished(free_sigils(l, start, sigils));
        });
    });
}


/// `Start LexSigils, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lex> start_lex_sigils(Lex l0) {
    return prism_rtl::make_rc<LexSigils>(l0);
}


/// ReadSigils: unbounded fn Lex -> ((Text, Bool, Lex))
std::tuple<Text, bool, Lex> read_sigils(const Lex& l0) {
    std::tuple<Text, bool, Lex> this_ = std::tuple{Text::lit(""), false, l0};
    Lex l = l0;
    Text sigils = Text::lit("");
    bool caret = false;
    bool going = true;
    while (going) {
        auto c = peek(l);
        if (c == Text::lit("^")) {
            l = bump(l);
            caret = true;
            going = false;
        } else if (is_sigil_char(c) && (!((c == Text::lit("!")) && (peek_at(l, Nat(1u)) == Text::lit("="))))) {
            l = bump(l);
            sigils = prism_rtl::cat(sigils, c);
        } else  {
            going = false;
        }
    }
    this_ = std::tuple{sigils, caret, l};
    return this_;
}


prism_rtl::Turn<std::tuple<Text, bool, Lex>> ReadSigils::cycle() const {
    const auto& l0 = this->l0;
    std::tuple<Text, bool, Lex> this_ = std::tuple{Text::lit(""), false, l0};
    Lex l = l0;
    Text sigils = Text::lit("");
    bool caret = false;
    bool going = true;
    return call_then(loop_job(std::tuple{this_, caret, going, l, sigils}, [=](std::tuple<std::tuple<Text, bool, Lex>, bool, bool, Lex, Text> _p0) {
        auto this_ = std::get<0>(_p0);
        auto caret = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto l = std::get<3>(_p0);
        auto sigils = std::get<4>(_p0);
        return going
            ? ({
            auto c = peek(l);
            if (c == Text::lit("^")) {
                l = bump(l);
                caret = true;
                going = false;
            } else if (is_sigil_char(c) && (!((c == Text::lit("!")) && (peek_at(l, Nat(1u)) == Text::lit("="))))) {
                l = bump(l);
                sigils = prism_rtl::cat(sigils, c);
            } else  {
                going = false;
            }
            Expected<std::tuple<std::tuple<Text, bool, Lex>, bool, bool, Lex, Text>, std::tuple<std::tuple<Text, bool, Lex>, bool, bool, Lex, Text>>(std::tuple{this_, caret, going, l, sigils});
        })
            : Expected<std::tuple<std::tuple<Text, bool, Lex>, bool, bool, Lex, Text>, std::tuple<std::tuple<Text, bool, Lex>, bool, bool, Lex, Text>>(unexpected(std::tuple{this_, caret, going, l, sigils}));
    }), [=](std::tuple<std::tuple<Text, bool, Lex>, bool, bool, Lex, Text> _p0) {
        auto this_ = std::get<0>(_p0);
        auto caret = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto l = std::get<3>(_p0);
        auto sigils = std::get<4>(_p0);
        return ({
            this_ = std::tuple{sigils, caret, l};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start ReadSigils, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, bool, Lex>> start_read_sigils(Lex l0) {
    return prism_rtl::make_rc<ReadSigils>(l0);
}


/// LexCaret: unbounded fn Lex, Nat, Text, Text -> Lex
Lex lex_caret(const Lex& l, const Nat& start, const Text& sigils, const Text& next) {
    return is_upper(next) && (sigils == Text::lit(""))
        ? ({
        auto [path_, l2] = lex_qualified_path(l);
        push_tok(l2, TokKind(TokKind::KTrait{path_}), start, l2.pos);
    })
        : ({
        auto&& _skipped = lex_qualified_path(l);
        auto&& skipped = std::get<1>(_skipped);
        auto l2 = is_ident_start(next) ? skipped : l;
        lex_err(l2, start, prelude::max(l2.pos, l.pos), Text::lit("`^` marks a trait and attaches to its uppercase name: no trait is a value"));
    });
}


prism_rtl::Turn<Lex> LexCaret::cycle() const {
    const auto& l = this->l;
    const auto& start = this->start;
    const auto& sigils = this->sigils;
    const auto& next = this->next;
    return is_upper(next) && (sigils == Text::lit(""))
        ? ({
        auto l_1 = l;
        auto start_2 = start;
        call_then(start_lex_qualified_path(l_1), [=](std::tuple<Array<Text>, Lex> lex_qualified_path_39322) {
        return ({
            auto [path_, l2] = lex_qualified_path_39322;
            (prism_rtl::finished(push_tok(l2, TokKind(TokKind::KTrait{path_}), start_2, l2.pos)));
        });
    });
    })
        : ({
        auto l_1 = l;
        auto next_2 = next;
        auto start_3 = start;
        call_then(start_lex_qualified_path(l_1), [=](std::tuple<Array<Text>, Lex> lex_qualified_path_39434) {
        return ({
            auto&& _skipped = lex_qualified_path_39434;
            auto&& skipped = std::get<1>(_skipped);
            auto l2 = is_ident_start(next_2) ? skipped : l_1;
            (prism_rtl::finished(lex_err(l2, start_3, prelude::max(l2.pos, l_1.pos), Text::lit("`^` marks a trait and attaches to its uppercase name: no trait is a value"))));
        });
    });
    });
}


/// `Start LexCaret, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lex> start_lex_caret(Lex l, Nat start, Text sigils, Text next) {
    return prism_rtl::make_rc<LexCaret>(l, start, sigils, next);
}


/// LexAttached: unbounded fn Lex, Nat, Text, Text -> Lex
Lex lex_attached(const Lex& l, const Nat& start, const Text& sigils, const Text& next) {
    return next == Text::lit("\"")
        ? ({
        auto [text, l2] = lex_text(l);
        push_tok(l2, TokKind(TokKind::KText{sigils, text}), start, l2.pos);
    })
        : is_digit(next)
        ? ({
        auto [kind, l2] = lex_number(l, sigils);
        push_tok(l2, kind, start, l2.pos);
    })
        : lex_word_token(l, sigils, start);
}


prism_rtl::Turn<Lex> LexAttached::cycle() const {
    const auto& l = this->l;
    const auto& start = this->start;
    const auto& sigils = this->sigils;
    const auto& next = this->next;
    return next == Text::lit("\"")
        ? ({
        auto l_1 = l;
        auto sigils_2 = sigils;
        auto start_3 = start;
        call_then(start_lex_text(l_1), [=](std::tuple<Array<TextSegTok>, Lex> lex_text_39773) {
        return ({
            auto [text, l2] = lex_text_39773;
            (prism_rtl::finished(push_tok(l2, TokKind(TokKind::KText{sigils_2, text}), start_3, l2.pos)));
        });
    });
    })
        : is_digit(next)
        ? ({
        auto l_1 = l;
        auto sigils_2 = sigils;
        auto start_3 = start;
        call_then(start_lex_number(l_1, sigils_2), [=](std::tuple<TokKind, Lex> lex_number_39893) {
        return ({
            auto [kind, l2] = lex_number_39893;
            (prism_rtl::finished(push_tok(l2, kind, start_3, l2.pos)));
        });
    });
    })
        : prism_rtl::more(prism_rtl::rc(LexWordToken(l, sigils, start)));
}


/// `Start LexAttached, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lex> start_lex_attached(Lex l, Nat start, Text sigils, Text next) {
    return prism_rtl::make_rc<LexAttached>(l, start, sigils, next);
}


/// FreeSigils: fn Lex, Nat, Text -> Lex
Lex free_sigils(const Lex& l0, const Nat& start, const Text& sigils) {
    Lex this_ = l0;
    auto space_after = next_is_space(this_, Nat(0u));
    auto all = fold_chars(sigils, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                (prism_rtl::finished(prelude::push(acc, c)));
            });
        });
    })));
    for (auto&& [i40321, v40321] : prism_rtl::enumerate(all)) {
        auto k40321 = nat_of(i40321);
        auto s = v40321;
        auto at_ = start + k40321;
        if (space_after && ((k40321 + Nat(1u)) == len(all))) {
            if (s == Text::lit("!")) {
                this_ = lex_err(this_, at_, at_ + Nat(1u), Text::lit("`!` is never free: no event fires a constant (write `!e` touching its name)"));
            }
            if (s == Text::lit("&")) {
                this_ = lex_err(this_, at_, at_ + Nat(1u), Text::lit("`&` is never free: no reference exists outside the value an `update` block names"));
            }
        }
        this_ = push_tok(this_, TokKind(TokKind::KFree{s}), at_, at_ + Nat(1u));
    }
    return this_;
}


/// LexQualifiedPath: unbounded fn Lex -> (([Text], Lex))
std::tuple<Array<Text>, Lex> lex_qualified_path(const Lex& l0) {
    std::tuple<Array<Text>, Lex> this_ = std::tuple{Array<Text>{}, l0};
    auto [first_, l1] = lex_ident(l0);
    Array<Text> path_ = Array(std::vector{first_});
    Lex l = l1;
    bool going = true;
    while (going) {
        auto last_ = or_(last(path_), Text::lit(""));
        auto next = peek_at(l, Nat(1u));
        if ((peek(l) != Text::lit(".")) || (!is_upper(head(last_)))) {
            going = false;
        } else if (is_upper(next)) {
            auto [seg, l2] = lex_ident(bump(l));
            path_ = prelude::push(path_, seg);
            l = l2;
        } else  {
            going = false;
            if (is_ident_start(next)) {
                auto [w, l2] = lex_ident(bump(l));
                if (is_reserved_ctor(w)) {
                    path_ = prelude::push(path_, w);
                    l = l2;
                }
            }
        }
    }
    this_ = std::tuple{path_, l};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<Text>, Lex>> LexQualifiedPath::cycle() const {
    const auto& l0 = this->l0;
    std::tuple<Array<Text>, Lex> this_ = std::tuple{Array<Text>{}, l0};
    auto [first_, l1] = lex_ident(l0);
    Array<Text> path_ = Array(std::vector{first_});
    Lex l = l1;
    bool going = true;
    return call_then(loop_job(std::tuple{this_, going, l, path_}, [=](std::tuple<std::tuple<Array<Text>, Lex>, bool, Lex, Array<Text>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto l = std::get<2>(_p0);
        auto path_ = std::get<3>(_p0);
        return going
            ? ({
            auto last_ = or_(last(path_), Text::lit(""));
            auto next = peek_at(l, Nat(1u));
            if ((peek(l) != Text::lit(".")) || (!is_upper(head(last_)))) {
                going = false;
            } else if (is_upper(next)) {
                auto [seg, l2] = lex_ident(bump(l));
                path_ = prelude::push(path_, seg);
                l = l2;
            } else  {
                going = false;
                if (is_ident_start(next)) {
                    auto [w, l2] = lex_ident(bump(l));
                    if (is_reserved_ctor(w)) {
                        path_ = prelude::push(path_, w);
                        l = l2;
                    }
                }
            }
            Expected<std::tuple<std::tuple<Array<Text>, Lex>, bool, Lex, Array<Text>>, std::tuple<std::tuple<Array<Text>, Lex>, bool, Lex, Array<Text>>>(std::tuple{this_, going, l, path_});
        })
            : Expected<std::tuple<std::tuple<Array<Text>, Lex>, bool, Lex, Array<Text>>, std::tuple<std::tuple<Array<Text>, Lex>, bool, Lex, Array<Text>>>(unexpected(std::tuple{this_, going, l, path_}));
    }), [=](std::tuple<std::tuple<Array<Text>, Lex>, bool, Lex, Array<Text>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto l = std::get<2>(_p0);
        auto path_ = std::get<3>(_p0);
        return ({
            this_ = std::tuple{path_, l};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start LexQualifiedPath, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, Lex>> start_lex_qualified_path(Lex l0) {
    return prism_rtl::make_rc<LexQualifiedPath>(l0);
}


/// LexIdent: unbounded fn Lex -> ((Text, Lex))
std::tuple<Text, Lex> lex_ident(const Lex& l0) {
    auto l = ({
        Lex this_ = l0;
        while (is_ident_char(peek(this_))) {
            this_.pos = this_.pos + Nat(1u);
        }
        this_;
    });
    auto word = slice(l, l0.pos, l.pos);
    return std::tuple{word, l};
}


prism_rtl::Turn<std::tuple<Text, Lex>> LexIdent::cycle() const {
    const auto& l0 = this->l0;
    Lex this_ = l0;
    auto l0_1 = l0;
    return call_then(loop_job(std::tuple{this_}, [=](std::tuple<Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return is_ident_char(peek(this_))
            ? ({
            this_.pos = this_.pos + Nat(1u);
            Expected<std::tuple<Lex>, std::tuple<Lex>>(std::tuple{this_});
        })
            : Expected<std::tuple<Lex>, std::tuple<Lex>>(unexpected(std::tuple{this_}));
    }), [=](std::tuple<Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto l = this_;
            auto word = slice(l, l0_1.pos, l.pos);
            (prism_rtl::finished(std::tuple{word, l}));
        });
    });
}


/// `Start LexIdent, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Lex>> start_lex_ident(Lex l0) {
    return prism_rtl::make_rc<LexIdent>(l0);
}


/// LexWordToken: unbounded fn Lex, Text, Nat -> Lex
Lex lex_word_token(const Lex& l0, const Text& sigils, const Nat& start) {
    auto w_start = l0.pos;
    auto [path_, l1] = lex_qualified_path(l0);
    auto l = is_non_ascii(peek(l1)) ? skip_non_ascii(l1, w_start) : l1;
    auto first_ = or_(index(path_, Nat(0u)), Text::lit(""));
    return starts_with(l, Text::lit(".*")) && is_upper(head(first_))
        ? ({
        auto l2 = lexer::forward(l, Nat(2u));
        auto l3 = sigils != Text::lit("")
            ? lex_err(l2, start, l2.pos, Text::lit("a family pattern takes no sigil"))
            : l2;
        push_tok(l3, TokKind(TokKind::KFamily{path_}), start, l3.pos);
    })
        : ((len(path_) == Nat(1u)) && is_keyword(first_)) && (!(is_bound_word(first_) && (sigils != Text::lit(""))))
        ? lex_keyword(l, first_, sigils, start)
        : lex_name(l, path_, sigils, start, w_start);
}


prism_rtl::Turn<Lex> LexWordToken::cycle() const {
    const auto& l0 = this->l0;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    auto w_start = l0.pos;
    auto l0_1 = l0;
    auto sigils_2 = sigils;
    auto start_3 = start;
    return call_then(start_lex_qualified_path(l0_1), [=](std::tuple<Array<Text>, Lex> lex_qualified_path_42195) {
        return ({
            auto [path_, l1] = lex_qualified_path_42195;
            auto l = is_non_ascii(peek(l1)) ? skip_non_ascii(l1, w_start) : l1;
            auto first_ = or_(index(path_, Nat(0u)), Text::lit(""));
            starts_with(l, Text::lit(".*")) && is_upper(head(first_))
            ? ({
            auto l2 = lexer::forward(l, Nat(2u));
            auto l3 = sigils_2 != Text::lit("")
                ? lex_err(l2, start_3, l2.pos, Text::lit("a family pattern takes no sigil"))
                : l2;
            (prism_rtl::finished(push_tok(l3, TokKind(TokKind::KFamily{path_}), start_3, l3.pos)));
        })
            : ((len(path_) == Nat(1u)) && is_keyword(first_)) && (!(is_bound_word(first_) && (sigils_2 != Text::lit(""))))
            ? prism_rtl::more(prism_rtl::rc(LexKeyword(l, first_, sigils_2, start_3)))
            : prism_rtl::more(prism_rtl::rc(LexName(l, path_, sigils_2, start_3, w_start)));
        });
    });
}


/// `Start LexWordToken, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lex> start_lex_word_token(Lex l0, Text sigils, Nat start) {
    return prism_rtl::make_rc<LexWordToken>(l0, sigils, start);
}


/// SkipNonAscii: unbounded fn Lex, Nat -> Lex
Lex skip_non_ascii(const Lex& l0, const Nat& w_start) {
    auto l = ({
        Lex this_ = l0;
        while (is_ident_char(peek(this_)) || is_non_ascii(peek(this_))) {
            this_.pos = this_.pos + len_text(peek(this_));
        }
        this_;
    });
    return lex_err(l, w_start, l.pos, Text::lit("names are ASCII letters, digits and underscores"));
}


prism_rtl::Turn<Lex> SkipNonAscii::cycle() const {
    const auto& l0 = this->l0;
    const auto& w_start = this->w_start;
    Lex this_ = l0;
    auto w_start_1 = w_start;
    return call_then(loop_job(std::tuple{this_}, [=](std::tuple<Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return is_ident_char(peek(this_)) || is_non_ascii(peek(this_))
            ? ({
            this_.pos = this_.pos + len_text(peek(this_));
            Expected<std::tuple<Lex>, std::tuple<Lex>>(std::tuple{this_});
        })
            : Expected<std::tuple<Lex>, std::tuple<Lex>>(unexpected(std::tuple{this_}));
    }), [=](std::tuple<Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto l = this_;
            (prism_rtl::finished(lex_err(l, w_start_1, l.pos, Text::lit("names are ASCII letters, digits and underscores"))));
        });
    });
}


/// `Start SkipNonAscii, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lex> start_skip_non_ascii(Lex l0, Nat w_start) {
    return prism_rtl::make_rc<SkipNonAscii>(l0, w_start);
}


/// LexKeyword: unbounded fn Lex, Text, Text, Nat -> Lex
Lex lex_keyword(const Lex& l, const Text& w, const Text& sigils, const Nat& start) {
    auto l1 = (sigils != Text::lit("")) && (!(((w == Text::lit("widget")) || (w == Text::lit("unit"))) || (w == Text::lit("nil"))))
        ? lex_err(l, start, l.pos, prism_rtl::cat("`", w, "` is a keyword and takes no sigil"))
        : l;
    auto l2 = (w == Text::lit("widget")) && (sigils != Text::lit("@"))
        ? lex_err(l1, start, l1.pos, Text::lit("`widget` is a block only as `@widget:`"))
        : l1;
    auto l3 = push_tok(l2, TokKind(TokKind::KKw{w, sigils}), start, l2.pos);
    return ((w == Text::lit("output")) || (w == Text::lit("inline_text"))) || (w == Text::lit("raw"))
        ? maybe_template(l3, w)
        : l3;
}


prism_rtl::Turn<Lex> LexKeyword::cycle() const {
    const auto& l = this->l;
    const auto& w = this->w;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    auto l1 = (sigils != Text::lit("")) && (!(((w == Text::lit("widget")) || (w == Text::lit("unit"))) || (w == Text::lit("nil"))))
        ? lex_err(l, start, l.pos, prism_rtl::cat("`", w, "` is a keyword and takes no sigil"))
        : l;
    auto l2 = (w == Text::lit("widget")) && (sigils != Text::lit("@"))
        ? lex_err(l1, start, l1.pos, Text::lit("`widget` is a block only as `@widget:`"))
        : l1;
    auto l3 = push_tok(l2, TokKind(TokKind::KKw{w, sigils}), start, l2.pos);
    return ((w == Text::lit("output")) || (w == Text::lit("inline_text"))) || (w == Text::lit("raw"))
        ? prism_rtl::more(prism_rtl::rc(MaybeTemplate(l3, w)))
        : prism_rtl::finished(l3);
}


/// `Start LexKeyword, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lex> start_lex_keyword(Lex l, Text w, Text sigils, Nat start) {
    return prism_rtl::make_rc<LexKeyword>(l, w, sigils, start);
}


/// LexName: unbounded fn Lex, [Text], Text, Nat, Nat -> Lex
Lex lex_name(const Lex& l, const Array<Text>& path_, const Text& sigils, const Nat& start, const Nat& w_start) {
    auto [case_, l1] = name_case_of(l, path_, w_start);
    auto l2 = is_path_word(l1, sigils, path_)
        ? ({
        Lex this_ = l1;
        this_.path_next = true;
        this_;
    })
        : l1;
    return push_tok(l2, TokKind(TokKind::KName{NameTok{.sigils = sigils, .path_ = path_, .case_ = case_}}), start, l2.pos);
}


prism_rtl::Turn<Lex> LexName::cycle() const {
    const auto& l = this->l;
    const auto& path_ = this->path_;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    const auto& w_start = this->w_start;
    auto [case_, l1] = name_case_of(l, path_, w_start);
    auto l2 = is_path_word(l1, sigils, path_)
        ? ({
        Lex this_ = l1;
        this_.path_next = true;
        this_;
    })
        : l1;
    return prism_rtl::finished(push_tok(l2, TokKind(TokKind::KName{NameTok{.sigils = sigils, .path_ = path_, .case_ = case_}}), start, l2.pos));
}


/// `Start LexName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lex> start_lex_name(Lex l, Array<Text> path_, Text sigils, Nat start, Nat w_start) {
    return prism_rtl::make_rc<LexName>(l, path_, sigils, start, w_start);
}


/// NameCaseOf: fn Lex, [Text], Nat -> ((NameCase, Lex))
std::tuple<NameCase, Lex> name_case_of(const Lex& l, const Array<Text>& path_, const Nat& w_start) {
    auto last_ = or_(last(path_), Text::lit(""));
    return last_ == Text::lit("_")
        ? std::tuple{NameCase(NameCase::CaseTopic{}), l}
        : (head(last_) == Text::lit("_")) && all_chars(after_first(last_), ({
        auto f = prism_rtl::rc(is_digit);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))
        ? std::tuple{NameCase(NameCase::CaseHole{}), l}
        : head(last_) == Text::lit("_")
        ? std::tuple{NameCase(NameCase::CaseLower{}), lex_err(l, w_start, l.pos, Text::lit("`_` followed by a letter is not a name: `_` alone is the topic, `_1` a hole"))}
        : is_reserved_ctor(last_)
        ? std::tuple{NameCase(NameCase::CaseReserved{}), l}
        : is_upper(head(last_))
        ? ({
        auto underscored = fold(path_, false, [&](const bool& seen, const Text& seg) { return seen || contains(seg, Text::lit("_")); });
        underscored
        ? std::tuple{NameCase(NameCase::CaseUpper{}), lex_err(l, w_start, l.pos, prism_rtl::cat("`", join(path_, Text::lit(".")), "`: a capital promises UpperCamelCase"))}
        : std::tuple{NameCase(NameCase::CaseUpper{}), l};
    })
        : std::tuple{NameCase(NameCase::CaseLower{}), l};
}


/// IsPathWord: fn Lex, Text, [Text] -> Bool
bool is_path_word(const Lex& l, const Text& sigils, const Array<Text>& path_) {
    auto w = or_(index(path_, Nat(0u)), Text::lit(""));
    auto words = w == Text::lit("at")
        ? Array(std::vector{Text::lit("send"), Text::lit("click"), Text::lit("answer")})
        : Array(std::vector{Text::lit("click")});
    auto prev = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = last(l->tokens);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = t.kind;
                if (prism_rtl::is<TokKind::KName>(_m)) {
                    auto&& n = prism_rtl::as<TokKind::KName>(_m).a0;
                    if ((n.sigils == Text::lit("")) && (len(n->path_) == Nat(1u))) {
                        _v.set(or_(index(n->path_, Nat(0u)), Text::lit("")));
                        goto _done;
                    }
                }
                {
                    _v.set(Text::lit(""));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ((((l.test_depth != std::optional<Nat>{}) && (sigils == Text::lit(""))) && (len(path_) == Nat(1u))) && ((w == Text::lit("at")) || (w == Text::lit("element")))) && fold(words, false, [&](const bool& seen, const Text& x) { return seen || (x == prev); });
}


/// LexNumber: unbounded fn Lex, Text -> ((TokKind, Lex))
std::tuple<TokKind, Lex> lex_number(const Lex& l, const Text& sigils) {
    return (peek(l) == Text::lit("0")) && contains(Text::lit("xob"), peek_at(l, Nat(1u)))
        ? lex_radix(l, sigils)
        : lex_decimal(l, sigils);
}


prism_rtl::Turn<std::tuple<TokKind, Lex>> LexNumber::cycle() const {
    const auto& l = this->l;
    const auto& sigils = this->sigils;
    return (peek(l) == Text::lit("0")) && contains(Text::lit("xob"), peek_at(l, Nat(1u)))
        ? prism_rtl::more(prism_rtl::rc(LexRadix(l, sigils)))
        : prism_rtl::more(prism_rtl::rc(LexDecimal(l, sigils)));
}


/// `Start LexNumber, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<TokKind, Lex>> start_lex_number(Lex l, Text sigils) {
    return prism_rtl::make_rc<LexNumber>(l, sigils);
}


/// RadixDigit: fn Text, Text -> Bool
bool radix_digit(const Text& text0, const Text& c) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("x")) {
            return is_hex_digit(c);
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("o")) {
            return (Text::lit("0") <= c) && (c <= Text::lit("7"));
        }
    }
    {
        return (c == Text::lit("0")) || (c == Text::lit("1"));
    }
}


/// LexRadix: unbounded fn Lex, Text -> ((TokKind, Lex))
std::tuple<TokKind, Lex> lex_radix(const Lex& l0, const Text& sigils) {
    auto start = l0.pos;
    auto radix = peek_at(l0, Nat(1u));
    auto l1 = lexer::forward(l0, Nat(2u));
    auto l2 = ({
        Lex this_ = l1;
        while (radix_digit(radix, peek(this_)) || (peek(this_) == Text::lit("_"))) {
            this_.pos = this_.pos + Nat(1u);
        }
        this_;
    });
    auto l3 = l2.pos == l1.pos
        ? lex_err(l2, start, l2.pos, Text::lit("a radix prefix needs digits after it"))
        : l2;
    auto l4 = check_no_suffix(l3, start);
    auto kind = TokKind(TokKind::KInt{sigils, slice(l4, start, l4.pos)});
    return std::tuple{kind, l4};
}


prism_rtl::Turn<std::tuple<TokKind, Lex>> LexRadix::cycle() const {
    const auto& l0 = this->l0;
    const auto& sigils = this->sigils;
    auto start = l0.pos;
    auto radix = peek_at(l0, Nat(1u));
    auto l1 = lexer::forward(l0, Nat(2u));
    Lex this_ = l1;
    auto l1_1 = l1;
    auto radix_2 = radix;
    auto sigils_3 = sigils;
    auto start_4 = start;
    return call_then(loop_job(std::tuple{this_}, ({
        auto radix_2_5 = radix_2;
        [=](std::tuple<Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return radix_digit(radix_2_5, peek(this_)) || (peek(this_) == Text::lit("_"))
            ? ({
            this_.pos = this_.pos + Nat(1u);
            Expected<std::tuple<Lex>, std::tuple<Lex>>(std::tuple{this_});
        })
            : Expected<std::tuple<Lex>, std::tuple<Lex>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto l2 = this_;
            auto l3 = l2.pos == l1_1.pos
                ? lex_err(l2, start_4, l2.pos, Text::lit("a radix prefix needs digits after it"))
                : l2;
            call_then(start_check_no_suffix(l3, start_4), [=](Lex check_no_suffix_46451) {
            return ({
                auto l4 = check_no_suffix_46451;
                auto kind = TokKind(TokKind::KInt{sigils_3, slice(l4, start_4, l4.pos)});
                (prism_rtl::finished(std::tuple{kind, l4}));
            });
        });
        });
    });
}


/// `Start LexRadix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<TokKind, Lex>> start_lex_radix(Lex l0, Text sigils) {
    return prism_rtl::make_rc<LexRadix>(l0, sigils);
}


/// SkipDigits: unbounded fn Lex -> Lex
Lex skip_digits(const Lex& l) {
    Lex this_ = l;
    while (is_digit(peek(this_)) || (peek(this_) == Text::lit("_"))) {
        this_.pos = this_.pos + Nat(1u);
    }
    return this_;
}


prism_rtl::Turn<Lex> SkipDigits::cycle() const {
    const auto& l = this->l;
    Lex this_ = l;
    return call_then(loop_job(std::tuple{this_}, [=](std::tuple<Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return is_digit(peek(this_)) || (peek(this_) == Text::lit("_"))
            ? ({
            this_.pos = this_.pos + Nat(1u);
            Expected<std::tuple<Lex>, std::tuple<Lex>>(std::tuple{this_});
        })
            : Expected<std::tuple<Lex>, std::tuple<Lex>>(unexpected(std::tuple{this_}));
    }), [=](std::tuple<Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return prism_rtl::finished(this_);
    });
}


/// `Start SkipDigits, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lex> start_skip_digits(Lex l) {
    return prism_rtl::make_rc<SkipDigits>(l);
}


/// LexDecimal: unbounded fn Lex, Text -> ((TokKind, Lex))
std::tuple<TokKind, Lex> lex_decimal(const Lex& l0, const Text& sigils) {
    auto start = l0.pos;
    auto l1 = skip_digits(l0);
    auto next = peek_at(l1, Nat(1u));
    return (peek(l1) == Text::lit(".")) && is_digit(next)
        ? number_tail(skip_digits(bump(l1)), sigils, start, true)
        : (((peek(l1) == Text::lit(".")) && (next != Text::lit("."))) && (next != Text::lit(""))) && (!is_ident_start(next))
        ? ({
        auto l2 = bump(l1);
        auto l3 = lex_err(l2, start, l2.pos, prism_rtl::cat("`", slice(l2, start, l2.pos), "` is not a number: a decimal literal has digits on both sides of its point"));
        auto kind = TokKind(TokKind::KFloat{sigils, slice(l3, start, dec(l2.pos))});
        std::tuple{kind, l3};
    })
        : number_tail(l1, sigils, start, false);
}


prism_rtl::Turn<std::tuple<TokKind, Lex>> LexDecimal::cycle() const {
    const auto& l0 = this->l0;
    const auto& sigils = this->sigils;
    auto start = l0.pos;
    auto l0_1 = l0;
    auto sigils_2 = sigils;
    return call_then(start_skip_digits(l0_1), [=](Lex skip_digits_46800) {
        return ({
            auto l1 = skip_digits_46800;
            auto next = peek_at(l1, Nat(1u));
            (peek(l1) == Text::lit(".")) && is_digit(next)
            ? call_then(start_skip_digits(bump(l1)), [=](Lex skip_digits_46898) { return prism_rtl::more(prism_rtl::rc(NumberTail(skip_digits_46898, sigils_2, start, true))); })
            : (((peek(l1) == Text::lit(".")) && (next != Text::lit("."))) && (next != Text::lit(""))) && (!is_ident_start(next))
            ? ({
            auto l2 = bump(l1);
            auto l3 = lex_err(l2, start, l2.pos, prism_rtl::cat("`", slice(l2, start, l2.pos), "` is not a number: a decimal literal has digits on both sides of its point"));
            auto kind = TokKind(TokKind::KFloat{sigils_2, slice(l3, start, dec(l2.pos))});
            (prism_rtl::finished(std::tuple{kind, l3}));
        })
            : prism_rtl::more(prism_rtl::rc(NumberTail(l1, sigils_2, start, false)));
        });
    });
}


/// `Start LexDecimal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<TokKind, Lex>> start_lex_decimal(Lex l0, Text sigils) {
    return prism_rtl::make_rc<LexDecimal>(l0, sigils);
}


/// let durationUnits
Array<std::tuple<Text, Nat>> duration_units() {
    return Array(std::vector{std::tuple{Text::lit("ns"), Nat(1u)}, std::tuple{Text::lit("us"), Nat(1000u)}, std::tuple{Text::lit("ms"), Nat(1000000u)}, std::tuple{Text::lit("min"), *Nat::from_int(Int(60000000000ll))}, std::tuple{Text::lit("s"), *Nat::from_int(Int(1000000000ll))}, std::tuple{Text::lit("h"), *Nat::from_int(Int(3600000000000ll))}});
}


/// ?UnitAt: fn Lex -> ?((Text, Nat))
std::optional<std::tuple<Text, Nat>> unit_at(const Lex& l) {
    return fold(duration_units(), std::optional<std::tuple<Text, Nat>>{}, [&](const std::optional<std::tuple<Text, Nat>>& found_opt, const std::tuple<Text, Nat>& u) {
        return (found_opt == std::optional<std::tuple<Text, Nat>>{}) && unit_here(l, u)
            ? std::optional(u)
            : found_opt;
    });
}


/// UnitHere: fn Lex, ((Text, Nat)) -> Bool
bool unit_here(const Lex& l, const std::tuple<Text, Nat>& arg1) {
    {
        auto&& u = std::get<0>(arg1);
        return starts_with(l, u) && (!is_ident_char(peek_at(l, len_text(u))));
    }
    prism_rtl::unreachable("no arm matched");
}


/// NumberTail: unbounded fn Lex, Text, Nat, Bool -> ((TokKind, Lex))
std::tuple<TokKind, Lex> number_tail(const Lex& l, const Text& sigils, const Nat& start, const bool& decimal) {
    auto&& _m = unit_at(l);
    if (prism_rtl::is_some(_m)) {
        auto&& u = std::get<0>(prism_rtl::some_of(_m));
        auto&& scale = std::get<1>(prism_rtl::some_of(_m));
        auto digits = slice(l, start, l.pos);
        auto l2 = lexer::forward(l, len_text(u));
        auto l3 = whole_nanoseconds(digits, scale)
            ? l2
            : lex_err(l2, start, l2.pos, prism_rtl::cat("`", digits, u, "` does not name a whole number of nanoseconds"));
        auto kind = TokKind(TokKind::KDuration{sigils, digits, u});
        return std::tuple{kind, l3};
    }
    if (prism_rtl::is_none(_m)) {
        auto [dec_, l2] = exponent(l, decimal);
        auto l3 = check_no_suffix(l2, start);
        auto text = slice(l3, start, l3.pos);
        auto kind = dec_
            ? TokKind(TokKind::KFloat{sigils, text})
            : TokKind(TokKind::KInt{sigils, text});
        return std::tuple{kind, l3};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<TokKind, Lex>> NumberTail::cycle() const {
    const auto& l = this->l;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    const auto& decimal = this->decimal;
    return ({
        auto&& _m = unit_at(l);
        prism_rtl::is_some(_m) ? ({
        auto&& u = std::get<0>(prism_rtl::some_of(_m));
        auto&& scale = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto digits = slice(l, start, l.pos);
        auto l2 = lexer::forward(l, len_text(u));
        auto l3 = whole_nanoseconds(digits, scale)
            ? l2
            : lex_err(l2, start, l2.pos, prism_rtl::cat("`", digits, u, "` does not name a whole number of nanoseconds"));
        auto kind = TokKind(TokKind::KDuration{sigils, digits, u});
        (prism_rtl::finished(std::tuple{kind, l3}));
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto decimal_1 = decimal;
        auto l_2 = l;
        auto sigils_3 = sigils;
        auto start_4 = start;
        call_then(start_exponent(l_2, decimal_1), [=](std::tuple<bool, Lex> exponent_48719) {
        return ({
            auto [dec_, l2] = exponent_48719;
            call_then(start_check_no_suffix(l2, start_4), [=](Lex check_no_suffix_48756) {
            return ({
                auto l3 = check_no_suffix_48756;
                auto text = slice(l3, start_4, l3.pos);
                auto kind = dec_
                    ? TokKind(TokKind::KFloat{sigils_3, text})
                    : TokKind(TokKind::KInt{sigils_3, text});
                (prism_rtl::finished(std::tuple{kind, l3}));
            });
        });
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start NumberTail, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<TokKind, Lex>> start_number_tail(Lex l, Text sigils, Nat start, bool decimal) {
    return prism_rtl::make_rc<NumberTail>(l, sigils, start, decimal);
}


/// Exponent: unbounded fn Lex, Bool -> ((Bool, Lex))
std::tuple<bool, Lex> exponent(const Lex& l, const bool& decimal) {
    auto l1 = bump(l);
    auto l2 = (peek(l1) == Text::lit("+")) || (peek(l1) == Text::lit("-"))
        ? bump(l1)
        : l1;
    return ((peek(l) == Text::lit("e")) || (peek(l) == Text::lit("E"))) && is_digit(peek(l2))
        ? std::tuple{true, skip_digits(l2)}
        : std::tuple{decimal, l};
}


prism_rtl::Turn<std::tuple<bool, Lex>> Exponent::cycle() const {
    const auto& l = this->l;
    const auto& decimal = this->decimal;
    auto l1 = bump(l);
    auto l2 = (peek(l1) == Text::lit("+")) || (peek(l1) == Text::lit("-"))
        ? bump(l1)
        : l1;
    return ((peek(l) == Text::lit("e")) || (peek(l) == Text::lit("E"))) && is_digit(peek(l2))
        ? call_then(start_skip_digits(l2), [=](Lex skip_digits_49158) { return prism_rtl::finished(std::tuple{true, skip_digits_49158}); })
        : prism_rtl::finished(std::tuple{decimal, l});
}


/// `Start Exponent, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<bool, Lex>> start_exponent(Lex l, bool decimal) {
    return prism_rtl::make_rc<Exponent>(l, decimal);
}


/// WholeNanoseconds: fn Text, Nat -> Bool
bool whole_nanoseconds(const Text& text, const Nat& scale) {
    auto parts = split(concat(split(text, Text::lit("_"))), Text::lit("."));
    auto&& _m = index(parts, Nat(1u));
    if (prism_rtl::is_none(_m)) {
        return true;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& frac0 = prism_rtl::some_of(_m);
        auto frac = trim_zeros(frac0);
        auto k = len_text(frac);
        auto f = frac == Text::lit("") ? Nat(0u) : or_(parse_nat_opt(frac), Nat(1u));
        auto tens = fold_chars(frac, Nat(1u), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=](std::tuple<Nat, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return once_job([=]() {
                return ({
                    auto p_ = p0;
                    static_cast<void>(p1);
                    (prism_rtl::finished(p_ * Nat(10u)));
                });
            });
        })));
        return (k <= Nat(30u)) && (or_(mod_(f * scale, tens), Nat(1u)) == Nat(0u));
    }
    prism_rtl::unreachable("no arm matched");
}


/// TrimZeros: fn Text -> Text
Text trim_zeros(const Text& t) {
    return trim_trailing(t, Text::lit("0"));
}


/// CheckNoSuffix: unbounded fn Lex, Nat -> Lex
Lex check_no_suffix(const Lex& l0, const Nat& start) {
    return is_ident_char(peek(l0))
        ? ({
        auto l = ({
            Lex this_ = l0;
            while (is_ident_char(peek(this_))) {
                this_.pos = this_.pos + Nat(1u);
            }
            this_;
        });
        lex_err(l, start, l.pos, prism_rtl::cat("`", slice(l, start, l.pos), "` is not a token: a number literal has no suffix (write a type annotation)"));
    })
        : l0;
}


prism_rtl::Turn<Lex> CheckNoSuffix::cycle() const {
    const auto& l0 = this->l0;
    const auto& start = this->start;
    return is_ident_char(peek(l0))
        ? ({
        Lex this_ = l0;
        auto start_1 = start;
        call_then(loop_job(std::tuple{this_}, [=](std::tuple<Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return is_ident_char(peek(this_))
            ? ({
            this_.pos = this_.pos + Nat(1u);
            Expected<std::tuple<Lex>, std::tuple<Lex>>(std::tuple{this_});
        })
            : Expected<std::tuple<Lex>, std::tuple<Lex>>(unexpected(std::tuple{this_}));
    }), [=](std::tuple<Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto l = this_;
            (prism_rtl::finished(lex_err(l, start_1, l.pos, prism_rtl::cat("`", slice(l, start_1, l.pos), "` is not a token: a number literal has no suffix (write a type annotation)"))));
        });
    });
    })
        : prism_rtl::finished(l0);
}


/// `Start CheckNoSuffix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lex> start_check_no_suffix(Lex l0, Nat start) {
    return prism_rtl::make_rc<CheckNoSuffix>(l0, start);
}


/// LexEscape: unbounded fn Lex -> ((Text, Lex))
std::tuple<Text, Lex> lex_escape(const Lex& l0) {
    auto start = l0.pos;
    auto l1 = bump(l0);
    auto c = peek(l1);
    auto l2 = bump(l1);
    {
        auto&& m50423_0 = c;
        if (m50423_0 == Text::lit("\\")) {
            return std::tuple{Text::lit("\\"), l2};
        }
    }
    {
        auto&& m50423_1 = c;
        if (m50423_1 == Text::lit("\"")) {
            return std::tuple{Text::lit("\""), l2};
        }
    }
    {
        auto&& m50423_2 = c;
        if (m50423_2 == Text::lit("'")) {
            return std::tuple{Text::lit("'"), l2};
        }
    }
    {
        auto&& m50423_3 = c;
        if (m50423_3 == Text::lit("n")) {
            return std::tuple{Text::lit("\n"), l2};
        }
    }
    {
        auto&& m50423_4 = c;
        if (m50423_4 == Text::lit("t")) {
            return std::tuple{Text::lit("\t"), l2};
        }
    }
    {
        auto&& m50423_5 = c;
        if (m50423_5 == Text::lit("{")) {
            return std::tuple{Text::lit("{"), l2};
        }
    }
    {
        auto&& m50423_6 = c;
        if (m50423_6 == Text::lit("}")) {
            return std::tuple{Text::lit("}"), l2};
        }
    }
    {
        auto&& m50423_7 = c;
        if (m50423_7 == Text::lit("u")) {
            return unicode_escape(l2, start);
        }
    }
    {
        auto&& m50423_8 = c;
        if (m50423_8 == Text::lit("")) {
            return std::tuple{Text::lit(""), lex_err(l1, start, l1.pos, Text::lit("a text literal ends inside an escape"))};
        }
    }
    {
        return std::tuple{Text::lit(""), lex_err(l2, start, l2.pos, prism_rtl::cat("`\\", c, "` is not an escape: the escapes are \\\\ \\\" \\n \\t \\{ \\} \\u{hex}"))};
    }
}


prism_rtl::Turn<std::tuple<Text, Lex>> LexEscape::cycle() const {
    const auto& l0 = this->l0;
    auto start = l0.pos;
    auto l1 = bump(l0);
    auto c = peek(l1);
    auto l2 = bump(l1);
    return ({
        ({
        auto&& m50423_0 = c;
        (m50423_0 == Text::lit("\\"));
    }) ? ({
        auto&& m50423_0 = c;
        prism_rtl::finished(std::tuple{Text::lit("\\"), l2});
    })
        : ({
        auto&& m50423_1 = c;
        (m50423_1 == Text::lit("\""));
    }) ? ({
        auto&& m50423_1 = c;
        prism_rtl::finished(std::tuple{Text::lit("\""), l2});
    })
        : ({
        auto&& m50423_2 = c;
        (m50423_2 == Text::lit("'"));
    }) ? ({
        auto&& m50423_2 = c;
        prism_rtl::finished(std::tuple{Text::lit("'"), l2});
    })
        : ({
        auto&& m50423_3 = c;
        (m50423_3 == Text::lit("n"));
    }) ? ({
        auto&& m50423_3 = c;
        prism_rtl::finished(std::tuple{Text::lit("\n"), l2});
    })
        : ({
        auto&& m50423_4 = c;
        (m50423_4 == Text::lit("t"));
    }) ? ({
        auto&& m50423_4 = c;
        prism_rtl::finished(std::tuple{Text::lit("\t"), l2});
    })
        : ({
        auto&& m50423_5 = c;
        (m50423_5 == Text::lit("{"));
    }) ? ({
        auto&& m50423_5 = c;
        prism_rtl::finished(std::tuple{Text::lit("{"), l2});
    })
        : ({
        auto&& m50423_6 = c;
        (m50423_6 == Text::lit("}"));
    }) ? ({
        auto&& m50423_6 = c;
        prism_rtl::finished(std::tuple{Text::lit("}"), l2});
    })
        : ({
        auto&& m50423_7 = c;
        (m50423_7 == Text::lit("u"));
    }) ? ({
        auto&& m50423_7 = c;
        prism_rtl::more(prism_rtl::rc(UnicodeEscape(l2, start)));
    })
        : ({
        auto&& m50423_8 = c;
        (m50423_8 == Text::lit(""));
    }) ? ({
        auto&& m50423_8 = c;
        prism_rtl::finished(std::tuple{Text::lit(""), lex_err(l1, start, l1.pos, Text::lit("a text literal ends inside an escape"))});
    })
        : prism_rtl::finished(std::tuple{Text::lit(""), lex_err(l2, start, l2.pos, prism_rtl::cat("`\\", c, "` is not an escape: the escapes are \\\\ \\\" \\n \\t \\{ \\} \\u{hex}"))});
    });
}


/// `Start LexEscape, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Lex>> start_lex_escape(Lex l0) {
    return prism_rtl::make_rc<LexEscape>(l0);
}


/// UnicodeEscape: unbounded fn Lex, Nat -> ((Text, Lex))
std::tuple<Text, Lex> unicode_escape(const Lex& l, const Nat& start) {
    return peek(l) != Text::lit("{")
        ? std::tuple{Text::lit(""), lex_err(l, start, l.pos, Text::lit("`\\u` is written `\\u{hex}`"))}
        : ({
        auto hs = l.pos + Nat(1u);
        auto l1 = ({
            Lex this_ = bump(l);
            while (is_hex_digit(peek(this_))) {
                this_.pos = this_.pos + Nat(1u);
            }
            this_;
        });
        auto hex = slice(l1, hs, l1.pos);
        peek(l1) != Text::lit("}")
        ? std::tuple{Text::lit(""), lex_err(l1, start, l1.pos, Text::lit("`\\u{` needs its closing `}`"))}
        : ({
        auto l2 = bump(l1);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Lex>> _v;
        auto&& _m = ascii_char(or_(parse_hex(hex), Nat(1114112u)));
        if (prism_rtl::is_some(_m)) {
            auto&& ch = prism_rtl::some_of(_m);
            _v.set(std::tuple{ch, l2});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{Text::lit(""), lex_err(l2, start, l2.pos, prism_rtl::cat("`\\u{", hex, "}` is past ASCII, which prismc cannot write yet (prismc/README.md, gap UC)"))});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
    });
}


prism_rtl::Turn<std::tuple<Text, Lex>> UnicodeEscape::cycle() const {
    const auto& l = this->l;
    const auto& start = this->start;
    return peek(l) != Text::lit("{")
        ? prism_rtl::finished(std::tuple{Text::lit(""), lex_err(l, start, l.pos, Text::lit("`\\u` is written `\\u{hex}`"))})
        : ({
        auto hs = l.pos + Nat(1u);
        Lex this_ = bump(l);
        auto hs_1 = hs;
        auto start_2 = start;
        call_then(loop_job(std::tuple{this_}, [=](std::tuple<Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return is_hex_digit(peek(this_))
            ? ({
            this_.pos = this_.pos + Nat(1u);
            Expected<std::tuple<Lex>, std::tuple<Lex>>(std::tuple{this_});
        })
            : Expected<std::tuple<Lex>, std::tuple<Lex>>(unexpected(std::tuple{this_}));
    }), [=](std::tuple<Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto l1 = this_;
            auto hex = slice(l1, hs_1, l1.pos);
            peek(l1) != Text::lit("}")
            ? prism_rtl::finished(std::tuple{Text::lit(""), lex_err(l1, start_2, l1.pos, Text::lit("`\\u{` needs its closing `}`"))})
            : ({
            auto l2 = bump(l1);
            ({
            auto&& _m = ascii_char(or_(parse_hex(hex), Nat(1114112u)));
            prism_rtl::is_some(_m) ? ({
            auto&& ch = prism_rtl::some_of(_m);
            prism_rtl::finished(std::tuple{ch, l2});
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{Text::lit(""), lex_err(l2, start_2, l2.pos, prism_rtl::cat("`\\u{", hex, "}` is past ASCII, which prismc cannot write yet (prismc/README.md, gap UC)"))})
            : throw prism_rtl::Panic("no arm matched");
        });
        });
        });
    });
    });
}


/// `Start UnicodeEscape, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Lex>> start_unicode_escape(Lex l, Nat start) {
    return prism_rtl::make_rc<UnicodeEscape>(l, start);
}


/// LexText: unbounded fn Lex -> (([TextSegTok], Lex))
std::tuple<Array<TextSegTok>, Lex> lex_text(const Lex& l0) {
    std::tuple<Array<TextSegTok>, Lex> this_ = std::tuple{Array<TextSegTok>{}, l0};
    auto start = l0.pos;
    Lex l = bump(l0);
    Array<TextSegTok> segs = Array<TextSegTok>{};
    Text cur = Text::lit("");
    bool going = true;
    while (going) {
        auto c = peek(l);
        if ((c == Text::lit("")) || (c == Text::lit("\n"))) {
            l = lex_err(l, start, l.pos, Text::lit("a text literal ends on its line: close it with `\"`, or write a multiline text as `raw <markdown>...</markdown>`"));
            going = false;
        } else  {
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                {
                    auto&& u52163_0 = c;
                    if (u52163_0 == Text::lit("\"")) {
                        _v.set(({
                            l = bump(l);
                            going = false;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u52163_1 = c;
                    if (u52163_1 == Text::lit("\\")) {
                        _v.set(({
                            auto [s, l2] = lex_escape(l);
                            cur = prism_rtl::cat(cur, s);
                            l = l2;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u52163_2 = c;
                    if (u52163_2 == Text::lit("{")) {
                        _v.set(({
                            if (cur != Text::lit("")) {
                                segs = prelude::push(segs, TextSegTok(TextSegTok::TsPlain{cur}));
                                cur = Text::lit("");
                            }
                            auto ps = l.pos;
                            auto [toks, l2] = nested(bump(l), Mode(Mode::MPlaceholder{Text::lit("single")}));
                            segs = prelude::push(segs, TextSegTok(TextSegTok::TsPlaceholder{toks, ast::Range{.start = ps, .end = l2.pos}}));
                            l = l2;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u52163_3 = c;
                    if (u52163_3 == Text::lit("}")) {
                        _v.set(({
                            l = lex_err(bump(l), l.pos, l.pos + Nat(1u), Text::lit("a `}` in text is written `\\}`"));
                            cur = prism_rtl::cat(cur, "}");
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        l = bump(l);
                        cur = prism_rtl::cat(cur, c);
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
        }
    }
    if (cur != Text::lit("")) {
        segs = prelude::push(segs, TextSegTok(TextSegTok::TsPlain{cur}));
    }
    this_ = std::tuple{segs, l};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<TextSegTok>, Lex>> LexText::cycle() const {
    const auto& l0 = this->l0;
    std::tuple<Array<TextSegTok>, Lex> this_ = std::tuple{Array<TextSegTok>{}, l0};
    auto start = l0.pos;
    Lex l = bump(l0);
    Array<TextSegTok> segs = Array<TextSegTok>{};
    Text cur = Text::lit("");
    bool going = true;
    return call_then(loop_job(std::tuple{this_, cur, going, l, segs}, ({
        auto start_1 = start;
        [=](std::tuple<std::tuple<Array<TextSegTok>, Lex>, Text, bool, Lex, Array<TextSegTok>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto cur = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto l = std::get<3>(_p0);
        auto segs = std::get<4>(_p0);
        return going
            ? ({
            auto c = peek(l);
            if ((c == Text::lit("")) || (c == Text::lit("\n"))) {
                l = lex_err(l, start_1, l.pos, Text::lit("a text literal ends on its line: close it with `\"`, or write a multiline text as `raw <markdown>...</markdown>`"));
                going = false;
            } else  {
                ({
                    __label__ _done;
                    prism_rtl::Slot<Unit> _v;
                    {
                        auto&& u52163_0 = c;
                        if (u52163_0 == Text::lit("\"")) {
                            _v.set(({
                                l = bump(l);
                                going = false;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u52163_1 = c;
                        if (u52163_1 == Text::lit("\\")) {
                            _v.set(({
                                auto [s, l2] = lex_escape(l);
                                cur = prism_rtl::cat(cur, s);
                                l = l2;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u52163_2 = c;
                        if (u52163_2 == Text::lit("{")) {
                            _v.set(({
                                if (cur != Text::lit("")) {
                                    segs = prelude::push(segs, TextSegTok(TextSegTok::TsPlain{cur}));
                                    cur = Text::lit("");
                                }
                                auto ps = l.pos;
                                auto [toks, l2] = nested(bump(l), Mode(Mode::MPlaceholder{Text::lit("single")}));
                                segs = prelude::push(segs, TextSegTok(TextSegTok::TsPlaceholder{toks, ast::Range{.start = ps, .end = l2.pos}}));
                                l = l2;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u52163_3 = c;
                        if (u52163_3 == Text::lit("}")) {
                            _v.set(({
                                l = lex_err(bump(l), l.pos, l.pos + Nat(1u), Text::lit("a `}` in text is written `\\}`"));
                                cur = prism_rtl::cat(cur, "}");
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        _v.set(({
                            l = bump(l);
                            cur = prism_rtl::cat(cur, c);
                            Unit{};
                        }));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            }
            Expected<std::tuple<std::tuple<Array<TextSegTok>, Lex>, Text, bool, Lex, Array<TextSegTok>>, std::tuple<std::tuple<Array<TextSegTok>, Lex>, Text, bool, Lex, Array<TextSegTok>>>(std::tuple{this_, cur, going, l, segs});
        })
            : Expected<std::tuple<std::tuple<Array<TextSegTok>, Lex>, Text, bool, Lex, Array<TextSegTok>>, std::tuple<std::tuple<Array<TextSegTok>, Lex>, Text, bool, Lex, Array<TextSegTok>>>(unexpected(std::tuple{this_, cur, going, l, segs}));
    };
    })), [=](std::tuple<std::tuple<Array<TextSegTok>, Lex>, Text, bool, Lex, Array<TextSegTok>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto cur = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto l = std::get<3>(_p0);
        auto segs = std::get<4>(_p0);
        return ({
            if (cur != Text::lit("")) {
                segs = prelude::push(segs, TextSegTok(TextSegTok::TsPlain{cur}));
            }
            this_ = std::tuple{segs, l};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start LexText, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<TextSegTok>, Lex>> start_lex_text(Lex l0) {
    return prism_rtl::make_rc<LexText>(l0);
}


/// LexChar: unbounded fn Lex -> ((Text, Lex))
std::tuple<Text, Lex> lex_char(const Lex& l0) {
    auto start = l0.pos;
    auto l1 = bump(l0);
    auto c = peek(l1);
    auto [s, l2] = c == Text::lit("\\")
        ? lex_escape(l1)
        : ((c == Text::lit("'")) || (c == Text::lit("\n"))) || (c == Text::lit(""))
        ? std::tuple{Text::lit(""), l1}
        : std::tuple{c, bump(l1)};
    auto ok = peek(l2) == Text::lit("'");
    auto l3 = ok ? bump(l2) : char_tail(l2, start);
    auto l4 = s == Text::lit("")
        ? lex_err(l3, start, l3.pos, Text::lit("a character literal holds one code point: `'c'`"))
        : l3;
    auto ch = s == Text::lit("") ? Text::lit("\000"sv) : s;
    return std::tuple{ch, l4};
}


prism_rtl::Turn<std::tuple<Text, Lex>> LexChar::cycle() const {
    const auto& l0 = this->l0;
    auto start = l0.pos;
    auto l1 = bump(l0);
    auto c = peek(l1);
    auto [s, l2] = c == Text::lit("\\")
        ? lex_escape(l1)
        : ((c == Text::lit("'")) || (c == Text::lit("\n"))) || (c == Text::lit(""))
        ? std::tuple{Text::lit(""), l1}
        : std::tuple{c, bump(l1)};
    auto ok = peek(l2) == Text::lit("'");
    auto l3 = ok ? bump(l2) : char_tail(l2, start);
    auto l4 = s == Text::lit("")
        ? lex_err(l3, start, l3.pos, Text::lit("a character literal holds one code point: `'c'`"))
        : l3;
    auto ch = s == Text::lit("") ? Text::lit("\000"sv) : s;
    return prism_rtl::finished(std::tuple{ch, l4});
}


/// `Start LexChar, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Lex>> start_lex_char(Lex l0) {
    return prism_rtl::make_rc<LexChar>(l0);
}


/// CharTail: unbounded fn Lex, Nat -> Lex
Lex char_tail(const Lex& l0, const Nat& start) {
    auto l1 = ({
        Lex this_ = l0;
        while (((peek(this_) != Text::lit("'")) && (peek(this_) != Text::lit("\n"))) && (peek(this_) != Text::lit(""))) {
            this_.pos = this_.pos + len_text(peek(this_));
        }
        this_;
    });
    auto l2 = peek(l1) == Text::lit("'") ? bump(l1) : l1;
    return lex_err(l2, start, l2.pos, Text::lit("a character literal holds one code point: `'c'`"));
}


prism_rtl::Turn<Lex> CharTail::cycle() const {
    const auto& l0 = this->l0;
    const auto& start = this->start;
    Lex this_ = l0;
    auto start_1 = start;
    return call_then(loop_job(std::tuple{this_}, [=](std::tuple<Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return ((peek(this_) != Text::lit("'")) && (peek(this_) != Text::lit("\n"))) && (peek(this_) != Text::lit(""))
            ? ({
            this_.pos = this_.pos + len_text(peek(this_));
            Expected<std::tuple<Lex>, std::tuple<Lex>>(std::tuple{this_});
        })
            : Expected<std::tuple<Lex>, std::tuple<Lex>>(unexpected(std::tuple{this_}));
    }), [=](std::tuple<Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto l1 = this_;
            auto l2 = peek(l1) == Text::lit("'") ? bump(l1) : l1;
            (prism_rtl::finished(lex_err(l2, start_1, l2.pos, Text::lit("a character literal holds one code point: `'c'`"))));
        });
    });
}


/// `Start CharTail, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lex> start_char_tail(Lex l0, Nat start) {
    return prism_rtl::make_rc<CharTail>(l0, start);
}


/// LexPath: unbounded fn Lex -> (([PathSegTok], Lex))
std::tuple<Array<PathSegTok>, Lex> lex_path(const Lex& l0) {
    std::tuple<Array<PathSegTok>, Lex> this_ = std::tuple{Array<PathSegTok>{}, l0};
    Lex l = l0;
    Array<PathSegTok> segs = Array<PathSegTok>{};
    bool going = true;
    while (going) {
        auto s = l.pos;
        auto c = peek(l);
        if (c == Text::lit("#")) {
            auto digits = ({
                Lex this_ = bump(l);
                while (is_digit(peek(this_))) {
                    this_.pos = this_.pos + Nat(1u);
                }
                this_;
            });
            auto text = slice(digits, s + Nat(1u), digits.pos);
            l = text == Text::lit("")
                ? lex_err(digits, s, digits.pos, Text::lit("a generation segment is `#` and a number"))
                : digits;
            segs = prelude::push(segs, PathSegTok(PathSegTok::PstGen{or_(parse_nat_opt(text), Nat(0u))}));
        } else if (is_digit(c)) {
            auto digits = ({
                Lex this_ = l;
                while (is_digit(peek(this_))) {
                    this_.pos = this_.pos + Nat(1u);
                }
                this_;
            });
            segs = prelude::push(segs, PathSegTok(PathSegTok::PstNum{or_(parse_nat_opt(slice(digits, s, digits.pos)), Nat(0u))}));
            l = digits;
        } else if (c == Text::lit("[")) {
            auto [toks, l2] = nested(bump(l), Mode(Mode::MPathKey{}));
            segs = prelude::push(segs, PathSegTok(PathSegTok::PstKey{toks}));
            l = l2;
        } else  {
            l = lex_err(l, s, s, Text::lit("expected a path segment: a number, `#` and a number, or `[key]`"));
            going = false;
        }
        if (going) {
            if (peek(l) == Text::lit("/")) {
                l = bump(l);
            } else  {
                going = false;
            }
        }
    }
    this_ = std::tuple{segs, l};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<PathSegTok>, Lex>> LexPath::cycle() const {
    const auto& l0 = this->l0;
    std::tuple<Array<PathSegTok>, Lex> this_ = std::tuple{Array<PathSegTok>{}, l0};
    Lex l = l0;
    Array<PathSegTok> segs = Array<PathSegTok>{};
    bool going = true;
    return call_then(loop_job(std::tuple{this_, going, l, segs}, [=](std::tuple<std::tuple<Array<PathSegTok>, Lex>, bool, Lex, Array<PathSegTok>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto l = std::get<2>(_p0);
        auto segs = std::get<3>(_p0);
        return going
            ? ({
            auto s = l.pos;
            auto c = peek(l);
            if (c == Text::lit("#")) {
                auto digits = ({
                    Lex this_ = bump(l);
                    while (is_digit(peek(this_))) {
                        this_.pos = this_.pos + Nat(1u);
                    }
                    this_;
                });
                auto text = slice(digits, s + Nat(1u), digits.pos);
                l = text == Text::lit("")
                    ? lex_err(digits, s, digits.pos, Text::lit("a generation segment is `#` and a number"))
                    : digits;
                segs = prelude::push(segs, PathSegTok(PathSegTok::PstGen{or_(parse_nat_opt(text), Nat(0u))}));
            } else if (is_digit(c)) {
                auto digits = ({
                    Lex this_ = l;
                    while (is_digit(peek(this_))) {
                        this_.pos = this_.pos + Nat(1u);
                    }
                    this_;
                });
                segs = prelude::push(segs, PathSegTok(PathSegTok::PstNum{or_(parse_nat_opt(slice(digits, s, digits.pos)), Nat(0u))}));
                l = digits;
            } else if (c == Text::lit("[")) {
                auto [toks, l2] = nested(bump(l), Mode(Mode::MPathKey{}));
                segs = prelude::push(segs, PathSegTok(PathSegTok::PstKey{toks}));
                l = l2;
            } else  {
                l = lex_err(l, s, s, Text::lit("expected a path segment: a number, `#` and a number, or `[key]`"));
                going = false;
            }
            if (going) {
                if (peek(l) == Text::lit("/")) {
                    l = bump(l);
                } else  {
                    going = false;
                }
            }
            Expected<std::tuple<std::tuple<Array<PathSegTok>, Lex>, bool, Lex, Array<PathSegTok>>, std::tuple<std::tuple<Array<PathSegTok>, Lex>, bool, Lex, Array<PathSegTok>>>(std::tuple{this_, going, l, segs});
        })
            : Expected<std::tuple<std::tuple<Array<PathSegTok>, Lex>, bool, Lex, Array<PathSegTok>>, std::tuple<std::tuple<Array<PathSegTok>, Lex>, bool, Lex, Array<PathSegTok>>>(unexpected(std::tuple{this_, going, l, segs}));
    }), [=](std::tuple<std::tuple<Array<PathSegTok>, Lex>, bool, Lex, Array<PathSegTok>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto l = std::get<2>(_p0);
        auto segs = std::get<3>(_p0);
        return ({
            this_ = std::tuple{segs, l};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start LexPath, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<PathSegTok>, Lex>> start_lex_path(Lex l0) {
    return prism_rtl::make_rc<LexPath>(l0);
}


/// MaybeTemplate: unbounded fn Lex, Text -> Lex
Lex maybe_template(const Lex& l0, const Text& kw) {
    auto l = ({
        Lex this_ = l0;
        while (peek(this_) == Text::lit(" ")) {
            this_.pos = this_.pos + Nat(1u);
        }
        this_;
    });
    return (peek(l) == Text::lit("<")) && (template_tag_ahead(l) != Text::lit(""))
        ? ({
        auto keyword = kw == Text::lit("output")
            ? Text::lit("Output")
            : kw == Text::lit("inline_text") ? Text::lit("InlineText") : Text::lit("Raw");
        auto [kind, l2] = lex_template(l, keyword, l.pos);
        auto l3 = ({
            Lex this_ = l2;
            this_.last_ws = true;
            this_;
        });
        push_tok(l3, kind, l.pos, l3.pos);
    })
        : lex_err(l0, l0.pos, l0.pos, prism_rtl::cat("`", kw, "` is followed by a language tag, `<rust>`"));
}


prism_rtl::Turn<Lex> MaybeTemplate::cycle() const {
    const auto& l0 = this->l0;
    const auto& kw = this->kw;
    Lex this_ = l0;
    auto kw_1 = kw;
    auto l0_2 = l0;
    return call_then(loop_job(std::tuple{this_}, [=](std::tuple<Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return peek(this_) == Text::lit(" ")
            ? ({
            this_.pos = this_.pos + Nat(1u);
            Expected<std::tuple<Lex>, std::tuple<Lex>>(std::tuple{this_});
        })
            : Expected<std::tuple<Lex>, std::tuple<Lex>>(unexpected(std::tuple{this_}));
    }), [=](std::tuple<Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto l = this_;
            (peek(l) == Text::lit("<")) && (template_tag_ahead(l) != Text::lit(""))
            ? ({
            auto keyword = kw_1 == Text::lit("output")
                ? Text::lit("Output")
                : kw_1 == Text::lit("inline_text")
                ? Text::lit("InlineText")
                : Text::lit("Raw");
            call_then(start_lex_template(l, keyword, l.pos), [=](std::tuple<TokKind, Lex> lex_template_56607) {
            return ({
                auto [kind, l2] = lex_template_56607;
                auto l3 = ({
                    Lex this_ = l2;
                    this_.last_ws = true;
                    this_;
                });
                (prism_rtl::finished(push_tok(l3, kind, l.pos, l3.pos)));
            });
        });
        })
            : prism_rtl::finished(lex_err(l0_2, l0_2.pos, l0_2.pos, prism_rtl::cat("`", kw_1, "` is followed by a language tag, `<rust>`")));
        });
    });
}


/// `Start MaybeTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lex> start_maybe_template(Lex l0, Text kw) {
    return prism_rtl::make_rc<MaybeTemplate>(l0, kw);
}


/// TemplateTagAhead: unbounded fn Lex -> Text
Text template_tag_ahead(const Lex& l) {
    auto&& _name = lex_ident(bump(l));
    auto&& name = std::get<0>(_name);
    auto after_ = peek_at(l, len_text(name) + Nat(1u));
    return (((peek(l) == Text::lit("<")) && (name != Text::lit(""))) && is_lower(head(name))) && (after_ == Text::lit(">"))
        ? name
        : Text::lit("");
}


prism_rtl::Turn<Text> TemplateTagAhead::cycle() const {
    const auto& l = this->l;
    auto l_1 = l;
    return call_then(start_lex_ident(bump(l_1)), [=](std::tuple<Text, Lex> lex_ident_56998) {
        return ({
            auto&& _name = lex_ident_56998;
            auto&& name = std::get<0>(_name);
            auto after_ = peek_at(l_1, len_text(name) + Nat(1u));
            (((peek(l_1) == Text::lit("<")) && (name != Text::lit(""))) && is_lower(head(name))) && (after_ == Text::lit(">"))
            ? prism_rtl::finished(name)
            : prism_rtl::finished(Text::lit(""));
        });
    });
}


/// `Start TemplateTagAhead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_template_tag_ahead(Lex l) {
    return prism_rtl::make_rc<TemplateTagAhead>(l);
}


/// LexTemplate: unbounded fn Lex, Text, Nat -> ((TokKind, Lex))
std::tuple<TokKind, Lex> lex_template(const Lex& l0, const Text& keyword, const Nat& start) {
    auto lang = template_tag_ahead(l0);
    auto l1 = lexer::forward(l0, len_text(lang) + Nat(2u));
    auto delims = (lang == Text::lit("markdown")) || (lang == Text::lit("html"))
        ? Text::lit("single")
        : Text::lit("double");
    auto ends_line = (peek(l1) == Text::lit("\n")) || starts_with(l1, Text::lit("\r\n"));
    auto skip = peek(l1) == Text::lit("\r") ? Nat(2u) : Nat(1u);
    auto l2 = ends_line ? lexer::forward(l1, skip) : l1;
    auto [parts, l3] = template_body(l2, prism_rtl::cat("</", lang, ">"), delims, keyword == Text::lit("Raw"), !ends_line, start);
    auto kind = TokKind(TokKind::KTemplate{TemplateTok{.keyword = keyword, .lang = lang, .delims = delims, .parts = parts}});
    return std::tuple{kind, l3};
}


prism_rtl::Turn<std::tuple<TokKind, Lex>> LexTemplate::cycle() const {
    const auto& l0 = this->l0;
    const auto& keyword = this->keyword;
    const auto& start = this->start;
    auto keyword_1 = keyword;
    auto l0_2 = l0;
    auto start_3 = start;
    return call_then(start_template_tag_ahead(l0_2), [=](Text template_tag_ahead_57331) {
        return ({
            auto lang = template_tag_ahead_57331;
            auto l1 = lexer::forward(l0_2, len_text(lang) + Nat(2u));
            auto delims = (lang == Text::lit("markdown")) || (lang == Text::lit("html"))
                ? Text::lit("single")
                : Text::lit("double");
            auto ends_line = (peek(l1) == Text::lit("\n")) || starts_with(l1, Text::lit("\r\n"));
            auto skip = peek(l1) == Text::lit("\r") ? Nat(2u) : Nat(1u);
            auto l2 = ends_line ? lexer::forward(l1, skip) : l1;
            call_then(start_template_body(l2, prism_rtl::cat("</", lang, ">"), delims, keyword_1 == Text::lit("Raw"), !ends_line, start_3), [=](std::tuple<Array<TPartTok>, Lex> template_body_57745) {
            return ({
                auto [parts, l3] = template_body_57745;
                auto kind = TokKind(TokKind::KTemplate{TemplateTok{.keyword = keyword_1, .lang = lang, .delims = delims, .parts = parts}});
                (prism_rtl::finished(std::tuple{kind, l3}));
            });
        });
        });
    });
}


/// `Start LexTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<TokKind, Lex>> start_lex_template(Lex l0, Text keyword, Nat start) {
    return prism_rtl::make_rc<LexTemplate>(l0, keyword, start);
}


/// let emptyLine
RawLine empty_line() {
    return RawLine{.items = Array<RawItem>{}, .newline = false, .block = false};
}


/// AddItem: fn RawLine, RawItem -> RawLine
RawLine add_item(const RawLine& line, const RawItem& item) {
    RawLine this_ = line;
    this_.items = add_raw(this_.items, item);
    return this_;
}


/// AddRaw: fn [RawItem], RawItem -> [RawItem]
Array<RawItem> add_raw(const Array<RawItem>& items, const RawItem& raw_item1) {
    if (prism_rtl::is<RawItem::RiText>(raw_item1)) {
        auto&& t = prism_rtl::as<RawItem::RiText>(raw_item1).a0;
        auto&& _m = last(items);
        if (prism_rtl::is_some(_m) && prism_rtl::is<RawItem::RiText>(prism_rtl::some_of(_m))) {
            auto&& s = prism_rtl::as<RawItem::RiText>(prism_rtl::some_of(_m)).a0;
            return prelude::push(pop(items), RawItem(RawItem::RiText{prism_rtl::cat(s, t)}));
        }
        {
            return prelude::push(items, RawItem(RawItem::RiText{t}));
        }
    }
    {
        auto&& item = raw_item1;
        return prelude::push(items, item);
    }
}


/// OnlyWhitespace: fn RawLine -> Bool
bool only_whitespace(const RawLine& line) {
    return fold(line.items, true, [&](const bool& ok, const RawItem& it) { return ok && is_blank_text(it); });
}


/// IsBlankText: fn RawItem -> Bool
bool is_blank_text(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiText>(raw_item0)) {
        auto&& s = prism_rtl::as<RawItem::RiText>(raw_item0).a0;
        return all_chars(s, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
            return once_job([=]() {
                return ({
                    auto c = p0;
                    (prism_rtl::finished((c == Text::lit(" ")) || (c == Text::lit("\r"))));
                });
            });
        })));
    }
    {
        return false;
    }
}


/// TextLen: fn RawLine -> Nat
Nat text_len(const RawLine& line) {
    return fold(line.items, Nat(0u), [&](const Nat& n, const RawItem& it) { return n + text_len_of(it); });
}


/// TextLenOf: fn RawItem -> Nat
Nat text_len_of(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiText>(raw_item0)) {
        auto&& s = prism_rtl::as<RawItem::RiText>(raw_item0).a0;
        return len_text(s);
    }
    {
        return Nat(0u);
    }
}


/// TemplateBody: unbounded fn Lex, Text, Text, Bool, Bool, Nat -> (([TPartTok], Lex))
std::tuple<Array<TPartTok>, Lex> template_body(const Lex& l0, const Text& close, const Text& delims, const bool& is_raw, const bool& first_continues, const Nat& open_start) {
    auto open = delims == Text::lit("double") ? Text::lit("{{") : Text::lit("{");
    auto how = TplHow{.close = close, .delims = delims, .open = open, .is_raw = is_raw, .first_continues = first_continues};
    auto start = TplRead{.l = l0, .lines = Array<RawLine>{}, .cur = empty_line(), .closing_col = std::optional<Nat>{}, .closed = false, .at_line_start = !first_continues, .going = true};
    auto r = ({
        TplRead this_ = start;
        while (this_.going) {
            this_ = template_step(this_, how);
        }
        this_;
    });
    auto l1 = r.closed
        ? r.l
        : lex_err(r.l, open_start, r.l.pos, prism_rtl::cat("a template never closes: expected `", close, "`"));
    return finish_template_lines(l1, prelude::push(r.lines, r.cur), or_(r.closing_col, Nat(0u)), first_continues);
}


prism_rtl::Turn<std::tuple<Array<TPartTok>, Lex>> TemplateBody::cycle() const {
    const auto& l0 = this->l0;
    const auto& close = this->close;
    const auto& delims = this->delims;
    const auto& is_raw = this->is_raw;
    const auto& first_continues = this->first_continues;
    const auto& open_start = this->open_start;
    auto open = delims == Text::lit("double") ? Text::lit("{{") : Text::lit("{");
    auto how = TplHow{.close = close, .delims = delims, .open = open, .is_raw = is_raw, .first_continues = first_continues};
    auto start = TplRead{.l = l0, .lines = Array<RawLine>{}, .cur = empty_line(), .closing_col = std::optional<Nat>{}, .closed = false, .at_line_start = !first_continues, .going = true};
    TplRead this_ = start;
    auto close_1 = close;
    auto first_continues_2 = first_continues;
    auto open_start_3 = open_start;
    return call_then(loop_job(std::tuple{this_}, ({
        auto how_4 = how;
        [=](std::tuple<TplRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return this_.going
            ? ({
            this_ = template_step(this_, how_4);
            Expected<std::tuple<TplRead>, std::tuple<TplRead>>(std::tuple{this_});
        })
            : Expected<std::tuple<TplRead>, std::tuple<TplRead>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<TplRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto r = this_;
            auto l1 = r.closed
                ? r.l
                : lex_err(r.l, open_start_3, r.l.pos, prism_rtl::cat("a template never closes: expected `", close_1, "`"));
            (prism_rtl::finished(finish_template_lines(l1, prelude::push(r.lines, r.cur), or_(r.closing_col, Nat(0u)), first_continues_2)));
        });
    });
}


/// `Start TemplateBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<TPartTok>, Lex>> start_template_body(Lex l0, Text close, Text delims, bool is_raw, bool first_continues, Nat open_start) {
    return prism_rtl::make_rc<TemplateBody>(l0, close, delims, is_raw, first_continues, open_start);
}


/// TemplateStep: unbounded fn TplRead, TplHow -> TplRead
TplRead template_step(const TplRead& s, const TplHow& how) {
    auto rest_ = rest_of_line(s.l);
    auto c = peek(s.l);
    return (s.at_line_start && (!how.is_raw)) && (trim(rest_) == how.open)
        ? brace_block_line(s, rest_, how)
        : starts_with(s.l, how.close)
        ? close_template(s, how)
        : c == Text::lit("")
        ? ({
        TplRead this_ = s;
        this_.at_line_start = false;
        this_.going = false;
        this_;
    })
        : c == Text::lit("\n")
        ? ({
        TplRead this_ = s;
        this_.l = bump(this_.l);
        this_.cur.newline = true;
        this_.lines = prelude::push(this_.lines, this_.cur);
        this_.cur = empty_line();
        this_.at_line_start = true;
        this_;
    })
        : ({
        auto [item, l2] = template_item(s.l, how);
        ({
        TplRead this_ = s;
        this_.at_line_start = false;
        this_.l = l2;
        this_.cur = add_item(this_.cur, item);
        this_;
    });
    });
}


prism_rtl::Turn<TplRead> TemplateStep::cycle() const {
    const auto& s = this->s;
    const auto& how = this->how;
    auto how_1 = how;
    auto s_2 = s;
    return call_then(start_rest_of_line(s_2.l), [=](Text rest_of_line_60605) {
        return ({
            auto rest_ = rest_of_line_60605;
            auto c = peek(s_2.l);
            (s_2.at_line_start && (!how_1.is_raw)) && (trim(rest_) == how_1.open)
            ? prism_rtl::more(prism_rtl::rc(BraceBlockLine(s_2, rest_, how_1)))
            : starts_with(s_2.l, how_1.close)
            ? prism_rtl::finished(close_template(s_2, how_1))
            : c == Text::lit("")
            ? prism_rtl::finished(({
            TplRead this_ = s_2;
            this_.at_line_start = false;
            this_.going = false;
            this_;
        }))
            : c == Text::lit("\n")
            ? prism_rtl::finished(({
            TplRead this_ = s_2;
            this_.l = bump(this_.l);
            this_.cur.newline = true;
            this_.lines = prelude::push(this_.lines, this_.cur);
            this_.cur = empty_line();
            this_.at_line_start = true;
            this_;
        }))
            : call_then(start_template_item(s_2.l, how_1), [=](std::tuple<RawItem, Lex> template_item_61212) {
            return ({
                auto [item, l2] = template_item_61212;
                (prism_rtl::finished(({
                TplRead this_ = s_2;
                this_.at_line_start = false;
                this_.l = l2;
                this_.cur = add_item(this_.cur, item);
                this_;
            })));
            });
        });
        });
    });
}


/// `Start TemplateStep, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TplRead> start_template_step(TplRead s, TplHow how) {
    return prism_rtl::make_rc<TemplateStep>(s, how);
}


/// BraceBlockLine: unbounded fn TplRead, Text, TplHow -> TplRead
TplRead brace_block_line(const TplRead& s, const Text& rest_, const TplHow& how) {
    auto bs = s.l.pos;
    auto past = lexer::forward(s.l, len_text(rest_));
    auto at_ = peek(past) == Text::lit("\n") ? bump(past) : past;
    auto [toks, l2] = nested(at_, Mode(Mode::MBrace{how.delims}));
    auto line = RawLine{.items = Array(std::vector{RawItem(RawItem::RiBlock{toks, ast::Range{.start = bs, .end = l2.pos}})}), .newline = false, .block = true};
    TplRead this_ = s;
    this_.lines = prelude::push(this_.lines, line);
    this_.l = l2;
    return this_;
}


prism_rtl::Turn<TplRead> BraceBlockLine::cycle() const {
    const auto& s = this->s;
    const auto& rest_ = this->rest_;
    const auto& how = this->how;
    auto bs = s.l.pos;
    auto past = lexer::forward(s.l, len_text(rest_));
    auto at_ = peek(past) == Text::lit("\n") ? bump(past) : past;
    auto how_1 = how;
    auto s_2 = s;
    return call_then(start_nested(at_, Mode(Mode::MBrace{how_1.delims})), [=](std::tuple<Array<Tok>, Lex> nested_61590) {
        return ({
            auto [toks, l2] = nested_61590;
            auto line = RawLine{.items = Array(std::vector{RawItem(RawItem::RiBlock{toks, ast::Range{.start = bs, .end = l2.pos}})}), .newline = false, .block = true};
            (prism_rtl::finished(({
            TplRead this_ = s_2;
            this_.lines = prelude::push(this_.lines, line);
            this_.l = l2;
            this_;
        })));
        });
    });
}


/// `Start BraceBlockLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TplRead> start_brace_block_line(TplRead s, Text rest_, TplHow how) {
    return prism_rtl::make_rc<BraceBlockLine>(s, rest_, how);
}


/// CloseTemplate: fn TplRead, TplHow -> TplRead
TplRead close_template(const TplRead& s, const TplHow& how) {
    TplRead this_ = s;
    this_.at_line_start = false;
    if (only_whitespace(this_.cur) && ((len(this_.lines) > Nat(0u)) || (!how.first_continues))) {
        this_.closing_col = std::optional(text_len(this_.cur));
        this_.cur.items = Array<RawItem>{};
    }
    this_.l = lexer::forward(this_.l, len_text(how.close));
    this_.closed = true;
    this_.going = false;
    return this_;
}


/// TemplateItem: unbounded fn Lex, TplHow -> ((RawItem, Lex))
std::tuple<RawItem, Lex> template_item(const Lex& l, const TplHow& how) {
    auto live = !how.is_raw;
    return (live && (how.delims == Text::lit("double"))) && starts_with(l, Text::lit("\\{{"))
        ? std::tuple{RawItem(RawItem::RiText{Text::lit("{{")}), lexer::forward(l, Nat(3u))}
        : (live && (how.delims == Text::lit("single"))) && starts_with(l, Text::lit("\\{"))
        ? std::tuple{RawItem(RawItem::RiText{Text::lit("{")}), lexer::forward(l, Nat(2u))}
        : live && starts_with(l, how.open)
        ? ({
        auto ps = l.pos;
        auto [toks, l2] = nested(lexer::forward(l, len_text(how.open)), Mode(Mode::MPlaceholder{how.delims}));
        auto item = RawItem(RawItem::RiPlaceholder{toks, ast::Range{.start = ps, .end = l2.pos}});
        std::tuple{item, l2};
    })
        : (live && starts_with(l, Text::lit("<@"))) && is_upper(peek_at(l, Nat(2u)))
        ? template_call(l, how.delims, how.open)
        : std::tuple{RawItem(RawItem::RiText{peek(l)}), bump(l)};
}


prism_rtl::Turn<std::tuple<RawItem, Lex>> TemplateItem::cycle() const {
    const auto& l = this->l;
    const auto& how = this->how;
    auto live = !how.is_raw;
    return (live && (how.delims == Text::lit("double"))) && starts_with(l, Text::lit("\\{{"))
        ? prism_rtl::finished(std::tuple{RawItem(RawItem::RiText{Text::lit("{{")}), lexer::forward(l, Nat(3u))})
        : (live && (how.delims == Text::lit("single"))) && starts_with(l, Text::lit("\\{"))
        ? prism_rtl::finished(std::tuple{RawItem(RawItem::RiText{Text::lit("{")}), lexer::forward(l, Nat(2u))})
        : live && starts_with(l, how.open)
        ? ({
        auto ps = l.pos;
        auto how_1 = how;
        auto l_2 = l;
        call_then(start_nested(lexer::forward(l_2, len_text(how_1.open)), Mode(Mode::MPlaceholder{how_1.delims})), [=](std::tuple<Array<Tok>, Lex> nested_62836) {
        return ({
            auto [toks, l2] = nested_62836;
            auto item = RawItem(RawItem::RiPlaceholder{toks, ast::Range{.start = ps, .end = l2.pos}});
            (prism_rtl::finished(std::tuple{item, l2}));
        });
    });
    })
        : (live && starts_with(l, Text::lit("<@"))) && is_upper(peek_at(l, Nat(2u)))
        ? prism_rtl::more(prism_rtl::rc(TemplateCall(l, how.delims, how.open)))
        : prism_rtl::finished(std::tuple{RawItem(RawItem::RiText{peek(l)}), bump(l)});
}


/// `Start TemplateItem, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<RawItem, Lex>> start_template_item(Lex l, TplHow how) {
    return prism_rtl::make_rc<TemplateItem>(l, how);
}


/// TemplateCall: unbounded fn Lex, Text, Text -> ((RawItem, Lex))
std::tuple<RawItem, Lex> template_call(const Lex& l0, const Text& delims, const Text& open) {
    auto start = l0.pos;
    auto&& _sigils = read_sigils(bump(l0));
    auto&& sigils = std::get<0>(_sigils);
    auto&& l1 = std::get<2>(_sigils);
    auto [path_, l2] = lex_qualified_path(l1);
    auto name = NameTok{.sigils = sigils, .path_ = path_, .case_ = NameCase(NameCase::CaseUpper{})};
    auto close = prism_rtl::cat("</", sigils, join(path_, Text::lit(".")), ">");
    auto r = ({
        CallRead this_ = CallRead{.l = l2, .attrs = Array<AttrTok>{}, .body = std::optional<Array<TPartTok>>{}, .going = true};
        while (this_.going) {
            this_ = call_step(this_, start, close, delims, open);
        }
        this_;
    });
    auto item = RawItem(RawItem::RiCall{name, r.attrs, r.body, ast::Range{.start = start, .end = r.l.pos}});
    return std::tuple{item, r.l};
}


prism_rtl::Turn<std::tuple<RawItem, Lex>> TemplateCall::cycle() const {
    const auto& l0 = this->l0;
    const auto& delims = this->delims;
    const auto& open = this->open;
    auto start = l0.pos;
    auto delims_1 = delims;
    auto l0_2 = l0;
    auto open_3 = open;
    return call_then(start_read_sigils(bump(l0_2)), [=](std::tuple<Text, bool, Lex> read_sigils_63568) {
        return ({
            auto&& _sigils = read_sigils_63568;
            auto&& sigils = std::get<0>(_sigils);
            auto&& l1 = std::get<2>(_sigils);
            call_then(start_lex_qualified_path(l1), [=](std::tuple<Array<Text>, Lex> lex_qualified_path_63612) {
            return ({
                auto [path_, l2] = lex_qualified_path_63612;
                auto name = NameTok{.sigils = sigils, .path_ = path_, .case_ = NameCase(NameCase::CaseUpper{})};
                auto close = prism_rtl::cat("</", sigils, join(path_, Text::lit(".")), ">");
                CallRead this_ = CallRead{.l = l2, .attrs = Array<AttrTok>{}, .body = std::optional<Array<TPartTok>>{}, .going = true};
                auto name_4 = name;
                auto start_5 = start;
                call_then(loop_job(std::tuple{this_}, ({
                auto close_6 = close;
                auto delims_1_7 = delims_1;
                auto open_3_7 = open_3;
                auto start_5_7 = start_5;
                [=](std::tuple<CallRead> _p0) {
                auto this_ = std::get<0>(_p0);
                return this_.going
                    ? ({
                    this_ = call_step(this_, start_5_7, close_6, delims_1_7, open_3_7);
                    Expected<std::tuple<CallRead>, std::tuple<CallRead>>(std::tuple{this_});
                })
                    : Expected<std::tuple<CallRead>, std::tuple<CallRead>>(unexpected(std::tuple{this_}));
            };
            })), [=](std::tuple<CallRead> _p0) {
                auto this_ = std::get<0>(_p0);
                return ({
                    auto r = this_;
                    auto item = RawItem(RawItem::RiCall{name_4, r.attrs, r.body, ast::Range{.start = start_5, .end = r.l.pos}});
                    (prism_rtl::finished(std::tuple{item, r.l}));
                });
            });
            });
        });
        });
    });
}


/// `Start TemplateCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<RawItem, Lex>> start_template_call(Lex l0, Text delims, Text open) {
    return prism_rtl::make_rc<TemplateCall>(l0, delims, open);
}


/// CallStep: unbounded fn CallRead, Nat, Text, Text, Text -> CallRead
CallRead call_step(const CallRead& s0, const Nat& start, const Text& close, const Text& delims, const Text& open) {
    auto l = ({
        Lex this_ = s0.l;
        while (contains(Text::lit(" \n\r"), peek(this_))) {
            this_.pos = this_.pos + Nat(1u);
        }
        this_;
    });
    auto s = ({
        CallRead this_ = s0;
        this_.l = l;
        this_;
    });
    auto at_ = l.pos;
    return starts_with(l, Text::lit("/>"))
        ? ({
        CallRead this_ = s;
        this_.l = lexer::forward(l, Nat(2u));
        this_.going = false;
        this_;
    })
        : peek(l) == Text::lit(">")
        ? ({
        auto past = bump(l);
        auto continues = peek(past) != Text::lit("\n");
        auto from = continues ? past : bump(past);
        auto [parts, l3] = template_body(from, close, delims, false, continues, start);
        ({
        CallRead this_ = s;
        this_.body = std::optional(parts);
        this_.l = l3;
        this_.going = false;
        this_;
    });
    })
        : !is_ident_start(peek(l))
        ? ({
        CallRead this_ = s;
        this_.l = lex_err(l, at_, at_ + Nat(1u), Text::lit("expected an attribute `name=value`, `/>` or `>` in a template call"));
        this_.going = false;
        this_;
    })
        : ({
        auto [aname, l3] = lex_ident(l);
        peek(l3) != Text::lit("=")
        ? ({
        CallRead this_ = s;
        this_.l = lex_err(l3, at_, l3.pos, Text::lit("an attribute is `name=value`"));
        this_;
    })
        : ({
        auto [tokens, l4] = attr_value(bump(l3), delims, open);
        ({
        CallRead this_ = s;
        this_.attrs = prelude::push(this_.attrs, AttrTok{.name = aname, .tokens = tokens, .span = ast::Range{.start = at_, .end = l4.pos}});
        this_.l = l4;
        this_;
    });
    });
    });
}


prism_rtl::Turn<CallRead> CallStep::cycle() const {
    const auto& s0 = this->s0;
    const auto& start = this->start;
    const auto& close = this->close;
    const auto& delims = this->delims;
    const auto& open = this->open;
    Lex this_ = s0.l;
    auto close_1 = close;
    auto delims_2 = delims;
    auto open_3 = open;
    auto s0_4 = s0;
    auto start_5 = start;
    return call_then(loop_job(std::tuple{this_}, [=](std::tuple<Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return contains(Text::lit(" \n\r"), peek(this_))
            ? ({
            this_.pos = this_.pos + Nat(1u);
            Expected<std::tuple<Lex>, std::tuple<Lex>>(std::tuple{this_});
        })
            : Expected<std::tuple<Lex>, std::tuple<Lex>>(unexpected(std::tuple{this_}));
    }), [=](std::tuple<Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto l = this_;
            auto s = ({
                CallRead this_ = s0_4;
                this_.l = l;
                this_;
            });
            auto at_ = l.pos;
            starts_with(l, Text::lit("/>"))
            ? prism_rtl::finished(({
            CallRead this_ = s;
            this_.l = lexer::forward(l, Nat(2u));
            this_.going = false;
            this_;
        }))
            : peek(l) == Text::lit(">")
            ? ({
            auto past = bump(l);
            auto continues = peek(past) != Text::lit("\n");
            auto from = continues ? past : bump(past);
            call_then(start_template_body(from, close_1, delims_2, false, continues, start_5), [=](std::tuple<Array<TPartTok>, Lex> template_body_64547) {
            return ({
                auto [parts, l3] = template_body_64547;
                (prism_rtl::finished(({
                CallRead this_ = s;
                this_.body = std::optional(parts);
                this_.l = l3;
                this_.going = false;
                this_;
            })));
            });
        });
        })
            : !is_ident_start(peek(l))
            ? prism_rtl::finished(({
            CallRead this_ = s;
            this_.l = lex_err(l, at_, at_ + Nat(1u), Text::lit("expected an attribute `name=value`, `/>` or `>` in a template call"));
            this_.going = false;
            this_;
        }))
            : call_then(start_lex_ident(l), [=](std::tuple<Text, Lex> lex_ident_64946) {
            return ({
                auto [aname, l3] = lex_ident_64946;
                peek(l3) != Text::lit("=")
                ? prism_rtl::finished(({
                CallRead this_ = s;
                this_.l = lex_err(l3, at_, l3.pos, Text::lit("an attribute is `name=value`"));
                this_;
            }))
                : ({
                auto [tokens, l4] = attr_value(bump(l3), delims_2, open_3);
                (prism_rtl::finished(({
                CallRead this_ = s;
                this_.attrs = prelude::push(this_.attrs, AttrTok{.name = aname, .tokens = tokens, .span = ast::Range{.start = at_, .end = l4.pos}});
                this_.l = l4;
                this_;
            })));
            });
            });
        });
        });
    });
}


/// `Start CallStep, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<CallRead> start_call_step(CallRead s0, Nat start, Text close, Text delims, Text open) {
    return prism_rtl::make_rc<CallStep>(s0, start, close, delims, open);
}


/// AttrValue: unbounded fn Lex, Text, Text -> (([Tok], Lex))
std::tuple<Array<Tok>, Lex> attr_value(const Lex& l, const Text& delims, const Text& open) {
    return starts_with(l, open)
        ? nested(lexer::forward(l, len_text(open)), Mode(Mode::MPlaceholder{delims}))
        : peek(l) == Text::lit("\"")
        ? ({
        auto [text, l2] = lex_text(l);
        auto tok = Tok{.kind = TokKind(TokKind::KText{Text::lit(""), text}), .span = ast::Range{.start = l.pos, .end = l2.pos}, .touches = false, .line_start = false};
        std::tuple{Array(std::vector{tok}), l2};
    })
        : std::tuple{Array<Tok>{}, lex_err(l, l.pos, l.pos, prism_rtl::cat("an attribute's value is a placeholder `", open, "...` or a text literal"))};
}


/// FinishTemplateLines: fn Lex, [RawLine], Nat, Bool -> (([TPartTok], Lex))
std::tuple<Array<TPartTok>, Lex> finish_template_lines(const Lex& l0, const Array<RawLine>& lines, const Nat& strip, const bool& first_continues) {
    std::tuple<Array<TPartTok>, Lex> this_ = std::tuple{Array<TPartTok>{}, l0};
    Lex l = l0;
    Array<TPartTok> parts = Array<TPartTok>{};
    for (auto&& [i66299, v66299] : prism_rtl::enumerate(lines)) {
        auto k66299 = nat_of(i66299);
        auto line = v66299;
        if (line.block) {
            parts = append(parts, block_parts(line.items));
        } else  {
            auto first_ = (k66299 == Nat(0u)) && first_continues;
            auto [items, l2] = (!first_) && (strip > Nat(0u))
                ? strip_line(line, strip, l)
                : std::tuple{line.items, l};
            l = l2;
            auto non_blank = fold(items, Array<RawItem>{}, [&](const Array<RawItem>& acc, const RawItem& it) { return is_blank_or_empty(it) ? acc : prelude::push(acc, it); });
            auto alone = (((!first_) && line.newline) && (len(non_blank) == Nat(1u))) && is_placeholder_item(or_(index(non_blank, Nat(0u)), RawItem(RawItem::RiText{Text::lit("")})));
            if (alone) {
                parts = prelude::push(parts, alone_placeholder(items));
            } else  {
                parts = fold(items, parts, push_part);
                if (line.newline) {
                    parts = push_part(parts, RawItem(RawItem::RiText{Text::lit("\n")}));
                }
            }
        }
    }
    this_ = std::tuple{parts, l};
    return this_;
}


/// BlockParts: fn [RawItem] -> [TPartTok]
Array<TPartTok> block_parts(const Array<RawItem>& items) {
    return fold(items, Array<TPartTok>{}, [&](const Array<TPartTok>& acc, const RawItem& it) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<TPartTok>> _v;
            if (prism_rtl::is<RawItem::RiBlock>(it)) {
                auto&& tokens = prism_rtl::as<RawItem::RiBlock>(it).a0;
                auto&& span = prism_rtl::as<RawItem::RiBlock>(it).a1;
                _v.set(prelude::push(acc, TPartTok(TPartTok::TptBlock{tokens, span})));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// StripLine: fn RawLine, Nat, Lex -> (([RawItem], Lex))
std::tuple<Array<RawItem>, Lex> strip_line(const RawLine& line, const Nat& strip, const Lex& l) {
    auto blank = only_whitespace(line);
    auto n = ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = index(line.items, Nat(0u));
        if (prism_rtl::is_some(_m) && prism_rtl::is<RawItem::RiText>(prism_rtl::some_of(_m))) {
            auto&& s = prism_rtl::as<RawItem::RiText>(prism_rtl::some_of(_m)).a0;
            _v.set(leading_in(s, Text::lit(" ")));
            goto _done;
        }
        {
            _v.set(Nat(0u));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto items = ({
        __label__ _done;
        prism_rtl::Slot<Array<RawItem>> _v;
        auto&& _m = index(line.items, Nat(0u));
        if (prism_rtl::is_some(_m) && prism_rtl::is<RawItem::RiText>(prism_rtl::some_of(_m))) {
            auto&& s = prism_rtl::as<RawItem::RiText>(prism_rtl::some_of(_m)).a0;
            _v.set(({
                auto rest_ = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = cursor_at(s, prelude::min(n, strip));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c = prism_rtl::some_of(_m);
                        _v.set(after(c));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                append(Array(std::vector{RawItem(RawItem::RiText{rest_})}), drop(line.items, Nat(1u)));
            }));
            goto _done;
        }
        {
            _v.set(line.items);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto l2 = (n < strip) && (!blank)
        ? lex_err(l, first_item_span(items).start, first_item_span(items).end, Text::lit("a template line is indented less than its closing tag (Q-CT3)"))
        : l;
    auto kept = index(items, Nat(0u)) == std::optional(RawItem(RawItem::RiText{Text::lit("")}))
        ? drop(items, Nat(1u))
        : items;
    return std::tuple{kept, l2};
}


/// IsBlankOrEmpty: fn RawItem -> Bool
bool is_blank_or_empty(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiText>(raw_item0)) {
        auto&& s = prism_rtl::as<RawItem::RiText>(raw_item0).a0;
        return trim(s) == Text::lit("");
    }
    {
        return false;
    }
}


/// IsPlaceholderItem: fn RawItem -> Bool
bool is_placeholder_item(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiPlaceholder>(raw_item0)) {
        return true;
    }
    {
        return false;
    }
}


/// FirstItemSpan: fn [RawItem] -> Range
ast::Range first_item_span(const Array<RawItem>& items) {
    return or_(fold(items, std::optional<ast::Range>{}, [&](const std::optional<ast::Range>& found_opt, const RawItem& it) { return found_opt != std::optional<ast::Range>{} ? found_opt : item_span(it); }), ast::Range{.start = Nat(0u), .end = Nat(0u)});
}


/// ?ItemSpan: fn RawItem -> ?Range
std::optional<ast::Range> item_span(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiPlaceholder>(raw_item0)) {
        auto&& span = prism_rtl::as<RawItem::RiPlaceholder>(raw_item0).a1;
        return std::optional(span);
    }
    if (prism_rtl::is<RawItem::RiBlock>(raw_item0)) {
        auto&& span = prism_rtl::as<RawItem::RiBlock>(raw_item0).a1;
        return std::optional(span);
    }
    if (prism_rtl::is<RawItem::RiCall>(raw_item0)) {
        auto&& span = prism_rtl::as<RawItem::RiCall>(raw_item0).a3;
        return std::optional(span);
    }
    {
        return std::optional<ast::Range>{};
    }
}


/// AlonePlaceholder: fn [RawItem] -> TPartTok
TPartTok alone_placeholder(const Array<RawItem>& items) {
    auto&& _part = fold(items, std::tuple{Nat(0u), TPartTok(TPartTok::TptText{Text::lit("")})}, [&](const std::tuple<Nat, TPartTok>& _p0, const RawItem& it) {
        auto&& c = std::get<0>(_p0);
        auto&& p_ = std::get<1>(_p0);
        return alone_step(c, p_, it);
    });
    auto&& part = std::get<1>(_part);
    return part;
}


/// AloneStep: fn Nat, TPartTok, RawItem -> ((Nat, TPartTok))
std::tuple<Nat, TPartTok> alone_step(const Nat& c, const TPartTok& tpart_tok1, const RawItem& raw_item2) {
    auto&& _m = std::tuple{tpart_tok1, raw_item2};
    if (prism_rtl::is<TPartTok::TptText>(std::get<0>(_m)) && prism_rtl::is<RawItem::RiText>(std::get<1>(_m))) {
        auto&& c0_1_0 = prism_rtl::as<TPartTok::TptText>(std::get<0>(_m)).a0;
        auto&& s = prism_rtl::as<RawItem::RiText>(std::get<1>(_m)).a0;
        if (c0_1_0 == Text::lit("")) {
            return c == Nat(0u)
                ? std::tuple{leading_in(s, Text::lit(" ")), TPartTok(TPartTok::TptText{Text::lit("")})}
                : std::tuple{c, TPartTok(TPartTok::TptText{Text::lit("")})};
        }
    }
    if (prism_rtl::is<TPartTok::TptText>(std::get<0>(_m)) && prism_rtl::is<RawItem::RiPlaceholder>(std::get<1>(_m))) {
        auto&& c1_1_0 = prism_rtl::as<TPartTok::TptText>(std::get<0>(_m)).a0;
        auto&& tokens = prism_rtl::as<RawItem::RiPlaceholder>(std::get<1>(_m)).a0;
        auto&& span = prism_rtl::as<RawItem::RiPlaceholder>(std::get<1>(_m)).a1;
        if (c1_1_0 == Text::lit("")) {
            return std::tuple{c, TPartTok(TPartTok::TptPlaceholder{tokens, std::optional(c), span})};
        }
    }
    {
        auto&& p_ = std::get<0>(_m);
        return std::tuple{c, p_};
    }
    prism_rtl::unreachable("no arm matched");
}


/// PushPart: fn [TPartTok], RawItem -> [TPartTok]
Array<TPartTok> push_part(const Array<TPartTok>& parts, const RawItem& raw_item1) {
    if (prism_rtl::is<RawItem::RiText>(raw_item1)) {
        auto&& c0_1_0 = prism_rtl::as<RawItem::RiText>(raw_item1).a0;
        if (c0_1_0 == Text::lit("")) {
            return parts;
        }
    }
    if (prism_rtl::is<RawItem::RiText>(raw_item1)) {
        auto&& t = prism_rtl::as<RawItem::RiText>(raw_item1).a0;
        auto&& _m = last(parts);
        if (prism_rtl::is_some(_m) && prism_rtl::is<TPartTok::TptText>(prism_rtl::some_of(_m))) {
            auto&& s = prism_rtl::as<TPartTok::TptText>(prism_rtl::some_of(_m)).a0;
            return prelude::push(pop(parts), TPartTok(TPartTok::TptText{prism_rtl::cat(s, t)}));
        }
        {
            return prelude::push(parts, TPartTok(TPartTok::TptText{t}));
        }
    }
    if (prism_rtl::is<RawItem::RiPlaceholder>(raw_item1)) {
        auto&& tokens = prism_rtl::as<RawItem::RiPlaceholder>(raw_item1).a0;
        auto&& span = prism_rtl::as<RawItem::RiPlaceholder>(raw_item1).a1;
        return prelude::push(parts, TPartTok(TPartTok::TptPlaceholder{tokens, std::optional<Nat>{}, span}));
    }
    if (prism_rtl::is<RawItem::RiBlock>(raw_item1)) {
        auto&& tokens = prism_rtl::as<RawItem::RiBlock>(raw_item1).a0;
        auto&& span = prism_rtl::as<RawItem::RiBlock>(raw_item1).a1;
        return prelude::push(parts, TPartTok(TPartTok::TptBlock{tokens, span}));
    }
    if (prism_rtl::is<RawItem::RiCall>(raw_item1)) {
        auto&& name = prism_rtl::as<RawItem::RiCall>(raw_item1).a0;
        auto&& attrs = prism_rtl::as<RawItem::RiCall>(raw_item1).a1;
        auto&& body_opt = prism_rtl::as<RawItem::RiCall>(raw_item1).a2;
        auto&& span = prism_rtl::as<RawItem::RiCall>(raw_item1).a3;
        return prelude::push(parts, TPartTok(TPartTok::TptCall{name, attrs, body_opt, span}));
    }
    prism_rtl::unreachable("no arm matched");
}


/// RenderTokens: fn [Tok] -> Text
Text render_tokens(const Array<Tok>& tokens) {
    auto&& _out = fold(tokens, std::tuple{Text::lit(""), std::optional<Tok>{}}, [&](const std::tuple<Text, std::optional<Tok>>& _p0, const Tok& t) {
        auto&& acc = std::get<0>(_p0);
        auto&& prev_opt = std::get<1>(_p0);
        return render_step(acc, prev_opt, t);
    });
    auto&& out = std::get<0>(_out);
    return prism_rtl::cat(out, "\n");
}


/// RenderStep: fn Text, ?Tok, Tok -> ((Text, ?Tok))
std::tuple<Text, std::optional<Tok>> render_step(const Text& acc, const std::optional<Tok>& prev_opt, const Tok& t) {
    auto gap = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_none(prev_opt)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        if (prism_rtl::is_some(prev_opt)) {
            auto&& p_ = prism_rtl::some_of(prev_opt);
            _v.set(is_layout(t.kind)
                ? Text::lit("\n")
                : (is_bracket(p_.kind) && is_bracket(t.kind)) && t.touches
                ? Text::lit("·")
                : Text::lit(" "));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return t.kind == TokKind(TokKind::KEof{})
        ? std::tuple{acc, std::optional(t)}
        : std::tuple{prism_rtl::cat(acc, gap, token_text(t.kind)), std::optional(t)};
}


/// IsBracket: fn TokKind -> Bool
bool is_bracket(const TokKind& tok_kind0) {
    if (prism_rtl::is<TokKind::KOpen>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KClose>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// RenderInner: fn [Tok] -> Text
Text render_inner(const Array<Tok>& tokens) {
    return join(split(trim_end(trim_newlines(render_tokens(tokens))), Text::lit("\n")), Text::lit(" "));
}


/// TrimNewlines: fn Text -> Text
Text trim_newlines(const Text& t) {
    return trim_trailing(t, Text::lit("\n \t"));
}


/// TokenText: fn TokKind -> Text
Text token_text(const TokKind& tok_kind0) {
    if (prism_rtl::is<TokKind::KName>(tok_kind0)) {
        auto&& n = prism_rtl::as<TokKind::KName>(tok_kind0).a0;
        return prism_rtl::cat(n.sigils, join(n->path_, Text::lit(".")));
    }
    if (prism_rtl::is<TokKind::KFamily>(tok_kind0)) {
        auto&& p_ = prism_rtl::as<TokKind::KFamily>(tok_kind0).a0;
        return prism_rtl::cat(join(p_, Text::lit(".")), ".*");
    }
    if (prism_rtl::is<TokKind::KTrait>(tok_kind0)) {
        auto&& p_ = prism_rtl::as<TokKind::KTrait>(tok_kind0).a0;
        return prism_rtl::cat("^", join(p_, Text::lit(".")));
    }
    if (prism_rtl::is<TokKind::KKw>(tok_kind0)) {
        auto&& w = prism_rtl::as<TokKind::KKw>(tok_kind0).a0;
        auto&& s = prism_rtl::as<TokKind::KKw>(tok_kind0).a1;
        return prism_rtl::cat(s, w);
    }
    if (prism_rtl::is<TokKind::KFree>(tok_kind0)) {
        auto&& s = prism_rtl::as<TokKind::KFree>(tok_kind0).a0;
        return prism_rtl::cat("free", s);
    }
    if (prism_rtl::is<TokKind::KLensDot>(tok_kind0)) {
        return Text::lit("&.");
    }
    if (prism_rtl::is<TokKind::KInt>(tok_kind0)) {
        auto&& s = prism_rtl::as<TokKind::KInt>(tok_kind0).a0;
        auto&& t = prism_rtl::as<TokKind::KInt>(tok_kind0).a1;
        return prism_rtl::cat(s, t);
    }
    if (prism_rtl::is<TokKind::KFloat>(tok_kind0)) {
        auto&& s = prism_rtl::as<TokKind::KFloat>(tok_kind0).a0;
        auto&& t = prism_rtl::as<TokKind::KFloat>(tok_kind0).a1;
        return prism_rtl::cat(s, t);
    }
    if (prism_rtl::is<TokKind::KDuration>(tok_kind0)) {
        auto&& s = prism_rtl::as<TokKind::KDuration>(tok_kind0).a0;
        auto&& t = prism_rtl::as<TokKind::KDuration>(tok_kind0).a1;
        auto&& u = prism_rtl::as<TokKind::KDuration>(tok_kind0).a2;
        return prism_rtl::cat(s, t, u);
    }
    if (prism_rtl::is<TokKind::KChar>(tok_kind0)) {
        auto&& s = prism_rtl::as<TokKind::KChar>(tok_kind0).a0;
        auto&& c = prism_rtl::as<TokKind::KChar>(tok_kind0).a1;
        return prism_rtl::cat(s, debug_char(c));
    }
    if (prism_rtl::is<TokKind::KText>(tok_kind0)) {
        auto&& s = prism_rtl::as<TokKind::KText>(tok_kind0).a0;
        auto&& segs = prism_rtl::as<TokKind::KText>(tok_kind0).a1;
        return prism_rtl::cat(s, "TEXT(", concat(each(segs, seg_text)), ")");
    }
    if (prism_rtl::is<TokKind::KTemplate>(tok_kind0)) {
        auto&& t = prism_rtl::as<TokKind::KTemplate>(tok_kind0).a0;
        return prism_rtl::cat("TEMPLATE<", t.lang, ">(", concat(each(t.parts, part_text)), ")");
    }
    if (prism_rtl::is<TokKind::KOp>(tok_kind0) && prism_rtl::as<TokKind::KOp>(tok_kind0).a1) {
        auto&& op = prism_rtl::as<TokKind::KOp>(tok_kind0).a0;
        return prism_rtl::cat(op, "pre");
    }
    if (prism_rtl::is<TokKind::KOp>(tok_kind0) && !prism_rtl::as<TokKind::KOp>(tok_kind0).a1) {
        auto&& op = prism_rtl::as<TokKind::KOp>(tok_kind0).a0;
        return op;
    }
    if (prism_rtl::is<TokKind::KSuffixed>(tok_kind0)) {
        auto&& op = prism_rtl::as<TokKind::KSuffixed>(tok_kind0).a0;
        auto&& ty = prism_rtl::as<TokKind::KSuffixed>(tok_kind0).a1;
        return prism_rtl::cat(op, join(ty, Text::lit(".")));
    }
    if (prism_rtl::is<TokKind::KDot>(tok_kind0) && prism_rtl::as<TokKind::KDot>(tok_kind0).a0) {
        return Text::lit(".pre");
    }
    if (prism_rtl::is<TokKind::KDot>(tok_kind0) && !prism_rtl::as<TokKind::KDot>(tok_kind0).a0) {
        return Text::lit(".");
    }
    if (prism_rtl::is<TokKind::KDotDot>(tok_kind0)) {
        return Text::lit("..");
    }
    if (prism_rtl::is<TokKind::KComma>(tok_kind0)) {
        return Text::lit(",");
    }
    if (prism_rtl::is<TokKind::KColon>(tok_kind0)) {
        return Text::lit(":");
    }
    if (prism_rtl::is<TokKind::KSemi>(tok_kind0)) {
        return Text::lit(";");
    }
    if (prism_rtl::is<TokKind::KBackslash>(tok_kind0)) {
        return Text::lit("\\");
    }
    if (prism_rtl::is<TokKind::KLambdaBar>(tok_kind0)) {
        return Text::lit("|");
    }
    if (prism_rtl::is<TokKind::KBar>(tok_kind0)) {
        return Text::lit("|");
    }
    if (prism_rtl::is<TokKind::KLtLt>(tok_kind0)) {
        return Text::lit("<<");
    }
    if (prism_rtl::is<TokKind::KGtGt>(tok_kind0)) {
        return Text::lit(">>");
    }
    if (prism_rtl::is<TokKind::KOpen>(tok_kind0)) {
        auto&& k = prism_rtl::as<TokKind::KOpen>(tok_kind0).a0;
        return k;
    }
    if (prism_rtl::is<TokKind::KClose>(tok_kind0)) {
        auto&& k = prism_rtl::as<TokKind::KClose>(tok_kind0).a0;
        return close_char(k);
    }
    if (prism_rtl::is<TokKind::KAbsent>(tok_kind0)) {
        return Text::lit("absent");
    }
    if (prism_rtl::is<TokKind::KNonEmpty>(tok_kind0)) {
        return Text::lit("nonempty");
    }
    if (prism_rtl::is<TokKind::KPath>(tok_kind0)) {
        auto&& segs = prism_rtl::as<TokKind::KPath>(tok_kind0).a0;
        return prism_rtl::cat("PATH(", join(each(segs, path_seg_text), Text::lit("/")), ")");
    }
    if (prism_rtl::is<TokKind::KLayOpen>(tok_kind0)) {
        return Text::lit("open");
    }
    if (prism_rtl::is<TokKind::KLaySep>(tok_kind0)) {
        return Text::lit("sep");
    }
    if (prism_rtl::is<TokKind::KLayClose>(tok_kind0)) {
        return Text::lit("close");
    }
    if (prism_rtl::is<TokKind::KEof>(tok_kind0)) {
        return Text::lit("eof");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SegText: fn TextSegTok -> Text
Text seg_text(const TextSegTok& text_seg_tok0) {
    if (prism_rtl::is<TextSegTok::TsPlain>(text_seg_tok0)) {
        auto&& p_ = prism_rtl::as<TextSegTok::TsPlain>(text_seg_tok0).a0;
        return escape_braces(escape_debug(p_, true, true));
    }
    if (prism_rtl::is<TextSegTok::TsPlaceholder>(text_seg_tok0)) {
        auto&& toks = prism_rtl::as<TextSegTok::TsPlaceholder>(text_seg_tok0).a0;
        return prism_rtl::cat("{", render_inner(toks), "}");
    }
    prism_rtl::unreachable("no arm matched");
}


/// EscapeBraces: fn Text -> Text
Text escape_braces(const Text& t) {
    return map_chars(t, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return once_job([=]() {
            return ({
                auto c = p0;
                (c == Text::lit("{")) || (c == Text::lit("}"))
                ? prism_rtl::finished(prism_rtl::cat("\\", c))
                : prism_rtl::finished(c);
            });
        });
    })));
}


/// PathSegText: fn PathSegTok -> Text
Text path_seg_text(const PathSegTok& path_seg_tok0) {
    if (prism_rtl::is<PathSegTok::PstNum>(path_seg_tok0)) {
        auto&& n = prism_rtl::as<PathSegTok::PstNum>(path_seg_tok0).a0;
        return prism_rtl::cat(n);
    }
    if (prism_rtl::is<PathSegTok::PstGen>(path_seg_tok0)) {
        auto&& n = prism_rtl::as<PathSegTok::PstGen>(path_seg_tok0).a0;
        return prism_rtl::cat("#", n);
    }
    if (prism_rtl::is<PathSegTok::PstKey>(path_seg_tok0)) {
        auto&& toks = prism_rtl::as<PathSegTok::PstKey>(path_seg_tok0).a0;
        return prism_rtl::cat("[", render_inner(toks), "]");
    }
    prism_rtl::unreachable("no arm matched");
}


/// PartText: fn TPartTok -> Text
Text part_text(const TPartTok& tpart_tok0) {
    if (prism_rtl::is<TPartTok::TptText>(tpart_tok0)) {
        auto&& t = prism_rtl::as<TPartTok::TptText>(tpart_tok0).a0;
        return debug_text(t);
    }
    if (prism_rtl::is<TPartTok::TptPlaceholder>(tpart_tok0)) {
        auto&& toks = prism_rtl::as<TPartTok::TptPlaceholder>(tpart_tok0).a0;
        auto&& col_opt = prism_rtl::as<TPartTok::TptPlaceholder>(tpart_tok0).a1;
        return prism_rtl::cat("{{", render_inner(toks), "}}", col_text(col_opt));
    }
    if (prism_rtl::is<TPartTok::TptBlock>(tpart_tok0)) {
        auto&& toks = prism_rtl::as<TPartTok::TptBlock>(tpart_tok0).a0;
        return prism_rtl::cat("BLOCK{ ", render_inner(toks), " }");
    }
    if (prism_rtl::is<TPartTok::TptCall>(tpart_tok0)) {
        auto&& name = prism_rtl::as<TPartTok::TptCall>(tpart_tok0).a0;
        auto&& attrs = prism_rtl::as<TPartTok::TptCall>(tpart_tok0).a1;
        auto&& body_opt = prism_rtl::as<TPartTok::TptCall>(tpart_tok0).a2;
        return prism_rtl::cat("<", name.sigils, join(name->path_, Text::lit(".")), concat(each(attrs, attr_text)), call_body(name, body_opt));
    }
    prism_rtl::unreachable("no arm matched");
}


/// ColText: fn ?Nat -> Text
Text col_text(const std::optional<Nat>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& c = prism_rtl::some_of(opt0);
        return prism_rtl::cat("@col", c);
    }
    prism_rtl::unreachable("no arm matched");
}


/// AttrText: fn AttrTok -> Text
Text attr_text(const AttrTok& a) {
    return prism_rtl::cat(" ", a.name, "={", render_inner(a->tokens), "}");
}


/// CallBody: fn NameTok, ?[TPartTok] -> Text
Text call_body(const NameTok& name_tok0, const std::optional<Array<TPartTok>>& opt1) {
    auto&& _m = std::tuple{name_tok0, opt1};
    if (prism_rtl::is_none(std::get<1>(_m))) {
        return Text::lit("/>");
    }
    if (prism_rtl::is_some(std::get<1>(_m))) {
        auto&& name = std::get<0>(_m);
        auto&& parts = prism_rtl::some_of(std::get<1>(_m));
        return prism_rtl::cat(">", concat(each(parts, part_text)), "</", name.sigils, join(name->path_, Text::lit(".")), ">");
    }
    prism_rtl::unreachable("no arm matched");
}


/// DebugText: fn Text -> Text
Text debug_text(const Text& t) {
    return prism_rtl::cat("\"", escape_debug(t, false, true), "\"");
}


/// DebugChar: fn Text -> Text
Text debug_char(const Text& c) {
    return prism_rtl::cat("'", escape_debug(c, true, false), "'");
}


/// EscapeDebug: fn Text, Bool, Bool -> Text
Text escape_debug(const Text& t, const bool& single, const bool& double_) {
    return map_chars(t, ({
        auto single_1 = single;
        auto double__2 = double_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto single_1_3 = single_1;
            auto double__2_3 = double__2;
            once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::finished(escape_char(c, single_1_3, double__2_3)));
            });
        });
        });
    })));
    }));
}


/// EscapeChar: fn Text, Bool, Bool -> Text
Text escape_char(const Text& c, const bool& single, const bool& double_) {
    {
        auto&& m74488_0 = c;
        if (m74488_0 == Text::lit("\000"sv)) {
            return Text::lit("\\0");
        }
    }
    {
        auto&& m74488_1 = c;
        if (m74488_1 == Text::lit("\t")) {
            return Text::lit("\\t");
        }
    }
    {
        auto&& m74488_2 = c;
        if (m74488_2 == Text::lit("\r")) {
            return Text::lit("\\r");
        }
    }
    {
        auto&& m74488_3 = c;
        if (m74488_3 == Text::lit("\n")) {
            return Text::lit("\\n");
        }
    }
    {
        auto&& m74488_4 = c;
        if (m74488_4 == Text::lit("\\")) {
            return Text::lit("\\\\");
        }
    }
    {
        auto&& m74488_5 = c;
        if (m74488_5 == Text::lit("'")) {
            if (single) {
                return Text::lit("\\'");
            }
        }
    }
    {
        auto&& m74488_6 = c;
        if (m74488_6 == Text::lit("\"")) {
            if (double_) {
                return Text::lit("\\\"");
            }
        }
    }
    {
        if ((c < Text::lit(" ")) || (c == Text::lit(""))) {
            return prism_rtl::cat("\\u{", hex_of(code_of(c)), "}");
        }
    }
    {
        return c;
    }
}


/// CodeOf: fn Text -> Nat
Nat code_of(const Text& c) {
    return c == Text::lit("")
        ? Nat(128u)
        : len_text(or_(index(split(ascii_text(), c), Nat(0u)), ascii_text()));
}


/// HexOf: fn Nat -> Text
Text hex_of(const Nat& n) {
    return hex_digits(n, n);
}


/// HexDigits: fn Nat, Nat -> Text
Text hex_digits(const Nat& n, const Nat& fuel) {
    auto&& _m = fuel.checked_sub(Nat(1u));
    if (prism_rtl::is_some(_m)) {
        auto&& left = prism_rtl::some_of(_m);
        if (n >= Nat(16u)) {
            return prism_rtl::cat(hex_digits(or_(div(n, Nat(16u)), Nat(0u)), left), char_at_byte(hex_digits_value(), or_(mod_(n, Nat(16u)), Nat(0u))));
        }
    }
    {
        return n < Nat(16u) ? char_at_byte(hex_digits_value(), n) : Text::lit("0");
    }
}

}  // namespace crate::lexer
