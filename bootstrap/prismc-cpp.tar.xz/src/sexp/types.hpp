// The module `Sexp`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <sexp/decl.hpp>
#include "elem.decl.hpp"
#include <ast/decl.hpp>
#include <lexer/decl.hpp>

namespace crate {

using namespace prelude;



}  // namespace crate
