// The module `Sexp`, from `target/bootstrap/cpp-src/prismc/sexp.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include <sexp/module.hpp>
#include <ast/module.hpp>
#include <lexer/module.hpp>
#include <sexp/generic.hpp>
#include <lexer/generic.hpp>

namespace crate::sexp {

/// Nl: fn Nat -> Text
Text nl(const Nat& d) {
    return prism_rtl::cat("\n", indent(d));
}


/// Indent: fn Nat -> Text
Text indent(const Nat& d) {
    auto&& _m = d.checked_sub(Nat(1u));
    if (prism_rtl::is_some(_m)) {
        auto&& m = prism_rtl::some_of(_m);
        return prism_rtl::cat("  ", indent(m));
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Path: fn [Text] -> Text
Text path_(const Array<Text>& p_) {
    return crate::lexer::join(p_, Text::lit("."));
}


/// SNameText: fn SName -> Text
Text sname_text(const crate::ast::SName& n) {
    return prism_rtl::cat(n.sigils, sexp::path_(n->path_));
}


/// SexpModule: fn Module -> Text
Text sexp_module(const crate::ast::Module& m) {
    auto name_1 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.name;
        if (prism_rtl::is_some(_m)) {
            auto&& n = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(nl(Nat(1u)), "(name ", sexp::path_(n->path_), ")"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto emits = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.emit_row;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(nl(Nat(1u)), "(emit ", sexp_row(r), ")"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto mods = concat(each(m.mods, [&](const crate::ast::ModLine& l) { return prism_rtl::cat(nl(Nat(1u)), "(", l.is_test ? Text::lit("test-mod") : Text::lit("mod"), " ", l.name.name, ")"); }));
    auto uses = concat(each(m.uses, [&](const crate::ast::Use& u) { return prism_rtl::cat(nl(Nat(1u)), "(use ", sexp::path_(u->target->path_), u.star ? Text::lit(".*") : Text::lit(""), ")"); }));
    auto template_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.template_;
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(nl(Nat(1u)), sexp_template(t, Nat(1u))));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto decls = concat(each(m.decls, [&](const crate::ast::Decl& d) { return prism_rtl::cat(nl(Nat(1u)), sexp_decl(d, Nat(1u))); }));
    return prism_rtl::cat("(module", name_1, emits, mods, uses, template_, decls, ")\n");
}


/// SexpRow: fn Row -> Text
Text sexp_row(const crate::ast::Row_& r) {
    return prism_rtl::cat("(row", spaced(r.terms, ({
        auto f = prism_rtl::rc(sexp_row_term);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::ast::RowTerm)>>(prism_rtl::rc([=](crate::ast::RowTerm a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    })), ")");
}


/// SexpRowTerm: fn RowTerm -> Text
Text sexp_row_term(const crate::ast::RowTerm& row_term0) {
    if (prism_rtl::is<crate::ast::RowTerm::RFamily>(row_term0)) {
        auto&& q = prism_rtl::as<crate::ast::RowTerm::RFamily>(row_term0).a0;
        return prism_rtl::cat(sexp::path_(q->path_), ".*");
    }
    if (prism_rtl::is<crate::ast::RowTerm::RVar>(row_term0)) {
        auto&& v_ = prism_rtl::as<crate::ast::RowTerm::RVar>(row_term0).a0;
        return prism_rtl::cat("(var ", v_.name, ")");
    }
    if (prism_rtl::is<crate::ast::RowTerm::RType>(row_term0)) {
        auto&& t = prism_rtl::as<crate::ast::RowTerm::RType>(row_term0).a0;
        return sexp_type(t);
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpDecl: fn Decl, Nat -> Text
Text sexp_decl(const crate::ast::Decl& d, const Nat& depth) {
    auto&& _m = d.kind;
    if (prism_rtl::is<crate::ast::DeclKind::DSignature>(_m)) {
        auto&& s = prism_rtl::as<crate::ast::DeclKind::DSignature>(_m).a0;
        return sexp_signature(s);
    }
    if (prism_rtl::is<crate::ast::DeclKind::DFn>(_m)) {
        auto&& f = prism_rtl::as<crate::ast::DeclKind::DFn>(_m).a0;
        return sexp_fn(f, depth);
    }
    if (prism_rtl::is<crate::ast::DeclKind::DLet>(_m)) {
        auto&& l = prism_rtl::as<crate::ast::DeclKind::DLet>(_m).a0;
        return prism_rtl::cat("(let ", sexp_pattern(l.pattern, depth), opt_type(l.ty), " ", sexp_expr(l->value, depth), ")");
    }
    if (prism_rtl::is<crate::ast::DeclKind::DWidget>(_m)) {
        auto&& w = prism_rtl::as<crate::ast::DeclKind::DWidget>(_m).a0;
        return prism_rtl::cat("(widget ", sname_text(w.name), sexp_block(w.body, depth), ")");
    }
    if (prism_rtl::is<crate::ast::DeclKind::DType>(_m)) {
        auto&& t = prism_rtl::as<crate::ast::DeclKind::DType>(_m).a0;
        return prism_rtl::cat("(type ", sexp::path_(t.name->path_), concat(each(t.params, [&](const crate::ast::Ident& p_) { return prism_rtl::cat(" ", p_.name); })), sexp_type_body(t.body, depth), ")");
    }
    if (prism_rtl::is<crate::ast::DeclKind::DTag>(_m)) {
        auto&& t = prism_rtl::as<crate::ast::DeclKind::DTag>(_m).a0;
        return prism_rtl::cat("(tag ", sexp::path_(t.name->path_), " ", sexp_type(t.of_type), sexp_bounds(t.bounds), sexp_fields(t.fields, depth), ")");
    }
    if (prism_rtl::is<crate::ast::DeclKind::DDerive>(_m)) {
        auto&& ts = prism_rtl::as<crate::ast::DeclKind::DDerive>(_m).a0;
        return prism_rtl::cat("(derive", concat(each(ts, [&](const crate::ast::TraitRef& t) { return prism_rtl::cat(" ^", sexp::path_(t->path_)); })), ")");
    }
    if (prism_rtl::is<crate::ast::DeclKind::DTrait>(_m)) {
        auto&& t = prism_rtl::as<crate::ast::DeclKind::DTrait>(_m).a0;
        return prism_rtl::cat("(trait ^", sexp::path_(t.name->path_), concat(each(t.params, [&](const crate::ast::Ident& p_) { return prism_rtl::cat(" ", p_.name); })), sexp_bounds(t.bounds), sexp_items(t.items, depth), ")");
    }
    if (prism_rtl::is<crate::ast::DeclKind::DImpl>(_m)) {
        auto&& i = prism_rtl::as<crate::ast::DeclKind::DImpl>(_m).a0;
        return prism_rtl::cat("(impl ^", sexp::path_(i.trait_ref->path_), " ", sexp_type(i.ty), sexp_bounds(i.bounds), sexp_items(i.items, depth), ")");
    }
    if (prism_rtl::is<crate::ast::DeclKind::DCheck>(_m)) {
        auto&& c = prism_rtl::as<crate::ast::DeclKind::DCheck>(_m).a0;
        return prism_rtl::cat("(check ", c.name.name, concat(each(c.lines, [&](const crate::ast::CheckLine& l) { return prism_rtl::cat(nl(depth + Nat(1u)), "(line ", sexp_expr(l.expr, depth + Nat(1u)), check_pattern(l.pattern, depth + Nat(1u)), ")"); })), ")");
    }
    if (prism_rtl::is<crate::ast::DeclKind::DTest>(_m)) {
        auto&& t = prism_rtl::as<crate::ast::DeclKind::DTest>(_m).a0;
        return sexp_test(t, depth);
    }
    if (prism_rtl::is<crate::ast::DeclKind::DStmt>(_m)) {
        auto&& s = prism_rtl::as<crate::ast::DeclKind::DStmt>(_m).a0;
        return sexp_stmt(s, depth);
    }
    prism_rtl::unreachable("no arm matched");
}


/// OptType: fn ?Type -> Text
Text opt_type(const std::optional<crate::ast::Type>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& t = prism_rtl::some_of(opt0);
        return prism_rtl::cat(" ", sexp_type(t));
    }
    prism_rtl::unreachable("no arm matched");
}


/// CheckPattern: fn ?Pattern, Nat -> Text
Text check_pattern(const std::optional<crate::ast::Pattern_>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& p_ = prism_rtl::some_of(std::get<0>(_m));
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat(" => ", sexp_pattern(p_, d));
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpTypeBody: fn ?TypeBody, Nat -> Text
Text sexp_type_body(const std::optional<crate::ast::TypeBody>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit(" opaque");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& b = prism_rtl::some_of(std::get<0>(_m));
        auto&& depth = std::get<1>(_m);
        if (prism_rtl::is<crate::ast::TypeBody::TbRecord>(b)) {
            auto&& fs = prism_rtl::as<crate::ast::TypeBody::TbRecord>(b).a0;
            return prism_rtl::cat(" record", sexp_fields(fs, depth));
        }
        if (prism_rtl::is<crate::ast::TypeBody::TbChoice>(b)) {
            auto&& cs = prism_rtl::as<crate::ast::TypeBody::TbChoice>(b).a0;
            return prism_rtl::cat(" choice", concat(each(cs, [&](const crate::ast::Case_& c) { return prism_rtl::cat(nl(depth + Nat(1u)), sexp_case(c)); })));
        }
        if (prism_rtl::is<crate::ast::TypeBody::TbRow>(b)) {
            return Text::lit(" row");
        }
        if (prism_rtl::is<crate::ast::TypeBody::TbNewtype>(b)) {
            auto&& c = prism_rtl::as<crate::ast::TypeBody::TbNewtype>(b).a0;
            return prism_rtl::cat(" newtype ", sexp_case(c));
        }
        if (prism_rtl::is<crate::ast::TypeBody::TbUnit>(b)) {
            auto&& i = prism_rtl::as<crate::ast::TypeBody::TbUnit>(b).a0;
            return prism_rtl::cat(" unit ", i.name);
        }
        if (prism_rtl::is<crate::ast::TypeBody::TbAlias>(b)) {
            auto&& t = prism_rtl::as<crate::ast::TypeBody::TbAlias>(b).a0;
            return prism_rtl::cat(" alias ", sexp_type(t));
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpSignature: fn Signature -> Text
Text sexp_signature(const crate::ast::Signature& s) {
    return prism_rtl::cat("(sig ", sexp_def_name(s.name), " ", sexp_type(s.ty), sexp_bounds(s.bounds), ")");
}


/// SexpDefName: fn DefName -> Text
Text sexp_def_name(const crate::ast::DefName& def_name0) {
    if (prism_rtl::is<crate::ast::DefName::DefSName>(def_name0)) {
        auto&& n = prism_rtl::as<crate::ast::DefName::DefSName>(def_name0).a0;
        return sname_text(n);
    }
    if (prism_rtl::is<crate::ast::DefName::DefOp>(def_name0)) {
        auto&& o = prism_rtl::as<crate::ast::DefName::DefOp>(def_name0).a0;
        return prism_rtl::cat("(op ", o, ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpBounds: fn [Bound] -> Text
Text sexp_bounds(const Array<crate::ast::Bound>& bs) {
    return concat(each(bs, [&](const crate::ast::Bound& b) { return prism_rtl::cat(" (where ", b.var.name, concat(each(b.traits, [&](const crate::ast::TraitRef& t) { return prism_rtl::cat(" ^", sexp::path_(t->path_)); })), ")"); }));
}


/// SexpFn: fn FnClause, Nat -> Text
Text sexp_fn(const crate::ast::FnClause& f, const Nat& depth) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = f.body;
        if (prism_rtl::is<crate::ast::FnBody::BodyExpr>(_m)) {
            auto&& e = prism_rtl::as<crate::ast::FnBody::BodyExpr>(_m).a0;
            _v.set(prism_rtl::cat(nl(depth + Nat(1u)), sexp_expr(e, depth + Nat(1u))));
            goto _done;
        }
        if (prism_rtl::is<crate::ast::FnBody::BodyBlock>(_m)) {
            auto&& b = prism_rtl::as<crate::ast::FnBody::BodyBlock>(_m).a0;
            _v.set(sexp_block(b, depth));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::cat("(fn ", sexp_def_name(f.name), " (params", concat(each(f.params, [&](const crate::ast::Pattern_& p_) { return prism_rtl::cat(" ", sexp_pattern(p_, depth)); })), ")", body, ")");
}


/// SexpFields: fn [Field], Nat -> Text
Text sexp_fields(const Array<crate::ast::Field>& fs, const Nat& depth) {
    return concat(each(fs, [&](const crate::ast::Field& f) { return prism_rtl::cat(nl(depth + Nat(1u)), "(field ", f.name.name, " ", sexp_type(f.ty), ")"); }));
}


/// SexpCase: fn Case -> Text
Text sexp_case(const crate::ast::Case_& c) {
    auto indexed = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = c.indexed;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(" -> ", sexp_type(r)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::cat("(case ", sname_text(c.name), spaced(c->args, ({
        auto f = prism_rtl::rc(sexp_type);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::ast::Type)>>(prism_rtl::rc([=](crate::ast::Type a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    })), indexed, ")");
}


/// SexpItems: fn [TraitItem], Nat -> Text
Text sexp_items(const Array<crate::ast::TraitItem>& items, const Nat& depth) {
    return concat(each(items, [&](const crate::ast::TraitItem& it) { return prism_rtl::cat(nl(depth + Nat(1u)), sexp_item(it, depth + Nat(1u))); }));
}


/// SexpItem: fn TraitItem, Nat -> Text
Text sexp_item(const crate::ast::TraitItem& trait_item0, const Nat& n1) {
    auto&& _m = std::tuple{trait_item0, n1};
    if (prism_rtl::is<crate::ast::TraitItem::TiSignature>(std::get<0>(_m))) {
        auto&& s = prism_rtl::as<crate::ast::TraitItem::TiSignature>(std::get<0>(_m)).a0;
        return sexp_signature(s);
    }
    if (prism_rtl::is<crate::ast::TraitItem::TiFn>(std::get<0>(_m))) {
        auto&& f = prism_rtl::as<crate::ast::TraitItem::TiFn>(std::get<0>(_m)).a0;
        auto&& d = std::get<1>(_m);
        return sexp_fn(f, d);
    }
    if (prism_rtl::is<crate::ast::TraitItem::TiAssocType>(std::get<0>(_m))) {
        auto&& name = prism_rtl::as<crate::ast::TraitItem::TiAssocType>(std::get<0>(_m)).a0;
        auto&& params = prism_rtl::as<crate::ast::TraitItem::TiAssocType>(std::get<0>(_m)).a1;
        auto&& value_opt = prism_rtl::as<crate::ast::TraitItem::TiAssocType>(std::get<0>(_m)).a2;
        return prism_rtl::cat("(assoc-type ", name.name, concat(each(params, [&](const crate::ast::Ident& p_) { return prism_rtl::cat(" ", p_.name); })), opt_type(value_opt), ")");
    }
    if (prism_rtl::is<crate::ast::TraitItem::TiAssocRow>(std::get<0>(_m))) {
        auto&& name = prism_rtl::as<crate::ast::TraitItem::TiAssocRow>(std::get<0>(_m)).a0;
        return prism_rtl::cat("(assoc-row ", sname_text(name), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpTest: fn TestDecl, Nat -> Text
Text sexp_test(const crate::ast::TestDecl& t, const Nat& depth) {
    auto seed_1 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.seed;
        if (prism_rtl::is_some(_m)) {
            auto&& s = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(" (seed ", s, ")"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::cat("(test ", t.name.name, " ", sexp_expr(t.blueprint, depth), seed_1, concat(each(t.steps, [&](const crate::ast::TestStep& s) { return prism_rtl::cat(nl(depth + Nat(1u)), sexp_step(s, depth + Nat(1u))); })), ")");
}


/// SexpStep: fn TestStep, Nat -> Text
Text sexp_step(const crate::ast::TestStep& s, const Nat& d) {
    auto withs = concat(each(s.withs, [&](const crate::ast::Entry& w) { return prism_rtl::cat(" (with ", sexp_expr(w.element, d), " ", sexp_expr(w->value, d), ")"); }));
    auto checks = concat(each(s.checks, [&](const crate::ast::TestCheck& c) { return prism_rtl::cat(nl(d + Nat(1u)), sexp_check(c, d + Nat(1u))); }));
    return prism_rtl::cat("(step", withs, " ", sexp_action(s.action, d), checks, ")");
}


/// SexpAction: fn StepAction, Nat -> Text
Text sexp_action(const crate::ast::StepAction& step_action0, const Nat& n1) {
    auto&& _m = std::tuple{step_action0, n1};
    if (prism_rtl::is<crate::ast::StepAction::SaBuild>(std::get<0>(_m))) {
        return Text::lit("build");
    }
    if (prism_rtl::is<crate::ast::StepAction::SaTick>(std::get<0>(_m))) {
        return Text::lit("tick");
    }
    if (prism_rtl::is<crate::ast::StepAction::SaCompute>(std::get<0>(_m)) && prism_rtl::as<crate::ast::StepAction::SaCompute>(std::get<0>(_m)).a0) {
        return Text::lit("compute-until-idle");
    }
    if (prism_rtl::is<crate::ast::StepAction::SaCompute>(std::get<0>(_m)) && !prism_rtl::as<crate::ast::StepAction::SaCompute>(std::get<0>(_m)).a0) {
        return Text::lit("compute");
    }
    if (prism_rtl::is<crate::ast::StepAction::SaWithOnly>(std::get<0>(_m))) {
        return Text::lit("with-only");
    }
    if (prism_rtl::is<crate::ast::StepAction::SaPush>(std::get<0>(_m))) {
        auto&& e = prism_rtl::as<crate::ast::StepAction::SaPush>(std::get<0>(_m)).a0;
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat("(push ", sexp_expr(e.element, d), " ", sexp_expr(e->value, d), ")");
    }
    if (prism_rtl::is<crate::ast::StepAction::SaDeliver>(std::get<0>(_m))) {
        auto&& ds = prism_rtl::as<crate::ast::StepAction::SaDeliver>(std::get<0>(_m)).a0;
        auto&& d = std::get<1>(_m);
        return crate::lexer::join(each(ds, [&](const crate::ast::Delivery& x) { return sexp_delivery(x, d); }), Text::lit(" "));
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpDelivery: fn Delivery, Nat -> Text
Text sexp_delivery(const crate::ast::Delivery& x, const Nat& d) {
    auto word = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = x.kind;
        if (prism_rtl::is<crate::ast::DeliveryKind::DkSend>(_m)) {
            _v.set(Text::lit("send"));
            goto _done;
        }
        if (prism_rtl::is<crate::ast::DeliveryKind::DkClick>(_m)) {
            _v.set(Text::lit("click"));
            goto _done;
        }
        if (prism_rtl::is<crate::ast::DeliveryKind::DkAnswer>(_m)) {
            _v.set(Text::lit("answer"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto value = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = x.kind;
        if (prism_rtl::is<crate::ast::DeliveryKind::DkSend>(_m)) {
            auto&& v_ = prism_rtl::as<crate::ast::DeliveryKind::DkSend>(_m).a0;
            _v.set(prism_rtl::cat(" ", sexp_expr(v_, d)));
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::cat("(", word, " ", sexp_target(x->target, d), value, ")");
}


/// SexpTarget: fn Target, Nat -> Text
Text sexp_target(const crate::ast::Target& target0, const Nat& d) {
    if (prism_rtl::is<crate::ast::Target::TgPattern>(target0)) {
        auto&& p_ = prism_rtl::as<crate::ast::Target::TgPattern>(target0).a0;
        return sexp_pattern(p_, d);
    }
    if (prism_rtl::is<crate::ast::Target::TgPath>(target0)) {
        auto&& p_ = prism_rtl::as<crate::ast::Target::TgPath>(target0).a0;
        return sexp_path(Text::lit("at"), p_, d);
    }
    if (prism_rtl::is<crate::ast::Target::TgElement>(target0)) {
        auto&& p_ = prism_rtl::as<crate::ast::Target::TgElement>(target0).a0;
        return sexp_path(Text::lit("element"), p_, d);
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpPath: fn Text, TestPath, Nat -> Text
Text sexp_path(const Text& word, const crate::ast::TestPath& p_, const Nat& d) {
    return prism_rtl::cat("(", word, concat(each(p_.segments, [&](const crate::ast::PathSeg& s) { return sexp_path_seg(s, d); })), ")");
}


/// SexpPathSeg: fn PathSeg, Nat -> Text
Text sexp_path_seg(const crate::ast::PathSeg& path_seg0, const Nat& n1) {
    auto&& _m = std::tuple{path_seg0, n1};
    if (prism_rtl::is<crate::ast::PathSeg::PsNum>(std::get<0>(_m))) {
        auto&& n = prism_rtl::as<crate::ast::PathSeg::PsNum>(std::get<0>(_m)).a0;
        return prism_rtl::cat(" ", n);
    }
    if (prism_rtl::is<crate::ast::PathSeg::PsGen>(std::get<0>(_m))) {
        auto&& n = prism_rtl::as<crate::ast::PathSeg::PsGen>(std::get<0>(_m)).a0;
        return prism_rtl::cat(" #", n);
    }
    if (prism_rtl::is<crate::ast::PathSeg::PsKey>(std::get<0>(_m))) {
        auto&& e = prism_rtl::as<crate::ast::PathSeg::PsKey>(std::get<0>(_m)).a0;
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat(" [", sexp_expr(e, d), "]");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpCheck: fn TestCheck, Nat -> Text
Text sexp_check(const crate::ast::TestCheck& c, const Nat& d) {
    auto&& _m = c.kind;
    if (prism_rtl::is<crate::ast::TestCheckKind::CkExpect>(_m)) {
        auto&& p_ = prism_rtl::as<crate::ast::TestCheckKind::CkExpect>(_m).a0;
        return prism_rtl::cat("(=> expect ", sexp_pattern(p_, d), ")");
    }
    if (prism_rtl::is<crate::ast::TestCheckKind::CkExpectNone>(_m)) {
        auto&& p_ = prism_rtl::as<crate::ast::TestCheckKind::CkExpectNone>(_m).a0;
        return prism_rtl::cat("(=> expect_none ", sexp_pattern(p_, d), ")");
    }
    if (prism_rtl::is<crate::ast::TestCheckKind::CkExpectCount>(_m)) {
        auto&& p_ = prism_rtl::as<crate::ast::TestCheckKind::CkExpectCount>(_m).a0;
        auto&& n = prism_rtl::as<crate::ast::TestCheckKind::CkExpectCount>(_m).a1;
        return prism_rtl::cat("(=> expect_count ", sexp_pattern(p_, d), " ", n, ")");
    }
    if (prism_rtl::is<crate::ast::TestCheckKind::CkExpectTop>(_m)) {
        auto&& p_ = prism_rtl::as<crate::ast::TestCheckKind::CkExpectTop>(_m).a0;
        return prism_rtl::cat("(=> expect_top ", sexp_pattern(p_, d), ")");
    }
    if (prism_rtl::is<crate::ast::TestCheckKind::CkExpectTopNone>(_m)) {
        auto&& p_ = prism_rtl::as<crate::ast::TestCheckKind::CkExpectTopNone>(_m).a0;
        return prism_rtl::cat("(=> expect_top_none ", sexp_pattern(p_, d), ")");
    }
    if (prism_rtl::is<crate::ast::TestCheckKind::CkRequested>(_m)) {
        auto&& p_ = prism_rtl::as<crate::ast::TestCheckKind::CkRequested>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::ast::TestCheckKind::CkRequested>(_m).a1;
        return prism_rtl::cat("(=> requested ", sexp_pattern(p_, d), " ", sexp_pattern(v_, d), ")");
    }
    if (prism_rtl::is<crate::ast::TestCheckKind::CkUnrequested>(_m)) {
        auto&& p_ = prism_rtl::as<crate::ast::TestCheckKind::CkUnrequested>(_m).a0;
        return prism_rtl::cat("(=> unrequested ", sexp_pattern(p_, d), ")");
    }
    if (prism_rtl::is<crate::ast::TestCheckKind::CkReturns>(_m)) {
        auto&& p_ = prism_rtl::as<crate::ast::TestCheckKind::CkReturns>(_m).a0;
        return prism_rtl::cat("(=> returns ", sexp_pattern(p_, d), ")");
    }
    if (prism_rtl::is<crate::ast::TestCheckKind::CkFired>(_m)) {
        auto&& p_ = prism_rtl::as<crate::ast::TestCheckKind::CkFired>(_m).a0;
        return prism_rtl::cat("(=> fired ", sexp_pattern(p_, d), ")");
    }
    if (prism_rtl::is<crate::ast::TestCheckKind::CkQuiet>(_m)) {
        return Text::lit("(=> quiet)");
    }
    if (prism_rtl::is<crate::ast::TestCheckKind::CkSettles>(_m)) {
        return Text::lit("(=> settles)");
    }
    if (prism_rtl::is<crate::ast::TestCheckKind::CkAborted>(_m)) {
        return Text::lit("(=> aborted)");
    }
    if (prism_rtl::is<crate::ast::TestCheckKind::CkSnapshot>(_m)) {
        auto&& s = prism_rtl::as<crate::ast::TestCheckKind::CkSnapshot>(_m).a0;
        return prism_rtl::cat("(=> snapshot ", crate::lexer::debug_text(s), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpBlock: fn Block, Nat -> Text
Text sexp_block(const crate::ast::Block& b, const Nat& d) {
    return b.inline_
        ? prism_rtl::cat(" (inline", concat(each(b.stmts, [&](const crate::ast::Stmt& s) { return prism_rtl::cat(" ", sexp_stmt(s, d)); })), ")")
        : concat(each(b.stmts, [&](const crate::ast::Stmt& s) { return prism_rtl::cat(nl(d + Nat(1u)), sexp_stmt(s, d + Nat(1u))); }));
}


/// SexpStmt: fn Stmt, Nat -> Text
Text sexp_stmt(const crate::ast::Stmt& s, const Nat& d) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::ast::StmtKind::SEmit>(_m)) {
        auto&& r = prism_rtl::as<crate::ast::StmtKind::SEmit>(_m).a0;
        return prism_rtl::cat("(emit ", sexp_row(r), ")");
    }
    if (prism_rtl::is<crate::ast::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::ast::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<crate::ast::StmtKind::SBind>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::ast::StmtKind::SBind>(_m).a1;
        return prism_rtl::cat("(bind ", sexp_pattern(p_, d), " ", sexp_expr(v_, d), ")");
    }
    if (prism_rtl::is<crate::ast::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::ast::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<crate::ast::StmtKind::SBind>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::ast::StmtKind::SBind>(_m).a1;
        auto&& t = prism_rtl::some_of(prism_rtl::as<crate::ast::StmtKind::SBind>(_m).a2);
        return prism_rtl::cat("(hold ", sexp_pattern(p_, d), " ", sexp_expr(v_, d), " then ", sexp_expr(t, d), ")");
    }
    if (prism_rtl::is<crate::ast::StmtKind::SIgnore>(_m)) {
        auto&& e = prism_rtl::as<crate::ast::StmtKind::SIgnore>(_m).a0;
        return prism_rtl::cat("(ignore ", sexp_expr(e, d), ")");
    }
    if (prism_rtl::is<crate::ast::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::ast::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<crate::ast::StmtKind::SLet>(_m).a1;
        auto&& v_ = prism_rtl::as<crate::ast::StmtKind::SLet>(_m).a2;
        return prism_rtl::cat("(let ", sexp_pattern(p_, d), opt_type(ty_opt), " ", sexp_expr(v_, d), ")");
    }
    if (prism_rtl::is<crate::ast::StmtKind::SSignature>(_m)) {
        auto&& sg = prism_rtl::as<crate::ast::StmtKind::SSignature>(_m).a0;
        return sexp_signature(sg);
    }
    if (prism_rtl::is<crate::ast::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<crate::ast::StmtKind::SFn>(_m).a0;
        return sexp_fn(f, d);
    }
    if (prism_rtl::is<crate::ast::StmtKind::SWidget>(_m)) {
        auto&& w = prism_rtl::as<crate::ast::StmtKind::SWidget>(_m).a0;
        return prism_rtl::cat("(widget ", sname_text(w.name), sexp_block(w.body, d), ")");
    }
    if (prism_rtl::is<crate::ast::StmtKind::SSet>(_m)) {
        auto&& t = prism_rtl::as<crate::ast::StmtKind::SSet>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::ast::StmtKind::SSet>(_m).a1;
        return prism_rtl::cat("(set ", sexp_expr(t, d), " ", sexp_expr(v_, d), ")");
    }
    if (prism_rtl::is<crate::ast::StmtKind::SAccum>(_m)) {
        auto&& t = prism_rtl::as<crate::ast::StmtKind::SAccum>(_m).a0;
        auto&& op = prism_rtl::as<crate::ast::StmtKind::SAccum>(_m).a1;
        auto&& v_ = prism_rtl::as<crate::ast::StmtKind::SAccum>(_m).a2;
        return prism_rtl::cat("(", op, " ", sexp_expr(t, d), " ", sexp_expr(v_, d), ")");
    }
    if (prism_rtl::is<crate::ast::StmtKind::SRequire>(_m)) {
        auto&& c = prism_rtl::as<crate::ast::StmtKind::SRequire>(_m).a0;
        return prism_rtl::cat("(require ", sexp_expr(c, d), ")");
    }
    if (prism_rtl::is<crate::ast::StmtKind::SForbid>(_m)) {
        auto&& c = prism_rtl::as<crate::ast::StmtKind::SForbid>(_m).a0;
        return prism_rtl::cat("(forbid ", sexp_expr(c, d), ")");
    }
    if (prism_rtl::is<crate::ast::StmtKind::SWhile>(_m)) {
        auto&& c = prism_rtl::as<crate::ast::StmtKind::SWhile>(_m).a0;
        auto&& body = prism_rtl::as<crate::ast::StmtKind::SWhile>(_m).a1;
        return prism_rtl::cat("(while ", sexp_cond(c, d), sexp_block(body, d), ")");
    }
    if (prism_rtl::is<crate::ast::StmtKind::SReturn>(_m)) {
        auto&& e = prism_rtl::as<crate::ast::StmtKind::SReturn>(_m).a0;
        return prism_rtl::cat("(return ", sexp_expr(e, d), ")");
    }
    if (prism_rtl::is<crate::ast::StmtKind::SExpr>(_m)) {
        auto&& e = prism_rtl::as<crate::ast::StmtKind::SExpr>(_m).a0;
        return sexp_expr(e, d);
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpCond: fn Cond, Nat -> Text
Text sexp_cond(const crate::ast::Cond& cond0, const Nat& d) {
    if (prism_rtl::is<crate::ast::Cond::CondExpr>(cond0)) {
        auto&& e = prism_rtl::as<crate::ast::Cond::CondExpr>(cond0).a0;
        return sexp_expr(e, d);
    }
    if (prism_rtl::is<crate::ast::Cond::CondBind>(cond0)) {
        auto&& p_ = prism_rtl::as<crate::ast::Cond::CondBind>(cond0).a0;
        auto&& v_ = prism_rtl::as<crate::ast::Cond::CondBind>(cond0).a1;
        auto&& g_opt = prism_rtl::as<crate::ast::Cond::CondBind>(cond0).a2;
        return prism_rtl::cat("(<- ", sexp_pattern(p_, d), " ", sexp_expr(v_, d), sexp_guard(g_opt, d), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpGuard: fn ?Expr, Nat -> Text
Text sexp_guard(const std::optional<crate::ast::Expr>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& g = prism_rtl::some_of(std::get<0>(_m));
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat(" (if ", sexp_expr(g, d), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpLiteral: fn Literal, Nat -> Text
Text sexp_literal(const crate::ast::Literal& l, const Nat& d) {
    auto&& _m = l.kind;
    if (prism_rtl::is<crate::ast::LitKind::LInt>(_m)) {
        auto&& s = prism_rtl::as<crate::ast::LitKind::LInt>(_m).a0;
        return prism_rtl::cat(l.marks, s);
    }
    if (prism_rtl::is<crate::ast::LitKind::LFloat>(_m)) {
        auto&& s = prism_rtl::as<crate::ast::LitKind::LFloat>(_m).a0;
        return prism_rtl::cat(l.marks, s);
    }
    if (prism_rtl::is<crate::ast::LitKind::LDuration>(_m)) {
        auto&& digits = prism_rtl::as<crate::ast::LitKind::LDuration>(_m).a0;
        auto&& u = prism_rtl::as<crate::ast::LitKind::LDuration>(_m).a1;
        return prism_rtl::cat(l.marks, digits, u);
    }
    if (prism_rtl::is<crate::ast::LitKind::LChar>(_m)) {
        auto&& c = prism_rtl::as<crate::ast::LitKind::LChar>(_m).a0;
        return prism_rtl::cat(l.marks, crate::lexer::debug_char(c));
    }
    if (prism_rtl::is<crate::ast::LitKind::LText>(_m)) {
        auto&& segs = prism_rtl::as<crate::ast::LitKind::LText>(_m).a0;
        return all_plain_segs(segs)
            ? prism_rtl::cat(l.marks, crate::lexer::debug_text(concat(each(segs, plain_seg_text))))
            : prism_rtl::cat("(", l.marks, "text", concat(each(segs, [&](const crate::ast::TextSeg& s) { return prism_rtl::cat(" ", sexp_seg(s, d)); })), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// AllPlainSegs: fn [TextSeg] -> Bool
bool all_plain_segs(const Array<crate::ast::TextSeg>& segs) {
    return fold(segs, true, [&](const bool& ok, const crate::ast::TextSeg& s) { return ok && is_plain_text_seg(s); });
}


/// IsPlainTextSeg: fn TextSeg -> Bool
bool is_plain_text_seg(const crate::ast::TextSeg& text_seg0) {
    if (prism_rtl::is<crate::ast::TextSeg::SegPlain>(text_seg0)) {
        return true;
    }
    {
        return false;
    }
}


/// PlainSegText: fn TextSeg -> Text
Text plain_seg_text(const crate::ast::TextSeg& text_seg0) {
    if (prism_rtl::is<crate::ast::TextSeg::SegPlain>(text_seg0)) {
        auto&& s = prism_rtl::as<crate::ast::TextSeg::SegPlain>(text_seg0).a0;
        return s;
    }
    {
        return Text::lit("");
    }
}


/// SexpSeg: fn TextSeg, Nat -> Text
Text sexp_seg(const crate::ast::TextSeg& text_seg0, const Nat& n1) {
    auto&& _m = std::tuple{text_seg0, n1};
    if (prism_rtl::is<crate::ast::TextSeg::SegPlain>(std::get<0>(_m))) {
        auto&& p_ = prism_rtl::as<crate::ast::TextSeg::SegPlain>(std::get<0>(_m)).a0;
        return crate::lexer::debug_text(p_);
    }
    if (prism_rtl::is<crate::ast::TextSeg::SegPlaceholder>(std::get<0>(_m))) {
        auto&& e = prism_rtl::as<crate::ast::TextSeg::SegPlaceholder>(std::get<0>(_m)).a0;
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat("{", sexp_expr(e, d), "}");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpArgs: fn [Arg], Nat -> Text
Text sexp_args(const Array<crate::ast::Arg>& args, const Nat& d) {
    return concat(each(args, [&](const crate::ast::Arg& a) { return prism_rtl::cat(" ", arg_name(a.name), sexp_expr(a->value, d)); }));
}


/// ArgName: fn ?Ident -> Text
Text arg_name(const std::optional<crate::ast::Ident>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& n = prism_rtl::some_of(opt0);
        return prism_rtl::cat(n.name, "=");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpExprs: fn [Expr], Nat -> Text
Text sexp_exprs(const Array<crate::ast::Expr>& es, const Nat& d) {
    return concat(each(es, [&](const crate::ast::Expr& x) { return prism_rtl::cat(" ", sexp_expr(x, d)); }));
}


/// SexpExpr: fn Expr, Nat -> Text
Text sexp_expr(const crate::ast::Expr& e, const Nat& d) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::ExprKind::EName>(_m).a0;
        return sname_text(n);
    }
    if (prism_rtl::is<crate::ast::ExprKind::ELit>(_m)) {
        auto&& l = prism_rtl::as<crate::ast::ExprKind::ELit>(_m).a0;
        return sexp_literal(l, d);
    }
    if (prism_rtl::is<crate::ast::ExprKind::EUnit>(_m)) {
        auto&& s = prism_rtl::as<crate::ast::ExprKind::EUnit>(_m).a0;
        return prism_rtl::cat(s, "unit");
    }
    if (prism_rtl::is<crate::ast::ExprKind::ENil>(_m)) {
        auto&& s = prism_rtl::as<crate::ast::ExprKind::ENil>(_m).a0;
        return prism_rtl::cat(s, "nil");
    }
    if (prism_rtl::is<crate::ast::ExprKind::EBound>(_m)) {
        auto&& b = prism_rtl::as<crate::ast::ExprKind::EBound>(_m).a0;
        return b;
    }
    if (prism_rtl::is<crate::ast::ExprKind::ETuple>(_m)) {
        auto&& es = prism_rtl::as<crate::ast::ExprKind::ETuple>(_m).a0;
        return prism_rtl::cat("(tuple", sexp_exprs(es, d), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::EArray>(_m)) {
        auto&& es = prism_rtl::as<crate::ast::ExprKind::EArray>(_m).a0;
        return prism_rtl::cat("(array", sexp_exprs(es, d), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::EMap>(_m)) {
        auto&& es = prism_rtl::as<crate::ast::ExprKind::EMap>(_m).a0;
        return prism_rtl::cat("(map", concat(each(es, [&](const std::tuple<crate::ast::Expr, crate::ast::Expr>& _p0) {
            auto&& k = std::get<0>(_p0);
            auto&& v_ = std::get<1>(_p0);
            return prism_rtl::cat(" (", sexp_expr(k, d), ": ", sexp_expr(v_, d), ")");
        })), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
        return prism_rtl::cat("(group ", sexp_expr(x, d), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::ECall>(_m)) {
        auto&& callee = prism_rtl::as<crate::ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::ast::ExprKind::ECall>(_m).a1;
        auto&& parens = prism_rtl::as<crate::ast::ExprKind::ECall>(_m).a2;
        auto&& rest = prism_rtl::as<crate::ast::ExprKind::ECall>(_m).a3;
        return prism_rtl::cat("(", parens ? Text::lit("call()") : Text::lit("call"), " ", sexp_expr(callee, d), sexp_args(args, d), rest ? Text::lit(" ..") : Text::lit(""), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::EBinary>(_m)) {
        auto&& op = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a0;
        auto&& lhs = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a1;
        auto&& rhs = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a2;
        return prism_rtl::cat("(", op, " ", sexp_expr(lhs, d), " ", sexp_expr(rhs, d), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::ESuffixed>(_m)) {
        auto&& op = prism_rtl::as<crate::ast::ExprKind::ESuffixed>(_m).a0;
        auto&& ty = prism_rtl::as<crate::ast::ExprKind::ESuffixed>(_m).a1;
        auto&& lhs = prism_rtl::as<crate::ast::ExprKind::ESuffixed>(_m).a2;
        auto&& rhs = prism_rtl::as<crate::ast::ExprKind::ESuffixed>(_m).a3;
        return prism_rtl::cat("(", op, sexp::path_(ty->path_), " ", sexp_expr(lhs, d), " ", sexp_expr(rhs, d), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::EUnary>(_m)) {
        auto&& op = prism_rtl::as<crate::ast::ExprKind::EUnary>(_m).a0;
        auto&& operand = prism_rtl::as<crate::ast::ExprKind::EUnary>(_m).a1;
        return prism_rtl::cat("(", op, " ", sexp_expr(operand, d), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::EFreeSigil>(_m)) {
        auto&& s = prism_rtl::as<crate::ast::ExprKind::EFreeSigil>(_m).a0;
        auto&& operand = prism_rtl::as<crate::ast::ExprKind::EFreeSigil>(_m).a1;
        return prism_rtl::cat("(free", s, " ", sexp_expr(operand, d), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::EField>(_m)) {
        auto&& recv = prism_rtl::as<crate::ast::ExprKind::EField>(_m).a0;
        auto&& sigils = prism_rtl::as<crate::ast::ExprKind::EField>(_m).a1;
        auto&& name = prism_rtl::as<crate::ast::ExprKind::EField>(_m).a2;
        return prism_rtl::cat("(. ", sexp_expr(recv, d), " ", sigils, name.name, ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::EIndex>(_m)) {
        auto&& recv = prism_rtl::as<crate::ast::ExprKind::EIndex>(_m).a0;
        auto&& index = prism_rtl::as<crate::ast::ExprKind::EIndex>(_m).a1;
        return prism_rtl::cat("(index ", sexp_expr(recv, d), " ", sexp_expr(index, d), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::ETopicField>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::ExprKind::ETopicField>(_m).a0;
        return prism_rtl::cat("(. _ ", n.name, ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::ETopicIndex>(_m)) {
        auto&& i = prism_rtl::as<crate::ast::ExprKind::ETopicIndex>(_m).a0;
        return prism_rtl::cat("(index _ ", sexp_expr(i, d), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::EMethod>(_m)) {
        auto&& recv = prism_rtl::as<crate::ast::ExprKind::EMethod>(_m).a0;
        auto&& method = prism_rtl::as<crate::ast::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<crate::ast::ExprKind::EMethod>(_m).a2;
        return prism_rtl::cat("(.", sname_text(method), " ", sexp_expr(recv, d), sexp_args(args, d), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::ETypeArgs>(_m)) {
        auto&& target = prism_rtl::as<crate::ast::ExprKind::ETypeArgs>(_m).a0;
        auto&& types = prism_rtl::as<crate::ast::ExprKind::ETypeArgs>(_m).a1;
        return prism_rtl::cat("(<<>> ", sexp_expr(target, d), spaced(types, ({
            auto f = prism_rtl::rc(sexp_type);
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::ast::Type)>>(prism_rtl::rc([=](crate::ast::Type a0) {
            return ({
                auto f_1 = f;
                once_job([=]() { return prism_rtl::finished(f_1(a0)); });
            });
        })));
        })), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::ECast>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::ECast>(_m).a0;
        auto&& ty = prism_rtl::as<crate::ast::ExprKind::ECast>(_m).a1;
        auto&& checked = prism_rtl::as<crate::ast::ExprKind::ECast>(_m).a2;
        return prism_rtl::cat("(", checked ? Text::lit("as?") : Text::lit("as"), " ", sexp_expr(x, d), " ", sexp_type(ty), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::ENonEmpty>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::ENonEmpty>(_m).a0;
        return prism_rtl::cat("(nonempty ", sexp_expr(x, d), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::EAbsent>(_m)) {
        return Text::lit("absent");
    }
    if (prism_rtl::is<crate::ast::ExprKind::ERest>(_m)) {
        return Text::lit("..");
    }
    if (prism_rtl::is<crate::ast::ExprKind::ELambda>(_m)) {
        auto&& params_opt = prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a1;
        return prism_rtl::cat("(lambda", sexp_lambda_params(params_opt, d), sexp_lambda_body(body, d), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::EIf>(_m)) {
        auto&& c = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a0;
        auto&& then_block = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a1;
        auto&& else_block_opt = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a2;
        return prism_rtl::cat("(if ", sexp_cond(c, d), sexp_block(then_block, d), sexp_else(else_block_opt, d), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::EMatch>(_m)) {
        auto&& scrutinee = prism_rtl::as<crate::ast::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::ast::ExprKind::EMatch>(_m).a1;
        return prism_rtl::cat("(match ", sexp_expr(scrutinee, d), concat(each(arms, [&](const crate::ast::Arm& a) { return prism_rtl::cat(nl(d + Nat(1u)), sexp_arm(a, d + Nat(1u))); })), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::ERebuild>(_m)) {
        auto&& scrutinee = prism_rtl::as<crate::ast::ExprKind::ERebuild>(_m).a0;
        auto&& body = prism_rtl::as<crate::ast::ExprKind::ERebuild>(_m).a1;
        return prism_rtl::cat("(rebuild ", sexp_expr(scrutinee, d), sexp_block(body, d), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::EFor>(_m)) {
        auto&& binders_opt = prism_rtl::as<crate::ast::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<crate::ast::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<crate::ast::ExprKind::EFor>(_m).a2;
        return prism_rtl::cat("(for", sexp_binders(binders_opt, d), " ", sexp_expr(source, d), sexp_block(body, d), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::EGiven>(_m)) {
        auto&& b = prism_rtl::as<crate::ast::ExprKind::EGiven>(_m).a0;
        return prism_rtl::cat("(given", sexp_block(b, d), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::EUpdate>(_m)) {
        auto&& target = prism_rtl::as<crate::ast::ExprKind::EUpdate>(_m).a0;
        auto&& body = prism_rtl::as<crate::ast::ExprKind::EUpdate>(_m).a1;
        return prism_rtl::cat("(update ", sexp_expr(target, d), sexp_block(body, d), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::EWidgetBlock>(_m)) {
        auto&& b = prism_rtl::as<crate::ast::ExprKind::EWidgetBlock>(_m).a0;
        return prism_rtl::cat("(@widget", sexp_block(b, d), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::EMonad>(_m)) {
        auto&& m = prism_rtl::as<crate::ast::ExprKind::EMonad>(_m).a0;
        auto&& body = prism_rtl::as<crate::ast::ExprKind::EMonad>(_m).a1;
        return prism_rtl::cat("(monad ", sexp_expr(m, d), sexp_block(body, d), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::ETemplate>(_m)) {
        auto&& t = prism_rtl::as<crate::ast::ExprKind::ETemplate>(_m).a0;
        return sexp_template(t, d);
    }
    if (prism_rtl::is<crate::ast::ExprKind::EAny>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EAny>(_m).a0;
        return prism_rtl::cat("(any ", sexp_expr(x, d), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::ELens>(_m)) {
        auto&& path__ = prism_rtl::as<crate::ast::ExprKind::ELens>(_m).a0;
        return prism_rtl::cat("(lens ", crate::lexer::join(each(path__, [&](const crate::ast::Ident& i) { return i.name; }), Text::lit(".")), ")");
    }
    if (prism_rtl::is<crate::ast::ExprKind::EError>(_m)) {
        return Text::lit("<error>");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpLambdaParams: fn ?[Pattern], Nat -> Text
Text sexp_lambda_params(const std::optional<Array<crate::ast::Pattern_>>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit(" topic");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& ps = prism_rtl::some_of(std::get<0>(_m));
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat(" (params", concat(each(ps, [&](const crate::ast::Pattern_& p_) { return prism_rtl::cat(" ", sexp_pattern(p_, d)); })), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpLambdaBody: fn LambdaBody, Nat -> Text
Text sexp_lambda_body(const crate::ast::LambdaBody& lambda_body0, const Nat& d) {
    if (prism_rtl::is<crate::ast::LambdaBody::LbExpr>(lambda_body0)) {
        auto&& e = prism_rtl::as<crate::ast::LambdaBody::LbExpr>(lambda_body0).a0;
        return prism_rtl::cat(" ", sexp_expr(e, d));
    }
    if (prism_rtl::is<crate::ast::LambdaBody::LbBlock>(lambda_body0)) {
        auto&& b = prism_rtl::as<crate::ast::LambdaBody::LbBlock>(lambda_body0).a0;
        return sexp_block(b, d);
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpElse: fn ?Block, Nat -> Text
Text sexp_else(const std::optional<crate::ast::Block>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& b = prism_rtl::some_of(std::get<0>(_m));
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat(b.inline_ ? Text::lit("") : nl(d), " else", sexp_block(b, d));
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpArm: fn Arm, Nat -> Text
Text sexp_arm(const crate::ast::Arm& a, const Nat& d) {
    auto pattern = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = a.pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            _v.set(sexp_pattern(p_, d));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit("otherwise"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::cat("(arm ", pattern, sexp_guard(a.guard, d), sexp_block(a.body, d), ")");
}


/// SexpBinders: fn ?ForBinders, Nat -> Text
Text sexp_binders(const std::optional<crate::ast::ForBinders>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& b = prism_rtl::some_of(std::get<0>(_m));
        auto&& d = std::get<1>(_m);
        auto second = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            auto&& _m = b.second;
            if (prism_rtl::is_some(_m)) {
                auto&& s = prism_rtl::some_of(_m);
                _v.set(prism_rtl::cat(", ", sexp_pattern(s, d)));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return prism_rtl::cat(" ", sexp_pattern(b.first, d), second, " <-");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpTemplate: fn Template, Nat -> Text
Text sexp_template(const crate::ast::Template& t, const Nat& d) {
    return prism_rtl::cat("(template ", t.keyword, " <", t.lang, ">", sexp_parts(t.parts, d + Nat(1u)), ")");
}


/// SexpParts: fn [TemplatePart], Nat -> Text
Text sexp_parts(const Array<crate::ast::TemplatePart>& parts, const Nat& d) {
    return concat(each(parts, [&](const crate::ast::TemplatePart& p_) { return prism_rtl::cat(nl(d), sexp_part(p_, d)); }));
}


/// SexpPart: fn TemplatePart, Nat -> Text
Text sexp_part(const crate::ast::TemplatePart& template_part0, const Nat& n1) {
    auto&& _m = std::tuple{template_part0, n1};
    if (prism_rtl::is<crate::ast::TemplatePart::TpText>(std::get<0>(_m))) {
        auto&& s = prism_rtl::as<crate::ast::TemplatePart::TpText>(std::get<0>(_m)).a0;
        return crate::lexer::debug_text(s);
    }
    if (prism_rtl::is<crate::ast::TemplatePart::TpPlaceholder>(std::get<0>(_m))) {
        auto&& e = prism_rtl::as<crate::ast::TemplatePart::TpPlaceholder>(std::get<0>(_m)).a0;
        auto&& col_opt = prism_rtl::as<crate::ast::TemplatePart::TpPlaceholder>(std::get<0>(_m)).a1;
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat("{{", sexp_expr(e, d), "}}", column_text(col_opt));
    }
    if (prism_rtl::is<crate::ast::TemplatePart::TpBlock>(std::get<0>(_m))) {
        auto&& b = prism_rtl::as<crate::ast::TemplatePart::TpBlock>(std::get<0>(_m)).a0;
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat("(brace-block", sexp_block(b, d), ")");
    }
    if (prism_rtl::is<crate::ast::TemplatePart::TpCall>(std::get<0>(_m))) {
        auto&& name = prism_rtl::as<crate::ast::TemplatePart::TpCall>(std::get<0>(_m)).a0;
        auto&& attrs = prism_rtl::as<crate::ast::TemplatePart::TpCall>(std::get<0>(_m)).a1;
        auto&& body_opt = prism_rtl::as<crate::ast::TemplatePart::TpCall>(std::get<0>(_m)).a2;
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat("(call ", sname_text(name), sexp_args(attrs, d), call_parts(body_opt, d), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ColumnText: fn ?Nat -> Text
Text column_text(const std::optional<Nat>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& c = prism_rtl::some_of(opt0);
        return prism_rtl::cat(" @col ", c);
    }
    prism_rtl::unreachable("no arm matched");
}


/// CallParts: fn ?[TemplatePart], Nat -> Text
Text call_parts(const std::optional<Array<crate::ast::TemplatePart>>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& parts = prism_rtl::some_of(std::get<0>(_m));
        auto&& d = std::get<1>(_m);
        return sexp_parts(parts, d + Nat(1u));
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpPattern: fn Pattern, Nat -> Text
Text sexp_pattern(const crate::ast::Pattern_& p_, const Nat& d) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::ast::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
        return sname_text(n);
    }
    if (prism_rtl::is<crate::ast::PatternKind::PIgnore>(_m)) {
        return Text::lit("ignore");
    }
    if (prism_rtl::is<crate::ast::PatternKind::PLit>(_m)) {
        auto&& l = prism_rtl::as<crate::ast::PatternKind::PLit>(_m).a0;
        return sexp_literal(l, d);
    }
    if (prism_rtl::is<crate::ast::PatternKind::PNeg>(_m)) {
        auto&& l = prism_rtl::as<crate::ast::PatternKind::PNeg>(_m).a0;
        return prism_rtl::cat("-", sexp_literal(l, d));
    }
    if (prism_rtl::is<crate::ast::PatternKind::PUnit>(_m)) {
        return Text::lit("unit");
    }
    if (prism_rtl::is<crate::ast::PatternKind::PNil>(_m)) {
        return Text::lit("nil");
    }
    if (prism_rtl::is<crate::ast::PatternKind::PCtor>(_m)) {
        auto&& name = prism_rtl::as<crate::ast::PatternKind::PCtor>(_m).a0;
        auto&& args = prism_rtl::as<crate::ast::PatternKind::PCtor>(_m).a1;
        return prism_rtl::cat("(ctor ", sname_text(name), concat(each(args, [&](const crate::ast::Pattern_& a) { return prism_rtl::cat(" ", sexp_pattern(a, d)); })), ")");
    }
    if (prism_rtl::is<crate::ast::PatternKind::PRecord>(_m)) {
        auto&& name = prism_rtl::as<crate::ast::PatternKind::PRecord>(_m).a0;
        auto&& fields = prism_rtl::as<crate::ast::PatternKind::PRecord>(_m).a1;
        auto&& rest = prism_rtl::as<crate::ast::PatternKind::PRecord>(_m).a2;
        return prism_rtl::cat("(record ", sname_text(name), concat(each(fields, [&](const crate::ast::FieldPat& f) { return prism_rtl::cat(" ", arg_name(f.name), sexp_pattern(f.pattern, d)); })), rest ? Text::lit(" ..") : Text::lit(""), ")");
    }
    if (prism_rtl::is<crate::ast::PatternKind::PSigil>(_m)) {
        auto&& s = prism_rtl::as<crate::ast::PatternKind::PSigil>(_m).a0;
        auto&& inner = prism_rtl::as<crate::ast::PatternKind::PSigil>(_m).a1;
        return prism_rtl::cat("(free", s, " ", sexp_pattern(inner, d), ")");
    }
    if (prism_rtl::is<crate::ast::PatternKind::PTuple>(_m)) {
        auto&& ps = prism_rtl::as<crate::ast::PatternKind::PTuple>(_m).a0;
        return prism_rtl::cat("(tuple", concat(each(ps, [&](const crate::ast::Pattern_& x) { return prism_rtl::cat(" ", sexp_pattern(x, d)); })), ")");
    }
    if (prism_rtl::is<crate::ast::PatternKind::PArray>(_m)) {
        auto&& ps = prism_rtl::as<crate::ast::PatternKind::PArray>(_m).a0;
        return prism_rtl::cat("(array", concat(each(ps, [&](const crate::ast::Pattern_& x) { return prism_rtl::cat(" ", sexp_pattern(x, d)); })), ")");
    }
    if (prism_rtl::is<crate::ast::PatternKind::PGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::PatternKind::PGroup>(_m).a0;
        return prism_rtl::cat("(group ", sexp_pattern(x, d), ")");
    }
    if (prism_rtl::is<crate::ast::PatternKind::PFamily>(_m)) {
        auto&& q = prism_rtl::as<crate::ast::PatternKind::PFamily>(_m).a0;
        return prism_rtl::cat(sexp::path_(q->path_), ".*");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpType: fn Type -> Text
Text sexp_type(const crate::ast::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<crate::ast::TypeKind::TName>(_m)) {
        auto&& name = prism_rtl::as<crate::ast::TypeKind::TName>(_m).a0;
        auto&& m16205_0_1 = prism_rtl::as<crate::ast::TypeKind::TName>(_m).a1;
        if (m16205_0_1.size() == 0u) {
            return sname_text(name);
        }
    }
    if (prism_rtl::is<crate::ast::TypeKind::TName>(_m)) {
        auto&& name = prism_rtl::as<crate::ast::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<crate::ast::TypeKind::TName>(_m).a1;
        return prism_rtl::cat("(", sname_text(name), concat(each(args, [&](const crate::ast::Type& a) { return prism_rtl::cat(" ", sexp_type(a)); })), ")");
    }
    if (prism_rtl::is<crate::ast::TypeKind::TSigiled>(_m)) {
        auto&& sigils = prism_rtl::as<crate::ast::TypeKind::TSigiled>(_m).a0;
        auto&& inner = prism_rtl::as<crate::ast::TypeKind::TSigiled>(_m).a1;
        return prism_rtl::cat("(free", sigils, " ", sexp_type(inner), ")");
    }
    if (prism_rtl::is<crate::ast::TypeKind::TArray>(_m) && prism_rtl::as<crate::ast::TypeKind::TArray>(_m).a1) {
        auto&& elem = prism_rtl::as<crate::ast::TypeKind::TArray>(_m).a0;
        return prism_rtl::cat("[[", sexp_type(elem), "]]");
    }
    if (prism_rtl::is<crate::ast::TypeKind::TArray>(_m) && !prism_rtl::as<crate::ast::TypeKind::TArray>(_m).a1) {
        auto&& elem = prism_rtl::as<crate::ast::TypeKind::TArray>(_m).a0;
        return prism_rtl::cat("[", sexp_type(elem), "]");
    }
    if (prism_rtl::is<crate::ast::TypeKind::TTuple>(_m)) {
        auto&& ts = prism_rtl::as<crate::ast::TypeKind::TTuple>(_m).a0;
        return prism_rtl::cat("(tuple", concat(each(ts, [&](const crate::ast::Type& x) { return prism_rtl::cat(" ", sexp_type(x)); })), ")");
    }
    if (prism_rtl::is<crate::ast::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::TypeKind::TGroup>(_m).a0;
        return prism_rtl::cat("(group ", sexp_type(x), ")");
    }
    if (prism_rtl::is<crate::ast::TypeKind::TMap>(_m)) {
        auto&& k = prism_rtl::as<crate::ast::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::ast::TypeKind::TMap>(_m).a1;
        return prism_rtl::cat("(==> ", sexp_type(k), " ", sexp_type(v_), ")");
    }
    if (prism_rtl::is<crate::ast::TypeKind::TFn>(_m)) {
        auto&& color = prism_rtl::as<crate::ast::TypeKind::TFn>(_m).a0;
        auto&& params = prism_rtl::as<crate::ast::TypeKind::TFn>(_m).a1;
        auto&& result = prism_rtl::as<crate::ast::TypeKind::TFn>(_m).a2;
        return prism_rtl::cat("(", color_text(color), "fn", concat(each(params, [&](const crate::ast::Type& x) { return prism_rtl::cat(" ", sexp_type(x)); })), " -> ", sexp_type(result), ")");
    }
    if (prism_rtl::is<crate::ast::TypeKind::TEmit>(_m)) {
        auto&& ty = prism_rtl::as<crate::ast::TypeKind::TEmit>(_m).a0;
        auto&& r = prism_rtl::as<crate::ast::TypeKind::TEmit>(_m).a1;
        return prism_rtl::cat("(emit ", sexp_type(ty), " ", sexp_type(r), ")");
    }
    if (prism_rtl::is<crate::ast::TypeKind::TRowUnion>(_m)) {
        auto&& ts = prism_rtl::as<crate::ast::TypeKind::TRowUnion>(_m).a0;
        return prism_rtl::cat("(|", concat(each(ts, [&](const crate::ast::Type& x) { return prism_rtl::cat(" ", sexp_type(x)); })), ")");
    }
    if (prism_rtl::is<crate::ast::TypeKind::TFamily>(_m)) {
        auto&& q = prism_rtl::as<crate::ast::TypeKind::TFamily>(_m).a0;
        return prism_rtl::cat(sexp::path_(q->path_), ".*");
    }
    if (prism_rtl::is<crate::ast::TypeKind::TAny>(_m)) {
        auto&& tr = prism_rtl::as<crate::ast::TypeKind::TAny>(_m).a0;
        return prism_rtl::cat("(any ^", sexp::path_(tr->path_), ")");
    }
    if (prism_rtl::is<crate::ast::TypeKind::TUnit>(_m)) {
        auto&& s = prism_rtl::as<crate::ast::TypeKind::TUnit>(_m).a0;
        return prism_rtl::cat(s, "unit");
    }
    if (prism_rtl::is<crate::ast::TypeKind::THole>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::TypeKind::THole>(_m).a0;
        return sname_text(n);
    }
    if (prism_rtl::is<crate::ast::TypeKind::TAbsent>(_m)) {
        return Text::lit("absent");
    }
    if (prism_rtl::is<crate::ast::TypeKind::TNonEmpty>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::TypeKind::TNonEmpty>(_m).a0;
        return prism_rtl::cat("(nonempty ", sexp_type(x), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ColorText: fn Color -> Text
Text color_text(const crate::ast::Color& color0) {
    if (prism_rtl::is<crate::ast::Color::Bounded>(color0)) {
        return Text::lit("");
    }
    if (prism_rtl::is<crate::ast::Color::Unbounded>(color0)) {
        return Text::lit("unbounded ");
    }
    if (prism_rtl::is<crate::ast::Color::ColorVar>(color0)) {
        auto&& v_ = prism_rtl::as<crate::ast::Color::ColorVar>(color0).a0;
        return prism_rtl::cat(v_.name, " ");
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::sexp
