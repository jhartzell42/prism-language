// The module `Sexp`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <sexp/types.hpp>
#include "elem.types.hpp"
#include <ast/types.hpp>
#include <lexer/types.hpp>

namespace crate {

using namespace prelude;

namespace sexp {

Text nl(const Nat& d);

Text indent(const Nat& d);

template <class A>
Text spaced(const Array<A>& xs, const prism_rtl::Fn<prism_rtl::JobRef<Text>(A)>& f_fn);

Text path_(const Array<Text>& p_);

Text sname_text(const crate::ast::SName& n);

Text sexp_module(const crate::ast::Module& m);

Text sexp_row(const crate::ast::Row_& r);

Text sexp_row_term(const crate::ast::RowTerm& row_term0);

Text sexp_decl(const crate::ast::Decl& d, const Nat& depth);

Text opt_type(const std::optional<crate::ast::Type>& opt0);

Text check_pattern(const std::optional<crate::ast::Pattern_>& opt0, const Nat& n1);

Text sexp_type_body(const std::optional<crate::ast::TypeBody>& opt0, const Nat& n1);

Text sexp_signature(const crate::ast::Signature& s);

Text sexp_def_name(const crate::ast::DefName& def_name0);

Text sexp_bounds(const Array<crate::ast::Bound>& bs);

Text sexp_fn(const crate::ast::FnClause& f, const Nat& depth);

Text sexp_fields(const Array<crate::ast::Field>& fs, const Nat& depth);

Text sexp_case(const crate::ast::Case_& c);

Text sexp_items(const Array<crate::ast::TraitItem>& items, const Nat& depth);

Text sexp_item(const crate::ast::TraitItem& trait_item0, const Nat& n1);

Text sexp_test(const crate::ast::TestDecl& t, const Nat& depth);

Text sexp_step(const crate::ast::TestStep& s, const Nat& d);

Text sexp_action(const crate::ast::StepAction& step_action0, const Nat& n1);

Text sexp_delivery(const crate::ast::Delivery& x, const Nat& d);

Text sexp_target(const crate::ast::Target& target0, const Nat& d);

Text sexp_path(const Text& word, const crate::ast::TestPath& p_, const Nat& d);

Text sexp_path_seg(const crate::ast::PathSeg& path_seg0, const Nat& n1);

Text sexp_check(const crate::ast::TestCheck& c, const Nat& d);

Text sexp_block(const crate::ast::Block& b, const Nat& d);

Text sexp_stmt(const crate::ast::Stmt& s, const Nat& d);

Text sexp_cond(const crate::ast::Cond& cond0, const Nat& d);

Text sexp_guard(const std::optional<crate::ast::Expr>& opt0, const Nat& n1);

Text sexp_literal(const crate::ast::Literal& l, const Nat& d);

bool all_plain_segs(const Array<crate::ast::TextSeg>& segs);

bool is_plain_text_seg(const crate::ast::TextSeg& text_seg0);

Text plain_seg_text(const crate::ast::TextSeg& text_seg0);

Text sexp_seg(const crate::ast::TextSeg& text_seg0, const Nat& n1);

Text sexp_args(const Array<crate::ast::Arg>& args, const Nat& d);

Text arg_name(const std::optional<crate::ast::Ident>& opt0);

Text sexp_exprs(const Array<crate::ast::Expr>& es, const Nat& d);

Text sexp_expr(const crate::ast::Expr& e, const Nat& d);

Text sexp_lambda_params(const std::optional<Array<crate::ast::Pattern_>>& opt0, const Nat& n1);

Text sexp_lambda_body(const crate::ast::LambdaBody& lambda_body0, const Nat& d);

Text sexp_else(const std::optional<crate::ast::Block>& opt0, const Nat& n1);

Text sexp_arm(const crate::ast::Arm& a, const Nat& d);

Text sexp_binders(const std::optional<crate::ast::ForBinders>& opt0, const Nat& n1);

Text sexp_template(const crate::ast::Template& t, const Nat& d);

Text sexp_parts(const Array<crate::ast::TemplatePart>& parts, const Nat& d);

Text sexp_part(const crate::ast::TemplatePart& template_part0, const Nat& n1);

Text column_text(const std::optional<Nat>& opt0);

Text call_parts(const std::optional<Array<crate::ast::TemplatePart>>& opt0, const Nat& n1);

Text sexp_pattern(const crate::ast::Pattern_& p_, const Nat& d);

Text sexp_type(const crate::ast::Type& t);

Text color_text(const crate::ast::Color& color0);

}  // namespace sexp



}  // namespace crate
