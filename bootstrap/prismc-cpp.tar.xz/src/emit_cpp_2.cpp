// The module `EmitCpp`, from `target/bootstrap/cpp-src/prismc/emit_cpp.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "crate.hpp"

namespace crate::emit_cpp {

/// `Start GuardTest, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_guard_test(Cp cp, Array<lower::Cc> xs1) {
    return std::make_shared<GuardTest>(cp, xs1);
}


/// MatchArm: unbounded fn Cp, Text, XArm -> Text
Text match_arm(const Cp& cp0, const Text& subject, const lower::XArm& a) {
    auto cp = unbind(cp0, arm_names(a));
    auto tests = pat_conds(cp, a.pat, subject);
    auto binds = pat_binds(cp, a.pat, subject);
    auto body = leaves(a.body)
        ? prism_rtl::cat(cpp_expr(cp, a.body), ";")
        : prism_rtl::cat("_v.set(", cpp_expr(cp, a.body), ");\ngoto _done;");
    auto guarded = len(a.conds) == Nat(0u) ? body : guarded_arm(cp, a.conds, body);
    auto inner = lexer::join(append(binds, Array(std::vector{guarded})), Text("\n"));
    return len(tests) == Nat(0u)
        ? cpp_templates::braced(inner)
        : cpp_templates::if_block(conds(tests), inner);
}


prism_rtl::Turn<Text> MatchArm::cycle() const {
    const auto& cp0 = this->cp0;
    const auto& subject = this->subject;
    const auto& a = this->a;
    auto a_1 = a;
    auto cp0_2 = cp0;
    auto subject_3 = subject;
    return call_then(start_arm_names(a_1), [=](Array<Text> arm_names_41634) {
        return ({
            auto cp = unbind(cp0_2, arm_names_41634);
            call_then(start_pat_conds(cp, a_1.pat, subject_3), [=](Array<Text> pat_conds_41662) {
            return ({
                auto tests = pat_conds_41662;
                call_then(start_pat_binds(cp, a_1.pat, subject_3), [=](Array<Text> pat_binds_41706) {
                return ({
                    auto binds = pat_binds_41706;
                    auto body = leaves(a_1.body)
                        ? prism_rtl::cat(cpp_expr(cp, a_1.body), ";")
                        : prism_rtl::cat("_v.set(", cpp_expr(cp, a_1.body), ");\ngoto _done;");
                    auto guarded = len(a_1.conds) == Nat(0u) ? body : guarded_arm(cp, a_1.conds, body);
                    auto inner = lexer::join(append(binds, Array(std::vector{guarded})), Text("\n"));
                    len(tests) == Nat(0u)
                    ? prism_rtl::finished(cpp_templates::braced(inner))
                    : prism_rtl::finished(cpp_templates::if_block(conds(tests), inner));
                });
            });
            });
        });
        });
    });
}


/// `Start MatchArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_match_arm(Cp cp0, Text subject, lower::XArm a) {
    return std::make_shared<MatchArm>(cp0, subject, a);
}


/// GuardedArm: unbounded fn Cp, [Cc], Text -> Text
Text guarded_arm(const Cp& cp, const Array<lower::Cc>& xs1, const Text& body) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& c0_1 = xs1;
            if (c0_1.size() == 0u) {
                _v.set(body);
                goto _done;
            }
        }
        {
            auto&& cs = xs1;
            _v.set(({
                auto first_ = or_(index(cs, Nat(0u)), lower::Cc(lower::Cc::CcIf{lower::Ex(lower::Ex::XUnit{})}));
                auto rest = guarded_arm(cp, drop(cs, Nat(1u)), body);
                ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is<lower::Cc::CcIf>(first_)) {
                    auto&& x = prism_rtl::as<lower::Cc::CcIf>(first_).a0;
                    _v.set(cpp_templates::if_block(cpp_expr(cp, x), rest));
                    goto _done;
                }
                if (prism_rtl::is<lower::Cc::CcLet>(first_)) {
                    auto&& p_ = prism_rtl::as<lower::Cc::CcLet>(first_).a0;
                    auto&& x = prism_rtl::as<lower::Cc::CcLet>(first_).a1;
                    _v.set(({
                        auto [v_, pre] = cond_subject(cp, x, len(cs));
                        auto inner = cpp_templates::if_block(conds(pat_conds(cp, p_, v_)), lexer::join(append(pat_binds(cp, p_, v_), Array(std::vector{rest})), Text("\n")));
                        len(pre) == Nat(0u)
                        ? inner
                        : cpp_templates::braced(lexer::join(prelude::push(pre, inner), Text("\n")));
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> GuardedArm::cycle() const {
    const auto& cp = this->cp;
    const auto& xs1 = this->xs1;
    const auto& body = this->body;
    return ({
        ({
        auto&& j0_1 = xs1;
        (j0_1.size() == 0u);
    }) ? ({
        auto&& j0_1 = xs1;
        prism_rtl::finished(body);
    })
        : ({
        auto&& cs = xs1;
        ({
        auto first_ = or_(index(cs, Nat(0u)), lower::Cc(lower::Cc::CcIf{lower::Ex(lower::Ex::XUnit{})}));
        auto body_1 = body;
        auto cp_2 = cp;
        auto cs_3 = cs;
        call_then(start_guarded_arm(cp_2, drop(cs_3, Nat(1u)), body_1), [=](Text guarded_arm_42306) {
        return ({
            auto rest = guarded_arm_42306;
            ({
            prism_rtl::is<lower::Cc::CcIf>(first_) ? ({
            auto&& x = prism_rtl::as<lower::Cc::CcIf>(first_).a0;
            ({
            auto x_4 = x;
            call_then(start_cpp_expr(cp_2, x_4), [=](Text cpp_expr_42382) { return prism_rtl::finished(cpp_templates::if_block(cpp_expr_42382, rest)); });
        });
        })
            : prism_rtl::is<lower::Cc::CcLet>(first_) ? ({
            auto&& p_ = prism_rtl::as<lower::Cc::CcLet>(first_).a0;
            auto&& x = prism_rtl::as<lower::Cc::CcLet>(first_).a1;
            ({
            auto p__4 = p_;
            auto x_5 = x;
            call_then(start_cond_subject(cp_2, x_5, len(cs_3)), [=](std::tuple<Text, Array<Text>> cond_subject_42452) {
            return ({
                auto [v_, pre] = cond_subject_42452;
                call_then(start_pat_conds(cp_2, p__4, v_), [=](Array<Text> pat_conds_42520) {
                return call_then(start_pat_binds(cp_2, p__4, v_), [=](Array<Text> pat_binds_42556) {
                    return ({
                        auto inner = cpp_templates::if_block(conds(pat_conds_42520), lexer::join(append(pat_binds_42556, Array(std::vector{rest})), Text("\n")));
                        len(pre) == Nat(0u)
                        ? prism_rtl::finished(inner)
                        : prism_rtl::finished(cpp_templates::braced(lexer::join(prelude::push(pre, inner), Text("\n"))));
                    });
                });
            });
            });
        });
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    });
    });
    });
}


/// `Start GuardedArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_guarded_arm(Cp cp, Array<lower::Cc> xs1, Text body) {
    return std::make_shared<GuardedArm>(cp, xs1, body);
}


/// CppLabeled: unbounded fn Cp, Text, [Do], Ex, OutTy -> Text
Text cpp_labeled(const Cp& cp, const Text& label, const Array<lower::Do>& dos, const lower::Ex& e, const lower::OutTy& t) {
    auto l = cpp_label(label);
    auto last = leaves(e)
        ? prism_rtl::cat(cpp_expr(cp, e), ";")
        : prism_rtl::cat(l, "_v.set(", cpp_expr(cp, e), ");");
    return cpp_templates::labeled_expr(l, cpp_type(cp, t), lexer::join(prelude::push(run_to_end(each_job(dos, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Do)>>(prism_rtl::rc([=](lower::Do p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(CppStatement(cp_1_2, d))));
            });
        }));
        });
    })));
    }))), last), Text("\n")));
}


prism_rtl::Turn<Text> CppLabeled::cycle() const {
    const auto& cp = this->cp;
    const auto& label = this->label;
    const auto& dos = this->dos;
    const auto& e = this->e;
    const auto& t = this->t;
    auto l = cpp_label(label);
    auto last = leaves(e)
        ? prism_rtl::cat(cpp_expr(cp, e), ";")
        : prism_rtl::cat(l, "_v.set(", cpp_expr(cp, e), ");");
    auto cp_1 = cp;
    auto dos_2 = dos;
    auto t_3 = t;
    return call_then(start_cpp_type(cp_1, t_3), [=](Text cpp_type_42982) {
        return call_value(each_job(dos_2, ({
            auto cp_1_4 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Do)>>(prism_rtl::rc([=](lower::Do p0) {
            return ({
                auto cp_1_4_4 = cp_1_4;
                entered(once_job([=]() {
                return ({
                    auto d = p0;
                    (prism_rtl::more(prism_rtl::rc(CppStatement(cp_1_4_4, d))));
                });
            }));
            });
        })));
        })), [=](Array<Text> each_43011) { return prism_rtl::finished(cpp_templates::labeled_expr(l, cpp_type_42982, lexer::join(prelude::push(each_43011, last), Text("\n")))); });
    });
}


/// `Start CppLabeled, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_labeled(Cp cp, Text label, Array<lower::Do> dos, lower::Ex e, lower::OutTy t) {
    return std::make_shared<CppLabeled>(cp, label, dos, e, t);
}


/// CppLabel: fn Text -> Text
Text cpp_label(const Text& l) {
    return take_text(l, Nat(1u)) == Text("'") ? drop_text(l, Nat(1u)) : l;
}


/// CppBreak: unbounded fn Cp, Text, Ex -> Text
Text cpp_break(const Cp& cp, const Text& l, const lower::Ex& y) {
    auto n = cpp_label(l);
    return prism_rtl::cat("{ ", n, "_v.set(", cpp_expr(cp, y), "); goto ", n, "; }");
}


prism_rtl::Turn<Text> CppBreak::cycle() const {
    const auto& cp = this->cp;
    const auto& l = this->l;
    const auto& y = this->y;
    auto n = cpp_label(l);
    auto cp_1 = cp;
    auto y_2 = y;
    return call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_43253) { return prism_rtl::finished(prism_rtl::cat("{ ", n, "_v.set(", cpp_expr_43253, "); goto ", n, "; }")); });
}


/// `Start CppBreak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_break(Cp cp, Text l, lower::Ex y) {
    return std::make_shared<CppBreak>(cp, l, y);
}


/// CppStatements: unbounded fn Cp, [Do] -> Text
Text cpp_statements(const Cp& cp, const Array<lower::Do>& dos) {
    auto&& _st = cpp_statements_cp(cp, dos);
    auto&& st = std::get<0>(_st);
    return st;
}


prism_rtl::Turn<Text> CppStatements::cycle() const {
    const auto& cp = this->cp;
    const auto& dos = this->dos;
    auto cp_1 = cp;
    auto dos_2 = dos;
    return call_then(start_cpp_statements_cp(cp_1, dos_2), [=](std::tuple<Text, Cp> cpp_statements_cp_43575) {
        return ({
            auto&& _st = cpp_statements_cp_43575;
            auto&& st = std::get<0>(_st);
            (prism_rtl::finished(st));
        });
    });
}


/// `Start CppStatements, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_statements(Cp cp, Array<lower::Do> dos) {
    return std::make_shared<CppStatements>(cp, dos);
}


/// CppStatementsCp: unbounded fn Cp, [Do] -> ((Text, Cp))
std::tuple<Text, Cp> cpp_statements_cp(const Cp& cp, const Array<lower::Do>& dos) {
    auto [lines, last] = run_to_end(fold_job(dos, std::tuple{Array<Text>{}, cp}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Cp>>(std::tuple<std::tuple<Array<Text>, Cp>, lower::Do>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, Cp>, lower::Do> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [acc, c] = p0;
                auto d = p1;
                call_then(start_rebound(c, d), [=](Cp rebound_44002) {
                return ({
                    auto c2 = rebound_44002;
                    auto line = ({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        if (prism_rtl::is<lower::Do::DoLet>(d)) {
                            auto&& p_ = prism_rtl::as<lower::Do::DoLet>(d).a0;
                            auto&& x = prism_rtl::as<lower::Do::DoLet>(d).a1;
                            _v.set(cpp_let(c, c2, p_, x));
                            goto _done;
                        }
                        {
                            _v.set(cpp_statement(c2, d));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{prelude::push(acc, line), c2}));
                });
            });
            });
        }));
    }))));
    return std::tuple{lexer::join(lines, Text("\n")), last};
}


prism_rtl::Turn<std::tuple<Text, Cp>> CppStatementsCp::cycle() const {
    const auto& cp = this->cp;
    const auto& dos = this->dos;
    auto cp_1 = cp;
    auto dos_2 = dos;
    return call_value(fold_job(dos_2, std::tuple{Array<Text>{}, cp_1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Cp>>(std::tuple<std::tuple<Array<Text>, Cp>, lower::Do>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, Cp>, lower::Do> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [acc, c] = p0;
                auto d = p1;
                call_then(start_rebound(c, d), [=](Cp rebound_44002) {
                return ({
                    auto c2 = rebound_44002;
                    auto line = ({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        if (prism_rtl::is<lower::Do::DoLet>(d)) {
                            auto&& p_ = prism_rtl::as<lower::Do::DoLet>(d).a0;
                            auto&& x = prism_rtl::as<lower::Do::DoLet>(d).a1;
                            _v.set(cpp_let(c, c2, p_, x));
                            goto _done;
                        }
                        {
                            _v.set(cpp_statement(c2, d));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{prelude::push(acc, line), c2}));
                });
            });
            });
        }));
    }))), [=](std::tuple<Array<Text>, Cp> fold_43944) {
        return ({
            auto [lines, last] = fold_43944;
            (prism_rtl::finished(std::tuple{lexer::join(lines, Text("\n")), last}));
        });
    });
}


/// `Start CppStatementsCp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Cp>> start_cpp_statements_cp(Cp cp, Array<lower::Do> dos) {
    return std::make_shared<CppStatementsCp>(cp, dos);
}


/// Unvexed: fn Text -> Text
Text unvexed(const Text& t) {
    auto head = or_(index(split(t, Text("(")), Nat(0u)), Text(""));
    auto type_like = lexer::contains(head, Text(":")) || lexer::contains(Text("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), take_text(head, Nat(1u)));
    auto vexing = (((drop_text(t, lexer::dec(len_text(t))) == Text(")")) && (!lexer::contains(head, Text(" ")))) && (head != Text(""))) && type_like;
    return vexing ? prism_rtl::cat("(", t, ")") : t;
}


/// Rebound: unbounded fn Cp, Do -> Cp
Cp rebound(const Cp& cp, const lower::Do& d) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Cp> _v;
        if (prism_rtl::is<lower::Do::DoLetElse>(d)) {
            auto&& p_ = prism_rtl::as<lower::Do::DoLetElse>(d).a0;
            _v.set(unbind(cp, pat_names(p_)));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoLet>(d) && prism_rtl::is<lower::Pa::PaTuple>(prism_rtl::as<lower::Do::DoLet>(d).a0)) {
            auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(prism_rtl::as<lower::Do::DoLet>(d).a0).a0;
            _v.set(unbind(cp, pat_names(lower::Pa(lower::Pa::PaTuple{ps}))));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoLet>(d) && prism_rtl::is<lower::Pa::PaCtor>(prism_rtl::as<lower::Do::DoLet>(d).a0)) {
            auto&& c = prism_rtl::as<lower::Pa::PaCtor>(prism_rtl::as<lower::Do::DoLet>(d).a0).a0;
            auto&& ps = prism_rtl::as<lower::Pa::PaCtor>(prism_rtl::as<lower::Do::DoLet>(d).a0).a1;
            _v.set(unbind(cp, pat_names(lower::Pa(lower::Pa::PaCtor{c, ps}))));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoLet>(d) && prism_rtl::is<lower::Pa::PaRecord>(prism_rtl::as<lower::Do::DoLet>(d).a0)) {
            auto&& c = prism_rtl::as<lower::Pa::PaRecord>(prism_rtl::as<lower::Do::DoLet>(d).a0).a0;
            auto&& fs = prism_rtl::as<lower::Pa::PaRecord>(prism_rtl::as<lower::Do::DoLet>(d).a0).a1;
            auto&& r = prism_rtl::as<lower::Pa::PaRecord>(prism_rtl::as<lower::Do::DoLet>(d).a0).a2;
            _v.set(unbind(cp, pat_names(lower::Pa(lower::Pa::PaRecord{c, fs, r}))));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoLet>(d)) {
            auto&& p_ = prism_rtl::as<lower::Do::DoLet>(d).a0;
            auto&& x = prism_rtl::as<lower::Do::DoLet>(d).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Cp> _v;
                auto&& _m = let_name(p_);
                if (prism_rtl::is_some(_m)) {
                    auto&& n = prism_rtl::some_of(_m);
                    _v.set(({
                        auto pointing_ = is_pointer_let(cp, p_, x) ? pointing(cp, n) : known_value(cp, p_, n);
                        cpp_mentions(cpp_expr(cp, x), var_name(cp, n))
                        ? ({
                        auto fresh = prism_rtl::cat(var_name(cp, n), "_", inc(len(keys(cp.renames))));
                        ({
                        Cp this_ = pointing_;
                        this_.renames = insert(this_.renames, n, fresh);
                        this_;
                    });
                    })
                        : pointing_;
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(cp);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(cp);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Cp> Rebound::cycle() const {
    const auto& cp = this->cp;
    const auto& d = this->d;
    return ({
        prism_rtl::is<lower::Do::DoLetElse>(d) ? ({
        auto&& p_ = prism_rtl::as<lower::Do::DoLetElse>(d).a0;
        ({
        auto cp_1 = cp;
        auto p__2 = p_;
        call_then(start_pat_names(p__2), [=](Array<Text> pat_names_44810) { return prism_rtl::finished(unbind(cp_1, pat_names_44810)); });
    });
    })
        : prism_rtl::is<lower::Do::DoLet>(d) && prism_rtl::is<lower::Pa::PaTuple>(prism_rtl::as<lower::Do::DoLet>(d).a0) ? ({
        auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(prism_rtl::as<lower::Do::DoLet>(d).a0).a0;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        call_then(start_pat_names(lower::Pa(lower::Pa::PaTuple{ps_2})), [=](Array<Text> pat_names_44866) { return prism_rtl::finished(unbind(cp_1, pat_names_44866)); });
    });
    })
        : prism_rtl::is<lower::Do::DoLet>(d) && prism_rtl::is<lower::Pa::PaCtor>(prism_rtl::as<lower::Do::DoLet>(d).a0) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaCtor>(prism_rtl::as<lower::Do::DoLet>(d).a0).a0;
        auto&& ps = prism_rtl::as<lower::Pa::PaCtor>(prism_rtl::as<lower::Do::DoLet>(d).a0).a1;
        ({
        auto c_1 = c;
        auto cp_2 = cp;
        auto ps_3 = ps;
        call_then(start_pat_names(lower::Pa(lower::Pa::PaCtor{c_1, ps_3})), [=](Array<Text> pat_names_44935) { return prism_rtl::finished(unbind(cp_2, pat_names_44935)); });
    });
    })
        : prism_rtl::is<lower::Do::DoLet>(d) && prism_rtl::is<lower::Pa::PaRecord>(prism_rtl::as<lower::Do::DoLet>(d).a0) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaRecord>(prism_rtl::as<lower::Do::DoLet>(d).a0).a0;
        auto&& fs = prism_rtl::as<lower::Pa::PaRecord>(prism_rtl::as<lower::Do::DoLet>(d).a0).a1;
        auto&& r = prism_rtl::as<lower::Pa::PaRecord>(prism_rtl::as<lower::Do::DoLet>(d).a0).a2;
        ({
        auto c_1 = c;
        auto cp_2 = cp;
        auto fs_3 = fs;
        auto r_4 = r;
        call_then(start_pat_names(lower::Pa(lower::Pa::PaRecord{c_1, fs_3, r_4})), [=](Array<Text> pat_names_45011) { return prism_rtl::finished(unbind(cp_2, pat_names_45011)); });
    });
    })
        : prism_rtl::is<lower::Do::DoLet>(d) ? ({
        auto&& p_ = prism_rtl::as<lower::Do::DoLet>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoLet>(d).a1;
        ({
        auto&& _m = let_name(p_);
        prism_rtl::is_some(_m) ? ({
        auto&& n = prism_rtl::some_of(_m);
        ({
        auto pointing_ = is_pointer_let(cp, p_, x) ? pointing(cp, n) : known_value(cp, p_, n);
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_45210) {
        return cpp_mentions(cpp_expr_45210, var_name(cp_1, n))
            ? ({
            auto fresh = prism_rtl::cat(var_name(cp_1, n), "_", inc(len(keys(cp_1.renames))));
            (prism_rtl::finished(({
            Cp this_ = pointing_;
            this_.renames = insert(this_.renames, n, fresh);
            this_;
        })));
        })
            : prism_rtl::finished(pointing_);
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(cp)
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(cp);
    });
}


/// `Start Rebound, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Cp> start_rebound(Cp cp, lower::Do d) {
    return std::make_shared<Rebound>(cp, d);
}


/// PatNames: unbounded fn Pa -> [Text]
Array<Text> pat_names(const lower::Pa& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        if (prism_rtl::is<lower::Pa::PaBind>(p_)) {
            auto&& n = prism_rtl::as<lower::Pa::PaBind>(p_).a0;
            _v.set(Array(std::vector{n}));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaMut>(p_)) {
            auto&& n = prism_rtl::as<lower::Pa::PaMut>(p_).a0;
            _v.set(Array(std::vector{n}));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaTyped>(p_)) {
            auto&& q = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
            _v.set(pat_names(q));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaCtor>(p_)) {
            auto&& ps = prism_rtl::as<lower::Pa::PaCtor>(p_).a1;
            _v.set(concat2(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
                return entered(once_job([=]() {
                    return ({
                        auto q = p0;
                        (prism_rtl::more(prism_rtl::rc(PatNames(q))));
                    });
                }));
            }))))));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaRecord>(p_)) {
            auto&& fs = prism_rtl::as<lower::Pa::PaRecord>(p_).a1;
            _v.set(concat2(run_to_end(each_job(fs, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, lower::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Pa> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto&& _q = p0;
                        auto&& q = std::get<1>(_q);
                        (prism_rtl::more(prism_rtl::rc(PatNames(q))));
                    });
                }));
            }))))));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaTuple>(p_)) {
            auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
            _v.set(concat2(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
                return entered(once_job([=]() {
                    return ({
                        auto q = p0;
                        (prism_rtl::more(prism_rtl::rc(PatNames(q))));
                    });
                }));
            }))))));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaSlice>(p_)) {
            auto&& ps = prism_rtl::as<lower::Pa::PaSlice>(p_).a0;
            _v.set(concat2(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
                return entered(once_job([=]() {
                    return ({
                        auto q = p0;
                        (prism_rtl::more(prism_rtl::rc(PatNames(q))));
                    });
                }));
            }))))));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaRest>(p_)) {
            auto&& n = prism_rtl::as<lower::Pa::PaRest>(p_).a0;
            _v.set(n == Text("") ? Array<Text>{} : Array(std::vector{n}));
            goto _done;
        }
        {
            _v.set(Array<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Text>> PatNames::cycle() const {
    const auto& p_ = this->p_;
    return ({
        prism_rtl::is<lower::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(p_).a0;
        prism_rtl::finished(Array(std::vector{n}));
    })
        : prism_rtl::is<lower::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaMut>(p_).a0;
        prism_rtl::finished(Array(std::vector{n}));
    })
        : prism_rtl::is<lower::Pa::PaTyped>(p_) ? ({
        auto&& q = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
        prism_rtl::more(prism_rtl::rc(PatNames(q)));
    })
        : prism_rtl::is<lower::Pa::PaCtor>(p_) ? ({
        auto&& ps = prism_rtl::as<lower::Pa::PaCtor>(p_).a1;
        ({
        auto ps_1 = ps;
        call_value(each_job(ps_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(PatNames(q))));
            });
        }));
    }))), [=](Array<Array<Text>> each_45671) { return prism_rtl::finished(concat2(each_45671)); });
    });
    })
        : prism_rtl::is<lower::Pa::PaRecord>(p_) ? ({
        auto&& fs = prism_rtl::as<lower::Pa::PaRecord>(p_).a1;
        ({
        auto fs_1 = fs;
        call_value(each_job(fs_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, lower::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Pa> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _q = p0;
                auto&& q = std::get<1>(_q);
                (prism_rtl::more(prism_rtl::rc(PatNames(q))));
            });
        }));
    }))), [=](Array<Array<Text>> each_45739) { return prism_rtl::finished(concat2(each_45739)); });
    });
    })
        : prism_rtl::is<lower::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
        ({
        auto ps_1 = ps;
        call_value(each_job(ps_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(PatNames(q))));
            });
        }));
    }))), [=](Array<Array<Text>> each_45802) { return prism_rtl::finished(concat2(each_45802)); });
    });
    })
        : prism_rtl::is<lower::Pa::PaSlice>(p_) ? ({
        auto&& ps = prism_rtl::as<lower::Pa::PaSlice>(p_).a0;
        ({
        auto ps_1 = ps;
        call_value(each_job(ps_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(PatNames(q))));
            });
        }));
    }))), [=](Array<Array<Text>> each_45853) { return prism_rtl::finished(concat2(each_45853)); });
    });
    })
        : prism_rtl::is<lower::Pa::PaRest>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaRest>(p_).a0;
        n == Text("")
        ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::finished(Array(std::vector{n}));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start PatNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_pat_names(lower::Pa p_) {
    return std::make_shared<PatNames>(p_);
}


/// ArmNames: unbounded fn XArm -> [Text]
Array<Text> arm_names(const lower::XArm& a) {
    return append(pat_names(a.pat), concat2(run_to_end(each_job(a.conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(lower::Cc)>>(prism_rtl::rc([=](lower::Cc p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::more(prism_rtl::rc(CondNames(c))));
            });
        }));
    }))))));
}


prism_rtl::Turn<Array<Text>> ArmNames::cycle() const {
    const auto& a = this->a;
    auto a_1 = a;
    return call_then(start_pat_names(a_1.pat), [=](Array<Text> pat_names_46005) {
        return call_value(each_job(a_1.conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(lower::Cc)>>(prism_rtl::rc([=](lower::Cc p0) {
            return entered(once_job([=]() {
                return ({
                    auto c = p0;
                    (prism_rtl::more(prism_rtl::rc(CondNames(c))));
                });
            }));
        }))), [=](Array<Array<Text>> each_46032) { return prism_rtl::finished(append(pat_names_46005, concat2(each_46032))); });
    });
}


/// `Start ArmNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_arm_names(lower::XArm a) {
    return std::make_shared<ArmNames>(a);
}


/// CondNames: unbounded fn Cc -> [Text]
Array<Text> cond_names(const lower::Cc& cc0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        if (prism_rtl::is<lower::Cc::CcLet>(cc0)) {
            auto&& q = prism_rtl::as<lower::Cc::CcLet>(cc0).a0;
            _v.set(pat_names(q));
            goto _done;
        }
        if (prism_rtl::is<lower::Cc::CcIf>(cc0)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Text>> CondNames::cycle() const {
    const auto& cc0 = this->cc0;
    return ({
        prism_rtl::is<lower::Cc::CcLet>(cc0) ? ({
        auto&& q = prism_rtl::as<lower::Cc::CcLet>(cc0).a0;
        prism_rtl::more(prism_rtl::rc(PatNames(q)));
    })
        : prism_rtl::is<lower::Cc::CcIf>(cc0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cond_names(lower::Cc cc0) {
    return std::make_shared<CondNames>(cc0);
}


/// Unbind: fn Cp, [Text] -> Cp
Cp unbind(const Cp& cp, const Array<Text>& names) {
    Cp this_ = cp;
    this_.renames = fold(names, this_.renames, [&](const Map<Text, Text>& m, const Text& n) { return prelude::remove(m, n); });
    this_.pointers = fold(names, this_.pointers, [&](const Map<Text, bool>& m, const Text& n) { return prelude::remove(m, n); });
    return this_;
}


/// Pointing: fn Cp, Text -> Cp
Cp pointing(const Cp& cp, const Text& n) {
    Cp this_ = cp;
    this_.pointers = insert(this_.pointers, n, true);
    return this_;
}


/// KnownValue: fn Cp, Pa, Text -> Cp
Cp known_value(const Cp& cp, const lower::Pa& p_, const Text& n) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Cp> _v;
        if (prism_rtl::is<lower::Pa::PaTyped>(p_)) {
            _v.set(({
                Cp this_ = cp;
                this_.pointers = insert(this_.pointers, n, false);
                this_;
            }));
            goto _done;
        }
        {
            _v.set(cp);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// IsPointerLet: fn Cp, Pa, Ex -> Bool
bool is_pointer_let(const Cp& cp, const lower::Pa& p_, const lower::Ex& x) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lower::Pa::PaTyped>(p_)) {
            auto&& t = prism_rtl::as<lower::Pa::PaTyped>(p_).a1;
            _v.set(is_pointer_ty(cp, t));
            goto _done;
        }
        {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                if (prism_rtl::is<lower::Ex::XCall>(x)) {
                    auto&& m47150_0_0 = prism_rtl::as<lower::Ex::XCall>(x).a0;
                    if (m47150_0_0 == Text("prism_rtl::Host::new")) {
                        _v.set(true);
                        goto _done;
                    }
                }
                if (prism_rtl::is<lower::Ex::XCall>(x)) {
                    auto&& m47150_1_0 = prism_rtl::as<lower::Ex::XCall>(x).a0;
                    auto&& m47150_1_1 = prism_rtl::as<lower::Ex::XCall>(x).a1;
                    if (m47150_1_0 == Text("Rc::new")) {
                        if (m47150_1_1.size() == 1u) {
                            {
                                auto&& _c2 = index(m47150_1_1, Nat(0u));
                                if (prism_rtl::is_some(_c2) && prism_rtl::is<lower::Ex::XCall>(prism_rtl::some_of(_c2))) {
                                    auto&& m47150_1_1_0_0 = prism_rtl::as<lower::Ex::XCall>(prism_rtl::some_of(_c2)).a0;
                                    if (m47150_1_1_0_0 == Text("Port::new")) {
                                        _v.set(true);
                                        goto _done;
                                    }
                                }
                            }
                        }
                    }
                }
                {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        auto&& _m = pointer(cp, x);
                        if (prism_rtl::is_some(_m)) {
                            auto&& b = prism_rtl::some_of(_m);
                            _v.set(b);
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(false);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// Inc: fn Nat -> Nat
Nat inc(const Nat& n) {
    return n + Nat(1u);
}


/// ?LetName: fn Pa -> ?Text
std::optional<Text> let_name(const lower::Pa& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        if (prism_rtl::is<lower::Pa::PaBind>(p_)) {
            auto&& n = prism_rtl::as<lower::Pa::PaBind>(p_).a0;
            _v.set(std::optional(n));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaMut>(p_)) {
            auto&& n = prism_rtl::as<lower::Pa::PaMut>(p_).a0;
            _v.set(std::optional(n));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaTyped>(p_)) {
            auto&& q = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
            _v.set(let_name(q));
            goto _done;
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// VarName: fn Cp, Text -> Text
Text var_name(const Cp& cp, const Text& n) {
    return or_(prelude::get(cp.renames, n), cpp_id(n));
}


/// CppMentions: fn Text, Text -> Bool
bool cpp_mentions(const Text& t, const Text& n) {
    auto parts = split(t, n);
    auto k = len(parts);
    return fold(check_errors::range0(lexer::dec(k)), false, [&](const bool& f, const Nat& i) { return f || ((!cpp_ends_ident(or_(index(parts, i), Text("")))) && (!cpp_starts_ident(or_(index(parts, i + Nat(1u)), Text(""))))); });
}


/// CppEndsIdent: fn Text -> Bool
bool cpp_ends_ident(const Text& t) {
    auto c = drop_text(t, lexer::dec(len_text(t)));
    return (cpp_ident_char(c) || (c == Text("."))) || (c == Text(">"));
}


/// CppStartsIdent: fn Text -> Bool
bool cpp_starts_ident(const Text& t) {
    return cpp_ident_char(take_text(t, Nat(1u)));
}


/// CppIdentChar: fn Text -> Bool
bool cpp_ident_char(const Text& c) {
    return (c != Text("")) && lexer::contains(Text("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"), c);
}


/// CppStatement: unbounded fn Cp, Do -> Text
Text cpp_statement(const Cp& cp, const lower::Do& d) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Do::DoLet>(d)) {
            auto&& p_ = prism_rtl::as<lower::Do::DoLet>(d).a0;
            auto&& x = prism_rtl::as<lower::Do::DoLet>(d).a1;
            _v.set(cpp_let(cp, cp, p_, x));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoLetElse>(d)) {
            auto&& p_ = prism_rtl::as<lower::Do::DoLetElse>(d).a0;
            auto&& x = prism_rtl::as<lower::Do::DoLetElse>(d).a1;
            auto&& e = prism_rtl::as<lower::Do::DoLetElse>(d).a2;
            _v.set(({
                auto v_ = prism_rtl::cat("_", or_(first_binder(p_), Text("m")));
                (prism_rtl::cat("auto&& ", v_, " = ", cpp_expr(cp, x), ";\nif (!(", conds(pat_conds(cp, p_, v_)), ")) { ", cpp_expr(cp, e), "; }\n", lexer::join(pat_binds(cp, p_, v_), Text("\n"))));
            }));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoAssign>(d)) {
            auto&& p_ = prism_rtl::as<lower::Do::DoAssign>(d).a0;
            auto&& x = prism_rtl::as<lower::Do::DoAssign>(d).a1;
            _v.set(prism_rtl::cat(cpp_expr(cp, p_), " = ", cpp_expr(cp, x), ";"));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoWhile>(d)) {
            auto&& c = prism_rtl::as<lower::Do::DoWhile>(d).a0;
            auto&& body = prism_rtl::as<lower::Do::DoWhile>(d).a1;
            _v.set(cpp_templates::block(prism_rtl::cat("while (", cpp_expr(cp, c), ")"), cpp_statements(cp, body)));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoWhileLet>(d)) {
            auto&& p_ = prism_rtl::as<lower::Do::DoWhileLet>(d).a0;
            auto&& x = prism_rtl::as<lower::Do::DoWhileLet>(d).a1;
            auto&& body = prism_rtl::as<lower::Do::DoWhileLet>(d).a2;
            _v.set(({
                auto v_ = Text("_m");
                auto head = prism_rtl::cat("auto&& _m = ", cpp_expr(cp, x), ";\nif (!(", conds(pat_conds(cp, p_, v_)), ")) break;");
                (cpp_templates::block(Text("while (true)"), lexer::join(append(append(Array(std::vector{head}), pat_binds(cp, p_, v_)), Array(std::vector{cpp_statements(cp, body)})), Text("\n"))));
            }));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoFor>(d)) {
            auto&& p_ = prism_rtl::as<lower::Do::DoFor>(d).a0;
            auto&& x = prism_rtl::as<lower::Do::DoFor>(d).a1;
            auto&& body = prism_rtl::as<lower::Do::DoFor>(d).a2;
            _v.set(cpp_for(cp, p_, x, body));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoExpr>(d) && prism_rtl::is<lower::Ex::XBreak>(prism_rtl::as<lower::Do::DoExpr>(d).a0)) {
            auto&& l = prism_rtl::as<lower::Ex::XBreak>(prism_rtl::as<lower::Do::DoExpr>(d).a0).a0;
            auto&& y = prism_rtl::as<lower::Ex::XBreak>(prism_rtl::as<lower::Do::DoExpr>(d).a0).a1;
            _v.set(cpp_break(cp, l, y));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoExpr>(d) && prism_rtl::is<lower::Ex::XBreakLoop>(prism_rtl::as<lower::Do::DoExpr>(d).a0)) {
            _v.set(Text("break;"));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoExpr>(d)) {
            auto&& x = prism_rtl::as<lower::Do::DoExpr>(d).a0;
            _v.set(prism_rtl::cat(cpp_expr(cp, x), ";"));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoIf>(d)) {
            auto&& c = prism_rtl::as<lower::Do::DoIf>(d).a0;
            auto&& t = prism_rtl::as<lower::Do::DoIf>(d).a1;
            auto&& e = prism_rtl::as<lower::Do::DoIf>(d).a2;
            _v.set(prism_rtl::cat(cpp_templates::block(prism_rtl::cat("if (", cpp_expr(cp, c), ")"), cpp_statements(cp, t)), cpp_else(cp, e)));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoIfLet>(d)) {
            auto&& p_ = prism_rtl::as<lower::Do::DoIfLet>(d).a0;
            auto&& x = prism_rtl::as<lower::Do::DoIfLet>(d).a1;
            auto&& t = prism_rtl::as<lower::Do::DoIfLet>(d).a2;
            auto&& e = prism_rtl::as<lower::Do::DoIfLet>(d).a3;
            _v.set(cpp_if_let(cp, p_, x, t, e));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoMatch>(d)) {
            auto&& x = prism_rtl::as<lower::Do::DoMatch>(d).a0;
            auto&& cases = prism_rtl::as<lower::Do::DoMatch>(d).a1;
            _v.set(cpp_do_match(cp, x, cases));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoReturn>(d)) {
            auto&& x = prism_rtl::as<lower::Do::DoReturn>(d).a0;
            _v.set(prism_rtl::cat("return ", cpp_expr(cp, x), ";"));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoScope>(d)) {
            auto&& body = prism_rtl::as<lower::Do::DoScope>(d).a0;
            _v.set(prism_rtl::cat("{ ", cpp_inline(cp, body), " }"));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoLine>(d)) {
            auto&& body = prism_rtl::as<lower::Do::DoLine>(d).a0;
            _v.set(cpp_inline(cp, body));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoNote>(d)) {
            auto&& t = prism_rtl::as<lower::Do::DoNote>(d).a0;
            _v.set(prism_rtl::cat("// ", t));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> CppStatement::cycle() const {
    const auto& cp = this->cp;
    const auto& d = this->d;
    return ({
        prism_rtl::is<lower::Do::DoLet>(d) ? ({
        auto&& p_ = prism_rtl::as<lower::Do::DoLet>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoLet>(d).a1;
        prism_rtl::more(prism_rtl::rc(CppLet(cp, cp, p_, x)));
    })
        : prism_rtl::is<lower::Do::DoLetElse>(d) ? ({
        auto&& p_ = prism_rtl::as<lower::Do::DoLetElse>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoLetElse>(d).a1;
        auto&& e = prism_rtl::as<lower::Do::DoLetElse>(d).a2;
        ({
        auto cp_1 = cp;
        auto e_2 = e;
        auto p__3 = p_;
        auto x_4 = x;
        call_then(start_first_binder(p__3), [=](std::optional<Text> first_binder_48456) {
        return ({
            auto v_ = prism_rtl::cat("_", or_(first_binder_48456, Text("m")));
            call_then(start_cpp_expr(cp_1, x_4), [=](Text cpp_expr_48502) { return call_then(start_pat_conds(cp_1, p__3, v_), [=](Array<Text> pat_conds_48533) { return call_then(start_cpp_expr(cp_1, e_2), [=](Text cpp_expr_48559) { return call_then(start_pat_binds(cp_1, p__3, v_), [=](Array<Text> pat_binds_48586) { return prism_rtl::finished(prism_rtl::cat("auto&& ", v_, " = ", cpp_expr_48502, ";\nif (!(", conds(pat_conds_48533), ")) { ", cpp_expr_48559, "; }\n", lexer::join(pat_binds_48586, Text("\n")))); }); }); }); });
        });
    });
    });
    })
        : prism_rtl::is<lower::Do::DoAssign>(d) ? ({
        auto&& p_ = prism_rtl::as<lower::Do::DoAssign>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoAssign>(d).a1;
        ({
        auto cp_1 = cp;
        auto p__2 = p_;
        auto x_3 = x;
        call_then(start_cpp_expr(cp_1, p__2), [=](Text cpp_expr_48634) { return call_then(start_cpp_expr(cp_1, x_3), [=](Text cpp_expr_48652) { return prism_rtl::finished(prism_rtl::cat(cpp_expr_48634, " = ", cpp_expr_48652, ";")); }); });
    });
    })
        : prism_rtl::is<lower::Do::DoWhile>(d) ? ({
        auto&& c = prism_rtl::as<lower::Do::DoWhile>(d).a0;
        auto&& body = prism_rtl::as<lower::Do::DoWhile>(d).a1;
        ({
        auto body_1 = body;
        auto c_2 = c;
        auto cp_3 = cp;
        call_then(start_cpp_expr(cp_3, c_2), [=](Text cpp_expr_48705) { return call_then(start_cpp_statements(cp_3, body_1), [=](Text cpp_statements_48724) { return prism_rtl::finished(cpp_templates::block(prism_rtl::cat("while (", cpp_expr_48705, ")"), cpp_statements_48724)); }); });
    });
    })
        : prism_rtl::is<lower::Do::DoWhileLet>(d) ? ({
        auto&& p_ = prism_rtl::as<lower::Do::DoWhileLet>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoWhileLet>(d).a1;
        auto&& body = prism_rtl::as<lower::Do::DoWhileLet>(d).a2;
        ({
        auto v_ = Text("_m");
        auto body_1 = body;
        auto cp_2 = cp;
        auto p__3 = p_;
        auto x_4 = x;
        call_then(start_cpp_expr(cp_2, x_4), [=](Text cpp_expr_48829) {
        return call_then(start_pat_conds(cp_2, p__3, v_), [=](Array<Text> pat_conds_48860) {
            return ({
                auto head = prism_rtl::cat("auto&& _m = ", cpp_expr_48829, ";\nif (!(", conds(pat_conds_48860), ")) break;");
                call_then(start_pat_binds(cp_2, p__3, v_), [=](Array<Text> pat_binds_48953) { return call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_48977) { return prism_rtl::finished(cpp_templates::block(Text("while (true)"), lexer::join(append(append(Array(std::vector{head}), pat_binds_48953), Array(std::vector{cpp_statements_48977})), Text("\n")))); }); });
            });
        });
    });
    });
    })
        : prism_rtl::is<lower::Do::DoFor>(d) ? ({
        auto&& p_ = prism_rtl::as<lower::Do::DoFor>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoFor>(d).a1;
        auto&& body = prism_rtl::as<lower::Do::DoFor>(d).a2;
        prism_rtl::more(prism_rtl::rc(CppFor(cp, p_, x, body)));
    })
        : prism_rtl::is<lower::Do::DoExpr>(d) && prism_rtl::is<lower::Ex::XBreak>(prism_rtl::as<lower::Do::DoExpr>(d).a0) ? ({
        auto&& l = prism_rtl::as<lower::Ex::XBreak>(prism_rtl::as<lower::Do::DoExpr>(d).a0).a0;
        auto&& y = prism_rtl::as<lower::Ex::XBreak>(prism_rtl::as<lower::Do::DoExpr>(d).a0).a1;
        prism_rtl::more(prism_rtl::rc(CppBreak(cp, l, y)));
    })
        : prism_rtl::is<lower::Do::DoExpr>(d) && prism_rtl::is<lower::Ex::XBreakLoop>(prism_rtl::as<lower::Do::DoExpr>(d).a0) ? prism_rtl::finished(Text("break;"))
        : prism_rtl::is<lower::Do::DoExpr>(d) ? ({
        auto&& x = prism_rtl::as<lower::Do::DoExpr>(d).a0;
        ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_49147) { return prism_rtl::finished(prism_rtl::cat(cpp_expr_49147, ";")); });
    });
    })
        : prism_rtl::is<lower::Do::DoIf>(d) ? ({
        auto&& c = prism_rtl::as<lower::Do::DoIf>(d).a0;
        auto&& t = prism_rtl::as<lower::Do::DoIf>(d).a1;
        auto&& e = prism_rtl::as<lower::Do::DoIf>(d).a2;
        ({
        auto c_1 = c;
        auto cp_2 = cp;
        auto e_3 = e;
        auto t_4 = t;
        call_then(start_cpp_expr(cp_2, c_1), [=](Text cpp_expr_49196) { return call_then(start_cpp_statements(cp_2, t_4), [=](Text cpp_statements_49215) { return call_then(start_cpp_else(cp_2, e_3), [=](Text cpp_else_49237) { return prism_rtl::finished(prism_rtl::cat(cpp_templates::block(prism_rtl::cat("if (", cpp_expr_49196, ")"), cpp_statements_49215), cpp_else_49237)); }); }); });
    });
    })
        : prism_rtl::is<lower::Do::DoIfLet>(d) ? ({
        auto&& p_ = prism_rtl::as<lower::Do::DoIfLet>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoIfLet>(d).a1;
        auto&& t = prism_rtl::as<lower::Do::DoIfLet>(d).a2;
        auto&& e = prism_rtl::as<lower::Do::DoIfLet>(d).a3;
        prism_rtl::more(prism_rtl::rc(CppIfLet(cp, p_, x, t, e)));
    })
        : prism_rtl::is<lower::Do::DoMatch>(d) ? ({
        auto&& x = prism_rtl::as<lower::Do::DoMatch>(d).a0;
        auto&& cases = prism_rtl::as<lower::Do::DoMatch>(d).a1;
        prism_rtl::more(prism_rtl::rc(CppDoMatch(cp, x, cases)));
    })
        : prism_rtl::is<lower::Do::DoReturn>(d) ? ({
        auto&& x = prism_rtl::as<lower::Do::DoReturn>(d).a0;
        ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_49372) { return prism_rtl::finished(prism_rtl::cat("return ", cpp_expr_49372, ";")); });
    });
    })
        : prism_rtl::is<lower::Do::DoScope>(d) ? ({
        auto&& body = prism_rtl::as<lower::Do::DoScope>(d).a0;
        ({
        auto body_1 = body;
        auto cp_2 = cp;
        call_then(start_cpp_inline(cp_2, body_1), [=](Text cpp_inline_49412) { return prism_rtl::finished(prism_rtl::cat("{ ", cpp_inline_49412, " }")); });
    });
    })
        : prism_rtl::is<lower::Do::DoLine>(d) ? ({
        auto&& body = prism_rtl::as<lower::Do::DoLine>(d).a0;
        prism_rtl::more(prism_rtl::rc(CppInline(cp, body)));
    })
        : prism_rtl::is<lower::Do::DoNote>(d) ? ({
        auto&& t = prism_rtl::as<lower::Do::DoNote>(d).a0;
        prism_rtl::finished(prism_rtl::cat("// ", t));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CppStatement, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_statement(Cp cp, lower::Do d) {
    return std::make_shared<CppStatement>(cp, d);
}


/// CppInline: unbounded fn Cp, [Do] -> Text
Text cpp_inline(const Cp& cp, const Array<lower::Do>& dos) {
    return lexer::join(run_to_end(each_job(dos, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Do)>>(prism_rtl::rc([=](lower::Do p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(CppStatement(cp_1_2, d))));
            });
        }));
        });
    })));
    }))), Text(" "));
}


prism_rtl::Turn<Text> CppInline::cycle() const {
    const auto& cp = this->cp;
    const auto& dos = this->dos;
    auto cp_1 = cp;
    auto dos_2 = dos;
    return call_value(each_job(dos_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Do)>>(prism_rtl::rc([=](lower::Do p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(CppStatement(cp_1_3_3, d))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_49566) { return prism_rtl::finished(lexer::join(each_49566, Text(" "))); });
}


/// `Start CppInline, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_inline(Cp cp, Array<lower::Do> dos) {
    return std::make_shared<CppInline>(cp, dos);
}


/// CppElse: unbounded fn Cp, [Do] -> Text
Text cpp_else(const Cp& cp, const Array<lower::Do>& xs1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& c0_1 = xs1;
            if (c0_1.size() == 0u) {
                _v.set(Text(""));
                goto _done;
            }
        }
        {
            auto&& c1_1 = xs1;
            if (c1_1.size() == 1u) {
                {
                    auto&& _c1 = index(c1_1, Nat(0u));
                    if (prism_rtl::is_some(_c1) && prism_rtl::is<lower::Do::DoIf>(prism_rtl::some_of(_c1))) {
                        auto&& c = prism_rtl::as<lower::Do::DoIf>(prism_rtl::some_of(_c1)).a0;
                        auto&& t = prism_rtl::as<lower::Do::DoIf>(prism_rtl::some_of(_c1)).a1;
                        auto&& e = prism_rtl::as<lower::Do::DoIf>(prism_rtl::some_of(_c1)).a2;
                        _v.set(prism_rtl::cat(" else ", cpp_statement(cp, lower::Do(lower::Do::DoIf{c, t, e}))));
                        goto _done;
                    }
                }
            }
        }
        {
            auto&& c2_1 = xs1;
            if (c2_1.size() == 1u) {
                {
                    auto&& _c1 = index(c2_1, Nat(0u));
                    if (prism_rtl::is_some(_c1) && prism_rtl::is<lower::Do::DoIfLet>(prism_rtl::some_of(_c1))) {
                        auto&& p_ = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a0;
                        auto&& x = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a1;
                        auto&& t = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a2;
                        auto&& e = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a3;
                        _v.set(prism_rtl::cat(" else ", cpp_statement(cp, lower::Do(lower::Do::DoIfLet{p_, x, t, e}))));
                        goto _done;
                    }
                }
            }
        }
        {
            auto&& body = xs1;
            _v.set(prism_rtl::cat(" else ", cpp_templates::block(Text(""), cpp_statements(cp, body))));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> CppElse::cycle() const {
    const auto& cp = this->cp;
    const auto& xs1 = this->xs1;
    return ({
        ({
        auto&& j0_1 = xs1;
        (j0_1.size() == 0u);
    }) ? ({
        auto&& j0_1 = xs1;
        prism_rtl::finished(Text(""));
    })
        : ({
        auto&& j1_1 = xs1;
        (j1_1.size() == 1u) && ({
        auto&& _c1 = index(j1_1, Nat(0u));
        prism_rtl::is_some(_c1) && prism_rtl::is<lower::Do::DoIf>(prism_rtl::some_of(_c1));
    });
    }) ? ({
        auto&& j1_1 = xs1;
        auto&& _c1 = index(j1_1, Nat(0u));
        auto&& c = prism_rtl::as<lower::Do::DoIf>(prism_rtl::some_of(_c1)).a0;
        auto&& t = prism_rtl::as<lower::Do::DoIf>(prism_rtl::some_of(_c1)).a1;
        auto&& e = prism_rtl::as<lower::Do::DoIf>(prism_rtl::some_of(_c1)).a2;
        ({
        auto cp_1 = cp;
        call_then(start_cpp_statement(cp_1, lower::Do(lower::Do::DoIf{c, t, e})), [=](Text cpp_statement_49715) { return prism_rtl::finished(prism_rtl::cat(" else ", cpp_statement_49715)); });
    });
    })
        : ({
        auto&& j2_1 = xs1;
        (j2_1.size() == 1u) && ({
        auto&& _c1 = index(j2_1, Nat(0u));
        prism_rtl::is_some(_c1) && prism_rtl::is<lower::Do::DoIfLet>(prism_rtl::some_of(_c1));
    });
    }) ? ({
        auto&& j2_1 = xs1;
        auto&& _c1 = index(j2_1, Nat(0u));
        auto&& p_ = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a0;
        auto&& x = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a1;
        auto&& t = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a2;
        auto&& e = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a3;
        ({
        auto cp_1 = cp;
        call_then(start_cpp_statement(cp_1, lower::Do(lower::Do::DoIfLet{p_, x, t, e})), [=](Text cpp_statement_49799) { return prism_rtl::finished(prism_rtl::cat(" else ", cpp_statement_49799)); });
    });
    })
        : ({
        auto&& body = xs1;
        ({
        auto body_1 = body;
        auto cp_2 = cp;
        call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_49880) { return prism_rtl::finished(prism_rtl::cat(" else ", cpp_templates::block(Text(""), cpp_statements_49880))); });
    });
    });
    });
}


/// `Start CppElse, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_else(Cp cp, Array<lower::Do> xs1) {
    return std::make_shared<CppElse>(cp, xs1);
}


/// CppLet: unbounded fn Cp, Cp, Pa, Ex -> Text
Text cpp_let(const Cp& cp, const Cp& named, const lower::Pa& p_, const lower::Ex& x) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Pa::PaWild>(p_)) {
            _v.set(prism_rtl::cat("static_cast<void>(", cpp_expr(cp, x), ");"));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaBind>(p_)) {
            auto&& n = prism_rtl::as<lower::Pa::PaBind>(p_).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is<lower::Ex::XRef>(x)) {
                    _v.set(prism_rtl::cat("const auto& ", var_name(named, n), " = ", cpp_expr(cp, x), ";"));
                    goto _done;
                }
                {
                    _v.set(prism_rtl::cat("auto ", var_name(named, n), " = ", cpp_expr(cp, x), ";"));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaMut>(p_)) {
            auto&& n = prism_rtl::as<lower::Pa::PaMut>(p_).a0;
            _v.set(prism_rtl::cat("auto ", var_name(named, n), " = ", cpp_expr(cp, x), ";"));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaTyped>(p_)) {
            auto&& m50096_3_0 = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
            auto&& t = prism_rtl::as<lower::Pa::PaTyped>(p_).a1;
            if (prism_rtl::is<lower::Pa::PaBind>(m50096_3_0)) {
                auto&& n = prism_rtl::as<lower::Pa::PaBind>(m50096_3_0).a0;
                _v.set(prism_rtl::cat(cpp_type(cp, t), " ", var_name(named, n), " = ", cpp_expr(cp, x), ";"));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::Pa::PaTyped>(p_)) {
            auto&& m50096_4_0 = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
            auto&& t = prism_rtl::as<lower::Pa::PaTyped>(p_).a1;
            if (prism_rtl::is<lower::Pa::PaMut>(m50096_4_0)) {
                auto&& n = prism_rtl::as<lower::Pa::PaMut>(m50096_4_0).a0;
                _v.set(prism_rtl::cat(cpp_type(cp, t), " ", var_name(named, n), " = ", cpp_expr(cp, x), ";"));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::Pa::PaTuple>(p_)) {
            auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
            _v.set(fold(ps, true, [&](const bool& f, const lower::Pa& q) { return f && is_name(q); })
                ? prism_rtl::cat("auto [", lexer::join(each(ps, [&](const lower::Pa& q) { return pat_name(q); }), Text(", ")), "] = ", cpp_expr(cp, x), ";")
                : let_through(cp, p_, x));
            goto _done;
        }
        {
            _v.set(let_through(cp, p_, x));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> CppLet::cycle() const {
    const auto& cp = this->cp;
    const auto& named = this->named;
    const auto& p_ = this->p_;
    const auto& x = this->x;
    return ({
        prism_rtl::is<lower::Pa::PaWild>(p_) ? ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_50137) { return prism_rtl::finished(prism_rtl::cat("static_cast<void>(", cpp_expr_50137, ");")); });
    })
        : prism_rtl::is<lower::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(p_).a0;
        ({
        prism_rtl::is<lower::Ex::XRef>(x) ? ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto named_3 = named;
        auto x_4 = x;
        call_then(start_cpp_expr(cp_1, x_4), [=](Text cpp_expr_50234) { return prism_rtl::finished(prism_rtl::cat("const auto& ", var_name(named_3, n_2), " = ", cpp_expr_50234, ";")); });
    })
        : ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto named_3 = named;
        auto x_4 = x;
        call_then(start_cpp_expr(cp_1, x_4), [=](Text cpp_expr_50298) { return prism_rtl::finished(prism_rtl::cat("auto ", var_name(named_3, n_2), " = ", cpp_expr_50298, ";")); });
    });
    });
    })
        : prism_rtl::is<lower::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaMut>(p_).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto named_3 = named;
        auto x_4 = x;
        call_then(start_cpp_expr(cp_1, x_4), [=](Text cpp_expr_50356) { return prism_rtl::finished(prism_rtl::cat("auto ", var_name(named_3, n_2), " = ", cpp_expr_50356, ";")); });
    });
    })
        : prism_rtl::is<lower::Pa::PaTyped>(p_) && ({
        auto&& m50096_3_0 = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(p_).a1;
        prism_rtl::is<lower::Pa::PaBind>(m50096_3_0);
    }) ? ({
        auto&& m50096_3_0 = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(p_).a1;
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(m50096_3_0).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto named_3 = named;
        auto t_4 = t;
        auto x_5 = x;
        call_then(start_cpp_type(cp_1, t_4), [=](Text cpp_type_50402) { return call_then(start_cpp_expr(cp_1, x_5), [=](Text cpp_expr_50439) { return prism_rtl::finished(prism_rtl::cat(cpp_type_50402, " ", var_name(named_3, n_2), " = ", cpp_expr_50439, ";")); }); });
    });
    })
        : prism_rtl::is<lower::Pa::PaTyped>(p_) && ({
        auto&& m50096_4_0 = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(p_).a1;
        prism_rtl::is<lower::Pa::PaMut>(m50096_4_0);
    }) ? ({
        auto&& m50096_4_0 = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(p_).a1;
        auto&& n = prism_rtl::as<lower::Pa::PaMut>(m50096_4_0).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto named_3 = named;
        auto t_4 = t;
        auto x_5 = x;
        call_then(start_cpp_type(cp_1, t_4), [=](Text cpp_type_50484) { return call_then(start_cpp_expr(cp_1, x_5), [=](Text cpp_expr_50521) { return prism_rtl::finished(prism_rtl::cat(cpp_type_50484, " ", var_name(named_3, n_2), " = ", cpp_expr_50521, ";")); }); });
    });
    })
        : prism_rtl::is<lower::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
        fold(ps, true, [&](const bool& f, const lower::Pa& q) { return f && is_name(q); })
        ? ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto x_3 = x;
        call_then(start_cpp_expr(cp_1, x_3), [=](Text cpp_expr_50654) { return prism_rtl::finished(prism_rtl::cat("auto [", lexer::join(each(ps_2, [&](const lower::Pa& q) { return pat_name(q); }), Text(", ")), "] = ", cpp_expr_50654, ";")); });
    })
        : prism_rtl::more(prism_rtl::rc(LetThrough(cp, p_, x)));
    })
        : prism_rtl::more(prism_rtl::rc(LetThrough(cp, p_, x)));
    });
}


/// `Start CppLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_let(Cp cp, Cp named, lower::Pa p_, lower::Ex x) {
    return std::make_shared<CppLet>(cp, named, p_, x);
}


/// LetThrough: unbounded fn Cp, Pa, Ex -> Text
Text let_through(const Cp& cp, const lower::Pa& p_, const lower::Ex& x) {
    auto t_1 = prism_rtl::cat("_", or_(first_binder(p_), Text("t")));
    return prism_rtl::cat("auto&& ", t_1, " = ", cpp_expr(cp, x), ";\n", lexer::join(pat_binds(cp, p_, t_1), Text("\n")));
}


prism_rtl::Turn<Text> LetThrough::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& x = this->x;
    auto cp_1 = cp;
    auto p__2 = p_;
    auto x_3 = x;
    return call_then(start_first_binder(p__2), [=](std::optional<Text> first_binder_50913) {
        return ({
            auto t_4 = prism_rtl::cat("_", or_(first_binder_50913, Text("t")));
            call_then(start_cpp_expr(cp_1, x_3), [=](Text cpp_expr_50955) { return call_then(start_pat_binds(cp_1, p__2, t_4), [=](Array<Text> pat_binds_50979) { return prism_rtl::finished(prism_rtl::cat("auto&& ", t_4, " = ", cpp_expr_50955, ";\n", lexer::join(pat_binds_50979, Text("\n")))); }); });
        });
    });
}


/// `Start LetThrough, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_let_through(Cp cp, lower::Pa p_, lower::Ex x) {
    return std::make_shared<LetThrough>(cp, p_, x);
}


/// ?FirstBinder: unbounded fn Pa -> ?Text
std::optional<Text> first_binder(const lower::Pa& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        if (prism_rtl::is<lower::Pa::PaBind>(p_)) {
            auto&& n = prism_rtl::as<lower::Pa::PaBind>(p_).a0;
            _v.set(std::optional(n));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaMut>(p_)) {
            auto&& n = prism_rtl::as<lower::Pa::PaMut>(p_).a0;
            _v.set(std::optional(n));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaTyped>(p_)) {
            auto&& q = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
            _v.set(first_binder(q));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaCtor>(p_)) {
            auto&& ps = prism_rtl::as<lower::Pa::PaCtor>(p_).a1;
            _v.set(run_to_end(fold_job(ps, std::optional<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Text>>(std::tuple<std::optional<Text>, lower::Pa>)>>(prism_rtl::rc([=](std::tuple<std::optional<Text>, lower::Pa> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto f_opt = p0;
                        auto q = p1;
                        ({
                        prism_rtl::is_some(f_opt) ? ({
                        auto&& b = prism_rtl::some_of(f_opt);
                        prism_rtl::finished(std::optional(b));
                    })
                        : prism_rtl::is_none(f_opt) ? prism_rtl::more(prism_rtl::rc(FirstBinder(q)))
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaTuple>(p_)) {
            auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
            _v.set(run_to_end(fold_job(ps, std::optional<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Text>>(std::tuple<std::optional<Text>, lower::Pa>)>>(prism_rtl::rc([=](std::tuple<std::optional<Text>, lower::Pa> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto f_opt = p0;
                        auto q = p1;
                        ({
                        prism_rtl::is_some(f_opt) ? ({
                        auto&& b = prism_rtl::some_of(f_opt);
                        prism_rtl::finished(std::optional(b));
                    })
                        : prism_rtl::is_none(f_opt) ? prism_rtl::more(prism_rtl::rc(FirstBinder(q)))
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
            })))));
            goto _done;
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::optional<Text>> FirstBinder::cycle() const {
    const auto& p_ = this->p_;
    return ({
        prism_rtl::is<lower::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(p_).a0;
        prism_rtl::finished(std::optional(n));
    })
        : prism_rtl::is<lower::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaMut>(p_).a0;
        prism_rtl::finished(std::optional(n));
    })
        : prism_rtl::is<lower::Pa::PaTyped>(p_) ? ({
        auto&& q = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
        prism_rtl::more(prism_rtl::rc(FirstBinder(q)));
    })
        : prism_rtl::is<lower::Pa::PaCtor>(p_) ? ({
        auto&& ps = prism_rtl::as<lower::Pa::PaCtor>(p_).a1;
        fold_job(ps, std::optional<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Text>>(std::tuple<std::optional<Text>, lower::Pa>)>>(prism_rtl::rc([=](std::tuple<std::optional<Text>, lower::Pa> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto f_opt = p0;
                auto q = p1;
                ({
                prism_rtl::is_some(f_opt) ? ({
                auto&& b = prism_rtl::some_of(f_opt);
                prism_rtl::finished(std::optional(b));
            })
                : prism_rtl::is_none(f_opt) ? prism_rtl::more(prism_rtl::rc(FirstBinder(q)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<lower::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
        fold_job(ps, std::optional<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Text>>(std::tuple<std::optional<Text>, lower::Pa>)>>(prism_rtl::rc([=](std::tuple<std::optional<Text>, lower::Pa> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto f_opt = p0;
                auto q = p1;
                ({
                prism_rtl::is_some(f_opt) ? ({
                auto&& b = prism_rtl::some_of(f_opt);
                prism_rtl::finished(std::optional(b));
            })
                : prism_rtl::is_none(f_opt) ? prism_rtl::more(prism_rtl::rc(FirstBinder(q)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::finished(std::optional<Text>{});
    });
}


/// `Start FirstBinder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Text>> start_first_binder(lower::Pa p_) {
    return std::make_shared<FirstBinder>(p_);
}


/// IsName: fn Pa -> Bool
bool is_name(const lower::Pa& pa0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lower::Pa::PaBind>(pa0)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaMut>(pa0)) {
            _v.set(true);
            goto _done;
        }
        {
            auto&& other = pa0;
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// PatName: fn Pa -> Text
Text pat_name(const lower::Pa& pa0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Pa::PaBind>(pa0)) {
            auto&& n = prism_rtl::as<lower::Pa::PaBind>(pa0).a0;
            _v.set(cpp_id(n));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaMut>(pa0)) {
            auto&& n = prism_rtl::as<lower::Pa::PaMut>(pa0).a0;
            _v.set(cpp_id(n));
            goto _done;
        }
        {
            auto&& other = pa0;
            _v.set(Text("_"));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// CppIfLet: unbounded fn Cp, Pa, Ex, [Do], [Do] -> Text
Text cpp_if_let(const Cp& cp0, const lower::Pa& p_, const lower::Ex& x, const Array<lower::Do>& t, const Array<lower::Do>& e) {
    auto cp = unbind(cp0, pat_names(p_));
    auto v_ = Text("_m");
    auto head = prism_rtl::cat("if (auto&& _m = ", cpp_expr(cp, x), "; ", conds(pat_conds(cp, p_, v_)), ")");
    auto body = lexer::join(append(pat_binds(cp, p_, v_), Array(std::vector{cpp_statements(cp, t)})), Text("\n"));
    return prism_rtl::cat(cpp_templates::block(head, body), cpp_else(cp, e));
}


prism_rtl::Turn<Text> CppIfLet::cycle() const {
    const auto& cp0 = this->cp0;
    const auto& p_ = this->p_;
    const auto& x = this->x;
    const auto& t = this->t;
    const auto& e = this->e;
    auto cp0_1 = cp0;
    auto e_2 = e;
    auto p__3 = p_;
    auto t_4 = t;
    auto x_5 = x;
    return call_then(start_pat_names(p__3), [=](Array<Text> pat_names_51766) {
        return ({
            auto cp = unbind(cp0_1, pat_names_51766);
            auto v_ = Text("_m");
            call_then(start_cpp_expr(cp, x_5), [=](Text cpp_expr_51828) {
            return call_then(start_pat_conds(cp, p__3, v_), [=](Array<Text> pat_conds_51852) {
                return ({
                    auto head = prism_rtl::cat("if (auto&& _m = ", cpp_expr_51828, "; ", conds(pat_conds_51852), ")");
                    call_then(start_pat_binds(cp, p__3, v_), [=](Array<Text> pat_binds_51903) {
                    return call_then(start_cpp_statements(cp, t_4), [=](Text cpp_statements_51926) {
                        return ({
                            auto body = lexer::join(append(pat_binds_51903, Array(std::vector{cpp_statements_51926})), Text("\n"));
                            call_then(start_cpp_else(cp, e_2), [=](Text cpp_else_51980) { return prism_rtl::finished(prism_rtl::cat(cpp_templates::block(head, body), cpp_else_51980)); });
                        });
                    });
                });
                });
            });
        });
        });
    });
}


/// `Start CppIfLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_if_let(Cp cp0, lower::Pa p_, lower::Ex x, Array<lower::Do> t, Array<lower::Do> e) {
    return std::make_shared<CppIfLet>(cp0, p_, x, t, e);
}


/// CppDoMatch: unbounded fn Cp, Ex, [((Pa, [Do]))] -> Text
Text cpp_do_match(const Cp& cp, const lower::Ex& x, const Array<std::tuple<lower::Pa, Array<lower::Do>>>& cases) {
    auto v_ = Text("_m");
    auto arms = run_to_end(each_job(cases, ({
        auto cp_1 = cp;
        auto v__2 = v_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Text>>(std::tuple<lower::Pa, Array<lower::Do>>)>>(prism_rtl::rc([=](std::tuple<lower::Pa, Array<lower::Do>> p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto v__2_3 = v__2;
            entered(once_job([=]() {
            return ({
                auto [p_, body] = p0;
                call_then(start_pat_conds(cp_1_3, p_, v__2_3), [=](Array<Text> pat_conds_52160) {
                return ({
                    auto tests = pat_conds_52160;
                    call_then(start_pat_binds(cp_1_3, p_, v__2_3), [=](Array<Text> pat_binds_52212) {
                    return call_then(start_cpp_statements(cp_1_3, body), [=](Text cpp_statements_52235) {
                        return ({
                            auto inner = lexer::join(append(pat_binds_52212, Array(std::vector{cpp_statements_52235})), Text("\n"));
                            (prism_rtl::finished(std::tuple{tests, inner}));
                        });
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })));
    auto blocks = each(check_errors::range0(len(arms)), [&](const Nat& i) {
        return ({
            auto [tests, inner] = or_(index(arms, i), std::tuple{Array<Text>{}, Text("")});
            auto head = i == Nat(0u)
                ? prism_rtl::cat("if (", conds(tests), ")")
                : len(tests) == Nat(0u)
                ? Text("else")
                : prism_rtl::cat("else if (", conds(tests), ")");
            (cpp_templates::block(head, inner));
        });
    });
    return cpp_templates::braced(prism_rtl::cat("auto&& _m = ", cpp_expr(cp, x), ";\n", lexer::join(blocks, Text(" "))));
}


prism_rtl::Turn<Text> CppDoMatch::cycle() const {
    const auto& cp = this->cp;
    const auto& x = this->x;
    const auto& cases = this->cases_;
    auto v_ = Text("_m");
    auto cases_1 = cases;
    auto cp_2 = cp;
    auto x_3 = x;
    return call_value(each_job(cases_1, ({
        auto cp_2_4 = cp_2;
        auto v__4 = v_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Text>>(std::tuple<lower::Pa, Array<lower::Do>>)>>(prism_rtl::rc([=](std::tuple<lower::Pa, Array<lower::Do>> p0) {
        return ({
            auto cp_2_4_5 = cp_2_4;
            auto v__4_5 = v__4;
            entered(once_job([=]() {
            return ({
                auto [p_, body] = p0;
                call_then(start_pat_conds(cp_2_4_5, p_, v__4_5), [=](Array<Text> pat_conds_52160) {
                return ({
                    auto tests = pat_conds_52160;
                    call_then(start_pat_binds(cp_2_4_5, p_, v__4_5), [=](Array<Text> pat_binds_52212) {
                    return call_then(start_cpp_statements(cp_2_4_5, body), [=](Text cpp_statements_52235) {
                        return ({
                            auto inner = lexer::join(append(pat_binds_52212, Array(std::vector{cpp_statements_52235})), Text("\n"));
                            (prism_rtl::finished(std::tuple{tests, inner}));
                        });
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Array<Text>, Text>> each_52113) {
        return ({
            auto arms = each_52113;
            auto blocks = each(check_errors::range0(len(arms)), [&](const Nat& i) {
                return ({
                    auto [tests, inner] = or_(index(arms, i), std::tuple{Array<Text>{}, Text("")});
                    auto head = i == Nat(0u)
                        ? prism_rtl::cat("if (", conds(tests), ")")
                        : len(tests) == Nat(0u)
                        ? Text("else")
                        : prism_rtl::cat("else if (", conds(tests), ")");
                    (cpp_templates::block(head, inner));
                });
            });
            call_then(start_cpp_expr(cp_2, x_3), [=](Text cpp_expr_52565) { return prism_rtl::finished(cpp_templates::braced(prism_rtl::cat("auto&& _m = ", cpp_expr_52565, ";\n", lexer::join(blocks, Text(" "))))); });
        });
    });
}


/// `Start CppDoMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_do_match(Cp cp, lower::Ex x, Array<std::tuple<lower::Pa, Array<lower::Do>>> cases_) {
    return std::make_shared<CppDoMatch>(cp, x, cases_);
}


/// CppFor: unbounded fn Cp, Pa, Ex, [Do] -> Text
Text cpp_for(const Cp& cp0, const lower::Pa& p_, const lower::Ex& x, const Array<lower::Do>& body) {
    return cpp_for_in(unbind(cp0, pat_names(p_)), p_, cpp_expr(cp0, x), body);
}


prism_rtl::Turn<Text> CppFor::cycle() const {
    const auto& cp0 = this->cp0;
    const auto& p_ = this->p_;
    const auto& x = this->x;
    const auto& body = this->body;
    auto body_1 = body;
    auto cp0_2 = cp0;
    auto p__3 = p_;
    auto x_4 = x;
    return call_then(start_pat_names(p__3), [=](Array<Text> pat_names_52779) { return call_then(start_cpp_expr(cp0_2, x_4), [=](Text cpp_expr_52797) { return prism_rtl::more(prism_rtl::rc(CppForIn(unbind(cp0_2, pat_names_52779), p__3, cpp_expr_52797, body_1))); }); });
}


/// `Start CppFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_for(Cp cp0, lower::Pa p_, lower::Ex x, Array<lower::Do> body) {
    return std::make_shared<CppFor>(cp0, p_, x, body);
}


/// CppForIn: unbounded fn Cp, Pa, Text, [Do] -> Text
Text cpp_for_in(const Cp& cp, const lower::Pa& p_, const Text& xs, const Array<lower::Do>& body) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Pa::PaBind>(p_)) {
            auto&& n = prism_rtl::as<lower::Pa::PaBind>(p_).a0;
            _v.set(cpp_templates::block(prism_rtl::cat("for (auto&& ", cpp_id(n), " : ", xs, ")"), cpp_statements(cp, body)));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaMut>(p_)) {
            auto&& n = prism_rtl::as<lower::Pa::PaMut>(p_).a0;
            _v.set(cpp_templates::block(prism_rtl::cat("for (auto ", cpp_id(n), " : ", xs, ")"), cpp_statements(cp, body)));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaTuple>(p_)) {
            auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
            _v.set(fold(ps, true, [&](const bool& f, const lower::Pa& q) { return f && is_name(q); })
                ? cpp_templates::block(prism_rtl::cat("for (auto&& [", lexer::join(each(ps, [&](const lower::Pa& q) { return pat_name(q); }), Text(", ")), "] : ", xs, ")"), cpp_statements(cp, body))
                : cpp_templates::block(prism_rtl::cat("for (auto&& _e : ", xs, ")"), lexer::join(append(pat_binds(cp, p_, Text("_e")), Array(std::vector{cpp_statements(cp, body)})), Text("\n"))));
            goto _done;
        }
        {
            _v.set(cpp_templates::block(prism_rtl::cat("for (auto&& _e : ", xs, ")"), lexer::join(append(pat_binds(cp, p_, Text("_e")), Array(std::vector{cpp_statements(cp, body)})), Text("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> CppForIn::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& xs = this->xs;
    const auto& body = this->body;
    return ({
        prism_rtl::is<lower::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(p_).a0;
        ({
        auto body_1 = body;
        auto cp_2 = cp;
        auto n_3 = n;
        auto xs_4 = xs;
        call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_52963) { return prism_rtl::finished(cpp_templates::block(prism_rtl::cat("for (auto&& ", cpp_id(n_3), " : ", xs_4, ")"), cpp_statements_52963)); });
    });
    })
        : prism_rtl::is<lower::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaMut>(p_).a0;
        ({
        auto body_1 = body;
        auto cp_2 = cp;
        auto n_3 = n;
        auto xs_4 = xs;
        call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_53038) { return prism_rtl::finished(cpp_templates::block(prism_rtl::cat("for (auto ", cpp_id(n_3), " : ", xs_4, ")"), cpp_statements_53038)); });
    });
    })
        : prism_rtl::is<lower::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
        fold(ps, true, [&](const bool& f, const lower::Pa& q) { return f && is_name(q); })
        ? ({
        auto body_1 = body;
        auto cp_2 = cp;
        auto ps_3 = ps;
        auto xs_4 = xs;
        call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_53199) { return prism_rtl::finished(cpp_templates::block(prism_rtl::cat("for (auto&& [", lexer::join(each(ps_3, [&](const lower::Pa& q) { return pat_name(q); }), Text(", ")), "] : ", xs_4, ")"), cpp_statements_53199)); });
    })
        : ({
        auto body_1 = body;
        auto cp_2 = cp;
        auto p__3 = p_;
        auto xs_4 = xs;
        call_then(start_pat_binds(cp_2, p__3, Text("_e")), [=](Array<Text> pat_binds_53284) { return call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_53310) { return prism_rtl::finished(cpp_templates::block(prism_rtl::cat("for (auto&& _e : ", xs_4, ")"), lexer::join(append(pat_binds_53284, Array(std::vector{cpp_statements_53310})), Text("\n")))); }); });
    });
    })
        : ({
        auto body_1 = body;
        auto cp_2 = cp;
        auto p__3 = p_;
        auto xs_4 = xs;
        call_then(start_pat_binds(cp_2, p__3, Text("_e")), [=](Array<Text> pat_binds_53406) { return call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_53432) { return prism_rtl::finished(cpp_templates::block(prism_rtl::cat("for (auto&& _e : ", xs_4, ")"), lexer::join(append(pat_binds_53406, Array(std::vector{cpp_statements_53432})), Text("\n")))); }); });
    });
    });
}


/// `Start CppForIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_for_in(Cp cp, lower::Pa p_, Text xs, Array<lower::Do> body) {
    return std::make_shared<CppForIn>(cp, p_, xs, body);
}


/// CppBody: unbounded fn Cp, Ex -> Text
Text cpp_body(const Cp& cp, const lower::Ex& ex1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Ex::XBlock>(ex1)) {
            auto&& dos = prism_rtl::as<lower::Ex::XBlock>(ex1).a0;
            auto&& e = prism_rtl::as<lower::Ex::XBlock>(ex1).a1;
            _v.set(({
                auto [st, cp2] = cpp_statements_cp(cp, dos);
                len(dos) == Nat(0u)
                ? cpp_body(cp, e)
                : prism_rtl::cat(st, "\n", cpp_body(cp2, e));
            }));
            goto _done;
        }
        {
            auto&& x = ex1;
            _v.set(leaves(x)
                ? prism_rtl::cat(cpp_expr(cp, x), ";")
                : prism_rtl::cat("return ", cpp_expr(cp, x), ";"));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> CppBody::cycle() const {
    const auto& cp = this->cp;
    const auto& ex1 = this->ex1;
    return ({
        prism_rtl::is<lower::Ex::XBlock>(ex1) ? ({
        auto&& dos = prism_rtl::as<lower::Ex::XBlock>(ex1).a0;
        auto&& e = prism_rtl::as<lower::Ex::XBlock>(ex1).a1;
        ({
        auto cp_1 = cp;
        auto dos_2 = dos;
        auto e_3 = e;
        call_then(start_cpp_statements_cp(cp_1, dos_2), [=](std::tuple<Text, Cp> cpp_statements_cp_53620) {
        return ({
            auto [st, cp2] = cpp_statements_cp_53620;
            len(dos_2) == Nat(0u)
            ? prism_rtl::more(prism_rtl::rc(CppBody(cp_1, e_3)))
            : call_then(start_cpp_body(cp2, e_3), [=](Text cpp_body_53695) { return prism_rtl::finished(prism_rtl::cat(st, "\n", cpp_body_53695)); });
        });
    });
    });
    })
        : ({
        auto&& x = ex1;
        leaves(x)
        ? ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_53746) { return prism_rtl::finished(prism_rtl::cat(cpp_expr_53746, ";")); });
    })
        : ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_53778) { return prism_rtl::finished(prism_rtl::cat("return ", cpp_expr_53778, ";")); });
    });
    });
    });
}


/// `Start CppBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_body(Cp cp, lower::Ex ex1) {
    return std::make_shared<CppBody>(cp, ex1);
}


/// CppTemplateHead: fn [Text] -> Text
Text cpp_template_head(const Array<Text>& xs0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& c0_0 = xs0;
            if (c0_0.size() == 0u) {
                _v.set(Text(""));
                goto _done;
            }
        }
        {
            auto&& ps = xs0;
            _v.set(prism_rtl::cat("template <", lexer::join(each(ps, [&](const Text& p_) { return prism_rtl::cat("class ", p_); }), Text(", ")), ">\n"));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// GenericNamesOf: fn [((Text, [Text]))] -> [Text]
Array<Text> generic_names_of(const Array<std::tuple<Text, Array<Text>>>& gs) {
    return each(gs, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g = std::get<0>(_p0);
        return g;
    });
}


/// HeadOf: fn Text, [Text] -> Text
Text head_of(const Text& name, const Array<Text>& xs1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& c0_1 = xs1;
            if (c0_1.size() == 0u) {
                _v.set(name);
                goto _done;
            }
        }
        {
            auto&& ps = xs1;
            _v.set(prism_rtl::cat(name, "<", lexer::join(ps, Text(", ")), ">"));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
Text cpp_params(const Cp& cp, const Array<std::tuple<Text, lower::OutTy>>& ps) {
    return lexer::join(run_to_end(each_job(ps, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_param_type(cp_1_2, t), [=](Text param_type_54443) { return prism_rtl::finished(prism_rtl::cat(param_type_54443, " ", cpp_id(n))); });
            });
        }));
        });
    })));
    }))), Text(", "));
}


prism_rtl::Turn<Text> CppParams::cycle() const {
    const auto& cp = this->cp;
    const auto& ps = this->ps;
    auto cp_1 = cp;
    auto ps_2 = ps;
    return call_value(each_job(ps_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_param_type(cp_1_3_3, t), [=](Text param_type_54443) { return prism_rtl::finished(prism_rtl::cat(param_type_54443, " ", cpp_id(n))); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_54420) { return prism_rtl::finished(lexer::join(each_54420, Text(", "))); });
}


/// `Start CppParams, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_params(Cp cp, Array<std::tuple<Text, lower::OutTy>> ps) {
    return std::make_shared<CppParams>(cp, ps);
}


/// FnSignature: unbounded fn Cp, FnDef -> Text
Text fn_signature(const Cp& cp, const lower::FnDef& f) {
    return prism_rtl::cat(cpp_template_head(generic_names_of(f.generics)), cpp_type(cp, f.ret), " ", cpp_id(f.name), "(", cpp_params(cp, f.params), ")");
}


prism_rtl::Turn<Text> FnSignature::cycle() const {
    const auto& cp = this->cp;
    const auto& f = this->f;
    auto cp_1 = cp;
    auto f_2 = f;
    return call_then(start_cpp_type(cp_1, f_2.ret), [=](Text cpp_type_54674) { return call_then(start_cpp_params(cp_1, f_2.params), [=](Text cpp_params_54709) { return prism_rtl::finished(prism_rtl::cat(cpp_template_head(generic_names_of(f_2.generics)), cpp_type_54674, " ", cpp_id(f_2.name), "(", cpp_params_54709, ")")); }); });
}


/// `Start FnSignature, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_fn_signature(Cp cp, lower::FnDef f) {
    return std::make_shared<FnSignature>(cp, f);
}


/// FnDefinition: unbounded fn Cp, FnDef -> Text
Text fn_definition(const Cp& cp, const lower::FnDef& f) {
    return cpp_templates::cpp_function(cpp_doc(f.doc), fn_signature(cp, f), cpp_body(cp, f.body));
}


prism_rtl::Turn<Text> FnDefinition::cycle() const {
    const auto& cp = this->cp;
    const auto& f = this->f;
    auto cp_1 = cp;
    auto f_2 = f;
    return call_then(start_fn_signature(cp_1, f_2), [=](Text fn_signature_54834) { return call_then(start_cpp_body(cp_1, f_2.body), [=](Text cpp_body_54855) { return prism_rtl::finished(cpp_templates::cpp_function(cpp_doc(f_2.doc), fn_signature_54834, cpp_body_54855)); }); });
}


/// `Start FnDefinition, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_fn_definition(Cp cp, lower::FnDef f) {
    return std::make_shared<FnDefinition>(cp, f);
}


/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
Array<Text> value_deps(const Cp& cp, const lower::OutTy& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
            auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
            auto&& args = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
            _v.set(({
                auto own = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = type_of(cp, n);
                    if (prism_rtl::is_some(_m)) {
                        auto&& info = prism_rtl::some_of(_m);
                        _v.set((((info.kind == Text("record")) || (info.kind == Text("newtype"))) || (info.kind == Text("unit"))) || (info.kind == Text("tag"))
                            ? Array(std::vector{absolute(cp, n)})
                            : Array<Text>{});
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<Text>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                append(own, concat2(run_to_end(each_job(args, ({
                auto cp_1 = cp;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(lower::OutTy)>>(prism_rtl::rc([=](lower::OutTy p0) {
                return ({
                    auto cp_1_2 = cp_1;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_2, a))));
                    });
                }));
                });
            })));
            })))));
            }));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutOpt>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutOpt>(t).a0;
            _v.set(value_deps(cp, i));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutRes>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutRes>(t).a0;
            _v.set(value_deps(cp, i));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutRc>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutRc>(t).a0;
            _v.set(value_deps(cp, i));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutCell>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutCell>(t).a0;
            _v.set(value_deps(cp, i));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutTuple>(t)) {
            auto&& ts = prism_rtl::as<lower::OutTy::OutTuple>(t).a0;
            _v.set(concat2(run_to_end(each_job(ts, ({
                auto cp_1 = cp;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(lower::OutTy)>>(prism_rtl::rc([=](lower::OutTy p0) {
                return ({
                    auto cp_1_2 = cp_1;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_2, a))));
                    });
                }));
                });
            })));
            })))));
            goto _done;
        }
        {
            _v.set(Array<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Text>> ValueDeps::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    return ({
        prism_rtl::is<lower::OutTy::OutNamed>(t) ? ({
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& args = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        ({
        auto own = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = type_of(cp, n);
            if (prism_rtl::is_some(_m)) {
                auto&& info = prism_rtl::some_of(_m);
                _v.set((((info.kind == Text("record")) || (info.kind == Text("newtype"))) || (info.kind == Text("unit"))) || (info.kind == Text("tag"))
                    ? Array(std::vector{absolute(cp, n)})
                    : Array<Text>{});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto args_1 = args;
        auto cp_2 = cp;
        call_value(each_job(args_1, ({
        auto cp_2_3 = cp_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(lower::OutTy)>>(prism_rtl::rc([=](lower::OutTy p0) {
        return ({
            auto cp_2_3_3 = cp_2_3;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_2_3_3, a))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_55818) { return prism_rtl::finished(append(own, concat2(each_55818))); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutOpt>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutOpt>(t).a0;
        prism_rtl::more(prism_rtl::rc(ValueDeps(cp, i)));
    })
        : prism_rtl::is<lower::OutTy::OutRes>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutRes>(t).a0;
        prism_rtl::more(prism_rtl::rc(ValueDeps(cp, i)));
    })
        : prism_rtl::is<lower::OutTy::OutRc>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutRc>(t).a0;
        prism_rtl::more(prism_rtl::rc(ValueDeps(cp, i)));
    })
        : prism_rtl::is<lower::OutTy::OutCell>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutCell>(t).a0;
        prism_rtl::more(prism_rtl::rc(ValueDeps(cp, i)));
    })
        : prism_rtl::is<lower::OutTy::OutTuple>(t) ? ({
        auto&& ts = prism_rtl::as<lower::OutTy::OutTuple>(t).a0;
        ({
        auto cp_1 = cp;
        auto ts_2 = ts;
        call_value(each_job(ts_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(lower::OutTy)>>(prism_rtl::rc([=](lower::OutTy p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_3_3, a))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_55998) { return prism_rtl::finished(concat2(each_55998)); });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start ValueDeps, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_value_deps(Cp cp, lower::OutTy t) {
    return std::make_shared<ValueDeps>(cp, t);
}


/// let noParts
Parts no_parts() {
    return Parts{.forward = Array<Text>{}, .handles = Array<Text>{}, .values = Array<ValueDecl>{}, .cases_ = Array<Text>{}, .protos = Array<Text>{}, .classes = Array<Text>{}, .generic = Array<Text>{}, .defs = Array<Text>{}};
}


/// JoinParts: fn Parts, Parts -> Parts
Parts join_parts(const Parts& a, const Parts& b) {
    return Parts{.forward = append(a.forward, b.forward), .handles = append(a.handles, b.handles), .values = append(a.values, b.values), .cases_ = append(a.cases_, b.cases_), .protos = append(a.protos, b.protos), .classes = append(a.classes, b.classes), .generic = append(a.generic, b.generic), .defs = append(a.defs, b.defs)};
}


/// ItemParts: unbounded fn Cp, Item -> Parts
Parts item_parts(const Cp& cp, const lower::Item& it) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Parts> _v;
        if (prism_rtl::is<lower::Item::ItType>(it)) {
            auto&& t = prism_rtl::as<lower::Item::ItType>(it).a0;
            _v.set(type_parts(cp, t));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItTag>(it)) {
            auto&& t = prism_rtl::as<lower::Item::ItTag>(it).a0;
            _v.set(tag_parts(cp, t));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItRow>(it)) {
            auto&& r = prism_rtl::as<lower::Item::ItRow>(it).a0;
            _v.set(row_parts(cp, cp.home, r));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItFn>(it)) {
            auto&& f = prism_rtl::as<lower::Item::ItFn>(it).a0;
            _v.set(fn_parts(cp, f));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItJob>(it)) {
            auto&& j = prism_rtl::as<lower::Item::ItJob>(it).a0;
            _v.set(job_parts(cp, j));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItNode>(it)) {
            auto&& n = prism_rtl::as<lower::Item::ItNode>(it).a0;
            _v.set(node_parts(cp, n));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItTrait>(it)) {
            auto&& t = prism_rtl::as<lower::Item::ItTrait>(it).a0;
            _v.set(trait_parts(cp, t));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItImpl>(it)) {
            auto&& i = prism_rtl::as<lower::Item::ItImpl>(it).a0;
            _v.set(impl_parts(cp, i));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItNote>(it)) {
            auto&& t = prism_rtl::as<lower::Item::ItNote>(it).a0;
            _v.set(protos_defs(Array<Text>{}, Array(std::vector{prism_rtl::cat("// ", t)})));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItRefused>(it)) {
            auto&& t = prism_rtl::as<lower::Item::ItRefused>(it).a0;
            _v.set(protos_defs(Array<Text>{}, Array(std::vector{prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), lower::escape(t), "\");")})));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Parts> ItemParts::cycle() const {
    const auto& cp = this->cp;
    const auto& it = this->it;
    return ({
        prism_rtl::is<lower::Item::ItType>(it) ? ({
        auto&& t = prism_rtl::as<lower::Item::ItType>(it).a0;
        prism_rtl::more(prism_rtl::rc(TypeParts(cp, t)));
    })
        : prism_rtl::is<lower::Item::ItTag>(it) ? ({
        auto&& t = prism_rtl::as<lower::Item::ItTag>(it).a0;
        prism_rtl::more(prism_rtl::rc(TagParts(cp, t)));
    })
        : prism_rtl::is<lower::Item::ItRow>(it) ? ({
        auto&& r = prism_rtl::as<lower::Item::ItRow>(it).a0;
        prism_rtl::more(prism_rtl::rc(RowParts(cp, cp.home, r)));
    })
        : prism_rtl::is<lower::Item::ItFn>(it) ? ({
        auto&& f = prism_rtl::as<lower::Item::ItFn>(it).a0;
        prism_rtl::more(prism_rtl::rc(FnParts(cp, f)));
    })
        : prism_rtl::is<lower::Item::ItJob>(it) ? ({
        auto&& j = prism_rtl::as<lower::Item::ItJob>(it).a0;
        prism_rtl::more(prism_rtl::rc(JobParts(cp, j)));
    })
        : prism_rtl::is<lower::Item::ItNode>(it) ? ({
        auto&& n = prism_rtl::as<lower::Item::ItNode>(it).a0;
        prism_rtl::more(prism_rtl::rc(NodeParts(cp, n)));
    })
        : prism_rtl::is<lower::Item::ItTrait>(it) ? ({
        auto&& t = prism_rtl::as<lower::Item::ItTrait>(it).a0;
        prism_rtl::more(prism_rtl::rc(TraitParts(cp, t)));
    })
        : prism_rtl::is<lower::Item::ItImpl>(it) ? ({
        auto&& i = prism_rtl::as<lower::Item::ItImpl>(it).a0;
        prism_rtl::more(prism_rtl::rc(ImplParts(cp, i)));
    })
        : prism_rtl::is<lower::Item::ItNote>(it) ? ({
        auto&& t = prism_rtl::as<lower::Item::ItNote>(it).a0;
        prism_rtl::finished(protos_defs(Array<Text>{}, Array(std::vector{prism_rtl::cat("// ", t)})));
    })
        : prism_rtl::is<lower::Item::ItRefused>(it) ? ({
        auto&& t = prism_rtl::as<lower::Item::ItRefused>(it).a0;
        prism_rtl::finished(protos_defs(Array<Text>{}, Array(std::vector{prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), lower::escape(t), "\");")})));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ItemParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_item_parts(Cp cp, lower::Item it) {
    return std::make_shared<ItemParts>(cp, it);
}


/// FnParts: unbounded fn Cp, FnDef -> Parts
Parts fn_parts(const Cp& cp, const lower::FnDef& f) {
    return len(f.generics) > Nat(0u)
        ? generic_only(Array(std::vector{fn_definition(cp, f)}))
        : protos_defs(Array(std::vector{prism_rtl::cat(fn_signature(cp, f), ";")}), Array(std::vector{fn_definition(cp, f)}));
}


prism_rtl::Turn<Parts> FnParts::cycle() const {
    const auto& cp = this->cp;
    const auto& f = this->f;
    return len(f.generics) > Nat(0u)
        ? ({
        auto cp_1 = cp;
        auto f_2 = f;
        call_then(start_fn_definition(cp_1, f_2), [=](Text fn_definition_57082) { return prism_rtl::finished(generic_only(Array(std::vector{fn_definition_57082}))); });
    })
        : ({
        auto cp_1 = cp;
        auto f_2 = f;
        call_then(start_fn_signature(cp_1, f_2), [=](Text fn_signature_57129) { return call_then(start_fn_definition(cp_1, f_2), [=](Text fn_definition_57156) { return prism_rtl::finished(protos_defs(Array(std::vector{prism_rtl::cat(fn_signature_57129, ";")}), Array(std::vector{fn_definition_57156}))); }); });
    });
}


/// `Start FnParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_fn_parts(Cp cp, lower::FnDef f) {
    return std::make_shared<FnParts>(cp, f);
}


/// CppDoc: fn Text -> Text
Text cpp_doc(const Text& text) {
    return text == Text("")
        ? Text("")
        : concat(each(split(text, Text("\n")), [&](const Text& l) { return l == Text("") ? Text("///\n") : prism_rtl::cat("/// ", l, "\n"); }));
}


/// CppSourceDoc: fn Text, Text -> Text
Text cpp_source_doc(const Text& lead, const Text& source) {
    auto quoted = concat(each(split(source, Text("\n")), [&](const Text& l) { return l == Text("") ? Text("///\n") : prism_rtl::cat("/// ", l, "\n"); }));
    return source == Text("")
        ? cpp_doc(lead)
        : lead == Text("")
        ? prism_rtl::cat("/// ```prism\n", quoted, "/// ```\n")
        : prism_rtl::cat("/// ", lead, "\n///\n/// ```prism\n", quoted, "/// ```\n");
}


/// TypeParts: unbounded fn Cp, TyDef -> Parts
Parts type_parts(const Cp& cp, const lower::TyDef& t) {
    auto eq = t.eq;
    auto ord = t.ord && (!t.floaty);
    auto gens = cpp_template_head(t.params);
    auto head = head_of(t.name, t.params);
    auto doc = cpp_source_doc(prism_rtl::cat("`", t.prism, "`:"), t.doc);
    auto members_ = members(t.show_ != lower::Shown(lower::Shown::NotShown{}), t.pod, head);
    auto generic = len(t.params) > Nat(0u);
    auto fwd = prism_rtl::cat(gens, t.shape == lower::TyShape(lower::TyShape::ShapeChoice{})
        ? Text("class")
        : Text("struct"), " ", t.name, ";");
    return ({
        __label__ _done;
        prism_rtl::Slot<Parts> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeChoice>(_m)) {
            _v.set(({
                auto names = each(t.cases_, [&](const lower::CaseDef& c) { return c.name; });
                auto friend_eq = eq && (!generic)
                    ? prism_rtl::cat("\nfriend inline bool operator==(const ", head, "& a, const ", head, "& b);")
                    : Text("");
                auto handle = cpp_templates::choice_handle(doc, gens, t.name, lexer::join(each(names, [&](const Text& n) { return prism_rtl::cat("struct ", n, ";"); }), Text("\n")), lexer::join(names, Text(", ")), prism_rtl::cat(members_, friend_eq));
                auto cases = run_to_end(each_job(t.cases_, ({
                    auto cp_1 = cp;
                    auto gens_2 = gens;
                    auto head_3 = head;
                    auto eq_4 = eq;
                    auto ord_5 = ord;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::CaseDef)>>(prism_rtl::rc([=](lower::CaseDef p0) {
                    return ({
                        auto cp_1_6 = cp_1;
                        auto gens_2_6 = gens_2;
                        auto head_3_6 = head_3;
                        auto eq_4_6 = eq_4;
                        auto ord_5_6 = ord_5;
                        entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            (prism_rtl::more(prism_rtl::rc(CaseStruct(cp_1_6, gens_2_6, head_3_6, c, eq_4_6, ord_5_6))));
                        });
                    }));
                    });
                })));
                })));
                auto cmp = lexer::join(filter(Array(std::vector{eq
                    ? prism_rtl::cat(gens, "inline bool operator==(const ", head, "& a, const ", head, "& b) { return a.cases() == b.cases(); }")
                    : Text(""), ord
                    ? prism_rtl::cat(gens, "inline auto operator<=>(const ", head, "& a, const ", head, "& b) { return a.cases() <=> b.cases(); }")
                    : Text("")}), [&](const Text& s) { return s != Text(""); }), Text("\n"));
                auto defs = type_defs(cp, t, head);
                Parts{.forward = Array(std::vector{fwd}), .handles = Array(std::vector{handle}), .values = Array<ValueDecl>{}, .cases_ = append(cases, Array(std::vector{cases_accessor(gens, head), cmp})), .protos = Array<Text>{}, .classes = Array<Text>{}, .generic = generic ? Array(std::vector{defs}) : Array<Text>{}, .defs = generic ? Array<Text>{} : Array(std::vector{defs})};
            }));
            goto _done;
        }
        {
            _v.set(({
                auto first_ = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                auto fields = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = t.shape;
                    if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
                        _v.set(lexer::join(run_to_end(each_job(first_.fields, ({
                            auto cp_1 = cp;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
                            return ({
                                auto cp_1_2 = cp_1;
                                entered(once_job([=]() {
                                return ({
                                    auto [f, ft] = p0;
                                    call_then(start_cpp_type(cp_1_2, ft), [=](Text cpp_type_59756) { return prism_rtl::finished(prism_rtl::cat(cpp_type_59756, " ", field_id(f), ";")); });
                                });
                            }));
                            });
                        })));
                        }))), Text("\n")));
                        goto _done;
                    }
                    if (prism_rtl::is<lower::TyShape::ShapeNewtype>(_m)) {
                        _v.set(positional_fields(cp, first_.fields));
                        goto _done;
                    }
                    {
                        _v.set(Text(""));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto cmps = lexer::join(filter(Array(std::vector{eq
                    ? prism_rtl::cat("bool operator==(const ", t.name, "&) const = default;")
                    : Text(""), ord
                    ? prism_rtl::cat("auto operator<=>(const ", t.name, "&) const = default;")
                    : Text("")}), [&](const Text& s) { return s != Text(""); }), Text("\n"));
                auto decl = cpp_templates::value_struct(doc, gens, t.name, fields, lexer::join(filter(Array(std::vector{cmps, members_}), [&](const Text& s) { return s != Text(""); }), Text("\n")));
                auto defs = type_defs(cp, t, head);
                auto deps = concat2(run_to_end(each_job(first_.fields, ({
                    auto cp_1 = cp;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
                    return ({
                        auto cp_1_2 = cp_1;
                        entered(once_job([=]() {
                        return ({
                            auto&& _ft = p0;
                            auto&& ft = std::get<1>(_ft);
                            (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_2, ft))));
                        });
                    }));
                    });
                })));
                }))));
                Parts{.forward = Array(std::vector{fwd}), .handles = Array<Text>{}, .values = Array(std::vector{ValueDecl{.path_ = prism_rtl::cat(cp.home, "::", t.name), .deps = deps, .text = decl}}), .cases_ = Array<Text>{}, .protos = Array<Text>{}, .classes = Array<Text>{}, .generic = generic ? Array(std::vector{defs}) : Array<Text>{}, .defs = generic ? Array<Text>{} : Array(std::vector{defs})};
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Parts> TypeParts::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    auto eq = t.eq;
    auto ord = t.ord && (!t.floaty);
    auto gens = cpp_template_head(t.params);
    auto head = head_of(t.name, t.params);
    auto doc = cpp_source_doc(prism_rtl::cat("`", t.prism, "`:"), t.doc);
    auto members_ = members(t.show_ != lower::Shown(lower::Shown::NotShown{}), t.pod, head);
    auto generic = len(t.params) > Nat(0u);
    auto fwd = prism_rtl::cat(gens, t.shape == lower::TyShape(lower::TyShape::ShapeChoice{})
        ? Text("class")
        : Text("struct"), " ", t.name, ";");
    return ({
        auto&& _m = t.shape;
        prism_rtl::is<lower::TyShape::ShapeChoice>(_m) ? ({
        auto names = each(t.cases_, [&](const lower::CaseDef& c) { return c.name; });
        auto friend_eq = eq && (!generic)
            ? prism_rtl::cat("\nfriend inline bool operator==(const ", head, "& a, const ", head, "& b);")
            : Text("");
        auto handle = cpp_templates::choice_handle(doc, gens, t.name, lexer::join(each(names, [&](const Text& n) { return prism_rtl::cat("struct ", n, ";"); }), Text("\n")), lexer::join(names, Text(", ")), prism_rtl::cat(members_, friend_eq));
        auto cp_1 = cp;
        auto t_2 = t;
        call_value(each_job(t_2.cases_, ({
        auto cp_1_3 = cp_1;
        auto gens_3 = gens;
        auto head_4 = head;
        auto eq_5 = eq;
        auto ord_6 = ord;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::CaseDef)>>(prism_rtl::rc([=](lower::CaseDef p0) {
        return ({
            auto cp_1_3_7 = cp_1_3;
            auto gens_3_7 = gens_3;
            auto head_4_7 = head_4;
            auto eq_5_7 = eq_5;
            auto ord_6_7 = ord_6;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::more(prism_rtl::rc(CaseStruct(cp_1_3_7, gens_3_7, head_4_7, c, eq_5_7, ord_6_7))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_58905) {
        return ({
            auto cases = each_58905;
            auto cmp = lexer::join(filter(Array(std::vector{eq
                ? prism_rtl::cat(gens, "inline bool operator==(const ", head, "& a, const ", head, "& b) { return a.cases() == b.cases(); }")
                : Text(""), ord
                ? prism_rtl::cat(gens, "inline auto operator<=>(const ", head, "& a, const ", head, "& b) { return a.cases() <=> b.cases(); }")
                : Text("")}), [&](const Text& s) { return s != Text(""); }), Text("\n"));
            call_then(start_type_defs(cp_1, t_2, head), [=](Text type_defs_59289) {
            return ({
                auto defs = type_defs_59289;
                (prism_rtl::finished(Parts{.forward = Array(std::vector{fwd}), .handles = Array(std::vector{handle}), .values = Array<ValueDecl>{}, .cases_ = append(cases, Array(std::vector{cases_accessor(gens, head), cmp})), .protos = Array<Text>{}, .classes = Array<Text>{}, .generic = generic ? Array(std::vector{defs}) : Array<Text>{}, .defs = generic ? Array<Text>{} : Array(std::vector{defs})}));
            });
        });
        });
    });
    })
        : ({
        auto first_ = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
        auto fields = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            auto&& _m = t.shape;
            if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
                _v.set(lexer::join(run_to_end(each_job(first_.fields, ({
                    auto cp_1 = cp;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
                    return ({
                        auto cp_1_2 = cp_1;
                        entered(once_job([=]() {
                        return ({
                            auto [f, ft] = p0;
                            call_then(start_cpp_type(cp_1_2, ft), [=](Text cpp_type_59756) { return prism_rtl::finished(prism_rtl::cat(cpp_type_59756, " ", field_id(f), ";")); });
                        });
                    }));
                    });
                })));
                }))), Text("\n")));
                goto _done;
            }
            if (prism_rtl::is<lower::TyShape::ShapeNewtype>(_m)) {
                _v.set(positional_fields(cp, first_.fields));
                goto _done;
            }
            {
                _v.set(Text(""));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto cmps = lexer::join(filter(Array(std::vector{eq
            ? prism_rtl::cat("bool operator==(const ", t.name, "&) const = default;")
            : Text(""), ord
            ? prism_rtl::cat("auto operator<=>(const ", t.name, "&) const = default;")
            : Text("")}), [&](const Text& s) { return s != Text(""); }), Text("\n"));
        auto decl = cpp_templates::value_struct(doc, gens, t.name, fields, lexer::join(filter(Array(std::vector{cmps, members_}), [&](const Text& s) { return s != Text(""); }), Text("\n")));
        auto cp_1 = cp;
        auto t_2 = t;
        call_then(start_type_defs(cp_1, t_2, head), [=](Text type_defs_60230) {
        return ({
            auto defs = type_defs_60230;
            call_value(each_job(first_.fields, ({
            auto cp_1_3 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
            return ({
                auto cp_1_3_3 = cp_1_3;
                entered(once_job([=]() {
                return ({
                    auto&& _ft = p0;
                    auto&& ft = std::get<1>(_ft);
                    (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_3_3, ft))));
                });
            }));
            });
        })));
        })), [=](Array<Array<Text>> each_60283) {
            return ({
                auto deps = concat2(each_60283);
                (prism_rtl::finished(Parts{.forward = Array(std::vector{fwd}), .handles = Array<Text>{}, .values = Array(std::vector{ValueDecl{.path_ = prism_rtl::cat(cp_1.home, "::", t_2.name), .deps = deps, .text = decl}}), .cases_ = Array<Text>{}, .protos = Array<Text>{}, .classes = Array<Text>{}, .generic = generic ? Array(std::vector{defs}) : Array<Text>{}, .defs = generic ? Array<Text>{} : Array(std::vector{defs})}));
            });
        });
        });
    });
    });
    });
}


/// `Start TypeParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_type_parts(Cp cp, lower::TyDef t) {
    return std::make_shared<TypeParts>(cp, t);
}


/// CasesAccessor: fn Text, Text -> Text
Text cases_accessor(const Text& gens, const Text& head) {
    return prism_rtl::cat(gens, "inline const ", gens == Text("") ? Text("") : Text("typename "), head, "::Cases& ", head, "::cases() const { return *cases_; }");
}


/// Members: fn Bool, Bool, Text -> Text
Text members(const bool& shown, const bool& pod, const Text& head) {
    auto s = shown
        ? Array(std::vector{Text("void show(Printer& p) const;")})
        : Array<Text>{};
    auto d = pod
        ? Array(std::vector{Text("Pod to_pod() const;"), prism_rtl::cat("static Result<", head, "> from_pod(const Pod& whole);")})
        : Array<Text>{};
    return lexer::join(append(s, d), Text("\n"));
}


/// CaseStruct: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
Text case_struct(const Cp& cp, const Text& gens, const Text& head, const lower::CaseDef& c, const bool& eq, const bool& ord) {
    auto fields = positional_fields(cp, c.fields);
    auto cmps = lexer::join(filter(Array(std::vector{eq
        ? prism_rtl::cat("bool operator==(const ", c.name, "&) const = default;")
        : Text(""), ord
        ? prism_rtl::cat("auto operator<=>(const ", c.name, "&) const = default;")
        : Text("")}), [&](const Text& s) { return s != Text(""); }), Text("\n"));
    return cpp_templates::case_decl(gens, prism_rtl::cat(head, "::", c.name), lexer::join(filter(Array(std::vector{fields, cmps}), [&](const Text& s) { return s != Text(""); }), Text("\n")));
}


prism_rtl::Turn<Text> CaseStruct::cycle() const {
    const auto& cp = this->cp;
    const auto& gens = this->gens;
    const auto& head = this->head;
    const auto& c = this->c;
    const auto& eq = this->eq;
    const auto& ord = this->ord;
    auto c_1 = c;
    auto cp_2 = cp;
    auto eq_3 = eq;
    auto gens_4 = gens;
    auto head_5 = head;
    auto ord_6 = ord;
    return call_then(start_positional_fields(cp_2, c_1.fields), [=](Text positional_fields_61298) {
        return ({
            auto fields = positional_fields_61298;
            auto cmps = lexer::join(filter(Array(std::vector{eq_3
                ? prism_rtl::cat("bool operator==(const ", c_1.name, "&) const = default;")
                : Text(""), ord_6
                ? prism_rtl::cat("auto operator<=>(const ", c_1.name, "&) const = default;")
                : Text("")}), [&](const Text& s) { return s != Text(""); }), Text("\n"));
            (prism_rtl::finished(cpp_templates::case_decl(gens_4, prism_rtl::cat(head_5, "::", c_1.name), lexer::join(filter(Array(std::vector{fields, cmps}), [&](const Text& s) { return s != Text(""); }), Text("\n")))));
        });
    });
}


/// `Start CaseStruct, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_case_struct(Cp cp, Text gens, Text head, lower::CaseDef c, bool eq, bool ord) {
    return std::make_shared<CaseStruct>(cp, gens, head, c, eq, ord);
}


/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
Text type_defs(const Cp& cp, const lower::TyDef& t, const Text& head) {
    auto gens = cpp_template_head(t.params);
    auto show_ = t.show_ == lower::Shown(lower::Shown::ShownDerived{})
        ? Array(std::vector{show_def(cp, t, head, gens)})
        : Array<Text>{};
    auto pod = t.pod
        ? Array(std::vector{to_pod_def(cp, t, head, gens), from_pod_def(cp, t, head, gens)})
        : Array<Text>{};
    return lexer::join(append(show_, pod), Text("\n"));
}


prism_rtl::Turn<Text> TypeDefs::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    const auto& head = this->head;
    auto gens = cpp_template_head(t.params);
    auto show_ = t.show_ == lower::Shown(lower::Shown::ShownDerived{})
        ? Array(std::vector{show_def(cp, t, head, gens)})
        : Array<Text>{};
    auto pod = t.pod
        ? Array(std::vector{to_pod_def(cp, t, head, gens), from_pod_def(cp, t, head, gens)})
        : Array<Text>{};
    return prism_rtl::finished(lexer::join(append(show_, pod), Text("\n")));
}


/// `Start TypeDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_type_defs(Cp cp, lower::TyDef t, Text head) {
    return std::make_shared<TypeDefs>(cp, t, head);
}


/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
Text show_def(const Cp& cp, const lower::TyDef& t, const Text& head, const Text& gens) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (prism_rtl::cat("p.record(\"", t.prism, "\", {", lexer::join(each(c.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field(f), "\", ", field_id(f), "}");
            }), Text(", ")), "});"));
            }));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeChoice>(_m)) {
            _v.set(lexer::join(each(check_errors::range0(len(t.cases_)), [&](const Nat& i) { return show_case(t, i); }), Text("\n")));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case(t), "\", {", lexer::join(each(check_errors::range0(first_arity(t)), [&](const Nat& k) { return prism_rtl::cat("a", k); }), Text(", ")), "});"));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case(t), "\", {});"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return cpp_templates::cpp_function(Text(""), prism_rtl::cat(gens, "void ", head, "::show(Printer& p) const"), body);
}


prism_rtl::Turn<Text> ShowDef::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    const auto& head = this->head;
    const auto& gens = this->gens;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (prism_rtl::cat("p.record(\"", t.prism, "\", {", lexer::join(each(c.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field(f), "\", ", field_id(f), "}");
            }), Text(", ")), "});"));
            }));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeChoice>(_m)) {
            _v.set(lexer::join(each(check_errors::range0(len(t.cases_)), [&](const Nat& i) { return show_case(t, i); }), Text("\n")));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case(t), "\", {", lexer::join(each(check_errors::range0(first_arity(t)), [&](const Nat& k) { return prism_rtl::cat("a", k); }), Text(", ")), "});"));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case(t), "\", {});"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::finished(cpp_templates::cpp_function(Text(""), prism_rtl::cat(gens, "void ", head, "::show(Printer& p) const"), body));
}


/// `Start ShowDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_def(Cp cp, lower::TyDef t, Text head, Text gens) {
    return std::make_shared<ShowDef>(cp, t, head, gens);
}


/// ShowCase: fn TyDef, Nat -> Text
Text show_case(const lower::TyDef& t, const Nat& i) {
    auto c = or_(index(t.cases_, i), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
    auto head = prism_rtl::cat(i == Nat(0u) ? Text("if") : Text("else if"), " (auto c = std::get_if<", c.name, ">(&cases()))");
    return prism_rtl::cat(head, " p.choice(\"", c.prism, "\", {", lexer::join(each(check_errors::range0(len(c.fields)), [&](const Nat& k) { return prism_rtl::cat("c->a", k); }), Text(", ")), "});");
}


/// FirstCase: fn TyDef -> Text
Text first_case(const lower::TyDef& t) {
    return or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text(""), .prism = t.prism, .fields = Array<std::tuple<Text, lower::OutTy>>{}}).prism;
}


/// FirstArity: fn TyDef -> Nat
Nat first_arity(const lower::TyDef& t) {
    return len(or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}}).fields);
}


/// FieldTypes: fn [((Text, OutTy))] -> [OutTy]
Array<lower::OutTy> field_types(const Array<std::tuple<Text, lower::OutTy>>& fs) {
    return each(fs, [&](const std::tuple<Text, lower::OutTy>& _p0) {
        auto&& t = std::get<1>(_p0);
        return t;
    });
}


/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
Text positional_fields(const Cp& cp, const Array<std::tuple<Text, lower::OutTy>>& fs) {
    auto tys = field_types(fs);
    return lexer::join(run_to_end(each_job(check_errors::range0(len(tys)), ({
        auto cp_1 = cp;
        auto tys_2 = tys;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto tys_2_3 = tys_2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_cpp_type(cp_1_3, or_(index(tys_2_3, i), lower::OutTy(lower::OutTy::OutUnit{}))), [=](Text cpp_type_63556) { return prism_rtl::finished(prism_rtl::cat(cpp_type_63556, " a", i, ";")); });
            });
        }));
        });
    })));
    }))), Text("\n"));
}


prism_rtl::Turn<Text> PositionalFields::cycle() const {
    const auto& cp = this->cp;
    const auto& fs = this->fs;
    auto tys = field_types(fs);
    auto cp_1 = cp;
    return call_value(each_job(check_errors::range0(len(tys)), ({
        auto cp_1_2 = cp_1;
        auto tys_2 = tys;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_2_3 = cp_1_2;
            auto tys_2_3 = tys_2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_cpp_type(cp_1_2_3, or_(index(tys_2_3, i), lower::OutTy(lower::OutTy::OutUnit{}))), [=](Text cpp_type_63556) { return prism_rtl::finished(prism_rtl::cat(cpp_type_63556, " a", i, ";")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_63524) { return prism_rtl::finished(lexer::join(each_63524, Text("\n"))); });
}


/// `Start PositionalFields, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_positional_fields(Cp cp, Array<std::tuple<Text, lower::OutTy>> fs) {
    return std::make_shared<PositionalFields>(cp, fs);
}


/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
Text to_pod_def(const Cp& cp, const lower::TyDef& t, const Text& head, const Text& gens) {
    auto structure = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (prism_rtl::cat("Pod::record(\"", t.prism, "\", {", lexer::join(each(c.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field(f), "\", prism_rtl::to_pod(", field_id(f), ")}");
            }), Text(", ")), "})"));
            }));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeChoice>(_m)) {
            _v.set(choice_pod(t));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case(t), "\", {", lexer::join(each(check_errors::range0(first_arity(t)), [&](const Nat& k) { return prism_rtl::cat("prism_rtl::to_pod(a", k, ")"); }), Text(", ")), "})"));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case(t), "\", {})"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto body = t.show_ == lower::Shown(lower::Shown::ShownOwn{})
        ? prism_rtl::cat("Pod structure = ", structure, ";\nreturn Pod::shown(prism_rtl::show(*this), structure);")
        : prism_rtl::cat("return ", structure, ";");
    return cpp_templates::cpp_function(Text(""), prism_rtl::cat(gens, "Pod ", head, "::to_pod() const"), body);
}


prism_rtl::Turn<Text> ToPodDef::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    const auto& head = this->head;
    const auto& gens = this->gens;
    auto structure = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (prism_rtl::cat("Pod::record(\"", t.prism, "\", {", lexer::join(each(c.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field(f), "\", prism_rtl::to_pod(", field_id(f), ")}");
            }), Text(", ")), "})"));
            }));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeChoice>(_m)) {
            _v.set(choice_pod(t));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case(t), "\", {", lexer::join(each(check_errors::range0(first_arity(t)), [&](const Nat& k) { return prism_rtl::cat("prism_rtl::to_pod(a", k, ")"); }), Text(", ")), "})"));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case(t), "\", {})"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto body = t.show_ == lower::Shown(lower::Shown::ShownOwn{})
        ? prism_rtl::cat("Pod structure = ", structure, ";\nreturn Pod::shown(prism_rtl::show(*this), structure);")
        : prism_rtl::cat("return ", structure, ";");
    return prism_rtl::finished(cpp_templates::cpp_function(Text(""), prism_rtl::cat(gens, "Pod ", head, "::to_pod() const"), body));
}


/// `Start ToPodDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_to_pod_def(Cp cp, lower::TyDef t, Text head, Text gens) {
    return std::make_shared<ToPodDef>(cp, t, head, gens);
}


/// ChoicePod: fn TyDef -> Text
Text choice_pod(const lower::TyDef& t) {
    auto arms = each(check_errors::range0(len(t.cases_)), [&](const Nat& i) {
        return ({
            auto c = or_(index(t.cases_, i), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
            (prism_rtl::cat("std::holds_alternative<", c.name, ">(cases()) ? Pod::choice(\"", c.prism, "\", {", lexer::join(each(check_errors::range0(len(c.fields)), [&](const Nat& k) { return prism_rtl::cat("prism_rtl::to_pod(std::get<", c.name, ">(cases()).a", k, ")"); }), Text(", ")), "})"));
        });
    });
    return prism_rtl::cat(lexer::join(arms, Text("\n    : ")), "\n    : Pod()");
}


/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
Text from_pod_def(const Cp& cp, const lower::TyDef& t, const Text& head, const Text& gens) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                auto reads = lexer::join(run_to_end(each_job(c.fields, ({
                    auto cp_1 = cp;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
                    return ({
                        auto cp_1_2 = cp_1;
                        entered(once_job([=]() {
                        return ({
                            auto [f, ft] = p0;
                            call_then(start_cpp_type(cp_1_2, ft), [=](Text cpp_type_65128) { return prism_rtl::finished(prism_rtl::cat(".", field_id(f), " = TRY(prism_rtl::from_pod<", cpp_type_65128, ">(TRY(prelude::field(whole, \"", prism_field(f), "\"))))")); });
                        });
                    }));
                    });
                })));
                }))), Text(", "));
                (prism_rtl::cat("return ", head, "{", reads, "};"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms = run_to_end(each_job(t.cases_, ({
                    auto cp_1 = cp;
                    auto t_2 = t;
                    auto head_3 = head;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::CaseDef)>>(prism_rtl::rc([=](lower::CaseDef p0) {
                    return ({
                        auto cp_1_4 = cp_1;
                        auto t_2_4 = t_2;
                        auto head_3_4 = head_3;
                        entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            ({
                            auto n = len(c.fields);
                            auto tys = field_types(c.fields);
                            call_value(each_job(check_errors::range0(n), ({
                            auto cp_1_4_4 = cp_1_4;
                            auto tys_4 = tys;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                            return ({
                                auto cp_1_4_4_5 = cp_1_4_4;
                                auto tys_4_5 = tys_4;
                                entered(once_job([=]() {
                                return ({
                                    auto i = p0;
                                    call_then(start_cpp_type(cp_1_4_4_5, or_(index(tys_4_5, i), lower::OutTy(lower::OutTy::OutUnit{}))), [=](Text cpp_type_65467) { return prism_rtl::finished(prism_rtl::cat("TRY(prism_rtl::from_pod<", cpp_type_65467, ">(c->args[", i, "]))")); });
                                });
                            }));
                            });
                        })));
                        })), [=](Array<Text> each_65419) {
                            return ({
                                auto args = lexer::join(each_65419, Text(", "));
                                auto made = ({
                                    __label__ _done;
                                    prism_rtl::Slot<Text> _v;
                                    auto&& _m = t_2_4.shape;
                                    if (prism_rtl::is<lower::TyShape::ShapeChoice>(_m)) {
                                        _v.set(prism_rtl::cat(head_3_4, "(", c.name, "{", args, "})"));
                                        goto _done;
                                    }
                                    {
                                        _v.set(prism_rtl::cat(head_3_4, "{", args, "}"));
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                                (prism_rtl::finished(prism_rtl::cat("if (c->ctor == \"", c.prism, "\" && c->args.size() == ", n, ") return ", made, ";")));
                            });
                        });
                        });
                        });
                    }));
                    });
                })));
                })));
                (prism_rtl::cat("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {\n", indent_cpp(lexer::join(arms, Text("\n"))), "\n}\nreturn mismatch<", head, ">(\"a ", t.prism, "\", p);"));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return cpp_templates::cpp_function(Text(""), prism_rtl::cat(gens, "Result<", head, "> ", head, "::from_pod(const Pod& whole)"), body);
}


prism_rtl::Turn<Text> FromPodDef::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    const auto& head = this->head;
    const auto& gens = this->gens;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                auto reads = lexer::join(run_to_end(each_job(c.fields, ({
                    auto cp_1 = cp;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
                    return ({
                        auto cp_1_2 = cp_1;
                        entered(once_job([=]() {
                        return ({
                            auto [f, ft] = p0;
                            call_then(start_cpp_type(cp_1_2, ft), [=](Text cpp_type_65128) { return prism_rtl::finished(prism_rtl::cat(".", field_id(f), " = TRY(prism_rtl::from_pod<", cpp_type_65128, ">(TRY(prelude::field(whole, \"", prism_field(f), "\"))))")); });
                        });
                    }));
                    });
                })));
                }))), Text(", "));
                (prism_rtl::cat("return ", head, "{", reads, "};"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms = run_to_end(each_job(t.cases_, ({
                    auto cp_1 = cp;
                    auto t_2 = t;
                    auto head_3 = head;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::CaseDef)>>(prism_rtl::rc([=](lower::CaseDef p0) {
                    return ({
                        auto cp_1_4 = cp_1;
                        auto t_2_4 = t_2;
                        auto head_3_4 = head_3;
                        entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            ({
                            auto n = len(c.fields);
                            auto tys = field_types(c.fields);
                            call_value(each_job(check_errors::range0(n), ({
                            auto cp_1_4_4 = cp_1_4;
                            auto tys_4 = tys;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                            return ({
                                auto cp_1_4_4_5 = cp_1_4_4;
                                auto tys_4_5 = tys_4;
                                entered(once_job([=]() {
                                return ({
                                    auto i = p0;
                                    call_then(start_cpp_type(cp_1_4_4_5, or_(index(tys_4_5, i), lower::OutTy(lower::OutTy::OutUnit{}))), [=](Text cpp_type_65467) { return prism_rtl::finished(prism_rtl::cat("TRY(prism_rtl::from_pod<", cpp_type_65467, ">(c->args[", i, "]))")); });
                                });
                            }));
                            });
                        })));
                        })), [=](Array<Text> each_65419) {
                            return ({
                                auto args = lexer::join(each_65419, Text(", "));
                                auto made = ({
                                    __label__ _done;
                                    prism_rtl::Slot<Text> _v;
                                    auto&& _m = t_2_4.shape;
                                    if (prism_rtl::is<lower::TyShape::ShapeChoice>(_m)) {
                                        _v.set(prism_rtl::cat(head_3_4, "(", c.name, "{", args, "})"));
                                        goto _done;
                                    }
                                    {
                                        _v.set(prism_rtl::cat(head_3_4, "{", args, "}"));
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                                (prism_rtl::finished(prism_rtl::cat("if (c->ctor == \"", c.prism, "\" && c->args.size() == ", n, ") return ", made, ";")));
                            });
                        });
                        });
                        });
                    }));
                    });
                })));
                })));
                (prism_rtl::cat("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {\n", indent_cpp(lexer::join(arms, Text("\n"))), "\n}\nreturn mismatch<", head, ">(\"a ", t.prism, "\", p);"));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(cpp_templates::cpp_function(Text(""), prism_rtl::cat(gens, "Result<", head, "> ", head, "::from_pod(const Pod& whole)"), body));
}


/// `Start FromPodDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_from_pod_def(Cp cp, lower::TyDef t, Text head, Text gens) {
    return std::make_shared<FromPodDef>(cp, t, head, gens);
}


/// PrismField: fn Text -> Text
Text prism_field(const Text& f) {
    return drop_text(f, lexer::dec(len_text(f))) == Text("_")
        ? take_text(f, lexer::dec(len_text(f)))
        : f;
}


/// IndentCpp: fn Text -> Text
Text indent_cpp(const Text& t) {
    return lexer::join(each(split(t, Text("\n")), [&](const Text& l) { return l == Text("") ? Text("") : prism_rtl::cat("    ", l); }), Text("\n"));
}


/// TagParts: unbounded fn Cp, TagDef -> Parts
Parts tag_parts(const Cp& cp, const lower::TagDef& t) {
    auto fields = lexer::join(run_to_end(each_job(t.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, lower::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto&& _f = p0;
                auto&& f = std::get<1>(_f);
                auto&& ft = std::get<2>(_f);
                call_then(start_cpp_type(cp_1_2, ft), [=](Text cpp_type_66513) { return prism_rtl::finished(prism_rtl::cat(cpp_type_66513, " ", field_id(f), ";")); });
            });
        }));
        });
    })));
    }))), Text("\n"));
    auto pods = lexer::join(each(t.fields, [&](const std::tuple<Text, Text, lower::OutTy>& _p0) {
        auto&& p_ = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        return prism_rtl::cat("{\"", p_, "\", prism_rtl::to_pod(", field_id(f), ")}");
    }), Text(", "));
    auto reads = lexer::join(run_to_end(each_job(t.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, lower::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [p_, f, ft] = p0;
                call_then(start_cpp_type(cp_1_2, ft), [=](Text cpp_type_66753) { return prism_rtl::finished(prism_rtl::cat(".", field_id(f), " = TRY(prism_rtl::from_pod<", cpp_type_66753, ">(TRY(prelude::field(p, \"", p_, "\"))))")); });
            });
        }));
        });
    })));
    }))), Text(", "));
    auto eq = t.pod
        ? prism_rtl::cat("bool operator==(const ", t.name, "&) const = default;")
        : Text("");
    auto back = t.pod
        ? prism_rtl::cat("static Result<", t.name, "> from_pod(const Pod& p);")
        : Text("");
    auto decl = cpp_templates::cpp_tag_struct(cpp_source_doc(prism_rtl::cat("The `Level` of `", t.tag_name, "`:"), t.doc), t.name, fields, t.tag_name, lexer::join(filter(Array(std::vector{eq, back}), [&](const Text& s) { return s != Text(""); }), Text("\n")));
    auto to_pod_1 = cpp_templates::cpp_function(Text(""), prism_rtl::cat("Pod ", t.name, "::to_pod() const"), prism_rtl::cat("return Pod::element(TAG, {", pods, "});"));
    auto show_ = cpp_templates::cpp_function(Text(""), prism_rtl::cat("void ", t.name, "::show(Printer& p) const"), Text("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
    auto from_pod_2 = t.pod
        ? Array(std::vector{cpp_templates::cpp_function(Text(""), prism_rtl::cat("Result<", t.name, "> ", t.name, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag(); t && *t == TAG) return ", t.name, "{", reads, "};\nreturn mismatch<", t.name, ">(\"a ", t.tag_name, "\", p);"))})
        : Array<Text>{};
    auto deps = concat2(run_to_end(each_job(t.fields, ({
        auto cp_3 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, lower::OutTy> p0) {
        return ({
            auto cp_3_4 = cp_3;
            entered(once_job([=]() {
            return ({
                auto&& _ft = p0;
                auto&& ft = std::get<2>(_ft);
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_3_4, ft))));
            });
        }));
        });
    })));
    }))));
    return Parts{.forward = Array(std::vector{prism_rtl::cat("struct ", t.name, ";")}), .handles = Array<Text>{}, .values = Array(std::vector{ValueDecl{.path_ = prism_rtl::cat(cp.home, "::", t.name), .deps = deps, .text = decl}}), .cases_ = Array<Text>{}, .protos = Array<Text>{}, .classes = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{to_pod_1, show_}), from_pod_2)};
}


prism_rtl::Turn<Parts> TagParts::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    auto cp_1 = cp;
    auto t_2 = t;
    return call_value(each_job(t_2.fields, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, lower::OutTy> p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto&& _f = p0;
                auto&& f = std::get<1>(_f);
                auto&& ft = std::get<2>(_f);
                call_then(start_cpp_type(cp_1_3_3, ft), [=](Text cpp_type_66513) { return prism_rtl::finished(prism_rtl::cat(cpp_type_66513, " ", field_id(f), ";")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_66475) {
        return ({
            auto fields = lexer::join(each_66475, Text("\n"));
            auto pods = lexer::join(each(t_2.fields, [&](const std::tuple<Text, Text, lower::OutTy>& _p0) {
                auto&& p_ = std::get<0>(_p0);
                auto&& f = std::get<1>(_p0);
                return prism_rtl::cat("{\"", p_, "\", prism_rtl::to_pod(", field_id(f), ")}");
            }), Text(", "));
            call_value(each_job(t_2.fields, ({
            auto cp_1_3 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, lower::OutTy> p0) {
            return ({
                auto cp_1_3_3 = cp_1_3;
                entered(once_job([=]() {
                return ({
                    auto [p_, f, ft] = p0;
                    call_then(start_cpp_type(cp_1_3_3, ft), [=](Text cpp_type_66753) { return prism_rtl::finished(prism_rtl::cat(".", field_id(f), " = TRY(prism_rtl::from_pod<", cpp_type_66753, ">(TRY(prelude::field(p, \"", p_, "\"))))")); });
                });
            }));
            });
        })));
        })), [=](Array<Text> each_66681) {
            return ({
                auto reads = lexer::join(each_66681, Text(", "));
                auto eq = t_2.pod
                    ? prism_rtl::cat("bool operator==(const ", t_2.name, "&) const = default;")
                    : Text("");
                auto back = t_2.pod
                    ? prism_rtl::cat("static Result<", t_2.name, "> from_pod(const Pod& p);")
                    : Text("");
                auto decl = cpp_templates::cpp_tag_struct(cpp_source_doc(prism_rtl::cat("The `Level` of `", t_2.tag_name, "`:"), t_2.doc), t_2.name, fields, t_2.tag_name, lexer::join(filter(Array(std::vector{eq, back}), [&](const Text& s) { return s != Text(""); }), Text("\n")));
                auto to_pod_3 = cpp_templates::cpp_function(Text(""), prism_rtl::cat("Pod ", t_2.name, "::to_pod() const"), prism_rtl::cat("return Pod::element(TAG, {", pods, "});"));
                auto show_ = cpp_templates::cpp_function(Text(""), prism_rtl::cat("void ", t_2.name, "::show(Printer& p) const"), Text("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
                auto from_pod_4 = t_2.pod
                    ? Array(std::vector{cpp_templates::cpp_function(Text(""), prism_rtl::cat("Result<", t_2.name, "> ", t_2.name, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag(); t && *t == TAG) return ", t_2.name, "{", reads, "};\nreturn mismatch<", t_2.name, ">(\"a ", t_2.tag_name, "\", p);"))})
                    : Array<Text>{};
                call_value(each_job(t_2.fields, ({
                auto cp_1_5 = cp_1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, lower::OutTy> p0) {
                return ({
                    auto cp_1_5_5 = cp_1_5;
                    entered(once_job([=]() {
                    return ({
                        auto&& _ft = p0;
                        auto&& ft = std::get<2>(_ft);
                        (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_5_5, ft))));
                    });
                }));
                });
            })));
            })), [=](Array<Array<Text>> each_67658) {
                return ({
                    auto deps = concat2(each_67658);
                    (prism_rtl::finished(Parts{.forward = Array(std::vector{prism_rtl::cat("struct ", t_2.name, ";")}), .handles = Array<Text>{}, .values = Array(std::vector{ValueDecl{.path_ = prism_rtl::cat(cp_1.home, "::", t_2.name), .deps = deps, .text = decl}}), .cases_ = Array<Text>{}, .protos = Array<Text>{}, .classes = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{to_pod_3, show_}), from_pod_4)}));
                });
            });
            });
        });
        });
    });
}


/// `Start TagParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_tag_parts(Cp cp, lower::TagDef t) {
    return std::make_shared<TagParts>(cp, t);
}


/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
Parts row_parts(const Cp& cp, const Text& m, const lower::RowDef& r) {
    auto names = each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        return v_;
    });
    auto pod = prism_rtl::cat("Pod to_pod() const;\nvoid show(Printer& p) const;", r.pod
        ? prism_rtl::cat("\nstatic Result<", r.name, "> from_pod(const Pod& p);")
        : Text(""));
    auto handle = cpp_templates::choice_handle(cpp_source_doc(prism_rtl::cat("`", r.prism, "`, a row kind's values:"), r.doc), Text(""), r.name, lexer::join(each(names, [&](const Text& n) { return prism_rtl::cat("struct ", n, ";"); }), Text("\n")), lexer::join(names, Text(", ")), pod);
    auto cases = each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return cpp_templates::case_decl(Text(""), prism_rtl::cat(r.name, "::", v_), prism_rtl::cat(row_struct(m, st), " a0;", r.pod
            ? prism_rtl::cat("\nbool operator==(const ", v_, "&) const = default;")
            : Text("")));
    });
    auto eq = r.pod
        ? Array(std::vector{prism_rtl::cat("inline bool operator==(const ", r.name, "& a, const ", r.name, "& b) { return a.cases() == b.cases(); }")})
        : Array<Text>{};
    auto to_pod_1 = cpp_templates::cpp_function(Text(""), prism_rtl::cat("Pod ", r.name, "::to_pod() const"), Text("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
    auto show_ = cpp_templates::cpp_function(Text(""), prism_rtl::cat("void ", r.name, "::show(Printer& p) const"), Text("Show<Pod>::show(to_pod(), p);"));
    auto reads = lexer::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat("if (*t == ", row_struct(m, st), "::TAG) return ", r.name, "(", v_, "{TRY(prism_rtl::from_pod<", row_struct(m, st), ">(p))});");
    }), Text("\n"));
    auto from_pod_2 = r.pod
        ? Array(std::vector{cpp_templates::cpp_function(Text(""), prism_rtl::cat("Result<", r.name, "> ", r.name, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag()) {\n", indent_cpp(reads), "\n}\nreturn mismatch<", r.name, ">(\"a ", r.name, "\", p);"))})
        : Array<Text>{};
    return Parts{.forward = Array(std::vector{prism_rtl::cat("class ", r.name, ";")}), .handles = Array(std::vector{handle}), .values = Array<ValueDecl>{}, .cases_ = append(prelude::push(cases, cases_accessor(Text(""), r.name)), eq), .protos = Array<Text>{}, .classes = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{to_pod_1, show_}), from_pod_2)};
}


prism_rtl::Turn<Parts> RowParts::cycle() const {
    const auto& cp = this->cp;
    const auto& m = this->m;
    const auto& r = this->r;
    auto names = each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        return v_;
    });
    auto pod = prism_rtl::cat("Pod to_pod() const;\nvoid show(Printer& p) const;", r.pod
        ? prism_rtl::cat("\nstatic Result<", r.name, "> from_pod(const Pod& p);")
        : Text(""));
    auto handle = cpp_templates::choice_handle(cpp_source_doc(prism_rtl::cat("`", r.prism, "`, a row kind's values:"), r.doc), Text(""), r.name, lexer::join(each(names, [&](const Text& n) { return prism_rtl::cat("struct ", n, ";"); }), Text("\n")), lexer::join(names, Text(", ")), pod);
    auto cases = each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return cpp_templates::case_decl(Text(""), prism_rtl::cat(r.name, "::", v_), prism_rtl::cat(row_struct(m, st), " a0;", r.pod
            ? prism_rtl::cat("\nbool operator==(const ", v_, "&) const = default;")
            : Text("")));
    });
    auto eq = r.pod
        ? Array(std::vector{prism_rtl::cat("inline bool operator==(const ", r.name, "& a, const ", r.name, "& b) { return a.cases() == b.cases(); }")})
        : Array<Text>{};
    auto to_pod_1 = cpp_templates::cpp_function(Text(""), prism_rtl::cat("Pod ", r.name, "::to_pod() const"), Text("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
    auto show_ = cpp_templates::cpp_function(Text(""), prism_rtl::cat("void ", r.name, "::show(Printer& p) const"), Text("Show<Pod>::show(to_pod(), p);"));
    auto reads = lexer::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat("if (*t == ", row_struct(m, st), "::TAG) return ", r.name, "(", v_, "{TRY(prism_rtl::from_pod<", row_struct(m, st), ">(p))});");
    }), Text("\n"));
    auto from_pod_2 = r.pod
        ? Array(std::vector{cpp_templates::cpp_function(Text(""), prism_rtl::cat("Result<", r.name, "> ", r.name, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag()) {\n", indent_cpp(reads), "\n}\nreturn mismatch<", r.name, ">(\"a ", r.name, "\", p);"))})
        : Array<Text>{};
    return prism_rtl::finished(Parts{.forward = Array(std::vector{prism_rtl::cat("class ", r.name, ";")}), .handles = Array(std::vector{handle}), .values = Array<ValueDecl>{}, .cases_ = append(prelude::push(cases, cases_accessor(Text(""), r.name)), eq), .protos = Array<Text>{}, .classes = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{to_pod_1, show_}), from_pod_2)});
}


/// `Start RowParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_row_parts(Cp cp, Text m, lower::RowDef r) {
    return std::make_shared<RowParts>(cp, m, r);
}


/// RowStruct: fn Text, Text -> Text
Text row_struct(const Text& m, const Text& st) {
    return lexer::contains(st, Text(":")) || (m == Text(""))
        ? type_path(st)
        : prism_rtl::cat("crate::", m, "::", st);
}


/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
Parts answer_parts(const Cp& cp, const lower::AnswerDef& a) {
    auto names = each(a.cases_, [&](const lower::AnswerCase& c) { return c.variant; });
    auto accessors = lexer::join(run_to_end(each_job(a.cases_, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::AnswerCase)>>(prism_rtl::rc([=](lower::AnswerCase p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(start_cpp_type(cp_1_2, c.ty), [=](Text cpp_type_70171) { return prism_rtl::finished(prism_rtl::cat("Result<", cpp_type_70171, "> ", c.accessor, "() const;")); });
            });
        }));
        });
    })));
    }))), Text("\n"));
    auto members_ = prism_rtl::cat("const char* tag() const;\n", accessors, "\nstatic Result<Answer> decode(const Elem& e, const Pod& v);");
    auto handle = cpp_templates::choice_handle(cpp_doc(Text("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host's\nsupplier answers a child place with, and what a World's answer to a forwarded element\ndecodes to, carrying the tag's output.")), Text(""), Text("Answer"), lexer::join(each(names, [&](const Text& n) { return prism_rtl::cat("struct ", n, ";"); }), Text("\n")), lexer::join(names, Text(", ")), members_);
    auto cases = run_to_end(each_job(a.cases_, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::AnswerCase)>>(prism_rtl::rc([=](lower::AnswerCase p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(start_cpp_type(cp_1_2, c.ty), [=](Text cpp_type_70756) { return prism_rtl::finished(cpp_templates::case_decl(Text(""), prism_rtl::cat("Answer::", c.variant), prism_rtl::cat(cpp_type_70756, " a0;"))); });
            });
        }));
        });
    })));
    })));
    auto tags = lexer::join(each(a.cases_, [&](const lower::AnswerCase& c) { return prism_rtl::cat("if (std::holds_alternative<", c.variant, ">(cases())) return ", type_path(c.struct_path), "::TAG;"); }), Text("\n"));
    auto tag_fn = cpp_templates::cpp_function(Text(""), Text("const char* Answer::tag() const"), prism_rtl::cat(tags, "\nprism_rtl::unreachable();"));
    auto getters = run_to_end(each_job(a.cases_, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::AnswerCase)>>(prism_rtl::rc([=](lower::AnswerCase p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(start_cpp_type(cp_1_2, c.ty), [=](Text cpp_type_71114) { return prism_rtl::finished(cpp_templates::cpp_function(cpp_doc(prism_rtl::cat("A `", c.tag_name, "`'s answer.")), prism_rtl::cat("Result<", cpp_type_71114, "> Answer::", c.accessor, "() const"), prism_rtl::cat("if (auto c = std::get_if<", c.variant, ">(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where ", c.tag_name, "'s was expected\")));"))); });
            });
        }));
        });
    })));
    })));
    auto decodes = lexer::join(run_to_end(each_job(a.cases_, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::AnswerCase)>>(prism_rtl::rc([=](lower::AnswerCase p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(start_cpp_type(cp_1_2, c.ty), [=](Text cpp_type_71462) { return prism_rtl::finished(prism_rtl::cat("if (is<Elem::", c.variant, ">(e)) return Answer(", c.variant, "{TRY(prism_rtl::from_pod<", cpp_type_71462, ">(v))});")); });
            });
        }));
        });
    })));
    }))), Text("\n"));
    auto decode_1 = cpp_templates::cpp_function(cpp_doc(Text("A World's answer to the element `e`, decoded by its tag.")), Text("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), prism_rtl::cat(decodes, "\nprism_rtl::unreachable();"));
    return Parts{.forward = Array(std::vector{Text("class Answer;")}), .handles = Array(std::vector{handle}), .values = Array<ValueDecl>{}, .cases_ = prelude::push(cases, cases_accessor(Text(""), Text("Answer"))), .protos = Array<Text>{}, .classes = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{tag_fn}), prelude::push(getters, decode_1))};
}


prism_rtl::Turn<Parts> AnswerParts::cycle() const {
    const auto& cp = this->cp;
    const auto& a = this->a;
    auto names = each(a.cases_, [&](const lower::AnswerCase& c) { return c.variant; });
    auto a_1 = a;
    auto cp_2 = cp;
    return call_value(each_job(a_1.cases_, ({
        auto cp_2_3 = cp_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::AnswerCase)>>(prism_rtl::rc([=](lower::AnswerCase p0) {
        return ({
            auto cp_2_3_3 = cp_2_3;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(start_cpp_type(cp_2_3_3, c.ty), [=](Text cpp_type_70171) { return prism_rtl::finished(prism_rtl::cat("Result<", cpp_type_70171, "> ", c.accessor, "() const;")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_70143) {
        return ({
            auto accessors = lexer::join(each_70143, Text("\n"));
            auto members_ = prism_rtl::cat("const char* tag() const;\n", accessors, "\nstatic Result<Answer> decode(const Elem& e, const Pod& v);");
            auto handle = cpp_templates::choice_handle(cpp_doc(Text("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host's\nsupplier answers a child place with, and what a World's answer to a forwarded element\ndecodes to, carrying the tag's output.")), Text(""), Text("Answer"), lexer::join(each(names, [&](const Text& n) { return prism_rtl::cat("struct ", n, ";"); }), Text("\n")), lexer::join(names, Text(", ")), members_);
            call_value(each_job(a_1.cases_, ({
            auto cp_2_3 = cp_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::AnswerCase)>>(prism_rtl::rc([=](lower::AnswerCase p0) {
            return ({
                auto cp_2_3_3 = cp_2_3;
                entered(once_job([=]() {
                return ({
                    auto c = p0;
                    call_then(start_cpp_type(cp_2_3_3, c.ty), [=](Text cpp_type_70756) { return prism_rtl::finished(cpp_templates::case_decl(Text(""), prism_rtl::cat("Answer::", c.variant), prism_rtl::cat(cpp_type_70756, " a0;"))); });
                });
            }));
            });
        })));
        })), [=](Array<Text> each_70699) {
            return ({
                auto cases = each_70699;
                auto tags = lexer::join(each(a_1.cases_, [&](const lower::AnswerCase& c) { return prism_rtl::cat("if (std::holds_alternative<", c.variant, ">(cases())) return ", type_path(c.struct_path), "::TAG;"); }), Text("\n"));
                auto tag_fn = cpp_templates::cpp_function(Text(""), Text("const char* Answer::tag() const"), prism_rtl::cat(tags, "\nprism_rtl::unreachable();"));
                call_value(each_job(a_1.cases_, ({
                auto cp_2_3 = cp_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::AnswerCase)>>(prism_rtl::rc([=](lower::AnswerCase p0) {
                return ({
                    auto cp_2_3_3 = cp_2_3;
                    entered(once_job([=]() {
                    return ({
                        auto c = p0;
                        call_then(start_cpp_type(cp_2_3_3, c.ty), [=](Text cpp_type_71114) { return prism_rtl::finished(cpp_templates::cpp_function(cpp_doc(prism_rtl::cat("A `", c.tag_name, "`'s answer.")), prism_rtl::cat("Result<", cpp_type_71114, "> Answer::", c.accessor, "() const"), prism_rtl::cat("if (auto c = std::get_if<", c.variant, ">(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where ", c.tag_name, "'s was expected\")));"))); });
                    });
                }));
                });
            })));
            })), [=](Array<Text> each_71036) {
                return ({
                    auto getters = each_71036;
                    call_value(each_job(a_1.cases_, ({
                    auto cp_2_3 = cp_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::AnswerCase)>>(prism_rtl::rc([=](lower::AnswerCase p0) {
                    return ({
                        auto cp_2_3_3 = cp_2_3;
                        entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            call_then(start_cpp_type(cp_2_3_3, c.ty), [=](Text cpp_type_71462) { return prism_rtl::finished(prism_rtl::cat("if (is<Elem::", c.variant, ">(e)) return Answer(", c.variant, "{TRY(prism_rtl::from_pod<", cpp_type_71462, ">(v))});")); });
                        });
                    }));
                    });
                })));
                })), [=](Array<Text> each_71360) {
                    return ({
                        auto decodes = lexer::join(each_71360, Text("\n"));
                        auto decode_3 = cpp_templates::cpp_function(cpp_doc(Text("A World's answer to the element `e`, decoded by its tag.")), Text("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), prism_rtl::cat(decodes, "\nprism_rtl::unreachable();"));
                        (prism_rtl::finished(Parts{.forward = Array(std::vector{Text("class Answer;")}), .handles = Array(std::vector{handle}), .values = Array<ValueDecl>{}, .cases_ = prelude::push(cases, cases_accessor(Text(""), Text("Answer"))), .protos = Array<Text>{}, .classes = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{tag_fn}), prelude::push(getters, decode_3))}));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start AnswerParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_answer_parts(Cp cp, lower::AnswerDef a) {
    return std::make_shared<AnswerParts>(cp, a);
}


/// JobParts: unbounded fn Cp, JobDef -> Parts
Parts job_parts(const Cp& cp, const lower::JobDef& j) {
    auto gens = cpp_template_head(generic_names_of(j.generics));
    auto head = head_of(j.name, generic_names_of(j.generics));
    auto jcp = with_fields(cp, j.fields);
    auto fields = lexer::join(run_to_end(each_job(j.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_cpp_type(cp_1_2, t), [=](Text cpp_type_72241) { return prism_rtl::finished(prism_rtl::cat(cpp_type_72241, " ", field_id(n), ";")); });
            });
        }));
        });
    })));
    }))), Text("\n"));
    auto params = lexer::join(run_to_end(each_job(j.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_cpp_type(cp_1_2, t), [=](Text cpp_type_72329) { return prism_rtl::finished(prism_rtl::cat(cpp_type_72329, " ", field_id(n))); });
            });
        }));
        });
    })));
    }))), Text(", "));
    auto inits = lexer::join(each(j.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
        auto&& n = std::get<0>(_p0);
        return prism_rtl::cat(field_id(n), "(std::move(", field_id(n), "))");
    }), Text(", "));
    auto ctor = len(j.fields) == Nat(0u)
        ? Text("")
        : prism_rtl::cat(j.name, "(", params, ") : ", inits, " {}");
    auto ret = cpp_type(cp, j.ret);
    auto decl = cpp_templates::job_struct(cpp_doc(j.doc), gens, j.name, ret, fields, ctor);
    auto cycle_1 = cpp_templates::cpp_function(Text(""), prism_rtl::cat(gens, "prism_rtl::Turn<", ret, "> ", head, "::cycle() const"), cpp_body(jcp, j.body));
    auto start = cpp_templates::cpp_function(cpp_doc(prism_rtl::cat("`Start ", j.name, ", x`: what the function value is when passed to `@Run`.")), prism_rtl::cat(gens, "prism_rtl::JobRef<", ret, "> ", j.start, "(", params, ")"), prism_rtl::cat("return std::make_shared<", head, ">(", lexer::join(each(j.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
        auto&& n = std::get<0>(_p0);
        return field_id(n);
    }), Text(", ")), ");"));
    auto generic = len(j.generics) > Nat(0u);
    return Parts{.forward = Array(std::vector{prism_rtl::cat(gens, "struct ", j.name, ";")}), .handles = Array<Text>{}, .values = Array<ValueDecl>{}, .cases_ = Array<Text>{}, .protos = generic
        ? Array<Text>{}
        : Array(std::vector{prism_rtl::cat("prism_rtl::JobRef<", ret, "> ", j.start, "(", params, ");")}), .classes = Array(std::vector{decl}), .generic = generic ? Array(std::vector{cycle_1, start}) : Array<Text>{}, .defs = generic ? Array<Text>{} : Array(std::vector{cycle_1, start})};
}


prism_rtl::Turn<Parts> JobParts::cycle() const {
    const auto& cp = this->cp;
    const auto& j = this->j;
    auto gens = cpp_template_head(generic_names_of(j.generics));
    auto head = head_of(j.name, generic_names_of(j.generics));
    auto jcp = with_fields(cp, j.fields);
    auto cp_1 = cp;
    auto j_2 = j;
    return call_value(each_job(j_2.fields, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_cpp_type(cp_1_3_3, t), [=](Text cpp_type_72241) { return prism_rtl::finished(prism_rtl::cat(cpp_type_72241, " ", field_id(n), ";")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_72212) {
        return ({
            auto fields = lexer::join(each_72212, Text("\n"));
            call_value(each_job(j_2.fields, ({
            auto cp_1_3 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
            return ({
                auto cp_1_3_3 = cp_1_3;
                entered(once_job([=]() {
                return ({
                    auto [n, t] = p0;
                    call_then(start_cpp_type(cp_1_3_3, t), [=](Text cpp_type_72329) { return prism_rtl::finished(prism_rtl::cat(cpp_type_72329, " ", field_id(n))); });
                });
            }));
            });
        })));
        })), [=](Array<Text> each_72300) {
            return ({
                auto params = lexer::join(each_72300, Text(", "));
                auto inits = lexer::join(each(j_2.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                    auto&& n = std::get<0>(_p0);
                    return prism_rtl::cat(field_id(n), "(std::move(", field_id(n), "))");
                }), Text(", "));
                auto ctor = len(j_2.fields) == Nat(0u)
                    ? Text("")
                    : prism_rtl::cat(j_2.name, "(", params, ") : ", inits, " {}");
                call_then(start_cpp_type(cp_1, j_2.ret), [=](Text cpp_type_72561) {
                return ({
                    auto ret = cpp_type_72561;
                    auto decl = cpp_templates::job_struct(cpp_doc(j_2.doc), gens, j_2.name, ret, fields, ctor);
                    call_then(start_cpp_body(jcp, j_2.body), [=](Text cpp_body_72739) {
                    return ({
                        auto cycle_3 = cpp_templates::cpp_function(Text(""), prism_rtl::cat(gens, "prism_rtl::Turn<", ret, "> ", head, "::cycle() const"), cpp_body_72739);
                        auto start = cpp_templates::cpp_function(cpp_doc(prism_rtl::cat("`Start ", j_2.name, ", x`: what the function value is when passed to `@Run`.")), prism_rtl::cat(gens, "prism_rtl::JobRef<", ret, "> ", j_2.start, "(", params, ")"), prism_rtl::cat("return std::make_shared<", head, ">(", lexer::join(each(j_2.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                            auto&& n = std::get<0>(_p0);
                            return field_id(n);
                        }), Text(", ")), ");"));
                        auto generic = len(j_2.generics) > Nat(0u);
                        (prism_rtl::finished(Parts{.forward = Array(std::vector{prism_rtl::cat(gens, "struct ", j_2.name, ";")}), .handles = Array<Text>{}, .values = Array<ValueDecl>{}, .cases_ = Array<Text>{}, .protos = generic
                        ? Array<Text>{}
                        : Array(std::vector{prism_rtl::cat("prism_rtl::JobRef<", ret, "> ", j_2.start, "(", params, ");")}), .classes = Array(std::vector{decl}), .generic = generic ? Array(std::vector{cycle_3, start}) : Array<Text>{}, .defs = generic ? Array<Text>{} : Array(std::vector{cycle_3, start})}));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start JobParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_job_parts(Cp cp, lower::JobDef j) {
    return std::make_shared<JobParts>(cp, j);
}


/// TraitParts: unbounded fn Cp, TraitDef -> Parts
Parts trait_parts(const Cp& cp, const lower::TraitDef& t) {
    auto defaults = filter(t.methods, [&](const lower::FnDef& f) { return f.public_; });
    auto defs = run_to_end(each_job(defaults, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(FnDefinition(cp_1_2, with_generics(f, Array(std::vector{std::tuple{Text("Self"), Array<Text>{}}}))))));
            });
        }));
        });
    })));
    })));
    return generic_only(Array(std::vector{cpp_templates::trait_namespace(t.name, lexer::join(defs, Text("\n")))}));
}


prism_rtl::Turn<Parts> TraitParts::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    auto defaults = filter(t.methods, [&](const lower::FnDef& f) { return f.public_; });
    auto cp_1 = cp;
    auto t_2 = t;
    return call_value(each_job(defaults, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(FnDefinition(cp_1_3_3, with_generics(f, Array(std::vector{std::tuple{Text("Self"), Array<Text>{}}}))))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_73630) {
        return ({
            auto defs = each_73630;
            (prism_rtl::finished(generic_only(Array(std::vector{cpp_templates::trait_namespace(t_2.name, lexer::join(defs, Text("\n")))}))));
        });
    });
}


/// `Start TraitParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_trait_parts(Cp cp, lower::TraitDef t) {
    return std::make_shared<TraitParts>(cp, t);
}


/// ImplParts: unbounded fn Cp, ImplDef -> Parts
Parts impl_parts(const Cp& cp, const lower::ImplDef& i) {
    auto head = cpp_type(cp, i.head);
    auto gens = cpp_template_head(generic_names_of(i.generics));
    auto fns = run_to_end(each_job(i.methods, ({
        auto cp_1 = cp;
        auto i_2 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto i_2_3 = i_2;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(FnParts(cp_1_3, with_generics(f, i_2_3.generics)))));
            });
        }));
        });
    })));
    })));
    auto own = fold(fns, no_parts(), [&](const Parts& acc, const Parts& p_) { return join_parts(acc, p_); });
    return ({
        __label__ _done;
        prism_rtl::Slot<Parts> _v;
        auto&& _m = i.cls;
        {
            auto&& m74214_0 = _m;
            if (m74214_0 == Text("Prelude.Show")) {
                _v.set(({
                    auto shown = or_(index(each(i.methods, [&](const lower::FnDef& f) { return f.name; }), Nat(0u)), Text("show"));
                    join_parts(own, protos_defs(Array<Text>{}, Array(std::vector{cpp_templates::cpp_function(Text(""), prism_rtl::cat(gens, "void ", head, "::show(Printer& p) const"), prism_rtl::cat("p.raw(", shown, "(*this).to_string());"))})));
                }));
                goto _done;
            }
        }
        {
            auto&& m74214_1 = _m;
            if (m74214_1 == Text("Prelude.Eq")) {
                _v.set(({
                    auto eq = fold(i.methods, Text(""), [&](const Text& acc, const lower::FnDef& f) {
                        return (take_text(f.name, Nat(2u)) != Text("ne")) && (acc == Text(""))
                            ? f.name
                            : acc;
                    });
                    join_parts(own, protos_defs(Array(std::vector{prism_rtl::cat(gens, "bool operator==(const ", head, "& a, const ", head, "& b);")}), Array(std::vector{cpp_templates::cpp_function(Text(""), prism_rtl::cat(gens, "bool operator==(const ", head, "& a, const ", head, "& b)"), prism_rtl::cat("return ", eq, "(a, b);"))})));
                }));
                goto _done;
            }
        }
        {
            _v.set(({
                auto tr = type_path(i.tr);
                auto in_trait = run_to_end(each_job(i.methods, ({
                    auto tr_1 = tr;
                    auto cp_2 = cp;
                    auto i_3 = i;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
                    return ({
                        auto tr_1_4 = tr_1;
                        auto cp_2_4 = cp_2;
                        auto i_3_4 = i_3;
                        entered(once_job([=]() {
                        return ({
                            auto f = p0;
                            call_then(start_fn_definition(cp_2_4, with_generics(f, i_3_4.generics)), [=](Text fn_definition_74929) { return prism_rtl::finished(cpp_templates::trait_namespace(tr_1_4, fn_definition_74929)); });
                        });
                    }));
                    });
                })));
                })));
                auto protos = run_to_end(each_job(i.methods, ({
                    auto tr_1 = tr;
                    auto cp_2 = cp;
                    auto i_3 = i;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
                    return ({
                        auto tr_1_4 = tr_1;
                        auto cp_2_4 = cp_2;
                        auto i_3_4 = i_3;
                        entered(once_job([=]() {
                        return ({
                            auto f = p0;
                            call_then(start_fn_signature(cp_2_4, with_generics(f, i_3_4.generics)), [=](Text fn_signature_75043) { return prism_rtl::finished(cpp_templates::trait_namespace(tr_1_4, prism_rtl::cat(fn_signature_75043, ";"))); });
                        });
                    }));
                    });
                })));
                })));
                protos_defs(protos, in_trait);
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Parts> ImplParts::cycle() const {
    const auto& cp = this->cp;
    const auto& i = this->i;
    auto cp_1 = cp;
    auto i_2 = i;
    return call_then(start_cpp_type(cp_1, i_2.head), [=](Text cpp_type_73996) {
        return ({
            auto head = cpp_type_73996;
            auto gens = cpp_template_head(generic_names_of(i_2.generics));
            call_value(each_job(i_2.methods, ({
            auto cp_1_3 = cp_1;
            auto i_2_3 = i_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
            return ({
                auto cp_1_3_3 = cp_1_3;
                auto i_2_3_3 = i_2_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    (prism_rtl::more(prism_rtl::rc(FnParts(cp_1_3_3, with_generics(f, i_2_3_3.generics)))));
                });
            }));
            });
        })));
        })), [=](Array<Parts> each_74088) {
            return ({
                auto fns = each_74088;
                auto own = fold(fns, no_parts(), [&](const Parts& acc, const Parts& p_) { return join_parts(acc, p_); });
                ({
                auto&& _m = i_2.cls;
                ({
                auto&& m74214_0 = _m;
                (m74214_0 == Text("Prelude.Show"));
            }) ? ({
                auto&& m74214_0 = _m;
                ({
                auto shown = or_(index(each(i_2.methods, [&](const lower::FnDef& f) { return f.name; }), Nat(0u)), Text("show"));
                (prism_rtl::finished(join_parts(own, protos_defs(Array<Text>{}, Array(std::vector{cpp_templates::cpp_function(Text(""), prism_rtl::cat(gens, "void ", head, "::show(Printer& p) const"), prism_rtl::cat("p.raw(", shown, "(*this).to_string());"))})))));
            });
            })
                : ({
                auto&& m74214_1 = _m;
                (m74214_1 == Text("Prelude.Eq"));
            }) ? ({
                auto&& m74214_1 = _m;
                ({
                auto eq = fold(i_2.methods, Text(""), [&](const Text& acc, const lower::FnDef& f) {
                    return (take_text(f.name, Nat(2u)) != Text("ne")) && (acc == Text(""))
                        ? f.name
                        : acc;
                });
                (prism_rtl::finished(join_parts(own, protos_defs(Array(std::vector{prism_rtl::cat(gens, "bool operator==(const ", head, "& a, const ", head, "& b);")}), Array(std::vector{cpp_templates::cpp_function(Text(""), prism_rtl::cat(gens, "bool operator==(const ", head, "& a, const ", head, "& b)"), prism_rtl::cat("return ", eq, "(a, b);"))})))));
            });
            })
                : ({
                auto tr = type_path(i_2.tr);
                call_value(each_job(i_2.methods, ({
                auto tr_3 = tr;
                auto cp_1_4 = cp_1;
                auto i_2_4 = i_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
                return ({
                    auto tr_3_4 = tr_3;
                    auto cp_1_4_4 = cp_1_4;
                    auto i_2_4_4 = i_2_4;
                    entered(once_job([=]() {
                    return ({
                        auto f = p0;
                        call_then(start_fn_definition(cp_1_4_4, with_generics(f, i_2_4_4.generics)), [=](Text fn_definition_74929) { return prism_rtl::finished(cpp_templates::trait_namespace(tr_3_4, fn_definition_74929)); });
                    });
                }));
                });
            })));
            })), [=](Array<Text> each_74888) {
                return ({
                    auto in_trait = each_74888;
                    call_value(each_job(i_2.methods, ({
                    auto tr_3 = tr;
                    auto cp_1_4 = cp_1;
                    auto i_2_4 = i_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
                    return ({
                        auto tr_3_4 = tr_3;
                        auto cp_1_4_4 = cp_1_4;
                        auto i_2_4_4 = i_2_4;
                        entered(once_job([=]() {
                        return ({
                            auto f = p0;
                            call_then(start_fn_signature(cp_1_4_4, with_generics(f, i_2_4_4.generics)), [=](Text fn_signature_75043) { return prism_rtl::finished(cpp_templates::trait_namespace(tr_3_4, prism_rtl::cat(fn_signature_75043, ";"))); });
                        });
                    }));
                    });
                })));
                })), [=](Array<Text> each_75001) {
                    return ({
                        auto protos = each_75001;
                        (prism_rtl::finished(protos_defs(protos, in_trait)));
                    });
                });
                });
            });
            });
            });
            });
        });
        });
    });
}


/// `Start ImplParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_impl_parts(Cp cp, lower::ImplDef i) {
    return std::make_shared<ImplParts>(cp, i);
}


/// WithGenerics: fn FnDef, [((Text, [Text]))] -> FnDef
lower::FnDef with_generics(const lower::FnDef& f, const Array<std::tuple<Text, Array<Text>>>& gs) {
    lower::FnDef this_ = f;
    this_.generics = append(gs, this_.generics);
    return this_;
}


/// GenericOnly: fn [Text] -> Parts
Parts generic_only(const Array<Text>& xs) {
    Parts this_ = no_parts();
    this_.generic = xs;
    return this_;
}


/// ProtosDefs: fn [Text], [Text] -> Parts
Parts protos_defs(const Array<Text>& ps, const Array<Text>& ds) {
    Parts this_ = no_parts();
    this_.protos = ps;
    this_.defs = ds;
    return this_;
}


/// NodeParts: unbounded fn Cp, NodeDef -> Parts
Parts node_parts(const Cp& cp, const lower::NodeDef& n) {
    auto ncp = with_fields(cp, each(n.fields, [&](const std::tuple<Text, lower::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& t = std::get<1>(_p0);
        return std::tuple{f, t};
    }));
    auto base = (n.row_kind == lower::RowKind(lower::RowKind::NotARow{})) && (len(n.hosted) == Nat(0u))
        ? Text("Node")
        : Text("Row");
    auto fields = lexer::join(run_to_end(each_job(n.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy, Text>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy, Text> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [f, t, doc] = p0;
                call_then(start_cpp_type(cp_1_2, t), [=](Text cpp_type_76019) { return prism_rtl::finished(prism_rtl::cat(cpp_doc(doc), "mutable ", cpp_type_76019, " ", field_id(f), ";")); });
            });
        }));
        });
    })));
    }))), Text("\n"));
    auto consts = lexer::join(each(n.consts, [&](const std::tuple<Text, Nat, Text>& _p0) {
        auto&& c = std::get<0>(_p0);
        auto&& h = std::get<1>(_p0);
        auto&& doc = std::get<2>(_p0);
        return prism_rtl::cat(cpp_doc(prism_rtl::cat("The ", doc, ".")), "static constexpr std::uint32_t ", c, " = ", h, ";");
    }), Text("\n"));
    auto ctor_params = lexer::join(append(Array(std::vector{Text("Path path")}), run_to_end(each_job(n.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy, Text>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy, Text> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto&& _f = p0;
                auto&& f = std::get<0>(_f);
                auto&& t = std::get<1>(_f);
                call_then(start_cpp_type(cp_1_2, t), [=](Text cpp_type_76271) { return prism_rtl::finished(prism_rtl::cat(cpp_type_76271, " ", field_id(f))); });
            });
        }));
        });
    })));
    })))), Text(", "));
    auto ctor_inits = lexer::join(append(Array(std::vector{Text("path(std::move(path))")}), each(n.fields, [&](const std::tuple<Text, lower::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return prism_rtl::cat(field_id(f), "(std::move(", field_id(f), "))");
    })), Text(", "));
    auto params = concat(run_to_end(each_job(n.params, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [p_, t] = p0;
                call_then(start_param_type(cp_1_2, t), [=](Text param_type_76510) { return prism_rtl::finished(prism_rtl::cat(param_type_76510, " ", p_, ", ")); });
            });
        }));
        });
    })));
    }))));
    auto ret = n.fallible
        ? prism_rtl::cat("Result<std::shared_ptr<", n.name, ">>")
        : prism_rtl::cat("std::shared_ptr<", n.name, ">");
    auto make_decl = prism_rtl::cat("static ", ret, " make(Path path, ", params, "Cx& cx);");
    auto method_decls = run_to_end(each_job(append(n.methods, n.hosted), ({
        auto ncp_1 = ncp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::MethDef)>>(prism_rtl::rc([=](lower::MethDef p0) {
        return ({
            auto ncp_1_2 = ncp_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                call_then(start_method_sig(ncp_1_2, m, Text("")), [=](Text method_sig_76765) { return prism_rtl::finished(prism_rtl::cat(method_sig_76765, ";")); });
            });
        }));
        });
    })));
    })));
    auto builder_decls = append(each(n.builders, [&](const lower::ForDef& b) { return prism_rtl::cat("Done ", b.name, "_build(Cx& cx);"); }), each(n.gens, [&](const lower::GenDef& g) { return prism_rtl::cat("Done ", g.name, "_build(Cx& cx);"); }));
    auto hook_decls = each(n.hooks, [&](const std::tuple<Text, Array<lower::Do>>& _p0) {
        auto&& h = std::get<0>(_p0);
        return prism_rtl::cat(hook_sig(h, Text("")), " override;");
    });
    auto answer_decl = len(n.answers) == Nat(0u)
        ? Array<Text>{}
        : Array(std::vector{Text("Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;")});
    auto row_decl = n.row_kind == lower::RowKind(lower::RowKind::NotARow{})
        ? Array<Text>{}
        : Array(std::vector{Text("void leave_row(Cx& cx) override;")});
    auto decls = lexer::join(append(append(append(append(append(Array(std::vector{make_decl}), method_decls), builder_decls), hook_decls), answer_decl), row_decl), Text("\n"));
    auto doc = cpp_source_doc(prism_rtl::cat("`", n.prism, "`: a node of its own (docs/backend.md, \"A widget block\")."), n.doc);
    auto decl = cpp_templates::node_class(doc, n.name, base, fields, consts, prism_rtl::cat(n.name, "(", ctor_params, ") : ", ctor_inits, " {}"), decls);
    auto by_field = each(n.fields, [&](const std::tuple<Text, lower::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return or_(fold(n.inits, std::optional<lower::Ex>{}, [&](const std::optional<lower::Ex>& found_opt, const std::tuple<Text, lower::Ex>& _p1) {
            auto&& g = std::get<0>(_p1);
            auto&& v_ = std::get<1>(_p1);
            return g == f ? std::optional(v_) : found_opt;
        }), lower::Ex(lower::Ex::XVar{f}));
    });
    auto [lets_text, lcp] = cpp_statements_cp(ncp, n.lets);
    auto args = lexer::join(append(Array(std::vector{Text("path")}), run_to_end(each_job(by_field, ({
        auto lcp_1 = lcp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
        return ({
            auto lcp_1_2 = lcp_1;
            entered(once_job([=]() {
            return ({
                auto v_ = p0;
                (prism_rtl::more(prism_rtl::rc(CppExpr(lcp_1_2, v_))));
            });
        }));
        });
    })));
    })))), Text(", "));
    auto tail = n.fallible ? Text("return node;") : Text("return node;");
    auto make_1 = cpp_templates::node_make(n.name, prism_rtl::cat(ret, " ", n.name, "::make(Path path, ", params, "Cx& cx)"), lets_text, args, lexer::join(filter(Array(std::vector{cpp_statements(pointing(lcp, Text("node")), n->build), tail}), [&](const Text& s) { return s != Text(""); }), Text("\n")));
    auto methods = run_to_end(each_job(append(n.methods, n.hosted), ({
        auto ncp_2 = ncp;
        auto n_3 = n;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::MethDef)>>(prism_rtl::rc([=](lower::MethDef p0) {
        return ({
            auto ncp_2_4 = ncp_2;
            auto n_3_4 = n_3;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(MethodDef(ncp_2_4, n_3_4.name, m))));
            });
        }));
        });
    })));
    })));
    auto builders = append(run_to_end(each_job(n.builders, ({
        auto ncp_2 = ncp;
        auto n_3 = n;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::ForDef)>>(prism_rtl::rc([=](lower::ForDef p0) {
        return ({
            auto ncp_2_4 = ncp_2;
            auto n_3_4 = n_3;
            entered(once_job([=]() {
            return ({
                auto b = p0;
                (prism_rtl::more(prism_rtl::rc(ForBuildCpp(ncp_2_4, n_3_4.name, b))));
            });
        }));
        });
    })));
    }))), run_to_end(each_job(n.gens, ({
        auto ncp_2 = ncp;
        auto n_3 = n;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::GenDef)>>(prism_rtl::rc([=](lower::GenDef p0) {
        return ({
            auto ncp_2_4 = ncp_2;
            auto n_3_4 = n_3;
            entered(once_job([=]() {
            return ({
                auto g = p0;
                (prism_rtl::more(prism_rtl::rc(GenBuildCpp(ncp_2_4, n_3_4.name, g))));
            });
        }));
        });
    })));
    }))));
    auto hooks = run_to_end(each_job(n.hooks, ({
        auto n_2 = n;
        auto ncp_3 = ncp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<lower::Do>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<lower::Do>> p0) {
        return ({
            auto n_2_4 = n_2;
            auto ncp_3_4 = ncp_3;
            entered(once_job([=]() {
            return ({
                auto [h, body] = p0;
                call_then(start_cpp_statements(ncp_3_4, body), [=](Text cpp_statements_78502) { return prism_rtl::finished(cpp_templates::cpp_function(Text(""), hook_sig(h, prism_rtl::cat(n_2_4.name, "::")), prism_rtl::cat(cpp_statements_78502, "\nreturn {};"))); });
            });
        }));
        });
    })));
    })));
    auto answer = len(n.answers) == Nat(0u)
        ? Array<Text>{}
        : Array(std::vector{answer_def_cpp(ncp, n)});
    auto leaving = n.row_kind == lower::RowKind(lower::RowKind::NotARow{})
        ? Array<Text>{}
        : Array(std::vector{row_leaving(ncp, n)});
    auto defs = append(append(append(append(append(Array(std::vector{make_1}), methods), builders), hooks), answer), leaving);
    auto own = Parts{.forward = Array(std::vector{prism_rtl::cat("class ", n.name, ";")}), .handles = Array<Text>{}, .values = Array<ValueDecl>{}, .cases_ = Array<Text>{}, .protos = Array<Text>{}, .classes = Array(std::vector{decl}), .generic = Array<Text>{}, .defs = defs};
    return own;
}


prism_rtl::Turn<Parts> NodeParts::cycle() const {
    const auto& cp = this->cp;
    const auto& n = this->n;
    auto ncp = with_fields(cp, each(n.fields, [&](const std::tuple<Text, lower::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& t = std::get<1>(_p0);
        return std::tuple{f, t};
    }));
    auto base = (n.row_kind == lower::RowKind(lower::RowKind::NotARow{})) && (len(n.hosted) == Nat(0u))
        ? Text("Node")
        : Text("Row");
    auto cp_1 = cp;
    auto n_2 = n;
    return call_value(each_job(n_2.fields, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy, Text>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy, Text> p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto [f, t, doc] = p0;
                call_then(start_cpp_type(cp_1_3_3, t), [=](Text cpp_type_76019) { return prism_rtl::finished(prism_rtl::cat(cpp_doc(doc), "mutable ", cpp_type_76019, " ", field_id(f), ";")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_75965) {
        return ({
            auto fields = lexer::join(each_75965, Text("\n"));
            auto consts = lexer::join(each(n_2.consts, [&](const std::tuple<Text, Nat, Text>& _p0) {
                auto&& c = std::get<0>(_p0);
                auto&& h = std::get<1>(_p0);
                auto&& doc = std::get<2>(_p0);
                return prism_rtl::cat(cpp_doc(prism_rtl::cat("The ", doc, ".")), "static constexpr std::uint32_t ", c, " = ", h, ";");
            }), Text("\n"));
            call_value(each_job(n_2.fields, ({
            auto cp_1_3 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy, Text>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy, Text> p0) {
            return ({
                auto cp_1_3_3 = cp_1_3;
                entered(once_job([=]() {
                return ({
                    auto&& _f = p0;
                    auto&& f = std::get<0>(_f);
                    auto&& t = std::get<1>(_f);
                    call_then(start_cpp_type(cp_1_3_3, t), [=](Text cpp_type_76271) { return prism_rtl::finished(prism_rtl::cat(cpp_type_76271, " ", field_id(f))); });
                });
            }));
            });
        })));
        })), [=](Array<Text> each_76234) {
            return ({
                auto ctor_params = lexer::join(append(Array(std::vector{Text("Path path")}), each_76234), Text(", "));
                auto ctor_inits = lexer::join(append(Array(std::vector{Text("path(std::move(path))")}), each(n_2.fields, [&](const std::tuple<Text, lower::OutTy, Text>& _p0) {
                    auto&& f = std::get<0>(_p0);
                    return prism_rtl::cat(field_id(f), "(std::move(", field_id(f), "))");
                })), Text(", "));
                call_value(each_job(n_2.params, ({
                auto cp_1_3 = cp_1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
                return ({
                    auto cp_1_3_3 = cp_1_3;
                    entered(once_job([=]() {
                    return ({
                        auto [p_, t] = p0;
                        call_then(start_param_type(cp_1_3_3, t), [=](Text param_type_76510) { return prism_rtl::finished(prism_rtl::cat(param_type_76510, " ", p_, ", ")); });
                    });
                }));
                });
            })));
            })), [=](Array<Text> each_76481) {
                return ({
                    auto params = concat(each_76481);
                    auto ret = n_2.fallible
                        ? prism_rtl::cat("Result<std::shared_ptr<", n_2.name, ">>")
                        : prism_rtl::cat("std::shared_ptr<", n_2.name, ">");
                    auto make_decl = prism_rtl::cat("static ", ret, " make(Path path, ", params, "Cx& cx);");
                    call_value(each_job(append(n_2.methods, n_2.hosted), ({
                    auto ncp_3 = ncp;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::MethDef)>>(prism_rtl::rc([=](lower::MethDef p0) {
                    return ({
                        auto ncp_3_4 = ncp_3;
                        entered(once_job([=]() {
                        return ({
                            auto m = p0;
                            call_then(start_method_sig(ncp_3_4, m, Text("")), [=](Text method_sig_76765) { return prism_rtl::finished(prism_rtl::cat(method_sig_76765, ";")); });
                        });
                    }));
                    });
                })));
                })), [=](Array<Text> each_76723) {
                    return ({
                        auto method_decls = each_76723;
                        auto builder_decls = append(each(n_2.builders, [&](const lower::ForDef& b) { return prism_rtl::cat("Done ", b.name, "_build(Cx& cx);"); }), each(n_2.gens, [&](const lower::GenDef& g) { return prism_rtl::cat("Done ", g.name, "_build(Cx& cx);"); }));
                        auto hook_decls = each(n_2.hooks, [&](const std::tuple<Text, Array<lower::Do>>& _p0) {
                            auto&& h = std::get<0>(_p0);
                            return prism_rtl::cat(hook_sig(h, Text("")), " override;");
                        });
                        auto answer_decl = len(n_2.answers) == Nat(0u)
                            ? Array<Text>{}
                            : Array(std::vector{Text("Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;")});
                        auto row_decl = n_2.row_kind == lower::RowKind(lower::RowKind::NotARow{})
                            ? Array<Text>{}
                            : Array(std::vector{Text("void leave_row(Cx& cx) override;")});
                        auto decls = lexer::join(append(append(append(append(append(Array(std::vector{make_decl}), method_decls), builder_decls), hook_decls), answer_decl), row_decl), Text("\n"));
                        auto doc = cpp_source_doc(prism_rtl::cat("`", n_2.prism, "`: a node of its own (docs/backend.md, \"A widget block\")."), n_2.doc);
                        auto decl = cpp_templates::node_class(doc, n_2.name, base, fields, consts, prism_rtl::cat(n_2.name, "(", ctor_params, ") : ", ctor_inits, " {}"), decls);
                        auto by_field = each(n_2.fields, [&](const std::tuple<Text, lower::OutTy, Text>& _p0) {
                            auto&& f = std::get<0>(_p0);
                            return or_(fold(n_2.inits, std::optional<lower::Ex>{}, [&](const std::optional<lower::Ex>& found_opt, const std::tuple<Text, lower::Ex>& _p1) {
                                auto&& g = std::get<0>(_p1);
                                auto&& v_ = std::get<1>(_p1);
                                return g == f ? std::optional(v_) : found_opt;
                            }), lower::Ex(lower::Ex::XVar{f}));
                        });
                        call_then(start_cpp_statements_cp(ncp, n_2.lets), [=](std::tuple<Text, Cp> cpp_statements_cp_77834) {
                        return ({
                            auto [lets_text, lcp] = cpp_statements_cp_77834;
                            call_value(each_job(by_field, ({
                            auto lcp_3 = lcp;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
                            return ({
                                auto lcp_3_4 = lcp_3;
                                entered(once_job([=]() {
                                return ({
                                    auto v_ = p0;
                                    (prism_rtl::more(prism_rtl::rc(CppExpr(lcp_3_4, v_))));
                                });
                            }));
                            });
                        })));
                        })), [=](Array<Text> each_77903) {
                            return ({
                                auto args = lexer::join(append(Array(std::vector{Text("path")}), each_77903), Text(", "));
                                auto tail = n_2.fallible ? Text("return node;") : Text("return node;");
                                call_then(start_cpp_statements(pointing(lcp, Text("node")), n_2->build), [=](Text cpp_statements_78127) {
                                return ({
                                    auto make_3 = cpp_templates::node_make(n_2.name, prism_rtl::cat(ret, " ", n_2.name, "::make(Path path, ", params, "Cx& cx)"), lets_text, args, lexer::join(filter(Array(std::vector{cpp_statements_78127, tail}), [&](const Text& s) { return s != Text(""); }), Text("\n")));
                                    call_value(each_job(append(n_2.methods, n_2.hosted), ({
                                    auto ncp_4 = ncp;
                                    auto n_2_5 = n_2;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::MethDef)>>(prism_rtl::rc([=](lower::MethDef p0) {
                                    return ({
                                        auto ncp_4_5 = ncp_4;
                                        auto n_2_5_5 = n_2_5;
                                        entered(once_job([=]() {
                                        return ({
                                            auto m = p0;
                                            (prism_rtl::more(prism_rtl::rc(MethodDef(ncp_4_5, n_2_5_5.name, m))));
                                        });
                                    }));
                                    });
                                })));
                                })), [=](Array<Text> each_78222) {
                                    return ({
                                        auto methods = each_78222;
                                        call_value(each_job(n_2.builders, ({
                                        auto ncp_4 = ncp;
                                        auto n_2_5 = n_2;
                                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::ForDef)>>(prism_rtl::rc([=](lower::ForDef p0) {
                                        return ({
                                            auto ncp_4_5 = ncp_4;
                                            auto n_2_5_5 = n_2_5;
                                            entered(once_job([=]() {
                                            return ({
                                                auto b = p0;
                                                (prism_rtl::more(prism_rtl::rc(ForBuildCpp(ncp_4_5, n_2_5_5.name, b))));
                                            });
                                        }));
                                        });
                                    })));
                                    })), [=](Array<Text> each_78314) {
                                        return call_value(each_job(n_2.gens, ({
                                            auto ncp_4 = ncp;
                                            auto n_2_5 = n_2;
                                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::GenDef)>>(prism_rtl::rc([=](lower::GenDef p0) {
                                            return ({
                                                auto ncp_4_5 = ncp_4;
                                                auto n_2_5_5 = n_2_5;
                                                entered(once_job([=]() {
                                                return ({
                                                    auto g = p0;
                                                    (prism_rtl::more(prism_rtl::rc(GenBuildCpp(ncp_4_5, n_2_5_5.name, g))));
                                                });
                                            }));
                                            });
                                        })));
                                        })), [=](Array<Text> each_78366) {
                                            return ({
                                                auto builders = append(each_78314, each_78366);
                                                call_value(each_job(n_2.hooks, ({
                                                auto n_2_4 = n_2;
                                                auto ncp_4 = ncp;
                                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<lower::Do>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<lower::Do>> p0) {
                                                return ({
                                                    auto n_2_4_5 = n_2_4;
                                                    auto ncp_4_5 = ncp_4;
                                                    entered(once_job([=]() {
                                                    return ({
                                                        auto [h, body] = p0;
                                                        call_then(start_cpp_statements(ncp_4_5, body), [=](Text cpp_statements_78502) { return prism_rtl::finished(cpp_templates::cpp_function(Text(""), hook_sig(h, prism_rtl::cat(n_2_4_5.name, "::")), prism_rtl::cat(cpp_statements_78502, "\nreturn {};"))); });
                                                    });
                                                }));
                                                });
                                            })));
                                            })), [=](Array<Text> each_78428) {
                                                return ({
                                                    auto hooks = each_78428;
                                                    auto answer = len(n_2.answers) == Nat(0u)
                                                        ? Array<Text>{}
                                                        : Array(std::vector{answer_def_cpp(ncp, n_2)});
                                                    auto leaving = n_2.row_kind == lower::RowKind(lower::RowKind::NotARow{})
                                                        ? Array<Text>{}
                                                        : Array(std::vector{row_leaving(ncp, n_2)});
                                                    auto defs = append(append(append(append(append(Array(std::vector{make_3}), methods), builders), hooks), answer), leaving);
                                                    auto own = Parts{.forward = Array(std::vector{prism_rtl::cat("class ", n_2.name, ";")}), .handles = Array<Text>{}, .values = Array<ValueDecl>{}, .cases_ = Array<Text>{}, .protos = Array<Text>{}, .classes = Array(std::vector{decl}), .generic = Array<Text>{}, .defs = defs};
                                                    (prism_rtl::finished(own));
                                                });
                                            });
                                            });
                                        });
                                    });
                                    });
                                });
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start NodeParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_node_parts(Cp cp, lower::NodeDef n) {
    return std::make_shared<NodeParts>(cp, n);
}


/// MethodSig: unbounded fn Cp, MethDef, Text -> Text
Text method_sig(const Cp& cp, const lower::MethDef& m, const Text& owner) {
    auto cx_ = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = m.cx_;
        if (prism_rtl::is<lower::CxArg::CxMut>(_m)) {
            _v.set(Array(std::vector{Text("Cx& cx")}));
            goto _done;
        }
        if (prism_rtl::is<lower::CxArg::CxRef>(_m)) {
            _v.set(Array(std::vector{Text("const Cx& cx")}));
            goto _done;
        }
        if (prism_rtl::is<lower::CxArg::CxNone>(_m)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto params = lexer::join(append(run_to_end(each_job(m.params, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [p_, t] = p0;
                call_then(start_param_type(cp_1_2, t), [=](Text param_type_79209) { return prism_rtl::finished(prism_rtl::cat(param_type_79209, " ", p_)); });
            });
        }));
        });
    })));
    }))), cx_), Text(", "));
    auto constness = m.recv == lower::Recv(lower::Recv::RecvRef{}) ? Text(" const") : Text("");
    return prism_rtl::cat(cpp_type(cp, m.ret), " ", owner, node_method_name(cp, m.name), "(", params, ")", constness);
}


prism_rtl::Turn<Text> MethodSig::cycle() const {
    const auto& cp = this->cp;
    const auto& m = this->m;
    const auto& owner = this->owner;
    auto cx_ = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = m.cx_;
        if (prism_rtl::is<lower::CxArg::CxMut>(_m)) {
            _v.set(Array(std::vector{Text("Cx& cx")}));
            goto _done;
        }
        if (prism_rtl::is<lower::CxArg::CxRef>(_m)) {
            _v.set(Array(std::vector{Text("const Cx& cx")}));
            goto _done;
        }
        if (prism_rtl::is<lower::CxArg::CxNone>(_m)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cp_1 = cp;
    auto m_2 = m;
    auto owner_3 = owner;
    return call_value(each_job(m_2.params, ({
        auto cp_1_4 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            entered(once_job([=]() {
            return ({
                auto [p_, t] = p0;
                call_then(start_param_type(cp_1_4_4, t), [=](Text param_type_79209) { return prism_rtl::finished(prism_rtl::cat(param_type_79209, " ", p_)); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_79180) {
        return ({
            auto params = lexer::join(append(each_79180, cx_), Text(", "));
            auto constness = m_2.recv == lower::Recv(lower::Recv::RecvRef{}) ? Text(" const") : Text("");
            call_then(start_cpp_type(cp_1, m_2.ret), [=](Text cpp_type_79309) { return prism_rtl::finished(prism_rtl::cat(cpp_type_79309, " ", owner_3, node_method_name(cp_1, m_2.name), "(", params, ")", constness)); });
        });
    });
}


/// `Start MethodSig, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_method_sig(Cp cp, lower::MethDef m, Text owner) {
    return std::make_shared<MethodSig>(cp, m, owner);
}


/// MethodDef: unbounded fn Cp, Text, MethDef -> Text
Text method_def(const Cp& cp, const Text& owner, const lower::MethDef& m) {
    auto [st, cp2] = cpp_statements_cp(cp, m.body);
    auto body = m.ret == lower::OutTy(lower::OutTy::OutUnit{})
        ? prism_rtl::cat(st, "\nreturn Unit{};")
        : len(m.body) == Nat(0u)
        ? cpp_body(cp, m.tail)
        : prism_rtl::cat(st, "\n", cpp_body(cp2, m.tail));
    return cpp_templates::cpp_function(cpp_doc(m.doc), method_sig(cp, m, prism_rtl::cat(owner, "::")), body);
}


prism_rtl::Turn<Text> MethodDef::cycle() const {
    const auto& cp = this->cp;
    const auto& owner = this->owner;
    const auto& m = this->m;
    auto cp_1 = cp;
    auto m_2 = m;
    auto owner_3 = owner;
    return call_then(start_cpp_statements_cp(cp_1, m_2.body), [=](std::tuple<Text, Cp> cpp_statements_cp_79485) {
        return ({
            auto [st, cp2] = cpp_statements_cp_79485;
            auto body = m_2.ret == lower::OutTy(lower::OutTy::OutUnit{})
                ? prism_rtl::cat(st, "\nreturn Unit{};")
                : len(m_2.body) == Nat(0u)
                ? cpp_body(cp_1, m_2.tail)
                : prism_rtl::cat(st, "\n", cpp_body(cp2, m_2.tail));
            call_then(start_method_sig(cp_1, m_2, prism_rtl::cat(owner_3, "::")), [=](Text method_sig_79689) { return prism_rtl::finished(cpp_templates::cpp_function(cpp_doc(m_2.doc), method_sig_79689, body)); });
        });
    });
}


/// `Start MethodDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_method_def(Cp cp, Text owner, lower::MethDef m) {
    return std::make_shared<MethodDef>(cp, owner, m);
}


/// HookSig: fn Text, Text -> Text
Text hook_sig(const Text& text0, const Text& owner) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& c0_0 = text0;
            if (c0_0 == Text("push")) {
                _v.set(prism_rtl::cat("Done ", owner, "push(const Pod& element, const Pod& v, Cx& cx)"));
                goto _done;
            }
        }
        {
            auto&& h = text0;
            _v.set(prism_rtl::cat("Done ", owner, h, "(Cx& cx)"));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// AnswerDefCpp: unbounded fn Cp, NodeDef -> Text
Text answer_def_cpp(const Cp& cp, const lower::NodeDef& n) {
    auto arms = run_to_end(each_job(n.answers, ({
        auto cp_1 = cp;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Text>>(std::tuple<lower::Pa, lower::Ex>)>>(prism_rtl::rc([=](std::tuple<lower::Pa, lower::Ex> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [pat, call] = p0;
                call_then(start_pat_conds(cp_1_2, pat, Text("at")), [=](Array<Text> pat_conds_80032) {
                return ({
                    auto tests = pat_conds_80032;
                    call_then(start_pat_binds(cp_1_2, pat, Text("at")), [=](Array<Text> pat_binds_80075) {
                    return ({
                        auto binds = pat_binds_80075;
                        call_then(start_cpp_expr(cp_1_2, call), [=](Text cpp_expr_80136) { return prism_rtl::finished(std::tuple{tests, lexer::join(prelude::push(binds, prism_rtl::cat(cpp_expr_80136, ";")), Text("\n"))}); });
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })));
    auto blocks = each(check_errors::range0(len(arms)), [&](const Nat& i) {
        return ({
            auto [tests, inner] = or_(index(arms, i), std::tuple{Array<Text>{}, Text("")});
            (cpp_templates::block(prism_rtl::cat(i == Nat(0u) ? Text("if") : Text("else if"), " (", conds(tests), ")"), inner));
        });
    });
    return cpp_templates::cpp_function(Text(""), prism_rtl::cat("Done ", n.name, "::answer(std::span<const Segment> at, const Pod& v, Cx& cx)"), prism_rtl::cat(lexer::join(blocks, Text(" ")), " else {\n    return unexpected(Fault::answer(str(\"no answering place at \", path_of(at))));\n}\nreturn {};"));
}


prism_rtl::Turn<Text> AnswerDefCpp::cycle() const {
    const auto& cp = this->cp;
    const auto& n = this->n;
    auto cp_1 = cp;
    auto n_2 = n;
    return call_value(each_job(n_2.answers, ({
        auto cp_1_3 = cp_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Text>>(std::tuple<lower::Pa, lower::Ex>)>>(prism_rtl::rc([=](std::tuple<lower::Pa, lower::Ex> p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto [pat, call] = p0;
                call_then(start_pat_conds(cp_1_3_3, pat, Text("at")), [=](Array<Text> pat_conds_80032) {
                return ({
                    auto tests = pat_conds_80032;
                    call_then(start_pat_binds(cp_1_3_3, pat, Text("at")), [=](Array<Text> pat_binds_80075) {
                    return ({
                        auto binds = pat_binds_80075;
                        call_then(start_cpp_expr(cp_1_3_3, call), [=](Text cpp_expr_80136) { return prism_rtl::finished(std::tuple{tests, lexer::join(prelude::push(binds, prism_rtl::cat(cpp_expr_80136, ";")), Text("\n"))}); });
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Array<Text>, Text>> each_79979) {
        return ({
            auto arms = each_79979;
            auto blocks = each(check_errors::range0(len(arms)), [&](const Nat& i) {
                return ({
                    auto [tests, inner] = or_(index(arms, i), std::tuple{Array<Text>{}, Text("")});
                    (cpp_templates::block(prism_rtl::cat(i == Nat(0u) ? Text("if") : Text("else if"), " (", conds(tests), ")"), inner));
                });
            });
            (prism_rtl::finished(cpp_templates::cpp_function(Text(""), prism_rtl::cat("Done ", n_2.name, "::answer(std::span<const Segment> at, const Pod& v, Cx& cx)"), prism_rtl::cat(lexer::join(blocks, Text(" ")), " else {\n    return unexpected(Fault::answer(str(\"no answering place at \", path_of(at))));\n}\nreturn {};"))));
        });
    });
}


/// `Start AnswerDefCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_answer_def_cpp(Cp cp, lower::NodeDef n) {
    return std::make_shared<AnswerDefCpp>(cp, n);
}


/// RowLeaving: unbounded fn Cp, NodeDef -> Text
Text row_leaving(const Cp& cp, const lower::NodeDef& n) {
    auto kept = n.row_kind == lower::RowKind(lower::RowKind::ForRow{})
        ? Array(std::vector{Text("this->left_entry = entry(cx);")})
        : Array<Text>{};
    auto unsubscribe = each(n.subs, [&](const std::tuple<Text, Text, lower::OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        return prism_rtl::cat("if (auto p = parent.lock(); p && ", m, "_sub) deref(p->", ev, "_port).unsubscribe(*std::exchange(", m, "_sub, std::nullopt));");
    });
    return cpp_templates::cpp_function(Text(""), prism_rtl::cat("void ", n.name, "::leave_row(Cx& cx)"), lexer::join(append(prelude::push(kept, Text("remove_places(cx);")), unsubscribe), Text("\n")));
}


prism_rtl::Turn<Text> RowLeaving::cycle() const {
    const auto& cp = this->cp;
    const auto& n = this->n;
    auto kept = n.row_kind == lower::RowKind(lower::RowKind::ForRow{})
        ? Array(std::vector{Text("this->left_entry = entry(cx);")})
        : Array<Text>{};
    auto unsubscribe = each(n.subs, [&](const std::tuple<Text, Text, lower::OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        return prism_rtl::cat("if (auto p = parent.lock(); p && ", m, "_sub) deref(p->", ev, "_port).unsubscribe(*std::exchange(", m, "_sub, std::nullopt));");
    });
    return prism_rtl::finished(cpp_templates::cpp_function(Text(""), prism_rtl::cat("void ", n.name, "::leave_row(Cx& cx)"), lexer::join(append(prelude::push(kept, Text("remove_places(cx);")), unsubscribe), Text("\n"))));
}


/// `Start RowLeaving, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_row_leaving(Cp cp, lower::NodeDef n) {
    return std::make_shared<RowLeaving>(cp, n);
}


/// ForBuildCpp: unbounded fn Cp, Text, ForDef -> Text
Text for_build_cpp(const Cp& cp, const Text& owner, const lower::ForDef& b) {
    return cpp_templates::for_build_template(owner, b.name, cpp_expr(cp, b.at), cpp_type(cp, b.key_ty), cpp_type(cp, b.value_ty), call_path(prism_rtl::cat(b.row_node, "::build")), b->source, cpp_expr(cp, b->parent), concat(run_to_end(each_job(b.passed, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                call_then(start_cpp_expr(cp_1_2, x), [=](Text cpp_expr_81440) { return prism_rtl::finished(prism_rtl::cat(", ", cpp_expr_81440)); });
            });
        }));
        });
    })));
    })))));
}


prism_rtl::Turn<Text> ForBuildCpp::cycle() const {
    const auto& cp = this->cp;
    const auto& owner = this->owner;
    const auto& b = this->b;
    auto b_1 = b;
    auto cp_2 = cp;
    auto owner_3 = owner;
    return call_then(start_cpp_expr(cp_2, b_1.at), [=](Text cpp_expr_81273) {
        return call_then(start_cpp_type(cp_2, b_1.key_ty), [=](Text cpp_type_81293) {
            return call_then(start_cpp_type(cp_2, b_1.value_ty), [=](Text cpp_type_81316) {
                return call_then(start_cpp_expr(cp_2, b_1->parent), [=](Text cpp_expr_81384) {
                    return call_value(each_job(b_1.passed, ({
                        auto cp_2_4 = cp_2;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
                        return ({
                            auto cp_2_4_4 = cp_2_4;
                            entered(once_job([=]() {
                            return ({
                                auto x = p0;
                                call_then(start_cpp_expr(cp_2_4_4, x), [=](Text cpp_expr_81440) { return prism_rtl::finished(prism_rtl::cat(", ", cpp_expr_81440)); });
                            });
                        }));
                        });
                    })));
                    })), [=](Array<Text> each_81416) { return prism_rtl::finished(cpp_templates::for_build_template(owner_3, b_1.name, cpp_expr_81273, cpp_type_81293, cpp_type_81316, call_path(prism_rtl::cat(b_1.row_node, "::build")), b_1->source, cpp_expr_81384, concat(each_81416))); });
                });
            });
        });
    });
}


/// `Start ForBuildCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_for_build_cpp(Cp cp, Text owner, lower::ForDef b) {
    return std::make_shared<ForBuildCpp>(cp, owner, b);
}


/// GenBuildCpp: unbounded fn Cp, Text, GenDef -> Text
Text gen_build_cpp(const Cp& cp, const Text& owner, const lower::GenDef& gd) {
    auto path_ = gd.transparent
        ? Text("this->path")
        : prism_rtl::cat(cpp_expr(cp, gd.at), ".child(Segment::gen(g))");
    return cpp_templates::gen_build_template(owner, gd.name, cpp_expr(cp, gd.at), path_, cpp_expr(cp, gd->source), cpp_type(cp, gd.value_ty), cpp_expr(cp, gd.select));
}


prism_rtl::Turn<Text> GenBuildCpp::cycle() const {
    const auto& cp = this->cp;
    const auto& owner = this->owner;
    const auto& gd = this->gd;
    auto path_ = gd.transparent
        ? Text("this->path")
        : prism_rtl::cat(cpp_expr(cp, gd.at), ".child(Segment::gen(g))");
    auto cp_1 = cp;
    auto gd_2 = gd;
    auto owner_3 = owner;
    return call_then(start_cpp_expr(cp_1, gd_2.at), [=](Text cpp_expr_81676) { return call_then(start_cpp_expr(cp_1, gd_2->source), [=](Text cpp_expr_81703) { return call_then(start_cpp_type(cp_1, gd_2.value_ty), [=](Text cpp_type_81728) { return call_then(start_cpp_expr(cp_1, gd_2.select), [=](Text cpp_expr_81754) { return prism_rtl::finished(cpp_templates::gen_build_template(owner_3, gd_2.name, cpp_expr_81676, path_, cpp_expr_81703, cpp_type_81728, cpp_expr_81754)); }); }); }); });
}


/// `Start GenBuildCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_gen_build_cpp(Cp cp, Text owner, lower::GenDef gd) {
    return std::make_shared<GenBuildCpp>(cp, owner, gd);
}


/// ProgramCpp: unbounded fn Cp, ProgDef, Bool -> Text
Text program_cpp(const Cp& cp, const lower::ProgDef& p_, const bool& fallible) {
    auto n = len(p_.params);
    auto names = each(p_.params, [&](const std::tuple<Text, lower::OutTy>& _p0) {
        auto&& a = std::get<0>(_p0);
        return a;
    });
    auto plural = n == Nat(1u) ? Text("") : Text("s");
    auto decode = n == Nat(0u)
        ? Text("static_cast<void>(args);")
        : lexer::join(append(Array(std::vector{prism_rtl::cat("if (args.size() != ", n, ") return unexpected(Fault::answer(\"@", p_.prism, " takes ", n, " argument", plural, "\"));")}), run_to_end(each_job(check_errors::range0(n), ({
        auto cp_1 = cp;
        auto p__2 = p_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto p__2_3 = p__2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(DecodeArg(cp_1_3, p__2_3.params, i))));
            });
        }));
        });
    })));
    })))), Text("\n"));
    auto call = prism_rtl::cat(call_path(prism_rtl::cat(p_.node_, "::build")), "(Path::root(), ", concat(each(names, [&](const Text& a) { return prism_rtl::cat(a, ", "); })), "cx)");
    auto root = fallible ? prism_rtl::cat("TRY(", call, ")") : call;
    return cpp_templates::program_class(p_.name, p_.prism, type_path(p_.node_), decode, root);
}


prism_rtl::Turn<Text> ProgramCpp::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& fallible = this->fallible;
    auto n = len(p_.params);
    auto names = each(p_.params, [&](const std::tuple<Text, lower::OutTy>& _p0) {
        auto&& a = std::get<0>(_p0);
        return a;
    });
    auto plural = n == Nat(1u) ? Text("") : Text("s");
    auto decode = n == Nat(0u)
        ? Text("static_cast<void>(args);")
        : lexer::join(append(Array(std::vector{prism_rtl::cat("if (args.size() != ", n, ") return unexpected(Fault::answer(\"@", p_.prism, " takes ", n, " argument", plural, "\"));")}), run_to_end(each_job(check_errors::range0(n), ({
        auto cp_1 = cp;
        auto p__2 = p_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto p__2_3 = p__2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(DecodeArg(cp_1_3, p__2_3.params, i))));
            });
        }));
        });
    })));
    })))), Text("\n"));
    auto call = prism_rtl::cat(call_path(prism_rtl::cat(p_.node_, "::build")), "(Path::root(), ", concat(each(names, [&](const Text& a) { return prism_rtl::cat(a, ", "); })), "cx)");
    auto root = fallible ? prism_rtl::cat("TRY(", call, ")") : call;
    return prism_rtl::finished(cpp_templates::program_class(p_.name, p_.prism, type_path(p_.node_), decode, root));
}


/// `Start ProgramCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_program_cpp(Cp cp, lower::ProgDef p_, bool fallible) {
    return std::make_shared<ProgramCpp>(cp, p_, fallible);
}


/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
Text decode_arg(const Cp& cp, const Array<std::tuple<Text, lower::OutTy>>& ps, const Nat& i) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(ps, i);
        if (prism_rtl::is_some(_m)) {
            auto&& a = std::get<0>(prism_rtl::some_of(_m));
            auto&& t = std::get<1>(prism_rtl::some_of(_m));
            _v.set(prism_rtl::cat("auto ", a, " = TRY(prism_rtl::from_pod<", cpp_type(cp, t), ">(args[", i, "]));"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> DecodeArg::cycle() const {
    const auto& cp = this->cp;
    const auto& ps = this->ps;
    const auto& i = this->i;
    return ({
        auto&& _m = index(ps, i);
        prism_rtl::is_some(_m) ? ({
        auto&& a = std::get<0>(prism_rtl::some_of(_m));
        auto&& t = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, t), [=](Text cpp_type_82584) { return prism_rtl::finished(prism_rtl::cat("auto ", a, " = TRY(prism_rtl::from_pod<", cpp_type_82584, ">(args[", i_2, "]));")); });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Text(""))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start DecodeArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_decode_arg(Cp cp, Array<std::tuple<Text, lower::OutTy>> ps, Nat i) {
    return std::make_shared<DecodeArg>(cp, ps, i);
}


/// ModuleParts: unbounded fn Cp, ModDef -> Parts
Parts module_parts(const Cp& cp, const lower::ModDef& m) {
    auto mcp = in_home(cp, m.name);
    auto all = run_to_end(fold_job(m.items, no_parts(), ({
        auto mcp_1 = mcp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(std::tuple<Parts, lower::Item>)>>(prism_rtl::rc([=](std::tuple<Parts, lower::Item> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto mcp_1_2 = mcp_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto it = p1;
                call_then(start_item_parts(mcp_1_2, it), [=](Parts item_parts_83033) { return prism_rtl::finished(join_parts(acc, item_parts_83033)); });
            });
        }));
        });
    })));
    })));
    return Parts{.forward = in_ns(m.name, all.forward), .handles = in_ns(m.name, all.handles), .values = each(all.values, [&](const ValueDecl& v_) { return in_ns_value(m.name, v_); }), .cases_ = in_ns(m.name, all.cases_), .protos = in_ns(m.name, all.protos), .classes = in_ns(m.name, all.classes), .generic = in_ns(m.name, all.generic), .defs = all.defs};
}


prism_rtl::Turn<Parts> ModuleParts::cycle() const {
    const auto& cp = this->cp;
    const auto& m = this->m;
    auto mcp = in_home(cp, m.name);
    auto m_1 = m;
    return call_value(fold_job(m_1.items, no_parts(), ({
        auto mcp_2 = mcp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(std::tuple<Parts, lower::Item>)>>(prism_rtl::rc([=](std::tuple<Parts, lower::Item> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto mcp_2_3 = mcp_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto it = p1;
                call_then(start_item_parts(mcp_2_3, it), [=](Parts item_parts_83033) { return prism_rtl::finished(join_parts(acc, item_parts_83033)); });
            });
        }));
        });
    })));
    })), [=](Parts fold_82983) {
        return ({
            auto all = fold_82983;
            (prism_rtl::finished(Parts{.forward = in_ns(m_1.name, all.forward), .handles = in_ns(m_1.name, all.handles), .values = each(all.values, [&](const ValueDecl& v_) { return in_ns_value(m_1.name, v_); }), .cases_ = in_ns(m_1.name, all.cases_), .protos = in_ns(m_1.name, all.protos), .classes = in_ns(m_1.name, all.classes), .generic = in_ns(m_1.name, all.generic), .defs = all.defs}));
        });
    });
}


/// `Start ModuleParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_module_parts(Cp cp, lower::ModDef m) {
    return std::make_shared<ModuleParts>(cp, m);
}


/// InNsValue: fn Text, ValueDecl -> ValueDecl
ValueDecl in_ns_value(const Text& ns, const ValueDecl& v_) {
    ValueDecl this_ = v_;
    this_.text = prism_rtl::cat("namespace ", ns, " {\n\n", this_.text, "\n\n}  // namespace ", ns);
    return this_;
}


/// InNs: fn Text, [Text] -> [Text]
Array<Text> in_ns(const Text& ns, const Array<Text>& xs1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        {
            auto&& c0_1 = xs1;
            if (c0_1.size() == 0u) {
                _v.set(Array<Text>{});
                goto _done;
            }
        }
        {
            auto&& xs = xs1;
            _v.set(Array(std::vector{prism_rtl::cat("namespace ", ns, " {\n\n", lexer::join(xs, Text("\n\n")), "\n\n}  // namespace ", ns)}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// NodeFallibleCpp: fn Model, Text -> Bool
bool node_fallible_cpp(const lower::Model& model, const Text& path_) {
    return fold(model.mods, false, [&](const bool& f, const lower::ModDef& m) {
        return fold(m.items, f, [&](const bool& f2, const lower::Item& it) {
            return ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                if (prism_rtl::is<lower::Item::ItNode>(it)) {
                    auto&& n = prism_rtl::as<lower::Item::ItNode>(it).a0;
                    _v.set(f2 || ((prism_rtl::cat(m.name, "::", n.name) == path_) && n.fallible));
                    goto _done;
                }
                {
                    _v.set(f2);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
    });
}


/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> emit_cpp(const lower::Model& model, const Text& runtime, const Array<Text>& scripts) {
    auto cp = context(model);
    auto crate_ = in_home(cp, Text(""));
    auto elem = row_parts(crate_, Text(""), model.elem);
    auto answer = answer_parts(crate_, model->answer);
    auto mods = run_to_end(each_job(model.mods, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(lower::ModDef)>>(prism_rtl::rc([=](lower::ModDef p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(ModuleParts(cp_1_2, m))));
            });
        }));
        });
    })));
    })));
    auto all = fold(mods, join_parts(elem, answer), [&](const Parts& acc, const Parts& p_) { return join_parts(acc, p_); });
    auto programs = lexer::join(run_to_end(each_job(all_programs_cpp(model), ({
        auto crate__1 = crate_;
        auto model_2 = model;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::ProgDef)>>(prism_rtl::rc([=](lower::ProgDef p0) {
        return ({
            auto crate__1_3 = crate__1;
            auto model_2_3 = model_2;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(ProgramCpp(crate__1_3, p_, node_fallible_cpp(model_2_3, p_.node_)))));
            });
        }));
        });
    })));
    }))), Text("\n\n"));
    auto header_ = header(model.name, all, programs);
    auto regs = concat(each(model.programs, [&](const lower::ProgDef& p_) { return prism_rtl::cat("\n.program<", p_.name, ">(\"", p_.prism, "\")"); }));
    auto checks = concat(run_to_end(each_job(model.checks, ({
        auto crate__1 = crate_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::CheckDef)>>(prism_rtl::rc([=](lower::CheckDef p0) {
        return ({
            auto crate__1_2 = crate__1;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_value(each_job(c.lines, ({
                auto crate__1_2_2 = crate__1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
                return ({
                    auto crate__1_2_2_2 = crate__1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto l = p0;
                        (prism_rtl::more(prism_rtl::rc(CppExpr(crate__1_2_2_2, l))));
                    });
                }));
                });
            })));
            })), [=](Array<Text> each_84715) { return prism_rtl::finished(prism_rtl::cat("\n.check(\"", c.name, "\", [] { return std::vector<Result<Pod>>{", lexer::join(each_84715, Text(", ")), "}; })")); });
            });
        }));
        });
    })));
    }))));
    auto script_list = lexer::join(each(scripts, [&](const Text& s) { return prism_rtl::cat("\"", lower::escape(s), "\","); }), Text("\n"));
    auto world = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(r->world);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text("test"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto canvas_1 = world == Text("canvas");
    auto run_root = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(cpp_templates::cpp_run_root(r.name, canvas_1
                ? cpp_templates::cpp_canvas_run(r.name)
                : cpp_templates::cpp_no_canvas(r.name)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(cpp_templates::cpp_no_root(model.name));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto includes = canvas_1 ? cpp_templates::cpp_canvas_include(Text("")) : Text("");
    auto main = cpp_templates::cpp_main(model.name, includes, regs, checks, script_list, world, run_root, lexer::join(concat2(each(Array(std::vector{elem, answer}), [&](const Parts& p_) { return p_.defs; })), Text("\n\n")));
    auto per_module = each(check_errors::range0(len(model.mods)), [&](const Nat& i) {
        return ({
            auto m = or_(index(model.mods, i), lower::ModDef{.name = Text(""), .prism = Text(""), .path_ = Text(""), .uses = Array<Text>{}, .items = Array<lower::Item>{}});
            auto p_ = or_(index(mods, i), no_parts());
            module_files(m, chunks(p_.defs));
        });
    });
    auto files = fold(per_module, Array<std::tuple<Text, Text>>{}, [&](const Array<std::tuple<Text, Text>>& acc, const Array<std::tuple<Text, Text>>& fs) { return append(acc, fs); });
    auto sources = lexer::join(each(files, [&](const std::tuple<Text, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f;
    }), Text(" "));
    return append(Array(std::vector{std::tuple{Text("Makefile"), cpp_templates::cpp_makefile(model.name, runtime, sources, canvas_1 ? cpp_templates::cpp_makefile_canvas(runtime) : Text(""))}, std::tuple{Text("src/crate.hpp"), header_}, std::tuple{Text("src/main.cpp"), main}, std::tuple{Text("src/prelude.hpp"), cpp_prelude_template::cpp_prelude_source(Text(""))}}), files);
}


prism_rtl::Turn<Array<std::tuple<Text, Text>>> EmitCpp::cycle() const {
    const auto& model = this->model;
    const auto& runtime = this->runtime;
    const auto& scripts = this->scripts;
    auto cp = context(model);
    auto crate_ = in_home(cp, Text(""));
    auto model_1 = model;
    auto runtime_2 = runtime;
    auto scripts_3 = scripts;
    return call_then(start_row_parts(crate_, Text(""), model_1.elem), [=](Parts row_parts_84124) {
        return ({
            auto elem = row_parts_84124;
            call_then(start_answer_parts(crate_, model_1->answer), [=](Parts answer_parts_84172) {
            return ({
                auto answer = answer_parts_84172;
                call_value(each_job(model_1.mods, ({
                auto cp_4 = cp;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(lower::ModDef)>>(prism_rtl::rc([=](lower::ModDef p0) {
                return ({
                    auto cp_4_5 = cp_4;
                    entered(once_job([=]() {
                    return ({
                        auto m = p0;
                        (prism_rtl::more(prism_rtl::rc(ModuleParts(cp_4_5, m))));
                    });
                }));
                });
            })));
            })), [=](Array<Parts> each_84219) {
                return ({
                    auto mods = each_84219;
                    auto all = fold(mods, join_parts(elem, answer), [&](const Parts& acc, const Parts& p_) { return join_parts(acc, p_); });
                    call_value(each_job(all_programs_cpp(model_1), ({
                    auto crate__4 = crate_;
                    auto model_1_5 = model_1;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::ProgDef)>>(prism_rtl::rc([=](lower::ProgDef p0) {
                    return ({
                        auto crate__4_5 = crate__4;
                        auto model_1_5_5 = model_1_5;
                        entered(once_job([=]() {
                        return ({
                            auto p_ = p0;
                            (prism_rtl::more(prism_rtl::rc(ProgramCpp(crate__4_5, p_, node_fallible_cpp(model_1_5_5, p_.node_)))));
                        });
                    }));
                    });
                })));
                })), [=](Array<Text> each_84362) {
                    return ({
                        auto programs = lexer::join(each_84362, Text("\n\n"));
                        call_then(start_header(model_1.name, all, programs), [=](Text header_84475) {
                        return ({
                            auto header_ = header_84475;
                            auto regs = concat(each(model_1.programs, [&](const lower::ProgDef& p_) { return prism_rtl::cat("\n.program<", p_.name, ">(\"", p_.prism, "\")"); }));
                            call_value(each_job(model_1.checks, ({
                            auto crate__4 = crate_;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::CheckDef)>>(prism_rtl::rc([=](lower::CheckDef p0) {
                            return ({
                                auto crate__4_5 = crate__4;
                                entered(once_job([=]() {
                                return ({
                                    auto c = p0;
                                    call_value(each_job(c.lines, ({
                                    auto crate__4_5_5 = crate__4_5;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
                                    return ({
                                        auto crate__4_5_5_5 = crate__4_5_5;
                                        entered(once_job([=]() {
                                        return ({
                                            auto l = p0;
                                            (prism_rtl::more(prism_rtl::rc(CppExpr(crate__4_5_5_5, l))));
                                        });
                                    }));
                                    });
                                })));
                                })), [=](Array<Text> each_84715) { return prism_rtl::finished(prism_rtl::cat("\n.check(\"", c.name, "\", [] { return std::vector<Result<Pod>>{", lexer::join(each_84715, Text(", ")), "}; })")); });
                                });
                            }));
                            });
                        })));
                        })), [=](Array<Text> each_84621) {
                            return ({
                                auto checks = concat(each_84621);
                                auto script_list = lexer::join(each(scripts_3, [&](const Text& s) { return prism_rtl::cat("\"", lower::escape(s), "\","); }), Text("\n"));
                                auto world = ({
                                    __label__ _done;
                                    prism_rtl::Slot<Text> _v;
                                    auto&& _m = model_1.root;
                                    if (prism_rtl::is_some(_m)) {
                                        auto&& r = prism_rtl::some_of(_m);
                                        _v.set(r->world);
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(_m)) {
                                        _v.set(Text("test"));
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                });
                                auto canvas_4 = world == Text("canvas");
                                auto run_root = ({
                                    __label__ _done;
                                    prism_rtl::Slot<Text> _v;
                                    auto&& _m = model_1.root;
                                    if (prism_rtl::is_some(_m)) {
                                        auto&& r = prism_rtl::some_of(_m);
                                        _v.set(cpp_templates::cpp_run_root(r.name, canvas_4
                                            ? cpp_templates::cpp_canvas_run(r.name)
                                            : cpp_templates::cpp_no_canvas(r.name)));
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(_m)) {
                                        _v.set(cpp_templates::cpp_no_root(model_1.name));
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                });
                                auto includes = canvas_4 ? cpp_templates::cpp_canvas_include(Text("")) : Text("");
                                auto main = cpp_templates::cpp_main(model_1.name, includes, regs, checks, script_list, world, run_root, lexer::join(concat2(each(Array(std::vector{elem, answer}), [&](const Parts& p_) { return p_.defs; })), Text("\n\n")));
                                auto per_module = each(check_errors::range0(len(model_1.mods)), [&](const Nat& i) {
                                    return ({
                                        auto m = or_(index(model_1.mods, i), lower::ModDef{.name = Text(""), .prism = Text(""), .path_ = Text(""), .uses = Array<Text>{}, .items = Array<lower::Item>{}});
                                        auto p_ = or_(index(mods, i), no_parts());
                                        module_files(m, chunks(p_.defs));
                                    });
                                });
                                auto files = fold(per_module, Array<std::tuple<Text, Text>>{}, [&](const Array<std::tuple<Text, Text>>& acc, const Array<std::tuple<Text, Text>>& fs) { return append(acc, fs); });
                                auto sources = lexer::join(each(files, [&](const std::tuple<Text, Text>& _p0) {
                                    auto&& f = std::get<0>(_p0);
                                    return f;
                                }), Text(" "));
                                (prism_rtl::finished(append(Array(std::vector{std::tuple{Text("Makefile"), cpp_templates::cpp_makefile(model_1.name, runtime_2, sources, canvas_4 ? cpp_templates::cpp_makefile_canvas(runtime_2) : Text(""))}, std::tuple{Text("src/crate.hpp"), header_}, std::tuple{Text("src/main.cpp"), main}, std::tuple{Text("src/prelude.hpp"), cpp_prelude_template::cpp_prelude_source(Text(""))}}), files)));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}

}  // namespace crate::emit_cpp
