// The module `CheckBlocks`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check_blocks/types.hpp>
#include "elem.types.hpp"
#include <ast/types.hpp>
#include <check_env/types.hpp>
#include <check_errors/types.hpp>
#include <check_expr/types.hpp>
#include <check_passes/types.hpp>
#include <check_types/types.hpp>
#include <lexer/types.hpp>
#include <typed/types.hpp>

namespace crate {

using namespace prelude;

namespace check_blocks {

Array<Nat> group_order(const Array<crate::ast::Stmt>& stmts);

Array<Array<Nat>> dep_order(const Array<crate::ast::Stmt>& stmts);

prism_rtl::JobRef<Array<Array<Nat>>> start_dep_order(Array<crate::ast::Stmt> stmts);

Array<Text> group_defs(const crate::ast::Stmt& s);

prism_rtl::JobRef<Array<Text>> start_group_defs(crate::ast::Stmt s);

Array<Nat> reach_idx(const Array<Array<Nat>>& deps, const Array<Nat>& frontier, const Array<Nat>& seen);

prism_rtl::JobRef<Array<Nat>> start_reach_idx(Array<Array<Nat>> deps, Array<Nat> frontier, Array<Nat> seen);

Array<Array<Nat>> emit_groups(const Array<Array<Nat>>& comps, const Array<Array<Nat>>& deps, const Array<Nat>& done, const Array<Array<Nat>>& acc);

prism_rtl::JobRef<Array<Array<Nat>>> start_emit_groups(Array<Array<Nat>> comps, Array<Array<Nat>> deps, Array<Nat> done, Array<Array<Nat>> acc);

bool is_hold(const crate::ast::Stmt& s);

bool is_let_like(const crate::ast::Stmt& s);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_widget_block(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Block& b);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_widget_block(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Block b);

crate::ast::Stmt dummy_stmt2();

std::tuple<crate::check_expr::Env, crate::check_types::St> block_row(const crate::check_expr::Env& env, const crate::check_types::St& st, const Array<crate::ast::Stmt>& stmts);

prism_rtl::JobRef<std::tuple<crate::check_expr::Env, crate::check_types::St>> start_block_row(crate::check_expr::Env env, crate::check_types::St st, Array<crate::ast::Stmt> stmts);

crate::ast::Type row_as_type(const crate::ast::Row_& row_decl);

crate::ast::Type row_term_type(const crate::ast::RowTerm& row_term0);

crate::check_types::Rw resolve_scope_row(const crate::check_expr::Env& env, const crate::check_types::Rw& rw);

std::tuple<crate::check_expr::Env, crate::check_types::St> pre_bind_stmt(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Stmt& s);

prism_rtl::JobRef<std::tuple<crate::check_expr::Env, crate::check_types::St>> start_pre_bind_stmt(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Stmt s);

std::tuple<crate::check_expr::Env, crate::check_types::St> pre_bind_pattern(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Pattern_& p_);

prism_rtl::JobRef<std::tuple<crate::check_expr::Env, crate::check_types::St>> start_pre_bind_pattern(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Pattern_ p_);

std::tuple<crate::check_expr::Env, crate::check_types::St, std::optional<crate::check_types::Ty>> widget_stmt(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Stmt& s, const bool& last);

prism_rtl::JobRef<std::tuple<crate::check_expr::Env, crate::check_types::St, std::optional<crate::check_types::Ty>>> start_widget_stmt(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Stmt s, bool last);

crate::check_types::St bind_stmt(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Pattern_& p_, const crate::ast::Expr& e, const crate::ast::Range& span);

prism_rtl::JobRef<crate::check_types::St> start_bind_stmt(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Pattern_ p_, crate::ast::Expr e, crate::ast::Range span);

bool is_builder(const crate::ast::Expr& e);

std::tuple<crate::check_types::Ty, crate::check_types::St> bind_output(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::check_types::Ty& t, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_bind_output(crate::check_expr::Env env, crate::check_types::St st, crate::check_types::Ty t, crate::ast::Range span);

crate::check_types::St add_incl(const crate::check_types::St& st, const crate::check_types::Rw& sub, const crate::check_types::Rw& sup, const crate::ast::Range& span, const Text& what);

crate::check_types::St hold_stmt(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Pattern_& p_, const crate::ast::Expr& init, const crate::ast::Expr& step_, const crate::ast::Range& span);

prism_rtl::JobRef<crate::check_types::St> start_hold_stmt(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Pattern_ p_, crate::ast::Expr init, crate::ast::Expr step_, crate::ast::Range span);

crate::check_types::St ignore_stmt(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Expr& e, const crate::ast::Range& span);

prism_rtl::JobRef<crate::check_types::St> start_ignore_stmt(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Expr e, crate::ast::Range span);

std::tuple<crate::check_types::Ty, crate::check_types::St> bare_line(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Expr& e, const bool& last);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_bare_line(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Expr e, bool last);

crate::check_types::St note_as_last(const crate::check_types::St& st, const crate::ast::Range& span);

std::tuple<crate::check_types::Ty, crate::check_types::St> bare_line_kind(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Expr& e, const bool& last);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_bare_line_kind(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Expr e, bool last);

crate::check_types::St discarded(const crate::check_types::St& st, const crate::check_types::Ty& t, const crate::ast::Range& span);

prism_rtl::JobRef<crate::check_types::St> start_discarded(crate::check_types::St st, crate::check_types::Ty t, crate::ast::Range span);

std::tuple<crate::check_types::Ty, crate::check_types::St> building_match(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Expr& scrut, const Array<crate::ast::Arm>& arms, const crate::ast::Range& span, const bool& last);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_building_match(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Expr scrut, Array<crate::ast::Arm> arms, crate::ast::Range span, bool last);

std::tuple<crate::check_types::Ty, crate::check_types::St> building_if(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Cond& c, const crate::ast::Block& then_b, const std::optional<crate::ast::Block>& else_b_opt, const crate::ast::Range& span, const bool& last);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_building_if(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Cond c, crate::ast::Block then_b, std::optional<crate::ast::Block> else_b_opt, crate::ast::Range span, bool last);

std::tuple<crate::check_types::Ty, crate::check_types::St> arm_widget_block(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Block& b);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_rebuild(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Expr& scrut, const crate::ast::Block& body, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_rebuild(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Expr scrut, crate::ast::Block body, crate::ast::Range span);

crate::check_expr::Env with_topic(const crate::check_expr::Env& env, const Text& name, const crate::check_types::Ty& t);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_for(const crate::check_expr::Env& env, const crate::check_types::St& st, const std::optional<crate::ast::ForBinders>& binders_opt, const crate::ast::Expr& source, const crate::ast::Block& body, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_for(crate::check_expr::Env env, crate::check_types::St st, std::optional<crate::ast::ForBinders> binders_opt, crate::ast::Expr source, crate::ast::Block body, crate::ast::Range span);

std::tuple<crate::check_types::Ty, crate::check_types::Ty, crate::check_types::St> coll_parts(const crate::check_types::St& st, const crate::check_types::Ty& t, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::Ty, crate::check_types::St>> start_coll_parts(crate::check_types::St st, crate::check_types::Ty t, crate::ast::Range span);

crate::check_expr::Env loop_indices(const crate::check_expr::Env& env);

std::tuple<crate::check_expr::Env, crate::check_types::St> bind_for_binders(const crate::check_expr::Env& env, const crate::check_types::St& st, const std::optional<crate::ast::ForBinders>& binders_opt, const crate::check_types::Ty& k, const crate::check_types::Ty& v_, const bool& live);

prism_rtl::JobRef<std::tuple<crate::check_expr::Env, crate::check_types::St>> start_bind_for_binders(crate::check_expr::Env env, crate::check_types::St st, std::optional<crate::ast::ForBinders> binders_opt, crate::check_types::Ty k, crate::check_types::Ty v_, bool live);

crate::check_expr::Env unpending(const crate::check_expr::Env& env);

std::tuple<crate::check_types::Ty, crate::check_types::St> gather(const crate::check_types::St& st, const crate::check_types::Ty& res, const crate::check_types::Ty& k, const bool& live);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_gather(crate::check_types::St st, crate::check_types::Ty res, crate::check_types::Ty k, bool live);

crate::check_types::Ty live_map(const bool& live, const crate::check_types::Ty& k, const crate::check_types::Ty& v_);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_given(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Block& b, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_given(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Block b, crate::ast::Range span);

Text given_mark_of(const Array<crate::ast::Stmt>& stmts);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_given_block(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Block& b, const Text& mark);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_given_block(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Block b, Text mark);

std::tuple<crate::check_expr::Env, crate::check_types::St, std::optional<crate::check_types::Ty>> given_stmt(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Stmt& s, const Text& mark, const bool& last, const std::optional<crate::check_types::Ty>& res_opt);

prism_rtl::JobRef<std::tuple<crate::check_expr::Env, crate::check_types::St, std::optional<crate::check_types::Ty>>> start_given_stmt(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Stmt s, Text mark, bool last, std::optional<crate::check_types::Ty> res_opt);

std::tuple<crate::check_types::Ty, crate::check_types::St> infer_update(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Expr& target, const crate::ast::Block& body, const crate::ast::Range& span);

prism_rtl::JobRef<std::tuple<crate::check_types::Ty, crate::check_types::St>> start_infer_update(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Expr target, crate::ast::Block body, crate::ast::Range span);

std::tuple<crate::check_expr::Env, crate::check_types::St> update_stmts(const crate::check_expr::Env& env, const crate::check_types::St& st, const Array<crate::ast::Stmt>& stmts);

prism_rtl::JobRef<std::tuple<crate::check_expr::Env, crate::check_types::St>> start_update_stmts(crate::check_expr::Env env, crate::check_types::St st, Array<crate::ast::Stmt> stmts);

std::tuple<crate::check_expr::Env, crate::check_types::St> update_stmt(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Stmt& s);

prism_rtl::JobRef<std::tuple<crate::check_expr::Env, crate::check_types::St>> start_update_stmt(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Stmt s);

crate::check_types::St ref_target(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Expr& e);

bool is_ref(const crate::ast::Expr& e);

crate::check_types::St update_if(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Cond& c, const crate::ast::Block& then_b, const std::optional<crate::ast::Block>& else_b_opt);

prism_rtl::JobRef<crate::check_types::St> start_update_if(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Cond c, crate::ast::Block then_b, std::optional<crate::ast::Block> else_b_opt);

crate::check_types::St update_match(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Expr& scrut, const Array<crate::ast::Arm>& arms, const crate::ast::Range& span);

prism_rtl::JobRef<crate::check_types::St> start_update_match(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Expr scrut, Array<crate::ast::Arm> arms, crate::ast::Range span);

crate::check_types::St update_while(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Cond& c, const crate::ast::Block& body);

prism_rtl::JobRef<crate::check_types::St> start_update_while(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Cond c, crate::ast::Block body);

crate::check_types::St update_for(const crate::check_expr::Env& env, const crate::check_types::St& st, const std::optional<crate::ast::ForBinders>& binders_opt, const crate::ast::Expr& source, const crate::ast::Block& body, const crate::ast::Range& span);

prism_rtl::JobRef<crate::check_types::St> start_update_for(crate::check_expr::Env env, crate::check_types::St st, std::optional<crate::ast::ForBinders> binders_opt, crate::ast::Expr source, crate::ast::Block body, crate::ast::Range span);

}  // namespace check_blocks


namespace check_blocks {

/// The step machine of `DepOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DepOrder: unbounded fn [Stmt] -> [ [Nat] ]
struct DepOrder : prism_rtl::Job<Array<Array<Nat>>> {
    Array<crate::ast::Stmt> stmts;
    DepOrder(Array<crate::ast::Stmt> stmts) : stmts(std::move(stmts)) {}
    prism_rtl::Turn<Array<Array<Nat>>> cycle() const override;
};


/// The step machine of `GroupDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GroupDefs: unbounded fn Stmt -> [Text]
struct GroupDefs : prism_rtl::Job<Array<Text>> {
    crate::ast::Stmt s;
    GroupDefs(crate::ast::Stmt s) : s(std::move(s)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ReachIdx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReachIdx: unbounded fn [ [Nat] ], [Nat], [Nat] -> [Nat]
struct ReachIdx : prism_rtl::Job<Array<Nat>> {
    Array<Array<Nat>> deps;
    Array<Nat> frontier;
    Array<Nat> seen;
    ReachIdx(Array<Array<Nat>> deps, Array<Nat> frontier, Array<Nat> seen) : deps(std::move(deps)), frontier(std::move(frontier)), seen(std::move(seen)) {}
    prism_rtl::Turn<Array<Nat>> cycle() const override;
};


/// The step machine of `EmitGroups`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EmitGroups: unbounded fn [ [Nat] ], [ [Nat] ], [Nat], [ [Nat] ] -> [ [Nat] ]
struct EmitGroups : prism_rtl::Job<Array<Array<Nat>>> {
    Array<Array<Nat>> comps;
    Array<Array<Nat>> deps;
    Array<Nat> done;
    Array<Array<Nat>> acc;
    EmitGroups(Array<Array<Nat>> comps, Array<Array<Nat>> deps, Array<Nat> done, Array<Array<Nat>> acc) : comps(std::move(comps)), deps(std::move(deps)), done(std::move(done)), acc(std::move(acc)) {}
    prism_rtl::Turn<Array<Array<Nat>>> cycle() const override;
};


/// The step machine of `InferWidgetBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
struct InferWidgetBlock : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Block b;
    InferWidgetBlock(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Block b) : env(std::move(env)), st(std::move(st)), b(std::move(b)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `BlockRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockRow: unbounded fn Env, St, [Stmt] -> ((Env, St))
struct BlockRow : prism_rtl::Job<std::tuple<crate::check_expr::Env, crate::check_types::St>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    Array<crate::ast::Stmt> stmts;
    BlockRow(crate::check_expr::Env env, crate::check_types::St st, Array<crate::ast::Stmt> stmts) : env(std::move(env)), st(std::move(st)), stmts(std::move(stmts)) {}
    prism_rtl::Turn<std::tuple<crate::check_expr::Env, crate::check_types::St>> cycle() const override;
};


/// The step machine of `PreBindStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreBindStmt: unbounded fn Env, St, Stmt -> ((Env, St))
struct PreBindStmt : prism_rtl::Job<std::tuple<crate::check_expr::Env, crate::check_types::St>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Stmt s;
    PreBindStmt(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Stmt s) : env(std::move(env)), st(std::move(st)), s(std::move(s)) {}
    prism_rtl::Turn<std::tuple<crate::check_expr::Env, crate::check_types::St>> cycle() const override;
};


/// The step machine of `PreBindPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreBindPattern: unbounded fn Env, St, Pattern -> ((Env, St))
struct PreBindPattern : prism_rtl::Job<std::tuple<crate::check_expr::Env, crate::check_types::St>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Pattern_ p_;
    PreBindPattern(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Pattern_ p_) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::check_expr::Env, crate::check_types::St>> cycle() const override;
};


/// The step machine of `WidgetStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WidgetStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St, ?Ty))
struct WidgetStmt : prism_rtl::Job<std::tuple<crate::check_expr::Env, crate::check_types::St, std::optional<crate::check_types::Ty>>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Stmt s;
    bool last;
    WidgetStmt(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Stmt s, bool last) : env(std::move(env)), st(std::move(st)), s(std::move(s)), last(std::move(last)) {}
    prism_rtl::Turn<std::tuple<crate::check_expr::Env, crate::check_types::St, std::optional<crate::check_types::Ty>>> cycle() const override;
};


/// The step machine of `BindStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindStmt: unbounded fn Env, St, Pattern, Expr, Range -> St
struct BindStmt : prism_rtl::Job<crate::check_types::St> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Pattern_ p_;
    crate::ast::Expr e;
    crate::ast::Range span;
    BindStmt(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Pattern_ p_, crate::ast::Expr e, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)), e(std::move(e)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `BindOutput`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindOutput: unbounded fn Env, St, Ty, Range -> ((Ty, St))
struct BindOutput : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::check_types::Ty t;
    crate::ast::Range span;
    BindOutput(crate::check_expr::Env env, crate::check_types::St st, crate::check_types::Ty t, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `HoldStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HoldStmt: unbounded fn Env, St, Pattern, Expr, Expr, Range -> St
struct HoldStmt : prism_rtl::Job<crate::check_types::St> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Pattern_ p_;
    crate::ast::Expr init;
    crate::ast::Expr step_;
    crate::ast::Range span;
    HoldStmt(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Pattern_ p_, crate::ast::Expr init, crate::ast::Expr step_, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)), init(std::move(init)), step_(std::move(step_)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `IgnoreStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IgnoreStmt: unbounded fn Env, St, Expr, Range -> St
struct IgnoreStmt : prism_rtl::Job<crate::check_types::St> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Expr e;
    crate::ast::Range span;
    IgnoreStmt(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Expr e, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), e(std::move(e)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `BareLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BareLine: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
struct BareLine : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Expr e;
    bool last;
    BareLine(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Expr e, bool last) : env(std::move(env)), st(std::move(st)), e(std::move(e)), last(std::move(last)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `BareLineKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BareLineKind: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
struct BareLineKind : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Expr e;
    bool last;
    BareLineKind(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Expr e, bool last) : env(std::move(env)), st(std::move(st)), e(std::move(e)), last(std::move(last)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `Discarded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Discarded: unbounded fn St, Ty, Range -> St
struct Discarded : prism_rtl::Job<crate::check_types::St> {
    crate::check_types::St st;
    crate::check_types::Ty t;
    crate::ast::Range span;
    Discarded(crate::check_types::St st, crate::check_types::Ty t, crate::ast::Range span) : st(std::move(st)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `BuildingMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildingMatch: unbounded fn Env, St, Expr, [Arm], Range, Bool -> ((Ty, St))
struct BuildingMatch : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Expr scrut;
    Array<crate::ast::Arm> arms;
    crate::ast::Range span;
    bool last;
    BuildingMatch(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Expr scrut, Array<crate::ast::Arm> arms, crate::ast::Range span, bool last) : env(std::move(env)), st(std::move(st)), scrut(std::move(scrut)), arms(std::move(arms)), span(std::move(span)), last(std::move(last)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `BuildingIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildingIf: unbounded fn Env, St, Cond, Block, ?Block, Range, Bool -> ((Ty, St))
struct BuildingIf : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Cond c;
    crate::ast::Block then_b;
    std::optional<crate::ast::Block> else_b_opt;
    crate::ast::Range span;
    bool last;
    BuildingIf(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Cond c, crate::ast::Block then_b, std::optional<crate::ast::Block> else_b_opt, crate::ast::Range span, bool last) : env(std::move(env)), st(std::move(st)), c(std::move(c)), then_b(std::move(then_b)), else_b_opt(std::move(else_b_opt)), span(std::move(span)), last(std::move(last)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferRebuild`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferRebuild: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
struct InferRebuild : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Expr scrut;
    crate::ast::Block body;
    crate::ast::Range span;
    InferRebuild(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Expr scrut, crate::ast::Block body, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), scrut(std::move(scrut)), body(std::move(body)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> ((Ty, St))
struct InferFor : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    std::optional<crate::ast::ForBinders> binders_opt;
    crate::ast::Expr source;
    crate::ast::Block body;
    crate::ast::Range span;
    InferFor(crate::check_expr::Env env, crate::check_types::St st, std::optional<crate::ast::ForBinders> binders_opt, crate::ast::Expr source, crate::ast::Block body, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), binders_opt(std::move(binders_opt)), source(std::move(source)), body(std::move(body)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `CollParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CollParts: unbounded fn St, Ty, Range -> ((Ty, Ty, St))
struct CollParts : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::Ty, crate::check_types::St>> {
    crate::check_types::St st;
    crate::check_types::Ty t;
    crate::ast::Range span;
    CollParts(crate::check_types::St st, crate::check_types::Ty t, crate::ast::Range span) : st(std::move(st)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `BindForBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindForBinders: unbounded fn Env, St, ?ForBinders, Ty, Ty, Bool -> ((Env, St))
struct BindForBinders : prism_rtl::Job<std::tuple<crate::check_expr::Env, crate::check_types::St>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    std::optional<crate::ast::ForBinders> binders_opt;
    crate::check_types::Ty k;
    crate::check_types::Ty v_;
    bool live;
    BindForBinders(crate::check_expr::Env env, crate::check_types::St st, std::optional<crate::ast::ForBinders> binders_opt, crate::check_types::Ty k, crate::check_types::Ty v_, bool live) : env(std::move(env)), st(std::move(st)), binders_opt(std::move(binders_opt)), k(std::move(k)), v_(std::move(v_)), live(std::move(live)) {}
    prism_rtl::Turn<std::tuple<crate::check_expr::Env, crate::check_types::St>> cycle() const override;
};


/// The step machine of `Gather`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Gather: unbounded fn St, Ty, Ty, Bool -> ((Ty, St))
struct Gather : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    crate::check_types::St st;
    crate::check_types::Ty res;
    crate::check_types::Ty k;
    bool live;
    Gather(crate::check_types::St st, crate::check_types::Ty res, crate::check_types::Ty k, bool live) : st(std::move(st)), res(std::move(res)), k(std::move(k)), live(std::move(live)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferGiven`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferGiven: unbounded fn Env, St, Block, Range -> ((Ty, St))
struct InferGiven : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Block b;
    crate::ast::Range span;
    InferGiven(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Block b, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), b(std::move(b)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `InferGivenBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferGivenBlock: unbounded fn Env, St, Block, Text -> ((Ty, St))
struct InferGivenBlock : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Block b;
    Text mark;
    InferGivenBlock(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Block b, Text mark) : env(std::move(env)), st(std::move(st)), b(std::move(b)), mark(std::move(mark)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `GivenStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GivenStmt: unbounded fn Env, St, Stmt, Text, Bool, ?Ty -> ((Env, St, ?Ty))
struct GivenStmt : prism_rtl::Job<std::tuple<crate::check_expr::Env, crate::check_types::St, std::optional<crate::check_types::Ty>>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Stmt s;
    Text mark;
    bool last;
    std::optional<crate::check_types::Ty> res_opt;
    GivenStmt(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Stmt s, Text mark, bool last, std::optional<crate::check_types::Ty> res_opt) : env(std::move(env)), st(std::move(st)), s(std::move(s)), mark(std::move(mark)), last(std::move(last)), res_opt(std::move(res_opt)) {}
    prism_rtl::Turn<std::tuple<crate::check_expr::Env, crate::check_types::St, std::optional<crate::check_types::Ty>>> cycle() const override;
};


/// The step machine of `InferUpdate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferUpdate: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
struct InferUpdate : prism_rtl::Job<std::tuple<crate::check_types::Ty, crate::check_types::St>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Expr target;
    crate::ast::Block body;
    crate::ast::Range span;
    InferUpdate(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Expr target, crate::ast::Block body, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), target(std::move(target)), body(std::move(body)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::Ty, crate::check_types::St>> cycle() const override;
};


/// The step machine of `UpdateStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateStmts: unbounded fn Env, St, [Stmt] -> ((Env, St))
struct UpdateStmts : prism_rtl::Job<std::tuple<crate::check_expr::Env, crate::check_types::St>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    Array<crate::ast::Stmt> stmts;
    UpdateStmts(crate::check_expr::Env env, crate::check_types::St st, Array<crate::ast::Stmt> stmts) : env(std::move(env)), st(std::move(st)), stmts(std::move(stmts)) {}
    prism_rtl::Turn<std::tuple<crate::check_expr::Env, crate::check_types::St>> cycle() const override;
};


/// The step machine of `UpdateStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateStmt: unbounded fn Env, St, Stmt -> ((Env, St))
struct UpdateStmt : prism_rtl::Job<std::tuple<crate::check_expr::Env, crate::check_types::St>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Stmt s;
    UpdateStmt(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Stmt s) : env(std::move(env)), st(std::move(st)), s(std::move(s)) {}
    prism_rtl::Turn<std::tuple<crate::check_expr::Env, crate::check_types::St>> cycle() const override;
};


/// The step machine of `UpdateIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateIf: unbounded fn Env, St, Cond, Block, ?Block -> St
struct UpdateIf : prism_rtl::Job<crate::check_types::St> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Cond c;
    crate::ast::Block then_b;
    std::optional<crate::ast::Block> else_b_opt;
    UpdateIf(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Cond c, crate::ast::Block then_b, std::optional<crate::ast::Block> else_b_opt) : env(std::move(env)), st(std::move(st)), c(std::move(c)), then_b(std::move(then_b)), else_b_opt(std::move(else_b_opt)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `UpdateMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateMatch: unbounded fn Env, St, Expr, [Arm], Range -> St
struct UpdateMatch : prism_rtl::Job<crate::check_types::St> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Expr scrut;
    Array<crate::ast::Arm> arms;
    crate::ast::Range span;
    UpdateMatch(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Expr scrut, Array<crate::ast::Arm> arms, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), scrut(std::move(scrut)), arms(std::move(arms)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `UpdateWhile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateWhile: unbounded fn Env, St, Cond, Block -> St
struct UpdateWhile : prism_rtl::Job<crate::check_types::St> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Cond c;
    crate::ast::Block body;
    UpdateWhile(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Cond c, crate::ast::Block body) : env(std::move(env)), st(std::move(st)), c(std::move(c)), body(std::move(body)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `UpdateFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> St
struct UpdateFor : prism_rtl::Job<crate::check_types::St> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    std::optional<crate::ast::ForBinders> binders_opt;
    crate::ast::Expr source;
    crate::ast::Block body;
    crate::ast::Range span;
    UpdateFor(crate::check_expr::Env env, crate::check_types::St st, std::optional<crate::ast::ForBinders> binders_opt, crate::ast::Expr source, crate::ast::Block body, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), binders_opt(std::move(binders_opt)), source(std::move(source)), body(std::move(body)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


}  // namespace check_blocks

}  // namespace crate
