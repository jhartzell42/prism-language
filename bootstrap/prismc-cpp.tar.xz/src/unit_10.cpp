// The modules `Check.Errors`, `Check.Expr`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/errors/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/expr/module.hpp>
#include <check/env/module.hpp>
#include <check/types/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>

// The module `Check.Errors`, from `target/bootstrap/cpp-src/prismc/check/errors.prism`.
namespace crate::check::errors {

void CDiag::show(Printer& p) const {
    p.record("CDiag", {{"code", code_p}, {"file", file_p}, {"span", span_p}, {"message", message_p}, {"fix", fix_p}});
}

Pod CDiag::to_pod() const {
    return Pod::record("CDiag", {{"code", prism_rtl::to_pod(code_p)}, {"file", prism_rtl::to_pod(file_p)}, {"span", prism_rtl::to_pod(span_p)}, {"message", prism_rtl::to_pod(message_p)}, {"fix", prism_rtl::to_pod(fix_p)}});
}

Result<CDiag> CDiag::from_pod(const Pod& whole) {
    return CDiag{.code_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "code")))), .file_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .message_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "message")))), .fix_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "fix"))))};
}


bool Src::operator==(const Src& o) const { return path_p == o.path_p && text_p == o.text_p && starts_p == o.starts_p && segs_p == o.segs_p; }

void Src::show(Printer& p) const {
    p.record("Src", {{"path", path_p}, {"text", text_p}, {"starts", starts_p}, {"segs", segs_p}});
}

Pod Src::to_pod() const {
    return Pod::record("Src", {{"path", prism_rtl::to_pod(path_p)}, {"text", prism_rtl::to_pod(text_p)}, {"starts", prism_rtl::to_pod(starts_p)}, {"segs", prism_rtl::to_pod(segs_p)}});
}

Result<Src> Src::from_pod(const Pod& whole) {
    return Src{.path_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .text_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "text")))), .starts_p = TRY(prism_rtl::from_pod<Array<Nat>>(TRY(crate::prelude::field(whole, "starts")))), .segs_p = TRY(prism_rtl::from_pod<Array<SrcSeg>>(TRY(crate::prelude::field(whole, "segs"))))};
}


void SrcSeg::show(Printer& p) const {
    p.record("SrcSeg", {{"path", path_p}, {"start", start_p}, {"line", line_p}, {"role", role_p}});
}

Pod SrcSeg::to_pod() const {
    return Pod::record("SrcSeg", {{"path", prism_rtl::to_pod(path_p)}, {"start", prism_rtl::to_pod(start_p)}, {"line", prism_rtl::to_pod(line_p)}, {"role", prism_rtl::to_pod(role_p)}});
}

Result<SrcSeg> SrcSeg::from_pod(const Pod& whole) {
    return SrcSeg{.path_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .start_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "start")))), .line_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "line")))), .role_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "role"))))};
}


/// MkSrc: fn Text, Text -> Src
Src mk_src_f(const Text& path_p0, const Text& text_p1) {
    return Src{.path_p = path_p0, .text_p = text_p1, .starts_p = cline_starts_f(text_p1), .segs_p = Array(std::vector{SrcSeg{.path_p = path_p0, .start_p = Nat(0u), .line_p = Nat(0u), .role_p = Text::lit("loose")}})};
}


/// MkJoinedSrc: fn [((Text, Text, Text))] -> Src
Src mk_joined_src_f(const Array<std::tuple<Text, Text, Text>>& files_p0) {
    auto text_p1 = crate::syntax::lexer::chars::join_f(crate::prelude::each(files_p0, [&](const std::tuple<Text, Text, Text>& _p0) {
        auto&& t_p4 = std::get<1>(_p0);
        return t_p4;
    }), Text::lit("\n"));
    auto starts_p2 = cline_starts_f(text_p1);
    auto&& _segs_pa = crate::prelude::fold(files_p0, std::tuple{Array<SrcSeg>{}, Nat(0u)}, [&](const std::tuple<Array<SrcSeg>, Nat>& _p0, const std::tuple<Text, Text, Text>& _p1) {
        auto&& acc_p5 = std::get<0>(_p0);
        auto&& at_p6 = std::get<1>(_p0);
        auto&& path_p7 = std::get<0>(_p1);
        auto&& t_p8 = std::get<1>(_p1);
        auto&& role_p9 = std::get<2>(_p1);
        return std::tuple{crate::prelude::push(acc_p5, SrcSeg{.path_p = path_p7, .start_p = at_p6, .line_p = cline_of_f(starts_p2, at_p6), .role_p = role_p9}), (at_p6 + crate::prelude::len_text(t_p8)) + Nat(1u)};
    });
    auto&& segs_pa = std::get<0>(_segs_pa);
    auto first_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::prelude::index(files_p0, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& path_pb = std::get<0>(prism_rtl::some_of(_m));
            _v.set(path_pb);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return Src{.path_p = first_p3, .text_p = text_p1, .starts_p = starts_p2, .segs_p = segs_pa};
}


/// SegAt: fn Src, Nat -> SrcSeg
SrcSeg seg_at_f(const Src& src_p0, const Nat& offset_p1) {
    return crate::prelude::fold(src_p0.segs_p, crate::prelude::or_(crate::prelude::index(src_p0.segs_p, Nat(0u)), SrcSeg{.path_p = src_p0.path_p, .start_p = Nat(0u), .line_p = Nat(0u), .role_p = Text::lit("loose")}), [&](const SrcSeg& found_p2, const SrcSeg& s_p3) { return prism_rtl::deref(s_p3).start_p <= offset_p1 ? s_p3 : found_p2; });
}


/// SrcPlace: fn Src, Nat -> Text
Text src_place_f(const Src& src_p0, const Nat& offset_p1) {
    auto seg_p2 = seg_at_f(src_p0, offset_p1);
    return prism_rtl::cat(prism_rtl::deref(seg_p2).path_p, ":", crate::prelude::or_(cline_of_f(src_p0.starts_p, offset_p1).checked_sub(prism_rtl::deref(seg_p2).line_p), Nat(0u)) + Nat(1u));
}


/// Diag0: fn Text, Nat, Range, Text -> CDiag
CDiag diag0_f(const Text& code_p0, const Nat& file_p1, const crate::syntax::Range& span_p2, const Text& message_p3) {
    return CDiag{.code_p = code_p0, .file_p = file_p1, .span_p = span_p2, .message_p = message_p3, .fix_p = Text::lit("")};
}


/// DiagFix: fn Text, Nat, Range, Text, Text -> CDiag
CDiag diag_fix_f(const Text& code_p0, const Nat& file_p1, const crate::syntax::Range& span_p2, const Text& message_p3, const Text& fix_p4) {
    return CDiag{.code_p = code_p0, .file_p = file_p1, .span_p = span_p2, .message_p = message_p3, .fix_p = fix_p4};
}


/// CLineStarts: fn Text -> [Nat]
Array<Nat> cline_starts_f(const Text& text_p0) {
    auto&& _starts_p4 = crate::prelude::fold(crate::prelude::split_on(text_p0, Text::lit("\n")), std::tuple{Array<Nat>{}, Nat(0u)}, [&](const std::tuple<Array<Nat>, Nat>& _p0, const Text& line_p3) {
        auto&& acc_p1 = std::get<0>(_p0);
        auto&& at_p2 = std::get<1>(_p0);
        return std::tuple{crate::prelude::push(acc_p1, at_p2), (at_p2 + crate::prelude::len_text(line_p3)) + Nat(1u)};
    });
    auto&& starts_p4 = std::get<0>(_starts_p4);
    return starts_p4;
}


/// CLineOf: fn [Nat], Nat -> Nat
Nat cline_of_f(const Array<Nat>& starts_p0, const Nat& offset_p1) {
    return crate::syntax::lexer::chars::dec_f(crate::prelude::fold(starts_p0, Nat(0u), [&](const Nat& n_p2, const Nat& s_p3) { return s_p3 <= offset_p1 ? n_p2 + Nat(1u) : n_p2; }));
}


/// LineText: fn Src, Nat -> Text
Text line_text_f(const Src& src_p0, const Nat& n_p1) {
    auto from_p2 = crate::prelude::or_(crate::prelude::index(src_p0.starts_p, n_p1), Nat(0u));
    auto to_p3 = crate::prelude::or_(crate::prelude::index(src_p0.starts_p, n_p1 + Nat(1u)), crate::prelude::len_text(src_p0.text_p) + Nat(1u));
    return crate::syntax::lexer::chars::between_f(src_p0.text_p, from_p2, crate::prelude::max(from_p2, crate::prelude::or_(to_p3.checked_sub(Nat(1u)), Nat(0u))));
}


/// SpanText: fn Src, Range -> Text
Text span_text_f(const Src& src_p0, const crate::syntax::Range& r_p1) {
    return crate::syntax::lexer::chars::between_f(src_p0.text_p, r_p1.start_p, crate::prelude::max(r_p1.start_p, r_p1.end_p));
}


/// Repeat: fn Text, Nat -> Text
Text repeat_f(const Text& t_p0, const Nat& n_p1) {
    return crate::prelude::concat(crate::prelude::fold(range0_f(n_p1), Array<Text>{}, [&](const Array<Text>& acc_p2, const Nat& _p1) { return crate::prelude::push(acc_p2, t_p0); }));
}


/// Range0: fn Nat -> [Nat]
Array<Nat> range0_f(const Nat& n_p0) {
    Array<Nat> this_ = Array<Nat>{};
    Nat i_p1 = Nat(0u);
    Nat left_p2 = n_p0;
    while (true) {
        auto&& _m = left_p2.checked_sub(Nat(1u));
        if (!(prism_rtl::is_some(_m))) break;
        auto&& m_p3 = prism_rtl::some_of(_m);
        left_p2 = m_p3;
        this_ = crate::prelude::push(this_, i_p1);
        i_p1 = i_p1 + Nat(1u);
    }
    return this_;
}


/// RenderCDiag: fn [Src], CDiag -> Text
Text render_cdiag_f(const Array<Src>& srcs_p0, const CDiag& d_p1) {
    auto&& _m = crate::prelude::index(srcs_p0, d_p1.file_p);
    if (prism_rtl::is_none(_m)) {
        return prism_rtl::cat("?: ", severity_f(d_p1), "[", d_p1.code_p, "]: ", d_p1.message_p, "\n");
    }
    if (prism_rtl::is_some(_m)) {
        auto&& src_p2 = prism_rtl::some_of(_m);
        auto line_p3 = cline_of_f(prism_rtl::deref(src_p2).starts_p, prism_rtl::deref(d_p1.span_p).start_p);
        auto col_p4 = crate::syntax::lexer::chars::column_of_f(prism_rtl::deref(src_p2).text_p, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(src_p2).starts_p, line_p3), Nat(0u)), prism_rtl::deref(d_p1.span_p).start_p);
        auto text_p5 = line_text_f(src_p2, line_p3);
        auto width_p6 = crate::prelude::max(Nat(1u), crate::prelude::min(crate::syntax::lexer::chars::count_chars_f(span_text_f(src_p2, d_p1.span_p)), crate::prelude::or_(crate::syntax::lexer::chars::count_chars_f(text_p5).checked_sub(col_p4), Nat(1u))));
        auto carets_p7 = prism_rtl::cat("    ", repeat_f(Text::lit(" "), col_p4), repeat_f(Text::lit("^"), width_p6));
        auto fix_p8 = d_p1.fix_p == Text::lit("")
            ? Text::lit("")
            : prism_rtl::cat("  fix: ", d_p1.fix_p, "\n");
        return prism_rtl::cat(src_place_f(src_p2, prism_rtl::deref(d_p1.span_p).start_p), ": ", severity_f(d_p1), "[", d_p1.code_p, "]: ", d_p1.message_p, "\n    ", text_p5, "\n", carets_p7, "\n", fix_p8);
    }
    prism_rtl::unreachable("no arm matched");
}


/// Severity: fn CDiag -> Text
Text severity_f(const CDiag& d_p0) {
    return is_warning_f(d_p0) ? Text::lit("warning") : Text::lit("error");
}


/// IsWarning: fn CDiag -> Bool
bool is_warning_f(const CDiag& d_p0) {
    return d_p0.code_p == Text::lit("unused");
}


/// SortDiags: fn [CDiag] -> [CDiag]
Array<CDiag> sort_diags_f(const Array<CDiag>& ds_p0) {
    return crate::prelude::fold(ds_p0, Array<CDiag>{}, [&](const Array<CDiag>& acc_p1, const CDiag& d_p2) { return insert_sorted_f(acc_p1, d_p2); });
}


/// InsertSorted: fn [CDiag], CDiag -> [CDiag]
Array<CDiag> insert_sorted_f(const Array<CDiag>& acc_p0, const CDiag& d_p1) {
    auto before_p2 = crate::prelude::filter(acc_p0, [&](const CDiag& x_p4) { return !diag_before2_f(d_p1, x_p4); });
    auto after_p3 = crate::prelude::filter(acc_p0, [&](const CDiag& x_p5) { return diag_before2_f(d_p1, x_p5); });
    return any_is_f(acc_p0, d_p1)
        ? acc_p0
        : crate::prelude::append(crate::prelude::push(before_p2, d_p1), after_p3);
}


/// AnyIs: fn [CDiag], CDiag -> Bool
bool any_is_f(const Array<CDiag>& xs_p0, const CDiag& d_p1) {
    return crate::prelude::fold(xs_p0, false, [&](const bool& seen_p2, const CDiag& x_p3) { return prism_rtl::deref(seen_p2) || (x_p3 == d_p1); });
}


/// DiagBefore2: fn CDiag, CDiag -> Bool
bool diag_before2_f(const CDiag& a_p0, const CDiag& b_p1) {
    return a_p0.file_p != b_p1.file_p
        ? a_p0.file_p < b_p1.file_p
        : prism_rtl::deref(a_p0.span_p).start_p < prism_rtl::deref(b_p1.span_p).start_p;
}


/// CountWord: fn Nat -> Text
Text count_word_f(const Nat& n0) {
    {
        auto&& c0_0 = n0;
        if (c0_0 == Nat(0u)) {
            return Text::lit("no");
        }
    }
    {
        auto&& c1_0 = n0;
        if (c1_0 == Nat(1u)) {
            return Text::lit("one");
        }
    }
    {
        auto&& c2_0 = n0;
        if (c2_0 == Nat(2u)) {
            return Text::lit("two");
        }
    }
    {
        auto&& c3_0 = n0;
        if (c3_0 == Nat(3u)) {
            return Text::lit("three");
        }
    }
    {
        auto&& c4_0 = n0;
        if (c4_0 == Nat(4u)) {
            return Text::lit("four");
        }
    }
    {
        auto&& n_p0 = n0;
        return crate::prelude::show_text(n_p0);
    }
}

}  // namespace crate::check::errors


// The module `Check.Expr`, from `target/bootstrap/cpp-src/prismc/check/expr/mod.prism`.
namespace crate::check::expr {

bool Env::operator==(const Env& o) const { return g_p == o.g_p && home_p == o.home_p && file_p == o.file_p && src_p == o.src_p && locals_p == o.locals_p && scope_p == o.scope_p && givens_p == o.givens_p && mark_p == o.mark_p && in_update_p == o.in_update_p && def_name_p == o.def_name_p && refine_p == o.refine_p && pending_p == o.pending_p && ids_p == o.ids_p; }

void Env::show(Printer& p) const {
    p.record("Env", {{"g", g_p}, {"home", home_p}, {"file", file_p}, {"src", src_p}, {"locals", locals_p}, {"scope", scope_p}, {"givens", givens_p}, {"mark", mark_p}, {"inUpdate", in_update_p}, {"defName", def_name_p}, {"refine", refine_p}, {"pending", pending_p}, {"ids", ids_p}});
}

Pod Env::to_pod() const {
    return Pod::record("Env", {{"g", prism_rtl::to_pod(g_p)}, {"home", prism_rtl::to_pod(home_p)}, {"file", prism_rtl::to_pod(file_p)}, {"src", prism_rtl::to_pod(src_p)}, {"locals", prism_rtl::to_pod(locals_p)}, {"scope", prism_rtl::to_pod(scope_p)}, {"givens", prism_rtl::to_pod(givens_p)}, {"mark", prism_rtl::to_pod(mark_p)}, {"inUpdate", prism_rtl::to_pod(in_update_p)}, {"defName", prism_rtl::to_pod(def_name_p)}, {"refine", prism_rtl::to_pod(refine_p)}, {"pending", prism_rtl::to_pod(pending_p)}, {"ids", prism_rtl::to_pod(ids_p)}});
}

Result<Env> Env::from_pod(const Pod& whole) {
    return Env{.g_p = TRY(prism_rtl::from_pod<crate::check::env::G>(TRY(crate::prelude::field(whole, "g")))), .home_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .file_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .src_p = TRY(prism_rtl::from_pod<crate::check::errors::Src>(TRY(crate::prelude::field(whole, "src")))), .locals_p = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Scheme>>(TRY(crate::prelude::field(whole, "locals")))), .scope_p = TRY(prism_rtl::from_pod<crate::check::types::Rw>(TRY(crate::prelude::field(whole, "scope")))), .givens_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "givens")))), .mark_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "mark")))), .in_update_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "inUpdate")))), .def_name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "defName")))), .refine_p = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "refine")))), .pending_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "pending")))), .ids_p = TRY(prism_rtl::from_pod<Map<Text, Nat>>(TRY(crate::prelude::field(whole, "ids"))))};
}


/// WithLocal: fn Env, Text, Scheme -> Env
Env with_local_f(const Env& env_p0, const Text& name_p1, const crate::check::types::Scheme& sc_p2) {
    Env this_ = env_p0;
    this_.locals_p = crate::prelude::insert(this_.locals_p, name_p1, sc_p2);
    return this_;
}


/// CallId: fn St, Text, Range -> St
crate::check::types::St call_id_f(const crate::check::types::St& st_p0, const Text& qk_p1, const crate::syntax::Range& span_p2) {
    return !crate::syntax::lexer::chars::has_prefix_f(crate::check::types::bare_name_f(qk_p1), Text::lit("@"))
        ? st_p0
        : ({
        auto s2_p3 = ({
            crate::check::types::St this_ = st_p0;
            this_.local_next_p = this_.local_next_p + Nat(1u);
            (std::move(this_));
        });
        (crate::check::types::recording::note_call_f(s2_p3, span_p2, st_p0.local_next_p));
    });
}


/// BindLocalId: fn Env, St, Text, Range -> ((Env, St))
std::tuple<Env, crate::check::types::St> bind_local_id_f(const Env& env_p0, const crate::check::types::St& st_p1, const Text& name_p2, const crate::syntax::Range& span_p3) {
    auto place_p4 = prism_rtl::cat(st_p1.file_p, ":", span_p3.start_p, ":", span_p3.end_p);
    auto [id_p9, st2_pa] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, crate::check::types::St>> _v;
        auto&& _m = crate::prelude::get(st_p1.local_ids_p, place_p4);
        if (prism_rtl::is_some(_m)) {
            auto&& i_p6 = prism_rtl::some_of(_m);
            _v.set(std::tuple{i_p6, st_p1});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                auto fresh_p7 = st_p1.local_next_p;
                auto s2_p8 = ({
                    crate::check::types::St this_ = st_p1;
                    this_.local_next_p = this_.local_next_p + Nat(1u);
                    this_.local_ids_p = crate::prelude::insert(this_.local_ids_p, place_p4, fresh_p7);
                    (std::move(this_));
                });
                std::tuple{fresh_p7, crate::check::types::recording::note_local_f(s2_p8, span_p3, fresh_p7)};
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto env2_p5 = ({
        Env this_ = env_p0;
        this_.ids_p = crate::prelude::insert(this_.ids_p, name_p2, id_p9);
        (std::move(this_));
    });
    return std::tuple{env2_p5, st2_pa};
}


/// SrcText: fn Env, Range -> Text
Text src_text_f(const Env& env_p0, const crate::syntax::Range& r_p1) {
    return crate::check::errors::span_text_f(env_p0.src_p, r_p1);
}


/// IsComparison: fn Text -> Bool
bool is_comparison_f(const Text& n_p0) {
    return crate::check::types::has_text_f(Array(std::vector{Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit("<="), Text::lit(">"), Text::lit(">="), Text::lit("Compare"), Text::lit("?"), Text::lit("~"), Text::lit("$")}), n_p0);
}


/// HasTimeMark: fn Text -> Bool
bool has_time_mark_f(const Text& marks_p0) {
    return crate::syntax::lexer::chars::contains_f(marks_p0, Text::lit("$")) || crate::syntax::lexer::chars::contains_f(marks_p0, Text::lit("!"));
}


/// IsTimeSigil: fn Text -> Bool
bool is_time_sigil_f(const Text& s_p0) {
    return (s_p0 == Text::lit("$")) || (s_p0 == Text::lit("!"));
}


/// IsPlainSigil: fn Text -> Bool
bool is_plain_sigil_f(const Text& s_p0) {
    return (s_p0 == Text::lit("?")) || (s_p0 == Text::lit("~"));
}


/// InnerOf: unbounded fn St, Ty -> Ty
crate::check::types::Ty inner_of_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    auto&& _m = crate::check::types::recording::walk_f(st_p0, t_p1);
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& i_p2 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return prism_rtl::deref(i_p2);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
        auto&& i_p3 = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
        return prism_rtl::deref(i_p3);
    }
    {
        auto&& other_p4 = _m;
        return other_p4;
    }
}


prism_rtl::Turn<crate::check::types::Ty> InnerOf::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0x = st_p0;
    auto t_p1x = t_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x, t_p1x), [=](crate::check::types::Ty walk_f_4169) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TySig>(walk_f_4169) ? ({
            auto&& i_p2 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_4169).a1;
            prism_rtl::finished(prism_rtl::deref(i_p2));
        })
            : prism_rtl::is<crate::check::types::Ty::TyAt>(walk_f_4169) ? ({
            auto&& i_p3 = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_f_4169).a0;
            prism_rtl::finished(prism_rtl::deref(i_p3));
        })
            : ({
            auto&& other_p4 = walk_f_4169;
            prism_rtl::finished(other_p4);
        });
        });
    });
}


/// `Start InnerOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_inner_of_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<InnerOf>(st_p0, t_p1);
}


/// IsLambda: fn Expr -> Bool
bool is_lambda_f(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicField>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p1 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_lambda_f(prism_rtl::deref(prism_rtl::deref(x_p1)));
    }
    {
        return false;
    }
}


/// Infer: unbounded fn Env, St, Expr -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f(const Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2) {
    auto [t_p3, st2_p4] = infer_kind_f(env_p0, st_p1, e_p2);
    return std::tuple{t_p3, crate::check::types::recording::note_ty_f(st2_p4, e_p2.span_p, t_p3)};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> Infer::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& e_p2 = this->e_p2;
    auto e_p2x = e_p2;
    auto env_p0x = env_p0;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(start_infer_kind_f(env_p0x, st_p1x, e_p2x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_kind_f_4721) {
        return ({
            auto [t_p3, st2_p4] = infer_kind_f_4721;
            (prism_rtl::finished(std::tuple{t_p3, crate::check::types::recording::note_ty_f(st2_p4, prism_rtl::deref(e_p2x).span_p, t_p3)}));
        });
    });
}


/// `Start Infer, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_f(Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<Infer>(env_p0, st_p1, e_p2);
}


/// InferKind: unbounded fn Env, St, Expr -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_kind_f(const Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = prism_rtl::deref(e_p2.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return infer_name_f(env_p0, st_p1, n_p3, e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l_p4 = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        return infer_lit_f(env_p0, st_p1, l_p4, false, e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnit>(_m)) {
        auto&& marks_p5 = prism_rtl::as<crate::syntax::ExprKind::EUnit>(_m).a0;
        return std::tuple{crate::check::types::with_marks_f(marks_p5, crate::check::types::t_unit_p(), env_p0.scope_p), st_p1};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENil>(_m)) {
        auto&& marks_p6 = prism_rtl::as<crate::syntax::ExprKind::ENil>(_m).a0;
        auto [v_p7, st2_p8] = crate::check::types::fresh_var_f(st_p1, false, Text::lit(""));
        return std::tuple{crate::check::types::with_marks_f(marks_p6, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_p7)}), env_p0.scope_p), st2_p8};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBound>(_m)) {
        auto&& b_p9 = prism_rtl::as<crate::syntax::ExprKind::EBound>(_m).a0;
        return infer_bound_f(env_p0, st_p1, b_p9, e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es_pa = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        auto [ts_pb, st2_pc] = infer_all_f(env_p0, st_p1, es_pa);
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyTuple{ts_pb}), st2_pc};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& es_pd = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        return crate::check::expr::operators::infer_array_f(env_p0, st_p1, es_pd, e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& entries_pe = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        return crate::check::expr::operators::infer_map_f(env_p0, st_p1, entries_pe, e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_pf = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return infer_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_pf)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& callee_pg = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_ph = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return crate::check::expr::calls::infer_call_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(callee_pg)), args_ph, e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& op_pi = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& lhs_pj = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& rhs_pk = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return crate::check::expr::operators::infer_binary_f(env_p0, st_p1, op_pi, prism_rtl::deref(prism_rtl::deref(lhs_pj)), prism_rtl::deref(prism_rtl::deref(rhs_pk)), e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& op_pl = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
        auto&& x_pm = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return crate::check::expr::operators::infer_unary_f(env_p0, st_p1, op_pl, prism_rtl::deref(prism_rtl::deref(x_pm)), e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), e_p2.span_p, Text::lit("this checker does not implement suffixed operators"))};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& s_pn = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x_po = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return crate::check::expr::operators::infer_free_sigil_f(env_p0, st_p1, s_pn, prism_rtl::deref(prism_rtl::deref(x_po)), e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& recv_pp = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& sigils_pq = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a1;
        auto&& name_pr = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        return crate::check::expr::operators::infer_field_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(recv_pp)), sigils_pq, name_pr, e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& recv_ps = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& idx_pt = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return crate::check::expr::operators::infer_index_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(recv_ps)), prism_rtl::deref(prism_rtl::deref(idx_pt)), e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicField>(_m)) {
        return crate::check::expr::calls::infer_lambda_f(env_p0, st_p1, e_p2, std::optional<crate::check::types::Ty>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
        return crate::check::expr::calls::infer_lambda_f(env_p0, st_p1, e_p2, std::optional<crate::check::types::Ty>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& recv_pu = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& m_pv = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args_p10 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return crate::check::expr::calls::infer_call_f(env_p0, st_p1, crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{m_pv})), .span_p = prism_rtl::deref(m_pv).span_p}, crate::prelude::append(Array(std::vector{crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = prism_rtl::deref(prism_rtl::deref(recv_pu)), .span_p = prism_rtl::deref(recv_pu).span_p}}), args_p10), e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& target_p11 = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        return crate::check::expr::calls::infer_call_f(env_p0, st_p1, e_p2, Array<crate::syntax::Arg>{}, e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
        auto&& x_p12 = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        auto&& ty_p13 = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a1;
        auto&& checked_p14 = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a2;
        return prism_rtl::deref(checked_p14)
            ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), e_p2.span_p, Text::lit("this checker does not implement non-empty arrays"))}
            : ({
            auto cx_p15 = env_cx_f(env_p0);
            auto [t_p17, st2_p18] = crate::check::env::reading::conv_type_f(cx_p15, st_p1, ty_p13);
            auto st3_p16 = check_f(env_p0, st2_p18, prism_rtl::deref(prism_rtl::deref(x_p12)), t_p17);
            std::tuple{t_p17, st3_p16};
        });
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), e_p2.span_p, Text::lit("this checker does not implement non-empty arrays"))};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAbsent>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), e_p2.span_p, Text::lit("this checker does not implement sparse tuples"))};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERest>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st_p1};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        return crate::check::expr::calls::infer_lambda_f(env_p0, st_p1, e_p2, std::optional<crate::check::types::Ty>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c_p19 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_p1a = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_o1b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        return crate::check::expr::lifting::infer_if_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(c_p19)), then_b_p1a, else_b_o1b, e_p2.span_p, std::optional<crate::check::types::Ty>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& scrut_p1c = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p1d = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return crate::check::expr::lifting::infer_match_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(scrut_p1c)), arms_p1d, e_p2.span_p, std::optional<crate::check::types::Ty>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
        auto&& scrut_p1e = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& body_p1f = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        return crate::check::blocks::structure::infer_rebuild_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(scrut_p1e)), body_p1f, e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
        auto&& binders_o1g = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source_p1h = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body_p1i = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        return crate::check::blocks::structure::infer_for_f(env_p0, st_p1, binders_o1g, prism_rtl::deref(prism_rtl::deref(source_p1h)), body_p1i, e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
        auto&& b_p1j = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        return crate::check::blocks::structure::infer_given_f(env_p0, st_p1, b_p1j, e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
        auto&& target_p1k = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& body_p1l = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        return crate::check::blocks::borrows::infer_update_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(target_p1k)), body_p1l, e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        auto&& b_p1m = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        auto [t_p1n, st2_p1o] = crate::check::blocks::infer_widget_block_f(env_p0, st_p1, b_p1m);
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t_p1n), env_p0.scope_p}), st2_p1o};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), e_p2.span_p, Text::lit("this checker does not implement `T monad:` blocks"))};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m)) {
        auto&& t_p1p = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        return crate::check::expr::lets::infer_template_f(env_p0, st_p1, t_p1p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
        auto&& x_p1q = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        auto [t_p1r, st2_p1s] = infer_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_p1q)));
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAny{Array<Text>{}}), st2_p1s};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELens>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), e_p2.span_p, Text::lit("this checker does not implement named lenses and `Over`"))};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EError>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st_p1};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferKind::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferName(env_p0, st_p1, n_p3, prism_rtl::deref(e_p2).span_p)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
        auto&& l_p4 = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferLit(env_p0, st_p1, l_p4, false, prism_rtl::deref(e_p2).span_p)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUnit>(_m) ? ({
        auto&& marks_p5 = prism_rtl::as<crate::syntax::ExprKind::EUnit>(_m).a0;
        prism_rtl::finished(std::tuple{crate::check::types::with_marks_f(marks_p5, crate::check::types::t_unit_p(), prism_rtl::deref(env_p0).scope_p), st_p1});
    })
        : prism_rtl::is<crate::syntax::ExprKind::ENil>(_m) ? ({
        auto&& marks_p6 = prism_rtl::as<crate::syntax::ExprKind::ENil>(_m).a0;
        ({
        auto [v_p7, st2_p8] = crate::check::types::fresh_var_f(st_p1, false, Text::lit(""));
        (prism_rtl::finished(std::tuple{crate::check::types::with_marks_f(marks_p6, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_p7)}), prism_rtl::deref(env_p0).scope_p), st2_p8}));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBound>(_m) ? ({
        auto&& b_p9 = prism_rtl::as<crate::syntax::ExprKind::EBound>(_m).a0;
        prism_rtl::finished(infer_bound_f(env_p0, st_p1, b_p9, prism_rtl::deref(e_p2).span_p));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m) ? ({
        auto&& es_pa = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        ({
        auto env_p0x = env_p0;
        auto es_pax = es_pa;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_infer_all_f(env_p0x, st_p1x, es_pax), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> infer_all_f_5231) {
        return ({
            auto [ts_pb, st2_pc] = infer_all_f_5231;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyTuple{ts_pb}), st2_pc}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) ? ({
        auto&& es_pd = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::operators::InferArray(env_p0, st_p1, es_pd, prism_rtl::deref(e_p2).span_p)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMap>(_m) ? ({
        auto&& entries_pe = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::operators::InferMap(env_p0, st_p1, entries_pe, prism_rtl::deref(e_p2).span_p)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_pf = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Infer(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_pf)))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& callee_pg = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_ph = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::InferCall(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(callee_pg)), args_ph, prism_rtl::deref(e_p2).span_p)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) ? ({
        auto&& op_pi = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& lhs_pj = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& rhs_pk = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::operators::InferBinary(env_p0, st_p1, op_pi, prism_rtl::deref(prism_rtl::deref(lhs_pj)), prism_rtl::deref(prism_rtl::deref(rhs_pk)), prism_rtl::deref(e_p2).span_p)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) ? ({
        auto&& op_pl = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
        auto&& x_pm = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::operators::InferUnary(env_p0, st_p1, op_pl, prism_rtl::deref(prism_rtl::deref(x_pm)), prism_rtl::deref(e_p2).span_p)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), prism_rtl::deref(e_p2).span_p, Text::lit("this checker does not implement suffixed operators"))})
        : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) ? ({
        auto&& s_pn = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x_po = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::operators::InferFreeSigil(env_p0, st_p1, s_pn, prism_rtl::deref(prism_rtl::deref(x_po)), prism_rtl::deref(e_p2).span_p)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& recv_pp = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& sigils_pq = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a1;
        auto&& name_pr = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::operators::InferField(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(recv_pp)), sigils_pq, name_pr, prism_rtl::deref(e_p2).span_p)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& recv_ps = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& idx_pt = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::operators::InferIndex(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(recv_ps)), prism_rtl::deref(prism_rtl::deref(idx_pt)), prism_rtl::deref(e_p2).span_p)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETopicField>(_m) ? prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::InferLambda(env_p0, st_p1, e_p2, std::optional<crate::check::types::Ty>{})))
        : prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m) ? prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::InferLambda(env_p0, st_p1, e_p2, std::optional<crate::check::types::Ty>{})))
        : prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m) ? ({
        auto&& recv_pu = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& m_pv = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args_p10 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::InferCall(env_p0, st_p1, crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{m_pv})), .span_p = prism_rtl::deref(m_pv).span_p}, crate::prelude::append(Array(std::vector{crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = prism_rtl::deref(prism_rtl::deref(recv_pu)), .span_p = prism_rtl::deref(recv_pu).span_p}}), args_p10), prism_rtl::deref(e_p2).span_p)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m) ? ({
        auto&& target_p11 = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::InferCall(env_p0, st_p1, e_p2, Array<crate::syntax::Arg>{}, prism_rtl::deref(e_p2).span_p)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECast>(_m) ? ({
        auto&& x_p12 = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        auto&& ty_p13 = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a1;
        auto&& checked_p14 = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a2;
        prism_rtl::deref(checked_p14)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), prism_rtl::deref(e_p2).span_p, Text::lit("this checker does not implement non-empty arrays"))})
        : ({
        auto cx_p15 = env_cx_f(env_p0);
        auto env_p0x = env_p0;
        auto st_p1x = st_p1;
        auto ty_p13x = ty_p13;
        auto x_p12x = prism_rtl::deref(prism_rtl::deref(x_p12));
        (crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p15, st_p1x, ty_p13x), [=, env_p0x = std::move(env_p0x), x_p12x = std::move(x_p12x)](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_6484) {
        return ({
            auto [t_p17, st2_p18] = conv_type_f_6484;
            (crate::prelude::call_then(start_check_f(env_p0x, st2_p18, x_p12x, t_p17), [=](crate::check::types::St check_f_6526) {
            return ({
                auto st3_p16 = check_f_6526;
                (prism_rtl::finished(std::tuple{t_p17, st3_p16}));
            });
        }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), prism_rtl::deref(e_p2).span_p, Text::lit("this checker does not implement non-empty arrays"))})
        : prism_rtl::is<crate::syntax::ExprKind::EAbsent>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), prism_rtl::deref(e_p2).span_p, Text::lit("this checker does not implement sparse tuples"))})
        : prism_rtl::is<crate::syntax::ExprKind::ERest>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st_p1})
        : prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::InferLambda(env_p0, st_p1, e_p2, std::optional<crate::check::types::Ty>{})))
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c_p19 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_p1a = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_o1b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::lifting::InferIf(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(c_p19)), then_b_p1a, else_b_o1b, prism_rtl::deref(e_p2).span_p, std::optional<crate::check::types::Ty>{})));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& scrut_p1c = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p1d = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::lifting::InferMatch(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(scrut_p1c)), arms_p1d, prism_rtl::deref(e_p2).span_p, std::optional<crate::check::types::Ty>{})));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m) ? ({
        auto&& scrut_p1e = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& body_p1f = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::blocks::structure::InferRebuild(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(scrut_p1e)), body_p1f, prism_rtl::deref(e_p2).span_p)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& binders_o1g = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source_p1h = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body_p1i = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        prism_rtl::more(prism_rtl::rc(crate::check::blocks::structure::InferFor(env_p0, st_p1, binders_o1g, prism_rtl::deref(prism_rtl::deref(source_p1h)), body_p1i, prism_rtl::deref(e_p2).span_p)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m) ? ({
        auto&& b_p1j = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::blocks::structure::InferGiven(env_p0, st_p1, b_p1j, prism_rtl::deref(e_p2).span_p)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m) ? ({
        auto&& target_p1k = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& body_p1l = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::blocks::borrows::InferUpdate(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(target_p1k)), body_p1l, prism_rtl::deref(e_p2).span_p)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m) ? ({
        auto&& b_p1m = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        ({
        auto b_p1mx = b_p1m;
        auto env_p0x = env_p0;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::blocks::start_infer_widget_block_f(env_p0x, st_p1x, b_p1mx), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block_f_7322) {
        return ({
            auto [t_p1n, st2_p1o] = infer_widget_block_f_7322;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t_p1n), prism_rtl::deref(env_p0x).scope_p}), st2_p1o}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), prism_rtl::deref(e_p2).span_p, Text::lit("this checker does not implement `T monad:` blocks"))})
        : prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m) ? ({
        auto&& t_p1p = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::lets::InferTemplate(env_p0, st_p1, t_p1p)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EAny>(_m) ? ({
        auto&& x_p1q = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        ({
        auto env_p0x = env_p0;
        auto st_p1x = st_p1;
        auto x_p1qx = prism_rtl::deref(prism_rtl::deref(x_p1q));
        (crate::prelude::call_then(start_infer_f(env_p0x, st_p1x, x_p1qx), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_7589) {
        return ({
            auto [t_p1r, st2_p1s] = infer_f_7589;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAny{Array<Text>{}}), st2_p1s}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::ELens>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), prism_rtl::deref(e_p2).span_p, Text::lit("this checker does not implement named lenses and `Over`"))})
        : prism_rtl::is<crate::syntax::ExprKind::EError>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st_p1})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_kind_f(Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<InferKind>(env_p0, st_p1, e_p2);
}


/// InferAll: unbounded fn Env, St, [Expr] -> (([Ty], St))
std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> infer_all_f(const Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Expr>& es_p2) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(es_p2, std::tuple{Array<crate::check::types::Ty>{}, st_p1}, ({
        auto env_p0x = env_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Expr>)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x)](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0xy = env_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy)]() {
            return ({
                auto [acc_p3, s_p4] = p0;
                auto x_p5 = p1;
                (crate::prelude::call_then(start_infer_f(env_p0xy, s_p4, x_p5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_7922) {
                return ({
                    auto [t_p6, s2_p7] = infer_f_7922;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p3, t_p6), s2_p7}));
                });
            }));
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> InferAll::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& es_p2 = this->es_p2;
    return crate::prelude::fold_job(es_p2, std::tuple{Array<crate::check::types::Ty>{}, st_p1}, ({
        auto env_p0x = env_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Expr>)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x)](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0xy = env_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy)]() {
            return ({
                auto [acc_p3, s_p4] = p0;
                auto x_p5 = p1;
                (crate::prelude::call_then(start_infer_f(env_p0xy, s_p4, x_p5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_7922) {
                return ({
                    auto [t_p6, s2_p7] = infer_f_7922;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p3, t_p6), s2_p7}));
                });
            }));
            });
        })));
        });
    }));
    }))->cycle();
}


/// `Start InferAll, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> start_infer_all_f(Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Expr> es_p2) {
    return prism_rtl::make_rc<InferAll>(env_p0, st_p1, es_p2);
}


/// Check: unbounded fn Env, St, Expr, Ty -> St
crate::check::types::St check_f(const Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2, const crate::check::types::Ty& expected_p3) {
    auto&& _m = prism_rtl::deref(e_p2.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        auto [t_p4, st2_p5] = crate::check::expr::calls::infer_lambda_f(env_p0, st_p1, e_p2, std::optional(expected_p3));
        return crate::check::types::unify::unify_f(crate::check::types::recording::note_ty_f(st2_p5, e_p2.span_p, t_p4), expected_p3, t_p4, e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p6 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return crate::check::types::recording::note_ty_f(check_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_p6)), expected_p3), e_p2.span_p, expected_p3);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& scrut_p7 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p8 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        auto [t_p9, st2_pa] = crate::check::expr::lifting::infer_match_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(scrut_p7)), arms_p8, e_p2.span_p, std::optional(expected_p3));
        return crate::check::types::unify::unify_f(crate::check::types::recording::note_ty_f(st2_pa, e_p2.span_p, t_p9), expected_p3, t_p9, e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c_pb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_pc = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_od = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        auto [t_pe, st2_pf] = crate::check::expr::lifting::infer_if_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(c_pb)), then_b_pc, else_b_od, e_p2.span_p, std::optional(expected_p3));
        return crate::check::types::unify::unify_f(crate::check::types::recording::note_ty_f(st2_pf, e_p2.span_p, t_pe), expected_p3, t_pe, e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
        auto&& x_pg = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        return crate::check::types::recording::note_ty_f(check_any_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_pg)), expected_p3, e_p2.span_p), e_p2.span_p, expected_p3);
    }
    {
        auto [t_ph, st2_pi] = infer_f(env_p0, st_p1, e_p2);
        return crate::check::types::unify::unify_f(st2_pi, expected_p3, t_ph, e_p2.span_p);
    }
}


prism_rtl::Turn<crate::check::types::St> Check::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& e_p2 = this->e_p2;
    const auto& expected_p3 = this->expected_p3;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto e_p2x = e_p2;
        auto env_p0x = env_p0;
        auto expected_p3x = expected_p3;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::expr::calls::start_infer_lambda_f(env_p0x, st_p1x, e_p2x, std::optional(expected_p3x)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lambda_f_8231) {
        return ({
            auto [t_p4, st2_p5] = infer_lambda_f_8231;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(crate::check::types::recording::note_ty_f(st2_p5, prism_rtl::deref(e_p2x).span_p, t_p4), expected_p3x, t_p4, prism_rtl::deref(e_p2x).span_p))));
        });
    }));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p6 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        ({
        auto e_p2x = e_p2;
        auto env_p0x = env_p0;
        auto expected_p3x = expected_p3;
        auto st_p1x = st_p1;
        auto x_p6x = prism_rtl::deref(prism_rtl::deref(x_p6));
        (crate::prelude::call_then(start_check_f(env_p0x, st_p1x, x_p6x, expected_p3x), [=, e_p2x = std::move(e_p2x)](crate::check::types::St check_f_8349) { return prism_rtl::finished(crate::check::types::recording::note_ty_f(check_f_8349, prism_rtl::deref(e_p2x).span_p, expected_p3x)); }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& scrut_p7 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p8 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        ({
        auto arms_p8x = arms_p8;
        auto e_p2x = e_p2;
        auto env_p0x = env_p0;
        auto expected_p3x = expected_p3;
        auto scrut_p7x = prism_rtl::deref(prism_rtl::deref(scrut_p7));
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::expr::lifting::start_infer_match_f(env_p0x, st_p1x, scrut_p7x, arms_p8x, prism_rtl::deref(e_p2x).span_p, std::optional(expected_p3x)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_match_f_8444) {
        return ({
            auto [t_p9, st2_pa] = infer_match_f_8444;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(crate::check::types::recording::note_ty_f(st2_pa, prism_rtl::deref(e_p2x).span_p, t_p9), expected_p3x, t_p9, prism_rtl::deref(e_p2x).span_p))));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c_pb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_pc = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_od = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        ({
        auto else_b_odx = else_b_od;
        auto c_pbx = prism_rtl::deref(prism_rtl::deref(c_pb));
        auto e_p2x = e_p2;
        auto env_p0x = env_p0;
        auto expected_p3x = expected_p3;
        auto st_p1x = st_p1;
        auto then_b_pcx = then_b_pc;
        (crate::prelude::call_then(crate::check::expr::lifting::start_infer_if_f(env_p0x, st_p1x, c_pbx, then_b_pcx, else_b_odx, prism_rtl::deref(e_p2x).span_p, std::optional(expected_p3x)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_if_f_8608) {
        return ({
            auto [t_pe, st2_pf] = infer_if_f_8608;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(crate::check::types::recording::note_ty_f(st2_pf, prism_rtl::deref(e_p2x).span_p, t_pe), expected_p3x, t_pe, prism_rtl::deref(e_p2x).span_p))));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EAny>(_m) ? ({
        auto&& x_pg = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        ({
        auto e_p2x = e_p2;
        auto env_p0x = env_p0;
        auto expected_p3x = expected_p3;
        auto st_p1x = st_p1;
        auto x_pgx = prism_rtl::deref(prism_rtl::deref(x_pg));
        (crate::prelude::call_then(start_check_any_f(env_p0x, st_p1x, x_pgx, expected_p3x, prism_rtl::deref(e_p2x).span_p), [=](crate::check::types::St check_any_f_8743) { return prism_rtl::finished(crate::check::types::recording::note_ty_f(check_any_f_8743, prism_rtl::deref(e_p2x).span_p, expected_p3x)); }));
    });
    })
        : ({
        auto e_p2x = e_p2;
        auto env_p0x = env_p0;
        auto expected_p3x = expected_p3;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_infer_f(env_p0x, st_p1x, e_p2x), [=, expected_p3x = std::move(expected_p3x)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_8840) {
        return ({
            auto [t_ph, st2_pi] = infer_f_8840;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st2_pi, expected_p3x, t_ph, prism_rtl::deref(e_p2x).span_p))));
        });
    }));
    });
    });
}


/// `Start Check, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_f(Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2, crate::check::types::Ty expected_p3) {
    return prism_rtl::make_rc<Check>(env_p0, st_p1, e_p2, expected_p3);
}


/// CheckAny: unbounded fn Env, St, Expr, Ty, Range -> St
crate::check::types::St check_any_f(const Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& x_p2, const crate::check::types::Ty& expected_p3, const crate::syntax::Range& span_p4) {
    auto&& _m = crate::check::types::recording::walk_f(st_p1, expected_p3);
    if (prism_rtl::is<crate::check::types::Ty::TyAny>(_m)) {
        auto&& trs_p5 = prism_rtl::as<crate::check::types::Ty::TyAny>(_m).a0;
        auto [t_p6, st2_p7] = infer_f(env_p0, st_p1, x_p2);
        return crate::prelude::fold(trs_p5, st2_p7, [&](const crate::check::types::St& s_p8, const Text& tr_p9) { return add_want_f(s_p8, tr_p9, t_p6, span_p4); });
    }
    {
        auto&& other_pa = _m;
        auto [t_pb, st2_pc] = infer_f(env_p0, st_p1, x_p2);
        return crate::check::types::unify::unify_f(st2_pc, other_pa, crate::check::types::Ty(crate::check::types::Ty::TyAny{Array<Text>{}}), span_p4);
    }
}


prism_rtl::Turn<crate::check::types::St> CheckAny::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& x_p2 = this->x_p2;
    const auto& expected_p3 = this->expected_p3;
    const auto& span_p4 = this->span_p4;
    auto env_p0x = env_p0;
    auto expected_p3x = expected_p3;
    auto span_p4x = span_p4;
    auto st_p1x = st_p1;
    auto x_p2x = x_p2;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x, expected_p3x), [=](crate::check::types::Ty walk_f_9088) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyAny>(walk_f_9088) ? ({
            auto&& trs_p5 = prism_rtl::as<crate::check::types::Ty::TyAny>(walk_f_9088).a0;
            crate::prelude::call_then(start_infer_f(env_p0x, st_p1x, x_p2x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_9147) {
            return ({
                auto [t_p6, st2_p7] = infer_f_9147;
                (prism_rtl::finished(crate::prelude::fold(trs_p5, st2_p7, [&](const crate::check::types::St& s_p8, const Text& tr_p9) { return add_want_f(s_p8, tr_p9, t_p6, span_p4x); })));
            });
        });
        })
            : ({
            auto&& other_pa = walk_f_9088;
            crate::prelude::call_then(start_infer_f(env_p0x, st_p1x, x_p2x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_9255) {
            return ({
                auto [t_pb, st2_pc] = infer_f_9255;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st2_pc, other_pa, crate::check::types::Ty(crate::check::types::Ty::TyAny{Array<Text>{}}), span_p4x))));
            });
        });
        });
        });
    });
}


/// `Start CheckAny, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_any_f(Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr x_p2, crate::check::types::Ty expected_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<CheckAny>(env_p0, st_p1, x_p2, expected_p3, span_p4);
}


/// AddWant: fn St, Text, Ty, Range -> St
crate::check::types::St add_want_f(const crate::check::types::St& st_p0, const Text& cls_p1, const crate::check::types::Ty& t_p2, const crate::syntax::Range& span_p3) {
    crate::check::types::St this_ = st_p0;
    this_.wants_p = crate::prelude::push(this_.wants_p, crate::check::types::Want{.cls_p = cls_p1, .ty_p = t_p2, .file_p = this_.file_p, .span_p = span_p3, .level_p = this_.level_p});
    return this_;
}


/// EnvCx: fn Env -> Cx
crate::check::env::reading::Cx_ env_cx_f(const Env& env_p0) {
    auto base_p1 = crate::check::env::reading::cx_of_f(env_p0.g_p, env_p0.home_p);
    crate::check::env::reading::Cx_ this_ = base_p1;
    this_.scope_p = env_p0.scope_p;
    return this_;
}


/// InferName: unbounded fn Env, St, SName, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_name_f(const Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::SName& n_p2, const crate::syntax::Range& span_p3) {
    auto local_p4 = crate::check::env::sname_key_f(n_p2);
    return env_p0.in_update_p && has_time_mark_f(n_p2.sigils_p)
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix_f(st_p1, Text::lit("time-in-update"), span_p3, prism_rtl::cat("`", local_p4, "` in an `update` block"), Text::lit("an `&` block cannot see time: pass the plain value in, and lift the function"))}
        : infer_name_in_f(env_p0, st_p1, n_p2, span_p3);
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferName::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& n_p2 = this->n_p2;
    const auto& span_p3 = this->span_p3;
    auto local_p4 = crate::check::env::sname_key_f(n_p2);
    return prism_rtl::deref(env_p0).in_update_p && has_time_mark_f(prism_rtl::deref(n_p2).sigils_p)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix_f(st_p1, Text::lit("time-in-update"), span_p3, prism_rtl::cat("`", local_p4, "` in an `update` block"), Text::lit("an `&` block cannot see time: pass the plain value in, and lift the function"))})
        : prism_rtl::more(prism_rtl::rc(InferNameIn(env_p0, st_p1, n_p2, span_p3)));
}


/// `Start InferName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_name_f(Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<InferName>(env_p0, st_p1, n_p2, span_p3);
}


/// InferNameIn: unbounded fn Env, St, SName, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_name_in_f(const Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::SName& n_p2, const crate::syntax::Range& span_p3) {
    auto local_p4 = crate::check::env::sname_key_f(n_p2);
    auto&& _m = crate::prelude::get(env_p0.locals_p, local_p4);
    if (prism_rtl::is_some(_m)) {
        auto&& sc_p5 = prism_rtl::some_of(_m);
        auto st2_p6 = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            auto&& _m = crate::prelude::get(env_p0.ids_p, local_p4);
            if (prism_rtl::is_some(_m)) {
                auto&& id_p7 = prism_rtl::some_of(_m);
                _v.set(crate::check::types::recording::note_use_f(st_p1, span_p3, id_p7));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(st_p1);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return instantiate_local_f(st2_p6, sc_p5, span_p3, local_p4);
    }
    if (prism_rtl::is_none(_m)) {
        return infer_global_f(env_p0, st_p1, n_p2, span_p3);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferNameIn::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& n_p2 = this->n_p2;
    const auto& span_p3 = this->span_p3;
    auto local_p4 = crate::check::env::sname_key_f(n_p2);
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0).locals_p, local_p4);
        prism_rtl::is_some(_m) ? ({
        auto&& sc_p5 = prism_rtl::some_of(_m);
        ({
        auto st2_p6 = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0).ids_p, local_p4);
            if (prism_rtl::is_some(_m)) {
                auto&& id_p7 = prism_rtl::some_of(_m);
                _v.set(crate::check::types::recording::note_use_f(st_p1, span_p3, id_p7));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(st_p1);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::more(prism_rtl::rc(InstantiateLocal(st2_p6, sc_p5, span_p3, local_p4))));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(InferGlobal(env_p0, st_p1, n_p2, span_p3)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferNameIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_name_in_f(Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<InferNameIn>(env_p0, st_p1, n_p2, span_p3);
}


/// InstantiateLocal: unbounded fn St, Scheme, Range, Text -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_local_f(const crate::check::types::St& st_p0, const crate::check::types::Scheme& sc_p1, const crate::syntax::Range& span_p2, const Text& name_p3) {
    return (crate::prelude::len(sc_p1.qs_p) == Nat(0u)) && (crate::prelude::len(sc_p1.cqs_p) == Nat(0u))
        ? crate::check::types::schemes::instantiate_f(st_p0, sc_p1, span_p2)
        : ({
        auto [t_p4, st2_p5, inst_p6] = crate::check::types::schemes::instantiate_with_f(st_p0, sc_p1, span_p2, Array<crate::check::types::Ty>{});
        std::tuple{t_p4, crate::check::types::recording::note_inst_f(st2_p5, span_p2, name_p3, sc_p1, inst_p6)};
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InstantiateLocal::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& sc_p1 = this->sc_p1;
    const auto& span_p2 = this->span_p2;
    const auto& name_p3 = this->name_p3;
    return (crate::prelude::len(prism_rtl::deref(sc_p1).qs_p) == Nat(0u)) && (crate::prelude::len(prism_rtl::deref(sc_p1).cqs_p) == Nat(0u))
        ? prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::Instantiate(st_p0, sc_p1, span_p2)))
        : ({
        auto name_p3x = name_p3;
        auto sc_p1x = sc_p1;
        auto span_p2x = span_p2;
        auto st_p0x = st_p0;
        (crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(st_p0x, sc_p1x, span_p2x, Array<crate::check::types::Ty>{}), [=, name_p3x = std::move(name_p3x)](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst> instantiate_with_f_10896) {
        return ({
            auto [t_p4, st2_p5, inst_p6] = instantiate_with_f_10896;
            (prism_rtl::finished(std::tuple{t_p4, crate::check::types::recording::note_inst_f(st2_p5, span_p2x, name_p3x, sc_p1x, inst_p6)}));
        });
    }));
    });
}


/// `Start InstantiateLocal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_instantiate_local_f(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1, crate::syntax::Range span_p2, Text name_p3) {
    return prism_rtl::make_rc<InstantiateLocal>(st_p0, sc_p1, span_p2, name_p3);
}


/// InferGlobal: unbounded fn Env, St, SName, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_global_f(const Env& env_p0, const crate::check::types::St& st0_p1, const crate::syntax::SName& n_p2, const crate::syntax::Range& span_p3) {
    auto [qk_o6, why_p7] = crate::check::env::names::resolve_value_f(env_p0.g_p, env_p0.home_p, n_p2);
    auto st1_p4 = collision_at_f(env_p0, st0_p1, why_p7, crate::check::env::sname_key_f(n_p2), span_p3);
    auto st_p5 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        if (prism_rtl::is_some(qk_o6)) {
            auto&& qk_p8 = prism_rtl::some_of(qk_o6);
            _v.set(crate::check::types::recording::note_global_f(st1_p4, span_p3, qk_p8));
            goto _done;
        }
        if (prism_rtl::is_none(qk_o6)) {
            _v.set(st1_p4);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is_none(qk_o6)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p5, Text::lit("unknown-name"), span_p3, prism_rtl::cat("nothing declares `", crate::check::env::sname_key_f(n_p2), "` here"))};
    }
    if (prism_rtl::is_some(qk_o6)) {
        auto&& qk_p9 = prism_rtl::some_of(qk_o6);
        return why_p7 == Text::lit("tag")
            ? tag_value_f(env_p0, st_p5, qk_p9, span_p3)
            : crate::check::expr::calls::is_local_maker_f(qk_p9) && (!env_p0.in_update_p)
            ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::expr::calls::local_outside_f(st_p5, qk_p9, span_p3)}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g_p).vals_p, qk_p9);
            if (prism_rtl::is_some(_m)) {
                auto&& v_pa = prism_rtl::some_of(_m);
                _v.set(crate::check::types::schemes::instantiate_f(crate::check::expr::calls::note_method_use_f(call_id_f(st_p5, qk_p9, span_p3), v_pa, span_p3), prism_rtl::deref(v_pa).scheme_p, span_p3));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g_p).ctors_p, qk_p9);
                    if (prism_rtl::is_some(_m)) {
                        auto&& c_pb = prism_rtl::some_of(_m);
                        _v.set(ctor_value_f(env_p0, st_p5, c_pb, span_p3));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p5, Text::lit("unknown-name"), span_p3, prism_rtl::cat("`", crate::check::env::sname_key_f(n_p2), "` has no signature line or type"))});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferGlobal::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st0_p1 = this->st0_p1;
    const auto& n_p2 = this->n_p2;
    const auto& span_p3 = this->span_p3;
    auto [qk_o6, why_p7] = crate::check::env::names::resolve_value_f(prism_rtl::deref(env_p0).g_p, prism_rtl::deref(env_p0).home_p, n_p2);
    auto st1_p4 = collision_at_f(env_p0, st0_p1, why_p7, crate::check::env::sname_key_f(n_p2), span_p3);
    auto st_p5 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        if (prism_rtl::is_some(qk_o6)) {
            auto&& qk_p8 = prism_rtl::some_of(qk_o6);
            _v.set(crate::check::types::recording::note_global_f(st1_p4, span_p3, qk_p8));
            goto _done;
        }
        if (prism_rtl::is_none(qk_o6)) {
            _v.set(st1_p4);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        prism_rtl::is_none(qk_o6) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p5, Text::lit("unknown-name"), span_p3, prism_rtl::cat("nothing declares `", crate::check::env::sname_key_f(n_p2), "` here"))})
        : prism_rtl::is_some(qk_o6) ? ({
        auto&& qk_p9 = prism_rtl::some_of(qk_o6);
        why_p7 == Text::lit("tag")
        ? prism_rtl::more(prism_rtl::rc(TagValue(env_p0, st_p5, qk_p9, span_p3)))
        : crate::check::expr::calls::is_local_maker_f(qk_p9) && (!prism_rtl::deref(env_p0).in_update_p)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::expr::calls::local_outside_f(st_p5, qk_p9, span_p3)})
        : ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g_p).vals_p, qk_p9);
        prism_rtl::is_some(_m) ? ({
        auto&& v_pa = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::Instantiate(crate::check::expr::calls::note_method_use_f(call_id_f(st_p5, qk_p9, span_p3), v_pa, span_p3), prism_rtl::deref(v_pa).scheme_p, span_p3)));
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g_p).ctors_p, qk_p9);
        prism_rtl::is_some(_m) ? ({
        auto&& c_pb = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(CtorValue(env_p0, st_p5, c_pb, span_p3)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p5, Text::lit("unknown-name"), span_p3, prism_rtl::cat("`", crate::check::env::sname_key_f(n_p2), "` has no signature line or type"))})
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferGlobal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_global_f(Env env_p0, crate::check::types::St st0_p1, crate::syntax::SName n_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<InferGlobal>(env_p0, st0_p1, n_p2, span_p3);
}


/// CollisionAt: fn Env, St, Text, Text, Range -> St
crate::check::types::St collision_at_f(const Env& env_p0, const crate::check::types::St& st_p1, const Text& why_p2, const Text& name_p3, const crate::syntax::Range& span_p4) {
    return why_p2 != Text::lit("collision")
        ? st_p1
        : ({
        auto keys_p5 = crate::prelude::or_(crate::prelude::get(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(env_p0.g_p).bare_p, env_p0.home_p), Map<Text, Array<Text>>{}), name_p3), Array<Text>{});
        auto others_p6 = crate::prelude::filter(keys_p5, [&](const Text& k_p7) { return crate::syntax::lexer::chars::contains_f(k_p7, Text::lit(".")); });
        (crate::check::types::recording::err_fix_f(st_p1, Text::lit("collision"), span_p4, prism_rtl::cat("`", name_p3, "` is declared by more than one module this file reaches by a bare name: ", crate::syntax::lexer::chars::join_f(crate::prelude::each(keys_p5, [&](const Text& k_p8) { return prism_rtl::cat("`", k_p8, "`"); }), Text::lit(", "))), prism_rtl::cat("write the one meant qualified, as `", crate::prelude::or_(crate::prelude::index(others_p6, Nat(0u)), name_p3), "`, or rename this file\'s own")));
    });
}


/// CtorValue: unbounded fn Env, St, CtorInfo, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> ctor_value_f(const Env& env_p0, const crate::check::types::St& st_p1, const crate::check::env::CtorInfo& c_p2, const crate::syntax::Range& span_p3) {
    auto sc_p4 = crate::check::types::Scheme{.qs_p = c_p2.params_p, .plain_qs_p = Array<Text>{}, .rqs_p = Array<Text>{}, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = Array<std::tuple<Text, Text>>{}, .ty_p = crate::prelude::len(c_p2.args_p) == Nat(0u)
        ? c_p2.ty_p
        : crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), c_p2.args_p, prism_rtl::rc(c_p2.ty_p)})};
    return crate::check::types::schemes::instantiate_f(st_p1, sc_p4, span_p3);
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> CtorValue::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& c_p2 = this->c_p2;
    const auto& span_p3 = this->span_p3;
    auto sc_p4 = crate::check::types::Scheme{.qs_p = prism_rtl::deref(c_p2).params_p, .plain_qs_p = Array<Text>{}, .rqs_p = Array<Text>{}, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = Array<std::tuple<Text, Text>>{}, .ty_p = crate::prelude::len(prism_rtl::deref(c_p2).args_p) == Nat(0u)
        ? prism_rtl::deref(c_p2).ty_p
        : crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), prism_rtl::deref(c_p2).args_p, prism_rtl::rc(prism_rtl::deref(c_p2).ty_p)})};
    return prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::Instantiate(st_p1, sc_p4, span_p3)));
}


/// `Start CtorValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_ctor_value_f(Env env_p0, crate::check::types::St st_p1, crate::check::env::CtorInfo c_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<CtorValue>(env_p0, st_p1, c_p2, span_p3);
}


/// TagValue: unbounded fn Env, St, Text, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> tag_value_f(const Env& env_p0, const crate::check::types::St& st_p1, const Text& name_p2, const crate::syntax::Range& span_p3) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g_p).tags_p, name_p2);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unknown-name"), span_p3, prism_rtl::cat("no tag `", name_p2, "`"))};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& tg_p4 = prism_rtl::some_of(_m);
        return prism_rtl::deref(tg_p4).kind_p == Text::lit("Element")
            ? ({
            auto [rw_p6, st2_p7] = crate::check::types::recording::fresh_row_f(st_p1, Array(std::vector{prism_rtl::deref(tg_p4).family_p}));
            auto erow_p5 = crate::check::types::Rw{.fams_p = Array(std::vector{prism_rtl::deref(tg_p4).family_p}), .minus_p = Array<Text>{}, .tail_p = prism_rtl::deref(rw_p6).tail_p};
            auto [out_p8, st3_p9] = crate::check::types::schemes::instantiate_f(st2_p7, crate::check::types::Scheme{.qs_p = prism_rtl::deref(tg_p4).qs_p, .plain_qs_p = Array<Text>{}, .rqs_p = prism_rtl::deref(tg_p4).rqs_p, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = prism_rtl::deref(tg_p4).bounds_p, .ty_p = prism_rtl::deref(tg_p4).out_p}, span_p3);
            std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{erow_p5, prism_rtl::rc(out_p8)}), st3_p9};
        })
            : std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(tg_p4).kind_p, Array<crate::check::types::Ty>{}}), st_p1};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> TagValue::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& name_p2 = this->name_p2;
    const auto& span_p3 = this->span_p3;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g_p).tags_p, name_p2);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unknown-name"), span_p3, prism_rtl::cat("no tag `", name_p2, "`"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& tg_p4 = prism_rtl::some_of(_m);
        prism_rtl::deref(tg_p4).kind_p == Text::lit("Element")
        ? ({
        auto [rw_p6, st2_p7] = crate::check::types::recording::fresh_row_f(st_p1, Array(std::vector{prism_rtl::deref(tg_p4).family_p}));
        auto erow_p5 = crate::check::types::Rw{.fams_p = Array(std::vector{prism_rtl::deref(tg_p4).family_p}), .minus_p = Array<Text>{}, .tail_p = prism_rtl::deref(rw_p6).tail_p};
        auto span_p3x = span_p3;
        (crate::prelude::call_then(crate::check::types::schemes::start_instantiate_f(st2_p7, crate::check::types::Scheme{.qs_p = prism_rtl::deref(tg_p4).qs_p, .plain_qs_p = Array<Text>{}, .rqs_p = prism_rtl::deref(tg_p4).rqs_p, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = prism_rtl::deref(tg_p4).bounds_p, .ty_p = prism_rtl::deref(tg_p4).out_p}, span_p3x), [=, erow_p5 = std::move(erow_p5)](std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_f_13506) {
        return ({
            auto [out_p8, st3_p9] = instantiate_f_13506;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{erow_p5, prism_rtl::rc(out_p8)}), st3_p9}));
        });
    }));
    })
        : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(tg_p4).kind_p, Array<crate::check::types::Ty>{}}), st_p1});
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TagValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_tag_value_f(Env env_p0, crate::check::types::St st_p1, Text name_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<TagValue>(env_p0, st_p1, name_p2, span_p3);
}


/// InferBound: fn Env, St, Text, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_bound_f(const Env& env_p0, const crate::check::types::St& st_p1, const Text& b_p2, const crate::syntax::Range& span_p3) {
    auto&& _m = crate::prelude::get(env_p0.locals_p, b_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& sc_p4 = prism_rtl::some_of(_m);
        return std::tuple{prism_rtl::deref(sc_p4).ty_p, st_p1};
    }
    if (prism_rtl::is_none(_m)) {
        return b_p2 == Text::lit("key")
            ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unknown-name"), span_p3, Text::lit("`key` is bound only in a loop over a map"))}
            : std::tuple{crate::check::types::t_nat_p(), st_p1};
    }
    prism_rtl::unreachable("no arm matched");
}


/// InferLit: unbounded fn Env, St, Literal, Bool, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lit_f(const Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Literal& l_p2, const bool& negative_p3, const crate::syntax::Range& span_p4) {
    auto sigils_p5 = crate::syntax::lexer::chars::fold_chars_f(l_p2.marks_p, Text::lit(""), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::once_job([=]() {
            return ({
                auto acc_p7 = p0;
                auto c_p8 = p1;
                (crate::check::types::unify::is_mark_char_f(c_p8)
                ? prism_rtl::finished(prism_rtl::cat(acc_p7, c_p8))
                : prism_rtl::finished(acc_p7));
            });
        });
    })));
    auto signed_p6 = negative_p3 || crate::syntax::lexer::chars::contains_f(l_p2.marks_p, Text::lit("-"));
    auto [base_ph, st2_pi] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = l_p2.kind_p;
        if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
            auto&& digits_p9 = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
            _v.set(({
                auto [v_pd, s1_pe] = crate::check::types::fresh_var_f(st_p1, true, Text::lit(""));
                auto s2_pa = add_want_f(s1_pe, Text::lit("Prelude.Num"), v_pd, span_p4);
                auto s3_pb = std::move(signed_p6)
                    ? add_want_f(s2_pa, Text::lit("Prelude.Signed"), v_pd, span_p4)
                    : s2_pa;
                auto s4_pc = add_range_f(s3_pb, v_pd, digits_p9, signed_p6, span_p4);
                std::tuple{v_pd, s4_pc};
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LitKind::LFloat>(_m)) {
            _v.set(std::tuple{crate::check::types::t_float_p(), st_p1});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LitKind::LDuration>(_m)) {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Duration"), Array<crate::check::types::Ty>{}}), st_p1});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
            _v.set(std::tuple{crate::check::types::t_char_p(), st_p1});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
            auto&& segs_pf = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
            _v.set(infer_text_f(env_p0, st_p1, segs_pf, crate::syntax::lexer::chars::contains_f(sigils_p5, Text::lit("$")), span_p4));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LitKind::LRegex>(_m)) {
            auto&& r_pg = prism_rtl::as<crate::syntax::LitKind::LRegex>(_m).a0;
            _v.set(infer_regex_f(st_p1, r_pg));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::syntax::lexer::chars::contains_f(sigils_p5, Text::lit("$")) && (crate::check::types::head_sigil_f(st2_pi, base_ph) == Text::lit("$"))
        ? std::tuple{base_ph, st2_pi}
        : crate::syntax::lexer::chars::contains_f(sigils_p5, Text::lit("$"))
        ? std::tuple{crate::check::types::with_marks_f(sigils_p5, base_ph, env_p0.scope_p), crate::check::types::recording::note_app_f(st2_pi, span_p4, Text::lit("$"), Text::lit("const"), Text::lit("$"), Array<Nat>{}, Text::lit(""), crate::check::types::Col(crate::check::types::Col::CBound{}))}
        : std::tuple{crate::check::types::with_marks_f(sigils_p5, base_ph, env_p0.scope_p), st2_pi};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferLit::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& l_p2 = this->l_p2;
    const auto& negative_p3 = this->negative_p3;
    const auto& span_p4 = this->span_p4;
    auto env_p0x = env_p0;
    auto l_p2x = l_p2;
    auto negative_p3x = prism_rtl::deref(negative_p3);
    auto span_p4x = span_p4;
    auto st_p1x = st_p1;
    return crate::prelude::call_value(crate::syntax::lexer::chars::start_fold_chars_f(prism_rtl::deref(l_p2x).marks_p, Text::lit(""), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::once_job([=]() {
            return ({
                auto acc_p7 = p0;
                auto c_p8 = p1;
                (crate::check::types::unify::is_mark_char_f(c_p8)
                ? prism_rtl::finished(prism_rtl::cat(acc_p7, c_p8))
                : prism_rtl::finished(acc_p7));
            });
        });
    }))), [=](Text fold_chars_f_14479) {
        return ({
            auto sigils_p5 = fold_chars_f_14479;
            auto signed_p6 = negative_p3x || crate::syntax::lexer::chars::contains_f(prism_rtl::deref(l_p2x).marks_p, Text::lit("-"));
            auto [base_ph, st2_pi] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                auto&& _m = prism_rtl::deref(l_p2x).kind_p;
                if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
                    auto&& digits_p9 = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
                    _v.set(({
                        auto [v_pd, s1_pe] = crate::check::types::fresh_var_f(st_p1x, true, Text::lit(""));
                        auto s2_pa = add_want_f(s1_pe, Text::lit("Prelude.Num"), v_pd, span_p4x);
                        auto s3_pb = std::move(signed_p6)
                            ? add_want_f(s2_pa, Text::lit("Prelude.Signed"), v_pd, span_p4x)
                            : s2_pa;
                        auto s4_pc = add_range_f(s3_pb, v_pd, digits_p9, signed_p6, span_p4x);
                        std::tuple{v_pd, s4_pc};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LitKind::LFloat>(_m)) {
                    _v.set(std::tuple{crate::check::types::t_float_p(), st_p1x});
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LitKind::LDuration>(_m)) {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Duration"), Array<crate::check::types::Ty>{}}), st_p1x});
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
                    _v.set(std::tuple{crate::check::types::t_char_p(), st_p1x});
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
                    auto&& segs_pf = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
                    _v.set(infer_text_f(env_p0x, st_p1x, segs_pf, crate::syntax::lexer::chars::contains_f(sigils_p5, Text::lit("$")), span_p4x));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LitKind::LRegex>(_m)) {
                    auto&& r_pg = prism_rtl::as<crate::syntax::LitKind::LRegex>(_m).a0;
                    _v.set(infer_regex_f(st_p1x, r_pg));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (crate::syntax::lexer::chars::contains_f(sigils_p5, Text::lit("$")) && (crate::check::types::head_sigil_f(st2_pi, base_ph) == Text::lit("$"))
            ? prism_rtl::finished(std::tuple{base_ph, st2_pi})
            : crate::syntax::lexer::chars::contains_f(sigils_p5, Text::lit("$"))
            ? prism_rtl::finished(std::tuple{crate::check::types::with_marks_f(sigils_p5, base_ph, prism_rtl::deref(env_p0x).scope_p), crate::check::types::recording::note_app_f(st2_pi, span_p4x, Text::lit("$"), Text::lit("const"), Text::lit("$"), Array<Nat>{}, Text::lit(""), crate::check::types::Col(crate::check::types::Col::CBound{}))})
            : prism_rtl::finished(std::tuple{crate::check::types::with_marks_f(sigils_p5, base_ph, prism_rtl::deref(env_p0x).scope_p), st2_pi}));
        });
    });
}


/// `Start InferLit, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_lit_f(Env env_p0, crate::check::types::St st_p1, crate::syntax::Literal l_p2, bool negative_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<InferLit>(env_p0, st_p1, l_p2, negative_p3, span_p4);
}


/// InferRegex: unbounded fn St, RegexLit -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_regex_f(const crate::check::types::St& st_p0, const crate::syntax::RegexLit& r_p1) {
    auto t_p2 = crate::check::types::Ty(crate::check::types::Ty::TyCon{r_p1.replacement_o == std::optional<Text>{}
        ? Text::lit("Regex")
        : Text::lit("RegexReplacement"), Array<crate::check::types::Ty>{}});
    auto&& _m = crate::check::regex::regex_refusal_o(r_p1.pattern_p, r_p1.flags_p, r_p1.replacement_o);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{t_p2, st_p0};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& d_p3 = prism_rtl::some_of(_m);
        auto [base_p6, text_p7] = prism_rtl::deref(d_p3).part_p == Text::lit("flags")
            ? std::tuple{r_p1.flags_at_p, r_p1.flags_p}
            : prism_rtl::deref(d_p3).part_p == Text::lit("pattern")
            ? std::tuple{r_p1.pattern_at_p, r_p1.pattern_p}
            : std::tuple{r_p1.replacement_at_p, crate::prelude::or_(r_p1.replacement_o, Text::lit(""))};
        auto start_p4 = base_p6 + prism_rtl::deref(d_p3).at_p;
        auto span_p5 = crate::syntax::Range{.start_p = start_p4, .end_p = start_p4 + crate::prelude::max(crate::prelude::len_text(crate::check::regex::rx_char_at_f(text_p7, prism_rtl::deref(d_p3).at_p)), Nat(1u))};
        return prism_rtl::deref(d_p3).message_p == crate::check::regex::rx_unknown_flag_p()
            ? std::tuple{t_p2, crate::check::types::recording::err_fix_f(st_p0, Text::lit("regex"), span_p5, prism_rtl::deref(d_p3).message_p, Text::lit("a replacement that starts with letters and holds anything but letters is written in the hashed form, `%#/x/#hello world/#`"))}
            : std::tuple{t_p2, crate::check::types::recording::err_f(st_p0, Text::lit("regex"), span_p5, prism_rtl::deref(d_p3).message_p)};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferRegex::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& r_p1 = this->r_p1;
    auto t_p2 = crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(r_p1).replacement_o == std::optional<Text>{}
        ? Text::lit("Regex")
        : Text::lit("RegexReplacement"), Array<crate::check::types::Ty>{}});
    auto r_p1x = r_p1;
    auto st_p0x = st_p0;
    return crate::prelude::call_then(crate::check::regex::start_regex_refusal_o(prism_rtl::deref(r_p1x).pattern_p, prism_rtl::deref(r_p1x).flags_p, prism_rtl::deref(r_p1x).replacement_o), [=](std::optional<crate::check::regex::RxDiag> regex_refusal_o_15951) {
        return ({
            prism_rtl::is_none(regex_refusal_o_15951) ? prism_rtl::finished(std::tuple{t_p2, st_p0x})
            : prism_rtl::is_some(regex_refusal_o_15951) ? ({
            auto&& d_p3 = prism_rtl::some_of(regex_refusal_o_15951);
            ({
            auto [base_p6, text_p7] = prism_rtl::deref(d_p3).part_p == Text::lit("flags")
                ? std::tuple{prism_rtl::deref(r_p1x).flags_at_p, prism_rtl::deref(r_p1x).flags_p}
                : prism_rtl::deref(d_p3).part_p == Text::lit("pattern")
                ? std::tuple{prism_rtl::deref(r_p1x).pattern_at_p, prism_rtl::deref(r_p1x).pattern_p}
                : std::tuple{prism_rtl::deref(r_p1x).replacement_at_p, crate::prelude::or_(prism_rtl::deref(r_p1x).replacement_o, Text::lit(""))};
            auto start_p4 = base_p6 + prism_rtl::deref(d_p3).at_p;
            auto span_p5 = crate::syntax::Range{.start_p = start_p4, .end_p = start_p4 + crate::prelude::max(crate::prelude::len_text(crate::check::regex::rx_char_at_f(text_p7, prism_rtl::deref(d_p3).at_p)), Nat(1u))};
            (prism_rtl::deref(d_p3).message_p == crate::check::regex::rx_unknown_flag_p()
            ? prism_rtl::finished(std::tuple{t_p2, crate::check::types::recording::err_fix_f(st_p0x, Text::lit("regex"), span_p5, prism_rtl::deref(d_p3).message_p, Text::lit("a replacement that starts with letters and holds anything but letters is written in the hashed form, `%#/x/#hello world/#`"))})
            : prism_rtl::finished(std::tuple{t_p2, crate::check::types::recording::err_f(st_p0x, Text::lit("regex"), span_p5, prism_rtl::deref(d_p3).message_p)}));
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start InferRegex, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_regex_f(crate::check::types::St st_p0, crate::syntax::RegexLit r_p1) {
    return prism_rtl::make_rc<InferRegex>(st_p0, r_p1);
}


/// AddRange: fn St, Ty, Text, Bool, Range -> St
crate::check::types::St add_range_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& v_p1, const Text& digits_p2, const bool& signed_p3, const crate::syntax::Range& span_p4) {
    crate::check::types::St this_ = st_p0;
    this_.wants_p = crate::prelude::push(this_.wants_p, crate::check::types::Want{.cls_p = prism_rtl::cat("Range ", signed_p3 ? Text::lit("-") : Text::lit(""), digits_p2), .ty_p = v_p1, .file_p = this_.file_p, .span_p = span_p4, .level_p = this_.level_p});
    return this_;
}


/// InferText: unbounded fn Env, St, [TextSeg], Bool, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_text_f(const Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::TextSeg>& segs_p2, const bool& dollar_p3, const crate::syntax::Range& span_p4) {
    auto holes_p5 = crate::prelude::fold(segs_p2, Array<crate::syntax::Expr>{}, [&](const Array<crate::syntax::Expr>& acc_p6, const crate::syntax::TextSeg& sg_p7) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
            if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg_p7)) {
                auto&& x_p8 = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg_p7).a0;
                _v.set(crate::prelude::push(acc_p6, x_p8));
                goto _done;
            }
            {
                _v.set(acc_p6);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return crate::prelude::len(holes_p5) == Nat(0u)
        ? std::tuple{crate::check::types::t_text_p(), st_p1}
        : ({
        auto [events_p12, dyns_p13, opts_p14, st2_p15, lifted_p16] = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(holes_p5)), std::tuple{Array<crate::syntax::Range>{}, Int(0ll), Array<Text>{}, st_p1, Array<Nat>{}}, ({
            auto holes_p5x = holes_p5;
            auto span_p4x = span_p4;
            auto env_p0x = env_p0;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>>(std::tuple<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>, Nat>)>>(prism_rtl::rc([=, holes_p5x = std::move(holes_p5x), span_p4x = std::move(span_p4x), env_p0x = std::move(env_p0x)](std::tuple<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto holes_p5xy = holes_p5x;
                auto span_p4xy = span_p4x;
                auto env_p0xy = env_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, holes_p5xy = std::move(holes_p5xy), span_p4xy = std::move(span_p4xy), env_p0xy = std::move(env_p0xy)]() {
                return ({
                    auto [ev_pf, dy_pg, op_ph, s_pi, li_pj] = p0;
                    auto hi_pk = p1;
                    ({
                    auto x_pl = crate::prelude::or_(crate::prelude::index(holes_p5xy, hi_pk), crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = span_p4xy});
                    (crate::prelude::call_then(start_infer_f(env_p0xy, s_pi, x_pl), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_17646) {
                    return ({
                        auto [t_p10, s2_p11] = infer_f_17646;
                        (crate::prelude::call_then(crate::check::types::start_head_sigil_f(s2_p11, t_p10), [=](Text head_sigil_f_17685) {
                        return ({
                            auto head_pm = head_sigil_f_17685;
                            auto inner_pn = is_time_sigil_f(head_pm) ? inner_of_f(s2_p11, t_p10) : t_p10;
                            (crate::prelude::call_then(crate::check::types::start_head_sigil_f(s2_p11, inner_pn), [=, head_pm = std::move(head_pm)](Text head_sigil_f_17789) {
                            return ({
                                auto ih_po = head_sigil_f_17789;
                                auto plain_t_pp = is_plain_sigil_f(ih_po) ? inner_of_f(s2_p11, inner_pn) : inner_pn;
                                auto s3_pq = head_pm == Text::lit("@")
                                    ? crate::check::types::recording::err_f(s2_p11, Text::lit("blueprint-operand"), prism_rtl::deref(x_pl).span_p, Text::lit("a text over a blueprint; bind it first"))
                                    : s2_p11;
                                (crate::prelude::call_then(start_show_want_f(s3_pq, plain_t_pp, prism_rtl::deref(x_pl).span_p), [=, ih_po = std::move(ih_po)](crate::check::types::St show_want_f_18029) {
                                return ({
                                    auto s4_pr = show_want_f_18029;
                                    auto ev2_ps = head_pm == Text::lit("!")
                                        ? crate::prelude::push(ev_pf, prism_rtl::deref(x_pl).span_p)
                                        : ev_pf;
                                    auto dy2_pt = head_pm == Text::lit("$") ? dy_pg + Int(1ll) : dy_pg;
                                    auto op2_pu = is_plain_sigil_f(ih_po)
                                        ? crate::check::types::add_text_f(op_ph, ih_po)
                                        : op_ph;
                                    auto li2_pv = is_time_sigil_f(head_pm) ? crate::prelude::push(li_pj, hi_pk) : li_pj;
                                    (prism_rtl::finished(std::tuple{ev2_ps, dy2_pt, op2_pu, s4_pr, li2_pv}));
                                });
                            }));
                            });
                        }));
                        });
                    }));
                    });
                }));
                });
                });
            })));
            });
        }));
        })));
        auto st3_p9 = dollar_p3 && (crate::prelude::len(events_p12) > Nat(0u))
            ? crate::check::types::recording::err_f(st2_p15, Text::lit("event-in-text"), crate::prelude::or_(crate::prelude::index(events_p12, Nat(0u)), span_p4), Text::lit("an event in a dynamic text"))
            : crate::prelude::len(events_p12) > Nat(1u)
            ? crate::check::types::recording::err_fix_f(st2_p15, Text::lit("two-events"), crate::prelude::or_(crate::prelude::index(events_p12, Nat(1u)), span_p4), Text::lit("two events in one operation"), Text::lit("merge them with `<|`, or hold one first"))
            : st2_p15;
        auto st4_pa = crate::prelude::len(opts_p14) > Nat(1u)
            ? crate::check::types::recording::err_f(st3_p9, Text::lit("optional-and-fault"), span_p4, Text::lit("`?` and `~` in one operation"))
            : st3_p9;
        auto with_opt_pb = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Ty> _v;
            auto&& _m = crate::prelude::index(opts_p14, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& o_p17 = prism_rtl::some_of(_m);
                _v.set(crate::check::types::Ty(crate::check::types::Ty::TySig{o_p17, prism_rtl::rc(crate::check::types::t_text_p())}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::check::types::t_text_p());
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto layer_pc = (crate::prelude::len(events_p12) > Nat(0u)) && (!dollar_p3)
            ? Text::lit("!")
            : (dyns_p13 > Int(0ll)) || dollar_p3 ? Text::lit("$") : Text::lit("");
        auto res_pd = layer_pc == Text::lit("")
            ? with_opt_pb
            : crate::check::types::Ty(crate::check::types::Ty::TySig{layer_pc, prism_rtl::rc(with_opt_pb)});
        auto kind_pe = layer_pc == Text::lit("")
            ? Text::lit("plain")
            : crate::prelude::len(lifted_p16) == Nat(0u)
            ? Text::lit("const")
            : Text::lit("map");
        std::tuple{res_pd, crate::check::types::recording::note_app_f(st4_pa, span_p4, Text::lit("text"), kind_pe, layer_pc, lifted_p16, crate::prelude::or_(crate::prelude::index(opts_p14, Nat(0u)), Text::lit("")), crate::check::types::Col(crate::check::types::Col::CBound{}))};
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferText::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& segs_p2 = this->segs_p2;
    const auto& dollar_p3 = this->dollar_p3;
    const auto& span_p4 = this->span_p4;
    auto holes_p5 = crate::prelude::fold(segs_p2, Array<crate::syntax::Expr>{}, [&](const Array<crate::syntax::Expr>& acc_p6, const crate::syntax::TextSeg& sg_p7) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
            if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg_p7)) {
                auto&& x_p8 = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg_p7).a0;
                _v.set(crate::prelude::push(acc_p6, x_p8));
                goto _done;
            }
            {
                _v.set(acc_p6);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return crate::prelude::len(holes_p5) == Nat(0u)
        ? prism_rtl::finished(std::tuple{crate::check::types::t_text_p(), st_p1})
        : ({
        auto dollar_p3x = prism_rtl::deref(dollar_p3);
        auto env_p0x = env_p0;
        auto span_p4x = span_p4;
        auto st_p1x = st_p1;
        (crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(holes_p5)), std::tuple{Array<crate::syntax::Range>{}, Int(0ll), Array<Text>{}, st_p1x, Array<Nat>{}}, ({
        auto holes_p5x = holes_p5;
        auto span_p4xx = span_p4x;
        auto env_p0xx = env_p0x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>>(std::tuple<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>, Nat>)>>(prism_rtl::rc([=, holes_p5x = std::move(holes_p5x), span_p4xx = std::move(span_p4xx), env_p0xx = std::move(env_p0xx)](std::tuple<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto holes_p5xy = holes_p5x;
            auto span_p4xxy = span_p4xx;
            auto env_p0xxy = env_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, holes_p5xy = std::move(holes_p5xy), span_p4xxy = std::move(span_p4xxy), env_p0xxy = std::move(env_p0xxy)]() {
            return ({
                auto [ev_pf, dy_pg, op_ph, s_pi, li_pj] = p0;
                auto hi_pk = p1;
                ({
                auto x_pl = crate::prelude::or_(crate::prelude::index(holes_p5xy, hi_pk), crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = span_p4xxy});
                (crate::prelude::call_then(start_infer_f(env_p0xxy, s_pi, x_pl), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_17646) {
                return ({
                    auto [t_p10, s2_p11] = infer_f_17646;
                    (crate::prelude::call_then(crate::check::types::start_head_sigil_f(s2_p11, t_p10), [=](Text head_sigil_f_17685) {
                    return ({
                        auto head_pm = head_sigil_f_17685;
                        auto inner_pn = is_time_sigil_f(head_pm) ? inner_of_f(s2_p11, t_p10) : t_p10;
                        (crate::prelude::call_then(crate::check::types::start_head_sigil_f(s2_p11, inner_pn), [=, head_pm = std::move(head_pm)](Text head_sigil_f_17789) {
                        return ({
                            auto ih_po = head_sigil_f_17789;
                            auto plain_t_pp = is_plain_sigil_f(ih_po) ? inner_of_f(s2_p11, inner_pn) : inner_pn;
                            auto s3_pq = head_pm == Text::lit("@")
                                ? crate::check::types::recording::err_f(s2_p11, Text::lit("blueprint-operand"), prism_rtl::deref(x_pl).span_p, Text::lit("a text over a blueprint; bind it first"))
                                : s2_p11;
                            (crate::prelude::call_then(start_show_want_f(s3_pq, plain_t_pp, prism_rtl::deref(x_pl).span_p), [=, ih_po = std::move(ih_po)](crate::check::types::St show_want_f_18029) {
                            return ({
                                auto s4_pr = show_want_f_18029;
                                auto ev2_ps = head_pm == Text::lit("!")
                                    ? crate::prelude::push(ev_pf, prism_rtl::deref(x_pl).span_p)
                                    : ev_pf;
                                auto dy2_pt = head_pm == Text::lit("$") ? dy_pg + Int(1ll) : dy_pg;
                                auto op2_pu = is_plain_sigil_f(ih_po)
                                    ? crate::check::types::add_text_f(op_ph, ih_po)
                                    : op_ph;
                                auto li2_pv = is_time_sigil_f(head_pm) ? crate::prelude::push(li_pj, hi_pk) : li_pj;
                                (prism_rtl::finished(std::tuple{ev2_ps, dy2_pt, op2_pu, s4_pr, li2_pv}));
                            });
                        }));
                        });
                    }));
                    });
                }));
                });
            }));
            });
            });
        })));
        });
    }));
    })), [=, dollar_p3x = std::move(dollar_p3x)](std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>> fold_17470) {
        return ({
            auto [events_p12, dyns_p13, opts_p14, st2_p15, lifted_p16] = fold_17470;
            auto st3_p9 = dollar_p3x && (crate::prelude::len(events_p12) > Nat(0u))
                ? crate::check::types::recording::err_f(st2_p15, Text::lit("event-in-text"), crate::prelude::or_(crate::prelude::index(events_p12, Nat(0u)), span_p4x), Text::lit("an event in a dynamic text"))
                : crate::prelude::len(events_p12) > Nat(1u)
                ? crate::check::types::recording::err_fix_f(st2_p15, Text::lit("two-events"), crate::prelude::or_(crate::prelude::index(events_p12, Nat(1u)), span_p4x), Text::lit("two events in one operation"), Text::lit("merge them with `<|`, or hold one first"))
                : st2_p15;
            auto st4_pa = crate::prelude::len(opts_p14) > Nat(1u)
                ? crate::check::types::recording::err_f(st3_p9, Text::lit("optional-and-fault"), span_p4x, Text::lit("`?` and `~` in one operation"))
                : st3_p9;
            auto with_opt_pb = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::Ty> _v;
                auto&& _m = crate::prelude::index(opts_p14, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& o_p17 = prism_rtl::some_of(_m);
                    _v.set(crate::check::types::Ty(crate::check::types::Ty::TySig{o_p17, prism_rtl::rc(crate::check::types::t_text_p())}));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::check::types::t_text_p());
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto layer_pc = (crate::prelude::len(events_p12) > Nat(0u)) && (!dollar_p3x)
                ? Text::lit("!")
                : (dyns_p13 > Int(0ll)) || dollar_p3x ? Text::lit("$") : Text::lit("");
            auto res_pd = layer_pc == Text::lit("")
                ? with_opt_pb
                : crate::check::types::Ty(crate::check::types::Ty::TySig{layer_pc, prism_rtl::rc(with_opt_pb)});
            auto kind_pe = layer_pc == Text::lit("")
                ? Text::lit("plain")
                : crate::prelude::len(lifted_p16) == Nat(0u)
                ? Text::lit("const")
                : Text::lit("map");
            (prism_rtl::finished(std::tuple{res_pd, crate::check::types::recording::note_app_f(st4_pa, span_p4x, Text::lit("text"), kind_pe, layer_pc, lifted_p16, crate::prelude::or_(crate::prelude::index(opts_p14, Nat(0u)), Text::lit("")), crate::check::types::Col(crate::check::types::Col::CBound{}))}));
        });
    }));
    });
}


/// `Start InferText, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_text_f(Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::TextSeg> segs_p2, bool dollar_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<InferText>(env_p0, st_p1, segs_p2, dollar_p3, span_p4);
}


/// ShowWant: unbounded fn St, Ty, Range -> St
crate::check::types::St show_want_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1, const crate::syntax::Range& span_p2) {
    auto&& _m = crate::check::types::recording::walk_f(st_p0, t_p1);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m19342_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m19342_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m19342_0_0 == Text::lit("Text")) {
            if (m19342_0_1.size() == 0u) {
                return st_p0;
            }
        }
    }
    {
        auto&& other_p3 = _m;
        return add_want_f(st_p0, Text::lit("Prelude.Show"), other_p3, span_p2);
    }
}


prism_rtl::Turn<crate::check::types::St> ShowWant::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    const auto& span_p2 = this->span_p2;
    auto span_p2x = span_p2;
    auto st_p0x = st_p0;
    auto t_p1x = t_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x, t_p1x), [=](crate::check::types::Ty walk_f_19348) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_f_19348) && ({
            auto&& m19342_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_19348).a0;
            auto&& m19342_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_19348).a1;
            (m19342_0_0 == Text::lit("Text")) && (m19342_0_1.size() == 0u);
        }) ? ({
            auto&& m19342_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_19348).a0;
            auto&& m19342_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_19348).a1;
            prism_rtl::finished(st_p0x);
        })
            : ({
            auto&& other_p3 = walk_f_19348;
            prism_rtl::finished(add_want_f(st_p0x, Text::lit("Prelude.Show"), other_p3, span_p2x));
        });
        });
    });
}


/// `Start ShowWant, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_show_want_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1, crate::syntax::Range span_p2) {
    return prism_rtl::make_rc<ShowWant>(st_p0, t_p1, span_p2);
}

}  // namespace crate::check::expr
