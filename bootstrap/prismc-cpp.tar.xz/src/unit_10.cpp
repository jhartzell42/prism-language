// The modules `Check.Errors`, `Check.Expr`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/errors/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/expr/module.hpp>
#include <check/env/module.hpp>
#include <check/types/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Errors`, from `target/bootstrap/cpp-src/prismc/check/errors.prism`.
namespace crate::check::errors {

void CDiag::show(Printer& p) const {
    p.record("CDiag", {{"code", code}, {"file", file}, {"span", span}, {"message", message}, {"fix", fix}});
}

Pod CDiag::to_pod() const {
    return Pod::record("CDiag", {{"code", prism_rtl::to_pod(code)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}, {"message", prism_rtl::to_pod(message)}, {"fix", prism_rtl::to_pod(fix)}});
}

Result<CDiag> CDiag::from_pod(const Pod& whole) {
    return CDiag{.code = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "code")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .message = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "message")))), .fix = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "fix"))))};
}


bool Src::operator==(const Src& o) const { return path_ == o.path_ && text == o.text && starts == o.starts && segs == o.segs; }

void Src::show(Printer& p) const {
    p.record("Src", {{"path", path_}, {"text", text}, {"starts", starts}, {"segs", segs}});
}

Pod Src::to_pod() const {
    return Pod::record("Src", {{"path", prism_rtl::to_pod(path_)}, {"text", prism_rtl::to_pod(text)}, {"starts", prism_rtl::to_pod(starts)}, {"segs", prism_rtl::to_pod(segs)}});
}

Result<Src> Src::from_pod(const Pod& whole) {
    return Src{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .text = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "text")))), .starts = TRY(prism_rtl::from_pod<Array<Nat>>(TRY(crate::prelude::field(whole, "starts")))), .segs = TRY(prism_rtl::from_pod<Array<SrcSeg>>(TRY(crate::prelude::field(whole, "segs"))))};
}


void SrcSeg::show(Printer& p) const {
    p.record("SrcSeg", {{"path", path_}, {"start", start}, {"line", line}, {"role", role}});
}

Pod SrcSeg::to_pod() const {
    return Pod::record("SrcSeg", {{"path", prism_rtl::to_pod(path_)}, {"start", prism_rtl::to_pod(start)}, {"line", prism_rtl::to_pod(line)}, {"role", prism_rtl::to_pod(role)}});
}

Result<SrcSeg> SrcSeg::from_pod(const Pod& whole) {
    return SrcSeg{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .start = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "start")))), .line = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "line")))), .role = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "role"))))};
}


/// MkSrc: fn Text, Text -> Src
Src mk_src(const Text& path_p0, const Text& text_p1) {
    return Src{.path_ = path_p0, .text = text_p1, .starts = cline_starts(text_p1), .segs = Array(std::vector{SrcSeg{.path_ = path_p0, .start = Nat(0u), .line = Nat(0u), .role = Text::lit("loose")}})};
}


/// MkJoinedSrc: fn [((Text, Text, Text))] -> Src
Src mk_joined_src(const Array<std::tuple<Text, Text, Text>>& files_p0) {
    auto text_p1 = crate::syntax::lexer::chars::join(each(files_p0, [&](const std::tuple<Text, Text, Text>& _p0) {
        auto&& t_p4 = std::get<1>(_p0);
        return t_p4;
    }), Text::lit("\n"));
    auto starts_p2 = cline_starts(text_p1);
    auto&& _segs_pa = fold(files_p0, std::tuple{Array<SrcSeg>{}, Nat(0u)}, [&](const std::tuple<Array<SrcSeg>, Nat>& _p0, const std::tuple<Text, Text, Text>& _p1) {
        auto&& acc_p5 = std::get<0>(_p0);
        auto&& at_p6 = std::get<1>(_p0);
        auto&& path_p7 = std::get<0>(_p1);
        auto&& t_p8 = std::get<1>(_p1);
        auto&& role_p9 = std::get<2>(_p1);
        return std::tuple{crate::prelude::push(acc_p5, SrcSeg{.path_ = path_p7, .start = at_p6, .line = cline_of(starts_p2, at_p6), .role = role_p9}), (at_p6 + len_text(t_p8)) + Nat(1u)};
    });
    auto&& segs_pa = std::get<0>(_segs_pa);
    auto first_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(files_p0, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& path_pb = std::get<0>(prism_rtl::some_of(_m));
            _v.set(path_pb);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return Src{.path_ = first_p3, .text = text_p1, .starts = starts_p2, .segs = segs_pa};
}


/// SegAt: fn Src, Nat -> SrcSeg
SrcSeg seg_at(const Src& src_p0, const Nat& offset_p1) {
    return fold(src_p0.segs, or_(index(src_p0.segs, Nat(0u)), SrcSeg{.path_ = src_p0.path_, .start = Nat(0u), .line = Nat(0u), .role = Text::lit("loose")}), [&](const SrcSeg& found_p2, const SrcSeg& s_p3) { return prism_rtl::deref(s_p3).start <= offset_p1 ? s_p3 : found_p2; });
}


/// SrcPlace: fn Src, Nat -> Text
Text src_place(const Src& src_p0, const Nat& offset_p1) {
    auto seg_p2 = seg_at(src_p0, offset_p1);
    return prism_rtl::cat(seg_p2->path_, ":", or_(cline_of(src_p0.starts, offset_p1).checked_sub(prism_rtl::deref(seg_p2).line), Nat(0u)) + Nat(1u));
}


/// Diag0: fn Text, Nat, Range, Text -> CDiag
CDiag diag0(const Text& code_p0, const Nat& file_p1, const crate::syntax::Range& span_p2, const Text& message_p3) {
    return CDiag{.code = code_p0, .file = file_p1, .span = span_p2, .message = message_p3, .fix = Text::lit("")};
}


/// DiagFix: fn Text, Nat, Range, Text, Text -> CDiag
CDiag diag_fix(const Text& code_p0, const Nat& file_p1, const crate::syntax::Range& span_p2, const Text& message_p3, const Text& fix_p4) {
    return CDiag{.code = code_p0, .file = file_p1, .span = span_p2, .message = message_p3, .fix = fix_p4};
}


/// CLineStarts: fn Text -> [Nat]
Array<Nat> cline_starts(const Text& text_p0) {
    auto&& _starts_p4 = fold(split_on(text_p0, Text::lit("\n")), std::tuple{Array<Nat>{}, Nat(0u)}, [&](const std::tuple<Array<Nat>, Nat>& _p0, const Text& line_p3) {
        auto&& acc_p1 = std::get<0>(_p0);
        auto&& at_p2 = std::get<1>(_p0);
        return std::tuple{crate::prelude::push(acc_p1, at_p2), (at_p2 + len_text(line_p3)) + Nat(1u)};
    });
    auto&& starts_p4 = std::get<0>(_starts_p4);
    return starts_p4;
}


/// CLineOf: fn [Nat], Nat -> Nat
Nat cline_of(const Array<Nat>& starts_p0, const Nat& offset_p1) {
    return crate::syntax::lexer::chars::dec(fold(starts_p0, Nat(0u), [&](const Nat& n_p2, const Nat& s_p3) { return s_p3 <= offset_p1 ? n_p2 + Nat(1u) : n_p2; }));
}


/// LineText: fn Src, Nat -> Text
Text line_text(const Src& src_p0, const Nat& n_p1) {
    auto from_p2 = or_(index(src_p0.starts, n_p1), Nat(0u));
    auto to_p3 = or_(index(src_p0.starts, n_p1 + Nat(1u)), len_text(src_p0.text) + Nat(1u));
    return crate::syntax::lexer::chars::between(src_p0.text, from_p2, crate::prelude::max(from_p2, or_(to_p3.checked_sub(Nat(1u)), Nat(0u))));
}


/// SpanText: fn Src, Range -> Text
Text span_text(const Src& src_p0, const crate::syntax::Range& r_p1) {
    return crate::syntax::lexer::chars::between(src_p0.text, r_p1.start, crate::prelude::max(r_p1.start, r_p1.end));
}


/// Repeat: fn Text, Nat -> Text
Text repeat(const Text& t_p0, const Nat& n_p1) {
    return concat(fold(range0(n_p1), Array<Text>{}, [&](const Array<Text>& acc_p2, const Nat& _p1) { return crate::prelude::push(acc_p2, t_p0); }));
}


/// Range0: fn Nat -> [Nat]
Array<Nat> range0(const Nat& n_p0) {
    Array<Nat> this_ = Array<Nat>{};
    Nat i_p1 = Nat(0u);
    Nat left_p2 = n_p0;
    while (true) {
        auto&& _m = left_p2.checked_sub(Nat(1u));
        if (!(prism_rtl::is_some(_m))) break;
        auto&& m_p3 = prism_rtl::some_of(_m);
        left_p2 = m_p3;
        this_ = crate::prelude::push(this_, i_p1);
        i_p1 = i_p1 + Nat(1u);
    }
    return this_;
}


/// RenderCDiag: fn [Src], CDiag -> Text
Text render_cdiag(const Array<Src>& srcs_p0, const CDiag& d_p1) {
    auto&& _m = index(srcs_p0, d_p1.file);
    if (prism_rtl::is_none(_m)) {
        return prism_rtl::cat("?: ", severity(d_p1), "[", d_p1.code, "]: ", d_p1.message, "\n");
    }
    if (prism_rtl::is_some(_m)) {
        auto&& src_p2 = prism_rtl::some_of(_m);
        auto line_p3 = cline_of(prism_rtl::deref(src_p2).starts, prism_rtl::deref(d_p1.span).start);
        auto col_p4 = crate::syntax::lexer::chars::column_of(src_p2->text, or_(index(prism_rtl::deref(src_p2).starts, line_p3), Nat(0u)), prism_rtl::deref(d_p1.span).start);
        auto text_p5 = line_text(src_p2, line_p3);
        auto width_p6 = crate::prelude::max(Nat(1u), crate::prelude::min(crate::syntax::lexer::chars::count_chars(span_text(src_p2, d_p1.span)), or_(crate::syntax::lexer::chars::count_chars(text_p5).checked_sub(col_p4), Nat(1u))));
        auto carets_p7 = prism_rtl::cat("    ", repeat(Text::lit(" "), col_p4), repeat(Text::lit("^"), width_p6));
        auto fix_p8 = d_p1.fix == Text::lit("")
            ? Text::lit("")
            : prism_rtl::cat("  fix: ", d_p1.fix, "\n");
        return prism_rtl::cat(src_place(src_p2, prism_rtl::deref(d_p1.span).start), ": ", severity(d_p1), "[", d_p1.code, "]: ", d_p1.message, "\n    ", text_p5, "\n", carets_p7, "\n", fix_p8);
    }
    prism_rtl::unreachable("no arm matched");
}


/// Severity: fn CDiag -> Text
Text severity(const CDiag& d_p0) {
    return is_warning(d_p0) ? Text::lit("warning") : Text::lit("error");
}


/// IsWarning: fn CDiag -> Bool
bool is_warning(const CDiag& d_p0) {
    return d_p0.code == Text::lit("unused");
}


/// SortDiags: fn [CDiag] -> [CDiag]
Array<CDiag> sort_diags(const Array<CDiag>& ds_p0) {
    return fold(ds_p0, Array<CDiag>{}, [&](const Array<CDiag>& acc_p1, const CDiag& d_p2) { return insert_sorted(acc_p1, d_p2); });
}


/// InsertSorted: fn [CDiag], CDiag -> [CDiag]
Array<CDiag> insert_sorted(const Array<CDiag>& acc_p0, const CDiag& d_p1) {
    auto before_p2 = filter(acc_p0, [&](const CDiag& x_p4) { return !diag_before2(d_p1, x_p4); });
    auto after_p3 = filter(acc_p0, [&](const CDiag& x_p5) { return diag_before2(d_p1, x_p5); });
    return any_is(acc_p0, d_p1)
        ? acc_p0
        : append(crate::prelude::push(before_p2, d_p1), after_p3);
}


/// AnyIs: fn [CDiag], CDiag -> Bool
bool any_is(const Array<CDiag>& xs_p0, const CDiag& d_p1) {
    return fold(xs_p0, false, [&](const bool& seen_p2, const CDiag& x_p3) { return prism_rtl::deref(seen_p2) || (x_p3 == d_p1); });
}


/// DiagBefore2: fn CDiag, CDiag -> Bool
bool diag_before2(const CDiag& a_p0, const CDiag& b_p1) {
    return a_p0.file != b_p1.file
        ? a_p0.file < b_p1.file
        : prism_rtl::deref(a_p0.span).start < prism_rtl::deref(b_p1.span).start;
}


/// CountWord: fn Nat -> Text
Text count_word(const Nat& n0) {
    {
        auto&& c0_0 = n0;
        if (c0_0 == Nat(0u)) {
            return Text::lit("no");
        }
    }
    {
        auto&& c1_0 = n0;
        if (c1_0 == Nat(1u)) {
            return Text::lit("one");
        }
    }
    {
        auto&& c2_0 = n0;
        if (c2_0 == Nat(2u)) {
            return Text::lit("two");
        }
    }
    {
        auto&& c3_0 = n0;
        if (c3_0 == Nat(3u)) {
            return Text::lit("three");
        }
    }
    {
        auto&& c4_0 = n0;
        if (c4_0 == Nat(4u)) {
            return Text::lit("four");
        }
    }
    {
        auto&& n_p0 = n0;
        return show_text(n_p0);
    }
}

}  // namespace crate::check::errors


// The module `Check.Expr`, from `target/bootstrap/cpp-src/prismc/check/expr/mod.prism`.
namespace crate::check::expr {

bool Env::operator==(const Env& o) const { return g == o.g && home == o.home && file == o.file && src == o.src && locals == o.locals && scope == o.scope && givens == o.givens && mark == o.mark && in_update == o.in_update && def_name == o.def_name && refine == o.refine && pending == o.pending && ids == o.ids; }

void Env::show(Printer& p) const {
    p.record("Env", {{"g", g}, {"home", home}, {"file", file}, {"src", src}, {"locals", locals}, {"scope", scope}, {"givens", givens}, {"mark", mark}, {"in_update", in_update}, {"def_name", def_name}, {"refine", refine}, {"pending", pending}, {"ids", ids}});
}

Pod Env::to_pod() const {
    return Pod::record("Env", {{"g", prism_rtl::to_pod(g)}, {"home", prism_rtl::to_pod(home)}, {"file", prism_rtl::to_pod(file)}, {"src", prism_rtl::to_pod(src)}, {"locals", prism_rtl::to_pod(locals)}, {"scope", prism_rtl::to_pod(scope)}, {"givens", prism_rtl::to_pod(givens)}, {"mark", prism_rtl::to_pod(mark)}, {"in_update", prism_rtl::to_pod(in_update)}, {"def_name", prism_rtl::to_pod(def_name)}, {"refine", prism_rtl::to_pod(refine)}, {"pending", prism_rtl::to_pod(pending)}, {"ids", prism_rtl::to_pod(ids)}});
}

Result<Env> Env::from_pod(const Pod& whole) {
    return Env{.g = TRY(prism_rtl::from_pod<crate::check::env::G>(TRY(crate::prelude::field(whole, "g")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .src = TRY(prism_rtl::from_pod<crate::check::errors::Src>(TRY(crate::prelude::field(whole, "src")))), .locals = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Scheme>>(TRY(crate::prelude::field(whole, "locals")))), .scope = TRY(prism_rtl::from_pod<crate::check::types::Rw>(TRY(crate::prelude::field(whole, "scope")))), .givens = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "givens")))), .mark = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "mark")))), .in_update = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "in_update")))), .def_name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "def_name")))), .refine = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "refine")))), .pending = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "pending")))), .ids = TRY(prism_rtl::from_pod<Map<Text, Nat>>(TRY(crate::prelude::field(whole, "ids"))))};
}


/// WithLocal: fn Env, Text, Scheme -> Env
Env with_local(const Env& env_p0, const Text& name_p1, const crate::check::types::Scheme& sc_p2) {
    Env this_ = env_p0;
    this_.locals = insert(this_.locals, name_p1, sc_p2);
    return this_;
}


/// BindLocalId: fn Env, St, Text, Range -> ((Env, St))
std::tuple<Env, crate::check::types::St> bind_local_id(const Env& env_p0, const crate::check::types::St& st_p1, const Text& name_p2, const crate::syntax::Range& span_p3) {
    auto place_p4 = prism_rtl::cat(st_p1.file, ":", span_p3.start, ":", span_p3.end);
    auto [id_p9, st2_pa] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, crate::check::types::St>> _v;
        auto&& _m = crate::prelude::get(st_p1.local_ids, place_p4);
        if (prism_rtl::is_some(_m)) {
            auto&& i_p6 = prism_rtl::some_of(_m);
            _v.set(std::tuple{i_p6, st_p1});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                auto fresh_p7 = st_p1.local_next;
                auto s2_p8 = ({
                    crate::check::types::St this_ = st_p1;
                    this_.local_next = this_.local_next + Nat(1u);
                    this_.local_ids = insert(this_.local_ids, place_p4, fresh_p7);
                    (std::move(this_));
                });
                std::tuple{fresh_p7, crate::check::types::recording::note_local(s2_p8, span_p3, fresh_p7)};
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto env2_p5 = ({
        Env this_ = env_p0;
        this_.ids = insert(this_.ids, name_p2, id_p9);
        (std::move(this_));
    });
    return std::tuple{env2_p5, st2_pa};
}


/// SrcText: fn Env, Range -> Text
Text src_text(const Env& env_p0, const crate::syntax::Range& r_p1) {
    return crate::check::errors::span_text(env_p0.src, r_p1);
}


/// IsComparison: fn Text -> Bool
bool is_comparison(const Text& n_p0) {
    return crate::check::types::has_text(Array(std::vector{Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit("<="), Text::lit(">"), Text::lit(">="), Text::lit("Compare"), Text::lit("?"), Text::lit("~"), Text::lit("$")}), n_p0);
}


/// HasTimeMark: fn Text -> Bool
bool has_time_mark(const Text& marks_p0) {
    return crate::syntax::lexer::chars::contains(marks_p0, Text::lit("$")) || crate::syntax::lexer::chars::contains(marks_p0, Text::lit("!"));
}


/// IsTimeSigil: fn Text -> Bool
bool is_time_sigil(const Text& s_p0) {
    return (s_p0 == Text::lit("$")) || (s_p0 == Text::lit("!"));
}


/// IsPlainSigil: fn Text -> Bool
bool is_plain_sigil(const Text& s_p0) {
    return (s_p0 == Text::lit("?")) || (s_p0 == Text::lit("~"));
}


/// InnerOf: unbounded fn St, Ty -> Ty
crate::check::types::Ty inner_of(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    auto&& _m = crate::check::types::recording::walk(st_p0, t_p1);
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& i_p2 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return prism_rtl::deref(i_p2);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
        auto&& i_p3 = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
        return prism_rtl::deref(i_p3);
    }
    {
        auto&& other_p4 = _m;
        return other_p4;
    }
}


prism_rtl::Turn<crate::check::types::Ty> InnerOf::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0_1 = st_p0;
    auto t_p1_2 = t_p1;
    return call_then(crate::check::types::recording::start_walk(st_p0_1, t_p1_2), [=](crate::check::types::Ty walk_3844) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TySig>(walk_3844) ? ({
            auto&& i_p2 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_3844).a1;
            prism_rtl::finished(prism_rtl::deref(i_p2));
        })
            : prism_rtl::is<crate::check::types::Ty::TyAt>(walk_3844) ? ({
            auto&& i_p3 = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_3844).a0;
            prism_rtl::finished(prism_rtl::deref(i_p3));
        })
            : ({
            auto&& other_p4 = walk_3844;
            prism_rtl::finished(other_p4);
        });
        });
    });
}


/// `Start InnerOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_inner_of(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<InnerOf>(st_p0, t_p1);
}


/// IsLambda: fn Expr -> Bool
bool is_lambda(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicField>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p1 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_lambda(prism_rtl::deref(prism_rtl::deref(x_p1)));
    }
    {
        return false;
    }
}


/// Infer: unbounded fn Env, St, Expr -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer(const Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2) {
    auto [t_p3, st2_p4] = infer_kind(env_p0, st_p1, e_p2);
    return std::tuple{t_p3, crate::check::types::recording::note_ty(st2_p4, e_p2.span, t_p3)};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> Infer::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& e_p2 = this->e_p2;
    auto e_p2_1 = e_p2;
    auto env_p0_2 = env_p0;
    auto st_p1_3 = st_p1;
    return call_then(start_infer_kind(env_p0_2, st_p1_3, e_p2_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_kind_4396) {
        return ({
            auto [t_p3, st2_p4] = infer_kind_4396;
            (prism_rtl::finished(std::tuple{t_p3, crate::check::types::recording::note_ty(st2_p4, prism_rtl::deref(e_p2_1).span, t_p3)}));
        });
    });
}


/// `Start Infer, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer(Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<Infer>(env_p0, st_p1, e_p2);
}


/// InferKind: unbounded fn Env, St, Expr -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_kind(const Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = prism_rtl::deref(e_p2.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return infer_name(env_p0, st_p1, n_p3, e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l_p4 = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        return infer_lit(env_p0, st_p1, l_p4, false, e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnit>(_m)) {
        auto&& marks_p5 = prism_rtl::as<crate::syntax::ExprKind::EUnit>(_m).a0;
        return std::tuple{crate::check::types::with_marks(marks_p5, crate::check::types::t_unit(), env_p0.scope), st_p1};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENil>(_m)) {
        auto&& marks_p6 = prism_rtl::as<crate::syntax::ExprKind::ENil>(_m).a0;
        auto [v_p7, st2_p8] = crate::check::types::fresh_var(st_p1, false, Text::lit(""));
        return std::tuple{crate::check::types::with_marks(marks_p6, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_p7)}), env_p0.scope), st2_p8};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBound>(_m)) {
        auto&& b_p9 = prism_rtl::as<crate::syntax::ExprKind::EBound>(_m).a0;
        return infer_bound(env_p0, st_p1, b_p9, e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es_pa = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        auto [ts_pb, st2_pc] = infer_all(env_p0, st_p1, es_pa);
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyTuple{ts_pb}), st2_pc};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& es_pd = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        return crate::check::expr::operators::infer_array(env_p0, st_p1, es_pd, e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& entries_pe = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        return crate::check::expr::operators::infer_map(env_p0, st_p1, entries_pe, e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_pf = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return infer(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_pf)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& callee_pg = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_ph = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return crate::check::expr::calls::infer_call(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(callee_pg)), args_ph, e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& op_pi = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& lhs_pj = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& rhs_pk = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return crate::check::expr::operators::infer_binary(env_p0, st_p1, op_pi, prism_rtl::deref(prism_rtl::deref(lhs_pj)), prism_rtl::deref(prism_rtl::deref(rhs_pk)), e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& op_pl = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
        auto&& x_pm = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return crate::check::expr::operators::infer_unary(env_p0, st_p1, op_pl, prism_rtl::deref(prism_rtl::deref(x_pm)), e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), e_p2.span, Text::lit("this checker does not implement suffixed operators"))};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& s_pn = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x_po = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return crate::check::expr::operators::infer_free_sigil(env_p0, st_p1, s_pn, prism_rtl::deref(prism_rtl::deref(x_po)), e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& recv_pp = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& sigils_pq = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a1;
        auto&& name_pr = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        return crate::check::expr::operators::infer_field(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(recv_pp)), sigils_pq, name_pr, e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& recv_ps = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& idx_pt = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return crate::check::expr::operators::infer_index(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(recv_ps)), prism_rtl::deref(prism_rtl::deref(idx_pt)), e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicField>(_m)) {
        return crate::check::expr::calls::infer_lambda(env_p0, st_p1, e_p2, std::optional<crate::check::types::Ty>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
        return crate::check::expr::calls::infer_lambda(env_p0, st_p1, e_p2, std::optional<crate::check::types::Ty>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& recv_pu = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& m_pv = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args_p10 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return crate::check::expr::calls::infer_call(env_p0, st_p1, crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{m_pv})), .span = prism_rtl::deref(m_pv).span}, append(Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = prism_rtl::deref(prism_rtl::deref(recv_pu)), .span = prism_rtl::deref(recv_pu).span}}), args_p10), e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& target_p11 = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        return crate::check::expr::calls::infer_call(env_p0, st_p1, e_p2, Array<crate::syntax::Arg>{}, e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
        auto&& x_p12 = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        auto&& ty_p13 = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a1;
        auto&& checked_p14 = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a2;
        return prism_rtl::deref(checked_p14)
            ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), e_p2.span, Text::lit("this checker does not implement non-empty arrays"))}
            : ({
            auto cx_p15 = env_cx(env_p0);
            auto [t_p17, st2_p18] = crate::check::env::reading::conv_type(cx_p15, st_p1, ty_p13);
            auto st3_p16 = crate::check::expr::check(env_p0, st2_p18, prism_rtl::deref(prism_rtl::deref(x_p12)), t_p17);
            std::tuple{t_p17, st3_p16};
        });
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), e_p2.span, Text::lit("this checker does not implement non-empty arrays"))};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAbsent>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), e_p2.span, Text::lit("this checker does not implement sparse tuples"))};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERest>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st_p1};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        return crate::check::expr::calls::infer_lambda(env_p0, st_p1, e_p2, std::optional<crate::check::types::Ty>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c_p19 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_p1a = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_o1b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        return crate::check::expr::lifting::infer_if(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(c_p19)), then_b_p1a, else_b_o1b, e_p2.span, std::optional<crate::check::types::Ty>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& scrut_p1c = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p1d = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return crate::check::expr::lifting::infer_match(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(scrut_p1c)), arms_p1d, e_p2.span, std::optional<crate::check::types::Ty>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
        auto&& scrut_p1e = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& body_p1f = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        return crate::check::blocks::structure::infer_rebuild(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(scrut_p1e)), body_p1f, e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
        auto&& binders_o1g = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source_p1h = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body_p1i = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        return crate::check::blocks::structure::infer_for(env_p0, st_p1, binders_o1g, prism_rtl::deref(prism_rtl::deref(source_p1h)), body_p1i, e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
        auto&& b_p1j = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        return crate::check::blocks::structure::infer_given(env_p0, st_p1, b_p1j, e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
        auto&& target_p1k = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& body_p1l = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        return crate::check::blocks::borrows::infer_update(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(target_p1k)), body_p1l, e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        auto&& b_p1m = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        auto [t_p1n, st2_p1o] = crate::check::blocks::infer_widget_block(env_p0, st_p1, b_p1m);
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t_p1n), env_p0.scope}), st2_p1o};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), e_p2.span, Text::lit("this checker does not implement `T monad:` blocks"))};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m)) {
        auto&& t_p1p = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        return crate::check::expr::lets::infer_template(env_p0, st_p1, t_p1p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
        auto&& x_p1q = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        auto [t_p1r, st2_p1s] = infer(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_p1q)));
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAny{Array<Text>{}}), st2_p1s};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELens>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), e_p2.span, Text::lit("this checker does not implement named lenses and `Over`"))};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EError>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st_p1};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferKind::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferName(env_p0, st_p1, n_p3, prism_rtl::deref(e_p2).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
        auto&& l_p4 = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferLit(env_p0, st_p1, l_p4, false, prism_rtl::deref(e_p2).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUnit>(_m) ? ({
        auto&& marks_p5 = prism_rtl::as<crate::syntax::ExprKind::EUnit>(_m).a0;
        prism_rtl::finished(std::tuple{crate::check::types::with_marks(marks_p5, crate::check::types::t_unit(), prism_rtl::deref(env_p0).scope), st_p1});
    })
        : prism_rtl::is<crate::syntax::ExprKind::ENil>(_m) ? ({
        auto&& marks_p6 = prism_rtl::as<crate::syntax::ExprKind::ENil>(_m).a0;
        ({
        auto [v_p7, st2_p8] = crate::check::types::fresh_var(st_p1, false, Text::lit(""));
        (prism_rtl::finished(std::tuple{crate::check::types::with_marks(marks_p6, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_p7)}), prism_rtl::deref(env_p0).scope), st2_p8}));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBound>(_m) ? ({
        auto&& b_p9 = prism_rtl::as<crate::syntax::ExprKind::EBound>(_m).a0;
        prism_rtl::finished(infer_bound(env_p0, st_p1, b_p9, prism_rtl::deref(e_p2).span));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m) ? ({
        auto&& es_pa = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        ({
        auto env_p0_1 = env_p0;
        auto es_pa_2 = es_pa;
        auto st_p1_3 = st_p1;
        call_then(start_infer_all(env_p0_1, st_p1_3, es_pa_2), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> infer_all_4906) {
        return ({
            auto [ts_pb, st2_pc] = infer_all_4906;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyTuple{ts_pb}), st2_pc}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) ? ({
        auto&& es_pd = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::operators::InferArray(env_p0, st_p1, es_pd, prism_rtl::deref(e_p2).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMap>(_m) ? ({
        auto&& entries_pe = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::operators::InferMap(env_p0, st_p1, entries_pe, prism_rtl::deref(e_p2).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_pf = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Infer(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_pf)))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& callee_pg = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_ph = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::InferCall(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(callee_pg)), args_ph, prism_rtl::deref(e_p2).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) ? ({
        auto&& op_pi = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& lhs_pj = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& rhs_pk = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::operators::InferBinary(env_p0, st_p1, op_pi, prism_rtl::deref(prism_rtl::deref(lhs_pj)), prism_rtl::deref(prism_rtl::deref(rhs_pk)), prism_rtl::deref(e_p2).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) ? ({
        auto&& op_pl = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
        auto&& x_pm = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::operators::InferUnary(env_p0, st_p1, op_pl, prism_rtl::deref(prism_rtl::deref(x_pm)), prism_rtl::deref(e_p2).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), prism_rtl::deref(e_p2).span, Text::lit("this checker does not implement suffixed operators"))})
        : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) ? ({
        auto&& s_pn = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x_po = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::operators::InferFreeSigil(env_p0, st_p1, s_pn, prism_rtl::deref(prism_rtl::deref(x_po)), prism_rtl::deref(e_p2).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& recv_pp = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& sigils_pq = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a1;
        auto&& name_pr = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::operators::InferField(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(recv_pp)), sigils_pq, name_pr, prism_rtl::deref(e_p2).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& recv_ps = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& idx_pt = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::operators::InferIndex(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(recv_ps)), prism_rtl::deref(prism_rtl::deref(idx_pt)), prism_rtl::deref(e_p2).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETopicField>(_m) ? prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::InferLambda(env_p0, st_p1, e_p2, std::optional<crate::check::types::Ty>{})))
        : prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m) ? prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::InferLambda(env_p0, st_p1, e_p2, std::optional<crate::check::types::Ty>{})))
        : prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m) ? ({
        auto&& recv_pu = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& m_pv = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args_p10 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::InferCall(env_p0, st_p1, crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{m_pv})), .span = prism_rtl::deref(m_pv).span}, append(Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = prism_rtl::deref(prism_rtl::deref(recv_pu)), .span = prism_rtl::deref(recv_pu).span}}), args_p10), prism_rtl::deref(e_p2).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m) ? ({
        auto&& target_p11 = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::InferCall(env_p0, st_p1, e_p2, Array<crate::syntax::Arg>{}, prism_rtl::deref(e_p2).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECast>(_m) ? ({
        auto&& x_p12 = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        auto&& ty_p13 = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a1;
        auto&& checked_p14 = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a2;
        prism_rtl::deref(checked_p14)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), prism_rtl::deref(e_p2).span, Text::lit("this checker does not implement non-empty arrays"))})
        : ({
        auto cx_p15 = env_cx(env_p0);
        auto env_p0_1 = env_p0;
        auto st_p1_2 = st_p1;
        auto ty_p13_3 = ty_p13;
        auto x_p12_4 = prism_rtl::deref(prism_rtl::deref(x_p12));
        call_then(crate::check::env::reading::start_conv_type(cx_p15, st_p1_2, ty_p13_3), [=, env_p0_1 = std::move(env_p0_1), x_p12_4 = std::move(x_p12_4)](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_6159) {
        return ({
            auto [t_p17, st2_p18] = conv_type_6159;
            call_then(start_check(env_p0_1, st2_p18, x_p12_4, t_p17), [=](crate::check::types::St check_6201) {
            return ({
                auto st3_p16 = check_6201;
                (prism_rtl::finished(std::tuple{t_p17, st3_p16}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), prism_rtl::deref(e_p2).span, Text::lit("this checker does not implement non-empty arrays"))})
        : prism_rtl::is<crate::syntax::ExprKind::EAbsent>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), prism_rtl::deref(e_p2).span, Text::lit("this checker does not implement sparse tuples"))})
        : prism_rtl::is<crate::syntax::ExprKind::ERest>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st_p1})
        : prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::InferLambda(env_p0, st_p1, e_p2, std::optional<crate::check::types::Ty>{})))
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c_p19 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_p1a = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_o1b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::lifting::InferIf(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(c_p19)), then_b_p1a, else_b_o1b, prism_rtl::deref(e_p2).span, std::optional<crate::check::types::Ty>{})));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& scrut_p1c = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p1d = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::lifting::InferMatch(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(scrut_p1c)), arms_p1d, prism_rtl::deref(e_p2).span, std::optional<crate::check::types::Ty>{})));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m) ? ({
        auto&& scrut_p1e = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& body_p1f = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::blocks::structure::InferRebuild(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(scrut_p1e)), body_p1f, prism_rtl::deref(e_p2).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& binders_o1g = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source_p1h = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body_p1i = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        prism_rtl::more(prism_rtl::rc(crate::check::blocks::structure::InferFor(env_p0, st_p1, binders_o1g, prism_rtl::deref(prism_rtl::deref(source_p1h)), body_p1i, prism_rtl::deref(e_p2).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m) ? ({
        auto&& b_p1j = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::blocks::structure::InferGiven(env_p0, st_p1, b_p1j, prism_rtl::deref(e_p2).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m) ? ({
        auto&& target_p1k = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& body_p1l = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::blocks::borrows::InferUpdate(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(target_p1k)), body_p1l, prism_rtl::deref(e_p2).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m) ? ({
        auto&& b_p1m = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        ({
        auto b_p1m_1 = b_p1m;
        auto env_p0_2 = env_p0;
        auto st_p1_3 = st_p1;
        call_then(crate::check::blocks::start_infer_widget_block(env_p0_2, st_p1_3, b_p1m_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block_6997) {
        return ({
            auto [t_p1n, st2_p1o] = infer_widget_block_6997;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t_p1n), prism_rtl::deref(env_p0_2).scope}), st2_p1o}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), prism_rtl::deref(e_p2).span, Text::lit("this checker does not implement `T monad:` blocks"))})
        : prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m) ? ({
        auto&& t_p1p = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::lets::InferTemplate(env_p0, st_p1, t_p1p)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EAny>(_m) ? ({
        auto&& x_p1q = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        ({
        auto env_p0_1 = env_p0;
        auto st_p1_2 = st_p1;
        auto x_p1q_3 = prism_rtl::deref(prism_rtl::deref(x_p1q));
        call_then(start_infer(env_p0_1, st_p1_2, x_p1q_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_7264) {
        return ({
            auto [t_p1r, st2_p1s] = infer_7264;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAny{Array<Text>{}}), st2_p1s}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::ELens>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unsupported"), prism_rtl::deref(e_p2).span, Text::lit("this checker does not implement named lenses and `Over`"))})
        : prism_rtl::is<crate::syntax::ExprKind::EError>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st_p1})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_kind(Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<InferKind>(env_p0, st_p1, e_p2);
}


/// InferAll: unbounded fn Env, St, [Expr] -> (([Ty], St))
std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> infer_all(const Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Expr>& es_p2) {
    return run_to_end(fold_job(es_p2, std::tuple{Array<crate::check::types::Ty>{}, st_p1}, ({
        auto env_p0_1 = env_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Expr>)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1)](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0_1_2 = env_p0_1;
            entered(once_job([=, env_p0_1_2 = std::move(env_p0_1_2)]() {
            return ({
                auto [acc_p3, s_p4] = p0;
                auto x_p5 = p1;
                call_then(start_infer(env_p0_1_2, s_p4, x_p5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_7597) {
                return ({
                    auto [t_p6, s2_p7] = infer_7597;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p3, t_p6), s2_p7}));
                });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> InferAll::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& es_p2 = this->es_p2;
    return fold_job(es_p2, std::tuple{Array<crate::check::types::Ty>{}, st_p1}, ({
        auto env_p0_1 = env_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Expr>)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1)](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0_1_2 = env_p0_1;
            entered(once_job([=, env_p0_1_2 = std::move(env_p0_1_2)]() {
            return ({
                auto [acc_p3, s_p4] = p0;
                auto x_p5 = p1;
                call_then(start_infer(env_p0_1_2, s_p4, x_p5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_7597) {
                return ({
                    auto [t_p6, s2_p7] = infer_7597;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p3, t_p6), s2_p7}));
                });
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start InferAll, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> start_infer_all(Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Expr> es_p2) {
    return prism_rtl::make_rc<InferAll>(env_p0, st_p1, es_p2);
}


/// Check: unbounded fn Env, St, Expr, Ty -> St
crate::check::types::St check(const Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2, const crate::check::types::Ty& expected_p3) {
    auto&& _m = prism_rtl::deref(e_p2.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        auto [t_p4, st2_p5] = crate::check::expr::calls::infer_lambda(env_p0, st_p1, e_p2, std::optional(expected_p3));
        return crate::check::types::unify::unify(crate::check::types::recording::note_ty(st2_p5, e_p2.span, t_p4), expected_p3, t_p4, e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p6 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return crate::check::types::recording::note_ty(crate::check::expr::check(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_p6)), expected_p3), e_p2.span, expected_p3);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& scrut_p7 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p8 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        auto [t_p9, st2_pa] = crate::check::expr::lifting::infer_match(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(scrut_p7)), arms_p8, e_p2.span, std::optional(expected_p3));
        return crate::check::types::unify::unify(crate::check::types::recording::note_ty(st2_pa, e_p2.span, t_p9), expected_p3, t_p9, e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c_pb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_pc = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_od = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        auto [t_pe, st2_pf] = crate::check::expr::lifting::infer_if(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(c_pb)), then_b_pc, else_b_od, e_p2.span, std::optional(expected_p3));
        return crate::check::types::unify::unify(crate::check::types::recording::note_ty(st2_pf, e_p2.span, t_pe), expected_p3, t_pe, e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
        auto&& x_pg = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        return crate::check::types::recording::note_ty(check_any(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_pg)), expected_p3, e_p2.span), e_p2.span, expected_p3);
    }
    {
        auto [t_ph, st2_pi] = infer(env_p0, st_p1, e_p2);
        return crate::check::types::unify::unify(st2_pi, expected_p3, t_ph, e_p2.span);
    }
}


prism_rtl::Turn<crate::check::types::St> Check::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& e_p2 = this->e_p2;
    const auto& expected_p3 = this->expected_p3;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind);
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto e_p2_1 = e_p2;
        auto env_p0_2 = env_p0;
        auto expected_p3_3 = expected_p3;
        auto st_p1_4 = st_p1;
        call_then(crate::check::expr::calls::start_infer_lambda(env_p0_2, st_p1_4, e_p2_1, std::optional(expected_p3_3)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lambda_7906) {
        return ({
            auto [t_p4, st2_p5] = infer_lambda_7906;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(crate::check::types::recording::note_ty(st2_p5, prism_rtl::deref(e_p2_1).span, t_p4), expected_p3_3, t_p4, prism_rtl::deref(e_p2_1).span))));
        });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p6 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        ({
        auto e_p2_1 = e_p2;
        auto env_p0_2 = env_p0;
        auto expected_p3_3 = expected_p3;
        auto st_p1_4 = st_p1;
        auto x_p6_5 = prism_rtl::deref(prism_rtl::deref(x_p6));
        call_then(start_check(env_p0_2, st_p1_4, x_p6_5, expected_p3_3), [=, e_p2_1 = std::move(e_p2_1)](crate::check::types::St check_8024) { return prism_rtl::finished(crate::check::types::recording::note_ty(check_8024, prism_rtl::deref(e_p2_1).span, expected_p3_3)); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& scrut_p7 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p8 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        ({
        auto arms_p8_1 = arms_p8;
        auto e_p2_2 = e_p2;
        auto env_p0_3 = env_p0;
        auto expected_p3_4 = expected_p3;
        auto scrut_p7_5 = prism_rtl::deref(prism_rtl::deref(scrut_p7));
        auto st_p1_6 = st_p1;
        call_then(crate::check::expr::lifting::start_infer_match(env_p0_3, st_p1_6, scrut_p7_5, arms_p8_1, prism_rtl::deref(e_p2_2).span, std::optional(expected_p3_4)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_match_8119) {
        return ({
            auto [t_p9, st2_pa] = infer_match_8119;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(crate::check::types::recording::note_ty(st2_pa, prism_rtl::deref(e_p2_2).span, t_p9), expected_p3_4, t_p9, prism_rtl::deref(e_p2_2).span))));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c_pb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_pc = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_od = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        ({
        auto else_b_od_1 = else_b_od;
        auto c_pb_2 = prism_rtl::deref(prism_rtl::deref(c_pb));
        auto e_p2_3 = e_p2;
        auto env_p0_4 = env_p0;
        auto expected_p3_5 = expected_p3;
        auto st_p1_6 = st_p1;
        auto then_b_pc_7 = then_b_pc;
        call_then(crate::check::expr::lifting::start_infer_if(env_p0_4, st_p1_6, c_pb_2, then_b_pc_7, else_b_od_1, prism_rtl::deref(e_p2_3).span, std::optional(expected_p3_5)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_if_8283) {
        return ({
            auto [t_pe, st2_pf] = infer_if_8283;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(crate::check::types::recording::note_ty(st2_pf, prism_rtl::deref(e_p2_3).span, t_pe), expected_p3_5, t_pe, prism_rtl::deref(e_p2_3).span))));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EAny>(_m) ? ({
        auto&& x_pg = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        ({
        auto e_p2_1 = e_p2;
        auto env_p0_2 = env_p0;
        auto expected_p3_3 = expected_p3;
        auto st_p1_4 = st_p1;
        auto x_pg_5 = prism_rtl::deref(prism_rtl::deref(x_pg));
        call_then(start_check_any(env_p0_2, st_p1_4, x_pg_5, expected_p3_3, prism_rtl::deref(e_p2_1).span), [=](crate::check::types::St check_any_8418) { return prism_rtl::finished(crate::check::types::recording::note_ty(check_any_8418, prism_rtl::deref(e_p2_1).span, expected_p3_3)); });
    });
    })
        : ({
        auto e_p2_1 = e_p2;
        auto env_p0_2 = env_p0;
        auto expected_p3_3 = expected_p3;
        auto st_p1_4 = st_p1;
        call_then(start_infer(env_p0_2, st_p1_4, e_p2_1), [=, expected_p3_3 = std::move(expected_p3_3)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_8515) {
        return ({
            auto [t_ph, st2_pi] = infer_8515;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st2_pi, expected_p3_3, t_ph, prism_rtl::deref(e_p2_1).span))));
        });
    });
    });
    });
}


/// `Start Check, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check(Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2, crate::check::types::Ty expected_p3) {
    return prism_rtl::make_rc<Check>(env_p0, st_p1, e_p2, expected_p3);
}


/// CheckAny: unbounded fn Env, St, Expr, Ty, Range -> St
crate::check::types::St check_any(const Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& x_p2, const crate::check::types::Ty& expected_p3, const crate::syntax::Range& span_p4) {
    auto&& _m = crate::check::types::recording::walk(st_p1, expected_p3);
    if (prism_rtl::is<crate::check::types::Ty::TyAny>(_m)) {
        auto&& trs_p5 = prism_rtl::as<crate::check::types::Ty::TyAny>(_m).a0;
        auto [t_p6, st2_p7] = infer(env_p0, st_p1, x_p2);
        return fold(trs_p5, st2_p7, [&](const crate::check::types::St& s_p8, const Text& tr_p9) { return add_want(s_p8, tr_p9, t_p6, span_p4); });
    }
    {
        auto&& other_pa = _m;
        auto [t_pb, st2_pc] = infer(env_p0, st_p1, x_p2);
        return crate::check::types::unify::unify(st2_pc, other_pa, crate::check::types::Ty(crate::check::types::Ty::TyAny{Array<Text>{}}), span_p4);
    }
}


prism_rtl::Turn<crate::check::types::St> CheckAny::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& x_p2 = this->x_p2;
    const auto& expected_p3 = this->expected_p3;
    const auto& span_p4 = this->span_p4;
    auto env_p0_1 = env_p0;
    auto expected_p3_2 = expected_p3;
    auto span_p4_3 = span_p4;
    auto st_p1_4 = st_p1;
    auto x_p2_5 = x_p2;
    return call_then(crate::check::types::recording::start_walk(st_p1_4, expected_p3_2), [=](crate::check::types::Ty walk_8763) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyAny>(walk_8763) ? ({
            auto&& trs_p5 = prism_rtl::as<crate::check::types::Ty::TyAny>(walk_8763).a0;
            call_then(start_infer(env_p0_1, st_p1_4, x_p2_5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_8822) {
            return ({
                auto [t_p6, st2_p7] = infer_8822;
                (prism_rtl::finished(fold(trs_p5, st2_p7, [&](const crate::check::types::St& s_p8, const Text& tr_p9) { return add_want(s_p8, tr_p9, t_p6, span_p4_3); })));
            });
        });
        })
            : ({
            auto&& other_pa = walk_8763;
            call_then(start_infer(env_p0_1, st_p1_4, x_p2_5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_8930) {
            return ({
                auto [t_pb, st2_pc] = infer_8930;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st2_pc, other_pa, crate::check::types::Ty(crate::check::types::Ty::TyAny{Array<Text>{}}), span_p4_3))));
            });
        });
        });
        });
    });
}


/// `Start CheckAny, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_any(Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr x_p2, crate::check::types::Ty expected_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<CheckAny>(env_p0, st_p1, x_p2, expected_p3, span_p4);
}


/// AddWant: fn St, Text, Ty, Range -> St
crate::check::types::St add_want(const crate::check::types::St& st_p0, const Text& cls_p1, const crate::check::types::Ty& t_p2, const crate::syntax::Range& span_p3) {
    crate::check::types::St this_ = st_p0;
    this_.wants = crate::prelude::push(this_.wants, crate::check::types::Want{.cls = cls_p1, .ty = t_p2, .file = this_.file, .span = span_p3, .level = this_.level});
    return this_;
}


/// EnvCx: fn Env -> Cx
crate::check::env::reading::Cx_ env_cx(const Env& env_p0) {
    auto base_p1 = crate::check::env::reading::cx_of(env_p0.g, env_p0.home);
    crate::check::env::reading::Cx_ this_ = base_p1;
    this_.scope = env_p0.scope;
    return this_;
}


/// InferName: unbounded fn Env, St, SName, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_name(const Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::SName& n_p2, const crate::syntax::Range& span_p3) {
    auto local_p4 = crate::check::env::sname_key(n_p2);
    return env_p0.in_update && has_time_mark(n_p2.sigils)
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix(st_p1, Text::lit("time-in-update"), span_p3, prism_rtl::cat("`", local_p4, "` in an `update` block"), Text::lit("an `&` block cannot see time: pass the plain value in, and lift the function"))}
        : infer_name_in(env_p0, st_p1, n_p2, span_p3);
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferName::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& n_p2 = this->n_p2;
    const auto& span_p3 = this->span_p3;
    auto local_p4 = crate::check::env::sname_key(n_p2);
    return prism_rtl::deref(env_p0).in_update && has_time_mark(prism_rtl::deref(n_p2).sigils)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix(st_p1, Text::lit("time-in-update"), span_p3, prism_rtl::cat("`", local_p4, "` in an `update` block"), Text::lit("an `&` block cannot see time: pass the plain value in, and lift the function"))})
        : prism_rtl::more(prism_rtl::rc(InferNameIn(env_p0, st_p1, n_p2, span_p3)));
}


/// `Start InferName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_name(Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<InferName>(env_p0, st_p1, n_p2, span_p3);
}


/// InferNameIn: unbounded fn Env, St, SName, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_name_in(const Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::SName& n_p2, const crate::syntax::Range& span_p3) {
    auto local_p4 = crate::check::env::sname_key(n_p2);
    auto&& _m = crate::prelude::get(env_p0.locals, local_p4);
    if (prism_rtl::is_some(_m)) {
        auto&& sc_p5 = prism_rtl::some_of(_m);
        auto st2_p6 = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            auto&& _m = crate::prelude::get(env_p0.ids, local_p4);
            if (prism_rtl::is_some(_m)) {
                auto&& id_p7 = prism_rtl::some_of(_m);
                _v.set(crate::check::types::recording::note_use(st_p1, span_p3, id_p7));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(st_p1);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return instantiate_local(st2_p6, sc_p5, span_p3, local_p4);
    }
    if (prism_rtl::is_none(_m)) {
        return infer_global(env_p0, st_p1, n_p2, span_p3);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferNameIn::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& n_p2 = this->n_p2;
    const auto& span_p3 = this->span_p3;
    auto local_p4 = crate::check::env::sname_key(n_p2);
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0).locals, local_p4);
        prism_rtl::is_some(_m) ? ({
        auto&& sc_p5 = prism_rtl::some_of(_m);
        ({
        auto st2_p6 = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0).ids, local_p4);
            if (prism_rtl::is_some(_m)) {
                auto&& id_p7 = prism_rtl::some_of(_m);
                _v.set(crate::check::types::recording::note_use(st_p1, span_p3, id_p7));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(st_p1);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::more(prism_rtl::rc(InstantiateLocal(st2_p6, sc_p5, span_p3, local_p4))));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(InferGlobal(env_p0, st_p1, n_p2, span_p3)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferNameIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_name_in(Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<InferNameIn>(env_p0, st_p1, n_p2, span_p3);
}


/// InstantiateLocal: unbounded fn St, Scheme, Range, Text -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_local(const crate::check::types::St& st_p0, const crate::check::types::Scheme& sc_p1, const crate::syntax::Range& span_p2, const Text& name_p3) {
    return (len(sc_p1.qs) == Nat(0u)) && (len(sc_p1.cqs) == Nat(0u))
        ? crate::check::types::schemes::instantiate(st_p0, sc_p1, span_p2)
        : ({
        auto [t_p4, st2_p5, inst_p6] = crate::check::types::schemes::instantiate_with(st_p0, sc_p1, span_p2, Array<crate::check::types::Ty>{});
        std::tuple{t_p4, crate::check::types::recording::note_inst(st2_p5, span_p2, name_p3, sc_p1, inst_p6)};
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InstantiateLocal::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& sc_p1 = this->sc_p1;
    const auto& span_p2 = this->span_p2;
    const auto& name_p3 = this->name_p3;
    return (len(prism_rtl::deref(sc_p1).qs) == Nat(0u)) && (len(prism_rtl::deref(sc_p1).cqs) == Nat(0u))
        ? prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::Instantiate(st_p0, sc_p1, span_p2)))
        : ({
        auto name_p3_1 = name_p3;
        auto sc_p1_2 = sc_p1;
        auto span_p2_3 = span_p2;
        auto st_p0_4 = st_p0;
        call_then(crate::check::types::schemes::start_instantiate_with(st_p0_4, sc_p1_2, span_p2_3, Array<crate::check::types::Ty>{}), [=, name_p3_1 = std::move(name_p3_1)](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst> instantiate_with_10571) {
        return ({
            auto [t_p4, st2_p5, inst_p6] = instantiate_with_10571;
            (prism_rtl::finished(std::tuple{t_p4, crate::check::types::recording::note_inst(st2_p5, span_p2_3, name_p3_1, sc_p1_2, inst_p6)}));
        });
    });
    });
}


/// `Start InstantiateLocal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_instantiate_local(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1, crate::syntax::Range span_p2, Text name_p3) {
    return prism_rtl::make_rc<InstantiateLocal>(st_p0, sc_p1, span_p2, name_p3);
}


/// InferGlobal: unbounded fn Env, St, SName, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_global(const Env& env_p0, const crate::check::types::St& st0_p1, const crate::syntax::SName& n_p2, const crate::syntax::Range& span_p3) {
    auto [qk_o5, why_p6] = crate::check::env::names::resolve_value(env_p0.g, env_p0.home, n_p2);
    auto st_p4 = collision_at(env_p0, st0_p1, why_p6, crate::check::env::sname_key(n_p2), span_p3);
    if (prism_rtl::is_none(qk_o5)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p4, Text::lit("unknown-name"), span_p3, prism_rtl::cat("nothing declares `", crate::check::env::sname_key(n_p2), "` here"))};
    }
    if (prism_rtl::is_some(qk_o5)) {
        auto&& qk_p7 = prism_rtl::some_of(qk_o5);
        return why_p6 == Text::lit("tag")
            ? tag_value(env_p0, st_p4, qk_p7, span_p3)
            : crate::check::expr::calls::is_local_maker(qk_p7) && (!env_p0.in_update)
            ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::expr::calls::local_outside(st_p4, qk_p7, span_p3)}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g).vals, qk_p7);
            if (prism_rtl::is_some(_m)) {
                auto&& v_p8 = prism_rtl::some_of(_m);
                _v.set(crate::check::types::schemes::instantiate(crate::check::expr::calls::note_method_use(st_p4, v_p8, span_p3), prism_rtl::deref(v_p8).scheme, span_p3));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g).ctors, qk_p7);
                    if (prism_rtl::is_some(_m)) {
                        auto&& c_p9 = prism_rtl::some_of(_m);
                        _v.set(ctor_value(env_p0, st_p4, c_p9, span_p3));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p4, Text::lit("unknown-name"), span_p3, prism_rtl::cat("`", crate::check::env::sname_key(n_p2), "` has no signature line or type"))});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferGlobal::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st0_p1 = this->st0_p1;
    const auto& n_p2 = this->n_p2;
    const auto& span_p3 = this->span_p3;
    auto [qk_o5, why_p6] = crate::check::env::names::resolve_value(prism_rtl::deref(env_p0).g, prism_rtl::deref(env_p0).home, n_p2);
    auto st_p4 = collision_at(env_p0, st0_p1, why_p6, crate::check::env::sname_key(n_p2), span_p3);
    return ({
        prism_rtl::is_none(qk_o5) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p4, Text::lit("unknown-name"), span_p3, prism_rtl::cat("nothing declares `", crate::check::env::sname_key(n_p2), "` here"))})
        : prism_rtl::is_some(qk_o5) ? ({
        auto&& qk_p7 = prism_rtl::some_of(qk_o5);
        why_p6 == Text::lit("tag")
        ? prism_rtl::more(prism_rtl::rc(TagValue(env_p0, st_p4, qk_p7, span_p3)))
        : crate::check::expr::calls::is_local_maker(qk_p7) && (!prism_rtl::deref(env_p0).in_update)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::expr::calls::local_outside(st_p4, qk_p7, span_p3)})
        : ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g).vals, qk_p7);
        prism_rtl::is_some(_m) ? ({
        auto&& v_p8 = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::Instantiate(crate::check::expr::calls::note_method_use(st_p4, v_p8, span_p3), prism_rtl::deref(v_p8).scheme, span_p3)));
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g).ctors, qk_p7);
        prism_rtl::is_some(_m) ? ({
        auto&& c_p9 = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(CtorValue(env_p0, st_p4, c_p9, span_p3)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p4, Text::lit("unknown-name"), span_p3, prism_rtl::cat("`", crate::check::env::sname_key(n_p2), "` has no signature line or type"))})
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferGlobal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_global(Env env_p0, crate::check::types::St st0_p1, crate::syntax::SName n_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<InferGlobal>(env_p0, st0_p1, n_p2, span_p3);
}


/// CollisionAt: fn Env, St, Text, Text, Range -> St
crate::check::types::St collision_at(const Env& env_p0, const crate::check::types::St& st_p1, const Text& why_p2, const Text& name_p3, const crate::syntax::Range& span_p4) {
    return why_p2 != Text::lit("collision")
        ? st_p1
        : ({
        auto keys_p5 = or_(crate::prelude::get(or_(crate::prelude::get(prism_rtl::deref(env_p0.g).bare, env_p0.home), Map<Text, Array<Text>>{}), name_p3), Array<Text>{});
        auto others_p6 = filter(keys_p5, [&](const Text& k_p7) { return crate::syntax::lexer::chars::contains(k_p7, Text::lit(".")); });
        (crate::check::types::recording::err_fix(st_p1, Text::lit("collision"), span_p4, prism_rtl::cat("`", name_p3, "` is declared by more than one module this file reaches by a bare name: ", crate::syntax::lexer::chars::join(each(keys_p5, [&](const Text& k_p8) { return prism_rtl::cat("`", k_p8, "`"); }), Text::lit(", "))), prism_rtl::cat("write the one meant qualified, as `", or_(index(others_p6, Nat(0u)), name_p3), "`, or rename this file\'s own")));
    });
}


/// CtorValue: unbounded fn Env, St, CtorInfo, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> ctor_value(const Env& env_p0, const crate::check::types::St& st_p1, const crate::check::env::CtorInfo& c_p2, const crate::syntax::Range& span_p3) {
    auto sc_p4 = crate::check::types::Scheme{.qs = c_p2.params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = len(c_p2.args) == Nat(0u)
        ? c_p2.ty
        : crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), c_p2.args, prism_rtl::rc(c_p2.ty)})};
    return crate::check::types::schemes::instantiate(st_p1, sc_p4, span_p3);
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> CtorValue::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& c_p2 = this->c_p2;
    const auto& span_p3 = this->span_p3;
    auto sc_p4 = crate::check::types::Scheme{.qs = prism_rtl::deref(c_p2).params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = len(c_p2->args) == Nat(0u)
        ? prism_rtl::deref(c_p2).ty
        : crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), c_p2->args, prism_rtl::rc(prism_rtl::deref(c_p2).ty)})};
    return prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::Instantiate(st_p1, sc_p4, span_p3)));
}


/// `Start CtorValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_ctor_value(Env env_p0, crate::check::types::St st_p1, crate::check::env::CtorInfo c_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<CtorValue>(env_p0, st_p1, c_p2, span_p3);
}


/// TagValue: unbounded fn Env, St, Text, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> tag_value(const Env& env_p0, const crate::check::types::St& st_p1, const Text& name_p2, const crate::syntax::Range& span_p3) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g).tags, name_p2);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unknown-name"), span_p3, prism_rtl::cat("no tag `", name_p2, "`"))};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& tg_p4 = prism_rtl::some_of(_m);
        return prism_rtl::deref(tg_p4).kind == Text::lit("Element")
            ? ({
            auto [rw_p6, st2_p7] = crate::check::types::recording::fresh_row(st_p1, Array(std::vector{prism_rtl::deref(tg_p4).family}));
            auto erow_p5 = crate::check::types::Rw{.fams = Array(std::vector{prism_rtl::deref(tg_p4).family}), .minus = Array<Text>{}, .tail = prism_rtl::deref(rw_p6).tail};
            auto [out_p8, st3_p9] = crate::check::types::schemes::instantiate(st2_p7, crate::check::types::Scheme{.qs = prism_rtl::deref(tg_p4).qs, .plain_qs = Array<Text>{}, .rqs = prism_rtl::deref(tg_p4).rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = prism_rtl::deref(tg_p4).bounds, .ty = tg_p4->out}, span_p3);
            std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{erow_p5, prism_rtl::rc(out_p8)}), st3_p9};
        })
            : std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(tg_p4).kind, Array<crate::check::types::Ty>{}}), st_p1};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> TagValue::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& name_p2 = this->name_p2;
    const auto& span_p3 = this->span_p3;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g).tags, name_p2);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unknown-name"), span_p3, prism_rtl::cat("no tag `", name_p2, "`"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& tg_p4 = prism_rtl::some_of(_m);
        prism_rtl::deref(tg_p4).kind == Text::lit("Element")
        ? ({
        auto [rw_p6, st2_p7] = crate::check::types::recording::fresh_row(st_p1, Array(std::vector{prism_rtl::deref(tg_p4).family}));
        auto erow_p5 = crate::check::types::Rw{.fams = Array(std::vector{prism_rtl::deref(tg_p4).family}), .minus = Array<Text>{}, .tail = prism_rtl::deref(rw_p6).tail};
        auto span_p3_1 = span_p3;
        call_then(crate::check::types::schemes::start_instantiate(st2_p7, crate::check::types::Scheme{.qs = prism_rtl::deref(tg_p4).qs, .plain_qs = Array<Text>{}, .rqs = prism_rtl::deref(tg_p4).rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = prism_rtl::deref(tg_p4).bounds, .ty = tg_p4->out}, span_p3_1), [=, erow_p5 = std::move(erow_p5)](std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_13081) {
        return ({
            auto [out_p8, st3_p9] = instantiate_13081;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{erow_p5, prism_rtl::rc(out_p8)}), st3_p9}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(tg_p4).kind, Array<crate::check::types::Ty>{}}), st_p1});
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TagValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_tag_value(Env env_p0, crate::check::types::St st_p1, Text name_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<TagValue>(env_p0, st_p1, name_p2, span_p3);
}


/// InferBound: fn Env, St, Text, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_bound(const Env& env_p0, const crate::check::types::St& st_p1, const Text& b_p2, const crate::syntax::Range& span_p3) {
    auto&& _m = crate::prelude::get(env_p0.locals, b_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& sc_p4 = prism_rtl::some_of(_m);
        return std::tuple{prism_rtl::deref(sc_p4).ty, st_p1};
    }
    if (prism_rtl::is_none(_m)) {
        return b_p2 == Text::lit("key")
            ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unknown-name"), span_p3, Text::lit("`key` is bound only in a loop over a map"))}
            : std::tuple{crate::check::types::t_nat(), st_p1};
    }
    prism_rtl::unreachable("no arm matched");
}


/// InferLit: unbounded fn Env, St, Literal, Bool, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lit(const Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Literal& l_p2, const bool& negative_p3, const crate::syntax::Range& span_p4) {
    auto sigils_p5 = crate::syntax::lexer::chars::fold_chars(l_p2.marks, Text::lit(""), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto acc_p7 = p0;
                auto c_p8 = p1;
                (crate::check::types::unify::is_mark_char(c_p8)
                ? prism_rtl::finished(prism_rtl::cat(acc_p7, c_p8))
                : prism_rtl::finished(acc_p7));
            });
        });
    })));
    auto signed_p6 = negative_p3 || crate::syntax::lexer::chars::contains(l_p2.marks, Text::lit("-"));
    auto [base_ph, st2_pi] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = l_p2.kind;
        if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
            auto&& digits_p9 = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
            _v.set(({
                auto [v_pd, s1_pe] = crate::check::types::fresh_var(st_p1, true, Text::lit(""));
                auto s2_pa = add_want(s1_pe, Text::lit("Prelude.Num"), v_pd, span_p4);
                auto s3_pb = std::move(signed_p6)
                    ? add_want(s2_pa, Text::lit("Prelude.Signed"), v_pd, span_p4)
                    : s2_pa;
                auto s4_pc = add_range(s3_pb, v_pd, digits_p9, signed_p6, span_p4);
                std::tuple{v_pd, s4_pc};
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LitKind::LFloat>(_m)) {
            _v.set(std::tuple{crate::check::types::t_float(), st_p1});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LitKind::LDuration>(_m)) {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Duration"), Array<crate::check::types::Ty>{}}), st_p1});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
            _v.set(std::tuple{crate::check::types::t_char(), st_p1});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
            auto&& segs_pf = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
            _v.set(infer_text(env_p0, st_p1, segs_pf, crate::syntax::lexer::chars::contains(sigils_p5, Text::lit("$")), span_p4));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LitKind::LRegex>(_m)) {
            auto&& r_pg = prism_rtl::as<crate::syntax::LitKind::LRegex>(_m).a0;
            _v.set(infer_regex(st_p1, r_pg));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::syntax::lexer::chars::contains(sigils_p5, Text::lit("$")) && (crate::check::types::head_sigil(st2_pi, base_ph) == Text::lit("$"))
        ? std::tuple{base_ph, st2_pi}
        : crate::syntax::lexer::chars::contains(sigils_p5, Text::lit("$"))
        ? std::tuple{crate::check::types::with_marks(sigils_p5, base_ph, env_p0.scope), crate::check::types::recording::note_app(st2_pi, span_p4, Text::lit("$"), Text::lit("const"), Text::lit("$"), Array<Nat>{}, Text::lit(""), crate::check::types::Col(crate::check::types::Col::CBound{}))}
        : std::tuple{crate::check::types::with_marks(sigils_p5, base_ph, env_p0.scope), st2_pi};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferLit::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& l_p2 = this->l_p2;
    const auto& negative_p3 = this->negative_p3;
    const auto& span_p4 = this->span_p4;
    auto env_p0_1 = env_p0;
    auto l_p2_2 = l_p2;
    auto negative_p3_3 = prism_rtl::deref(negative_p3);
    auto span_p4_4 = span_p4;
    auto st_p1_5 = st_p1;
    return call_value(crate::syntax::lexer::chars::start_fold_chars(prism_rtl::deref(l_p2_2).marks, Text::lit(""), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto acc_p7 = p0;
                auto c_p8 = p1;
                (crate::check::types::unify::is_mark_char(c_p8)
                ? prism_rtl::finished(prism_rtl::cat(acc_p7, c_p8))
                : prism_rtl::finished(acc_p7));
            });
        });
    }))), [=](Text fold_chars_14054) {
        return ({
            auto sigils_p5 = fold_chars_14054;
            auto signed_p6 = negative_p3_3 || crate::syntax::lexer::chars::contains(prism_rtl::deref(l_p2_2).marks, Text::lit("-"));
            auto [base_ph, st2_pi] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                auto&& _m = prism_rtl::deref(l_p2_2).kind;
                if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
                    auto&& digits_p9 = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
                    _v.set(({
                        auto [v_pd, s1_pe] = crate::check::types::fresh_var(st_p1_5, true, Text::lit(""));
                        auto s2_pa = add_want(s1_pe, Text::lit("Prelude.Num"), v_pd, span_p4_4);
                        auto s3_pb = std::move(signed_p6)
                            ? add_want(s2_pa, Text::lit("Prelude.Signed"), v_pd, span_p4_4)
                            : s2_pa;
                        auto s4_pc = add_range(s3_pb, v_pd, digits_p9, signed_p6, span_p4_4);
                        std::tuple{v_pd, s4_pc};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LitKind::LFloat>(_m)) {
                    _v.set(std::tuple{crate::check::types::t_float(), st_p1_5});
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LitKind::LDuration>(_m)) {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Duration"), Array<crate::check::types::Ty>{}}), st_p1_5});
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
                    _v.set(std::tuple{crate::check::types::t_char(), st_p1_5});
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
                    auto&& segs_pf = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
                    _v.set(infer_text(env_p0_1, st_p1_5, segs_pf, crate::syntax::lexer::chars::contains(sigils_p5, Text::lit("$")), span_p4_4));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LitKind::LRegex>(_m)) {
                    auto&& r_pg = prism_rtl::as<crate::syntax::LitKind::LRegex>(_m).a0;
                    _v.set(infer_regex(st_p1_5, r_pg));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (crate::syntax::lexer::chars::contains(sigils_p5, Text::lit("$")) && (crate::check::types::head_sigil(st2_pi, base_ph) == Text::lit("$"))
            ? prism_rtl::finished(std::tuple{base_ph, st2_pi})
            : crate::syntax::lexer::chars::contains(sigils_p5, Text::lit("$"))
            ? prism_rtl::finished(std::tuple{crate::check::types::with_marks(sigils_p5, base_ph, prism_rtl::deref(env_p0_1).scope), crate::check::types::recording::note_app(st2_pi, span_p4_4, Text::lit("$"), Text::lit("const"), Text::lit("$"), Array<Nat>{}, Text::lit(""), crate::check::types::Col(crate::check::types::Col::CBound{}))})
            : prism_rtl::finished(std::tuple{crate::check::types::with_marks(sigils_p5, base_ph, prism_rtl::deref(env_p0_1).scope), st2_pi}));
        });
    });
}


/// `Start InferLit, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_lit(Env env_p0, crate::check::types::St st_p1, crate::syntax::Literal l_p2, bool negative_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<InferLit>(env_p0, st_p1, l_p2, negative_p3, span_p4);
}


/// InferRegex: unbounded fn St, RegexLit -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_regex(const crate::check::types::St& st_p0, const crate::syntax::RegexLit& r_p1) {
    auto t_p2 = crate::check::types::Ty(crate::check::types::Ty::TyCon{r_p1.replacement == std::optional<Text>{}
        ? Text::lit("Regex")
        : Text::lit("RegexReplacement"), Array<crate::check::types::Ty>{}});
    auto&& _m = crate::check::regex::regex_refusal(r_p1.pattern, r_p1.flags, r_p1.replacement);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{t_p2, st_p0};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& d_p3 = prism_rtl::some_of(_m);
        auto [base_p6, text_p7] = prism_rtl::deref(d_p3).part == Text::lit("flags")
            ? std::tuple{r_p1.flags_at, r_p1.flags}
            : prism_rtl::deref(d_p3).part == Text::lit("pattern")
            ? std::tuple{r_p1.pattern_at, r_p1.pattern}
            : std::tuple{r_p1.replacement_at, or_(r_p1.replacement, Text::lit(""))};
        auto start_p4 = base_p6 + prism_rtl::deref(d_p3).at;
        auto span_p5 = crate::syntax::Range{.start = start_p4, .end = start_p4 + crate::prelude::max(len_text(crate::check::regex::rx_char_at(text_p7, prism_rtl::deref(d_p3).at)), Nat(1u))};
        return prism_rtl::deref(d_p3).message == crate::check::regex::rx_unknown_flag()
            ? std::tuple{t_p2, crate::check::types::recording::err_fix(st_p0, Text::lit("regex"), span_p5, prism_rtl::deref(d_p3).message, Text::lit("a replacement that starts with letters and holds anything but letters is written in the hashed form, `%#/x/#hello world/#`"))}
            : std::tuple{t_p2, crate::check::types::recording::err(st_p0, Text::lit("regex"), span_p5, prism_rtl::deref(d_p3).message)};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferRegex::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& r_p1 = this->r_p1;
    auto t_p2 = crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(r_p1).replacement == std::optional<Text>{}
        ? Text::lit("Regex")
        : Text::lit("RegexReplacement"), Array<crate::check::types::Ty>{}});
    auto r_p1_1 = r_p1;
    auto st_p0_2 = st_p0;
    return call_then(crate::check::regex::start_regex_refusal(prism_rtl::deref(r_p1_1).pattern, prism_rtl::deref(r_p1_1).flags, prism_rtl::deref(r_p1_1).replacement), [=](std::optional<crate::check::regex::RxDiag> regex_refusal_15526) {
        return ({
            prism_rtl::is_none(regex_refusal_15526) ? prism_rtl::finished(std::tuple{t_p2, st_p0_2})
            : prism_rtl::is_some(regex_refusal_15526) ? ({
            auto&& d_p3 = prism_rtl::some_of(regex_refusal_15526);
            ({
            auto [base_p6, text_p7] = prism_rtl::deref(d_p3).part == Text::lit("flags")
                ? std::tuple{prism_rtl::deref(r_p1_1).flags_at, prism_rtl::deref(r_p1_1).flags}
                : prism_rtl::deref(d_p3).part == Text::lit("pattern")
                ? std::tuple{prism_rtl::deref(r_p1_1).pattern_at, prism_rtl::deref(r_p1_1).pattern}
                : std::tuple{prism_rtl::deref(r_p1_1).replacement_at, or_(prism_rtl::deref(r_p1_1).replacement, Text::lit(""))};
            auto start_p4 = base_p6 + prism_rtl::deref(d_p3).at;
            auto span_p5 = crate::syntax::Range{.start = start_p4, .end = start_p4 + crate::prelude::max(len_text(crate::check::regex::rx_char_at(text_p7, prism_rtl::deref(d_p3).at)), Nat(1u))};
            (prism_rtl::deref(d_p3).message == crate::check::regex::rx_unknown_flag()
            ? prism_rtl::finished(std::tuple{t_p2, crate::check::types::recording::err_fix(st_p0_2, Text::lit("regex"), span_p5, prism_rtl::deref(d_p3).message, Text::lit("a replacement that starts with letters and holds anything but letters is written in the hashed form, `%#/x/#hello world/#`"))})
            : prism_rtl::finished(std::tuple{t_p2, crate::check::types::recording::err(st_p0_2, Text::lit("regex"), span_p5, prism_rtl::deref(d_p3).message)}));
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start InferRegex, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_regex(crate::check::types::St st_p0, crate::syntax::RegexLit r_p1) {
    return prism_rtl::make_rc<InferRegex>(st_p0, r_p1);
}


/// AddRange: fn St, Ty, Text, Bool, Range -> St
crate::check::types::St add_range(const crate::check::types::St& st_p0, const crate::check::types::Ty& v_p1, const Text& digits_p2, const bool& signed_p3, const crate::syntax::Range& span_p4) {
    crate::check::types::St this_ = st_p0;
    this_.wants = crate::prelude::push(this_.wants, crate::check::types::Want{.cls = prism_rtl::cat("Range ", signed_p3 ? Text::lit("-") : Text::lit(""), digits_p2), .ty = v_p1, .file = this_.file, .span = span_p4, .level = this_.level});
    return this_;
}


/// InferText: unbounded fn Env, St, [TextSeg], Bool, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_text(const Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::TextSeg>& segs_p2, const bool& dollar_p3, const crate::syntax::Range& span_p4) {
    auto holes_p5 = fold(segs_p2, Array<crate::syntax::Expr>{}, [&](const Array<crate::syntax::Expr>& acc_p6, const crate::syntax::TextSeg& sg_p7) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
            if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg_p7)) {
                auto&& x_p8 = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg_p7).a0;
                _v.set(crate::prelude::push(acc_p6, x_p8));
                goto _done;
            }
            {
                _v.set(acc_p6);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return len(holes_p5) == Nat(0u)
        ? std::tuple{crate::check::types::t_text(), st_p1}
        : ({
        auto [events_p12, dyns_p13, opts_p14, st2_p15, lifted_p16] = run_to_end(fold_job(crate::check::errors::range0(len(holes_p5)), std::tuple{Array<crate::syntax::Range>{}, Int(0ll), Array<Text>{}, st_p1, Array<Nat>{}}, ({
            auto holes_p5_1 = holes_p5;
            auto span_p4_2 = span_p4;
            auto env_p0_3 = env_p0;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>>(std::tuple<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>, Nat>)>>(prism_rtl::rc([=, holes_p5_1 = std::move(holes_p5_1), span_p4_2 = std::move(span_p4_2), env_p0_3 = std::move(env_p0_3)](std::tuple<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto holes_p5_1_4 = holes_p5_1;
                auto span_p4_2_4 = span_p4_2;
                auto env_p0_3_4 = env_p0_3;
                entered(once_job([=, holes_p5_1_4 = std::move(holes_p5_1_4), span_p4_2_4 = std::move(span_p4_2_4), env_p0_3_4 = std::move(env_p0_3_4)]() {
                return ({
                    auto [ev_pf, dy_pg, op_ph, s_pi, li_pj] = p0;
                    auto hi_pk = p1;
                    ({
                    auto x_pl = or_(index(holes_p5_1_4, hi_pk), crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_p4_2_4});
                    call_then(start_infer(env_p0_3_4, s_pi, x_pl), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_17221) {
                    return ({
                        auto [t_p10, s2_p11] = infer_17221;
                        call_then(crate::check::types::start_head_sigil(s2_p11, t_p10), [=](Text head_sigil_17260) {
                        return ({
                            auto head_pm = head_sigil_17260;
                            auto inner_pn = is_time_sigil(head_pm) ? inner_of(s2_p11, t_p10) : t_p10;
                            call_then(crate::check::types::start_head_sigil(s2_p11, inner_pn), [=, head_pm = std::move(head_pm)](Text head_sigil_17364) {
                            return ({
                                auto ih_po = head_sigil_17364;
                                auto plain_t_pp = is_plain_sigil(ih_po) ? inner_of(s2_p11, inner_pn) : inner_pn;
                                auto s3_pq = head_pm == Text::lit("@")
                                    ? crate::check::types::recording::err(s2_p11, Text::lit("blueprint-operand"), prism_rtl::deref(x_pl).span, Text::lit("a text over a blueprint; bind it first"))
                                    : s2_p11;
                                call_then(start_show_want(s3_pq, plain_t_pp, prism_rtl::deref(x_pl).span), [=, ih_po = std::move(ih_po)](crate::check::types::St show_want_17604) {
                                return ({
                                    auto s4_pr = show_want_17604;
                                    auto ev2_ps = head_pm == Text::lit("!")
                                        ? crate::prelude::push(ev_pf, prism_rtl::deref(x_pl).span)
                                        : ev_pf;
                                    auto dy2_pt = head_pm == Text::lit("$") ? dy_pg + Int(1ll) : dy_pg;
                                    auto op2_pu = is_plain_sigil(ih_po) ? crate::check::types::add_text(op_ph, ih_po) : op_ph;
                                    auto li2_pv = is_time_sigil(head_pm) ? crate::prelude::push(li_pj, hi_pk) : li_pj;
                                    (prism_rtl::finished(std::tuple{ev2_ps, dy2_pt, op2_pu, s4_pr, li2_pv}));
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        }));
        })));
        auto st3_p9 = dollar_p3 && (len(events_p12) > Nat(0u))
            ? crate::check::types::recording::err(st2_p15, Text::lit("event-in-text"), or_(index(events_p12, Nat(0u)), span_p4), Text::lit("an event in a dynamic text"))
            : len(events_p12) > Nat(1u)
            ? crate::check::types::recording::err_fix(st2_p15, Text::lit("two-events"), or_(index(events_p12, Nat(1u)), span_p4), Text::lit("two events in one operation"), Text::lit("merge them with `<|`, or hold one first"))
            : st2_p15;
        auto st4_pa = len(opts_p14) > Nat(1u)
            ? crate::check::types::recording::err(st3_p9, Text::lit("optional-and-fault"), span_p4, Text::lit("`?` and `~` in one operation"))
            : st3_p9;
        auto with_opt_pb = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Ty> _v;
            auto&& _m = index(opts_p14, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& o_p17 = prism_rtl::some_of(_m);
                _v.set(crate::check::types::Ty(crate::check::types::Ty::TySig{o_p17, prism_rtl::rc(crate::check::types::t_text())}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::check::types::t_text());
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto layer_pc = (len(events_p12) > Nat(0u)) && (!dollar_p3)
            ? Text::lit("!")
            : (dyns_p13 > Int(0ll)) || dollar_p3 ? Text::lit("$") : Text::lit("");
        auto res_pd = layer_pc == Text::lit("")
            ? with_opt_pb
            : crate::check::types::Ty(crate::check::types::Ty::TySig{layer_pc, prism_rtl::rc(with_opt_pb)});
        auto kind_pe = layer_pc == Text::lit("")
            ? Text::lit("plain")
            : len(lifted_p16) == Nat(0u) ? Text::lit("const") : Text::lit("map");
        std::tuple{res_pd, crate::check::types::recording::note_app(st4_pa, span_p4, Text::lit("text"), kind_pe, layer_pc, lifted_p16, or_(index(opts_p14, Nat(0u)), Text::lit("")), crate::check::types::Col(crate::check::types::Col::CBound{}))};
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferText::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& segs_p2 = this->segs_p2;
    const auto& dollar_p3 = this->dollar_p3;
    const auto& span_p4 = this->span_p4;
    auto holes_p5 = fold(segs_p2, Array<crate::syntax::Expr>{}, [&](const Array<crate::syntax::Expr>& acc_p6, const crate::syntax::TextSeg& sg_p7) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
            if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg_p7)) {
                auto&& x_p8 = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg_p7).a0;
                _v.set(crate::prelude::push(acc_p6, x_p8));
                goto _done;
            }
            {
                _v.set(acc_p6);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return len(holes_p5) == Nat(0u)
        ? prism_rtl::finished(std::tuple{crate::check::types::t_text(), st_p1})
        : ({
        auto dollar_p3_1 = prism_rtl::deref(dollar_p3);
        auto env_p0_2 = env_p0;
        auto span_p4_3 = span_p4;
        auto st_p1_4 = st_p1;
        call_value(fold_job(crate::check::errors::range0(len(holes_p5)), std::tuple{Array<crate::syntax::Range>{}, Int(0ll), Array<Text>{}, st_p1_4, Array<Nat>{}}, ({
        auto holes_p5_5 = holes_p5;
        auto span_p4_3_6 = span_p4_3;
        auto env_p0_2_6 = env_p0_2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>>(std::tuple<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>, Nat>)>>(prism_rtl::rc([=, holes_p5_5 = std::move(holes_p5_5), span_p4_3_6 = std::move(span_p4_3_6), env_p0_2_6 = std::move(env_p0_2_6)](std::tuple<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto holes_p5_5_6 = holes_p5_5;
            auto span_p4_3_6_6 = span_p4_3_6;
            auto env_p0_2_6_6 = env_p0_2_6;
            entered(once_job([=, holes_p5_5_6 = std::move(holes_p5_5_6), span_p4_3_6_6 = std::move(span_p4_3_6_6), env_p0_2_6_6 = std::move(env_p0_2_6_6)]() {
            return ({
                auto [ev_pf, dy_pg, op_ph, s_pi, li_pj] = p0;
                auto hi_pk = p1;
                ({
                auto x_pl = or_(index(holes_p5_5_6, hi_pk), crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_p4_3_6_6});
                call_then(start_infer(env_p0_2_6_6, s_pi, x_pl), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_17221) {
                return ({
                    auto [t_p10, s2_p11] = infer_17221;
                    call_then(crate::check::types::start_head_sigil(s2_p11, t_p10), [=](Text head_sigil_17260) {
                    return ({
                        auto head_pm = head_sigil_17260;
                        auto inner_pn = is_time_sigil(head_pm) ? inner_of(s2_p11, t_p10) : t_p10;
                        call_then(crate::check::types::start_head_sigil(s2_p11, inner_pn), [=, head_pm = std::move(head_pm)](Text head_sigil_17364) {
                        return ({
                            auto ih_po = head_sigil_17364;
                            auto plain_t_pp = is_plain_sigil(ih_po) ? inner_of(s2_p11, inner_pn) : inner_pn;
                            auto s3_pq = head_pm == Text::lit("@")
                                ? crate::check::types::recording::err(s2_p11, Text::lit("blueprint-operand"), prism_rtl::deref(x_pl).span, Text::lit("a text over a blueprint; bind it first"))
                                : s2_p11;
                            call_then(start_show_want(s3_pq, plain_t_pp, prism_rtl::deref(x_pl).span), [=, ih_po = std::move(ih_po)](crate::check::types::St show_want_17604) {
                            return ({
                                auto s4_pr = show_want_17604;
                                auto ev2_ps = head_pm == Text::lit("!")
                                    ? crate::prelude::push(ev_pf, prism_rtl::deref(x_pl).span)
                                    : ev_pf;
                                auto dy2_pt = head_pm == Text::lit("$") ? dy_pg + Int(1ll) : dy_pg;
                                auto op2_pu = is_plain_sigil(ih_po) ? crate::check::types::add_text(op_ph, ih_po) : op_ph;
                                auto li2_pv = is_time_sigil(head_pm) ? crate::prelude::push(li_pj, hi_pk) : li_pj;
                                (prism_rtl::finished(std::tuple{ev2_ps, dy2_pt, op2_pu, s4_pr, li2_pv}));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })), [=, dollar_p3_1 = std::move(dollar_p3_1)](std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>> fold_17045) {
        return ({
            auto [events_p12, dyns_p13, opts_p14, st2_p15, lifted_p16] = fold_17045;
            auto st3_p9 = dollar_p3_1 && (len(events_p12) > Nat(0u))
                ? crate::check::types::recording::err(st2_p15, Text::lit("event-in-text"), or_(index(events_p12, Nat(0u)), span_p4_3), Text::lit("an event in a dynamic text"))
                : len(events_p12) > Nat(1u)
                ? crate::check::types::recording::err_fix(st2_p15, Text::lit("two-events"), or_(index(events_p12, Nat(1u)), span_p4_3), Text::lit("two events in one operation"), Text::lit("merge them with `<|`, or hold one first"))
                : st2_p15;
            auto st4_pa = len(opts_p14) > Nat(1u)
                ? crate::check::types::recording::err(st3_p9, Text::lit("optional-and-fault"), span_p4_3, Text::lit("`?` and `~` in one operation"))
                : st3_p9;
            auto with_opt_pb = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::Ty> _v;
                auto&& _m = index(opts_p14, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& o_p17 = prism_rtl::some_of(_m);
                    _v.set(crate::check::types::Ty(crate::check::types::Ty::TySig{o_p17, prism_rtl::rc(crate::check::types::t_text())}));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::check::types::t_text());
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto layer_pc = (len(events_p12) > Nat(0u)) && (!dollar_p3_1)
                ? Text::lit("!")
                : (dyns_p13 > Int(0ll)) || dollar_p3_1 ? Text::lit("$") : Text::lit("");
            auto res_pd = layer_pc == Text::lit("")
                ? with_opt_pb
                : crate::check::types::Ty(crate::check::types::Ty::TySig{layer_pc, prism_rtl::rc(with_opt_pb)});
            auto kind_pe = layer_pc == Text::lit("")
                ? Text::lit("plain")
                : len(lifted_p16) == Nat(0u) ? Text::lit("const") : Text::lit("map");
            (prism_rtl::finished(std::tuple{res_pd, crate::check::types::recording::note_app(st4_pa, span_p4_3, Text::lit("text"), kind_pe, layer_pc, lifted_p16, or_(index(opts_p14, Nat(0u)), Text::lit("")), crate::check::types::Col(crate::check::types::Col::CBound{}))}));
        });
    });
    });
}


/// `Start InferText, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_text(Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::TextSeg> segs_p2, bool dollar_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<InferText>(env_p0, st_p1, segs_p2, dollar_p3, span_p4);
}


/// ShowWant: unbounded fn St, Ty, Range -> St
crate::check::types::St show_want(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1, const crate::syntax::Range& span_p2) {
    auto&& _m = crate::check::types::recording::walk(st_p0, t_p1);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m18917_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m18917_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m18917_0_0 == Text::lit("Text")) {
            if (m18917_0_1.size() == 0u) {
                return st_p0;
            }
        }
    }
    {
        auto&& other_p3 = _m;
        return add_want(st_p0, Text::lit("Prelude.Show"), other_p3, span_p2);
    }
}


prism_rtl::Turn<crate::check::types::St> ShowWant::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    const auto& span_p2 = this->span_p2;
    auto span_p2_1 = span_p2;
    auto st_p0_2 = st_p0;
    auto t_p1_3 = t_p1;
    return call_then(crate::check::types::recording::start_walk(st_p0_2, t_p1_3), [=](crate::check::types::Ty walk_18923) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_18923) && ({
            auto&& m18917_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_18923).a0;
            auto&& m18917_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_18923).a1;
            (m18917_0_0 == Text::lit("Text")) && (m18917_0_1.size() == 0u);
        }) ? ({
            auto&& m18917_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_18923).a0;
            auto&& m18917_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_18923).a1;
            prism_rtl::finished(st_p0_2);
        })
            : ({
            auto&& other_p3 = walk_18923;
            prism_rtl::finished(add_want(st_p0_2, Text::lit("Prelude.Show"), other_p3, span_p2_1));
        });
        });
    });
}


/// `Start ShowWant, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_show_want(crate::check::types::St st_p0, crate::check::types::Ty t_p1, crate::syntax::Range span_p2) {
    return prism_rtl::make_rc<ShowWant>(st_p0, t_p1, span_p2);
}

}  // namespace crate::check::expr
