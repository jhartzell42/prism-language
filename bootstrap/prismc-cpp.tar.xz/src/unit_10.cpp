// The modules `Check.Errors`, `Check.Expr`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/errors/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/expr/module.hpp>
#include <check/env/module.hpp>
#include <check/types/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Errors`, from `target/bootstrap/cpp-src/prismc/check/errors.prism`.
namespace crate::check::errors {

void CDiag::show(Printer& p) const {
    p.record("CDiag", {{"code", code}, {"file", file}, {"span", span}, {"message", message}, {"fix", fix}});
}

Pod CDiag::to_pod() const {
    return Pod::record("CDiag", {{"code", prism_rtl::to_pod(code)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}, {"message", prism_rtl::to_pod(message)}, {"fix", prism_rtl::to_pod(fix)}});
}

Result<CDiag> CDiag::from_pod(const Pod& whole) {
    return CDiag{.code = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "code")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .message = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "message")))), .fix = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "fix"))))};
}


bool Src::operator==(const Src& o) const { return path_ == o.path_ && text == o.text && starts == o.starts && segs == o.segs; }

void Src::show(Printer& p) const {
    p.record("Src", {{"path", path_}, {"text", text}, {"starts", starts}, {"segs", segs}});
}

Pod Src::to_pod() const {
    return Pod::record("Src", {{"path", prism_rtl::to_pod(path_)}, {"text", prism_rtl::to_pod(text)}, {"starts", prism_rtl::to_pod(starts)}, {"segs", prism_rtl::to_pod(segs)}});
}

Result<Src> Src::from_pod(const Pod& whole) {
    return Src{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .text = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "text")))), .starts = TRY(prism_rtl::from_pod<Array<Nat>>(TRY(crate::prelude::field(whole, "starts")))), .segs = TRY(prism_rtl::from_pod<Array<SrcSeg>>(TRY(crate::prelude::field(whole, "segs"))))};
}


void SrcSeg::show(Printer& p) const {
    p.record("SrcSeg", {{"path", path_}, {"start", start}, {"line", line}, {"role", role}});
}

Pod SrcSeg::to_pod() const {
    return Pod::record("SrcSeg", {{"path", prism_rtl::to_pod(path_)}, {"start", prism_rtl::to_pod(start)}, {"line", prism_rtl::to_pod(line)}, {"role", prism_rtl::to_pod(role)}});
}

Result<SrcSeg> SrcSeg::from_pod(const Pod& whole) {
    return SrcSeg{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .start = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "start")))), .line = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "line")))), .role = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "role"))))};
}


/// MkSrc: fn Text, Text -> Src
Src mk_src(const Text& path_, const Text& text_) {
    return Src{.path_ = path_, .text = text_, .starts = cline_starts(text_), .segs = Array(std::vector{SrcSeg{.path_ = path_, .start = Nat(0u), .line = Nat(0u), .role = Text::lit("loose")}})};
}


/// MkJoinedSrc: fn [((Text, Text, Text))] -> Src
Src mk_joined_src(const Array<std::tuple<Text, Text, Text>>& files) {
    auto text_ = crate::syntax::lexer::chars::join(each(files, [&](const std::tuple<Text, Text, Text>& _p0) {
        auto&& t = std::get<1>(_p0);
        return t;
    }), Text::lit("\n"));
    auto starts = cline_starts(text_);
    auto&& _segs = fold(files, std::tuple{Array<SrcSeg>{}, Nat(0u)}, [&](const std::tuple<Array<SrcSeg>, Nat>& _p0, const std::tuple<Text, Text, Text>& _p1) {
        auto&& acc = std::get<0>(_p0);
        auto&& at_ = std::get<1>(_p0);
        auto&& path_ = std::get<0>(_p1);
        auto&& t = std::get<1>(_p1);
        auto&& role = std::get<2>(_p1);
        return std::tuple{crate::prelude::push(acc, SrcSeg{.path_ = path_, .start = at_, .line = cline_of(starts, at_), .role = role}), (at_ + len_text(t)) + Nat(1u)};
    });
    auto&& segs = std::get<0>(_segs);
    auto first_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(files, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& path_ = std::get<0>(prism_rtl::some_of(_m));
            _v.set(path_);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return Src{.path_ = first_, .text = text_, .starts = starts, .segs = segs};
}


/// SegAt: fn Src, Nat -> SrcSeg
SrcSeg seg_at(const Src& src, const Nat& offset) {
    return fold(src.segs, or_(index(src.segs, Nat(0u)), SrcSeg{.path_ = src.path_, .start = Nat(0u), .line = Nat(0u), .role = Text::lit("loose")}), [&](const SrcSeg& found, const SrcSeg& s) { return prism_rtl::val(s).start <= offset ? s : found; });
}


/// SrcPlace: fn Src, Nat -> Text
Text src_place(const Src& src, const Nat& offset) {
    auto seg = seg_at(src, offset);
    return prism_rtl::cat(seg->path_, ":", or_(cline_of(src.starts, offset).checked_sub(prism_rtl::val(seg).line), Nat(0u)) + Nat(1u));
}


/// Diag0: fn Text, Nat, Range, Text -> CDiag
CDiag diag0(const Text& code, const Nat& file, const crate::syntax::Range& span, const Text& message) {
    return CDiag{.code = code, .file = file, .span = span, .message = message, .fix = Text::lit("")};
}


/// DiagFix: fn Text, Nat, Range, Text, Text -> CDiag
CDiag diag_fix(const Text& code, const Nat& file, const crate::syntax::Range& span, const Text& message, const Text& fix) {
    return CDiag{.code = code, .file = file, .span = span, .message = message, .fix = fix};
}


/// CLineStarts: fn Text -> [Nat]
Array<Nat> cline_starts(const Text& text_) {
    auto&& _starts = fold(split_on(text_, Text::lit("\n")), std::tuple{Array<Nat>{}, Nat(0u)}, [&](const std::tuple<Array<Nat>, Nat>& _p0, const Text& line) {
        auto&& acc = std::get<0>(_p0);
        auto&& at_ = std::get<1>(_p0);
        return std::tuple{crate::prelude::push(acc, at_), (at_ + len_text(line)) + Nat(1u)};
    });
    auto&& starts = std::get<0>(_starts);
    return starts;
}


/// CLineOf: fn [Nat], Nat -> Nat
Nat cline_of(const Array<Nat>& starts, const Nat& offset) {
    return crate::syntax::lexer::chars::dec(fold(starts, Nat(0u), [&](const Nat& n, const Nat& s) { return s <= offset ? n + Nat(1u) : n; }));
}


/// LineText: fn Src, Nat -> Text
Text line_text(const Src& src, const Nat& n) {
    auto from = or_(index(src.starts, n), Nat(0u));
    auto to = or_(index(src.starts, n + Nat(1u)), len_text(src.text) + Nat(1u));
    return crate::syntax::lexer::chars::between(src.text, from, crate::prelude::max(from, or_(to.checked_sub(Nat(1u)), Nat(0u))));
}


/// SpanText: fn Src, Range -> Text
Text span_text(const Src& src, const crate::syntax::Range& r) {
    return crate::syntax::lexer::chars::between(src.text, r.start, crate::prelude::max(r.start, r.end));
}


/// Repeat: fn Text, Nat -> Text
Text repeat(const Text& t, const Nat& n) {
    return concat(fold(range0(n), Array<Text>{}, [&](const Array<Text>& acc, const Nat& _p1) { return crate::prelude::push(acc, t); }));
}


/// Range0: fn Nat -> [Nat]
Array<Nat> range0(const Nat& n) {
    Array<Nat> this_ = Array<Nat>{};
    Nat i = Nat(0u);
    Nat left = n;
    while (true) {
        auto&& _m = left.checked_sub(Nat(1u));
        if (!(prism_rtl::is_some(_m))) break;
        auto&& m = prism_rtl::some_of(_m);
        left = m;
        this_ = crate::prelude::push(this_, i);
        i = i + Nat(1u);
    }
    return this_;
}


/// RenderCDiag: fn [Src], CDiag -> Text
Text render_cdiag(const Array<Src>& srcs, const CDiag& d) {
    auto&& _m = index(srcs, d.file);
    if (prism_rtl::is_none(_m)) {
        return prism_rtl::cat("?: ", severity(d), "[", d.code, "]: ", d.message, "\n");
    }
    if (prism_rtl::is_some(_m)) {
        auto&& src = prism_rtl::some_of(_m);
        auto line = cline_of(prism_rtl::val(src).starts, prism_rtl::val(d.span).start);
        auto col = crate::syntax::lexer::chars::column_of(src->text, or_(index(prism_rtl::val(src).starts, line), Nat(0u)), prism_rtl::val(d.span).start);
        auto text_ = line_text(src, line);
        auto width = crate::prelude::max(Nat(1u), crate::prelude::min(crate::syntax::lexer::chars::count_chars(span_text(src, d.span)), or_(crate::syntax::lexer::chars::count_chars(text_).checked_sub(col), Nat(1u))));
        auto carets = prism_rtl::cat("    ", repeat(Text::lit(" "), col), repeat(Text::lit("^"), width));
        auto fix_1 = d.fix == Text::lit("")
            ? Text::lit("")
            : prism_rtl::cat("  fix: ", d.fix, "\n");
        return prism_rtl::cat(src_place(src, prism_rtl::val(d.span).start), ": ", severity(d), "[", d.code, "]: ", d.message, "\n    ", text_, "\n", carets, "\n", fix_1);
    }
    prism_rtl::unreachable("no arm matched");
}


/// Severity: fn CDiag -> Text
Text severity(const CDiag& d) {
    return is_warning(d) ? Text::lit("warning") : Text::lit("error");
}


/// IsWarning: fn CDiag -> Bool
bool is_warning(const CDiag& d) {
    return d.code == Text::lit("unused");
}


/// SortDiags: fn [CDiag] -> [CDiag]
Array<CDiag> sort_diags(const Array<CDiag>& ds) {
    return fold(ds, Array<CDiag>{}, [&](const Array<CDiag>& acc, const CDiag& d) { return insert_sorted(acc, d); });
}


/// InsertSorted: fn [CDiag], CDiag -> [CDiag]
Array<CDiag> insert_sorted(const Array<CDiag>& acc, const CDiag& d) {
    auto before_ = filter(acc, [&](const CDiag& x) { return !diag_before2(d, x); });
    auto after_ = filter(acc, [&](const CDiag& x) { return diag_before2(d, x); });
    return any_is(acc, d) ? acc : append(crate::prelude::push(before_, d), after_);
}


/// AnyIs: fn [CDiag], CDiag -> Bool
bool any_is(const Array<CDiag>& xs, const CDiag& d) {
    return fold(xs, false, [&](const bool& seen, const CDiag& x) { return prism_rtl::val(seen) || (x == d); });
}


/// DiagBefore2: fn CDiag, CDiag -> Bool
bool diag_before2(const CDiag& a, const CDiag& b) {
    return a.file != b.file
        ? a.file < b.file
        : prism_rtl::val(a.span).start < prism_rtl::val(b.span).start;
}


/// CountWord: fn Nat -> Text
Text count_word(const Nat& n0) {
    {
        auto&& c0_0 = n0;
        if (c0_0 == Nat(0u)) {
            return Text::lit("no");
        }
    }
    {
        auto&& c1_0 = n0;
        if (c1_0 == Nat(1u)) {
            return Text::lit("one");
        }
    }
    {
        auto&& c2_0 = n0;
        if (c2_0 == Nat(2u)) {
            return Text::lit("two");
        }
    }
    {
        auto&& c3_0 = n0;
        if (c3_0 == Nat(3u)) {
            return Text::lit("three");
        }
    }
    {
        auto&& c4_0 = n0;
        if (c4_0 == Nat(4u)) {
            return Text::lit("four");
        }
    }
    {
        auto&& n = n0;
        return show_text(n);
    }
}

}  // namespace crate::check::errors


// The module `Check.Expr`, from `target/bootstrap/cpp-src/prismc/check/expr/mod.prism`.
namespace crate::check::expr {

bool Env::operator==(const Env& o) const { return g == o.g && home == o.home && file == o.file && src == o.src && locals == o.locals && scope == o.scope && givens == o.givens && mark == o.mark && in_update == o.in_update && def_name == o.def_name && refine == o.refine && pending == o.pending; }

void Env::show(Printer& p) const {
    p.record("Env", {{"g", g}, {"home", home}, {"file", file}, {"src", src}, {"locals", locals}, {"scope", scope}, {"givens", givens}, {"mark", mark}, {"in_update", in_update}, {"def_name", def_name}, {"refine", refine}, {"pending", pending}});
}

Pod Env::to_pod() const {
    return Pod::record("Env", {{"g", prism_rtl::to_pod(g)}, {"home", prism_rtl::to_pod(home)}, {"file", prism_rtl::to_pod(file)}, {"src", prism_rtl::to_pod(src)}, {"locals", prism_rtl::to_pod(locals)}, {"scope", prism_rtl::to_pod(scope)}, {"givens", prism_rtl::to_pod(givens)}, {"mark", prism_rtl::to_pod(mark)}, {"in_update", prism_rtl::to_pod(in_update)}, {"def_name", prism_rtl::to_pod(def_name)}, {"refine", prism_rtl::to_pod(refine)}, {"pending", prism_rtl::to_pod(pending)}});
}

Result<Env> Env::from_pod(const Pod& whole) {
    return Env{.g = TRY(prism_rtl::from_pod<crate::check::env::G>(TRY(crate::prelude::field(whole, "g")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .src = TRY(prism_rtl::from_pod<crate::check::errors::Src>(TRY(crate::prelude::field(whole, "src")))), .locals = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Scheme>>(TRY(crate::prelude::field(whole, "locals")))), .scope = TRY(prism_rtl::from_pod<crate::check::types::Rw>(TRY(crate::prelude::field(whole, "scope")))), .givens = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "givens")))), .mark = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "mark")))), .in_update = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "in_update")))), .def_name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "def_name")))), .refine = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "refine")))), .pending = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "pending"))))};
}


/// WithLocal: fn Env, Text, Scheme -> Env
Env with_local(const Env& env, const Text& name, const crate::check::types::Scheme& sc) {
    Env this_ = env;
    this_.locals = insert(this_.locals, name, sc);
    return this_;
}


/// SrcText: fn Env, Range -> Text
Text src_text(const Env& env, const crate::syntax::Range& r) {
    return crate::check::errors::span_text(env.src, r);
}


/// IsComparison: fn Text -> Bool
bool is_comparison(const Text& n) {
    return crate::check::types::has_text(Array(std::vector{Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit("<="), Text::lit(">"), Text::lit(">="), Text::lit("Compare"), Text::lit("?"), Text::lit("~"), Text::lit("$")}), n);
}


/// HasTimeMark: fn Text -> Bool
bool has_time_mark(const Text& marks) {
    return crate::syntax::lexer::chars::contains(marks, Text::lit("$")) || crate::syntax::lexer::chars::contains(marks, Text::lit("!"));
}


/// IsTimeSigil: fn Text -> Bool
bool is_time_sigil(const Text& s) {
    return (s == Text::lit("$")) || (s == Text::lit("!"));
}


/// IsPlainSigil: fn Text -> Bool
bool is_plain_sigil(const Text& s) {
    return (s == Text::lit("?")) || (s == Text::lit("~"));
}


/// InnerOf: unbounded fn St, Ty -> Ty
crate::check::types::Ty inner_of(const crate::check::types::St& st, const crate::check::types::Ty& t) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return prism_rtl::val(i);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
        return prism_rtl::val(i);
    }
    {
        auto&& other = _m;
        return other;
    }
}


prism_rtl::Turn<crate::check::types::Ty> InnerOf::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(crate::check::types::recording::start_walk(st_1, t_2), [=](crate::check::types::Ty walk_3049) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TySig>(walk_3049) ? ({
            auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(walk_3049).a1;
            prism_rtl::finished(prism_rtl::val(i));
        })
            : prism_rtl::is<crate::check::types::Ty::TyAt>(walk_3049) ? ({
            auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_3049).a0;
            prism_rtl::finished(prism_rtl::val(i));
        })
            : ({
            auto&& other = walk_3049;
            prism_rtl::finished(other);
        });
        });
    });
}


/// `Start InnerOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_inner_of(crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<InnerOf>(st, t);
}


/// IsLambda: fn Expr -> Bool
bool is_lambda(const crate::syntax::Expr& e) {
    auto&& _m = prism_rtl::val(e.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicField>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_lambda(prism_rtl::val(prism_rtl::val(x)));
    }
    {
        return false;
    }
}


/// Infer: unbounded fn Env, St, Expr -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer(const Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e) {
    auto [t, st2] = infer_kind(env, st, e);
    return std::tuple{t, crate::check::types::recording::note_ty(st2, e.span, t)};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> Infer::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    auto e_1 = e;
    auto env_2 = env;
    auto st_3 = st;
    return call_then(start_infer_kind(env_2, st_3, e_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_kind_3601) {
        return ({
            auto [t, st2] = infer_kind_3601;
            (prism_rtl::finished(std::tuple{t, crate::check::types::recording::note_ty(st2, prism_rtl::val(e_1).span, t)}));
        });
    });
}


/// `Start Infer, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer(Env env, crate::check::types::St st, crate::syntax::Expr e) {
    return prism_rtl::make_rc<Infer>(env, st, e);
}


/// InferKind: unbounded fn Env, St, Expr -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_kind(const Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e) {
    auto&& _m = prism_rtl::val(e.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return infer_name(env, st, n, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        return infer_lit(env, st, l, false, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnit>(_m)) {
        auto&& marks = prism_rtl::as<crate::syntax::ExprKind::EUnit>(_m).a0;
        return std::tuple{crate::check::types::with_marks(marks, crate::check::types::t_unit(), env.scope), st};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENil>(_m)) {
        auto&& marks = prism_rtl::as<crate::syntax::ExprKind::ENil>(_m).a0;
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        return std::tuple{crate::check::types::with_marks(marks, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_)}), env.scope), st2};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBound>(_m)) {
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EBound>(_m).a0;
        return infer_bound(env, st, b, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        auto [ts, st2] = infer_all(env, st, es);
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyTuple{ts}), st2};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        return crate::check::expr::operators::infer_array(env, st, es, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& entries = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        return crate::check::expr::operators::infer_map(env, st, entries, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return infer(env, st, prism_rtl::val(prism_rtl::val(x)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& callee = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return crate::check::expr::calls::infer_call(env, st, prism_rtl::val(prism_rtl::val(callee)), args, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& op = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& lhs = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& rhs = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return crate::check::expr::operators::infer_binary(env, st, op, prism_rtl::val(prism_rtl::val(lhs)), prism_rtl::val(prism_rtl::val(rhs)), e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& op = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return crate::check::expr::operators::infer_unary(env, st, op, prism_rtl::val(prism_rtl::val(x)), e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), e.span, Text::lit("this checker does not implement suffixed operators"))};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return crate::check::expr::operators::infer_free_sigil(env, st, s, prism_rtl::val(prism_rtl::val(x)), e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& recv = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& sigils = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a1;
        auto&& name = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        return crate::check::expr::operators::infer_field(env, st, prism_rtl::val(prism_rtl::val(recv)), sigils, name, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& recv = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& idx = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return crate::check::expr::operators::infer_index(env, st, prism_rtl::val(prism_rtl::val(recv)), prism_rtl::val(prism_rtl::val(idx)), e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicField>(_m)) {
        return crate::check::expr::calls::infer_lambda(env, st, e, std::optional<crate::check::types::Ty>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
        return crate::check::expr::calls::infer_lambda(env, st, e, std::optional<crate::check::types::Ty>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& recv = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& m = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return crate::check::expr::calls::infer_call(env, st, crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{m})), .span = prism_rtl::val(m).span}, append(Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = prism_rtl::val(prism_rtl::val(recv)), .span = prism_rtl::val(recv).span}}), args), e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& target = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        return crate::check::expr::calls::infer_call(env, st, e, Array<crate::syntax::Arg>{}, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        auto&& ty = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a1;
        auto&& checked = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a2;
        return prism_rtl::val(checked)
            ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), e.span, Text::lit("this checker does not implement non-empty arrays"))}
            : ({
            auto cx_ = env_cx(env);
            auto [t, st2] = crate::check::env::reading::conv_type(cx_, st, ty);
            auto st3 = crate::check::expr::check(env, st2, prism_rtl::val(prism_rtl::val(x)), t);
            std::tuple{t, st3};
        });
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), e.span, Text::lit("this checker does not implement non-empty arrays"))};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAbsent>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), e.span, Text::lit("this checker does not implement sparse tuples"))};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERest>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        return crate::check::expr::calls::infer_lambda(env, st, e, std::optional<crate::check::types::Ty>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        return crate::check::expr::lifting::infer_if(env, st, prism_rtl::val(prism_rtl::val(c)), then_b, else_b_opt, e.span, std::optional<crate::check::types::Ty>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return crate::check::expr::lifting::infer_match(env, st, prism_rtl::val(prism_rtl::val(scrut)), arms, e.span, std::optional<crate::check::types::Ty>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        return crate::check::blocks::structure::infer_rebuild(env, st, prism_rtl::val(prism_rtl::val(scrut)), body, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
        auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        return crate::check::blocks::structure::infer_for(env, st, binders_opt, prism_rtl::val(prism_rtl::val(source)), body, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        return crate::check::blocks::structure::infer_given(env, st, b, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
        auto&& target = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        return crate::check::blocks::borrows::infer_update(env, st, prism_rtl::val(prism_rtl::val(target)), body, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        auto [t, st2] = crate::check::blocks::infer_widget_block(env, st, b);
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t), env.scope}), st2};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), e.span, Text::lit("this checker does not implement `T monad:` blocks"))};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        return crate::check::expr::lets::infer_template(env, st, t);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        auto [t, st2] = infer(env, st, prism_rtl::val(prism_rtl::val(x)));
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAny{Array<Text>{}}), st2};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELens>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), e.span, Text::lit("this checker does not implement named lenses and `Over`"))};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EError>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferKind::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    return ({
        auto&& _m = prism_rtl::val(prism_rtl::val(e).kind);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferName(env, st, n, prism_rtl::val(e).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferLit(env, st, l, false, prism_rtl::val(e).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUnit>(_m) ? ({
        auto&& marks = prism_rtl::as<crate::syntax::ExprKind::EUnit>(_m).a0;
        prism_rtl::finished(std::tuple{crate::check::types::with_marks(marks, crate::check::types::t_unit(), prism_rtl::val(env).scope), st});
    })
        : prism_rtl::is<crate::syntax::ExprKind::ENil>(_m) ? ({
        auto&& marks = prism_rtl::as<crate::syntax::ExprKind::ENil>(_m).a0;
        ({
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        (prism_rtl::finished(std::tuple{crate::check::types::with_marks(marks, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_)}), prism_rtl::val(env).scope), st2}));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBound>(_m) ? ({
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EBound>(_m).a0;
        prism_rtl::finished(infer_bound(env, st, b, prism_rtl::val(e).span));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m) ? ({
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        ({
        auto env_1 = env;
        auto es_2 = es;
        auto st_3 = st;
        call_then(start_infer_all(env_1, st_3, es_2), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> infer_all_4111) {
        return ({
            auto [ts, st2] = infer_all_4111;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyTuple{ts}), st2}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) ? ({
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::operators::InferArray(env, st, es, prism_rtl::val(e).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMap>(_m) ? ({
        auto&& entries = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::operators::InferMap(env, st, entries, prism_rtl::val(e).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Infer(env, st, prism_rtl::val(prism_rtl::val(x)))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& callee = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::InferCall(env, st, prism_rtl::val(prism_rtl::val(callee)), args, prism_rtl::val(e).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) ? ({
        auto&& op = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& lhs = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& rhs = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::operators::InferBinary(env, st, op, prism_rtl::val(prism_rtl::val(lhs)), prism_rtl::val(prism_rtl::val(rhs)), prism_rtl::val(e).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) ? ({
        auto&& op = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::operators::InferUnary(env, st, op, prism_rtl::val(prism_rtl::val(x)), prism_rtl::val(e).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), prism_rtl::val(e).span, Text::lit("this checker does not implement suffixed operators"))})
        : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::operators::InferFreeSigil(env, st, s, prism_rtl::val(prism_rtl::val(x)), prism_rtl::val(e).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& recv = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& sigils = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a1;
        auto&& name = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::operators::InferField(env, st, prism_rtl::val(prism_rtl::val(recv)), sigils, name, prism_rtl::val(e).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& recv = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& idx = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::operators::InferIndex(env, st, prism_rtl::val(prism_rtl::val(recv)), prism_rtl::val(prism_rtl::val(idx)), prism_rtl::val(e).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETopicField>(_m) ? prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::InferLambda(env, st, e, std::optional<crate::check::types::Ty>{})))
        : prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m) ? prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::InferLambda(env, st, e, std::optional<crate::check::types::Ty>{})))
        : prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m) ? ({
        auto&& recv = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& m = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::InferCall(env, st, crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{m})), .span = prism_rtl::val(m).span}, append(Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = prism_rtl::val(prism_rtl::val(recv)), .span = prism_rtl::val(recv).span}}), args), prism_rtl::val(e).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m) ? ({
        auto&& target = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::InferCall(env, st, e, Array<crate::syntax::Arg>{}, prism_rtl::val(e).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECast>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        auto&& ty = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a1;
        auto&& checked = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a2;
        prism_rtl::val(checked)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), prism_rtl::val(e).span, Text::lit("this checker does not implement non-empty arrays"))})
        : ({
        auto cx_ = env_cx(env);
        auto env_1 = env;
        auto st_2 = st;
        auto ty_3 = ty;
        auto x_4 = prism_rtl::val(prism_rtl::val(x));
        call_then(crate::check::env::reading::start_conv_type(cx_, st_2, ty_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_5364) {
        return ({
            auto [t, st2] = conv_type_5364;
            call_then(start_check(env_1, st2, x_4, t), [=](crate::check::types::St check_5406) {
            return ({
                auto st3 = check_5406;
                (prism_rtl::finished(std::tuple{t, st3}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), prism_rtl::val(e).span, Text::lit("this checker does not implement non-empty arrays"))})
        : prism_rtl::is<crate::syntax::ExprKind::EAbsent>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), prism_rtl::val(e).span, Text::lit("this checker does not implement sparse tuples"))})
        : prism_rtl::is<crate::syntax::ExprKind::ERest>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st})
        : prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::InferLambda(env, st, e, std::optional<crate::check::types::Ty>{})))
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::lifting::InferIf(env, st, prism_rtl::val(prism_rtl::val(c)), then_b, else_b_opt, prism_rtl::val(e).span, std::optional<crate::check::types::Ty>{})));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::lifting::InferMatch(env, st, prism_rtl::val(prism_rtl::val(scrut)), arms, prism_rtl::val(e).span, std::optional<crate::check::types::Ty>{})));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m) ? ({
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::blocks::structure::InferRebuild(env, st, prism_rtl::val(prism_rtl::val(scrut)), body, prism_rtl::val(e).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        prism_rtl::more(prism_rtl::rc(crate::check::blocks::structure::InferFor(env, st, binders_opt, prism_rtl::val(prism_rtl::val(source)), body, prism_rtl::val(e).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m) ? ({
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::blocks::structure::InferGiven(env, st, b, prism_rtl::val(e).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m) ? ({
        auto&& target = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::blocks::borrows::InferUpdate(env, st, prism_rtl::val(prism_rtl::val(target)), body, prism_rtl::val(e).span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m) ? ({
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        ({
        auto b_1 = b;
        auto env_2 = env;
        auto st_3 = st;
        call_then(crate::check::blocks::start_infer_widget_block(env_2, st_3, b_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block_6202) {
        return ({
            auto [t, st2] = infer_widget_block_6202;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t), prism_rtl::val(env_2).scope}), st2}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), prism_rtl::val(e).span, Text::lit("this checker does not implement `T monad:` blocks"))})
        : prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::lets::InferTemplate(env, st, t)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EAny>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        ({
        auto env_1 = env;
        auto st_2 = st;
        auto x_3 = prism_rtl::val(prism_rtl::val(x));
        call_then(start_infer(env_1, st_2, x_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_6469) {
        return ({
            auto [t, st2] = infer_6469;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAny{Array<Text>{}}), st2}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::ELens>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), prism_rtl::val(e).span, Text::lit("this checker does not implement named lenses and `Over`"))})
        : prism_rtl::is<crate::syntax::ExprKind::EError>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_kind(Env env, crate::check::types::St st, crate::syntax::Expr e) {
    return prism_rtl::make_rc<InferKind>(env, st, e);
}


/// InferAll: unbounded fn Env, St, [Expr] -> (([Ty], St))
std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> infer_all(const Env& env, const crate::check::types::St& st, const Array<crate::syntax::Expr>& es) {
    return run_to_end(fold_job(es, std::tuple{Array<crate::check::types::Ty>{}, st}, ({
        auto env_1 = env;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_2 = env_1;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto x = p1;
                call_then(start_infer(env_1_2, s, x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_6802) {
                return ({
                    auto [t, s2] = infer_6802;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, t), s2}));
                });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> InferAll::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& es = this->es;
    return fold_job(es, std::tuple{Array<crate::check::types::Ty>{}, st}, ({
        auto env_1 = env;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_2 = env_1;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto x = p1;
                call_then(start_infer(env_1_2, s, x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_6802) {
                return ({
                    auto [t, s2] = infer_6802;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, t), s2}));
                });
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start InferAll, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> start_infer_all(Env env, crate::check::types::St st, Array<crate::syntax::Expr> es) {
    return prism_rtl::make_rc<InferAll>(env, st, es);
}


/// Check: unbounded fn Env, St, Expr, Ty -> St
crate::check::types::St check(const Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e, const crate::check::types::Ty& expected) {
    auto&& _m = prism_rtl::val(e.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        auto [t, st2] = crate::check::expr::calls::infer_lambda(env, st, e, std::optional(expected));
        return crate::check::types::unify::unify(crate::check::types::recording::note_ty(st2, e.span, t), expected, t, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return crate::check::types::recording::note_ty(crate::check::expr::check(env, st, prism_rtl::val(prism_rtl::val(x)), expected), e.span, expected);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        auto [t, st2] = crate::check::expr::lifting::infer_match(env, st, prism_rtl::val(prism_rtl::val(scrut)), arms, e.span, std::optional(expected));
        return crate::check::types::unify::unify(crate::check::types::recording::note_ty(st2, e.span, t), expected, t, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        auto [t, st2] = crate::check::expr::lifting::infer_if(env, st, prism_rtl::val(prism_rtl::val(c)), then_b, else_b_opt, e.span, std::optional(expected));
        return crate::check::types::unify::unify(crate::check::types::recording::note_ty(st2, e.span, t), expected, t, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        return crate::check::types::recording::note_ty(check_any(env, st, prism_rtl::val(prism_rtl::val(x)), expected, e.span), e.span, expected);
    }
    {
        auto [t, st2] = infer(env, st, e);
        return crate::check::types::unify::unify(st2, expected, t, e.span);
    }
}


prism_rtl::Turn<crate::check::types::St> Check::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    const auto& expected = this->expected;
    return ({
        auto&& _m = prism_rtl::val(prism_rtl::val(e).kind);
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto e_1 = e;
        auto env_2 = env;
        auto expected_3 = expected;
        auto st_4 = st;
        call_then(crate::check::expr::calls::start_infer_lambda(env_2, st_4, e_1, std::optional(expected_3)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lambda_7111) {
        return ({
            auto [t, st2] = infer_lambda_7111;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(crate::check::types::recording::note_ty(st2, prism_rtl::val(e_1).span, t), expected_3, t, prism_rtl::val(e_1).span))));
        });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        ({
        auto e_1 = e;
        auto env_2 = env;
        auto expected_3 = expected;
        auto st_4 = st;
        auto x_5 = prism_rtl::val(prism_rtl::val(x));
        call_then(start_check(env_2, st_4, x_5, expected_3), [=](crate::check::types::St check_7229) { return prism_rtl::finished(crate::check::types::recording::note_ty(check_7229, prism_rtl::val(e_1).span, expected_3)); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        ({
        auto arms_1 = arms;
        auto e_2 = e;
        auto env_3 = env;
        auto expected_4 = expected;
        auto scrut_5 = prism_rtl::val(prism_rtl::val(scrut));
        auto st_6 = st;
        call_then(crate::check::expr::lifting::start_infer_match(env_3, st_6, scrut_5, arms_1, prism_rtl::val(e_2).span, std::optional(expected_4)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_match_7324) {
        return ({
            auto [t, st2] = infer_match_7324;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(crate::check::types::recording::note_ty(st2, prism_rtl::val(e_2).span, t), expected_4, t, prism_rtl::val(e_2).span))));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        ({
        auto else_b_opt_1 = else_b_opt;
        auto c_2 = prism_rtl::val(prism_rtl::val(c));
        auto e_3 = e;
        auto env_4 = env;
        auto expected_5 = expected;
        auto st_6 = st;
        auto then_b_7 = then_b;
        call_then(crate::check::expr::lifting::start_infer_if(env_4, st_6, c_2, then_b_7, else_b_opt_1, prism_rtl::val(e_3).span, std::optional(expected_5)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_if_7488) {
        return ({
            auto [t, st2] = infer_if_7488;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(crate::check::types::recording::note_ty(st2, prism_rtl::val(e_3).span, t), expected_5, t, prism_rtl::val(e_3).span))));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EAny>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        ({
        auto e_1 = e;
        auto env_2 = env;
        auto expected_3 = expected;
        auto st_4 = st;
        auto x_5 = prism_rtl::val(prism_rtl::val(x));
        call_then(start_check_any(env_2, st_4, x_5, expected_3, prism_rtl::val(e_1).span), [=](crate::check::types::St check_any_7623) { return prism_rtl::finished(crate::check::types::recording::note_ty(check_any_7623, prism_rtl::val(e_1).span, expected_3)); });
    });
    })
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto expected_3 = expected;
        auto st_4 = st;
        call_then(start_infer(env_2, st_4, e_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_7720) {
        return ({
            auto [t, st2] = infer_7720;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st2, expected_3, t, prism_rtl::val(e_1).span))));
        });
    });
    });
    });
}


/// `Start Check, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check(Env env, crate::check::types::St st, crate::syntax::Expr e, crate::check::types::Ty expected) {
    return prism_rtl::make_rc<Check>(env, st, e, expected);
}


/// CheckAny: unbounded fn Env, St, Expr, Ty, Range -> St
crate::check::types::St check_any(const Env& env, const crate::check::types::St& st, const crate::syntax::Expr& x, const crate::check::types::Ty& expected, const crate::syntax::Range& span) {
    auto&& _m = crate::check::types::recording::walk(st, expected);
    if (prism_rtl::is<crate::check::types::Ty::TyAny>(_m)) {
        auto&& trs = prism_rtl::as<crate::check::types::Ty::TyAny>(_m).a0;
        auto [t, st2] = infer(env, st, x);
        return fold(trs, st2, [&](const crate::check::types::St& s, const Text& tr) { return add_want(s, tr, t, span); });
    }
    {
        auto&& other = _m;
        auto [t, st2] = infer(env, st, x);
        return crate::check::types::unify::unify(st2, other, crate::check::types::Ty(crate::check::types::Ty::TyAny{Array<Text>{}}), span);
    }
}


prism_rtl::Turn<crate::check::types::St> CheckAny::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& x = this->x;
    const auto& expected = this->expected;
    const auto& span = this->span;
    auto env_1 = env;
    auto expected_2 = expected;
    auto span_3 = span;
    auto st_4 = st;
    auto x_5 = x;
    return call_then(crate::check::types::recording::start_walk(st_4, expected_2), [=](crate::check::types::Ty walk_7968) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyAny>(walk_7968) ? ({
            auto&& trs = prism_rtl::as<crate::check::types::Ty::TyAny>(walk_7968).a0;
            call_then(start_infer(env_1, st_4, x_5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_8027) {
            return ({
                auto [t, st2] = infer_8027;
                (prism_rtl::finished(fold(trs, st2, [&](const crate::check::types::St& s, const Text& tr) { return add_want(s, tr, t, span_3); })));
            });
        });
        })
            : ({
            auto&& other = walk_7968;
            call_then(start_infer(env_1, st_4, x_5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_8135) {
            return ({
                auto [t, st2] = infer_8135;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st2, other, crate::check::types::Ty(crate::check::types::Ty::TyAny{Array<Text>{}}), span_3))));
            });
        });
        });
        });
    });
}


/// `Start CheckAny, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_any(Env env, crate::check::types::St st, crate::syntax::Expr x, crate::check::types::Ty expected, crate::syntax::Range span) {
    return prism_rtl::make_rc<CheckAny>(env, st, x, expected, span);
}


/// AddWant: fn St, Text, Ty, Range -> St
crate::check::types::St add_want(const crate::check::types::St& st, const Text& cls, const crate::check::types::Ty& t, const crate::syntax::Range& span) {
    crate::check::types::St this_ = st;
    this_.wants = crate::prelude::push(this_.wants, crate::check::types::Want{.cls = cls, .ty = t, .file = this_.file, .span = span, .level = this_.level});
    return this_;
}


/// EnvCx: fn Env -> Cx
crate::check::env::reading::Cx_ env_cx(const Env& env) {
    auto base = crate::check::env::reading::cx_of(env.g, env.home);
    crate::check::env::reading::Cx_ this_ = base;
    this_.scope = env.scope;
    return this_;
}


/// InferName: unbounded fn Env, St, SName, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_name(const Env& env, const crate::check::types::St& st, const crate::syntax::SName& n, const crate::syntax::Range& span) {
    auto local = crate::check::env::sname_key(n);
    return env.in_update && has_time_mark(n.sigils)
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix(st, Text::lit("time-in-update"), span, prism_rtl::cat("`", local, "` in an `update` block"), Text::lit("an `&` block cannot see time: pass the plain value in, and lift the function"))}
        : infer_name_in(env, st, n, span);
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferName::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& span = this->span;
    auto local = crate::check::env::sname_key(n);
    return prism_rtl::val(env).in_update && has_time_mark(prism_rtl::val(n).sigils)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix(st, Text::lit("time-in-update"), span, prism_rtl::cat("`", local, "` in an `update` block"), Text::lit("an `&` block cannot see time: pass the plain value in, and lift the function"))})
        : prism_rtl::more(prism_rtl::rc(InferNameIn(env, st, n, span)));
}


/// `Start InferName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_name(Env env, crate::check::types::St st, crate::syntax::SName n, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferName>(env, st, n, span);
}


/// InferNameIn: unbounded fn Env, St, SName, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_name_in(const Env& env, const crate::check::types::St& st, const crate::syntax::SName& n, const crate::syntax::Range& span) {
    auto local = crate::check::env::sname_key(n);
    auto&& _m = crate::prelude::get(env.locals, local);
    if (prism_rtl::is_some(_m)) {
        auto&& sc = prism_rtl::some_of(_m);
        return instantiate_local(st, sc, span, local);
    }
    if (prism_rtl::is_none(_m)) {
        return infer_global(env, st, n, span);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferNameIn::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& span = this->span;
    auto local = crate::check::env::sname_key(n);
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::val(env).locals, local);
        prism_rtl::is_some(_m) ? ({
        auto&& sc = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(InstantiateLocal(st, sc, span, local)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(InferGlobal(env, st, n, span)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferNameIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_name_in(Env env, crate::check::types::St st, crate::syntax::SName n, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferNameIn>(env, st, n, span);
}


/// InstantiateLocal: unbounded fn St, Scheme, Range, Text -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_local(const crate::check::types::St& st, const crate::check::types::Scheme& sc, const crate::syntax::Range& span, const Text& name) {
    return (len(sc.qs) == Nat(0u)) && (len(sc.cqs) == Nat(0u))
        ? crate::check::types::schemes::instantiate(st, sc, span)
        : ({
        auto [t, st2, inst] = crate::check::types::schemes::instantiate_with(st, sc, span, Array<crate::check::types::Ty>{});
        std::tuple{t, crate::check::types::recording::note_inst(st2, span, name, sc, inst)};
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InstantiateLocal::cycle() const {
    const auto& st = this->st;
    const auto& sc = this->sc;
    const auto& span = this->span;
    const auto& name = this->name;
    return (len(prism_rtl::val(sc).qs) == Nat(0u)) && (len(prism_rtl::val(sc).cqs) == Nat(0u))
        ? prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::Instantiate(st, sc, span)))
        : ({
        auto name_1 = name;
        auto sc_2 = sc;
        auto span_3 = span;
        auto st_4 = st;
        call_then(crate::check::types::schemes::start_instantiate_with(st_4, sc_2, span_3, Array<crate::check::types::Ty>{}), [=](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst> instantiate_with_9652) {
        return ({
            auto [t, st2, inst] = instantiate_with_9652;
            (prism_rtl::finished(std::tuple{t, crate::check::types::recording::note_inst(st2, span_3, name_1, sc_2, inst)}));
        });
    });
    });
}


/// `Start InstantiateLocal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_instantiate_local(crate::check::types::St st, crate::check::types::Scheme sc, crate::syntax::Range span, Text name) {
    return prism_rtl::make_rc<InstantiateLocal>(st, sc, span, name);
}


/// InferGlobal: unbounded fn Env, St, SName, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_global(const Env& env, const crate::check::types::St& st0, const crate::syntax::SName& n, const crate::syntax::Range& span) {
    auto [qk_opt, why] = crate::check::env::names::resolve_value(env.g, env.home, n);
    auto st = collision_at(env, st0, why, crate::check::env::sname_key(n), span);
    if (prism_rtl::is_none(qk_opt)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unknown-name"), span, prism_rtl::cat("nothing declares `", crate::check::env::sname_key(n), "` here"))};
    }
    if (prism_rtl::is_some(qk_opt)) {
        auto&& qk = prism_rtl::some_of(qk_opt);
        return why == Text::lit("tag")
            ? tag_value(env, st, qk, span)
            : crate::check::expr::calls::is_local_maker(qk) && (!env.in_update)
            ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::expr::calls::local_outside(st, qk, span)}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::val(env.g).vals, qk);
            if (prism_rtl::is_some(_m)) {
                auto&& v_ = prism_rtl::some_of(_m);
                _v.set(crate::check::types::schemes::instantiate(crate::check::expr::calls::note_method_use(st, v_, span), prism_rtl::val(v_).scheme, span));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                    auto&& _m = crate::prelude::get(prism_rtl::val(env.g).ctors, qk);
                    if (prism_rtl::is_some(_m)) {
                        auto&& c = prism_rtl::some_of(_m);
                        _v.set(ctor_value(env, st, c, span));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unknown-name"), span, prism_rtl::cat("`", crate::check::env::sname_key(n), "` has no signature line or type"))});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferGlobal::cycle() const {
    const auto& env = this->env;
    const auto& st0 = this->st0;
    const auto& n = this->n;
    const auto& span = this->span;
    auto [qk_opt, why] = crate::check::env::names::resolve_value(prism_rtl::val(env).g, prism_rtl::val(env).home, n);
    auto st = collision_at(env, st0, why, crate::check::env::sname_key(n), span);
    return ({
        prism_rtl::is_none(qk_opt) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unknown-name"), span, prism_rtl::cat("nothing declares `", crate::check::env::sname_key(n), "` here"))})
        : prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        why == Text::lit("tag")
        ? prism_rtl::more(prism_rtl::rc(TagValue(env, st, qk, span)))
        : crate::check::expr::calls::is_local_maker(qk) && (!prism_rtl::val(env).in_update)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::expr::calls::local_outside(st, qk, span)})
        : ({
        auto&& _m = crate::prelude::get(prism_rtl::val(prism_rtl::val(env).g).vals, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::Instantiate(crate::check::expr::calls::note_method_use(st, v_, span), prism_rtl::val(v_).scheme, span)));
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(prism_rtl::val(prism_rtl::val(env).g).ctors, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(CtorValue(env, st, c, span)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unknown-name"), span, prism_rtl::cat("`", crate::check::env::sname_key(n), "` has no signature line or type"))})
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferGlobal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_global(Env env, crate::check::types::St st0, crate::syntax::SName n, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferGlobal>(env, st0, n, span);
}


/// CollisionAt: fn Env, St, Text, Text, Range -> St
crate::check::types::St collision_at(const Env& env, const crate::check::types::St& st, const Text& why, const Text& name, const crate::syntax::Range& span) {
    return why != Text::lit("collision")
        ? st
        : ({
        auto keys_ = or_(crate::prelude::get(or_(crate::prelude::get(prism_rtl::val(env.g).bare, env.home), Map<Text, Array<Text>>{}), name), Array<Text>{});
        auto others = filter(keys_, [&](const Text& k) { return crate::syntax::lexer::chars::contains(k, Text::lit(".")); });
        (crate::check::types::recording::err_fix(st, Text::lit("collision"), span, prism_rtl::cat("`", name, "` is declared by more than one module this file reaches by a bare name: ", crate::syntax::lexer::chars::join(each(keys_, [&](const Text& k) { return prism_rtl::cat("`", k, "`"); }), Text::lit(", "))), prism_rtl::cat("write the one meant qualified, as `", or_(index(others, Nat(0u)), name), "`, or rename this file\'s own")));
    });
}


/// CtorValue: unbounded fn Env, St, CtorInfo, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> ctor_value(const Env& env, const crate::check::types::St& st, const crate::check::env::CtorInfo& c, const crate::syntax::Range& span) {
    auto sc = crate::check::types::Scheme{.qs = c.params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = len(c.args) == Nat(0u)
        ? c.ty
        : crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), c.args, prism_rtl::rc(c.ty)})};
    return crate::check::types::schemes::instantiate(st, sc, span);
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> CtorValue::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& span = this->span;
    auto sc = crate::check::types::Scheme{.qs = prism_rtl::val(c).params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = len(c->args) == Nat(0u)
        ? prism_rtl::val(c).ty
        : crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), c->args, prism_rtl::rc(prism_rtl::val(c).ty)})};
    return prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::Instantiate(st, sc, span)));
}


/// `Start CtorValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_ctor_value(Env env, crate::check::types::St st, crate::check::env::CtorInfo c, crate::syntax::Range span) {
    return prism_rtl::make_rc<CtorValue>(env, st, c, span);
}


/// TagValue: unbounded fn Env, St, Text, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> tag_value(const Env& env, const crate::check::types::St& st, const Text& name, const crate::syntax::Range& span) {
    auto&& _m = crate::prelude::get(prism_rtl::val(env.g).tags, name);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unknown-name"), span, prism_rtl::cat("no tag `", name, "`"))};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& tg = prism_rtl::some_of(_m);
        return prism_rtl::val(tg).kind == Text::lit("Element")
            ? ({
            auto [rw, st2] = crate::check::types::recording::fresh_row(st, Array(std::vector{prism_rtl::val(tg).family}));
            auto erow = crate::check::types::Rw{.fams = Array(std::vector{prism_rtl::val(tg).family}), .minus = Array<Text>{}, .tail = prism_rtl::val(rw).tail};
            auto [out, st3] = crate::check::types::schemes::instantiate(st2, crate::check::types::Scheme{.qs = prism_rtl::val(tg).qs, .plain_qs = Array<Text>{}, .rqs = prism_rtl::val(tg).rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = prism_rtl::val(tg).bounds, .ty = tg->out}, span);
            std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{erow, prism_rtl::rc(out)}), st3};
        })
            : std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::val(tg).kind, Array<crate::check::types::Ty>{}}), st};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> TagValue::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& name = this->name;
    const auto& span = this->span;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::val(prism_rtl::val(env).g).tags, name);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unknown-name"), span, prism_rtl::cat("no tag `", name, "`"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        prism_rtl::val(tg).kind == Text::lit("Element")
        ? ({
        auto [rw, st2] = crate::check::types::recording::fresh_row(st, Array(std::vector{prism_rtl::val(tg).family}));
        auto erow = crate::check::types::Rw{.fams = Array(std::vector{prism_rtl::val(tg).family}), .minus = Array<Text>{}, .tail = prism_rtl::val(rw).tail};
        auto span_1 = span;
        call_then(crate::check::types::schemes::start_instantiate(st2, crate::check::types::Scheme{.qs = prism_rtl::val(tg).qs, .plain_qs = Array<Text>{}, .rqs = prism_rtl::val(tg).rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = prism_rtl::val(tg).bounds, .ty = tg->out}, span_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_12162) {
        return ({
            auto [out, st3] = instantiate_12162;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{erow, prism_rtl::rc(out)}), st3}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::val(tg).kind, Array<crate::check::types::Ty>{}}), st});
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TagValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_tag_value(Env env, crate::check::types::St st, Text name, crate::syntax::Range span) {
    return prism_rtl::make_rc<TagValue>(env, st, name, span);
}


/// InferBound: fn Env, St, Text, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_bound(const Env& env, const crate::check::types::St& st, const Text& b, const crate::syntax::Range& span) {
    auto&& _m = crate::prelude::get(env.locals, b);
    if (prism_rtl::is_some(_m)) {
        auto&& sc = prism_rtl::some_of(_m);
        return std::tuple{prism_rtl::val(sc).ty, st};
    }
    if (prism_rtl::is_none(_m)) {
        return b == Text::lit("key")
            ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unknown-name"), span, Text::lit("`key` is bound only in a loop over a map"))}
            : std::tuple{crate::check::types::t_nat(), st};
    }
    prism_rtl::unreachable("no arm matched");
}


/// InferLit: unbounded fn Env, St, Literal, Bool, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lit(const Env& env, const crate::check::types::St& st, const crate::syntax::Literal& l, const bool& negative, const crate::syntax::Range& span) {
    auto sigils = crate::syntax::lexer::chars::fold_chars(l.marks, Text::lit(""), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                (crate::check::types::unify::is_mark_char(c)
                ? prism_rtl::finished(prism_rtl::cat(acc, c))
                : prism_rtl::finished(acc));
            });
        });
    })));
    auto signed_ = prism_rtl::val(negative) || crate::syntax::lexer::chars::contains(l.marks, Text::lit("-"));
    auto [base, st2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = l.kind;
        if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
            auto&& digits = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
            _v.set(({
                auto [v_, s1] = crate::check::types::fresh_var(st, true, Text::lit(""));
                auto s2 = add_want(s1, Text::lit("Prelude.Num"), v_, span);
                auto s3 = signed_ ? add_want(s2, Text::lit("Prelude.Signed"), v_, span) : s2;
                auto s4 = add_range(s3, v_, digits, signed_, span);
                std::tuple{v_, s4};
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LitKind::LFloat>(_m)) {
            _v.set(std::tuple{crate::check::types::t_float(), st});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LitKind::LDuration>(_m)) {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Duration"), Array<crate::check::types::Ty>{}}), st});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
            _v.set(std::tuple{crate::check::types::t_char(), st});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
            auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
            _v.set(infer_text(env, st, segs, crate::syntax::lexer::chars::contains(sigils, Text::lit("$")), span));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LitKind::LRegex>(_m)) {
            auto&& r = prism_rtl::as<crate::syntax::LitKind::LRegex>(_m).a0;
            _v.set(infer_regex(st, r));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::syntax::lexer::chars::contains(sigils, Text::lit("$")) && (crate::check::types::head_sigil(st2, base) == Text::lit("$"))
        ? std::tuple{base, st2}
        : crate::syntax::lexer::chars::contains(sigils, Text::lit("$"))
        ? std::tuple{crate::check::types::with_marks(sigils, base, env.scope), crate::check::types::recording::note_app(st2, span, Text::lit("$"), Text::lit("const"), Text::lit("$"), Array<Nat>{}, Text::lit(""), crate::check::types::Col(crate::check::types::Col::CBound{}))}
        : std::tuple{crate::check::types::with_marks(sigils, base, env.scope), st2};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferLit::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& l = this->l;
    const auto& negative = this->negative;
    const auto& span = this->span;
    auto env_1 = env;
    auto l_2 = l;
    auto negative_3 = prism_rtl::val(negative);
    auto span_4 = span;
    auto st_5 = st;
    return call_value(crate::syntax::lexer::chars::start_fold_chars(prism_rtl::val(l_2).marks, Text::lit(""), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                (crate::check::types::unify::is_mark_char(c)
                ? prism_rtl::finished(prism_rtl::cat(acc, c))
                : prism_rtl::finished(acc));
            });
        });
    }))), [=](Text fold_chars_13135) {
        return ({
            auto sigils = fold_chars_13135;
            auto signed_ = negative_3 || crate::syntax::lexer::chars::contains(prism_rtl::val(l_2).marks, Text::lit("-"));
            auto [base, st2] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                auto&& _m = prism_rtl::val(l_2).kind;
                if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
                    auto&& digits = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
                    _v.set(({
                        auto [v_, s1] = crate::check::types::fresh_var(st_5, true, Text::lit(""));
                        auto s2 = add_want(s1, Text::lit("Prelude.Num"), v_, span_4);
                        auto s3 = signed_ ? add_want(s2, Text::lit("Prelude.Signed"), v_, span_4) : s2;
                        auto s4 = add_range(s3, v_, digits, signed_, span_4);
                        std::tuple{v_, s4};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LitKind::LFloat>(_m)) {
                    _v.set(std::tuple{crate::check::types::t_float(), st_5});
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LitKind::LDuration>(_m)) {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Duration"), Array<crate::check::types::Ty>{}}), st_5});
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
                    _v.set(std::tuple{crate::check::types::t_char(), st_5});
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
                    auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
                    _v.set(infer_text(env_1, st_5, segs, crate::syntax::lexer::chars::contains(sigils, Text::lit("$")), span_4));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LitKind::LRegex>(_m)) {
                    auto&& r = prism_rtl::as<crate::syntax::LitKind::LRegex>(_m).a0;
                    _v.set(infer_regex(st_5, r));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (crate::syntax::lexer::chars::contains(sigils, Text::lit("$")) && (crate::check::types::head_sigil(st2, base) == Text::lit("$"))
            ? prism_rtl::finished(std::tuple{base, st2})
            : crate::syntax::lexer::chars::contains(sigils, Text::lit("$"))
            ? prism_rtl::finished(std::tuple{crate::check::types::with_marks(sigils, base, prism_rtl::val(env_1).scope), crate::check::types::recording::note_app(st2, span_4, Text::lit("$"), Text::lit("const"), Text::lit("$"), Array<Nat>{}, Text::lit(""), crate::check::types::Col(crate::check::types::Col::CBound{}))})
            : prism_rtl::finished(std::tuple{crate::check::types::with_marks(sigils, base, prism_rtl::val(env_1).scope), st2}));
        });
    });
}


/// `Start InferLit, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_lit(Env env, crate::check::types::St st, crate::syntax::Literal l, bool negative, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferLit>(env, st, l, negative, span);
}


/// InferRegex: unbounded fn St, RegexLit -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_regex(const crate::check::types::St& st, const crate::syntax::RegexLit& r) {
    auto t = crate::check::types::Ty(crate::check::types::Ty::TyCon{r.replacement == std::optional<Text>{}
        ? Text::lit("Regex")
        : Text::lit("RegexReplacement"), Array<crate::check::types::Ty>{}});
    auto&& _m = crate::check::regex::regex_refusal(r.pattern, r.flags, r.replacement);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{t, st};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& d = prism_rtl::some_of(_m);
        auto [base, text_] = prism_rtl::val(d).part == Text::lit("flags")
            ? std::tuple{r.flags_at, r.flags}
            : prism_rtl::val(d).part == Text::lit("pattern")
            ? std::tuple{r.pattern_at, r.pattern}
            : std::tuple{r.replacement_at, or_(r.replacement, Text::lit(""))};
        auto start = base + prism_rtl::val(d).at;
        auto span = crate::syntax::Range{.start = start, .end = start + crate::prelude::max(len_text(crate::check::regex::rx_char_at(text_, prism_rtl::val(d).at)), Nat(1u))};
        return prism_rtl::val(d).message == crate::check::regex::rx_unknown_flag()
            ? std::tuple{t, crate::check::types::recording::err_fix(st, Text::lit("regex"), span, prism_rtl::val(d).message, Text::lit("a replacement that starts with letters and holds anything but letters is written in the hashed form, `%#/x/#hello world/#`"))}
            : std::tuple{t, crate::check::types::recording::err(st, Text::lit("regex"), span, prism_rtl::val(d).message)};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferRegex::cycle() const {
    const auto& st = this->st;
    const auto& r = this->r;
    auto t = crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::val(r).replacement == std::optional<Text>{}
        ? Text::lit("Regex")
        : Text::lit("RegexReplacement"), Array<crate::check::types::Ty>{}});
    auto r_1 = r;
    auto st_2 = st;
    return call_then(crate::check::regex::start_regex_refusal(prism_rtl::val(r_1).pattern, prism_rtl::val(r_1).flags, prism_rtl::val(r_1).replacement), [=](std::optional<crate::check::regex::RxDiag> regex_refusal_14607) {
        return ({
            prism_rtl::is_none(regex_refusal_14607) ? prism_rtl::finished(std::tuple{t, st_2})
            : prism_rtl::is_some(regex_refusal_14607) ? ({
            auto&& d = prism_rtl::some_of(regex_refusal_14607);
            ({
            auto [base, text_] = prism_rtl::val(d).part == Text::lit("flags")
                ? std::tuple{prism_rtl::val(r_1).flags_at, prism_rtl::val(r_1).flags}
                : prism_rtl::val(d).part == Text::lit("pattern")
                ? std::tuple{prism_rtl::val(r_1).pattern_at, prism_rtl::val(r_1).pattern}
                : std::tuple{prism_rtl::val(r_1).replacement_at, or_(prism_rtl::val(r_1).replacement, Text::lit(""))};
            auto start = base + prism_rtl::val(d).at;
            auto span = crate::syntax::Range{.start = start, .end = start + crate::prelude::max(len_text(crate::check::regex::rx_char_at(text_, prism_rtl::val(d).at)), Nat(1u))};
            (prism_rtl::val(d).message == crate::check::regex::rx_unknown_flag()
            ? prism_rtl::finished(std::tuple{t, crate::check::types::recording::err_fix(st_2, Text::lit("regex"), span, prism_rtl::val(d).message, Text::lit("a replacement that starts with letters and holds anything but letters is written in the hashed form, `%#/x/#hello world/#`"))})
            : prism_rtl::finished(std::tuple{t, crate::check::types::recording::err(st_2, Text::lit("regex"), span, prism_rtl::val(d).message)}));
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start InferRegex, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_regex(crate::check::types::St st, crate::syntax::RegexLit r) {
    return prism_rtl::make_rc<InferRegex>(st, r);
}


/// AddRange: fn St, Ty, Text, Bool, Range -> St
crate::check::types::St add_range(const crate::check::types::St& st, const crate::check::types::Ty& v_, const Text& digits, const bool& signed_, const crate::syntax::Range& span) {
    crate::check::types::St this_ = st;
    this_.wants = crate::prelude::push(this_.wants, crate::check::types::Want{.cls = prism_rtl::cat("Range ", prism_rtl::val(signed_) ? Text::lit("-") : Text::lit(""), digits), .ty = v_, .file = this_.file, .span = span, .level = this_.level});
    return this_;
}


/// InferText: unbounded fn Env, St, [TextSeg], Bool, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_text(const Env& env, const crate::check::types::St& st, const Array<crate::syntax::TextSeg>& segs, const bool& dollar, const crate::syntax::Range& span) {
    auto holes = fold(segs, Array<crate::syntax::Expr>{}, [&](const Array<crate::syntax::Expr>& acc, const crate::syntax::TextSeg& sg) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
            if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg)) {
                auto&& x = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg).a0;
                _v.set(crate::prelude::push(acc, x));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return len(holes) == Nat(0u)
        ? std::tuple{crate::check::types::t_text(), st}
        : ({
        auto [events, dyns, opts, st2, lifted] = run_to_end(fold_job(crate::check::errors::range0(len(holes)), std::tuple{Array<crate::syntax::Range>{}, Int(0ll), Array<Text>{}, st, Array<Nat>{}}, ({
            auto holes_1 = holes;
            auto span_2 = span;
            auto env_3 = env;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>>(std::tuple<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto holes_1_4 = holes_1;
                auto span_2_4 = span_2;
                auto env_3_4 = env_3;
                entered(once_job([=]() {
                return ({
                    auto [ev, dy, op, s, li] = p0;
                    auto hi = p1;
                    ({
                    auto x = or_(index(holes_1_4, hi), crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_2_4});
                    call_then(start_infer(env_3_4, s, x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_16302) {
                    return ({
                        auto [t, s2] = infer_16302;
                        call_then(crate::check::types::start_head_sigil(s2, t), [=](Text head_sigil_16341) {
                        return ({
                            auto head = head_sigil_16341;
                            auto inner = is_time_sigil(head) ? inner_of(s2, t) : t;
                            call_then(crate::check::types::start_head_sigil(s2, inner), [=](Text head_sigil_16445) {
                            return ({
                                auto ih = head_sigil_16445;
                                auto plain_t = is_plain_sigil(ih) ? inner_of(s2, inner) : inner;
                                auto s3 = head == Text::lit("@")
                                    ? crate::check::types::recording::err(s2, Text::lit("blueprint-operand"), prism_rtl::val(x).span, Text::lit("a text over a blueprint; bind it first"))
                                    : s2;
                                call_then(start_show_want(s3, plain_t, prism_rtl::val(x).span), [=](crate::check::types::St show_want_16685) {
                                return ({
                                    auto s4 = show_want_16685;
                                    auto ev2 = head == Text::lit("!")
                                        ? crate::prelude::push(ev, prism_rtl::val(x).span)
                                        : ev;
                                    auto dy2 = head == Text::lit("$") ? dy + Int(1ll) : dy;
                                    auto op2 = is_plain_sigil(ih) ? crate::check::types::add_text(op, ih) : op;
                                    auto li2 = is_time_sigil(head) ? crate::prelude::push(li, hi) : li;
                                    (prism_rtl::finished(std::tuple{ev2, dy2, op2, s4, li2}));
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        }));
        })));
        auto st3 = prism_rtl::val(dollar) && (len(events) > Nat(0u))
            ? crate::check::types::recording::err(st2, Text::lit("event-in-text"), or_(index(events, Nat(0u)), span), Text::lit("an event in a dynamic text"))
            : len(events) > Nat(1u)
            ? crate::check::types::recording::err_fix(st2, Text::lit("two-events"), or_(index(events, Nat(1u)), span), Text::lit("two events in one operation"), Text::lit("merge them with `<|`, or hold one first"))
            : st2;
        auto st4 = len(opts) > Nat(1u)
            ? crate::check::types::recording::err(st3, Text::lit("optional-and-fault"), span, Text::lit("`?` and `~` in one operation"))
            : st3;
        auto with_opt = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Ty> _v;
            auto&& _m = index(opts, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& o = prism_rtl::some_of(_m);
                _v.set(crate::check::types::Ty(crate::check::types::Ty::TySig{o, prism_rtl::rc(crate::check::types::t_text())}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::check::types::t_text());
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto layer = (len(events) > Nat(0u)) && (!prism_rtl::val(dollar))
            ? Text::lit("!")
            : (dyns > Int(0ll)) || prism_rtl::val(dollar)
            ? Text::lit("$")
            : Text::lit("");
        auto res = layer == Text::lit("")
            ? with_opt
            : crate::check::types::Ty(crate::check::types::Ty::TySig{layer, prism_rtl::rc(with_opt)});
        auto kind = layer == Text::lit("")
            ? Text::lit("plain")
            : len(lifted) == Nat(0u) ? Text::lit("const") : Text::lit("map");
        std::tuple{res, crate::check::types::recording::note_app(st4, span, Text::lit("text"), kind, layer, lifted, or_(index(opts, Nat(0u)), Text::lit("")), crate::check::types::Col(crate::check::types::Col::CBound{}))};
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferText::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& segs = this->segs;
    const auto& dollar = this->dollar;
    const auto& span = this->span;
    auto holes = fold(segs, Array<crate::syntax::Expr>{}, [&](const Array<crate::syntax::Expr>& acc, const crate::syntax::TextSeg& sg) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
            if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg)) {
                auto&& x = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg).a0;
                _v.set(crate::prelude::push(acc, x));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return len(holes) == Nat(0u)
        ? prism_rtl::finished(std::tuple{crate::check::types::t_text(), st})
        : ({
        auto dollar_1 = prism_rtl::val(dollar);
        auto env_2 = env;
        auto span_3 = span;
        auto st_4 = st;
        call_value(fold_job(crate::check::errors::range0(len(holes)), std::tuple{Array<crate::syntax::Range>{}, Int(0ll), Array<Text>{}, st_4, Array<Nat>{}}, ({
        auto holes_5 = holes;
        auto span_3_6 = span_3;
        auto env_2_6 = env_2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>>(std::tuple<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto holes_5_6 = holes_5;
            auto span_3_6_6 = span_3_6;
            auto env_2_6_6 = env_2_6;
            entered(once_job([=]() {
            return ({
                auto [ev, dy, op, s, li] = p0;
                auto hi = p1;
                ({
                auto x = or_(index(holes_5_6, hi), crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_3_6_6});
                call_then(start_infer(env_2_6_6, s, x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_16302) {
                return ({
                    auto [t, s2] = infer_16302;
                    call_then(crate::check::types::start_head_sigil(s2, t), [=](Text head_sigil_16341) {
                    return ({
                        auto head = head_sigil_16341;
                        auto inner = is_time_sigil(head) ? inner_of(s2, t) : t;
                        call_then(crate::check::types::start_head_sigil(s2, inner), [=](Text head_sigil_16445) {
                        return ({
                            auto ih = head_sigil_16445;
                            auto plain_t = is_plain_sigil(ih) ? inner_of(s2, inner) : inner;
                            auto s3 = head == Text::lit("@")
                                ? crate::check::types::recording::err(s2, Text::lit("blueprint-operand"), prism_rtl::val(x).span, Text::lit("a text over a blueprint; bind it first"))
                                : s2;
                            call_then(start_show_want(s3, plain_t, prism_rtl::val(x).span), [=](crate::check::types::St show_want_16685) {
                            return ({
                                auto s4 = show_want_16685;
                                auto ev2 = head == Text::lit("!")
                                    ? crate::prelude::push(ev, prism_rtl::val(x).span)
                                    : ev;
                                auto dy2 = head == Text::lit("$") ? dy + Int(1ll) : dy;
                                auto op2 = is_plain_sigil(ih) ? crate::check::types::add_text(op, ih) : op;
                                auto li2 = is_time_sigil(head) ? crate::prelude::push(li, hi) : li;
                                (prism_rtl::finished(std::tuple{ev2, dy2, op2, s4, li2}));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>> fold_16126) {
        return ({
            auto [events, dyns, opts, st2, lifted] = fold_16126;
            auto st3 = dollar_1 && (len(events) > Nat(0u))
                ? crate::check::types::recording::err(st2, Text::lit("event-in-text"), or_(index(events, Nat(0u)), span_3), Text::lit("an event in a dynamic text"))
                : len(events) > Nat(1u)
                ? crate::check::types::recording::err_fix(st2, Text::lit("two-events"), or_(index(events, Nat(1u)), span_3), Text::lit("two events in one operation"), Text::lit("merge them with `<|`, or hold one first"))
                : st2;
            auto st4 = len(opts) > Nat(1u)
                ? crate::check::types::recording::err(st3, Text::lit("optional-and-fault"), span_3, Text::lit("`?` and `~` in one operation"))
                : st3;
            auto with_opt = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::Ty> _v;
                auto&& _m = index(opts, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& o = prism_rtl::some_of(_m);
                    _v.set(crate::check::types::Ty(crate::check::types::Ty::TySig{o, prism_rtl::rc(crate::check::types::t_text())}));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::check::types::t_text());
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto layer = (len(events) > Nat(0u)) && (!dollar_1)
                ? Text::lit("!")
                : (dyns > Int(0ll)) || dollar_1 ? Text::lit("$") : Text::lit("");
            auto res = layer == Text::lit("")
                ? with_opt
                : crate::check::types::Ty(crate::check::types::Ty::TySig{layer, prism_rtl::rc(with_opt)});
            auto kind = layer == Text::lit("")
                ? Text::lit("plain")
                : len(lifted) == Nat(0u) ? Text::lit("const") : Text::lit("map");
            (prism_rtl::finished(std::tuple{res, crate::check::types::recording::note_app(st4, span_3, Text::lit("text"), kind, layer, lifted, or_(index(opts, Nat(0u)), Text::lit("")), crate::check::types::Col(crate::check::types::Col::CBound{}))}));
        });
    });
    });
}


/// `Start InferText, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_text(Env env, crate::check::types::St st, Array<crate::syntax::TextSeg> segs, bool dollar, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferText>(env, st, segs, dollar, span);
}


/// ShowWant: unbounded fn St, Ty, Range -> St
crate::check::types::St show_want(const crate::check::types::St& st, const crate::check::types::Ty& t, const crate::syntax::Range& span) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m17998_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m17998_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m17998_0_0 == Text::lit("Text")) {
            if (m17998_0_1.size() == 0u) {
                return st;
            }
        }
    }
    {
        auto&& other = _m;
        return add_want(st, Text::lit("Prelude.Show"), other, span);
    }
}


prism_rtl::Turn<crate::check::types::St> ShowWant::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& span = this->span;
    auto span_1 = span;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(crate::check::types::recording::start_walk(st_2, t_3), [=](crate::check::types::Ty walk_18004) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_18004) && ({
            auto&& m17998_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_18004).a0;
            auto&& m17998_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_18004).a1;
            (m17998_0_0 == Text::lit("Text")) && (m17998_0_1.size() == 0u);
        }) ? ({
            auto&& m17998_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_18004).a0;
            auto&& m17998_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_18004).a1;
            prism_rtl::finished(st_2);
        })
            : ({
            auto&& other = walk_18004;
            prism_rtl::finished(add_want(st_2, Text::lit("Prelude.Show"), other, span_1));
        });
        });
    });
}


/// `Start ShowWant, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_show_want(crate::check::types::St st, crate::check::types::Ty t, crate::syntax::Range span) {
    return prism_rtl::make_rc<ShowWant>(st, t, span);
}

}  // namespace crate::check::expr
