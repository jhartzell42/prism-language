// The modules `Check.Shrink.Locals`, `Check.Shrink.Relations`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/shrink/locals/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Shrink.Locals`, from `target/bootstrap/cpp-src/prismc/check/shrink/locals.prism`.
namespace crate::check::shrink::locals {

/// WithLocals: unbounded fn Shrink, [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))] -> Shrink
crate::check::shrink::Shrink with_locals(const crate::check::shrink::Shrink& sk, const Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>& found) {
    auto [bases, owners, clauses, wdecls] = fold(found, std::tuple{Map<Text, Map<Text, crate::check::shrink::Rel>>{}, Map<Text, Text>{}, Map<Text, Array<crate::syntax::decls::FnClause>>{}, Map<Text, std::tuple<crate::check::env::Def, crate::syntax::decls::WidgetDecl>>{}}, [&](const std::tuple<Map<Text, Map<Text, crate::check::shrink::Rel>>, Map<Text, Text>, Map<Text, Array<crate::syntax::decls::FnClause>>, Map<Text, std::tuple<crate::check::env::Def, crate::syntax::decls::WidgetDecl>>>& _p0, const std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>& _p1) {
        auto&& bs = std::get<0>(_p0);
        auto&& os = std::get<1>(_p0);
        auto&& cs = std::get<2>(_p0);
        auto&& ws = std::get<3>(_p0);
        auto&& d = std::get<0>(_p1);
        auto&& gk = std::get<1>(_p1);
        auto&& n = std::get<2>(_p1);
        auto&& m = std::get<3>(_p1);
        auto&& c_opt = std::get<4>(_p1);
        auto&& w_opt = std::get<5>(_p1);
        return ({
            auto qk = local_key(n, d.qk, gk);
            auto bs2 = crate::check::env::has_key(bs, qk)
                ? bs
                : insert(bs, qk, crate::check::shrink::summaries::marks(m));
            auto os2 = insert(os, qk, d.qk);
            auto cs2 = ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, Array<crate::syntax::decls::FnClause>>> _v;
                if (prism_rtl::is_some(c_opt)) {
                    auto&& c = prism_rtl::some_of(c_opt);
                    _v.set(insert(cs, qk, crate::prelude::push(or_(crate::prelude::get(cs, qk), Array<crate::syntax::decls::FnClause>{}), c)));
                    goto _done;
                }
                if (prism_rtl::is_none(c_opt)) {
                    _v.set(cs);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto ws2 = ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, std::tuple<crate::check::env::Def, crate::syntax::decls::WidgetDecl>>> _v;
                if (prism_rtl::is_some(w_opt)) {
                    auto&& w = prism_rtl::some_of(w_opt);
                    _v.set(insert(ws, qk, std::tuple{d, w}));
                    goto _done;
                }
                if (prism_rtl::is_none(w_opt)) {
                    _v.set(ws);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            std::tuple{bs2, os2, cs2, ws2};
        });
    });
    auto fn_defs = fold(keys(clauses), Array<crate::check::env::Def>{}, [&](const Array<crate::check::env::Def>& acc, const Text& qk) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::env::Def>> _v;
            auto&& _m = std::tuple{crate::prelude::get(owners, qk), crate::prelude::get(clauses, qk)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& oq = prism_rtl::some_of(std::get<0>(_m));
                auto&& cl = prism_rtl::some_of(std::get<1>(_m));
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::check::env::Def>> _v;
                    auto&& _m = crate::prelude::get(sk.by_key, oq);
                    if (prism_rtl::is_some(_m)) {
                        auto&& d = prism_rtl::some_of(_m);
                        _v.set(crate::prelude::push(acc, crate::check::env::Def{.qk = qk, .name = or_(index(split_on(qk, Text::lit(" #")), Nat(0u)), qk), .home = d.home, .file = d->file, .span = d.span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbFn{cl})}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto w_defs = fold(keys(wdecls), Array<crate::check::env::Def>{}, [&](const Array<crate::check::env::Def>& acc, const Text& qk) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::env::Def>> _v;
            auto&& _m = crate::prelude::get(wdecls, qk);
            if (prism_rtl::is_some(_m)) {
                auto&& d = std::get<0>(prism_rtl::some_of(_m));
                auto&& w = std::get<1>(prism_rtl::some_of(_m));
                _v.set(crate::prelude::push(acc, crate::check::env::Def{.qk = qk, .name = crate::check::env::sname_key(w.name), .home = d.home, .file = d->file, .span = w.span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbWidget{w})}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto locals = append(fn_defs, w_defs);
    crate::check::shrink::Shrink this_ = sk;
    this_.fns = append(this_.fns, locals);
    this_.by_key = fold(locals, this_.by_key, [&](const Map<Text, crate::check::env::Def>& m, const crate::check::env::Def& d) { return insert(m, d.qk, d); });
    this_.local_of = owners;
    this_.local_base = bases;
    return this_;
}


prism_rtl::Turn<crate::check::shrink::Shrink> WithLocals::cycle() const {
    const auto& sk = this->sk;
    const auto& found = this->found;
    auto [bases, owners, clauses, wdecls] = fold(found, std::tuple{Map<Text, Map<Text, crate::check::shrink::Rel>>{}, Map<Text, Text>{}, Map<Text, Array<crate::syntax::decls::FnClause>>{}, Map<Text, std::tuple<crate::check::env::Def, crate::syntax::decls::WidgetDecl>>{}}, [&](const std::tuple<Map<Text, Map<Text, crate::check::shrink::Rel>>, Map<Text, Text>, Map<Text, Array<crate::syntax::decls::FnClause>>, Map<Text, std::tuple<crate::check::env::Def, crate::syntax::decls::WidgetDecl>>>& _p0, const std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>& _p1) {
        auto&& bs = std::get<0>(_p0);
        auto&& os = std::get<1>(_p0);
        auto&& cs = std::get<2>(_p0);
        auto&& ws = std::get<3>(_p0);
        auto&& d = std::get<0>(_p1);
        auto&& gk = std::get<1>(_p1);
        auto&& n = std::get<2>(_p1);
        auto&& m = std::get<3>(_p1);
        auto&& c_opt = std::get<4>(_p1);
        auto&& w_opt = std::get<5>(_p1);
        return ({
            auto qk = local_key(n, d.qk, gk);
            auto bs2 = crate::check::env::has_key(bs, qk)
                ? bs
                : insert(bs, qk, crate::check::shrink::summaries::marks(m));
            auto os2 = insert(os, qk, d.qk);
            auto cs2 = ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, Array<crate::syntax::decls::FnClause>>> _v;
                if (prism_rtl::is_some(c_opt)) {
                    auto&& c = prism_rtl::some_of(c_opt);
                    _v.set(insert(cs, qk, crate::prelude::push(or_(crate::prelude::get(cs, qk), Array<crate::syntax::decls::FnClause>{}), c)));
                    goto _done;
                }
                if (prism_rtl::is_none(c_opt)) {
                    _v.set(cs);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto ws2 = ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, std::tuple<crate::check::env::Def, crate::syntax::decls::WidgetDecl>>> _v;
                if (prism_rtl::is_some(w_opt)) {
                    auto&& w = prism_rtl::some_of(w_opt);
                    _v.set(insert(ws, qk, std::tuple{d, w}));
                    goto _done;
                }
                if (prism_rtl::is_none(w_opt)) {
                    _v.set(ws);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            std::tuple{bs2, os2, cs2, ws2};
        });
    });
    auto fn_defs = fold(keys(clauses), Array<crate::check::env::Def>{}, [&](const Array<crate::check::env::Def>& acc, const Text& qk) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::env::Def>> _v;
            auto&& _m = std::tuple{crate::prelude::get(owners, qk), crate::prelude::get(clauses, qk)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& oq = prism_rtl::some_of(std::get<0>(_m));
                auto&& cl = prism_rtl::some_of(std::get<1>(_m));
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::check::env::Def>> _v;
                    auto&& _m = crate::prelude::get(sk.by_key, oq);
                    if (prism_rtl::is_some(_m)) {
                        auto&& d = prism_rtl::some_of(_m);
                        _v.set(crate::prelude::push(acc, crate::check::env::Def{.qk = qk, .name = or_(index(split_on(qk, Text::lit(" #")), Nat(0u)), qk), .home = d.home, .file = d->file, .span = d.span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbFn{cl})}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto w_defs = fold(keys(wdecls), Array<crate::check::env::Def>{}, [&](const Array<crate::check::env::Def>& acc, const Text& qk) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::env::Def>> _v;
            auto&& _m = crate::prelude::get(wdecls, qk);
            if (prism_rtl::is_some(_m)) {
                auto&& d = std::get<0>(prism_rtl::some_of(_m));
                auto&& w = std::get<1>(prism_rtl::some_of(_m));
                _v.set(crate::prelude::push(acc, crate::check::env::Def{.qk = qk, .name = crate::check::env::sname_key(w.name), .home = d.home, .file = d->file, .span = w.span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbWidget{w})}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto locals = append(fn_defs, w_defs);
    return prism_rtl::finished(({
        crate::check::shrink::Shrink this_ = sk;
        this_.fns = append(this_.fns, locals);
        this_.by_key = fold(locals, this_.by_key, [&](const Map<Text, crate::check::env::Def>& m, const crate::check::env::Def& d) { return insert(m, d.qk, d); });
        this_.local_of = owners;
        this_.local_base = bases;
        this_;
    }));
}


/// `Start WithLocals, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::shrink::Shrink> start_with_locals(crate::check::shrink::Shrink sk, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>> found) {
    return prism_rtl::make_rc<WithLocals>(sk, found);
}


/// LocalKey: fn Text, Text, Text -> Text
Text local_key(const Text& n, const Text& owner, const Text& gk) {
    return prism_rtl::cat(n, " #local ", owner, " ", gk);
}


/// DefWalk: unbounded fn Shrink, Def -> ((Text, [Text], [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]))
std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>> def_walk(const crate::check::shrink::Shrink& sk, const crate::check::env::Def& d) {
    auto [refs, locals] = run_to_end(fold_job(crate::check::shrink::types::def_clauses(d), std::tuple{Array<Text>{}, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{}}, ({
        auto sk_1 = sk;
        auto d_2 = d;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>>(std::tuple<std::tuple<Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_3 = sk_1;
            auto d_2_3 = d_2;
            entered(once_job([=]() {
            return ({
                auto [rs, ls] = p0;
                auto c = p1;
                call_then(start_clause_base(sk_1_3, d_2_3, c), [=](Map<Text, crate::check::shrink::Rel> clause_base_4223) {
                return call_then(crate::check::shrink::walk::start_body_spots(c.body, clause_base_4223), [=](Array<crate::check::shrink::walk::Spot> body_spots_4204) {
                    return ({
                        auto spots = body_spots_4204;
                        call_then(crate::check::shrink::calls::start_spots_refs(sk_1_3, d_2_3, spots, rs), [=](Array<Text> spots_refs_4255) { return prism_rtl::finished(std::tuple{spots_refs_4255, fold(spots, ls, [&](const Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>& a2, const crate::check::shrink::walk::Spot& sp) { return append(a2, spot_local(d_2_3, sp)); })}); });
                    });
                });
            });
            });
        }));
        });
    }));
    })));
    return std::tuple{d.qk, refs, locals};
}


prism_rtl::Turn<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>> DefWalk::cycle() const {
    const auto& sk = this->sk;
    const auto& d = this->d;
    auto d_1 = d;
    auto sk_2 = sk;
    return call_value(fold_job(crate::check::shrink::types::def_clauses(d_1), std::tuple{Array<Text>{}, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{}}, ({
        auto sk_2_3 = sk_2;
        auto d_1_3 = d_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>>(std::tuple<std::tuple<Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_2_3_3 = sk_2_3;
            auto d_1_3_3 = d_1_3;
            entered(once_job([=]() {
            return ({
                auto [rs, ls] = p0;
                auto c = p1;
                call_then(start_clause_base(sk_2_3_3, d_1_3_3, c), [=](Map<Text, crate::check::shrink::Rel> clause_base_4223) {
                return call_then(crate::check::shrink::walk::start_body_spots(c.body, clause_base_4223), [=](Array<crate::check::shrink::walk::Spot> body_spots_4204) {
                    return ({
                        auto spots = body_spots_4204;
                        call_then(crate::check::shrink::calls::start_spots_refs(sk_2_3_3, d_1_3_3, spots, rs), [=](Array<Text> spots_refs_4255) { return prism_rtl::finished(std::tuple{spots_refs_4255, fold(spots, ls, [&](const Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>& a2, const crate::check::shrink::walk::Spot& sp) { return append(a2, spot_local(d_1_3_3, sp)); })}); });
                    });
                });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>> fold_4130) {
        return ({
            auto [refs, locals] = fold_4130;
            (prism_rtl::finished(std::tuple{d_1.qk, refs, locals}));
        });
    });
}


/// `Start DefWalk, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>> start_def_walk(crate::check::shrink::Shrink sk, crate::check::env::Def d) {
    return prism_rtl::make_rc<DefWalk>(sk, d);
}


/// SpotLocal: fn Def, Spot -> [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]
Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>> spot_local(const crate::check::env::Def& d, const crate::check::shrink::walk::Spot& sp) {
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(sp)) {
        auto&& s = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp).a0;
        auto&& m = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp).a1;
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
            auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
            auto n = crate::check::env::def_name_text(f.name);
            auto&& _m = crate::prelude::get(m, prism_rtl::cat("lfn:", n));
            if (prism_rtl::is_some(_m)) {
                auto&& r = prism_rtl::some_of(_m);
                return Array(std::vector{std::tuple{d, prism_rtl::cat(d->file, ".", r.param), n, m, std::optional(f), std::optional<crate::syntax::decls::WidgetDecl>{}}});
            }
            if (prism_rtl::is_none(_m)) {
                return Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
            auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
            auto n = crate::check::env::sname_key(w.name);
            auto&& _m = crate::prelude::get(m, prism_rtl::cat("lfn:", n));
            if (prism_rtl::is_some(_m)) {
                auto&& r = prism_rtl::some_of(_m);
                return Array(std::vector{std::tuple{d, prism_rtl::cat(d->file, ".", r.param), n, m, std::optional<crate::syntax::decls::FnClause>{}, std::optional(w)}});
            }
            if (prism_rtl::is_none(_m)) {
                return Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        {
            return Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{};
        }
    }
    {
        return Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{};
    }
}


/// ?LocalTarget: fn Shrink, Def, Site -> ?Text
std::optional<Text> local_target(const crate::check::shrink::Shrink& sk, const crate::check::env::Def& d, const crate::check::shrink::walk::Site& site) {
    auto&& _m = crate::prelude::get(site.rels, prism_rtl::cat("lfn:", site.callee));
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return std::optional(local_key(site.callee, or_(crate::prelude::get(sk.local_of, d.qk), d.qk), prism_rtl::cat(d->file, ".", r.param)));
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ClauseBase: unbounded fn Shrink, Def, FnClause -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> clause_base(const crate::check::shrink::Shrink& sk, const crate::check::env::Def& d, const crate::syntax::decls::FnClause& c) {
    auto&& _m = crate::prelude::get(sk.local_base, d.qk);
    if (prism_rtl::is_some(_m)) {
        auto&& b = prism_rtl::some_of(_m);
        return param_rels_on(b, c.params);
    }
    if (prism_rtl::is_none(_m)) {
        return param_rels_on(insert(or_(crate::prelude::get(sk.seeds, d.home), Map<Text, crate::check::shrink::Rel>{}), Text::lit("file:"), crate::check::shrink::Rel{.param = d->file, .strict = false}), c.params);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> ClauseBase::cycle() const {
    const auto& sk = this->sk;
    const auto& d = this->d;
    const auto& c = this->c;
    return ({
        auto&& _m = crate::prelude::get(sk.local_base, d.qk);
        prism_rtl::is_some(_m) ? ({
        auto&& b = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(ParamRelsOn(b, c.params)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(ParamRelsOn(insert(or_(crate::prelude::get(sk.seeds, d.home), Map<Text, crate::check::shrink::Rel>{}), Text::lit("file:"), crate::check::shrink::Rel{.param = d->file, .strict = false}), c.params)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ClauseBase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_clause_base(crate::check::shrink::Shrink sk, crate::check::env::Def d, crate::syntax::decls::FnClause c) {
    return prism_rtl::make_rc<ClauseBase>(sk, d, c);
}


/// ?ResolveCallee: fn G, Text, Text -> ?Text
std::optional<Text> resolve_callee(const crate::check::env::G& g, const Text& m, const Text& n) {
    return is_op_text(n)
        ? resolve_op(g, m, n)
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        auto&& _m = resolve_name(g, m, n);
        if (prism_rtl::is_some(_m)) {
            auto&& k = prism_rtl::some_of(_m);
            _v.set(std::optional(k));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::syntax::lexer::chars::has_prefix(n, Text::lit("@"))
                ? resolve_name(g, m, crate::syntax::lexer::chars::after_first(n))
                : std::optional<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// ?ResolveOp: fn G, Text, Text -> ?Text
std::optional<Text> resolve_op(const crate::check::env::G& g, const Text& m, const Text& op) {
    auto&& _k_opt = crate::check::env::names::resolve_value(g, m, crate::syntax::SName{.sigils = Text::lit(""), .path_ = Array(std::vector{op}), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
    auto&& k_opt = std::get<0>(_k_opt);
    return k_opt;
}


/// IsOpText: fn Text -> Bool
bool is_op_text(const Text& n) {
    return (len_text(n) > Nat(0u)) && (!crate::syntax::lexer::chars::fold_chars(n, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=](std::tuple<bool, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto seen = p0;
                auto ch = p1;
                (prism_rtl::finished(((seen || crate::syntax::lexer::chars::is_upper(ch)) || crate::syntax::lexer::chars::is_lower(ch)) || (ch == Text::lit("_"))));
            });
        });
    }))));
}


/// ?ResolveName: fn G, Text, Text -> ?Text
std::optional<Text> resolve_name(const crate::check::env::G& g, const Text& m, const Text& n) {
    auto marks = crate::check::types::unify::marks_of(n);
    auto path_ = split_on(crate::syntax::lexer::chars::drop_prefix(n, marks), Text::lit("."));
    auto&& _k_opt = crate::check::env::names::resolve_value(g, m, crate::syntax::SName{.sigils = marks, .path_ = path_, .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
    auto&& k_opt = std::get<0>(_k_opt);
    return k_opt;
}


/// NamesInStmt: unbounded fn Stmt -> [Text]
Array<Text> names_in_stmt(const crate::syntax::Stmt& s) {
    return crate::check::shrink::walk::spots_names(crate::check::shrink::walk::stmt_spots(s, Map<Text, crate::check::shrink::Rel>{}));
}


prism_rtl::Turn<Array<Text>> NamesInStmt::cycle() const {
    const auto& s = this->s;
    auto s_1 = s;
    return call_then(crate::check::shrink::walk::start_stmt_spots(s_1, Map<Text, crate::check::shrink::Rel>{}), [=](Array<crate::check::shrink::walk::Spot> stmt_spots_6728) { return prism_rtl::more(prism_rtl::rc(crate::check::shrink::walk::SpotsNames(stmt_spots_6728))); });
}


/// `Start NamesInStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_names_in_stmt(crate::syntax::Stmt s) {
    return prism_rtl::make_rc<NamesInStmt>(s);
}


/// Sccs: unbounded fn [Text], [((Text, [Text]))] -> [ [Text] ]
Array<Array<Text>> sccs(const Array<Text>& keys_, const Array<std::tuple<Text, Array<Text>>>& refs) {
    auto adj = fold(refs, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        return insert(m, k, rs);
    });
    auto rev = fold(refs, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        return fold(rs, m, [&](const Map<Text, Array<Text>>& m2, const Text& r) { return insert(m2, r, crate::prelude::push(or_(crate::prelude::get(m2, r), Array<Text>{}), k)); });
    });
    auto&& _post = run_to_end(fold_job(keys_, std::tuple{Map<Text, bool>{}, Array<Text>{}}, ({
        auto adj_1 = adj;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto adj_1_2 = adj_1;
            entered(once_job([=]() {
            return ({
                auto [seen, out] = p0;
                auto k = p1;
                (prism_rtl::more(prism_rtl::rc(PostVisit(adj_1_2, seen, out, k))));
            });
        }));
        });
    }));
    })));
    auto&& post = std::get<1>(_post);
    auto [ignore2, comps] = run_to_end(fold_job(crate::check::types::reverse2(post), std::tuple{Map<Text, bool>{}, Array<Array<Text>>{}}, ({
        auto rev_1 = rev;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Array<Text>>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Array<Text>>>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, bool>, Array<Array<Text>>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rev_1_2 = rev_1;
            entered(once_job([=]() {
            return ({
                auto [seen, acc] = p0;
                auto k = p1;
                (crate::check::env::has_key(seen, k)
                ? prism_rtl::finished(std::tuple{seen, acc})
                : call_then(start_collect(rev_1_2, seen, Array<Text>{}, k), [=](std::tuple<Map<Text, bool>, Array<Text>> collect_7570) {
                return ({
                    auto [seen2, comp] = collect_7570;
                    (prism_rtl::finished(std::tuple{seen2, crate::prelude::push(acc, comp)}));
                });
            }));
            });
        }));
        });
    }));
    })));
    return filter(comps, [&](const Array<Text>& c) { return (len(c) > Nat(1u)) || fold(c, false, [&](const bool& self_, const Text& k) { return self_ || crate::check::types::has_text(or_(crate::prelude::get(adj, k), Array<Text>{}), k); }); });
}


prism_rtl::Turn<Array<Array<Text>>> Sccs::cycle() const {
    const auto& keys_ = this->keys_;
    const auto& refs = this->refs;
    auto adj = fold(refs, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        return insert(m, k, rs);
    });
    auto rev = fold(refs, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        return fold(rs, m, [&](const Map<Text, Array<Text>>& m2, const Text& r) { return insert(m2, r, crate::prelude::push(or_(crate::prelude::get(m2, r), Array<Text>{}), k)); });
    });
    auto keys__1 = keys_;
    return call_value(fold_job(keys__1, std::tuple{Map<Text, bool>{}, Array<Text>{}}, ({
        auto adj_2 = adj;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto adj_2_3 = adj_2;
            entered(once_job([=]() {
            return ({
                auto [seen, out] = p0;
                auto k = p1;
                (prism_rtl::more(prism_rtl::rc(PostVisit(adj_2_3, seen, out, k))));
            });
        }));
        });
    }));
    })), [=](std::tuple<Map<Text, bool>, Array<Text>> fold_7323) {
        return ({
            auto&& _post = fold_7323;
            auto&& post = std::get<1>(_post);
            call_value(fold_job(crate::check::types::reverse2(post), std::tuple{Map<Text, bool>{}, Array<Array<Text>>{}}, ({
            auto rev_2 = rev;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Array<Text>>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Array<Text>>>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, bool>, Array<Array<Text>>>, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto rev_2_3 = rev_2;
                entered(once_job([=]() {
                return ({
                    auto [seen, acc] = p0;
                    auto k = p1;
                    (crate::check::env::has_key(seen, k)
                    ? prism_rtl::finished(std::tuple{seen, acc})
                    : call_then(start_collect(rev_2_3, seen, Array<Text>{}, k), [=](std::tuple<Map<Text, bool>, Array<Text>> collect_7570) {
                    return ({
                        auto [seen2, comp] = collect_7570;
                        (prism_rtl::finished(std::tuple{seen2, crate::prelude::push(acc, comp)}));
                    });
                }));
                });
            }));
            });
        }));
        })), [=](std::tuple<Map<Text, bool>, Array<Array<Text>>> fold_7425) {
            return ({
                auto [ignore2, comps] = fold_7425;
                (prism_rtl::finished(filter(comps, [&](const Array<Text>& c) { return (len(c) > Nat(1u)) || fold(c, false, [&](const bool& self_, const Text& k) { return self_ || crate::check::types::has_text(or_(crate::prelude::get(adj, k), Array<Text>{}), k); }); })));
            });
        });
        });
    });
}


/// `Start Sccs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Array<Text>>> start_sccs(Array<Text> keys_, Array<std::tuple<Text, Array<Text>>> refs) {
    return prism_rtl::make_rc<Sccs>(keys_, refs);
}


/// PostVisit: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
std::tuple<Map<Text, bool>, Array<Text>> post_visit(const Map<Text, Array<Text>>& adj, const Map<Text, bool>& seen, const Array<Text>& out, const Text& k) {
    return crate::check::env::has_key(seen, k)
        ? std::tuple{seen, out}
        : ({
        auto [seen2, out2] = run_to_end(fold_job(or_(crate::prelude::get(adj, k), Array<Text>{}), std::tuple{insert(seen, k, true), out}, ({
            auto adj_1 = adj;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto adj_1_2 = adj_1;
                entered(once_job([=]() {
                return ({
                    auto [s, o] = p0;
                    auto n = p1;
                    (prism_rtl::more(prism_rtl::rc(PostVisit(adj_1_2, s, o, n))));
                });
            }));
            });
        }));
        })));
        std::tuple{seen2, crate::prelude::push(out2, k)};
    });
}


prism_rtl::Turn<std::tuple<Map<Text, bool>, Array<Text>>> PostVisit::cycle() const {
    const auto& adj = this->adj;
    const auto& seen = this->seen;
    const auto& out = this->out;
    const auto& k = this->k;
    return crate::check::env::has_key(seen, k)
        ? prism_rtl::finished(std::tuple{seen, out})
        : ({
        auto adj_1 = adj;
        auto k_2 = k;
        auto out_3 = out;
        auto seen_4 = seen;
        call_value(fold_job(or_(crate::prelude::get(adj_1, k_2), Array<Text>{}), std::tuple{insert(seen_4, k_2, true), out_3}, ({
        auto adj_1_5 = adj_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto adj_1_5_5 = adj_1_5;
            entered(once_job([=]() {
            return ({
                auto [s, o] = p0;
                auto n = p1;
                (prism_rtl::more(prism_rtl::rc(PostVisit(adj_1_5_5, s, o, n))));
            });
        }));
        });
    }));
    })), [=](std::tuple<Map<Text, bool>, Array<Text>> fold_7954) {
        return ({
            auto [seen2, out2] = fold_7954;
            (prism_rtl::finished(std::tuple{seen2, crate::prelude::push(out2, k_2)}));
        });
    });
    });
}


/// `Start PostVisit, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>> start_post_visit(Map<Text, Array<Text>> adj, Map<Text, bool> seen, Array<Text> out, Text k) {
    return prism_rtl::make_rc<PostVisit>(adj, seen, out, k);
}


/// Collect: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
std::tuple<Map<Text, bool>, Array<Text>> collect(const Map<Text, Array<Text>>& rev, const Map<Text, bool>& seen, const Array<Text>& comp, const Text& k) {
    return crate::check::env::has_key(seen, k)
        ? std::tuple{seen, comp}
        : run_to_end(fold_job(or_(crate::prelude::get(rev, k), Array<Text>{}), std::tuple{insert(seen, k, true), crate::prelude::push(comp, k)}, ({
        auto rev_1 = rev;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rev_1_2 = rev_1;
            entered(once_job([=]() {
            return ({
                auto [s, c] = p0;
                auto n = p1;
                (prism_rtl::more(prism_rtl::rc(Collect(rev_1_2, s, c, n))));
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Map<Text, bool>, Array<Text>>> Collect::cycle() const {
    const auto& rev = this->rev;
    const auto& seen = this->seen;
    const auto& comp = this->comp;
    const auto& k = this->k;
    return crate::check::env::has_key(seen, k)
        ? prism_rtl::finished(std::tuple{seen, comp})
        : fold_job(or_(crate::prelude::get(rev, k), Array<Text>{}), std::tuple{insert(seen, k, true), crate::prelude::push(comp, k)}, ({
        auto rev_1 = rev;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rev_1_2 = rev_1;
            entered(once_job([=]() {
            return ({
                auto [s, c] = p0;
                auto n = p1;
                (prism_rtl::more(prism_rtl::rc(Collect(rev_1_2, s, c, n))));
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start Collect, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>> start_collect(Map<Text, Array<Text>> rev, Map<Text, bool> seen, Array<Text> comp, Text k) {
    return prism_rtl::make_rc<Collect>(rev, seen, comp, k);
}


/// ShrinkComponent: unbounded fn Shrink, St, [Text] -> St
crate::check::types::St shrink_component(const crate::check::shrink::Shrink& sk, const crate::check::types::St& st, const Array<Text>& comp) {
    return fold(comp, true, [&](const bool& ok_, const Text& k) { return ok_ && crate::check::shrink::types::is_unbounded_key(sk.g, crate::check::shrink::types::sig_key_of(sk, or_(crate::prelude::get(sk.local_of, k), k))); })
        ? st
        : ({
        auto graphs = run_to_end(fold_job(sk.fns, Array<crate::check::shrink::Sc>{}, ({
            auto comp_1 = comp;
            auto sk_2 = sk;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::Sc>, crate::check::env::Def> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto comp_1_3 = comp_1;
                auto sk_2_3 = sk_2;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto d = p1;
                    (crate::check::types::has_text(comp_1_3, d.qk)
                    ? call_then(start_call_graphs(sk_2_3, d, comp_1_3), [=](Array<crate::check::shrink::Sc> call_graphs_8869) { return prism_rtl::finished(append(acc, call_graphs_8869)); })
                    : prism_rtl::finished(acc));
                });
            }));
            });
        })));
        })));
        auto closure_1 = crate::check::shrink::summaries::closure(graphs);
        auto bad = filter(closure_1, [&](const crate::check::shrink::Sc& sc) {
            return ((sc.caller == sc.callee) && (crate::check::shrink::summaries::compose(sc, sc)->edges == sc->edges)) && (!fold(sc->edges, false, [&](const bool& seen, const std::tuple<Nat, Nat, bool>& _p1) {
                auto&& a = std::get<0>(_p1);
                auto&& b = std::get<1>(_p1);
                auto&& s = std::get<2>(_p1);
                return seen || ((a == b) && s);
            }));
        });
        ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = index(bad, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& sc = prism_rtl::some_of(_m);
            _v.set(({
                auto s2 = ({
                    crate::check::types::St this_ = st;
                    this_.file = sc->file;
                    this_;
                });
                auto what = sc.arg == Text::lit("")
                    ? Text::lit("")
                    : prism_rtl::cat(" on `", sc.arg, "`");
                auto st3 = crate::check::types::recording::err_fix(s2, Text::lit("may-not-end"), sc.span, prism_rtl::cat("`", crate::check::shrink::types::shown_key(sc.caller), "` calls ", sc.caller == sc.callee
                    ? Text::lit("itself")
                    : prism_rtl::cat("`", crate::check::shrink::types::shown_key(sc.callee), "`"), what, ", not smaller than what it was given"), Text::lit("make an argument shrink (a part taken apart by `match`, or the `? m` of `match n -? 1`), or mark the cycle\'s functions `unbounded fn`"));
                ({
                crate::check::types::St this_ = st3;
                this_.file = st->file;
                this_;
            });
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<crate::check::types::St> ShrinkComponent::cycle() const {
    const auto& sk = this->sk;
    const auto& st = this->st;
    const auto& comp = this->comp;
    return fold(comp, true, [&](const bool& ok_, const Text& k) { return ok_ && crate::check::shrink::types::is_unbounded_key(sk.g, crate::check::shrink::types::sig_key_of(sk, or_(crate::prelude::get(sk.local_of, k), k))); })
        ? prism_rtl::finished(st)
        : ({
        auto comp_1 = comp;
        auto sk_2 = sk;
        auto st_3 = st;
        call_value(fold_job(sk_2.fns, Array<crate::check::shrink::Sc>{}, ({
        auto comp_1_4 = comp_1;
        auto sk_2_4 = sk_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::Sc>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto comp_1_4_4 = comp_1_4;
            auto sk_2_4_4 = sk_2_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto d = p1;
                (crate::check::types::has_text(comp_1_4_4, d.qk)
                ? call_then(start_call_graphs(sk_2_4_4, d, comp_1_4_4), [=](Array<crate::check::shrink::Sc> call_graphs_8869) { return prism_rtl::finished(append(acc, call_graphs_8869)); })
                : prism_rtl::finished(acc));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::shrink::Sc> fold_8804) {
        return ({
            auto graphs = fold_8804;
            call_then(crate::check::shrink::summaries::start_closure(graphs), [=](Array<crate::check::shrink::Sc> closure_8925) {
            return ({
                auto closure = closure_8925;
                auto bad = filter(closure, [&](const crate::check::shrink::Sc& sc) {
                    return ((sc.caller == sc.callee) && (crate::check::shrink::summaries::compose(sc, sc)->edges == sc->edges)) && (!fold(sc->edges, false, [&](const bool& seen, const std::tuple<Nat, Nat, bool>& _p1) {
                        auto&& a = std::get<0>(_p1);
                        auto&& b = std::get<1>(_p1);
                        auto&& s = std::get<2>(_p1);
                        return seen || ((a == b) && s);
                    }));
                });
                ({
                auto&& _m = index(bad, Nat(0u));
                prism_rtl::is_some(_m) ? ({
                auto&& sc = prism_rtl::some_of(_m);
                ({
                auto s2 = ({
                    crate::check::types::St this_ = st_3;
                    this_.file = sc->file;
                    this_;
                });
                auto what = sc.arg == Text::lit("")
                    ? Text::lit("")
                    : prism_rtl::cat(" on `", sc.arg, "`");
                auto st3 = crate::check::types::recording::err_fix(s2, Text::lit("may-not-end"), sc.span, prism_rtl::cat("`", crate::check::shrink::types::shown_key(sc.caller), "` calls ", sc.caller == sc.callee
                    ? Text::lit("itself")
                    : prism_rtl::cat("`", crate::check::shrink::types::shown_key(sc.callee), "`"), what, ", not smaller than what it was given"), Text::lit("make an argument shrink (a part taken apart by `match`, or the `? m` of `match n -? 1`), or mark the cycle\'s functions `unbounded fn`"));
                (prism_rtl::finished(({
                crate::check::types::St this_ = st3;
                this_.file = st_3->file;
                this_;
            })));
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(st_3)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        });
        });
    });
    });
}


/// `Start ShrinkComponent, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_shrink_component(crate::check::shrink::Shrink sk, crate::check::types::St st, Array<Text> comp) {
    return prism_rtl::make_rc<ShrinkComponent>(sk, st, comp);
}


/// CallGraphs: unbounded fn Shrink, Def, [Text] -> [Sc]
Array<crate::check::shrink::Sc> call_graphs(const crate::check::shrink::Shrink& sk, const crate::check::env::Def& d, const Array<Text>& comp) {
    return run_to_end(fold_job(crate::check::shrink::types::def_clauses(d), Array<crate::check::shrink::Sc>{}, ({
        auto sk_1 = sk;
        auto d_2 = d;
        auto comp_3 = comp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_4 = sk_1;
            auto d_2_4 = d_2;
            auto comp_3_4 = comp_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                call_then(start_clause_graphs(sk_1_4, d_2_4, c, comp_3_4), [=](Array<crate::check::shrink::Sc> clause_graphs_9987) { return prism_rtl::finished(append(acc, clause_graphs_9987)); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::check::shrink::Sc>> CallGraphs::cycle() const {
    const auto& sk = this->sk;
    const auto& d = this->d;
    const auto& comp = this->comp;
    return fold_job(crate::check::shrink::types::def_clauses(d), Array<crate::check::shrink::Sc>{}, ({
        auto sk_1 = sk;
        auto d_2 = d;
        auto comp_3 = comp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_4 = sk_1;
            auto d_2_4 = d_2;
            auto comp_3_4 = comp_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                call_then(start_clause_graphs(sk_1_4, d_2_4, c, comp_3_4), [=](Array<crate::check::shrink::Sc> clause_graphs_9987) { return prism_rtl::finished(append(acc, clause_graphs_9987)); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start CallGraphs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_call_graphs(crate::check::shrink::Shrink sk, crate::check::env::Def d, Array<Text> comp) {
    return prism_rtl::make_rc<CallGraphs>(sk, d, comp);
}


/// ClauseGraphs: unbounded fn Shrink, Def, FnClause, [Text] -> [Sc]
Array<crate::check::shrink::Sc> clause_graphs(const crate::check::shrink::Shrink& sk, const crate::check::env::Def& d, const crate::syntax::decls::FnClause& c, const Array<Text>& comp) {
    auto base = clause_base(sk, d, c);
    auto rels = crate::check::shrink::summaries::summary_seeds(sk, d, crate::check::shrink::walk::body_spots(c.body, base), base);
    return run_to_end(fold_job(crate::check::shrink::walk::body_sites(c.body, rels), Array<crate::check::shrink::Sc>{}, ({
        auto sk_1 = sk;
        auto d_2 = d;
        auto comp_3 = comp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_4 = sk_1;
            auto d_2_4 = d_2;
            auto comp_3_4 = comp_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto site = p1;
                ({
                auto&& _m = local_target(sk_1_4, d_2_4, site);
                prism_rtl::is_some(_m) ? ({
                auto&& t = prism_rtl::some_of(_m);
                crate::check::types::has_text(comp_3_4, t)
                ? call_then(start_site_graph(sk_1_4, d_2_4, site, t), [=](crate::check::shrink::Sc site_graph_10345) { return prism_rtl::finished(crate::prelude::push(acc, site_graph_10345)); })
                : prism_rtl::finished(acc);
            })
                : prism_rtl::is_none(_m) ? crate::check::shrink::relations::is_local(site.rels, site.callee) || crate::check::env::has_key(sk_1_4.local_of, d_2_4.qk)
                ? prism_rtl::finished(acc)
                : ({
                auto&& _m = resolve_callee(sk_1_4.g, d_2_4.home, site.callee);
                prism_rtl::is_some(_m) ? ({
                auto&& k = prism_rtl::some_of(_m);
                call_then(crate::check::shrink::types::start_dispatch_targets(sk_1_4, d_2_4, site, k), [=](Array<Text> dispatch_targets_10567) {
                return fold_job(dispatch_targets_10567, acc, ({
                    auto comp_3_4_4 = comp_3_4;
                    auto sk_1_4_4 = sk_1_4;
                    auto d_2_4_4 = d_2_4;
                    auto site_4 = site;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::Sc>, Text> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto comp_3_4_4_5 = comp_3_4_4;
                        auto sk_1_4_4_5 = sk_1_4_4;
                        auto d_2_4_4_5 = d_2_4_4;
                        auto site_4_5 = site_4;
                        entered(once_job([=]() {
                        return ({
                            auto acc2 = p0;
                            auto t = p1;
                            (crate::check::types::has_text(comp_3_4_4_5, t)
                            ? call_then(start_site_graph(sk_1_4_4_5, d_2_4_4_5, site_4_5, t), [=](crate::check::shrink::Sc site_graph_10648) { return prism_rtl::finished(crate::prelude::push(acc2, site_graph_10648)); })
                            : prism_rtl::finished(acc2));
                        });
                    }));
                    });
                })));
                }))->cycle();
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                : throw prism_rtl::Panic("no arm matched");
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::check::shrink::Sc>> ClauseGraphs::cycle() const {
    const auto& sk = this->sk;
    const auto& d = this->d;
    const auto& c = this->c;
    const auto& comp = this->comp;
    auto c_1 = c;
    auto comp_2 = comp;
    auto d_3 = d;
    auto sk_4 = sk;
    return call_then(start_clause_base(sk_4, d_3, c_1), [=](Map<Text, crate::check::shrink::Rel> clause_base_10129) {
        return ({
            auto base = clause_base_10129;
            call_then(crate::check::shrink::walk::start_body_spots(c_1.body, base), [=](Array<crate::check::shrink::walk::Spot> body_spots_10185) {
            return call_then(crate::check::shrink::summaries::start_summary_seeds(sk_4, d_3, body_spots_10185, base), [=](Map<Text, crate::check::shrink::Rel> summary_seeds_10164) {
                return ({
                    auto rels = summary_seeds_10164;
                    call_then(crate::check::shrink::walk::start_body_sites(c_1.body, rels), [=](Array<crate::check::shrink::walk::Site> body_sites_10225) {
                    return fold_job(body_sites_10225, Array<crate::check::shrink::Sc>{}, ({
                        auto sk_4_5 = sk_4;
                        auto d_3_5 = d_3;
                        auto comp_2_5 = comp_2;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto sk_4_5_5 = sk_4_5;
                            auto d_3_5_5 = d_3_5;
                            auto comp_2_5_5 = comp_2_5;
                            entered(once_job([=]() {
                            return ({
                                auto acc = p0;
                                auto site = p1;
                                ({
                                auto&& _m = local_target(sk_4_5_5, d_3_5_5, site);
                                prism_rtl::is_some(_m) ? ({
                                auto&& t = prism_rtl::some_of(_m);
                                crate::check::types::has_text(comp_2_5_5, t)
                                ? call_then(start_site_graph(sk_4_5_5, d_3_5_5, site, t), [=](crate::check::shrink::Sc site_graph_10345) { return prism_rtl::finished(crate::prelude::push(acc, site_graph_10345)); })
                                : prism_rtl::finished(acc);
                            })
                                : prism_rtl::is_none(_m) ? crate::check::shrink::relations::is_local(site.rels, site.callee) || crate::check::env::has_key(sk_4_5_5.local_of, d_3_5_5.qk)
                                ? prism_rtl::finished(acc)
                                : ({
                                auto&& _m = resolve_callee(sk_4_5_5.g, d_3_5_5.home, site.callee);
                                prism_rtl::is_some(_m) ? ({
                                auto&& k = prism_rtl::some_of(_m);
                                call_then(crate::check::shrink::types::start_dispatch_targets(sk_4_5_5, d_3_5_5, site, k), [=](Array<Text> dispatch_targets_10567) {
                                return fold_job(dispatch_targets_10567, acc, ({
                                    auto comp_2_5_5_5 = comp_2_5_5;
                                    auto sk_4_5_5_5 = sk_4_5_5;
                                    auto d_3_5_5_5 = d_3_5_5;
                                    auto site_5 = site;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::Sc>, Text> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto comp_2_5_5_5_6 = comp_2_5_5_5;
                                        auto sk_4_5_5_5_6 = sk_4_5_5_5;
                                        auto d_3_5_5_5_6 = d_3_5_5_5;
                                        auto site_5_6 = site_5;
                                        entered(once_job([=]() {
                                        return ({
                                            auto acc2 = p0;
                                            auto t = p1;
                                            (crate::check::types::has_text(comp_2_5_5_5_6, t)
                                            ? call_then(start_site_graph(sk_4_5_5_5_6, d_3_5_5_5_6, site_5_6, t), [=](crate::check::shrink::Sc site_graph_10648) { return prism_rtl::finished(crate::prelude::push(acc2, site_graph_10648)); })
                                            : prism_rtl::finished(acc2));
                                        });
                                    }));
                                    });
                                })));
                                }))->cycle();
                            });
                            })
                                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                                : throw prism_rtl::Panic("no arm matched");
                            })
                                : throw prism_rtl::Panic("no arm matched");
                            });
                            });
                        }));
                        });
                    })));
                    }))->cycle();
                });
                });
            });
        });
        });
    });
}


/// `Start ClauseGraphs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_clause_graphs(crate::check::shrink::Shrink sk, crate::check::env::Def d, crate::syntax::decls::FnClause c, Array<Text> comp) {
    return prism_rtl::make_rc<ClauseGraphs>(sk, d, c, comp);
}


/// SiteGraph: unbounded fn Shrink, Def, Site, Text -> Sc
crate::check::shrink::Sc site_graph(const crate::check::shrink::Shrink& sk, const crate::check::env::Def& d, const crate::check::shrink::walk::Site& site, const Text& k) {
    auto edges = run_to_end(fold_job(arg_slots(sk, site->args, k), Array<std::tuple<Nat, Nat, bool>>{}, ({
        auto site_1 = site;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Nat, Nat, bool>>>(std::tuple<Array<std::tuple<Nat, Nat, bool>>, std::tuple<Nat, crate::syntax::Arg>>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Nat, Nat, bool>>, std::tuple<Nat, crate::syntax::Arg>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto site_1_2 = site_1;
            entered(once_job([=]() {
            return ({
                auto es = p0;
                auto [j, a] = p1;
                call_then(crate::check::shrink::walk::start_rel_of(site_1_2.rels, a->value), [=](std::optional<crate::check::shrink::Rel> rel_of_10986) {
                return ({
                    prism_rtl::is_some(rel_of_10986) ? ({
                    auto&& r = prism_rtl::some_of(rel_of_10986);
                    prism_rtl::finished(crate::prelude::push(es, std::tuple{r.param, j, r.strict}));
                })
                    : prism_rtl::is_none(rel_of_10986) ? prism_rtl::finished(es)
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
        }));
        });
    }));
    })));
    auto arg_text = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(site->args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(expr_name(a->value));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::check::shrink::Sc{.caller = d.qk, .callee = k, .edges = edges, .span = site.span, .file = d->file, .arg = arg_text};
}


prism_rtl::Turn<crate::check::shrink::Sc> SiteGraph::cycle() const {
    const auto& sk = this->sk;
    const auto& d = this->d;
    const auto& site = this->site;
    const auto& k = this->k;
    auto d_1 = d;
    auto k_2 = k;
    auto site_3 = site;
    auto sk_4 = sk;
    return call_then(start_arg_slots(sk_4, site_3->args, k_2), [=](Array<std::tuple<Nat, crate::syntax::Arg>> arg_slots_10930) {
        return call_value(fold_job(arg_slots_10930, Array<std::tuple<Nat, Nat, bool>>{}, ({
            auto site_3_5 = site_3;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Nat, Nat, bool>>>(std::tuple<Array<std::tuple<Nat, Nat, bool>>, std::tuple<Nat, crate::syntax::Arg>>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Nat, Nat, bool>>, std::tuple<Nat, crate::syntax::Arg>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto site_3_5_5 = site_3_5;
                entered(once_job([=]() {
                return ({
                    auto es = p0;
                    auto [j, a] = p1;
                    call_then(crate::check::shrink::walk::start_rel_of(site_3_5_5.rels, a->value), [=](std::optional<crate::check::shrink::Rel> rel_of_10986) {
                    return ({
                        prism_rtl::is_some(rel_of_10986) ? ({
                        auto&& r = prism_rtl::some_of(rel_of_10986);
                        prism_rtl::finished(crate::prelude::push(es, std::tuple{r.param, j, r.strict}));
                    })
                        : prism_rtl::is_none(rel_of_10986) ? prism_rtl::finished(es)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                });
                });
            }));
            });
        }));
        })), [=](Array<std::tuple<Nat, Nat, bool>> fold_10924) {
            return ({
                auto edges = fold_10924;
                auto arg_text = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = index(site_3->args, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& a = prism_rtl::some_of(_m);
                        _v.set(expr_name(a->value));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit(""));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (prism_rtl::finished(crate::check::shrink::Sc{.caller = d_1.qk, .callee = k_2, .edges = edges, .span = site_3.span, .file = d_1->file, .arg = arg_text}));
            });
        });
    });
}


/// `Start SiteGraph, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::shrink::Sc> start_site_graph(crate::check::shrink::Shrink sk, crate::check::env::Def d, crate::check::shrink::walk::Site site, Text k) {
    return prism_rtl::make_rc<SiteGraph>(sk, d, site, k);
}


/// ArgSlots: unbounded fn Shrink, [Arg], Text -> [((Nat, Arg))]
Array<std::tuple<Nat, crate::syntax::Arg>> arg_slots(const crate::check::shrink::Shrink& sk, const Array<crate::syntax::Arg>& args, const Text& k) {
    auto&& _out = run_to_end(fold_job(args, std::tuple{Nat(0u), Array<std::tuple<Nat, crate::syntax::Arg>>{}}, ({
        auto sk_1 = sk;
        auto k_2 = k;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Nat, Array<std::tuple<Nat, crate::syntax::Arg>>>>(std::tuple<std::tuple<Nat, Array<std::tuple<Nat, crate::syntax::Arg>>>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Nat, Array<std::tuple<Nat, crate::syntax::Arg>>>, crate::syntax::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_3 = sk_1;
            auto k_2_3 = k_2;
            entered(once_job([=]() {
            return ({
                auto [pos, acc] = p0;
                auto a = p1;
                ({
                auto&& _m = a.name;
                prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{pos + Nat(1u), crate::prelude::push(acc, std::tuple{pos, a})})
                : prism_rtl::is_some(_m) ? ({
                auto&& id = prism_rtl::some_of(_m);
                ({
                auto id_3 = id;
                call_then(start_param_named(sk_1_3, k_2_3, id_3.name), [=](std::optional<Nat> param_named_11800) {
                return ({
                    prism_rtl::is_some(param_named_11800) ? ({
                    auto&& j = prism_rtl::some_of(param_named_11800);
                    prism_rtl::finished(std::tuple{pos, crate::prelude::push(acc, std::tuple{j, a})});
                })
                    : prism_rtl::is_none(param_named_11800) ? prism_rtl::finished(std::tuple{pos, acc})
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
    auto&& out = std::get<1>(_out);
    return out;
}


prism_rtl::Turn<Array<std::tuple<Nat, crate::syntax::Arg>>> ArgSlots::cycle() const {
    const auto& sk = this->sk;
    const auto& args = this->args;
    const auto& k = this->k;
    auto args_1 = args;
    auto k_2 = k;
    auto sk_3 = sk;
    return call_value(fold_job(args_1, std::tuple{Nat(0u), Array<std::tuple<Nat, crate::syntax::Arg>>{}}, ({
        auto sk_3_4 = sk_3;
        auto k_2_4 = k_2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Nat, Array<std::tuple<Nat, crate::syntax::Arg>>>>(std::tuple<std::tuple<Nat, Array<std::tuple<Nat, crate::syntax::Arg>>>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Nat, Array<std::tuple<Nat, crate::syntax::Arg>>>, crate::syntax::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_3_4_4 = sk_3_4;
            auto k_2_4_4 = k_2_4;
            entered(once_job([=]() {
            return ({
                auto [pos, acc] = p0;
                auto a = p1;
                ({
                auto&& _m = a.name;
                prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{pos + Nat(1u), crate::prelude::push(acc, std::tuple{pos, a})})
                : prism_rtl::is_some(_m) ? ({
                auto&& id = prism_rtl::some_of(_m);
                ({
                auto id_4 = id;
                call_then(start_param_named(sk_3_4_4, k_2_4_4, id_4.name), [=](std::optional<Nat> param_named_11800) {
                return ({
                    prism_rtl::is_some(param_named_11800) ? ({
                    auto&& j = prism_rtl::some_of(param_named_11800);
                    prism_rtl::finished(std::tuple{pos, crate::prelude::push(acc, std::tuple{j, a})});
                })
                    : prism_rtl::is_none(param_named_11800) ? prism_rtl::finished(std::tuple{pos, acc})
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Nat, Array<std::tuple<Nat, crate::syntax::Arg>>> fold_11673) {
        return ({
            auto&& _out = fold_11673;
            auto&& out = std::get<1>(_out);
            (prism_rtl::finished(out));
        });
    });
}


/// `Start ArgSlots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Nat, crate::syntax::Arg>>> start_arg_slots(crate::check::shrink::Shrink sk, Array<crate::syntax::Arg> args, Text k) {
    return prism_rtl::make_rc<ArgSlots>(sk, args, k);
}


/// ?ParamNamed: unbounded fn Shrink, Text, Text -> ?Nat
std::optional<Nat> param_named(const crate::check::shrink::Shrink& sk, const Text& k, const Text& name) {
    auto clauses = crate::check::shrink::types::def_clauses(or_(crate::prelude::get(sk.by_key, k), crate::check::env::decls::dummy_def()));
    return name == Text::lit("#body")
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Nat>> _v;
        auto&& _m = index(clauses, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            _v.set(len(c.params) > Nat(0u)
                ? std::optional(crate::syntax::lexer::chars::dec(len(c.params)))
                : std::optional<Nat>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::optional<Nat>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    })
        : param_named_in(clauses, name);
}


prism_rtl::Turn<std::optional<Nat>> ParamNamed::cycle() const {
    const auto& sk = this->sk;
    const auto& k = this->k;
    const auto& name = this->name;
    auto clauses = crate::check::shrink::types::def_clauses(or_(crate::prelude::get(sk.by_key, k), crate::check::env::decls::dummy_def()));
    return name == Text::lit("#body")
        ? ({
        auto&& _m = index(clauses, Nat(0u));
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        len(c.params) > Nat(0u)
        ? prism_rtl::finished(std::optional(crate::syntax::lexer::chars::dec(len(c.params))))
        : prism_rtl::finished(std::optional<Nat>{});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Nat>{})
        : throw prism_rtl::Panic("no arm matched");
    })
        : prism_rtl::finished(param_named_in(clauses, name));
}


/// `Start ParamNamed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Nat>> start_param_named(crate::check::shrink::Shrink sk, Text k, Text name) {
    return prism_rtl::make_rc<ParamNamed>(sk, k, name);
}


/// ?ParamNamedIn: unbounded fn [FnClause], Text -> ?Nat
std::optional<Nat> param_named_in(const Array<crate::syntax::decls::FnClause>& clauses, const Text& name) {
    auto found = run_to_end(fold_job(clauses, Array<Nat>{}, ({
        auto name_1 = name;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto name_1_2 = name_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                fold_job(crate::check::errors::range0(len(c.params)), acc, ({
                auto c_2 = c;
                auto name_1_2_3 = name_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_2_3 = c_2;
                    auto name_1_2_3_3 = name_1_2_3;
                    entered(once_job([=]() {
                    return ({
                        auto a2 = p0;
                        auto i = p1;
                        ({
                        auto&& _m = index(c_2_3.params, i);
                        prism_rtl::is_some(_m) ? ({
                        auto&& p_ = prism_rtl::some_of(_m);
                        (param_name_of(p_) == name_1_2_3_3) && (!crate::check::types::has_nat(a2, i))
                        ? prism_rtl::finished(crate::prelude::push(a2, i))
                        : prism_rtl::finished(a2);
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(a2)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
    return len(found) == Nat(1u) ? index(found, Nat(0u)) : std::optional<Nat>{};
}


/// ParamNameOf: unbounded fn Pattern -> Text
Text param_name_of(const crate::syntax::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto text_ = crate::check::env::sname_key(n);
        return crate::syntax::lexer::chars::drop_prefix(text_, crate::check::types::unify::marks_of(text_));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return param_name_of(q);
    }
    {
        return Text::lit("");
    }
}


/// ExprName: fn Expr -> Text
Text expr_name(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::check::env::sname_key(n);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return expr_name(x);
    }
    {
        return Text::lit("");
    }
}


/// ParamRelsOn: unbounded fn (Text ==> Rel), [Pattern] -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> param_rels_on(const Map<Text, crate::check::shrink::Rel>& base, const Array<crate::syntax::Pattern_>& ps) {
    return run_to_end(fold_job(crate::check::errors::range0(len(ps)), crate::check::shrink::relations::hide(base, crate::check::shrink::walk::patterns_names(ps)), ({
        auto ps_1 = ps;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Nat>)>>(prism_rtl::rc([=](std::tuple<Map<Text, crate::check::shrink::Rel>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ps_1_2 = ps_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto i = p1;
                ({
                auto&& _m = index(ps_1_2, i);
                prism_rtl::is_some(_m) ? ({
                auto&& p_ = prism_rtl::some_of(_m);
                ({
                auto&& _m = p_.kind;
                prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                prism_rtl::finished(insert(m, crate::check::env::sname_key(n), crate::check::shrink::Rel{.param = i, .strict = false}));
            })
                : call_then(crate::check::env::names::start_pattern_names(p_), [=](Array<Text> pattern_names_13573) { return prism_rtl::finished(fold(pattern_names_13573, m, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& n) { return insert(m2, n, crate::check::shrink::Rel{.param = i, .strict = true}); })); });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> ParamRelsOn::cycle() const {
    const auto& base = this->base;
    const auto& ps = this->ps;
    auto base_1 = base;
    auto ps_2 = ps;
    return call_then(crate::check::shrink::walk::start_patterns_names(ps_2), [=](Array<Text> patterns_names_13416) {
        return fold_job(crate::check::errors::range0(len(ps_2)), crate::check::shrink::relations::hide(base_1, patterns_names_13416), ({
            auto ps_2_3 = ps_2;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Nat>)>>(prism_rtl::rc([=](std::tuple<Map<Text, crate::check::shrink::Rel>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto ps_2_3_3 = ps_2_3;
                entered(once_job([=]() {
                return ({
                    auto m = p0;
                    auto i = p1;
                    ({
                    auto&& _m = index(ps_2_3_3, i);
                    prism_rtl::is_some(_m) ? ({
                    auto&& p_ = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = p_.kind;
                    prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                    auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                    prism_rtl::finished(insert(m, crate::check::env::sname_key(n), crate::check::shrink::Rel{.param = i, .strict = false}));
                })
                    : call_then(crate::check::env::names::start_pattern_names(p_), [=](Array<Text> pattern_names_13573) { return prism_rtl::finished(fold(pattern_names_13573, m, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& n) { return insert(m2, n, crate::check::shrink::Rel{.param = i, .strict = true}); })); });
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        }));
        }))->cycle();
    });
}


/// `Start ParamRelsOn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_param_rels_on(Map<Text, crate::check::shrink::Rel> base, Array<crate::syntax::Pattern_> ps) {
    return prism_rtl::make_rc<ParamRelsOn>(base, ps);
}

}  // namespace crate::check::shrink::locals


// The module `Check.Shrink.Relations`, from `target/bootstrap/cpp-src/prismc/check/shrink/relations.prism`.
namespace crate::check::shrink::relations {

/// Hide: fn (Text ==> Rel), [Text] -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> hide(const Map<Text, crate::check::shrink::Rel>& m, const Array<Text>& names) {
    return fold(names, m, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& n) { return insert(crate::prelude::remove(crate::prelude::remove(crate::prelude::remove(crate::prelude::remove(m2, n), prism_rtl::cat("ne:", n)), prism_rtl::cat("lamlet:", n)), prism_rtl::cat("lfn:", n)), prism_rtl::cat("local:", n), no_rel()); });
}


/// let noRel
crate::check::shrink::Rel no_rel() {
    return crate::check::shrink::Rel{.param = Nat(0u), .strict = false};
}


/// IsLocal: fn (Text ==> Rel), Text -> Bool
bool is_local(const Map<Text, crate::check::shrink::Rel>& m, const Text& n) {
    return crate::check::env::has_key(m, prism_rtl::cat("local:", n));
}


/// PreIs: fn (Text ==> Rel), Text, Text -> Bool
bool pre_is(const Map<Text, crate::check::shrink::Rel>& m, const Text& n, const Text& bare) {
    return (((n == bare) || (n == prism_rtl::cat("Prelude.", bare))) && crate::check::env::has_key(m, prism_rtl::cat("pre:", n))) && (!is_local(m, n));
}


/// let preludeNames
Array<Text> prelude_names() {
    return Array(std::vector{Text::lit("Drop"), Text::lit("Take"), Text::lit("Filter"), Text::lit("Remove"), Text::lit("Min"), Text::lit("Values"), Text::lit("Keys"), Text::lit("?Step"), Text::lit("Fold"), Text::lit("Each"), Text::lit("Push"), Text::lit("Insert"), Text::lit("Append"), Text::lit("Freeze"), Text::lit("-?"), Text::lit("@Defer"), Text::lit("@Later"), Text::lit("@Run"), Text::lit("@Machine"), Text::lit("@started")});
}


/// PreludeSeeds: fn G, Text -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> prelude_seeds(const crate::check::env::G& g, const Text& h) {
    return fold(prelude_names(), Map<Text, crate::check::shrink::Rel>{}, [&](const Map<Text, crate::check::shrink::Rel>& m, const Text& n) {
        return ({
            auto q = prism_rtl::cat("Prelude.", n);
            !is_prelude_key(g, q)
            ? m
            : fold(Array(std::vector{n, q}), m, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& sp) {
            return crate::check::shrink::locals::resolve_callee(g, h, sp) == std::optional(q)
                ? insert(m2, prism_rtl::cat("pre:", sp), no_rel())
                : m2;
        });
        });
    });
}


/// IsPreludeKey: fn G, Text -> Bool
bool is_prelude_key(const crate::check::env::G& g, const Text& q) {
    auto&& _m = crate::prelude::get(g.vals, q);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        return (crate::syntax::lexer::chars::has_prefix(q, Text::lit("Prelude.")) && (v_.home == Text::lit("Prelude"))) && (v_->file >= g.prelude_from);
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// BlockRels: unbounded fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> block_rels(const Array<crate::syntax::Stmt>& stmts, const Map<Text, crate::check::shrink::Rel>& m) {
    return run_to_end(fold_job(stmts, local_fn_marks(stmts, hide(m, stmts_binders(stmts))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto m2 = p0;
                auto s = p1;
                call_then(start_stmt_rels(s, m2), [=](Map<Text, crate::check::shrink::Rel> stmt_rels_4447) { return prism_rtl::finished(crate::check::passes::cycles::lam_let_rels(s, stmt_rels_4447)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> BlockRels::cycle() const {
    const auto& stmts = this->stmts;
    const auto& m = this->m;
    auto m_1 = m;
    auto stmts_2 = stmts;
    return call_then(start_stmts_binders(stmts_2), [=](Array<Text> stmts_binders_4400) {
        return fold_job(stmts_2, local_fn_marks(stmts_2, hide(m_1, stmts_binders_4400)), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto m2 = p0;
                    auto s = p1;
                    call_then(start_stmt_rels(s, m2), [=](Map<Text, crate::check::shrink::Rel> stmt_rels_4447) { return prism_rtl::finished(crate::check::passes::cycles::lam_let_rels(s, stmt_rels_4447)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start BlockRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_block_rels(Array<crate::syntax::Stmt> stmts, Map<Text, crate::check::shrink::Rel> m) {
    return prism_rtl::make_rc<BlockRels>(stmts, m);
}


/// LocalFnMarks: fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> local_fn_marks(const Array<crate::syntax::Stmt>& stmts, const Map<Text, crate::check::shrink::Rel>& m) {
    return fold(stmts, m, [&](const Map<Text, crate::check::shrink::Rel>& m2, const crate::syntax::Stmt& s) {
        return ({
            auto n_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<Text>> _v;
                auto&& _m = s.kind;
                if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
                    auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
                    _v.set(std::optional(crate::check::env::def_name_text(f.name)));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
                    auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
                    _v.set(std::optional(crate::check::env::sname_key(w.name)));
                    goto _done;
                }
                {
                    _v.set(std::optional<Text>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
            if (prism_rtl::is_some(n_opt)) {
                auto&& n = prism_rtl::some_of(n_opt);
                _v.set(crate::check::env::has_key(m2, prism_rtl::cat("lfn:", n))
                    ? m2
                    : insert(m2, prism_rtl::cat("lfn:", n), crate::check::shrink::Rel{.param = s.span.start, .strict = false}));
                goto _done;
            }
            if (prism_rtl::is_none(n_opt)) {
                _v.set(m2);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    });
}


/// StmtsBinders: unbounded fn [Stmt] -> [Text]
Array<Text> stmts_binders(const Array<crate::syntax::Stmt>& stmts) {
    return run_to_end(fold_job(stmts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                ({
                auto&& _m = s.kind;
                prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                ({
                auto p__1 = p_;
                call_then(crate::check::env::names::start_pattern_names(p__1), [=](Array<Text> pattern_names_5121) { return prism_rtl::finished(crate::check::types::union_texts(acc, pattern_names_5121)); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
                ({
                auto p__1 = p_;
                call_then(crate::check::env::names::start_pattern_names(p__1), [=](Array<Text> pattern_names_5183) { return prism_rtl::finished(crate::check::types::union_texts(acc, pattern_names_5183)); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
                auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
                prism_rtl::finished(crate::check::types::add_text(acc, crate::check::env::def_name_text(f.name)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
                auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
                prism_rtl::finished(crate::check::types::add_text(acc, crate::check::env::sname_key(w.name)));
            })
                : prism_rtl::finished(acc);
            });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> StmtsBinders::cycle() const {
    const auto& stmts = this->stmts;
    return fold_job(stmts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                ({
                auto&& _m = s.kind;
                prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                ({
                auto p__1 = p_;
                call_then(crate::check::env::names::start_pattern_names(p__1), [=](Array<Text> pattern_names_5121) { return prism_rtl::finished(crate::check::types::union_texts(acc, pattern_names_5121)); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
                ({
                auto p__1 = p_;
                call_then(crate::check::env::names::start_pattern_names(p__1), [=](Array<Text> pattern_names_5183) { return prism_rtl::finished(crate::check::types::union_texts(acc, pattern_names_5183)); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
                auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
                prism_rtl::finished(crate::check::types::add_text(acc, crate::check::env::def_name_text(f.name)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
                auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
                prism_rtl::finished(crate::check::types::add_text(acc, crate::check::env::sname_key(w.name)));
            })
                : prism_rtl::finished(acc);
            });
            });
        }));
    })))->cycle();
}


/// `Start StmtsBinders, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_stmts_binders(Array<crate::syntax::Stmt> stmts) {
    return prism_rtl::make_rc<StmtsBinders>(stmts);
}


/// StmtRels: unbounded fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> stmt_rels(const crate::syntax::Stmt& s, const Map<Text, crate::check::shrink::Rel>& m) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        return bind_rels(p_, e, m, false);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        return bind_rels(p_, e, m, true);
    }
    {
        return m;
    }
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> StmtRels::cycle() const {
    const auto& s = this->s;
    const auto& m = this->m;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        prism_rtl::more(prism_rtl::rc(BindRels(p_, e, m, false)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        prism_rtl::more(prism_rtl::rc(BindRels(p_, e, m, true)));
    })
        : prism_rtl::finished(m);
    });
}


/// `Start StmtRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_stmt_rels(crate::syntax::Stmt s, Map<Text, crate::check::shrink::Rel> m) {
    return prism_rtl::make_rc<StmtRels>(s, m);
}


/// BindRels: unbounded fn Pattern, Expr, (Text ==> Rel), Bool -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> bind_rels(const crate::syntax::Pattern_& p_, const crate::syntax::Expr& e, const Map<Text, crate::check::shrink::Rel>& m, const bool& refutable) {
    auto base_opt = crate::check::shrink::walk::rel_of(m, e);
    auto dec_opt = crate::check::shrink::summaries::decrement_of(m, e);
    auto h = non_empty_rels(hide(m, crate::check::env::names::pattern_names(p_)), p_, e, refutable);
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        if (prism_rtl::is_some(base_opt)) {
            auto&& r = prism_rtl::some_of(base_opt);
            return insert(h, crate::check::env::sname_key(n), r);
        }
        if (prism_rtl::is_none(base_opt)) {
            if (prism_rtl::is_some(dec_opt)) {
                auto&& r = prism_rtl::some_of(dec_opt);
                return refutable ? insert(h, crate::check::env::sname_key(n), r) : h;
            }
            if (prism_rtl::is_none(dec_opt)) {
                return h;
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& m5947_1_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& inner = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        if (m5947_1_0 == Text::lit("?")) {
            if (prism_rtl::is_some(dec_opt)) {
                auto&& r = prism_rtl::some_of(dec_opt);
                return fold(crate::check::env::names::pattern_names(inner), h, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& n) { return insert(m2, n, r); });
            }
            if (prism_rtl::is_none(dec_opt)) {
                if (prism_rtl::is_some(base_opt)) {
                    auto&& r = prism_rtl::some_of(base_opt);
                    return fold(crate::check::env::names::pattern_names(inner), h, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& n) { return insert(m2, n, crate::check::shrink::Rel{.param = r.param, .strict = true}); });
                }
                if (prism_rtl::is_none(base_opt)) {
                    return h;
                }
                prism_rtl::unreachable("no arm matched");
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    {
        if (prism_rtl::is_some(base_opt)) {
            auto&& r = prism_rtl::some_of(base_opt);
            return fold(crate::check::env::names::pattern_names(p_), h, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& n) { return insert(m2, n, crate::check::shrink::Rel{.param = r.param, .strict = true}); });
        }
        if (prism_rtl::is_none(base_opt)) {
            return h;
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> BindRels::cycle() const {
    const auto& p_ = this->p_;
    const auto& e = this->e;
    const auto& m = this->m;
    const auto& refutable = this->refutable;
    auto e_1 = e;
    auto m_2 = m;
    auto p__3 = p_;
    auto refutable_4 = refutable;
    return call_then(crate::check::shrink::walk::start_rel_of(m_2, e_1), [=](std::optional<crate::check::shrink::Rel> rel_of_5829) {
        return ({
            auto base_opt = rel_of_5829;
            call_then(crate::check::shrink::summaries::start_decrement_of(m_2, e_1), [=](std::optional<crate::check::shrink::Rel> decrement_of_5856) {
            return ({
                auto dec_opt = decrement_of_5856;
                call_then(crate::check::env::names::start_pattern_names(p__3), [=](Array<Text> pattern_names_5909) {
                return call_then(start_non_empty_rels(hide(m_2, pattern_names_5909), p__3, e_1, refutable_4), [=](Map<Text, crate::check::shrink::Rel> non_empty_rels_5886) {
                    return ({
                        auto h = non_empty_rels_5886;
                        ({
                        auto&& _m = p__3.kind;
                        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                        ({
                        prism_rtl::is_some(base_opt) ? ({
                        auto&& r = prism_rtl::some_of(base_opt);
                        prism_rtl::finished(insert(h, crate::check::env::sname_key(n), r));
                    })
                        : prism_rtl::is_none(base_opt) ? ({
                        prism_rtl::is_some(dec_opt) ? ({
                        auto&& r = prism_rtl::some_of(dec_opt);
                        refutable_4
                        ? prism_rtl::finished(insert(h, crate::check::env::sname_key(n), r))
                        : prism_rtl::finished(h);
                    })
                        : prism_rtl::is_none(dec_opt) ? prism_rtl::finished(h)
                        : throw prism_rtl::Panic("no arm matched");
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    })
                        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) && ({
                        auto&& m5947_1_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
                        auto&& inner = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
                        (m5947_1_0 == Text::lit("?"));
                    }) ? ({
                        auto&& m5947_1_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
                        auto&& inner = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
                        ({
                        prism_rtl::is_some(dec_opt) ? ({
                        auto&& r = prism_rtl::some_of(dec_opt);
                        ({
                        auto inner_5 = inner;
                        auto r_6 = r;
                        call_then(crate::check::env::names::start_pattern_names(inner_5), [=](Array<Text> pattern_names_6217) { return prism_rtl::finished(fold(pattern_names_6217, h, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& n) { return insert(m2, n, r_6); })); });
                    });
                    })
                        : prism_rtl::is_none(dec_opt) ? ({
                        prism_rtl::is_some(base_opt) ? ({
                        auto&& r = prism_rtl::some_of(base_opt);
                        ({
                        auto inner_5 = inner;
                        auto r_6 = r;
                        call_then(crate::check::env::names::start_pattern_names(inner_5), [=](Array<Text> pattern_names_6323) { return prism_rtl::finished(fold(pattern_names_6323, h, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& n) { return insert(m2, n, crate::check::shrink::Rel{.param = r_6.param, .strict = true}); })); });
                    });
                    })
                        : prism_rtl::is_none(base_opt) ? prism_rtl::finished(h)
                        : throw prism_rtl::Panic("no arm matched");
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    })
                        : ({
                        prism_rtl::is_some(base_opt) ? ({
                        auto&& r = prism_rtl::some_of(base_opt);
                        ({
                        auto r_5 = r;
                        call_then(crate::check::env::names::start_pattern_names(p__3), [=](Array<Text> pattern_names_6480) { return prism_rtl::finished(fold(pattern_names_6480, h, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& n) { return insert(m2, n, crate::check::shrink::Rel{.param = r_5.param, .strict = true}); })); });
                    });
                    })
                        : prism_rtl::is_none(base_opt) ? prism_rtl::finished(h)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start BindRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_bind_rels(crate::syntax::Pattern_ p_, crate::syntax::Expr e, Map<Text, crate::check::shrink::Rel> m, bool refutable) {
    return prism_rtl::make_rc<BindRels>(p_, e, m, refutable);
}


/// NonEmptyRels: unbounded fn (Text ==> Rel), Pattern, Expr, Bool -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> non_empty_rels(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Pattern_& p_, const crate::syntax::Expr& e, const bool& refutable) {
    return !refutable
        ? m
        : ({
        __label__ _done;
        prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
        auto&& _m = non_empty_name(p_, e);
        if (prism_rtl::is_some(_m)) {
            auto&& n = prism_rtl::some_of(_m);
            _v.set(crate::check::types::has_text(crate::check::env::names::pattern_names(p_), n)
                ? m
                : insert(m, prism_rtl::cat("ne:", n), no_rel()));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(m);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> NonEmptyRels::cycle() const {
    const auto& m = this->m;
    const auto& p_ = this->p_;
    const auto& e = this->e;
    const auto& refutable = this->refutable;
    return !refutable
        ? prism_rtl::finished(m)
        : ({
        auto&& _m = non_empty_name(p_, e);
        prism_rtl::is_some(_m) ? ({
        auto&& n = prism_rtl::some_of(_m);
        ({
        auto m_1 = m;
        auto p__2 = p_;
        call_then(crate::check::env::names::start_pattern_names(p__2), [=](Array<Text> pattern_names_7016) {
        return crate::check::types::has_text(pattern_names_7016, n)
            ? prism_rtl::finished(m_1)
            : prism_rtl::finished(insert(m_1, prism_rtl::cat("ne:", n), no_rel()));
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start NonEmptyRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_non_empty_rels(Map<Text, crate::check::shrink::Rel> m, crate::syntax::Pattern_ p_, crate::syntax::Expr e, bool refutable) {
    return prism_rtl::make_rc<NonEmptyRels>(m, p_, e, refutable);
}


/// ?NonEmptyName: fn Pattern, Expr -> ?Text
std::optional<Text> non_empty_name(const crate::syntax::Pattern_& p_, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return non_empty_name(p_, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
            auto&& m7216_0_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
            if (m7216_0_0 == Text::lit("?")) {
                return name_of(r);
            }
        }
        if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
            auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
            return non_empty_name(q, e);
        }
        {
            return std::optional<Text>{};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
            auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
            return len(ps) > Nat(0u)
                ? std::optional(crate::check::env::sname_key(n))
                : std::optional<Text>{};
        }
        if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
            auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
            return non_empty_name(q, e);
        }
        {
            return std::optional<Text>{};
        }
    }
    {
        return std::optional<Text>{};
    }
}


/// ?NameOf: fn Expr -> ?Text
std::optional<Text> name_of(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return std::optional(crate::check::env::sname_key(n));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return name_of(x);
    }
    {
        return std::optional<Text>{};
    }
}


/// ArmPatRels: unbounded fn Expr, Arm, (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> arm_pat_rels(const crate::syntax::Expr& s, const crate::syntax::Arm& a, const Map<Text, crate::check::shrink::Rel>& m) {
    auto&& _m = a.pattern;
    if (prism_rtl::is_some(_m)) {
        auto&& p_ = prism_rtl::some_of(_m);
        return bind_rels(p_, s, m, true);
    }
    if (prism_rtl::is_none(_m)) {
        return m;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> ArmPatRels::cycle() const {
    const auto& s = this->s;
    const auto& a = this->a;
    const auto& m = this->m;
    return ({
        auto&& _m = a.pattern;
        prism_rtl::is_some(_m) ? ({
        auto&& p_ = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(BindRels(p_, s, m, true)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ArmPatRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_arm_pat_rels(crate::syntax::Expr s, crate::syntax::Arm a, Map<Text, crate::check::shrink::Rel> m) {
    return prism_rtl::make_rc<ArmPatRels>(s, a, m);
}


/// CondRels: unbounded fn Cond, (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> cond_rels(const crate::syntax::Cond& c, const Map<Text, crate::check::shrink::Rel>& m) {
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
        auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
        return bind_rels(p_, x, m, true);
    }
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
        return m;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> CondRels::cycle() const {
    const auto& c = this->c;
    const auto& m = this->m;
    return ({
        prism_rtl::is<crate::syntax::Cond::CondBind>(c) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
        prism_rtl::more(prism_rtl::rc(BindRels(p_, x, m, true)));
    })
        : prism_rtl::is<crate::syntax::Cond::CondExpr>(c) ? prism_rtl::finished(m)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_cond_rels(crate::syntax::Cond c, Map<Text, crate::check::shrink::Rel> m) {
    return prism_rtl::make_rc<CondRels>(c, m);
}


/// StepRels: unbounded fn (Text ==> Rel), Expr, [Pattern], Nat -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> step_rels(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& coll, const Array<crate::syntax::Pattern_>& ps, const Nat& at_) {
    auto h = hide(m, run_to_end(fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto p_ = p1;
                call_then(crate::check::env::names::start_pattern_names(p_), [=](Array<Text> pattern_names_8705) { return prism_rtl::finished(crate::check::types::union_texts(a, pattern_names_8705)); });
            });
        }));
    })))));
    auto&& _m = crate::check::shrink::walk::rel_of(m, coll);
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return run_to_end(fold_job(drop(ps, at_), h, ({
            auto r_1 = r;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto r_1_2 = r_1;
                entered(once_job([=]() {
                return ({
                    auto m2 = p0;
                    auto p_ = p1;
                    call_then(crate::check::env::names::start_pattern_names(p_), [=](Array<Text> pattern_names_8799) { return prism_rtl::finished(fold(pattern_names_8799, m2, [&](const Map<Text, crate::check::shrink::Rel>& m3, const Text& n) { return insert(m3, n, crate::check::shrink::Rel{.param = r_1_2.param, .strict = true}); })); });
                });
            }));
            });
        }));
        })));
    }
    if (prism_rtl::is_none(_m)) {
        return h;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> StepRels::cycle() const {
    const auto& m = this->m;
    const auto& coll = this->coll;
    const auto& ps = this->ps;
    const auto& at_ = this->at_;
    auto at__1 = at_;
    auto coll_2 = coll;
    auto m_3 = m;
    auto ps_4 = ps;
    return call_value(fold_job(ps_4, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto p_ = p1;
                call_then(crate::check::env::names::start_pattern_names(p_), [=](Array<Text> pattern_names_8705) { return prism_rtl::finished(crate::check::types::union_texts(a, pattern_names_8705)); });
            });
        }));
    }))), [=](Array<Text> fold_8667) {
        return ({
            auto h = hide(m_3, fold_8667);
            call_then(crate::check::shrink::walk::start_rel_of(m_3, coll_2), [=](std::optional<crate::check::shrink::Rel> rel_of_8732) {
            return ({
                prism_rtl::is_some(rel_of_8732) ? ({
                auto&& r = prism_rtl::some_of(rel_of_8732);
                fold_job(drop(ps_4, at__1), h, ({
                auto r_5 = r;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Pattern_> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto r_5_6 = r_5;
                    entered(once_job([=]() {
                    return ({
                        auto m2 = p0;
                        auto p_ = p1;
                        call_then(crate::check::env::names::start_pattern_names(p_), [=](Array<Text> pattern_names_8799) { return prism_rtl::finished(fold(pattern_names_8799, m2, [&](const Map<Text, crate::check::shrink::Rel>& m3, const Text& n) { return insert(m3, n, crate::check::shrink::Rel{.param = r_5_6.param, .strict = true}); })); });
                    });
                }));
                });
            }));
            }))->cycle();
            })
                : prism_rtl::is_none(rel_of_8732) ? prism_rtl::finished(h)
                : throw prism_rtl::Panic("no arm matched");
            });
        });
        });
    });
}


/// `Start StepRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_step_rels(Map<Text, crate::check::shrink::Rel> m, crate::syntax::Expr coll, Array<crate::syntax::Pattern_> ps, Nat at_) {
    return prism_rtl::make_rc<StepRels>(m, coll, ps, at_);
}

}  // namespace crate::check::shrink::relations
