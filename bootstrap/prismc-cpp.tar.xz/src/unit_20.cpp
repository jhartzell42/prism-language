// The module `Check.Shrink.Calls`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/shrink/calls/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Shrink.Calls`, from `target/bootstrap/cpp-src/prismc/check/shrink/calls.prism`.
namespace crate::check::shrink::calls {

void Slot_::show(Printer& p) const {
    p.record("Slot", {{"owner", owner}, {"at", at}, {"arity", arity}});
}

Pod Slot_::to_pod() const {
    return Pod::record("Slot", {{"owner", prism_rtl::to_pod(owner)}, {"at", prism_rtl::to_pod(at)}, {"arity", prism_rtl::to_pod(arity)}});
}

Result<Slot_> Slot_::from_pod(const Pod& whole) {
    return Slot_{.owner = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "owner")))), .at = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "at")))), .arity = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "arity"))))};
}


/// HofSeeds: unbounded fn Shrink, [Text] -> (Text ==> (Text ==> Rel))
Map<Text, Map<Text, crate::check::shrink::Rel>> hof_seeds(const crate::check::shrink::Shrink& sk_p0, const Array<Text>& homes_p1) {
    auto cands_p2 = hof_candidates(sk_p0);
    auto cleared_p3 = clear_slots(sk_p0, homes_p1, cands_p2, Nat(0u));
    auto sums_p4 = slot_sums(sk_p0, homes_p1, cleared_p3, top_sums(cleared_p3), Nat(0u));
    return fold(homes_p1, Map<Text, Map<Text, crate::check::shrink::Rel>>{}, [&](const Map<Text, Map<Text, crate::check::shrink::Rel>>& m_p5, const Text& h_p6) { return insert(m_p5, h_p6, slot_seeds(sk_p0, h_p6, cleared_p3, sums_p4, false)); });
}


prism_rtl::Turn<Map<Text, Map<Text, crate::check::shrink::Rel>>> HofSeeds::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& homes_p1 = this->homes_p1;
    auto cands_p2 = hof_candidates(sk_p0);
    auto homes_p1_1 = homes_p1;
    auto sk_p0_2 = sk_p0;
    return call_then(start_clear_slots(sk_p0_2, homes_p1_1, cands_p2, Nat(0u)), [=](Array<Slot_> clear_slots_2618) {
        return ({
            auto cleared_p3 = clear_slots_2618;
            call_then(start_slot_sums(sk_p0_2, homes_p1_1, cleared_p3, top_sums(cleared_p3), Nat(0u)), [=](Map<Text, crate::check::shrink::Rel> slot_sums_2664) {
            return ({
                auto sums_p4 = slot_sums_2664;
                (prism_rtl::finished(fold(homes_p1_1, Map<Text, Map<Text, crate::check::shrink::Rel>>{}, [&](const Map<Text, Map<Text, crate::check::shrink::Rel>>& m_p5, const Text& h_p6) { return insert(m_p5, h_p6, slot_seeds(sk_p0_2, h_p6, cleared_p3, sums_p4, false)); })));
            });
        });
        });
    });
}


/// `Start HofSeeds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Map<Text, crate::check::shrink::Rel>>> start_hof_seeds(crate::check::shrink::Shrink sk_p0, Array<Text> homes_p1) {
    return prism_rtl::make_rc<HofSeeds>(sk_p0, homes_p1);
}


/// HofCandidates: fn Shrink -> [Slot]
Array<Slot_> hof_candidates(const crate::check::shrink::Shrink& sk_p0) {
    return fold(sk_p0.fns, Array<Slot_>{}, [&](const Array<Slot_>& acc_p1, const crate::check::env::Def& d_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Slot_>> _v;
            auto&& _m = prism_rtl::deref(d_p2).body;
            if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
                auto&& clauses_p3 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Slot_>> _v;
                    auto&& _m = crate::prelude::get(prism_rtl::deref(sk_p0.g).vals, prism_rtl::deref(d_p2).qk);
                    if (prism_rtl::is_some(_m)) {
                        auto&& v_p4 = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Slot_>> _v;
                            auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p4).scheme).ty;
                            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                                auto&& ps_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
                                _v.set(fold(crate::check::errors::range0(len(ps_p5)), acc_p1, [&](const Array<Slot_>& a2_p6, const Nat& j_p7) {
                                    return ({
                                        __label__ _done;
                                        prism_rtl::Slot<Array<Slot_>> _v;
                                        auto&& _m = index(ps_p5, j_p7);
                                        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m))) {
                                            auto&& fps_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m)).a1;
                                            _v.set(fold(clauses_p3, true, [&](const bool& ok_p9, const crate::syntax::decls::FnClause& c_pa) { return prism_rtl::deref(ok_p9) && slot_named(c_pa, j_p7); })
                                                ? crate::prelude::push(a2_p6, Slot_{.owner = prism_rtl::deref(d_p2).qk, .at = j_p7, .arity = len(fps_p8)})
                                                : a2_p6);
                                            goto _done;
                                        }
                                        {
                                            _v.set(a2_p6);
                                            goto _done;
                                        }
                                    _done:
                                        _v.take();
                                    });
                                }));
                                goto _done;
                            }
                            {
                                _v.set(acc_p1);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc_p1);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// SlotNamed: fn FnClause, Nat -> Bool
bool slot_named(const crate::syntax::decls::FnClause& c_p0, const Nat& j_p1) {
    auto&& _m = index(c_p0.params, j_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& p_p2 = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p2).kind);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            return true;
        }
        if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// SlotName: fn FnClause, Nat -> Text
Text slot_name(const crate::syntax::decls::FnClause& c_p0, const Nat& j_p1) {
    auto&& _m = index(c_p0.params, j_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& p_p2 = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p2).kind);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n_p3 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return crate::check::env::sname_key(n_p3);
        }
        {
            return Text::lit("");
        }
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SlotSeeds: fn Shrink, Text, [Slot], (Text ==> Rel), Bool -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> slot_seeds(const crate::check::shrink::Shrink& sk_p0, const Text& h_p1, const Array<Slot_>& slots_p2, const Map<Text, crate::check::shrink::Rel>& sums_p3, const bool& with_top_p4) {
    auto pre_p5 = or_(crate::prelude::get(sk_p0.seeds, h_p1), Map<Text, crate::check::shrink::Rel>{});
    auto start_p6 = with_top_p4
        ? insert(pre_p5, Text::lit("⊤"), crate::check::shrink::Rel{.param = crate::check::shrink::walk::top_param(), .strict = false})
        : pre_p5;
    return fold(slots_p2, start_p6, [&](const Map<Text, crate::check::shrink::Rel>& m_p7, const Slot_& sl_p8) {
        return fold(spellings(sk_p0.g, h_p1, prism_rtl::deref(sl_p8).owner), m_p7, [&](const Map<Text, crate::check::shrink::Rel>& m2_p9, const Text& sp_pa) {
            return ({
                auto m3_pb = insert(m2_p9, prism_rtl::cat("acc:", sp_pa, ":", prism_rtl::deref(sl_p8).at), crate::check::shrink::Rel{.param = prism_rtl::deref(sl_p8).arity, .strict = false});
                fold(crate::check::errors::range0(prism_rtl::deref(sl_p8).arity), m3_pb, [&](const Map<Text, crate::check::shrink::Rel>& m4_pc, const Nat& q_pd) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
                    auto&& _m = crate::prelude::get(sums_p3, prism_rtl::cat(prism_rtl::deref(sl_p8).owner, ":", prism_rtl::deref(sl_p8).at, ":", q_pd));
                    if (prism_rtl::is_some(_m)) {
                        auto&& r_pe = prism_rtl::some_of(_m);
                        _v.set((prism_rtl::deref(r_pe).param == crate::check::shrink::walk::top_param()) && (!with_top_p4)
                            ? m4_pc
                            : insert(m4_pc, prism_rtl::cat("sum:", sp_pa, ":", prism_rtl::deref(sl_p8).at, ":", q_pd), r_pe));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(m4_pc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
            });
            });
        });
    });
}


/// Spellings: fn G, Text, Text -> [Text]
Array<Text> spellings(const crate::check::env::G& g_p0, const Text& h_p1, const Text& k_p2) {
    return filter(crate::check::types::add_text(Array(std::vector{crate::check::types::bare_name(k_p2)}), k_p2), [&](const Text& sp_p3) { return crate::check::shrink::locals::resolve_name(g_p0, h_p1, sp_p3) == std::optional(k_p2); });
}


/// ClearSlots: unbounded fn Shrink, [Text], [Slot], Nat -> [Slot]
Array<Slot_> clear_slots(const crate::check::shrink::Shrink& sk_p0, const Array<Text>& homes_p1, const Array<Slot_>& slots_p2, const Nat& round_p3) {
    auto sks_p4 = seeds_for(sk_p0, homes_p1, slots_p2, Map<Text, crate::check::shrink::Rel>{}, false);
    auto kept_p5 = run_to_end(filter_job(slots_p2, ({
        auto sks_p4_1 = sks_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Slot_)>>(prism_rtl::rc([=, sks_p4_1 = std::move(sks_p4_1)](Slot_ p0) {
        return ({
            auto sks_p4_1_2 = sks_p4_1;
            entered(once_job([=, sks_p4_1_2 = std::move(sks_p4_1_2)]() {
            return ({
                auto sl_p6 = p0;
                call_then(start_slot_escapes(sks_p4_1_2, sl_p6), [=](bool slot_escapes_5090) { return prism_rtl::finished(!slot_escapes_5090); });
            });
        }));
        });
    })));
    })));
    return len(kept_p5) == len(slots_p2)
        ? kept_p5
        : round_p3 > Nat(20u)
        ? Array<Slot_>{}
        : clear_slots(sk_p0, homes_p1, kept_p5, round_p3 + Nat(1u));
}


prism_rtl::Turn<Array<Slot_>> ClearSlots::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& homes_p1 = this->homes_p1;
    const auto& slots_p2 = this->slots_p2;
    const auto& round_p3 = this->round_p3;
    auto sks_p4 = seeds_for(sk_p0, homes_p1, slots_p2, Map<Text, crate::check::shrink::Rel>{}, false);
    auto homes_p1_1 = homes_p1;
    auto round_p3_2 = round_p3;
    auto sk_p0_3 = sk_p0;
    auto slots_p2_4 = slots_p2;
    return call_value(filter_job(slots_p2_4, ({
        auto sks_p4_5 = sks_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Slot_)>>(prism_rtl::rc([=, sks_p4_5 = std::move(sks_p4_5)](Slot_ p0) {
        return ({
            auto sks_p4_5_6 = sks_p4_5;
            entered(once_job([=, sks_p4_5_6 = std::move(sks_p4_5_6)]() {
            return ({
                auto sl_p6 = p0;
                call_then(start_slot_escapes(sks_p4_5_6, sl_p6), [=](bool slot_escapes_5090) { return prism_rtl::finished(!slot_escapes_5090); });
            });
        }));
        });
    })));
    })), [=](Array<Slot_> filter_5065) {
        return ({
            auto kept_p5 = filter_5065;
            len(kept_p5) == len(slots_p2_4)
            ? prism_rtl::finished(kept_p5)
            : round_p3_2 > Nat(20u)
            ? prism_rtl::finished(Array<Slot_>{})
            : prism_rtl::more(prism_rtl::rc(ClearSlots(sk_p0_3, homes_p1_1, kept_p5, round_p3_2 + Nat(1u))));
        });
    });
}


/// `Start ClearSlots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Slot_>> start_clear_slots(crate::check::shrink::Shrink sk_p0, Array<Text> homes_p1, Array<Slot_> slots_p2, Nat round_p3) {
    return prism_rtl::make_rc<ClearSlots>(sk_p0, homes_p1, slots_p2, round_p3);
}


/// SeedsFor: fn Shrink, [Text], [Slot], (Text ==> Rel), Bool -> Shrink
crate::check::shrink::Shrink seeds_for(const crate::check::shrink::Shrink& sk_p0, const Array<Text>& homes_p1, const Array<Slot_>& slots_p2, const Map<Text, crate::check::shrink::Rel>& sums_p3, const bool& with_top_p4) {
    crate::check::shrink::Shrink this_ = sk_p0;
    this_.seeds = fold(homes_p1, Map<Text, Map<Text, crate::check::shrink::Rel>>{}, [&](const Map<Text, Map<Text, crate::check::shrink::Rel>>& m_p5, const Text& h_p6) { return insert(m_p5, h_p6, slot_seeds(sk_p0, h_p6, slots_p2, sums_p3, with_top_p4)); });
    return this_;
}


/// SlotEscapes: unbounded fn Shrink, Slot -> Bool
bool slot_escapes(const crate::check::shrink::Shrink& sk_p0, const Slot_& sl_p1) {
    auto&& _m = crate::prelude::get(sk_p0.by_key, sl_p1.owner);
    if (prism_rtl::is_some(_m)) {
        auto&& d_p2 = prism_rtl::some_of(_m);
        return run_to_end(fold_job(crate::check::shrink::types::def_clauses(d_p2), false, ({
            auto sl_p1_1 = sl_p1;
            auto sk_p0_2 = sk_p0;
            auto d_p2_3 = d_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sl_p1_1 = std::move(sl_p1_1), sk_p0_2 = std::move(sk_p0_2), d_p2_3 = std::move(d_p2_3)](std::tuple<bool, crate::syntax::decls::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto sl_p1_1_4 = sl_p1_1;
                auto sk_p0_2_4 = sk_p0_2;
                auto d_p2_3_4 = d_p2_3;
                entered(once_job([=, sl_p1_1_4 = std::move(sl_p1_1_4), sk_p0_2_4 = std::move(sk_p0_2_4), d_p2_3_4 = std::move(d_p2_3_4)]() {
                return ({
                    auto seen_p3 = p0;
                    auto c_p4 = p1;
                    ({
                    auto n_p5 = slot_name(c_p4, sl_p1_1_4.at);
                    (std::move(seen_p3) || (n_p5 == Text::lit(""))
                    ? prism_rtl::finished(std::move(seen_p3))
                    : call_then(crate::check::shrink::locals::start_clause_base(sk_p0_2_4, d_p2_3_4, c_p4), [=](Map<Text, crate::check::shrink::Rel> clause_base_5891) {
                    return call_then(crate::check::shrink::walk::start_body_spots(prism_rtl::deref(c_p4).body, clause_base_5891), [=](Array<crate::check::shrink::walk::Spot> body_spots_5872) {
                        return fold_job(body_spots_5872, false, ({
                            auto n_p5_4 = n_p5;
                            auto sl_p1_1_4_5 = sl_p1_1_4;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, n_p5_4 = std::move(n_p5_4), sl_p1_1_4_5 = std::move(sl_p1_1_4_5)](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto n_p5_4_5 = n_p5_4;
                                auto sl_p1_1_4_5_5 = sl_p1_1_4_5;
                                entered(once_job([=, n_p5_4_5 = std::move(n_p5_4_5), sl_p1_1_4_5_5 = std::move(sl_p1_1_4_5_5)]() {
                                return ({
                                    auto esc_p6 = p0;
                                    auto sp_p7 = p1;
                                    (prism_rtl::finished(std::move(esc_p6) || spot_escapes(sp_p7, n_p5_4_5, sl_p1_1_4_5_5.at)));
                                });
                            }));
                            });
                        })));
                        }))->cycle();
                    });
                }));
                });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is_none(_m)) {
        return true;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> SlotEscapes::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& sl_p1 = this->sl_p1;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(sk_p0).by_key, prism_rtl::deref(sl_p1).owner);
        prism_rtl::is_some(_m) ? ({
        auto&& d_p2 = prism_rtl::some_of(_m);
        fold_job(crate::check::shrink::types::def_clauses(d_p2), false, ({
        auto sl_p1_1 = sl_p1;
        auto sk_p0_2 = sk_p0;
        auto d_p2_3 = d_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sl_p1_1 = std::move(sl_p1_1), sk_p0_2 = std::move(sk_p0_2), d_p2_3 = std::move(d_p2_3)](std::tuple<bool, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sl_p1_1_4 = sl_p1_1;
            auto sk_p0_2_4 = sk_p0_2;
            auto d_p2_3_4 = d_p2_3;
            entered(once_job([=, sl_p1_1_4 = std::move(sl_p1_1_4), sk_p0_2_4 = std::move(sk_p0_2_4), d_p2_3_4 = std::move(d_p2_3_4)]() {
            return ({
                auto seen_p3 = p0;
                auto c_p4 = p1;
                ({
                auto n_p5 = slot_name(c_p4, prism_rtl::deref(sl_p1_1_4).at);
                (std::move(seen_p3) || (n_p5 == Text::lit(""))
                ? prism_rtl::finished(std::move(seen_p3))
                : call_then(crate::check::shrink::locals::start_clause_base(sk_p0_2_4, d_p2_3_4, c_p4), [=](Map<Text, crate::check::shrink::Rel> clause_base_5891) {
                return call_then(crate::check::shrink::walk::start_body_spots(prism_rtl::deref(c_p4).body, clause_base_5891), [=](Array<crate::check::shrink::walk::Spot> body_spots_5872) {
                    return fold_job(body_spots_5872, false, ({
                        auto n_p5_4 = n_p5;
                        auto sl_p1_1_4_5 = sl_p1_1_4;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, n_p5_4 = std::move(n_p5_4), sl_p1_1_4_5 = std::move(sl_p1_1_4_5)](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto n_p5_4_5 = n_p5_4;
                            auto sl_p1_1_4_5_5 = sl_p1_1_4_5;
                            entered(once_job([=, n_p5_4_5 = std::move(n_p5_4_5), sl_p1_1_4_5_5 = std::move(sl_p1_1_4_5_5)]() {
                            return ({
                                auto esc_p6 = p0;
                                auto sp_p7 = p1;
                                (prism_rtl::finished(std::move(esc_p6) || spot_escapes(sp_p7, n_p5_4_5, prism_rtl::deref(sl_p1_1_4_5_5).at)));
                            });
                        }));
                        });
                    })));
                    }))->cycle();
                });
            }));
            });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(true)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SlotEscapes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_slot_escapes(crate::check::shrink::Shrink sk_p0, Slot_ sl_p1) {
    return prism_rtl::make_rc<SlotEscapes>(sk_p0, sl_p1);
}


/// SpotEscapes: unbounded fn Spot, Text, Nat -> Bool
bool spot_escapes(const crate::check::shrink::walk::Spot& sp_p0, const Text& n_p1, const Nat& j_p2) {
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(sp_p0)) {
        auto&& e_p3 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(sp_p0).a0;
        auto&& m_p4 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(sp_p0).a1;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p3).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& x_p5 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return (crate::check::env::sname_key(x_p5) == n_p1) && is_slot_param(m_p4, n_p1, j_p2);
        }
        {
            return fold(crate::check::shrink::walk::spot_sites(sp_p0), false, [&](const bool& seen_p6, const crate::check::shrink::walk::Site& site_p7) { return prism_rtl::deref(seen_p6) || (((prism_rtl::deref(site_p7).callee == n_p1) && is_slot_param(prism_rtl::deref(site_p7).rels, n_p1, j_p2)) && crate::check::env::has_key(prism_rtl::deref(site_p7).rels, Text::lit("lam:"))); });
        }
    }
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(sp_p0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> SpotEscapes::cycle() const {
    const auto& sp_p0 = this->sp_p0;
    const auto& n_p1 = this->n_p1;
    const auto& j_p2 = this->j_p2;
    return ({
        prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(sp_p0) ? ({
        auto&& e_p3 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(sp_p0).a0;
        auto&& m_p4 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(sp_p0).a1;
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p3).kind);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& x_p5 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        prism_rtl::finished((crate::check::env::sname_key(x_p5) == n_p1) && is_slot_param(m_p4, n_p1, j_p2));
    })
        : ({
        auto j_p2_1 = j_p2;
        auto n_p1_2 = n_p1;
        auto sp_p0_3 = sp_p0;
        call_then(crate::check::shrink::walk::start_spot_sites(sp_p0_3), [=, j_p2_1 = std::move(j_p2_1), n_p1_2 = std::move(n_p1_2)](Array<crate::check::shrink::walk::Site> spot_sites_6182) { return prism_rtl::finished(fold(spot_sites_6182, false, [&](const bool& seen_p6, const crate::check::shrink::walk::Site& site_p7) { return prism_rtl::deref(seen_p6) || (((prism_rtl::deref(site_p7).callee == n_p1_2) && is_slot_param(prism_rtl::deref(site_p7).rels, n_p1_2, j_p2_1)) && crate::check::env::has_key(prism_rtl::deref(site_p7).rels, Text::lit("lam:"))); })); });
    });
    });
    })
        : prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(sp_p0) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotEscapes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_spot_escapes(crate::check::shrink::walk::Spot sp_p0, Text n_p1, Nat j_p2) {
    return prism_rtl::make_rc<SpotEscapes>(sp_p0, n_p1, j_p2);
}


/// IsSlotParam: fn (Text ==> Rel), Text, Nat -> Bool
bool is_slot_param(const Map<Text, crate::check::shrink::Rel>& m_p0, const Text& n_p1, const Nat& j_p2) {
    return crate::prelude::get(m_p0, n_p1) == std::optional(crate::check::shrink::Rel{.param = j_p2, .strict = false});
}


/// TopSums: fn [Slot] -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> top_sums(const Array<Slot_>& slots_p0) {
    return fold(slots_p0, Map<Text, crate::check::shrink::Rel>{}, [&](const Map<Text, crate::check::shrink::Rel>& m_p1, const Slot_& sl_p2) { return fold(crate::check::errors::range0(prism_rtl::deref(sl_p2).arity), m_p1, [&](const Map<Text, crate::check::shrink::Rel>& m2_p3, const Nat& q_p4) { return insert(m2_p3, prism_rtl::cat(prism_rtl::deref(sl_p2).owner, ":", prism_rtl::deref(sl_p2).at, ":", q_p4), crate::check::shrink::Rel{.param = crate::check::shrink::walk::top_param(), .strict = false}); }); });
}


/// SlotSums: unbounded fn Shrink, [Text], [Slot], (Text ==> Rel), Nat -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> slot_sums(const crate::check::shrink::Shrink& sk_p0, const Array<Text>& homes_p1, const Array<Slot_>& slots_p2, const Map<Text, crate::check::shrink::Rel>& sums_p3, const Nat& round_p4) {
    auto sks_p5 = seeds_for(sk_p0, homes_p1, slots_p2, sums_p3, true);
    auto next_p6 = run_to_end(fold_job(slots_p2, Map<Text, crate::check::shrink::Rel>{}, ({
        auto sks_p5_1 = sks_p5;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Slot_>)>>(prism_rtl::rc([=, sks_p5_1 = std::move(sks_p5_1)](std::tuple<Map<Text, crate::check::shrink::Rel>, Slot_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sks_p5_1_2 = sks_p5_1;
            entered(once_job([=, sks_p5_1_2 = std::move(sks_p5_1_2)]() {
            return ({
                auto m_p7 = p0;
                auto sl_p8 = p1;
                call_then(start_slot_calls(sks_p5_1_2, sl_p8), [=, m_p7 = std::move(m_p7)](Array<crate::check::shrink::walk::Site> slot_calls_7327) {
                return ({
                    auto calls_p9 = slot_calls_7327;
                    fold_job(crate::check::errors::range0(prism_rtl::deref(sl_p8).arity), m_p7, ({
                    auto calls_p9_2 = calls_p9;
                    auto sl_p8_3 = sl_p8;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Nat>)>>(prism_rtl::rc([=, calls_p9_2 = std::move(calls_p9_2), sl_p8_3 = std::move(sl_p8_3)](std::tuple<Map<Text, crate::check::shrink::Rel>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto calls_p9_2_4 = calls_p9_2;
                        auto sl_p8_3_4 = sl_p8_3;
                        entered(once_job([=, calls_p9_2_4 = std::move(calls_p9_2_4), sl_p8_3_4 = std::move(sl_p8_3_4)]() {
                        return ({
                            auto m2_pa = p0;
                            auto q_pb = p1;
                            call_then(start_meet_args(calls_p9_2_4, q_pb), [=, m2_pa = std::move(m2_pa)](std::optional<crate::check::shrink::Rel> meet_args_7395) {
                            return ({
                                prism_rtl::is_some(meet_args_7395) ? ({
                                auto&& r_pc = prism_rtl::some_of(meet_args_7395);
                                prism_rtl::finished(insert(m2_pa, prism_rtl::cat(prism_rtl::deref(sl_p8_3_4).owner, ":", prism_rtl::deref(sl_p8_3_4).at, ":", q_pb), r_pc));
                            })
                                : prism_rtl::is_none(meet_args_7395) ? prism_rtl::finished(m2_pa)
                                : throw prism_rtl::Panic("no arm matched");
                            });
                        });
                        });
                    }));
                    });
                }));
                }))->cycle();
                });
            });
            });
        }));
        });
    }));
    })));
    return next_p6 == sums_p3
        ? next_p6
        : round_p4 > Nat(12u)
        ? Map<Text, crate::check::shrink::Rel>{}
        : slot_sums(sk_p0, homes_p1, slots_p2, next_p6, round_p4 + Nat(1u));
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> SlotSums::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& homes_p1 = this->homes_p1;
    const auto& slots_p2 = this->slots_p2;
    const auto& sums_p3 = this->sums_p3;
    const auto& round_p4 = this->round_p4;
    auto sks_p5 = seeds_for(sk_p0, homes_p1, slots_p2, sums_p3, true);
    auto homes_p1_1 = homes_p1;
    auto round_p4_2 = round_p4;
    auto sk_p0_3 = sk_p0;
    auto slots_p2_4 = slots_p2;
    auto sums_p3_5 = sums_p3;
    return call_value(fold_job(slots_p2_4, Map<Text, crate::check::shrink::Rel>{}, ({
        auto sks_p5_6 = sks_p5;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Slot_>)>>(prism_rtl::rc([=, sks_p5_6 = std::move(sks_p5_6)](std::tuple<Map<Text, crate::check::shrink::Rel>, Slot_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sks_p5_6_7 = sks_p5_6;
            entered(once_job([=, sks_p5_6_7 = std::move(sks_p5_6_7)]() {
            return ({
                auto m_p7 = p0;
                auto sl_p8 = p1;
                call_then(start_slot_calls(sks_p5_6_7, sl_p8), [=, m_p7 = std::move(m_p7)](Array<crate::check::shrink::walk::Site> slot_calls_7327) {
                return ({
                    auto calls_p9 = slot_calls_7327;
                    fold_job(crate::check::errors::range0(prism_rtl::deref(sl_p8).arity), m_p7, ({
                    auto calls_p9_7 = calls_p9;
                    auto sl_p8_8 = sl_p8;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Nat>)>>(prism_rtl::rc([=, calls_p9_7 = std::move(calls_p9_7), sl_p8_8 = std::move(sl_p8_8)](std::tuple<Map<Text, crate::check::shrink::Rel>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto calls_p9_7_9 = calls_p9_7;
                        auto sl_p8_8_9 = sl_p8_8;
                        entered(once_job([=, calls_p9_7_9 = std::move(calls_p9_7_9), sl_p8_8_9 = std::move(sl_p8_8_9)]() {
                        return ({
                            auto m2_pa = p0;
                            auto q_pb = p1;
                            call_then(start_meet_args(calls_p9_7_9, q_pb), [=, m2_pa = std::move(m2_pa)](std::optional<crate::check::shrink::Rel> meet_args_7395) {
                            return ({
                                prism_rtl::is_some(meet_args_7395) ? ({
                                auto&& r_pc = prism_rtl::some_of(meet_args_7395);
                                prism_rtl::finished(insert(m2_pa, prism_rtl::cat(prism_rtl::deref(sl_p8_8_9).owner, ":", prism_rtl::deref(sl_p8_8_9).at, ":", q_pb), r_pc));
                            })
                                : prism_rtl::is_none(meet_args_7395) ? prism_rtl::finished(m2_pa)
                                : throw prism_rtl::Panic("no arm matched");
                            });
                        });
                        });
                    }));
                    });
                }));
                }))->cycle();
                });
            });
            });
        }));
        });
    }));
    })), [=](Map<Text, crate::check::shrink::Rel> fold_7282) {
        return ({
            auto next_p6 = fold_7282;
            next_p6 == sums_p3_5
            ? prism_rtl::finished(next_p6)
            : round_p4_2 > Nat(12u)
            ? prism_rtl::finished(Map<Text, crate::check::shrink::Rel>{})
            : prism_rtl::more(prism_rtl::rc(SlotSums(sk_p0_3, homes_p1_1, slots_p2_4, next_p6, round_p4_2 + Nat(1u))));
        });
    });
}


/// `Start SlotSums, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_slot_sums(crate::check::shrink::Shrink sk_p0, Array<Text> homes_p1, Array<Slot_> slots_p2, Map<Text, crate::check::shrink::Rel> sums_p3, Nat round_p4) {
    return prism_rtl::make_rc<SlotSums>(sk_p0, homes_p1, slots_p2, sums_p3, round_p4);
}


/// SlotCalls: unbounded fn Shrink, Slot -> [Site]
Array<crate::check::shrink::walk::Site> slot_calls(const crate::check::shrink::Shrink& sk_p0, const Slot_& sl_p1) {
    auto&& _m = crate::prelude::get(sk_p0.by_key, sl_p1.owner);
    if (prism_rtl::is_some(_m)) {
        auto&& d_p2 = prism_rtl::some_of(_m);
        return run_to_end(fold_job(crate::check::shrink::types::def_clauses(d_p2), Array<crate::check::shrink::walk::Site>{}, ({
            auto sl_p1_1 = sl_p1;
            auto sk_p0_2 = sk_p0;
            auto d_p2_3 = d_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>>(std::tuple<Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sl_p1_1 = std::move(sl_p1_1), sk_p0_2 = std::move(sk_p0_2), d_p2_3 = std::move(d_p2_3)](std::tuple<Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto sl_p1_1_4 = sl_p1_1;
                auto sk_p0_2_4 = sk_p0_2;
                auto d_p2_3_4 = d_p2_3;
                entered(once_job([=, sl_p1_1_4 = std::move(sl_p1_1_4), sk_p0_2_4 = std::move(sk_p0_2_4), d_p2_3_4 = std::move(d_p2_3_4)]() {
                return ({
                    auto acc_p3 = p0;
                    auto c_p4 = p1;
                    ({
                    auto n_p5 = slot_name(c_p4, sl_p1_1_4.at);
                    n_p5 == Text::lit("")
                    ? prism_rtl::finished(acc_p3)
                    : call_then(crate::check::shrink::locals::start_clause_base(sk_p0_2_4, d_p2_3_4, c_p4), [=](Map<Text, crate::check::shrink::Rel> clause_base_7920) {
                    return ({
                        auto base_p6 = clause_base_7920;
                        call_then(crate::check::shrink::walk::start_body_spots(prism_rtl::deref(c_p4).body, base_p6), [=](Array<crate::check::shrink::walk::Spot> body_spots_7984) {
                        return call_then(crate::check::shrink::summaries::start_summary_seeds(sk_p0_2_4, d_p2_3_4, body_spots_7984, base_p6), [=](Map<Text, crate::check::shrink::Rel> summary_seeds_7963) {
                            return ({
                                auto rels_p7 = summary_seeds_7963;
                                call_then(crate::check::shrink::walk::start_body_spots(prism_rtl::deref(c_p4).body, rels_p7), [=](Array<crate::check::shrink::walk::Spot> body_spots_8032) {
                                return fold_job(body_spots_8032, acc_p3, ({
                                    auto n_p5_4 = n_p5;
                                    auto sl_p1_1_4_5 = sl_p1_1_4;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>>(std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, n_p5_4 = std::move(n_p5_4), sl_p1_1_4_5 = std::move(sl_p1_1_4_5)](std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto n_p5_4_5 = n_p5_4;
                                        auto sl_p1_1_4_5_5 = sl_p1_1_4_5;
                                        entered(once_job([=, n_p5_4_5 = std::move(n_p5_4_5), sl_p1_1_4_5_5 = std::move(sl_p1_1_4_5_5)]() {
                                        return ({
                                            auto a2_p8 = p0;
                                            auto sp_p9 = p1;
                                            ({
                                            prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(sp_p9) ? ({
                                            auto&& e_pa = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(sp_p9).a0;
                                            ({
                                            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_pa).kind);
                                            prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? prism_rtl::finished(a2_p8)
                                            : call_then(crate::check::shrink::walk::start_spot_sites(sp_p9), [=](Array<crate::check::shrink::walk::Site> spot_sites_8220) { return prism_rtl::finished(append(a2_p8, filter(spot_sites_8220, [&](const crate::check::shrink::walk::Site& site_pb) { return (prism_rtl::deref(site_pb).callee == n_p5_4_5) && is_slot_param(prism_rtl::deref(site_pb).rels, n_p5_4_5, sl_p1_1_4_5_5.at); }))); });
                                        });
                                        })
                                            : prism_rtl::finished(a2_p8);
                                        });
                                        });
                                    }));
                                    });
                                })));
                                }))->cycle();
                            });
                            });
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is_none(_m)) {
        return Array<crate::check::shrink::walk::Site>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::check::shrink::walk::Site>> SlotCalls::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& sl_p1 = this->sl_p1;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(sk_p0).by_key, prism_rtl::deref(sl_p1).owner);
        prism_rtl::is_some(_m) ? ({
        auto&& d_p2 = prism_rtl::some_of(_m);
        fold_job(crate::check::shrink::types::def_clauses(d_p2), Array<crate::check::shrink::walk::Site>{}, ({
        auto sl_p1_1 = sl_p1;
        auto sk_p0_2 = sk_p0;
        auto d_p2_3 = d_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>>(std::tuple<Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sl_p1_1 = std::move(sl_p1_1), sk_p0_2 = std::move(sk_p0_2), d_p2_3 = std::move(d_p2_3)](std::tuple<Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sl_p1_1_4 = sl_p1_1;
            auto sk_p0_2_4 = sk_p0_2;
            auto d_p2_3_4 = d_p2_3;
            entered(once_job([=, sl_p1_1_4 = std::move(sl_p1_1_4), sk_p0_2_4 = std::move(sk_p0_2_4), d_p2_3_4 = std::move(d_p2_3_4)]() {
            return ({
                auto acc_p3 = p0;
                auto c_p4 = p1;
                ({
                auto n_p5 = slot_name(c_p4, prism_rtl::deref(sl_p1_1_4).at);
                n_p5 == Text::lit("")
                ? prism_rtl::finished(acc_p3)
                : call_then(crate::check::shrink::locals::start_clause_base(sk_p0_2_4, d_p2_3_4, c_p4), [=](Map<Text, crate::check::shrink::Rel> clause_base_7920) {
                return ({
                    auto base_p6 = clause_base_7920;
                    call_then(crate::check::shrink::walk::start_body_spots(prism_rtl::deref(c_p4).body, base_p6), [=](Array<crate::check::shrink::walk::Spot> body_spots_7984) {
                    return call_then(crate::check::shrink::summaries::start_summary_seeds(sk_p0_2_4, d_p2_3_4, body_spots_7984, base_p6), [=](Map<Text, crate::check::shrink::Rel> summary_seeds_7963) {
                        return ({
                            auto rels_p7 = summary_seeds_7963;
                            call_then(crate::check::shrink::walk::start_body_spots(prism_rtl::deref(c_p4).body, rels_p7), [=](Array<crate::check::shrink::walk::Spot> body_spots_8032) {
                            return fold_job(body_spots_8032, acc_p3, ({
                                auto n_p5_4 = n_p5;
                                auto sl_p1_1_4_5 = sl_p1_1_4;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>>(std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, n_p5_4 = std::move(n_p5_4), sl_p1_1_4_5 = std::move(sl_p1_1_4_5)](std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot> _p0) {
                                auto&& p0 = std::get<0>(_p0);
                                auto&& p1 = std::get<1>(_p0);
                                return ({
                                    auto n_p5_4_5 = n_p5_4;
                                    auto sl_p1_1_4_5_5 = sl_p1_1_4_5;
                                    entered(once_job([=, n_p5_4_5 = std::move(n_p5_4_5), sl_p1_1_4_5_5 = std::move(sl_p1_1_4_5_5)]() {
                                    return ({
                                        auto a2_p8 = p0;
                                        auto sp_p9 = p1;
                                        ({
                                        prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(sp_p9) ? ({
                                        auto&& e_pa = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(sp_p9).a0;
                                        ({
                                        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_pa).kind);
                                        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? prism_rtl::finished(a2_p8)
                                        : call_then(crate::check::shrink::walk::start_spot_sites(sp_p9), [=](Array<crate::check::shrink::walk::Site> spot_sites_8220) { return prism_rtl::finished(append(a2_p8, filter(spot_sites_8220, [&](const crate::check::shrink::walk::Site& site_pb) { return (prism_rtl::deref(site_pb).callee == n_p5_4_5) && is_slot_param(prism_rtl::deref(site_pb).rels, n_p5_4_5, prism_rtl::deref(sl_p1_1_4_5_5).at); }))); });
                                    });
                                    })
                                        : prism_rtl::finished(a2_p8);
                                    });
                                    });
                                }));
                                });
                            })));
                            }))->cycle();
                        });
                        });
                    });
                });
                });
            });
            });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Array<crate::check::shrink::walk::Site>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SlotCalls, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>> start_slot_calls(crate::check::shrink::Shrink sk_p0, Slot_ sl_p1) {
    return prism_rtl::make_rc<SlotCalls>(sk_p0, sl_p1);
}


/// ?MeetArgs: unbounded fn [Site], Nat -> ?Rel
std::optional<crate::check::shrink::Rel> meet_args(const Array<crate::check::shrink::walk::Site>& calls_p0, const Nat& q_p1) {
    return run_to_end(fold_job(calls_p0, std::optional(crate::check::shrink::Rel{.param = crate::check::shrink::walk::top_param(), .strict = false}), ({
        auto q_p1_1 = q_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>>(std::tuple<std::optional<crate::check::shrink::Rel>, crate::check::shrink::walk::Site>)>>(prism_rtl::rc([=, q_p1_1 = std::move(q_p1_1)](std::tuple<std::optional<crate::check::shrink::Rel>, crate::check::shrink::walk::Site> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto q_p1_1_2 = q_p1_1;
            entered(once_job([=, q_p1_1_2 = std::move(q_p1_1_2)]() {
            return ({
                auto acc_o2 = p0;
                auto site_p3 = p1;
                ({
                prism_rtl::is_none(acc_o2) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                : prism_rtl::is_some(acc_o2) ? ({
                auto&& acc_p4 = prism_rtl::some_of(acc_o2);
                ({
                auto&& _m = index(site_p3->args, q_p1_1_2);
                prism_rtl::is_some(_m) ? ({
                auto&& a_p5 = prism_rtl::some_of(_m);
                prism_rtl::deref(a_p5).name != std::optional<crate::syntax::Ident>{}
                ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                : ({
                auto acc_p4_2 = acc_p4;
                call_then(crate::check::shrink::walk::start_rel_of(prism_rtl::deref(site_p3).rels, a_p5->value), [=, acc_p4_2 = std::move(acc_p4_2)](std::optional<crate::check::shrink::Rel> rel_of_8797) {
                return ({
                    prism_rtl::is_some(rel_of_8797) ? ({
                    auto&& r_p6 = prism_rtl::some_of(rel_of_8797);
                    prism_rtl::deref(r_p6).param == crate::check::shrink::walk::top_param()
                    ? prism_rtl::finished(std::optional(acc_p4_2))
                    : prism_rtl::deref(acc_p4_2).param == crate::check::shrink::walk::top_param()
                    ? prism_rtl::finished(std::optional(r_p6))
                    : prism_rtl::deref(acc_p4_2).param == prism_rtl::deref(r_p6).param
                    ? prism_rtl::finished(std::optional(crate::check::shrink::Rel{.param = prism_rtl::deref(r_p6).param, .strict = prism_rtl::deref(acc_p4_2).strict && prism_rtl::deref(r_p6).strict}))
                    : prism_rtl::finished(std::optional<crate::check::shrink::Rel>{});
                })
                    : prism_rtl::is_none(rel_of_8797) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<std::optional<crate::check::shrink::Rel>> MeetArgs::cycle() const {
    const auto& calls_p0 = this->calls_p0;
    const auto& q_p1 = this->q_p1;
    return fold_job(calls_p0, std::optional(crate::check::shrink::Rel{.param = crate::check::shrink::walk::top_param(), .strict = false}), ({
        auto q_p1_1 = q_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>>(std::tuple<std::optional<crate::check::shrink::Rel>, crate::check::shrink::walk::Site>)>>(prism_rtl::rc([=, q_p1_1 = std::move(q_p1_1)](std::tuple<std::optional<crate::check::shrink::Rel>, crate::check::shrink::walk::Site> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto q_p1_1_2 = q_p1_1;
            entered(once_job([=, q_p1_1_2 = std::move(q_p1_1_2)]() {
            return ({
                auto acc_o2 = p0;
                auto site_p3 = p1;
                ({
                prism_rtl::is_none(acc_o2) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                : prism_rtl::is_some(acc_o2) ? ({
                auto&& acc_p4 = prism_rtl::some_of(acc_o2);
                ({
                auto&& _m = index(site_p3->args, q_p1_1_2);
                prism_rtl::is_some(_m) ? ({
                auto&& a_p5 = prism_rtl::some_of(_m);
                prism_rtl::deref(a_p5).name != std::optional<crate::syntax::Ident>{}
                ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                : ({
                auto acc_p4_2 = acc_p4;
                call_then(crate::check::shrink::walk::start_rel_of(prism_rtl::deref(site_p3).rels, a_p5->value), [=, acc_p4_2 = std::move(acc_p4_2)](std::optional<crate::check::shrink::Rel> rel_of_8797) {
                return ({
                    prism_rtl::is_some(rel_of_8797) ? ({
                    auto&& r_p6 = prism_rtl::some_of(rel_of_8797);
                    prism_rtl::deref(r_p6).param == crate::check::shrink::walk::top_param()
                    ? prism_rtl::finished(std::optional(acc_p4_2))
                    : prism_rtl::deref(acc_p4_2).param == crate::check::shrink::walk::top_param()
                    ? prism_rtl::finished(std::optional(r_p6))
                    : prism_rtl::deref(acc_p4_2).param == prism_rtl::deref(r_p6).param
                    ? prism_rtl::finished(std::optional(crate::check::shrink::Rel{.param = prism_rtl::deref(r_p6).param, .strict = prism_rtl::deref(acc_p4_2).strict && prism_rtl::deref(r_p6).strict}))
                    : prism_rtl::finished(std::optional<crate::check::shrink::Rel>{});
                })
                    : prism_rtl::is_none(rel_of_8797) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start MeetArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>> start_meet_args(Array<crate::check::shrink::walk::Site> calls_p0, Nat q_p1) {
    return prism_rtl::make_rc<MeetArgs>(calls_p0, q_p1);
}


/// DefRefs: unbounded fn Shrink, Def -> [Text]
Array<Text> def_refs(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1) {
    return run_to_end(fold_job(crate::check::shrink::types::def_clauses(d_p1), Array<Text>{}, ({
        auto sk_p0_1 = sk_p0;
        auto d_p1_2 = d_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sk_p0_1 = std::move(sk_p0_1), d_p1_2 = std::move(d_p1_2)](std::tuple<Array<Text>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0_1_3 = sk_p0_1;
            auto d_p1_2_3 = d_p1_2;
            entered(once_job([=, sk_p0_1_3 = std::move(sk_p0_1_3), d_p1_2_3 = std::move(d_p1_2_3)]() {
            return ({
                auto acc_p2 = p0;
                auto c_p3 = p1;
                call_then(crate::check::shrink::locals::start_clause_base(sk_p0_1_3, d_p1_2_3, c_p3), [=, acc_p2 = std::move(acc_p2)](Map<Text, crate::check::shrink::Rel> clause_base_9334) { return call_then(crate::check::shrink::walk::start_body_spots(prism_rtl::deref(c_p3).body, clause_base_9334), [=](Array<crate::check::shrink::walk::Spot> body_spots_9315) { return prism_rtl::more(prism_rtl::rc(SpotsRefs(sk_p0_1_3, d_p1_2_3, body_spots_9315, acc_p2))); }); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> DefRefs::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& d_p1 = this->d_p1;
    return fold_job(crate::check::shrink::types::def_clauses(d_p1), Array<Text>{}, ({
        auto sk_p0_1 = sk_p0;
        auto d_p1_2 = d_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sk_p0_1 = std::move(sk_p0_1), d_p1_2 = std::move(d_p1_2)](std::tuple<Array<Text>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0_1_3 = sk_p0_1;
            auto d_p1_2_3 = d_p1_2;
            entered(once_job([=, sk_p0_1_3 = std::move(sk_p0_1_3), d_p1_2_3 = std::move(d_p1_2_3)]() {
            return ({
                auto acc_p2 = p0;
                auto c_p3 = p1;
                call_then(crate::check::shrink::locals::start_clause_base(sk_p0_1_3, d_p1_2_3, c_p3), [=, acc_p2 = std::move(acc_p2)](Map<Text, crate::check::shrink::Rel> clause_base_9334) { return call_then(crate::check::shrink::walk::start_body_spots(prism_rtl::deref(c_p3).body, clause_base_9334), [=](Array<crate::check::shrink::walk::Spot> body_spots_9315) { return prism_rtl::more(prism_rtl::rc(SpotsRefs(sk_p0_1_3, d_p1_2_3, body_spots_9315, acc_p2))); }); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start DefRefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_def_refs(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1) {
    return prism_rtl::make_rc<DefRefs>(sk_p0, d_p1);
}


/// SpotsRefs: unbounded fn Shrink, Def, [Spot], [Text] -> [Text]
Array<Text> spots_refs(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const Array<crate::check::shrink::walk::Spot>& spots_p2, const Array<Text>& acc_p3) {
    return run_to_end(fold_job(spots_p2, acc_p3, ({
        auto sk_p0_1 = sk_p0;
        auto d_p1_2 = d_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, sk_p0_1 = std::move(sk_p0_1), d_p1_2 = std::move(d_p1_2)](std::tuple<Array<Text>, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0_1_3 = sk_p0_1;
            auto d_p1_2_3 = d_p1_2;
            entered(once_job([=, sk_p0_1_3 = std::move(sk_p0_1_3), d_p1_2_3 = std::move(d_p1_2_3)]() {
            return ({
                auto a1_p4 = p0;
                auto sp_p5 = p1;
                call_then(crate::check::shrink::walk::start_spot_sites(sp_p5), [=, a1_p4 = std::move(a1_p4)](Array<crate::check::shrink::walk::Site> spot_sites_9490) {
                return prism_rtl::finished(fold(spot_sites_9490, a1_p4, [&](const Array<Text>& a2_p6, const crate::check::shrink::walk::Site& site_p7) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        auto&& _m = crate::check::shrink::locals::local_target(sk_p0_1_3, d_p1_2_3, site_p7);
                        if (prism_rtl::is_some(_m)) {
                            auto&& t_p8 = prism_rtl::some_of(_m);
                            _v.set(crate::check::types::add_text(a2_p6, t_p8));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(crate::check::shrink::relations::is_local(prism_rtl::deref(site_p7).rels, prism_rtl::deref(site_p7).callee) || crate::check::env::has_key(sk_p0_1_3.local_of, d_p1_2_3.qk)
                                ? a2_p6
                                : ({
                                __label__ _done;
                                prism_rtl::Slot<Array<Text>> _v;
                                auto&& _m = crate::check::shrink::locals::resolve_callee(sk_p0_1_3.g, d_p1_2_3.home, prism_rtl::deref(site_p7).callee);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& k_p9 = prism_rtl::some_of(_m);
                                    _v.set(fold(crate::check::shrink::types::targets_of(sk_p0_1_3, k_p9), a2_p6, [&](const Array<Text>& a3_pa, const Text& t_pb) {
                                        return crate::check::env::has_key(sk_p0_1_3.by_key, t_pb)
                                            ? crate::check::types::add_text(a3_pa, t_pb)
                                            : a3_pa;
                                    }));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(a2_p6);
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> SpotsRefs::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& d_p1 = this->d_p1;
    const auto& spots_p2 = this->spots_p2;
    const auto& acc_p3 = this->acc_p3;
    return fold_job(spots_p2, acc_p3, ({
        auto sk_p0_1 = sk_p0;
        auto d_p1_2 = d_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, sk_p0_1 = std::move(sk_p0_1), d_p1_2 = std::move(d_p1_2)](std::tuple<Array<Text>, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0_1_3 = sk_p0_1;
            auto d_p1_2_3 = d_p1_2;
            entered(once_job([=, sk_p0_1_3 = std::move(sk_p0_1_3), d_p1_2_3 = std::move(d_p1_2_3)]() {
            return ({
                auto a1_p4 = p0;
                auto sp_p5 = p1;
                call_then(crate::check::shrink::walk::start_spot_sites(sp_p5), [=, a1_p4 = std::move(a1_p4)](Array<crate::check::shrink::walk::Site> spot_sites_9490) {
                return prism_rtl::finished(fold(spot_sites_9490, a1_p4, [&](const Array<Text>& a2_p6, const crate::check::shrink::walk::Site& site_p7) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        auto&& _m = crate::check::shrink::locals::local_target(sk_p0_1_3, d_p1_2_3, site_p7);
                        if (prism_rtl::is_some(_m)) {
                            auto&& t_p8 = prism_rtl::some_of(_m);
                            _v.set(crate::check::types::add_text(a2_p6, t_p8));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(crate::check::shrink::relations::is_local(prism_rtl::deref(site_p7).rels, prism_rtl::deref(site_p7).callee) || crate::check::env::has_key(prism_rtl::deref(sk_p0_1_3).local_of, prism_rtl::deref(d_p1_2_3).qk)
                                ? a2_p6
                                : ({
                                __label__ _done;
                                prism_rtl::Slot<Array<Text>> _v;
                                auto&& _m = crate::check::shrink::locals::resolve_callee(prism_rtl::deref(sk_p0_1_3).g, prism_rtl::deref(d_p1_2_3).home, prism_rtl::deref(site_p7).callee);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& k_p9 = prism_rtl::some_of(_m);
                                    _v.set(fold(crate::check::shrink::types::targets_of(sk_p0_1_3, k_p9), a2_p6, [&](const Array<Text>& a3_pa, const Text& t_pb) {
                                        return crate::check::env::has_key(prism_rtl::deref(sk_p0_1_3).by_key, t_pb)
                                            ? crate::check::types::add_text(a3_pa, t_pb)
                                            : a3_pa;
                                    }));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(a2_p6);
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start SpotsRefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spots_refs(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, Array<crate::check::shrink::walk::Spot> spots_p2, Array<Text> acc_p3) {
    return prism_rtl::make_rc<SpotsRefs>(sk_p0, d_p1, spots_p2, acc_p3);
}

}  // namespace crate::check::shrink::calls
