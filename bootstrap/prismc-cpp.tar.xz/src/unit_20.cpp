// The modules `Check.Shrink`, `Check.Shrink.Calls`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/shrink/module.hpp>
#include <syntax/module.hpp>
#include <check/env/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Shrink`, from `target/bootstrap/cpp-src/prismc/check/shrink/mod.prism`.
namespace crate::check::shrink {

void Rel::show(Printer& p) const {
    p.record("Rel", {{"param", param_p}, {"strict", strict_p}});
}

Pod Rel::to_pod() const {
    return Pod::record("Rel", {{"param", prism_rtl::to_pod(param_p)}, {"strict", prism_rtl::to_pod(strict_p)}});
}

Result<Rel> Rel::from_pod(const Pod& whole) {
    return Rel{.param_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "param")))), .strict_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "strict"))))};
}


void Sc::show(Printer& p) const {
    p.record("Sc", {{"caller", caller_p}, {"callee", callee_p}, {"edges", edges_p}, {"span", span_p}, {"file", file_p}, {"arg", arg_p}});
}

Pod Sc::to_pod() const {
    return Pod::record("Sc", {{"caller", prism_rtl::to_pod(caller_p)}, {"callee", prism_rtl::to_pod(callee_p)}, {"edges", prism_rtl::to_pod(edges_p)}, {"span", prism_rtl::to_pod(span_p)}, {"file", prism_rtl::to_pod(file_p)}, {"arg", prism_rtl::to_pod(arg_p)}});
}

Result<Sc> Sc::from_pod(const Pod& whole) {
    return Sc{.caller_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "caller")))), .callee_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "callee")))), .edges_p = TRY(prism_rtl::from_pod<Array<std::tuple<Nat, Nat, bool>>>(TRY(crate::prelude::field(whole, "edges")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .file_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .arg_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "arg"))))};
}


bool Shrink::operator==(const Shrink& o) const { return g_p == o.g_p && fns_p == o.fns_p && by_key_p == o.by_key_p && targets_p == o.targets_p && impl_defs_p == o.impl_defs_p && choices_p == o.choices_p && sums_p == o.sums_p && seeds_p == o.seeds_p && local_of_p == o.local_of_p && local_base_p == o.local_base_p; }

void Shrink::show(Printer& p) const {
    p.record("Shrink", {{"g", g_p}, {"fns", fns_p}, {"byKey", by_key_p}, {"targets", targets_p}, {"implDefs", impl_defs_p}, {"choices", choices_p}, {"sums", sums_p}, {"seeds", seeds_p}, {"localOf", local_of_p}, {"localBase", local_base_p}});
}

Pod Shrink::to_pod() const {
    return Pod::record("Shrink", {{"g", prism_rtl::to_pod(g_p)}, {"fns", prism_rtl::to_pod(fns_p)}, {"byKey", prism_rtl::to_pod(by_key_p)}, {"targets", prism_rtl::to_pod(targets_p)}, {"implDefs", prism_rtl::to_pod(impl_defs_p)}, {"choices", prism_rtl::to_pod(choices_p)}, {"sums", prism_rtl::to_pod(sums_p)}, {"seeds", prism_rtl::to_pod(seeds_p)}, {"localOf", prism_rtl::to_pod(local_of_p)}, {"localBase", prism_rtl::to_pod(local_base_p)}});
}

Result<Shrink> Shrink::from_pod(const Pod& whole) {
    return Shrink{.g_p = TRY(prism_rtl::from_pod<crate::check::env::G>(TRY(crate::prelude::field(whole, "g")))), .fns_p = TRY(prism_rtl::from_pod<Array<crate::check::env::Def>>(TRY(crate::prelude::field(whole, "fns")))), .by_key_p = TRY(prism_rtl::from_pod<Map<Text, crate::check::env::Def>>(TRY(crate::prelude::field(whole, "byKey")))), .targets_p = TRY(prism_rtl::from_pod<Map<Text, Array<Text>>>(TRY(crate::prelude::field(whole, "targets")))), .impl_defs_p = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "implDefs")))), .choices_p = TRY(prism_rtl::from_pod<Map<Text, Array<Text>>>(TRY(crate::prelude::field(whole, "choices")))), .sums_p = TRY(prism_rtl::from_pod<Map<Text, Nat>>(TRY(crate::prelude::field(whole, "sums")))), .seeds_p = TRY(prism_rtl::from_pod<Map<Text, Map<Text, Rel>>>(TRY(crate::prelude::field(whole, "seeds")))), .local_of_p = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "localOf")))), .local_base_p = TRY(prism_rtl::from_pod<Map<Text, Map<Text, Rel>>>(TRY(crate::prelude::field(whole, "localBase"))))};
}


/// ShrinkCheck: unbounded fn G, St, [Def] -> ((St, [((Text, [Text]))]))
std::tuple<crate::check::types::St, Array<std::tuple<Text, Array<Text>>>> shrink_check_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Array<crate::check::env::Def>& defs_p2) {
    auto fns_p3 = crate::prelude::each(crate::prelude::filter(defs_p2, [&](const crate::check::env::Def& d_pi) { return crate::prelude::len(crate::check::shrink::types::def_clauses_f(d_pi)) > Nat(0u); }), [&](const crate::check::env::Def& d_pj) { return crate::check::shrink::types::own_key_f(d_pj); });
    auto by_key_p4 = crate::prelude::fold(fns_p3, Map<Text, crate::check::env::Def>{}, [&](const Map<Text, crate::check::env::Def>& m_pk, const crate::check::env::Def& d_pl) { return crate::prelude::insert(m_pk, prism_rtl::deref(d_pl).qk_p, d_pl); });
    auto homes_p5 = crate::prelude::fold(fns_p3, Array<Text>{}, [&](const Array<Text>& acc_pm, const crate::check::env::Def& d_pn) { return crate::check::types::add_text_f(acc_pm, prism_rtl::deref(d_pn).home_p); });
    auto nats_p6 = crate::check::shrink::types::nat_minus_seeds_f(st_p1);
    auto pre_p7 = crate::prelude::fold(homes_p5, Map<Text, Map<Text, Rel>>{}, [&](const Map<Text, Map<Text, Rel>>& m_po, const Text& h_pp) { return crate::prelude::insert(m_po, h_pp, crate::prelude::fold(crate::prelude::keys(nats_p6), crate::check::shrink::relations::prelude_seeds_f(g_p0, h_pp), [&](const Map<Text, Rel>& m2_pq, const Text& k_pr) { return crate::prelude::insert(m2_pq, k_pr, crate::check::shrink::relations::no_rel_p()); })); });
    auto sk0_p8 = Shrink{.g_p = g_p0, .fns_p = fns_p3, .by_key_p = by_key_p4, .targets_p = crate::check::shrink::types::method_targets_f(g_p0, fns_p3), .impl_defs_p = crate::check::shrink::types::impl_defs_f(g_p0, fns_p3), .choices_p = st_p1.choices_p, .sums_p = Map<Text, Nat>{}, .seeds_p = pre_p7, .local_of_p = Map<Text, Text>{}, .local_base_p = Map<Text, Map<Text, Rel>>{}};
    auto sk1_p9 = ({
        Shrink this_ = sk0_p8;
        this_.sums_p = crate::check::shrink::summaries::parts_summaries_f(sk0_p8, fns_p3);
        (std::move(this_));
    });
    auto skg_pa = ({
        Shrink this_ = sk1_p9;
        this_.seeds_p = crate::check::shrink::calls::hof_seeds_f(sk1_p9, homes_p5);
        (std::move(this_));
    });
    auto walked_pb = crate::prelude::run_to_end(crate::prelude::each_job(fns_p3, ({
        auto skg_pax = skg_pa;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>>(crate::check::env::Def)>>(prism_rtl::rc([=, skg_pax = std::move(skg_pax)](crate::check::env::Def p0) {
        return ({
            auto skg_paxy = skg_pax;
            (crate::prelude::entered(crate::prelude::once_job([=, skg_paxy = std::move(skg_paxy)]() {
            return ({
                auto d_ps = p0;
                (prism_rtl::more(prism_rtl::rc(crate::check::shrink::locals::DefWalk(skg_paxy, d_ps))));
            });
        })));
        });
    }));
    })));
    auto sk_pc = crate::check::shrink::locals::with_locals_f(skg_pa, crate::prelude::fold(walked_pb, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{}, [&](const Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>& acc_pt, const std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>& _p1) {
        auto&& ls_pu = std::get<2>(_p1);
        return crate::prelude::append(acc_pt, ls_pu);
    }));
    auto refs_pd = crate::prelude::append(crate::prelude::each(walked_pb, [&](const std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>& _p0) {
        auto&& k_pv = std::get<0>(_p0);
        auto&& rs_p10 = std::get<1>(_p0);
        return std::tuple{k_pv, rs_p10};
    }), crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::drop(prism_rtl::deref(sk_pc).fns_p, crate::prelude::len(fns_p3)), ({
        auto sk_pcx = sk_pc;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>>>(crate::check::env::Def)>>(prism_rtl::rc([=, sk_pcx = std::move(sk_pcx)](crate::check::env::Def p0) {
        return ({
            auto sk_pcxy = sk_pcx;
            (crate::prelude::entered(crate::prelude::once_job([=, sk_pcxy = std::move(sk_pcxy)]() {
            return ({
                auto d_p11 = p0;
                (crate::prelude::call_then(crate::check::shrink::calls::start_def_refs_f(sk_pcxy, d_p11), [=](Array<Text> def_refs_f_3915) { return prism_rtl::finished(std::tuple{prism_rtl::deref(d_p11).qk_p, def_refs_f_3915}); }));
            });
        })));
        });
    }));
    }))));
    auto keys_pe = crate::prelude::each(prism_rtl::deref(sk_pc).fns_p, [&](const crate::check::env::Def& d_p12) { return prism_rtl::deref(d_p12).qk_p; });
    auto sccs_pf = crate::check::shrink::locals::sccs_f(keys_pe, refs_pd);
    auto st2_pg = crate::prelude::run_to_end(crate::prelude::fold_job(sccs_pf, crate::check::shrink::types::negative_types_f(g_p0, st_p1), ({
        auto sk_pcx = sk_pc;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Array<Text>>)>>(prism_rtl::rc([=, sk_pcx = std::move(sk_pcx)](std::tuple<crate::check::types::St, Array<Text>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_pcxy = sk_pcx;
            (crate::prelude::entered(crate::prelude::once_job([=, sk_pcxy = std::move(sk_pcxy)]() {
            return ({
                auto s_p13 = p0;
                auto comp_p14 = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::shrink::locals::ShrinkComponent(sk_pcxy, s_p13, comp_p14))));
            });
        })));
        });
    })));
    })));
    auto st3_ph = crate::prelude::run_to_end(crate::prelude::fold_job(fns_p3, st2_pg, ({
        auto sk_pcx = sk_pc;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::env::Def>)>>(prism_rtl::rc([=, sk_pcx = std::move(sk_pcx)](std::tuple<crate::check::types::St, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_pcxy = sk_pcx;
            (crate::prelude::entered(crate::prelude::once_job([=, sk_pcxy = std::move(sk_pcxy)]() {
            return ({
                auto s_p15 = p0;
                auto d_p16 = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::shrink::summaries::LoopsOf(sk_pcxy, s_p15, d_p16))));
            });
        })));
        });
    })));
    })));
    return std::tuple{st3_ph, refs_pd};
}


prism_rtl::Turn<std::tuple<crate::check::types::St, Array<std::tuple<Text, Array<Text>>>>> ShrinkCheck::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& defs_p2 = this->defs_p2;
    auto fns_p3 = crate::prelude::each(crate::prelude::filter(defs_p2, [&](const crate::check::env::Def& d_pi) { return crate::prelude::len(crate::check::shrink::types::def_clauses_f(d_pi)) > Nat(0u); }), [&](const crate::check::env::Def& d_pj) { return crate::check::shrink::types::own_key_f(d_pj); });
    auto by_key_p4 = crate::prelude::fold(fns_p3, Map<Text, crate::check::env::Def>{}, [&](const Map<Text, crate::check::env::Def>& m_pk, const crate::check::env::Def& d_pl) { return crate::prelude::insert(m_pk, prism_rtl::deref(d_pl).qk_p, d_pl); });
    auto homes_p5 = crate::prelude::fold(fns_p3, Array<Text>{}, [&](const Array<Text>& acc_pm, const crate::check::env::Def& d_pn) { return crate::check::types::add_text_f(acc_pm, prism_rtl::deref(d_pn).home_p); });
    auto g_p0x = g_p0;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(crate::check::shrink::types::start_nat_minus_seeds_f(st_p1x), [=](Map<Text, Rel> nat_minus_seeds_f_3210) {
        return ({
            auto nats_p6 = nat_minus_seeds_f_3210;
            auto pre_p7 = crate::prelude::fold(homes_p5, Map<Text, Map<Text, Rel>>{}, [&](const Map<Text, Map<Text, Rel>>& m_po, const Text& h_pp) { return crate::prelude::insert(m_po, h_pp, crate::prelude::fold(crate::prelude::keys(nats_p6), crate::check::shrink::relations::prelude_seeds_f(g_p0x, h_pp), [&](const Map<Text, Rel>& m2_pq, const Text& k_pr) { return crate::prelude::insert(m2_pq, k_pr, crate::check::shrink::relations::no_rel_p()); })); });
            auto sk0_p8 = Shrink{.g_p = g_p0x, .fns_p = fns_p3, .by_key_p = by_key_p4, .targets_p = crate::check::shrink::types::method_targets_f(g_p0x, fns_p3), .impl_defs_p = crate::check::shrink::types::impl_defs_f(g_p0x, fns_p3), .choices_p = prism_rtl::deref(st_p1x).choices_p, .sums_p = Map<Text, Nat>{}, .seeds_p = pre_p7, .local_of_p = Map<Text, Text>{}, .local_base_p = Map<Text, Map<Text, Rel>>{}};
            auto sk1_p9 = ({
                Shrink this_ = sk0_p8;
                this_.sums_p = crate::check::shrink::summaries::parts_summaries_f(sk0_p8, fns_p3);
                (std::move(this_));
            });
            auto skg_pa = ({
                Shrink this_ = sk1_p9;
                this_.seeds_p = crate::check::shrink::calls::hof_seeds_f(sk1_p9, homes_p5);
                (std::move(this_));
            });
            (crate::prelude::call_value(crate::prelude::each_job(fns_p3, ({
            auto skg_pax = skg_pa;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>>(crate::check::env::Def)>>(prism_rtl::rc([=, skg_pax = std::move(skg_pax)](crate::check::env::Def p0) {
            return ({
                auto skg_paxy = skg_pax;
                (crate::prelude::entered(crate::prelude::once_job([=, skg_paxy = std::move(skg_paxy)]() {
                return ({
                    auto d_ps = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::check::shrink::locals::DefWalk(skg_paxy, d_ps))));
                });
            })));
            });
        }));
        })), [=](Array<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>> each_3674) {
            return ({
                auto walked_pb = each_3674;
                (crate::prelude::call_then(crate::check::shrink::locals::start_with_locals_f(skg_pa, crate::prelude::fold(walked_pb, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{}, [&](const Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>& acc_pt, const std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>& _p1) {
                auto&& ls_pu = std::get<2>(_p1);
                return crate::prelude::append(acc_pt, ls_pu);
            })), [=](Shrink with_locals_f_3717) {
                return ({
                    auto sk_pc = with_locals_f_3717;
                    (crate::prelude::call_value(crate::prelude::each_job(crate::prelude::drop(prism_rtl::deref(sk_pc).fns_p, crate::prelude::len(fns_p3)), ({
                    auto sk_pcx = sk_pc;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>>>(crate::check::env::Def)>>(prism_rtl::rc([=, sk_pcx = std::move(sk_pcx)](crate::check::env::Def p0) {
                    return ({
                        auto sk_pcxy = sk_pcx;
                        (crate::prelude::entered(crate::prelude::once_job([=, sk_pcxy = std::move(sk_pcxy)]() {
                        return ({
                            auto d_p11 = p0;
                            (crate::prelude::call_then(crate::check::shrink::calls::start_def_refs_f(sk_pcxy, d_p11), [=](Array<Text> def_refs_f_3915) { return prism_rtl::finished(std::tuple{prism_rtl::deref(d_p11).qk_p, def_refs_f_3915}); }));
                        });
                    })));
                    });
                }));
                })), [=](Array<std::tuple<Text, Array<Text>>> each_3870) {
                    return ({
                        auto refs_pd = crate::prelude::append(crate::prelude::each(walked_pb, [&](const std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>& _p0) {
                            auto&& k_pv = std::get<0>(_p0);
                            auto&& rs_p10 = std::get<1>(_p0);
                            return std::tuple{k_pv, rs_p10};
                        }), each_3870);
                        auto keys_pe = crate::prelude::each(prism_rtl::deref(sk_pc).fns_p, [&](const crate::check::env::Def& d_p12) { return prism_rtl::deref(d_p12).qk_p; });
                        (crate::prelude::call_then(crate::check::shrink::locals::start_sccs_f(keys_pe, refs_pd), [=](Array<Array<Text>> sccs_f_3986) {
                        return ({
                            auto sccs_pf = sccs_f_3986;
                            (crate::prelude::call_then(crate::check::shrink::types::start_negative_types_f(g_p0x, st_p1x), [=, sccs_pf = std::move(sccs_pf)](crate::check::types::St negative_types_f_4028) {
                            return crate::prelude::call_value(crate::prelude::fold_job(sccs_pf, negative_types_f_4028, ({
                                auto sk_pcx = sk_pc;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Array<Text>>)>>(prism_rtl::rc([=, sk_pcx = std::move(sk_pcx)](std::tuple<crate::check::types::St, Array<Text>> _p0) {
                                auto&& p0 = std::get<0>(_p0);
                                auto&& p1 = std::get<1>(_p0);
                                return ({
                                    auto sk_pcxy = sk_pcx;
                                    (crate::prelude::entered(crate::prelude::once_job([=, sk_pcxy = std::move(sk_pcxy)]() {
                                    return ({
                                        auto s_p13 = p0;
                                        auto comp_p14 = p1;
                                        (prism_rtl::more(prism_rtl::rc(crate::check::shrink::locals::ShrinkComponent(sk_pcxy, s_p13, comp_p14))));
                                    });
                                })));
                                });
                            })));
                            })), [=](crate::check::types::St fold_4016) {
                                return ({
                                    auto st2_pg = fold_4016;
                                    (crate::prelude::call_value(crate::prelude::fold_job(fns_p3, st2_pg, ({
                                    auto sk_pcx = sk_pc;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::env::Def>)>>(prism_rtl::rc([=, sk_pcx = std::move(sk_pcx)](std::tuple<crate::check::types::St, crate::check::env::Def> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto sk_pcxy = sk_pcx;
                                        (crate::prelude::entered(crate::prelude::once_job([=, sk_pcxy = std::move(sk_pcxy)]() {
                                        return ({
                                            auto s_p15 = p0;
                                            auto d_p16 = p1;
                                            (prism_rtl::more(prism_rtl::rc(crate::check::shrink::summaries::LoopsOf(sk_pcxy, s_p15, d_p16))));
                                        });
                                    })));
                                    });
                                })));
                                })), [=](crate::check::types::St fold_4103) {
                                    return ({
                                        auto st3_ph = fold_4103;
                                        (prism_rtl::finished(std::tuple{st3_ph, refs_pd}));
                                    });
                                }));
                                });
                            });
                        }));
                        });
                    }));
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start ShrinkCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::St, Array<std::tuple<Text, Array<Text>>>>> start_shrink_check_f(crate::check::env::G g_p0, crate::check::types::St st_p1, Array<crate::check::env::Def> defs_p2) {
    return prism_rtl::make_rc<ShrinkCheck>(g_p0, st_p1, defs_p2);
}


/// UnusedDefs: unbounded fn [Def], [((Text, [Text]))], Nat -> [CDiag]
Array<crate::check::errors::CDiag> unused_defs_f(const Array<crate::check::env::Def>& defs_p0, const Array<std::tuple<Text, Array<Text>>>& refs_p1, const Nat& shown_p2) {
    auto used0_p3 = crate::prelude::fold(refs_p1, Map<Text, Unit>{}, [&](const Map<Text, Unit>& m_p6, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k_p7 = std::get<0>(_p1);
        auto&& rs_p8 = std::get<1>(_p1);
        return crate::prelude::fold(rs_p8, m_p6, [&](const Map<Text, Unit>& m2_p9, const Text& r_pa) { return r_pa == k_p7 ? m2_p9 : crate::prelude::insert(m2_p9, r_pa, Unit{}); });
    });
    auto used_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(defs_p0, used0_p3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Unit>>(std::tuple<Map<Text, Unit>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Unit>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto m_pb = p0;
                auto d_pc = p1;
                ({
                auto&& _m = prism_rtl::deref(d_pc).body_p;
                prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m) ? ({
                auto&& c_pd = prism_rtl::as<crate::check::env::DefBody::DbCheck>(_m).a0;
                crate::prelude::fold_job(prism_rtl::deref(c_pd).lines_p, m_pb, ({
                auto d_pcx = d_pc;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Unit>>(std::tuple<Map<Text, Unit>, crate::syntax::decls::CheckLine>)>>(prism_rtl::rc([=, d_pcx = std::move(d_pcx)](std::tuple<Map<Text, Unit>, crate::syntax::decls::CheckLine> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto d_pcxy = d_pcx;
                    (crate::prelude::entered(crate::prelude::once_job([=, d_pcxy = std::move(d_pcxy)]() {
                    return ({
                        auto m2_pe = p0;
                        auto l_pf = p1;
                        (crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(prism_rtl::deref(l_pf).expr_p), [=, m2_pe = std::move(m2_pe)](Array<crate::syntax::Expr> exprs_in_f_4836) {
                        return prism_rtl::finished(crate::prelude::fold(exprs_in_f_4836, m2_pe, [&](const Map<Text, Unit>& m3_pg, const crate::syntax::Expr& e_ph) {
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<Map<Text, Unit>> _v;
                                auto&& _m = prism_rtl::deref(prism_rtl::deref(e_ph).kind_p);
                                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                                    auto&& n_pi = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                                    _v.set(crate::prelude::insert(crate::prelude::insert(m3_pg, crate::check::env::sname_key_f(n_pi), Unit{}), crate::check::env::qual_key_f(prism_rtl::deref(d_pcxy).home_p, crate::check::env::sname_key_f(n_pi)), Unit{}));
                                    goto _done;
                                }
                                {
                                    _v.set(m3_pg);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        }));
                    }));
                    });
                })));
                });
            }));
            }))->cycle();
            })
                : prism_rtl::finished(m_pb);
            });
            });
        }));
    }))));
    auto own_p5 = crate::prelude::filter(defs_p0, [&](const crate::check::env::Def& d_pj) { return ((((prism_rtl::deref(d_pj).file_p < shown_p2) && (!crate::check::env::has_key_f(used_p4, prism_rtl::deref(d_pj).qk_p))) && (prism_rtl::deref(d_pj).name_p != Text::lit("@main"))) && (!is_method_def_f(d_pj))) && (!is_testing_def_f(d_pj)); });
    return crate::prelude::each(own_p5, [&](const crate::check::env::Def& d_pk) { return crate::check::errors::CDiag{.code_p = Text::lit("unused"), .file_p = prism_rtl::deref(d_pk).file_p, .span_p = prism_rtl::deref(d_pk).span_p, .message_p = prism_rtl::cat("nothing uses `", prism_rtl::deref(d_pk).name_p, "`"), .fix_p = Text::lit("delete it, or use it")}; });
}


prism_rtl::Turn<Array<crate::check::errors::CDiag>> UnusedDefs::cycle() const {
    const auto& defs_p0 = this->defs_p0;
    const auto& refs_p1 = this->refs_p1;
    const auto& shown_p2 = this->shown_p2;
    auto used0_p3 = crate::prelude::fold(refs_p1, Map<Text, Unit>{}, [&](const Map<Text, Unit>& m_p6, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k_p7 = std::get<0>(_p1);
        auto&& rs_p8 = std::get<1>(_p1);
        return crate::prelude::fold(rs_p8, m_p6, [&](const Map<Text, Unit>& m2_p9, const Text& r_pa) { return r_pa == k_p7 ? m2_p9 : crate::prelude::insert(m2_p9, r_pa, Unit{}); });
    });
    auto defs_p0x = defs_p0;
    auto shown_p2x = shown_p2;
    return crate::prelude::call_value(crate::prelude::fold_job(defs_p0x, used0_p3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Unit>>(std::tuple<Map<Text, Unit>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Unit>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto m_pb = p0;
                auto d_pc = p1;
                ({
                auto&& _m = prism_rtl::deref(d_pc).body_p;
                prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m) ? ({
                auto&& c_pd = prism_rtl::as<crate::check::env::DefBody::DbCheck>(_m).a0;
                crate::prelude::fold_job(prism_rtl::deref(c_pd).lines_p, m_pb, ({
                auto d_pcx = d_pc;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Unit>>(std::tuple<Map<Text, Unit>, crate::syntax::decls::CheckLine>)>>(prism_rtl::rc([=, d_pcx = std::move(d_pcx)](std::tuple<Map<Text, Unit>, crate::syntax::decls::CheckLine> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto d_pcxy = d_pcx;
                    (crate::prelude::entered(crate::prelude::once_job([=, d_pcxy = std::move(d_pcxy)]() {
                    return ({
                        auto m2_pe = p0;
                        auto l_pf = p1;
                        (crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(prism_rtl::deref(l_pf).expr_p), [=, m2_pe = std::move(m2_pe)](Array<crate::syntax::Expr> exprs_in_f_4836) {
                        return prism_rtl::finished(crate::prelude::fold(exprs_in_f_4836, m2_pe, [&](const Map<Text, Unit>& m3_pg, const crate::syntax::Expr& e_ph) {
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<Map<Text, Unit>> _v;
                                auto&& _m = prism_rtl::deref(prism_rtl::deref(e_ph).kind_p);
                                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                                    auto&& n_pi = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                                    _v.set(crate::prelude::insert(crate::prelude::insert(m3_pg, crate::check::env::sname_key_f(n_pi), Unit{}), crate::check::env::qual_key_f(prism_rtl::deref(d_pcxy).home_p, crate::check::env::sname_key_f(n_pi)), Unit{}));
                                    goto _done;
                                }
                                {
                                    _v.set(m3_pg);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        }));
                    }));
                    });
                })));
                });
            }));
            }))->cycle();
            })
                : prism_rtl::finished(m_pb);
            });
            });
        }));
    }))), [=](Map<Text, Unit> fold_4745) {
        return ({
            auto used_p4 = fold_4745;
            auto own_p5 = crate::prelude::filter(defs_p0x, [&](const crate::check::env::Def& d_pj) { return ((((prism_rtl::deref(d_pj).file_p < shown_p2x) && (!crate::check::env::has_key_f(used_p4, prism_rtl::deref(d_pj).qk_p))) && (prism_rtl::deref(d_pj).name_p != Text::lit("@main"))) && (!is_method_def_f(d_pj))) && (!is_testing_def_f(d_pj)); });
            (prism_rtl::finished(crate::prelude::each(own_p5, [&](const crate::check::env::Def& d_pk) { return crate::check::errors::CDiag{.code_p = Text::lit("unused"), .file_p = prism_rtl::deref(d_pk).file_p, .span_p = prism_rtl::deref(d_pk).span_p, .message_p = prism_rtl::cat("nothing uses `", prism_rtl::deref(d_pk).name_p, "`"), .fix_p = Text::lit("delete it, or use it")}; })));
        });
    });
}


/// `Start UnusedDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::errors::CDiag>> start_unused_defs_f(Array<crate::check::env::Def> defs_p0, Array<std::tuple<Text, Array<Text>>> refs_p1, Nat shown_p2) {
    return prism_rtl::make_rc<UnusedDefs>(defs_p0, refs_p1, shown_p2);
}


/// TestOnlyReached: fn [Src], [Def], [((Text, [Text]))] -> [CDiag]
Array<crate::check::errors::CDiag> test_only_reached_f(const Array<crate::check::errors::Src>& srcs_p0, const Array<crate::check::env::Def>& defs_p1, const Array<std::tuple<Text, Array<Text>>>& refs_p2) {
    auto in_test_p3 = crate::prelude::fold(defs_p1, Map<Text, crate::check::env::Def>{}, [&](const Map<Text, crate::check::env::Def>& m_p4, const crate::check::env::Def& d_p5) {
        return def_role_f(srcs_p0, d_p5) == Text::lit("test")
            ? crate::prelude::insert(m_p4, prism_rtl::deref(d_p5).qk_p, d_p5)
            : m_p4;
    });
    return crate::prelude::size(in_test_p3) == Nat(0u)
        ? Array<crate::check::errors::CDiag>{}
        : ({
        auto by_key_p6 = crate::prelude::fold(defs_p1, Map<Text, crate::check::env::Def>{}, [&](const Map<Text, crate::check::env::Def>& m_p7, const crate::check::env::Def& d_p8) { return crate::prelude::insert(m_p7, prism_rtl::deref(d_p8).qk_p, d_p8); });
        (crate::prelude::fold(refs_p2, Array<crate::check::errors::CDiag>{}, [&](const Array<crate::check::errors::CDiag>& acc_p9, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k_pa = std::get<0>(_p1);
        auto&& rs_pb = std::get<1>(_p1);
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::errors::CDiag>> _v;
            auto&& _m = crate::prelude::get(by_key_p6, k_pa);
            if (prism_rtl::is_some(_m)) {
                auto&& d_pc = prism_rtl::some_of(_m);
                _v.set(def_role_f(srcs_p0, d_pc) == Text::lit("test")
                    ? acc_p9
                    : crate::prelude::fold(rs_pb, acc_p9, [&](const Array<crate::check::errors::CDiag>& a_pd, const Text& r_pe) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::check::errors::CDiag>> _v;
                        auto&& _m = crate::prelude::get(in_test_p3, r_pe);
                        if (prism_rtl::is_some(_m)) {
                            auto&& t_pf = prism_rtl::some_of(_m);
                            _v.set(crate::prelude::push(a_pd, crate::check::errors::CDiag{.code_p = Text::lit("test-only-reached"), .file_p = prism_rtl::deref(d_pc).file_p, .span_p = prism_rtl::deref(d_pc).span_p, .message_p = prism_rtl::cat("`", prism_rtl::deref(d_pc).name_p, "` names `", prism_rtl::deref(t_pf).qk_p, "`, which a test module declares (", last_path_part_f(prism_rtl::deref(crate::check::errors::seg_at_f(crate::prelude::or_(crate::prelude::index(srcs_p0, prism_rtl::deref(t_pf).file_p), crate::check::errors::mk_src_f(Text::lit(""), Text::lit(""))), prism_rtl::deref(prism_rtl::deref(t_pf).span_p).start_p)).path_p), "): only test modules name it"), .fix_p = prism_rtl::cat("move `", prism_rtl::deref(t_pf).qk_p, "` out of the test module, or `", prism_rtl::deref(d_pc).name_p, "` into one")}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(a_pd);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc_p9);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }));
    });
}


/// DefRole: fn [Src], Def -> Text
Text def_role_f(const Array<crate::check::errors::Src>& srcs_p0, const crate::check::env::Def& d_p1) {
    return prism_rtl::deref(crate::check::errors::seg_at_f(crate::prelude::or_(crate::prelude::index(srcs_p0, d_p1.file_p), crate::check::errors::mk_src_f(Text::lit(""), Text::lit(""))), prism_rtl::deref(d_p1.span_p).start_p)).role_p;
}


/// LastPathPart: fn Text -> Text
Text last_path_part_f(const Text& p_p0) {
    return crate::prelude::or_(crate::syntax::lexer::chars::last_o(crate::prelude::split_on(p_p0, Text::lit("/"))), p_p0);
}


/// IsTestingDef: fn Def -> Bool
bool is_testing_def_f(const crate::check::env::Def& d_p0) {
    auto&& _m = d_p0.body_p;
    if (prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbTest>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// IsMethodDef: fn Def -> Bool
bool is_method_def_f(const crate::check::env::Def& d_p0) {
    auto&& _m = d_p0.body_p;
    if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
        return true;
    }
    {
        return false;
    }
}

}  // namespace crate::check::shrink


// The module `Check.Shrink.Calls`, from `target/bootstrap/cpp-src/prismc/check/shrink/calls.prism`.
namespace crate::check::shrink::calls {

void Slot_::show(Printer& p) const {
    p.record("Slot", {{"owner", owner_p}, {"at", at_p}, {"arity", arity_p}});
}

Pod Slot_::to_pod() const {
    return Pod::record("Slot", {{"owner", prism_rtl::to_pod(owner_p)}, {"at", prism_rtl::to_pod(at_p)}, {"arity", prism_rtl::to_pod(arity_p)}});
}

Result<Slot_> Slot_::from_pod(const Pod& whole) {
    return Slot_{.owner_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "owner")))), .at_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "at")))), .arity_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "arity"))))};
}


/// HofSeeds: unbounded fn Shrink, [Text] -> (Text ==> (Text ==> Rel))
Map<Text, Map<Text, crate::check::shrink::Rel>> hof_seeds_f(const crate::check::shrink::Shrink& sk_p0, const Array<Text>& homes_p1) {
    auto cands_p2 = hof_candidates_f(sk_p0);
    auto cleared_p3 = clear_slots_f(sk_p0, homes_p1, cands_p2, Nat(0u));
    auto sums_p4 = slot_sums_f(sk_p0, homes_p1, cleared_p3, top_sums_f(cleared_p3), Nat(0u));
    return crate::prelude::fold(homes_p1, Map<Text, Map<Text, crate::check::shrink::Rel>>{}, [&](const Map<Text, Map<Text, crate::check::shrink::Rel>>& m_p5, const Text& h_p6) { return crate::prelude::insert(m_p5, h_p6, slot_seeds_f(sk_p0, h_p6, cleared_p3, sums_p4, false)); });
}


prism_rtl::Turn<Map<Text, Map<Text, crate::check::shrink::Rel>>> HofSeeds::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& homes_p1 = this->homes_p1;
    auto cands_p2 = hof_candidates_f(sk_p0);
    auto homes_p1x = homes_p1;
    auto sk_p0x = sk_p0;
    return crate::prelude::call_then(start_clear_slots_f(sk_p0x, homes_p1x, cands_p2, Nat(0u)), [=](Array<Slot_> clear_slots_f_2618) {
        return ({
            auto cleared_p3 = clear_slots_f_2618;
            (crate::prelude::call_then(start_slot_sums_f(sk_p0x, homes_p1x, cleared_p3, top_sums_f(cleared_p3), Nat(0u)), [=](Map<Text, crate::check::shrink::Rel> slot_sums_f_2664) {
            return ({
                auto sums_p4 = slot_sums_f_2664;
                (prism_rtl::finished(crate::prelude::fold(homes_p1x, Map<Text, Map<Text, crate::check::shrink::Rel>>{}, [&](const Map<Text, Map<Text, crate::check::shrink::Rel>>& m_p5, const Text& h_p6) { return crate::prelude::insert(m_p5, h_p6, slot_seeds_f(sk_p0x, h_p6, cleared_p3, sums_p4, false)); })));
            });
        }));
        });
    });
}


/// `Start HofSeeds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Map<Text, crate::check::shrink::Rel>>> start_hof_seeds_f(crate::check::shrink::Shrink sk_p0, Array<Text> homes_p1) {
    return prism_rtl::make_rc<HofSeeds>(sk_p0, homes_p1);
}


/// HofCandidates: fn Shrink -> [Slot]
Array<Slot_> hof_candidates_f(const crate::check::shrink::Shrink& sk_p0) {
    return crate::prelude::fold(sk_p0.fns_p, Array<Slot_>{}, [&](const Array<Slot_>& acc_p1, const crate::check::env::Def& d_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Slot_>> _v;
            auto&& _m = prism_rtl::deref(d_p2).body_p;
            if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
                auto&& clauses_p3 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Slot_>> _v;
                    auto&& _m = crate::prelude::get(prism_rtl::deref(sk_p0.g_p).vals_p, prism_rtl::deref(d_p2).qk_p);
                    if (prism_rtl::is_some(_m)) {
                        auto&& v_p4 = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Slot_>> _v;
                            auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p4).scheme_p).ty_p;
                            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                                auto&& ps_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
                                _v.set(crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(ps_p5)), acc_p1, [&](const Array<Slot_>& a2_p6, const Nat& j_p7) {
                                    return ({
                                        __label__ _done;
                                        prism_rtl::Slot<Array<Slot_>> _v;
                                        auto&& _m = crate::prelude::index(ps_p5, j_p7);
                                        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m))) {
                                            auto&& fps_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m)).a1;
                                            _v.set(crate::prelude::fold(clauses_p3, true, [&](const bool& ok_p9, const crate::syntax::decls::FnClause& c_pa) { return prism_rtl::deref(ok_p9) && slot_named_f(c_pa, j_p7); })
                                                ? crate::prelude::push(a2_p6, Slot_{.owner_p = prism_rtl::deref(d_p2).qk_p, .at_p = j_p7, .arity_p = crate::prelude::len(fps_p8)})
                                                : a2_p6);
                                            goto _done;
                                        }
                                        {
                                            _v.set(a2_p6);
                                            goto _done;
                                        }
                                    _done:
                                        _v.take();
                                    });
                                }));
                                goto _done;
                            }
                            {
                                _v.set(acc_p1);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc_p1);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// SlotNamed: fn FnClause, Nat -> Bool
bool slot_named_f(const crate::syntax::decls::FnClause& c_p0, const Nat& j_p1) {
    auto&& _m = crate::prelude::index(c_p0.params_p, j_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& p_p2 = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p2).kind_p);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            return true;
        }
        if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// SlotName: fn FnClause, Nat -> Text
Text slot_name_f(const crate::syntax::decls::FnClause& c_p0, const Nat& j_p1) {
    auto&& _m = crate::prelude::index(c_p0.params_p, j_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& p_p2 = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p2).kind_p);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n_p3 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return crate::check::env::sname_key_f(n_p3);
        }
        {
            return Text::lit("");
        }
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SlotSeeds: fn Shrink, Text, [Slot], (Text ==> Rel), Bool -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> slot_seeds_f(const crate::check::shrink::Shrink& sk_p0, const Text& h_p1, const Array<Slot_>& slots_p2, const Map<Text, crate::check::shrink::Rel>& sums_p3, const bool& with_top_p4) {
    auto pre_p5 = crate::prelude::or_(crate::prelude::get(sk_p0.seeds_p, h_p1), Map<Text, crate::check::shrink::Rel>{});
    auto start_p6 = with_top_p4
        ? crate::prelude::insert(pre_p5, Text::lit("⊤"), crate::check::shrink::Rel{.param_p = crate::check::shrink::walk::top_param_p(), .strict_p = false})
        : pre_p5;
    return crate::prelude::fold(slots_p2, start_p6, [&](const Map<Text, crate::check::shrink::Rel>& m_p7, const Slot_& sl_p8) {
        return crate::prelude::fold(spellings_f(sk_p0.g_p, h_p1, prism_rtl::deref(sl_p8).owner_p), m_p7, [&](const Map<Text, crate::check::shrink::Rel>& m2_p9, const Text& sp_pa) {
            return ({
                auto m3_pb = crate::prelude::insert(m2_p9, prism_rtl::cat("acc:", sp_pa, ":", prism_rtl::deref(sl_p8).at_p), crate::check::shrink::Rel{.param_p = prism_rtl::deref(sl_p8).arity_p, .strict_p = false});
                (crate::prelude::fold(crate::check::errors::range0_f(prism_rtl::deref(sl_p8).arity_p), m3_pb, [&](const Map<Text, crate::check::shrink::Rel>& m4_pc, const Nat& q_pd) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
                    auto&& _m = crate::prelude::get(sums_p3, prism_rtl::cat(prism_rtl::deref(sl_p8).owner_p, ":", prism_rtl::deref(sl_p8).at_p, ":", q_pd));
                    if (prism_rtl::is_some(_m)) {
                        auto&& r_pe = prism_rtl::some_of(_m);
                        _v.set((prism_rtl::deref(r_pe).param_p == crate::check::shrink::walk::top_param_p()) && (!with_top_p4)
                            ? m4_pc
                            : crate::prelude::insert(m4_pc, prism_rtl::cat("sum:", sp_pa, ":", prism_rtl::deref(sl_p8).at_p, ":", q_pd), r_pe));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(m4_pc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
            }));
            });
        });
    });
}


/// Spellings: fn G, Text, Text -> [Text]
Array<Text> spellings_f(const crate::check::env::G& g_p0, const Text& h_p1, const Text& k_p2) {
    return crate::prelude::filter(crate::check::types::add_text_f(Array(std::vector{crate::check::types::bare_name_f(k_p2)}), k_p2), [&](const Text& sp_p3) { return crate::check::shrink::locals::resolve_name_o(g_p0, h_p1, sp_p3) == std::optional(k_p2); });
}


/// ClearSlots: unbounded fn Shrink, [Text], [Slot], Nat -> [Slot]
Array<Slot_> clear_slots_f(const crate::check::shrink::Shrink& sk_p0, const Array<Text>& homes_p1, const Array<Slot_>& slots_p2, const Nat& round_p3) {
    auto sks_p4 = seeds_for_f(sk_p0, homes_p1, slots_p2, Map<Text, crate::check::shrink::Rel>{}, false);
    auto kept_p5 = crate::prelude::run_to_end(crate::prelude::filter_job(slots_p2, ({
        auto sks_p4x = sks_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Slot_)>>(prism_rtl::rc([=, sks_p4x = std::move(sks_p4x)](Slot_ p0) {
        return ({
            auto sks_p4xy = sks_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, sks_p4xy = std::move(sks_p4xy)]() {
            return ({
                auto sl_p6 = p0;
                (crate::prelude::call_then(start_slot_escapes_f(sks_p4xy, sl_p6), [=](bool slot_escapes_f_5090) { return prism_rtl::finished(!slot_escapes_f_5090); }));
            });
        })));
        });
    })));
    })));
    return crate::prelude::len(kept_p5) == crate::prelude::len(slots_p2)
        ? kept_p5
        : round_p3 > Nat(20u)
        ? Array<Slot_>{}
        : clear_slots_f(sk_p0, homes_p1, kept_p5, round_p3 + Nat(1u));
}


prism_rtl::Turn<Array<Slot_>> ClearSlots::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& homes_p1 = this->homes_p1;
    const auto& slots_p2 = this->slots_p2;
    const auto& round_p3 = this->round_p3;
    auto sks_p4 = seeds_for_f(sk_p0, homes_p1, slots_p2, Map<Text, crate::check::shrink::Rel>{}, false);
    auto homes_p1x = homes_p1;
    auto round_p3x = round_p3;
    auto sk_p0x = sk_p0;
    auto slots_p2x = slots_p2;
    return crate::prelude::call_value(crate::prelude::filter_job(slots_p2x, ({
        auto sks_p4x = sks_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Slot_)>>(prism_rtl::rc([=, sks_p4x = std::move(sks_p4x)](Slot_ p0) {
        return ({
            auto sks_p4xy = sks_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, sks_p4xy = std::move(sks_p4xy)]() {
            return ({
                auto sl_p6 = p0;
                (crate::prelude::call_then(start_slot_escapes_f(sks_p4xy, sl_p6), [=](bool slot_escapes_f_5090) { return prism_rtl::finished(!slot_escapes_f_5090); }));
            });
        })));
        });
    })));
    })), [=](Array<Slot_> filter_5065) {
        return ({
            auto kept_p5 = filter_5065;
            (crate::prelude::len(kept_p5) == crate::prelude::len(slots_p2x)
            ? prism_rtl::finished(kept_p5)
            : round_p3x > Nat(20u)
            ? prism_rtl::finished(Array<Slot_>{})
            : prism_rtl::more(prism_rtl::rc(ClearSlots(sk_p0x, homes_p1x, kept_p5, round_p3x + Nat(1u)))));
        });
    });
}


/// `Start ClearSlots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Slot_>> start_clear_slots_f(crate::check::shrink::Shrink sk_p0, Array<Text> homes_p1, Array<Slot_> slots_p2, Nat round_p3) {
    return prism_rtl::make_rc<ClearSlots>(sk_p0, homes_p1, slots_p2, round_p3);
}


/// SeedsFor: fn Shrink, [Text], [Slot], (Text ==> Rel), Bool -> Shrink
crate::check::shrink::Shrink seeds_for_f(const crate::check::shrink::Shrink& sk_p0, const Array<Text>& homes_p1, const Array<Slot_>& slots_p2, const Map<Text, crate::check::shrink::Rel>& sums_p3, const bool& with_top_p4) {
    crate::check::shrink::Shrink this_ = sk_p0;
    this_.seeds_p = crate::prelude::fold(homes_p1, Map<Text, Map<Text, crate::check::shrink::Rel>>{}, [&](const Map<Text, Map<Text, crate::check::shrink::Rel>>& m_p5, const Text& h_p6) { return crate::prelude::insert(m_p5, h_p6, slot_seeds_f(sk_p0, h_p6, slots_p2, sums_p3, with_top_p4)); });
    return this_;
}


/// SlotEscapes: unbounded fn Shrink, Slot -> Bool
bool slot_escapes_f(const crate::check::shrink::Shrink& sk_p0, const Slot_& sl_p1) {
    auto&& _m = crate::prelude::get(sk_p0.by_key_p, sl_p1.owner_p);
    if (prism_rtl::is_some(_m)) {
        auto&& d_p2 = prism_rtl::some_of(_m);
        return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(d_p2), false, ({
            auto sl_p1x = sl_p1;
            auto sk_p0x = sk_p0;
            auto d_p2x = d_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sl_p1x = std::move(sl_p1x), sk_p0x = std::move(sk_p0x), d_p2x = std::move(d_p2x)](std::tuple<bool, crate::syntax::decls::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto sl_p1xy = sl_p1x;
                auto sk_p0xy = sk_p0x;
                auto d_p2xy = d_p2x;
                (crate::prelude::entered(crate::prelude::once_job([=, sl_p1xy = std::move(sl_p1xy), sk_p0xy = std::move(sk_p0xy), d_p2xy = std::move(d_p2xy)]() {
                return ({
                    auto seen_p3 = p0;
                    auto c_p4 = p1;
                    ({
                    auto n_p5 = slot_name_f(c_p4, prism_rtl::deref(sl_p1xy).at_p);
                    (std::move(seen_p3) || (n_p5 == Text::lit(""))
                    ? prism_rtl::finished(std::move(seen_p3))
                    : crate::prelude::call_then(crate::check::shrink::locals::start_clause_base_f(sk_p0xy, d_p2xy, c_p4), [=](Map<Text, crate::check::shrink::Rel> clause_base_f_5891) {
                    return crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(prism_rtl::deref(c_p4).body_p, clause_base_f_5891), [=](Array<crate::check::shrink::walk::Spot> body_spots_f_5872) {
                        return crate::prelude::fold_job(body_spots_f_5872, false, ({
                            auto n_p5x = n_p5;
                            auto sl_p1xyx = sl_p1xy;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, n_p5x = std::move(n_p5x), sl_p1xyx = std::move(sl_p1xyx)](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto n_p5xy = n_p5x;
                                auto sl_p1xyxy = sl_p1xyx;
                                (crate::prelude::entered(crate::prelude::once_job([=, n_p5xy = std::move(n_p5xy), sl_p1xyxy = std::move(sl_p1xyxy)]() {
                                return ({
                                    auto esc_p6 = p0;
                                    auto sp_p7 = p1;
                                    (prism_rtl::finished(std::move(esc_p6) || spot_escapes_f(sp_p7, n_p5xy, prism_rtl::deref(sl_p1xyxy).at_p)));
                                });
                            })));
                            });
                        })));
                        }))->cycle();
                    });
                }));
                });
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is_none(_m)) {
        return true;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> SlotEscapes::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& sl_p1 = this->sl_p1;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(sk_p0).by_key_p, prism_rtl::deref(sl_p1).owner_p);
        prism_rtl::is_some(_m) ? ({
        auto&& d_p2 = prism_rtl::some_of(_m);
        crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(d_p2), false, ({
        auto sl_p1x = sl_p1;
        auto sk_p0x = sk_p0;
        auto d_p2x = d_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sl_p1x = std::move(sl_p1x), sk_p0x = std::move(sk_p0x), d_p2x = std::move(d_p2x)](std::tuple<bool, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sl_p1xy = sl_p1x;
            auto sk_p0xy = sk_p0x;
            auto d_p2xy = d_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, sl_p1xy = std::move(sl_p1xy), sk_p0xy = std::move(sk_p0xy), d_p2xy = std::move(d_p2xy)]() {
            return ({
                auto seen_p3 = p0;
                auto c_p4 = p1;
                ({
                auto n_p5 = slot_name_f(c_p4, prism_rtl::deref(sl_p1xy).at_p);
                (std::move(seen_p3) || (n_p5 == Text::lit(""))
                ? prism_rtl::finished(std::move(seen_p3))
                : crate::prelude::call_then(crate::check::shrink::locals::start_clause_base_f(sk_p0xy, d_p2xy, c_p4), [=](Map<Text, crate::check::shrink::Rel> clause_base_f_5891) {
                return crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(prism_rtl::deref(c_p4).body_p, clause_base_f_5891), [=](Array<crate::check::shrink::walk::Spot> body_spots_f_5872) {
                    return crate::prelude::fold_job(body_spots_f_5872, false, ({
                        auto n_p5x = n_p5;
                        auto sl_p1xyx = sl_p1xy;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, n_p5x = std::move(n_p5x), sl_p1xyx = std::move(sl_p1xyx)](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto n_p5xy = n_p5x;
                            auto sl_p1xyxy = sl_p1xyx;
                            (crate::prelude::entered(crate::prelude::once_job([=, n_p5xy = std::move(n_p5xy), sl_p1xyxy = std::move(sl_p1xyxy)]() {
                            return ({
                                auto esc_p6 = p0;
                                auto sp_p7 = p1;
                                (prism_rtl::finished(std::move(esc_p6) || spot_escapes_f(sp_p7, n_p5xy, prism_rtl::deref(sl_p1xyxy).at_p)));
                            });
                        })));
                        });
                    })));
                    }))->cycle();
                });
            }));
            });
            });
        })));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(true)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SlotEscapes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_slot_escapes_f(crate::check::shrink::Shrink sk_p0, Slot_ sl_p1) {
    return prism_rtl::make_rc<SlotEscapes>(sk_p0, sl_p1);
}


/// SpotEscapes: unbounded fn Spot, Text, Nat -> Bool
bool spot_escapes_f(const crate::check::shrink::walk::Spot& sp_p0, const Text& n_p1, const Nat& j_p2) {
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(sp_p0)) {
        auto&& e_p3 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(sp_p0).a0;
        auto&& m_p4 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(sp_p0).a1;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p3).kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& x_p5 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return (crate::check::env::sname_key_f(x_p5) == n_p1) && is_slot_param_f(m_p4, n_p1, j_p2);
        }
        {
            return crate::prelude::fold(crate::check::shrink::walk::spot_sites_f(sp_p0), false, [&](const bool& seen_p6, const crate::check::shrink::walk::Site& site_p7) { return prism_rtl::deref(seen_p6) || (((prism_rtl::deref(site_p7).callee_p == n_p1) && is_slot_param_f(prism_rtl::deref(site_p7).rels_p, n_p1, j_p2)) && crate::check::env::has_key_f(prism_rtl::deref(site_p7).rels_p, Text::lit("lam:"))); });
        }
    }
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(sp_p0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> SpotEscapes::cycle() const {
    const auto& sp_p0 = this->sp_p0;
    const auto& n_p1 = this->n_p1;
    const auto& j_p2 = this->j_p2;
    return ({
        prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(sp_p0) ? ({
        auto&& e_p3 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(sp_p0).a0;
        auto&& m_p4 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(sp_p0).a1;
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p3).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& x_p5 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        prism_rtl::finished((crate::check::env::sname_key_f(x_p5) == n_p1) && is_slot_param_f(m_p4, n_p1, j_p2));
    })
        : ({
        auto j_p2x = j_p2;
        auto n_p1x = n_p1;
        auto sp_p0x = sp_p0;
        (crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p0x), [=, j_p2x = std::move(j_p2x), n_p1x = std::move(n_p1x)](Array<crate::check::shrink::walk::Site> spot_sites_f_6182) { return prism_rtl::finished(crate::prelude::fold(spot_sites_f_6182, false, [&](const bool& seen_p6, const crate::check::shrink::walk::Site& site_p7) { return prism_rtl::deref(seen_p6) || (((prism_rtl::deref(site_p7).callee_p == n_p1x) && is_slot_param_f(prism_rtl::deref(site_p7).rels_p, n_p1x, j_p2x)) && crate::check::env::has_key_f(prism_rtl::deref(site_p7).rels_p, Text::lit("lam:"))); })); }));
    });
    });
    })
        : prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(sp_p0) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotEscapes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_spot_escapes_f(crate::check::shrink::walk::Spot sp_p0, Text n_p1, Nat j_p2) {
    return prism_rtl::make_rc<SpotEscapes>(sp_p0, n_p1, j_p2);
}


/// IsSlotParam: fn (Text ==> Rel), Text, Nat -> Bool
bool is_slot_param_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Text& n_p1, const Nat& j_p2) {
    return crate::prelude::get(m_p0, n_p1) == std::optional(crate::check::shrink::Rel{.param_p = j_p2, .strict_p = false});
}


/// TopSums: fn [Slot] -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> top_sums_f(const Array<Slot_>& slots_p0) {
    return crate::prelude::fold(slots_p0, Map<Text, crate::check::shrink::Rel>{}, [&](const Map<Text, crate::check::shrink::Rel>& m_p1, const Slot_& sl_p2) { return crate::prelude::fold(crate::check::errors::range0_f(prism_rtl::deref(sl_p2).arity_p), m_p1, [&](const Map<Text, crate::check::shrink::Rel>& m2_p3, const Nat& q_p4) { return crate::prelude::insert(m2_p3, prism_rtl::cat(prism_rtl::deref(sl_p2).owner_p, ":", prism_rtl::deref(sl_p2).at_p, ":", q_p4), crate::check::shrink::Rel{.param_p = crate::check::shrink::walk::top_param_p(), .strict_p = false}); }); });
}


/// SlotSums: unbounded fn Shrink, [Text], [Slot], (Text ==> Rel), Nat -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> slot_sums_f(const crate::check::shrink::Shrink& sk_p0, const Array<Text>& homes_p1, const Array<Slot_>& slots_p2, const Map<Text, crate::check::shrink::Rel>& sums_p3, const Nat& round_p4) {
    auto sks_p5 = seeds_for_f(sk_p0, homes_p1, slots_p2, sums_p3, true);
    auto next_p6 = crate::prelude::run_to_end(crate::prelude::fold_job(slots_p2, Map<Text, crate::check::shrink::Rel>{}, ({
        auto sks_p5x = sks_p5;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Slot_>)>>(prism_rtl::rc([=, sks_p5x = std::move(sks_p5x)](std::tuple<Map<Text, crate::check::shrink::Rel>, Slot_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sks_p5xy = sks_p5x;
            (crate::prelude::entered(crate::prelude::once_job([=, sks_p5xy = std::move(sks_p5xy)]() {
            return ({
                auto m_p7 = p0;
                auto sl_p8 = p1;
                (crate::prelude::call_then(start_slot_calls_f(sks_p5xy, sl_p8), [=, m_p7 = std::move(m_p7)](Array<crate::check::shrink::walk::Site> slot_calls_f_7327) {
                return ({
                    auto calls_p9 = slot_calls_f_7327;
                    (crate::prelude::fold_job(crate::check::errors::range0_f(prism_rtl::deref(sl_p8).arity_p), m_p7, ({
                    auto calls_p9x = calls_p9;
                    auto sl_p8x = sl_p8;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Nat>)>>(prism_rtl::rc([=, calls_p9x = std::move(calls_p9x), sl_p8x = std::move(sl_p8x)](std::tuple<Map<Text, crate::check::shrink::Rel>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto calls_p9xy = calls_p9x;
                        auto sl_p8xy = sl_p8x;
                        (crate::prelude::entered(crate::prelude::once_job([=, calls_p9xy = std::move(calls_p9xy), sl_p8xy = std::move(sl_p8xy)]() {
                        return ({
                            auto m2_pa = p0;
                            auto q_pb = p1;
                            (crate::prelude::call_then(start_meet_args_o(calls_p9xy, q_pb), [=, m2_pa = std::move(m2_pa)](std::optional<crate::check::shrink::Rel> meet_args_o_7395) {
                            return ({
                                prism_rtl::is_some(meet_args_o_7395) ? ({
                                auto&& r_pc = prism_rtl::some_of(meet_args_o_7395);
                                prism_rtl::finished(crate::prelude::insert(m2_pa, prism_rtl::cat(prism_rtl::deref(sl_p8xy).owner_p, ":", prism_rtl::deref(sl_p8xy).at_p, ":", q_pb), r_pc));
                            })
                                : prism_rtl::is_none(meet_args_o_7395) ? prism_rtl::finished(m2_pa)
                                : throw prism_rtl::Panic("no arm matched");
                            });
                        }));
                        });
                    })));
                    });
                }));
                }))->cycle());
                });
            }));
            });
        })));
        });
    }));
    })));
    return next_p6 == sums_p3
        ? next_p6
        : round_p4 > Nat(12u)
        ? Map<Text, crate::check::shrink::Rel>{}
        : slot_sums_f(sk_p0, homes_p1, slots_p2, next_p6, round_p4 + Nat(1u));
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> SlotSums::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& homes_p1 = this->homes_p1;
    const auto& slots_p2 = this->slots_p2;
    const auto& sums_p3 = this->sums_p3;
    const auto& round_p4 = this->round_p4;
    auto sks_p5 = seeds_for_f(sk_p0, homes_p1, slots_p2, sums_p3, true);
    auto homes_p1x = homes_p1;
    auto round_p4x = round_p4;
    auto sk_p0x = sk_p0;
    auto slots_p2x = slots_p2;
    auto sums_p3x = sums_p3;
    return crate::prelude::call_value(crate::prelude::fold_job(slots_p2x, Map<Text, crate::check::shrink::Rel>{}, ({
        auto sks_p5x = sks_p5;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Slot_>)>>(prism_rtl::rc([=, sks_p5x = std::move(sks_p5x)](std::tuple<Map<Text, crate::check::shrink::Rel>, Slot_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sks_p5xy = sks_p5x;
            (crate::prelude::entered(crate::prelude::once_job([=, sks_p5xy = std::move(sks_p5xy)]() {
            return ({
                auto m_p7 = p0;
                auto sl_p8 = p1;
                (crate::prelude::call_then(start_slot_calls_f(sks_p5xy, sl_p8), [=, m_p7 = std::move(m_p7)](Array<crate::check::shrink::walk::Site> slot_calls_f_7327) {
                return ({
                    auto calls_p9 = slot_calls_f_7327;
                    (crate::prelude::fold_job(crate::check::errors::range0_f(prism_rtl::deref(sl_p8).arity_p), m_p7, ({
                    auto calls_p9x = calls_p9;
                    auto sl_p8x = sl_p8;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Nat>)>>(prism_rtl::rc([=, calls_p9x = std::move(calls_p9x), sl_p8x = std::move(sl_p8x)](std::tuple<Map<Text, crate::check::shrink::Rel>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto calls_p9xy = calls_p9x;
                        auto sl_p8xy = sl_p8x;
                        (crate::prelude::entered(crate::prelude::once_job([=, calls_p9xy = std::move(calls_p9xy), sl_p8xy = std::move(sl_p8xy)]() {
                        return ({
                            auto m2_pa = p0;
                            auto q_pb = p1;
                            (crate::prelude::call_then(start_meet_args_o(calls_p9xy, q_pb), [=, m2_pa = std::move(m2_pa)](std::optional<crate::check::shrink::Rel> meet_args_o_7395) {
                            return ({
                                prism_rtl::is_some(meet_args_o_7395) ? ({
                                auto&& r_pc = prism_rtl::some_of(meet_args_o_7395);
                                prism_rtl::finished(crate::prelude::insert(m2_pa, prism_rtl::cat(prism_rtl::deref(sl_p8xy).owner_p, ":", prism_rtl::deref(sl_p8xy).at_p, ":", q_pb), r_pc));
                            })
                                : prism_rtl::is_none(meet_args_o_7395) ? prism_rtl::finished(m2_pa)
                                : throw prism_rtl::Panic("no arm matched");
                            });
                        }));
                        });
                    })));
                    });
                }));
                }))->cycle());
                });
            }));
            });
        })));
        });
    }));
    })), [=](Map<Text, crate::check::shrink::Rel> fold_7282) {
        return ({
            auto next_p6 = fold_7282;
            next_p6 == sums_p3x
            ? prism_rtl::finished(next_p6)
            : round_p4x > Nat(12u)
            ? prism_rtl::finished(Map<Text, crate::check::shrink::Rel>{})
            : prism_rtl::more(prism_rtl::rc(SlotSums(sk_p0x, homes_p1x, slots_p2x, next_p6, round_p4x + Nat(1u))));
        });
    });
}


/// `Start SlotSums, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_slot_sums_f(crate::check::shrink::Shrink sk_p0, Array<Text> homes_p1, Array<Slot_> slots_p2, Map<Text, crate::check::shrink::Rel> sums_p3, Nat round_p4) {
    return prism_rtl::make_rc<SlotSums>(sk_p0, homes_p1, slots_p2, sums_p3, round_p4);
}


/// SlotCalls: unbounded fn Shrink, Slot -> [Site]
Array<crate::check::shrink::walk::Site> slot_calls_f(const crate::check::shrink::Shrink& sk_p0, const Slot_& sl_p1) {
    auto&& _m = crate::prelude::get(sk_p0.by_key_p, sl_p1.owner_p);
    if (prism_rtl::is_some(_m)) {
        auto&& d_p2 = prism_rtl::some_of(_m);
        return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(d_p2), Array<crate::check::shrink::walk::Site>{}, ({
            auto sl_p1x = sl_p1;
            auto sk_p0x = sk_p0;
            auto d_p2x = d_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>>(std::tuple<Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sl_p1x = std::move(sl_p1x), sk_p0x = std::move(sk_p0x), d_p2x = std::move(d_p2x)](std::tuple<Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto sl_p1xy = sl_p1x;
                auto sk_p0xy = sk_p0x;
                auto d_p2xy = d_p2x;
                (crate::prelude::entered(crate::prelude::once_job([=, sl_p1xy = std::move(sl_p1xy), sk_p0xy = std::move(sk_p0xy), d_p2xy = std::move(d_p2xy)]() {
                return ({
                    auto acc_p3 = p0;
                    auto c_p4 = p1;
                    ({
                    auto n_p5 = slot_name_f(c_p4, prism_rtl::deref(sl_p1xy).at_p);
                    n_p5 == Text::lit("")
                    ? prism_rtl::finished(acc_p3)
                    : crate::prelude::call_then(crate::check::shrink::locals::start_clause_base_f(sk_p0xy, d_p2xy, c_p4), [=](Map<Text, crate::check::shrink::Rel> clause_base_f_7920) {
                    return ({
                        auto base_p6 = clause_base_f_7920;
                        (crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(prism_rtl::deref(c_p4).body_p, base_p6), [=](Array<crate::check::shrink::walk::Spot> body_spots_f_7984) {
                        return crate::prelude::call_then(crate::check::shrink::summaries::start_summary_seeds_f(sk_p0xy, d_p2xy, body_spots_f_7984, base_p6), [=](Map<Text, crate::check::shrink::Rel> summary_seeds_f_7963) {
                            return ({
                                auto rels_p7 = summary_seeds_f_7963;
                                (crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(prism_rtl::deref(c_p4).body_p, rels_p7), [=](Array<crate::check::shrink::walk::Spot> body_spots_f_8032) {
                                return crate::prelude::fold_job(body_spots_f_8032, acc_p3, ({
                                    auto n_p5x = n_p5;
                                    auto sl_p1xyx = sl_p1xy;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>>(std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, n_p5x = std::move(n_p5x), sl_p1xyx = std::move(sl_p1xyx)](std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto n_p5xy = n_p5x;
                                        auto sl_p1xyxy = sl_p1xyx;
                                        (crate::prelude::entered(crate::prelude::once_job([=, n_p5xy = std::move(n_p5xy), sl_p1xyxy = std::move(sl_p1xyxy)]() {
                                        return ({
                                            auto a2_p8 = p0;
                                            auto sp_p9 = p1;
                                            ({
                                            prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(sp_p9) ? ({
                                            auto&& e_pa = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(sp_p9).a0;
                                            ({
                                            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_pa).kind_p);
                                            prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? prism_rtl::finished(a2_p8)
                                            : crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p9), [=](Array<crate::check::shrink::walk::Site> spot_sites_f_8220) { return prism_rtl::finished(crate::prelude::append(a2_p8, crate::prelude::filter(spot_sites_f_8220, [&](const crate::check::shrink::walk::Site& site_pb) { return (prism_rtl::deref(site_pb).callee_p == n_p5xy) && is_slot_param_f(prism_rtl::deref(site_pb).rels_p, n_p5xy, prism_rtl::deref(sl_p1xyxy).at_p); }))); });
                                        });
                                        })
                                            : prism_rtl::finished(a2_p8);
                                        });
                                        });
                                    })));
                                    });
                                })));
                                }))->cycle();
                            }));
                            });
                        });
                    }));
                    });
                });
                });
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is_none(_m)) {
        return Array<crate::check::shrink::walk::Site>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::check::shrink::walk::Site>> SlotCalls::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& sl_p1 = this->sl_p1;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(sk_p0).by_key_p, prism_rtl::deref(sl_p1).owner_p);
        prism_rtl::is_some(_m) ? ({
        auto&& d_p2 = prism_rtl::some_of(_m);
        crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(d_p2), Array<crate::check::shrink::walk::Site>{}, ({
        auto sl_p1x = sl_p1;
        auto sk_p0x = sk_p0;
        auto d_p2x = d_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>>(std::tuple<Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sl_p1x = std::move(sl_p1x), sk_p0x = std::move(sk_p0x), d_p2x = std::move(d_p2x)](std::tuple<Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sl_p1xy = sl_p1x;
            auto sk_p0xy = sk_p0x;
            auto d_p2xy = d_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, sl_p1xy = std::move(sl_p1xy), sk_p0xy = std::move(sk_p0xy), d_p2xy = std::move(d_p2xy)]() {
            return ({
                auto acc_p3 = p0;
                auto c_p4 = p1;
                ({
                auto n_p5 = slot_name_f(c_p4, prism_rtl::deref(sl_p1xy).at_p);
                n_p5 == Text::lit("")
                ? prism_rtl::finished(acc_p3)
                : crate::prelude::call_then(crate::check::shrink::locals::start_clause_base_f(sk_p0xy, d_p2xy, c_p4), [=](Map<Text, crate::check::shrink::Rel> clause_base_f_7920) {
                return ({
                    auto base_p6 = clause_base_f_7920;
                    (crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(prism_rtl::deref(c_p4).body_p, base_p6), [=](Array<crate::check::shrink::walk::Spot> body_spots_f_7984) {
                    return crate::prelude::call_then(crate::check::shrink::summaries::start_summary_seeds_f(sk_p0xy, d_p2xy, body_spots_f_7984, base_p6), [=](Map<Text, crate::check::shrink::Rel> summary_seeds_f_7963) {
                        return ({
                            auto rels_p7 = summary_seeds_f_7963;
                            (crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(prism_rtl::deref(c_p4).body_p, rels_p7), [=](Array<crate::check::shrink::walk::Spot> body_spots_f_8032) {
                            return crate::prelude::fold_job(body_spots_f_8032, acc_p3, ({
                                auto n_p5x = n_p5;
                                auto sl_p1xyx = sl_p1xy;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>>(std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, n_p5x = std::move(n_p5x), sl_p1xyx = std::move(sl_p1xyx)](std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot> _p0) {
                                auto&& p0 = std::get<0>(_p0);
                                auto&& p1 = std::get<1>(_p0);
                                return ({
                                    auto n_p5xy = n_p5x;
                                    auto sl_p1xyxy = sl_p1xyx;
                                    (crate::prelude::entered(crate::prelude::once_job([=, n_p5xy = std::move(n_p5xy), sl_p1xyxy = std::move(sl_p1xyxy)]() {
                                    return ({
                                        auto a2_p8 = p0;
                                        auto sp_p9 = p1;
                                        ({
                                        prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(sp_p9) ? ({
                                        auto&& e_pa = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(sp_p9).a0;
                                        ({
                                        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_pa).kind_p);
                                        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? prism_rtl::finished(a2_p8)
                                        : crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p9), [=](Array<crate::check::shrink::walk::Site> spot_sites_f_8220) { return prism_rtl::finished(crate::prelude::append(a2_p8, crate::prelude::filter(spot_sites_f_8220, [&](const crate::check::shrink::walk::Site& site_pb) { return (prism_rtl::deref(site_pb).callee_p == n_p5xy) && is_slot_param_f(prism_rtl::deref(site_pb).rels_p, n_p5xy, prism_rtl::deref(sl_p1xyxy).at_p); }))); });
                                    });
                                    })
                                        : prism_rtl::finished(a2_p8);
                                    });
                                    });
                                })));
                                });
                            })));
                            }))->cycle();
                        }));
                        });
                    });
                }));
                });
            });
            });
            });
        })));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Array<crate::check::shrink::walk::Site>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SlotCalls, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>> start_slot_calls_f(crate::check::shrink::Shrink sk_p0, Slot_ sl_p1) {
    return prism_rtl::make_rc<SlotCalls>(sk_p0, sl_p1);
}


/// ?MeetArgs: unbounded fn [Site], Nat -> ?Rel
std::optional<crate::check::shrink::Rel> meet_args_o(const Array<crate::check::shrink::walk::Site>& calls_p0, const Nat& q_p1) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(calls_p0, std::optional(crate::check::shrink::Rel{.param_p = crate::check::shrink::walk::top_param_p(), .strict_p = false}), ({
        auto q_p1x = q_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>>(std::tuple<std::optional<crate::check::shrink::Rel>, crate::check::shrink::walk::Site>)>>(prism_rtl::rc([=, q_p1x = std::move(q_p1x)](std::tuple<std::optional<crate::check::shrink::Rel>, crate::check::shrink::walk::Site> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto q_p1xy = q_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, q_p1xy = std::move(q_p1xy)]() {
            return ({
                auto acc_o2 = p0;
                auto site_p3 = p1;
                ({
                prism_rtl::is_none(acc_o2) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                : prism_rtl::is_some(acc_o2) ? ({
                auto&& acc_p4 = prism_rtl::some_of(acc_o2);
                ({
                auto&& _m = crate::prelude::index(prism_rtl::deref(site_p3).args_p, q_p1xy);
                prism_rtl::is_some(_m) ? ({
                auto&& a_p5 = prism_rtl::some_of(_m);
                prism_rtl::deref(a_p5).name_o != std::optional<crate::syntax::Ident>{}
                ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                : ({
                auto acc_p4x = acc_p4;
                (crate::prelude::call_then(crate::check::shrink::walk::start_rel_of_o(prism_rtl::deref(site_p3).rels_p, prism_rtl::deref(a_p5).value_p), [=, acc_p4x = std::move(acc_p4x)](std::optional<crate::check::shrink::Rel> rel_of_o_8797) {
                return ({
                    prism_rtl::is_some(rel_of_o_8797) ? ({
                    auto&& r_p6 = prism_rtl::some_of(rel_of_o_8797);
                    prism_rtl::deref(r_p6).param_p == crate::check::shrink::walk::top_param_p()
                    ? prism_rtl::finished(std::optional(acc_p4x))
                    : prism_rtl::deref(acc_p4x).param_p == crate::check::shrink::walk::top_param_p()
                    ? prism_rtl::finished(std::optional(r_p6))
                    : prism_rtl::deref(acc_p4x).param_p == prism_rtl::deref(r_p6).param_p
                    ? prism_rtl::finished(std::optional(crate::check::shrink::Rel{.param_p = prism_rtl::deref(r_p6).param_p, .strict_p = prism_rtl::deref(acc_p4x).strict_p && prism_rtl::deref(r_p6).strict_p}))
                    : prism_rtl::finished(std::optional<crate::check::shrink::Rel>{});
                })
                    : prism_rtl::is_none(rel_of_o_8797) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            }));
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<std::optional<crate::check::shrink::Rel>> MeetArgs::cycle() const {
    const auto& calls_p0 = this->calls_p0;
    const auto& q_p1 = this->q_p1;
    return crate::prelude::fold_job(calls_p0, std::optional(crate::check::shrink::Rel{.param_p = crate::check::shrink::walk::top_param_p(), .strict_p = false}), ({
        auto q_p1x = q_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>>(std::tuple<std::optional<crate::check::shrink::Rel>, crate::check::shrink::walk::Site>)>>(prism_rtl::rc([=, q_p1x = std::move(q_p1x)](std::tuple<std::optional<crate::check::shrink::Rel>, crate::check::shrink::walk::Site> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto q_p1xy = q_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, q_p1xy = std::move(q_p1xy)]() {
            return ({
                auto acc_o2 = p0;
                auto site_p3 = p1;
                ({
                prism_rtl::is_none(acc_o2) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                : prism_rtl::is_some(acc_o2) ? ({
                auto&& acc_p4 = prism_rtl::some_of(acc_o2);
                ({
                auto&& _m = crate::prelude::index(prism_rtl::deref(site_p3).args_p, q_p1xy);
                prism_rtl::is_some(_m) ? ({
                auto&& a_p5 = prism_rtl::some_of(_m);
                prism_rtl::deref(a_p5).name_o != std::optional<crate::syntax::Ident>{}
                ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                : ({
                auto acc_p4x = acc_p4;
                (crate::prelude::call_then(crate::check::shrink::walk::start_rel_of_o(prism_rtl::deref(site_p3).rels_p, prism_rtl::deref(a_p5).value_p), [=, acc_p4x = std::move(acc_p4x)](std::optional<crate::check::shrink::Rel> rel_of_o_8797) {
                return ({
                    prism_rtl::is_some(rel_of_o_8797) ? ({
                    auto&& r_p6 = prism_rtl::some_of(rel_of_o_8797);
                    prism_rtl::deref(r_p6).param_p == crate::check::shrink::walk::top_param_p()
                    ? prism_rtl::finished(std::optional(acc_p4x))
                    : prism_rtl::deref(acc_p4x).param_p == crate::check::shrink::walk::top_param_p()
                    ? prism_rtl::finished(std::optional(r_p6))
                    : prism_rtl::deref(acc_p4x).param_p == prism_rtl::deref(r_p6).param_p
                    ? prism_rtl::finished(std::optional(crate::check::shrink::Rel{.param_p = prism_rtl::deref(r_p6).param_p, .strict_p = prism_rtl::deref(acc_p4x).strict_p && prism_rtl::deref(r_p6).strict_p}))
                    : prism_rtl::finished(std::optional<crate::check::shrink::Rel>{});
                })
                    : prism_rtl::is_none(rel_of_o_8797) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            }));
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start MeetArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>> start_meet_args_o(Array<crate::check::shrink::walk::Site> calls_p0, Nat q_p1) {
    return prism_rtl::make_rc<MeetArgs>(calls_p0, q_p1);
}


/// DefRefs: unbounded fn Shrink, Def -> [Text]
Array<Text> def_refs_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(d_p1), Array<Text>{}, ({
        auto sk_p0x = sk_p0;
        auto d_p1x = d_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sk_p0x = std::move(sk_p0x), d_p1x = std::move(d_p1x)](std::tuple<Array<Text>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0xy = sk_p0x;
            auto d_p1xy = d_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xy = std::move(sk_p0xy), d_p1xy = std::move(d_p1xy)]() {
            return ({
                auto acc_p2 = p0;
                auto c_p3 = p1;
                (crate::prelude::call_then(crate::check::shrink::locals::start_clause_base_f(sk_p0xy, d_p1xy, c_p3), [=, acc_p2 = std::move(acc_p2)](Map<Text, crate::check::shrink::Rel> clause_base_f_9334) { return crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(prism_rtl::deref(c_p3).body_p, clause_base_f_9334), [=](Array<crate::check::shrink::walk::Spot> body_spots_f_9315) { return prism_rtl::more(prism_rtl::rc(SpotsRefs(sk_p0xy, d_p1xy, body_spots_f_9315, acc_p2))); }); }));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> DefRefs::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& d_p1 = this->d_p1;
    return crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(d_p1), Array<Text>{}, ({
        auto sk_p0x = sk_p0;
        auto d_p1x = d_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sk_p0x = std::move(sk_p0x), d_p1x = std::move(d_p1x)](std::tuple<Array<Text>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0xy = sk_p0x;
            auto d_p1xy = d_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xy = std::move(sk_p0xy), d_p1xy = std::move(d_p1xy)]() {
            return ({
                auto acc_p2 = p0;
                auto c_p3 = p1;
                (crate::prelude::call_then(crate::check::shrink::locals::start_clause_base_f(sk_p0xy, d_p1xy, c_p3), [=, acc_p2 = std::move(acc_p2)](Map<Text, crate::check::shrink::Rel> clause_base_f_9334) { return crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(prism_rtl::deref(c_p3).body_p, clause_base_f_9334), [=](Array<crate::check::shrink::walk::Spot> body_spots_f_9315) { return prism_rtl::more(prism_rtl::rc(SpotsRefs(sk_p0xy, d_p1xy, body_spots_f_9315, acc_p2))); }); }));
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start DefRefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_def_refs_f(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1) {
    return prism_rtl::make_rc<DefRefs>(sk_p0, d_p1);
}


/// SpotsRefs: unbounded fn Shrink, Def, [Spot], [Text] -> [Text]
Array<Text> spots_refs_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const Array<crate::check::shrink::walk::Spot>& spots_p2, const Array<Text>& acc_p3) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(spots_p2, acc_p3, ({
        auto sk_p0x = sk_p0;
        auto d_p1x = d_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, sk_p0x = std::move(sk_p0x), d_p1x = std::move(d_p1x)](std::tuple<Array<Text>, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0xy = sk_p0x;
            auto d_p1xy = d_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xy = std::move(sk_p0xy), d_p1xy = std::move(d_p1xy)]() {
            return ({
                auto a1_p4 = p0;
                auto sp_p5 = p1;
                (crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p5), [=, a1_p4 = std::move(a1_p4)](Array<crate::check::shrink::walk::Site> spot_sites_f_9490) {
                return prism_rtl::finished(crate::prelude::fold(spot_sites_f_9490, a1_p4, [&](const Array<Text>& a2_p6, const crate::check::shrink::walk::Site& site_p7) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        auto&& _m = crate::check::shrink::locals::local_target_o(sk_p0xy, d_p1xy, site_p7);
                        if (prism_rtl::is_some(_m)) {
                            auto&& t_p8 = prism_rtl::some_of(_m);
                            _v.set(crate::check::types::add_text_f(a2_p6, t_p8));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(crate::check::shrink::relations::is_local_f(prism_rtl::deref(site_p7).rels_p, prism_rtl::deref(site_p7).callee_p) || crate::check::env::has_key_f(prism_rtl::deref(sk_p0xy).local_of_p, prism_rtl::deref(d_p1xy).qk_p)
                                ? a2_p6
                                : ({
                                __label__ _done;
                                prism_rtl::Slot<Array<Text>> _v;
                                auto&& _m = crate::check::shrink::locals::resolve_callee_o(prism_rtl::deref(sk_p0xy).g_p, prism_rtl::deref(d_p1xy).home_p, prism_rtl::deref(site_p7).callee_p);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& k_p9 = prism_rtl::some_of(_m);
                                    _v.set(crate::prelude::fold(crate::check::shrink::types::targets_of_f(sk_p0xy, k_p9), a2_p6, [&](const Array<Text>& a3_pa, const Text& t_pb) {
                                        return crate::check::env::has_key_f(prism_rtl::deref(sk_p0xy).by_key_p, t_pb)
                                            ? crate::check::types::add_text_f(a3_pa, t_pb)
                                            : a3_pa;
                                    }));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(a2_p6);
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
            }));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> SpotsRefs::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& d_p1 = this->d_p1;
    const auto& spots_p2 = this->spots_p2;
    const auto& acc_p3 = this->acc_p3;
    return crate::prelude::fold_job(spots_p2, acc_p3, ({
        auto sk_p0x = sk_p0;
        auto d_p1x = d_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, sk_p0x = std::move(sk_p0x), d_p1x = std::move(d_p1x)](std::tuple<Array<Text>, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0xy = sk_p0x;
            auto d_p1xy = d_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xy = std::move(sk_p0xy), d_p1xy = std::move(d_p1xy)]() {
            return ({
                auto a1_p4 = p0;
                auto sp_p5 = p1;
                (crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p5), [=, a1_p4 = std::move(a1_p4)](Array<crate::check::shrink::walk::Site> spot_sites_f_9490) {
                return prism_rtl::finished(crate::prelude::fold(spot_sites_f_9490, a1_p4, [&](const Array<Text>& a2_p6, const crate::check::shrink::walk::Site& site_p7) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        auto&& _m = crate::check::shrink::locals::local_target_o(sk_p0xy, d_p1xy, site_p7);
                        if (prism_rtl::is_some(_m)) {
                            auto&& t_p8 = prism_rtl::some_of(_m);
                            _v.set(crate::check::types::add_text_f(a2_p6, t_p8));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(crate::check::shrink::relations::is_local_f(prism_rtl::deref(site_p7).rels_p, prism_rtl::deref(site_p7).callee_p) || crate::check::env::has_key_f(prism_rtl::deref(sk_p0xy).local_of_p, prism_rtl::deref(d_p1xy).qk_p)
                                ? a2_p6
                                : ({
                                __label__ _done;
                                prism_rtl::Slot<Array<Text>> _v;
                                auto&& _m = crate::check::shrink::locals::resolve_callee_o(prism_rtl::deref(sk_p0xy).g_p, prism_rtl::deref(d_p1xy).home_p, prism_rtl::deref(site_p7).callee_p);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& k_p9 = prism_rtl::some_of(_m);
                                    _v.set(crate::prelude::fold(crate::check::shrink::types::targets_of_f(sk_p0xy, k_p9), a2_p6, [&](const Array<Text>& a3_pa, const Text& t_pb) {
                                        return crate::check::env::has_key_f(prism_rtl::deref(sk_p0xy).by_key_p, t_pb)
                                            ? crate::check::types::add_text_f(a3_pa, t_pb)
                                            : a3_pa;
                                    }));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(a2_p6);
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
            }));
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start SpotsRefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spots_refs_f(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, Array<crate::check::shrink::walk::Spot> spots_p2, Array<Text> acc_p3) {
    return prism_rtl::make_rc<SpotsRefs>(sk_p0, d_p1, spots_p2, acc_p3);
}

}  // namespace crate::check::shrink::calls
