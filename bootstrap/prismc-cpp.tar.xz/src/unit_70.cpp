// The module `Syntax.Parser.Expr`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Syntax.Parser.Expr`, from `target/bootstrap/cpp-src/prismc/syntax/parser/expr.prism`.
namespace crate::syntax::parser::expr {

bool ArgsRead::operator==(const ArgsRead& o) const { return args_p == o.args_p && rest_p == o.rest_p && p_p == o.p_p && going_p == o.going_p; }

void ArgsRead::show(Printer& p) const {
    p.record("ArgsRead", {{"args", args_p}, {"rest", rest_p}, {"p", p_p}, {"going", going_p}});
}

Pod ArgsRead::to_pod() const {
    return Pod::record("ArgsRead", {{"args", prism_rtl::to_pod(args_p)}, {"rest", prism_rtl::to_pod(rest_p)}, {"p", prism_rtl::to_pod(p_p)}, {"going", prism_rtl::to_pod(going_p)}});
}

Result<ArgsRead> ArgsRead::from_pod(const Pod& whole) {
    return ArgsRead{.args_p = TRY(prism_rtl::from_pod<Array<crate::syntax::Arg>>(TRY(crate::prelude::field(whole, "args")))), .rest_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "rest")))), .p_p = TRY(prism_rtl::from_pod<crate::syntax::parser::Ps>(TRY(crate::prelude::field(whole, "p")))), .going_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "going"))))};
}


void Climb::show(Printer& p) const {
    p.record("Climb", {{"lhs", lhs_p}, {"p", p_p}, {"going", going_p}});
}

Pod Climb::to_pod() const {
    return Pod::record("Climb", {{"lhs", prism_rtl::to_pod(lhs_p)}, {"p", prism_rtl::to_pod(p_p)}, {"going", prism_rtl::to_pod(going_p)}});
}

Result<Climb> Climb::from_pod(const Pod& whole) {
    return Climb{.lhs_p = TRY(prism_rtl::from_pod<crate::syntax::Expr>(TRY(crate::prelude::field(whole, "lhs")))), .p_p = TRY(prism_rtl::from_pod<crate::syntax::parser::Ps>(TRY(crate::prelude::field(whole, "p")))), .going_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "going"))))};
}


/// ParseExpr: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_f(const crate::syntax::parser::Ps& p_p0) {
    return parse_expr_ctx_f(p_p0, true);
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseExpr::cycle() const {
    const auto& p_p0 = this->p_p0;
    return prism_rtl::more(prism_rtl::rc(ParseExprCtx(p_p0, true)));
}


/// `Start ParseExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_expr_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseExpr>(p_p0);
}


/// ParseArgExpr: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_arg_expr_f(const crate::syntax::parser::Ps& p_p0) {
    return parse_expr_ctx_f(p_p0, false);
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseArgExpr::cycle() const {
    const auto& p_p0 = this->p_p0;
    return prism_rtl::more(prism_rtl::rc(ParseExprCtx(p_p0, false)));
}


/// `Start ParseArgExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_arg_expr_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseArgExpr>(p_p0);
}


/// ParseExprCtx: unbounded fn Ps, Bool -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_ctx_f(const crate::syntax::parser::Ps& p_p0, const bool& commas_p1) {
    return parse_binary_f(p_p0, Nat(4u), commas_p1 && (!p_p0.step_mode_p));
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseExprCtx::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& commas_p1 = this->commas_p1;
    return prism_rtl::more(prism_rtl::rc(ParseBinary(p_p0, Nat(4u), prism_rtl::deref(commas_p1) && (!prism_rtl::deref(p_p0).step_mode_p))));
}


/// `Start ParseExprCtx, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_expr_ctx_f(crate::syntax::parser::Ps p_p0, bool commas_p1) {
    return prism_rtl::make_rc<ParseExprCtx>(p_p0, commas_p1);
}


/// ParseRhsExpr: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_f(const crate::syntax::parser::Ps& p0_p0) {
    std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> this_ = parse_expr_f(p0_p0);
    auto [e0_p1, p1_p2] = this_;
    crate::syntax::Expr e_p3 = e0_p1;
    crate::syntax::parser::Ps p_p4 = p1_p2;
    while (at_line_method_f(p_p4)) {
        auto [method_p5, p2_p6] = crate::syntax::parser::parse_sname_f(crate::syntax::parser::adv_f(p_p4));
        auto [args_p7, p3_p8] = arg_starts_here_f(p2_p6)
            ? parse_call_args_f(p2_p6, true)
            : std::tuple{Array<crate::syntax::Arg>{}, p2_p6};
        e_p3 = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMethod{prism_rtl::rc(e_p3), method_p5, args_p7})), .span_p = crate::syntax::parser::to_f(e_p3.span_p, crate::syntax::parser::prev_f(p3_p8))};
        p_p4 = p3_p8;
    }
    this_ = std::tuple{e_p3, p_p4};
    return this_;
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseRhsExpr::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> this_ = parse_expr_f(p0_p0);
    auto [e0_p1, p1_p2] = this_;
    crate::syntax::Expr e_p3 = e0_p1;
    crate::syntax::parser::Ps p_p4 = p1_p2;
    return crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_), std::move(e_p3), std::move(p_p4)}, [=](std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, crate::syntax::parser::Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto e_p3 = std::get<1>(_p0);
        auto p_p4 = std::get<2>(_p0);
        return at_line_method_f(p_p4)
            ? ({
            auto [method_p5, p2_p6] = crate::syntax::parser::parse_sname_f(crate::syntax::parser::adv_f(p_p4));
            auto [args_p7, p3_p8] = arg_starts_here_f(p2_p6)
                ? parse_call_args_f(p2_p6, true)
                : std::tuple{Array<crate::syntax::Arg>{}, p2_p6};
            e_p3 = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMethod{prism_rtl::rc(e_p3), method_p5, args_p7})), .span_p = crate::syntax::parser::to_f(prism_rtl::deref(e_p3).span_p, crate::syntax::parser::prev_f(p3_p8))};
            p_p4 = p3_p8;
            Expected<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, crate::syntax::parser::Ps>, std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, crate::syntax::parser::Ps>>(std::tuple{this_, e_p3, p_p4});
        })
            : Expected<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, crate::syntax::parser::Ps>, std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, crate::syntax::parser::Ps>>(unexpected(std::tuple{this_, e_p3, p_p4}));
    }), [=](std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, crate::syntax::parser::Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto e_p3 = std::get<1>(_p0);
        auto p_p4 = std::get<2>(_p0);
        return ({
            this_ = std::tuple{e_p3, p_p4};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start ParseRhsExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_rhs_expr_f(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseRhsExpr>(p0_p0);
}


/// AtLineMethod: fn Ps -> Bool
bool at_line_method_f(const crate::syntax::parser::Ps& p_p0) {
    return ((crate::syntax::parser::kind_f(p_p0) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDot{true})) && prism_rtl::deref(crate::syntax::parser::tk_f(p_p0)).line_start_p) && is_plain_upper_f(crate::syntax::parser::kind_at_f(p_p0, Nat(1u)));
}


/// IsPlainUpper: fn TokKind -> Bool
bool is_plain_upper_f(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(tok_kind0)) {
        auto&& n_p0 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(tok_kind0).a0;
        return (prism_rtl::deref(n_p0).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})) && (prism_rtl::deref(n_p0).sigils_p == Text::lit(""));
    }
    {
        return false;
    }
}


/// IsUpperTok: fn TokKind -> Bool
bool is_upper_tok_f(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(tok_kind0)) {
        auto&& n_p0 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(tok_kind0).a0;
        return prism_rtl::deref(n_p0).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{});
    }
    {
        return false;
    }
}


/// ?PeekBinop: fn Ps -> ?((Text, ?[Text]))
std::optional<std::tuple<Text, std::optional<Array<Text>>>> peek_binop_o(const crate::syntax::parser::Ps& p_p0) {
    auto&& _m = crate::syntax::parser::kind_f(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m)) {
        auto&& op_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        auto&& prefix_p2 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a1;
        if ((!prefix_p2) || (op_p1 == Text::lit("-?"))) {
            return is_binop_f(op_p1)
                ? std::optional(std::tuple{op_p1, std::optional<Array<Text>>{}})
                : std::optional<std::tuple<Text, std::optional<Array<Text>>>>{};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KSuffixed>(_m)) {
        auto&& op_p3 = prism_rtl::as<crate::syntax::lexer::TokKind::KSuffixed>(_m).a0;
        auto&& ty_p4 = prism_rtl::as<crate::syntax::lexer::TokKind::KSuffixed>(_m).a1;
        return is_binop_f(op_p3)
            ? std::optional(std::tuple{op_p3, std::optional(ty_p4)})
            : std::optional<std::tuple<Text, std::optional<Array<Text>>>>{};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m2766_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2766_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m2766_2_0 == Text::lit("on")) {
            if (m2766_2_1 == Text::lit("")) {
                return std::optional(std::tuple{Text::lit("on"), std::optional<Array<Text>>{}});
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m2766_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2766_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m2766_3_0 == Text::lit("or")) {
            if (m2766_3_1 == Text::lit("")) {
                return std::optional(std::tuple{Text::lit("or"), std::optional<Array<Text>>{}});
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m2766_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2766_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m2766_4_0 == Text::lit("and")) {
            if (m2766_4_1 == Text::lit("")) {
                return std::optional(std::tuple{Text::lit("and"), std::optional<Array<Text>>{}});
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m2766_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2766_5_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m2766_5_0 == Text::lit("mod")) {
            if (m2766_5_1 == Text::lit("")) {
                return std::optional(std::tuple{Text::lit("mod"), std::optional<Array<Text>>{}});
            }
        }
    }
    {
        return std::optional<std::tuple<Text, std::optional<Array<Text>>>>{};
    }
}


/// IsBinop: fn Text -> Bool
bool is_binop_f(const Text& op_p0) {
    return crate::prelude::fold(Array(std::vector{Text::lit("<|"), Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit("<="), Text::lit(">"), Text::lit(">="), Text::lit("+"), Text::lit("-"), Text::lit("+?"), Text::lit("-?"), Text::lit("*"), Text::lit("/"), Text::lit("*?")}), false, [&](const bool& seen_p1, const Text& o_p2) { return prism_rtl::deref(seen_p1) || (o_p2 == op_p0); });
}


/// Level: fn Text -> Nat
Nat level_f(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("<|")) {
            return Nat(4u);
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("on")) {
            return Nat(5u);
        }
    }
    {
        auto&& c2_0 = text0;
        if (c2_0 == Text::lit("or")) {
            return Nat(6u);
        }
    }
    {
        auto&& c3_0 = text0;
        if (c3_0 == Text::lit("and")) {
            return Nat(7u);
        }
    }
    {
        auto&& c4_0 = text0;
        if (c4_0 == Text::lit("+")) {
            return Nat(10u);
        }
    }
    {
        auto&& c5_0 = text0;
        if (c5_0 == Text::lit("-")) {
            return Nat(10u);
        }
    }
    {
        auto&& c6_0 = text0;
        if (c6_0 == Text::lit("+?")) {
            return Nat(10u);
        }
    }
    {
        auto&& c7_0 = text0;
        if (c7_0 == Text::lit("-?")) {
            return Nat(10u);
        }
    }
    {
        auto&& c8_0 = text0;
        if (c8_0 == Text::lit("*")) {
            return Nat(11u);
        }
    }
    {
        auto&& c9_0 = text0;
        if (c9_0 == Text::lit("/")) {
            return Nat(11u);
        }
    }
    {
        auto&& c10_0 = text0;
        if (c10_0 == Text::lit("*?")) {
            return Nat(11u);
        }
    }
    {
        auto&& c11_0 = text0;
        if (c11_0 == Text::lit("mod")) {
            return Nat(11u);
        }
    }
    {
        return Nat(9u);
    }
}


/// ParseBinary: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_binary_f(const crate::syntax::parser::Ps& p0_p0, const Nat& min_p1, const bool& commas_p2) {
    auto [lhs_p4, p1_p5] = parse_prefix_f(p0_p0, min_p1, commas_p2);
    auto r_p3 = ({
        Climb this_ = Climb{.lhs_p = lhs_p4, .p_p = p1_p5, .going_p = true};
        while (this_.going_p && (!prism_rtl::deref(this_.p_p).bad_p)) {
            this_ = climb_step_f(this_, min_p1, commas_p2);
        }
        (std::move(this_));
    });
    return std::tuple{prism_rtl::deref(r_p3).lhs_p, prism_rtl::deref(r_p3).p_p};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseBinary::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    const auto& min_p1 = this->min_p1;
    const auto& commas_p2 = this->commas_p2;
    auto commas_p2x = prism_rtl::deref(commas_p2);
    auto min_p1x = min_p1;
    auto p0_p0x = p0_p0;
    return crate::prelude::call_then(start_parse_prefix_f(p0_p0x, min_p1x, std::move(commas_p2x)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_prefix_f_4034) {
        return ({
            auto [lhs_p4, p1_p5] = parse_prefix_f_4034;
            Climb this_ = Climb{.lhs_p = lhs_p4, .p_p = p1_p5, .going_p = true};
            auto lhs_p4z = lhs_p4;
            (crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_)}, ({
            auto commas_p2xx = commas_p2x;
            auto min_p1xx = min_p1x;
            [=, commas_p2xx = std::move(commas_p2xx), min_p1xx = std::move(min_p1xx)](std::tuple<Climb> _p0) {
            auto this_ = std::get<0>(_p0);
            return prism_rtl::deref(this_).going_p && (!prism_rtl::deref(prism_rtl::deref(this_).p_p).bad_p)
                ? ({
                this_ = climb_step_f(this_, min_p1xx, commas_p2xx);
                Expected<std::tuple<Climb>, std::tuple<Climb>>(std::tuple{this_});
            })
                : Expected<std::tuple<Climb>, std::tuple<Climb>>(unexpected(std::tuple{this_}));
        };
        })), [=](std::tuple<Climb> _p0) {
            auto this_ = std::get<0>(_p0);
            return ({
                auto r_p3 = this_;
                (prism_rtl::finished(std::tuple{prism_rtl::deref(r_p3).lhs_p, prism_rtl::deref(r_p3).p_p}));
            });
        }));
        });
    });
}


/// `Start ParseBinary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_binary_f(crate::syntax::parser::Ps p0_p0, Nat min_p1, bool commas_p2) {
    return prism_rtl::make_rc<ParseBinary>(p0_p0, min_p1, commas_p2);
}


/// ClimbStep: unbounded fn Climb, Nat, Bool -> Climb
Climb climb_step_f(const Climb& c_p0, const Nat& min_p1, const bool& commas_p2) {
    auto p_p3 = c_p0.p_p;
    return crate::syntax::parser::at_kw_f(p_p3, Text::lit("as")) && (min_p1 <= Nat(12u))
        ? ({
        auto [ty_p6, p2_p7] = crate::syntax::parser::types::parse_type_f(crate::syntax::parser::adv_f(p_p3));
        auto checked_p4 = (crate::syntax::parser::kind_f(p2_p7) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFree{Text::lit("?")})) && prism_rtl::deref(crate::syntax::parser::tk_f(p2_p7)).touches_p;
        auto p3_p5 = std::move(checked_p4) ? crate::syntax::parser::adv_f(p2_p7) : p2_p7;
        ({
        Climb this_ = c_p0;
        this_.lhs_p = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECast{prism_rtl::rc(this_.lhs_p), ty_p6, std::move(checked_p4)})), .span_p = crate::syntax::parser::to_f(prism_rtl::deref(this_.lhs_p).span_p, crate::syntax::parser::prev_f(p3_p5))};
        this_.p_p = p3_p5;
        (std::move(this_));
    });
    })
        : ({
        __label__ _done;
        prism_rtl::Slot<Climb> _v;
        auto&& _m = peek_binop_o(p_p3);
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                Climb this_ = c_p0;
                this_.going_p = false;
                this_.p_p = no_operator_f(p_p3);
                (std::move(this_));
            }));
            goto _done;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& op_p8 = std::get<0>(prism_rtl::some_of(_m));
            auto&& suffix_o9 = std::get<1>(prism_rtl::some_of(_m));
            _v.set(level_f(op_p8) < min_p1
                ? ({
                Climb this_ = c_p0;
                this_.going_p = false;
                (std::move(this_));
            })
                : ({
                auto p1_pa = crate::syntax::parser::kind_f(p_p3) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOp{Text::lit("-?"), true})
                    ? crate::syntax::parser::note_error_f(p_p3, crate::syntax::parser::here_f(p_p3), Text::lit("`-?` is the checked subtraction by longest match; to subtract or negate an optional, write `-(?x)`"))
                    : p_p3;
                auto op_tok_pb = crate::syntax::parser::tk_f(p1_pa);
                auto [rhs_pf, p2_pg] = parse_binary_f(crate::syntax::parser::adv_f(p1_pa), level_f(op_p8) + Nat(1u), commas_p2);
                auto span_pc = crate::syntax::parser::to_f(prism_rtl::deref(c_p0.lhs_p).span_p, prism_rtl::deref(rhs_pf).span_p);
                auto kind_pd = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::syntax::ExprKind> _v;
                    if (prism_rtl::is_none(suffix_o9)) {
                        _v.set(crate::syntax::ExprKind(crate::syntax::ExprKind::EBinary{op_p8, prism_rtl::rc(c_p0.lhs_p), prism_rtl::rc(rhs_pf)}));
                        goto _done;
                    }
                    if (prism_rtl::is_some(suffix_o9)) {
                        auto&& ty_ph = prism_rtl::some_of(suffix_o9);
                        _v.set(crate::syntax::ExprKind(crate::syntax::ExprKind::ESuffixed{op_p8, crate::syntax::QualName{.path_p = ty_ph, .span_p = prism_rtl::deref(op_tok_pb).span_p}, prism_rtl::rc(c_p0.lhs_p), prism_rtl::rc(rhs_pf)}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto p3_pe = suffix_o9 == std::optional<Array<Text>>{}
                    ? p2_pg
                    : crate::syntax::parser::out_of_scope_f(p2_pg, prism_rtl::deref(op_tok_pb).span_p, Text::lit("suffixed operators"), prism_rtl::cat("the suffixed operator `", crate::syntax::lexer::corpus::token_text_f(prism_rtl::deref(op_tok_pb).kind_p), "` is out of this compiler"));
                ({
                Climb this_ = c_p0;
                this_.lhs_p = crate::syntax::Expr{.kind_p = prism_rtl::rc(kind_pd), .span_p = span_pc};
                this_.p_p = p3_pe;
                (std::move(this_));
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Climb> ClimbStep::cycle() const {
    const auto& c_p0 = this->c_p0;
    const auto& min_p1 = this->min_p1;
    const auto& commas_p2 = this->commas_p2;
    auto p_p3 = prism_rtl::deref(c_p0).p_p;
    return crate::syntax::parser::at_kw_f(p_p3, Text::lit("as")) && (min_p1 <= Nat(12u))
        ? ({
        auto c_p0x = c_p0;
        (crate::prelude::call_then(crate::syntax::parser::types::start_parse_type_f(crate::syntax::parser::adv_f(p_p3)), [=, c_p0x = std::move(c_p0x)](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_f_4430) {
        return ({
            auto [ty_p6, p2_p7] = parse_type_f_4430;
            auto checked_p4 = (crate::syntax::parser::kind_f(p2_p7) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFree{Text::lit("?")})) && prism_rtl::deref(crate::syntax::parser::tk_f(p2_p7)).touches_p;
            auto p3_p5 = std::move(checked_p4) ? crate::syntax::parser::adv_f(p2_p7) : p2_p7;
            (prism_rtl::finished(({
            Climb this_ = c_p0x;
            this_.lhs_p = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECast{prism_rtl::rc(this_.lhs_p), ty_p6, std::move(checked_p4)})), .span_p = crate::syntax::parser::to_f(prism_rtl::deref(this_.lhs_p).span_p, crate::syntax::parser::prev_f(p3_p5))};
            this_.p_p = p3_p5;
            (std::move(this_));
        })));
        });
    }));
    })
        : ({
        auto&& _m = peek_binop_o(p_p3);
        prism_rtl::is_none(_m) ? prism_rtl::finished(({
        Climb this_ = c_p0;
        this_.going_p = false;
        this_.p_p = no_operator_f(p_p3);
        (std::move(this_));
    }))
        : prism_rtl::is_some(_m) ? ({
        auto&& op_p8 = std::get<0>(prism_rtl::some_of(_m));
        auto&& suffix_o9 = std::get<1>(prism_rtl::some_of(_m));
        level_f(op_p8) < min_p1
        ? prism_rtl::finished(({
        Climb this_ = c_p0;
        this_.going_p = false;
        (std::move(this_));
    }))
        : ({
        auto p1_pa = crate::syntax::parser::kind_f(p_p3) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOp{Text::lit("-?"), true})
            ? crate::syntax::parser::note_error_f(p_p3, crate::syntax::parser::here_f(p_p3), Text::lit("`-?` is the checked subtraction by longest match; to subtract or negate an optional, write `-(?x)`"))
            : p_p3;
        auto op_tok_pb = crate::syntax::parser::tk_f(p1_pa);
        auto c_p0x = c_p0;
        auto commas_p2x = prism_rtl::deref(commas_p2);
        (crate::prelude::call_then(start_parse_binary_f(crate::syntax::parser::adv_f(p1_pa), level_f(op_p8) + Nat(1u), std::move(commas_p2x)), [=, op_tok_pb = std::move(op_tok_pb), c_p0x = std::move(c_p0x)](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_binary_f_5342) {
        return ({
            auto [rhs_pf, p2_pg] = parse_binary_f_5342;
            auto span_pc = crate::syntax::parser::to_f(prism_rtl::deref(prism_rtl::deref(c_p0x).lhs_p).span_p, prism_rtl::deref(rhs_pf).span_p);
            auto kind_pd = ({
                __label__ _done;
                prism_rtl::Slot<crate::syntax::ExprKind> _v;
                if (prism_rtl::is_none(suffix_o9)) {
                    _v.set(crate::syntax::ExprKind(crate::syntax::ExprKind::EBinary{op_p8, prism_rtl::rc(prism_rtl::deref(c_p0x).lhs_p), prism_rtl::rc(rhs_pf)}));
                    goto _done;
                }
                if (prism_rtl::is_some(suffix_o9)) {
                    auto&& ty_ph = prism_rtl::some_of(suffix_o9);
                    _v.set(crate::syntax::ExprKind(crate::syntax::ExprKind::ESuffixed{op_p8, crate::syntax::QualName{.path_p = ty_ph, .span_p = prism_rtl::deref(op_tok_pb).span_p}, prism_rtl::rc(prism_rtl::deref(c_p0x).lhs_p), prism_rtl::rc(rhs_pf)}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto p3_pe = suffix_o9 == std::optional<Array<Text>>{}
                ? p2_pg
                : crate::syntax::parser::out_of_scope_f(p2_pg, prism_rtl::deref(op_tok_pb).span_p, Text::lit("suffixed operators"), prism_rtl::cat("the suffixed operator `", crate::syntax::lexer::corpus::token_text_f(prism_rtl::deref(op_tok_pb).kind_p), "` is out of this compiler"));
            (prism_rtl::finished(({
            Climb this_ = c_p0x;
            this_.lhs_p = crate::syntax::Expr{.kind_p = prism_rtl::rc(kind_pd), .span_p = span_pc};
            this_.p_p = p3_pe;
            (std::move(this_));
        })));
        });
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ClimbStep, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Climb> start_climb_step_f(Climb c_p0, Nat min_p1, bool commas_p2) {
    return prism_rtl::make_rc<ClimbStep>(c_p0, min_p1, commas_p2);
}


/// NoOperator: fn Ps -> Ps
crate::syntax::parser::Ps no_operator_f(const crate::syntax::parser::Ps& p_p0) {
    auto&& _m = crate::syntax::parser::kind_f(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a1) {
        auto&& o_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        if (((o_p1 == Text::lit("-")) || (o_p1 == Text::lit("+"))) && (!prism_rtl::deref(crate::syntax::parser::tk_f(p_p0)).line_start_p)) {
            return crate::syntax::parser::error_at_f(p_p0, crate::syntax::parser::here_f(p_p0), prism_rtl::cat("`", o_p1, "` here is a prefix sign by the spacing rule (a space before it and none after); did you mean `a ", o_p1, " 1`, with spaces on both sides?"));
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KBar>(_m)) {
        return crate::syntax::parser::error_at_f(p_p0, crate::syntax::parser::here_f(p_p0), Text::lit("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row"));
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(_m).a0) {
        if ((!at_line_method_f(p_p0)) && is_upper_tok_f(crate::syntax::parser::kind_at_f(p_p0, Nat(1u)))) {
            return crate::syntax::parser::error_at_f(p_p0, crate::syntax::parser::here_f(p_p0), Text::lit("a spaced `.Method` begins its own line, below the call it takes as its receiver (layout rule 9)"));
        }
    }
    {
        return p_p0;
    }
}


/// ParsePrefix: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_prefix_f(const crate::syntax::parser::Ps& p_p0, const Nat& min_p1, const bool& commas_p2) {
    auto start_p3 = crate::syntax::parser::here_f(p_p0);
    return crate::syntax::parser::at_kw_f(p_p0, Text::lit("not"))
        ? ({
        auto [operand_p4, q_p5] = parse_binary_f(crate::syntax::parser::adv_f(p_p0), crate::prelude::max(Nat(9u), min_p1), commas_p2);
        std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EUnary{Text::lit("not"), prism_rtl::rc(operand_p4)})), .span_p = crate::syntax::parser::to_f(start_p3, prism_rtl::deref(operand_p4).span_p)}, q_p5};
    })
        : ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> _v;
        auto&& _m = crate::syntax::parser::kind_f(p_p0);
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a1) {
            auto&& op_p6 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
            if ((op_p6 == Text::lit("-")) || (op_p6 == Text::lit("+"))) {
                _v.set(({
                    auto [operand_p8, q_p9] = parse_postfix_expr_f(crate::syntax::parser::adv_f(p_p0), commas_p2);
                    auto name_p7 = op_p6 == Text::lit("-") ? Text::lit("neg") : Text::lit("pos");
                    std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EUnary{name_p7, prism_rtl::rc(operand_p8)})), .span_p = crate::syntax::parser::to_f(start_p3, prism_rtl::deref(operand_p8).span_p)}, q_p9};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m)) {
            auto&& m7135_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
            if (m7135_1_0 == Text::lit("-?")) {
                _v.set(std::tuple{crate::syntax::parser::decls::no_expr_p(), crate::syntax::parser::error_at_f(p_p0, crate::syntax::parser::here_f(p_p0), Text::lit("`-?` is the checked subtraction and needs a left operand; to negate an optional write `-(?x)`"))});
                goto _done;
            }
        }
        {
            _v.set(parse_postfix_expr_f(p_p0, commas_p2));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParsePrefix::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& min_p1 = this->min_p1;
    const auto& commas_p2 = this->commas_p2;
    auto start_p3 = crate::syntax::parser::here_f(p_p0);
    return crate::syntax::parser::at_kw_f(p_p0, Text::lit("not"))
        ? ({
        auto commas_p2x = prism_rtl::deref(commas_p2);
        auto min_p1x = min_p1;
        auto p_p0x = p_p0;
        (crate::prelude::call_then(start_parse_binary_f(crate::syntax::parser::adv_f(p_p0x), crate::prelude::max(Nat(9u), min_p1x), std::move(commas_p2x)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_binary_f_7002) {
        return ({
            auto [operand_p4, q_p5] = parse_binary_f_7002;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EUnary{Text::lit("not"), prism_rtl::rc(operand_p4)})), .span_p = crate::syntax::parser::to_f(start_p3, prism_rtl::deref(operand_p4).span_p)}, q_p5}));
        });
    }));
    })
        : ({
        auto&& _m = crate::syntax::parser::kind_f(p_p0);
        prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a1 && ({
        auto&& op_p6 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        ((op_p6 == Text::lit("-")) || (op_p6 == Text::lit("+")));
    }) ? ({
        auto&& op_p6 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        ({
        auto commas_p2x = prism_rtl::deref(commas_p2);
        auto p_p0x = p_p0;
        (crate::prelude::call_then(start_parse_postfix_expr_f(crate::syntax::parser::adv_f(p_p0x), std::move(commas_p2x)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_postfix_expr_f_7230) {
        return ({
            auto [operand_p8, q_p9] = parse_postfix_expr_f_7230;
            auto name_p7 = op_p6 == Text::lit("-") ? Text::lit("neg") : Text::lit("pos");
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EUnary{name_p7, prism_rtl::rc(operand_p8)})), .span_p = crate::syntax::parser::to_f(start_p3, prism_rtl::deref(operand_p8).span_p)}, q_p9}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m) && ({
        auto&& m7135_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        (m7135_1_0 == Text::lit("-?"));
    }) ? ({
        auto&& m7135_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr_p(), crate::syntax::parser::error_at_f(p_p0, crate::syntax::parser::here_f(p_p0), Text::lit("`-?` is the checked subtraction and needs a left operand; to negate an optional write `-(?x)`"))});
    })
        : prism_rtl::more(prism_rtl::rc(ParsePostfixExpr(p_p0, prism_rtl::deref(commas_p2))));
    });
}


/// `Start ParsePrefix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_prefix_f(crate::syntax::parser::Ps p_p0, Nat min_p1, bool commas_p2) {
    return prism_rtl::make_rc<ParsePrefix>(p_p0, min_p1, commas_p2);
}


/// ParsePostfixExpr: unbounded fn Ps, Bool -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_postfix_expr_f(const crate::syntax::parser::Ps& p_p0, const bool& commas_p1) {
    auto [e_p2, took_rest_p3, q_p4] = parse_primary_f(p_p0, commas_p1);
    return took_rest_p3
        ? std::tuple{e_p2, q_p4}
        : parse_postfix_f(e_p2, q_p4, commas_p1);
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParsePostfixExpr::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& commas_p1 = this->commas_p1;
    auto commas_p1x = prism_rtl::deref(commas_p1);
    auto p_p0x = p_p0;
    return crate::prelude::call_then(start_parse_primary_f(p_p0x, std::move(commas_p1x)), [=](std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> parse_primary_f_7837) {
        return ({
            auto [e_p2, took_rest_p3, q_p4] = parse_primary_f_7837;
            took_rest_p3
            ? prism_rtl::finished(std::tuple{e_p2, q_p4})
            : prism_rtl::more(prism_rtl::rc(ParsePostfix(e_p2, q_p4, commas_p1x)));
        });
    });
}


/// `Start ParsePostfixExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_postfix_expr_f(crate::syntax::parser::Ps p_p0, bool commas_p1) {
    return prism_rtl::make_rc<ParsePostfixExpr>(p_p0, commas_p1);
}


/// ParsePostfix: unbounded fn Expr, Ps, Bool -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_postfix_f(const crate::syntax::Expr& e0_p0, const crate::syntax::parser::Ps& p0_p1, const bool& commas_p2) {
    std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> this_ = std::tuple{e0_p0, p0_p1};
    crate::syntax::Expr e_p3 = e0_p0;
    crate::syntax::parser::Ps p_p4 = p0_p1;
    bool going_p5 = true;
    while (std::move(going_p5) && (!p_p4.bad_p)) {
        auto [e2_p6, p2_p7, more_p8] = postfix_step_f(e_p3, p_p4, commas_p2);
        e_p3 = e2_p6;
        p_p4 = p2_p7;
        going_p5 = more_p8;
    }
    this_ = std::tuple{e_p3, p_p4};
    return this_;
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParsePostfix::cycle() const {
    const auto& e0_p0 = this->e0_p0;
    const auto& p0_p1 = this->p0_p1;
    const auto& commas_p2 = this->commas_p2;
    std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> this_ = std::tuple{e0_p0, p0_p1};
    crate::syntax::Expr e_p3 = e0_p0;
    crate::syntax::parser::Ps p_p4 = p0_p1;
    bool going_p5 = true;
    return crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_), std::move(e_p3), std::move(going_p5), std::move(p_p4)}, ({
        auto commas_p2x = prism_rtl::deref(commas_p2);
        [=, commas_p2x = std::move(commas_p2x)](std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, bool, crate::syntax::parser::Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto e_p3 = std::get<1>(_p0);
        auto going_p5 = std::get<2>(_p0);
        auto p_p4 = std::get<3>(_p0);
        return going_p5 && (!prism_rtl::deref(p_p4).bad_p)
            ? ({
            auto [e2_p6, p2_p7, more_p8] = postfix_step_f(e_p3, p_p4, commas_p2x);
            e_p3 = e2_p6;
            p_p4 = p2_p7;
            going_p5 = more_p8;
            Expected<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, bool, crate::syntax::parser::Ps>, std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, bool, crate::syntax::parser::Ps>>(std::tuple{this_, e_p3, going_p5, p_p4});
        })
            : Expected<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, bool, crate::syntax::parser::Ps>, std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, bool, crate::syntax::parser::Ps>>(unexpected(std::tuple{this_, e_p3, going_p5, p_p4}));
    };
    })), [=](std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, bool, crate::syntax::parser::Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto e_p3 = std::get<1>(_p0);
        auto going_p5 = std::get<2>(_p0);
        auto p_p4 = std::get<3>(_p0);
        return ({
            this_ = std::tuple{e_p3, p_p4};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start ParsePostfix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_postfix_f(crate::syntax::Expr e0_p0, crate::syntax::parser::Ps p0_p1, bool commas_p2) {
    return prism_rtl::make_rc<ParsePostfix>(e0_p0, p0_p1, commas_p2);
}


/// PostfixStep: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool> postfix_step_f(const crate::syntax::Expr& e_p0, const crate::syntax::parser::Ps& p_p1, const bool& commas_p2) {
    auto&& _m = crate::syntax::parser::kind_f(p_p1);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(_m) && !prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(_m).a0) {
        return field_or_method_f(e_p0, p_p1, commas_p2);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && !prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a1) {
        auto&& m8467_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m8467_1_0 == Text::lit("[")) {
            if (prism_rtl::deref(crate::syntax::parser::tk_f(p_p1)).touches_p && (!crate::syntax::parser::at_double_open_f(p_p1, Text::lit("[")))) {
                auto [index_p4, p1_p5] = crate::syntax::parser::bracketed_f(crate::syntax::parser::adv_f(p_p1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(start_parse_expr_f(a0)); })));
                auto p2_p3 = crate::syntax::parser::expect_close_f(p1_p5, Text::lit("["));
                return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIndex{prism_rtl::rc(e_p0), prism_rtl::rc(index_p4)})), .span_p = crate::syntax::parser::to_f(e_p0.span_p, crate::syntax::parser::prev_f(p2_p3))}, p2_p3, true};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLtLt>(_m)) {
        auto [types_p6, q_p7] = parse_type_args_f(p_p1);
        return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETypeArgs{prism_rtl::rc(e_p0), types_p6})), .span_p = crate::syntax::parser::to_f(e_p0.span_p, crate::syntax::parser::prev_f(q_p7))}, q_p7, true};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KNonEmpty>(_m)) {
        auto span_p8 = crate::syntax::parser::here_f(p_p1);
        auto q_p9 = crate::syntax::parser::out_of_scope_f(crate::syntax::parser::adv_f(p_p1), span_p8, Text::lit("non-empty arrays"), Text::lit("the non-empty mark `+` is out of this compiler"));
        return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ENonEmpty{prism_rtl::rc(e_p0)})), .span_p = crate::syntax::parser::to_f(e_p0.span_p, span_p8)}, q_p9, true};
    }
    {
        return std::tuple{e_p0, p_p1, false};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool>> PostfixStep::cycle() const {
    const auto& e_p0 = this->e_p0;
    const auto& p_p1 = this->p_p1;
    const auto& commas_p2 = this->commas_p2;
    return ({
        auto&& _m = crate::syntax::parser::kind_f(p_p1);
        prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(_m) && !prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(_m).a0 ? prism_rtl::more(prism_rtl::rc(FieldOrMethod(e_p0, p_p1, prism_rtl::deref(commas_p2))))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && !prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a1 && ({
        auto&& m8467_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        (m8467_1_0 == Text::lit("[")) && (prism_rtl::deref(crate::syntax::parser::tk_f(p_p1)).touches_p && (!crate::syntax::parser::at_double_open_f(p_p1, Text::lit("["))));
    }) ? ({
        auto&& m8467_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        ({
        auto e_p0x = e_p0;
        auto p_p1x = p_p1;
        (crate::prelude::call_then(crate::syntax::parser::start_bracketed_f(crate::syntax::parser::adv_f(p_p1x), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(start_parse_expr_f(a0)); }))), [=, e_p0x = std::move(e_p0x)](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> bracketed_f_8622) {
        return ({
            auto [index_p4, p1_p5] = bracketed_f_8622;
            auto p2_p3 = crate::syntax::parser::expect_close_f(p1_p5, Text::lit("["));
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIndex{prism_rtl::rc(e_p0x), prism_rtl::rc(index_p4)})), .span_p = crate::syntax::parser::to_f(prism_rtl::deref(e_p0x).span_p, crate::syntax::parser::prev_f(p2_p3))}, p2_p3, true}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KLtLt>(_m) ? ({
        auto e_p0x = e_p0;
        auto p_p1x = p_p1;
        (crate::prelude::call_then(start_parse_type_args_f(p_p1x), [=, e_p0x = std::move(e_p0x)](std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps> parse_type_args_f_8806) {
        return ({
            auto [types_p6, q_p7] = parse_type_args_f_8806;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETypeArgs{prism_rtl::rc(e_p0x), types_p6})), .span_p = crate::syntax::parser::to_f(prism_rtl::deref(e_p0x).span_p, crate::syntax::parser::prev_f(q_p7))}, q_p7, true}));
        });
    }));
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KNonEmpty>(_m) ? ({
        auto span_p8 = crate::syntax::parser::here_f(p_p1);
        auto q_p9 = crate::syntax::parser::out_of_scope_f(crate::syntax::parser::adv_f(p_p1), span_p8, Text::lit("non-empty arrays"), Text::lit("the non-empty mark `+` is out of this compiler"));
        (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ENonEmpty{prism_rtl::rc(e_p0)})), .span_p = crate::syntax::parser::to_f(prism_rtl::deref(e_p0).span_p, span_p8)}, q_p9, true}));
    })
        : prism_rtl::finished(std::tuple{e_p0, p_p1, false});
    });
}


/// `Start PostfixStep, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool>> start_postfix_step_f(crate::syntax::Expr e_p0, crate::syntax::parser::Ps p_p1, bool commas_p2) {
    return prism_rtl::make_rc<PostfixStep>(e_p0, p_p1, commas_p2);
}


/// FieldOrMethod: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool> field_or_method_f(const crate::syntax::Expr& e_p0, const crate::syntax::parser::Ps& p0_p1, const bool& commas_p2) {
    auto dot_p3 = crate::syntax::parser::here_f(p0_p1);
    auto p_p4 = crate::syntax::parser::adv_f(p0_p1);
    auto&& _m = crate::syntax::parser::kind_f(p_p4);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n_p5 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if ((crate::prelude::len(prism_rtl::deref(n_p5).path_p) == Nat(1u)) && ((prism_rtl::deref(n_p5).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{})) || (prism_rtl::deref(n_p5).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseTopic{})))) {
            auto t_p6 = crate::syntax::parser::here_f(p_p4);
            auto field_p7 = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(e_p0), prism_rtl::deref(n_p5).sigils_p, crate::syntax::Ident{.name_p = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(n_p5).path_p, Nat(0u)), Text::lit("")), .span_p = t_p6}})), .span_p = crate::syntax::parser::to_f(e_p0.span_p, t_p6)};
            auto p1_p8 = crate::syntax::parser::adv_f(p_p4);
            return arg_starts_here_f(p1_p8) && (!prism_rtl::deref(crate::syntax::parser::tk_f(p1_p8)).line_start_p)
                ? ({
                auto [args_p9, p2_pa] = parse_call_args_f(p1_p8, commas_p2);
                std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(field_p7), args_p9, false, false})), .span_p = crate::syntax::parser::to_f(prism_rtl::deref(field_p7).span_p, crate::syntax::parser::prev_f(p2_pa))}, p2_pa, false};
            })
                : std::tuple{field_p7, p1_p8, true};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& w_pb = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m9299_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m9299_1_1 == Text::lit("")) {
            if (crate::syntax::lexer::is_bound_word_f(w_pb)) {
                auto t_pc = crate::syntax::parser::here_f(p_p4);
                return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(e_p0), Text::lit(""), crate::syntax::Ident{.name_p = w_pb, .span_p = t_pc}})), .span_p = crate::syntax::parser::to_f(e_p0.span_p, t_pc)}, crate::syntax::parser::adv_f(p_p4), true};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n_pd = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if ((prism_rtl::deref(n_pd).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})) || (prism_rtl::deref(n_pd).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseReserved{}))) {
            auto [method_pe, p1_pf] = crate::syntax::parser::parse_sname_f(p_p4);
            auto [args_pg, p2_ph] = arg_starts_here_f(p1_pf)
                ? parse_call_args_f(p1_pf, commas_p2)
                : std::tuple{Array<crate::syntax::Arg>{}, p1_pf};
            return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMethod{prism_rtl::rc(e_p0), method_pe, args_pg})), .span_p = crate::syntax::parser::to_f(e_p0.span_p, crate::syntax::parser::prev_f(p2_ph))}, p2_ph, false};
        }
    }
    {
        return std::tuple{e_p0, crate::syntax::parser::error_at_f(p_p4, dot_p3, Text::lit("expected a field name or a `.Method` after `.`")), false};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool>> FieldOrMethod::cycle() const {
    const auto& e_p0 = this->e_p0;
    const auto& p0_p1 = this->p0_p1;
    const auto& commas_p2 = this->commas_p2;
    auto dot_p3 = crate::syntax::parser::here_f(p0_p1);
    auto p_p4 = crate::syntax::parser::adv_f(p0_p1);
    return ({
        auto&& _m = crate::syntax::parser::kind_f(p_p4);
        prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n_p5 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ((crate::prelude::len(prism_rtl::deref(n_p5).path_p) == Nat(1u)) && ((prism_rtl::deref(n_p5).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{})) || (prism_rtl::deref(n_p5).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseTopic{}))));
    }) ? ({
        auto&& n_p5 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ({
        auto t_p6 = crate::syntax::parser::here_f(p_p4);
        auto field_p7 = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(e_p0), prism_rtl::deref(n_p5).sigils_p, crate::syntax::Ident{.name_p = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(n_p5).path_p, Nat(0u)), Text::lit("")), .span_p = t_p6}})), .span_p = crate::syntax::parser::to_f(prism_rtl::deref(e_p0).span_p, t_p6)};
        auto p1_p8 = crate::syntax::parser::adv_f(p_p4);
        arg_starts_here_f(p1_p8) && (!prism_rtl::deref(crate::syntax::parser::tk_f(p1_p8)).line_start_p)
        ? ({
        auto commas_p2x = prism_rtl::deref(commas_p2);
        (crate::prelude::call_then(start_parse_call_args_f(p1_p8, std::move(commas_p2x)), [=](std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps> parse_call_args_f_9918) {
        return ({
            auto [args_p9, p2_pa] = parse_call_args_f_9918;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(field_p7), args_p9, false, false})), .span_p = crate::syntax::parser::to_f(prism_rtl::deref(field_p7).span_p, crate::syntax::parser::prev_f(p2_pa))}, p2_pa, false}));
        });
    }));
    })
        : prism_rtl::finished(std::tuple{field_p7, p1_p8, true});
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& w_pb = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m9299_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m9299_1_1 == Text::lit("")) && crate::syntax::lexer::is_bound_word_f(w_pb);
    }) ? ({
        auto&& w_pb = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m9299_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto t_pc = crate::syntax::parser::here_f(p_p4);
        (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(e_p0), Text::lit(""), crate::syntax::Ident{.name_p = w_pb, .span_p = t_pc}})), .span_p = crate::syntax::parser::to_f(prism_rtl::deref(e_p0).span_p, t_pc)}, crate::syntax::parser::adv_f(p_p4), true}));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n_pd = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ((prism_rtl::deref(n_pd).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})) || (prism_rtl::deref(n_pd).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseReserved{})));
    }) ? ({
        auto&& n_pd = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ({
        auto [method_pe, p1_pf] = crate::syntax::parser::parse_sname_f(p_p4);
        auto [args_pg, p2_ph] = arg_starts_here_f(p1_pf)
            ? parse_call_args_f(p1_pf, commas_p2)
            : std::tuple{Array<crate::syntax::Arg>{}, p1_pf};
        (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMethod{prism_rtl::rc(e_p0), method_pe, args_pg})), .span_p = crate::syntax::parser::to_f(prism_rtl::deref(e_p0).span_p, crate::syntax::parser::prev_f(p2_ph))}, p2_ph, false}));
    });
    })
        : prism_rtl::finished(std::tuple{e_p0, crate::syntax::parser::error_at_f(p_p4, dot_p3, Text::lit("expected a field name or a `.Method` after `.`")), false});
    });
}


/// `Start FieldOrMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool>> start_field_or_method_f(crate::syntax::Expr e_p0, crate::syntax::parser::Ps p0_p1, bool commas_p2) {
    return prism_rtl::make_rc<FieldOrMethod>(e_p0, p0_p1, commas_p2);
}


/// ParseTypeArgs: unbounded fn Ps -> (([Type], Ps))
std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps> parse_type_args_f(const crate::syntax::parser::Ps& p_p0) {
    auto [types_p1, q_p2] = crate::syntax::parser::commas_f(crate::syntax::parser::adv_f(p_p0), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(crate::syntax::parser::types::start_parse_type_f(a0)); })));
    return crate::syntax::parser::kind_f(q_p2) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KGtGt{})
        ? std::tuple{types_p1, crate::syntax::parser::adv_f(q_p2)}
        : std::tuple{types_p1, crate::syntax::parser::error_here_f(q_p2, Text::lit("expected `>>` to close the type arguments"))};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>> ParseTypeArgs::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto p_p0x = p_p0;
    return crate::prelude::call_then(crate::syntax::parser::start_commas_f(crate::syntax::parser::adv_f(p_p0x), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(crate::syntax::parser::types::start_parse_type_f(a0)); }))), [=](std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps> commas_f_10908) {
        return ({
            auto [types_p1, q_p2] = commas_f_10908;
            (crate::syntax::parser::kind_f(q_p2) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KGtGt{})
            ? prism_rtl::finished(std::tuple{types_p1, crate::syntax::parser::adv_f(q_p2)})
            : prism_rtl::finished(std::tuple{types_p1, crate::syntax::parser::error_here_f(q_p2, Text::lit("expected `>>` to close the type arguments"))}));
        });
    });
}


/// `Start ParseTypeArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>> start_parse_type_args_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseTypeArgs>(p_p0);
}


/// ArgStartsHere: fn Ps -> Bool
bool arg_starts_here_f(const crate::syntax::parser::Ps& p_p0) {
    auto t_p1 = crate::syntax::parser::tk_f(p_p0);
    auto&& _m = prism_rtl::deref(t_p1).kind_p;
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KRegex>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTemplate>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLensDot>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KBackslash>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KAbsent>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m11225_12_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        auto&& prefix_p2 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a1;
        if (m11225_12_0 == Text::lit("[")) {
            return (prism_rtl::deref(prefix_p2) || (!prism_rtl::deref(t_p1).touches_p)) || crate::syntax::parser::at_double_open_f(p_p0, Text::lit("["));
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a1) {
        auto&& op_p3 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        return (op_p3 == Text::lit("+")) || (op_p3 == Text::lit("-"));
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(_m).a0) {
        return !at_line_method_f(p_p0);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& w_p4 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        return crate::prelude::fold(arg_words_p(), false, [&](const bool& seen_p5, const Text& x_p6) { return prism_rtl::deref(seen_p5) || (x_p6 == w_p4); });
    }
    {
        return false;
    }
}


/// let argWords
Array<Text> arg_words_p() {
    return Array(std::vector{Text::lit("unit"), Text::lit("nil"), Text::lit("key"), Text::lit("ix"), Text::lit("jx"), Text::lit("kx"), Text::lit("not"), Text::lit("any"), Text::lit("given"), Text::lit("update"), Text::lit("match"), Text::lit("rebuild"), Text::lit("widget"), Text::lit("output"), Text::lit("inline_text"), Text::lit("raw")});
}


/// ParseCallArgs: unbounded fn Ps, Bool -> (([Arg], Ps))
std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps> parse_call_args_f(const crate::syntax::parser::Ps& p_p0, const bool& commas_p1) {
    return commas_p1 && (!p_p0.step_mode_p)
        ? crate::syntax::parser::commas_f(p_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Arg, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(start_parse_arg_f(a0)); })))
        : parse_one_arg_f(p_p0);
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> ParseCallArgs::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& commas_p1 = this->commas_p1;
    return prism_rtl::deref(commas_p1) && (!prism_rtl::deref(p_p0).step_mode_p)
        ? prism_rtl::more(prism_rtl::rc(crate::syntax::parser::Commas(p_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Arg, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(start_parse_arg_f(a0)); })))))
        : prism_rtl::more(prism_rtl::rc(ParseOneArg(p_p0)));
}


/// `Start ParseCallArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> start_parse_call_args_f(crate::syntax::parser::Ps p_p0, bool commas_p1) {
    return prism_rtl::make_rc<ParseCallArgs>(p_p0, commas_p1);
}


/// ParseOneArg: unbounded fn Ps -> (([Arg], Ps))
std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps> parse_one_arg_f(const crate::syntax::parser::Ps& p_p0) {
    auto [a_p1, q_p2] = parse_arg_f(p_p0);
    return std::tuple{Array(std::vector{a_p1}), q_p2};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> ParseOneArg::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto p_p0x = p_p0;
    return crate::prelude::call_then(start_parse_arg_f(p_p0x), [=](std::tuple<crate::syntax::Arg, crate::syntax::parser::Ps> parse_arg_f_12477) {
        return ({
            auto [a_p1, q_p2] = parse_arg_f_12477;
            (prism_rtl::finished(std::tuple{Array(std::vector{a_p1}), q_p2}));
        });
    });
}


/// `Start ParseOneArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> start_parse_one_arg_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseOneArg>(p_p0);
}


/// ParseArg: unbounded fn Ps -> ((Arg, Ps))
std::tuple<crate::syntax::Arg, crate::syntax::parser::Ps> parse_arg_f(const crate::syntax::parser::Ps& p_p0) {
    auto [value_p1, q_p2] = parse_arg_expr_f(p_p0);
    return std::tuple{crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = value_p1, .span_p = prism_rtl::deref(value_p1).span_p}, q_p2};
}


prism_rtl::Turn<std::tuple<crate::syntax::Arg, crate::syntax::parser::Ps>> ParseArg::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto p_p0x = p_p0;
    return crate::prelude::call_then(start_parse_arg_expr_f(p_p0x), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_arg_expr_f_12585) {
        return ({
            auto [value_p1, q_p2] = parse_arg_expr_f_12585;
            (prism_rtl::finished(std::tuple{crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = value_p1, .span_p = prism_rtl::deref(value_p1).span_p}, q_p2}));
        });
    });
}


/// `Start ParseArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Arg, crate::syntax::parser::Ps>> start_parse_arg_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseArg>(p_p0);
}


/// ParseParenArgs: unbounded fn Ps -> (([Arg], Bool, Ps))
std::tuple<Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps> parse_paren_args_f(const crate::syntax::parser::Ps& p0_p0) {
    auto p_p1 = crate::syntax::parser::adv_f(p0_p0);
    return crate::syntax::parser::at_close_f(p_p1, Text::lit("("))
        ? std::tuple{Array<crate::syntax::Arg>{}, false, crate::syntax::parser::adv_f(p_p1)}
        : ({
        auto r_p2 = ({
            ArgsRead this_ = ArgsRead{.args_p = Array<crate::syntax::Arg>{}, .rest_p = false, .p_p = p_p1, .going_p = true};
            while (this_.going_p && (!prism_rtl::deref(this_.p_p).bad_p)) {
                if (crate::syntax::parser::kind_f(this_.p_p) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDotDot{})) {
                    this_.p_p = crate::syntax::parser::adv_f(this_.p_p);
                    this_.rest_p = true;
                } else  {
                    auto start_p3 = crate::syntax::parser::here_f(this_.p_p);
                    auto [name_o4, p1_p5] = parse_arg_name_f(this_.p_p);
                    auto [value_p6, p2_p7] = parse_arg_expr_f(p1_p5);
                    this_.args_p = crate::prelude::push(this_.args_p, crate::syntax::Arg{.name_o = name_o4, .value_p = value_p6, .span_p = crate::syntax::parser::to_f(start_p3, prism_rtl::deref(value_p6).span_p)});
                    this_.p_p = p2_p7;
                }
                if (crate::syntax::parser::at_comma_f(this_.p_p)) {
                    this_.p_p = crate::syntax::parser::adv_f(this_.p_p);
                } else  {
                    this_.p_p = crate::syntax::parser::expect_close_f(this_.p_p, Text::lit("("));
                    this_.going_p = false;
                }
            }
            (std::move(this_));
        });
        std::tuple{prism_rtl::deref(r_p2).args_p, prism_rtl::deref(r_p2).rest_p, prism_rtl::deref(r_p2).p_p};
    });
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps>> ParseParenArgs::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    auto p_p1 = crate::syntax::parser::adv_f(p0_p0);
    return crate::syntax::parser::at_close_f(p_p1, Text::lit("("))
        ? prism_rtl::finished(std::tuple{Array<crate::syntax::Arg>{}, false, crate::syntax::parser::adv_f(p_p1)})
        : ({
        ArgsRead this_ = ArgsRead{.args_p = Array<crate::syntax::Arg>{}, .rest_p = false, .p_p = p_p1, .going_p = true};
        auto p_p1z = p_p1;
        (crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_)}, ({
        auto p_p1x = p_p1;
        [=](std::tuple<ArgsRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return prism_rtl::deref(this_).going_p && (!prism_rtl::deref(prism_rtl::deref(this_).p_p).bad_p)
            ? ({
            if (crate::syntax::parser::kind_f(prism_rtl::deref(this_).p_p) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDotDot{})) {
                prism_rtl::deref(this_).p_p = crate::syntax::parser::adv_f(prism_rtl::deref(this_).p_p);
                prism_rtl::deref(this_).rest_p = true;
            } else  {
                auto start_p3 = crate::syntax::parser::here_f(prism_rtl::deref(this_).p_p);
                auto [name_o4, p1_p5] = parse_arg_name_f(prism_rtl::deref(this_).p_p);
                auto [value_p6, p2_p7] = parse_arg_expr_f(p1_p5);
                prism_rtl::deref(this_).args_p = crate::prelude::push(prism_rtl::deref(this_).args_p, crate::syntax::Arg{.name_o = name_o4, .value_p = value_p6, .span_p = crate::syntax::parser::to_f(start_p3, prism_rtl::deref(value_p6).span_p)});
                prism_rtl::deref(this_).p_p = p2_p7;
            }
            if (crate::syntax::parser::at_comma_f(prism_rtl::deref(this_).p_p)) {
                prism_rtl::deref(this_).p_p = crate::syntax::parser::adv_f(prism_rtl::deref(this_).p_p);
            } else  {
                prism_rtl::deref(this_).p_p = crate::syntax::parser::expect_close_f(prism_rtl::deref(this_).p_p, Text::lit("("));
                prism_rtl::deref(this_).going_p = false;
            }
            Expected<std::tuple<ArgsRead>, std::tuple<ArgsRead>>(std::tuple{this_});
        })
            : Expected<std::tuple<ArgsRead>, std::tuple<ArgsRead>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<ArgsRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto r_p2 = this_;
            (prism_rtl::finished(std::tuple{prism_rtl::deref(r_p2).args_p, prism_rtl::deref(r_p2).rest_p, prism_rtl::deref(r_p2).p_p}));
        });
    }));
    });
}


/// `Start ParseParenArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps>> start_parse_paren_args_f(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseParenArgs>(p0_p0);
}


/// ParseArgName: fn Ps -> ((?Ident, Ps))
std::tuple<std::optional<crate::syntax::Ident>, crate::syntax::parser::Ps> parse_arg_name_f(const crate::syntax::parser::Ps& p_p0) {
    auto&& _m = crate::syntax::parser::kind_f(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if ((((prism_rtl::deref(n_p1).sigils_p == Text::lit("")) && (crate::prelude::len(prism_rtl::deref(n_p1).path_p) == Nat(1u))) && (prism_rtl::deref(n_p1).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) && crate::syntax::parser::at_op_f(crate::syntax::parser::adv_f(p_p0), Text::lit("="))) {
            return std::tuple{std::optional(crate::syntax::Ident{.name_p = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(n_p1).path_p, Nat(0u)), Text::lit("")), .span_p = crate::syntax::parser::here_f(p_p0)}), crate::syntax::parser::adv_f(crate::syntax::parser::adv_f(p_p0))};
        }
    }
    {
        return std::tuple{std::optional<crate::syntax::Ident>{}, p_p0};
    }
}


/// ParsePrimary: unbounded fn Ps, Bool -> ((Expr, Bool, Ps))
std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> parse_primary_f(const crate::syntax::parser::Ps& p_p0, const bool& commas_p1) {
    auto start_p2 = crate::syntax::parser::here_f(p_p0);
    auto tok_p3 = crate::syntax::parser::tk_f(p_p0);
    auto&& _m = prism_rtl::deref(tok_p3).kind_p;
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n_p4 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        return name_primary_f(p_p0, n_p4, commas_p1);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& w_p5 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& sigils_p6 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        return keyword_primary_f(p_p0, w_p5, sigils_p6, commas_p1);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m)) {
        return literal_primary_f(p_p0);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(_m)) {
        return literal_primary_f(p_p0);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(_m)) {
        return literal_primary_f(p_p0);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(_m)) {
        return literal_primary_f(p_p0);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m)) {
        return literal_primary_f(p_p0);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KRegex>(_m)) {
        return literal_primary_f(p_p0);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTemplate>(_m)) {
        auto&& t_p7 = prism_rtl::as<crate::syntax::lexer::TokKind::KTemplate>(_m).a0;
        auto [tpl_p8, q_p9] = parse_template_f(crate::syntax::parser::adv_f(p_p0), t_p7, prism_rtl::deref(tok_p3).span_p);
        return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETemplate{tpl_p8})), .span_p = prism_rtl::deref(tok_p3).span_p}, false, q_p9};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m14436_9_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m14436_9_0 == Text::lit("(")) {
            return paren_primary_f(p_p0);
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m14436_10_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m14436_10_0 == Text::lit("[")) {
            return square_primary_f(p_p0);
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        return map_primary_f(p_p0);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(_m).a0) {
        auto p1_pa = crate::syntax::parser::adv_f(p_p0);
        auto&& _m = crate::syntax::parser::kind_f(p1_pa);
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
            auto&& n_pb = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
            if (((prism_rtl::deref(n_pb).sigils_p == Text::lit("")) && (crate::prelude::len(prism_rtl::deref(n_pb).path_p) == Nat(1u))) && (prism_rtl::deref(n_pb).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) {
                auto t_pc = crate::syntax::parser::here_f(p1_pa);
                return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETopicField{crate::syntax::Ident{.name_p = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(n_pb).path_p, Nat(0u)), Text::lit("")), .span_p = t_pc}})), .span_p = crate::syntax::parser::to_f(start_p2, t_pc)}, false, crate::syntax::parser::adv_f(p1_pa)};
            }
        }
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
            auto&& n_pd = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
            if (prism_rtl::deref(n_pd).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})) {
                return std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p1_pa, start_p2, prism_rtl::cat("a spaced `.", crate::syntax::lexer::chars::join_f(prism_rtl::deref(n_pd).path_p, Text::lit(".")), "` begins its own line, below the call it takes as its receiver (layout rule 9)"))};
            }
        }
        {
            return std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p1_pa, start_p2, Text::lit("a prefix `.` takes a field name, applied to the topic `_`"))};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLensDot>(_m)) {
        return lens_primary_f(p_p0);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
        auto&& s_pe = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        return s_pe == Text::lit("!")
            ? std::tuple{crate::syntax::parser::decls::no_expr_p(), true, crate::syntax::parser::error_at_f(crate::syntax::parser::adv_f(p_p0), prism_rtl::deref(tok_p3).span_p, Text::lit("`!` is never free: no event fires a constant"))}
            : s_pe == Text::lit("&")
            ? std::tuple{crate::syntax::parser::decls::no_expr_p(), true, crate::syntax::parser::error_at_f(crate::syntax::parser::adv_f(p_p0), prism_rtl::deref(tok_p3).span_p, Text::lit("`&` is never free: no reference exists outside the value an `update` block names"))}
            : ({
            auto [operand_pf, q_pg] = parse_expr_ctx_f(crate::syntax::parser::adv_f(p_p0), commas_p1);
            std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EFreeSigil{s_pe, prism_rtl::rc(operand_pf)})), .span_p = crate::syntax::parser::to_f(start_p2, prism_rtl::deref(operand_pf).span_p)}, true, q_pg};
        });
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KBackslash>(_m)) {
        auto [e_ph, q_pi] = parse_lambda_f(p_p0);
        return std::tuple{e_ph, true, q_pi};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KAbsent>(_m)) {
        auto q_pj = crate::syntax::parser::out_of_scope_f(crate::syntax::parser::adv_f(p_p0), prism_rtl::deref(tok_p3).span_p, Text::lit("sparse tuples"), Text::lit("an absent component `-` makes a sparse tuple, which is out of this compiler"));
        return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EAbsent{})), .span_p = prism_rtl::deref(tok_p3).span_p}, false, q_pj};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDotDot>(_m)) {
        return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ERest{})), .span_p = prism_rtl::deref(tok_p3).span_p}, false, crate::syntax::parser::adv_f(p_p0)};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTrait>(_m)) {
        return std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, prism_rtl::deref(tok_p3).span_p, Text::lit("no trait is a value: a `^Trait` stands in a type, a bound, `derive`, `trait` or `impl`"))};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        auto&& path_pk = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        return std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, prism_rtl::deref(tok_p3).span_p, prism_rtl::cat("`", crate::syntax::lexer::chars::join_f(path_pk, Text::lit(".")), ".*` names every tag of a family: it stands in a pattern, an `emit` row or a `use`, not in an expression"))};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KBar>(_m)) {
        return std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, prism_rtl::deref(tok_p3).span_p, Text::lit("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row"))};
    }
    {
        return std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_here_f(p_p0, Text::lit("expected an expression"))};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> ParsePrimary::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& commas_p1 = this->commas_p1;
    auto start_p2 = crate::syntax::parser::here_f(p_p0);
    auto tok_p3 = crate::syntax::parser::tk_f(p_p0);
    return ({
        auto&& _m = prism_rtl::deref(tok_p3).kind_p;
        prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) ? ({
        auto&& n_p4 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(NamePrimary(p_p0, n_p4, prism_rtl::deref(commas_p1))));
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) ? ({
        auto&& w_p5 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& sigils_p6 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        prism_rtl::more(prism_rtl::rc(KeywordPrimary(p_p0, w_p5, sigils_p6, prism_rtl::deref(commas_p1))));
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_p0)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_p0)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_p0)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_p0)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_p0)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KRegex>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_p0)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KTemplate>(_m) ? ({
        auto&& t_p7 = prism_rtl::as<crate::syntax::lexer::TokKind::KTemplate>(_m).a0;
        ({
        auto p_p0x = p_p0;
        auto t_p7x = t_p7;
        (crate::prelude::call_then(start_parse_template_f(crate::syntax::parser::adv_f(p_p0x), t_p7x, prism_rtl::deref(tok_p3).span_p), [=](std::tuple<crate::syntax::Template, crate::syntax::parser::Ps> parse_template_f_14898) {
        return ({
            auto [tpl_p8, q_p9] = parse_template_f_14898;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETemplate{tpl_p8})), .span_p = prism_rtl::deref(tok_p3).span_p}, false, q_p9}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && ({
        auto&& m14436_9_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        (m14436_9_0 == Text::lit("("));
    }) ? ({
        auto&& m14436_9_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ParenPrimary(p_p0)));
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && ({
        auto&& m14436_10_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        (m14436_10_0 == Text::lit("["));
    }) ? ({
        auto&& m14436_10_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        prism_rtl::more(prism_rtl::rc(SquarePrimary(p_p0)));
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) ? prism_rtl::more(prism_rtl::rc(MapPrimary(p_p0)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(_m).a0 ? ({
        auto p1_pa = crate::syntax::parser::adv_f(p_p0);
        ({
        auto&& _m = crate::syntax::parser::kind_f(p1_pa);
        prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n_pb = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        (((prism_rtl::deref(n_pb).sigils_p == Text::lit("")) && (crate::prelude::len(prism_rtl::deref(n_pb).path_p) == Nat(1u))) && (prism_rtl::deref(n_pb).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{})));
    }) ? ({
        auto&& n_pb = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ({
        auto t_pc = crate::syntax::parser::here_f(p1_pa);
        (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETopicField{crate::syntax::Ident{.name_p = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(n_pb).path_p, Nat(0u)), Text::lit("")), .span_p = t_pc}})), .span_p = crate::syntax::parser::to_f(start_p2, t_pc)}, false, crate::syntax::parser::adv_f(p1_pa)}));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n_pd = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        (prism_rtl::deref(n_pd).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{}));
    }) ? ({
        auto&& n_pd = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p1_pa, start_p2, prism_rtl::cat("a spaced `.", crate::syntax::lexer::chars::join_f(prism_rtl::deref(n_pd).path_p, Text::lit(".")), "` begins its own line, below the call it takes as its receiver (layout rule 9)"))});
    })
        : prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p1_pa, start_p2, Text::lit("a prefix `.` takes a field name, applied to the topic `_`"))});
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KLensDot>(_m) ? prism_rtl::more(prism_rtl::rc(LensPrimary(p_p0)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m) ? ({
        auto&& s_pe = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        s_pe == Text::lit("!")
        ? prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr_p(), true, crate::syntax::parser::error_at_f(crate::syntax::parser::adv_f(p_p0), prism_rtl::deref(tok_p3).span_p, Text::lit("`!` is never free: no event fires a constant"))})
        : s_pe == Text::lit("&")
        ? prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr_p(), true, crate::syntax::parser::error_at_f(crate::syntax::parser::adv_f(p_p0), prism_rtl::deref(tok_p3).span_p, Text::lit("`&` is never free: no reference exists outside the value an `update` block names"))})
        : ({
        auto commas_p1x = prism_rtl::deref(commas_p1);
        auto p_p0x = p_p0;
        auto s_pex = s_pe;
        (crate::prelude::call_then(start_parse_expr_ctx_f(crate::syntax::parser::adv_f(p_p0x), std::move(commas_p1x)), [=, s_pex = std::move(s_pex)](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_ctx_f_16414) {
        return ({
            auto [operand_pf, q_pg] = parse_expr_ctx_f_16414;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EFreeSigil{s_pex, prism_rtl::rc(operand_pf)})), .span_p = crate::syntax::parser::to_f(start_p2, prism_rtl::deref(operand_pf).span_p)}, true, q_pg}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KBackslash>(_m) ? ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(start_parse_lambda_f(p_p0x), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_lambda_f_16585) {
        return ({
            auto [e_ph, q_pi] = parse_lambda_f_16585;
            (prism_rtl::finished(std::tuple{e_ph, true, q_pi}));
        });
    }));
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KAbsent>(_m) ? ({
        auto q_pj = crate::syntax::parser::out_of_scope_f(crate::syntax::parser::adv_f(p_p0), prism_rtl::deref(tok_p3).span_p, Text::lit("sparse tuples"), Text::lit("an absent component `-` makes a sparse tuple, which is out of this compiler"));
        (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EAbsent{})), .span_p = prism_rtl::deref(tok_p3).span_p}, false, q_pj}));
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KDotDot>(_m) ? prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ERest{})), .span_p = prism_rtl::deref(tok_p3).span_p}, false, crate::syntax::parser::adv_f(p_p0)})
        : prism_rtl::is<crate::syntax::lexer::TokKind::KTrait>(_m) ? prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, prism_rtl::deref(tok_p3).span_p, Text::lit("no trait is a value: a `^Trait` stands in a type, a bound, `derive`, `trait` or `impl`"))})
        : prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m) ? ({
        auto&& path_pk = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, prism_rtl::deref(tok_p3).span_p, prism_rtl::cat("`", crate::syntax::lexer::chars::join_f(path_pk, Text::lit(".")), ".*` names every tag of a family: it stands in a pattern, an `emit` row or a `use`, not in an expression"))});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KBar>(_m) ? prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, prism_rtl::deref(tok_p3).span_p, Text::lit("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row"))})
        : prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_here_f(p_p0, Text::lit("expected an expression"))});
    });
}


/// `Start ParsePrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_parse_primary_f(crate::syntax::parser::Ps p_p0, bool commas_p1) {
    return prism_rtl::make_rc<ParsePrimary>(p_p0, commas_p1);
}


/// LiteralPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> literal_primary_f(const crate::syntax::parser::Ps& p_p0) {
    auto [lit_p1, q_p2] = parse_literal_f(p_p0);
    return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELit{lit_p1})), .span_p = prism_rtl::deref(lit_p1).span_p}, false, q_p2};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> LiteralPrimary::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto p_p0x = p_p0;
    return crate::prelude::call_then(start_parse_literal_f(p_p0x), [=](std::tuple<crate::syntax::Literal, crate::syntax::parser::Ps> parse_literal_f_17581) {
        return ({
            auto [lit_p1, q_p2] = parse_literal_f_17581;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELit{lit_p1})), .span_p = prism_rtl::deref(lit_p1).span_p}, false, q_p2}));
        });
    });
}


/// `Start LiteralPrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_literal_primary_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<LiteralPrimary>(p_p0);
}


/// NamePrimary: unbounded fn Ps, NameTok, Bool -> ((Expr, Bool, Ps))
std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> name_primary_f(const crate::syntax::parser::Ps& p0_p0, const crate::syntax::lexer::NameTok& n_p1, const bool& commas_p2) {
    auto start_p3 = crate::syntax::parser::here_f(p0_p0);
    auto name_p4 = crate::syntax::SName{.sigils_p = n_p1.sigils_p, .path_p = n_p1.path_p, .span_p = start_p3};
    auto p1_p5 = crate::syntax::parser::check_name_scope_f(crate::syntax::parser::adv_f(p0_p0), name_p4);
    auto plain_p6 = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name_p4})), .span_p = start_p3};
    auto [e_p7, p_p8] = crate::syntax::parser::kind_f(p1_p5) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLtLt{})
        ? type_args_on_f(plain_p6, p1_p5, start_p3)
        : std::tuple{plain_p6, p1_p5};
    return crate::syntax::parser::is_callee_f(name_p4)
        ? crate::syntax::parser::at_single_open_f(p_p8, Text::lit("(")) && prism_rtl::deref(crate::syntax::parser::tk_f(p_p8)).touches_p
        ? ({
        auto [args_p9, rest_pa, q_pb] = parse_paren_args_f(p_p8);
        std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(e_p7), args_p9, true, rest_pa})), .span_p = crate::syntax::parser::to_f(start_p3, crate::syntax::parser::prev_f(q_pb))}, false, q_pb};
    })
        : crate::syntax::parser::at_kw_f(p_p8, Text::lit("monad"))
        ? ({
        auto kw_pc = crate::syntax::parser::here_f(p_p8);
        auto [body_pd, q_pe] = crate::syntax::parser::blocks::parse_block_after_colon_f(crate::syntax::parser::out_of_scope_f(crate::syntax::parser::adv_f(p_p8), kw_pc, Text::lit("`T monad:` blocks and `^Monad`"), Text::lit("monad blocks are out of this compiler")));
        std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMonad{prism_rtl::rc(e_p7), body_pd})), .span_p = crate::syntax::parser::to_f(start_p3, prism_rtl::deref(body_pd).span_p)}, true, q_pe};
    })
        : arg_starts_here_f(p_p8)
        ? ({
        auto [args_pf, q_pg] = parse_call_args_f(p_p8, commas_p2);
        std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(e_p7), args_pf, false, false})), .span_p = crate::syntax::parser::to_f(start_p3, crate::syntax::parser::prev_f(q_pg))}, true, q_pg};
    })
        : std::tuple{e_p7, false, p_p8}
        : (crate::syntax::parser::at_single_open_f(p_p8, Text::lit("(")) && prism_rtl::deref(crate::syntax::parser::tk_f(p_p8)).touches_p) && (!crate::syntax::parser::is_topic_f(name_p4))
        ? std::tuple{e_p7, false, crate::syntax::parser::error_at_f(p_p8, crate::syntax::parser::here_f(p_p8), prism_rtl::cat("`", crate::syntax::parser::name_text_f(name_p4), "` is a value and is not applied: a function\'s name is uppercase (case is a mark)"))}
        : std::tuple{e_p7, false, p_p8};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> NamePrimary::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    const auto& n_p1 = this->n_p1;
    const auto& commas_p2 = this->commas_p2;
    auto start_p3 = crate::syntax::parser::here_f(p0_p0);
    auto name_p4 = crate::syntax::SName{.sigils_p = prism_rtl::deref(n_p1).sigils_p, .path_p = prism_rtl::deref(n_p1).path_p, .span_p = start_p3};
    auto p1_p5 = crate::syntax::parser::check_name_scope_f(crate::syntax::parser::adv_f(p0_p0), name_p4);
    auto plain_p6 = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name_p4})), .span_p = start_p3};
    auto [e_p7, p_p8] = crate::syntax::parser::kind_f(p1_p5) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLtLt{})
        ? type_args_on_f(plain_p6, p1_p5, start_p3)
        : std::tuple{plain_p6, p1_p5};
    return crate::syntax::parser::is_callee_f(name_p4)
        ? crate::syntax::parser::at_single_open_f(p_p8, Text::lit("(")) && prism_rtl::deref(crate::syntax::parser::tk_f(p_p8)).touches_p
        ? crate::prelude::call_then(start_parse_paren_args_f(p_p8), [=](std::tuple<Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps> parse_paren_args_f_18204) {
        return ({
            auto [args_p9, rest_pa, q_pb] = parse_paren_args_f_18204;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(e_p7), args_p9, true, rest_pa})), .span_p = crate::syntax::parser::to_f(start_p3, crate::syntax::parser::prev_f(q_pb))}, false, q_pb}));
        });
    })
        : crate::syntax::parser::at_kw_f(p_p8, Text::lit("monad"))
        ? ({
        auto kw_pc = crate::syntax::parser::here_f(p_p8);
        (crate::prelude::call_then(crate::syntax::parser::blocks::start_parse_block_after_colon_f(crate::syntax::parser::out_of_scope_f(crate::syntax::parser::adv_f(p_p8), kw_pc, Text::lit("`T monad:` blocks and `^Monad`"), Text::lit("monad blocks are out of this compiler"))), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_f_18455) {
        return ({
            auto [body_pd, q_pe] = parse_block_after_colon_f_18455;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMonad{prism_rtl::rc(e_p7), body_pd})), .span_p = crate::syntax::parser::to_f(start_p3, prism_rtl::deref(body_pd).span_p)}, true, q_pe}));
        });
    }));
    })
        : arg_starts_here_f(p_p8)
        ? ({
        auto commas_p2x = prism_rtl::deref(commas_p2);
        (crate::prelude::call_then(start_parse_call_args_f(p_p8, std::move(commas_p2x)), [=](std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps> parse_call_args_f_18721) {
        return ({
            auto [args_pf, q_pg] = parse_call_args_f_18721;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(e_p7), args_pf, false, false})), .span_p = crate::syntax::parser::to_f(start_p3, crate::syntax::parser::prev_f(q_pg))}, true, q_pg}));
        });
    }));
    })
        : prism_rtl::finished(std::tuple{e_p7, false, p_p8})
        : (crate::syntax::parser::at_single_open_f(p_p8, Text::lit("(")) && prism_rtl::deref(crate::syntax::parser::tk_f(p_p8)).touches_p) && (!crate::syntax::parser::is_topic_f(name_p4))
        ? prism_rtl::finished(std::tuple{e_p7, false, crate::syntax::parser::error_at_f(p_p8, crate::syntax::parser::here_f(p_p8), prism_rtl::cat("`", crate::syntax::parser::name_text_f(name_p4), "` is a value and is not applied: a function\'s name is uppercase (case is a mark)"))})
        : prism_rtl::finished(std::tuple{e_p7, false, p_p8});
}


/// `Start NamePrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_name_primary_f(crate::syntax::parser::Ps p0_p0, crate::syntax::lexer::NameTok n_p1, bool commas_p2) {
    return prism_rtl::make_rc<NamePrimary>(p0_p0, n_p1, commas_p2);
}


/// TypeArgsOn: unbounded fn Expr, Ps, Range -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> type_args_on_f(const crate::syntax::Expr& e_p0, const crate::syntax::parser::Ps& p_p1, const crate::syntax::Range& start_p2) {
    auto [types_p3, q_p4] = parse_type_args_f(p_p1);
    return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETypeArgs{prism_rtl::rc(e_p0), types_p3})), .span_p = crate::syntax::parser::to_f(start_p2, crate::syntax::parser::prev_f(q_p4))}, q_p4};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> TypeArgsOn::cycle() const {
    const auto& e_p0 = this->e_p0;
    const auto& p_p1 = this->p_p1;
    const auto& start_p2 = this->start_p2;
    auto e_p0x = e_p0;
    auto p_p1x = p_p1;
    auto start_p2x = start_p2;
    return crate::prelude::call_then(start_parse_type_args_f(p_p1x), [=](std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps> parse_type_args_f_19224) {
        return ({
            auto [types_p3, q_p4] = parse_type_args_f_19224;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETypeArgs{prism_rtl::rc(e_p0x), types_p3})), .span_p = crate::syntax::parser::to_f(start_p2x, crate::syntax::parser::prev_f(q_p4))}, q_p4}));
        });
    });
}


/// `Start TypeArgsOn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_type_args_on_f(crate::syntax::Expr e_p0, crate::syntax::parser::Ps p_p1, crate::syntax::Range start_p2) {
    return prism_rtl::make_rc<TypeArgsOn>(e_p0, p_p1, start_p2);
}


/// ParenPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> paren_primary_f(const crate::syntax::parser::Ps& p_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    return crate::syntax::parser::at_double_open_f(p_p0, Text::lit("("))
        ? ({
        auto [elems_p3, p1_p4] = crate::syntax::parser::commas_f(crate::syntax::parser::open_double_f(p_p0), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(start_parse_arg_expr_f(a0)); })));
        auto p2_p2 = crate::syntax::parser::close_double_f(p1_p4, Text::lit("("));
        std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETuple{elems_p3})), .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(p2_p2))}, false, p2_p2};
    })
        : ({
        auto [inner_p5, p1_p6] = crate::syntax::parser::bracketed_f(crate::syntax::parser::adv_f(p_p0), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(start_parse_rhs_expr_f(a0)); })));
        (crate::syntax::parser::at_comma_f(p1_p6)
        ? std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p1_p6, crate::syntax::parser::here_f(p1_p6), Text::lit("a group holds one expression: a comma here needs a call at the group\'s head, or `((` `))` for a tuple"))}
        : ({
        auto p2_p7 = crate::syntax::parser::expect_close_f(p1_p6, Text::lit("("));
        std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EGroup{prism_rtl::rc(inner_p5)})), .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(p2_p7))}, false, p2_p7};
    }));
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> ParenPrimary::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    return crate::syntax::parser::at_double_open_f(p_p0, Text::lit("("))
        ? ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(crate::syntax::parser::start_commas_f(crate::syntax::parser::open_double_f(p_p0x), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(start_parse_arg_expr_f(a0)); }))), [=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::parser::Ps> commas_f_19554) {
        return ({
            auto [elems_p3, p1_p4] = commas_f_19554;
            auto p2_p2 = crate::syntax::parser::close_double_f(p1_p4, Text::lit("("));
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETuple{elems_p3})), .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(p2_p2))}, false, p2_p2}));
        });
    }));
    })
        : ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(crate::syntax::parser::start_bracketed_f(crate::syntax::parser::adv_f(p_p0x), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(start_parse_rhs_expr_f(a0)); }))), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> bracketed_f_19818) {
        return ({
            auto [inner_p5, p1_p6] = bracketed_f_19818;
            (crate::syntax::parser::at_comma_f(p1_p6)
            ? prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p1_p6, crate::syntax::parser::here_f(p1_p6), Text::lit("a group holds one expression: a comma here needs a call at the group\'s head, or `((` `))` for a tuple"))})
            : ({
            auto p2_p7 = crate::syntax::parser::expect_close_f(p1_p6, Text::lit("("));
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EGroup{prism_rtl::rc(inner_p5)})), .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(p2_p7))}, false, p2_p7}));
        }));
        });
    }));
    });
}


/// `Start ParenPrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_paren_primary_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParenPrimary>(p_p0);
}


/// SquarePrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> square_primary_f(const crate::syntax::parser::Ps& p_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    return crate::syntax::parser::at_double_open_f(p_p0, Text::lit("["))
        ? ({
        auto p1_p2 = crate::syntax::parser::open_double_f(p_p0);
        auto [elems_p4, p2_p5] = crate::syntax::parser::at_close_f(p1_p2, Text::lit("["))
            ? std::tuple{Array<crate::syntax::Expr>{}, p1_p2}
            : crate::syntax::parser::commas_f(p1_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(start_parse_arg_expr_f(a0)); })));
        auto p3_p3 = crate::syntax::parser::close_double_f(p2_p5, Text::lit("["));
        std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EArray{elems_p4})), .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(p3_p3))}, false, p3_p3};
    })
        : ({
        auto [index_p7, p1_p8] = crate::syntax::parser::bracketed_f(crate::syntax::parser::adv_f(p_p0), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(start_parse_expr_f(a0)); })));
        auto p2_p6 = crate::syntax::parser::expect_close_f(p1_p8, Text::lit("["));
        std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETopicIndex{prism_rtl::rc(index_p7)})), .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(p2_p6))}, false, p2_p6};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> SquarePrimary::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    return crate::syntax::parser::at_double_open_f(p_p0, Text::lit("["))
        ? ({
        auto p1_p2 = crate::syntax::parser::open_double_f(p_p0);
        auto [elems_p4, p2_p5] = crate::syntax::parser::at_close_f(p1_p2, Text::lit("["))
            ? std::tuple{Array<crate::syntax::Expr>{}, p1_p2}
            : crate::syntax::parser::commas_f(p1_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(start_parse_arg_expr_f(a0)); })));
        auto p3_p3 = crate::syntax::parser::close_double_f(p2_p5, Text::lit("["));
        (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EArray{elems_p4})), .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(p3_p3))}, false, p3_p3}));
    })
        : ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(crate::syntax::parser::start_bracketed_f(crate::syntax::parser::adv_f(p_p0x), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(start_parse_expr_f(a0)); }))), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> bracketed_f_20642) {
        return ({
            auto [index_p7, p1_p8] = bracketed_f_20642;
            auto p2_p6 = crate::syntax::parser::expect_close_f(p1_p8, Text::lit("["));
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETopicIndex{prism_rtl::rc(index_p7)})), .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(p2_p6))}, false, p2_p6}));
        });
    }));
    });
}


/// `Start SquarePrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_square_primary_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<SquarePrimary>(p_p0);
}


/// MapPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> map_primary_f(const crate::syntax::parser::Ps& p_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto p1_p2 = crate::syntax::parser::adv_f(p_p0);
    auto [entries_p4, p2_p5] = crate::syntax::parser::at_close_f(p1_p2, Text::lit("{"))
        ? std::tuple{Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>{}, p1_p2}
        : crate::syntax::parser::commas_f(p1_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::Expr>, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(start_parse_map_entry_f(a0)); })));
    auto p3_p3 = crate::syntax::parser::expect_close_f(p2_p5, Text::lit("{"));
    return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMap{entries_p4})), .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(p3_p3))}, false, p3_p3};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> MapPrimary::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto p1_p2 = crate::syntax::parser::adv_f(p_p0);
    auto [entries_p4, p2_p5] = crate::syntax::parser::at_close_f(p1_p2, Text::lit("{"))
        ? std::tuple{Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>{}, p1_p2}
        : crate::syntax::parser::commas_f(p1_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::Expr>, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(start_parse_map_entry_f(a0)); })));
    auto p3_p3 = crate::syntax::parser::expect_close_f(p2_p5, Text::lit("{"));
    return prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMap{entries_p4})), .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(p3_p3))}, false, p3_p3});
}


/// `Start MapPrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_map_primary_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<MapPrimary>(p_p0);
}


/// ParseMapEntry: unbounded fn Ps -> ((((Expr, Expr)), Ps))
std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::Expr>, crate::syntax::parser::Ps> parse_map_entry_f(const crate::syntax::parser::Ps& p_p0) {
    auto [k_p1, p1_p2] = parse_arg_expr_f(p_p0);
    auto [v_p3, p2_p4] = parse_arg_expr_f(crate::syntax::parser::expect_colon_f(p1_p2));
    return std::tuple{std::tuple{k_p1, v_p3}, p2_p4};
}


prism_rtl::Turn<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::Expr>, crate::syntax::parser::Ps>> ParseMapEntry::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto p_p0x = p_p0;
    return crate::prelude::call_then(start_parse_arg_expr_f(p_p0x), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_arg_expr_f_21225) {
        return ({
            auto [k_p1, p1_p2] = parse_arg_expr_f_21225;
            (crate::prelude::call_then(start_parse_arg_expr_f(crate::syntax::parser::expect_colon_f(p1_p2)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_arg_expr_f_21260) {
            return ({
                auto [v_p3, p2_p4] = parse_arg_expr_f_21260;
                (prism_rtl::finished(std::tuple{std::tuple{k_p1, v_p3}, p2_p4}));
            });
        }));
        });
    });
}


/// `Start ParseMapEntry, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::Expr>, crate::syntax::parser::Ps>> start_parse_map_entry_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseMapEntry>(p_p0);
}


/// LensPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> lens_primary_f(const crate::syntax::parser::Ps& p0_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p0_p0);
    auto r_p2 = ({
        std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Ident>{}, crate::syntax::parser::adv_f(p0_p0)};
        Array<crate::syntax::Ident> path_p3 = Array<crate::syntax::Ident>{};
        crate::syntax::parser::Ps p_p4 = crate::syntax::parser::adv_f(p0_p0);
        bool going_p5 = true;
        while (std::move(going_p5) && (!p_p4.bad_p)) {
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = crate::syntax::parser::kind_f(p_p4);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
                    auto&& n_p6 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
                    if (((prism_rtl::deref(n_p6).sigils_p == Text::lit("")) && (prism_rtl::deref(n_p6).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) && (crate::prelude::len(prism_rtl::deref(n_p6).path_p) == Nat(1u))) {
                        _v.set(({
                            path_p3 = crate::prelude::push(path_p3, crate::syntax::Ident{.name_p = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(n_p6).path_p, Nat(0u)), Text::lit("")), .span_p = crate::syntax::parser::here_f(p_p4)});
                            p_p4 = crate::syntax::parser::adv_f(p_p4);
                            if (crate::syntax::parser::kind_f(p_p4) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDot{false})) {
                                p_p4 = crate::syntax::parser::adv_f(p_p4);
                            } else  {
                                going_p5 = false;
                            }
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        p_p4 = crate::syntax::parser::error_here_f(p_p4, Text::lit("expected a field name in a lens path"));
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
        }
        this_ = std::tuple{path_p3, p_p4};
        (std::move(this_));
    });
    auto [path_p7, q_p8] = r_p2;
    return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELens{path_p7})), .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_p8))}, false, q_p8};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> LensPrimary::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    auto start_p1 = crate::syntax::parser::here_f(p0_p0);
    std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Ident>{}, crate::syntax::parser::adv_f(p0_p0)};
    Array<crate::syntax::Ident> path_p3 = Array<crate::syntax::Ident>{};
    crate::syntax::parser::Ps p_p4 = crate::syntax::parser::adv_f(p0_p0);
    bool going_p5 = true;
    auto start_p1z = start_p1;
    return crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_), std::move(going_p5), std::move(p_p4), std::move(path_p3)}, [=](std::tuple<std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Ident>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going_p5 = std::get<1>(_p0);
        auto p_p4 = std::get<2>(_p0);
        auto path_p3 = std::get<3>(_p0);
        return going_p5 && (!prism_rtl::deref(p_p4).bad_p)
            ? ({
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = crate::syntax::parser::kind_f(p_p4);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
                    auto&& n_p6 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
                    if (((prism_rtl::deref(n_p6).sigils_p == Text::lit("")) && (prism_rtl::deref(n_p6).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) && (crate::prelude::len(prism_rtl::deref(n_p6).path_p) == Nat(1u))) {
                        _v.set(({
                            path_p3 = crate::prelude::push(path_p3, crate::syntax::Ident{.name_p = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(n_p6).path_p, Nat(0u)), Text::lit("")), .span_p = crate::syntax::parser::here_f(p_p4)});
                            p_p4 = crate::syntax::parser::adv_f(p_p4);
                            if (crate::syntax::parser::kind_f(p_p4) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDot{false})) {
                                p_p4 = crate::syntax::parser::adv_f(p_p4);
                            } else  {
                                going_p5 = false;
                            }
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        p_p4 = crate::syntax::parser::error_here_f(p_p4, Text::lit("expected a field name in a lens path"));
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            Expected<std::tuple<std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Ident>>, std::tuple<std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Ident>>>(std::tuple{this_, going_p5, p_p4, path_p3});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Ident>>, std::tuple<std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Ident>>>(unexpected(std::tuple{this_, going_p5, p_p4, path_p3}));
    }), [=](std::tuple<std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Ident>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going_p5 = std::get<1>(_p0);
        auto p_p4 = std::get<2>(_p0);
        auto path_p3 = std::get<3>(_p0);
        return ({
            this_ = std::tuple{path_p3, p_p4};
            auto r_p2 = this_;
            auto [path_p7, q_p8] = r_p2;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELens{path_p7})), .span_p = crate::syntax::parser::to_f(start_p1z, crate::syntax::parser::prev_f(q_p8))}, false, q_p8}));
        });
    });
}


/// `Start LensPrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_lens_primary_f(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<LensPrimary>(p0_p0);
}


/// KeywordPrimary: unbounded fn Ps, Text, Text, Bool -> ((Expr, Bool, Ps))
std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> keyword_primary_f(const crate::syntax::parser::Ps& p_p0, const Text& w_p1, const Text& sigils_p2, const bool& commas_p3) {
    auto start_p4 = crate::syntax::parser::here_f(p_p0);
    {
        auto&& m22385_0 = w_p1;
        if (m22385_0 == Text::lit("unit")) {
            return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EUnit{sigils_p2})), .span_p = start_p4}, false, crate::syntax::parser::adv_f(p_p0)};
        }
    }
    {
        auto&& m22385_1 = w_p1;
        if (m22385_1 == Text::lit("nil")) {
            return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ENil{sigils_p2})), .span_p = start_p4}, false, crate::syntax::parser::adv_f(p_p0)};
        }
    }
    {
        if (crate::syntax::lexer::is_bound_word_f(w_p1)) {
            return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EBound{w_p1})), .span_p = start_p4}, false, crate::syntax::parser::adv_f(p_p0)};
        }
    }
    {
        auto&& m22385_3 = w_p1;
        if (m22385_3 == Text::lit("if")) {
            return took_f(parse_if_f(p_p0));
        }
    }
    {
        auto&& m22385_4 = w_p1;
        if (m22385_4 == Text::lit("match")) {
            return took_f(parse_match_f(p_p0));
        }
    }
    {
        auto&& m22385_5 = w_p1;
        if (m22385_5 == Text::lit("rebuild")) {
            auto [scrutinee_p5, p1_p6] = parse_expr_f(crate::syntax::parser::adv_f(p_p0));
            auto [body_p7, p2_p8] = crate::syntax::parser::blocks::parse_block_after_colon_f(p1_p6);
            return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ERebuild{prism_rtl::rc(scrutinee_p5), body_p7})), .span_p = crate::syntax::parser::to_f(start_p4, prism_rtl::deref(body_p7).span_p)}, true, p2_p8};
        }
    }
    {
        auto&& m22385_6 = w_p1;
        if (m22385_6 == Text::lit("for")) {
            return took_f(parse_for_f(p_p0));
        }
    }
    {
        auto&& m22385_7 = w_p1;
        if (m22385_7 == Text::lit("given")) {
            auto [body_p9, q_pa] = crate::syntax::parser::blocks::parse_block_after_colon_f(crate::syntax::parser::adv_f(p_p0));
            return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EGiven{body_p9})), .span_p = crate::syntax::parser::to_f(start_p4, prism_rtl::deref(body_p9).span_p)}, true, q_pa};
        }
    }
    {
        auto&& m22385_8 = w_p1;
        if (m22385_8 == Text::lit("update")) {
            auto [target_pb, p1_pc] = parse_expr_f(crate::syntax::parser::adv_f(p_p0));
            auto [body_pd, p2_pe] = crate::syntax::parser::blocks::parse_block_after_colon_f(p1_pc);
            return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EUpdate{prism_rtl::rc(target_pb), body_pd})), .span_p = crate::syntax::parser::to_f(start_p4, prism_rtl::deref(body_pd).span_p)}, true, p2_pe};
        }
    }
    {
        auto&& m22385_9 = w_p1;
        if (m22385_9 == Text::lit("widget")) {
            auto [body_pf, q_pg] = crate::syntax::parser::blocks::parse_block_after_colon_f(crate::syntax::parser::adv_f(p_p0));
            return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EWidgetBlock{body_pf})), .span_p = crate::syntax::parser::to_f(start_p4, prism_rtl::deref(body_pf).span_p)}, true, q_pg};
        }
    }
    {
        auto&& m22385_10 = w_p1;
        if (m22385_10 == Text::lit("any")) {
            auto [operand_ph, q_pi] = parse_expr_ctx_f(crate::syntax::parser::adv_f(p_p0), commas_p3);
            return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EAny{prism_rtl::rc(operand_ph)})), .span_p = crate::syntax::parser::to_f(start_p4, prism_rtl::deref(operand_ph).span_p)}, true, q_pi};
        }
    }
    {
        auto&& m22385_11 = w_p1;
        if (m22385_11 == Text::lit("not")) {
            auto [e_pj, q_pk] = parse_binary_f(p_p0, Nat(8u), commas_p3);
            return std::tuple{e_pj, true, q_pk};
        }
    }
    {
        if (((w_p1 == Text::lit("output")) || (w_p1 == Text::lit("inline_text"))) || (w_p1 == Text::lit("raw"))) {
            auto p1_pl = crate::syntax::parser::adv_f(p_p0);
            auto&& _m = crate::syntax::parser::kind_f(p1_pl);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KTemplate>(_m)) {
                auto&& t_pm = prism_rtl::as<crate::syntax::lexer::TokKind::KTemplate>(_m).a0;
                auto tspan_pn = crate::syntax::parser::here_f(p1_pl);
                auto [tpl_po, q_pp] = parse_template_f(crate::syntax::parser::adv_f(p1_pl), t_pm, tspan_pn);
                return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETemplate{tpl_po})), .span_p = crate::syntax::parser::to_f(start_p4, tspan_pn)}, false, q_pp};
            }
            {
                return std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::fail_f(p1_pl)};
            }
        }
    }
    {
        auto&& m22385_13 = w_p1;
        if (m22385_13 == Text::lit("then")) {
            return std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, start_p4, Text::lit("`then` belongs to a hold: `$x <- start then step`"))};
        }
    }
    {
        auto&& m22385_14 = w_p1;
        if (m22385_14 == Text::lit("else")) {
            return std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, start_p4, Text::lit("`else` without its `if`"))};
        }
    }
    {
        auto&& m22385_15 = w_p1;
        if (m22385_15 == Text::lit("ignore")) {
            return std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, start_p4, Text::lit("`ignore` stands only inside a pattern or as the left side of a bind"))};
        }
    }
    {
        auto&& m22385_16 = w_p1;
        if (m22385_16 == Text::lit("return")) {
            return std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, start_p4, Text::lit("`return` ends a monad block, as its last statement"))};
        }
    }
    {
        return std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_here_f(p_p0, Text::lit("expected an expression"))};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> KeywordPrimary::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& w_p1 = this->w_p1;
    const auto& sigils_p2 = this->sigils_p2;
    const auto& commas_p3 = this->commas_p3;
    auto start_p4 = crate::syntax::parser::here_f(p_p0);
    return ({
        ({
        auto&& m22385_0 = w_p1;
        (m22385_0 == Text::lit("unit"));
    }) ? ({
        auto&& m22385_0 = w_p1;
        prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EUnit{sigils_p2})), .span_p = start_p4}, false, crate::syntax::parser::adv_f(p_p0)});
    })
        : ({
        auto&& m22385_1 = w_p1;
        (m22385_1 == Text::lit("nil"));
    }) ? ({
        auto&& m22385_1 = w_p1;
        prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ENil{sigils_p2})), .span_p = start_p4}, false, crate::syntax::parser::adv_f(p_p0)});
    })
        : ({
        crate::syntax::lexer::is_bound_word_f(w_p1);
    }) ? prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EBound{w_p1})), .span_p = start_p4}, false, crate::syntax::parser::adv_f(p_p0)})
        : ({
        auto&& m22385_3 = w_p1;
        (m22385_3 == Text::lit("if"));
    }) ? ({
        auto&& m22385_3 = w_p1;
        ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(start_parse_if_f(p_p0x), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_if_f_22647) { return prism_rtl::finished(took_f(parse_if_f_22647)); }));
    });
    })
        : ({
        auto&& m22385_4 = w_p1;
        (m22385_4 == Text::lit("match"));
    }) ? ({
        auto&& m22385_4 = w_p1;
        ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(start_parse_match_f(p_p0x), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_match_f_22681) { return prism_rtl::finished(took_f(parse_match_f_22681)); }));
    });
    })
        : ({
        auto&& m22385_5 = w_p1;
        (m22385_5 == Text::lit("rebuild"));
    }) ? ({
        auto&& m22385_5 = w_p1;
        ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(start_parse_expr_f(crate::syntax::parser::adv_f(p_p0x)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_f_22750) {
        return ({
            auto [scrutinee_p5, p1_p6] = parse_expr_f_22750;
            (crate::prelude::call_then(crate::syntax::parser::blocks::start_parse_block_after_colon_f(p1_p6), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_f_22799) {
            return ({
                auto [body_p7, p2_p8] = parse_block_after_colon_f_22799;
                (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ERebuild{prism_rtl::rc(scrutinee_p5), body_p7})), .span_p = crate::syntax::parser::to_f(start_p4, prism_rtl::deref(body_p7).span_p)}, true, p2_p8}));
            });
        }));
        });
    }));
    });
    })
        : ({
        auto&& m22385_6 = w_p1;
        (m22385_6 == Text::lit("for"));
    }) ? ({
        auto&& m22385_6 = w_p1;
        ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(start_parse_for_f(p_p0x), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_for_f_22936) { return prism_rtl::finished(took_f(parse_for_f_22936)); }));
    });
    })
        : ({
        auto&& m22385_7 = w_p1;
        (m22385_7 == Text::lit("given"));
    }) ? ({
        auto&& m22385_7 = w_p1;
        ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(crate::syntax::parser::blocks::start_parse_block_after_colon_f(crate::syntax::parser::adv_f(p_p0x)), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_f_22995) {
        return ({
            auto [body_p9, q_pa] = parse_block_after_colon_f_22995;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EGiven{body_p9})), .span_p = crate::syntax::parser::to_f(start_p4, prism_rtl::deref(body_p9).span_p)}, true, q_pa}));
        });
    }));
    });
    })
        : ({
        auto&& m22385_8 = w_p1;
        (m22385_8 == Text::lit("update"));
    }) ? ({
        auto&& m22385_8 = w_p1;
        ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(start_parse_expr_f(crate::syntax::parser::adv_f(p_p0x)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_f_23153) {
        return ({
            auto [target_pb, p1_pc] = parse_expr_f_23153;
            (crate::prelude::call_then(crate::syntax::parser::blocks::start_parse_block_after_colon_f(p1_pc), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_f_23202) {
            return ({
                auto [body_pd, p2_pe] = parse_block_after_colon_f_23202;
                (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EUpdate{prism_rtl::rc(target_pb), body_pd})), .span_p = crate::syntax::parser::to_f(start_p4, prism_rtl::deref(body_pd).span_p)}, true, p2_pe}));
            });
        }));
        });
    }));
    });
    })
        : ({
        auto&& m22385_9 = w_p1;
        (m22385_9 == Text::lit("widget"));
    }) ? ({
        auto&& m22385_9 = w_p1;
        ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(crate::syntax::parser::blocks::start_parse_block_after_colon_f(crate::syntax::parser::adv_f(p_p0x)), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_f_23415) {
        return ({
            auto [body_pf, q_pg] = parse_block_after_colon_f_23415;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EWidgetBlock{body_pf})), .span_p = crate::syntax::parser::to_f(start_p4, prism_rtl::deref(body_pf).span_p)}, true, q_pg}));
        });
    }));
    });
    })
        : ({
        auto&& m22385_10 = w_p1;
        (m22385_10 == Text::lit("any"));
    }) ? ({
        auto&& m22385_10 = w_p1;
        ({
        auto commas_p3x = prism_rtl::deref(commas_p3);
        auto p_p0x = p_p0;
        (crate::prelude::call_then(start_parse_expr_ctx_f(crate::syntax::parser::adv_f(p_p0x), std::move(commas_p3x)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_ctx_f_23576) {
        return ({
            auto [operand_ph, q_pi] = parse_expr_ctx_f_23576;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EAny{prism_rtl::rc(operand_ph)})), .span_p = crate::syntax::parser::to_f(start_p4, prism_rtl::deref(operand_ph).span_p)}, true, q_pi}));
        });
    }));
    });
    })
        : ({
        auto&& m22385_11 = w_p1;
        (m22385_11 == Text::lit("not"));
    }) ? ({
        auto&& m22385_11 = w_p1;
        ({
        auto commas_p3x = prism_rtl::deref(commas_p3);
        auto p_p0x = p_p0;
        (crate::prelude::call_then(start_parse_binary_f(p_p0x, Nat(8u), std::move(commas_p3x)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_binary_f_23729) {
        return ({
            auto [e_pj, q_pk] = parse_binary_f_23729;
            (prism_rtl::finished(std::tuple{e_pj, true, q_pk}));
        });
    }));
    });
    })
        : ({
        (((w_p1 == Text::lit("output")) || (w_p1 == Text::lit("inline_text"))) || (w_p1 == Text::lit("raw")));
    }) ? ({
        auto p1_pl = crate::syntax::parser::adv_f(p_p0);
        ({
        auto&& _m = crate::syntax::parser::kind_f(p1_pl);
        prism_rtl::is<crate::syntax::lexer::TokKind::KTemplate>(_m) ? ({
        auto&& t_pm = prism_rtl::as<crate::syntax::lexer::TokKind::KTemplate>(_m).a0;
        ({
        auto tspan_pn = crate::syntax::parser::here_f(p1_pl);
        (crate::prelude::call_then(start_parse_template_f(crate::syntax::parser::adv_f(p1_pl), t_pm, tspan_pn), [=](std::tuple<crate::syntax::Template, crate::syntax::parser::Ps> parse_template_f_24089) {
        return ({
            auto [tpl_po, q_pp] = parse_template_f_24089;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETemplate{tpl_po})), .span_p = crate::syntax::parser::to_f(start_p4, tspan_pn)}, false, q_pp}));
        });
    }));
    });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::fail_f(p1_pl)});
    });
    })
        : ({
        auto&& m22385_13 = w_p1;
        (m22385_13 == Text::lit("then"));
    }) ? ({
        auto&& m22385_13 = w_p1;
        prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, start_p4, Text::lit("`then` belongs to a hold: `$x <- start then step`"))});
    })
        : ({
        auto&& m22385_14 = w_p1;
        (m22385_14 == Text::lit("else"));
    }) ? ({
        auto&& m22385_14 = w_p1;
        prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, start_p4, Text::lit("`else` without its `if`"))});
    })
        : ({
        auto&& m22385_15 = w_p1;
        (m22385_15 == Text::lit("ignore"));
    }) ? ({
        auto&& m22385_15 = w_p1;
        prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, start_p4, Text::lit("`ignore` stands only inside a pattern or as the left side of a bind"))});
    })
        : ({
        auto&& m22385_16 = w_p1;
        (m22385_16 == Text::lit("return"));
    }) ? ({
        auto&& m22385_16 = w_p1;
        prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, start_p4, Text::lit("`return` ends a monad block, as its last statement"))});
    })
        : prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_here_f(p_p0, Text::lit("expected an expression"))});
    });
}


/// `Start KeywordPrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_keyword_primary_f(crate::syntax::parser::Ps p_p0, Text w_p1, Text sigils_p2, bool commas_p3) {
    return prism_rtl::make_rc<KeywordPrimary>(p_p0, w_p1, sigils_p2, commas_p3);
}


/// Took: fn ((Expr, Ps)) -> ((Expr, Bool, Ps))
std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> took_f(const std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>& arg0) {
    {
        auto&& e_p0 = std::get<0>(arg0);
        auto&& p_p1 = std::get<1>(arg0);
        return std::tuple{e_p0, true, p_p1};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ParseLiteral: unbounded fn Ps -> ((Literal, Ps))
std::tuple<crate::syntax::Literal, crate::syntax::parser::Ps> parse_literal_f(const crate::syntax::parser::Ps& p_p0) {
    auto span_p1 = crate::syntax::parser::here_f(p_p0);
    auto p1_p2 = crate::syntax::parser::adv_f(p_p0);
    auto&& _m = crate::syntax::parser::kind_f(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m)) {
        auto&& s_p3 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a0;
        auto&& t_p4 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a1;
        return std::tuple{crate::syntax::Literal{.marks_p = s_p3, .kind_p = crate::syntax::LitKind(crate::syntax::LitKind::LInt{t_p4}), .span_p = span_p1}, p1_p2};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(_m)) {
        auto&& s_p5 = prism_rtl::as<crate::syntax::lexer::TokKind::KFloat>(_m).a0;
        auto&& t_p6 = prism_rtl::as<crate::syntax::lexer::TokKind::KFloat>(_m).a1;
        return std::tuple{crate::syntax::Literal{.marks_p = s_p5, .kind_p = crate::syntax::LitKind(crate::syntax::LitKind::LFloat{t_p6}), .span_p = span_p1}, p1_p2};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(_m)) {
        auto&& s_p7 = prism_rtl::as<crate::syntax::lexer::TokKind::KDuration>(_m).a0;
        auto&& n_p8 = prism_rtl::as<crate::syntax::lexer::TokKind::KDuration>(_m).a1;
        auto&& u_p9 = prism_rtl::as<crate::syntax::lexer::TokKind::KDuration>(_m).a2;
        return std::tuple{crate::syntax::Literal{.marks_p = s_p7, .kind_p = crate::syntax::LitKind(crate::syntax::LitKind::LDuration{n_p8, u_p9}), .span_p = span_p1}, p1_p2};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(_m)) {
        auto&& s_pa = prism_rtl::as<crate::syntax::lexer::TokKind::KChar>(_m).a0;
        auto&& c_pb = prism_rtl::as<crate::syntax::lexer::TokKind::KChar>(_m).a1;
        return std::tuple{crate::syntax::Literal{.marks_p = s_pa, .kind_p = crate::syntax::LitKind(crate::syntax::LitKind::LChar{c_pb}), .span_p = span_p1}, p1_p2};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KRegex>(_m)) {
        auto&& s_pc = prism_rtl::as<crate::syntax::lexer::TokKind::KRegex>(_m).a0;
        auto&& r_pd = prism_rtl::as<crate::syntax::lexer::TokKind::KRegex>(_m).a1;
        return std::tuple{crate::syntax::Literal{.marks_p = s_pc, .kind_p = crate::syntax::LitKind(crate::syntax::LitKind::LRegex{r_pd}), .span_p = span_p1}, p1_p2};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m)) {
        auto&& s_pe = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a0;
        auto&& segs_pf = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a1;
        auto [out_pj, q_pk] = crate::prelude::run_to_end(crate::prelude::fold_job(segs_pf, std::tuple{Array<crate::syntax::TextSeg>{}, p1_p2}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>>(std::tuple<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>, crate::syntax::lexer::TextSegTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>, crate::syntax::lexer::TextSegTok> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto [acc_pg, pp_ph] = p0;
                    auto seg_pi = p1;
                    (prism_rtl::more(prism_rtl::rc(TextSegment(acc_pg, pp_ph, seg_pi))));
                });
            }));
        }))));
        return std::tuple{crate::syntax::Literal{.marks_p = s_pe, .kind_p = crate::syntax::LitKind(crate::syntax::LitKind::LText{out_pj}), .span_p = span_p1}, q_pk};
    }
    {
        return std::tuple{crate::syntax::Literal{.marks_p = Text::lit(""), .kind_p = crate::syntax::LitKind(crate::syntax::LitKind::LInt{Text::lit("")}), .span_p = span_p1}, crate::syntax::parser::error_at_f(p1_p2, span_p1, Text::lit("expected a literal"))};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Literal, crate::syntax::parser::Ps>> ParseLiteral::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto span_p1 = crate::syntax::parser::here_f(p_p0);
    auto p1_p2 = crate::syntax::parser::adv_f(p_p0);
    return ({
        auto&& _m = crate::syntax::parser::kind_f(p_p0);
        prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m) ? ({
        auto&& s_p3 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a0;
        auto&& t_p4 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a1;
        prism_rtl::finished(std::tuple{crate::syntax::Literal{.marks_p = s_p3, .kind_p = crate::syntax::LitKind(crate::syntax::LitKind::LInt{t_p4}), .span_p = span_p1}, p1_p2});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(_m) ? ({
        auto&& s_p5 = prism_rtl::as<crate::syntax::lexer::TokKind::KFloat>(_m).a0;
        auto&& t_p6 = prism_rtl::as<crate::syntax::lexer::TokKind::KFloat>(_m).a1;
        prism_rtl::finished(std::tuple{crate::syntax::Literal{.marks_p = s_p5, .kind_p = crate::syntax::LitKind(crate::syntax::LitKind::LFloat{t_p6}), .span_p = span_p1}, p1_p2});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(_m) ? ({
        auto&& s_p7 = prism_rtl::as<crate::syntax::lexer::TokKind::KDuration>(_m).a0;
        auto&& n_p8 = prism_rtl::as<crate::syntax::lexer::TokKind::KDuration>(_m).a1;
        auto&& u_p9 = prism_rtl::as<crate::syntax::lexer::TokKind::KDuration>(_m).a2;
        prism_rtl::finished(std::tuple{crate::syntax::Literal{.marks_p = s_p7, .kind_p = crate::syntax::LitKind(crate::syntax::LitKind::LDuration{n_p8, u_p9}), .span_p = span_p1}, p1_p2});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(_m) ? ({
        auto&& s_pa = prism_rtl::as<crate::syntax::lexer::TokKind::KChar>(_m).a0;
        auto&& c_pb = prism_rtl::as<crate::syntax::lexer::TokKind::KChar>(_m).a1;
        prism_rtl::finished(std::tuple{crate::syntax::Literal{.marks_p = s_pa, .kind_p = crate::syntax::LitKind(crate::syntax::LitKind::LChar{c_pb}), .span_p = span_p1}, p1_p2});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KRegex>(_m) ? ({
        auto&& s_pc = prism_rtl::as<crate::syntax::lexer::TokKind::KRegex>(_m).a0;
        auto&& r_pd = prism_rtl::as<crate::syntax::lexer::TokKind::KRegex>(_m).a1;
        prism_rtl::finished(std::tuple{crate::syntax::Literal{.marks_p = s_pc, .kind_p = crate::syntax::LitKind(crate::syntax::LitKind::LRegex{r_pd}), .span_p = span_p1}, p1_p2});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m) ? ({
        auto&& s_pe = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a0;
        auto&& segs_pf = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a1;
        crate::prelude::call_value(crate::prelude::fold_job(segs_pf, std::tuple{Array<crate::syntax::TextSeg>{}, p1_p2}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>>(std::tuple<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>, crate::syntax::lexer::TextSegTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>, crate::syntax::lexer::TextSegTok> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [acc_pg, pp_ph] = p0;
                auto seg_pi = p1;
                (prism_rtl::more(prism_rtl::rc(TextSegment(acc_pg, pp_ph, seg_pi))));
            });
        }));
    }))), [=](std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps> fold_25477) {
        return ({
            auto [out_pj, q_pk] = fold_25477;
            (prism_rtl::finished(std::tuple{crate::syntax::Literal{.marks_p = s_pe, .kind_p = crate::syntax::LitKind(crate::syntax::LitKind::LText{out_pj}), .span_p = span_p1}, q_pk}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::Literal{.marks_p = Text::lit(""), .kind_p = crate::syntax::LitKind(crate::syntax::LitKind::LInt{Text::lit("")}), .span_p = span_p1}, crate::syntax::parser::error_at_f(p1_p2, span_p1, Text::lit("expected a literal"))});
    });
}


/// `Start ParseLiteral, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Literal, crate::syntax::parser::Ps>> start_parse_literal_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseLiteral>(p_p0);
}


/// TextSegment: unbounded fn [TextSeg], Ps, TextSegTok -> (([TextSeg], Ps))
std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps> text_segment_f(const Array<crate::syntax::TextSeg>& acc_p0, const crate::syntax::parser::Ps& p_p1, const crate::syntax::lexer::TextSegTok& text_seg_tok2) {
    if (prism_rtl::is<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok2)) {
        auto&& s_p2 = prism_rtl::as<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok2).a0;
        return std::tuple{crate::prelude::push(acc_p0, crate::syntax::TextSeg(crate::syntax::TextSeg::SegPlain{s_p2})), p_p1};
    }
    if (prism_rtl::is<crate::syntax::lexer::TextSegTok::TsPlaceholder>(text_seg_tok2)) {
        auto&& toks_p5 = prism_rtl::as<crate::syntax::lexer::TextSegTok::TsPlaceholder>(text_seg_tok2).a0;
        auto&& span_p6 = prism_rtl::as<crate::syntax::lexer::TextSegTok::TsPlaceholder>(text_seg_tok2).a1;
        auto [e_p7, q_p8] = parse_nested_f(p_p1, toks_p5, span_p6);
        return std::tuple{crate::prelude::push(acc_p0, crate::syntax::TextSeg(crate::syntax::TextSeg::SegPlaceholder{e_p7})), q_p8};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>> TextSegment::cycle() const {
    const auto& acc_p0 = this->acc_p0;
    const auto& p_p1 = this->p_p1;
    const auto& text_seg_tok2 = this->text_seg_tok2;
    return ({
        prism_rtl::is<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok2) ? ({
        auto&& s_p2 = prism_rtl::as<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok2).a0;
        prism_rtl::finished(std::tuple{crate::prelude::push(acc_p0, crate::syntax::TextSeg(crate::syntax::TextSeg::SegPlain{s_p2})), p_p1});
    })
        : prism_rtl::is<crate::syntax::lexer::TextSegTok::TsPlaceholder>(text_seg_tok2) ? ({
        auto&& toks_p5 = prism_rtl::as<crate::syntax::lexer::TextSegTok::TsPlaceholder>(text_seg_tok2).a0;
        auto&& span_p6 = prism_rtl::as<crate::syntax::lexer::TextSegTok::TsPlaceholder>(text_seg_tok2).a1;
        ({
        auto acc_p0x = acc_p0;
        auto p_p1x = p_p1;
        auto span_p6x = span_p6;
        auto toks_p5x = toks_p5;
        (crate::prelude::call_then(start_parse_nested_f(p_p1x, toks_p5x, span_p6x), [=, acc_p0x = std::move(acc_p0x)](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_nested_f_25935) {
        return ({
            auto [e_p7, q_p8] = parse_nested_f_25935;
            (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p0x, crate::syntax::TextSeg(crate::syntax::TextSeg::SegPlaceholder{e_p7})), q_p8}));
        });
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TextSegment, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>> start_text_segment_f(Array<crate::syntax::TextSeg> acc_p0, crate::syntax::parser::Ps p_p1, crate::syntax::lexer::TextSegTok text_seg_tok2) {
    return prism_rtl::make_rc<TextSegment>(acc_p0, p_p1, text_seg_tok2);
}


/// ParseNested: unbounded fn Ps, [Tok], Range -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_nested_f(const crate::syntax::parser::Ps& p_p0, const Array<crate::syntax::lexer::Tok>& toks_p1, const crate::syntax::Range& span_p2) {
    auto sub_p3 = crate::syntax::parser::with_step_mode_f(crate::syntax::parser::sub_f(p_p0, toks_p1, crate::syntax::parser::at_end_f(span_p2)), false);
    auto [e_p7, s1_p8] = parse_rhs_expr_f(sub_p3);
    auto s2_p4 = (!prism_rtl::deref(s1_p8).bad_p) && (!crate::syntax::parser::at_eof_f(s1_p8))
        ? crate::syntax::parser::note_error_f(s1_p8, crate::syntax::parser::here_f(s1_p8), prism_rtl::cat("expected the end of the placeholder, found ", crate::syntax::parser::describe_f(crate::syntax::parser::kind_f(s1_p8))))
        : s1_p8;
    auto s3_p5 = prism_rtl::deref(s2_p4).bad_p && (crate::prelude::len(prism_rtl::deref(s2_p4).diags_p) == Nat(0u))
        ? crate::syntax::parser::note_error_f(crate::syntax::parser::unbad_f(s2_p4), span_p2, Text::lit("expected an expression in the placeholder"))
        : s2_p4;
    auto q_p6 = crate::syntax::parser::absorb_f(p_p0, s3_p5);
    return prism_rtl::deref(s1_p8).bad_p
        ? std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = span_p2}, q_p6}
        : std::tuple{e_p7, q_p6};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseNested::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& toks_p1 = this->toks_p1;
    const auto& span_p2 = this->span_p2;
    auto p_p0x = p_p0;
    auto span_p2x = span_p2;
    auto toks_p1x = toks_p1;
    return crate::prelude::call_then(crate::syntax::parser::start_sub_f(p_p0x, toks_p1x, crate::syntax::parser::at_end_f(span_p2x)), [=](crate::syntax::parser::Ps sub_f_26258) {
        return ({
            auto sub_p3 = crate::syntax::parser::with_step_mode_f(sub_f_26258, false);
            (crate::prelude::call_then(start_parse_rhs_expr_f(sub_p3), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_f_26312) {
            return ({
                auto [e_p7, s1_p8] = parse_rhs_expr_f_26312;
                auto s2_p4 = (!prism_rtl::deref(s1_p8).bad_p) && (!crate::syntax::parser::at_eof_f(s1_p8))
                    ? crate::syntax::parser::note_error_f(s1_p8, crate::syntax::parser::here_f(s1_p8), prism_rtl::cat("expected the end of the placeholder, found ", crate::syntax::parser::describe_f(crate::syntax::parser::kind_f(s1_p8))))
                    : s1_p8;
                auto s3_p5 = prism_rtl::deref(s2_p4).bad_p && (crate::prelude::len(prism_rtl::deref(s2_p4).diags_p) == Nat(0u))
                    ? crate::syntax::parser::note_error_f(crate::syntax::parser::unbad_f(s2_p4), span_p2x, Text::lit("expected an expression in the placeholder"))
                    : s2_p4;
                auto q_p6 = crate::syntax::parser::absorb_f(p_p0x, s3_p5);
                (prism_rtl::deref(s1_p8).bad_p
                ? prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = span_p2x}, q_p6})
                : prism_rtl::finished(std::tuple{e_p7, q_p6}));
            });
        }));
        });
    });
}


/// `Start ParseNested, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_nested_f(crate::syntax::parser::Ps p_p0, Array<crate::syntax::lexer::Tok> toks_p1, crate::syntax::Range span_p2) {
    return prism_rtl::make_rc<ParseNested>(p_p0, toks_p1, span_p2);
}


/// ParseTemplate: unbounded fn Ps, TemplateTok, Range -> ((Template, Ps))
std::tuple<crate::syntax::Template, crate::syntax::parser::Ps> parse_template_f(const crate::syntax::parser::Ps& p0_p0, const crate::syntax::lexer::TemplateTok& t_p1, const crate::syntax::Range& span_p2) {
    auto p1_p3 = (t_p1.delims_p == Text::lit("single")) && (t_p1.keyword_p != Text::lit("Raw"))
        ? crate::syntax::parser::out_of_scope_f(p0_p0, span_p2, Text::lit("the template notation"), prism_rtl::cat("a `<", t_p1.lang_p, ">` template is the template notation for an element language, out of this compiler (code templates only)"))
        : p0_p0;
    auto p2_p4 = t_p1.keyword_p == Text::lit("File")
        ? crate::syntax::parser::out_of_scope_f(p1_p3, span_p2, Text::lit("the template notation"), Text::lit("a file whose first token is a language tag is a template file, out of this compiler (code templates only)"))
        : p1_p3;
    auto [parts_p5, p3_p6] = template_parts_f(p2_p4, t_p1.parts_p);
    return std::tuple{crate::syntax::Template{.keyword_p = t_p1.keyword_p, .lang_p = t_p1.lang_p, .delims_p = t_p1.delims_p, .parts_p = parts_p5, .span_p = span_p2}, p3_p6};
}


prism_rtl::Turn<std::tuple<crate::syntax::Template, crate::syntax::parser::Ps>> ParseTemplate::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    const auto& t_p1 = this->t_p1;
    const auto& span_p2 = this->span_p2;
    auto p1_p3 = (prism_rtl::deref(t_p1).delims_p == Text::lit("single")) && (prism_rtl::deref(t_p1).keyword_p != Text::lit("Raw"))
        ? crate::syntax::parser::out_of_scope_f(p0_p0, span_p2, Text::lit("the template notation"), prism_rtl::cat("a `<", prism_rtl::deref(t_p1).lang_p, ">` template is the template notation for an element language, out of this compiler (code templates only)"))
        : p0_p0;
    auto p2_p4 = prism_rtl::deref(t_p1).keyword_p == Text::lit("File")
        ? crate::syntax::parser::out_of_scope_f(p1_p3, span_p2, Text::lit("the template notation"), Text::lit("a file whose first token is a language tag is a template file, out of this compiler (code templates only)"))
        : p1_p3;
    auto span_p2x = span_p2;
    auto t_p1x = t_p1;
    return crate::prelude::call_then(start_template_parts_f(p2_p4, prism_rtl::deref(t_p1x).parts_p), [=](std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps> template_parts_f_27307) {
        return ({
            auto [parts_p5, p3_p6] = template_parts_f_27307;
            (prism_rtl::finished(std::tuple{crate::syntax::Template{.keyword_p = prism_rtl::deref(t_p1x).keyword_p, .lang_p = prism_rtl::deref(t_p1x).lang_p, .delims_p = prism_rtl::deref(t_p1x).delims_p, .parts_p = parts_p5, .span_p = span_p2x}, p3_p6}));
        });
    });
}


/// `Start ParseTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Template, crate::syntax::parser::Ps>> start_parse_template_f(crate::syntax::parser::Ps p0_p0, crate::syntax::lexer::TemplateTok t_p1, crate::syntax::Range span_p2) {
    return prism_rtl::make_rc<ParseTemplate>(p0_p0, t_p1, span_p2);
}


/// TemplateParts: unbounded fn Ps, [TPartTok] -> (([TemplatePart], Ps))
std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps> template_parts_f(const crate::syntax::parser::Ps& p_p0, const Array<crate::syntax::lexer::TPartTok>& parts_p1) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(parts_p1, std::tuple{Array<crate::syntax::TemplatePart>{}, p_p0}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>>(std::tuple<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>, crate::syntax::lexer::TPartTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>, crate::syntax::lexer::TPartTok> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [acc_p2, q_p3] = p0;
                auto part_p4 = p1;
                (prism_rtl::more(prism_rtl::rc(TemplatePartOf(acc_p2, q_p3, part_p4))));
            });
        }));
    }))));
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>> TemplateParts::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& parts_p1 = this->parts_p1;
    return crate::prelude::fold_job(parts_p1, std::tuple{Array<crate::syntax::TemplatePart>{}, p_p0}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>>(std::tuple<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>, crate::syntax::lexer::TPartTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>, crate::syntax::lexer::TPartTok> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [acc_p2, q_p3] = p0;
                auto part_p4 = p1;
                (prism_rtl::more(prism_rtl::rc(TemplatePartOf(acc_p2, q_p3, part_p4))));
            });
        }));
    })))->cycle();
}


/// `Start TemplateParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>> start_template_parts_f(crate::syntax::parser::Ps p_p0, Array<crate::syntax::lexer::TPartTok> parts_p1) {
    return prism_rtl::make_rc<TemplateParts>(p_p0, parts_p1);
}


/// TemplatePartOf: unbounded fn [TemplatePart], Ps, TPartTok -> (([TemplatePart], Ps))
std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps> template_part_of_f(const Array<crate::syntax::TemplatePart>& acc_p0, const crate::syntax::parser::Ps& p_p1, const crate::syntax::lexer::TPartTok& tpart_tok2) {
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(tpart_tok2)) {
        auto&& s_p2 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(tpart_tok2).a0;
        return std::tuple{crate::prelude::push(acc_p0, crate::syntax::TemplatePart(crate::syntax::TemplatePart::TpText{s_p2})), p_p1};
    }
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok2)) {
        auto&& toks_p5 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok2).a0;
        auto&& col_o6 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok2).a1;
        auto&& span_p7 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok2).a2;
        auto [e_p8, q_p9] = parse_nested_f(p_p1, toks_p5, span_p7);
        return std::tuple{crate::prelude::push(acc_p0, crate::syntax::TemplatePart(crate::syntax::TemplatePart::TpPlaceholder{e_p8, col_o6})), q_p9};
    }
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptBlock>(tpart_tok2)) {
        auto&& toks_pc = prism_rtl::as<crate::syntax::lexer::TPartTok::TptBlock>(tpart_tok2).a0;
        auto&& span_pd = prism_rtl::as<crate::syntax::lexer::TPartTok::TptBlock>(tpart_tok2).a1;
        auto sub_pe = crate::syntax::parser::sub_f(p_p1, toks_pc, crate::syntax::parser::at_end_f(span_pd));
        auto [block_pf, s1_pg] = crate::syntax::parser::blocks::parse_block_until_eof_f(sub_pe, span_pd);
        return std::tuple{crate::prelude::push(acc_p0, crate::syntax::TemplatePart(crate::syntax::TemplatePart::TpBlock{block_pf})), crate::syntax::parser::absorb_f(p_p1, s1_pg)};
    }
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2)) {
        auto&& name_pj = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2).a0;
        auto&& attrs_pk = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2).a1;
        auto&& body_ol = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2).a2;
        auto&& span_pm = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2).a3;
        auto sname_pn = crate::syntax::SName{.sigils_p = prism_rtl::deref(name_pj).sigils_p, .path_p = prism_rtl::deref(name_pj).path_p, .span_p = span_pm};
        auto [args_pr, p1_ps] = crate::prelude::run_to_end(crate::prelude::fold_job(attrs_pk, std::tuple{Array<crate::syntax::Arg>{}, p_p1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>>(std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>, crate::syntax::lexer::AttrTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>, crate::syntax::lexer::AttrTok> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto [done_po, q_pp] = p0;
                    auto a_pq = p1;
                    (prism_rtl::more(prism_rtl::rc(AttrArg(done_po, q_pp, a_pq))));
                });
            }));
        }))));
        auto [inner_o10, p2_p11] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<std::optional<Array<crate::syntax::TemplatePart>>, crate::syntax::parser::Ps>> _v;
            if (prism_rtl::is_some(body_ol)) {
                auto&& b_pt = prism_rtl::some_of(body_ol);
                _v.set(({
                    auto [ps_pu, q_pv] = template_parts_f(p1_ps, b_pt);
                    std::tuple{std::optional(ps_pu), q_pv};
                }));
                goto _done;
            }
            if (prism_rtl::is_none(body_ol)) {
                _v.set(std::tuple{std::optional<Array<crate::syntax::TemplatePart>>{}, p1_ps});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return std::tuple{crate::prelude::push(acc_p0, crate::syntax::TemplatePart(crate::syntax::TemplatePart::TpCall{sname_pn, args_pr, inner_o10, span_pm})), p2_p11};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>> TemplatePartOf::cycle() const {
    const auto& acc_p0 = this->acc_p0;
    const auto& p_p1 = this->p_p1;
    const auto& tpart_tok2 = this->tpart_tok2;
    return ({
        prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(tpart_tok2) ? ({
        auto&& s_p2 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(tpart_tok2).a0;
        prism_rtl::finished(std::tuple{crate::prelude::push(acc_p0, crate::syntax::TemplatePart(crate::syntax::TemplatePart::TpText{s_p2})), p_p1});
    })
        : prism_rtl::is<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok2) ? ({
        auto&& toks_p5 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok2).a0;
        auto&& col_o6 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok2).a1;
        auto&& span_p7 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok2).a2;
        ({
        auto col_o6x = col_o6;
        auto acc_p0x = acc_p0;
        auto p_p1x = p_p1;
        auto span_p7x = span_p7;
        auto toks_p5x = toks_p5;
        (crate::prelude::call_then(start_parse_nested_f(p_p1x, toks_p5x, span_p7x), [=, col_o6x = std::move(col_o6x), acc_p0x = std::move(acc_p0x)](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_nested_f_27833) {
        return ({
            auto [e_p8, q_p9] = parse_nested_f_27833;
            (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p0x, crate::syntax::TemplatePart(crate::syntax::TemplatePart::TpPlaceholder{e_p8, col_o6x})), q_p9}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TPartTok::TptBlock>(tpart_tok2) ? ({
        auto&& toks_pc = prism_rtl::as<crate::syntax::lexer::TPartTok::TptBlock>(tpart_tok2).a0;
        auto&& span_pd = prism_rtl::as<crate::syntax::lexer::TPartTok::TptBlock>(tpart_tok2).a1;
        ({
        auto acc_p0x = acc_p0;
        auto p_p1x = p_p1;
        auto span_pdx = span_pd;
        auto toks_pcx = toks_pc;
        (crate::prelude::call_then(crate::syntax::parser::start_sub_f(p_p1x, toks_pcx, crate::syntax::parser::at_end_f(span_pdx)), [=, acc_p0x = std::move(acc_p0x)](crate::syntax::parser::Ps sub_f_27969) {
        return ({
            auto sub_pe = sub_f_27969;
            (crate::prelude::call_then(crate::syntax::parser::blocks::start_parse_block_until_eof_f(sub_pe, span_pdx), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_until_eof_f_28019) {
            return ({
                auto [block_pf, s1_pg] = parse_block_until_eof_f_28019;
                (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p0x, crate::syntax::TemplatePart(crate::syntax::TemplatePart::TpBlock{block_pf})), crate::syntax::parser::absorb_f(p_p1x, s1_pg)}));
            });
        }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2) ? ({
        auto&& name_pj = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2).a0;
        auto&& attrs_pk = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2).a1;
        auto&& body_ol = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2).a2;
        auto&& span_pm = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2).a3;
        ({
        auto sname_pn = crate::syntax::SName{.sigils_p = prism_rtl::deref(name_pj).sigils_p, .path_p = prism_rtl::deref(name_pj).path_p, .span_p = span_pm};
        auto body_olx = body_ol;
        auto acc_p0x = acc_p0;
        auto attrs_pkx = attrs_pk;
        auto p_p1x = p_p1;
        auto span_pmx = span_pm;
        (crate::prelude::call_value(crate::prelude::fold_job(attrs_pkx, std::tuple{Array<crate::syntax::Arg>{}, p_p1x}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>>(std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>, crate::syntax::lexer::AttrTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>, crate::syntax::lexer::AttrTok> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [done_po, q_pp] = p0;
                auto a_pq = p1;
                (prism_rtl::more(prism_rtl::rc(AttrArg(done_po, q_pp, a_pq))));
            });
        }));
    }))), [=, sname_pn = std::move(sname_pn), body_olx = std::move(body_olx), acc_p0x = std::move(acc_p0x), span_pmx = std::move(span_pmx)](std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps> fold_28254) {
        return ({
            auto [args_pr, p1_ps] = fold_28254;
            auto [inner_o10, p2_p11] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<std::optional<Array<crate::syntax::TemplatePart>>, crate::syntax::parser::Ps>> _v;
                if (prism_rtl::is_some(body_olx)) {
                    auto&& b_pt = prism_rtl::some_of(body_olx);
                    _v.set(({
                        auto [ps_pu, q_pv] = template_parts_f(p1_ps, b_pt);
                        std::tuple{std::optional(ps_pu), q_pv};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(body_olx)) {
                    _v.set(std::tuple{std::optional<Array<crate::syntax::TemplatePart>>{}, p1_ps});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p0x, crate::syntax::TemplatePart(crate::syntax::TemplatePart::TpCall{sname_pn, args_pr, inner_o10, span_pmx})), p2_p11}));
        });
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplatePartOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>> start_template_part_of_f(Array<crate::syntax::TemplatePart> acc_p0, crate::syntax::parser::Ps p_p1, crate::syntax::lexer::TPartTok tpart_tok2) {
    return prism_rtl::make_rc<TemplatePartOf>(acc_p0, p_p1, tpart_tok2);
}


/// AttrArg: unbounded fn [Arg], Ps, AttrTok -> (([Arg], Ps))
std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps> attr_arg_f(const Array<crate::syntax::Arg>& done_p0, const crate::syntax::parser::Ps& p_p1, const crate::syntax::lexer::AttrTok& a_p2) {
    auto [value_p3, q_p4] = parse_nested_f(p_p1, a_p2.tokens_p, a_p2.span_p);
    return std::tuple{crate::prelude::push(done_p0, crate::syntax::Arg{.name_o = std::optional(crate::syntax::Ident{.name_p = a_p2.name_p, .span_p = a_p2.span_p}), .value_p = value_p3, .span_p = a_p2.span_p}), q_p4};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> AttrArg::cycle() const {
    const auto& done_p0 = this->done_p0;
    const auto& p_p1 = this->p_p1;
    const auto& a_p2 = this->a_p2;
    auto a_p2x = a_p2;
    auto done_p0x = done_p0;
    auto p_p1x = p_p1;
    return crate::prelude::call_then(start_parse_nested_f(p_p1x, prism_rtl::deref(a_p2x).tokens_p, prism_rtl::deref(a_p2x).span_p), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_nested_f_28628) {
        return ({
            auto [value_p3, q_p4] = parse_nested_f_28628;
            (prism_rtl::finished(std::tuple{crate::prelude::push(done_p0x, crate::syntax::Arg{.name_o = std::optional(crate::syntax::Ident{.name_p = prism_rtl::deref(a_p2x).name_p, .span_p = prism_rtl::deref(a_p2x).span_p}), .value_p = value_p3, .span_p = prism_rtl::deref(a_p2x).span_p}), q_p4}));
        });
    });
}


/// `Start AttrArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> start_attr_arg_f(Array<crate::syntax::Arg> done_p0, crate::syntax::parser::Ps p_p1, crate::syntax::lexer::AttrTok a_p2) {
    return prism_rtl::make_rc<AttrArg>(done_p0, p_p1, a_p2);
}


/// ParseLambda: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_lambda_f(const crate::syntax::parser::Ps& p0_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p0_p0);
    auto p_p2 = crate::syntax::parser::adv_f(p0_p0);
    auto [params_o3, p1_p4] = crate::syntax::parser::kind_f(p_p2) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{true})
        ? lambda_params_f(crate::syntax::parser::adv_f(p_p2))
        : std::tuple{std::optional<Array<crate::syntax::Pattern_>>{}, p_p2};
    return crate::syntax::parser::at_open_l_f(p1_p4)
        ? ({
        auto [block_p5, q_p6] = crate::syntax::parser::blocks::parse_indented_block_f(p1_p4);
        std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELambda{params_o3, prism_rtl::rc(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbBlock{block_p5}))})), .span_p = crate::syntax::parser::to_f(start_p1, prism_rtl::deref(block_p5).span_p)}, q_p6};
    })
        : ({
        auto [body_p7, q_p8] = parse_expr_f(p1_p4);
        std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELambda{params_o3, prism_rtl::rc(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(body_p7)}))})), .span_p = crate::syntax::parser::to_f(start_p1, prism_rtl::deref(body_p7).span_p)}, q_p8};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseLambda::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    auto start_p1 = crate::syntax::parser::here_f(p0_p0);
    auto p_p2 = crate::syntax::parser::adv_f(p0_p0);
    auto [params_o3, p1_p4] = crate::syntax::parser::kind_f(p_p2) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{true})
        ? lambda_params_f(crate::syntax::parser::adv_f(p_p2))
        : std::tuple{std::optional<Array<crate::syntax::Pattern_>>{}, p_p2};
    return crate::syntax::parser::at_open_l_f(p1_p4)
        ? crate::prelude::call_then(crate::syntax::parser::blocks::start_parse_indented_block_f(p1_p4), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_indented_block_f_29257) {
        return ({
            auto [block_p5, q_p6] = parse_indented_block_f_29257;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELambda{params_o3, prism_rtl::rc(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbBlock{block_p5}))})), .span_p = crate::syntax::parser::to_f(start_p1, prism_rtl::deref(block_p5).span_p)}, q_p6}));
        });
    })
        : crate::prelude::call_then(start_parse_expr_f(p1_p4), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_f_29405) {
        return ({
            auto [body_p7, q_p8] = parse_expr_f_29405;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELambda{params_o3, prism_rtl::rc(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(body_p7)}))})), .span_p = crate::syntax::parser::to_f(start_p1, prism_rtl::deref(body_p7).span_p)}, q_p8}));
        });
    });
}


/// `Start ParseLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_lambda_f(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseLambda>(p0_p0);
}


/// LambdaParams: unbounded fn Ps -> ((?[Pattern], Ps))
std::tuple<std::optional<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps> lambda_params_f(const crate::syntax::parser::Ps& p_p0) {
    auto [ps_p2, p1_p3] = crate::syntax::parser::kind_f(p_p0) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{false})
        ? std::tuple{Array<crate::syntax::Pattern_>{}, p_p0}
        : crate::syntax::parser::commas_f(p_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto q_p1 = p0;
                (prism_rtl::more(prism_rtl::rc(crate::syntax::parser::types::ParsePattern(q_p1, false))));
            });
        }));
    })));
    return crate::syntax::parser::kind_f(p1_p3) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{false})
        ? std::tuple{std::optional(ps_p2), crate::syntax::parser::adv_f(p1_p3)}
        : std::tuple{std::optional<Array<crate::syntax::Pattern_>>{}, crate::syntax::parser::error_here_f(p1_p3, Text::lit("expected `|` to close the lambda\'s parameters"))};
}


prism_rtl::Turn<std::tuple<std::optional<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps>> LambdaParams::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto [ps_p2, p1_p3] = crate::syntax::parser::kind_f(p_p0) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{false})
        ? std::tuple{Array<crate::syntax::Pattern_>{}, p_p0}
        : crate::syntax::parser::commas_f(p_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto q_p1 = p0;
                (prism_rtl::more(prism_rtl::rc(crate::syntax::parser::types::ParsePattern(q_p1, false))));
            });
        }));
    })));
    return crate::syntax::parser::kind_f(p1_p3) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{false})
        ? prism_rtl::finished(std::tuple{std::optional(ps_p2), crate::syntax::parser::adv_f(p1_p3)})
        : prism_rtl::finished(std::tuple{std::optional<Array<crate::syntax::Pattern_>>{}, crate::syntax::parser::error_here_f(p1_p3, Text::lit("expected `|` to close the lambda\'s parameters"))});
}


/// `Start LambdaParams, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps>> start_lambda_params_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<LambdaParams>(p_p0);
}


/// ParseCond: unbounded fn Ps, Bool -> ((Cond, Ps))
std::tuple<crate::syntax::Cond, crate::syntax::parser::Ps> parse_cond_f(const crate::syntax::parser::Ps& p_p0, const bool& allow_guard_p1) {
    auto [pattern_p2, q_p3] = crate::syntax::parser::types::parse_pattern_f(p_p0, true);
    return (!prism_rtl::deref(q_p3).bad_p) && crate::syntax::parser::at_op_f(q_p3, Text::lit("<-"))
        ? ({
        auto [value_p4, q1_p5] = parse_expr_f(crate::syntax::parser::adv_f(q_p3));
        allow_guard_p1 && crate::syntax::parser::at_kw_f(q1_p5, Text::lit("if"))
        ? ({
        auto [guard_p6, q2_p7] = parse_expr_f(crate::syntax::parser::adv_f(q1_p5));
        std::tuple{crate::syntax::Cond(crate::syntax::Cond::CondBind{pattern_p2, prism_rtl::rc(value_p4), prism_rtl::rc(std::optional(guard_p6))}), q2_p7};
    })
        : std::tuple{crate::syntax::Cond(crate::syntax::Cond::CondBind{pattern_p2, prism_rtl::rc(value_p4), prism_rtl::rc(std::optional<crate::syntax::Expr>{})}), q1_p5};
    })
        : ({
        auto [e_p8, q1_p9] = parse_expr_f(p_p0);
        std::tuple{crate::syntax::Cond(crate::syntax::Cond::CondExpr{prism_rtl::rc(e_p8)}), q1_p9};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Cond, crate::syntax::parser::Ps>> ParseCond::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& allow_guard_p1 = this->allow_guard_p1;
    auto allow_guard_p1x = prism_rtl::deref(allow_guard_p1);
    auto p_p0x = p_p0;
    return crate::prelude::call_then(crate::syntax::parser::types::start_parse_pattern_f(p_p0x, true), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_f_29990) {
        return ({
            auto [pattern_p2, q_p3] = parse_pattern_f_29990;
            (!prism_rtl::deref(q_p3).bad_p) && crate::syntax::parser::at_op_f(q_p3, Text::lit("<-"))
            ? crate::prelude::call_then(start_parse_expr_f(crate::syntax::parser::adv_f(q_p3)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_f_30076) {
            return ({
                auto [value_p4, q1_p5] = parse_expr_f_30076;
                allow_guard_p1x && crate::syntax::parser::at_kw_f(q1_p5, Text::lit("if"))
                ? crate::prelude::call_then(start_parse_expr_f(crate::syntax::parser::adv_f(q1_p5)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_f_30169) {
                return ({
                    auto [guard_p6, q2_p7] = parse_expr_f_30169;
                    (prism_rtl::finished(std::tuple{crate::syntax::Cond(crate::syntax::Cond::CondBind{pattern_p2, prism_rtl::rc(value_p4), prism_rtl::rc(std::optional(guard_p6))}), q2_p7}));
                });
            })
                : prism_rtl::finished(std::tuple{crate::syntax::Cond(crate::syntax::Cond::CondBind{pattern_p2, prism_rtl::rc(value_p4), prism_rtl::rc(std::optional<crate::syntax::Expr>{})}), q1_p5});
            });
        })
            : crate::prelude::call_then(start_parse_expr_f(p_p0x), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_f_30332) {
            return ({
                auto [e_p8, q1_p9] = parse_expr_f_30332;
                (prism_rtl::finished(std::tuple{crate::syntax::Cond(crate::syntax::Cond::CondExpr{prism_rtl::rc(e_p8)}), q1_p9}));
            });
        });
        });
    });
}


/// `Start ParseCond, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Cond, crate::syntax::parser::Ps>> start_parse_cond_f(crate::syntax::parser::Ps p_p0, bool allow_guard_p1) {
    return prism_rtl::make_rc<ParseCond>(p_p0, allow_guard_p1);
}


/// ParseIf: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_if_f(const crate::syntax::parser::Ps& p0_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p0_p0);
    auto [cond_p3, p1_p4] = parse_cond_f(crate::syntax::parser::adv_f(p0_p0), false);
    auto [then_block_p5, p2_p6] = crate::syntax::parser::blocks::parse_block_after_colon_f(p1_p4);
    auto p3_p2 = crate::syntax::parser::at_sep_f(p2_p6) && is_else_f(crate::syntax::parser::kind_at_f(p2_p6, Nat(1u)))
        ? crate::syntax::parser::adv_f(p2_p6)
        : p2_p6;
    return crate::syntax::parser::at_kw_f(p3_p2, Text::lit("else"))
        ? ({
        auto [else_block_p7, q_p8] = crate::syntax::parser::blocks::parse_block_after_colon_f(crate::syntax::parser::adv_f(p3_p2));
        std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIf{prism_rtl::rc(cond_p3), then_block_p5, std::optional(else_block_p7)})), .span_p = crate::syntax::parser::to_f(start_p1, prism_rtl::deref(else_block_p7).span_p)}, q_p8};
    })
        : std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIf{prism_rtl::rc(cond_p3), then_block_p5, std::optional<crate::syntax::Block>{}})), .span_p = crate::syntax::parser::to_f(start_p1, prism_rtl::deref(then_block_p5).span_p)}, p3_p2};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseIf::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    auto start_p1 = crate::syntax::parser::here_f(p0_p0);
    auto p0_p0x = p0_p0;
    return crate::prelude::call_then(start_parse_cond_f(crate::syntax::parser::adv_f(p0_p0x), false), [=](std::tuple<crate::syntax::Cond, crate::syntax::parser::Ps> parse_cond_f_30565) {
        return ({
            auto [cond_p3, p1_p4] = parse_cond_f_30565;
            (crate::prelude::call_then(crate::syntax::parser::blocks::start_parse_block_after_colon_f(p1_p4), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_f_30619) {
            return ({
                auto [then_block_p5, p2_p6] = parse_block_after_colon_f_30619;
                auto p3_p2 = crate::syntax::parser::at_sep_f(p2_p6) && is_else_f(crate::syntax::parser::kind_at_f(p2_p6, Nat(1u)))
                    ? crate::syntax::parser::adv_f(p2_p6)
                    : p2_p6;
                (crate::syntax::parser::at_kw_f(p3_p2, Text::lit("else"))
                ? crate::prelude::call_then(crate::syntax::parser::blocks::start_parse_block_after_colon_f(crate::syntax::parser::adv_f(p3_p2)), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_f_30770) {
                return ({
                    auto [else_block_p7, q_p8] = parse_block_after_colon_f_30770;
                    (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIf{prism_rtl::rc(cond_p3), then_block_p5, std::optional(else_block_p7)})), .span_p = crate::syntax::parser::to_f(start_p1, prism_rtl::deref(else_block_p7).span_p)}, q_p8}));
                });
            })
                : prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIf{prism_rtl::rc(cond_p3), then_block_p5, std::optional<crate::syntax::Block>{}})), .span_p = crate::syntax::parser::to_f(start_p1, prism_rtl::deref(then_block_p5).span_p)}, p3_p2}));
            });
        }));
        });
    });
}


/// `Start ParseIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_if_f(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseIf>(p0_p0);
}


/// IsElse: fn TokKind -> Bool
bool is_else_f(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(tok_kind0)) {
        auto&& c0_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(tok_kind0).a0;
        if (c0_0_0 == Text::lit("else")) {
            return true;
        }
    }
    {
        return false;
    }
}


/// ParseMatch: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_match_f(const crate::syntax::parser::Ps& p0_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p0_p0);
    auto [scrutinee_p3, p1_p4] = parse_expr_f(crate::syntax::parser::adv_f(p0_p0));
    auto p2_p2 = crate::syntax::parser::expect_colon_f(p1_p4);
    return crate::syntax::parser::at_open_l_f(p2_p2)
        ? ({
        auto [arms_p5, q_p6] = match_arms_f(crate::syntax::parser::adv_f(p2_p2));
        std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMatch{prism_rtl::rc(scrutinee_p3), arms_p5})), .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_p6))}, q_p6};
    })
        : std::tuple{crate::syntax::parser::decls::no_expr_p(), crate::syntax::parser::error_here_f(p2_p2, Text::lit("a `match`\'s arms stand in an indented block after its `:`"))};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseMatch::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    auto start_p1 = crate::syntax::parser::here_f(p0_p0);
    auto p0_p0x = p0_p0;
    return crate::prelude::call_then(start_parse_expr_f(crate::syntax::parser::adv_f(p0_p0x)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_f_31351) {
        return ({
            auto [scrutinee_p3, p1_p4] = parse_expr_f_31351;
            auto p2_p2 = crate::syntax::parser::expect_colon_f(p1_p4);
            (crate::syntax::parser::at_open_l_f(p2_p2)
            ? crate::prelude::call_then(start_match_arms_f(crate::syntax::parser::adv_f(p2_p2)), [=](std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps> match_arms_f_31443) {
            return ({
                auto [arms_p5, q_p6] = match_arms_f_31443;
                (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMatch{prism_rtl::rc(scrutinee_p3), arms_p5})), .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_p6))}, q_p6}));
            });
        })
            : prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr_p(), crate::syntax::parser::error_here_f(p2_p2, Text::lit("a `match`\'s arms stand in an indented block after its `:`"))}));
        });
    });
}


/// `Start ParseMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_match_f(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseMatch>(p0_p0);
}


/// MatchArms: unbounded fn Ps -> (([Arm], Ps))
std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps> match_arms_f(const crate::syntax::parser::Ps& p0_p0) {
    std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Arm>{}, p0_p0};
    Array<crate::syntax::Arm> arms_p1 = Array<crate::syntax::Arm>{};
    crate::syntax::parser::Ps p_p2 = p0_p0;
    bool going_p3 = true;
    while (std::move(going_p3)) {
        auto [arm_p4, q_p5] = parse_arm_f(p_p2);
        if (!prism_rtl::deref(q_p5).bad_p) {
            arms_p1 = crate::prelude::push(arms_p1, arm_p4);
        }
        p_p2 = crate::syntax::parser::recovered_f(q_p5);
        {
            auto&& _m = crate::syntax::parser::kind_f(p_p2);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                p_p2 = crate::syntax::parser::adv_f(p_p2);
            } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                p_p2 = crate::syntax::parser::adv_f(p_p2);
                going_p3 = false;
            } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                going_p3 = false;
            } else {
                p_p2 = crate::syntax::parser::recover_f(crate::syntax::parser::complain_f(p_p2, Text::lit("expected the end of the arm")));
            }
        }
    }
    this_ = std::tuple{arms_p1, p_p2};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>> MatchArms::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Arm>{}, p0_p0};
    Array<crate::syntax::Arm> arms_p1 = Array<crate::syntax::Arm>{};
    crate::syntax::parser::Ps p_p2 = p0_p0;
    bool going_p3 = true;
    return crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_), std::move(arms_p1), std::move(going_p3), std::move(p_p2)}, [=](std::tuple<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>, Array<crate::syntax::Arm>, bool, crate::syntax::parser::Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto arms_p1 = std::get<1>(_p0);
        auto going_p3 = std::get<2>(_p0);
        auto p_p2 = std::get<3>(_p0);
        return going_p3
            ? ({
            auto [arm_p4, q_p5] = parse_arm_f(p_p2);
            if (!prism_rtl::deref(q_p5).bad_p) {
                arms_p1 = crate::prelude::push(arms_p1, arm_p4);
            }
            p_p2 = crate::syntax::parser::recovered_f(q_p5);
            {
                auto&& _m = crate::syntax::parser::kind_f(p_p2);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                    p_p2 = crate::syntax::parser::adv_f(p_p2);
                } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                    p_p2 = crate::syntax::parser::adv_f(p_p2);
                    going_p3 = false;
                } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                    going_p3 = false;
                } else {
                    p_p2 = crate::syntax::parser::recover_f(crate::syntax::parser::complain_f(p_p2, Text::lit("expected the end of the arm")));
                }
            }
            Expected<std::tuple<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>, Array<crate::syntax::Arm>, bool, crate::syntax::parser::Ps>, std::tuple<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>, Array<crate::syntax::Arm>, bool, crate::syntax::parser::Ps>>(std::tuple{this_, arms_p1, going_p3, p_p2});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>, Array<crate::syntax::Arm>, bool, crate::syntax::parser::Ps>, std::tuple<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>, Array<crate::syntax::Arm>, bool, crate::syntax::parser::Ps>>(unexpected(std::tuple{this_, arms_p1, going_p3, p_p2}));
    }), [=](std::tuple<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>, Array<crate::syntax::Arm>, bool, crate::syntax::parser::Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto arms_p1 = std::get<1>(_p0);
        auto going_p3 = std::get<2>(_p0);
        auto p_p2 = std::get<3>(_p0);
        return ({
            this_ = std::tuple{arms_p1, p_p2};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start MatchArms, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>> start_match_arms_f(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<MatchArms>(p0_p0);
}


/// ParseArm: unbounded fn Ps -> ((Arm, Ps))
std::tuple<crate::syntax::Arm, crate::syntax::parser::Ps> parse_arm_f(const crate::syntax::parser::Ps& p_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    return crate::syntax::parser::at_kw_f(p_p0, Text::lit("otherwise"))
        ? ({
        auto [body_p2, q_p3] = crate::syntax::parser::blocks::parse_block_after_colon_f(crate::syntax::parser::adv_f(p_p0));
        std::tuple{crate::syntax::Arm{.pattern_o = std::optional<crate::syntax::Pattern_>{}, .guard_o = std::optional<crate::syntax::Expr>{}, .body_p = body_p2, .span_p = crate::syntax::parser::to_f(start_p1, prism_rtl::deref(body_p2).span_p)}, q_p3};
    })
        : crate::syntax::parser::at_kw_f(p_p0, Text::lit("ignore")) && (crate::syntax::parser::kind_at_f(p_p0, Nat(1u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}))
        ? std::tuple{crate::syntax::Arm{.pattern_o = std::optional<crate::syntax::Pattern_>{}, .guard_o = std::optional<crate::syntax::Expr>{}, .body_p = crate::syntax::parser::decls::no_block_p(), .span_p = start_p1}, crate::syntax::parser::error_at_f(p_p0, crate::syntax::parser::here_f(p_p0), Text::lit("an arm beginning `ignore:` would read as \"ignore these cases\": the catch-all is `otherwise:`"))}
        : ({
        auto [pattern_p4, p1_p5] = crate::syntax::parser::types::parse_pattern_f(p_p0, true);
        auto [guard_o6, p2_p7] = crate::syntax::parser::at_kw_f(p1_p5, Text::lit("if"))
            ? optional_expr_f(crate::syntax::parser::adv_f(p1_p5))
            : std::tuple{std::optional<crate::syntax::Expr>{}, p1_p5};
        auto [body_p8, p3_p9] = crate::syntax::parser::blocks::parse_block_after_colon_f(p2_p7);
        std::tuple{crate::syntax::Arm{.pattern_o = std::optional(pattern_p4), .guard_o = guard_o6, .body_p = body_p8, .span_p = crate::syntax::parser::to_f(start_p1, prism_rtl::deref(body_p8).span_p)}, p3_p9};
    });
}


/// OptionalExpr: unbounded fn Ps -> ((?Expr, Ps))
std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::parser::Ps> optional_expr_f(const crate::syntax::parser::Ps& p_p0) {
    auto [e_p1, q_p2] = parse_expr_f(p_p0);
    return std::tuple{std::optional(e_p1), q_p2};
}


/// ParseFor: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_for_f(const crate::syntax::parser::Ps& p0_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p0_p0);
    auto p_p2 = crate::syntax::parser::adv_f(p0_p0);
    auto [binders_o3, p1_p4] = for_binders_of_f(p_p2);
    auto [source_p5, p2_p6] = parse_expr_f(p1_p4);
    auto [body_p7, p3_p8] = crate::syntax::parser::blocks::parse_block_after_colon_f(p2_p6);
    return std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EFor{binders_o3, prism_rtl::rc(source_p5), body_p7})), .span_p = crate::syntax::parser::to_f(start_p1, prism_rtl::deref(body_p7).span_p)}, p3_p8};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseFor::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    auto start_p1 = crate::syntax::parser::here_f(p0_p0);
    auto p_p2 = crate::syntax::parser::adv_f(p0_p0);
    return crate::prelude::call_then(start_for_binders_of_f(p_p2), [=](std::tuple<std::optional<crate::syntax::ForBinders>, crate::syntax::parser::Ps> for_binders_of_f_33299) {
        return ({
            auto [binders_o3, p1_p4] = for_binders_of_f_33299;
            (crate::prelude::call_then(start_parse_expr_f(p1_p4), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_f_33339) {
            return ({
                auto [source_p5, p2_p6] = parse_expr_f_33339;
                (crate::prelude::call_then(crate::syntax::parser::blocks::start_parse_block_after_colon_f(p2_p6), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_f_33375) {
                return ({
                    auto [body_p7, p3_p8] = parse_block_after_colon_f_33375;
                    (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EFor{binders_o3, prism_rtl::rc(source_p5), body_p7})), .span_p = crate::syntax::parser::to_f(start_p1, prism_rtl::deref(body_p7).span_p)}, p3_p8}));
                });
            }));
            });
        }));
        });
    });
}


/// `Start ParseFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_for_f(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseFor>(p0_p0);
}


/// ForBindersOf: unbounded fn Ps -> ((?ForBinders, Ps))
std::tuple<std::optional<crate::syntax::ForBinders>, crate::syntax::parser::Ps> for_binders_of_f(const crate::syntax::parser::Ps& p_p0) {
    auto [first_p1, q1_p2] = crate::syntax::parser::types::parse_pattern_f(p_p0, false);
    auto [second_o3, q2_p4] = crate::syntax::parser::at_comma_f(q1_p2)
        ? optional_pattern_f(crate::syntax::parser::adv_f(q1_p2))
        : std::tuple{std::optional<crate::syntax::Pattern_>{}, q1_p2};
    return (!prism_rtl::deref(q2_p4).bad_p) && crate::syntax::parser::at_op_f(q2_p4, Text::lit("<-"))
        ? std::tuple{std::optional(crate::syntax::ForBinders{.first_p = first_p1, .second_o = second_o3}), crate::syntax::parser::adv_f(q2_p4)}
        : std::tuple{std::optional<crate::syntax::ForBinders>{}, p_p0};
}


prism_rtl::Turn<std::tuple<std::optional<crate::syntax::ForBinders>, crate::syntax::parser::Ps>> ForBindersOf::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto p_p0x = p_p0;
    return crate::prelude::call_then(crate::syntax::parser::types::start_parse_pattern_f(p_p0x, false), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_f_33660) {
        return ({
            auto [first_p1, q1_p2] = parse_pattern_f_33660;
            auto [second_o3, q2_p4] = crate::syntax::parser::at_comma_f(q1_p2)
                ? optional_pattern_f(crate::syntax::parser::adv_f(q1_p2))
                : std::tuple{std::optional<crate::syntax::Pattern_>{}, q1_p2};
            (!prism_rtl::deref(q2_p4).bad_p) && crate::syntax::parser::at_op_f(q2_p4, Text::lit("<-"))
            ? prism_rtl::finished(std::tuple{std::optional(crate::syntax::ForBinders{.first_p = first_p1, .second_o = second_o3}), crate::syntax::parser::adv_f(q2_p4)})
            : prism_rtl::finished(std::tuple{std::optional<crate::syntax::ForBinders>{}, p_p0x});
        });
    });
}


/// `Start ForBindersOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::ForBinders>, crate::syntax::parser::Ps>> start_for_binders_of_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ForBindersOf>(p_p0);
}


/// OptionalPattern: unbounded fn Ps -> ((?Pattern, Ps))
std::tuple<std::optional<crate::syntax::Pattern_>, crate::syntax::parser::Ps> optional_pattern_f(const crate::syntax::parser::Ps& p_p0) {
    auto [pat_p1, q_p2] = crate::syntax::parser::types::parse_pattern_f(p_p0, false);
    return std::tuple{std::optional(pat_p1), q_p2};
}

}  // namespace crate::syntax::parser::expr
