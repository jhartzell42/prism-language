// The module `Check.Env`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/env/module.hpp>
#include <check/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Env`, from `target/bootstrap/cpp-src/prismc/check/env/mod.prism`.
namespace crate::check::env {

bool CtorInfo::operator==(const CtorInfo& o) const { return name_p == o.name_p && owner_p == o.owner_p && params_p == o.params_p && args_p == o.args_p && fields_p == o.fields_p && ty_p == o.ty_p && index_p == o.index_p; }

void CtorInfo::show(Printer& p) const {
    p.record("CtorInfo", {{"name", name_p}, {"owner", owner_p}, {"params", params_p}, {"args", args_p}, {"fields", fields_p}, {"ty", ty_p}, {"index", index_p}});
}

Pod CtorInfo::to_pod() const {
    return Pod::record("CtorInfo", {{"name", prism_rtl::to_pod(name_p)}, {"owner", prism_rtl::to_pod(owner_p)}, {"params", prism_rtl::to_pod(params_p)}, {"args", prism_rtl::to_pod(args_p)}, {"fields", prism_rtl::to_pod(fields_p)}, {"ty", prism_rtl::to_pod(ty_p)}, {"index", prism_rtl::to_pod(index_p)}});
}

Result<CtorInfo> CtorInfo::from_pod(const Pod& whole) {
    return CtorInfo{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .owner_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "owner")))), .params_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "params")))), .args_p = TRY(prism_rtl::from_pod<Array<crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "args")))), .fields_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "fields")))), .ty_p = TRY(prism_rtl::from_pod<crate::check::types::Ty>(TRY(crate::prelude::field(whole, "ty")))), .index_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "index"))))};
}


void Def::show(Printer& p) const {
    p.record("Def", {{"qk", qk_p}, {"name", name_p}, {"home", home_p}, {"file", file_p}, {"span", span_p}, {"body", body_p}});
}

Pod Def::to_pod() const {
    return Pod::record("Def", {{"qk", prism_rtl::to_pod(qk_p)}, {"name", prism_rtl::to_pod(name_p)}, {"home", prism_rtl::to_pod(home_p)}, {"file", prism_rtl::to_pod(file_p)}, {"span", prism_rtl::to_pod(span_p)}, {"body", prism_rtl::to_pod(body_p)}});
}

Result<Def> Def::from_pod(const Pod& whole) {
    return Def{.qk_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "qk")))), .name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .home_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .file_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .body_p = TRY(prism_rtl::from_pod<DefBody>(TRY(crate::prelude::field(whole, "body"))))};
}


bool DefBody::DbFn::operator==(const DbFn& o) const { return a0 == o.a0; }

bool DefBody::DbMethod::operator==(const DbMethod& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool DefBody::DbDefault::operator==(const DbDefault& o) const { return a0 == o.a0 && a1 == o.a1; }

void DefBody::show(Printer& p) const {
    if (auto c = std::get_if<DbFn>(&cases())) p.choice("DbFn", {c->a0});
    else if (auto c = std::get_if<DbLet>(&cases())) p.choice("DbLet", {c->a0});
    else if (auto c = std::get_if<DbWidget>(&cases())) p.choice("DbWidget", {c->a0});
    else if (auto c = std::get_if<DbMethod>(&cases())) p.choice("DbMethod", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<DbDefault>(&cases())) p.choice("DbDefault", {c->a0, c->a1});
    else if (auto c = std::get_if<DbCheck>(&cases())) p.choice("DbCheck", {c->a0});
    else if (auto c = std::get_if<DbTest>(&cases())) p.choice("DbTest", {c->a0});
}

Pod DefBody::to_pod() const {
    return std::holds_alternative<DbFn>(cases()) ? Pod::choice("DbFn", {prism_rtl::to_pod(std::get<DbFn>(cases()).a0)})
        : std::holds_alternative<DbLet>(cases()) ? Pod::choice("DbLet", {prism_rtl::to_pod(std::get<DbLet>(cases()).a0)})
        : std::holds_alternative<DbWidget>(cases()) ? Pod::choice("DbWidget", {prism_rtl::to_pod(std::get<DbWidget>(cases()).a0)})
        : std::holds_alternative<DbMethod>(cases()) ? Pod::choice("DbMethod", {prism_rtl::to_pod(std::get<DbMethod>(cases()).a0), prism_rtl::to_pod(std::get<DbMethod>(cases()).a1), prism_rtl::to_pod(std::get<DbMethod>(cases()).a2)})
        : std::holds_alternative<DbDefault>(cases()) ? Pod::choice("DbDefault", {prism_rtl::to_pod(std::get<DbDefault>(cases()).a0), prism_rtl::to_pod(std::get<DbDefault>(cases()).a1)})
        : std::holds_alternative<DbCheck>(cases()) ? Pod::choice("DbCheck", {prism_rtl::to_pod(std::get<DbCheck>(cases()).a0)})
        : std::holds_alternative<DbTest>(cases()) ? Pod::choice("DbTest", {prism_rtl::to_pod(std::get<DbTest>(cases()).a0)})
        : Pod();
}

Result<DefBody> DefBody::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "DbFn" && c->args.size() == 1) return DefBody(DbFn{TRY(prism_rtl::from_pod<Array<crate::syntax::decls::FnClause>>(c->args[0]))});
        if (c->ctor == "DbLet" && c->args.size() == 1) return DefBody(DbLet{TRY(prism_rtl::from_pod<crate::syntax::decls::LetDecl>(c->args[0]))});
        if (c->ctor == "DbWidget" && c->args.size() == 1) return DefBody(DbWidget{TRY(prism_rtl::from_pod<crate::syntax::decls::WidgetDecl>(c->args[0]))});
        if (c->ctor == "DbMethod" && c->args.size() == 3) return DefBody(DbMethod{TRY(prism_rtl::from_pod<Array<crate::syntax::decls::FnClause>>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<ImplInfo>(c->args[2]))});
        if (c->ctor == "DbDefault" && c->args.size() == 2) return DefBody(DbDefault{TRY(prism_rtl::from_pod<Array<crate::syntax::decls::FnClause>>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "DbCheck" && c->args.size() == 1) return DefBody(DbCheck{TRY(prism_rtl::from_pod<crate::syntax::decls::CheckDecl>(c->args[0]))});
        if (c->ctor == "DbTest" && c->args.size() == 1) return DefBody(DbTest{TRY(prism_rtl::from_pod<crate::syntax::decls::TestDecl>(c->args[0]))});
    }
    return mismatch<DefBody>("a DefBody", p);
}


bool G::operator==(const G& o) const { return mods_p == o.mods_p && types_p == o.types_p && ctors_p == o.ctors_p && tags_p == o.tags_p && families_p == o.families_p && fam_owner_p == o.fam_owner_p && vals_p == o.vals_p && traits_p == o.traits_p && impls_p == o.impls_p && bare_p == o.bare_p && bare_types_p == o.bare_types_p && bare_traits_p == o.bare_traits_p && srcs_p == o.srcs_p && defs_p == o.defs_p && program_row_p == o.program_row_p && elem_fams_p == o.elem_fams_p && root_module_o == o.root_module_o && app_root_p == o.app_root_p && fn_at_p == o.fn_at_p && prelude_from_p == o.prelude_from_p; }

void G::show(Printer& p) const {
    p.record("G", {{"mods", mods_p}, {"types", types_p}, {"ctors", ctors_p}, {"tags", tags_p}, {"families", families_p}, {"famOwner", fam_owner_p}, {"vals", vals_p}, {"traits", traits_p}, {"impls", impls_p}, {"bare", bare_p}, {"bareTypes", bare_types_p}, {"bareTraits", bare_traits_p}, {"srcs", srcs_p}, {"defs", defs_p}, {"programRow", program_row_p}, {"elemFams", elem_fams_p}, {"rootModule", root_module_o}, {"appRoot", app_root_p}, {"fnAt", fn_at_p}, {"preludeFrom", prelude_from_p}});
}

Pod G::to_pod() const {
    return Pod::record("G", {{"mods", prism_rtl::to_pod(mods_p)}, {"types", prism_rtl::to_pod(types_p)}, {"ctors", prism_rtl::to_pod(ctors_p)}, {"tags", prism_rtl::to_pod(tags_p)}, {"families", prism_rtl::to_pod(families_p)}, {"famOwner", prism_rtl::to_pod(fam_owner_p)}, {"vals", prism_rtl::to_pod(vals_p)}, {"traits", prism_rtl::to_pod(traits_p)}, {"impls", prism_rtl::to_pod(impls_p)}, {"bare", prism_rtl::to_pod(bare_p)}, {"bareTypes", prism_rtl::to_pod(bare_types_p)}, {"bareTraits", prism_rtl::to_pod(bare_traits_p)}, {"srcs", prism_rtl::to_pod(srcs_p)}, {"defs", prism_rtl::to_pod(defs_p)}, {"programRow", prism_rtl::to_pod(program_row_p)}, {"elemFams", prism_rtl::to_pod(elem_fams_p)}, {"rootModule", prism_rtl::to_pod(root_module_o)}, {"appRoot", prism_rtl::to_pod(app_root_p)}, {"fnAt", prism_rtl::to_pod(fn_at_p)}, {"preludeFrom", prism_rtl::to_pod(prelude_from_p)}});
}

Result<G> G::from_pod(const Pod& whole) {
    return G{.mods_p = TRY(prism_rtl::from_pod<Map<Text, ModInfo>>(TRY(crate::prelude::field(whole, "mods")))), .types_p = TRY(prism_rtl::from_pod<Map<Text, TyInfo>>(TRY(crate::prelude::field(whole, "types")))), .ctors_p = TRY(prism_rtl::from_pod<Map<Text, CtorInfo>>(TRY(crate::prelude::field(whole, "ctors")))), .tags_p = TRY(prism_rtl::from_pod<Map<Text, TagInfo>>(TRY(crate::prelude::field(whole, "tags")))), .families_p = TRY(prism_rtl::from_pod<Map<Text, Array<Text>>>(TRY(crate::prelude::field(whole, "families")))), .fam_owner_p = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "famOwner")))), .vals_p = TRY(prism_rtl::from_pod<Map<Text, ValInfo>>(TRY(crate::prelude::field(whole, "vals")))), .traits_p = TRY(prism_rtl::from_pod<Map<Text, TraitInfo>>(TRY(crate::prelude::field(whole, "traits")))), .impls_p = TRY(prism_rtl::from_pod<Map<Text, Array<ImplInfo>>>(TRY(crate::prelude::field(whole, "impls")))), .bare_p = TRY(prism_rtl::from_pod<Map<Text, Map<Text, Array<Text>>>>(TRY(crate::prelude::field(whole, "bare")))), .bare_types_p = TRY(prism_rtl::from_pod<Map<Text, Map<Text, Array<Text>>>>(TRY(crate::prelude::field(whole, "bareTypes")))), .bare_traits_p = TRY(prism_rtl::from_pod<Map<Text, Map<Text, Array<Text>>>>(TRY(crate::prelude::field(whole, "bareTraits")))), .srcs_p = TRY(prism_rtl::from_pod<Array<crate::check::errors::Src>>(TRY(crate::prelude::field(whole, "srcs")))), .defs_p = TRY(prism_rtl::from_pod<Array<Def>>(TRY(crate::prelude::field(whole, "defs")))), .program_row_p = TRY(prism_rtl::from_pod<crate::check::types::Rw>(TRY(crate::prelude::field(whole, "programRow")))), .elem_fams_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "elemFams")))), .root_module_o = TRY(prism_rtl::from_pod<std::optional<Text>>(TRY(crate::prelude::field(whole, "rootModule")))), .app_root_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "appRoot")))), .fn_at_p = TRY(prism_rtl::from_pod<Map<Text, Nat>>(TRY(crate::prelude::field(whole, "fnAt")))), .prelude_from_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "preludeFrom"))))};
}


bool ImplInfo::operator==(const ImplInfo& o) const { return cls_p == o.cls_p && head_p == o.head_p && qs_p == o.qs_p && bounds_p == o.bounds_p && home_p == o.home_p && file_p == o.file_p && span_p == o.span_p && derived_p == o.derived_p && assocs_p == o.assocs_p && methods_p == o.methods_p; }

void ImplInfo::show(Printer& p) const {
    p.record("ImplInfo", {{"cls", cls_p}, {"head", head_p}, {"qs", qs_p}, {"bounds", bounds_p}, {"home", home_p}, {"file", file_p}, {"span", span_p}, {"derived", derived_p}, {"assocs", assocs_p}, {"methods", methods_p}});
}

Pod ImplInfo::to_pod() const {
    return Pod::record("ImplInfo", {{"cls", prism_rtl::to_pod(cls_p)}, {"head", prism_rtl::to_pod(head_p)}, {"qs", prism_rtl::to_pod(qs_p)}, {"bounds", prism_rtl::to_pod(bounds_p)}, {"home", prism_rtl::to_pod(home_p)}, {"file", prism_rtl::to_pod(file_p)}, {"span", prism_rtl::to_pod(span_p)}, {"derived", prism_rtl::to_pod(derived_p)}, {"assocs", prism_rtl::to_pod(assocs_p)}, {"methods", prism_rtl::to_pod(methods_p)}});
}

Result<ImplInfo> ImplInfo::from_pod(const Pod& whole) {
    return ImplInfo{.cls_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "cls")))), .head_p = TRY(prism_rtl::from_pod<crate::check::types::Ty>(TRY(crate::prelude::field(whole, "head")))), .qs_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "qs")))), .bounds_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "bounds")))), .home_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .file_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .derived_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "derived")))), .assocs_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, crate::check::types::Ty>>>(TRY(crate::prelude::field(whole, "assocs")))), .methods_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "methods"))))};
}


void ModInfo::show(Printer& p) const {
    p.record("ModInfo", {{"name", name_p}, {"file", file_p}, {"emitRw", emit_rw_p}, {"rowVar", row_var_p}, {"uses", uses_p}, {"root", root_p}, {"tree", tree_p}});
}

Pod ModInfo::to_pod() const {
    return Pod::record("ModInfo", {{"name", prism_rtl::to_pod(name_p)}, {"file", prism_rtl::to_pod(file_p)}, {"emitRw", prism_rtl::to_pod(emit_rw_p)}, {"rowVar", prism_rtl::to_pod(row_var_p)}, {"uses", prism_rtl::to_pod(uses_p)}, {"root", prism_rtl::to_pod(root_p)}, {"tree", prism_rtl::to_pod(tree_p)}});
}

Result<ModInfo> ModInfo::from_pod(const Pod& whole) {
    return ModInfo{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .file_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .emit_rw_p = TRY(prism_rtl::from_pod<crate::check::types::Rw>(TRY(crate::prelude::field(whole, "emitRw")))), .row_var_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "rowVar")))), .uses_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, bool>>>(TRY(crate::prelude::field(whole, "uses")))), .root_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "root")))), .tree_p = TRY(prism_rtl::from_pod<crate::syntax::Module>(TRY(crate::prelude::field(whole, "tree"))))};
}


bool TagInfo::operator==(const TagInfo& o) const { return name_p == o.name_p && family_p == o.family_p && kind_p == o.kind_p && out_p == o.out_p && qs_p == o.qs_p && rqs_p == o.rqs_p && bounds_p == o.bounds_p && fields_p == o.fields_p && home_p == o.home_p && file_p == o.file_p && span_p == o.span_p; }

void TagInfo::show(Printer& p) const {
    p.record("TagInfo", {{"name", name_p}, {"family", family_p}, {"kind", kind_p}, {"out", out_p}, {"qs", qs_p}, {"rqs", rqs_p}, {"bounds", bounds_p}, {"fields", fields_p}, {"home", home_p}, {"file", file_p}, {"span", span_p}});
}

Pod TagInfo::to_pod() const {
    return Pod::record("TagInfo", {{"name", prism_rtl::to_pod(name_p)}, {"family", prism_rtl::to_pod(family_p)}, {"kind", prism_rtl::to_pod(kind_p)}, {"out", prism_rtl::to_pod(out_p)}, {"qs", prism_rtl::to_pod(qs_p)}, {"rqs", prism_rtl::to_pod(rqs_p)}, {"bounds", prism_rtl::to_pod(bounds_p)}, {"fields", prism_rtl::to_pod(fields_p)}, {"home", prism_rtl::to_pod(home_p)}, {"file", prism_rtl::to_pod(file_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<TagInfo> TagInfo::from_pod(const Pod& whole) {
    return TagInfo{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .family_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "family")))), .kind_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "kind")))), .out_p = TRY(prism_rtl::from_pod<crate::check::types::Ty>(TRY(crate::prelude::field(whole, "out")))), .qs_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "qs")))), .rqs_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "rqs")))), .bounds_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "bounds")))), .fields_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, crate::check::types::Ty>>>(TRY(crate::prelude::field(whole, "fields")))), .home_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .file_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void TraitInfo::show(Printer& p) const {
    p.record("TraitInfo", {{"name", name_p}, {"home", home_p}, {"param", param_p}, {"supers", supers_p}, {"methods", methods_p}, {"defaults", defaults_p}, {"assocs", assocs_p}, {"file", file_p}, {"span", span_p}});
}

Pod TraitInfo::to_pod() const {
    return Pod::record("TraitInfo", {{"name", prism_rtl::to_pod(name_p)}, {"home", prism_rtl::to_pod(home_p)}, {"param", prism_rtl::to_pod(param_p)}, {"supers", prism_rtl::to_pod(supers_p)}, {"methods", prism_rtl::to_pod(methods_p)}, {"defaults", prism_rtl::to_pod(defaults_p)}, {"assocs", prism_rtl::to_pod(assocs_p)}, {"file", prism_rtl::to_pod(file_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<TraitInfo> TraitInfo::from_pod(const Pod& whole) {
    return TraitInfo{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .home_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .param_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "param")))), .supers_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "supers")))), .methods_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "methods")))), .defaults_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "defaults")))), .assocs_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "assocs")))), .file_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool TyBody::BRecord::operator==(const BRecord& o) const { return a0 == o.a0; }

bool TyBody::BChoice::operator==(const BChoice& o) const { return a0 == o.a0; }

void TyBody::show(Printer& p) const {
    if (auto c = std::get_if<BRecord>(&cases())) p.choice("BRecord", {c->a0});
    else if (auto c = std::get_if<BChoice>(&cases())) p.choice("BChoice", {c->a0});
    else if (auto c = std::get_if<BRowKind>(&cases())) p.choice("BRowKind", {});
    else if (auto c = std::get_if<BAlias>(&cases())) p.choice("BAlias", {c->a0});
    else if (auto c = std::get_if<BOpaque>(&cases())) p.choice("BOpaque", {});
    else if (auto c = std::get_if<BPrim>(&cases())) p.choice("BPrim", {});
}

Pod TyBody::to_pod() const {
    return std::holds_alternative<BRecord>(cases()) ? Pod::choice("BRecord", {prism_rtl::to_pod(std::get<BRecord>(cases()).a0)})
        : std::holds_alternative<BChoice>(cases()) ? Pod::choice("BChoice", {prism_rtl::to_pod(std::get<BChoice>(cases()).a0)})
        : std::holds_alternative<BRowKind>(cases()) ? Pod::choice("BRowKind", {})
        : std::holds_alternative<BAlias>(cases()) ? Pod::choice("BAlias", {prism_rtl::to_pod(std::get<BAlias>(cases()).a0)})
        : std::holds_alternative<BOpaque>(cases()) ? Pod::choice("BOpaque", {})
        : std::holds_alternative<BPrim>(cases()) ? Pod::choice("BPrim", {})
        : Pod();
}

Result<TyBody> TyBody::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "BRecord" && c->args.size() == 1) return TyBody(BRecord{TRY(prism_rtl::from_pod<Array<std::tuple<Text, crate::check::types::Ty>>>(c->args[0]))});
        if (c->ctor == "BChoice" && c->args.size() == 1) return TyBody(BChoice{TRY(prism_rtl::from_pod<Array<std::tuple<Text, Array<crate::check::types::Ty>>>>(c->args[0]))});
        if (c->ctor == "BRowKind" && c->args.size() == 0) return TyBody(BRowKind{});
        if (c->ctor == "BAlias" && c->args.size() == 1) return TyBody(BAlias{TRY(prism_rtl::from_pod<crate::check::types::Ty>(c->args[0]))});
        if (c->ctor == "BOpaque" && c->args.size() == 0) return TyBody(BOpaque{});
        if (c->ctor == "BPrim" && c->args.size() == 0) return TyBody(BPrim{});
    }
    return mismatch<TyBody>("a TyBody", p);
}


void TyInfo::show(Printer& p) const {
    p.record("TyInfo", {{"name", name_p}, {"home", home_p}, {"params", params_p}, {"body", body_p}, {"derives", derives_p}, {"file", file_p}, {"span", span_p}});
}

Pod TyInfo::to_pod() const {
    return Pod::record("TyInfo", {{"name", prism_rtl::to_pod(name_p)}, {"home", prism_rtl::to_pod(home_p)}, {"params", prism_rtl::to_pod(params_p)}, {"body", prism_rtl::to_pod(body_p)}, {"derives", prism_rtl::to_pod(derives_p)}, {"file", prism_rtl::to_pod(file_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<TyInfo> TyInfo::from_pod(const Pod& whole) {
    return TyInfo{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .home_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .params_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "params")))), .body_p = TRY(prism_rtl::from_pod<TyBody>(TRY(crate::prelude::field(whole, "body")))), .derives_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "derives")))), .file_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void ValInfo::show(Printer& p) const {
    p.record("ValInfo", {{"qk", qk_p}, {"scheme", scheme_p}, {"sort", sort_p}, {"hasSig", has_sig_p}, {"home", home_p}, {"file", file_p}, {"span", span_p}});
}

Pod ValInfo::to_pod() const {
    return Pod::record("ValInfo", {{"qk", prism_rtl::to_pod(qk_p)}, {"scheme", prism_rtl::to_pod(scheme_p)}, {"sort", prism_rtl::to_pod(sort_p)}, {"hasSig", prism_rtl::to_pod(has_sig_p)}, {"home", prism_rtl::to_pod(home_p)}, {"file", prism_rtl::to_pod(file_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<ValInfo> ValInfo::from_pod(const Pod& whole) {
    return ValInfo{.qk_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "qk")))), .scheme_p = TRY(prism_rtl::from_pod<crate::check::types::Scheme>(TRY(crate::prelude::field(whole, "scheme")))), .sort_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "sort")))), .has_sig_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "hasSig")))), .home_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .file_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


/// IsRegexType: fn Text -> Bool
bool is_regex_type_f(const Text& n_p0) {
    return (n_p0 == Text::lit("Regex")) || (n_p0 == Text::lit("RegexReplacement"));
}


/// IsPrimType: fn Text -> Bool
bool is_prim_type_f(const Text& n_p0) {
    return crate::check::types::has_text_f(Array(std::vector{Text::lit("Bool"), Text::lit("unit"), Text::lit("Char"), Text::lit("Text"), Text::lit("Nat"), Text::lit("Int"), Text::lit("U8"), Text::lit("Float"), Text::lit("Path"), Text::lit("Duration"), Text::lit("Cursor"), Text::lit("Regex"), Text::lit("RegexReplacement")}), n_p0);
}


/// QualKey: fn Text, Text -> Text
Text qual_key_f(const Text& m_p0, const Text& name_p1) {
    return m_p0 == Text::lit("") ? name_p1 : prism_rtl::cat(m_p0, ".", name_p1);
}


/// Dotted: fn [Text] -> Text
Text dotted_f(const Array<Text>& parts_p0) {
    return crate::syntax::lexer::chars::join_f(parts_p0, Text::lit("."));
}


/// SNameKey: fn SName -> Text
Text sname_key_f(const crate::syntax::SName& n_p0) {
    return prism_rtl::cat(n_p0.sigils_p, dotted_f(n_p0.path_p));
}


/// DefNameText: fn DefName -> Text
Text def_name_text_f(const crate::syntax::decls::DefName& def_name0) {
    if (prism_rtl::is<crate::syntax::decls::DefName::DefSName>(def_name0)) {
        auto&& n_p0 = prism_rtl::as<crate::syntax::decls::DefName::DefSName>(def_name0).a0;
        return sname_key_f(n_p0);
    }
    if (prism_rtl::is<crate::syntax::decls::DefName::DefOp>(def_name0)) {
        auto&& o_p1 = prism_rtl::as<crate::syntax::decls::DefName::DefOp>(def_name0).a0;
        return o_p1;
    }
    prism_rtl::unreachable("no arm matched");
}


/// DefNameSpan: fn DefName -> Range
crate::syntax::Range def_name_span_f(const crate::syntax::decls::DefName& def_name0) {
    if (prism_rtl::is<crate::syntax::decls::DefName::DefSName>(def_name0)) {
        auto&& n_p0 = prism_rtl::as<crate::syntax::decls::DefName::DefSName>(def_name0).a0;
        return prism_rtl::deref(n_p0).span_p;
    }
    if (prism_rtl::is<crate::syntax::decls::DefName::DefOp>(def_name0)) {
        auto&& r_p1 = prism_rtl::as<crate::syntax::decls::DefName::DefOp>(def_name0).a1;
        return r_p1;
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsLowerText: fn Text -> Bool
bool is_lower_text_f(const Text& t_p0) {
    return crate::syntax::lexer::chars::is_lower_f(crate::syntax::lexer::chars::head_f(t_p0));
}


/// IsUpperText: fn Text -> Bool
bool is_upper_text_f(const Text& t_p0) {
    return crate::syntax::lexer::chars::is_upper_f(crate::syntax::lexer::chars::head_f(t_p0));
}


/// BuildG: unbounded fn [Src], [Module] -> ((G, St))
std::tuple<G, crate::check::types::St> build_g_f(const Array<crate::check::errors::Src>& srcs_p0, const Array<crate::syntax::Module>& trees_p1) {
    auto g0_p2 = G{.mods_p = Map<Text, ModInfo>{}, .types_p = Map<Text, TyInfo>{}, .ctors_p = Map<Text, CtorInfo>{}, .tags_p = Map<Text, TagInfo>{}, .families_p = Map<Text, Array<Text>>{}, .fam_owner_p = Map<Text, Text>{}, .vals_p = Map<Text, ValInfo>{}, .traits_p = Map<Text, TraitInfo>{}, .impls_p = Map<Text, Array<ImplInfo>>{}, .bare_p = Map<Text, Map<Text, Array<Text>>>{}, .bare_types_p = Map<Text, Map<Text, Array<Text>>>{}, .bare_traits_p = Map<Text, Map<Text, Array<Text>>>{}, .srcs_p = srcs_p0, .defs_p = Array<Def>{}, .program_row_p = crate::check::types::empty_row_p(), .elem_fams_p = Array<Text>{}, .root_module_o = std::optional<Text>{}, .app_root_p = app_root_f(srcs_p0, trees_p1), .fn_at_p = Map<Text, Nat>{}, .prelude_from_p = crate::prelude::len(trees_p1)};
    auto st0_p3 = crate::check::types::new_st_f(Nat(0u));
    auto [g1_pb, st1_pc] = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(trees_p1)), std::tuple{g0_p2, st0_p3}, [&](const std::tuple<G, crate::check::types::St>& _p0, const Nat& i_pa) {
        auto&& g_p8 = std::get<0>(_p0);
        auto&& st_p9 = std::get<1>(_p0);
        return add_module_f(g_p8, st_p9, i_pa, crate::prelude::or_(crate::prelude::index(trees_p1, i_pa), empty_module_p()));
    });
    auto g2_p4 = add_builtins_f(g1_pb);
    auto [g3_pg, st3_ph] = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(prism_rtl::deref(g2_p4).mods_p), std::tuple{g2_p4, st1_pc}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, crate::check::types::St>>(std::tuple<std::tuple<G, crate::check::types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, crate::check::types::St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [g_pd, st_pe] = p0;
                auto m_pf = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::env::names::CollectNames(g_pd, st_pe, m_pf))));
            });
        }));
    }))));
    auto g4_p5 = ({
        G this_ = g3_pg;
        this_.program_row_p = crate::check::env::names::program_row_f(this_);
        (std::move(this_));
    });
    auto [g6_pl, st6_pm] = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(prism_rtl::deref(g4_p5).mods_p), std::tuple{g4_p5, st3_ph}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, crate::check::types::St>>(std::tuple<std::tuple<G, crate::check::types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, crate::check::types::St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [g_pi, st_pj] = p0;
                auto m_pk = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::env::names::BuildTables(g_pi, st_pj, m_pk))));
            });
        }));
    }))));
    auto [g6b_pq, st6b_pr] = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(prism_rtl::deref(g6_pl).mods_p), std::tuple{g6_pl, st6_pm}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, crate::check::types::St>>(std::tuple<std::tuple<G, crate::check::types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, crate::check::types::St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [g_pn, st_po] = p0;
                auto m_pp = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::env::decls::ConvertTypes(g_pn, st_po, m_pp))));
            });
        }));
    }))));
    auto [g7_pv, st7_p10] = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(prism_rtl::deref(g6b_pq).mods_p), std::tuple{g6b_pq, st6b_pr}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, crate::check::types::St>>(std::tuple<std::tuple<G, crate::check::types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, crate::check::types::St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [g_ps, st_pt] = p0;
                auto m_pu = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::env::decls::ConvertDecls(g_ps, st_pt, m_pu))));
            });
        }));
    }))));
    auto g8_p6 = crate::check::env::traits::derived_impls_f(g7_pv);
    auto st8_p7 = crate::check::env::traits::coherence_f(g8_p6, crate::check::env::traits::derived_dynamics_f(g8_p6, st7_p10));
    return std::tuple{g8_p6, st8_p7};
}


prism_rtl::Turn<std::tuple<G, crate::check::types::St>> BuildG::cycle() const {
    const auto& srcs_p0 = this->srcs_p0;
    const auto& trees_p1 = this->trees_p1;
    auto g0_p2 = G{.mods_p = Map<Text, ModInfo>{}, .types_p = Map<Text, TyInfo>{}, .ctors_p = Map<Text, CtorInfo>{}, .tags_p = Map<Text, TagInfo>{}, .families_p = Map<Text, Array<Text>>{}, .fam_owner_p = Map<Text, Text>{}, .vals_p = Map<Text, ValInfo>{}, .traits_p = Map<Text, TraitInfo>{}, .impls_p = Map<Text, Array<ImplInfo>>{}, .bare_p = Map<Text, Map<Text, Array<Text>>>{}, .bare_types_p = Map<Text, Map<Text, Array<Text>>>{}, .bare_traits_p = Map<Text, Map<Text, Array<Text>>>{}, .srcs_p = srcs_p0, .defs_p = Array<Def>{}, .program_row_p = crate::check::types::empty_row_p(), .elem_fams_p = Array<Text>{}, .root_module_o = std::optional<Text>{}, .app_root_p = app_root_f(srcs_p0, trees_p1), .fn_at_p = Map<Text, Nat>{}, .prelude_from_p = crate::prelude::len(trees_p1)};
    auto st0_p3 = crate::check::types::new_st_f(Nat(0u));
    auto [g1_pb, st1_pc] = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(trees_p1)), std::tuple{g0_p2, st0_p3}, [&](const std::tuple<G, crate::check::types::St>& _p0, const Nat& i_pa) {
        auto&& g_p8 = std::get<0>(_p0);
        auto&& st_p9 = std::get<1>(_p0);
        return add_module_f(g_p8, st_p9, i_pa, crate::prelude::or_(crate::prelude::index(trees_p1, i_pa), empty_module_p()));
    });
    auto g2_p4 = add_builtins_f(g1_pb);
    return crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::keys(prism_rtl::deref(g2_p4).mods_p), std::tuple{g2_p4, st1_pc}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, crate::check::types::St>>(std::tuple<std::tuple<G, crate::check::types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, crate::check::types::St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [g_pd, st_pe] = p0;
                auto m_pf = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::env::names::CollectNames(g_pd, st_pe, m_pf))));
            });
        }));
    }))), [=](std::tuple<G, crate::check::types::St> fold_5904) {
        return ({
            auto [g3_pg, st3_ph] = fold_5904;
            auto g4_p5 = ({
                G this_ = g3_pg;
                this_.program_row_p = crate::check::env::names::program_row_f(this_);
                (std::move(this_));
            });
            (crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::keys(prism_rtl::deref(g4_p5).mods_p), std::tuple{g4_p5, st3_ph}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, crate::check::types::St>>(std::tuple<std::tuple<G, crate::check::types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, crate::check::types::St>, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto [g_pi, st_pj] = p0;
                    auto m_pk = p1;
                    (prism_rtl::more(prism_rtl::rc(crate::check::env::names::BuildTables(g_pi, st_pj, m_pk))));
                });
            }));
        }))), [=](std::tuple<G, crate::check::types::St> fold_6061) {
            return ({
                auto [g6_pl, st6_pm] = fold_6061;
                (crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::keys(prism_rtl::deref(g6_pl).mods_p), std::tuple{g6_pl, st6_pm}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, crate::check::types::St>>(std::tuple<std::tuple<G, crate::check::types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, crate::check::types::St>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto [g_pn, st_po] = p0;
                        auto m_pp = p1;
                        (prism_rtl::more(prism_rtl::rc(crate::check::env::decls::ConvertTypes(g_pn, st_po, m_pp))));
                    });
                }));
            }))), [=](std::tuple<G, crate::check::types::St> fold_6156) {
                return ({
                    auto [g6b_pq, st6b_pr] = fold_6156;
                    (crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::keys(prism_rtl::deref(g6b_pq).mods_p), std::tuple{g6b_pq, st6b_pr}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, crate::check::types::St>>(std::tuple<std::tuple<G, crate::check::types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, crate::check::types::St>, Text> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return crate::prelude::entered(crate::prelude::once_job([=]() {
                        return ({
                            auto [g_ps, st_pt] = p0;
                            auto m_pu = p1;
                            (prism_rtl::more(prism_rtl::rc(crate::check::env::decls::ConvertDecls(g_ps, st_pt, m_pu))));
                        });
                    }));
                }))), [=](std::tuple<G, crate::check::types::St> fold_6250) {
                    return ({
                        auto [g7_pv, st7_p10] = fold_6250;
                        auto g8_p6 = crate::check::env::traits::derived_impls_f(g7_pv);
                        (crate::prelude::call_then(crate::check::env::traits::start_coherence_f(g8_p6, crate::check::env::traits::derived_dynamics_f(g8_p6, st7_p10)), [=](crate::check::types::St coherence_f_6368) {
                        return ({
                            auto st8_p7 = coherence_f_6368;
                            (prism_rtl::finished(std::tuple{g8_p6, st8_p7}));
                        });
                    }));
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start BuildG, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, crate::check::types::St>> start_build_g_f(Array<crate::check::errors::Src> srcs_p0, Array<crate::syntax::Module> trees_p1) {
    return prism_rtl::make_rc<BuildG>(srcs_p0, trees_p1);
}


/// let emptyModule
crate::syntax::Module empty_module_p() {
    return crate::syntax::Module{.name_o = std::optional<crate::syntax::QualName>{}, .emit_row_o = std::optional<crate::syntax::Row_>{}, .mods_p = Array<crate::syntax::ModLine>{}, .uses_p = Array<crate::syntax::Use>{}, .decls_p = Array<crate::syntax::decls::Decl>{}, .template_o = std::optional<crate::syntax::Template>{}, .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}};
}


/// ModName: fn Module -> Text
Text mod_name_f(const crate::syntax::Module& m_p0) {
    auto&& _m = m_p0.name_o;
    if (prism_rtl::is_some(_m)) {
        auto&& q_p1 = prism_rtl::some_of(_m);
        return dotted_f(prism_rtl::deref(q_p1).path_p);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// AppRoot: fn [Src], [Module] -> Bool
bool app_root_f(const Array<crate::check::errors::Src>& srcs_p0, const Array<crate::syntax::Module>& trees_p1) {
    return crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(trees_p1)), false, [&](const bool& seen_p2, const Nat& i_p3) {
        return ({
            auto t_p4 = crate::prelude::or_(crate::prelude::index(trees_p1, i_p3), empty_module_p());
            auto name_p5 = mod_name_f(t_p4);
            name_p5 == Text::lit("App")
            ? false
            : (name_p5 == Text::lit("")) && (prism_rtl::deref(crate::check::errors::seg_at_f(crate::prelude::or_(crate::prelude::index(srcs_p0, i_p3), crate::check::errors::mk_src_f(Text::lit(""), Text::lit(""))), Nat(0u))).role_p != Text::lit("loose"))
            ? true
            : prism_rtl::deref(seen_p2);
        });
    });
}


/// UseName: fn G, Text -> Text
Text use_name_f(const G& g_p0, const Text& u_p1) {
    return g_p0.app_root_p && (u_p1 == Text::lit("App")) ? Text::lit("") : u_p1;
}


/// QualModule: fn G, [Text] -> Text
Text qual_module_f(const G& g_p0, const Array<Text>& parts_p1) {
    return use_name_f(g_p0, dotted_f(parts_p1));
}


/// AddModule: fn G, St, Nat, Module -> ((G, St))
std::tuple<G, crate::check::types::St> add_module_f(const G& g_p0, const crate::check::types::St& st_p1, const Nat& i_p2, const crate::syntax::Module& tree_p3) {
    auto name_p4 = mod_name_f(tree_p3);
    auto s_p5 = ({
        crate::check::types::St this_ = st_p1;
        this_.file_p = i_p2;
        (std::move(this_));
    });
    return has_key_f(g_p0.mods_p, name_p4)
        ? ({
        auto what_p6 = name_p4 == Text::lit("")
            ? Text::lit("two files have no `module` line")
            : prism_rtl::cat("two files declare `module ", name_p4, "`");
        std::tuple{g_p0, crate::check::types::recording::err_f(s_p5, Text::lit("collision"), tree_p3.span_p, what_p6)};
    })
        : ({
        auto info_p7 = ModInfo{.name_p = name_p4, .file_p = i_p2, .emit_rw_p = crate::check::types::empty_row_p(), .row_var_p = Text::lit(""), .uses_p = crate::prelude::each(tree_p3.uses_p, [&](const crate::syntax::Use& u_p9) { return std::tuple{use_name_f(g_p0, dotted_f(prism_rtl::deref(prism_rtl::deref(u_p9).target_p).path_p)), prism_rtl::deref(u_p9).star_p}; }), .root_p = name_p4 == Text::lit(""), .tree_p = tree_p3};
        auto g2_p8 = ({
            G this_ = g_p0;
            this_.mods_p = crate::prelude::insert(this_.mods_p, name_p4, info_p7);
            if (name_p4 == Text::lit("")) {
                this_.root_module_o = std::optional(Text::lit(""));
            }
            (std::move(this_));
        });
        std::tuple{g2_p8, s_p5};
    });
}


/// AddBuiltins: fn G -> G
G add_builtins_f(const G& g_p0) {
    auto bool_ctor_f1 = static_cast<Fn<CtorInfo(const Text&, const Nat&)>>(prism_rtl::rc([=](const Text& n_p6, const Nat& i_p7) { return CtorInfo{.name_p = n_p6, .owner_p = Text::lit("Bool"), .params_p = Array<Text>{}, .args_p = Array<crate::check::types::Ty>{}, .fields_p = Array<Text>{}, .ty_p = crate::check::types::t_bool_p(), .index_p = i_p7}; }));
    auto pre_p2 = crate::check::types::Scheme{.qs_p = Array(std::vector{Text::lit("a")}), .plain_qs_p = Array<Text>{}, .rqs_p = Array<Text>{}, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = Array<std::tuple<Text, Text>>{}, .ty_p = crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyQ{Text::lit("a")}))})};
    auto numbered_p3 = crate::check::types::schemes::mono_f(crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{crate::check::types::t_nat_p()}), prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Buffer"), Array(std::vector{crate::check::types::t_nat_p()})}))}));
    auto buf_empty_p4 = crate::check::types::Scheme{.qs_p = Array(std::vector{Text::lit("a")}), .plain_qs_p = Array<Text>{}, .rqs_p = Array<Text>{}, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = Array<std::tuple<Text, Text>>{}, .ty_p = crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Buffer"), Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyQ{Text::lit("a")})})})};
    auto tab_empty_p5 = crate::check::types::Scheme{.qs_p = Array(std::vector{Text::lit("k"), Text::lit("v")}), .plain_qs_p = Array<Text>{}, .rqs_p = Array<Text>{}, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = Array<std::tuple<Text, Text>>{}, .ty_p = crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Table"), Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyQ{Text::lit("k")}), crate::check::types::Ty(crate::check::types::Ty::TyQ{Text::lit("v")})})})};
    G this_ = g_p0;
    this_.ctors_p = crate::prelude::insert(crate::prelude::insert(this_.ctors_p, Text::lit("True"), bool_ctor_f1(Text::lit("True"), Nat(0u))), Text::lit("False"), bool_ctor_f1(Text::lit("False"), Nat(1u)));
    this_.vals_p = crate::prelude::insert(this_.vals_p, Text::lit("Prelude.never"), builtin_f(Text::lit("Prelude.never"), pre_p2));
    this_.vals_p = crate::prelude::insert(this_.vals_p, Text::lit("Buffer.Numbered"), builtin_f(Text::lit("Buffer.Numbered"), numbered_p3));
    this_.vals_p = crate::prelude::insert(this_.vals_p, Text::lit("Buffer.Empty"), builtin_f(Text::lit("Buffer.Empty"), buf_empty_p4));
    this_.vals_p = crate::prelude::insert(this_.vals_p, Text::lit("Table.Empty"), builtin_f(Text::lit("Table.Empty"), tab_empty_p5));
    return this_;
}


/// Builtin: fn Text, Scheme -> ValInfo
ValInfo builtin_f(const Text& qk_p0, const crate::check::types::Scheme& sc_p1) {
    return ValInfo{.qk_p = qk_p0, .scheme_p = sc_p1, .sort_p = Text::lit("builtin"), .has_sig_p = true, .home_p = Text::lit("Prelude"), .file_p = Nat(0u), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}};
}

}  // namespace crate::check::env
