// The module `Check.Env`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/env/module.hpp>
#include <check/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Env`, from `target/bootstrap/cpp-src/prismc/check/env/mod.prism`.
namespace crate::check::env {

bool CtorInfo::operator==(const CtorInfo& o) const { return name == o.name && owner == o.owner && params == o.params && args == o.args && fields == o.fields && ty == o.ty && index == o.index; }

void CtorInfo::show(Printer& p) const {
    p.record("CtorInfo", {{"name", name}, {"owner", owner}, {"params", params}, {"args", args}, {"fields", fields}, {"ty", ty}, {"index", index}});
}

Pod CtorInfo::to_pod() const {
    return Pod::record("CtorInfo", {{"name", prism_rtl::to_pod(name)}, {"owner", prism_rtl::to_pod(owner)}, {"params", prism_rtl::to_pod(params)}, {"args", prism_rtl::to_pod(args)}, {"fields", prism_rtl::to_pod(fields)}, {"ty", prism_rtl::to_pod(ty)}, {"index", prism_rtl::to_pod(index)}});
}

Result<CtorInfo> CtorInfo::from_pod(const Pod& whole) {
    return CtorInfo{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .owner = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "owner")))), .params = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "params")))), .args = TRY(prism_rtl::from_pod<Array<crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "args")))), .fields = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "fields")))), .ty = TRY(prism_rtl::from_pod<crate::check::types::Ty>(TRY(crate::prelude::field(whole, "ty")))), .index = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "index"))))};
}


void Def::show(Printer& p) const {
    p.record("Def", {{"qk", qk}, {"name", name}, {"home", home}, {"file", file}, {"span", span}, {"body", body}});
}

Pod Def::to_pod() const {
    return Pod::record("Def", {{"qk", prism_rtl::to_pod(qk)}, {"name", prism_rtl::to_pod(name)}, {"home", prism_rtl::to_pod(home)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}, {"body", prism_rtl::to_pod(body)}});
}

Result<Def> Def::from_pod(const Pod& whole) {
    return Def{.qk = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "qk")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .body = TRY(prism_rtl::from_pod<DefBody>(TRY(crate::prelude::field(whole, "body"))))};
}


bool DefBody::DbFn::operator==(const DbFn& o) const { return a0 == o.a0; }

bool DefBody::DbMethod::operator==(const DbMethod& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool DefBody::DbDefault::operator==(const DbDefault& o) const { return a0 == o.a0 && a1 == o.a1; }

void DefBody::show(Printer& p) const {
    if (auto c = std::get_if<DbFn>(&cases())) p.choice("DbFn", {c->a0});
    else if (auto c = std::get_if<DbLet>(&cases())) p.choice("DbLet", {c->a0});
    else if (auto c = std::get_if<DbWidget>(&cases())) p.choice("DbWidget", {c->a0});
    else if (auto c = std::get_if<DbMethod>(&cases())) p.choice("DbMethod", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<DbDefault>(&cases())) p.choice("DbDefault", {c->a0, c->a1});
    else if (auto c = std::get_if<DbCheck>(&cases())) p.choice("DbCheck", {c->a0});
    else if (auto c = std::get_if<DbTest>(&cases())) p.choice("DbTest", {c->a0});
}

Pod DefBody::to_pod() const {
    return std::holds_alternative<DbFn>(cases()) ? Pod::choice("DbFn", {prism_rtl::to_pod(std::get<DbFn>(cases()).a0)})
        : std::holds_alternative<DbLet>(cases()) ? Pod::choice("DbLet", {prism_rtl::to_pod(std::get<DbLet>(cases()).a0)})
        : std::holds_alternative<DbWidget>(cases()) ? Pod::choice("DbWidget", {prism_rtl::to_pod(std::get<DbWidget>(cases()).a0)})
        : std::holds_alternative<DbMethod>(cases()) ? Pod::choice("DbMethod", {prism_rtl::to_pod(std::get<DbMethod>(cases()).a0), prism_rtl::to_pod(std::get<DbMethod>(cases()).a1), prism_rtl::to_pod(std::get<DbMethod>(cases()).a2)})
        : std::holds_alternative<DbDefault>(cases()) ? Pod::choice("DbDefault", {prism_rtl::to_pod(std::get<DbDefault>(cases()).a0), prism_rtl::to_pod(std::get<DbDefault>(cases()).a1)})
        : std::holds_alternative<DbCheck>(cases()) ? Pod::choice("DbCheck", {prism_rtl::to_pod(std::get<DbCheck>(cases()).a0)})
        : std::holds_alternative<DbTest>(cases()) ? Pod::choice("DbTest", {prism_rtl::to_pod(std::get<DbTest>(cases()).a0)})
        : Pod();
}

Result<DefBody> DefBody::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "DbFn" && c->args.size() == 1) return DefBody(DbFn{TRY(prism_rtl::from_pod<Array<crate::syntax::decls::FnClause>>(c->args[0]))});
        if (c->ctor == "DbLet" && c->args.size() == 1) return DefBody(DbLet{TRY(prism_rtl::from_pod<crate::syntax::decls::LetDecl>(c->args[0]))});
        if (c->ctor == "DbWidget" && c->args.size() == 1) return DefBody(DbWidget{TRY(prism_rtl::from_pod<crate::syntax::decls::WidgetDecl>(c->args[0]))});
        if (c->ctor == "DbMethod" && c->args.size() == 3) return DefBody(DbMethod{TRY(prism_rtl::from_pod<Array<crate::syntax::decls::FnClause>>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<ImplInfo>(c->args[2]))});
        if (c->ctor == "DbDefault" && c->args.size() == 2) return DefBody(DbDefault{TRY(prism_rtl::from_pod<Array<crate::syntax::decls::FnClause>>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "DbCheck" && c->args.size() == 1) return DefBody(DbCheck{TRY(prism_rtl::from_pod<crate::syntax::decls::CheckDecl>(c->args[0]))});
        if (c->ctor == "DbTest" && c->args.size() == 1) return DefBody(DbTest{TRY(prism_rtl::from_pod<crate::syntax::decls::TestDecl>(c->args[0]))});
    }
    return mismatch<DefBody>("a DefBody", p);
}


bool G::operator==(const G& o) const { return mods == o.mods && types == o.types && ctors == o.ctors && tags == o.tags && families == o.families && fam_owner == o.fam_owner && vals == o.vals && traits == o.traits && impls == o.impls && bare == o.bare && bare_types == o.bare_types && bare_traits == o.bare_traits && srcs == o.srcs && defs == o.defs && program_row == o.program_row && elem_fams == o.elem_fams && root_module == o.root_module && app_root == o.app_root && fn_at == o.fn_at && prelude_from == o.prelude_from; }

void G::show(Printer& p) const {
    p.record("G", {{"mods", mods}, {"types", types}, {"ctors", ctors}, {"tags", tags}, {"families", families}, {"fam_owner", fam_owner}, {"vals", vals}, {"traits", traits}, {"impls", impls}, {"bare", bare}, {"bare_types", bare_types}, {"bare_traits", bare_traits}, {"srcs", srcs}, {"defs", defs}, {"program_row", program_row}, {"elem_fams", elem_fams}, {"root_module", root_module}, {"app_root", app_root}, {"fn_at", fn_at}, {"prelude_from", prelude_from}});
}

Pod G::to_pod() const {
    return Pod::record("G", {{"mods", prism_rtl::to_pod(mods)}, {"types", prism_rtl::to_pod(types)}, {"ctors", prism_rtl::to_pod(ctors)}, {"tags", prism_rtl::to_pod(tags)}, {"families", prism_rtl::to_pod(families)}, {"fam_owner", prism_rtl::to_pod(fam_owner)}, {"vals", prism_rtl::to_pod(vals)}, {"traits", prism_rtl::to_pod(traits)}, {"impls", prism_rtl::to_pod(impls)}, {"bare", prism_rtl::to_pod(bare)}, {"bare_types", prism_rtl::to_pod(bare_types)}, {"bare_traits", prism_rtl::to_pod(bare_traits)}, {"srcs", prism_rtl::to_pod(srcs)}, {"defs", prism_rtl::to_pod(defs)}, {"program_row", prism_rtl::to_pod(program_row)}, {"elem_fams", prism_rtl::to_pod(elem_fams)}, {"root_module", prism_rtl::to_pod(root_module)}, {"app_root", prism_rtl::to_pod(app_root)}, {"fn_at", prism_rtl::to_pod(fn_at)}, {"prelude_from", prism_rtl::to_pod(prelude_from)}});
}

Result<G> G::from_pod(const Pod& whole) {
    return G{.mods = TRY(prism_rtl::from_pod<Map<Text, ModInfo>>(TRY(crate::prelude::field(whole, "mods")))), .types = TRY(prism_rtl::from_pod<Map<Text, TyInfo>>(TRY(crate::prelude::field(whole, "types")))), .ctors = TRY(prism_rtl::from_pod<Map<Text, CtorInfo>>(TRY(crate::prelude::field(whole, "ctors")))), .tags = TRY(prism_rtl::from_pod<Map<Text, TagInfo>>(TRY(crate::prelude::field(whole, "tags")))), .families = TRY(prism_rtl::from_pod<Map<Text, Array<Text>>>(TRY(crate::prelude::field(whole, "families")))), .fam_owner = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "fam_owner")))), .vals = TRY(prism_rtl::from_pod<Map<Text, ValInfo>>(TRY(crate::prelude::field(whole, "vals")))), .traits = TRY(prism_rtl::from_pod<Map<Text, TraitInfo>>(TRY(crate::prelude::field(whole, "traits")))), .impls = TRY(prism_rtl::from_pod<Map<Text, Array<ImplInfo>>>(TRY(crate::prelude::field(whole, "impls")))), .bare = TRY(prism_rtl::from_pod<Map<Text, Map<Text, Array<Text>>>>(TRY(crate::prelude::field(whole, "bare")))), .bare_types = TRY(prism_rtl::from_pod<Map<Text, Map<Text, Array<Text>>>>(TRY(crate::prelude::field(whole, "bare_types")))), .bare_traits = TRY(prism_rtl::from_pod<Map<Text, Map<Text, Array<Text>>>>(TRY(crate::prelude::field(whole, "bare_traits")))), .srcs = TRY(prism_rtl::from_pod<Array<crate::check::errors::Src>>(TRY(crate::prelude::field(whole, "srcs")))), .defs = TRY(prism_rtl::from_pod<Array<Def>>(TRY(crate::prelude::field(whole, "defs")))), .program_row = TRY(prism_rtl::from_pod<crate::check::types::Rw>(TRY(crate::prelude::field(whole, "program_row")))), .elem_fams = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "elem_fams")))), .root_module = TRY(prism_rtl::from_pod<std::optional<Text>>(TRY(crate::prelude::field(whole, "root_module")))), .app_root = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "app_root")))), .fn_at = TRY(prism_rtl::from_pod<Map<Text, Nat>>(TRY(crate::prelude::field(whole, "fn_at")))), .prelude_from = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "prelude_from"))))};
}


bool ImplInfo::operator==(const ImplInfo& o) const { return cls == o.cls && head == o.head && qs == o.qs && bounds == o.bounds && home == o.home && file == o.file && span == o.span && derived == o.derived && assocs == o.assocs && methods == o.methods; }

void ImplInfo::show(Printer& p) const {
    p.record("ImplInfo", {{"cls", cls}, {"head", head}, {"qs", qs}, {"bounds", bounds}, {"home", home}, {"file", file}, {"span", span}, {"derived", derived}, {"assocs", assocs}, {"methods", methods}});
}

Pod ImplInfo::to_pod() const {
    return Pod::record("ImplInfo", {{"cls", prism_rtl::to_pod(cls)}, {"head", prism_rtl::to_pod(head)}, {"qs", prism_rtl::to_pod(qs)}, {"bounds", prism_rtl::to_pod(bounds)}, {"home", prism_rtl::to_pod(home)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}, {"derived", prism_rtl::to_pod(derived)}, {"assocs", prism_rtl::to_pod(assocs)}, {"methods", prism_rtl::to_pod(methods)}});
}

Result<ImplInfo> ImplInfo::from_pod(const Pod& whole) {
    return ImplInfo{.cls = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "cls")))), .head = TRY(prism_rtl::from_pod<crate::check::types::Ty>(TRY(crate::prelude::field(whole, "head")))), .qs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "qs")))), .bounds = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "bounds")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .derived = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "derived")))), .assocs = TRY(prism_rtl::from_pod<Array<std::tuple<Text, crate::check::types::Ty>>>(TRY(crate::prelude::field(whole, "assocs")))), .methods = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "methods"))))};
}


void ModInfo::show(Printer& p) const {
    p.record("ModInfo", {{"name", name}, {"file", file}, {"emit_rw", emit_rw}, {"row_var", row_var}, {"uses", uses}, {"root", root}, {"tree", tree}});
}

Pod ModInfo::to_pod() const {
    return Pod::record("ModInfo", {{"name", prism_rtl::to_pod(name)}, {"file", prism_rtl::to_pod(file)}, {"emit_rw", prism_rtl::to_pod(emit_rw)}, {"row_var", prism_rtl::to_pod(row_var)}, {"uses", prism_rtl::to_pod(uses)}, {"root", prism_rtl::to_pod(root)}, {"tree", prism_rtl::to_pod(tree)}});
}

Result<ModInfo> ModInfo::from_pod(const Pod& whole) {
    return ModInfo{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .emit_rw = TRY(prism_rtl::from_pod<crate::check::types::Rw>(TRY(crate::prelude::field(whole, "emit_rw")))), .row_var = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "row_var")))), .uses = TRY(prism_rtl::from_pod<Array<std::tuple<Text, bool>>>(TRY(crate::prelude::field(whole, "uses")))), .root = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "root")))), .tree = TRY(prism_rtl::from_pod<crate::syntax::Module>(TRY(crate::prelude::field(whole, "tree"))))};
}


bool TagInfo::operator==(const TagInfo& o) const { return name == o.name && family == o.family && kind == o.kind && out == o.out && qs == o.qs && rqs == o.rqs && bounds == o.bounds && fields == o.fields && home == o.home && file == o.file && span == o.span; }

void TagInfo::show(Printer& p) const {
    p.record("TagInfo", {{"name", name}, {"family", family}, {"kind", kind}, {"out", out}, {"qs", qs}, {"rqs", rqs}, {"bounds", bounds}, {"fields", fields}, {"home", home}, {"file", file}, {"span", span}});
}

Pod TagInfo::to_pod() const {
    return Pod::record("TagInfo", {{"name", prism_rtl::to_pod(name)}, {"family", prism_rtl::to_pod(family)}, {"kind", prism_rtl::to_pod(kind)}, {"out", prism_rtl::to_pod(out)}, {"qs", prism_rtl::to_pod(qs)}, {"rqs", prism_rtl::to_pod(rqs)}, {"bounds", prism_rtl::to_pod(bounds)}, {"fields", prism_rtl::to_pod(fields)}, {"home", prism_rtl::to_pod(home)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TagInfo> TagInfo::from_pod(const Pod& whole) {
    return TagInfo{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .family = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "family")))), .kind = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "kind")))), .out = TRY(prism_rtl::from_pod<crate::check::types::Ty>(TRY(crate::prelude::field(whole, "out")))), .qs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "qs")))), .rqs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "rqs")))), .bounds = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "bounds")))), .fields = TRY(prism_rtl::from_pod<Array<std::tuple<Text, crate::check::types::Ty>>>(TRY(crate::prelude::field(whole, "fields")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void TraitInfo::show(Printer& p) const {
    p.record("TraitInfo", {{"name", name}, {"home", home}, {"param", param}, {"supers", supers}, {"methods", methods}, {"defaults", defaults}, {"assocs", assocs}, {"file", file}, {"span", span}});
}

Pod TraitInfo::to_pod() const {
    return Pod::record("TraitInfo", {{"name", prism_rtl::to_pod(name)}, {"home", prism_rtl::to_pod(home)}, {"param", prism_rtl::to_pod(param)}, {"supers", prism_rtl::to_pod(supers)}, {"methods", prism_rtl::to_pod(methods)}, {"defaults", prism_rtl::to_pod(defaults)}, {"assocs", prism_rtl::to_pod(assocs)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TraitInfo> TraitInfo::from_pod(const Pod& whole) {
    return TraitInfo{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .param = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "param")))), .supers = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "supers")))), .methods = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "methods")))), .defaults = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "defaults")))), .assocs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "assocs")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool TyBody::BRecord::operator==(const BRecord& o) const { return a0 == o.a0; }

bool TyBody::BChoice::operator==(const BChoice& o) const { return a0 == o.a0; }

void TyBody::show(Printer& p) const {
    if (auto c = std::get_if<BRecord>(&cases())) p.choice("BRecord", {c->a0});
    else if (auto c = std::get_if<BChoice>(&cases())) p.choice("BChoice", {c->a0});
    else if (auto c = std::get_if<BRowKind>(&cases())) p.choice("BRowKind", {});
    else if (auto c = std::get_if<BAlias>(&cases())) p.choice("BAlias", {c->a0});
    else if (auto c = std::get_if<BOpaque>(&cases())) p.choice("BOpaque", {});
    else if (auto c = std::get_if<BPrim>(&cases())) p.choice("BPrim", {});
}

Pod TyBody::to_pod() const {
    return std::holds_alternative<BRecord>(cases()) ? Pod::choice("BRecord", {prism_rtl::to_pod(std::get<BRecord>(cases()).a0)})
        : std::holds_alternative<BChoice>(cases()) ? Pod::choice("BChoice", {prism_rtl::to_pod(std::get<BChoice>(cases()).a0)})
        : std::holds_alternative<BRowKind>(cases()) ? Pod::choice("BRowKind", {})
        : std::holds_alternative<BAlias>(cases()) ? Pod::choice("BAlias", {prism_rtl::to_pod(std::get<BAlias>(cases()).a0)})
        : std::holds_alternative<BOpaque>(cases()) ? Pod::choice("BOpaque", {})
        : std::holds_alternative<BPrim>(cases()) ? Pod::choice("BPrim", {})
        : Pod();
}

Result<TyBody> TyBody::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "BRecord" && c->args.size() == 1) return TyBody(BRecord{TRY(prism_rtl::from_pod<Array<std::tuple<Text, crate::check::types::Ty>>>(c->args[0]))});
        if (c->ctor == "BChoice" && c->args.size() == 1) return TyBody(BChoice{TRY(prism_rtl::from_pod<Array<std::tuple<Text, Array<crate::check::types::Ty>>>>(c->args[0]))});
        if (c->ctor == "BRowKind" && c->args.size() == 0) return TyBody(BRowKind{});
        if (c->ctor == "BAlias" && c->args.size() == 1) return TyBody(BAlias{TRY(prism_rtl::from_pod<crate::check::types::Ty>(c->args[0]))});
        if (c->ctor == "BOpaque" && c->args.size() == 0) return TyBody(BOpaque{});
        if (c->ctor == "BPrim" && c->args.size() == 0) return TyBody(BPrim{});
    }
    return mismatch<TyBody>("a TyBody", p);
}


void TyInfo::show(Printer& p) const {
    p.record("TyInfo", {{"name", name}, {"home", home}, {"params", params}, {"body", body}, {"derives", derives}, {"file", file}, {"span", span}});
}

Pod TyInfo::to_pod() const {
    return Pod::record("TyInfo", {{"name", prism_rtl::to_pod(name)}, {"home", prism_rtl::to_pod(home)}, {"params", prism_rtl::to_pod(params)}, {"body", prism_rtl::to_pod(body)}, {"derives", prism_rtl::to_pod(derives)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TyInfo> TyInfo::from_pod(const Pod& whole) {
    return TyInfo{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .params = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "params")))), .body = TRY(prism_rtl::from_pod<TyBody>(TRY(crate::prelude::field(whole, "body")))), .derives = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "derives")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void ValInfo::show(Printer& p) const {
    p.record("ValInfo", {{"qk", qk}, {"scheme", scheme}, {"sort", sort}, {"has_sig", has_sig}, {"home", home}, {"file", file}, {"span", span}});
}

Pod ValInfo::to_pod() const {
    return Pod::record("ValInfo", {{"qk", prism_rtl::to_pod(qk)}, {"scheme", prism_rtl::to_pod(scheme)}, {"sort", prism_rtl::to_pod(sort)}, {"has_sig", prism_rtl::to_pod(has_sig)}, {"home", prism_rtl::to_pod(home)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}});
}

Result<ValInfo> ValInfo::from_pod(const Pod& whole) {
    return ValInfo{.qk = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "qk")))), .scheme = TRY(prism_rtl::from_pod<crate::check::types::Scheme>(TRY(crate::prelude::field(whole, "scheme")))), .sort = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "sort")))), .has_sig = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "has_sig")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


/// IsRegexType: fn Text -> Bool
bool is_regex_type(const Text& n_p0) {
    return (n_p0 == Text::lit("Regex")) || (n_p0 == Text::lit("RegexReplacement"));
}


/// IsPrimType: fn Text -> Bool
bool is_prim_type(const Text& n_p0) {
    return crate::check::types::has_text(Array(std::vector{Text::lit("Bool"), Text::lit("unit"), Text::lit("Char"), Text::lit("Text"), Text::lit("Nat"), Text::lit("Int"), Text::lit("U8"), Text::lit("Float"), Text::lit("Path"), Text::lit("Duration"), Text::lit("Cursor"), Text::lit("Regex"), Text::lit("RegexReplacement")}), n_p0);
}


/// QualKey: fn Text, Text -> Text
Text qual_key(const Text& m_p0, const Text& name_p1) {
    return m_p0 == Text::lit("") ? name_p1 : prism_rtl::cat(m_p0, ".", name_p1);
}


/// Dotted: fn [Text] -> Text
Text dotted(const Array<Text>& parts_p0) {
    return crate::syntax::lexer::chars::join(parts_p0, Text::lit("."));
}


/// SNameKey: fn SName -> Text
Text sname_key(const crate::syntax::SName& n_p0) {
    return prism_rtl::cat(n_p0.sigils, dotted(n_p0.path_));
}


/// DefNameText: fn DefName -> Text
Text def_name_text(const crate::syntax::decls::DefName& def_name0) {
    if (prism_rtl::is<crate::syntax::decls::DefName::DefSName>(def_name0)) {
        auto&& n_p0 = prism_rtl::as<crate::syntax::decls::DefName::DefSName>(def_name0).a0;
        return sname_key(n_p0);
    }
    if (prism_rtl::is<crate::syntax::decls::DefName::DefOp>(def_name0)) {
        auto&& o_p1 = prism_rtl::as<crate::syntax::decls::DefName::DefOp>(def_name0).a0;
        return o_p1;
    }
    prism_rtl::unreachable("no arm matched");
}


/// DefNameSpan: fn DefName -> Range
crate::syntax::Range def_name_span(const crate::syntax::decls::DefName& def_name0) {
    if (prism_rtl::is<crate::syntax::decls::DefName::DefSName>(def_name0)) {
        auto&& n_p0 = prism_rtl::as<crate::syntax::decls::DefName::DefSName>(def_name0).a0;
        return prism_rtl::deref(n_p0).span;
    }
    if (prism_rtl::is<crate::syntax::decls::DefName::DefOp>(def_name0)) {
        auto&& r_p1 = prism_rtl::as<crate::syntax::decls::DefName::DefOp>(def_name0).a1;
        return r_p1;
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsLowerText: fn Text -> Bool
bool is_lower_text(const Text& t_p0) {
    return crate::syntax::lexer::chars::is_lower(crate::syntax::lexer::chars::head(t_p0));
}


/// IsUpperText: fn Text -> Bool
bool is_upper_text(const Text& t_p0) {
    return crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::head(t_p0));
}


/// BuildG: unbounded fn [Src], [Module] -> ((G, St))
std::tuple<G, crate::check::types::St> build_g(const Array<crate::check::errors::Src>& srcs_p0, const Array<crate::syntax::Module>& trees_p1) {
    auto g0_p2 = G{.mods = Map<Text, ModInfo>{}, .types = Map<Text, TyInfo>{}, .ctors = Map<Text, CtorInfo>{}, .tags = Map<Text, TagInfo>{}, .families = Map<Text, Array<Text>>{}, .fam_owner = Map<Text, Text>{}, .vals = Map<Text, ValInfo>{}, .traits = Map<Text, TraitInfo>{}, .impls = Map<Text, Array<ImplInfo>>{}, .bare = Map<Text, Map<Text, Array<Text>>>{}, .bare_types = Map<Text, Map<Text, Array<Text>>>{}, .bare_traits = Map<Text, Map<Text, Array<Text>>>{}, .srcs = srcs_p0, .defs = Array<Def>{}, .program_row = crate::check::types::empty_row(), .elem_fams = Array<Text>{}, .root_module = std::optional<Text>{}, .app_root = app_root(srcs_p0, trees_p1), .fn_at = Map<Text, Nat>{}, .prelude_from = len(trees_p1)};
    auto st0_p3 = crate::check::types::new_st(Nat(0u));
    auto [g1_pb, st1_pc] = fold(crate::check::errors::range0(len(trees_p1)), std::tuple{g0_p2, st0_p3}, [&](const std::tuple<G, crate::check::types::St>& _p0, const Nat& i_pa) {
        auto&& g_p8 = std::get<0>(_p0);
        auto&& st_p9 = std::get<1>(_p0);
        return add_module(g_p8, st_p9, i_pa, or_(index(trees_p1, i_pa), empty_module()));
    });
    auto g2_p4 = add_builtins(g1_pb);
    auto [g3_pg, st3_ph] = run_to_end(fold_job(keys(prism_rtl::deref(g2_p4).mods), std::tuple{g2_p4, st1_pc}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, crate::check::types::St>>(std::tuple<std::tuple<G, crate::check::types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, crate::check::types::St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [g_pd, st_pe] = p0;
                auto m_pf = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::env::names::CollectNames(g_pd, st_pe, m_pf))));
            });
        }));
    }))));
    auto g4_p5 = ({
        G this_ = g3_pg;
        this_.program_row = crate::check::env::names::program_row(this_);
        (std::move(this_));
    });
    auto [g6_pl, st6_pm] = run_to_end(fold_job(keys(prism_rtl::deref(g4_p5).mods), std::tuple{g4_p5, st3_ph}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, crate::check::types::St>>(std::tuple<std::tuple<G, crate::check::types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, crate::check::types::St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [g_pi, st_pj] = p0;
                auto m_pk = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::env::names::BuildTables(g_pi, st_pj, m_pk))));
            });
        }));
    }))));
    auto [g6b_pq, st6b_pr] = run_to_end(fold_job(keys(prism_rtl::deref(g6_pl).mods), std::tuple{g6_pl, st6_pm}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, crate::check::types::St>>(std::tuple<std::tuple<G, crate::check::types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, crate::check::types::St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [g_pn, st_po] = p0;
                auto m_pp = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::env::decls::ConvertTypes(g_pn, st_po, m_pp))));
            });
        }));
    }))));
    auto [g7_pv, st7_p10] = run_to_end(fold_job(keys(prism_rtl::deref(g6b_pq).mods), std::tuple{g6b_pq, st6b_pr}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, crate::check::types::St>>(std::tuple<std::tuple<G, crate::check::types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, crate::check::types::St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [g_ps, st_pt] = p0;
                auto m_pu = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::env::decls::ConvertDecls(g_ps, st_pt, m_pu))));
            });
        }));
    }))));
    auto g8_p6 = crate::check::env::traits::derived_impls(g7_pv);
    auto st8_p7 = crate::check::env::traits::coherence(g8_p6, crate::check::env::traits::derived_dynamics(g8_p6, st7_p10));
    return std::tuple{g8_p6, st8_p7};
}


prism_rtl::Turn<std::tuple<G, crate::check::types::St>> BuildG::cycle() const {
    const auto& srcs_p0 = this->srcs_p0;
    const auto& trees_p1 = this->trees_p1;
    auto g0_p2 = G{.mods = Map<Text, ModInfo>{}, .types = Map<Text, TyInfo>{}, .ctors = Map<Text, CtorInfo>{}, .tags = Map<Text, TagInfo>{}, .families = Map<Text, Array<Text>>{}, .fam_owner = Map<Text, Text>{}, .vals = Map<Text, ValInfo>{}, .traits = Map<Text, TraitInfo>{}, .impls = Map<Text, Array<ImplInfo>>{}, .bare = Map<Text, Map<Text, Array<Text>>>{}, .bare_types = Map<Text, Map<Text, Array<Text>>>{}, .bare_traits = Map<Text, Map<Text, Array<Text>>>{}, .srcs = srcs_p0, .defs = Array<Def>{}, .program_row = crate::check::types::empty_row(), .elem_fams = Array<Text>{}, .root_module = std::optional<Text>{}, .app_root = app_root(srcs_p0, trees_p1), .fn_at = Map<Text, Nat>{}, .prelude_from = len(trees_p1)};
    auto st0_p3 = crate::check::types::new_st(Nat(0u));
    auto [g1_pb, st1_pc] = fold(crate::check::errors::range0(len(trees_p1)), std::tuple{g0_p2, st0_p3}, [&](const std::tuple<G, crate::check::types::St>& _p0, const Nat& i_pa) {
        auto&& g_p8 = std::get<0>(_p0);
        auto&& st_p9 = std::get<1>(_p0);
        return add_module(g_p8, st_p9, i_pa, or_(index(trees_p1, i_pa), empty_module()));
    });
    auto g2_p4 = add_builtins(g1_pb);
    return call_value(fold_job(keys(prism_rtl::deref(g2_p4).mods), std::tuple{g2_p4, st1_pc}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, crate::check::types::St>>(std::tuple<std::tuple<G, crate::check::types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, crate::check::types::St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [g_pd, st_pe] = p0;
                auto m_pf = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::env::names::CollectNames(g_pd, st_pe, m_pf))));
            });
        }));
    }))), [=](std::tuple<G, crate::check::types::St> fold_5901) {
        return ({
            auto [g3_pg, st3_ph] = fold_5901;
            auto g4_p5 = ({
                G this_ = g3_pg;
                this_.program_row = crate::check::env::names::program_row(this_);
                (std::move(this_));
            });
            call_value(fold_job(keys(prism_rtl::deref(g4_p5).mods), std::tuple{g4_p5, st3_ph}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, crate::check::types::St>>(std::tuple<std::tuple<G, crate::check::types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, crate::check::types::St>, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto [g_pi, st_pj] = p0;
                    auto m_pk = p1;
                    (prism_rtl::more(prism_rtl::rc(crate::check::env::names::BuildTables(g_pi, st_pj, m_pk))));
                });
            }));
        }))), [=](std::tuple<G, crate::check::types::St> fold_6058) {
            return ({
                auto [g6_pl, st6_pm] = fold_6058;
                call_value(fold_job(keys(prism_rtl::deref(g6_pl).mods), std::tuple{g6_pl, st6_pm}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, crate::check::types::St>>(std::tuple<std::tuple<G, crate::check::types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, crate::check::types::St>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto [g_pn, st_po] = p0;
                        auto m_pp = p1;
                        (prism_rtl::more(prism_rtl::rc(crate::check::env::decls::ConvertTypes(g_pn, st_po, m_pp))));
                    });
                }));
            }))), [=](std::tuple<G, crate::check::types::St> fold_6153) {
                return ({
                    auto [g6b_pq, st6b_pr] = fold_6153;
                    call_value(fold_job(keys(prism_rtl::deref(g6b_pq).mods), std::tuple{g6b_pq, st6b_pr}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, crate::check::types::St>>(std::tuple<std::tuple<G, crate::check::types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, crate::check::types::St>, Text> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto [g_ps, st_pt] = p0;
                            auto m_pu = p1;
                            (prism_rtl::more(prism_rtl::rc(crate::check::env::decls::ConvertDecls(g_ps, st_pt, m_pu))));
                        });
                    }));
                }))), [=](std::tuple<G, crate::check::types::St> fold_6247) {
                    return ({
                        auto [g7_pv, st7_p10] = fold_6247;
                        auto g8_p6 = crate::check::env::traits::derived_impls(g7_pv);
                        call_then(crate::check::env::traits::start_coherence(g8_p6, crate::check::env::traits::derived_dynamics(g8_p6, st7_p10)), [=](crate::check::types::St coherence_6365) {
                        return ({
                            auto st8_p7 = coherence_6365;
                            (prism_rtl::finished(std::tuple{g8_p6, st8_p7}));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start BuildG, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, crate::check::types::St>> start_build_g(Array<crate::check::errors::Src> srcs_p0, Array<crate::syntax::Module> trees_p1) {
    return prism_rtl::make_rc<BuildG>(srcs_p0, trees_p1);
}


/// let emptyModule
crate::syntax::Module empty_module() {
    return crate::syntax::Module{.name = std::optional<crate::syntax::QualName>{}, .emit_row = std::optional<crate::syntax::Row_>{}, .mods = Array<crate::syntax::ModLine>{}, .uses = Array<crate::syntax::Use>{}, .decls = Array<crate::syntax::decls::Decl>{}, .template_ = std::optional<crate::syntax::Template>{}, .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// ModName: fn Module -> Text
Text mod_name(const crate::syntax::Module& m_p0) {
    auto&& _m = m_p0.name;
    if (prism_rtl::is_some(_m)) {
        auto&& q_p1 = prism_rtl::some_of(_m);
        return dotted(q_p1->path_);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// AppRoot: fn [Src], [Module] -> Bool
bool app_root(const Array<crate::check::errors::Src>& srcs_p0, const Array<crate::syntax::Module>& trees_p1) {
    return fold(crate::check::errors::range0(len(trees_p1)), false, [&](const bool& seen_p2, const Nat& i_p3) {
        return ({
            auto t_p4 = or_(index(trees_p1, i_p3), empty_module());
            auto name_p5 = mod_name(t_p4);
            name_p5 == Text::lit("App")
            ? false
            : (name_p5 == Text::lit("")) && (prism_rtl::deref(crate::check::errors::seg_at(or_(index(srcs_p0, i_p3), crate::check::errors::mk_src(Text::lit(""), Text::lit(""))), Nat(0u))).role != Text::lit("loose"))
            ? true
            : prism_rtl::deref(seen_p2);
        });
    });
}


/// UseName: fn G, Text -> Text
Text use_name(const G& g_p0, const Text& u_p1) {
    return g_p0.app_root && (u_p1 == Text::lit("App")) ? Text::lit("") : u_p1;
}


/// QualModule: fn G, [Text] -> Text
Text qual_module(const G& g_p0, const Array<Text>& parts_p1) {
    return use_name(g_p0, dotted(parts_p1));
}


/// AddModule: fn G, St, Nat, Module -> ((G, St))
std::tuple<G, crate::check::types::St> add_module(const G& g_p0, const crate::check::types::St& st_p1, const Nat& i_p2, const crate::syntax::Module& tree_p3) {
    auto name_p4 = mod_name(tree_p3);
    auto s_p5 = ({
        crate::check::types::St this_ = st_p1;
        this_.file = i_p2;
        (std::move(this_));
    });
    return has_key(g_p0.mods, name_p4)
        ? ({
        auto what_p6 = name_p4 == Text::lit("")
            ? Text::lit("two files have no `module` line")
            : prism_rtl::cat("two files declare `module ", name_p4, "`");
        std::tuple{g_p0, crate::check::types::recording::err(s_p5, Text::lit("collision"), tree_p3.span, what_p6)};
    })
        : ({
        auto info_p7 = ModInfo{.name = name_p4, .file = i_p2, .emit_rw = crate::check::types::empty_row(), .row_var = Text::lit(""), .uses = each(tree_p3.uses, [&](const crate::syntax::Use& u_p9) { return std::tuple{use_name(g_p0, dotted(u_p9->target->path_)), prism_rtl::deref(u_p9).star}; }), .root = name_p4 == Text::lit(""), .tree = tree_p3};
        auto g2_p8 = ({
            G this_ = g_p0;
            this_.mods = insert(this_.mods, name_p4, info_p7);
            if (name_p4 == Text::lit("")) {
                this_.root_module = std::optional(Text::lit(""));
            }
            (std::move(this_));
        });
        std::tuple{g2_p8, s_p5};
    });
}


/// AddBuiltins: fn G -> G
G add_builtins(const G& g_p0) {
    auto bool_ctor_f1 = static_cast<Fn<CtorInfo(const Text&, const Nat&)>>(prism_rtl::rc([=](const Text& n_p6, const Nat& i_p7) { return CtorInfo{.name = n_p6, .owner = Text::lit("Bool"), .params = Array<Text>{}, .args = Array<crate::check::types::Ty>{}, .fields = Array<Text>{}, .ty = crate::check::types::t_bool(), .index = i_p7}; }));
    auto pre_p2 = crate::check::types::Scheme{.qs = Array(std::vector{Text::lit("a")}), .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyQ{Text::lit("a")}))})};
    auto numbered_p3 = crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{crate::check::types::t_nat()}), prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Buffer"), Array(std::vector{crate::check::types::t_nat()})}))}));
    auto buf_empty_p4 = crate::check::types::Scheme{.qs = Array(std::vector{Text::lit("a")}), .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Buffer"), Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyQ{Text::lit("a")})})})};
    auto tab_empty_p5 = crate::check::types::Scheme{.qs = Array(std::vector{Text::lit("k"), Text::lit("v")}), .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Table"), Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyQ{Text::lit("k")}), crate::check::types::Ty(crate::check::types::Ty::TyQ{Text::lit("v")})})})};
    G this_ = g_p0;
    this_.ctors = insert(insert(this_.ctors, Text::lit("True"), bool_ctor_f1(Text::lit("True"), Nat(0u))), Text::lit("False"), bool_ctor_f1(Text::lit("False"), Nat(1u)));
    this_.vals = insert(this_.vals, Text::lit("Prelude.never"), builtin(Text::lit("Prelude.never"), pre_p2));
    this_.vals = insert(this_.vals, Text::lit("Buffer.Numbered"), builtin(Text::lit("Buffer.Numbered"), numbered_p3));
    this_.vals = insert(this_.vals, Text::lit("Buffer.Empty"), builtin(Text::lit("Buffer.Empty"), buf_empty_p4));
    this_.vals = insert(this_.vals, Text::lit("Table.Empty"), builtin(Text::lit("Table.Empty"), tab_empty_p5));
    return this_;
}


/// Builtin: fn Text, Scheme -> ValInfo
ValInfo builtin(const Text& qk_p0, const crate::check::types::Scheme& sc_p1) {
    return ValInfo{.qk = qk_p0, .scheme = sc_p1, .sort = Text::lit("builtin"), .has_sig = true, .home = Text::lit("Prelude"), .file = Nat(0u), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}

}  // namespace crate::check::env
