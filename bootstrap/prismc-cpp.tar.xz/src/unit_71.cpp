// The module `Syntax.Parser.TestLanguage`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/parser/test_language/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Syntax.Parser.TestLanguage`, from `target/bootstrap/cpp-src/prismc/syntax/parser/test_language.prism`.
namespace crate::syntax::parser::test_language {

/// let deliveryWords
Array<Text> delivery_words_p() {
    return Array(std::vector{Text::lit("send"), Text::lit("click"), Text::lit("answer")});
}


/// IsDeliveryWord: fn Text -> Bool
bool is_delivery_word_f(const Text& w_p0) {
    return crate::prelude::fold(delivery_words_p(), false, [&](const bool& seen_p1, const Text& d_p2) { return prism_rtl::deref(seen_p1) || (d_p2 == w_p0); });
}


/// StepWord: fn Ps -> Text
Text step_word_f(const crate::syntax::parser::Ps& p_p0) {
    auto&& _m = crate::syntax::parser::kind_f(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if (((prism_rtl::deref(n_p1).sigils_p == Text::lit("")) && (crate::prelude::len(prism_rtl::deref(n_p1).path_p) == Nat(1u))) && (prism_rtl::deref(n_p1).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) {
            return crate::prelude::or_(crate::prelude::index(prism_rtl::deref(n_p1).path_p, Nat(0u)), Text::lit(""));
        }
    }
    {
        return Text::lit("");
    }
}


/// AtWord: fn Ps, Text -> Bool
bool at_word_f(const crate::syntax::parser::Ps& p_p0, const Text& w_p1) {
    return step_word_f(p_p0) == w_p1;
}


/// ParseCheckDecl: unbounded fn Ps -> ((CheckDecl, Ps))
std::tuple<crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps> parse_check_decl_f(const crate::syntax::parser::Ps& p0_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p0_p0);
    auto [name_p3, p1_p4] = crate::syntax::parser::parse_ident_f(crate::syntax::parser::adv_f(p0_p0));
    auto p2_p2 = crate::syntax::parser::expect_colon_f(p1_p4);
    return crate::syntax::parser::at_open_l_f(p2_p2)
        ? ({
        auto [lines_p5, q_p6] = crate::syntax::parser::layout_items_f(crate::syntax::parser::adv_f(p2_p2), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::CheckLine, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(start_parse_check_line_f(a0)); })));
        std::tuple{crate::syntax::decls::CheckDecl{.name_p = name_p3, .lines_p = lines_p5, .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_p6))}, q_p6};
    })
        : std::tuple{crate::syntax::decls::CheckDecl{.name_p = name_p3, .lines_p = Array<crate::syntax::decls::CheckLine>{}, .span_p = start_p1}, crate::syntax::parser::error_here_f(p2_p2, Text::lit("a `check` block\'s lines stand in an indented block"))};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps>> ParseCheckDecl::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    auto start_p1 = crate::syntax::parser::here_f(p0_p0);
    auto [name_p3, p1_p4] = crate::syntax::parser::parse_ident_f(crate::syntax::parser::adv_f(p0_p0));
    auto p2_p2 = crate::syntax::parser::expect_colon_f(p1_p4);
    return crate::syntax::parser::at_open_l_f(p2_p2)
        ? crate::prelude::call_then(crate::syntax::parser::start_layout_items_f(crate::syntax::parser::adv_f(p2_p2), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::CheckLine, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(start_parse_check_line_f(a0)); }))), [=](std::tuple<Array<crate::syntax::decls::CheckLine>, crate::syntax::parser::Ps> layout_items_f_1679) {
        return ({
            auto [lines_p5, q_p6] = layout_items_f_1679;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::CheckDecl{.name_p = name_p3, .lines_p = lines_p5, .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_p6))}, q_p6}));
        });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::decls::CheckDecl{.name_p = name_p3, .lines_p = Array<crate::syntax::decls::CheckLine>{}, .span_p = start_p1}, crate::syntax::parser::error_here_f(p2_p2, Text::lit("a `check` block\'s lines stand in an indented block"))});
}


/// `Start ParseCheckDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps>> start_parse_check_decl_f(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseCheckDecl>(p0_p0);
}


/// ParseCheckLine: unbounded fn Ps -> ((CheckLine, Ps))
std::tuple<crate::syntax::decls::CheckLine, crate::syntax::parser::Ps> parse_check_line_f(const crate::syntax::parser::Ps& p_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto [expr_p2, p1_p3] = crate::syntax::parser::expr::parse_rhs_expr_f(p_p0);
    auto [pattern_o4, q_p5] = crate::syntax::parser::at_op_f(p1_p3, Text::lit("=>"))
        ? optional_pattern_top_f(crate::syntax::parser::adv_f(p1_p3))
        : std::tuple{std::optional<crate::syntax::Pattern_>{}, p1_p3};
    return std::tuple{crate::syntax::decls::CheckLine{.expr_p = expr_p2, .pattern_o = pattern_o4, .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_p5))}, q_p5};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::CheckLine, crate::syntax::parser::Ps>> ParseCheckLine::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto p_p0x = p_p0;
    return crate::prelude::call_then(crate::syntax::parser::expr::start_parse_rhs_expr_f(p_p0x), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_f_2042) {
        return ({
            auto [expr_p2, p1_p3] = parse_rhs_expr_f_2042;
            auto [pattern_o4, q_p5] = crate::syntax::parser::at_op_f(p1_p3, Text::lit("=>"))
                ? optional_pattern_top_f(crate::syntax::parser::adv_f(p1_p3))
                : std::tuple{std::optional<crate::syntax::Pattern_>{}, p1_p3};
            (prism_rtl::finished(std::tuple{crate::syntax::decls::CheckLine{.expr_p = expr_p2, .pattern_o = pattern_o4, .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_p5))}, q_p5}));
        });
    });
}


/// `Start ParseCheckLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::CheckLine, crate::syntax::parser::Ps>> start_parse_check_line_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseCheckLine>(p_p0);
}


/// OptionalPatternTop: unbounded fn Ps -> ((?Pattern, Ps))
std::tuple<std::optional<crate::syntax::Pattern_>, crate::syntax::parser::Ps> optional_pattern_top_f(const crate::syntax::parser::Ps& p_p0) {
    auto [pat_p1, q_p2] = crate::syntax::parser::types::parse_pattern_f(p_p0, true);
    return std::tuple{std::optional(pat_p1), q_p2};
}


prism_rtl::Turn<std::tuple<std::optional<crate::syntax::Pattern_>, crate::syntax::parser::Ps>> OptionalPatternTop::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto p_p0x = p_p0;
    return crate::prelude::call_then(crate::syntax::parser::types::start_parse_pattern_f(p_p0x, true), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_f_2327) {
        return ({
            auto [pat_p1, q_p2] = parse_pattern_f_2327;
            (prism_rtl::finished(std::tuple{std::optional(pat_p1), q_p2}));
        });
    });
}


/// `Start OptionalPatternTop, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::Pattern_>, crate::syntax::parser::Ps>> start_optional_pattern_top_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<OptionalPatternTop>(p_p0);
}


/// ParseTestDecl: unbounded fn Ps -> ((TestDecl, Ps))
std::tuple<crate::syntax::decls::TestDecl, crate::syntax::parser::Ps> parse_test_decl_f(const crate::syntax::parser::Ps& p0_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p0_p0);
    auto [name_p3, p1_p4] = crate::syntax::parser::parse_ident_f(crate::syntax::parser::adv_f(p0_p0));
    auto fallback_p2 = crate::syntax::decls::TestDecl{.name_p = name_p3, .blueprint_p = crate::syntax::parser::decls::no_expr_p(), .seed_o = std::optional<Nat>{}, .steps_p = Array<crate::syntax::decls::TestStep>{}, .span_p = start_p1};
    return !crate::syntax::parser::at_comma_f(p1_p4)
        ? std::tuple{fallback_p2, crate::syntax::parser::error_here_f(p1_p4, Text::lit("a test names its blueprint: `test name, @blueprint:`"))}
        : ({
        auto [blueprint_p6, p2_p7] = crate::syntax::parser::expr::parse_arg_expr_f(crate::syntax::parser::adv_f(p1_p4));
        auto [seed_o8, p3_p9] = crate::syntax::parser::at_comma_f(p2_p7)
            ? parse_seed_f(crate::syntax::parser::adv_f(p2_p7))
            : std::tuple{std::optional<Nat>{}, p2_p7};
        auto p4_p5 = crate::syntax::parser::expect_colon_f(p3_p9);
        crate::syntax::parser::at_open_l_f(p4_p5)
        ? ({
        auto saved_pa = prism_rtl::deref(p4_p5).step_mode_p;
        auto [steps_pd, p5_pe] = crate::syntax::parser::layout_items_f(crate::syntax::parser::adv_f(p4_p5), ({
            auto saved_pax = std::move(saved_pa);
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::TestStep, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=, saved_pax = std::move(saved_pax)](crate::syntax::parser::Ps p0) {
            return ({
                auto saved_paxy = saved_pax;
                (crate::prelude::entered(crate::prelude::once_job([=, saved_paxy = std::move(saved_paxy)]() {
                return ({
                    auto s_pc = p0;
                    (prism_rtl::more(prism_rtl::rc(StepIn(s_pc, saved_paxy))));
                });
            })));
            });
        }));
        }));
        auto q_pb = crate::syntax::parser::with_step_mode_f(p5_pe, saved_pa);
        std::tuple{crate::syntax::decls::TestDecl{.name_p = name_p3, .blueprint_p = blueprint_p6, .seed_o = seed_o8, .steps_p = steps_pd, .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_pb))}, q_pb};
    })
        : std::tuple{fallback_p2, crate::syntax::parser::error_here_f(p4_p5, Text::lit("a test\'s steps stand in an indented block"))};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::TestDecl, crate::syntax::parser::Ps>> ParseTestDecl::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    auto start_p1 = crate::syntax::parser::here_f(p0_p0);
    auto [name_p3, p1_p4] = crate::syntax::parser::parse_ident_f(crate::syntax::parser::adv_f(p0_p0));
    auto fallback_p2 = crate::syntax::decls::TestDecl{.name_p = name_p3, .blueprint_p = crate::syntax::parser::decls::no_expr_p(), .seed_o = std::optional<Nat>{}, .steps_p = Array<crate::syntax::decls::TestStep>{}, .span_p = start_p1};
    return !crate::syntax::parser::at_comma_f(p1_p4)
        ? prism_rtl::finished(std::tuple{fallback_p2, crate::syntax::parser::error_here_f(p1_p4, Text::lit("a test names its blueprint: `test name, @blueprint:`"))})
        : crate::prelude::call_then(crate::syntax::parser::expr::start_parse_arg_expr_f(crate::syntax::parser::adv_f(p1_p4)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_arg_expr_f_2820) {
        return ({
            auto [blueprint_p6, p2_p7] = parse_arg_expr_f_2820;
            auto [seed_o8, p3_p9] = crate::syntax::parser::at_comma_f(p2_p7)
                ? parse_seed_f(crate::syntax::parser::adv_f(p2_p7))
                : std::tuple{std::optional<Nat>{}, p2_p7};
            auto p4_p5 = crate::syntax::parser::expect_colon_f(p3_p9);
            (crate::syntax::parser::at_open_l_f(p4_p5)
            ? ({
            auto saved_pa = prism_rtl::deref(p4_p5).step_mode_p;
            (crate::prelude::call_then(crate::syntax::parser::start_layout_items_f(crate::syntax::parser::adv_f(p4_p5), ({
            auto saved_pax = std::move(saved_pa);
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::TestStep, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=, saved_pax = std::move(saved_pax)](crate::syntax::parser::Ps p0) {
            return ({
                auto saved_paxy = saved_pax;
                (crate::prelude::entered(crate::prelude::once_job([=, saved_paxy = std::move(saved_paxy)]() {
                return ({
                    auto s_pc = p0;
                    (prism_rtl::more(prism_rtl::rc(StepIn(s_pc, saved_paxy))));
                });
            })));
            });
        }));
        })), [=](std::tuple<Array<crate::syntax::decls::TestStep>, crate::syntax::parser::Ps> layout_items_f_3045) {
            return ({
                auto [steps_pd, p5_pe] = layout_items_f_3045;
                auto q_pb = crate::syntax::parser::with_step_mode_f(p5_pe, saved_pa);
                (prism_rtl::finished(std::tuple{crate::syntax::decls::TestDecl{.name_p = name_p3, .blueprint_p = blueprint_p6, .seed_o = seed_o8, .steps_p = steps_pd, .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_pb))}, q_pb}));
            });
        }));
        })
            : prism_rtl::finished(std::tuple{fallback_p2, crate::syntax::parser::error_here_f(p4_p5, Text::lit("a test\'s steps stand in an indented block"))}));
        });
    });
}


/// `Start ParseTestDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::TestDecl, crate::syntax::parser::Ps>> start_parse_test_decl_f(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseTestDecl>(p0_p0);
}


/// ParseSeed: fn Ps -> ((?Nat, Ps))
std::tuple<std::optional<Nat>, crate::syntax::parser::Ps> parse_seed_f(const crate::syntax::parser::Ps& p_p0) {
    return !at_word_f(p_p0, Text::lit("seed"))
        ? std::tuple{std::optional<Nat>{}, crate::syntax::parser::error_here_f(p_p0, Text::lit("after the blueprint, a test takes only `seed n`"))}
        : ({
        auto p1_p1 = crate::syntax::parser::adv_f(p_p0);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<Nat>, crate::syntax::parser::Ps>> _v;
        auto&& _m = crate::syntax::parser::kind_f(p1_p1);
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m)) {
            auto&& m3527_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a0;
            auto&& text_p2 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a1;
            if (m3527_0_0 == Text::lit("")) {
                _v.set(std::tuple{std::optional(parse_nat_text_f(text_p2)), crate::syntax::parser::adv_f(p1_p1)});
                goto _done;
            }
        }
        {
            _v.set(std::tuple{std::optional<Nat>{}, crate::syntax::parser::error_here_f(p1_p1, Text::lit("`seed` takes a number"))});
            goto _done;
        }
    _done:
        _v.take();
    });
    });
}


/// StepIn: unbounded fn Ps, Bool -> ((TestStep, Ps))
std::tuple<crate::syntax::decls::TestStep, crate::syntax::parser::Ps> step_in_f(const crate::syntax::parser::Ps& p_p0, const bool& saved_p1) {
    auto [s_p2, q_p3] = parse_step_f(crate::syntax::parser::with_step_mode_f(p_p0, true));
    return std::tuple{s_p2, crate::syntax::parser::with_step_mode_f(q_p3, saved_p1)};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::TestStep, crate::syntax::parser::Ps>> StepIn::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& saved_p1 = this->saved_p1;
    auto [s_p2, q_p3] = parse_step_f(crate::syntax::parser::with_step_mode_f(p_p0, true));
    return prism_rtl::finished(std::tuple{s_p2, crate::syntax::parser::with_step_mode_f(q_p3, saved_p1)});
}


/// `Start StepIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::TestStep, crate::syntax::parser::Ps>> start_step_in_f(crate::syntax::parser::Ps p_p0, bool saved_p1) {
    return prism_rtl::make_rc<StepIn>(p_p0, saved_p1);
}


/// ParseStep: unbounded fn Ps -> ((TestStep, Ps))
std::tuple<crate::syntax::decls::TestStep, crate::syntax::parser::Ps> parse_step_f(const crate::syntax::parser::Ps& p0_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p0_p0);
    auto [withs_p2, p1_p3] = with_entries_f(p0_p0);
    auto [action_p4, p2_p5] = step_action_of_f(p1_p3, withs_p2);
    return prism_rtl::deref(p2_p5).bad_p
        ? std::tuple{crate::syntax::decls::TestStep{.withs_p = withs_p2, .action_p = action_p4, .checks_p = Array<crate::syntax::decls::TestCheck>{}, .span_p = start_p1}, p2_p5}
        : crate::syntax::parser::at_open_l_f(p2_p5)
        ? ({
        auto [checks_p6, q_p7] = crate::syntax::parser::layout_items_f(crate::syntax::parser::adv_f(p2_p5), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::TestCheck, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return crate::prelude::entered(start_parse_test_check_f(a0)); })));
        std::tuple{crate::syntax::decls::TestStep{.withs_p = withs_p2, .action_p = action_p4, .checks_p = checks_p6, .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_p7))}, q_p7};
    })
        : crate::syntax::parser::at_comma_f(p2_p5)
        ? std::tuple{crate::syntax::decls::TestStep{.withs_p = withs_p2, .action_p = action_p4, .checks_p = Array<crate::syntax::decls::TestCheck>{}, .span_p = start_p1}, crate::syntax::parser::error_at_f(p2_p5, crate::syntax::parser::here_f(p2_p5), Text::lit("a comma in a step begins a delivery; a value with commas in it is written in parentheses"))}
        : std::tuple{crate::syntax::decls::TestStep{.withs_p = withs_p2, .action_p = action_p4, .checks_p = Array<crate::syntax::decls::TestCheck>{}, .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(p2_p5))}, p2_p5};
}


/// WithEntries: unbounded fn Ps -> (([Entry], Ps))
std::tuple<Array<crate::syntax::decls::Entry>, crate::syntax::parser::Ps> with_entries_f(const crate::syntax::parser::Ps& p0_p0) {
    std::tuple<Array<crate::syntax::decls::Entry>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::decls::Entry>{}, p0_p0};
    Array<crate::syntax::decls::Entry> withs_p1 = Array<crate::syntax::decls::Entry>{};
    crate::syntax::parser::Ps p_p2 = p0_p0;
    bool going_p3 = at_word_f(p0_p0, Text::lit("with"));
    while (std::move(going_p3) && (!p_p2.bad_p)) {
        auto [e_p4, q_p5] = parse_entry_f(crate::syntax::parser::adv_f(p_p2));
        withs_p1 = crate::prelude::push(withs_p1, e_p4);
        if (crate::syntax::parser::at_comma_f(q_p5)) {
            p_p2 = crate::syntax::parser::adv_f(q_p5);
            going_p3 = at_word_f(p_p2, Text::lit("with"));
        } else  {
            p_p2 = q_p5;
            going_p3 = false;
        }
    }
    this_ = std::tuple{withs_p1, p_p2};
    return this_;
}


/// StepActionOf: unbounded fn Ps, [Entry] -> ((StepAction, Ps))
std::tuple<crate::syntax::decls::StepAction, crate::syntax::parser::Ps> step_action_of_f(const crate::syntax::parser::Ps& p_p0, const Array<crate::syntax::decls::Entry>& withs_p1) {
    auto w_p2 = step_word_f(p_p0);
    {
        auto&& m5346_0 = w_p2;
        if (m5346_0 == Text::lit("build")) {
            return std::tuple{crate::syntax::decls::StepAction(crate::syntax::decls::StepAction::SaBuild{}), crate::syntax::parser::adv_f(p_p0)};
        }
    }
    {
        auto&& m5346_1 = w_p2;
        if (m5346_1 == Text::lit("tick")) {
            return std::tuple{crate::syntax::decls::StepAction(crate::syntax::decls::StepAction::SaTick{}), crate::syntax::parser::adv_f(p_p0)};
        }
    }
    {
        auto&& m5346_2 = w_p2;
        if (m5346_2 == Text::lit("compute")) {
            auto p1_p3 = crate::syntax::parser::adv_f(p_p0);
            return at_word_f(p1_p3, Text::lit("until"))
                ? ({
                auto p2_p4 = crate::syntax::parser::adv_f(p1_p3);
                at_word_f(p2_p4, Text::lit("idle"))
                ? std::tuple{crate::syntax::decls::StepAction(crate::syntax::decls::StepAction::SaCompute{true}), crate::syntax::parser::adv_f(p2_p4)}
                : std::tuple{crate::syntax::decls::StepAction(crate::syntax::decls::StepAction::SaCompute{true}), crate::syntax::parser::error_here_f(p2_p4, Text::lit("`compute until` is followed by `idle`"))};
            })
                : std::tuple{crate::syntax::decls::StepAction(crate::syntax::decls::StepAction::SaCompute{false}), p1_p3};
        }
    }
    {
        auto&& m5346_3 = w_p2;
        if (m5346_3 == Text::lit("push")) {
            auto [e_p5, q_p6] = parse_entry_f(crate::syntax::parser::adv_f(p_p0));
            return std::tuple{crate::syntax::decls::StepAction(crate::syntax::decls::StepAction::SaPush{e_p5}), q_p6};
        }
    }
    {
        if (is_delivery_word_f(w_p2)) {
            return deliveries_f(p_p0);
        }
    }
    {
        if ((crate::prelude::len(withs_p1) > Nat(0u)) && (crate::syntax::parser::at_open_l_f(p_p0) || crate::syntax::parser::at_stmt_boundary_f(p_p0))) {
            return std::tuple{crate::syntax::decls::StepAction(crate::syntax::decls::StepAction::SaWithOnly{}), p_p0};
        }
    }
    {
        return std::tuple{crate::syntax::decls::StepAction(crate::syntax::decls::StepAction::SaBuild{}), crate::syntax::parser::error_here_f(p_p0, Text::lit("expected a step: `build`, `tick`, `compute`, `send`, `click`, `answer`, `with` or `push`"))};
    }
}


/// Deliveries: unbounded fn Ps -> ((StepAction, Ps))
std::tuple<crate::syntax::decls::StepAction, crate::syntax::parser::Ps> deliveries_f(const crate::syntax::parser::Ps& p0_p0) {
    std::tuple<crate::syntax::decls::StepAction, crate::syntax::parser::Ps> this_ = std::tuple{crate::syntax::decls::StepAction(crate::syntax::decls::StepAction::SaBuild{}), p0_p0};
    auto [first_p1, p1_p2] = parse_delivery_f(p0_p0);
    Array<crate::syntax::decls::Delivery> ds_p3 = Array(std::vector{first_p1});
    crate::syntax::parser::Ps p_p4 = p1_p2;
    while (crate::syntax::parser::at_comma_f(p_p4) && (!p_p4.bad_p)) {
        if (is_delivery_name_f(crate::syntax::parser::kind_at_f(p_p4, Nat(1u)))) {
            auto [d_p5, q_p6] = parse_delivery_f(crate::syntax::parser::adv_f(p_p4));
            ds_p3 = crate::prelude::push(ds_p3, d_p5);
            p_p4 = q_p6;
        } else  {
            p_p4 = crate::syntax::parser::error_at_f(p_p4, crate::syntax::parser::here_f(p_p4), Text::lit("a comma in a step begins a delivery (`click p, click q`); a value with commas in it is written in parentheses: `send p, (Min a, b)`"));
        }
    }
    this_ = std::tuple{crate::syntax::decls::StepAction(crate::syntax::decls::StepAction::SaDeliver{ds_p3}), p_p4};
    return this_;
}


/// IsDeliveryName: fn TokKind -> Bool
bool is_delivery_name_f(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(tok_kind0)) {
        auto&& n_p0 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(tok_kind0).a0;
        return (crate::prelude::len(prism_rtl::deref(n_p0).path_p) == Nat(1u)) && is_delivery_word_f(crate::prelude::or_(crate::prelude::index(prism_rtl::deref(n_p0).path_p, Nat(0u)), Text::lit("")));
    }
    {
        return false;
    }
}


/// ParseEntry: unbounded fn Ps -> ((Entry, Ps))
std::tuple<crate::syntax::decls::Entry, crate::syntax::parser::Ps> parse_entry_f(const crate::syntax::parser::Ps& p_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto [element_p2, p1_p3] = crate::syntax::parser::expr::parse_arg_expr_f(p_p0);
    auto [value_p4, q_p5] = crate::syntax::parser::expr::parse_arg_expr_f(crate::syntax::parser::expect_op_f(p1_p3, Text::lit("=")));
    return std::tuple{crate::syntax::decls::Entry{.element_p = element_p2, .value_p = value_p4, .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_p5))}, q_p5};
}


/// ParseDelivery: unbounded fn Ps -> ((Delivery, Ps))
std::tuple<crate::syntax::decls::Delivery, crate::syntax::parser::Ps> parse_delivery_f(const crate::syntax::parser::Ps& p_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto word_p2 = step_word_f(p_p0);
    auto [target_p3, p1_p4] = parse_target_f(crate::syntax::parser::adv_f(p_p0));
    auto [kind_p5, q_p6] = word_p2 == Text::lit("send")
        ? send_value_f(p1_p4)
        : word_p2 == Text::lit("click")
        ? std::tuple{crate::syntax::decls::DeliveryKind(crate::syntax::decls::DeliveryKind::DkClick{}), p1_p4}
        : std::tuple{crate::syntax::decls::DeliveryKind(crate::syntax::decls::DeliveryKind::DkAnswer{}), p1_p4};
    return std::tuple{crate::syntax::decls::Delivery{.kind_p = kind_p5, .target_p = target_p3, .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_p6))}, q_p6};
}


/// SendValue: unbounded fn Ps -> ((DeliveryKind, Ps))
std::tuple<crate::syntax::decls::DeliveryKind, crate::syntax::parser::Ps> send_value_f(const crate::syntax::parser::Ps& p_p0) {
    return crate::syntax::parser::at_comma_f(p_p0)
        ? ({
        auto [v_p1, q_p2] = crate::syntax::parser::expr::parse_arg_expr_f(crate::syntax::parser::adv_f(p_p0));
        std::tuple{crate::syntax::decls::DeliveryKind(crate::syntax::decls::DeliveryKind::DkSend{v_p1}), q_p2};
    })
        : std::tuple{crate::syntax::decls::DeliveryKind(crate::syntax::decls::DeliveryKind::DkClick{}), crate::syntax::parser::error_here_f(p_p0, Text::lit("`send` takes a target and a value: `send p, v`"))};
}


/// ParseTarget: unbounded fn Ps -> ((Target, Ps))
std::tuple<crate::syntax::decls::Target, crate::syntax::parser::Ps> parse_target_f(const crate::syntax::parser::Ps& p_p0) {
    auto element_p1 = at_word_f(p_p0, Text::lit("element")) && is_path_kind_f(crate::syntax::parser::kind_at_f(p_p0, Nat(1u)));
    return at_word_f(p_p0, Text::lit("at")) || std::move(element_p1)
        ? ({
        auto p1_p2 = crate::syntax::parser::adv_f(p_p0);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::syntax::decls::Target, crate::syntax::parser::Ps>> _v;
        auto&& _m = crate::syntax::parser::kind_f(p1_p2);
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KPath>(_m)) {
            auto&& segs_p3 = prism_rtl::as<crate::syntax::lexer::TokKind::KPath>(_m).a0;
            _v.set(({
                auto span_p4 = crate::syntax::parser::here_f(p1_p2);
                auto [segments_p9, q_pa] = crate::prelude::run_to_end(crate::prelude::fold_job(segs_p3, std::tuple{Array<crate::syntax::decls::PathSeg>{}, crate::syntax::parser::adv_f(p1_p2)}, ({
                    auto span_p4x = span_p4;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::decls::PathSeg>, crate::syntax::parser::Ps>>(std::tuple<std::tuple<Array<crate::syntax::decls::PathSeg>, crate::syntax::parser::Ps>, crate::syntax::lexer::PathSegTok>)>>(prism_rtl::rc([=, span_p4x = std::move(span_p4x)](std::tuple<std::tuple<Array<crate::syntax::decls::PathSeg>, crate::syntax::parser::Ps>, crate::syntax::lexer::PathSegTok> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto span_p4xy = span_p4x;
                        (crate::prelude::entered(crate::prelude::once_job([=, span_p4xy = std::move(span_p4xy)]() {
                        return ({
                            auto [acc_p6, pp_p7] = p0;
                            auto seg_p8 = p1;
                            (prism_rtl::finished(path_seg_of_f(acc_p6, pp_p7, seg_p8, span_p4xy)));
                        });
                    })));
                    });
                }));
                })));
                auto path_p5 = crate::syntax::decls::TestPath{.segments_p = segments_p9, .span_p = span_p4};
                std::move(element_p1)
                ? std::tuple{crate::syntax::decls::Target(crate::syntax::decls::Target::TgElement{path_p5}), q_pa}
                : std::tuple{crate::syntax::decls::Target(crate::syntax::decls::Target::TgPath{path_p5}), q_pa};
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{crate::syntax::decls::Target(crate::syntax::decls::Target::TgPattern{crate::syntax::parser::decls::no_pattern_p()}), crate::syntax::parser::error_here_f(p1_p2, Text::lit("`at` takes a path, `1/#0/0`"))});
            goto _done;
        }
    _done:
        _v.take();
    });
    })
        : ({
        auto [pat_pb, q_pc] = crate::syntax::parser::types::parse_pattern_f(p_p0, false);
        std::tuple{crate::syntax::decls::Target(crate::syntax::decls::Target::TgPattern{pat_pb}), q_pc};
    });
}


/// IsPathKind: fn TokKind -> Bool
bool is_path_kind_f(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KPath>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// PathSegOf: unbounded fn [PathSeg], Ps, PathSegTok, Range -> (([PathSeg], Ps))
std::tuple<Array<crate::syntax::decls::PathSeg>, crate::syntax::parser::Ps> path_seg_of_f(const Array<crate::syntax::decls::PathSeg>& acc_p0, const crate::syntax::parser::Ps& p_p1, const crate::syntax::lexer::PathSegTok& path_seg_tok2, const crate::syntax::Range& range3) {
    auto&& _m = std::tuple{path_seg_tok2, range3};
    if (prism_rtl::is<crate::syntax::lexer::PathSegTok::PstNum>(std::get<0>(_m))) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::lexer::PathSegTok::PstNum>(std::get<0>(_m)).a0;
        return std::tuple{crate::prelude::push(acc_p0, crate::syntax::decls::PathSeg(crate::syntax::decls::PathSeg::PsNum{n_p2})), p_p1};
    }
    if (prism_rtl::is<crate::syntax::lexer::PathSegTok::PstGen>(std::get<0>(_m))) {
        auto&& n_p5 = prism_rtl::as<crate::syntax::lexer::PathSegTok::PstGen>(std::get<0>(_m)).a0;
        return std::tuple{crate::prelude::push(acc_p0, crate::syntax::decls::PathSeg(crate::syntax::decls::PathSeg::PsGen{n_p5})), p_p1};
    }
    if (prism_rtl::is<crate::syntax::lexer::PathSegTok::PstKey>(std::get<0>(_m))) {
        auto&& toks_p8 = prism_rtl::as<crate::syntax::lexer::PathSegTok::PstKey>(std::get<0>(_m)).a0;
        auto&& span_p9 = std::get<1>(_m);
        auto [e_pa, q_pb] = crate::syntax::parser::expr::parse_nested_f(p_p1, toks_p8, span_p9);
        return std::tuple{crate::prelude::push(acc_p0, crate::syntax::decls::PathSeg(crate::syntax::decls::PathSeg::PsKey{e_pa})), q_pb};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ParseTestCheck: unbounded fn Ps -> ((TestCheck, Ps))
std::tuple<crate::syntax::decls::TestCheck, crate::syntax::parser::Ps> parse_test_check_f(const crate::syntax::parser::Ps& p0_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p0_p0);
    auto p_p2 = crate::syntax::parser::expect_op_f(p0_p0, Text::lit("=>"));
    auto word_p3 = step_word_f(p_p2);
    return prism_rtl::deref(p_p2).bad_p
        ? std::tuple{crate::syntax::decls::TestCheck{.kind_p = crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), .span_p = start_p1}, p_p2}
        : word_p3 == Text::lit("")
        ? std::tuple{crate::syntax::decls::TestCheck{.kind_p = crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), .span_p = start_p1}, crate::syntax::parser::error_here_f(p_p2, Text::lit("expected a check after `=>`: `expect`, `returns`, `fired`, `quiet`, ..."))}
        : ({
        auto [kind_p4, q_p5] = check_kind_of_f(crate::syntax::parser::adv_f(p_p2), word_p3);
        std::tuple{crate::syntax::decls::TestCheck{.kind_p = kind_p4, .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_p5))}, q_p5};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::TestCheck, crate::syntax::parser::Ps>> ParseTestCheck::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    auto start_p1 = crate::syntax::parser::here_f(p0_p0);
    auto p_p2 = crate::syntax::parser::expect_op_f(p0_p0, Text::lit("=>"));
    auto word_p3 = step_word_f(p_p2);
    return prism_rtl::deref(p_p2).bad_p
        ? prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheck{.kind_p = crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), .span_p = start_p1}, p_p2})
        : word_p3 == Text::lit("")
        ? prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheck{.kind_p = crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), .span_p = start_p1}, crate::syntax::parser::error_here_f(p_p2, Text::lit("expected a check after `=>`: `expect`, `returns`, `fired`, `quiet`, ..."))})
        : crate::prelude::call_then(start_check_kind_of_f(crate::syntax::parser::adv_f(p_p2), word_p3), [=](std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps> check_kind_of_f_9526) {
        return ({
            auto [kind_p4, q_p5] = check_kind_of_f_9526;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheck{.kind_p = kind_p4, .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_p5))}, q_p5}));
        });
    });
}


/// `Start ParseTestCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::TestCheck, crate::syntax::parser::Ps>> start_parse_test_check_f(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseTestCheck>(p0_p0);
}


/// CheckKindOf: unbounded fn Ps, Text -> ((TestCheckKind, Ps))
std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps> check_kind_of_f(const crate::syntax::parser::Ps& p_p0, const Text& word_p1) {
    {
        auto&& m9701_0 = word_p1;
        if (m9701_0 == Text::lit("expect")) {
            return one_pattern_f(p_p0, ({
                auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkExpect{a0}); });
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, f = std::move(f)](crate::syntax::Pattern_ a0) {
                return ({
                    auto fy = f;
                    (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
                });
            })));
            }));
        }
    }
    {
        auto&& m9701_1 = word_p1;
        if (m9701_1 == Text::lit("expect_none")) {
            return one_pattern_f(p_p0, ({
                auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkExpectNone{a0}); });
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, f = std::move(f)](crate::syntax::Pattern_ a0) {
                return ({
                    auto fy = f;
                    (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
                });
            })));
            }));
        }
    }
    {
        auto&& m9701_2 = word_p1;
        if (m9701_2 == Text::lit("expect_top")) {
            return one_pattern_f(p_p0, ({
                auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkExpectTop{a0}); });
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, f = std::move(f)](crate::syntax::Pattern_ a0) {
                return ({
                    auto fy = f;
                    (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
                });
            })));
            }));
        }
    }
    {
        auto&& m9701_3 = word_p1;
        if (m9701_3 == Text::lit("expect_top_none")) {
            return one_pattern_f(p_p0, ({
                auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkExpectTopNone{a0}); });
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, f = std::move(f)](crate::syntax::Pattern_ a0) {
                return ({
                    auto fy = f;
                    (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
                });
            })));
            }));
        }
    }
    {
        auto&& m9701_4 = word_p1;
        if (m9701_4 == Text::lit("unrequested")) {
            return one_pattern_f(p_p0, ({
                auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkUnrequested{a0}); });
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, f = std::move(f)](crate::syntax::Pattern_ a0) {
                return ({
                    auto fy = f;
                    (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
                });
            })));
            }));
        }
    }
    {
        auto&& m9701_5 = word_p1;
        if (m9701_5 == Text::lit("returns")) {
            return one_pattern_f(p_p0, ({
                auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkReturns{a0}); });
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, f = std::move(f)](crate::syntax::Pattern_ a0) {
                return ({
                    auto fy = f;
                    (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
                });
            })));
            }));
        }
    }
    {
        auto&& m9701_6 = word_p1;
        if (m9701_6 == Text::lit("fired")) {
            return one_pattern_f(p_p0, ({
                auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkFired{a0}); });
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, f = std::move(f)](crate::syntax::Pattern_ a0) {
                return ({
                    auto fy = f;
                    (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
                });
            })));
            }));
        }
    }
    {
        auto&& m9701_7 = word_p1;
        if (m9701_7 == Text::lit("expect_count")) {
            auto [pat_p2, p1_p3] = crate::syntax::parser::types::parse_pattern_f(p_p0, false);
            return !crate::syntax::parser::at_comma_f(p1_p3)
                ? std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), crate::syntax::parser::error_here_f(p1_p3, Text::lit("`expect_count` takes a pattern and a count: `expect_count p, n`"))}
                : ({
                auto p2_p4 = crate::syntax::parser::adv_f(p1_p3);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps>> _v;
                auto&& _m = crate::syntax::parser::kind_f(p2_p4);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m)) {
                    auto&& m10260_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a0;
                    auto&& text_p5 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a1;
                    if (m10260_0_0 == Text::lit("")) {
                        _v.set(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkExpectCount{pat_p2, parse_nat_text_f(text_p5)}), crate::syntax::parser::adv_f(p2_p4)});
                        goto _done;
                    }
                }
                {
                    _v.set(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), crate::syntax::parser::error_here_f(p2_p4, Text::lit("`expect_count` takes a number"))});
                    goto _done;
                }
            _done:
                _v.take();
            });
            });
        }
    }
    {
        auto&& m9701_8 = word_p1;
        if (m9701_8 == Text::lit("requested")) {
            auto [place_p6, p1_p7] = crate::syntax::parser::types::parse_pattern_f(p_p0, false);
            return !crate::syntax::parser::at_comma_f(p1_p7)
                ? std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), crate::syntax::parser::error_here_f(p1_p7, Text::lit("`requested` takes a place and a value: `requested p, v`"))}
                : ({
                auto [value_p8, q_p9] = crate::syntax::parser::types::parse_pattern_f(crate::syntax::parser::adv_f(p1_p7), false);
                std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkRequested{place_p6, value_p8}), q_p9};
            });
        }
    }
    {
        auto&& m9701_9 = word_p1;
        if (m9701_9 == Text::lit("quiet")) {
            return std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), p_p0};
        }
    }
    {
        auto&& m9701_10 = word_p1;
        if (m9701_10 == Text::lit("settles")) {
            return std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkSettles{}), p_p0};
        }
    }
    {
        auto&& m9701_11 = word_p1;
        if (m9701_11 == Text::lit("aborted")) {
            return std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkAborted{}), p_p0};
        }
    }
    {
        auto&& m9701_12 = word_p1;
        if (m9701_12 == Text::lit("snapshot")) {
            auto&& _m = crate::syntax::parser::kind_f(p_p0);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m)) {
                auto&& m10860_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a0;
                auto&& segs_pa = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a1;
                if (m10860_0_0 == Text::lit("")) {
                    if (all_plain_f(segs_pa)) {
                        return std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkSnapshot{crate::prelude::concat(crate::prelude::each(segs_pa, plain_of_f))}), crate::syntax::parser::adv_f(p_p0)};
                    }
                }
            }
            {
                return std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), crate::syntax::parser::error_here_f(p_p0, Text::lit("`snapshot` takes a file name, a text literal"))};
            }
        }
    }
    {
        return std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), crate::syntax::parser::error_at_f(p_p0, crate::syntax::parser::prev_f(p_p0), prism_rtl::cat("`", word_p1, "` is not a check: the checks are expect, expect_none, expect_count, expect_top, expect_top_none, requested, unrequested, returns, fired, quiet, settles, aborted, snapshot"))};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps>> CheckKindOf::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& word_p1 = this->word_p1;
    return ({
        ({
        auto&& m9701_0 = word_p1;
        (m9701_0 == Text::lit("expect"));
    }) ? ({
        auto&& m9701_0 = word_p1;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_p0, ({
        auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkExpect{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, f = std::move(f)](crate::syntax::Pattern_ a0) {
        return ({
            auto fy = f;
            (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
        });
    })));
    }))));
    })
        : ({
        auto&& m9701_1 = word_p1;
        (m9701_1 == Text::lit("expect_none"));
    }) ? ({
        auto&& m9701_1 = word_p1;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_p0, ({
        auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkExpectNone{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, f = std::move(f)](crate::syntax::Pattern_ a0) {
        return ({
            auto fy = f;
            (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
        });
    })));
    }))));
    })
        : ({
        auto&& m9701_2 = word_p1;
        (m9701_2 == Text::lit("expect_top"));
    }) ? ({
        auto&& m9701_2 = word_p1;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_p0, ({
        auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkExpectTop{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, f = std::move(f)](crate::syntax::Pattern_ a0) {
        return ({
            auto fy = f;
            (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
        });
    })));
    }))));
    })
        : ({
        auto&& m9701_3 = word_p1;
        (m9701_3 == Text::lit("expect_top_none"));
    }) ? ({
        auto&& m9701_3 = word_p1;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_p0, ({
        auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkExpectTopNone{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, f = std::move(f)](crate::syntax::Pattern_ a0) {
        return ({
            auto fy = f;
            (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
        });
    })));
    }))));
    })
        : ({
        auto&& m9701_4 = word_p1;
        (m9701_4 == Text::lit("unrequested"));
    }) ? ({
        auto&& m9701_4 = word_p1;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_p0, ({
        auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkUnrequested{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, f = std::move(f)](crate::syntax::Pattern_ a0) {
        return ({
            auto fy = f;
            (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
        });
    })));
    }))));
    })
        : ({
        auto&& m9701_5 = word_p1;
        (m9701_5 == Text::lit("returns"));
    }) ? ({
        auto&& m9701_5 = word_p1;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_p0, ({
        auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkReturns{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, f = std::move(f)](crate::syntax::Pattern_ a0) {
        return ({
            auto fy = f;
            (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
        });
    })));
    }))));
    })
        : ({
        auto&& m9701_6 = word_p1;
        (m9701_6 == Text::lit("fired"));
    }) ? ({
        auto&& m9701_6 = word_p1;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_p0, ({
        auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkFired{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, f = std::move(f)](crate::syntax::Pattern_ a0) {
        return ({
            auto fy = f;
            (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
        });
    })));
    }))));
    })
        : ({
        auto&& m9701_7 = word_p1;
        (m9701_7 == Text::lit("expect_count"));
    }) ? ({
        auto&& m9701_7 = word_p1;
        ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(crate::syntax::parser::types::start_parse_pattern_f(p_p0x, false), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_f_10060) {
        return ({
            auto [pat_p2, p1_p3] = parse_pattern_f_10060;
            (!crate::syntax::parser::at_comma_f(p1_p3)
            ? prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), crate::syntax::parser::error_here_f(p1_p3, Text::lit("`expect_count` takes a pattern and a count: `expect_count p, n`"))})
            : ({
            auto p2_p4 = crate::syntax::parser::adv_f(p1_p3);
            ({
            auto&& _m = crate::syntax::parser::kind_f(p2_p4);
            prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m) && ({
            auto&& m10260_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a0;
            auto&& text_p5 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a1;
            (m10260_0_0 == Text::lit(""));
        }) ? ({
            auto&& m10260_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a0;
            auto&& text_p5 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a1;
            prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkExpectCount{pat_p2, parse_nat_text_f(text_p5)}), crate::syntax::parser::adv_f(p2_p4)});
        })
            : prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), crate::syntax::parser::error_here_f(p2_p4, Text::lit("`expect_count` takes a number"))});
        });
        }));
        });
    }));
    });
    })
        : ({
        auto&& m9701_8 = word_p1;
        (m9701_8 == Text::lit("requested"));
    }) ? ({
        auto&& m9701_8 = word_p1;
        ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(crate::syntax::parser::types::start_parse_pattern_f(p_p0x, false), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_f_10494) {
        return ({
            auto [place_p6, p1_p7] = parse_pattern_f_10494;
            (!crate::syntax::parser::at_comma_f(p1_p7)
            ? prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), crate::syntax::parser::error_here_f(p1_p7, Text::lit("`requested` takes a place and a value: `requested p, v`"))})
            : crate::prelude::call_then(crate::syntax::parser::types::start_parse_pattern_f(crate::syntax::parser::adv_f(p1_p7), false), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_f_10677) {
            return ({
                auto [value_p8, q_p9] = parse_pattern_f_10677;
                (prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkRequested{place_p6, value_p8}), q_p9}));
            });
        }));
        });
    }));
    });
    })
        : ({
        auto&& m9701_9 = word_p1;
        (m9701_9 == Text::lit("quiet"));
    }) ? ({
        auto&& m9701_9 = word_p1;
        prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), p_p0});
    })
        : ({
        auto&& m9701_10 = word_p1;
        (m9701_10 == Text::lit("settles"));
    }) ? ({
        auto&& m9701_10 = word_p1;
        prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkSettles{}), p_p0});
    })
        : ({
        auto&& m9701_11 = word_p1;
        (m9701_11 == Text::lit("aborted"));
    }) ? ({
        auto&& m9701_11 = word_p1;
        prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkAborted{}), p_p0});
    })
        : ({
        auto&& m9701_12 = word_p1;
        (m9701_12 == Text::lit("snapshot"));
    }) ? ({
        auto&& m9701_12 = word_p1;
        ({
        auto&& _m = crate::syntax::parser::kind_f(p_p0);
        prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m) && ({
        auto&& m10860_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a0;
        auto&& segs_pa = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a1;
        (m10860_0_0 == Text::lit("")) && all_plain_f(segs_pa);
    }) ? ({
        auto&& m10860_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a0;
        auto&& segs_pa = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a1;
        prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkSnapshot{crate::prelude::concat(crate::prelude::each(segs_pa, plain_of_f))}), crate::syntax::parser::adv_f(p_p0)});
    })
        : prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), crate::syntax::parser::error_here_f(p_p0, Text::lit("`snapshot` takes a file name, a text literal"))});
    });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), crate::syntax::parser::error_at_f(p_p0, crate::syntax::parser::prev_f(p_p0), prism_rtl::cat("`", word_p1, "` is not a check: the checks are expect, expect_none, expect_count, expect_top, expect_top_none, requested, unrequested, returns, fired, quiet, settles, aborted, snapshot"))});
    });
}


/// `Start CheckKindOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps>> start_check_kind_of_f(crate::syntax::parser::Ps p_p0, Text word_p1) {
    return prism_rtl::make_rc<CheckKindOf>(p_p0, word_p1);
}


/// OnePattern: unbounded fn Ps, (fn Pattern -> TestCheckKind) -> ((TestCheckKind, Ps))
std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps> one_pattern_f(const crate::syntax::parser::Ps& p_p0, const prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>& make_f1) {
    auto [pat_p2, q_p3] = crate::syntax::parser::types::parse_pattern_f(p_p0, false);
    return std::tuple{crate::prelude::run_to_end(make_f1(pat_p2)), q_p3};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps>> OnePattern::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& make_f1 = this->make_f1;
    auto make_f1x = make_f1;
    auto p_p0x = p_p0;
    return crate::prelude::call_then(crate::syntax::parser::types::start_parse_pattern_f(p_p0x, false), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_f_11423) {
        return ({
            auto [pat_p2, q_p3] = parse_pattern_f_11423;
            (crate::prelude::call_value(make_f1x(pat_p2), [=](crate::syntax::decls::TestCheckKind make_11451) { return prism_rtl::finished(std::tuple{make_11451, q_p3}); }));
        });
    });
}


/// `Start OnePattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps>> start_one_pattern_f(crate::syntax::parser::Ps p_p0, prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)> make_f1) {
    return prism_rtl::make_rc<OnePattern>(p_p0, make_f1);
}


/// AllPlain: fn [TextSegTok] -> Bool
bool all_plain_f(const Array<crate::syntax::lexer::TextSegTok>& segs_p0) {
    return crate::prelude::fold(segs_p0, true, [&](const bool& ok_p1, const crate::syntax::lexer::TextSegTok& s_p2) { return prism_rtl::deref(ok_p1) && is_plain_seg_f(s_p2); });
}


/// IsPlainSeg: fn TextSegTok -> Bool
bool is_plain_seg_f(const crate::syntax::lexer::TextSegTok& text_seg_tok0) {
    if (prism_rtl::is<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok0)) {
        return true;
    }
    {
        return false;
    }
}


/// PlainOf: fn TextSegTok -> Text
Text plain_of_f(const crate::syntax::lexer::TextSegTok& text_seg_tok0) {
    if (prism_rtl::is<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok0)) {
        auto&& s_p0 = prism_rtl::as<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok0).a0;
        return s_p0;
    }
    {
        return Text::lit("");
    }
}


/// ParseNatText: fn Text -> Nat
Nat parse_nat_text_f(const Text& text0_p0) {
    auto text_p1 = crate::prelude::concat(crate::prelude::split_on(text0_p0, Text::lit("_")));
    return crate::syntax::lexer::chars::has_prefix_f(text_p1, Text::lit("0x"))
        ? crate::prelude::or_(crate::syntax::lexer::chars::parse_hex_o(crate::syntax::lexer::chars::drop_prefix_f(text_p1, Text::lit("0x"))), Nat(0u))
        : crate::syntax::lexer::chars::has_prefix_f(text_p1, Text::lit("0o"))
        ? crate::prelude::or_(parse_radix_o(crate::syntax::lexer::chars::drop_prefix_f(text_p1, Text::lit("0o")), Nat(8u)), Nat(0u))
        : crate::syntax::lexer::chars::has_prefix_f(text_p1, Text::lit("0b"))
        ? crate::prelude::or_(parse_radix_o(crate::syntax::lexer::chars::drop_prefix_f(text_p1, Text::lit("0b")), Nat(2u)), Nat(0u))
        : crate::prelude::or_(crate::prelude::parse_nat_opt(text_p1), Nat(0u));
}


/// ?ParseRadix: fn Text, Nat -> ?Nat
std::optional<Nat> parse_radix_o(const Text& t_p0, const Nat& radix_p1) {
    return ({
        __label__ g12268;
        prism_rtl::Slot<std::optional<Nat>> g12268_v;
        {
            if (!((t_p0 != Text::lit("")) && crate::syntax::lexer::chars::all_chars_f(t_p0, ({
                auto radix_p1x = radix_p1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, radix_p1x = std::move(radix_p1x)](Text p0) {
                return ({
                    auto radix_p1xy = radix_p1x;
                    (crate::prelude::once_job([=, radix_p1xy = std::move(radix_p1xy)]() {
                    return ({
                        auto c_p2 = p0;
                        (prism_rtl::finished(crate::syntax::lexer::chars::is_digit_f(c_p2) && (crate::syntax::lexer::chars::hex_value_f(c_p2) < radix_p1xy)));
                    });
                }));
                });
            })));
            })))) {
                { g12268_v.set(std::nullopt); goto g12268; }
            }
            g12268_v.set(std::optional(crate::syntax::lexer::chars::fold_chars_f(t_p0, Nat(0u), ({
                auto radix_p1x = radix_p1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=, radix_p1x = std::move(radix_p1x)](std::tuple<Nat, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto radix_p1xy = radix_p1x;
                    (crate::prelude::once_job([=, radix_p1xy = std::move(radix_p1xy)]() {
                    return ({
                        auto n_p3 = p0;
                        auto c_p4 = p1;
                        (prism_rtl::finished((n_p3 * radix_p1xy) + crate::syntax::lexer::chars::hex_value_f(c_p4)));
                    });
                }));
                });
            })));
            }))));
        }
    g12268:
        g12268_v.take();
    });
}

}  // namespace crate::syntax::parser::test_language
