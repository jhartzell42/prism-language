// The modules `Check.Types`, `Check.Types.Colors`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/types/module.hpp>
#include <syntax/module.hpp>
#include <check/typed/module.hpp>
#include <check/errors/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Types`, from `target/bootstrap/cpp-src/prismc/check/types/mod.prism`.
namespace crate::check::types {

void CLeq::show(Printer& p) const {
    p.record("CLeq", {{"lo", lo_p}, {"hi", hi_p}, {"file", file_p}, {"span", span_p}, {"kind", kind_p}, {"name", name_p}, {"why", why_p}});
}

Pod CLeq::to_pod() const {
    return Pod::record("CLeq", {{"lo", prism_rtl::to_pod(lo_p)}, {"hi", prism_rtl::to_pod(hi_p)}, {"file", prism_rtl::to_pod(file_p)}, {"span", prism_rtl::to_pod(span_p)}, {"kind", prism_rtl::to_pod(kind_p)}, {"name", prism_rtl::to_pod(name_p)}, {"why", prism_rtl::to_pod(why_p)}});
}

Result<CLeq> CLeq::from_pod(const Pod& whole) {
    return CLeq{.lo_p = TRY(prism_rtl::from_pod<Col>(TRY(crate::prelude::field(whole, "lo")))), .hi_p = TRY(prism_rtl::from_pod<Col>(TRY(crate::prelude::field(whole, "hi")))), .file_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .kind_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "kind")))), .name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .why_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "why"))))};
}


void Col::show(Printer& p) const {
    if (auto c = std::get_if<CBound>(&cases())) p.choice("CBound", {});
    else if (auto c = std::get_if<CUnbound>(&cases())) p.choice("CUnbound", {});
    else if (auto c = std::get_if<CRigid>(&cases())) p.choice("CRigid", {c->a0});
    else if (auto c = std::get_if<CQ>(&cases())) p.choice("CQ", {c->a0});
    else if (auto c = std::get_if<CFlex>(&cases())) p.choice("CFlex", {c->a0});
}

Pod Col::to_pod() const {
    return std::holds_alternative<CBound>(cases()) ? Pod::choice("CBound", {})
        : std::holds_alternative<CUnbound>(cases()) ? Pod::choice("CUnbound", {})
        : std::holds_alternative<CRigid>(cases()) ? Pod::choice("CRigid", {prism_rtl::to_pod(std::get<CRigid>(cases()).a0)})
        : std::holds_alternative<CQ>(cases()) ? Pod::choice("CQ", {prism_rtl::to_pod(std::get<CQ>(cases()).a0)})
        : std::holds_alternative<CFlex>(cases()) ? Pod::choice("CFlex", {prism_rtl::to_pod(std::get<CFlex>(cases()).a0)})
        : Pod();
}

Result<Col> Col::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "CBound" && c->args.size() == 0) return Col(CBound{});
        if (c->ctor == "CUnbound" && c->args.size() == 0) return Col(CUnbound{});
        if (c->ctor == "CRigid" && c->args.size() == 1) return Col(CRigid{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "CQ" && c->args.size() == 1) return Col(CQ{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "CFlex" && c->args.size() == 1) return Col(CFlex{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
    }
    return mismatch<Col>("a Col", p);
}


void Incl::show(Printer& p) const {
    p.record("Incl", {{"sub", sub_p}, {"sup", sup_p}, {"file", file_p}, {"span", span_p}, {"what", what_p}, {"forward", forward_p}});
}

Pod Incl::to_pod() const {
    return Pod::record("Incl", {{"sub", prism_rtl::to_pod(sub_p)}, {"sup", prism_rtl::to_pod(sup_p)}, {"file", prism_rtl::to_pod(file_p)}, {"span", prism_rtl::to_pod(span_p)}, {"what", prism_rtl::to_pod(what_p)}, {"forward", prism_rtl::to_pod(forward_p)}});
}

Result<Incl> Incl::from_pod(const Pod& whole) {
    return Incl{.sub_p = TRY(prism_rtl::from_pod<Rw>(TRY(crate::prelude::field(whole, "sub")))), .sup_p = TRY(prism_rtl::from_pod<Rw>(TRY(crate::prelude::field(whole, "sup")))), .file_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .what_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "what")))), .forward_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "forward"))))};
}


void Rw::show(Printer& p) const {
    p.record("Rw", {{"fams", fams_p}, {"minus", minus_p}, {"tail", tail_p}});
}

Pod Rw::to_pod() const {
    return Pod::record("Rw", {{"fams", prism_rtl::to_pod(fams_p)}, {"minus", prism_rtl::to_pod(minus_p)}, {"tail", prism_rtl::to_pod(tail_p)}});
}

Result<Rw> Rw::from_pod(const Pod& whole) {
    return Rw{.fams_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "fams")))), .minus_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "minus")))), .tail_p = TRY(prism_rtl::from_pod<Tail>(TRY(crate::prelude::field(whole, "tail"))))};
}


void Scheme::show(Printer& p) const {
    p.record("Scheme", {{"qs", qs_p}, {"plainQs", plain_qs_p}, {"rqs", rqs_p}, {"cqs", cqs_p}, {"cjoins", cjoins_p}, {"bounds", bounds_p}, {"ty", ty_p}});
}

Pod Scheme::to_pod() const {
    return Pod::record("Scheme", {{"qs", prism_rtl::to_pod(qs_p)}, {"plainQs", prism_rtl::to_pod(plain_qs_p)}, {"rqs", prism_rtl::to_pod(rqs_p)}, {"cqs", prism_rtl::to_pod(cqs_p)}, {"cjoins", prism_rtl::to_pod(cjoins_p)}, {"bounds", prism_rtl::to_pod(bounds_p)}, {"ty", prism_rtl::to_pod(ty_p)}});
}

Result<Scheme> Scheme::from_pod(const Pod& whole) {
    return Scheme{.qs_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "qs")))), .plain_qs_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "plainQs")))), .rqs_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "rqs")))), .cqs_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "cqs")))), .cjoins_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "cjoins")))), .bounds_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "bounds")))), .ty_p = TRY(prism_rtl::from_pod<Ty>(TRY(crate::prelude::field(whole, "ty"))))};
}


bool St::operator==(const St& o) const { return next_p == o.next_p && tys_p == o.tys_p && infos_p == o.infos_p && rows_p == o.rows_p && lacks_p == o.lacks_p && wants_p == o.wants_p && incls_p == o.incls_p && diags_p == o.diags_p && level_p == o.level_p && file_p == o.file_p && color_p == o.color_p && color_why_p == o.color_why_p && color_flex_p == o.color_flex_p && cols_p == o.cols_p && cleqs_p == o.cleqs_p && col_q_p == o.col_q_p && col_up_p == o.col_up_p && deferred_p == o.deferred_p && binder_at_p == o.binder_at_p && row_names_p == o.row_names_p && layer_qs_p == o.layer_qs_p && field_qs_p == o.field_qs_p && recording_p == o.recording_p && typed_p == o.typed_p && choices_p == o.choices_p && size_tys_p == o.size_tys_p && local_next_p == o.local_next_p && local_ids_p == o.local_ids_p && any_givens_p == o.any_givens_p; }

void St::show(Printer& p) const {
    p.record("St", {{"next", next_p}, {"tys", tys_p}, {"infos", infos_p}, {"rows", rows_p}, {"lacks", lacks_p}, {"wants", wants_p}, {"incls", incls_p}, {"diags", diags_p}, {"level", level_p}, {"file", file_p}, {"color", color_p}, {"colorWhy", color_why_p}, {"colorFlex", color_flex_p}, {"cols", cols_p}, {"cleqs", cleqs_p}, {"colQ", col_q_p}, {"colUp", col_up_p}, {"deferred", deferred_p}, {"binderAt", binder_at_p}, {"rowNames", row_names_p}, {"layerQs", layer_qs_p}, {"fieldQs", field_qs_p}, {"recording", recording_p}, {"typed", typed_p}, {"choices", choices_p}, {"sizeTys", size_tys_p}, {"localNext", local_next_p}, {"localIds", local_ids_p}, {"anyGivens", any_givens_p}});
}

Pod St::to_pod() const {
    return Pod::record("St", {{"next", prism_rtl::to_pod(next_p)}, {"tys", prism_rtl::to_pod(tys_p)}, {"infos", prism_rtl::to_pod(infos_p)}, {"rows", prism_rtl::to_pod(rows_p)}, {"lacks", prism_rtl::to_pod(lacks_p)}, {"wants", prism_rtl::to_pod(wants_p)}, {"incls", prism_rtl::to_pod(incls_p)}, {"diags", prism_rtl::to_pod(diags_p)}, {"level", prism_rtl::to_pod(level_p)}, {"file", prism_rtl::to_pod(file_p)}, {"color", prism_rtl::to_pod(color_p)}, {"colorWhy", prism_rtl::to_pod(color_why_p)}, {"colorFlex", prism_rtl::to_pod(color_flex_p)}, {"cols", prism_rtl::to_pod(cols_p)}, {"cleqs", prism_rtl::to_pod(cleqs_p)}, {"colQ", prism_rtl::to_pod(col_q_p)}, {"colUp", prism_rtl::to_pod(col_up_p)}, {"deferred", prism_rtl::to_pod(deferred_p)}, {"binderAt", prism_rtl::to_pod(binder_at_p)}, {"rowNames", prism_rtl::to_pod(row_names_p)}, {"layerQs", prism_rtl::to_pod(layer_qs_p)}, {"fieldQs", prism_rtl::to_pod(field_qs_p)}, {"recording", prism_rtl::to_pod(recording_p)}, {"typed", prism_rtl::to_pod(typed_p)}, {"choices", prism_rtl::to_pod(choices_p)}, {"sizeTys", prism_rtl::to_pod(size_tys_p)}, {"localNext", prism_rtl::to_pod(local_next_p)}, {"localIds", prism_rtl::to_pod(local_ids_p)}, {"anyGivens", prism_rtl::to_pod(any_givens_p)}});
}

Result<St> St::from_pod(const Pod& whole) {
    return St{.next_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "next")))), .tys_p = TRY(prism_rtl::from_pod<Map<Nat, Ty>>(TRY(crate::prelude::field(whole, "tys")))), .infos_p = TRY(prism_rtl::from_pod<Map<Nat, VInfo>>(TRY(crate::prelude::field(whole, "infos")))), .rows_p = TRY(prism_rtl::from_pod<Map<Nat, Rw>>(TRY(crate::prelude::field(whole, "rows")))), .lacks_p = TRY(prism_rtl::from_pod<Map<Nat, Array<Text>>>(TRY(crate::prelude::field(whole, "lacks")))), .wants_p = TRY(prism_rtl::from_pod<Array<Want>>(TRY(crate::prelude::field(whole, "wants")))), .incls_p = TRY(prism_rtl::from_pod<Array<Incl>>(TRY(crate::prelude::field(whole, "incls")))), .diags_p = TRY(prism_rtl::from_pod<Array<crate::check::errors::CDiag>>(TRY(crate::prelude::field(whole, "diags")))), .level_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "level")))), .file_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .color_p = TRY(prism_rtl::from_pod<Col>(TRY(crate::prelude::field(whole, "color")))), .color_why_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "colorWhy")))), .color_flex_p = TRY(prism_rtl::from_pod<Array<std::tuple<Col, Text, crate::syntax::Range>>>(TRY(crate::prelude::field(whole, "colorFlex")))), .cols_p = TRY(prism_rtl::from_pod<Map<Nat, Col>>(TRY(crate::prelude::field(whole, "cols")))), .cleqs_p = TRY(prism_rtl::from_pod<Array<CLeq>>(TRY(crate::prelude::field(whole, "cleqs")))), .col_q_p = TRY(prism_rtl::from_pod<Map<Nat, Text>>(TRY(crate::prelude::field(whole, "colQ")))), .col_up_p = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "colUp")))), .deferred_p = TRY(prism_rtl::from_pod<Array<std::tuple<Ty, Ty, crate::syntax::Range>>>(TRY(crate::prelude::field(whole, "deferred")))), .binder_at_p = TRY(prism_rtl::from_pod<Map<Nat, crate::syntax::Range>>(TRY(crate::prelude::field(whole, "binderAt")))), .row_names_p = TRY(prism_rtl::from_pod<Map<Nat, Text>>(TRY(crate::prelude::field(whole, "rowNames")))), .layer_qs_p = TRY(prism_rtl::from_pod<Array<std::tuple<Ty, crate::syntax::Range, Text>>>(TRY(crate::prelude::field(whole, "layerQs")))), .field_qs_p = TRY(prism_rtl::from_pod<Array<crate::check::types::unify::FieldQ>>(TRY(crate::prelude::field(whole, "fieldQs")))), .recording_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "recording")))), .typed_p = TRY(prism_rtl::from_pod<crate::check::typed::TProgram>(TRY(crate::prelude::field(whole, "typed")))), .choices_p = TRY(prism_rtl::from_pod<Map<Text, Array<Text>>>(TRY(crate::prelude::field(whole, "choices")))), .size_tys_p = TRY(prism_rtl::from_pod<Map<Text, Ty>>(TRY(crate::prelude::field(whole, "sizeTys")))), .local_next_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "localNext")))), .local_ids_p = TRY(prism_rtl::from_pod<Map<Text, Nat>>(TRY(crate::prelude::field(whole, "localIds")))), .any_givens_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "anyGivens"))))};
}


void Tail::show(Printer& p) const {
    if (auto c = std::get_if<TlClosed>(&cases())) p.choice("TlClosed", {});
    else if (auto c = std::get_if<TlFlex>(&cases())) p.choice("TlFlex", {c->a0});
    else if (auto c = std::get_if<TlRigid>(&cases())) p.choice("TlRigid", {c->a0});
    else if (auto c = std::get_if<TlQ>(&cases())) p.choice("TlQ", {c->a0});
}

Pod Tail::to_pod() const {
    return std::holds_alternative<TlClosed>(cases()) ? Pod::choice("TlClosed", {})
        : std::holds_alternative<TlFlex>(cases()) ? Pod::choice("TlFlex", {prism_rtl::to_pod(std::get<TlFlex>(cases()).a0)})
        : std::holds_alternative<TlRigid>(cases()) ? Pod::choice("TlRigid", {prism_rtl::to_pod(std::get<TlRigid>(cases()).a0)})
        : std::holds_alternative<TlQ>(cases()) ? Pod::choice("TlQ", {prism_rtl::to_pod(std::get<TlQ>(cases()).a0)})
        : Pod();
}

Result<Tail> Tail::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TlClosed" && c->args.size() == 0) return Tail(TlClosed{});
        if (c->ctor == "TlFlex" && c->args.size() == 1) return Tail(TlFlex{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "TlRigid" && c->args.size() == 1) return Tail(TlRigid{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TlQ" && c->args.size() == 1) return Tail(TlQ{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Tail>("a Tail", p);
}


bool Ty::TyCon::operator==(const TyCon& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ty::TyFn::operator==(const TyFn& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool Ty::TyTuple::operator==(const TyTuple& o) const { return a0 == o.a0; }

bool Ty::TyArray::operator==(const TyArray& o) const { return a0 == o.a0; }

bool Ty::TyMap::operator==(const TyMap& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ty::TySig::operator==(const TySig& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ty::TyAt::operator==(const TyAt& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ty::TyElem::operator==(const TyElem& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ty::TyAssoc::operator==(const TyAssoc& o) const { return a0 == o.a0 && a1 == o.a1; }

void Ty::show(Printer& p) const {
    if (auto c = std::get_if<TyFlex>(&cases())) p.choice("TyFlex", {c->a0});
    else if (auto c = std::get_if<TyRigid>(&cases())) p.choice("TyRigid", {c->a0});
    else if (auto c = std::get_if<TyQ>(&cases())) p.choice("TyQ", {c->a0});
    else if (auto c = std::get_if<TyCon>(&cases())) p.choice("TyCon", {c->a0, c->a1});
    else if (auto c = std::get_if<TyFn>(&cases())) p.choice("TyFn", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<TyTuple>(&cases())) p.choice("TyTuple", {c->a0});
    else if (auto c = std::get_if<TyArray>(&cases())) p.choice("TyArray", {c->a0});
    else if (auto c = std::get_if<TyMap>(&cases())) p.choice("TyMap", {c->a0, c->a1});
    else if (auto c = std::get_if<TySig>(&cases())) p.choice("TySig", {c->a0, c->a1});
    else if (auto c = std::get_if<TyAt>(&cases())) p.choice("TyAt", {c->a0, c->a1});
    else if (auto c = std::get_if<TyElem>(&cases())) p.choice("TyElem", {c->a0, c->a1});
    else if (auto c = std::get_if<TyElemAny>(&cases())) p.choice("TyElemAny", {c->a0});
    else if (auto c = std::get_if<TyAssoc>(&cases())) p.choice("TyAssoc", {c->a0, c->a1});
    else if (auto c = std::get_if<TyAny>(&cases())) p.choice("TyAny", {c->a0});
    else if (auto c = std::get_if<TyErr>(&cases())) p.choice("TyErr", {});
}

Pod Ty::to_pod() const {
    return std::holds_alternative<TyFlex>(cases()) ? Pod::choice("TyFlex", {prism_rtl::to_pod(std::get<TyFlex>(cases()).a0)})
        : std::holds_alternative<TyRigid>(cases()) ? Pod::choice("TyRigid", {prism_rtl::to_pod(std::get<TyRigid>(cases()).a0)})
        : std::holds_alternative<TyQ>(cases()) ? Pod::choice("TyQ", {prism_rtl::to_pod(std::get<TyQ>(cases()).a0)})
        : std::holds_alternative<TyCon>(cases()) ? Pod::choice("TyCon", {prism_rtl::to_pod(std::get<TyCon>(cases()).a0), prism_rtl::to_pod(std::get<TyCon>(cases()).a1)})
        : std::holds_alternative<TyFn>(cases()) ? Pod::choice("TyFn", {prism_rtl::to_pod(std::get<TyFn>(cases()).a0), prism_rtl::to_pod(std::get<TyFn>(cases()).a1), prism_rtl::to_pod(std::get<TyFn>(cases()).a2)})
        : std::holds_alternative<TyTuple>(cases()) ? Pod::choice("TyTuple", {prism_rtl::to_pod(std::get<TyTuple>(cases()).a0)})
        : std::holds_alternative<TyArray>(cases()) ? Pod::choice("TyArray", {prism_rtl::to_pod(std::get<TyArray>(cases()).a0)})
        : std::holds_alternative<TyMap>(cases()) ? Pod::choice("TyMap", {prism_rtl::to_pod(std::get<TyMap>(cases()).a0), prism_rtl::to_pod(std::get<TyMap>(cases()).a1)})
        : std::holds_alternative<TySig>(cases()) ? Pod::choice("TySig", {prism_rtl::to_pod(std::get<TySig>(cases()).a0), prism_rtl::to_pod(std::get<TySig>(cases()).a1)})
        : std::holds_alternative<TyAt>(cases()) ? Pod::choice("TyAt", {prism_rtl::to_pod(std::get<TyAt>(cases()).a0), prism_rtl::to_pod(std::get<TyAt>(cases()).a1)})
        : std::holds_alternative<TyElem>(cases()) ? Pod::choice("TyElem", {prism_rtl::to_pod(std::get<TyElem>(cases()).a0), prism_rtl::to_pod(std::get<TyElem>(cases()).a1)})
        : std::holds_alternative<TyElemAny>(cases()) ? Pod::choice("TyElemAny", {prism_rtl::to_pod(std::get<TyElemAny>(cases()).a0)})
        : std::holds_alternative<TyAssoc>(cases()) ? Pod::choice("TyAssoc", {prism_rtl::to_pod(std::get<TyAssoc>(cases()).a0), prism_rtl::to_pod(std::get<TyAssoc>(cases()).a1)})
        : std::holds_alternative<TyAny>(cases()) ? Pod::choice("TyAny", {prism_rtl::to_pod(std::get<TyAny>(cases()).a0)})
        : std::holds_alternative<TyErr>(cases()) ? Pod::choice("TyErr", {})
        : Pod();
}

Result<Ty> Ty::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TyFlex" && c->args.size() == 1) return Ty(TyFlex{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "TyRigid" && c->args.size() == 1) return Ty(TyRigid{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TyQ" && c->args.size() == 1) return Ty(TyQ{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TyCon" && c->args.size() == 2) return Ty(TyCon{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Ty>>(c->args[1]))});
        if (c->ctor == "TyFn" && c->args.size() == 3) return Ty(TyFn{TRY(prism_rtl::from_pod<Col>(c->args[0])), TRY(prism_rtl::from_pod<Array<Ty>>(c->args[1])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[2]))});
        if (c->ctor == "TyTuple" && c->args.size() == 1) return Ty(TyTuple{TRY(prism_rtl::from_pod<Array<Ty>>(c->args[0]))});
        if (c->ctor == "TyArray" && c->args.size() == 1) return Ty(TyArray{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[0]))});
        if (c->ctor == "TyMap" && c->args.size() == 2) return Ty(TyMap{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[1]))});
        if (c->ctor == "TySig" && c->args.size() == 2) return Ty(TySig{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[1]))});
        if (c->ctor == "TyAt" && c->args.size() == 2) return Ty(TyAt{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[0])), TRY(prism_rtl::from_pod<Rw>(c->args[1]))});
        if (c->ctor == "TyElem" && c->args.size() == 2) return Ty(TyElem{TRY(prism_rtl::from_pod<Rw>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[1]))});
        if (c->ctor == "TyElemAny" && c->args.size() == 1) return Ty(TyElemAny{TRY(prism_rtl::from_pod<Rw>(c->args[0]))});
        if (c->ctor == "TyAssoc" && c->args.size() == 2) return Ty(TyAssoc{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[1]))});
        if (c->ctor == "TyAny" && c->args.size() == 1) return Ty(TyAny{TRY(prism_rtl::from_pod<Array<Text>>(c->args[0]))});
        if (c->ctor == "TyErr" && c->args.size() == 0) return Ty(TyErr{});
    }
    return mismatch<Ty>("a Ty", p);
}


void VInfo::show(Printer& p) const {
    p.record("VInfo", {{"plain", plain_p}, {"level", level_p}, {"name", name_p}});
}

Pod VInfo::to_pod() const {
    return Pod::record("VInfo", {{"plain", prism_rtl::to_pod(plain_p)}, {"level", prism_rtl::to_pod(level_p)}, {"name", prism_rtl::to_pod(name_p)}});
}

Result<VInfo> VInfo::from_pod(const Pod& whole) {
    return VInfo{.plain_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "plain")))), .level_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "level")))), .name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name"))))};
}


void Want::show(Printer& p) const {
    p.record("Want", {{"cls", cls_p}, {"ty", ty_p}, {"file", file_p}, {"span", span_p}, {"level", level_p}});
}

Pod Want::to_pod() const {
    return Pod::record("Want", {{"cls", prism_rtl::to_pod(cls_p)}, {"ty", prism_rtl::to_pod(ty_p)}, {"file", prism_rtl::to_pod(file_p)}, {"span", prism_rtl::to_pod(span_p)}, {"level", prism_rtl::to_pod(level_p)}});
}

Result<Want> Want::from_pod(const Pod& whole) {
    return Want{.cls_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "cls")))), .ty_p = TRY(prism_rtl::from_pod<Ty>(TRY(crate::prelude::field(whole, "ty")))), .file_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .level_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "level"))))};
}


/// NewSt: fn Nat -> St
St new_st_f(const Nat& file_p0) {
    return St{.next_p = Nat(0u), .tys_p = Map<Nat, Ty>{}, .infos_p = Map<Nat, VInfo>{}, .rows_p = Map<Nat, Rw>{}, .lacks_p = Map<Nat, Array<Text>>{}, .wants_p = Array<Want>{}, .incls_p = Array<Incl>{}, .diags_p = Array<crate::check::errors::CDiag>{}, .level_p = Nat(0u), .file_p = file_p0, .color_p = Col(Col::CBound{}), .color_why_p = Text::lit(""), .color_flex_p = Array<std::tuple<Col, Text, crate::syntax::Range>>{}, .cols_p = Map<Nat, Col>{}, .cleqs_p = Array<CLeq>{}, .col_q_p = Map<Nat, Text>{}, .col_up_p = Map<Text, Text>{}, .deferred_p = Array<std::tuple<Ty, Ty, crate::syntax::Range>>{}, .binder_at_p = Map<Nat, crate::syntax::Range>{}, .row_names_p = Map<Nat, Text>{}, .layer_qs_p = Array<std::tuple<Ty, crate::syntax::Range, Text>>{}, .field_qs_p = Array<crate::check::types::unify::FieldQ>{}, .recording_p = false, .typed_p = crate::check::typed::empty_typed_p(), .choices_p = Map<Text, Array<Text>>{}, .size_tys_p = Map<Text, Ty>{}, .local_next_p = Nat(0u), .local_ids_p = Map<Text, Nat>{}, .any_givens_p = Array<std::tuple<Text, Text>>{}};
}


/// Closed: fn [Text] -> Rw
Rw closed_f(const Array<Text>& fs_p0) {
    return Rw{.fams_p = sort_texts_f(fs_p0), .minus_p = Array<Text>{}, .tail_p = Tail(Tail::TlClosed{})};
}


/// let emptyRow
Rw empty_row_p() {
    return Rw{.fams_p = Array<Text>{}, .minus_p = Array<Text>{}, .tail_p = Tail(Tail::TlClosed{})};
}


/// let tInt
Ty t_int_p() {
    return Ty(Ty::TyCon{Text::lit("Int"), Array<Ty>{}});
}


/// let tNat
Ty t_nat_p() {
    return Ty(Ty::TyCon{Text::lit("Nat"), Array<Ty>{}});
}


/// let tText
Ty t_text_p() {
    return Ty(Ty::TyCon{Text::lit("Text"), Array<Ty>{}});
}


/// let tBool
Ty t_bool_p() {
    return Ty(Ty::TyCon{Text::lit("Bool"), Array<Ty>{}});
}


/// let tUnit
Ty t_unit_p() {
    return Ty(Ty::TyCon{Text::lit("unit"), Array<Ty>{}});
}


/// let tChar
Ty t_char_p() {
    return Ty(Ty::TyCon{Text::lit("Char"), Array<Ty>{}});
}


/// let tFloat
Ty t_float_p() {
    return Ty(Ty::TyCon{Text::lit("Float"), Array<Ty>{}});
}


/// HasText: fn [Text], Text -> Bool
bool has_text_f(const Array<Text>& xs_p0, const Text& x_p1) {
    return crate::prelude::fold(xs_p0, false, [&](const bool& seen_p2, const Text& y_p3) { return prism_rtl::deref(seen_p2) || (y_p3 == x_p1); });
}


/// HasNat: fn [Nat], Nat -> Bool
bool has_nat_f(const Array<Nat>& xs_p0, const Nat& x_p1) {
    return crate::prelude::fold(xs_p0, false, [&](const bool& seen_p2, const Nat& y_p3) { return prism_rtl::deref(seen_p2) || (y_p3 == x_p1); });
}


/// AddText: fn [Text], Text -> [Text]
Array<Text> add_text_f(const Array<Text>& xs_p0, const Text& x_p1) {
    return has_text_f(xs_p0, x_p1) ? xs_p0 : crate::prelude::push(xs_p0, x_p1);
}


/// UnionTexts: fn [Text], [Text] -> [Text]
Array<Text> union_texts_f(const Array<Text>& xs_p0, const Array<Text>& ys_p1) {
    return crate::prelude::fold(ys_p1, xs_p0, [&](const Array<Text>& acc_p2, const Text& y_p3) { return add_text_f(acc_p2, y_p3); });
}


/// MinusTexts: fn [Text], [Text] -> [Text]
Array<Text> minus_texts_f(const Array<Text>& xs_p0, const Array<Text>& ys_p1) {
    return crate::prelude::filter(xs_p0, [&](const Text& x_p2) { return !has_text_f(ys_p1, x_p2); });
}


/// InterTexts: fn [Text], [Text] -> [Text]
Array<Text> inter_texts_f(const Array<Text>& xs_p0, const Array<Text>& ys_p1) {
    return crate::prelude::filter(xs_p0, [&](const Text& x_p2) { return has_text_f(ys_p1, x_p2); });
}


/// AddNat: fn [Nat], Nat -> [Nat]
Array<Nat> add_nat_f(const Array<Nat>& xs_p0, const Nat& x_p1) {
    return has_nat_f(xs_p0, x_p1) ? xs_p0 : crate::prelude::push(xs_p0, x_p1);
}


/// SortTexts: fn [Text] -> [Text]
Array<Text> sort_texts_f(const Array<Text>& xs_p0) {
    return crate::prelude::fold(xs_p0, Array<Text>{}, [&](const Array<Text>& acc_p1, const Text& x_p2) {
        return has_text_f(acc_p1, x_p2)
            ? acc_p1
            : crate::prelude::append(crate::prelude::push(crate::prelude::filter(acc_p1, [&](const Text& y_p3) { return y_p3 < x_p2; }), x_p2), crate::prelude::filter(acc_p1, [&](const Text& y_p4) { return !(y_p4 < x_p2); }));
    });
}


/// BareName: fn Text -> Text
Text bare_name_f(const Text& q_p0) {
    return crate::prelude::or_(crate::syntax::lexer::chars::last_o(crate::prelude::split_on(q_p0, Text::lit("."))), q_p0);
}


/// FreshVar: fn St, Bool, Text -> ((Ty, St))
std::tuple<Ty, St> fresh_var_f(const St& st_p0, const bool& plain_p1, const Text& name_p2) {
    auto n_p3 = st_p0.next_p;
    auto st2_p4 = ({
        St this_ = st_p0;
        this_.next_p = this_.next_p + Nat(1u);
        this_.infos_p = crate::prelude::insert(this_.infos_p, n_p3, VInfo{.plain_p = plain_p1, .level_p = this_.level_p, .name_p = name_p2});
        (std::move(this_));
    });
    return std::tuple{Ty(Ty::TyFlex{n_p3}), st2_p4};
}


/// FreshCol: fn St -> ((Col, St))
std::tuple<Col, St> fresh_col_f(const St& st_p0) {
    auto n_p1 = st_p0.next_p;
    auto st2_p2 = ({
        St this_ = st_p0;
        this_.next_p = this_.next_p + Nat(1u);
        this_.infos_p = crate::prelude::insert(this_.infos_p, n_p1, VInfo{.plain_p = false, .level_p = this_.level_p, .name_p = Text::lit("")});
        (std::move(this_));
    });
    return std::tuple{Col(Col::CFlex{n_p1}), st2_p2};
}


/// StackOf: unbounded fn St, Ty -> Text
Text stack_of_f(const St& st_p0, const Ty& t_p1) {
    auto&& _m = crate::check::types::recording::walk_f(st_p0, t_p1);
    if (prism_rtl::is<Ty::TySig>(_m)) {
        auto&& s_p2 = prism_rtl::as<Ty::TySig>(_m).a0;
        auto&& i_p3 = prism_rtl::as<Ty::TySig>(_m).a1;
        return prism_rtl::cat(s_p2, stack_of_f(st_p0, prism_rtl::deref(i_p3)));
    }
    if (prism_rtl::is<Ty::TyAt>(_m)) {
        auto&& i_p4 = prism_rtl::as<Ty::TyAt>(_m).a0;
        return prism_rtl::cat("@", stack_of_f(st_p0, prism_rtl::deref(i_p4)));
    }
    {
        return Text::lit("");
    }
}


prism_rtl::Turn<Text> StackOf::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0x = st_p0;
    auto t_p1x = t_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x, t_p1x), [=](Ty walk_f_8402) {
        return ({
            prism_rtl::is<Ty::TySig>(walk_f_8402) ? ({
            auto&& s_p2 = prism_rtl::as<Ty::TySig>(walk_f_8402).a0;
            auto&& i_p3 = prism_rtl::as<Ty::TySig>(walk_f_8402).a1;
            crate::prelude::call_then(start_stack_of_f(st_p0x, prism_rtl::deref(i_p3)), [=](Text stack_of_f_8435) { return prism_rtl::finished(prism_rtl::cat(s_p2, stack_of_f_8435)); });
        })
            : prism_rtl::is<Ty::TyAt>(walk_f_8402) ? ({
            auto&& i_p4 = prism_rtl::as<Ty::TyAt>(walk_f_8402).a0;
            crate::prelude::call_then(start_stack_of_f(st_p0x, prism_rtl::deref(i_p4)), [=](Text stack_of_f_8474) { return prism_rtl::finished(prism_rtl::cat("@", stack_of_f_8474)); });
        })
            : prism_rtl::finished(Text::lit(""));
        });
    });
}


/// `Start StackOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_stack_of_f(St st_p0, Ty t_p1) {
    return prism_rtl::make_rc<StackOf>(st_p0, t_p1);
}


/// HeadSigil: unbounded fn St, Ty -> Text
Text head_sigil_f(const St& st_p0, const Ty& t_p1) {
    auto&& _m = crate::check::types::recording::walk_f(st_p0, t_p1);
    if (prism_rtl::is<Ty::TySig>(_m)) {
        auto&& s_p2 = prism_rtl::as<Ty::TySig>(_m).a0;
        return s_p2;
    }
    if (prism_rtl::is<Ty::TyAt>(_m)) {
        return Text::lit("@");
    }
    {
        return Text::lit("");
    }
}


prism_rtl::Turn<Text> HeadSigil::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0x = st_p0;
    auto t_p1x = t_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x, t_p1x), [=](Ty walk_f_8652) {
        return ({
            prism_rtl::is<Ty::TySig>(walk_f_8652) ? ({
            auto&& s_p2 = prism_rtl::as<Ty::TySig>(walk_f_8652).a0;
            prism_rtl::finished(s_p2);
        })
            : prism_rtl::is<Ty::TyAt>(walk_f_8652) ? prism_rtl::finished(Text::lit("@"))
            : prism_rtl::finished(Text::lit(""));
        });
    });
}


/// `Start HeadSigil, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_head_sigil_f(St st_p0, Ty t_p1) {
    return prism_rtl::make_rc<HeadSigil>(st_p0, t_p1);
}


/// IsFlexVar: unbounded fn St, Ty -> Bool
bool is_flex_var_f(const St& st_p0, const Ty& t_p1) {
    auto&& _m = crate::check::types::recording::walk_f(st_p0, t_p1);
    if (prism_rtl::is<Ty::TyFlex>(_m)) {
        return true;
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsFlexVar::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0x = st_p0;
    auto t_p1x = t_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x, t_p1x), [=](Ty walk_f_8801) {
        return ({
            prism_rtl::is<Ty::TyFlex>(walk_f_8801) ? prism_rtl::finished(true)
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsFlexVar, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_flex_var_f(St st_p0, Ty t_p1) {
    return prism_rtl::make_rc<IsFlexVar>(st_p0, t_p1);
}


/// IsFreeHeaded: unbounded fn St, Ty -> Bool
bool is_free_headed_f(const St& st_p0, const Ty& t_p1) {
    auto&& _m = crate::check::types::recording::walk_f(st_p0, t_p1);
    if (prism_rtl::is<Ty::TyFlex>(_m)) {
        auto&& n_p2 = prism_rtl::as<Ty::TyFlex>(_m).a0;
        return !prism_rtl::deref(crate::check::types::recording::info_of_f(st_p0, n_p2)).plain_p;
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsFreeHeaded::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0x = st_p0;
    auto t_p1x = t_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x, t_p1x), [=](Ty walk_f_9009) {
        return ({
            prism_rtl::is<Ty::TyFlex>(walk_f_9009) ? ({
            auto&& n_p2 = prism_rtl::as<Ty::TyFlex>(walk_f_9009).a0;
            prism_rtl::finished(!prism_rtl::deref(crate::check::types::recording::info_of_f(st_p0x, n_p2)).plain_p);
        })
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsFreeHeaded, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_free_headed_f(St st_p0, Ty t_p1) {
    return prism_rtl::make_rc<IsFreeHeaded>(st_p0, t_p1);
}


/// WithMarks: fn Text, Ty, Rw -> Ty
Ty with_marks_f(const Text& marks_p0, const Ty& t_p1, const Rw& rw_p2) {
    return crate::prelude::fold(reverse2_f(crate::syntax::lexer::chars::fold_chars_f(marks_p0, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::once_job([=]() {
            return ({
                auto acc_p3 = p0;
                auto c_p4 = p1;
                (prism_rtl::finished(crate::prelude::push(acc_p3, c_p4)));
            });
        });
    })))), t_p1, [&](const Ty& acc_p5, const Text& m_p6) {
        return m_p6 == Text::lit("@")
            ? Ty(Ty::TyAt{prism_rtl::rc(acc_p5), rw_p2})
            : Ty(Ty::TySig{m_p6, prism_rtl::rc(acc_p5)});
    });
}


/// Reverse2: fn [Text] -> [Text]
Array<Text> reverse2_f(const Array<Text>& xs_p0) {
    return crate::prelude::fold(xs_p0, Array<Text>{}, [&](const Array<Text>& acc_p1, const Text& x_p2) { return crate::prelude::append(Array(std::vector{x_p2}), acc_p1); });
}


/// ShowTy: unbounded fn St, Ty -> Text
Text show_ty_f(const St& st_p0, const Ty& t_p1) {
    return show_ty_in_f(st_p0, crate::check::types::recording::zonk_f(st_p0, t_p1), false);
}


prism_rtl::Turn<Text> ShowTy::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0x = st_p0;
    auto t_p1x = t_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p0x, t_p1x), [=](Ty zonk_f_9735) { return prism_rtl::more(prism_rtl::rc(ShowTyIn(st_p0x, zonk_f_9735, false))); });
}


/// `Start ShowTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_ty_f(St st_p0, Ty t_p1) {
    return prism_rtl::make_rc<ShowTy>(st_p0, t_p1);
}


/// ShowTyIn: unbounded fn St, Ty, Bool -> Text
Text show_ty_in_f(const St& st_p0, const Ty& t_p1, const bool& nested_p2) {
    if (prism_rtl::is<Ty::TyFlex>(t_p1)) {
        auto&& n_p3 = prism_rtl::as<Ty::TyFlex>(t_p1).a0;
        return prism_rtl::cat("t", n_p3);
    }
    if (prism_rtl::is<Ty::TyRigid>(t_p1)) {
        auto&& n_p4 = prism_rtl::as<Ty::TyRigid>(t_p1).a0;
        return n_p4;
    }
    if (prism_rtl::is<Ty::TyQ>(t_p1)) {
        auto&& n_p5 = prism_rtl::as<Ty::TyQ>(t_p1).a0;
        return n_p5;
    }
    if (prism_rtl::is<Ty::TyCon>(t_p1)) {
        auto&& n_p6 = prism_rtl::as<Ty::TyCon>(t_p1).a0;
        auto&& m9897_3_1 = prism_rtl::as<Ty::TyCon>(t_p1).a1;
        if (m9897_3_1.size() == 0u) {
            return bare_name_f(n_p6);
        }
    }
    if (prism_rtl::is<Ty::TyCon>(t_p1)) {
        auto&& n_p7 = prism_rtl::as<Ty::TyCon>(t_p1).a0;
        auto&& args_p8 = prism_rtl::as<Ty::TyCon>(t_p1).a1;
        auto inner_p9 = prism_rtl::cat(bare_name_f(n_p7), crate::prelude::concat(crate::prelude::run_to_end(crate::prelude::each_job(args_p8, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](Ty p0) {
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto a_pa = p0;
                    (crate::prelude::call_then(start_show_ty_in_f(st_p0xy, a_pa, true), [=](Text show_ty_in_f_10067) { return prism_rtl::finished(prism_rtl::cat(" ", show_ty_in_f_10067)); }));
                });
            })));
            });
        })));
        })))));
        return nested_p2 ? prism_rtl::cat("(", inner_p9, ")") : inner_p9;
    }
    if (prism_rtl::is<Ty::TyFn>(t_p1)) {
        auto&& c_pb = prism_rtl::as<Ty::TyFn>(t_p1).a0;
        auto&& ps_pc = prism_rtl::as<Ty::TyFn>(t_p1).a1;
        auto&& res_pd = prism_rtl::as<Ty::TyFn>(t_p1).a2;
        auto inner_pe = prism_rtl::cat(show_col_f(c_pb), "fn ", crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(ps_pc, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](Ty p0) {
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto p_pf = p0;
                    (prism_rtl::more(prism_rtl::rc(ShowTyIn(st_p0xy, p_pf, false))));
                });
            })));
            });
        })));
        }))), Text::lit(", ")), " -> ", show_ty_in_f(st_p0, prism_rtl::deref(prism_rtl::deref(res_pd)), false));
        return nested_p2 ? prism_rtl::cat("(", inner_pe, ")") : inner_pe;
    }
    if (prism_rtl::is<Ty::TyTuple>(t_p1)) {
        auto&& ts_pg = prism_rtl::as<Ty::TyTuple>(t_p1).a0;
        return prism_rtl::cat("((", crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(ts_pg, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](Ty p0) {
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto a_ph = p0;
                    (prism_rtl::more(prism_rtl::rc(ShowTyIn(st_p0xy, a_ph, false))));
                });
            })));
            });
        })));
        }))), Text::lit(", ")), "))");
    }
    if (prism_rtl::is<Ty::TyArray>(t_p1)) {
        auto&& e_pi = prism_rtl::as<Ty::TyArray>(t_p1).a0;
        auto inner_pj = show_ty_in_f(st_p0, prism_rtl::deref(prism_rtl::deref(e_pi)), false);
        return crate::syntax::lexer::chars::has_prefix_f(inner_pj, Text::lit("["))
            ? prism_rtl::cat("[ ", inner_pj, " ]")
            : prism_rtl::cat("[", inner_pj, "]");
    }
    if (prism_rtl::is<Ty::TyMap>(t_p1)) {
        auto&& k_pk = prism_rtl::as<Ty::TyMap>(t_p1).a0;
        auto&& v_pl = prism_rtl::as<Ty::TyMap>(t_p1).a1;
        auto inner_pm = prism_rtl::cat(show_ty_in_f(st_p0, prism_rtl::deref(prism_rtl::deref(k_pk)), true), " ==> ", show_ty_in_f(st_p0, prism_rtl::deref(prism_rtl::deref(v_pl)), true));
        return nested_p2 ? prism_rtl::cat("(", inner_pm, ")") : inner_pm;
    }
    if (prism_rtl::is<Ty::TySig>(t_p1)) {
        auto&& s_pn = prism_rtl::as<Ty::TySig>(t_p1).a0;
        auto&& i_po = prism_rtl::as<Ty::TySig>(t_p1).a1;
        return prism_rtl::cat(s_pn, show_ty_in_f(st_p0, prism_rtl::deref(prism_rtl::deref(i_po)), true));
    }
    if (prism_rtl::is<Ty::TyAt>(t_p1)) {
        auto&& i_pp = prism_rtl::as<Ty::TyAt>(t_p1).a0;
        auto&& rw_pq = prism_rtl::as<Ty::TyAt>(t_p1).a1;
        return prism_rtl::cat("@", show_ty_in_f(st_p0, prism_rtl::deref(prism_rtl::deref(i_pp)), true));
    }
    if (prism_rtl::is<Ty::TyElem>(t_p1)) {
        auto&& rw_pr = prism_rtl::as<Ty::TyElem>(t_p1).a0;
        auto&& o_ps = prism_rtl::as<Ty::TyElem>(t_p1).a1;
        auto inner_pt = prism_rtl::cat("Element ", show_row_in_f(rw_pr, true), " ", show_ty_in_f(st_p0, prism_rtl::deref(prism_rtl::deref(o_ps)), true));
        return nested_p2 ? prism_rtl::cat("(", inner_pt, ")") : inner_pt;
    }
    if (prism_rtl::is<Ty::TyElemAny>(t_p1)) {
        auto&& rw_pu = prism_rtl::as<Ty::TyElemAny>(t_p1).a0;
        return nested_p2
            ? prism_rtl::cat("(Elem ", show_row_in_f(rw_pu, true), ")")
            : prism_rtl::cat("Elem ", show_row_in_f(rw_pu, true));
    }
    if (prism_rtl::is<Ty::TyAssoc>(t_p1)) {
        auto&& n_pv = prism_rtl::as<Ty::TyAssoc>(t_p1).a0;
        auto&& a_p10 = prism_rtl::as<Ty::TyAssoc>(t_p1).a1;
        return nested_p2
            ? prism_rtl::cat("(", n_pv, " ", show_ty_in_f(st_p0, prism_rtl::deref(prism_rtl::deref(a_p10)), true), ")")
            : prism_rtl::cat(n_pv, " ", show_ty_in_f(st_p0, prism_rtl::deref(prism_rtl::deref(a_p10)), true));
    }
    if (prism_rtl::is<Ty::TyAny>(t_p1)) {
        auto&& ts_p11 = prism_rtl::as<Ty::TyAny>(t_p1).a0;
        return prism_rtl::cat("any ", crate::syntax::lexer::chars::join_f(crate::prelude::each(ts_p11, [&](const Text& x_p12) { return prism_rtl::cat("^", bare_name_f(x_p12)); }), Text::lit(" ")));
    }
    if (prism_rtl::is<Ty::TyErr>(t_p1)) {
        return Text::lit("?");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> ShowTyIn::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    const auto& nested_p2 = this->nested_p2;
    return ({
        prism_rtl::is<Ty::TyFlex>(t_p1) ? ({
        auto&& n_p3 = prism_rtl::as<Ty::TyFlex>(t_p1).a0;
        prism_rtl::finished(prism_rtl::cat("t", n_p3));
    })
        : prism_rtl::is<Ty::TyRigid>(t_p1) ? ({
        auto&& n_p4 = prism_rtl::as<Ty::TyRigid>(t_p1).a0;
        prism_rtl::finished(n_p4);
    })
        : prism_rtl::is<Ty::TyQ>(t_p1) ? ({
        auto&& n_p5 = prism_rtl::as<Ty::TyQ>(t_p1).a0;
        prism_rtl::finished(n_p5);
    })
        : prism_rtl::is<Ty::TyCon>(t_p1) && ({
        auto&& n_p6 = prism_rtl::as<Ty::TyCon>(t_p1).a0;
        auto&& m9897_3_1 = prism_rtl::as<Ty::TyCon>(t_p1).a1;
        (m9897_3_1.size() == 0u);
    }) ? ({
        auto&& n_p6 = prism_rtl::as<Ty::TyCon>(t_p1).a0;
        auto&& m9897_3_1 = prism_rtl::as<Ty::TyCon>(t_p1).a1;
        prism_rtl::finished(bare_name_f(n_p6));
    })
        : prism_rtl::is<Ty::TyCon>(t_p1) ? ({
        auto&& n_p7 = prism_rtl::as<Ty::TyCon>(t_p1).a0;
        auto&& args_p8 = prism_rtl::as<Ty::TyCon>(t_p1).a1;
        ({
        auto args_p8x = args_p8;
        auto n_p7x = n_p7;
        auto nested_p2x = prism_rtl::deref(nested_p2);
        auto st_p0x = st_p0;
        (crate::prelude::call_value(crate::prelude::each_job(args_p8x, ({
        auto st_p0xx = st_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](Ty p0) {
        return ({
            auto st_p0xxy = st_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
            return ({
                auto a_pa = p0;
                (crate::prelude::call_then(start_show_ty_in_f(st_p0xxy, a_pa, true), [=](Text show_ty_in_f_10067) { return prism_rtl::finished(prism_rtl::cat(" ", show_ty_in_f_10067)); }));
            });
        })));
        });
    })));
    })), [=, n_p7x = std::move(n_p7x), nested_p2x = std::move(nested_p2x)](Array<Text> each_10048) {
        return ({
            auto inner_p9 = prism_rtl::cat(bare_name_f(n_p7x), crate::prelude::concat(each_10048));
            nested_p2x
            ? prism_rtl::finished(prism_rtl::cat("(", inner_p9, ")"))
            : prism_rtl::finished(inner_p9);
        });
    }));
    });
    })
        : prism_rtl::is<Ty::TyFn>(t_p1) ? ({
        auto&& c_pb = prism_rtl::as<Ty::TyFn>(t_p1).a0;
        auto&& ps_pc = prism_rtl::as<Ty::TyFn>(t_p1).a1;
        auto&& res_pd = prism_rtl::as<Ty::TyFn>(t_p1).a2;
        ({
        auto c_pbx = c_pb;
        auto nested_p2x = prism_rtl::deref(nested_p2);
        auto ps_pcx = ps_pc;
        auto res_pdx = prism_rtl::deref(prism_rtl::deref(res_pd));
        auto st_p0x = st_p0;
        (crate::prelude::call_value(crate::prelude::each_job(ps_pcx, ({
        auto st_p0xx = st_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](Ty p0) {
        return ({
            auto st_p0xxy = st_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
            return ({
                auto p_pf = p0;
                (prism_rtl::more(prism_rtl::rc(ShowTyIn(st_p0xxy, p_pf, false))));
            });
        })));
        });
    })));
    })), [=, c_pbx = std::move(c_pbx), nested_p2x = std::move(nested_p2x), res_pdx = std::move(res_pdx)](Array<Text> each_10199) {
        return crate::prelude::call_then(start_show_ty_in_f(st_p0x, res_pdx, false), [=](Text show_ty_in_f_10247) {
            return ({
                auto inner_pe = prism_rtl::cat(show_col_f(c_pbx), "fn ", crate::syntax::lexer::chars::join_f(each_10199, Text::lit(", ")), " -> ", show_ty_in_f_10247);
                nested_p2x
                ? prism_rtl::finished(prism_rtl::cat("(", inner_pe, ")"))
                : prism_rtl::finished(inner_pe);
            });
        });
    }));
    });
    })
        : prism_rtl::is<Ty::TyTuple>(t_p1) ? ({
        auto&& ts_pg = prism_rtl::as<Ty::TyTuple>(t_p1).a0;
        ({
        auto st_p0x = st_p0;
        auto ts_pgx = ts_pg;
        (crate::prelude::call_value(crate::prelude::each_job(ts_pgx, ({
        auto st_p0xx = st_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](Ty p0) {
        return ({
            auto st_p0xxy = st_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
            return ({
                auto a_ph = p0;
                (prism_rtl::more(prism_rtl::rc(ShowTyIn(st_p0xxy, a_ph, false))));
            });
        })));
        });
    })));
    })), [=](Array<Text> each_10342) { return prism_rtl::finished(prism_rtl::cat("((", crate::syntax::lexer::chars::join_f(each_10342, Text::lit(", ")), "))")); }));
    });
    })
        : prism_rtl::is<Ty::TyArray>(t_p1) ? ({
        auto&& e_pi = prism_rtl::as<Ty::TyArray>(t_p1).a0;
        ({
        auto e_pix = prism_rtl::deref(prism_rtl::deref(e_pi));
        auto st_p0x = st_p0;
        (crate::prelude::call_then(start_show_ty_in_f(st_p0x, e_pix, false), [=](Text show_ty_in_f_10424) {
        return ({
            auto inner_pj = show_ty_in_f_10424;
            (crate::syntax::lexer::chars::has_prefix_f(inner_pj, Text::lit("["))
            ? prism_rtl::finished(prism_rtl::cat("[ ", inner_pj, " ]"))
            : prism_rtl::finished(prism_rtl::cat("[", inner_pj, "]")));
        });
    }));
    });
    })
        : prism_rtl::is<Ty::TyMap>(t_p1) ? ({
        auto&& k_pk = prism_rtl::as<Ty::TyMap>(t_p1).a0;
        auto&& v_pl = prism_rtl::as<Ty::TyMap>(t_p1).a1;
        ({
        auto k_pkx = prism_rtl::deref(prism_rtl::deref(k_pk));
        auto nested_p2x = prism_rtl::deref(nested_p2);
        auto st_p0x = st_p0;
        auto v_plx = prism_rtl::deref(prism_rtl::deref(v_pl));
        (crate::prelude::call_then(start_show_ty_in_f(st_p0x, k_pkx, true), [=, nested_p2x = std::move(nested_p2x), v_plx = std::move(v_plx)](Text show_ty_in_f_10551) {
        return crate::prelude::call_then(start_show_ty_in_f(st_p0x, v_plx, true), [=](Text show_ty_in_f_10578) {
            return ({
                auto inner_pm = prism_rtl::cat(show_ty_in_f_10551, " ==> ", show_ty_in_f_10578);
                nested_p2x
                ? prism_rtl::finished(prism_rtl::cat("(", inner_pm, ")"))
                : prism_rtl::finished(inner_pm);
            });
        });
    }));
    });
    })
        : prism_rtl::is<Ty::TySig>(t_p1) ? ({
        auto&& s_pn = prism_rtl::as<Ty::TySig>(t_p1).a0;
        auto&& i_po = prism_rtl::as<Ty::TySig>(t_p1).a1;
        ({
        auto i_pox = prism_rtl::deref(prism_rtl::deref(i_po));
        auto s_pnx = s_pn;
        auto st_p0x = st_p0;
        (crate::prelude::call_then(start_show_ty_in_f(st_p0x, i_pox, true), [=, s_pnx = std::move(s_pnx)](Text show_ty_in_f_10665) { return prism_rtl::finished(prism_rtl::cat(s_pnx, show_ty_in_f_10665)); }));
    });
    })
        : prism_rtl::is<Ty::TyAt>(t_p1) ? ({
        auto&& i_pp = prism_rtl::as<Ty::TyAt>(t_p1).a0;
        auto&& rw_pq = prism_rtl::as<Ty::TyAt>(t_p1).a1;
        ({
        auto i_ppx = prism_rtl::deref(prism_rtl::deref(i_pp));
        auto st_p0x = st_p0;
        (crate::prelude::call_then(start_show_ty_in_f(st_p0x, i_ppx, true), [=](Text show_ty_in_f_10707) { return prism_rtl::finished(prism_rtl::cat("@", show_ty_in_f_10707)); }));
    });
    })
        : prism_rtl::is<Ty::TyElem>(t_p1) ? ({
        auto&& rw_pr = prism_rtl::as<Ty::TyElem>(t_p1).a0;
        auto&& o_ps = prism_rtl::as<Ty::TyElem>(t_p1).a1;
        ({
        auto nested_p2x = prism_rtl::deref(nested_p2);
        auto o_psx = prism_rtl::deref(prism_rtl::deref(o_ps));
        auto rw_prx = rw_pr;
        auto st_p0x = st_p0;
        (crate::prelude::call_then(start_show_ty_in_f(st_p0x, o_psx, true), [=, nested_p2x = std::move(nested_p2x), rw_prx = std::move(rw_prx)](Text show_ty_in_f_10799) {
        return ({
            auto inner_pt = prism_rtl::cat("Element ", show_row_in_f(rw_prx, true), " ", show_ty_in_f_10799);
            nested_p2x
            ? prism_rtl::finished(prism_rtl::cat("(", inner_pt, ")"))
            : prism_rtl::finished(inner_pt);
        });
    }));
    });
    })
        : prism_rtl::is<Ty::TyElemAny>(t_p1) ? ({
        auto&& rw_pu = prism_rtl::as<Ty::TyElemAny>(t_p1).a0;
        prism_rtl::deref(nested_p2)
        ? prism_rtl::finished(prism_rtl::cat("(Elem ", show_row_in_f(rw_pu, true), ")"))
        : prism_rtl::finished(prism_rtl::cat("Elem ", show_row_in_f(rw_pu, true)));
    })
        : prism_rtl::is<Ty::TyAssoc>(t_p1) ? ({
        auto&& n_pv = prism_rtl::as<Ty::TyAssoc>(t_p1).a0;
        auto&& a_p10 = prism_rtl::as<Ty::TyAssoc>(t_p1).a1;
        prism_rtl::deref(nested_p2)
        ? ({
        auto a_p10x = prism_rtl::deref(prism_rtl::deref(a_p10));
        auto n_pvx = n_pv;
        auto st_p0x = st_p0;
        (crate::prelude::call_then(start_show_ty_in_f(st_p0x, a_p10x, true), [=, n_pvx = std::move(n_pvx)](Text show_ty_in_f_10994) { return prism_rtl::finished(prism_rtl::cat("(", n_pvx, " ", show_ty_in_f_10994, ")")); }));
    })
        : ({
        auto a_p10x = prism_rtl::deref(prism_rtl::deref(a_p10));
        auto n_pvx = n_pv;
        auto st_p0x = st_p0;
        (crate::prelude::call_then(start_show_ty_in_f(st_p0x, a_p10x, true), [=, n_pvx = std::move(n_pvx)](Text show_ty_in_f_11030) { return prism_rtl::finished(prism_rtl::cat(n_pvx, " ", show_ty_in_f_11030)); }));
    });
    })
        : prism_rtl::is<Ty::TyAny>(t_p1) ? ({
        auto&& ts_p11 = prism_rtl::as<Ty::TyAny>(t_p1).a0;
        prism_rtl::finished(prism_rtl::cat("any ", crate::syntax::lexer::chars::join_f(crate::prelude::each(ts_p11, [&](const Text& x_p12) { return prism_rtl::cat("^", bare_name_f(x_p12)); }), Text::lit(" "))));
    })
        : prism_rtl::is<Ty::TyErr>(t_p1) ? prism_rtl::finished(Text::lit("?"))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ShowTyIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_ty_in_f(St st_p0, Ty t_p1, bool nested_p2) {
    return prism_rtl::make_rc<ShowTyIn>(st_p0, t_p1, nested_p2);
}


/// ShowCol: fn Col -> Text
Text show_col_f(const Col& col0) {
    if (prism_rtl::is<Col::CBound>(col0)) {
        return Text::lit("");
    }
    if (prism_rtl::is<Col::CUnbound>(col0)) {
        return Text::lit("unbounded ");
    }
    if (prism_rtl::is<Col::CRigid>(col0)) {
        auto&& n_p0 = prism_rtl::as<Col::CRigid>(col0).a0;
        return prism_rtl::cat(n_p0, " ");
    }
    if (prism_rtl::is<Col::CQ>(col0)) {
        auto&& n_p1 = prism_rtl::as<Col::CQ>(col0).a0;
        return prism_rtl::cat(n_p1, " ");
    }
    if (prism_rtl::is<Col::CFlex>(col0)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ShowRow: fn Rw -> Text
Text show_row_f(const Rw& rw_p0) {
    return show_row_in_f(rw_p0, false);
}


/// ShowRowIn: fn Rw, Bool -> Text
Text show_row_in_f(const Rw& rw_p0, const bool& nested_p1) {
    auto fams_p2 = crate::prelude::each(rw_p0.fams_p, [&](const Text& f_p7) { return prism_rtl::cat(f_p7, ".*"); });
    auto tail_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = rw_p0.tail_p;
        if (prism_rtl::is<Tail::TlClosed>(_m)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        if (prism_rtl::is<Tail::TlFlex>(_m)) {
            auto&& n_p8 = prism_rtl::as<Tail::TlFlex>(_m).a0;
            _v.set(Array(std::vector{prism_rtl::cat("r", n_p8)}));
            goto _done;
        }
        if (prism_rtl::is<Tail::TlRigid>(_m)) {
            auto&& n_p9 = prism_rtl::as<Tail::TlRigid>(_m).a0;
            _v.set(Array(std::vector{n_p9}));
            goto _done;
        }
        if (prism_rtl::is<Tail::TlQ>(_m)) {
            auto&& n_pa = prism_rtl::as<Tail::TlQ>(_m).a0;
            _v.set(Array(std::vector{n_pa}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto parts_p4 = crate::prelude::append(tail_p3, fams_p2);
    auto minus_p5 = crate::prelude::len(rw_p0.minus_p) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" − {", crate::syntax::lexer::chars::join_f(rw_p0.minus_p, Text::lit(", ")), "}");
    auto inner_p6 = crate::prelude::len(parts_p4) == Nat(0u)
        ? Text::lit("unit")
        : crate::syntax::lexer::chars::join_f(parts_p4, Text::lit(" | "));
    return nested_p1 && ((crate::prelude::len(parts_p4) > Nat(1u)) || (minus_p5 != Text::lit("")))
        ? prism_rtl::cat("(", inner_p6, minus_p5, ")")
        : prism_rtl::cat(inner_p6, minus_p5);
}

}  // namespace crate::check::types


// The module `Check.Types.Colors`, from `target/bootstrap/cpp-src/prismc/check/types/colors.prism`.
namespace crate::check::types::colors {

/// JoinCol: fn Col, Col -> Col
crate::check::types::Col join_col_f(const crate::check::types::Col& col0, const crate::check::types::Col& col1) {
    auto&& _m = std::tuple{col0, col1};
    if (prism_rtl::is<crate::check::types::Col::CBound>(std::get<0>(_m))) {
        auto&& c_p0 = std::get<1>(_m);
        return c_p0;
    }
    if (prism_rtl::is<crate::check::types::Col::CBound>(std::get<1>(_m))) {
        auto&& c_p1 = std::get<0>(_m);
        return c_p1;
    }
    if (prism_rtl::is<crate::check::types::Col::CUnbound>(std::get<0>(_m))) {
        return crate::check::types::Col(crate::check::types::Col::CUnbound{});
    }
    if (prism_rtl::is<crate::check::types::Col::CUnbound>(std::get<1>(_m))) {
        return crate::check::types::Col(crate::check::types::Col::CUnbound{});
    }
    {
        auto&& a_p2 = std::get<0>(_m);
        auto&& b_p3 = std::get<1>(_m);
        return a_p2 == b_p3
            ? a_p2
            : crate::check::types::Col(crate::check::types::Col::CUnbound{});
    }
    prism_rtl::unreachable("no arm matched");
}


/// ColLeq: fn Col, Col -> Bool
bool col_leq_f(const crate::check::types::Col& a_p0, const crate::check::types::Col& b_p1) {
    return join_col_f(a_p0, b_p1) == b_p1;
}


/// ColWord: fn Col -> Text
Text col_word_f(const crate::check::types::Col& col0) {
    if (prism_rtl::is<crate::check::types::Col::CBound>(col0)) {
        return Text::lit("bounded");
    }
    if (prism_rtl::is<crate::check::types::Col::CUnbound>(col0)) {
        return Text::lit("unbounded");
    }
    if (prism_rtl::is<crate::check::types::Col::CRigid>(col0)) {
        auto&& n_p0 = prism_rtl::as<crate::check::types::Col::CRigid>(col0).a0;
        return prism_rtl::cat("`", n_p0, "`-colored");
    }
    if (prism_rtl::is<crate::check::types::Col::CQ>(col0)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Col::CQ>(col0).a0;
        return prism_rtl::cat("`", n_p1, "`-colored");
    }
    if (prism_rtl::is<crate::check::types::Col::CFlex>(col0)) {
        return Text::lit("bounded");
    }
    prism_rtl::unreachable("no arm matched");
}


/// UseColor: unbounded fn St, Col, Text, Range -> St
crate::check::types::St use_color_f(const crate::check::types::St& st_p0, const crate::check::types::Col& c0_p1, const Text& why_p2, const crate::syntax::Range& span_p3) {
    auto&& _m = walk_col_f(st_p0, c0_p1);
    if (prism_rtl::is<crate::check::types::Col::CFlex>(_m)) {
        auto&& n_p4 = prism_rtl::as<crate::check::types::Col::CFlex>(_m).a0;
        crate::check::types::St this_ = st_p0;
        this_.color_flex_p = crate::prelude::push(this_.color_flex_p, std::tuple{crate::check::types::Col(crate::check::types::Col::CFlex{n_p4}), why_p2, span_p3});
        return this_;
    }
    {
        auto&& c_p5 = _m;
        return join_known_f(st_p0, c_p5, why_p2);
    }
}


prism_rtl::Turn<crate::check::types::St> UseColor::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& c0_p1 = this->c0_p1;
    const auto& why_p2 = this->why_p2;
    const auto& span_p3 = this->span_p3;
    auto c0_p1x = c0_p1;
    auto span_p3x = span_p3;
    auto st_p0x = st_p0;
    auto why_p2x = why_p2;
    return crate::prelude::call_then(start_walk_col_f(st_p0x, c0_p1x), [=](crate::check::types::Col walk_col_f_1582) {
        return ({
            prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_f_1582) ? ({
            auto&& n_p4 = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_f_1582).a0;
            prism_rtl::finished(({
            crate::check::types::St this_ = st_p0x;
            this_.color_flex_p = crate::prelude::push(this_.color_flex_p, std::tuple{crate::check::types::Col(crate::check::types::Col::CFlex{n_p4}), why_p2x, span_p3x});
            (std::move(this_));
        }));
        })
            : ({
            auto&& c_p5 = walk_col_f_1582;
            prism_rtl::finished(join_known_f(st_p0x, c_p5, why_p2x));
        });
        });
    });
}


/// `Start UseColor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_use_color_f(crate::check::types::St st_p0, crate::check::types::Col c0_p1, Text why_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<UseColor>(st_p0, c0_p1, why_p2, span_p3);
}


/// JoinKnown: fn St, Col, Text -> St
crate::check::types::St join_known_f(const crate::check::types::St& st_p0, const crate::check::types::Col& c0_p1, const Text& why_p2) {
    auto c_p3 = up_col_f(st_p0, c0_p1);
    crate::check::types::St this_ = st_p0;
    if (!col_leq_f(c_p3, this_.color_p)) {
        this_.color_why_p = why_p2;
    }
    this_.color_p = join_col_f(this_.color_p, c_p3);
    return this_;
}


/// UpCol: fn St, Col -> Col
crate::check::types::Col up_col_f(const crate::check::types::St& st_p0, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CRigid>(col1)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Col::CRigid>(col1).a0;
        auto&& _m = crate::prelude::get(st_p0.col_up_p, n_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& up_p2 = prism_rtl::some_of(_m);
            return crate::check::types::Col(crate::check::types::Col::CRigid{up_p2});
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::Col(crate::check::types::Col::CRigid{n_p1});
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        auto&& c_p4 = col1;
        return c_p4;
    }
}


/// WalkCol: unbounded fn St, Col -> Col
crate::check::types::Col walk_col_f(const crate::check::types::St& st_p0, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CFlex>(col1)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Col::CFlex>(col1).a0;
        auto&& _m = crate::prelude::get(st_p0.cols_p, n_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& c_p2 = prism_rtl::some_of(_m);
            return walk_col_f(st_p0, c_p2);
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::Col(crate::check::types::Col::CFlex{n_p1});
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        auto&& c_p4 = col1;
        return c_p4;
    }
}


prism_rtl::Turn<crate::check::types::Col> WalkCol::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& col1 = this->col1;
    return ({
        prism_rtl::is<crate::check::types::Col::CFlex>(col1) ? ({
        auto&& n_p1 = prism_rtl::as<crate::check::types::Col::CFlex>(col1).a0;
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(st_p0).cols_p, n_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& c_p2 = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(WalkCol(st_p0, c_p2)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::Col(crate::check::types::Col::CFlex{n_p1}))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : ({
        auto&& c_p4 = col1;
        prism_rtl::finished(c_p4);
    });
    });
}


/// `Start WalkCol, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Col> start_walk_col_f(crate::check::types::St st_p0, crate::check::types::Col col1) {
    return prism_rtl::make_rc<WalkCol>(st_p0, col1);
}


/// IsRigidCol: fn Col -> Bool
bool is_rigid_col_f(const crate::check::types::Col& col0) {
    if (prism_rtl::is<crate::check::types::Col::CRigid>(col0)) {
        return true;
    }
    {
        return false;
    }
}


/// IsOwnCol: fn St, Col -> Bool
bool is_own_col_f(const crate::check::types::St& s_p0, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CFlex>(col1)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Col::CFlex>(col1).a0;
        return prism_rtl::deref(crate::check::types::recording::info_of_f(s_p0, n_p1)).level_p > s_p0.level_p;
    }
    {
        return false;
    }
}


/// IsFlexCol: fn Col -> Bool
bool is_flex_col_f(const crate::check::types::Col& col0) {
    if (prism_rtl::is<crate::check::types::Col::CFlex>(col0)) {
        return true;
    }
    {
        return false;
    }
}


/// SettledCol: unbounded fn St, Col -> Col
crate::check::types::Col settled_col_f(const crate::check::types::St& st_p0, const crate::check::types::Col& c_p1) {
    auto&& _m = walk_col_f(st_p0, c_p1);
    if (prism_rtl::is<crate::check::types::Col::CFlex>(_m)) {
        return crate::check::types::Col(crate::check::types::Col::CBound{});
    }
    {
        auto&& other_p2 = _m;
        return other_p2;
    }
}


prism_rtl::Turn<crate::check::types::Col> SettledCol::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& c_p1 = this->c_p1;
    auto c_p1x = c_p1;
    auto st_p0x = st_p0;
    return crate::prelude::call_then(start_walk_col_f(st_p0x, c_p1x), [=](crate::check::types::Col walk_col_f_2936) {
        return ({
            prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_f_2936) ? prism_rtl::finished(crate::check::types::Col(crate::check::types::Col::CBound{}))
            : ({
            auto&& other_p2 = walk_col_f_2936;
            prism_rtl::finished(other_p2);
        });
        });
    });
}


/// `Start SettledCol, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Col> start_settled_col_f(crate::check::types::St st_p0, crate::check::types::Col c_p1) {
    return prism_rtl::make_rc<SettledCol>(st_p0, c_p1);
}


/// UnifyCol: unbounded fn St, Col, Col -> ((Text, St))
std::tuple<Text, crate::check::types::St> unify_col_f(const crate::check::types::St& st_p0, const crate::check::types::Col& a0_p1, const crate::check::types::Col& b0_p2) {
    auto a_p3 = walk_col_f(st_p0, a0_p1);
    auto b_p4 = walk_col_f(st_p0, b0_p2);
    return a_p3 == b_p4
        ? std::tuple{Text::lit(""), st_p0}
        : ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, crate::check::types::St>> _v;
        auto&& _m = std::tuple{a_p3, b_p4};
        if (prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m))) {
            auto&& x_p5 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
            auto&& other_p6 = std::get<1>(_m);
            _v.set(std::tuple{Text::lit(""), bind_col_f(st_p0, x_p5, other_p6)});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m))) {
            auto&& other_p7 = std::get<0>(_m);
            auto&& y_p8 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
            _v.set(std::tuple{Text::lit(""), bind_col_f(st_p0, y_p8, other_p7)});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Col::CQ>(std::get<0>(_m))) {
            _v.set(std::tuple{Text::lit(""), st_p0});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Col::CQ>(std::get<1>(_m))) {
            _v.set(std::tuple{Text::lit(""), st_p0});
            goto _done;
        }
        {
            _v.set(std::tuple{Text::lit("mismatch"), st_p0});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> UnifyCol::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& a0_p1 = this->a0_p1;
    const auto& b0_p2 = this->b0_p2;
    auto a0_p1x = a0_p1;
    auto b0_p2x = b0_p2;
    auto st_p0x = st_p0;
    return crate::prelude::call_then(start_walk_col_f(st_p0x, a0_p1x), [=](crate::check::types::Col walk_col_f_3231) {
        return ({
            auto a_p3 = walk_col_f_3231;
            (crate::prelude::call_then(start_walk_col_f(st_p0x, b0_p2x), [=, a_p3 = std::move(a_p3)](crate::check::types::Col walk_col_f_3258) {
            return ({
                auto b_p4 = walk_col_f_3258;
                a_p3 == b_p4
                ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0x})
                : ({
                auto&& _m = std::tuple{a_p3, b_p4};
                prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) ? ({
                auto&& x_p5 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                auto&& other_p6 = std::get<1>(_m);
                prism_rtl::finished(std::tuple{Text::lit(""), bind_col_f(st_p0x, x_p5, other_p6)});
            })
                : prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                auto&& other_p7 = std::get<0>(_m);
                auto&& y_p8 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                prism_rtl::finished(std::tuple{Text::lit(""), bind_col_f(st_p0x, y_p8, other_p7)});
            })
                : prism_rtl::is<crate::check::types::Col::CQ>(std::get<0>(_m)) ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0x})
                : prism_rtl::is<crate::check::types::Col::CQ>(std::get<1>(_m)) ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0x})
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0x});
            });
            });
        }));
        });
    });
}


/// `Start UnifyCol, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_col_f(crate::check::types::St st_p0, crate::check::types::Col a0_p1, crate::check::types::Col b0_p2) {
    return prism_rtl::make_rc<UnifyCol>(st_p0, a0_p1, b0_p2);
}


/// BindCol: fn St, Nat, Col -> St
crate::check::types::St bind_col_f(const crate::check::types::St& st_p0, const Nat& n_p1, const crate::check::types::Col& c_p2) {
    auto st2_p3 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        if (prism_rtl::is<crate::check::types::Col::CFlex>(c_p2)) {
            auto&& m_p4 = prism_rtl::as<crate::check::types::Col::CFlex>(c_p2).a0;
            _v.set(crate::check::types::unify::lower_one_f(st_p0, m_p4, prism_rtl::deref(crate::check::types::recording::info_of_f(st_p0, n_p1)).level_p));
            goto _done;
        }
        {
            _v.set(st_p0);
            goto _done;
        }
    _done:
        _v.take();
    });
    crate::check::types::St this_ = st2_p3;
    this_.cols_p = crate::prelude::insert(this_.cols_p, n_p1, c_p2);
    return this_;
}


/// FreeColVars: unbounded fn St, Ty -> [Nat]
Array<Nat> free_col_vars_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    return free_cols_into_f(st_p0, Array<Nat>{}, t_p1);
}


prism_rtl::Turn<Array<Nat>> FreeColVars::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    return prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0, Array<Nat>{}, t_p1)));
}


/// `Start FreeColVars, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_free_col_vars_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<FreeColVars>(st_p0, t_p1);
}


/// FreeColsInto: unbounded fn St, [Nat], Ty -> [Nat]
Array<Nat> free_cols_into_f(const crate::check::types::St& st_p0, const Array<Nat>& acc_p1, const crate::check::types::Ty& t_p2) {
    auto&& _m = crate::check::types::recording::walk_f(st_p0, t_p2);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& args_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(args_p3, acc_p1, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto a_p4 = p0;
                    auto x_p5 = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0xy, a_p4, x_p5))));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& c_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0;
        auto&& ps_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
        auto&& res_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        auto acc2_p9 = ({
            __label__ _done;
            prism_rtl::Slot<Array<Nat>> _v;
            auto&& _m = walk_col_f(st_p0, c_p6);
            if (prism_rtl::is<crate::check::types::Col::CFlex>(_m)) {
                auto&& n_pa = prism_rtl::as<crate::check::types::Col::CFlex>(_m).a0;
                _v.set(crate::check::types::add_nat_f(acc_p1, n_pa));
                goto _done;
            }
            {
                _v.set(acc_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
        return free_cols_into_f(st_p0, crate::prelude::run_to_end(crate::prelude::fold_job(ps_p7, acc2_p9, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto a_pb = p0;
                    auto x_pc = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0xy, a_pb, x_pc))));
                });
            })));
            });
        })));
        }))), prism_rtl::deref(res_p8));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts_pd = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_pd, acc_p1, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto a_pe = p0;
                    auto x_pf = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0xy, a_pe, x_pf))));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& e_pg = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        return free_cols_into_f(st_p0, acc_p1, prism_rtl::deref(e_pg));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k_ph = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_pi = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return free_cols_into_f(st_p0, free_cols_into_f(st_p0, acc_p1, prism_rtl::deref(k_ph)), prism_rtl::deref(v_pi));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& i_pj = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return free_cols_into_f(st_p0, acc_p1, prism_rtl::deref(i_pj));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
        auto&& i_pk = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
        return free_cols_into_f(st_p0, acc_p1, prism_rtl::deref(i_pk));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& o_pl = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
        return free_cols_into_f(st_p0, acc_p1, prism_rtl::deref(o_pl));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(_m)) {
        auto&& a_pm = prism_rtl::as<crate::check::types::Ty::TyAssoc>(_m).a1;
        return free_cols_into_f(st_p0, acc_p1, prism_rtl::deref(a_pm));
    }
    {
        return acc_p1;
    }
}


prism_rtl::Turn<Array<Nat>> FreeColsInto::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& acc_p1 = this->acc_p1;
    const auto& t_p2 = this->t_p2;
    auto acc_p1x = acc_p1;
    auto st_p0x = st_p0;
    auto t_p2x = t_p2;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x, t_p2x), [=](crate::check::types::Ty walk_f_3992) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_f_3992) ? ({
            auto&& args_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_3992).a1;
            crate::prelude::fold_job(args_p3, acc_p1x, ({
            auto st_p0xx = st_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xxy = st_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
                return ({
                    auto a_p4 = p0;
                    auto x_p5 = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0xxy, a_p4, x_p5))));
                });
            })));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::types::Ty::TyFn>(walk_f_3992) ? ({
            auto&& c_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_f_3992).a0;
            auto&& ps_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_f_3992).a1;
            auto&& res_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_f_3992).a2;
            crate::prelude::call_then(start_walk_col_f(st_p0x, c_p6), [=](crate::check::types::Col walk_col_f_4120) {
            return ({
                auto acc2_p9 = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Nat>> _v;
                    if (prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_f_4120)) {
                        auto&& n_pa = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_f_4120).a0;
                        _v.set(crate::check::types::add_nat_f(acc_p1x, n_pa));
                        goto _done;
                    }
                    {
                        _v.set(acc_p1x);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                (crate::prelude::call_value(crate::prelude::fold_job(ps_p7, acc2_p9, ({
                auto st_p0xx = st_p0x;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto st_p0xxy = st_p0xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
                    return ({
                        auto a_pb = p0;
                        auto x_pc = p1;
                        (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0xxy, a_pb, x_pc))));
                    });
                })));
                });
            })));
            })), [=](Array<Nat> fold_4223) { return prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0x, fold_4223, prism_rtl::deref(res_p8)))); }));
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyTuple>(walk_f_3992) ? ({
            auto&& ts_pd = prism_rtl::as<crate::check::types::Ty::TyTuple>(walk_f_3992).a0;
            crate::prelude::fold_job(ts_pd, acc_p1x, ({
            auto st_p0xx = st_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xxy = st_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
                return ({
                    auto a_pe = p0;
                    auto x_pf = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0xxy, a_pe, x_pf))));
                });
            })));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::types::Ty::TyArray>(walk_f_3992) ? ({
            auto&& e_pg = prism_rtl::as<crate::check::types::Ty::TyArray>(walk_f_3992).a0;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0x, acc_p1x, prism_rtl::deref(e_pg))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyMap>(walk_f_3992) ? ({
            auto&& k_ph = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_f_3992).a0;
            auto&& v_pi = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_f_3992).a1;
            crate::prelude::call_then(start_free_cols_into_f(st_p0x, acc_p1x, prism_rtl::deref(k_ph)), [=](Array<Nat> free_cols_into_f_4407) { return prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0x, free_cols_into_f_4407, prism_rtl::deref(v_pi)))); });
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_f_3992) ? ({
            auto&& i_pj = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_3992).a1;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0x, acc_p1x, prism_rtl::deref(i_pj))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyAt>(walk_f_3992) ? ({
            auto&& i_pk = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_f_3992).a0;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0x, acc_p1x, prism_rtl::deref(i_pk))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyElem>(walk_f_3992) ? ({
            auto&& o_pl = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_f_3992).a1;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0x, acc_p1x, prism_rtl::deref(o_pl))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyAssoc>(walk_f_3992) ? ({
            auto&& a_pm = prism_rtl::as<crate::check::types::Ty::TyAssoc>(walk_f_3992).a1;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0x, acc_p1x, prism_rtl::deref(a_pm))));
        })
            : prism_rtl::finished(acc_p1x);
        });
    });
}


/// `Start FreeColsInto, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_free_cols_into_f(crate::check::types::St st_p0, Array<Nat> acc_p1, crate::check::types::Ty t_p2) {
    return prism_rtl::make_rc<FreeColsInto>(st_p0, acc_p1, t_p2);
}


/// AddLeq: unbounded fn St, Col, Col, Range, Text, Text, Text -> St
crate::check::types::St add_leq_f(const crate::check::types::St& st_p0, const crate::check::types::Col& lo0_p1, const crate::check::types::Col& hi0_p2, const crate::syntax::Range& span_p3, const Text& kind_p4, const Text& name_p5, const Text& why_p6) {
    auto lo_p7 = walk_col_f(st_p0, lo0_p1);
    auto hi_p8 = walk_col_f(st_p0, hi0_p2);
    return ((lo_p7 == crate::check::types::Col(crate::check::types::Col::CBound{})) || (hi_p8 == crate::check::types::Col(crate::check::types::Col::CUnbound{}))) || (lo_p7 == hi_p8)
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        this_.cleqs_p = crate::prelude::push(this_.cleqs_p, crate::check::types::CLeq{.lo_p = lo_p7, .hi_p = hi_p8, .file_p = this_.file_p, .span_p = span_p3, .kind_p = kind_p4, .name_p = name_p5, .why_p = why_p6});
        (std::move(this_));
    });
}


prism_rtl::Turn<crate::check::types::St> AddLeq::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& lo0_p1 = this->lo0_p1;
    const auto& hi0_p2 = this->hi0_p2;
    const auto& span_p3 = this->span_p3;
    const auto& kind_p4 = this->kind_p4;
    const auto& name_p5 = this->name_p5;
    const auto& why_p6 = this->why_p6;
    auto hi0_p2x = hi0_p2;
    auto kind_p4x = kind_p4;
    auto lo0_p1x = lo0_p1;
    auto name_p5x = name_p5;
    auto span_p3x = span_p3;
    auto st_p0x = st_p0;
    auto why_p6x = why_p6;
    return crate::prelude::call_then(start_walk_col_f(st_p0x, lo0_p1x), [=](crate::check::types::Col walk_col_f_4883) {
        return ({
            auto lo_p7 = walk_col_f_4883;
            (crate::prelude::call_then(start_walk_col_f(st_p0x, hi0_p2x), [=, lo_p7 = std::move(lo_p7)](crate::check::types::Col walk_col_f_4912) {
            return ({
                auto hi_p8 = walk_col_f_4912;
                ((lo_p7 == crate::check::types::Col(crate::check::types::Col::CBound{})) || (hi_p8 == crate::check::types::Col(crate::check::types::Col::CUnbound{}))) || (lo_p7 == hi_p8)
                ? prism_rtl::finished(st_p0x)
                : prism_rtl::finished(({
                crate::check::types::St this_ = st_p0x;
                this_.cleqs_p = crate::prelude::push(this_.cleqs_p, crate::check::types::CLeq{.lo_p = lo_p7, .hi_p = hi_p8, .file_p = this_.file_p, .span_p = span_p3x, .kind_p = kind_p4x, .name_p = name_p5x, .why_p = why_p6x});
                (std::move(this_));
            }));
            });
        }));
        });
    });
}


/// `Start AddLeq, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_add_leq_f(crate::check::types::St st_p0, crate::check::types::Col lo0_p1, crate::check::types::Col hi0_p2, crate::syntax::Range span_p3, Text kind_p4, Text name_p5, Text why_p6) {
    return prism_rtl::make_rc<AddLeq>(st_p0, lo0_p1, hi0_p2, span_p3, kind_p4, name_p5, why_p6);
}


/// Propagate: unbounded fn St, Bool -> St
crate::check::types::St propagate_f(const crate::check::types::St& st_p0, const bool& rigid_p1) {
    auto [st2_p8, changed_p9] = crate::prelude::run_to_end(crate::prelude::fold_job(st_p0.cleqs_p, std::tuple{st_p0, false}, ({
        auto rigid_p1x = rigid_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, bool>>(std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq>)>>(prism_rtl::rc([=, rigid_p1x = std::move(rigid_p1x)](std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rigid_p1xy = rigid_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, rigid_p1xy = std::move(rigid_p1xy)]() {
            return ({
                auto [s_p2, ch_p3] = p0;
                auto c_p4 = p1;
                (crate::prelude::call_then(start_walk_col_f(s_p2, prism_rtl::deref(c_p4).lo_p), [=](crate::check::types::Col walk_col_f_5490) {
                return ({
                    auto lo_p5 = walk_col_f_5490;
                    (crate::prelude::call_then(start_walk_col_f(s_p2, prism_rtl::deref(c_p4).hi_p), [=, lo_p5 = std::move(lo_p5)](crate::check::types::Col walk_col_f_5520) {
                    return ({
                        prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_f_5520) ? ({
                        auto&& h_p6 = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_f_5520).a0;
                        ({
                        auto forced_p7 = (lo_p5 == crate::check::types::Col(crate::check::types::Col::CUnbound{})) || (rigid_p1xy && is_rigid_col_f(lo_p5));
                        (std::move(forced_p7)
                        ? prism_rtl::finished(std::tuple{bind_col_f(s_p2, h_p6, lo_p5), true})
                        : prism_rtl::finished(std::tuple{s_p2, ch_p3}));
                    });
                    })
                        : prism_rtl::finished(std::tuple{s_p2, ch_p3});
                    });
                }));
                });
            }));
            });
        })));
        });
    }));
    })));
    return changed_p9 ? propagate_f(st2_p8, rigid_p1) : st2_p8;
}


prism_rtl::Turn<crate::check::types::St> Propagate::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& rigid_p1 = this->rigid_p1;
    auto rigid_p1x = prism_rtl::deref(rigid_p1);
    auto st_p0x = st_p0;
    return crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(st_p0x).cleqs_p, std::tuple{st_p0x, false}, ({
        auto rigid_p1xx = std::move(rigid_p1x);
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, bool>>(std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq>)>>(prism_rtl::rc([=, rigid_p1xx = std::move(rigid_p1xx)](std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rigid_p1xxy = rigid_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, rigid_p1xxy = std::move(rigid_p1xxy)]() {
            return ({
                auto [s_p2, ch_p3] = p0;
                auto c_p4 = p1;
                (crate::prelude::call_then(start_walk_col_f(s_p2, prism_rtl::deref(c_p4).lo_p), [=](crate::check::types::Col walk_col_f_5490) {
                return ({
                    auto lo_p5 = walk_col_f_5490;
                    (crate::prelude::call_then(start_walk_col_f(s_p2, prism_rtl::deref(c_p4).hi_p), [=, lo_p5 = std::move(lo_p5)](crate::check::types::Col walk_col_f_5520) {
                    return ({
                        prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_f_5520) ? ({
                        auto&& h_p6 = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_f_5520).a0;
                        ({
                        auto forced_p7 = (lo_p5 == crate::check::types::Col(crate::check::types::Col::CUnbound{})) || (rigid_p1xxy && is_rigid_col_f(lo_p5));
                        (std::move(forced_p7)
                        ? prism_rtl::finished(std::tuple{bind_col_f(s_p2, h_p6, lo_p5), true})
                        : prism_rtl::finished(std::tuple{s_p2, ch_p3}));
                    });
                    })
                        : prism_rtl::finished(std::tuple{s_p2, ch_p3});
                    });
                }));
                });
            }));
            });
        })));
        });
    }));
    })), [=](std::tuple<crate::check::types::St, bool> fold_5427) {
        return ({
            auto [st2_p8, changed_p9] = fold_5427;
            changed_p9
            ? prism_rtl::more(prism_rtl::rc(Propagate(st2_p8, rigid_p1x)))
            : prism_rtl::finished(st2_p8);
        });
    });
}


/// `Start Propagate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_propagate_f(crate::check::types::St st_p0, bool rigid_p1) {
    return prism_rtl::make_rc<Propagate>(st_p0, rigid_p1);
}


/// GeneralizeCols: unbounded fn St -> St
crate::check::types::St generalize_cols_f(const crate::check::types::St& st0_p0) {
    auto st1_p1 = lower_joined_f(propagate_f(st0_p0, false));
    auto st2_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(st1_p1).cleqs_p, st1_p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto s_p3 = p0;
                auto c_p4 = p1;
                (crate::prelude::call_then(start_walk_col_f(s_p3, prism_rtl::deref(c_p4).lo_p), [=](crate::check::types::Col walk_col_f_6260) {
                return ({
                    auto lo_p5 = walk_col_f_6260;
                    (crate::prelude::call_then(start_walk_col_f(s_p3, prism_rtl::deref(c_p4).hi_p), [=, lo_p5 = std::move(lo_p5)](crate::check::types::Col walk_col_f_6293) {
                    return ({
                        auto hi_p6 = walk_col_f_6293;
                        ({
                        auto&& _m = std::tuple{lo_p5, hi_p6};
                        prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                        auto&& x_p7 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                        auto&& y_p8 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                        ((x_p7 != y_p8) && is_own_col_f(s_p3, lo_p5)) && is_own_col_f(s_p3, hi_p6)
                        ? prism_rtl::finished(bind_col_f(s_p3, x_p7, hi_p6))
                        : prism_rtl::finished(s_p3);
                    })
                        : prism_rtl::finished(s_p3);
                    });
                    });
                }));
                });
            }));
            });
        }));
    }))));
    return crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(st2_p2).cleqs_p, st2_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto s_p9 = p0;
                auto c_pa = p1;
                (crate::prelude::call_then(start_walk_col_f(s_p9, prism_rtl::deref(c_pa).lo_p), [=](crate::check::types::Col walk_col_f_6522) {
                return ({
                    auto lo_pb = walk_col_f_6522;
                    (crate::prelude::call_then(start_walk_col_f(s_p9, prism_rtl::deref(c_pa).hi_p), [=, lo_pb = std::move(lo_pb)](crate::check::types::Col walk_col_f_6555) {
                    return ({
                        auto hi_pc = walk_col_f_6555;
                        ({
                        auto&& _m = std::tuple{lo_pb, hi_pc};
                        prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? prism_rtl::finished(s_p9)
                        : prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CUnbound>(std::get<1>(_m)) ? prism_rtl::finished(s_p9)
                        : prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) ? ({
                        auto&& x_pd = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                        auto&& other_pe = std::get<1>(_m);
                        is_own_col_f(s_p9, lo_pb)
                        ? prism_rtl::finished(bind_col_f(s_p9, x_pd, other_pe))
                        : prism_rtl::finished(s_p9);
                    })
                        : prism_rtl::is<crate::check::types::Col::CRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                        auto&& r_pf = prism_rtl::as<crate::check::types::Col::CRigid>(std::get<0>(_m)).a0;
                        auto&& y_pg = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                        is_own_col_f(s_p9, hi_pc)
                        ? prism_rtl::finished(bind_col_f(s_p9, y_pg, lo_pb))
                        : prism_rtl::finished(s_p9);
                    })
                        : prism_rtl::finished(s_p9);
                    });
                    });
                }));
                });
            }));
            });
        }));
    }))));
}


prism_rtl::Turn<crate::check::types::St> GeneralizeCols::cycle() const {
    const auto& st0_p0 = this->st0_p0;
    auto st0_p0x = st0_p0;
    return crate::prelude::call_then(start_propagate_f(st0_p0x, false), [=](crate::check::types::St propagate_f_6178) {
        return crate::prelude::call_then(start_lower_joined_f(propagate_f_6178), [=](crate::check::types::St lower_joined_f_6165) {
            return ({
                auto st1_p1 = lower_joined_f_6165;
                (crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(st1_p1).cleqs_p, st1_p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto s_p3 = p0;
                        auto c_p4 = p1;
                        (crate::prelude::call_then(start_walk_col_f(s_p3, prism_rtl::deref(c_p4).lo_p), [=](crate::check::types::Col walk_col_f_6260) {
                        return ({
                            auto lo_p5 = walk_col_f_6260;
                            (crate::prelude::call_then(start_walk_col_f(s_p3, prism_rtl::deref(c_p4).hi_p), [=, lo_p5 = std::move(lo_p5)](crate::check::types::Col walk_col_f_6293) {
                            return ({
                                auto hi_p6 = walk_col_f_6293;
                                ({
                                auto&& _m = std::tuple{lo_p5, hi_p6};
                                prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                                auto&& x_p7 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                                auto&& y_p8 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                                ((x_p7 != y_p8) && is_own_col_f(s_p3, lo_p5)) && is_own_col_f(s_p3, hi_p6)
                                ? prism_rtl::finished(bind_col_f(s_p3, x_p7, hi_p6))
                                : prism_rtl::finished(s_p3);
                            })
                                : prism_rtl::finished(s_p3);
                            });
                            });
                        }));
                        });
                    }));
                    });
                }));
            }))), [=](crate::check::types::St fold_6214) {
                return ({
                    auto st2_p2 = fold_6214;
                    (crate::prelude::fold_job(prism_rtl::deref(st2_p2).cleqs_p, st2_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return crate::prelude::entered(crate::prelude::once_job([=]() {
                        return ({
                            auto s_p9 = p0;
                            auto c_pa = p1;
                            (crate::prelude::call_then(start_walk_col_f(s_p9, prism_rtl::deref(c_pa).lo_p), [=](crate::check::types::Col walk_col_f_6522) {
                            return ({
                                auto lo_pb = walk_col_f_6522;
                                (crate::prelude::call_then(start_walk_col_f(s_p9, prism_rtl::deref(c_pa).hi_p), [=, lo_pb = std::move(lo_pb)](crate::check::types::Col walk_col_f_6555) {
                                return ({
                                    auto hi_pc = walk_col_f_6555;
                                    ({
                                    auto&& _m = std::tuple{lo_pb, hi_pc};
                                    prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? prism_rtl::finished(s_p9)
                                    : prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CUnbound>(std::get<1>(_m)) ? prism_rtl::finished(s_p9)
                                    : prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) ? ({
                                    auto&& x_pd = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                                    auto&& other_pe = std::get<1>(_m);
                                    is_own_col_f(s_p9, lo_pb)
                                    ? prism_rtl::finished(bind_col_f(s_p9, x_pd, other_pe))
                                    : prism_rtl::finished(s_p9);
                                })
                                    : prism_rtl::is<crate::check::types::Col::CRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                                    auto&& r_pf = prism_rtl::as<crate::check::types::Col::CRigid>(std::get<0>(_m)).a0;
                                    auto&& y_pg = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                                    is_own_col_f(s_p9, hi_pc)
                                    ? prism_rtl::finished(bind_col_f(s_p9, y_pg, lo_pb))
                                    : prism_rtl::finished(s_p9);
                                })
                                    : prism_rtl::finished(s_p9);
                                });
                                });
                            }));
                            });
                        }));
                        });
                    }));
                })))->cycle());
                });
            }));
            });
        });
    });
}


/// `Start GeneralizeCols, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_generalize_cols_f(crate::check::types::St st0_p0) {
    return prism_rtl::make_rc<GeneralizeCols>(st0_p0);
}


/// LowerJoined: unbounded fn St -> St
crate::check::types::St lower_joined_f(const crate::check::types::St& st_p0) {
    auto [st2_p8, changed_p9] = crate::prelude::run_to_end(crate::prelude::fold_job(st_p0.cleqs_p, std::tuple{st_p0, false}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, bool>>(std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [s_p1, ch_p2] = p0;
                auto c_p3 = p1;
                (crate::prelude::call_then(start_walk_col_f(s_p1, prism_rtl::deref(c_p3).lo_p), [=](crate::check::types::Col walk_col_f_7100) {
                return crate::prelude::call_then(start_walk_col_f(s_p1, prism_rtl::deref(c_p3).hi_p), [=](crate::check::types::Col walk_col_f_7119) {
                    return ({
                        auto&& _m = std::tuple{walk_col_f_7100, walk_col_f_7119};
                        prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                        auto&& x_p4 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                        auto&& y_p5 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                        ({
                        auto lx_p6 = prism_rtl::deref(crate::check::types::recording::info_of_f(s_p1, x_p4)).level_p;
                        auto ly_p7 = prism_rtl::deref(crate::check::types::recording::info_of_f(s_p1, y_p5)).level_p;
                        ((lx_p6 > prism_rtl::deref(s_p1).level_p) && (ly_p7 <= prism_rtl::deref(s_p1).level_p)) && (lx_p6 > ly_p7)
                        ? prism_rtl::finished(std::tuple{crate::check::types::unify::lower_one_f(s_p1, x_p4, ly_p7), true})
                        : ((ly_p7 > prism_rtl::deref(s_p1).level_p) && (lx_p6 <= prism_rtl::deref(s_p1).level_p)) && (ly_p7 > lx_p6)
                        ? prism_rtl::finished(std::tuple{crate::check::types::unify::lower_one_f(s_p1, y_p5, lx_p6), true})
                        : prism_rtl::finished(std::tuple{s_p1, ch_p2});
                    });
                    })
                        : prism_rtl::finished(std::tuple{s_p1, ch_p2});
                    });
                });
            }));
            });
        }));
    }))));
    return changed_p9 ? lower_joined_f(st2_p8) : st2_p8;
}


prism_rtl::Turn<crate::check::types::St> LowerJoined::cycle() const {
    const auto& st_p0 = this->st_p0;
    auto st_p0x = st_p0;
    return crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(st_p0x).cleqs_p, std::tuple{st_p0x, false}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, bool>>(std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [s_p1, ch_p2] = p0;
                auto c_p3 = p1;
                (crate::prelude::call_then(start_walk_col_f(s_p1, prism_rtl::deref(c_p3).lo_p), [=](crate::check::types::Col walk_col_f_7100) {
                return crate::prelude::call_then(start_walk_col_f(s_p1, prism_rtl::deref(c_p3).hi_p), [=](crate::check::types::Col walk_col_f_7119) {
                    return ({
                        auto&& _m = std::tuple{walk_col_f_7100, walk_col_f_7119};
                        prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                        auto&& x_p4 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                        auto&& y_p5 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                        ({
                        auto lx_p6 = prism_rtl::deref(crate::check::types::recording::info_of_f(s_p1, x_p4)).level_p;
                        auto ly_p7 = prism_rtl::deref(crate::check::types::recording::info_of_f(s_p1, y_p5)).level_p;
                        ((lx_p6 > prism_rtl::deref(s_p1).level_p) && (ly_p7 <= prism_rtl::deref(s_p1).level_p)) && (lx_p6 > ly_p7)
                        ? prism_rtl::finished(std::tuple{crate::check::types::unify::lower_one_f(s_p1, x_p4, ly_p7), true})
                        : ((ly_p7 > prism_rtl::deref(s_p1).level_p) && (lx_p6 <= prism_rtl::deref(s_p1).level_p)) && (ly_p7 > lx_p6)
                        ? prism_rtl::finished(std::tuple{crate::check::types::unify::lower_one_f(s_p1, y_p5, lx_p6), true})
                        : prism_rtl::finished(std::tuple{s_p1, ch_p2});
                    });
                    })
                        : prism_rtl::finished(std::tuple{s_p1, ch_p2});
                    });
                });
            }));
            });
        }));
    }))), [=](std::tuple<crate::check::types::St, bool> fold_7037) {
        return ({
            auto [st2_p8, changed_p9] = fold_7037;
            changed_p9
            ? prism_rtl::more(prism_rtl::rc(LowerJoined(st2_p8)))
            : prism_rtl::finished(st2_p8);
        });
    });
}


/// `Start LowerJoined, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_lower_joined_f(crate::check::types::St st_p0) {
    return prism_rtl::make_rc<LowerJoined>(st_p0);
}


/// CheckColors: unbounded fn St -> St
crate::check::types::St check_colors_f(const crate::check::types::St& st0_p0) {
    auto st_p1 = propagate_f(propagate_f(st0_p0, false), true);
    auto st2_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(st_p1).cleqs_p, st_p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto s_p3 = p0;
                auto c_p4 = p1;
                (crate::prelude::call_then(start_settled_col_f(s_p3, prism_rtl::deref(c_p4).lo_p), [=](crate::check::types::Col settled_col_f_7897) {
                return ({
                    auto lo_p5 = settled_col_f_7897;
                    (crate::prelude::call_then(start_settled_col_f(s_p3, prism_rtl::deref(c_p4).hi_p), [=, lo_p5 = std::move(lo_p5)](crate::check::types::Col settled_col_f_7933) {
                    return ({
                        auto hi_p6 = settled_col_f_7933;
                        col_leq_f(lo_p5, hi_p6) || col_leq_f(up_col_f(s_p3, lo_p5), up_col_f(s_p3, hi_p6))
                        ? prism_rtl::finished(s_p3)
                        : prism_rtl::finished(crate::check::types::recording::add_diag_f(s_p3, leq_diag_f(c_p4, lo_p5, hi_p6)));
                    });
                }));
                });
            }));
            });
        }));
    }))));
    crate::check::types::St this_ = st2_p2;
    this_.cleqs_p = Array<crate::check::types::CLeq>{};
    this_.color_flex_p = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
    this_.col_up_p = Map<Text, Text>{};
    return this_;
}


prism_rtl::Turn<crate::check::types::St> CheckColors::cycle() const {
    const auto& st0_p0 = this->st0_p0;
    auto st0_p0x = st0_p0;
    return crate::prelude::call_then(start_propagate_f(st0_p0x, false), [=](crate::check::types::St propagate_f_7811) {
        return crate::prelude::call_then(start_propagate_f(propagate_f_7811, true), [=](crate::check::types::St propagate_f_7800) {
            return ({
                auto st_p1 = propagate_f_7800;
                (crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(st_p1).cleqs_p, st_p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto s_p3 = p0;
                        auto c_p4 = p1;
                        (crate::prelude::call_then(start_settled_col_f(s_p3, prism_rtl::deref(c_p4).lo_p), [=](crate::check::types::Col settled_col_f_7897) {
                        return ({
                            auto lo_p5 = settled_col_f_7897;
                            (crate::prelude::call_then(start_settled_col_f(s_p3, prism_rtl::deref(c_p4).hi_p), [=, lo_p5 = std::move(lo_p5)](crate::check::types::Col settled_col_f_7933) {
                            return ({
                                auto hi_p6 = settled_col_f_7933;
                                col_leq_f(lo_p5, hi_p6) || col_leq_f(up_col_f(s_p3, lo_p5), up_col_f(s_p3, hi_p6))
                                ? prism_rtl::finished(s_p3)
                                : prism_rtl::finished(crate::check::types::recording::add_diag_f(s_p3, leq_diag_f(c_p4, lo_p5, hi_p6)));
                            });
                        }));
                        });
                    }));
                    });
                }));
            }))), [=](crate::check::types::St fold_7853) {
                return ({
                    auto st2_p2 = fold_7853;
                    (prism_rtl::finished(({
                    crate::check::types::St this_ = st2_p2;
                    this_.cleqs_p = Array<crate::check::types::CLeq>{};
                    this_.color_flex_p = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
                    this_.col_up_p = Map<Text, Text>{};
                    (std::move(this_));
                })));
                });
            }));
            });
        });
    });
}


/// `Start CheckColors, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_colors_f(crate::check::types::St st0_p0) {
    return prism_rtl::make_rc<CheckColors>(st0_p0);
}


/// LeqDiag: fn CLeq, Col, Col -> CDiag
crate::check::errors::CDiag leq_diag_f(const crate::check::types::CLeq& c_p0, const crate::check::types::Col& lo_p1, const crate::check::types::Col& hi_p2) {
    return c_p0.kind_p == Text::lit("lifted")
        ? crate::check::errors::diag_fix_f(Text::lit("lifted-unbounded"), c_p0.file_p, c_p0.span_p, prism_rtl::cat(col_word_f(lo_p1), " `", c_p0.name_p, "` lifted over `", c_p0.why_p, "`; use `@Run`"), prism_rtl::cat("run it through `!done <- @Run ", c_p0.name_p, ", ...`"))
        : c_p0.kind_p == Text::lit("arg")
        ? crate::check::errors::diag_fix_f(Text::lit("calls-unbounded"), c_p0.file_p, c_p0.span_p, prism_rtl::cat(col_word_f(hi_p2), " `", c_p0.name_p, "` takes a ", col_word_f(hi_p2), " closure; this one is ", col_word_f(lo_p1)), Text::lit("mark the parameter `unbounded fn`, or run the work through `@Run`"))
        : c_p0.kind_p == Text::lit("lambda")
        ? crate::check::errors::diag_fix_f(Text::lit("calls-unbounded"), c_p0.file_p, c_p0.span_p, prism_rtl::cat("this ", col_word_f(hi_p2), " lambda calls ", col_word_f(lo_p1), " `", c_p0.why_p, "`"), Text::lit("mark the function type it meets `unbounded fn`, or run the call through `@Run`"))
        : crate::check::errors::diag_fix_f(Text::lit("calls-unbounded"), c_p0.file_p, c_p0.span_p, prism_rtl::cat(col_word_f(hi_p2), " `", c_p0.name_p, "` calls ", col_word_f(lo_p1), " `", c_p0.why_p, "`"), prism_rtl::cat("mark `", c_p0.name_p, "` `unbounded fn`, or run the call through `@Run`"));
}


/// SettleBody: unbounded fn St, Col, Text -> St
crate::check::types::St settle_body_f(const crate::check::types::St& st0_p0, const crate::check::types::Col& col_p1, const Text& name_p2) {
    auto st_p3 = propagate_f(st0_p0, false);
    auto waiting_p4 = prism_rtl::deref(st_p3).color_flex_p;
    auto cleared_p5 = ({
        crate::check::types::St this_ = st_p3;
        this_.color_flex_p = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
        (std::move(this_));
    });
    return crate::prelude::run_to_end(crate::prelude::fold_job(waiting_p4, cleared_p5, ({
        auto col_p1x = col_p1;
        auto name_p2x = name_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>)>>(prism_rtl::rc([=, col_p1x = std::move(col_p1x), name_p2x = std::move(name_p2x)](std::tuple<crate::check::types::St, std::tuple<crate::check::types::Col, Text, crate::syntax::Range>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto col_p1xy = col_p1x;
            auto name_p2xy = name_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, col_p1xy = std::move(col_p1xy), name_p2xy = std::move(name_p2xy)]() {
            return ({
                auto s_p6 = p0;
                auto [c_p7, why_p8, span_p9] = p1;
                (crate::prelude::call_then(start_walk_col_f(s_p6, c_p7), [=](crate::check::types::Col walk_col_f_9404) {
                return ({
                    prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_f_9404) ? ({
                    auto&& n_pa = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_f_9404).a0;
                    prism_rtl::more(prism_rtl::rc(AddLeq(s_p6, crate::check::types::Col(crate::check::types::Col::CFlex{n_pa}), col_p1xy, span_p9, name_p2xy == Text::lit("") ? Text::lit("lambda") : Text::lit("body"), name_p2xy, why_p8)));
                })
                    : ({
                    auto&& known_pb = walk_col_f_9404;
                    prism_rtl::finished(join_known_f(s_p6, known_pb, why_p8));
                });
                });
            }));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> SettleBody::cycle() const {
    const auto& st0_p0 = this->st0_p0;
    const auto& col_p1 = this->col_p1;
    const auto& name_p2 = this->name_p2;
    auto col_p1x = col_p1;
    auto name_p2x = name_p2;
    auto st0_p0x = st0_p0;
    return crate::prelude::call_then(start_propagate_f(st0_p0x, false), [=](crate::check::types::St propagate_f_9238) {
        return ({
            auto st_p3 = propagate_f_9238;
            auto waiting_p4 = prism_rtl::deref(st_p3).color_flex_p;
            auto cleared_p5 = ({
                crate::check::types::St this_ = st_p3;
                this_.color_flex_p = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
                (std::move(this_));
            });
            (crate::prelude::fold_job(waiting_p4, cleared_p5, ({
            auto col_p1xx = col_p1x;
            auto name_p2xx = name_p2x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>)>>(prism_rtl::rc([=, col_p1xx = std::move(col_p1xx), name_p2xx = std::move(name_p2xx)](std::tuple<crate::check::types::St, std::tuple<crate::check::types::Col, Text, crate::syntax::Range>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto col_p1xxy = col_p1xx;
                auto name_p2xxy = name_p2xx;
                (crate::prelude::entered(crate::prelude::once_job([=, col_p1xxy = std::move(col_p1xxy), name_p2xxy = std::move(name_p2xxy)]() {
                return ({
                    auto s_p6 = p0;
                    auto [c_p7, why_p8, span_p9] = p1;
                    (crate::prelude::call_then(start_walk_col_f(s_p6, c_p7), [=](crate::check::types::Col walk_col_f_9404) {
                    return ({
                        prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_f_9404) ? ({
                        auto&& n_pa = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_f_9404).a0;
                        prism_rtl::more(prism_rtl::rc(AddLeq(s_p6, crate::check::types::Col(crate::check::types::Col::CFlex{n_pa}), col_p1xxy, span_p9, name_p2xxy == Text::lit("") ? Text::lit("lambda") : Text::lit("body"), name_p2xxy, why_p8)));
                    })
                        : ({
                        auto&& known_pb = walk_col_f_9404;
                        prism_rtl::finished(join_known_f(s_p6, known_pb, why_p8));
                    });
                    });
                }));
                });
            })));
            });
        })));
        }))->cycle());
        });
    });
}


/// `Start SettleBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_settle_body_f(crate::check::types::St st0_p0, crate::check::types::Col col_p1, Text name_p2) {
    return prism_rtl::make_rc<SettleBody>(st0_p0, col_p1, name_p2);
}

}  // namespace crate::check::types::colors
