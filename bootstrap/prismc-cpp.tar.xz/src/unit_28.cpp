// The modules `Check.Types.Unify`, `Checking`, `Compile`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Types.Unify`, from `target/bootstrap/cpp-src/prismc/check/types/unify.prism`.
namespace crate::check::types::unify {

void FieldQ::show(Printer& p) const {
    p.record("FieldQ", {{"recv", recv}, {"field", field}, {"result", result}, {"span", span}, {"file", file}, {"owners", owners}});
}

Pod FieldQ::to_pod() const {
    return Pod::record("FieldQ", {{"recv", prism_rtl::to_pod(recv)}, {"field", prism_rtl::to_pod(field)}, {"result", prism_rtl::to_pod(result)}, {"span", prism_rtl::to_pod(span)}, {"file", prism_rtl::to_pod(file)}, {"owners", prism_rtl::to_pod(owners)}});
}

Result<FieldQ> FieldQ::from_pod(const Pod& whole) {
    return FieldQ{.recv = TRY(prism_rtl::from_pod<crate::check::types::Ty>(TRY(crate::prelude::field(whole, "recv")))), .field = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "field")))), .result = TRY(prism_rtl::from_pod<crate::check::types::Ty>(TRY(crate::prelude::field(whole, "result")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .owners = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "owners"))))};
}


/// Unify: unbounded fn St, Ty, Ty, Range -> St
crate::check::types::St unify(const crate::check::types::St& st, const crate::check::types::Ty& expected, const crate::check::types::Ty& found, const crate::syntax::Range& span) {
    auto [verdict, st2] = unify_in(st, expected, found, span);
    return verdict == Text::lit("mismatch")
        ? ({
        auto e = crate::check::types::show_ty(st2, expected);
        auto f = crate::check::types::show_ty(st2, found);
        e == f
        ? crate::check::types::recording::err(st2, Text::lit("mismatch"), span, prism_rtl::cat("expected `", show_ty_q(st2, expected), "`, found `", show_ty_q(st2, found), "`"))
        : crate::check::types::recording::err(st2, Text::lit("mismatch"), span, prism_rtl::cat("expected `", e, "`, found `", f, "`"));
    })
        : st2;
}


prism_rtl::Turn<crate::check::types::St> Unify::cycle() const {
    const auto& st = this->st;
    const auto& expected = this->expected;
    const auto& found = this->found;
    const auto& span = this->span;
    auto expected_1 = expected;
    auto found_2 = found;
    auto span_3 = span;
    auto st_4 = st;
    return call_then(start_unify_in(st_4, expected_1, found_2, span_3), [=](std::tuple<Text, crate::check::types::St> unify_in_1030) {
        return ({
            auto [verdict, st2] = unify_in_1030;
            verdict == Text::lit("mismatch")
            ? call_then(crate::check::types::start_show_ty(st2, expected_1), [=](Text show_ty_1110) {
            return ({
                auto e = show_ty_1110;
                call_then(crate::check::types::start_show_ty(st2, found_2), [=](Text show_ty_1147) {
                return ({
                    auto f = show_ty_1147;
                    e == f
                    ? call_then(start_show_ty_q(st2, expected_1), [=](Text show_ty_q_1223) { return call_then(start_show_ty_q(st2, found_2), [=](Text show_ty_q_1256) { return prism_rtl::finished(crate::check::types::recording::err(st2, Text::lit("mismatch"), span_3, prism_rtl::cat("expected `", show_ty_q_1223, "`, found `", show_ty_q_1256, "`"))); }); })
                    : prism_rtl::finished(crate::check::types::recording::err(st2, Text::lit("mismatch"), span_3, prism_rtl::cat("expected `", e, "`, found `", f, "`")));
                });
            });
            });
        })
            : prism_rtl::finished(st2);
        });
    });
}


/// `Start Unify, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_unify(crate::check::types::St st, crate::check::types::Ty expected, crate::check::types::Ty found, crate::syntax::Range span) {
    return prism_rtl::make_rc<Unify>(st, expected, found, span);
}


/// ShowTyQ: unbounded fn St, Ty -> Text
Text show_ty_q(const crate::check::types::St& st, const crate::check::types::Ty& t) {
    auto&& _m = crate::check::types::recording::zonk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m1487_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m1487_0_1.size() == 0u) {
            return n;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        return prism_rtl::cat("(", n, concat(run_to_end(each_job(args, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    call_then(start_show_ty_q(st_1_2, a), [=](Text show_ty_q_1578) { return prism_rtl::finished(prism_rtl::cat(" ", show_ty_q_1578)); });
                });
            }));
            });
        })));
        })))), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return prism_rtl::cat(s, show_ty_q(st, i));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        auto inner = show_ty_q(st, e);
        return crate::syntax::lexer::chars::has_prefix(inner, Text::lit("["))
            ? prism_rtl::cat("[ ", inner, " ]")
            : prism_rtl::cat("[", inner, "]");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return prism_rtl::cat("(", show_ty_q(st, k), " ==> ", show_ty_q(st, v_), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a1;
        return prism_rtl::cat("@", show_ty_q(st, i), " emit ", crate::check::types::show_row_in(rw, true));
    }
    {
        auto&& other = _m;
        return crate::check::types::show_ty(st, other);
    }
}


prism_rtl::Turn<Text> ShowTyQ::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(crate::check::types::recording::start_zonk(st_1, t_2), [=](crate::check::types::Ty zonk_1493) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(zonk_1493) && ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(zonk_1493).a0;
            auto&& m1487_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(zonk_1493).a1;
            (m1487_0_1.size() == 0u);
        }) ? ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(zonk_1493).a0;
            auto&& m1487_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(zonk_1493).a1;
            prism_rtl::finished(n);
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(zonk_1493) ? ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(zonk_1493).a0;
            auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(zonk_1493).a1;
            call_value(each_job(args, ({
            auto st_1_3 = st_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto st_1_3_3 = st_1_3;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    call_then(start_show_ty_q(st_1_3_3, a), [=](Text show_ty_q_1578) { return prism_rtl::finished(prism_rtl::cat(" ", show_ty_q_1578)); });
                });
            }));
            });
        })));
        })), [=](Array<Text> each_1559) { return prism_rtl::finished(prism_rtl::cat("(", n, concat(each_1559), ")")); });
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(zonk_1493) ? ({
            auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(zonk_1493).a0;
            auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(zonk_1493).a1;
            call_then(start_show_ty_q(st_1, i), [=](Text show_ty_q_1619) { return prism_rtl::finished(prism_rtl::cat(s, show_ty_q_1619)); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyArray>(zonk_1493) ? ({
            auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(zonk_1493).a0;
            call_then(start_show_ty_q(st_1, e), [=](Text show_ty_q_1670) {
            return ({
                auto inner = show_ty_q_1670;
                (crate::syntax::lexer::chars::has_prefix(inner, Text::lit("["))
                ? prism_rtl::finished(prism_rtl::cat("[ ", inner, " ]"))
                : prism_rtl::finished(prism_rtl::cat("[", inner, "]")));
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyMap>(zonk_1493) ? ({
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(zonk_1493).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(zonk_1493).a1;
            call_then(start_show_ty_q(st_1, k), [=](Text show_ty_q_1770) { return call_then(start_show_ty_q(st_1, v_), [=](Text show_ty_q_1790) { return prism_rtl::finished(prism_rtl::cat("(", show_ty_q_1770, " ==> ", show_ty_q_1790, ")")); }); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyAt>(zonk_1493) ? ({
            auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(zonk_1493).a0;
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(zonk_1493).a1;
            call_then(start_show_ty_q(st_1, i), [=](Text show_ty_q_1826) { return prism_rtl::finished(prism_rtl::cat("@", show_ty_q_1826, " emit ", crate::check::types::show_row_in(rw, true))); });
        })
            : ({
            auto&& other = zonk_1493;
            prism_rtl::more(prism_rtl::rc(crate::check::types::ShowTy(st_1, other)));
        });
        });
    });
}


/// `Start ShowTyQ, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_ty_q(crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<ShowTyQ>(st, t);
}


/// TryUnify: unbounded fn St, Ty, Ty, Range -> ((Bool, St))
std::tuple<bool, crate::check::types::St> try_unify(const crate::check::types::St& st, const crate::check::types::Ty& expected, const crate::check::types::Ty& found, const crate::syntax::Range& span) {
    auto [verdict, st2] = unify_in(st, expected, found, span);
    return std::tuple{verdict == Text::lit(""), st2};
}


prism_rtl::Turn<std::tuple<bool, crate::check::types::St>> TryUnify::cycle() const {
    const auto& st = this->st;
    const auto& expected = this->expected;
    const auto& found = this->found;
    const auto& span = this->span;
    auto expected_1 = expected;
    auto found_2 = found;
    auto span_3 = span;
    auto st_4 = st;
    return call_then(start_unify_in(st_4, expected_1, found_2, span_3), [=](std::tuple<Text, crate::check::types::St> unify_in_2156) {
        return ({
            auto [verdict, st2] = unify_in_2156;
            (prism_rtl::finished(std::tuple{verdict == Text::lit(""), st2}));
        });
    });
}


/// `Start TryUnify, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<bool, crate::check::types::St>> start_try_unify(crate::check::types::St st, crate::check::types::Ty expected, crate::check::types::Ty found, crate::syntax::Range span) {
    return prism_rtl::make_rc<TryUnify>(st, expected, found, span);
}


/// UnifyIn: unbounded fn St, Ty, Ty, Range -> ((Text, St))
std::tuple<Text, crate::check::types::St> unify_in(const crate::check::types::St& st, const crate::check::types::Ty& expected, const crate::check::types::Ty& found, const crate::syntax::Range& span) {
    auto e = norm_assoc(st, crate::check::types::recording::walk(st, expected));
    auto f = norm_assoc(st, crate::check::types::recording::walk(st, found));
    return is_waiting_assoc(st, e) || is_waiting_assoc(st, f)
        ? e == f
        ? std::tuple{Text::lit(""), st}
        : std::tuple{Text::lit(""), defer(st, e, f, span)}
        : unify_heads(st, e, f, span);
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> UnifyIn::cycle() const {
    const auto& st = this->st;
    const auto& expected = this->expected;
    const auto& found = this->found;
    const auto& span = this->span;
    auto expected_1 = expected;
    auto found_2 = found;
    auto span_3 = span;
    auto st_4 = st;
    return call_then(crate::check::types::recording::start_walk(st_4, expected_1), [=](crate::check::types::Ty walk_2446) {
        return call_then(start_norm_assoc(st_4, walk_2446), [=](crate::check::types::Ty norm_assoc_2431) {
            return ({
                auto e = norm_assoc_2431;
                call_then(crate::check::types::recording::start_walk(st_4, found_2), [=](crate::check::types::Ty walk_2492) {
                return call_then(start_norm_assoc(st_4, walk_2492), [=](crate::check::types::Ty norm_assoc_2477) {
                    return ({
                        auto f = norm_assoc_2477;
                        call_then(start_is_waiting_assoc(st_4, e), [=](bool is_waiting_assoc_2516) {
                        return is_waiting_assoc_2516 || is_waiting_assoc(st_4, f)
                            ? e == f
                            ? prism_rtl::finished(std::tuple{Text::lit(""), st_4})
                            : prism_rtl::finished(std::tuple{Text::lit(""), defer(st_4, e, f, span_3)})
                            : prism_rtl::more(prism_rtl::rc(UnifyHeads(st_4, e, f, span_3)));
                    });
                    });
                });
            });
            });
        });
    });
}


/// `Start UnifyIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_in(crate::check::types::St st, crate::check::types::Ty expected, crate::check::types::Ty found, crate::syntax::Range span) {
    return prism_rtl::make_rc<UnifyIn>(st, expected, found, span);
}


/// NormAssoc: unbounded fn St, Ty -> Ty
crate::check::types::Ty norm_assoc(const crate::check::types::St& st, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t)) {
        auto&& m2934_0_0 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        if (m2934_0_0 == Text::lit("Quotient")) {
            auto&& _m = crate::check::types::recording::walk(st, a);
            if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                auto&& m2970_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
                auto&& m2970_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
                if (m2970_0_0 == Text::lit("Float")) {
                    if (m2970_0_1.size() == 0u) {
                        return crate::check::types::t_float();
                    }
                }
            }
            if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
                auto&& m2970_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
                if (m2970_1_1.size() == 0u) {
                    return ((n == Text::lit("Nat")) || (n == Text::lit("Int"))) || (n == Text::lit("U8"))
                        ? crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyCon{n, Array<crate::check::types::Ty>{}}))})
                        : t;
                }
            }
            {
                return t;
            }
        }
    }
    {
        auto&& other = t;
        return other;
    }
}


prism_rtl::Turn<crate::check::types::Ty> NormAssoc::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyAssoc>(t) && ({
        auto&& m2934_0_0 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        (m2934_0_0 == Text::lit("Quotient"));
    }) ? ({
        auto&& m2934_0_0 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        ({
        auto a_1 = a;
        auto st_2 = st;
        auto t_3 = t;
        call_then(crate::check::types::recording::start_walk(st_2, a_1), [=](crate::check::types::Ty walk_2976) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_2976) && ({
            auto&& m2970_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2976).a0;
            auto&& m2970_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2976).a1;
            (m2970_0_0 == Text::lit("Float")) && (m2970_0_1.size() == 0u);
        }) ? ({
            auto&& m2970_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2976).a0;
            auto&& m2970_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2976).a1;
            prism_rtl::finished(crate::check::types::t_float());
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_2976) && ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2976).a0;
            auto&& m2970_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2976).a1;
            (m2970_1_1.size() == 0u);
        }) ? ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2976).a0;
            auto&& m2970_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2976).a1;
            ((n == Text::lit("Nat")) || (n == Text::lit("Int"))) || (n == Text::lit("U8"))
            ? prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyCon{n, Array<crate::check::types::Ty>{}}))}))
            : prism_rtl::finished(t_3);
        })
            : prism_rtl::finished(t_3);
        });
    });
    });
    })
        : ({
        auto&& other = t;
        prism_rtl::finished(other);
    });
    });
}


/// `Start NormAssoc, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_norm_assoc(crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<NormAssoc>(st, t);
}


/// IsWaitingAssoc: unbounded fn St, Ty -> Bool
bool is_waiting_assoc(const crate::check::types::St& st, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t)) {
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        return crate::check::types::is_flex_var(st, a);
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsWaitingAssoc::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyAssoc>(t) ? ({
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::types::IsFlexVar(st, a)));
    })
        : prism_rtl::finished(false);
    });
}


/// `Start IsWaitingAssoc, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_waiting_assoc(crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<IsWaitingAssoc>(st, t);
}


/// Defer: fn St, Ty, Ty, Range -> St
crate::check::types::St defer(const crate::check::types::St& st, const crate::check::types::Ty& e, const crate::check::types::Ty& f, const crate::syntax::Range& span) {
    crate::check::types::St this_ = st;
    this_.deferred = crate::prelude::push(this_.deferred, std::tuple{e, f, span});
    return this_;
}


/// RetryDeferred: unbounded fn St -> St
crate::check::types::St retry_deferred(const crate::check::types::St& st) {
    auto waiting = st->deferred;
    auto cleared = ({
        crate::check::types::St this_ = st;
        this_.deferred = Array<std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range>>{};
        this_;
    });
    return run_to_end(fold_job(waiting, cleared, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range>>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto [e, f, span] = p1;
                (prism_rtl::more(prism_rtl::rc(Unify(s, e, f, span))));
            });
        }));
    }))));
}


prism_rtl::Turn<crate::check::types::St> RetryDeferred::cycle() const {
    const auto& st = this->st;
    auto waiting = st->deferred;
    auto cleared = ({
        crate::check::types::St this_ = st;
        this_.deferred = Array<std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range>>{};
        this_;
    });
    return fold_job(waiting, cleared, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range>>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto [e, f, span] = p1;
                (prism_rtl::more(prism_rtl::rc(Unify(s, e, f, span))));
            });
        }));
    })))->cycle();
}


/// `Start RetryDeferred, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_retry_deferred(crate::check::types::St st) {
    return prism_rtl::make_rc<RetryDeferred>(st);
}


/// UnifyHeads: unbounded fn St, Ty, Ty, Range -> ((Text, St))
std::tuple<Text, crate::check::types::St> unify_heads(const crate::check::types::St& st, const crate::check::types::Ty& e, const crate::check::types::Ty& f, const crate::syntax::Range& span) {
    auto&& _m = std::tuple{e, f};
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(std::get<0>(_m))) {
        return std::tuple{Text::lit(""), st};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(std::get<1>(_m))) {
        return std::tuple{Text::lit(""), st};
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<1>(_m))) {
        auto&& m3799_2_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a0;
        auto&& m3799_2_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& m3799_2_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a1;
        if (m3799_2_0_0 == Text::lit("~")) {
            if (m3799_2_1_0 == Text::lit("Prelude.Error")) {
                if (m3799_2_1_1.size() == 0u) {
                    return std::tuple{Text::lit(""), st};
                }
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TySig>(std::get<1>(_m))) {
        auto&& m3799_3_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& m3799_3_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& m3799_3_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a0;
        if (m3799_3_0_0 == Text::lit("Prelude.Error")) {
            if (m3799_3_0_1.size() == 0u) {
                if (m3799_3_1_0 == Text::lit("~")) {
                    return std::tuple{Text::lit(""), st};
                }
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<1>(_m))) {
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<0>(_m)).a0;
        auto&& b = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<1>(_m)).a0;
        return a == b
            ? std::tuple{Text::lit(""), st}
            : std::tuple{Text::lit(""), merge_vars(st, a, b)};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<0>(_m))) {
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<0>(_m)).a0;
        auto&& t = std::get<1>(_m);
        return bind_var(st, a, t, span);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<1>(_m))) {
        auto&& t = std::get<0>(_m);
        auto&& b = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<1>(_m)).a0;
        return bind_var(st, b, t, span);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyRigid>(std::get<1>(_m))) {
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyRigid>(std::get<0>(_m)).a0;
        auto&& b = prism_rtl::as<crate::check::types::Ty::TyRigid>(std::get<1>(_m)).a0;
        return a == b
            ? std::tuple{Text::lit(""), st}
            : std::tuple{Text::lit("mismatch"), st};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyQ>(std::get<1>(_m))) {
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyQ>(std::get<0>(_m)).a0;
        auto&& b = prism_rtl::as<crate::check::types::Ty::TyQ>(std::get<1>(_m)).a0;
        return a == b
            ? std::tuple{Text::lit(""), st}
            : std::tuple{Text::lit("mismatch"), st};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<1>(_m))) {
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& xs = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& b = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& ys = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a1;
        return (a == b) && (len(xs) == len(ys))
            ? unify_all(st, xs, ys, span)
            : std::tuple{Text::lit("mismatch"), st};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m))) {
        auto&& c1 = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a1;
        auto&& r1 = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a2;
        auto&& c2 = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
        auto&& qs = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
        auto&& r2 = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
        return len(ps) == len(qs)
            ? ({
            auto [v_, st2] = crate::check::types::colors::unify_col(st, c1, c2);
            v_ != Text::lit("")
            ? std::tuple{v_, st2}
            : unify_all(st2, crate::prelude::push(ps, r1), crate::prelude::push(qs, r2), span);
        })
            : std::tuple{Text::lit("mismatch"), st};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyTuple>(std::get<1>(_m))) {
        auto&& xs = prism_rtl::as<crate::check::types::Ty::TyTuple>(std::get<0>(_m)).a0;
        auto&& ys = prism_rtl::as<crate::check::types::Ty::TyTuple>(std::get<1>(_m)).a0;
        return len(xs) == len(ys)
            ? unify_all(st, xs, ys, span)
            : std::tuple{Text::lit("mismatch"), st};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyArray>(std::get<1>(_m))) {
        auto&& x = prism_rtl::as<crate::check::types::Ty::TyArray>(std::get<0>(_m)).a0;
        auto&& y = prism_rtl::as<crate::check::types::Ty::TyArray>(std::get<1>(_m)).a0;
        return unify_in(st, x, y, span);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyMap>(std::get<1>(_m))) {
        auto&& k1 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<0>(_m)).a0;
        auto&& v1 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<0>(_m)).a1;
        auto&& k2 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<1>(_m)).a0;
        auto&& v2 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<1>(_m)).a1;
        return unify_all(st, Array(std::vector{k1, v1}), Array(std::vector{k2, v2}), span);
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TySig>(std::get<1>(_m))) {
        auto&& s1 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a0;
        auto&& i1 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a1;
        auto&& s2 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a0;
        auto&& i2 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a1;
        return s1 == s2
            ? unify_in(st, i1, i2, span)
            : std::tuple{Text::lit("mismatch"), st};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<1>(_m))) {
        auto&& i1 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a0;
        auto&& r1 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a1;
        auto&& i2 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a0;
        auto&& r2 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a1;
        auto [v_, st2] = unify_in(st, i1, i2, span);
        return v_ != Text::lit("") ? std::tuple{v_, st2} : unify_row(st2, r1, r2, span);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyElem>(std::get<1>(_m))) {
        auto&& r1 = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<0>(_m)).a0;
        auto&& o1 = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<0>(_m)).a1;
        auto&& r2 = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<1>(_m)).a0;
        auto&& o2 = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<1>(_m)).a1;
        auto [v_, st2] = unify_row(st, r1, r2, span);
        return v_ != Text::lit("") ? std::tuple{v_, st2} : unify_in(st2, o1, o2, span);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyElemAny>(std::get<1>(_m))) {
        auto&& r1 = prism_rtl::as<crate::check::types::Ty::TyElemAny>(std::get<0>(_m)).a0;
        auto&& r2 = prism_rtl::as<crate::check::types::Ty::TyElemAny>(std::get<1>(_m)).a0;
        return unify_row(st, r1, r2, span);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAssoc>(std::get<1>(_m))) {
        auto&& n1 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<0>(_m)).a0;
        auto&& a1 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<0>(_m)).a1;
        auto&& n2 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<1>(_m)).a0;
        auto&& a2 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<1>(_m)).a1;
        return n1 == n2
            ? unify_in(st, a1, a2, span)
            : std::tuple{Text::lit("mismatch"), st};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAny>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAny>(std::get<1>(_m))) {
        auto&& xs = prism_rtl::as<crate::check::types::Ty::TyAny>(std::get<0>(_m)).a0;
        auto&& ys = prism_rtl::as<crate::check::types::Ty::TyAny>(std::get<1>(_m)).a0;
        return crate::check::types::sort_texts(xs) == crate::check::types::sort_texts(ys)
            ? std::tuple{Text::lit(""), st}
            : std::tuple{Text::lit("mismatch"), st};
    }
    {
        return std::tuple{Text::lit("mismatch"), st};
    }
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> UnifyHeads::cycle() const {
    const auto& st = this->st;
    const auto& e = this->e;
    const auto& f = this->f;
    const auto& span = this->span;
    return ({
        auto&& _m = std::tuple{e, f};
        prism_rtl::is<crate::check::types::Ty::TyErr>(std::get<0>(_m)) ? prism_rtl::finished(std::tuple{Text::lit(""), st})
        : prism_rtl::is<crate::check::types::Ty::TyErr>(std::get<1>(_m)) ? prism_rtl::finished(std::tuple{Text::lit(""), st})
        : prism_rtl::is<crate::check::types::Ty::TySig>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<1>(_m)) && ({
        auto&& m3799_2_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a0;
        auto&& m3799_2_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& m3799_2_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a1;
        (m3799_2_0_0 == Text::lit("~")) && (m3799_2_1_0 == Text::lit("Prelude.Error")) && (m3799_2_1_1.size() == 0u);
    }) ? ({
        auto&& m3799_2_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a0;
        auto&& m3799_2_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& m3799_2_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a1;
        prism_rtl::finished(std::tuple{Text::lit(""), st});
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TySig>(std::get<1>(_m)) && ({
        auto&& m3799_3_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& m3799_3_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& m3799_3_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a0;
        (m3799_3_0_0 == Text::lit("Prelude.Error")) && (m3799_3_0_1.size() == 0u) && (m3799_3_1_0 == Text::lit("~"));
    }) ? ({
        auto&& m3799_3_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& m3799_3_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& m3799_3_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a0;
        prism_rtl::finished(std::tuple{Text::lit(""), st});
    })
        : prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<1>(_m)) ? ({
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<0>(_m)).a0;
        auto&& b = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<1>(_m)).a0;
        a == b
        ? prism_rtl::finished(std::tuple{Text::lit(""), st})
        : prism_rtl::finished(std::tuple{Text::lit(""), merge_vars(st, a, b)});
    })
        : prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<0>(_m)) ? ({
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<0>(_m)).a0;
        auto&& t = std::get<1>(_m);
        prism_rtl::more(prism_rtl::rc(BindVar(st, a, t, span)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<1>(_m)) ? ({
        auto&& t = std::get<0>(_m);
        auto&& b = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<1>(_m)).a0;
        prism_rtl::more(prism_rtl::rc(BindVar(st, b, t, span)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyRigid>(std::get<1>(_m)) ? ({
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyRigid>(std::get<0>(_m)).a0;
        auto&& b = prism_rtl::as<crate::check::types::Ty::TyRigid>(std::get<1>(_m)).a0;
        a == b
        ? prism_rtl::finished(std::tuple{Text::lit(""), st})
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st});
    })
        : prism_rtl::is<crate::check::types::Ty::TyQ>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyQ>(std::get<1>(_m)) ? ({
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyQ>(std::get<0>(_m)).a0;
        auto&& b = prism_rtl::as<crate::check::types::Ty::TyQ>(std::get<1>(_m)).a0;
        a == b
        ? prism_rtl::finished(std::tuple{Text::lit(""), st})
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st});
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<1>(_m)) ? ({
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& xs = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& b = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& ys = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a1;
        (a == b) && (len(xs) == len(ys))
        ? prism_rtl::more(prism_rtl::rc(UnifyAll(st, xs, ys, span)))
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st});
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m)) ? ({
        auto&& c1 = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a1;
        auto&& r1 = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a2;
        auto&& c2 = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
        auto&& qs = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
        auto&& r2 = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
        len(ps) == len(qs)
        ? ({
        auto span_1 = span;
        auto st_2 = st;
        call_then(crate::check::types::colors::start_unify_col(st_2, c1, c2), [=](std::tuple<Text, crate::check::types::St> unify_col_4653) {
        return ({
            auto [v_, st2] = unify_col_4653;
            v_ != Text::lit("")
            ? prism_rtl::finished(std::tuple{v_, st2})
            : prism_rtl::more(prism_rtl::rc(UnifyAll(st2, crate::prelude::push(ps, r1), crate::prelude::push(qs, r2), span_1)));
        });
    });
    })
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st});
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyTuple>(std::get<1>(_m)) ? ({
        auto&& xs = prism_rtl::as<crate::check::types::Ty::TyTuple>(std::get<0>(_m)).a0;
        auto&& ys = prism_rtl::as<crate::check::types::Ty::TyTuple>(std::get<1>(_m)).a0;
        len(xs) == len(ys)
        ? prism_rtl::more(prism_rtl::rc(UnifyAll(st, xs, ys, span)))
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st});
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyArray>(std::get<1>(_m)) ? ({
        auto&& x = prism_rtl::as<crate::check::types::Ty::TyArray>(std::get<0>(_m)).a0;
        auto&& y = prism_rtl::as<crate::check::types::Ty::TyArray>(std::get<1>(_m)).a0;
        prism_rtl::more(prism_rtl::rc(UnifyIn(st, x, y, span)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyMap>(std::get<1>(_m)) ? ({
        auto&& k1 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<0>(_m)).a0;
        auto&& v1 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<0>(_m)).a1;
        auto&& k2 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<1>(_m)).a0;
        auto&& v2 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<1>(_m)).a1;
        prism_rtl::more(prism_rtl::rc(UnifyAll(st, Array(std::vector{k1, v1}), Array(std::vector{k2, v2}), span)));
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TySig>(std::get<1>(_m)) ? ({
        auto&& s1 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a0;
        auto&& i1 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a1;
        auto&& s2 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a0;
        auto&& i2 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a1;
        s1 == s2
        ? prism_rtl::more(prism_rtl::rc(UnifyIn(st, i1, i2, span)))
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st});
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<1>(_m)) ? ({
        auto&& i1 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a0;
        auto&& r1 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a1;
        auto&& i2 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a0;
        auto&& r2 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a1;
        ({
        auto span_1 = span;
        auto st_2 = st;
        call_then(start_unify_in(st_2, i1, i2, span_1), [=](std::tuple<Text, crate::check::types::St> unify_in_5237) {
        return ({
            auto [v_, st2] = unify_in_5237;
            v_ != Text::lit("")
            ? prism_rtl::finished(std::tuple{v_, st2})
            : prism_rtl::more(prism_rtl::rc(UnifyRow(st2, r1, r2, span_1)));
        });
    });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyElem>(std::get<1>(_m)) ? ({
        auto&& r1 = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<0>(_m)).a0;
        auto&& o1 = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<0>(_m)).a1;
        auto&& r2 = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<1>(_m)).a0;
        auto&& o2 = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<1>(_m)).a1;
        ({
        auto span_1 = span;
        auto st_2 = st;
        call_then(start_unify_row(st_2, r1, r2, span_1), [=](std::tuple<Text, crate::check::types::St> unify_row_5405) {
        return ({
            auto [v_, st2] = unify_row_5405;
            v_ != Text::lit("")
            ? prism_rtl::finished(std::tuple{v_, st2})
            : prism_rtl::more(prism_rtl::rc(UnifyIn(st2, o1, o2, span_1)));
        });
    });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElemAny>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyElemAny>(std::get<1>(_m)) ? ({
        auto&& r1 = prism_rtl::as<crate::check::types::Ty::TyElemAny>(std::get<0>(_m)).a0;
        auto&& r2 = prism_rtl::as<crate::check::types::Ty::TyElemAny>(std::get<1>(_m)).a0;
        prism_rtl::more(prism_rtl::rc(UnifyRow(st, r1, r2, span)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAssoc>(std::get<1>(_m)) ? ({
        auto&& n1 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<0>(_m)).a0;
        auto&& a1 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<0>(_m)).a1;
        auto&& n2 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<1>(_m)).a0;
        auto&& a2 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<1>(_m)).a1;
        n1 == n2
        ? prism_rtl::more(prism_rtl::rc(UnifyIn(st, a1, a2, span)))
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st});
    })
        : prism_rtl::is<crate::check::types::Ty::TyAny>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAny>(std::get<1>(_m)) ? ({
        auto&& xs = prism_rtl::as<crate::check::types::Ty::TyAny>(std::get<0>(_m)).a0;
        auto&& ys = prism_rtl::as<crate::check::types::Ty::TyAny>(std::get<1>(_m)).a0;
        crate::check::types::sort_texts(xs) == crate::check::types::sort_texts(ys)
        ? prism_rtl::finished(std::tuple{Text::lit(""), st})
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st});
    })
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st});
    });
}


/// `Start UnifyHeads, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_heads(crate::check::types::St st, crate::check::types::Ty e, crate::check::types::Ty f, crate::syntax::Range span) {
    return prism_rtl::make_rc<UnifyHeads>(st, e, f, span);
}


/// UnifyAll: unbounded fn St, [Ty], [Ty], Range -> ((Text, St))
std::tuple<Text, crate::check::types::St> unify_all(const crate::check::types::St& st, const Array<crate::check::types::Ty>& xs, const Array<crate::check::types::Ty>& ys, const crate::syntax::Range& span) {
    return run_to_end(fold_job(crate::check::errors::range0(len(xs)), std::tuple{Text::lit(""), st}, ({
        auto xs_1 = xs;
        auto ys_2 = ys;
        auto span_3 = span;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>>(std::tuple<std::tuple<Text, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Text, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xs_1_4 = xs_1;
            auto ys_2_4 = ys_2;
            auto span_3_4 = span_3;
            entered(once_job([=]() {
            return ({
                auto [v_, s] = p0;
                auto i = p1;
                v_ != Text::lit("")
                ? prism_rtl::finished(std::tuple{v_, s})
                : prism_rtl::more(prism_rtl::rc(UnifyIn(s, or_(index(xs_1_4, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), or_(index(ys_2_4, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), span_3_4)));
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> UnifyAll::cycle() const {
    const auto& st = this->st;
    const auto& xs = this->xs;
    const auto& ys = this->ys;
    const auto& span = this->span;
    return fold_job(crate::check::errors::range0(len(xs)), std::tuple{Text::lit(""), st}, ({
        auto xs_1 = xs;
        auto ys_2 = ys;
        auto span_3 = span;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>>(std::tuple<std::tuple<Text, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Text, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xs_1_4 = xs_1;
            auto ys_2_4 = ys_2;
            auto span_3_4 = span_3;
            entered(once_job([=]() {
            return ({
                auto [v_, s] = p0;
                auto i = p1;
                v_ != Text::lit("")
                ? prism_rtl::finished(std::tuple{v_, s})
                : prism_rtl::more(prism_rtl::rc(UnifyIn(s, or_(index(xs_1_4, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), or_(index(ys_2_4, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), span_3_4)));
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start UnifyAll, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_all(crate::check::types::St st, Array<crate::check::types::Ty> xs, Array<crate::check::types::Ty> ys, crate::syntax::Range span) {
    return prism_rtl::make_rc<UnifyAll>(st, xs, ys, span);
}


/// MergeVars: fn St, Nat, Nat -> St
crate::check::types::St merge_vars(const crate::check::types::St& st, const Nat& a, const Nat& b) {
    auto ia = crate::check::types::recording::info_of(st, a);
    auto ib = crate::check::types::recording::info_of(st, b);
    auto merged = crate::check::types::VInfo{.plain = ia.plain || ib.plain, .level = crate::prelude::min(ia.level, ib.level), .name = ib.name == Text::lit("") ? ia.name : ib.name};
    crate::check::types::St this_ = st;
    this_.tys = insert(this_.tys, a, crate::check::types::Ty(crate::check::types::Ty::TyFlex{b}));
    this_.infos = insert(this_.infos, b, merged);
    return this_;
}


/// BindVar: unbounded fn St, Nat, Ty, Range -> ((Text, St))
std::tuple<Text, crate::check::types::St> bind_var(const crate::check::types::St& st, const Nat& n, const crate::check::types::Ty& t, const crate::syntax::Range& span) {
    auto info = crate::check::types::recording::info_of(st, n);
    auto stack = crate::check::types::stack_of(st, t);
    return crate::check::types::has_nat(crate::check::types::recording::free_vars(st, t), n)
        ? std::tuple{Text::lit("reported"), crate::check::types::recording::err(st, Text::lit("occurs"), span, prism_rtl::cat("`t", n, "` would contain itself: `t", n, " = ", crate::check::types::show_ty(st, t), "`"))}
        : info.plain && (stack != Text::lit(""))
        ? info.name != Text::lit("")
        ? ({
        auto marks = marks_of(info.name);
        auto whole = prism_rtl::cat(marks, crate::check::types::show_ty_in(st, crate::check::types::recording::zonk(st, t), true));
        auto at_ = or_(crate::prelude::get(st.binder_at, n), span);
        auto st2 = crate::check::types::recording::err_fix(st, Text::lit("mark-stack"), at_, prism_rtl::cat("`", info.name, "` has type `", whole, "`, whose stack is `", marks, stack, "`; the name shows `", marks, "`"), prism_rtl::cat("rename to `", marks, stack, crate::syntax::lexer::chars::drop_prefix(info.name, marks), "`"));
        std::tuple{Text::lit(""), ({
        crate::check::types::St this_ = lower_levels(st2, append(crate::check::types::recording::free_vars(st2, t), crate::check::types::colors::free_col_vars(st2, t)), info.level);
        this_.tys = insert(this_.tys, n, t);
        this_;
    })};
    })
        : std::tuple{Text::lit("mismatch"), st}
        : ({
        auto lowered = lower_levels(st, append(crate::check::types::recording::free_vars(st, t), crate::check::types::colors::free_col_vars(st, t)), info.level);
        std::tuple{Text::lit(""), ({
        crate::check::types::St this_ = lowered;
        this_.tys = insert(this_.tys, n, t);
        this_;
    })};
    });
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> BindVar::cycle() const {
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& t = this->t;
    const auto& span = this->span;
    auto info = crate::check::types::recording::info_of(st, n);
    auto n_1 = n;
    auto span_2 = span;
    auto st_3 = st;
    auto t_4 = t;
    return call_then(crate::check::types::start_stack_of(st_3, t_4), [=](Text stack_of_6651) {
        return ({
            auto stack = stack_of_6651;
            call_then(crate::check::types::recording::start_free_vars(st_3, t_4), [=](Array<Nat> free_vars_6680) {
            return crate::check::types::has_nat(free_vars_6680, n_1)
                ? call_then(crate::check::types::start_show_ty(st_3, t_4), [=](Text show_ty_6786) { return prism_rtl::finished(std::tuple{Text::lit("reported"), crate::check::types::recording::err(st_3, Text::lit("occurs"), span_2, prism_rtl::cat("`t", n_1, "` would contain itself: `t", n_1, " = ", show_ty_6786, "`"))}); })
                : info.plain && (stack != Text::lit(""))
                ? info.name != Text::lit("")
                ? ({
                auto marks = marks_of(info.name);
                call_then(crate::check::types::recording::start_zonk(st_3, t_4), [=](crate::check::types::Ty zonk_6963) {
                return call_then(crate::check::types::start_show_ty_in(st_3, zonk_6963, true), [=](Text show_ty_in_6949) {
                    return ({
                        auto whole = prism_rtl::cat(marks, show_ty_in_6949);
                        auto at_ = or_(crate::prelude::get(st_3.binder_at, n_1), span_2);
                        auto st2 = crate::check::types::recording::err_fix(st_3, Text::lit("mark-stack"), at_, prism_rtl::cat("`", info.name, "` has type `", whole, "`, whose stack is `", marks, stack, "`; the name shows `", marks, "`"), prism_rtl::cat("rename to `", marks, stack, crate::syntax::lexer::chars::drop_prefix(info.name, marks), "`"));
                        (prism_rtl::finished(std::tuple{Text::lit(""), ({
                        crate::check::types::St this_ = lower_levels(st2, append(crate::check::types::recording::free_vars(st2, t_4), crate::check::types::colors::free_col_vars(st2, t_4)), info.level);
                        this_.tys = insert(this_.tys, n_1, t_4);
                        this_;
                    })}));
                    });
                });
            });
            })
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_3})
                : call_then(crate::check::types::recording::start_free_vars(st_3, t_4), [=](Array<Nat> free_vars_7628) {
                return call_then(crate::check::types::colors::start_free_col_vars(st_3, t_4), [=](Array<Nat> free_col_vars_7646) {
                    return ({
                        auto lowered = lower_levels(st_3, append(free_vars_7628, free_col_vars_7646), info.level);
                        (prism_rtl::finished(std::tuple{Text::lit(""), ({
                        crate::check::types::St this_ = lowered;
                        this_.tys = insert(this_.tys, n_1, t_4);
                        this_;
                    })}));
                    });
                });
            });
        });
        });
    });
}


/// `Start BindVar, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_bind_var(crate::check::types::St st, Nat n, crate::check::types::Ty t, crate::syntax::Range span) {
    return prism_rtl::make_rc<BindVar>(st, n, t, span);
}


/// MarksOf: fn Text -> Text
Text marks_of(const Text& name) {
    auto c = ({
        Cursor this_ = front(name);
        while (true) {
            auto&& _m = step(this_);
            if (!(prism_rtl::is_some(_m))) break;
            auto&& next_ = std::get<1>(prism_rtl::some_of(_m));
            if (!is_mark_char(crate::syntax::lexer::chars::char_at(this_))) {
                break;
            }
            this_ = next_;
        }
        this_;
    });
    return before(c);
}


/// IsMarkChar: fn Text -> Bool
bool is_mark_char(const Text& c) {
    return (((((c == Text::lit("$")) || (c == Text::lit("!"))) || (c == Text::lit("@"))) || (c == Text::lit("?"))) || (c == Text::lit("~"))) || (c == Text::lit("&"));
}


/// LowerLevels: fn St, [Nat], Nat -> St
crate::check::types::St lower_levels(const crate::check::types::St& st, const Array<Nat>& vs, const Nat& level) {
    return fold(vs, st, [&](const crate::check::types::St& s, const Nat& v_) { return lower_one(s, v_, level); });
}


/// LowerOne: fn St, Nat, Nat -> St
crate::check::types::St lower_one(const crate::check::types::St& s, const Nat& v_, const Nat& level) {
    auto i = crate::check::types::recording::info_of(s, v_);
    return i.level <= level
        ? s
        : ({
        crate::check::types::St this_ = s;
        this_.infos = insert(this_.infos, v_, crate::check::types::VInfo{.plain = i.plain, .level = level, .name = i.name});
        this_;
    });
}


/// UnifyRow: unbounded fn St, Rw, Rw, Range -> ((Text, St))
std::tuple<Text, crate::check::types::St> unify_row(const crate::check::types::St& st, const crate::check::types::Rw& a0, const crate::check::types::Rw& b0, const crate::syntax::Range& span) {
    auto a = crate::check::types::recording::walk_row(st, a0);
    auto b = crate::check::types::recording::walk_row(st, b0);
    auto only_a = crate::check::types::minus_texts(a.fams, b.fams);
    auto only_b = crate::check::types::minus_texts(b.fams, a.fams);
    auto&& _m = std::tuple{a.tail, b.tail};
    if (prism_rtl::is<crate::check::types::Tail::TlClosed>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlClosed>(std::get<1>(_m))) {
        return (len(only_a) == Nat(0u)) && (len(only_b) == Nat(0u))
            ? std::tuple{Text::lit(""), st}
            : std::tuple{Text::lit("mismatch"), st};
    }
    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<1>(_m))) {
        auto&& x = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<0>(_m)).a0;
        auto&& y = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<1>(_m)).a0;
        return x == y
            ? (len(only_a) == Nat(0u)) && (len(only_b) == Nat(0u))
            ? std::tuple{Text::lit(""), st}
            : std::tuple{Text::lit("mismatch"), st}
            : ({
            auto lacking = crate::check::types::union_texts(crate::check::types::union_texts(lacks_of(st, x), lacks_of(st, y)), crate::check::types::union_texts(a.fams, b.fams));
            auto [fresh, st2] = crate::check::types::recording::fresh_row(st, lacking);
            auto [v1, st3] = bind_row(st2, x, crate::check::types::Rw{.fams = only_b, .minus = Array<Text>{}, .tail = fresh.tail}, span);
            v1 != Text::lit("")
            ? std::tuple{v1, st3}
            : bind_row(st3, y, crate::check::types::Rw{.fams = only_a, .minus = Array<Text>{}, .tail = fresh.tail}, span);
        });
    }
    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<0>(_m))) {
        auto&& x = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<0>(_m)).a0;
        auto&& other = std::get<1>(_m);
        return len(only_a) == Nat(0u)
            ? bind_row(st, x, crate::check::types::Rw{.fams = only_b, .minus = b.minus, .tail = other}, span)
            : std::tuple{Text::lit("mismatch"), st};
    }
    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<1>(_m))) {
        auto&& other = std::get<0>(_m);
        auto&& y = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<1>(_m)).a0;
        return len(only_b) == Nat(0u)
            ? bind_row(st, y, crate::check::types::Rw{.fams = only_a, .minus = a.minus, .tail = other}, span)
            : std::tuple{Text::lit("mismatch"), st};
    }
    if (prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<1>(_m))) {
        auto&& x = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<0>(_m)).a0;
        auto&& y = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<1>(_m)).a0;
        return ((x == y) && (len(only_a) == Nat(0u))) && (len(only_b) == Nat(0u))
            ? std::tuple{Text::lit(""), st}
            : std::tuple{Text::lit("mismatch"), st};
    }
    if (prism_rtl::is<crate::check::types::Tail::TlQ>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlQ>(std::get<1>(_m))) {
        auto&& x = prism_rtl::as<crate::check::types::Tail::TlQ>(std::get<0>(_m)).a0;
        auto&& y = prism_rtl::as<crate::check::types::Tail::TlQ>(std::get<1>(_m)).a0;
        return ((x == y) && (len(only_a) == Nat(0u))) && (len(only_b) == Nat(0u))
            ? std::tuple{Text::lit(""), st}
            : std::tuple{Text::lit("mismatch"), st};
    }
    {
        return std::tuple{Text::lit("mismatch"), st};
    }
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> UnifyRow::cycle() const {
    const auto& st = this->st;
    const auto& a0 = this->a0;
    const auto& b0 = this->b0;
    const auto& span = this->span;
    auto a0_1 = a0;
    auto b0_2 = b0;
    auto span_3 = span;
    auto st_4 = st;
    return call_then(crate::check::types::recording::start_walk_row(st_4, a0_1), [=](crate::check::types::Rw walk_row_8688) {
        return ({
            auto a = walk_row_8688;
            call_then(crate::check::types::recording::start_walk_row(st_4, b0_2), [=](crate::check::types::Rw walk_row_8715) {
            return ({
                auto b = walk_row_8715;
                auto only_a = crate::check::types::minus_texts(a.fams, b.fams);
                auto only_b = crate::check::types::minus_texts(b.fams, a.fams);
                ({
                auto&& _m = std::tuple{a.tail, b.tail};
                prism_rtl::is<crate::check::types::Tail::TlClosed>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlClosed>(std::get<1>(_m)) ? (len(only_a) == Nat(0u)) && (len(only_b) == Nat(0u))
                ? prism_rtl::finished(std::tuple{Text::lit(""), st_4})
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_4})
                : prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<1>(_m)) ? ({
                auto&& x = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<0>(_m)).a0;
                auto&& y = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<1>(_m)).a0;
                x == y
                ? (len(only_a) == Nat(0u)) && (len(only_b) == Nat(0u))
                ? prism_rtl::finished(std::tuple{Text::lit(""), st_4})
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_4})
                : ({
                auto lacking = crate::check::types::union_texts(crate::check::types::union_texts(lacks_of(st_4, x), lacks_of(st_4, y)), crate::check::types::union_texts(a.fams, b.fams));
                auto [fresh, st2] = crate::check::types::recording::fresh_row(st_4, lacking);
                call_then(start_bind_row(st2, x, crate::check::types::Rw{.fams = only_b, .minus = Array<Text>{}, .tail = fresh.tail}, span_3), [=](std::tuple<Text, crate::check::types::St> bind_row_9329) {
                return ({
                    auto [v1, st3] = bind_row_9329;
                    v1 != Text::lit("")
                    ? prism_rtl::finished(std::tuple{v1, st3})
                    : prism_rtl::more(prism_rtl::rc(BindRow(st3, y, crate::check::types::Rw{.fams = only_a, .minus = Array<Text>{}, .tail = fresh.tail}, span_3)));
                });
            });
            });
            })
                : prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<0>(_m)) ? ({
                auto&& x = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<0>(_m)).a0;
                auto&& other = std::get<1>(_m);
                len(only_a) == Nat(0u)
                ? prism_rtl::more(prism_rtl::rc(BindRow(st_4, x, crate::check::types::Rw{.fams = only_b, .minus = b.minus, .tail = other}, span_3)))
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_4});
            })
                : prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<1>(_m)) ? ({
                auto&& other = std::get<0>(_m);
                auto&& y = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<1>(_m)).a0;
                len(only_b) == Nat(0u)
                ? prism_rtl::more(prism_rtl::rc(BindRow(st_4, y, crate::check::types::Rw{.fams = only_a, .minus = a.minus, .tail = other}, span_3)))
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_4});
            })
                : prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<1>(_m)) ? ({
                auto&& x = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<0>(_m)).a0;
                auto&& y = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<1>(_m)).a0;
                ((x == y) && (len(only_a) == Nat(0u))) && (len(only_b) == Nat(0u))
                ? prism_rtl::finished(std::tuple{Text::lit(""), st_4})
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_4});
            })
                : prism_rtl::is<crate::check::types::Tail::TlQ>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlQ>(std::get<1>(_m)) ? ({
                auto&& x = prism_rtl::as<crate::check::types::Tail::TlQ>(std::get<0>(_m)).a0;
                auto&& y = prism_rtl::as<crate::check::types::Tail::TlQ>(std::get<1>(_m)).a0;
                ((x == y) && (len(only_a) == Nat(0u))) && (len(only_b) == Nat(0u))
                ? prism_rtl::finished(std::tuple{Text::lit(""), st_4})
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_4});
            })
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_4});
            });
            });
        });
        });
    });
}


/// `Start UnifyRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_row(crate::check::types::St st, crate::check::types::Rw a0, crate::check::types::Rw b0, crate::syntax::Range span) {
    return prism_rtl::make_rc<UnifyRow>(st, a0, b0, span);
}


/// AskField: fn St, Ty, Text, Ty, Range, [Text] -> St
crate::check::types::St ask_field(const crate::check::types::St& st, const crate::check::types::Ty& recv, const Text& field_, const crate::check::types::Ty& result, const crate::syntax::Range& span, const Array<Text>& owners) {
    crate::check::types::St this_ = st;
    this_.field_qs = crate::prelude::push(this_.field_qs, FieldQ{.recv = recv, .field = field_, .result = result, .span = span, .file = this_.file, .owners = owners});
    return this_;
}


/// AskLayer: fn St, Ty, Range, Text -> St
crate::check::types::St ask_layer(const crate::check::types::St& st, const crate::check::types::Ty& t, const crate::syntax::Range& span, const Text& fname) {
    crate::check::types::St this_ = st;
    this_.layer_qs = crate::prelude::push(this_.layer_qs, std::tuple{t, span, fname});
    return this_;
}


/// LayerQuestions: unbounded fn St -> St
crate::check::types::St layer_questions(const crate::check::types::St& st) {
    auto qs = st.layer_qs;
    auto cleared = ({
        crate::check::types::St this_ = st;
        this_.layer_qs = Array<std::tuple<crate::check::types::Ty, crate::syntax::Range, Text>>{};
        this_;
    });
    return run_to_end(fold_job(qs, cleared, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::syntax::Range, Text>>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::syntax::Range, Text>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto [t, span, fname] = p1;
                call_then(crate::check::types::start_head_sigil(s, t), [=](Text head_sigil_11312) {
                return ({
                    auto h = head_sigil_11312;
                    call_then(crate::check::types::start_is_free_headed(s, t), [=](bool is_free_headed_11339) {
                    return (is_free_headed_11339 || (h == Text::lit("$"))) || (h == Text::lit("!"))
                        ? prism_rtl::finished(crate::check::types::recording::err_fix(s, Text::lit("layer-unknown"), span, prism_rtl::cat("the layer of this argument to `", fname, "` is not known here"), Text::lit("say it where the value is made: a name whose marks declare the layer (`let $x = ...`), `<<T>>` at the application that made it, or a signature on the enclosing `let`")))
                        : prism_rtl::finished(s);
                });
                });
            });
            });
        }));
    }))));
}


prism_rtl::Turn<crate::check::types::St> LayerQuestions::cycle() const {
    const auto& st = this->st;
    auto qs = st.layer_qs;
    auto cleared = ({
        crate::check::types::St this_ = st;
        this_.layer_qs = Array<std::tuple<crate::check::types::Ty, crate::syntax::Range, Text>>{};
        this_;
    });
    return fold_job(qs, cleared, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::syntax::Range, Text>>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::syntax::Range, Text>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto [t, span, fname] = p1;
                call_then(crate::check::types::start_head_sigil(s, t), [=](Text head_sigil_11312) {
                return ({
                    auto h = head_sigil_11312;
                    call_then(crate::check::types::start_is_free_headed(s, t), [=](bool is_free_headed_11339) {
                    return (is_free_headed_11339 || (h == Text::lit("$"))) || (h == Text::lit("!"))
                        ? prism_rtl::finished(crate::check::types::recording::err_fix(s, Text::lit("layer-unknown"), span, prism_rtl::cat("the layer of this argument to `", fname, "` is not known here"), Text::lit("say it where the value is made: a name whose marks declare the layer (`let $x = ...`), `<<T>>` at the application that made it, or a signature on the enclosing `let`")))
                        : prism_rtl::finished(s);
                });
                });
            });
            });
        }));
    })))->cycle();
}


/// `Start LayerQuestions, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_layer_questions(crate::check::types::St st) {
    return prism_rtl::make_rc<LayerQuestions>(st);
}


/// NameRow: fn St, Tail, Text -> St
crate::check::types::St name_row(const crate::check::types::St& st, const crate::check::types::Tail& tail1, const Text& text2) {
    auto&& _m = std::tuple{tail1, text2};
    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<0>(_m))) {
        auto&& n = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<0>(_m)).a0;
        auto&& q = std::get<1>(_m);
        crate::check::types::St this_ = st;
        this_.row_names = insert(this_.row_names, n, q);
        return this_;
    }
    {
        return st;
    }
    prism_rtl::unreachable("no arm matched");
}


/// RowName: fn St, Nat -> Text
Text row_name(const crate::check::types::St& st, const Nat& n) {
    return or_(crate::prelude::get(st.row_names, n), prism_rtl::cat("r", n));
}


/// LacksOf: fn St, Nat -> [Text]
Array<Text> lacks_of(const crate::check::types::St& st, const Nat& n) {
    return or_(crate::prelude::get(st.lacks, n), Array<Text>{});
}


/// BindRow: unbounded fn St, Nat, Rw, Range -> ((Text, St))
std::tuple<Text, crate::check::types::St> bind_row(const crate::check::types::St& st, const Nat& n, const crate::check::types::Rw& rw, const crate::syntax::Range& span) {
    auto bad = crate::check::types::inter_texts(lacks_of(st, n), rw.fams);
    return len(bad) > Nat(0u)
        ? ({
        auto fam = or_(index(bad, Nat(0u)), Text::lit(""));
        std::tuple{Text::lit("reported"), crate::check::types::recording::err_fix(st, Text::lit("row-lacks"), span, prism_rtl::cat("`", row_name(st, n), " | ", fam, ".*` promises `", row_name(st, n), "` has no `", fam, "` tags"), prism_rtl::cat("answer the `", fam, "` tags before this point, or widen the row"))};
    })
        : ({
        auto st2 = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            auto&& _m = rw.tail;
            if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
                auto&& m = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
                _v.set(({
                    crate::check::types::St this_ = st;
                    this_.lacks = insert(this_.lacks, m, crate::check::types::union_texts(lacks_of(st, m), lacks_of(st, n)));
                    this_;
                }));
                goto _done;
            }
            {
                _v.set(st);
                goto _done;
            }
        _done:
            _v.take();
        });
        std::tuple{Text::lit(""), ({
        crate::check::types::St this_ = st2;
        this_.rows = insert(this_.rows, n, rw);
        this_;
    })};
    });
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> BindRow::cycle() const {
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& rw = this->rw;
    const auto& span = this->span;
    auto bad = crate::check::types::inter_texts(lacks_of(st, n), rw.fams);
    return len(bad) > Nat(0u)
        ? ({
        auto fam = or_(index(bad, Nat(0u)), Text::lit(""));
        (prism_rtl::finished(std::tuple{Text::lit("reported"), crate::check::types::recording::err_fix(st, Text::lit("row-lacks"), span, prism_rtl::cat("`", row_name(st, n), " | ", fam, ".*` promises `", row_name(st, n), "` has no `", fam, "` tags"), prism_rtl::cat("answer the `", fam, "` tags before this point, or widen the row"))}));
    })
        : ({
        auto st2 = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            auto&& _m = rw.tail;
            if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
                auto&& m = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
                _v.set(({
                    crate::check::types::St this_ = st;
                    this_.lacks = insert(this_.lacks, m, crate::check::types::union_texts(lacks_of(st, m), lacks_of(st, n)));
                    this_;
                }));
                goto _done;
            }
            {
                _v.set(st);
                goto _done;
            }
        _done:
            _v.take();
        });
        (prism_rtl::finished(std::tuple{Text::lit(""), ({
        crate::check::types::St this_ = st2;
        this_.rows = insert(this_.rows, n, rw);
        this_;
    })}));
    });
}


/// `Start BindRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_bind_row(crate::check::types::St st, Nat n, crate::check::types::Rw rw, crate::syntax::Range span) {
    return prism_rtl::make_rc<BindRow>(st, n, rw, span);
}

}  // namespace crate::check::types::unify


// The module `Checking`, from `target/bootstrap/cpp-src/prismc/checking.prism`.
namespace crate::checking {

void CheckJob::show(Printer& p) const {
    p.record("CheckJob", {{"read", read}, {"world", world}, {"typed", typed}, {"unused", unused}});
}

Pod CheckJob::to_pod() const {
    return Pod::record("CheckJob", {{"read", prism_rtl::to_pod(read)}, {"world", prism_rtl::to_pod(world)}, {"typed", prism_rtl::to_pod(typed)}, {"unused", prism_rtl::to_pod(unused)}});
}

Result<CheckJob> CheckJob::from_pod(const Pod& whole) {
    return CheckJob{.read = TRY(prism_rtl::from_pod<crate::reading::ReadInput>(TRY(crate::prelude::field(whole, "read")))), .world = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "world")))), .typed = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "typed")))), .unused = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "unused"))))};
}


/// CheckFiles: unbounded fn CheckJob -> Outcome
crate::program::Outcome_ check_files(const CheckJob& job) {
    auto read = crate::reading::assemble(job.read);
    return len(read.errors) > Nat(0u)
        ? ({
        auto report = crate::reading::tree_report(job.read, read.errors);
        crate::program::Outcome_{.text = prism_rtl::cat(report, "\n"), .failed = true, .report = report};
    })
        : ({
        auto pp = crate::reading::parse_program(read);
        pp.errors != Text::lit("")
        ? crate::program::Outcome_{.text = prism_rtl::cat(pp.errors, "parse errors\n"), .failed = true, .report = prism_rtl::cat(pp.errors, "parse errors")}
        : ({
        auto pre = crate::reading::tree_decl_diags(pp);
        auto checked = each(pp.trees, [&](const crate::syntax::Module& t) { return crate::compile::without_tests(t); });
        auto report = crate::check::check_program(pp.srcs, checked, job->world, pp.shown, job.typed, job.unused, pre);
        auto summary = report.errors == Nat(0u)
            ? Text::lit("no errors\n")
            : prism_rtl::cat(report.errors, " error", report.errors == Nat(1u) ? Text::lit("") : Text::lit("s"), "\n");
        auto shown = job.typed
            ? prism_rtl::cat(crate::check::typed::print::typed_sexp(pp.srcs, checked, pp.shown, report.typed), commented(prism_rtl::cat(report->text, summary)))
            : prism_rtl::cat(report->text, summary);
        crate::program::Outcome_{.text = shown, .failed = report.errors > Nat(0u), .report = prism_rtl::cat(report->text, summary)};
    });
    });
}


prism_rtl::Turn<crate::program::Outcome_> CheckFiles::cycle() const {
    const auto& job = this->job;
    auto job_1 = job;
    return call_then(crate::reading::start_assemble(job_1.read), [=](crate::reading::Assembled assemble_1698) {
        return ({
            auto read = assemble_1698;
            len(read.errors) > Nat(0u)
            ? ({
            auto report = crate::reading::tree_report(job_1.read, read.errors);
            (prism_rtl::finished(crate::program::Outcome_{.text = prism_rtl::cat(report, "\n"), .failed = true, .report = report}));
        })
            : call_then(crate::reading::start_parse_program(read), [=](crate::reading::ParsedProgram parse_program_1890) {
            return ({
                auto pp = parse_program_1890;
                pp.errors != Text::lit("")
                ? prism_rtl::finished(crate::program::Outcome_{.text = prism_rtl::cat(pp.errors, "parse errors\n"), .failed = true, .report = prism_rtl::cat(pp.errors, "parse errors")})
                : ({
                auto pre = crate::reading::tree_decl_diags(pp);
                auto checked = each(pp.trees, [&](const crate::syntax::Module& t) { return crate::compile::without_tests(t); });
                call_then(crate::check::start_check_program(pp.srcs, checked, job_1->world, pp.shown, job_1.typed, job_1.unused, pre), [=](crate::check::Report_ check_program_2311) {
                return ({
                    auto report = check_program_2311;
                    auto summary = report.errors == Nat(0u)
                        ? Text::lit("no errors\n")
                        : prism_rtl::cat(report.errors, " error", report.errors == Nat(1u) ? Text::lit("") : Text::lit("s"), "\n");
                    auto shown = job_1.typed
                        ? prism_rtl::cat(crate::check::typed::print::typed_sexp(pp.srcs, checked, pp.shown, report.typed), commented(prism_rtl::cat(report->text, summary)))
                        : prism_rtl::cat(report->text, summary);
                    (prism_rtl::finished(crate::program::Outcome_{.text = shown, .failed = report.errors > Nat(0u), .report = prism_rtl::cat(report->text, summary)}));
                });
            });
            });
            });
        });
        });
    });
}


/// `Start CheckFiles, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::program::Outcome_> start_check_files(CheckJob job) {
    return prism_rtl::make_rc<CheckFiles>(job);
}


/// Commented: fn Text -> Text
Text commented(const Text& t) {
    return concat(each(filter(split_on(t, Text::lit("\n")), [&](const Text& l) { return l != Text::lit(""); }), [&](const Text& l) { return prism_rtl::cat("; ", l, "\n"); }));
}


// `@CheckMain` is inlined where it is applied.

/// let checkValued
Array<Text> check_valued() {
    return Array(std::vector{Text::lit("--prelude"), Text::lit("--out"), Text::lit("--world")});
}


// `@FinishCheck` is inlined where it is applied.

// `@WriteOut` is inlined where it is applied.

}  // namespace crate::checking


// The module `Compile`, from `target/bootstrap/cpp-src/prismc/compile.prism`.
namespace crate::compile {

void CompileJob::show(Printer& p) const {
    p.record("CompileJob", {{"read", read}, {"name", name}, {"runtime", runtime}, {"target", target}});
}

Pod CompileJob::to_pod() const {
    return Pod::record("CompileJob", {{"read", prism_rtl::to_pod(read)}, {"name", prism_rtl::to_pod(name)}, {"runtime", prism_rtl::to_pod(runtime)}, {"target", prism_rtl::to_pod(target)}});
}

Result<CompileJob> CompileJob::from_pod(const Pod& whole) {
    return CompileJob{.read = TRY(prism_rtl::from_pod<crate::reading::ReadInput>(TRY(crate::prelude::field(whole, "read")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .runtime = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "runtime")))), .target = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "target"))))};
}


void Compiled::show(Printer& p) const {
    p.record("Compiled", {{"files", files}, {"failed", failed}, {"report", report}});
}

Pod Compiled::to_pod() const {
    return Pod::record("Compiled", {{"files", prism_rtl::to_pod(files)}, {"failed", prism_rtl::to_pod(failed)}, {"report", prism_rtl::to_pod(report)}});
}

Result<Compiled> Compiled::from_pod(const Pod& whole) {
    return Compiled{.files = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "files")))), .failed = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "failed")))), .report = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "report"))))};
}


// `@CompileMain` is inlined where it is applied.

/// let compileValued
Array<Text> compile_valued() {
    return Array(std::vector{Text::lit("-o"), Text::lit("--prelude"), Text::lit("--name"), Text::lit("--runtime"), Text::lit("--target")});
}


/// ?RuntimeOf: fn ?Text, ?Text, Text -> ?Text
std::optional<Text> runtime_of(const std::optional<Text>& named_opt, const std::optional<Text>& root_opt, const Text& out) {
    if (prism_rtl::is_some(named_opt)) {
        auto&& r = prism_rtl::some_of(named_opt);
        return std::optional(r);
    }
    if (prism_rtl::is_none(named_opt)) {
        return !crate::syntax::lexer::chars::has_prefix(out, Text::lit("/"))
            ? std::optional(runtime_for(out))
            : root_opt;
    }
    prism_rtl::unreachable("no arm matched");
}


/// RuntimeFor: fn Text -> Text
Text runtime_for(const Text& out) {
    auto parts = filter(split_on(out, Text::lit("/")), [&](const Text& p_) { return (p_ != Text::lit("")) && (p_ != Text::lit(".")); });
    return len(parts) == Nat(0u)
        ? Text::lit(".")
        : crate::syntax::lexer::chars::join(each(parts, [&](const Text& _p0) { return Text::lit(".."); }), Text::lit("/"));
}


/// CompileProgram: unbounded fn CompileJob -> Compiled
Compiled compile_program(const CompileJob& job) {
    auto read = crate::reading::assemble(job.read);
    return len(read.errors) > Nat(0u)
        ? Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = crate::reading::tree_report(job.read, read.errors)}
        : ({
        auto pp = crate::reading::parse_program(read);
        pp.errors != Text::lit("")
        ? Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = prism_rtl::cat(pp.errors, "parse errors")}
        : ({
        auto pre = crate::reading::tree_decl_diags(pp);
        auto report = crate::check::check_program(pp.srcs, each(pp.trees, [&](const crate::syntax::Module& t) { return without_tests(t); }), Array<Text>{}, pp.shown, true, false, pre);
        report.errors > Nat(0u)
        ? Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = prism_rtl::cat(report->text, report.errors, " error", report.errors == Nat(1u) ? Text::lit("") : Text::lit("s"))}
        : ({
        auto model = crate::lower::program::lower_program(pp.srcs, pp.trees, pp.shown, report.typed, job.name);
        auto files = job->target == Text::lit("cpp")
            ? crate::emit::cpp::program::emit_cpp(model, job->runtime, read.scripts)
            : crate::emit::rust::items::emit_crate(model, job->runtime, read.scripts);
        auto refused = fold(files, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text>& _p1) {
            auto&& path_ = std::get<0>(_p1);
            auto&& text_ = std::get<1>(_p1);
            return fold(refusals(text_), acc, [&](const Array<Text>& a, const Text& r) { return crate::check::types::add_text(a, prism_rtl::cat(path_, ": ", r)); });
        });
        len(refused) == Nat(0u)
        ? Compiled{.files = files, .failed = false, .report = Text::lit("")}
        : Compiled{.files = files, .failed = true, .report = prism_rtl::cat(concat(each(refused, [&](const Text& r) { return prism_rtl::cat("error[not-lowered]: ", r, "\n"); })), len(refused), " construct", len(refused) == Nat(1u) ? Text::lit("") : Text::lit("s"), " the back end does not lower (the crate is written, with a `compile_error!` at each)")};
    });
    });
    });
}


prism_rtl::Turn<Compiled> CompileProgram::cycle() const {
    const auto& job = this->job;
    auto job_1 = job;
    return call_then(crate::reading::start_assemble(job_1.read), [=](crate::reading::Assembled assemble_4670) {
        return ({
            auto read = assemble_4670;
            len(read.errors) > Nat(0u)
            ? prism_rtl::finished(Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = crate::reading::tree_report(job_1.read, read.errors)})
            : call_then(crate::reading::start_parse_program(read), [=](crate::reading::ParsedProgram parse_program_4822) {
            return ({
                auto pp = parse_program_4822;
                pp.errors != Text::lit("")
                ? prism_rtl::finished(Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = prism_rtl::cat(pp.errors, "parse errors")})
                : ({
                auto pre = crate::reading::tree_decl_diags(pp);
                call_then(crate::check::start_check_program(pp.srcs, each(pp.trees, [&](const crate::syntax::Module& t) { return without_tests(t); }), Array<Text>{}, pp.shown, true, false, pre), [=](crate::check::Report_ check_program_5014) {
                return ({
                    auto report = check_program_5014;
                    report.errors > Nat(0u)
                    ? prism_rtl::finished(Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = prism_rtl::cat(report->text, report.errors, " error", report.errors == Nat(1u) ? Text::lit("") : Text::lit("s"))})
                    : call_then(crate::lower::program::start_lower_program(pp.srcs, pp.trees, pp.shown, report.typed, job_1.name), [=](crate::lower::model::Model lower_program_5303) {
                    return ({
                        auto model = lower_program_5303;
                        auto files = job_1->target == Text::lit("cpp")
                            ? crate::emit::cpp::program::emit_cpp(model, job_1->runtime, read.scripts)
                            : crate::emit::rust::items::emit_crate(model, job_1->runtime, read.scripts);
                        auto refused = fold(files, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text>& _p1) {
                            auto&& path_ = std::get<0>(_p1);
                            auto&& text_ = std::get<1>(_p1);
                            return fold(refusals(text_), acc, [&](const Array<Text>& a, const Text& r) { return crate::check::types::add_text(a, prism_rtl::cat(path_, ": ", r)); });
                        });
                        len(refused) == Nat(0u)
                        ? prism_rtl::finished(Compiled{.files = files, .failed = false, .report = Text::lit("")})
                        : prism_rtl::finished(Compiled{.files = files, .failed = true, .report = prism_rtl::cat(concat(each(refused, [&](const Text& r) { return prism_rtl::cat("error[not-lowered]: ", r, "\n"); })), len(refused), " construct", len(refused) == Nat(1u) ? Text::lit("") : Text::lit("s"), " the back end does not lower (the crate is written, with a `compile_error!` at each)")});
                    });
                });
                });
            });
            });
            });
        });
        });
    });
}


/// `Start CompileProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Compiled> start_compile_program(CompileJob job) {
    return prism_rtl::make_rc<CompileProgram>(job);
}


/// Refusals: fn Text -> [Text]
Array<Text> refusals(const Text& text_) {
    auto marker = Text::lit("compile_error!(\"prismc does not lower ");
    auto parts = split_on(text_, marker);
    return fold(drop(parts, Nat(1u)), Array<Text>{}, [&](const Array<Text>& acc, const Text& part) { return crate::check::types::add_text(acc, or_(index(split_on(part, Text::lit("\")")), Nat(0u)), part)); });
}


/// WithoutTests: fn Module -> Module
crate::syntax::Module without_tests(const crate::syntax::Module& m) {
    crate::syntax::Module this_ = m;
    this_.decls = each(filter(this_.decls, [&](const crate::syntax::decls::Decl& d) { return !is_test_decl(d); }), [&](const crate::syntax::decls::Decl& d) { return without_patterns(d); });
    return this_;
}


/// WithoutPatterns: fn Decl -> Decl
crate::syntax::decls::Decl without_patterns(const crate::syntax::decls::Decl& d) {
    auto&& _m = d.kind;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DCheck>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::decls::DeclKind::DCheck>(_m).a0;
        crate::syntax::decls::Decl this_ = d;
        this_.kind = crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DCheck{check_without_patterns(c)});
        return this_;
    }
    {
        return d;
    }
}


/// CheckWithoutPatterns: fn CheckDecl -> CheckDecl
crate::syntax::decls::CheckDecl check_without_patterns(const crate::syntax::decls::CheckDecl& c) {
    crate::syntax::decls::CheckDecl this_ = c;
    this_.lines = each(this_.lines, [&](const crate::syntax::decls::CheckLine& l) { return line_without_pattern(l); });
    return this_;
}


/// LineWithoutPattern: fn CheckLine -> CheckLine
crate::syntax::decls::CheckLine line_without_pattern(const crate::syntax::decls::CheckLine& l) {
    crate::syntax::decls::CheckLine this_ = l;
    this_.pattern = std::optional<crate::syntax::Pattern_>{};
    return this_;
}


/// IsTestDecl: fn Decl -> Bool
bool is_test_decl(const crate::syntax::decls::Decl& d) {
    auto&& _m = d.kind;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTest>(_m)) {
        return true;
    }
    {
        return false;
    }
}


// `@FinishCompile` is inlined where it is applied.

}  // namespace crate::compile
