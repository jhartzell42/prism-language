// The modules `Check.Types`, `Check.Types.Colors`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/types/module.hpp>
#include <syntax/module.hpp>
#include <check/typed/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Types`, from `target/bootstrap/cpp-src/prismc/check/types/mod.prism`.
namespace crate::check::types {

void CLeq::show(Printer& p) const {
    p.record("CLeq", {{"lo", lo}, {"hi", hi}, {"file", file}, {"span", span}, {"kind", kind}, {"name", name}, {"why", why}});
}

Pod CLeq::to_pod() const {
    return Pod::record("CLeq", {{"lo", prism_rtl::to_pod(lo)}, {"hi", prism_rtl::to_pod(hi)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}, {"kind", prism_rtl::to_pod(kind)}, {"name", prism_rtl::to_pod(name)}, {"why", prism_rtl::to_pod(why)}});
}

Result<CLeq> CLeq::from_pod(const Pod& whole) {
    return CLeq{.lo = TRY(prism_rtl::from_pod<Col>(TRY(crate::prelude::field(whole, "lo")))), .hi = TRY(prism_rtl::from_pod<Col>(TRY(crate::prelude::field(whole, "hi")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .kind = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "kind")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .why = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "why"))))};
}


void Col::show(Printer& p) const {
    if (auto c = std::get_if<CBound>(&cases())) p.choice("CBound", {});
    else if (auto c = std::get_if<CUnbound>(&cases())) p.choice("CUnbound", {});
    else if (auto c = std::get_if<CRigid>(&cases())) p.choice("CRigid", {c->a0});
    else if (auto c = std::get_if<CQ>(&cases())) p.choice("CQ", {c->a0});
    else if (auto c = std::get_if<CFlex>(&cases())) p.choice("CFlex", {c->a0});
}

Pod Col::to_pod() const {
    return std::holds_alternative<CBound>(cases()) ? Pod::choice("CBound", {})
        : std::holds_alternative<CUnbound>(cases()) ? Pod::choice("CUnbound", {})
        : std::holds_alternative<CRigid>(cases()) ? Pod::choice("CRigid", {prism_rtl::to_pod(std::get<CRigid>(cases()).a0)})
        : std::holds_alternative<CQ>(cases()) ? Pod::choice("CQ", {prism_rtl::to_pod(std::get<CQ>(cases()).a0)})
        : std::holds_alternative<CFlex>(cases()) ? Pod::choice("CFlex", {prism_rtl::to_pod(std::get<CFlex>(cases()).a0)})
        : Pod();
}

Result<Col> Col::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "CBound" && c->args.size() == 0) return Col(CBound{});
        if (c->ctor == "CUnbound" && c->args.size() == 0) return Col(CUnbound{});
        if (c->ctor == "CRigid" && c->args.size() == 1) return Col(CRigid{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "CQ" && c->args.size() == 1) return Col(CQ{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "CFlex" && c->args.size() == 1) return Col(CFlex{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
    }
    return mismatch<Col>("a Col", p);
}


void Incl::show(Printer& p) const {
    p.record("Incl", {{"sub", sub}, {"sup", sup}, {"file", file}, {"span", span}, {"what", what}, {"forward", forward}});
}

Pod Incl::to_pod() const {
    return Pod::record("Incl", {{"sub", prism_rtl::to_pod(sub)}, {"sup", prism_rtl::to_pod(sup)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}, {"what", prism_rtl::to_pod(what)}, {"forward", prism_rtl::to_pod(forward)}});
}

Result<Incl> Incl::from_pod(const Pod& whole) {
    return Incl{.sub = TRY(prism_rtl::from_pod<Rw>(TRY(crate::prelude::field(whole, "sub")))), .sup = TRY(prism_rtl::from_pod<Rw>(TRY(crate::prelude::field(whole, "sup")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .what = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "what")))), .forward = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "forward"))))};
}


void Rw::show(Printer& p) const {
    p.record("Rw", {{"fams", fams}, {"minus", minus}, {"tail", tail}});
}

Pod Rw::to_pod() const {
    return Pod::record("Rw", {{"fams", prism_rtl::to_pod(fams)}, {"minus", prism_rtl::to_pod(minus)}, {"tail", prism_rtl::to_pod(tail)}});
}

Result<Rw> Rw::from_pod(const Pod& whole) {
    return Rw{.fams = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "fams")))), .minus = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "minus")))), .tail = TRY(prism_rtl::from_pod<Tail>(TRY(crate::prelude::field(whole, "tail"))))};
}


void Scheme::show(Printer& p) const {
    p.record("Scheme", {{"qs", qs}, {"plain_qs", plain_qs}, {"rqs", rqs}, {"cqs", cqs}, {"cjoins", cjoins}, {"bounds", bounds}, {"ty", ty}});
}

Pod Scheme::to_pod() const {
    return Pod::record("Scheme", {{"qs", prism_rtl::to_pod(qs)}, {"plain_qs", prism_rtl::to_pod(plain_qs)}, {"rqs", prism_rtl::to_pod(rqs)}, {"cqs", prism_rtl::to_pod(cqs)}, {"cjoins", prism_rtl::to_pod(cjoins)}, {"bounds", prism_rtl::to_pod(bounds)}, {"ty", prism_rtl::to_pod(ty)}});
}

Result<Scheme> Scheme::from_pod(const Pod& whole) {
    return Scheme{.qs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "qs")))), .plain_qs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "plain_qs")))), .rqs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "rqs")))), .cqs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "cqs")))), .cjoins = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "cjoins")))), .bounds = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "bounds")))), .ty = TRY(prism_rtl::from_pod<Ty>(TRY(crate::prelude::field(whole, "ty"))))};
}


bool St::operator==(const St& o) const { return next == o.next && tys == o.tys && infos == o.infos && rows == o.rows && lacks == o.lacks && wants == o.wants && incls == o.incls && diags == o.diags && level == o.level && file == o.file && color == o.color && color_why == o.color_why && color_flex == o.color_flex && cols == o.cols && cleqs == o.cleqs && col_q == o.col_q && col_up == o.col_up && deferred == o.deferred && binder_at == o.binder_at && row_names == o.row_names && layer_qs == o.layer_qs && field_qs == o.field_qs && recording == o.recording && typed == o.typed && choices == o.choices && size_tys == o.size_tys && local_next == o.local_next && local_ids == o.local_ids; }

void St::show(Printer& p) const {
    p.record("St", {{"next", next}, {"tys", tys}, {"infos", infos}, {"rows", rows}, {"lacks", lacks}, {"wants", wants}, {"incls", incls}, {"diags", diags}, {"level", level}, {"file", file}, {"color", color}, {"color_why", color_why}, {"color_flex", color_flex}, {"cols", cols}, {"cleqs", cleqs}, {"col_q", col_q}, {"col_up", col_up}, {"deferred", deferred}, {"binder_at", binder_at}, {"row_names", row_names}, {"layer_qs", layer_qs}, {"field_qs", field_qs}, {"recording", recording}, {"typed", typed}, {"choices", choices}, {"size_tys", size_tys}, {"local_next", local_next}, {"local_ids", local_ids}});
}

Pod St::to_pod() const {
    return Pod::record("St", {{"next", prism_rtl::to_pod(next)}, {"tys", prism_rtl::to_pod(tys)}, {"infos", prism_rtl::to_pod(infos)}, {"rows", prism_rtl::to_pod(rows)}, {"lacks", prism_rtl::to_pod(lacks)}, {"wants", prism_rtl::to_pod(wants)}, {"incls", prism_rtl::to_pod(incls)}, {"diags", prism_rtl::to_pod(diags)}, {"level", prism_rtl::to_pod(level)}, {"file", prism_rtl::to_pod(file)}, {"color", prism_rtl::to_pod(color)}, {"color_why", prism_rtl::to_pod(color_why)}, {"color_flex", prism_rtl::to_pod(color_flex)}, {"cols", prism_rtl::to_pod(cols)}, {"cleqs", prism_rtl::to_pod(cleqs)}, {"col_q", prism_rtl::to_pod(col_q)}, {"col_up", prism_rtl::to_pod(col_up)}, {"deferred", prism_rtl::to_pod(deferred)}, {"binder_at", prism_rtl::to_pod(binder_at)}, {"row_names", prism_rtl::to_pod(row_names)}, {"layer_qs", prism_rtl::to_pod(layer_qs)}, {"field_qs", prism_rtl::to_pod(field_qs)}, {"recording", prism_rtl::to_pod(recording)}, {"typed", prism_rtl::to_pod(typed)}, {"choices", prism_rtl::to_pod(choices)}, {"size_tys", prism_rtl::to_pod(size_tys)}, {"local_next", prism_rtl::to_pod(local_next)}, {"local_ids", prism_rtl::to_pod(local_ids)}});
}

Result<St> St::from_pod(const Pod& whole) {
    return St{.next = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "next")))), .tys = TRY(prism_rtl::from_pod<Map<Nat, Ty>>(TRY(crate::prelude::field(whole, "tys")))), .infos = TRY(prism_rtl::from_pod<Map<Nat, VInfo>>(TRY(crate::prelude::field(whole, "infos")))), .rows = TRY(prism_rtl::from_pod<Map<Nat, Rw>>(TRY(crate::prelude::field(whole, "rows")))), .lacks = TRY(prism_rtl::from_pod<Map<Nat, Array<Text>>>(TRY(crate::prelude::field(whole, "lacks")))), .wants = TRY(prism_rtl::from_pod<Array<Want>>(TRY(crate::prelude::field(whole, "wants")))), .incls = TRY(prism_rtl::from_pod<Array<Incl>>(TRY(crate::prelude::field(whole, "incls")))), .diags = TRY(prism_rtl::from_pod<Array<crate::check::errors::CDiag>>(TRY(crate::prelude::field(whole, "diags")))), .level = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "level")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .color = TRY(prism_rtl::from_pod<Col>(TRY(crate::prelude::field(whole, "color")))), .color_why = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "color_why")))), .color_flex = TRY(prism_rtl::from_pod<Array<std::tuple<Col, Text, crate::syntax::Range>>>(TRY(crate::prelude::field(whole, "color_flex")))), .cols = TRY(prism_rtl::from_pod<Map<Nat, Col>>(TRY(crate::prelude::field(whole, "cols")))), .cleqs = TRY(prism_rtl::from_pod<Array<CLeq>>(TRY(crate::prelude::field(whole, "cleqs")))), .col_q = TRY(prism_rtl::from_pod<Map<Nat, Text>>(TRY(crate::prelude::field(whole, "col_q")))), .col_up = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "col_up")))), .deferred = TRY(prism_rtl::from_pod<Array<std::tuple<Ty, Ty, crate::syntax::Range>>>(TRY(crate::prelude::field(whole, "deferred")))), .binder_at = TRY(prism_rtl::from_pod<Map<Nat, crate::syntax::Range>>(TRY(crate::prelude::field(whole, "binder_at")))), .row_names = TRY(prism_rtl::from_pod<Map<Nat, Text>>(TRY(crate::prelude::field(whole, "row_names")))), .layer_qs = TRY(prism_rtl::from_pod<Array<std::tuple<Ty, crate::syntax::Range, Text>>>(TRY(crate::prelude::field(whole, "layer_qs")))), .field_qs = TRY(prism_rtl::from_pod<Array<crate::check::types::unify::FieldQ>>(TRY(crate::prelude::field(whole, "field_qs")))), .recording = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "recording")))), .typed = TRY(prism_rtl::from_pod<crate::check::typed::TProgram>(TRY(crate::prelude::field(whole, "typed")))), .choices = TRY(prism_rtl::from_pod<Map<Text, Array<Text>>>(TRY(crate::prelude::field(whole, "choices")))), .size_tys = TRY(prism_rtl::from_pod<Map<Text, Ty>>(TRY(crate::prelude::field(whole, "size_tys")))), .local_next = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "local_next")))), .local_ids = TRY(prism_rtl::from_pod<Map<Text, Nat>>(TRY(crate::prelude::field(whole, "local_ids"))))};
}


void Tail::show(Printer& p) const {
    if (auto c = std::get_if<TlClosed>(&cases())) p.choice("TlClosed", {});
    else if (auto c = std::get_if<TlFlex>(&cases())) p.choice("TlFlex", {c->a0});
    else if (auto c = std::get_if<TlRigid>(&cases())) p.choice("TlRigid", {c->a0});
    else if (auto c = std::get_if<TlQ>(&cases())) p.choice("TlQ", {c->a0});
}

Pod Tail::to_pod() const {
    return std::holds_alternative<TlClosed>(cases()) ? Pod::choice("TlClosed", {})
        : std::holds_alternative<TlFlex>(cases()) ? Pod::choice("TlFlex", {prism_rtl::to_pod(std::get<TlFlex>(cases()).a0)})
        : std::holds_alternative<TlRigid>(cases()) ? Pod::choice("TlRigid", {prism_rtl::to_pod(std::get<TlRigid>(cases()).a0)})
        : std::holds_alternative<TlQ>(cases()) ? Pod::choice("TlQ", {prism_rtl::to_pod(std::get<TlQ>(cases()).a0)})
        : Pod();
}

Result<Tail> Tail::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TlClosed" && c->args.size() == 0) return Tail(TlClosed{});
        if (c->ctor == "TlFlex" && c->args.size() == 1) return Tail(TlFlex{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "TlRigid" && c->args.size() == 1) return Tail(TlRigid{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TlQ" && c->args.size() == 1) return Tail(TlQ{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Tail>("a Tail", p);
}


bool Ty::TyCon::operator==(const TyCon& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ty::TyFn::operator==(const TyFn& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool Ty::TyTuple::operator==(const TyTuple& o) const { return a0 == o.a0; }

bool Ty::TyArray::operator==(const TyArray& o) const { return a0 == o.a0; }

bool Ty::TyMap::operator==(const TyMap& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ty::TySig::operator==(const TySig& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ty::TyAt::operator==(const TyAt& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ty::TyElem::operator==(const TyElem& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ty::TyAssoc::operator==(const TyAssoc& o) const { return a0 == o.a0 && a1 == o.a1; }

void Ty::show(Printer& p) const {
    if (auto c = std::get_if<TyFlex>(&cases())) p.choice("TyFlex", {c->a0});
    else if (auto c = std::get_if<TyRigid>(&cases())) p.choice("TyRigid", {c->a0});
    else if (auto c = std::get_if<TyQ>(&cases())) p.choice("TyQ", {c->a0});
    else if (auto c = std::get_if<TyCon>(&cases())) p.choice("TyCon", {c->a0, c->a1});
    else if (auto c = std::get_if<TyFn>(&cases())) p.choice("TyFn", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<TyTuple>(&cases())) p.choice("TyTuple", {c->a0});
    else if (auto c = std::get_if<TyArray>(&cases())) p.choice("TyArray", {c->a0});
    else if (auto c = std::get_if<TyMap>(&cases())) p.choice("TyMap", {c->a0, c->a1});
    else if (auto c = std::get_if<TySig>(&cases())) p.choice("TySig", {c->a0, c->a1});
    else if (auto c = std::get_if<TyAt>(&cases())) p.choice("TyAt", {c->a0, c->a1});
    else if (auto c = std::get_if<TyElem>(&cases())) p.choice("TyElem", {c->a0, c->a1});
    else if (auto c = std::get_if<TyElemAny>(&cases())) p.choice("TyElemAny", {c->a0});
    else if (auto c = std::get_if<TyAssoc>(&cases())) p.choice("TyAssoc", {c->a0, c->a1});
    else if (auto c = std::get_if<TyAny>(&cases())) p.choice("TyAny", {c->a0});
    else if (auto c = std::get_if<TyErr>(&cases())) p.choice("TyErr", {});
}

Pod Ty::to_pod() const {
    return std::holds_alternative<TyFlex>(cases()) ? Pod::choice("TyFlex", {prism_rtl::to_pod(std::get<TyFlex>(cases()).a0)})
        : std::holds_alternative<TyRigid>(cases()) ? Pod::choice("TyRigid", {prism_rtl::to_pod(std::get<TyRigid>(cases()).a0)})
        : std::holds_alternative<TyQ>(cases()) ? Pod::choice("TyQ", {prism_rtl::to_pod(std::get<TyQ>(cases()).a0)})
        : std::holds_alternative<TyCon>(cases()) ? Pod::choice("TyCon", {prism_rtl::to_pod(std::get<TyCon>(cases()).a0), prism_rtl::to_pod(std::get<TyCon>(cases()).a1)})
        : std::holds_alternative<TyFn>(cases()) ? Pod::choice("TyFn", {prism_rtl::to_pod(std::get<TyFn>(cases()).a0), prism_rtl::to_pod(std::get<TyFn>(cases()).a1), prism_rtl::to_pod(std::get<TyFn>(cases()).a2)})
        : std::holds_alternative<TyTuple>(cases()) ? Pod::choice("TyTuple", {prism_rtl::to_pod(std::get<TyTuple>(cases()).a0)})
        : std::holds_alternative<TyArray>(cases()) ? Pod::choice("TyArray", {prism_rtl::to_pod(std::get<TyArray>(cases()).a0)})
        : std::holds_alternative<TyMap>(cases()) ? Pod::choice("TyMap", {prism_rtl::to_pod(std::get<TyMap>(cases()).a0), prism_rtl::to_pod(std::get<TyMap>(cases()).a1)})
        : std::holds_alternative<TySig>(cases()) ? Pod::choice("TySig", {prism_rtl::to_pod(std::get<TySig>(cases()).a0), prism_rtl::to_pod(std::get<TySig>(cases()).a1)})
        : std::holds_alternative<TyAt>(cases()) ? Pod::choice("TyAt", {prism_rtl::to_pod(std::get<TyAt>(cases()).a0), prism_rtl::to_pod(std::get<TyAt>(cases()).a1)})
        : std::holds_alternative<TyElem>(cases()) ? Pod::choice("TyElem", {prism_rtl::to_pod(std::get<TyElem>(cases()).a0), prism_rtl::to_pod(std::get<TyElem>(cases()).a1)})
        : std::holds_alternative<TyElemAny>(cases()) ? Pod::choice("TyElemAny", {prism_rtl::to_pod(std::get<TyElemAny>(cases()).a0)})
        : std::holds_alternative<TyAssoc>(cases()) ? Pod::choice("TyAssoc", {prism_rtl::to_pod(std::get<TyAssoc>(cases()).a0), prism_rtl::to_pod(std::get<TyAssoc>(cases()).a1)})
        : std::holds_alternative<TyAny>(cases()) ? Pod::choice("TyAny", {prism_rtl::to_pod(std::get<TyAny>(cases()).a0)})
        : std::holds_alternative<TyErr>(cases()) ? Pod::choice("TyErr", {})
        : Pod();
}

Result<Ty> Ty::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TyFlex" && c->args.size() == 1) return Ty(TyFlex{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "TyRigid" && c->args.size() == 1) return Ty(TyRigid{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TyQ" && c->args.size() == 1) return Ty(TyQ{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TyCon" && c->args.size() == 2) return Ty(TyCon{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Ty>>(c->args[1]))});
        if (c->ctor == "TyFn" && c->args.size() == 3) return Ty(TyFn{TRY(prism_rtl::from_pod<Col>(c->args[0])), TRY(prism_rtl::from_pod<Array<Ty>>(c->args[1])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[2]))});
        if (c->ctor == "TyTuple" && c->args.size() == 1) return Ty(TyTuple{TRY(prism_rtl::from_pod<Array<Ty>>(c->args[0]))});
        if (c->ctor == "TyArray" && c->args.size() == 1) return Ty(TyArray{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[0]))});
        if (c->ctor == "TyMap" && c->args.size() == 2) return Ty(TyMap{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[1]))});
        if (c->ctor == "TySig" && c->args.size() == 2) return Ty(TySig{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[1]))});
        if (c->ctor == "TyAt" && c->args.size() == 2) return Ty(TyAt{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[0])), TRY(prism_rtl::from_pod<Rw>(c->args[1]))});
        if (c->ctor == "TyElem" && c->args.size() == 2) return Ty(TyElem{TRY(prism_rtl::from_pod<Rw>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[1]))});
        if (c->ctor == "TyElemAny" && c->args.size() == 1) return Ty(TyElemAny{TRY(prism_rtl::from_pod<Rw>(c->args[0]))});
        if (c->ctor == "TyAssoc" && c->args.size() == 2) return Ty(TyAssoc{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ty>>(c->args[1]))});
        if (c->ctor == "TyAny" && c->args.size() == 1) return Ty(TyAny{TRY(prism_rtl::from_pod<Array<Text>>(c->args[0]))});
        if (c->ctor == "TyErr" && c->args.size() == 0) return Ty(TyErr{});
    }
    return mismatch<Ty>("a Ty", p);
}


void VInfo::show(Printer& p) const {
    p.record("VInfo", {{"plain", plain}, {"level", level}, {"name", name}});
}

Pod VInfo::to_pod() const {
    return Pod::record("VInfo", {{"plain", prism_rtl::to_pod(plain)}, {"level", prism_rtl::to_pod(level)}, {"name", prism_rtl::to_pod(name)}});
}

Result<VInfo> VInfo::from_pod(const Pod& whole) {
    return VInfo{.plain = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "plain")))), .level = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "level")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name"))))};
}


void Want::show(Printer& p) const {
    p.record("Want", {{"cls", cls}, {"ty", ty}, {"file", file}, {"span", span}, {"level", level}});
}

Pod Want::to_pod() const {
    return Pod::record("Want", {{"cls", prism_rtl::to_pod(cls)}, {"ty", prism_rtl::to_pod(ty)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}, {"level", prism_rtl::to_pod(level)}});
}

Result<Want> Want::from_pod(const Pod& whole) {
    return Want{.cls = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "cls")))), .ty = TRY(prism_rtl::from_pod<Ty>(TRY(crate::prelude::field(whole, "ty")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .level = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "level"))))};
}


/// NewSt: fn Nat -> St
St new_st(const Nat& file_p0) {
    return St{.next = Nat(0u), .tys = Map<Nat, Ty>{}, .infos = Map<Nat, VInfo>{}, .rows = Map<Nat, Rw>{}, .lacks = Map<Nat, Array<Text>>{}, .wants = Array<Want>{}, .incls = Array<Incl>{}, .diags = Array<crate::check::errors::CDiag>{}, .level = Nat(0u), .file = file_p0, .color = Col(Col::CBound{}), .color_why = Text::lit(""), .color_flex = Array<std::tuple<Col, Text, crate::syntax::Range>>{}, .cols = Map<Nat, Col>{}, .cleqs = Array<CLeq>{}, .col_q = Map<Nat, Text>{}, .col_up = Map<Text, Text>{}, .deferred = Array<std::tuple<Ty, Ty, crate::syntax::Range>>{}, .binder_at = Map<Nat, crate::syntax::Range>{}, .row_names = Map<Nat, Text>{}, .layer_qs = Array<std::tuple<Ty, crate::syntax::Range, Text>>{}, .field_qs = Array<crate::check::types::unify::FieldQ>{}, .recording = false, .typed = crate::check::typed::empty_typed(), .choices = Map<Text, Array<Text>>{}, .size_tys = Map<Text, Ty>{}, .local_next = Nat(0u), .local_ids = Map<Text, Nat>{}};
}


/// Closed: fn [Text] -> Rw
Rw closed(const Array<Text>& fs_p0) {
    return Rw{.fams = sort_texts(fs_p0), .minus = Array<Text>{}, .tail = Tail(Tail::TlClosed{})};
}


/// let emptyRow
Rw empty_row() {
    return Rw{.fams = Array<Text>{}, .minus = Array<Text>{}, .tail = Tail(Tail::TlClosed{})};
}


/// let tInt
Ty t_int() {
    return Ty(Ty::TyCon{Text::lit("Int"), Array<Ty>{}});
}


/// let tNat
Ty t_nat() {
    return Ty(Ty::TyCon{Text::lit("Nat"), Array<Ty>{}});
}


/// let tText
Ty t_text() {
    return Ty(Ty::TyCon{Text::lit("Text"), Array<Ty>{}});
}


/// let tBool
Ty t_bool() {
    return Ty(Ty::TyCon{Text::lit("Bool"), Array<Ty>{}});
}


/// let tUnit
Ty t_unit() {
    return Ty(Ty::TyCon{Text::lit("unit"), Array<Ty>{}});
}


/// let tChar
Ty t_char() {
    return Ty(Ty::TyCon{Text::lit("Char"), Array<Ty>{}});
}


/// let tFloat
Ty t_float() {
    return Ty(Ty::TyCon{Text::lit("Float"), Array<Ty>{}});
}


/// HasText: fn [Text], Text -> Bool
bool has_text(const Array<Text>& xs_p0, const Text& x_p1) {
    return fold(xs_p0, false, [&](const bool& seen_p2, const Text& y_p3) { return prism_rtl::deref(seen_p2) || (y_p3 == x_p1); });
}


/// HasNat: fn [Nat], Nat -> Bool
bool has_nat(const Array<Nat>& xs_p0, const Nat& x_p1) {
    return fold(xs_p0, false, [&](const bool& seen_p2, const Nat& y_p3) { return prism_rtl::deref(seen_p2) || (y_p3 == x_p1); });
}


/// AddText: fn [Text], Text -> [Text]
Array<Text> add_text(const Array<Text>& xs_p0, const Text& x_p1) {
    return has_text(xs_p0, x_p1) ? xs_p0 : crate::prelude::push(xs_p0, x_p1);
}


/// UnionTexts: fn [Text], [Text] -> [Text]
Array<Text> union_texts(const Array<Text>& xs_p0, const Array<Text>& ys_p1) {
    return fold(ys_p1, xs_p0, [&](const Array<Text>& acc_p2, const Text& y_p3) { return add_text(acc_p2, y_p3); });
}


/// MinusTexts: fn [Text], [Text] -> [Text]
Array<Text> minus_texts(const Array<Text>& xs_p0, const Array<Text>& ys_p1) {
    return filter(xs_p0, [&](const Text& x_p2) { return !has_text(ys_p1, x_p2); });
}


/// InterTexts: fn [Text], [Text] -> [Text]
Array<Text> inter_texts(const Array<Text>& xs_p0, const Array<Text>& ys_p1) {
    return filter(xs_p0, [&](const Text& x_p2) { return has_text(ys_p1, x_p2); });
}


/// AddNat: fn [Nat], Nat -> [Nat]
Array<Nat> add_nat(const Array<Nat>& xs_p0, const Nat& x_p1) {
    return has_nat(xs_p0, x_p1) ? xs_p0 : crate::prelude::push(xs_p0, x_p1);
}


/// SortTexts: fn [Text] -> [Text]
Array<Text> sort_texts(const Array<Text>& xs_p0) {
    return fold(xs_p0, Array<Text>{}, [&](const Array<Text>& acc_p1, const Text& x_p2) {
        return has_text(acc_p1, x_p2)
            ? acc_p1
            : append(crate::prelude::push(filter(acc_p1, [&](const Text& y_p3) { return y_p3 < x_p2; }), x_p2), filter(acc_p1, [&](const Text& y_p4) { return !(y_p4 < x_p2); }));
    });
}


/// BareName: fn Text -> Text
Text bare_name(const Text& q_p0) {
    return or_(crate::syntax::lexer::chars::last(split_on(q_p0, Text::lit("."))), q_p0);
}


/// FreshVar: fn St, Bool, Text -> ((Ty, St))
std::tuple<Ty, St> fresh_var(const St& st_p0, const bool& plain_p1, const Text& name_p2) {
    auto n_p3 = st_p0.next;
    auto st2_p4 = ({
        St this_ = st_p0;
        this_.next = this_.next + Nat(1u);
        this_.infos = insert(this_.infos, n_p3, VInfo{.plain = plain_p1, .level = this_.level, .name = name_p2});
        (std::move(this_));
    });
    return std::tuple{Ty(Ty::TyFlex{n_p3}), st2_p4};
}


/// FreshCol: fn St -> ((Col, St))
std::tuple<Col, St> fresh_col(const St& st_p0) {
    auto n_p1 = st_p0.next;
    auto st2_p2 = ({
        St this_ = st_p0;
        this_.next = this_.next + Nat(1u);
        this_.infos = insert(this_.infos, n_p1, VInfo{.plain = false, .level = this_.level, .name = Text::lit("")});
        (std::move(this_));
    });
    return std::tuple{Col(Col::CFlex{n_p1}), st2_p2};
}


/// StackOf: unbounded fn St, Ty -> Text
Text stack_of(const St& st_p0, const Ty& t_p1) {
    auto&& _m = crate::check::types::recording::walk(st_p0, t_p1);
    if (prism_rtl::is<Ty::TySig>(_m)) {
        auto&& s_p2 = prism_rtl::as<Ty::TySig>(_m).a0;
        auto&& i_p3 = prism_rtl::as<Ty::TySig>(_m).a1;
        return prism_rtl::cat(s_p2, stack_of(st_p0, prism_rtl::deref(i_p3)));
    }
    if (prism_rtl::is<Ty::TyAt>(_m)) {
        auto&& i_p4 = prism_rtl::as<Ty::TyAt>(_m).a0;
        return prism_rtl::cat("@", stack_of(st_p0, prism_rtl::deref(i_p4)));
    }
    {
        return Text::lit("");
    }
}


prism_rtl::Turn<Text> StackOf::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0_1 = st_p0;
    auto t_p1_2 = t_p1;
    return call_then(crate::check::types::recording::start_walk(st_p0_1, t_p1_2), [=](Ty walk_8203) {
        return ({
            prism_rtl::is<Ty::TySig>(walk_8203) ? ({
            auto&& s_p2 = prism_rtl::as<Ty::TySig>(walk_8203).a0;
            auto&& i_p3 = prism_rtl::as<Ty::TySig>(walk_8203).a1;
            call_then(start_stack_of(st_p0_1, prism_rtl::deref(i_p3)), [=](Text stack_of_8236) { return prism_rtl::finished(prism_rtl::cat(s_p2, stack_of_8236)); });
        })
            : prism_rtl::is<Ty::TyAt>(walk_8203) ? ({
            auto&& i_p4 = prism_rtl::as<Ty::TyAt>(walk_8203).a0;
            call_then(start_stack_of(st_p0_1, prism_rtl::deref(i_p4)), [=](Text stack_of_8275) { return prism_rtl::finished(prism_rtl::cat("@", stack_of_8275)); });
        })
            : prism_rtl::finished(Text::lit(""));
        });
    });
}


/// `Start StackOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_stack_of(St st_p0, Ty t_p1) {
    return prism_rtl::make_rc<StackOf>(st_p0, t_p1);
}


/// HeadSigil: unbounded fn St, Ty -> Text
Text head_sigil(const St& st_p0, const Ty& t_p1) {
    auto&& _m = crate::check::types::recording::walk(st_p0, t_p1);
    if (prism_rtl::is<Ty::TySig>(_m)) {
        auto&& s_p2 = prism_rtl::as<Ty::TySig>(_m).a0;
        return s_p2;
    }
    if (prism_rtl::is<Ty::TyAt>(_m)) {
        return Text::lit("@");
    }
    {
        return Text::lit("");
    }
}


prism_rtl::Turn<Text> HeadSigil::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0_1 = st_p0;
    auto t_p1_2 = t_p1;
    return call_then(crate::check::types::recording::start_walk(st_p0_1, t_p1_2), [=](Ty walk_8453) {
        return ({
            prism_rtl::is<Ty::TySig>(walk_8453) ? ({
            auto&& s_p2 = prism_rtl::as<Ty::TySig>(walk_8453).a0;
            prism_rtl::finished(s_p2);
        })
            : prism_rtl::is<Ty::TyAt>(walk_8453) ? prism_rtl::finished(Text::lit("@"))
            : prism_rtl::finished(Text::lit(""));
        });
    });
}


/// `Start HeadSigil, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_head_sigil(St st_p0, Ty t_p1) {
    return prism_rtl::make_rc<HeadSigil>(st_p0, t_p1);
}


/// IsFlexVar: unbounded fn St, Ty -> Bool
bool is_flex_var(const St& st_p0, const Ty& t_p1) {
    auto&& _m = crate::check::types::recording::walk(st_p0, t_p1);
    if (prism_rtl::is<Ty::TyFlex>(_m)) {
        return true;
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsFlexVar::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0_1 = st_p0;
    auto t_p1_2 = t_p1;
    return call_then(crate::check::types::recording::start_walk(st_p0_1, t_p1_2), [=](Ty walk_8602) {
        return ({
            prism_rtl::is<Ty::TyFlex>(walk_8602) ? prism_rtl::finished(true)
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsFlexVar, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_flex_var(St st_p0, Ty t_p1) {
    return prism_rtl::make_rc<IsFlexVar>(st_p0, t_p1);
}


/// IsFreeHeaded: unbounded fn St, Ty -> Bool
bool is_free_headed(const St& st_p0, const Ty& t_p1) {
    auto&& _m = crate::check::types::recording::walk(st_p0, t_p1);
    if (prism_rtl::is<Ty::TyFlex>(_m)) {
        auto&& n_p2 = prism_rtl::as<Ty::TyFlex>(_m).a0;
        return !prism_rtl::deref(crate::check::types::recording::info_of(st_p0, n_p2)).plain;
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsFreeHeaded::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0_1 = st_p0;
    auto t_p1_2 = t_p1;
    return call_then(crate::check::types::recording::start_walk(st_p0_1, t_p1_2), [=](Ty walk_8810) {
        return ({
            prism_rtl::is<Ty::TyFlex>(walk_8810) ? ({
            auto&& n_p2 = prism_rtl::as<Ty::TyFlex>(walk_8810).a0;
            prism_rtl::finished(!prism_rtl::deref(crate::check::types::recording::info_of(st_p0_1, n_p2)).plain);
        })
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsFreeHeaded, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_free_headed(St st_p0, Ty t_p1) {
    return prism_rtl::make_rc<IsFreeHeaded>(st_p0, t_p1);
}


/// WithMarks: fn Text, Ty, Rw -> Ty
Ty with_marks(const Text& marks_p0, const Ty& t_p1, const Rw& rw_p2) {
    return fold(reverse2(crate::syntax::lexer::chars::fold_chars(marks_p0, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto acc_p3 = p0;
                auto c_p4 = p1;
                (prism_rtl::finished(crate::prelude::push(acc_p3, c_p4)));
            });
        });
    })))), t_p1, [&](const Ty& acc_p5, const Text& m_p6) {
        return m_p6 == Text::lit("@")
            ? Ty(Ty::TyAt{prism_rtl::rc(acc_p5), rw_p2})
            : Ty(Ty::TySig{m_p6, prism_rtl::rc(acc_p5)});
    });
}


/// Reverse2: fn [Text] -> [Text]
Array<Text> reverse2(const Array<Text>& xs_p0) {
    return fold(xs_p0, Array<Text>{}, [&](const Array<Text>& acc_p1, const Text& x_p2) { return append(Array(std::vector{x_p2}), acc_p1); });
}


/// ShowTy: unbounded fn St, Ty -> Text
Text show_ty(const St& st_p0, const Ty& t_p1) {
    return show_ty_in(st_p0, crate::check::types::recording::zonk(st_p0, t_p1), false);
}


prism_rtl::Turn<Text> ShowTy::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0_1 = st_p0;
    auto t_p1_2 = t_p1;
    return call_then(crate::check::types::recording::start_zonk(st_p0_1, t_p1_2), [=](Ty zonk_9536) { return prism_rtl::more(prism_rtl::rc(ShowTyIn(st_p0_1, zonk_9536, false))); });
}


/// `Start ShowTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_ty(St st_p0, Ty t_p1) {
    return prism_rtl::make_rc<ShowTy>(st_p0, t_p1);
}


/// ShowTyIn: unbounded fn St, Ty, Bool -> Text
Text show_ty_in(const St& st_p0, const Ty& t_p1, const bool& nested_p2) {
    if (prism_rtl::is<Ty::TyFlex>(t_p1)) {
        auto&& n_p3 = prism_rtl::as<Ty::TyFlex>(t_p1).a0;
        return prism_rtl::cat("t", n_p3);
    }
    if (prism_rtl::is<Ty::TyRigid>(t_p1)) {
        auto&& n_p4 = prism_rtl::as<Ty::TyRigid>(t_p1).a0;
        return n_p4;
    }
    if (prism_rtl::is<Ty::TyQ>(t_p1)) {
        auto&& n_p5 = prism_rtl::as<Ty::TyQ>(t_p1).a0;
        return n_p5;
    }
    if (prism_rtl::is<Ty::TyCon>(t_p1)) {
        auto&& n_p6 = prism_rtl::as<Ty::TyCon>(t_p1).a0;
        auto&& m9698_3_1 = prism_rtl::as<Ty::TyCon>(t_p1).a1;
        if (m9698_3_1.size() == 0u) {
            return bare_name(n_p6);
        }
    }
    if (prism_rtl::is<Ty::TyCon>(t_p1)) {
        auto&& n_p7 = prism_rtl::as<Ty::TyCon>(t_p1).a0;
        auto&& args_p8 = prism_rtl::as<Ty::TyCon>(t_p1).a1;
        auto inner_p9 = prism_rtl::cat(bare_name(n_p7), concat(run_to_end(each_job(args_p8, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](Ty p0) {
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto a_pa = p0;
                    call_then(start_show_ty_in(st_p0_1_2, a_pa, true), [=](Text show_ty_in_9868) { return prism_rtl::finished(prism_rtl::cat(" ", show_ty_in_9868)); });
                });
            }));
            });
        })));
        })))));
        return nested_p2 ? prism_rtl::cat("(", inner_p9, ")") : inner_p9;
    }
    if (prism_rtl::is<Ty::TyFn>(t_p1)) {
        auto&& c_pb = prism_rtl::as<Ty::TyFn>(t_p1).a0;
        auto&& ps_pc = prism_rtl::as<Ty::TyFn>(t_p1).a1;
        auto&& res_pd = prism_rtl::as<Ty::TyFn>(t_p1).a2;
        auto inner_pe = prism_rtl::cat(show_col(c_pb), "fn ", crate::syntax::lexer::chars::join(run_to_end(each_job(ps_pc, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](Ty p0) {
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto p_pf = p0;
                    (prism_rtl::more(prism_rtl::rc(ShowTyIn(st_p0_1_2, p_pf, false))));
                });
            }));
            });
        })));
        }))), Text::lit(", ")), " -> ", show_ty_in(st_p0, prism_rtl::deref(prism_rtl::deref(res_pd)), false));
        return nested_p2 ? prism_rtl::cat("(", inner_pe, ")") : inner_pe;
    }
    if (prism_rtl::is<Ty::TyTuple>(t_p1)) {
        auto&& ts_pg = prism_rtl::as<Ty::TyTuple>(t_p1).a0;
        return prism_rtl::cat("((", crate::syntax::lexer::chars::join(run_to_end(each_job(ts_pg, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](Ty p0) {
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto a_ph = p0;
                    (prism_rtl::more(prism_rtl::rc(ShowTyIn(st_p0_1_2, a_ph, false))));
                });
            }));
            });
        })));
        }))), Text::lit(", ")), "))");
    }
    if (prism_rtl::is<Ty::TyArray>(t_p1)) {
        auto&& e_pi = prism_rtl::as<Ty::TyArray>(t_p1).a0;
        auto inner_pj = show_ty_in(st_p0, prism_rtl::deref(prism_rtl::deref(e_pi)), false);
        return crate::syntax::lexer::chars::has_prefix(inner_pj, Text::lit("["))
            ? prism_rtl::cat("[ ", inner_pj, " ]")
            : prism_rtl::cat("[", inner_pj, "]");
    }
    if (prism_rtl::is<Ty::TyMap>(t_p1)) {
        auto&& k_pk = prism_rtl::as<Ty::TyMap>(t_p1).a0;
        auto&& v_pl = prism_rtl::as<Ty::TyMap>(t_p1).a1;
        auto inner_pm = prism_rtl::cat(show_ty_in(st_p0, prism_rtl::deref(prism_rtl::deref(k_pk)), true), " ==> ", show_ty_in(st_p0, prism_rtl::deref(prism_rtl::deref(v_pl)), true));
        return nested_p2 ? prism_rtl::cat("(", inner_pm, ")") : inner_pm;
    }
    if (prism_rtl::is<Ty::TySig>(t_p1)) {
        auto&& s_pn = prism_rtl::as<Ty::TySig>(t_p1).a0;
        auto&& i_po = prism_rtl::as<Ty::TySig>(t_p1).a1;
        return prism_rtl::cat(s_pn, show_ty_in(st_p0, prism_rtl::deref(prism_rtl::deref(i_po)), true));
    }
    if (prism_rtl::is<Ty::TyAt>(t_p1)) {
        auto&& i_pp = prism_rtl::as<Ty::TyAt>(t_p1).a0;
        auto&& rw_pq = prism_rtl::as<Ty::TyAt>(t_p1).a1;
        return prism_rtl::cat("@", show_ty_in(st_p0, prism_rtl::deref(prism_rtl::deref(i_pp)), true));
    }
    if (prism_rtl::is<Ty::TyElem>(t_p1)) {
        auto&& rw_pr = prism_rtl::as<Ty::TyElem>(t_p1).a0;
        auto&& o_ps = prism_rtl::as<Ty::TyElem>(t_p1).a1;
        auto inner_pt = prism_rtl::cat("Element ", show_row_in(rw_pr, true), " ", show_ty_in(st_p0, prism_rtl::deref(prism_rtl::deref(o_ps)), true));
        return nested_p2 ? prism_rtl::cat("(", inner_pt, ")") : inner_pt;
    }
    if (prism_rtl::is<Ty::TyElemAny>(t_p1)) {
        auto&& rw_pu = prism_rtl::as<Ty::TyElemAny>(t_p1).a0;
        return nested_p2
            ? prism_rtl::cat("(Elem ", show_row_in(rw_pu, true), ")")
            : prism_rtl::cat("Elem ", show_row_in(rw_pu, true));
    }
    if (prism_rtl::is<Ty::TyAssoc>(t_p1)) {
        auto&& n_pv = prism_rtl::as<Ty::TyAssoc>(t_p1).a0;
        auto&& a_p10 = prism_rtl::as<Ty::TyAssoc>(t_p1).a1;
        return nested_p2
            ? prism_rtl::cat("(", n_pv, " ", show_ty_in(st_p0, prism_rtl::deref(prism_rtl::deref(a_p10)), true), ")")
            : prism_rtl::cat(n_pv, " ", show_ty_in(st_p0, prism_rtl::deref(prism_rtl::deref(a_p10)), true));
    }
    if (prism_rtl::is<Ty::TyAny>(t_p1)) {
        auto&& ts_p11 = prism_rtl::as<Ty::TyAny>(t_p1).a0;
        return prism_rtl::cat("any ", crate::syntax::lexer::chars::join(each(ts_p11, [&](const Text& x_p12) { return prism_rtl::cat("^", bare_name(x_p12)); }), Text::lit(" ")));
    }
    if (prism_rtl::is<Ty::TyErr>(t_p1)) {
        return Text::lit("?");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> ShowTyIn::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    const auto& nested_p2 = this->nested_p2;
    return ({
        prism_rtl::is<Ty::TyFlex>(t_p1) ? ({
        auto&& n_p3 = prism_rtl::as<Ty::TyFlex>(t_p1).a0;
        prism_rtl::finished(prism_rtl::cat("t", n_p3));
    })
        : prism_rtl::is<Ty::TyRigid>(t_p1) ? ({
        auto&& n_p4 = prism_rtl::as<Ty::TyRigid>(t_p1).a0;
        prism_rtl::finished(n_p4);
    })
        : prism_rtl::is<Ty::TyQ>(t_p1) ? ({
        auto&& n_p5 = prism_rtl::as<Ty::TyQ>(t_p1).a0;
        prism_rtl::finished(n_p5);
    })
        : prism_rtl::is<Ty::TyCon>(t_p1) && ({
        auto&& n_p6 = prism_rtl::as<Ty::TyCon>(t_p1).a0;
        auto&& m9698_3_1 = prism_rtl::as<Ty::TyCon>(t_p1).a1;
        (m9698_3_1.size() == 0u);
    }) ? ({
        auto&& n_p6 = prism_rtl::as<Ty::TyCon>(t_p1).a0;
        auto&& m9698_3_1 = prism_rtl::as<Ty::TyCon>(t_p1).a1;
        prism_rtl::finished(bare_name(n_p6));
    })
        : prism_rtl::is<Ty::TyCon>(t_p1) ? ({
        auto&& n_p7 = prism_rtl::as<Ty::TyCon>(t_p1).a0;
        auto&& args_p8 = prism_rtl::as<Ty::TyCon>(t_p1).a1;
        ({
        auto args_p8_1 = args_p8;
        auto n_p7_2 = n_p7;
        auto nested_p2_3 = prism_rtl::deref(nested_p2);
        auto st_p0_4 = st_p0;
        call_value(each_job(args_p8_1, ({
        auto st_p0_4_5 = st_p0_4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=, st_p0_4_5 = std::move(st_p0_4_5)](Ty p0) {
        return ({
            auto st_p0_4_5_5 = st_p0_4_5;
            entered(once_job([=, st_p0_4_5_5 = std::move(st_p0_4_5_5)]() {
            return ({
                auto a_pa = p0;
                call_then(start_show_ty_in(st_p0_4_5_5, a_pa, true), [=](Text show_ty_in_9868) { return prism_rtl::finished(prism_rtl::cat(" ", show_ty_in_9868)); });
            });
        }));
        });
    })));
    })), [=, n_p7_2 = std::move(n_p7_2), nested_p2_3 = std::move(nested_p2_3)](Array<Text> each_9849) {
        return ({
            auto inner_p9 = prism_rtl::cat(bare_name(n_p7_2), concat(each_9849));
            nested_p2_3
            ? prism_rtl::finished(prism_rtl::cat("(", inner_p9, ")"))
            : prism_rtl::finished(inner_p9);
        });
    });
    });
    })
        : prism_rtl::is<Ty::TyFn>(t_p1) ? ({
        auto&& c_pb = prism_rtl::as<Ty::TyFn>(t_p1).a0;
        auto&& ps_pc = prism_rtl::as<Ty::TyFn>(t_p1).a1;
        auto&& res_pd = prism_rtl::as<Ty::TyFn>(t_p1).a2;
        ({
        auto c_pb_1 = c_pb;
        auto nested_p2_2 = prism_rtl::deref(nested_p2);
        auto ps_pc_3 = ps_pc;
        auto res_pd_4 = prism_rtl::deref(prism_rtl::deref(res_pd));
        auto st_p0_5 = st_p0;
        call_value(each_job(ps_pc_3, ({
        auto st_p0_5_6 = st_p0_5;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=, st_p0_5_6 = std::move(st_p0_5_6)](Ty p0) {
        return ({
            auto st_p0_5_6_6 = st_p0_5_6;
            entered(once_job([=, st_p0_5_6_6 = std::move(st_p0_5_6_6)]() {
            return ({
                auto p_pf = p0;
                (prism_rtl::more(prism_rtl::rc(ShowTyIn(st_p0_5_6_6, p_pf, false))));
            });
        }));
        });
    })));
    })), [=, c_pb_1 = std::move(c_pb_1), nested_p2_2 = std::move(nested_p2_2), res_pd_4 = std::move(res_pd_4)](Array<Text> each_10000) {
        return call_then(start_show_ty_in(st_p0_5, res_pd_4, false), [=](Text show_ty_in_10048) {
            return ({
                auto inner_pe = prism_rtl::cat(show_col(c_pb_1), "fn ", crate::syntax::lexer::chars::join(each_10000, Text::lit(", ")), " -> ", show_ty_in_10048);
                nested_p2_2
                ? prism_rtl::finished(prism_rtl::cat("(", inner_pe, ")"))
                : prism_rtl::finished(inner_pe);
            });
        });
    });
    });
    })
        : prism_rtl::is<Ty::TyTuple>(t_p1) ? ({
        auto&& ts_pg = prism_rtl::as<Ty::TyTuple>(t_p1).a0;
        ({
        auto st_p0_1 = st_p0;
        auto ts_pg_2 = ts_pg;
        call_value(each_job(ts_pg_2, ({
        auto st_p0_1_3 = st_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=, st_p0_1_3 = std::move(st_p0_1_3)](Ty p0) {
        return ({
            auto st_p0_1_3_3 = st_p0_1_3;
            entered(once_job([=, st_p0_1_3_3 = std::move(st_p0_1_3_3)]() {
            return ({
                auto a_ph = p0;
                (prism_rtl::more(prism_rtl::rc(ShowTyIn(st_p0_1_3_3, a_ph, false))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_10143) { return prism_rtl::finished(prism_rtl::cat("((", crate::syntax::lexer::chars::join(each_10143, Text::lit(", ")), "))")); });
    });
    })
        : prism_rtl::is<Ty::TyArray>(t_p1) ? ({
        auto&& e_pi = prism_rtl::as<Ty::TyArray>(t_p1).a0;
        ({
        auto e_pi_1 = prism_rtl::deref(prism_rtl::deref(e_pi));
        auto st_p0_2 = st_p0;
        call_then(start_show_ty_in(st_p0_2, e_pi_1, false), [=](Text show_ty_in_10225) {
        return ({
            auto inner_pj = show_ty_in_10225;
            (crate::syntax::lexer::chars::has_prefix(inner_pj, Text::lit("["))
            ? prism_rtl::finished(prism_rtl::cat("[ ", inner_pj, " ]"))
            : prism_rtl::finished(prism_rtl::cat("[", inner_pj, "]")));
        });
    });
    });
    })
        : prism_rtl::is<Ty::TyMap>(t_p1) ? ({
        auto&& k_pk = prism_rtl::as<Ty::TyMap>(t_p1).a0;
        auto&& v_pl = prism_rtl::as<Ty::TyMap>(t_p1).a1;
        ({
        auto k_pk_1 = prism_rtl::deref(prism_rtl::deref(k_pk));
        auto nested_p2_2 = prism_rtl::deref(nested_p2);
        auto st_p0_3 = st_p0;
        auto v_pl_4 = prism_rtl::deref(prism_rtl::deref(v_pl));
        call_then(start_show_ty_in(st_p0_3, k_pk_1, true), [=, nested_p2_2 = std::move(nested_p2_2), v_pl_4 = std::move(v_pl_4)](Text show_ty_in_10352) {
        return call_then(start_show_ty_in(st_p0_3, v_pl_4, true), [=](Text show_ty_in_10379) {
            return ({
                auto inner_pm = prism_rtl::cat(show_ty_in_10352, " ==> ", show_ty_in_10379);
                nested_p2_2
                ? prism_rtl::finished(prism_rtl::cat("(", inner_pm, ")"))
                : prism_rtl::finished(inner_pm);
            });
        });
    });
    });
    })
        : prism_rtl::is<Ty::TySig>(t_p1) ? ({
        auto&& s_pn = prism_rtl::as<Ty::TySig>(t_p1).a0;
        auto&& i_po = prism_rtl::as<Ty::TySig>(t_p1).a1;
        ({
        auto i_po_1 = prism_rtl::deref(prism_rtl::deref(i_po));
        auto s_pn_2 = s_pn;
        auto st_p0_3 = st_p0;
        call_then(start_show_ty_in(st_p0_3, i_po_1, true), [=, s_pn_2 = std::move(s_pn_2)](Text show_ty_in_10466) { return prism_rtl::finished(prism_rtl::cat(s_pn_2, show_ty_in_10466)); });
    });
    })
        : prism_rtl::is<Ty::TyAt>(t_p1) ? ({
        auto&& i_pp = prism_rtl::as<Ty::TyAt>(t_p1).a0;
        auto&& rw_pq = prism_rtl::as<Ty::TyAt>(t_p1).a1;
        ({
        auto i_pp_1 = prism_rtl::deref(prism_rtl::deref(i_pp));
        auto st_p0_2 = st_p0;
        call_then(start_show_ty_in(st_p0_2, i_pp_1, true), [=](Text show_ty_in_10508) { return prism_rtl::finished(prism_rtl::cat("@", show_ty_in_10508)); });
    });
    })
        : prism_rtl::is<Ty::TyElem>(t_p1) ? ({
        auto&& rw_pr = prism_rtl::as<Ty::TyElem>(t_p1).a0;
        auto&& o_ps = prism_rtl::as<Ty::TyElem>(t_p1).a1;
        ({
        auto nested_p2_1 = prism_rtl::deref(nested_p2);
        auto o_ps_2 = prism_rtl::deref(prism_rtl::deref(o_ps));
        auto rw_pr_3 = rw_pr;
        auto st_p0_4 = st_p0;
        call_then(start_show_ty_in(st_p0_4, o_ps_2, true), [=, nested_p2_1 = std::move(nested_p2_1), rw_pr_3 = std::move(rw_pr_3)](Text show_ty_in_10600) {
        return ({
            auto inner_pt = prism_rtl::cat("Element ", show_row_in(rw_pr_3, true), " ", show_ty_in_10600);
            nested_p2_1
            ? prism_rtl::finished(prism_rtl::cat("(", inner_pt, ")"))
            : prism_rtl::finished(inner_pt);
        });
    });
    });
    })
        : prism_rtl::is<Ty::TyElemAny>(t_p1) ? ({
        auto&& rw_pu = prism_rtl::as<Ty::TyElemAny>(t_p1).a0;
        prism_rtl::deref(nested_p2)
        ? prism_rtl::finished(prism_rtl::cat("(Elem ", show_row_in(rw_pu, true), ")"))
        : prism_rtl::finished(prism_rtl::cat("Elem ", show_row_in(rw_pu, true)));
    })
        : prism_rtl::is<Ty::TyAssoc>(t_p1) ? ({
        auto&& n_pv = prism_rtl::as<Ty::TyAssoc>(t_p1).a0;
        auto&& a_p10 = prism_rtl::as<Ty::TyAssoc>(t_p1).a1;
        prism_rtl::deref(nested_p2)
        ? ({
        auto a_p10_1 = prism_rtl::deref(prism_rtl::deref(a_p10));
        auto n_pv_2 = n_pv;
        auto st_p0_3 = st_p0;
        call_then(start_show_ty_in(st_p0_3, a_p10_1, true), [=, n_pv_2 = std::move(n_pv_2)](Text show_ty_in_10795) { return prism_rtl::finished(prism_rtl::cat("(", n_pv_2, " ", show_ty_in_10795, ")")); });
    })
        : ({
        auto a_p10_1 = prism_rtl::deref(prism_rtl::deref(a_p10));
        auto n_pv_2 = n_pv;
        auto st_p0_3 = st_p0;
        call_then(start_show_ty_in(st_p0_3, a_p10_1, true), [=, n_pv_2 = std::move(n_pv_2)](Text show_ty_in_10831) { return prism_rtl::finished(prism_rtl::cat(n_pv_2, " ", show_ty_in_10831)); });
    });
    })
        : prism_rtl::is<Ty::TyAny>(t_p1) ? ({
        auto&& ts_p11 = prism_rtl::as<Ty::TyAny>(t_p1).a0;
        prism_rtl::finished(prism_rtl::cat("any ", crate::syntax::lexer::chars::join(each(ts_p11, [&](const Text& x_p12) { return prism_rtl::cat("^", bare_name(x_p12)); }), Text::lit(" "))));
    })
        : prism_rtl::is<Ty::TyErr>(t_p1) ? prism_rtl::finished(Text::lit("?"))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ShowTyIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_ty_in(St st_p0, Ty t_p1, bool nested_p2) {
    return prism_rtl::make_rc<ShowTyIn>(st_p0, t_p1, nested_p2);
}


/// ShowCol: fn Col -> Text
Text show_col(const Col& col0) {
    if (prism_rtl::is<Col::CBound>(col0)) {
        return Text::lit("");
    }
    if (prism_rtl::is<Col::CUnbound>(col0)) {
        return Text::lit("unbounded ");
    }
    if (prism_rtl::is<Col::CRigid>(col0)) {
        auto&& n_p0 = prism_rtl::as<Col::CRigid>(col0).a0;
        return prism_rtl::cat(n_p0, " ");
    }
    if (prism_rtl::is<Col::CQ>(col0)) {
        auto&& n_p1 = prism_rtl::as<Col::CQ>(col0).a0;
        return prism_rtl::cat(n_p1, " ");
    }
    if (prism_rtl::is<Col::CFlex>(col0)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ShowRow: fn Rw -> Text
Text show_row(const Rw& rw_p0) {
    return show_row_in(rw_p0, false);
}


/// ShowRowIn: fn Rw, Bool -> Text
Text show_row_in(const Rw& rw_p0, const bool& nested_p1) {
    auto fams_p2 = each(rw_p0.fams, [&](const Text& f_p7) { return prism_rtl::cat(f_p7, ".*"); });
    auto tail_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = rw_p0.tail;
        if (prism_rtl::is<Tail::TlClosed>(_m)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        if (prism_rtl::is<Tail::TlFlex>(_m)) {
            auto&& n_p8 = prism_rtl::as<Tail::TlFlex>(_m).a0;
            _v.set(Array(std::vector{prism_rtl::cat("r", n_p8)}));
            goto _done;
        }
        if (prism_rtl::is<Tail::TlRigid>(_m)) {
            auto&& n_p9 = prism_rtl::as<Tail::TlRigid>(_m).a0;
            _v.set(Array(std::vector{n_p9}));
            goto _done;
        }
        if (prism_rtl::is<Tail::TlQ>(_m)) {
            auto&& n_pa = prism_rtl::as<Tail::TlQ>(_m).a0;
            _v.set(Array(std::vector{n_pa}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto parts_p4 = append(tail_p3, fams_p2);
    auto minus_p5 = len(rw_p0.minus) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" − {", crate::syntax::lexer::chars::join(rw_p0.minus, Text::lit(", ")), "}");
    auto inner_p6 = len(parts_p4) == Nat(0u)
        ? Text::lit("unit")
        : crate::syntax::lexer::chars::join(parts_p4, Text::lit(" | "));
    return nested_p1 && ((len(parts_p4) > Nat(1u)) || (minus_p5 != Text::lit("")))
        ? prism_rtl::cat("(", inner_p6, minus_p5, ")")
        : prism_rtl::cat(inner_p6, minus_p5);
}

}  // namespace crate::check::types


// The module `Check.Types.Colors`, from `target/bootstrap/cpp-src/prismc/check/types/colors.prism`.
namespace crate::check::types::colors {

/// JoinCol: fn Col, Col -> Col
crate::check::types::Col join_col(const crate::check::types::Col& col0, const crate::check::types::Col& col1) {
    auto&& _m = std::tuple{col0, col1};
    if (prism_rtl::is<crate::check::types::Col::CBound>(std::get<0>(_m))) {
        auto&& c_p0 = std::get<1>(_m);
        return c_p0;
    }
    if (prism_rtl::is<crate::check::types::Col::CBound>(std::get<1>(_m))) {
        auto&& c_p1 = std::get<0>(_m);
        return c_p1;
    }
    if (prism_rtl::is<crate::check::types::Col::CUnbound>(std::get<0>(_m))) {
        return crate::check::types::Col(crate::check::types::Col::CUnbound{});
    }
    if (prism_rtl::is<crate::check::types::Col::CUnbound>(std::get<1>(_m))) {
        return crate::check::types::Col(crate::check::types::Col::CUnbound{});
    }
    {
        auto&& a_p2 = std::get<0>(_m);
        auto&& b_p3 = std::get<1>(_m);
        return a_p2 == b_p3
            ? a_p2
            : crate::check::types::Col(crate::check::types::Col::CUnbound{});
    }
    prism_rtl::unreachable("no arm matched");
}


/// ColLeq: fn Col, Col -> Bool
bool col_leq(const crate::check::types::Col& a_p0, const crate::check::types::Col& b_p1) {
    return join_col(a_p0, b_p1) == b_p1;
}


/// ColWord: fn Col -> Text
Text col_word(const crate::check::types::Col& col0) {
    if (prism_rtl::is<crate::check::types::Col::CBound>(col0)) {
        return Text::lit("bounded");
    }
    if (prism_rtl::is<crate::check::types::Col::CUnbound>(col0)) {
        return Text::lit("unbounded");
    }
    if (prism_rtl::is<crate::check::types::Col::CRigid>(col0)) {
        auto&& n_p0 = prism_rtl::as<crate::check::types::Col::CRigid>(col0).a0;
        return prism_rtl::cat("`", n_p0, "`-colored");
    }
    if (prism_rtl::is<crate::check::types::Col::CQ>(col0)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Col::CQ>(col0).a0;
        return prism_rtl::cat("`", n_p1, "`-colored");
    }
    if (prism_rtl::is<crate::check::types::Col::CFlex>(col0)) {
        return Text::lit("bounded");
    }
    prism_rtl::unreachable("no arm matched");
}


/// UseColor: unbounded fn St, Col, Text, Range -> St
crate::check::types::St use_color(const crate::check::types::St& st_p0, const crate::check::types::Col& c0_p1, const Text& why_p2, const crate::syntax::Range& span_p3) {
    auto&& _m = walk_col(st_p0, c0_p1);
    if (prism_rtl::is<crate::check::types::Col::CFlex>(_m)) {
        auto&& n_p4 = prism_rtl::as<crate::check::types::Col::CFlex>(_m).a0;
        crate::check::types::St this_ = st_p0;
        this_.color_flex = crate::prelude::push(this_.color_flex, std::tuple{crate::check::types::Col(crate::check::types::Col::CFlex{n_p4}), why_p2, span_p3});
        return this_;
    }
    {
        auto&& c_p5 = _m;
        return join_known(st_p0, c_p5, why_p2);
    }
}


prism_rtl::Turn<crate::check::types::St> UseColor::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& c0_p1 = this->c0_p1;
    const auto& why_p2 = this->why_p2;
    const auto& span_p3 = this->span_p3;
    auto c0_p1_1 = c0_p1;
    auto span_p3_2 = span_p3;
    auto st_p0_3 = st_p0;
    auto why_p2_4 = why_p2;
    return call_then(start_walk_col(st_p0_3, c0_p1_1), [=](crate::check::types::Col walk_col_1582) {
        return ({
            prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_1582) ? ({
            auto&& n_p4 = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_1582).a0;
            prism_rtl::finished(({
            crate::check::types::St this_ = st_p0_3;
            this_.color_flex = crate::prelude::push(this_.color_flex, std::tuple{crate::check::types::Col(crate::check::types::Col::CFlex{n_p4}), why_p2_4, span_p3_2});
            (std::move(this_));
        }));
        })
            : ({
            auto&& c_p5 = walk_col_1582;
            prism_rtl::finished(join_known(st_p0_3, c_p5, why_p2_4));
        });
        });
    });
}


/// `Start UseColor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_use_color(crate::check::types::St st_p0, crate::check::types::Col c0_p1, Text why_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<UseColor>(st_p0, c0_p1, why_p2, span_p3);
}


/// JoinKnown: fn St, Col, Text -> St
crate::check::types::St join_known(const crate::check::types::St& st_p0, const crate::check::types::Col& c0_p1, const Text& why_p2) {
    auto c_p3 = up_col(st_p0, c0_p1);
    crate::check::types::St this_ = st_p0;
    if (!col_leq(c_p3, this_.color)) {
        this_.color_why = why_p2;
    }
    this_.color = join_col(this_.color, c_p3);
    return this_;
}


/// UpCol: fn St, Col -> Col
crate::check::types::Col up_col(const crate::check::types::St& st_p0, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CRigid>(col1)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Col::CRigid>(col1).a0;
        auto&& _m = crate::prelude::get(st_p0.col_up, n_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& up_p2 = prism_rtl::some_of(_m);
            return crate::check::types::Col(crate::check::types::Col::CRigid{up_p2});
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::Col(crate::check::types::Col::CRigid{n_p1});
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        auto&& c_p4 = col1;
        return c_p4;
    }
}


/// WalkCol: unbounded fn St, Col -> Col
crate::check::types::Col walk_col(const crate::check::types::St& st_p0, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CFlex>(col1)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Col::CFlex>(col1).a0;
        auto&& _m = crate::prelude::get(st_p0.cols, n_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& c_p2 = prism_rtl::some_of(_m);
            return walk_col(st_p0, c_p2);
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::Col(crate::check::types::Col::CFlex{n_p1});
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        auto&& c_p4 = col1;
        return c_p4;
    }
}


prism_rtl::Turn<crate::check::types::Col> WalkCol::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& col1 = this->col1;
    return ({
        prism_rtl::is<crate::check::types::Col::CFlex>(col1) ? ({
        auto&& n_p1 = prism_rtl::as<crate::check::types::Col::CFlex>(col1).a0;
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(st_p0).cols, n_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& c_p2 = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(WalkCol(st_p0, c_p2)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::Col(crate::check::types::Col::CFlex{n_p1}))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : ({
        auto&& c_p4 = col1;
        prism_rtl::finished(c_p4);
    });
    });
}


/// `Start WalkCol, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Col> start_walk_col(crate::check::types::St st_p0, crate::check::types::Col col1) {
    return prism_rtl::make_rc<WalkCol>(st_p0, col1);
}


/// IsRigidCol: fn Col -> Bool
bool is_rigid_col(const crate::check::types::Col& col0) {
    if (prism_rtl::is<crate::check::types::Col::CRigid>(col0)) {
        return true;
    }
    {
        return false;
    }
}


/// IsOwnCol: fn St, Col -> Bool
bool is_own_col(const crate::check::types::St& s_p0, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CFlex>(col1)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Col::CFlex>(col1).a0;
        return prism_rtl::deref(crate::check::types::recording::info_of(s_p0, n_p1)).level > s_p0.level;
    }
    {
        return false;
    }
}


/// IsFlexCol: fn Col -> Bool
bool is_flex_col(const crate::check::types::Col& col0) {
    if (prism_rtl::is<crate::check::types::Col::CFlex>(col0)) {
        return true;
    }
    {
        return false;
    }
}


/// SettledCol: unbounded fn St, Col -> Col
crate::check::types::Col settled_col(const crate::check::types::St& st_p0, const crate::check::types::Col& c_p1) {
    auto&& _m = walk_col(st_p0, c_p1);
    if (prism_rtl::is<crate::check::types::Col::CFlex>(_m)) {
        return crate::check::types::Col(crate::check::types::Col::CBound{});
    }
    {
        auto&& other_p2 = _m;
        return other_p2;
    }
}


prism_rtl::Turn<crate::check::types::Col> SettledCol::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& c_p1 = this->c_p1;
    auto c_p1_1 = c_p1;
    auto st_p0_2 = st_p0;
    return call_then(start_walk_col(st_p0_2, c_p1_1), [=](crate::check::types::Col walk_col_2936) {
        return ({
            prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_2936) ? prism_rtl::finished(crate::check::types::Col(crate::check::types::Col::CBound{}))
            : ({
            auto&& other_p2 = walk_col_2936;
            prism_rtl::finished(other_p2);
        });
        });
    });
}


/// `Start SettledCol, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Col> start_settled_col(crate::check::types::St st_p0, crate::check::types::Col c_p1) {
    return prism_rtl::make_rc<SettledCol>(st_p0, c_p1);
}


/// UnifyCol: unbounded fn St, Col, Col -> ((Text, St))
std::tuple<Text, crate::check::types::St> unify_col(const crate::check::types::St& st_p0, const crate::check::types::Col& a0_p1, const crate::check::types::Col& b0_p2) {
    auto a_p3 = walk_col(st_p0, a0_p1);
    auto b_p4 = walk_col(st_p0, b0_p2);
    return a_p3 == b_p4
        ? std::tuple{Text::lit(""), st_p0}
        : ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, crate::check::types::St>> _v;
        auto&& _m = std::tuple{a_p3, b_p4};
        if (prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m))) {
            auto&& x_p5 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
            auto&& other_p6 = std::get<1>(_m);
            _v.set(std::tuple{Text::lit(""), bind_col(st_p0, x_p5, other_p6)});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m))) {
            auto&& other_p7 = std::get<0>(_m);
            auto&& y_p8 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
            _v.set(std::tuple{Text::lit(""), bind_col(st_p0, y_p8, other_p7)});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Col::CQ>(std::get<0>(_m))) {
            _v.set(std::tuple{Text::lit(""), st_p0});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Col::CQ>(std::get<1>(_m))) {
            _v.set(std::tuple{Text::lit(""), st_p0});
            goto _done;
        }
        {
            _v.set(std::tuple{Text::lit("mismatch"), st_p0});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> UnifyCol::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& a0_p1 = this->a0_p1;
    const auto& b0_p2 = this->b0_p2;
    auto a0_p1_1 = a0_p1;
    auto b0_p2_2 = b0_p2;
    auto st_p0_3 = st_p0;
    return call_then(start_walk_col(st_p0_3, a0_p1_1), [=](crate::check::types::Col walk_col_3231) {
        return ({
            auto a_p3 = walk_col_3231;
            call_then(start_walk_col(st_p0_3, b0_p2_2), [=, a_p3 = std::move(a_p3)](crate::check::types::Col walk_col_3258) {
            return ({
                auto b_p4 = walk_col_3258;
                a_p3 == b_p4
                ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0_3})
                : ({
                auto&& _m = std::tuple{a_p3, b_p4};
                prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) ? ({
                auto&& x_p5 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                auto&& other_p6 = std::get<1>(_m);
                prism_rtl::finished(std::tuple{Text::lit(""), bind_col(st_p0_3, x_p5, other_p6)});
            })
                : prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                auto&& other_p7 = std::get<0>(_m);
                auto&& y_p8 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                prism_rtl::finished(std::tuple{Text::lit(""), bind_col(st_p0_3, y_p8, other_p7)});
            })
                : prism_rtl::is<crate::check::types::Col::CQ>(std::get<0>(_m)) ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0_3})
                : prism_rtl::is<crate::check::types::Col::CQ>(std::get<1>(_m)) ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0_3})
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0_3});
            });
            });
        });
        });
    });
}


/// `Start UnifyCol, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_col(crate::check::types::St st_p0, crate::check::types::Col a0_p1, crate::check::types::Col b0_p2) {
    return prism_rtl::make_rc<UnifyCol>(st_p0, a0_p1, b0_p2);
}


/// BindCol: fn St, Nat, Col -> St
crate::check::types::St bind_col(const crate::check::types::St& st_p0, const Nat& n_p1, const crate::check::types::Col& c_p2) {
    auto st2_p3 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        if (prism_rtl::is<crate::check::types::Col::CFlex>(c_p2)) {
            auto&& m_p4 = prism_rtl::as<crate::check::types::Col::CFlex>(c_p2).a0;
            _v.set(crate::check::types::unify::lower_one(st_p0, m_p4, prism_rtl::deref(crate::check::types::recording::info_of(st_p0, n_p1)).level));
            goto _done;
        }
        {
            _v.set(st_p0);
            goto _done;
        }
    _done:
        _v.take();
    });
    crate::check::types::St this_ = st2_p3;
    this_.cols = insert(this_.cols, n_p1, c_p2);
    return this_;
}


/// FreeColVars: unbounded fn St, Ty -> [Nat]
Array<Nat> free_col_vars(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    return free_cols_into(st_p0, Array<Nat>{}, t_p1);
}


prism_rtl::Turn<Array<Nat>> FreeColVars::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    return prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0, Array<Nat>{}, t_p1)));
}


/// `Start FreeColVars, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_free_col_vars(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<FreeColVars>(st_p0, t_p1);
}


/// FreeColsInto: unbounded fn St, [Nat], Ty -> [Nat]
Array<Nat> free_cols_into(const crate::check::types::St& st_p0, const Array<Nat>& acc_p1, const crate::check::types::Ty& t_p2) {
    auto&& _m = crate::check::types::recording::walk(st_p0, t_p2);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& args_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        return run_to_end(fold_job(args_p3, acc_p1, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto a_p4 = p0;
                    auto x_p5 = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0_1_2, a_p4, x_p5))));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& c_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0;
        auto&& ps_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
        auto&& res_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        auto acc2_p9 = ({
            __label__ _done;
            prism_rtl::Slot<Array<Nat>> _v;
            auto&& _m = walk_col(st_p0, c_p6);
            if (prism_rtl::is<crate::check::types::Col::CFlex>(_m)) {
                auto&& n_pa = prism_rtl::as<crate::check::types::Col::CFlex>(_m).a0;
                _v.set(crate::check::types::add_nat(acc_p1, n_pa));
                goto _done;
            }
            {
                _v.set(acc_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
        return free_cols_into(st_p0, run_to_end(fold_job(ps_p7, acc2_p9, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto a_pb = p0;
                    auto x_pc = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0_1_2, a_pb, x_pc))));
                });
            }));
            });
        })));
        }))), prism_rtl::deref(res_p8));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts_pd = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return run_to_end(fold_job(ts_pd, acc_p1, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto a_pe = p0;
                    auto x_pf = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0_1_2, a_pe, x_pf))));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& e_pg = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        return free_cols_into(st_p0, acc_p1, prism_rtl::deref(e_pg));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k_ph = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_pi = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return free_cols_into(st_p0, free_cols_into(st_p0, acc_p1, prism_rtl::deref(k_ph)), prism_rtl::deref(v_pi));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& i_pj = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return free_cols_into(st_p0, acc_p1, prism_rtl::deref(i_pj));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
        auto&& i_pk = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
        return free_cols_into(st_p0, acc_p1, prism_rtl::deref(i_pk));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& o_pl = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
        return free_cols_into(st_p0, acc_p1, prism_rtl::deref(o_pl));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(_m)) {
        auto&& a_pm = prism_rtl::as<crate::check::types::Ty::TyAssoc>(_m).a1;
        return free_cols_into(st_p0, acc_p1, prism_rtl::deref(a_pm));
    }
    {
        return acc_p1;
    }
}


prism_rtl::Turn<Array<Nat>> FreeColsInto::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& acc_p1 = this->acc_p1;
    const auto& t_p2 = this->t_p2;
    auto acc_p1_1 = acc_p1;
    auto st_p0_2 = st_p0;
    auto t_p2_3 = t_p2;
    return call_then(crate::check::types::recording::start_walk(st_p0_2, t_p2_3), [=](crate::check::types::Ty walk_3992) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_3992) ? ({
            auto&& args_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_3992).a1;
            fold_job(args_p3, acc_p1_1, ({
            auto st_p0_2_4 = st_p0_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0_2_4 = std::move(st_p0_2_4)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0_2_4_4 = st_p0_2_4;
                entered(once_job([=, st_p0_2_4_4 = std::move(st_p0_2_4_4)]() {
                return ({
                    auto a_p4 = p0;
                    auto x_p5 = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0_2_4_4, a_p4, x_p5))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::types::Ty::TyFn>(walk_3992) ? ({
            auto&& c_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_3992).a0;
            auto&& ps_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_3992).a1;
            auto&& res_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_3992).a2;
            call_then(start_walk_col(st_p0_2, c_p6), [=](crate::check::types::Col walk_col_4120) {
            return ({
                auto acc2_p9 = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Nat>> _v;
                    if (prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_4120)) {
                        auto&& n_pa = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_4120).a0;
                        _v.set(crate::check::types::add_nat(acc_p1_1, n_pa));
                        goto _done;
                    }
                    {
                        _v.set(acc_p1_1);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                call_value(fold_job(ps_p7, acc2_p9, ({
                auto st_p0_2_4 = st_p0_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0_2_4 = std::move(st_p0_2_4)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto st_p0_2_4_4 = st_p0_2_4;
                    entered(once_job([=, st_p0_2_4_4 = std::move(st_p0_2_4_4)]() {
                    return ({
                        auto a_pb = p0;
                        auto x_pc = p1;
                        (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0_2_4_4, a_pb, x_pc))));
                    });
                }));
                });
            })));
            })), [=](Array<Nat> fold_4223) { return prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0_2, fold_4223, prism_rtl::deref(res_p8)))); });
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyTuple>(walk_3992) ? ({
            auto&& ts_pd = prism_rtl::as<crate::check::types::Ty::TyTuple>(walk_3992).a0;
            fold_job(ts_pd, acc_p1_1, ({
            auto st_p0_2_4 = st_p0_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0_2_4 = std::move(st_p0_2_4)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0_2_4_4 = st_p0_2_4;
                entered(once_job([=, st_p0_2_4_4 = std::move(st_p0_2_4_4)]() {
                return ({
                    auto a_pe = p0;
                    auto x_pf = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0_2_4_4, a_pe, x_pf))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::types::Ty::TyArray>(walk_3992) ? ({
            auto&& e_pg = prism_rtl::as<crate::check::types::Ty::TyArray>(walk_3992).a0;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0_2, acc_p1_1, prism_rtl::deref(e_pg))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyMap>(walk_3992) ? ({
            auto&& k_ph = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_3992).a0;
            auto&& v_pi = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_3992).a1;
            call_then(start_free_cols_into(st_p0_2, acc_p1_1, prism_rtl::deref(k_ph)), [=](Array<Nat> free_cols_into_4407) { return prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0_2, free_cols_into_4407, prism_rtl::deref(v_pi)))); });
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_3992) ? ({
            auto&& i_pj = prism_rtl::as<crate::check::types::Ty::TySig>(walk_3992).a1;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0_2, acc_p1_1, prism_rtl::deref(i_pj))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyAt>(walk_3992) ? ({
            auto&& i_pk = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_3992).a0;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0_2, acc_p1_1, prism_rtl::deref(i_pk))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyElem>(walk_3992) ? ({
            auto&& o_pl = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_3992).a1;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0_2, acc_p1_1, prism_rtl::deref(o_pl))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyAssoc>(walk_3992) ? ({
            auto&& a_pm = prism_rtl::as<crate::check::types::Ty::TyAssoc>(walk_3992).a1;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_p0_2, acc_p1_1, prism_rtl::deref(a_pm))));
        })
            : prism_rtl::finished(acc_p1_1);
        });
    });
}


/// `Start FreeColsInto, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_free_cols_into(crate::check::types::St st_p0, Array<Nat> acc_p1, crate::check::types::Ty t_p2) {
    return prism_rtl::make_rc<FreeColsInto>(st_p0, acc_p1, t_p2);
}


/// AddLeq: unbounded fn St, Col, Col, Range, Text, Text, Text -> St
crate::check::types::St add_leq(const crate::check::types::St& st_p0, const crate::check::types::Col& lo0_p1, const crate::check::types::Col& hi0_p2, const crate::syntax::Range& span_p3, const Text& kind_p4, const Text& name_p5, const Text& why_p6) {
    auto lo_p7 = walk_col(st_p0, lo0_p1);
    auto hi_p8 = walk_col(st_p0, hi0_p2);
    return ((lo_p7 == crate::check::types::Col(crate::check::types::Col::CBound{})) || (hi_p8 == crate::check::types::Col(crate::check::types::Col::CUnbound{}))) || (lo_p7 == hi_p8)
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        this_.cleqs = crate::prelude::push(this_.cleqs, crate::check::types::CLeq{.lo = lo_p7, .hi = hi_p8, .file = this_.file, .span = span_p3, .kind = kind_p4, .name = name_p5, .why = why_p6});
        (std::move(this_));
    });
}


prism_rtl::Turn<crate::check::types::St> AddLeq::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& lo0_p1 = this->lo0_p1;
    const auto& hi0_p2 = this->hi0_p2;
    const auto& span_p3 = this->span_p3;
    const auto& kind_p4 = this->kind_p4;
    const auto& name_p5 = this->name_p5;
    const auto& why_p6 = this->why_p6;
    auto hi0_p2_1 = hi0_p2;
    auto kind_p4_2 = kind_p4;
    auto lo0_p1_3 = lo0_p1;
    auto name_p5_4 = name_p5;
    auto span_p3_5 = span_p3;
    auto st_p0_6 = st_p0;
    auto why_p6_7 = why_p6;
    return call_then(start_walk_col(st_p0_6, lo0_p1_3), [=](crate::check::types::Col walk_col_4883) {
        return ({
            auto lo_p7 = walk_col_4883;
            call_then(start_walk_col(st_p0_6, hi0_p2_1), [=, lo_p7 = std::move(lo_p7)](crate::check::types::Col walk_col_4912) {
            return ({
                auto hi_p8 = walk_col_4912;
                ((lo_p7 == crate::check::types::Col(crate::check::types::Col::CBound{})) || (hi_p8 == crate::check::types::Col(crate::check::types::Col::CUnbound{}))) || (lo_p7 == hi_p8)
                ? prism_rtl::finished(st_p0_6)
                : prism_rtl::finished(({
                crate::check::types::St this_ = st_p0_6;
                this_.cleqs = crate::prelude::push(this_.cleqs, crate::check::types::CLeq{.lo = lo_p7, .hi = hi_p8, .file = this_.file, .span = span_p3_5, .kind = kind_p4_2, .name = name_p5_4, .why = why_p6_7});
                (std::move(this_));
            }));
            });
        });
        });
    });
}


/// `Start AddLeq, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_add_leq(crate::check::types::St st_p0, crate::check::types::Col lo0_p1, crate::check::types::Col hi0_p2, crate::syntax::Range span_p3, Text kind_p4, Text name_p5, Text why_p6) {
    return prism_rtl::make_rc<AddLeq>(st_p0, lo0_p1, hi0_p2, span_p3, kind_p4, name_p5, why_p6);
}


/// Propagate: unbounded fn St, Bool -> St
crate::check::types::St propagate(const crate::check::types::St& st_p0, const bool& rigid_p1) {
    auto [st2_p8, changed_p9] = run_to_end(fold_job(st_p0.cleqs, std::tuple{st_p0, false}, ({
        auto rigid_p1_1 = rigid_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, bool>>(std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq>)>>(prism_rtl::rc([=, rigid_p1_1 = std::move(rigid_p1_1)](std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rigid_p1_1_2 = rigid_p1_1;
            entered(once_job([=, rigid_p1_1_2 = std::move(rigid_p1_1_2)]() {
            return ({
                auto [s_p2, ch_p3] = p0;
                auto c_p4 = p1;
                call_then(start_walk_col(s_p2, prism_rtl::deref(c_p4).lo), [=](crate::check::types::Col walk_col_5490) {
                return ({
                    auto lo_p5 = walk_col_5490;
                    call_then(start_walk_col(s_p2, prism_rtl::deref(c_p4).hi), [=, lo_p5 = std::move(lo_p5)](crate::check::types::Col walk_col_5520) {
                    return ({
                        prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_5520) ? ({
                        auto&& h_p6 = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_5520).a0;
                        ({
                        auto forced_p7 = (lo_p5 == crate::check::types::Col(crate::check::types::Col::CUnbound{})) || (rigid_p1_1_2 && is_rigid_col(lo_p5));
                        (std::move(forced_p7)
                        ? prism_rtl::finished(std::tuple{bind_col(s_p2, h_p6, lo_p5), true})
                        : prism_rtl::finished(std::tuple{s_p2, ch_p3}));
                    });
                    })
                        : prism_rtl::finished(std::tuple{s_p2, ch_p3});
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })));
    return changed_p9 ? propagate(st2_p8, rigid_p1) : st2_p8;
}


prism_rtl::Turn<crate::check::types::St> Propagate::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& rigid_p1 = this->rigid_p1;
    auto rigid_p1_1 = prism_rtl::deref(rigid_p1);
    auto st_p0_2 = st_p0;
    return call_value(fold_job(prism_rtl::deref(st_p0_2).cleqs, std::tuple{st_p0_2, false}, ({
        auto rigid_p1_1_3 = std::move(rigid_p1_1);
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, bool>>(std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq>)>>(prism_rtl::rc([=, rigid_p1_1_3 = std::move(rigid_p1_1_3)](std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rigid_p1_1_3_3 = rigid_p1_1_3;
            entered(once_job([=, rigid_p1_1_3_3 = std::move(rigid_p1_1_3_3)]() {
            return ({
                auto [s_p2, ch_p3] = p0;
                auto c_p4 = p1;
                call_then(start_walk_col(s_p2, prism_rtl::deref(c_p4).lo), [=](crate::check::types::Col walk_col_5490) {
                return ({
                    auto lo_p5 = walk_col_5490;
                    call_then(start_walk_col(s_p2, prism_rtl::deref(c_p4).hi), [=, lo_p5 = std::move(lo_p5)](crate::check::types::Col walk_col_5520) {
                    return ({
                        prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_5520) ? ({
                        auto&& h_p6 = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_5520).a0;
                        ({
                        auto forced_p7 = (lo_p5 == crate::check::types::Col(crate::check::types::Col::CUnbound{})) || (rigid_p1_1_3_3 && is_rigid_col(lo_p5));
                        (std::move(forced_p7)
                        ? prism_rtl::finished(std::tuple{bind_col(s_p2, h_p6, lo_p5), true})
                        : prism_rtl::finished(std::tuple{s_p2, ch_p3}));
                    });
                    })
                        : prism_rtl::finished(std::tuple{s_p2, ch_p3});
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<crate::check::types::St, bool> fold_5427) {
        return ({
            auto [st2_p8, changed_p9] = fold_5427;
            changed_p9
            ? prism_rtl::more(prism_rtl::rc(Propagate(st2_p8, rigid_p1_1)))
            : prism_rtl::finished(st2_p8);
        });
    });
}


/// `Start Propagate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_propagate(crate::check::types::St st_p0, bool rigid_p1) {
    return prism_rtl::make_rc<Propagate>(st_p0, rigid_p1);
}


/// GeneralizeCols: unbounded fn St -> St
crate::check::types::St generalize_cols(const crate::check::types::St& st0_p0) {
    auto st1_p1 = lower_joined(propagate(st0_p0, false));
    auto st2_p2 = run_to_end(fold_job(prism_rtl::deref(st1_p1).cleqs, st1_p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s_p3 = p0;
                auto c_p4 = p1;
                call_then(start_walk_col(s_p3, prism_rtl::deref(c_p4).lo), [=](crate::check::types::Col walk_col_6260) {
                return ({
                    auto lo_p5 = walk_col_6260;
                    call_then(start_walk_col(s_p3, prism_rtl::deref(c_p4).hi), [=, lo_p5 = std::move(lo_p5)](crate::check::types::Col walk_col_6293) {
                    return ({
                        auto hi_p6 = walk_col_6293;
                        ({
                        auto&& _m = std::tuple{lo_p5, hi_p6};
                        prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                        auto&& x_p7 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                        auto&& y_p8 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                        ((x_p7 != y_p8) && is_own_col(s_p3, lo_p5)) && is_own_col(s_p3, hi_p6)
                        ? prism_rtl::finished(bind_col(s_p3, x_p7, hi_p6))
                        : prism_rtl::finished(s_p3);
                    })
                        : prism_rtl::finished(s_p3);
                    });
                    });
                });
                });
            });
            });
        }));
    }))));
    return run_to_end(fold_job(prism_rtl::deref(st2_p2).cleqs, st2_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s_p9 = p0;
                auto c_pa = p1;
                call_then(start_walk_col(s_p9, prism_rtl::deref(c_pa).lo), [=](crate::check::types::Col walk_col_6522) {
                return ({
                    auto lo_pb = walk_col_6522;
                    call_then(start_walk_col(s_p9, prism_rtl::deref(c_pa).hi), [=, lo_pb = std::move(lo_pb)](crate::check::types::Col walk_col_6555) {
                    return ({
                        auto hi_pc = walk_col_6555;
                        ({
                        auto&& _m = std::tuple{lo_pb, hi_pc};
                        prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? prism_rtl::finished(s_p9)
                        : prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CUnbound>(std::get<1>(_m)) ? prism_rtl::finished(s_p9)
                        : prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) ? ({
                        auto&& x_pd = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                        auto&& other_pe = std::get<1>(_m);
                        is_own_col(s_p9, lo_pb)
                        ? prism_rtl::finished(bind_col(s_p9, x_pd, other_pe))
                        : prism_rtl::finished(s_p9);
                    })
                        : prism_rtl::is<crate::check::types::Col::CRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                        auto&& r_pf = prism_rtl::as<crate::check::types::Col::CRigid>(std::get<0>(_m)).a0;
                        auto&& y_pg = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                        is_own_col(s_p9, hi_pc)
                        ? prism_rtl::finished(bind_col(s_p9, y_pg, lo_pb))
                        : prism_rtl::finished(s_p9);
                    })
                        : prism_rtl::finished(s_p9);
                    });
                    });
                });
                });
            });
            });
        }));
    }))));
}


prism_rtl::Turn<crate::check::types::St> GeneralizeCols::cycle() const {
    const auto& st0_p0 = this->st0_p0;
    auto st0_p0_1 = st0_p0;
    return call_then(start_propagate(st0_p0_1, false), [=](crate::check::types::St propagate_6178) {
        return call_then(start_lower_joined(propagate_6178), [=](crate::check::types::St lower_joined_6165) {
            return ({
                auto st1_p1 = lower_joined_6165;
                call_value(fold_job(prism_rtl::deref(st1_p1).cleqs, st1_p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto s_p3 = p0;
                        auto c_p4 = p1;
                        call_then(start_walk_col(s_p3, prism_rtl::deref(c_p4).lo), [=](crate::check::types::Col walk_col_6260) {
                        return ({
                            auto lo_p5 = walk_col_6260;
                            call_then(start_walk_col(s_p3, prism_rtl::deref(c_p4).hi), [=, lo_p5 = std::move(lo_p5)](crate::check::types::Col walk_col_6293) {
                            return ({
                                auto hi_p6 = walk_col_6293;
                                ({
                                auto&& _m = std::tuple{lo_p5, hi_p6};
                                prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                                auto&& x_p7 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                                auto&& y_p8 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                                ((x_p7 != y_p8) && is_own_col(s_p3, lo_p5)) && is_own_col(s_p3, hi_p6)
                                ? prism_rtl::finished(bind_col(s_p3, x_p7, hi_p6))
                                : prism_rtl::finished(s_p3);
                            })
                                : prism_rtl::finished(s_p3);
                            });
                            });
                        });
                        });
                    });
                    });
                }));
            }))), [=](crate::check::types::St fold_6214) {
                return ({
                    auto st2_p2 = fold_6214;
                    fold_job(prism_rtl::deref(st2_p2).cleqs, st2_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto s_p9 = p0;
                            auto c_pa = p1;
                            call_then(start_walk_col(s_p9, prism_rtl::deref(c_pa).lo), [=](crate::check::types::Col walk_col_6522) {
                            return ({
                                auto lo_pb = walk_col_6522;
                                call_then(start_walk_col(s_p9, prism_rtl::deref(c_pa).hi), [=, lo_pb = std::move(lo_pb)](crate::check::types::Col walk_col_6555) {
                                return ({
                                    auto hi_pc = walk_col_6555;
                                    ({
                                    auto&& _m = std::tuple{lo_pb, hi_pc};
                                    prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? prism_rtl::finished(s_p9)
                                    : prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CUnbound>(std::get<1>(_m)) ? prism_rtl::finished(s_p9)
                                    : prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) ? ({
                                    auto&& x_pd = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                                    auto&& other_pe = std::get<1>(_m);
                                    is_own_col(s_p9, lo_pb)
                                    ? prism_rtl::finished(bind_col(s_p9, x_pd, other_pe))
                                    : prism_rtl::finished(s_p9);
                                })
                                    : prism_rtl::is<crate::check::types::Col::CRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                                    auto&& r_pf = prism_rtl::as<crate::check::types::Col::CRigid>(std::get<0>(_m)).a0;
                                    auto&& y_pg = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                                    is_own_col(s_p9, hi_pc)
                                    ? prism_rtl::finished(bind_col(s_p9, y_pg, lo_pb))
                                    : prism_rtl::finished(s_p9);
                                })
                                    : prism_rtl::finished(s_p9);
                                });
                                });
                            });
                            });
                        });
                        });
                    }));
                })))->cycle();
                });
            });
            });
        });
    });
}


/// `Start GeneralizeCols, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_generalize_cols(crate::check::types::St st0_p0) {
    return prism_rtl::make_rc<GeneralizeCols>(st0_p0);
}


/// LowerJoined: unbounded fn St -> St
crate::check::types::St lower_joined(const crate::check::types::St& st_p0) {
    auto [st2_p8, changed_p9] = run_to_end(fold_job(st_p0.cleqs, std::tuple{st_p0, false}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, bool>>(std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [s_p1, ch_p2] = p0;
                auto c_p3 = p1;
                call_then(start_walk_col(s_p1, prism_rtl::deref(c_p3).lo), [=](crate::check::types::Col walk_col_7100) {
                return call_then(start_walk_col(s_p1, prism_rtl::deref(c_p3).hi), [=](crate::check::types::Col walk_col_7119) {
                    return ({
                        auto&& _m = std::tuple{walk_col_7100, walk_col_7119};
                        prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                        auto&& x_p4 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                        auto&& y_p5 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                        ({
                        auto lx_p6 = prism_rtl::deref(crate::check::types::recording::info_of(s_p1, x_p4)).level;
                        auto ly_p7 = prism_rtl::deref(crate::check::types::recording::info_of(s_p1, y_p5)).level;
                        ((lx_p6 > prism_rtl::deref(s_p1).level) && (ly_p7 <= prism_rtl::deref(s_p1).level)) && (lx_p6 > ly_p7)
                        ? prism_rtl::finished(std::tuple{crate::check::types::unify::lower_one(s_p1, x_p4, ly_p7), true})
                        : ((ly_p7 > prism_rtl::deref(s_p1).level) && (lx_p6 <= prism_rtl::deref(s_p1).level)) && (ly_p7 > lx_p6)
                        ? prism_rtl::finished(std::tuple{crate::check::types::unify::lower_one(s_p1, y_p5, lx_p6), true})
                        : prism_rtl::finished(std::tuple{s_p1, ch_p2});
                    });
                    })
                        : prism_rtl::finished(std::tuple{s_p1, ch_p2});
                    });
                });
            });
            });
        }));
    }))));
    return changed_p9 ? lower_joined(st2_p8) : st2_p8;
}


prism_rtl::Turn<crate::check::types::St> LowerJoined::cycle() const {
    const auto& st_p0 = this->st_p0;
    auto st_p0_1 = st_p0;
    return call_value(fold_job(prism_rtl::deref(st_p0_1).cleqs, std::tuple{st_p0_1, false}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, bool>>(std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [s_p1, ch_p2] = p0;
                auto c_p3 = p1;
                call_then(start_walk_col(s_p1, prism_rtl::deref(c_p3).lo), [=](crate::check::types::Col walk_col_7100) {
                return call_then(start_walk_col(s_p1, prism_rtl::deref(c_p3).hi), [=](crate::check::types::Col walk_col_7119) {
                    return ({
                        auto&& _m = std::tuple{walk_col_7100, walk_col_7119};
                        prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                        auto&& x_p4 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                        auto&& y_p5 = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                        ({
                        auto lx_p6 = prism_rtl::deref(crate::check::types::recording::info_of(s_p1, x_p4)).level;
                        auto ly_p7 = prism_rtl::deref(crate::check::types::recording::info_of(s_p1, y_p5)).level;
                        ((lx_p6 > prism_rtl::deref(s_p1).level) && (ly_p7 <= prism_rtl::deref(s_p1).level)) && (lx_p6 > ly_p7)
                        ? prism_rtl::finished(std::tuple{crate::check::types::unify::lower_one(s_p1, x_p4, ly_p7), true})
                        : ((ly_p7 > prism_rtl::deref(s_p1).level) && (lx_p6 <= prism_rtl::deref(s_p1).level)) && (ly_p7 > lx_p6)
                        ? prism_rtl::finished(std::tuple{crate::check::types::unify::lower_one(s_p1, y_p5, lx_p6), true})
                        : prism_rtl::finished(std::tuple{s_p1, ch_p2});
                    });
                    })
                        : prism_rtl::finished(std::tuple{s_p1, ch_p2});
                    });
                });
            });
            });
        }));
    }))), [=](std::tuple<crate::check::types::St, bool> fold_7037) {
        return ({
            auto [st2_p8, changed_p9] = fold_7037;
            changed_p9
            ? prism_rtl::more(prism_rtl::rc(LowerJoined(st2_p8)))
            : prism_rtl::finished(st2_p8);
        });
    });
}


/// `Start LowerJoined, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_lower_joined(crate::check::types::St st_p0) {
    return prism_rtl::make_rc<LowerJoined>(st_p0);
}


/// CheckColors: unbounded fn St -> St
crate::check::types::St check_colors(const crate::check::types::St& st0_p0) {
    auto st_p1 = propagate(propagate(st0_p0, false), true);
    auto st2_p2 = run_to_end(fold_job(prism_rtl::deref(st_p1).cleqs, st_p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s_p3 = p0;
                auto c_p4 = p1;
                call_then(start_settled_col(s_p3, prism_rtl::deref(c_p4).lo), [=](crate::check::types::Col settled_col_7897) {
                return ({
                    auto lo_p5 = settled_col_7897;
                    call_then(start_settled_col(s_p3, prism_rtl::deref(c_p4).hi), [=, lo_p5 = std::move(lo_p5)](crate::check::types::Col settled_col_7933) {
                    return ({
                        auto hi_p6 = settled_col_7933;
                        col_leq(lo_p5, hi_p6) || col_leq(up_col(s_p3, lo_p5), up_col(s_p3, hi_p6))
                        ? prism_rtl::finished(s_p3)
                        : prism_rtl::finished(crate::check::types::recording::add_diag(s_p3, leq_diag(c_p4, lo_p5, hi_p6)));
                    });
                });
                });
            });
            });
        }));
    }))));
    crate::check::types::St this_ = st2_p2;
    this_.cleqs = Array<crate::check::types::CLeq>{};
    this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
    this_.col_up = Map<Text, Text>{};
    return this_;
}


prism_rtl::Turn<crate::check::types::St> CheckColors::cycle() const {
    const auto& st0_p0 = this->st0_p0;
    auto st0_p0_1 = st0_p0;
    return call_then(start_propagate(st0_p0_1, false), [=](crate::check::types::St propagate_7811) {
        return call_then(start_propagate(propagate_7811, true), [=](crate::check::types::St propagate_7800) {
            return ({
                auto st_p1 = propagate_7800;
                call_value(fold_job(prism_rtl::deref(st_p1).cleqs, st_p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto s_p3 = p0;
                        auto c_p4 = p1;
                        call_then(start_settled_col(s_p3, prism_rtl::deref(c_p4).lo), [=](crate::check::types::Col settled_col_7897) {
                        return ({
                            auto lo_p5 = settled_col_7897;
                            call_then(start_settled_col(s_p3, prism_rtl::deref(c_p4).hi), [=, lo_p5 = std::move(lo_p5)](crate::check::types::Col settled_col_7933) {
                            return ({
                                auto hi_p6 = settled_col_7933;
                                col_leq(lo_p5, hi_p6) || col_leq(up_col(s_p3, lo_p5), up_col(s_p3, hi_p6))
                                ? prism_rtl::finished(s_p3)
                                : prism_rtl::finished(crate::check::types::recording::add_diag(s_p3, leq_diag(c_p4, lo_p5, hi_p6)));
                            });
                        });
                        });
                    });
                    });
                }));
            }))), [=](crate::check::types::St fold_7853) {
                return ({
                    auto st2_p2 = fold_7853;
                    (prism_rtl::finished(({
                    crate::check::types::St this_ = st2_p2;
                    this_.cleqs = Array<crate::check::types::CLeq>{};
                    this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
                    this_.col_up = Map<Text, Text>{};
                    (std::move(this_));
                })));
                });
            });
            });
        });
    });
}


/// `Start CheckColors, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_colors(crate::check::types::St st0_p0) {
    return prism_rtl::make_rc<CheckColors>(st0_p0);
}


/// LeqDiag: fn CLeq, Col, Col -> CDiag
crate::check::errors::CDiag leq_diag(const crate::check::types::CLeq& c_p0, const crate::check::types::Col& lo_p1, const crate::check::types::Col& hi_p2) {
    return c_p0.kind == Text::lit("lifted")
        ? crate::check::errors::diag_fix(Text::lit("lifted-unbounded"), c_p0.file, c_p0.span, prism_rtl::cat(col_word(lo_p1), " `", c_p0.name, "` lifted over `", c_p0.why, "`; use `@Run`"), prism_rtl::cat("run it through `!done <- @Run ", c_p0.name, ", ...`"))
        : c_p0.kind == Text::lit("arg")
        ? crate::check::errors::diag_fix(Text::lit("calls-unbounded"), c_p0.file, c_p0.span, prism_rtl::cat(col_word(hi_p2), " `", c_p0.name, "` takes a ", col_word(hi_p2), " closure; this one is ", col_word(lo_p1)), Text::lit("mark the parameter `unbounded fn`, or run the work through `@Run`"))
        : c_p0.kind == Text::lit("lambda")
        ? crate::check::errors::diag_fix(Text::lit("calls-unbounded"), c_p0.file, c_p0.span, prism_rtl::cat("this ", col_word(hi_p2), " lambda calls ", col_word(lo_p1), " `", c_p0.why, "`"), Text::lit("mark the function type it meets `unbounded fn`, or run the call through `@Run`"))
        : crate::check::errors::diag_fix(Text::lit("calls-unbounded"), c_p0.file, c_p0.span, prism_rtl::cat(col_word(hi_p2), " `", c_p0.name, "` calls ", col_word(lo_p1), " `", c_p0.why, "`"), prism_rtl::cat("mark `", c_p0.name, "` `unbounded fn`, or run the call through `@Run`"));
}


/// SettleBody: unbounded fn St, Col, Text -> St
crate::check::types::St settle_body(const crate::check::types::St& st0_p0, const crate::check::types::Col& col_p1, const Text& name_p2) {
    auto st_p3 = propagate(st0_p0, false);
    auto waiting_p4 = prism_rtl::deref(st_p3).color_flex;
    auto cleared_p5 = ({
        crate::check::types::St this_ = st_p3;
        this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
        (std::move(this_));
    });
    return run_to_end(fold_job(waiting_p4, cleared_p5, ({
        auto col_p1_1 = col_p1;
        auto name_p2_2 = name_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>)>>(prism_rtl::rc([=, col_p1_1 = std::move(col_p1_1), name_p2_2 = std::move(name_p2_2)](std::tuple<crate::check::types::St, std::tuple<crate::check::types::Col, Text, crate::syntax::Range>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto col_p1_1_3 = col_p1_1;
            auto name_p2_2_3 = name_p2_2;
            entered(once_job([=, col_p1_1_3 = std::move(col_p1_1_3), name_p2_2_3 = std::move(name_p2_2_3)]() {
            return ({
                auto s_p6 = p0;
                auto [c_p7, why_p8, span_p9] = p1;
                call_then(start_walk_col(s_p6, c_p7), [=](crate::check::types::Col walk_col_9404) {
                return ({
                    prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_9404) ? ({
                    auto&& n_pa = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_9404).a0;
                    prism_rtl::more(prism_rtl::rc(AddLeq(s_p6, crate::check::types::Col(crate::check::types::Col::CFlex{n_pa}), col_p1_1_3, span_p9, name_p2_2_3 == Text::lit("") ? Text::lit("lambda") : Text::lit("body"), name_p2_2_3, why_p8)));
                })
                    : ({
                    auto&& known_pb = walk_col_9404;
                    prism_rtl::finished(join_known(s_p6, known_pb, why_p8));
                });
                });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> SettleBody::cycle() const {
    const auto& st0_p0 = this->st0_p0;
    const auto& col_p1 = this->col_p1;
    const auto& name_p2 = this->name_p2;
    auto col_p1_1 = col_p1;
    auto name_p2_2 = name_p2;
    auto st0_p0_3 = st0_p0;
    return call_then(start_propagate(st0_p0_3, false), [=](crate::check::types::St propagate_9238) {
        return ({
            auto st_p3 = propagate_9238;
            auto waiting_p4 = prism_rtl::deref(st_p3).color_flex;
            auto cleared_p5 = ({
                crate::check::types::St this_ = st_p3;
                this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
                (std::move(this_));
            });
            fold_job(waiting_p4, cleared_p5, ({
            auto col_p1_1_4 = col_p1_1;
            auto name_p2_2_4 = name_p2_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>)>>(prism_rtl::rc([=, col_p1_1_4 = std::move(col_p1_1_4), name_p2_2_4 = std::move(name_p2_2_4)](std::tuple<crate::check::types::St, std::tuple<crate::check::types::Col, Text, crate::syntax::Range>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto col_p1_1_4_4 = col_p1_1_4;
                auto name_p2_2_4_4 = name_p2_2_4;
                entered(once_job([=, col_p1_1_4_4 = std::move(col_p1_1_4_4), name_p2_2_4_4 = std::move(name_p2_2_4_4)]() {
                return ({
                    auto s_p6 = p0;
                    auto [c_p7, why_p8, span_p9] = p1;
                    call_then(start_walk_col(s_p6, c_p7), [=](crate::check::types::Col walk_col_9404) {
                    return ({
                        prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_9404) ? ({
                        auto&& n_pa = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_9404).a0;
                        prism_rtl::more(prism_rtl::rc(AddLeq(s_p6, crate::check::types::Col(crate::check::types::Col::CFlex{n_pa}), col_p1_1_4_4, span_p9, name_p2_2_4_4 == Text::lit("") ? Text::lit("lambda") : Text::lit("body"), name_p2_2_4_4, why_p8)));
                    })
                        : ({
                        auto&& known_pb = walk_col_9404;
                        prism_rtl::finished(join_known(s_p6, known_pb, why_p8));
                    });
                    });
                });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start SettleBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_settle_body(crate::check::types::St st0_p0, crate::check::types::Col col_p1, Text name_p2) {
    return prism_rtl::make_rc<SettleBody>(st0_p0, col_p1, name_p2);
}

}  // namespace crate::check::types::colors
