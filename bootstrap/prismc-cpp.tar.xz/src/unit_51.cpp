// The module `Lower.Node.Finish`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/node_/finish/module.hpp>
#include <lower/node_/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Node.Finish`, from `target/bootstrap/cpp-src/prismc/lower/node/finish.prism`.
namespace crate::lower::node_::finish {



/// Heights: fn [Gn] -> [Gn]
Array<crate::lower::node_::Gn> heights(const Array<crate::lower::node_::Gn>& gns_p0) {
    return fold(gns_p0, gns_p0, [&](const Array<crate::lower::node_::Gn>& cur_p1, const crate::lower::node_::Gn& _p1) { return each(cur_p1, [&](const crate::lower::node_::Gn& n_p2) { return height_step(cur_p1, n_p2); }); });
}


/// HeightStep: fn [Gn], Gn -> Gn
crate::lower::node_::Gn height_step(const Array<crate::lower::node_::Gn>& gns_p0, const crate::lower::node_::Gn& n_p1) {
    auto feeders_p2 = filter(gns_p0, [&](const crate::lower::node_::Gn& m_p5) { return fold(prism_rtl::deref(m_p5).outs, false, [&](const bool& f_p6, const crate::lower::node_::Out& o_p7) { return prism_rtl::deref(f_p6) || feeds(prism_rtl::deref(o_p7).sink, n_p1); }); });
    auto top_p3 = fold(feeders_p2, Nat(0u), [&](const Nat& hi_p8, const crate::lower::node_::Gn& m_p9) { return crate::prelude::max(hi_p8, prism_rtl::deref(m_p9).height); });
    auto h_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = n_p1.kind;
        if (prism_rtl::is<crate::lower::node_::GnKind::GnNamed>(_m)) {
            _v.set(top_p3);
            goto _done;
        }
        {
            auto&& kind_pa = _m;
            _v.set(is_comb(kind_pa)
                ? crate::prelude::max(top_p3 + Nat(1u), n_p1.floor)
                : n_p1.height);
            goto _done;
        }
    _done:
        _v.take();
    });
    crate::lower::node_::Gn this_ = n_p1;
    this_.height = h_p4;
    return this_;
}


/// IsComb: fn GnKind -> Bool
bool is_comb(const crate::lower::node_::GnKind& k_p0) {
    if (prism_rtl::is<crate::lower::node_::GnKind::GnMerge>(k_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnUnion>(k_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnBoth>(k_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnExcept>(k_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnMergeAll>(k_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnUpdated>(k_p0)) {
        return true;
    }
    {
        return false;
    }
}


/// Feeds: fn Sk, Gn -> Bool
bool feeds(const crate::lower::node_::Sk& sk0, const crate::lower::node_::Gn& n_p1) {
    if (prism_rtl::is<crate::lower::node_::Sk::SkNode>(sk0)) {
        auto&& m_p0 = prism_rtl::as<crate::lower::node_::Sk::SkNode>(sk0).a0;
        return m_p0 == n_p1.id;
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkIn>(sk0)) {
        auto&& m_p2 = prism_rtl::as<crate::lower::node_::Sk::SkIn>(sk0).a0;
        return m_p2 == n_p1.id;
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkCycle>(sk0)) {
        auto&& m_p4 = prism_rtl::as<crate::lower::node_::Sk::SkCycle>(sk0).a2;
        return m_p4 == n_p1.id;
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkMachine>(sk0)) {
        auto&& f_p6 = prism_rtl::as<crate::lower::node_::Sk::SkMachine>(sk0).a0;
        auto&& m_p7 = prism_rtl::as<crate::lower::node_::Sk::SkMachine>(sk0).a2;
        return (m_p7 == n_p1.id) || writes(f_p6, n_p1);
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkHold>(sk0)) {
        auto&& f_p9 = prism_rtl::as<crate::lower::node_::Sk::SkHold>(sk0).a0;
        return writes(f_p9, n_p1);
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkDistinct>(sk0)) {
        auto&& f_pb = prism_rtl::as<crate::lower::node_::Sk::SkDistinct>(sk0).a0;
        return writes(f_pb, n_p1);
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkPerKey>(sk0)) {
        auto&& f_pd = prism_rtl::as<crate::lower::node_::Sk::SkPerKey>(sk0).a0;
        return writes(f_pd, n_p1);
    }
    {
        auto&& other_pf = sk0;
        return false;
    }
}


/// Writes: fn Text, Gn -> Bool
bool writes(const Text& f_p0, const crate::lower::node_::Gn& n_p1) {
    return moves(crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{f_p0}), n_p1);
}


/// Moves: fn Read, Gn -> Bool
bool moves(const crate::lower::node_::Read& r_p0, const crate::lower::node_::Gn& n_p1) {
    return (n_p1.kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUpdated{})) && crate::lower::node_::has_read(n_p1.reads, r_p0);
}


/// ReadsClosed: fn (Text ==> [Read]), [Read] -> [Read]
Array<crate::lower::node_::Read> reads_closed(const Map<Text, Array<crate::lower::node_::Read>>& dyn_p0, const Array<crate::lower::node_::Read>& reads_p1) {
    return fold(crate::check::errors::range0(Nat(4u)), reads_p1, [&](const Array<crate::lower::node_::Read>& acc_p2, const Nat& _p1) { return fold(acc_p2, acc_p2, [&](const Array<crate::lower::node_::Read>& a_p3, const crate::lower::node_::Read& r_p4) { return crate::lower::node_::union_reads(a_p3, getter_reads(dyn_p0, r_p4)); }); });
}


/// GetterReads: fn (Text ==> [Read]), Read -> [Read]
Array<crate::lower::node_::Read> getter_reads(const Map<Text, Array<crate::lower::node_::Read>>& dyn_p0, const crate::lower::node_::Read& read1) {
    if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(read1)) {
        auto&& n_p1 = prism_rtl::as<crate::lower::node_::Read::OwnRead>(read1).a0;
        return or_(crate::prelude::get(dyn_p0, n_p1), Array<crate::lower::node_::Read>{});
    }
    if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(read1)) {
        return Array<crate::lower::node_::Read>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ReachesSnap: fn [Text], [Read] -> Bool
bool reaches_snap(const Array<Text>& roots_p0, const Array<crate::lower::node_::Read>& reads_p1) {
    return fold(reads_p1, false, [&](const bool& f_p2, const crate::lower::node_::Read& r_p3) {
        return prism_rtl::deref(f_p2) || ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r_p3)) {
                auto&& n_p4 = prism_rtl::as<crate::lower::node_::Read::OwnRead>(r_p3).a0;
                _v.set(crate::check::types::has_text(roots_p0, n_p4));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r_p3)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// SnapNames: fn Wx -> [Text]
Array<Text> snap_names(const crate::lower::node_::Wx& wx_p0) {
    return each(wx_p0.snaps, [&](const crate::lower::node_::SnapDef& sn_p1) { return prism_rtl::deref(sn_p1).name; });
}


/// WakeConst: fn [Nat], Nat -> Text
Text wake_const(const Array<Nat>& heights_p0, const Nat& h_p1) {
    return len(heights_p0) <= Nat(1u)
        ? Text::lit("WAKE")
        : prism_rtl::cat("WAKE_", h_p1);
}


/// SelfCall: fn Text, [Ex] -> Do
crate::lower::model::Do self_call(const Text& m_p0, const Array<crate::lower::model::Ex>& args_p1) {
    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), m_p0, crate::prelude::push(args_p1, crate::lower::model::Ex(crate::lower::model::Ex::XCx{}))})});
}


/// SinkCode: fn Sinks, Sk, Ex -> [Do]
Array<crate::lower::model::Do> sink_code(const Sinks& sk_p0, const crate::lower::node_::Sk& target_p1, const crate::lower::model::Ex& y_p2) {
    if (prism_rtl::is<crate::lower::node_::Sk::SkNode>(target_p1)) {
        auto&& m_p3 = prism_rtl::as<crate::lower::node_::Sk::SkNode>(target_p1).a0;
        return Array(std::vector{self_call(prism_rtl::deref(crate::lower::node_::gn_of(sk_p0.wx, m_p3)).name, Array(std::vector{y_p2}))});
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkIn>(target_p1)) {
        auto&& m_p4 = prism_rtl::as<crate::lower::node_::Sk::SkIn>(target_p1).a0;
        auto&& i_p5 = prism_rtl::as<crate::lower::node_::Sk::SkIn>(target_p1).a1;
        auto g_p6 = crate::lower::node_::gn_of(sk_p0.wx, m_p4);
        return append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(or_(index(prism_rtl::deref(g_p6).inputs, i_p5), Text::lit("")))})), Text::lit("set"), Array(std::vector{y_p2, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), ask_wake(sk_p0, prism_rtl::deref(g_p6).height));
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkHold>(target_p1)) {
        auto&& f_p7 = prism_rtl::as<crate::lower::node_::Sk::SkHold>(target_p1).a0;
        return append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f_p7)})), Text::lit("set"), Array(std::vector{y_p2, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), hold_written(sk_p0, f_p7));
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkDistinct>(target_p1)) {
        auto&& f_p8 = prism_rtl::as<crate::lower::node_::Sk::SkDistinct>(target_p1).a0;
        auto differs_p9 = crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("!="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f_p8)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(y_p2)})})}))});
        auto write_pa = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f_p8)})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(y_p2)})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{differs_p9, append(Array(std::vector{write_pa}), hold_written(sk_p0, f_p8)), Array<crate::lower::model::Do>{}})});
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkPerKey>(target_p1)) {
        auto&& f_pb = prism_rtl::as<crate::lower::node_::Sk::SkPerKey>(target_p1).a0;
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f_pb)})), Text::lit("written"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(y_p2)}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), hold_written(sk_p0, f_pb), Array<crate::lower::model::Do>{}})});
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkRequest>(target_p1)) {
        auto&& pos_pc = prism_rtl::as<crate::lower::node_::Sk::SkRequest>(target_p1).a0;
        auto&& field_pd = prism_rtl::as<crate::lower::node_::Sk::SkRequest>(target_p1).a1;
        auto field_ex_pe = field_pd == Text::lit("")
            ? crate::lower::model::Ex(crate::lower::model::Ex::XNone{})
            : crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{field_pd})})});
        return emits(sk_p0.wx, pos_pc)
            ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("request"), Array(std::vector{place_at(sk_p0.wx, Text::lit("self"), pos_pc), field_ex_pe, crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(y_p2), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})})})
            : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("requested")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(host_field_ex(sk_p0.wx, pos_pc)), Text::lit("request"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(place_at(sk_p0.wx, Text::lit("self"), pos_pc))}), field_ex_pe, crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(y_p2), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("keep"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("requested")})})})})});
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkResult>(target_p1)) {
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("result"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Outcome::Fired"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(y_p2), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})})})})});
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkArm>(target_p1)) {
        auto&& f_pf = prism_rtl::as<crate::lower::node_::Sk::SkArm>(target_p1).a0;
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f_pf)})), Text::lit("arm"), Array(std::vector{y_p2, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})});
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkMachine>(target_p1)) {
        auto&& f_pg = prism_rtl::as<crate::lower::node_::Sk::SkMachine>(target_p1).a0;
        auto&& step_ph = prism_rtl::as<crate::lower::node_::Sk::SkMachine>(target_p1).a1;
        auto&& out_pi = prism_rtl::as<crate::lower::node_::Sk::SkMachine>(target_p1).a2;
        auto stepped_pj = crate::lower::model::Ex(crate::lower::model::Ex::XCall{step_ph, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), f_pg})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(y_p2)})})});
        return append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("machine_s")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("machine_b")})})}), stepped_pj}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f_pg)})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("machine_s")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}), crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("machine_b")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("machine_b")}), Array(std::vector{self_call(prism_rtl::deref(crate::lower::node_::gn_of(sk_p0.wx, out_pi)).name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("machine_b")})}))}), Array<crate::lower::model::Do>{}})}), moved_marks(sk_p0, f_pg));
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkPort>(target_p1)) {
        auto&& f_pk = prism_rtl::as<crate::lower::node_::Sk::SkPort>(target_p1).a0;
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f_pk, "_port")})), Text::lit("fire"), Array(std::vector{y_p2, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("ok"), Array<crate::lower::model::Ex>{}})})});
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkUp>(target_p1)) {
        auto&& m_pl = prism_rtl::as<crate::lower::node_::Sk::SkUp>(target_p1).a0;
        auto keyed_pm = len(filter(prism_rtl::deref(sk_p0.wx).fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
            auto&& f_po = std::get<0>(_p0);
            return f_po == Text::lit("key");
        })) > Nat(0u);
        auto args_pn = std::move(keyed_pm)
            ? Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("key")}))}), y_p2, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})
            : Array(std::vector{y_p2, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})});
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("parent")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("parent")}))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})), m_pl, args_pn})})}), Array<crate::lower::model::Do>{}})});
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkCycle>(target_p1)) {
        auto&& job_pp = prism_rtl::as<crate::lower::node_::Sk::SkCycle>(target_p1).a0;
        auto&& again_pq = prism_rtl::as<crate::lower::node_::Sk::SkCycle>(target_p1).a1;
        auto&& res_pr = prism_rtl::as<crate::lower::node_::Sk::SkCycle>(target_p1).a2;
        auto more_ps = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(job_pp)})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("next")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(again_pq)})), Text::lit("arm"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})});
        auto fin_pt = Array(std::vector{self_call(prism_rtl::deref(crate::lower::node_::gn_of(sk_p0.wx, res_pr)).name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("b")})}))});
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoMatch{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(job_pp)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("cycle"), Array<crate::lower::model::Ex>{}}), Array(std::vector{std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("prism_rtl::Turn::More"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("next")})})}), more_ps}, std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("b")})})}), fin_pt}})})});
    }
    prism_rtl::unreachable("no arm matched");
}


/// HoldWritten: fn Sinks, Text -> [Do]
Array<crate::lower::model::Do> hold_written(const Sinks& sk_p0, const Text& f_p1) {
    auto r_p2 = crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{f_p1});
    auto read_by_place_p3 = crate::lower::node_::has_read(sk_p0.dirty, r_p2);
    auto dirty_p4 = std::move(read_by_place_p3)
        ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("dirty"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})})})})
        : Array<crate::lower::model::Do>{};
    auto told_p5 = Array<crate::lower::model::Do>{};
    auto stales_p6 = fold(prism_rtl::deref(sk_p0.wx).gen_holds, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc_pb, const std::tuple<Text, Array<crate::lower::node_::Read>>& _p1) {
        auto&& gname_pc = std::get<0>(_p1);
        auto&& hs_pd = std::get<1>(_p1);
        return crate::lower::node_::has_read(reads_closed(prism_rtl::deref(sk_p0.wx).dyn_reads, hs_pd), r_p2)
            ? crate::prelude::push(acc_pb, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gname_pc, "_stale")})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{true})})})}))
            : acc_pb;
    });
    auto row_marks_p7 = fold(prism_rtl::deref(sk_p0.wx).row_marks, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc_pe, const crate::lower::node_::RowMarks& rm_pf) { return append(acc_pe, row_written(sk_p0.wx, rm_pf, r_p2)); });
    auto builds_p8 = crate::lower::node_::has_read(sk_p0.builds, r_p2) || (len(stales_p6) > Nat(0u));
    auto rebuild_it_p9 = std::move(builds_p8) && (!lists_build(sk_p0, r_p2))
        ? append(stales_p6, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("build_later"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})})})}))
        : stales_p6;
    auto gathered_pa = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
        auto&& _m = prism_rtl::deref(sk_p0.wx).result_moved;
        if (prism_rtl::is_some(_m)) {
            auto&& m_pg = std::get<0>(prism_rtl::some_of(_m));
            auto&& rds_ph = std::get<1>(prism_rtl::some_of(_m));
            _v.set(crate::lower::node_::has_read(rds_ph, r_p2)
                ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("parent")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("parent")}))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})), m_pg, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), Array<crate::lower::model::Do>{}})})
                : Array<crate::lower::model::Do>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<crate::lower::model::Do>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return append(append(append(append(append(dirty_p4, told_p5), rebuild_it_p9), row_marks_p7), gathered_pa), moved_marks(sk_p0, f_p1));
}


/// HostFieldEx: fn Wx, Pos -> Ex
crate::lower::model::Ex host_field_ex(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::Pos_& pos_p1) {
    return crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), crate::lower::node_::elements::host_local(wx_p0, pos_p1)});
}


/// MovedMarks: fn Sinks, Text -> [Do]
Array<crate::lower::model::Do> moved_marks(const Sinks& sk_p0, const Text& f_p1) {
    return moved_by(sk_p0, crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{f_p1}));
}


/// MovedBy: fn Sinks, Read -> [Do]
Array<crate::lower::model::Do> moved_by(const Sinks& sk_p0, const crate::lower::node_::Read& r_p1) {
    auto moved_p2 = filter(prism_rtl::deref(sk_p0.wx).gns, [&](const crate::lower::node_::Gn& g_p9) { return moves(r_p1, g_p9); });
    auto flags_p3 = each(moved_p2, [&](const crate::lower::node_::Gn& g_pa) { return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(prism_rtl::deref(g_pa).name, "_moved")})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{true})})})}); });
    auto heights_p4 = sort_nats(fold(moved_p2, Array<Nat>{}, [&](const Array<Nat>& acc_pb, const crate::lower::node_::Gn& g_pc) { return crate::check::types::add_nat(acc_pb, prism_rtl::deref(g_pc).height); }));
    auto marks_p5 = each(snaps_behind(sk_p0.wx, r_p1), [&](const crate::lower::node_::SnapDef& sn_pd) { return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(prism_rtl::deref(sn_pd).name, "_snap")})), Text::lit("mark"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}); });
    auto listed_p6 = lists_build(sk_p0, r_p1)
        ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("build_later"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})})})})
        : Array<crate::lower::model::Do>{};
    auto answers_p7 = each(filter(prism_rtl::deref(sk_p0.wx).dyn_answers, [&](const std::tuple<Text, Array<crate::lower::node_::Read>>& _p0) {
        auto&& rds_pe = std::get<1>(_p0);
        return crate::lower::node_::has_read(reads_closed(prism_rtl::deref(sk_p0.wx).dyn_reads, rds_pe), r_p1);
    }), [&](const std::tuple<Text, Array<crate::lower::node_::Read>>& _p0) {
        auto&& name_pf = std::get<0>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(name_pf, "_port")})), Text::lit("fire"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("ok"), Array<crate::lower::model::Ex>{}})});
    });
    auto adoptions_p8 = each(filter(prism_rtl::deref(sk_p0.wx).flattens, [&](const crate::lower::node_::FlatDef& fl_pg) { return (fl_pg->generation != Text::lit("")) && (r_p1 == crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{prism_rtl::deref(fl_pg).outer})); }), [&](const crate::lower::node_::FlatDef& fl_ph) { return crate::lower::model::Do(crate::lower::model::Do::DoScope{adoption(fl_ph)}); });
    return append(append(append(append(append(fold(heights_p4, flags_p3, [&](const Array<crate::lower::model::Do>& acc_pi, const Nat& h_pj) { return append(acc_pi, ask_wake(sk_p0, h_pj)); }), marks_p5), listed_p6), answers_p7), adoptions_p8), source_marks(sk_p0.wx, r_p1));
}


/// SourceMarks: fn Wx, Read -> [Do]
Array<crate::lower::model::Do> source_marks(const crate::lower::node_::Wx& wx_p0, const crate::lower::node_::Read& r_p1) {
    auto fors_p2 = fold(wx_p0.builders, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc_p3, const crate::lower::model::ForDef& b_p4) {
        return crate::lower::node_::has_read(reads_closed(wx_p0.dyn_reads, or_(crate::prelude::get(wx_p0.dyn_reads, b_p4->source), Array<crate::lower::node_::Read>{})), r_p1)
            ? crate::prelude::push(acc_p3, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(b_p4->source, "_cache")})), Text::lit("mark"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}))
            : acc_p3;
    });
    return fold(wx_p0.let_caches, fors_p2, [&](const Array<crate::lower::model::Do>& acc_p5, const Text& c_p6) {
        return crate::lower::node_::has_read(reads_all(wx_p0.dyn_reads, or_(crate::prelude::get(wx_p0.dyn_reads, c_p6), Array<crate::lower::node_::Read>{})), r_p1)
            ? crate::prelude::push(acc_p5, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(c_p6, "_cache")})), Text::lit("mark"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}))
            : acc_p5;
    });
}


/// ReadsAll: fn (Text ==> [Read]), [Read] -> [Read]
Array<crate::lower::node_::Read> reads_all(const Map<Text, Array<crate::lower::node_::Read>>& dyn_p0, const Array<crate::lower::node_::Read>& reads_p1) {
    return fold(crate::check::errors::range0(crate::prelude::size(dyn_p0) + Nat(1u)), reads_p1, [&](const Array<crate::lower::node_::Read>& acc_p2, const Nat& _p1) { return fold(acc_p2, acc_p2, [&](const Array<crate::lower::node_::Read>& a_p3, const crate::lower::node_::Read& r_p4) { return crate::lower::node_::union_reads(a_p3, getter_reads(dyn_p0, r_p4)); }); });
}


/// IsOwnRead: fn Read -> Bool
bool is_own_read(const crate::lower::node_::Read& r_p0) {
    if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r_p0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// SnapsBehind: fn Wx, Read -> [SnapDef]
Array<crate::lower::node_::SnapDef> snaps_behind(const crate::lower::node_::Wx& wx_p0, const crate::lower::node_::Read& r_p1) {
    return filter(wx_p0.snaps, [&](const crate::lower::node_::SnapDef& sn_p2) { return (r_p1 == crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{prism_rtl::deref(sn_p2).live})) || crate::lower::node_::has_read(reads_closed(wx_p0.dyn_reads, Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{prism_rtl::deref(sn_p2).live})})), r_p1); });
}


/// ListsBuild: fn Sinks, Read -> Bool
bool lists_build(const Sinks& sk_p0, const crate::lower::node_::Read& r_p1) {
    return len(snaps_behind(sk_p0.wx, r_p1)) > Nat(0u);
}


/// FiringCode: unbounded fn Sinks, Gn, Ex -> [Do]
Array<crate::lower::model::Do> firing_code(const Sinks& sk_p0, const crate::lower::node_::Gn& g_p1, const crate::lower::model::Ex& x_p2) {
    auto many_p3 = (len(g_p1.outs) > Nat(1u)) && (!crate::lower::types::is_copy(g_p1.ty));
    auto xv_p4 = std::move(many_p3)
        ? crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(x_p2)})
        : x_p2;
    return run_to_end(fold_job(g_p1.outs, Array<crate::lower::model::Do>{}, ({
        auto xv_p4_1 = xv_p4;
        auto sk_p0_2 = sk_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, crate::lower::node_::Out>)>>(prism_rtl::rc([=, xv_p4_1 = std::move(xv_p4_1), sk_p0_2 = std::move(sk_p0_2)](std::tuple<Array<crate::lower::model::Do>, crate::lower::node_::Out> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xv_p4_1_3 = xv_p4_1;
            auto sk_p0_2_3 = sk_p0_2;
            entered(once_job([=, xv_p4_1_3 = std::move(xv_p4_1_3), sk_p0_2_3 = std::move(sk_p0_2_3)]() {
            return ({
                auto acc_p5 = p0;
                auto o_p6 = p1;
                call_value(prism_rtl::deref(o_p6).pipe(std::tuple{xv_p4_1_3, ({
                auto sk_p0_2_3_3 = sk_p0_2_3;
                auto o_p6_3 = o_p6;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=, sk_p0_2_3_3 = std::move(sk_p0_2_3_3), o_p6_3 = std::move(o_p6_3)](crate::lower::model::Ex p0) {
                return ({
                    auto sk_p0_2_3_3_4 = sk_p0_2_3_3;
                    auto o_p6_3_4 = o_p6_3;
                    once_job([=, sk_p0_2_3_3_4 = std::move(sk_p0_2_3_3_4), o_p6_3_4 = std::move(o_p6_3_4)]() {
                    return ({
                        auto y_p7 = p0;
                        (prism_rtl::finished(sink_code(sk_p0_2_3_3_4, prism_rtl::deref(o_p6_3_4).sink, y_p7)));
                    });
                });
                });
            })));
            })}), [=, acc_p5 = std::move(acc_p5)](Array<crate::lower::model::Do> call_13560) { return prism_rtl::finished(append(acc_p5, call_13560)); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Do>> FiringCode::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& g_p1 = this->g_p1;
    const auto& x_p2 = this->x_p2;
    auto many_p3 = (len(prism_rtl::deref(g_p1).outs) > Nat(1u)) && (!crate::lower::types::is_copy(prism_rtl::deref(g_p1).ty));
    auto xv_p4 = std::move(many_p3)
        ? crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(x_p2)})
        : x_p2;
    return fold_job(prism_rtl::deref(g_p1).outs, Array<crate::lower::model::Do>{}, ({
        auto xv_p4_1 = xv_p4;
        auto sk_p0_2 = sk_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, crate::lower::node_::Out>)>>(prism_rtl::rc([=, xv_p4_1 = std::move(xv_p4_1), sk_p0_2 = std::move(sk_p0_2)](std::tuple<Array<crate::lower::model::Do>, crate::lower::node_::Out> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xv_p4_1_3 = xv_p4_1;
            auto sk_p0_2_3 = sk_p0_2;
            entered(once_job([=, xv_p4_1_3 = std::move(xv_p4_1_3), sk_p0_2_3 = std::move(sk_p0_2_3)]() {
            return ({
                auto acc_p5 = p0;
                auto o_p6 = p1;
                call_value(prism_rtl::deref(o_p6).pipe(std::tuple{xv_p4_1_3, ({
                auto sk_p0_2_3_3 = sk_p0_2_3;
                auto o_p6_3 = o_p6;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=, sk_p0_2_3_3 = std::move(sk_p0_2_3_3), o_p6_3 = std::move(o_p6_3)](crate::lower::model::Ex p0) {
                return ({
                    auto sk_p0_2_3_3_4 = sk_p0_2_3_3;
                    auto o_p6_3_4 = o_p6_3;
                    once_job([=, sk_p0_2_3_3_4 = std::move(sk_p0_2_3_3_4), o_p6_3_4 = std::move(o_p6_3_4)]() {
                    return ({
                        auto y_p7 = p0;
                        (prism_rtl::finished(sink_code(sk_p0_2_3_3_4, prism_rtl::deref(o_p6_3_4).sink, y_p7)));
                    });
                });
                });
            })));
            })}), [=, acc_p5 = std::move(acc_p5)](Array<crate::lower::model::Do> call_13560) { return prism_rtl::finished(append(acc_p5, call_13560)); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start FiringCode, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Do>> start_firing_code(Sinks sk_p0, crate::lower::node_::Gn g_p1, crate::lower::model::Ex x_p2) {
    return prism_rtl::make_rc<FiringCode>(sk_p0, g_p1, x_p2);
}


/// FinishNode: unbounded fn Wx, Text, [((Text, OutTy))], Bool -> NodeDef
crate::lower::model::NodeDef finish_node(const crate::lower::node_::Wx& wx0_p0, const Text& qk_p1, const Array<std::tuple<Text, crate::lower::model::OutTy>>& params_p2, const bool& is_row_p3) {
    auto closed_gns_p4 = each(wx0_p0.gns, [&](const crate::lower::node_::Gn& g_p1j) {
        return prism_rtl::deref(g_p1j).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUpdated{})
            ? crate::lower::node_::dynamics::with_reads(g_p1j, reads_closed(wx0_p0.dyn_reads, prism_rtl::deref(g_p1j).reads))
            : g_p1j;
    });
    auto [row_defs_p1k, gns2_p1l] = finish_pending(wx0_p0, heights(closed_gns_p4));
    auto is_gen_p5 = is_row_p3 && (len(filter(wx0_p0.fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_p1m = std::get<0>(_p0);
        return f_p1m == Text::lit("key");
    })) == Nat(0u));
    auto wx_p6 = ({
        crate::lower::node_::Wx this_ = wx0_p0;
        this_.gns = heights(gns2_p1l);
        this_.build = append(this_.build, updated_gaps(wx0_p0, closed_gns_p4, is_gen_p5));
        this_.rows = fold(row_defs_p1k, this_.rows, [&](const Array<crate::lower::model::NodeDef>& acc_p1n, const crate::lower::model::NodeDef& rd_p1o) { return append(crate::prelude::push(acc_p1n, rd_p1o), prism_rtl::deref(rd_p1o).children); });
        (std::move(this_));
    });
    auto combs_p7 = filter(prism_rtl::deref(wx_p6).gns, [&](const crate::lower::node_::Gn& g_p1p) { return is_comb(prism_rtl::deref(g_p1p).kind) || (prism_rtl::deref(g_p1p).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnGather{})); });
    auto heights_p8 = sort_nats(fold(combs_p7, Array<Nat>{}, [&](const Array<Nat>& acc_p1q, const crate::lower::node_::Gn& g_p1r) { return crate::check::types::add_nat(acc_p1q, prism_rtl::deref(g_p1r).height); }));
    auto many_p9 = len(heights_p8) > Nat(1u);
    auto consts_pa = each(heights_p8, [&](const Nat& h_p1s) { return std::tuple{wake_const(heights_p8, h_p1s), h_p1s, Text::lit("merges\' height above the node\'s inputs")}; });
    auto live_pb = filter(prism_rtl::deref(wx_p6).places, [&](const crate::lower::node_::Place& p_p1t) { return prism_rtl::deref(p_p1t).getter != Text::lit(""); });
    auto root_reads_pc = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::node_::Read>> _v;
        auto&& _m = prism_rtl::deref(wx_p6).root_dyn;
        if (prism_rtl::is_some(_m)) {
            auto&& rds_p1u = std::get<1>(prism_rtl::some_of(_m));
            _v.set(reads_closed(prism_rtl::deref(wx_p6).dyn_reads, rds_p1u));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<crate::lower::node_::Read>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto dirty_holds_pd = fold(live_pb, root_reads_pc, [&](const Array<crate::lower::node_::Read>& acc_p1v, const crate::lower::node_::Place& p_p20) { return crate::lower::node_::union_reads(acc_p1v, reads_closed(prism_rtl::deref(wx_p6).dyn_reads, prism_rtl::deref(p_p20).reads)); });
    auto build_holds_pe = reads_closed(prism_rtl::deref(wx_p6).dyn_reads, prism_rtl::deref(wx_p6).build_holds);
    auto sinks_pf = Sinks{.wx = wx_p6, .dirty = dirty_holds_pd, .builds = build_holds_pe, .heights = heights_p8, .many = std::move(many_p9)};
    auto ev_methods_pg = run_to_end(each_job(filter(prism_rtl::deref(wx_p6).gns, [&](const crate::lower::node_::Gn& g_p21) { return prism_rtl::deref(g_p21).kind != crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNever{}); }), ({
        auto sinks_pf_1 = sinks_pf;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::MethDef>(crate::lower::node_::Gn)>>(prism_rtl::rc([=, sinks_pf_1 = std::move(sinks_pf_1)](crate::lower::node_::Gn p0) {
        return ({
            auto sinks_pf_1_2 = sinks_pf_1;
            entered(once_job([=, sinks_pf_1_2 = std::move(sinks_pf_1_2)]() {
            return ({
                auto g_p22 = p0;
                call_then(start_firing_code(sinks_pf_1_2, g_p22, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})), [=](Array<crate::lower::model::Do> firing_code_15352) { return prism_rtl::finished(crate::lower::model::MethDef{.name = prism_rtl::deref(g_p22).name, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("v"), prism_rtl::deref(g_p22).ty}}), .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = firing_code_15352, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = gn_doc(g_p22)}); });
            });
        }));
        });
    })));
    })));
    auto gather_ins_ph = each(filter(prism_rtl::deref(wx_p6).gns, [&](const crate::lower::node_::Gn& g_p23) { return prism_rtl::deref(g_p23).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnGather{}); }), [&](const crate::lower::node_::Gn& g_p24) { return gather_in(sinks_pf, g_p24); });
    auto place_getters_pi = each(live_pb, [&](const crate::lower::node_::Place& p_p25) { return crate::lower::model::MethDef{.name = prism_rtl::deref(p_p25).getter, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = crate::lower::types::elem_ty(), .body = Array<crate::lower::model::Do>{}, .tail = prism_rtl::deref(p_p25).level, .doc = prism_rtl::cat("Place ", crate::lower::model::place_text(prism_rtl::deref(p_p25).pos), "\'s level, read at the read point.")}; });
    auto wake_body_pj = std::move(many_p9)
        ? Array(std::vector{wake_by_height(combs_p7, heights_p8)})
        : each(combs_p7, [&](const crate::lower::node_::Gn& g_p26) { return decide(g_p26); });
    auto started_body_pk = each(wx_p6->started, [&](const Nat& st_p27) { return self_call(prism_rtl::deref(crate::lower::node_::gn_of(wx_p6, st_p27)).name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})); });
    auto deferred_body_pl = each(prism_rtl::deref(wx_p6).defers, [&](const std::tuple<Text, Nat>& _p0) {
        auto&& f_p28 = std::get<0>(_p0);
        auto&& id_p29 = std::get<1>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f_p28)})), Text::lit("fired"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{self_call(prism_rtl::deref(crate::lower::node_::gn_of(wx_p6, id_p29)).name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}))}), Array<crate::lower::model::Do>{}});
    });
    auto patch_body0_pm = fold(live_pb, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc_p2a, const crate::lower::node_::Place& p_p2b) {
        return append(acc_p2a, emits(wx_p6, prism_rtl::deref(p_p2b).pos)
            ? patch_place(wx_p6, p_p2b)
            : Array(std::vector{entry_take(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}), p_p2b)}));
    });
    auto patch_body_pn = append(patch_body0_pm, root_dyn_patch(wx_p6));
    auto build_body_po = build_steps(sinks_pf, false);
    auto push_body_pp = each(filter(prism_rtl::deref(wx_p6).dyn_places, [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos_p2c = std::get<0>(_p0);
        return emits(wx_p6, pos_p2c);
    }), [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos_p2d = std::get<0>(_p0);
        auto&& f_p2e = std::get<1>(_p0);
        auto&& t_p2f = std::get<2>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("element")})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f_p2e, "_element")}))}))}), dyn_place_write(sinks_pf, f_p2e, crate::lower::model::Ex(crate::lower::model::Ex::XDecode{t_p2f, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))})), Array<crate::lower::model::Do>{}});
    });
    auto hooks_pq = filter(Array(std::vector{std::tuple{Text::lit("wake"), wake_body_pj}, std::tuple{Text::lit("started"), started_body_pk}, std::tuple{Text::lit("deferred"), deferred_body_pl}, std::tuple{Text::lit("build"), build_body_po}, std::tuple{Text::lit("push"), push_body_pp}, std::tuple{Text::lit("patch"), patch_body_pn}}), [&](const std::tuple<Text, Array<crate::lower::model::Do>>& _p0) {
        auto&& b_p2g = std::get<1>(_p0);
        return len(b_p2g) > Nat(0u);
    });
    auto started_reg_pr = len(wx_p6->started) > Nat(0u)
        ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("on_started"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})})})})})
        : Array<crate::lower::model::Do>{};
    auto links_ps = each(prism_rtl::deref(wx_p6).hosts, [&](const crate::lower::node_::HostDef& h_p2h) { return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(prism_rtl::deref(h_p2h).name)})), Text::lit("link"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})})})}); });
    auto rows_built_pt = append(links_ps, build_steps(sinks_pf, true));
    auto subscribed_pu = each(prism_rtl::deref(wx_p6).subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev_p2i = std::get<0>(_p0);
        auto&& m_p2j = std::get<1>(_p0);
        auto&& t_p2k = std::get<2>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("subscribe_row"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), Text::lit("parent")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("p")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("p")})), prism_rtl::cat(ev_p2i, "_port")}))}))}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("n")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("n")})), m_p2j, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(m_p2j, "_sub")}))})})})});
    });
    auto answers_pv = append(each(filter(prism_rtl::deref(wx_p6).answers, [&](const std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos_p2l = std::get<0>(_p0);
        return emits(wx_p6, pos_p2l);
    }), [&](const std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos_p2m = std::get<0>(_p0);
        auto&& id_p2n = std::get<1>(_p0);
        auto&& t_p2o = std::get<2>(_p0);
        return answer_arm(wx_p6, pos_p2m, id_p2n, t_p2o);
    }), each(filter(prism_rtl::deref(wx_p6).dyn_places, [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos_p2p = std::get<0>(_p0);
        return emits(wx_p6, pos_p2p);
    }), [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos_p2q = std::get<0>(_p0);
        auto&& f_p2r = std::get<1>(_p0);
        auto&& t_p2s = std::get<2>(_p0);
        return dyn_answer_arm(sinks_pf, pos_p2q, f_p2r, t_p2s);
    }));
    auto forwards_p10 = append(each(filter(prism_rtl::deref(wx_p6).builders, [&](const crate::lower::model::ForDef& b_p2t) { return emits(wx_p6, prism_rtl::deref(b_p2t).pos); }), [&](const crate::lower::model::ForDef& b_p2u) { return std::tuple{pos_pat(prism_rtl::deref(b_p2u).pos, key_tail()), forward_answer(b_p2u)}; }), fold(filter(prism_rtl::deref(wx_p6).gens, [&](const crate::lower::model::GenDef& gd_p2v) { return emits(wx_p6, prism_rtl::deref(gd_p2v).pos); }), Array<std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>>{}, [&](const Array<std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>>& acc_p30, const crate::lower::model::GenDef& gd_p31) { return append(acc_p30, crate::lower::node_::switch_::gen_forwards(gd_p31)); }));
    auto host_methods_p11 = fold(prism_rtl::deref(wx_p6).hosts, Array<crate::lower::model::MethDef>{}, [&](const Array<crate::lower::model::MethDef>& acc_p32, const crate::lower::node_::HostDef& h_p33) { return append(acc_p32, Array(std::vector{typed_dispatch(sinks_pf, prism_rtl::cat(prism_rtl::deref(h_p33).name, "_answer"), prism_rtl::deref(h_p33).scope), host_moved(sinks_pf, h_p33)})); });
    auto gathered_p12 = filter(prism_rtl::deref(wx_p6).snaps, [&](const crate::lower::node_::SnapDef& sn_p34) { return !(prism_rtl::deref(sn_p34).before || is_generation(wx_p6, prism_rtl::deref(sn_p34).builder)); });
    auto gathered_moved_p13 = append(append(each(gathered_p12, [&](const crate::lower::node_::SnapDef& sn_p35) { return gathered_moved(sn_p35); }), each(prism_rtl::deref(wx_p6).snaps, [&](const crate::lower::node_::SnapDef& sn_p36) { return snap_publish(sinks_pf, sn_p36); })), flatten_methods(sinks_pf));
    auto hosted_methods_p14 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::MethDef>> _v;
        auto&& _m = prism_rtl::deref(wx_p6).hosted_by;
        if (prism_rtl::is_some(_m)) {
            _v.set(Array(std::vector{typed_dispatch(sinks_pf, Text::lit("deliver"), Nat(0u)), document_getter(wx_p6)}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<crate::lower::model::MethDef>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto moved_method_p15 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::MethDef>> _v;
        auto&& _m = prism_rtl::deref(wx_p6).hosted_by;
        if (prism_rtl::is_some(_m)) {
            auto&& m_p37 = prism_rtl::some_of(_m);
            _v.set(Array(std::vector{crate::lower::node_::finish::document_moved(m_p37)}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<crate::lower::model::MethDef>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto row_methods_p16 = is_row_p3 ? row_methods(wx_p6) : Array<crate::lower::model::MethDef>{};
    auto heard_build_f17 = ({
        auto wx_p6_1 = wx_p6;
        auto sinks_pf_2 = sinks_pf;
        (static_cast<Fn<Array<crate::lower::model::Do>(const Text&)>>(prism_rtl::rc([=, wx_p6_1 = std::move(wx_p6_1), sinks_pf_2 = std::move(sinks_pf_2)](const Text& m_p38) {
        return ({
            auto stales_p39 = fold(prism_rtl::deref(wx_p6_1).gen_holds, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc_p3b, const std::tuple<Text, Array<crate::lower::node_::Read>>& _p1) {
                auto&& gname_p3c = std::get<0>(_p1);
                auto&& hs_p3d = std::get<1>(_p1);
                return crate::lower::node_::has_read(reads_closed(prism_rtl::deref(wx_p6_1).dyn_reads, hs_p3d), crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m_p38}))
                    ? crate::prelude::push(acc_p3b, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gname_p3c, "_stale")})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{true})})})}))
                    : acc_p3b;
            });
            auto builds_p3a = crate::lower::node_::has_read(prism_rtl::deref(sinks_pf_2).builds, crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m_p38})) || (len(stales_p39) > Nat(0u));
            std::move(builds_p3a) && (!lists_build(sinks_pf_2, crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m_p38})))
            ? append(stales_p39, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("build_later"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})})})}))
            : stales_p39;
        });
    })));
    });
    auto heard_p18 = each(row_hears(wx_p6), [&](const Text& m_p3e) { return crate::lower::model::MethDef{.name = prism_rtl::cat("parent_wrote_", m_p3e), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = append(append(moved_by(sinks_pf, crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m_p3e})), heard_build_f17(m_p3e)), fold(prism_rtl::deref(wx_p6).row_marks, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc_p3f, const crate::lower::node_::RowMarks& rm_p3g) { return append(acc_p3f, row_written(wx_p6, rm_p3g, crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m_p3e}))); })), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = prism_rtl::cat("The block wrote behind its `", m_p3e, "`, which this row reads through the parent: the `!Updated` nodes over it are told and the wake asked at their heights; the row\'s own builders over it are listed for the build; the rows of this row\'s own `for`s that read it are marked.")}; });
    auto top_p19 = fold(prism_rtl::deref(wx_p6).gns, Nat(0u), [&](const Nat& hi_p3h, const crate::lower::node_::Gn& g_p3i) { return crate::prelude::max(hi_p3h, prism_rtl::deref(g_p3i).height); });
    auto wakes_field_p1a = std::move(many_p9)
        ? Array(std::vector{std::tuple{Text::lit("wakes"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWakes{}), Text::lit("the heights asked for this tick, lowest first")}})
        : Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{};
    auto wakes_init_p1b = std::move(many_p9)
        ? Array(std::vector{std::tuple{Text::lit("wakes"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Wakes::default"), Array<crate::lower::model::Ex>{}})}})
        : Array<std::tuple<Text, crate::lower::model::Ex>>{};
    auto gen_fields_p1c = fold(prism_rtl::deref(wx_p6).gens, Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{}, [&](const Array<std::tuple<Text, crate::lower::model::OutTy, Text>>& acc_p3j, const crate::lower::model::GenDef& gd_p3k) { return append(acc_p3j, Array(std::vector{std::tuple{prism_rtl::deref(gd_p3k).name, crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Row"), Array<crate::lower::model::OutTy>{}}))}))}))}), prism_rtl::cat("the current generation of the `rebuild` at place ", crate::lower::model::place_text(prism_rtl::deref(gd_p3k).pos))}, std::tuple{prism_rtl::cat(prism_rtl::deref(gd_p3k).name, "_count"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutCount{})})}), Text::lit("how many generations it has built")}, std::tuple{prism_rtl::cat(prism_rtl::deref(gd_p3k).name, "_stale"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})}), Text::lit("its source changed since it was built")}})); });
    auto gen_inits_p1d = fold(prism_rtl::deref(wx_p6).gens, Array<std::tuple<Text, crate::lower::model::Ex>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Ex>>& acc_p3l, const crate::lower::model::GenDef& gd_p3m) { return append(acc_p3l, Array(std::vector{std::tuple{prism_rtl::deref(gd_p3m).name, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})}, std::tuple{prism_rtl::cat(prism_rtl::deref(gd_p3m).name, "_count"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{Nat(0u)})})})}, std::tuple{prism_rtl::cat(prism_rtl::deref(gd_p3m).name, "_stale"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false})})})}})); });
    auto port_fields_p1e = each(prism_rtl::deref(wx_p6).ports, [&](const Text& pn_p3n) { return std::tuple{prism_rtl::cat(pn_p3n, "_port"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutPort{prism_rtl::rc(crate::lower::node_::keyed::gn_ty_named(wx_p6, pn_p3n))}), prism_rtl::cat("`!", pn_p3n, "`, which rows subscribe to")}; });
    auto port_inits_p1f = each(prism_rtl::deref(wx_p6).ports, [&](const Text& pn_p3o) { return std::tuple{prism_rtl::cat(pn_p3o, "_port"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Port::new"), Array<crate::lower::model::Ex>{}})}; });
    auto sub_fields_p1g = each(prism_rtl::deref(wx_p6).subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev_p3p = std::get<0>(_p0);
        auto&& m_p3q = std::get<1>(_p0);
        auto&& t_p3r = std::get<2>(_p0);
        return std::tuple{prism_rtl::cat(m_p3q, "_sub"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Handle"), Array<crate::lower::model::OutTy>{}}))})})}), prism_rtl::cat("the subscription to the parent\'s `!", ev_p3p, "`")};
    });
    auto sub_inits_p1h = each(prism_rtl::deref(wx_p6).subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev_p3s = std::get<0>(_p0);
        auto&& m_p3t = std::get<1>(_p0);
        auto&& t_p3u = std::get<2>(_p0);
        return std::tuple{prism_rtl::cat(m_p3t, "_sub"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})};
    });
    auto fallible_p1i = ((prism_rtl::deref(wx_p6).fallible || is_row_p3) || (len(prism_rtl::deref(wx_p6).builders) > Nat(0u))) || (len(prism_rtl::deref(wx_p6).gens) > Nat(0u));
    return crate::lower::model::NodeDef{.name = prism_rtl::deref(wx_p6).node_, .prism = crate::check::types::bare_name(qk_p1), .doc = crate::lower::functions::definition_text(prism_rtl::deref(wx_p6).lx, qk_p1), .params = params_p2, .fields = append(append(append(append(prism_rtl::deref(wx_p6).fields, wakes_field_p1a), gen_fields_p1c), port_fields_p1e), sub_fields_p1g), .consts = consts_pa, .lets = prism_rtl::deref(wx_p6).lets, .inits = append(prism_rtl::deref(wx_p6).inits, append(append(append(append(prism_rtl::deref(wx_p6).moves, wakes_init_p1b), gen_inits_p1d), port_inits_p1f), sub_inits_p1h)), .build = append(append(append(rows_built_pt, wx_p6->build), subscribed_pu), started_reg_pr), .fallible = std::move(fallible_p1i), .methods = append(append(append(append(append(append(append(append(ev_methods_pg, gather_ins_ph), place_getters_pi), prism_rtl::deref(wx_p6).getters), row_methods_p16), heard_p18), host_methods_p11), gathered_moved_p13), moved_method_p15), .answers = append(answers_pv, forwards_p10), .hooks = hooks_pq, .builders = prism_rtl::deref(wx_p6).builders, .wakes = std::move(many_p9), .children = wx_p6->rows, .gens = prism_rtl::deref(wx_p6).gens, .subs = prism_rtl::deref(wx_p6).subs, .top = top_p19, .row_kind = is_row_p3
        ? std::move(is_gen_p5)
        ? crate::lower::model::RowKind(crate::lower::model::RowKind::GenerationRow{})
        : crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})
        : crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{}), .hosted = hosted_methods_p14};
}


prism_rtl::Turn<crate::lower::model::NodeDef> FinishNode::cycle() const {
    const auto& wx0_p0 = this->wx0_p0;
    const auto& qk_p1 = this->qk_p1;
    const auto& params_p2 = this->params_p2;
    const auto& is_row_p3 = this->is_row_p3;
    auto closed_gns_p4 = each(prism_rtl::deref(wx0_p0).gns, [&](const crate::lower::node_::Gn& g_p1j) {
        return prism_rtl::deref(g_p1j).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUpdated{})
            ? crate::lower::node_::dynamics::with_reads(g_p1j, reads_closed(prism_rtl::deref(wx0_p0).dyn_reads, prism_rtl::deref(g_p1j).reads))
            : g_p1j;
    });
    auto is_row_p3_1 = prism_rtl::deref(is_row_p3);
    auto params_p2_2 = params_p2;
    auto qk_p1_3 = qk_p1;
    auto wx0_p0_4 = wx0_p0;
    return call_then(start_finish_pending(wx0_p0_4, heights(closed_gns_p4)), [=](std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>> finish_pending_14117) {
        return ({
            auto [row_defs_p1k, gns2_p1l] = finish_pending_14117;
            auto is_gen_p5 = is_row_p3_1 && (len(filter(prism_rtl::deref(wx0_p0_4).fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
                auto&& f_p1m = std::get<0>(_p0);
                return f_p1m == Text::lit("key");
            })) == Nat(0u));
            auto wx_p6 = ({
                crate::lower::node_::Wx this_ = wx0_p0_4;
                this_.gns = heights(gns2_p1l);
                this_.build = append(this_.build, updated_gaps(wx0_p0_4, closed_gns_p4, is_gen_p5));
                this_.rows = fold(row_defs_p1k, this_.rows, [&](const Array<crate::lower::model::NodeDef>& acc_p1n, const crate::lower::model::NodeDef& rd_p1o) { return append(crate::prelude::push(acc_p1n, rd_p1o), prism_rtl::deref(rd_p1o).children); });
                (std::move(this_));
            });
            auto combs_p7 = filter(prism_rtl::deref(wx_p6).gns, [&](const crate::lower::node_::Gn& g_p1p) { return is_comb(prism_rtl::deref(g_p1p).kind) || (prism_rtl::deref(g_p1p).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnGather{})); });
            auto heights_p8 = sort_nats(fold(combs_p7, Array<Nat>{}, [&](const Array<Nat>& acc_p1q, const crate::lower::node_::Gn& g_p1r) { return crate::check::types::add_nat(acc_p1q, prism_rtl::deref(g_p1r).height); }));
            auto many_p9 = len(heights_p8) > Nat(1u);
            auto consts_pa = each(heights_p8, [&](const Nat& h_p1s) { return std::tuple{wake_const(heights_p8, h_p1s), h_p1s, Text::lit("merges\' height above the node\'s inputs")}; });
            auto live_pb = filter(prism_rtl::deref(wx_p6).places, [&](const crate::lower::node_::Place& p_p1t) { return prism_rtl::deref(p_p1t).getter != Text::lit(""); });
            auto root_reads_pc = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::node_::Read>> _v;
                auto&& _m = prism_rtl::deref(wx_p6).root_dyn;
                if (prism_rtl::is_some(_m)) {
                    auto&& rds_p1u = std::get<1>(prism_rtl::some_of(_m));
                    _v.set(reads_closed(prism_rtl::deref(wx_p6).dyn_reads, rds_p1u));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Array<crate::lower::node_::Read>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto dirty_holds_pd = fold(live_pb, root_reads_pc, [&](const Array<crate::lower::node_::Read>& acc_p1v, const crate::lower::node_::Place& p_p20) { return crate::lower::node_::union_reads(acc_p1v, reads_closed(prism_rtl::deref(wx_p6).dyn_reads, prism_rtl::deref(p_p20).reads)); });
            auto build_holds_pe = reads_closed(prism_rtl::deref(wx_p6).dyn_reads, prism_rtl::deref(wx_p6).build_holds);
            auto sinks_pf = Sinks{.wx = wx_p6, .dirty = dirty_holds_pd, .builds = build_holds_pe, .heights = heights_p8, .many = std::move(many_p9)};
            call_value(each_job(filter(prism_rtl::deref(wx_p6).gns, [&](const crate::lower::node_::Gn& g_p21) { return prism_rtl::deref(g_p21).kind != crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNever{}); }), ({
            auto sinks_pf_5 = sinks_pf;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::MethDef>(crate::lower::node_::Gn)>>(prism_rtl::rc([=, sinks_pf_5 = std::move(sinks_pf_5)](crate::lower::node_::Gn p0) {
            return ({
                auto sinks_pf_5_6 = sinks_pf_5;
                entered(once_job([=, sinks_pf_5_6 = std::move(sinks_pf_5_6)]() {
                return ({
                    auto g_p22 = p0;
                    call_then(start_firing_code(sinks_pf_5_6, g_p22, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})), [=](Array<crate::lower::model::Do> firing_code_15352) { return prism_rtl::finished(crate::lower::model::MethDef{.name = prism_rtl::deref(g_p22).name, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("v"), prism_rtl::deref(g_p22).ty}}), .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = firing_code_15352, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = gn_doc(g_p22)}); });
                });
            }));
            });
        })));
        })), [=, is_gen_p5 = std::move(is_gen_p5), combs_p7 = std::move(combs_p7), heights_p8 = std::move(heights_p8), many_p9 = std::move(many_p9), consts_pa = std::move(consts_pa), live_pb = std::move(live_pb)](Array<crate::lower::model::MethDef> each_15212) {
            return ({
                auto ev_methods_pg = each_15212;
                auto gather_ins_ph = each(filter(prism_rtl::deref(wx_p6).gns, [&](const crate::lower::node_::Gn& g_p23) { return prism_rtl::deref(g_p23).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnGather{}); }), [&](const crate::lower::node_::Gn& g_p24) { return gather_in(sinks_pf, g_p24); });
                auto place_getters_pi = each(live_pb, [&](const crate::lower::node_::Place& p_p25) { return crate::lower::model::MethDef{.name = prism_rtl::deref(p_p25).getter, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = crate::lower::types::elem_ty(), .body = Array<crate::lower::model::Do>{}, .tail = prism_rtl::deref(p_p25).level, .doc = prism_rtl::cat("Place ", crate::lower::model::place_text(prism_rtl::deref(p_p25).pos), "\'s level, read at the read point.")}; });
                auto wake_body_pj = many_p9
                    ? Array(std::vector{wake_by_height(combs_p7, heights_p8)})
                    : each(combs_p7, [&](const crate::lower::node_::Gn& g_p26) { return decide(g_p26); });
                auto started_body_pk = each(wx_p6->started, [&](const Nat& st_p27) { return self_call(prism_rtl::deref(crate::lower::node_::gn_of(wx_p6, st_p27)).name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})); });
                auto deferred_body_pl = each(prism_rtl::deref(wx_p6).defers, [&](const std::tuple<Text, Nat>& _p0) {
                    auto&& f_p28 = std::get<0>(_p0);
                    auto&& id_p29 = std::get<1>(_p0);
                    return crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f_p28)})), Text::lit("fired"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{self_call(prism_rtl::deref(crate::lower::node_::gn_of(wx_p6, id_p29)).name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}))}), Array<crate::lower::model::Do>{}});
                });
                auto patch_body0_pm = fold(live_pb, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc_p2a, const crate::lower::node_::Place& p_p2b) {
                    return append(acc_p2a, emits(wx_p6, prism_rtl::deref(p_p2b).pos)
                        ? patch_place(wx_p6, p_p2b)
                        : Array(std::vector{entry_take(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}), p_p2b)}));
                });
                auto patch_body_pn = append(patch_body0_pm, root_dyn_patch(wx_p6));
                auto build_body_po = build_steps(sinks_pf, false);
                auto push_body_pp = each(filter(prism_rtl::deref(wx_p6).dyn_places, [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
                    auto&& pos_p2c = std::get<0>(_p0);
                    return emits(wx_p6, pos_p2c);
                }), [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
                    auto&& pos_p2d = std::get<0>(_p0);
                    auto&& f_p2e = std::get<1>(_p0);
                    auto&& t_p2f = std::get<2>(_p0);
                    return crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("element")})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f_p2e, "_element")}))}))}), dyn_place_write(sinks_pf, f_p2e, crate::lower::model::Ex(crate::lower::model::Ex::XDecode{t_p2f, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))})), Array<crate::lower::model::Do>{}});
                });
                auto hooks_pq = filter(Array(std::vector{std::tuple{Text::lit("wake"), wake_body_pj}, std::tuple{Text::lit("started"), started_body_pk}, std::tuple{Text::lit("deferred"), deferred_body_pl}, std::tuple{Text::lit("build"), build_body_po}, std::tuple{Text::lit("push"), push_body_pp}, std::tuple{Text::lit("patch"), patch_body_pn}}), [&](const std::tuple<Text, Array<crate::lower::model::Do>>& _p0) {
                    auto&& b_p2g = std::get<1>(_p0);
                    return len(b_p2g) > Nat(0u);
                });
                auto started_reg_pr = len(wx_p6->started) > Nat(0u)
                    ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("on_started"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})})})})})
                    : Array<crate::lower::model::Do>{};
                auto links_ps = each(prism_rtl::deref(wx_p6).hosts, [&](const crate::lower::node_::HostDef& h_p2h) { return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(prism_rtl::deref(h_p2h).name)})), Text::lit("link"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})})})}); });
                auto rows_built_pt = append(links_ps, build_steps(sinks_pf, true));
                auto subscribed_pu = each(prism_rtl::deref(wx_p6).subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
                    auto&& ev_p2i = std::get<0>(_p0);
                    auto&& m_p2j = std::get<1>(_p0);
                    auto&& t_p2k = std::get<2>(_p0);
                    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("subscribe_row"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), Text::lit("parent")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("p")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("p")})), prism_rtl::cat(ev_p2i, "_port")}))}))}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("n")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("n")})), m_p2j, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(m_p2j, "_sub")}))})})})});
                });
                auto answers_pv = append(each(filter(prism_rtl::deref(wx_p6).answers, [&](const std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>& _p0) {
                    auto&& pos_p2l = std::get<0>(_p0);
                    return emits(wx_p6, pos_p2l);
                }), [&](const std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>& _p0) {
                    auto&& pos_p2m = std::get<0>(_p0);
                    auto&& id_p2n = std::get<1>(_p0);
                    auto&& t_p2o = std::get<2>(_p0);
                    return answer_arm(wx_p6, pos_p2m, id_p2n, t_p2o);
                }), each(filter(prism_rtl::deref(wx_p6).dyn_places, [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
                    auto&& pos_p2p = std::get<0>(_p0);
                    return emits(wx_p6, pos_p2p);
                }), [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
                    auto&& pos_p2q = std::get<0>(_p0);
                    auto&& f_p2r = std::get<1>(_p0);
                    auto&& t_p2s = std::get<2>(_p0);
                    return dyn_answer_arm(sinks_pf, pos_p2q, f_p2r, t_p2s);
                }));
                auto forwards_p10 = append(each(filter(prism_rtl::deref(wx_p6).builders, [&](const crate::lower::model::ForDef& b_p2t) { return emits(wx_p6, prism_rtl::deref(b_p2t).pos); }), [&](const crate::lower::model::ForDef& b_p2u) { return std::tuple{pos_pat(prism_rtl::deref(b_p2u).pos, key_tail()), forward_answer(b_p2u)}; }), fold(filter(prism_rtl::deref(wx_p6).gens, [&](const crate::lower::model::GenDef& gd_p2v) { return emits(wx_p6, prism_rtl::deref(gd_p2v).pos); }), Array<std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>>{}, [&](const Array<std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>>& acc_p30, const crate::lower::model::GenDef& gd_p31) { return append(acc_p30, crate::lower::node_::switch_::gen_forwards(gd_p31)); }));
                auto host_methods_p11 = fold(prism_rtl::deref(wx_p6).hosts, Array<crate::lower::model::MethDef>{}, [&](const Array<crate::lower::model::MethDef>& acc_p32, const crate::lower::node_::HostDef& h_p33) { return append(acc_p32, Array(std::vector{typed_dispatch(sinks_pf, prism_rtl::cat(prism_rtl::deref(h_p33).name, "_answer"), prism_rtl::deref(h_p33).scope), host_moved(sinks_pf, h_p33)})); });
                auto gathered_p12 = filter(prism_rtl::deref(wx_p6).snaps, [&](const crate::lower::node_::SnapDef& sn_p34) { return !(prism_rtl::deref(sn_p34).before || is_generation(wx_p6, prism_rtl::deref(sn_p34).builder)); });
                auto gathered_moved_p13 = append(append(each(gathered_p12, [&](const crate::lower::node_::SnapDef& sn_p35) { return gathered_moved(sn_p35); }), each(prism_rtl::deref(wx_p6).snaps, [&](const crate::lower::node_::SnapDef& sn_p36) { return snap_publish(sinks_pf, sn_p36); })), flatten_methods(sinks_pf));
                auto hosted_methods_p14 = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::MethDef>> _v;
                    auto&& _m = prism_rtl::deref(wx_p6).hosted_by;
                    if (prism_rtl::is_some(_m)) {
                        _v.set(Array(std::vector{typed_dispatch(sinks_pf, Text::lit("deliver"), Nat(0u)), document_getter(wx_p6)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<crate::lower::model::MethDef>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto moved_method_p15 = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::MethDef>> _v;
                    auto&& _m = prism_rtl::deref(wx_p6).hosted_by;
                    if (prism_rtl::is_some(_m)) {
                        auto&& m_p37 = prism_rtl::some_of(_m);
                        _v.set(Array(std::vector{crate::lower::node_::finish::document_moved(m_p37)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<crate::lower::model::MethDef>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto row_methods_p16 = is_row_p3_1 ? row_methods(wx_p6) : Array<crate::lower::model::MethDef>{};
                auto heard_build_f17 = ({
                    auto wx_p6_5 = wx_p6;
                    auto sinks_pf_6 = sinks_pf;
                    (static_cast<Fn<Array<crate::lower::model::Do>(const Text&)>>(prism_rtl::rc([=, wx_p6_5 = std::move(wx_p6_5), sinks_pf_6 = std::move(sinks_pf_6)](const Text& m_p38) {
                    return ({
                        auto stales_p39 = fold(prism_rtl::deref(wx_p6_5).gen_holds, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc_p3b, const std::tuple<Text, Array<crate::lower::node_::Read>>& _p1) {
                            auto&& gname_p3c = std::get<0>(_p1);
                            auto&& hs_p3d = std::get<1>(_p1);
                            return crate::lower::node_::has_read(reads_closed(prism_rtl::deref(wx_p6_5).dyn_reads, hs_p3d), crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m_p38}))
                                ? crate::prelude::push(acc_p3b, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gname_p3c, "_stale")})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{true})})})}))
                                : acc_p3b;
                        });
                        auto builds_p3a = crate::lower::node_::has_read(prism_rtl::deref(sinks_pf_6).builds, crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m_p38})) || (len(stales_p39) > Nat(0u));
                        std::move(builds_p3a) && (!lists_build(sinks_pf_6, crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m_p38})))
                        ? append(stales_p39, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("build_later"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})})})}))
                        : stales_p39;
                    });
                })));
                });
                auto heard_p18 = each(row_hears(wx_p6), [&](const Text& m_p3e) { return crate::lower::model::MethDef{.name = prism_rtl::cat("parent_wrote_", m_p3e), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = append(append(moved_by(sinks_pf, crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m_p3e})), heard_build_f17(m_p3e)), fold(prism_rtl::deref(wx_p6).row_marks, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc_p3f, const crate::lower::node_::RowMarks& rm_p3g) { return append(acc_p3f, row_written(wx_p6, rm_p3g, crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m_p3e}))); })), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = prism_rtl::cat("The block wrote behind its `", m_p3e, "`, which this row reads through the parent: the `!Updated` nodes over it are told and the wake asked at their heights; the row\'s own builders over it are listed for the build; the rows of this row\'s own `for`s that read it are marked.")}; });
                auto top_p19 = fold(prism_rtl::deref(wx_p6).gns, Nat(0u), [&](const Nat& hi_p3h, const crate::lower::node_::Gn& g_p3i) { return crate::prelude::max(hi_p3h, prism_rtl::deref(g_p3i).height); });
                auto wakes_field_p1a = many_p9
                    ? Array(std::vector{std::tuple{Text::lit("wakes"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWakes{}), Text::lit("the heights asked for this tick, lowest first")}})
                    : Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{};
                auto wakes_init_p1b = many_p9
                    ? Array(std::vector{std::tuple{Text::lit("wakes"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Wakes::default"), Array<crate::lower::model::Ex>{}})}})
                    : Array<std::tuple<Text, crate::lower::model::Ex>>{};
                auto gen_fields_p1c = fold(prism_rtl::deref(wx_p6).gens, Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{}, [&](const Array<std::tuple<Text, crate::lower::model::OutTy, Text>>& acc_p3j, const crate::lower::model::GenDef& gd_p3k) { return append(acc_p3j, Array(std::vector{std::tuple{prism_rtl::deref(gd_p3k).name, crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Row"), Array<crate::lower::model::OutTy>{}}))}))}))}), prism_rtl::cat("the current generation of the `rebuild` at place ", crate::lower::model::place_text(prism_rtl::deref(gd_p3k).pos))}, std::tuple{prism_rtl::cat(prism_rtl::deref(gd_p3k).name, "_count"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutCount{})})}), Text::lit("how many generations it has built")}, std::tuple{prism_rtl::cat(prism_rtl::deref(gd_p3k).name, "_stale"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})}), Text::lit("its source changed since it was built")}})); });
                auto gen_inits_p1d = fold(prism_rtl::deref(wx_p6).gens, Array<std::tuple<Text, crate::lower::model::Ex>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Ex>>& acc_p3l, const crate::lower::model::GenDef& gd_p3m) { return append(acc_p3l, Array(std::vector{std::tuple{prism_rtl::deref(gd_p3m).name, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})}, std::tuple{prism_rtl::cat(prism_rtl::deref(gd_p3m).name, "_count"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{Nat(0u)})})})}, std::tuple{prism_rtl::cat(prism_rtl::deref(gd_p3m).name, "_stale"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false})})})}})); });
                auto port_fields_p1e = each(prism_rtl::deref(wx_p6).ports, [&](const Text& pn_p3n) { return std::tuple{prism_rtl::cat(pn_p3n, "_port"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutPort{prism_rtl::rc(crate::lower::node_::keyed::gn_ty_named(wx_p6, pn_p3n))}), prism_rtl::cat("`!", pn_p3n, "`, which rows subscribe to")}; });
                auto port_inits_p1f = each(prism_rtl::deref(wx_p6).ports, [&](const Text& pn_p3o) { return std::tuple{prism_rtl::cat(pn_p3o, "_port"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Port::new"), Array<crate::lower::model::Ex>{}})}; });
                auto sub_fields_p1g = each(prism_rtl::deref(wx_p6).subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
                    auto&& ev_p3p = std::get<0>(_p0);
                    auto&& m_p3q = std::get<1>(_p0);
                    auto&& t_p3r = std::get<2>(_p0);
                    return std::tuple{prism_rtl::cat(m_p3q, "_sub"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Handle"), Array<crate::lower::model::OutTy>{}}))})})}), prism_rtl::cat("the subscription to the parent\'s `!", ev_p3p, "`")};
                });
                auto sub_inits_p1h = each(prism_rtl::deref(wx_p6).subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
                    auto&& ev_p3s = std::get<0>(_p0);
                    auto&& m_p3t = std::get<1>(_p0);
                    auto&& t_p3u = std::get<2>(_p0);
                    return std::tuple{prism_rtl::cat(m_p3t, "_sub"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})};
                });
                auto fallible_p1i = ((prism_rtl::deref(wx_p6).fallible || is_row_p3_1) || (len(prism_rtl::deref(wx_p6).builders) > Nat(0u))) || (len(prism_rtl::deref(wx_p6).gens) > Nat(0u));
                (prism_rtl::finished(crate::lower::model::NodeDef{.name = prism_rtl::deref(wx_p6).node_, .prism = crate::check::types::bare_name(qk_p1_3), .doc = crate::lower::functions::definition_text(prism_rtl::deref(wx_p6).lx, qk_p1_3), .params = params_p2_2, .fields = append(append(append(append(prism_rtl::deref(wx_p6).fields, wakes_field_p1a), gen_fields_p1c), port_fields_p1e), sub_fields_p1g), .consts = consts_pa, .lets = prism_rtl::deref(wx_p6).lets, .inits = append(prism_rtl::deref(wx_p6).inits, append(append(append(append(prism_rtl::deref(wx_p6).moves, wakes_init_p1b), gen_inits_p1d), port_inits_p1f), sub_inits_p1h)), .build = append(append(append(rows_built_pt, wx_p6->build), subscribed_pu), started_reg_pr), .fallible = std::move(fallible_p1i), .methods = append(append(append(append(append(append(append(append(ev_methods_pg, gather_ins_ph), place_getters_pi), prism_rtl::deref(wx_p6).getters), row_methods_p16), heard_p18), host_methods_p11), gathered_moved_p13), moved_method_p15), .answers = append(answers_pv, forwards_p10), .hooks = hooks_pq, .builders = prism_rtl::deref(wx_p6).builders, .wakes = many_p9, .children = wx_p6->rows, .gens = prism_rtl::deref(wx_p6).gens, .subs = prism_rtl::deref(wx_p6).subs, .top = top_p19, .row_kind = is_row_p3_1
                ? is_gen_p5
                ? crate::lower::model::RowKind(crate::lower::model::RowKind::GenerationRow{})
                : crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})
                : crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{}), .hosted = hosted_methods_p14}));
            });
        });
        });
    });
}


/// `Start FinishNode, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::NodeDef> start_finish_node(crate::lower::node_::Wx wx0_p0, Text qk_p1, Array<std::tuple<Text, crate::lower::model::OutTy>> params_p2, bool is_row_p3) {
    return prism_rtl::make_rc<FinishNode>(wx0_p0, qk_p1, params_p2, is_row_p3);
}


/// IsGeneration: fn Wx, Text -> Bool
bool is_generation(const crate::lower::node_::Wx& wx_p0, const Text& name_p1) {
    return len(filter(wx_p0.gens, [&](const crate::lower::model::GenDef& gd_p2) { return prism_rtl::deref(gd_p2).name == name_p1; })) > Nat(0u);
}


/// FlattenMethods: fn Sinks -> [MethDef]
Array<crate::lower::model::MethDef> flatten_methods(const Sinks& sk_p0) {
    auto wx_p1 = sk_p0.wx;
    auto entries_p2 = fold(filter(prism_rtl::deref(wx_p1).flattens, [&](const crate::lower::node_::FlatDef& fl_p7) { return fl_p7->generation == Text::lit(""); }), Array<crate::lower::model::MethDef>{}, [&](const Array<crate::lower::model::MethDef>& acc_p8, const crate::lower::node_::FlatDef& fl_p9) {
        return ({
            auto set_pa = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(prism_rtl::deref(fl_p9).name, "_inner")})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("entry"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
            auto followed_pb = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(prism_rtl::deref(fl_p9).name, "_follow")})), Text::lit("follow"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("entry"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("updates")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))}))}), crate::lower::model::Ex(crate::lower::model::Ex::XPath{prism_rtl::cat(prism_rtl::deref(wx_p1).node_, "::", prism_rtl::deref(fl_p9).name, "_moved")})})})});
            auto moved_pc = crate::lower::model::MethDef{.name = prism_rtl::cat(prism_rtl::deref(fl_p9).name, "_moved"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = hold_written(sk_p0, prism_rtl::cat(prism_rtl::deref(fl_p9).name, "_inner")), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = prism_rtl::cat("`", prism_rtl::deref(fl_p9).name, "`\'s inner moved: what reads it reads it again.")};
            auto replaced_pd = crate::lower::model::MethDef{.name = prism_rtl::cat(prism_rtl::deref(fl_p9).name, "_replaced"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = adoption(fl_p9), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = prism_rtl::cat("The `for`\'s builder found another dynamic than `", prism_rtl::deref(fl_p9).name, "`\'s inner under this row\'s key: the adoption is queued for the first firings of the next tick, which is owed (Semantics ch. 4).")};
            auto adopt_pe = crate::lower::model::MethDef{.name = prism_rtl::cat(prism_rtl::deref(fl_p9).name, "_adopt"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = append(Array(std::vector{set_pa, followed_pb}), hold_written(sk_p0, prism_rtl::cat(prism_rtl::deref(fl_p9).name, "_inner"))), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = prism_rtl::cat("`", prism_rtl::deref(fl_p9).name, "` adopts the dynamic under its row\'s key as the tick before left it, among this tick\'s first firings: from here on it reads that inner (Semantics ch. 4).")};
            append(acc_p8, Array(std::vector{moved_pc, replaced_pd, adopt_pe}));
        });
    });
    auto adopts0_p3 = each(filter(prism_rtl::deref(wx_p1).flattens, [&](const crate::lower::node_::FlatDef& fl_pf) { return fl_pf->generation != Text::lit(""); }), [&](const crate::lower::node_::FlatDef& fl_pg) {
        return ({
            auto set_ph = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(prism_rtl::deref(fl_pg).name, "_inner")})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::deref(fl_pg).outer, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
            crate::lower::model::MethDef{.name = prism_rtl::cat(prism_rtl::deref(fl_pg).name, "_adopt"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = append(Array(std::vector{set_ph}), hold_written(sk_p0, prism_rtl::cat(prism_rtl::deref(fl_pg).name, "_inner"))), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("`@Flatten` adopts the inner its `rebuild`\'s dynamic held after the tick before, among this tick\'s first firings: from here on it reads that inner (Semantics ch. 7).")};
        });
    });
    auto adopts_p4 = append(adopts0_p3, entries_p2);
    auto dyn_gens_p5 = filter(prism_rtl::deref(wx_p1).gens, [&](const crate::lower::model::GenDef& gd_pi) { return len(filter(prism_rtl::deref(wx_p1).snaps, [&](const crate::lower::node_::SnapDef& sn_pj) { return prism_rtl::deref(sn_pj).builder == prism_rtl::deref(gd_pi).name; })) > Nat(0u); });
    auto moved_p6 = each(dyn_gens_p5, [&](const crate::lower::model::GenDef& gd_pk) {
        return ({
            auto marks_pl = fold(filter(prism_rtl::deref(wx_p1).flattens, [&](const crate::lower::node_::FlatDef& fl_pq) { return fl_pq->generation == prism_rtl::deref(gd_pk).name; }), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc_pr, const crate::lower::node_::FlatDef& fl_ps) { return append(acc_pr, hold_written(sk_p0, prism_rtl::cat(prism_rtl::deref(fl_ps).name, "_inner"))); });
            auto live_pm = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(prism_rtl::deref(gd_pk).name, "_result_live")})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("as_ref"), Array<crate::lower::model::Ex>{}});
            auto port_pn = crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("d")})), Text::lit("updates")});
            auto fire_po = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(port_pn), Text::lit("fire"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("ok"), Array<crate::lower::model::Ex>{}});
            auto fired_pp = crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("d")})})}), live_pm, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{fire_po})}), Array<crate::lower::model::Do>{}});
            crate::lower::model::MethDef{.name = prism_rtl::cat(prism_rtl::deref(gd_pk).name, "_result_moved"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = crate::prelude::push(marks_pl, fired_pp), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("The current generation\'s result moved: what reads a `@Flatten` over it reads it again, and the dynamic kept for it fires its update event for whoever follows it outside this node.")};
        });
    });
    return append(adopts_p4, moved_p6);
}


/// HostMoved: fn Sinks, HostDef -> MethDef
crate::lower::model::MethDef host_moved(const Sinks& sk_p0, const crate::lower::node_::HostDef& h_p1) {
    return crate::lower::model::MethDef{.name = prism_rtl::cat(h_p1.name, "_moved"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = hold_written(sk_p0, prism_rtl::cat(h_p1.name, "_doc_now")), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = prism_rtl::cat("A node of the child hosted at place ", crate::lower::model::place_text(h_p1.pos), " wrote behind its document: the structure is marked as for a write of a hold it reads (pick HO), the snapshot listed to be taken; the program\'s `$doc` moves when it is published, the tick after (pick ST).")};
}


/// BuildSteps: fn Sinks, Bool -> [Do]
Array<crate::lower::model::Do> build_steps(const Sinks& sk_p0, const bool& at_build_p1) {
    auto wx_p2 = sk_p0.wx;
    auto recv_p3 = at_build_p1
        ? crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})
        : crate::lower::model::Ex(crate::lower::model::Ex::XSelf{});
    auto take_f4 = ({
        auto at_build_p1_1 = at_build_p1;
        auto sk_p0_2 = sk_p0;
        (static_cast<Fn<crate::lower::model::Do(const crate::lower::node_::SnapDef&)>>(prism_rtl::rc([=, at_build_p1_1 = std::move(at_build_p1_1), sk_p0_2 = std::move(sk_p0_2)](const crate::lower::node_::SnapDef& sn_p8) { return at_build_p1_1 ? snap_take_at_build(sn_p8) : snap_take(sk_p0_2, sn_p8); })));
    });
    auto builder_f5 = ({
        auto wx_p2_1 = wx_p2;
        auto take_f4_2 = take_f4;
        auto recv_p3_3 = recv_p3;
        (static_cast<Fn<Array<crate::lower::model::Do>(const crate::lower::model::ForDef&)>>(prism_rtl::rc([=, wx_p2_1 = std::move(wx_p2_1), take_f4_2 = std::move(take_f4_2), recv_p3_3 = std::move(recv_p3_3)](const crate::lower::model::ForDef& b_p9) {
        return ({
            auto before_pa = each(filter(prism_rtl::deref(wx_p2_1).snaps, [&](const crate::lower::node_::SnapDef& sn_pc) { return prism_rtl::deref(sn_pc).before && (prism_rtl::deref(sn_pc).builder == prism_rtl::deref(b_p9).name); }), prism_rtl::deref(take_f4_2));
            auto after_pb = each(filter(prism_rtl::deref(wx_p2_1).snaps, [&](const crate::lower::node_::SnapDef& sn_pd) { return (!prism_rtl::deref(sn_pd).before) && (prism_rtl::deref(sn_pd).builder == prism_rtl::deref(b_p9).name); }), prism_rtl::deref(take_f4_2));
            append(crate::prelude::push(before_pa, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(recv_p3_3), prism_rtl::cat(prism_rtl::deref(b_p9).name, "_build"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})), after_pb);
        });
    })));
    });
    auto gen_f6 = ({
        auto at_build_p1_1 = at_build_p1;
        auto recv_p3_2 = recv_p3;
        auto wx_p2_3 = wx_p2;
        auto take_f4_4 = take_f4;
        (static_cast<Fn<Array<crate::lower::model::Do>(const crate::lower::model::GenDef&)>>(prism_rtl::rc([=, at_build_p1_1 = std::move(at_build_p1_1), recv_p3_2 = std::move(recv_p3_2), wx_p2_3 = std::move(wx_p2_3), take_f4_4 = std::move(take_f4_4)](const crate::lower::model::GenDef& gd_pe) {
        return ({
            auto built_pf = at_build_p1_1
                ? crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(recv_p3_2), prism_rtl::cat(prism_rtl::deref(gd_pe).name, "_build"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})
                : crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(prism_rtl::deref(gd_pe).name, "_stale")})), Text::lit("replace"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false})})}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(prism_rtl::deref(gd_pe).name, "_build"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})}), Array<crate::lower::model::Do>{}});
            append(Array(std::vector{built_pf}), each(filter(prism_rtl::deref(wx_p2_3).snaps, [&](const crate::lower::node_::SnapDef& sn_pg) { return (!prism_rtl::deref(sn_pg).before) && (prism_rtl::deref(sn_pg).builder == prism_rtl::deref(gd_pe).name); }), prism_rtl::deref(take_f4_4)));
        });
    })));
    });
    auto entries_f7 = ({
        auto at_build_p1_1 = at_build_p1;
        auto wx_p2_2 = wx_p2;
        auto recv_p3_3 = recv_p3;
        (static_cast<Fn<Array<crate::lower::model::Do>(const Nat&)>>(prism_rtl::rc([=, at_build_p1_1 = std::move(at_build_p1_1), wx_p2_2 = std::move(wx_p2_2), recv_p3_3 = std::move(recv_p3_3)](const Nat& k_ph) {
        return at_build_p1_1
            ? each(filter(prism_rtl::deref(wx_p2_2).places, [&](const crate::lower::node_::Place& pl_pi) { return ((prism_rtl::deref(prism_rtl::deref(pl_pi).pos).scope == k_ph) && (pl_pi->entry != Text::lit(""))) && (prism_rtl::deref(pl_pi).getter != Text::lit("")); }), [&](const crate::lower::node_::Place& pl_pj) { return entry_take(recv_p3_3, pl_pj); })
            : Array<crate::lower::model::Do>{};
    })));
    });
    return fold(crate::check::errors::range0(len(prism_rtl::deref(wx_p2).scopes) + Nat(1u)), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc_pk, const Nat& i_pl) {
        return ({
            auto k_pm = or_(len(prism_rtl::deref(wx_p2).scopes).checked_sub(i_pl), Nat(0u));
            auto builders_pn = fold(filter(prism_rtl::deref(wx_p2).builders, [&](const crate::lower::model::ForDef& b_po) { return prism_rtl::deref(prism_rtl::deref(b_po).pos).scope == k_pm; }), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& a_pp, const crate::lower::model::ForDef& b_pq) { return append(a_pp, builder_f5(b_pq)); });
            append(append(append(acc_pk, builders_pn), fold(filter(prism_rtl::deref(wx_p2).gens, [&](const crate::lower::model::GenDef& gd_pr) { return prism_rtl::deref(prism_rtl::deref(gd_pr).pos).scope == k_pm; }), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& a_ps, const crate::lower::model::GenDef& gd_pt) { return append(a_ps, gen_f6(gd_pt)); })), entries_f7(k_pm));
        });
    });
}


/// EntryTake: fn Ex, Place -> Do
crate::lower::model::Do entry_take(const crate::lower::model::Ex& recv_p0, const crate::lower::node_::Place& pl_p1) {
    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(recv_p0), pl_p1.entry})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(recv_p0), pl_p1.getter, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
}


/// SnapTakeAtBuild: fn SnapDef -> Do
crate::lower::model::Do snap_take_at_build(const crate::lower::node_::SnapDef& sn_p0) {
    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(sn_p0.name, "_snap")})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(sn_p0.name, "_now"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
}


/// SnapTake: fn Sinks, SnapDef -> Do
crate::lower::model::Do snap_take(const Sinks& sk_p0, const crate::lower::node_::SnapDef& sn_p1) {
    auto now_p2 = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(sn_p1.name, "_now"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})});
    auto take_p3 = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(sn_p1.name, "_snap")})), sn_p1.eq ? Text::lit("take_compared") : Text::lit("take"), Array(std::vector{now_p2, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
    auto queue_p4 = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("answer_later"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XLater{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(sn_p1.name, "_publish"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})})})});
    auto queued_p5 = crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(sn_p1.name, "_snap")})), Text::lit("queue"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("node")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})}), queue_p4}), Array<crate::lower::model::Do>{}});
    return crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(sn_p1.name, "_snap")})), Text::lit("marked"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{take_p3, queued_p5}), Array<crate::lower::model::Do>{}});
}


/// SnapPublish: fn Sinks, SnapDef -> MethDef
crate::lower::model::MethDef snap_publish(const Sinks& sk_p0, const crate::lower::node_::SnapDef& sn_p1) {
    return crate::lower::model::MethDef{.name = prism_rtl::cat(sn_p1.name, "_publish"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(sn_p1.name, "_snap")})), Text::lit("published"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), hold_written(sk_p0, sn_p1.name), Array<crate::lower::model::Do>{}})}), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = prism_rtl::cat(sn_p1.what, ", published: its snapshot of the tick before moved it, written as a hold is (pick ST).")};
}


/// GatheredMoved: fn SnapDef -> MethDef
crate::lower::model::MethDef gathered_moved(const crate::lower::node_::SnapDef& sn_p0) {
    return crate::lower::model::MethDef{.name = prism_rtl::cat(sn_p0.name, "_moved"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(sn_p0.name, "_snap")})), Text::lit("mark"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("build_later"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})})})}), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("A row\'s result moved: the `for`\'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).")};
}


/// DocumentGetter: fn Wx -> MethDef
crate::lower::model::MethDef document_getter(const crate::lower::node_::Wx& wx_p0) {
    auto is_own_f1 = static_cast<Fn<bool(const crate::lower::model::Pos_&)>>(prism_rtl::rc([=](const crate::lower::model::Pos_& p_p3) { return prism_rtl::deref(p_p3).scope == Nat(0u); }));
    auto body_p2 = document_body(({
        auto f = prism_rtl::rc(vec_push);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(std::tuple<crate::lower::model::Ex, crate::lower::model::Ex>)>>(prism_rtl::rc([=, f = std::move(f)](std::tuple<crate::lower::model::Ex, crate::lower::model::Ex> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        return ({
            auto f_1 = f;
            once_job([=, f_1 = std::move(f_1)]() { return prism_rtl::finished(f_1(a0, a1)); });
        });
    })));
    }), filter(wx_p0.places, [&](const crate::lower::node_::Place& pl_p4) { return is_own_f1(prism_rtl::deref(pl_p4).pos); }), filter(wx_p0.builders, [&](const crate::lower::model::ForDef& b_p5) { return is_own_f1(prism_rtl::deref(b_p5).pos); }), filter(wx_p0.gens, [&](const crate::lower::model::GenDef& gd_p6) { return is_own_f1(prism_rtl::deref(gd_p6).pos); }));
    return crate::lower::model::MethDef{.name = Text::lit("document"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Vec"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{}), crate::lower::types::entry_ty()})})})}), .body = append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("doc")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Vec"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{}), crate::lower::types::entry_ty()})})})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Vec::new"), Array<crate::lower::model::Ex>{}})})}), body_p2), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("doc")}), .doc = Text::lit("The row\'s own places, entries of its host\'s document, by their paths relative to the row (pick HO).")};
}


/// DocumentMoved: fn Text -> MethDef
crate::lower::model::MethDef document_moved(const Text& m_p0) {
    return crate::lower::model::MethDef{.name = Text::lit("document_moved"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("parent")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("parent")}))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})), m_p0, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), Array<crate::lower::model::Do>{}})}), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("A place of this row may have moved: its host\'s document moved, and the host\'s readers and rows are marked (pick HO).")};
}


/// DocumentBody: fn (fn Ex, Ex -> Do), [Place], [ForDef], [GenDef] -> [Do]
Array<crate::lower::model::Do> document_body(const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(std::tuple<crate::lower::model::Ex, crate::lower::model::Ex>)>& add_f0, const Array<crate::lower::node_::Place>& places_p1, const Array<crate::lower::model::ForDef>& builders_p2, const Array<crate::lower::model::GenDef>& gens_p3) {
    auto statics_p4 = run_to_end(each_job(places_p1, ({
        auto add_f0_1 = add_f0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(crate::lower::node_::Place)>>(prism_rtl::rc([=, add_f0_1 = std::move(add_f0_1)](crate::lower::node_::Place p0) {
        return ({
            auto add_f0_1_2 = add_f0_1;
            entered(once_job([=, add_f0_1_2 = std::move(add_f0_1_2)]() {
            return ({
                auto pl_p8 = p0;
                add_f0_1_2(std::tuple{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Path::root"), Array<crate::lower::model::Ex>{}})), Text::lit("at"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{prism_rtl::deref(prism_rtl::deref(pl_p8).pos).at})})}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), pl_p8->entry}))})})->cycle();
            });
        }));
        });
    })));
    })));
    auto row_doc_f5 = static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::model::ForDef)>>(prism_rtl::rc([=](crate::lower::model::ForDef p0) {
        return entered(once_job([=]() {
            return ({
                auto b_p9 = p0;
                (crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(b_p9).row_node, Text::lit("prism_rtl::HostRow"))
                ? prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("entries"), Array<crate::lower::model::Ex>{}}))
                : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("document"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})));
            });
        }));
    }));
    auto rows_p6 = run_to_end(each_job(builders_p2, ({
        auto row_doc_f5_1 = row_doc_f5;
        auto add_f0_2 = add_f0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(crate::lower::model::ForDef)>>(prism_rtl::rc([=, row_doc_f5_1 = std::move(row_doc_f5_1), add_f0_2 = std::move(add_f0_2)](crate::lower::model::ForDef p0) {
        return ({
            auto row_doc_f5_1_3 = row_doc_f5_1;
            auto add_f0_2_3 = add_f0_2;
            entered(once_job([=, row_doc_f5_1_3 = std::move(row_doc_f5_1_3), add_f0_2_3 = std::move(add_f0_2_3)]() {
            return ({
                auto b_pa = p0;
                call_value(row_doc_f5_1_3(b_pa), [=](crate::lower::model::Ex row_doc_35051) { return call_value(add_f0_2_3(std::tuple{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Path::root"), Array<crate::lower::model::Ex>{}})), Text::lit("at"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{prism_rtl::deref(prism_rtl::deref(b_pa).pos).at})})})), Text::lit("child"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Segment::Key"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("k")})), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})})})), Text::lit("join"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("p")}))})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("e")})}), [=](crate::lower::model::Do add_35065) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("k")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::deref(b_pa).name})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("iter"), Array<crate::lower::model::Ex>{}}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("p")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("e")})})}), row_doc_35051, Array(std::vector{add_35065})})})})); }); });
            });
        }));
        });
    })));
    })));
    auto generations_p7 = run_to_end(each_job(gens_p3, ({
        auto add_f0_1 = add_f0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(crate::lower::model::GenDef)>>(prism_rtl::rc([=, add_f0_1 = std::move(add_f0_1)](crate::lower::model::GenDef p0) {
        return ({
            auto add_f0_1_2 = add_f0_1;
            entered(once_job([=, add_f0_1_2 = std::move(add_f0_1_2)]() {
            return ({
                auto gd_pb = p0;
                call_value(add_f0_1_2(std::tuple{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Path::root"), Array<crate::lower::model::Ex>{}})), Text::lit("at"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{prism_rtl::deref(prism_rtl::deref(gd_pb).pos).at})})})), Text::lit("child"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Segment::Gen"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("g")})})})})})), Text::lit("join"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("p")}))})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("e")})}), [=](crate::lower::model::Do add_35637) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::deref(gd_pb).name})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("as_ref"), Array<crate::lower::model::Ex>{}}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("g")}), crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("-"), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(prism_rtl::deref(gd_pb).name, "_count")})), Text::lit("get"), Array<crate::lower::model::Ex>{}})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XIndex{Nat(1u)}))})}), crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("p")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("e")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("document"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{add_35637})})}), Array<crate::lower::model::Do>{}})); });
            });
        }));
        });
    })));
    })));
    return append(append(statics_p4, rows_p6), generations_p7);
}


/// MapInsert: fn Ex, Ex -> Do
crate::lower::model::Do map_insert(const crate::lower::model::Ex& path_p0, const crate::lower::model::Ex& e_p1) {
    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("doc")})), Text::lit("insert"), Array(std::vector{path_p0, e_p1})})});
}


/// VecPush: fn Ex, Ex -> Do
crate::lower::model::Do vec_push(const crate::lower::model::Ex& path_p0, const crate::lower::model::Ex& e_p1) {
    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("doc")})), Text::lit("push"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{path_p0, e_p1})})})})});
}


/// DynAnswerArm: fn Sinks, Pos, Text, OutTy -> ((Pa, Ex))
std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> dyn_answer_arm(const Sinks& sk_p0, const crate::lower::model::Pos_& pos_p1, const Text& f_p2, const crate::lower::model::OutTy& t_p3) {
    return std::tuple{pos_pat(pos_p1, Array<crate::lower::model::Pa>{}), crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dyn_place_write(sk_p0, f_p2, crate::lower::model::Ex(crate::lower::model::Ex::XDecode{t_p3, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))})};
}


/// DynPlaceWrite: fn Sinks, Text, Ex -> [Do]
Array<crate::lower::model::Do> dyn_place_write(const Sinks& sk_p0, const Text& f_p1, const crate::lower::model::Ex& value_p2) {
    return append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f_p1)})), Text::lit("set"), Array(std::vector{value_p2, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), hold_written(sk_p0, f_p1));
}


/// UpdatedGaps: fn Wx, [Gn], Bool -> [Do]
Array<crate::lower::model::Do> updated_gaps(const crate::lower::node_::Wx& wx_p0, const Array<crate::lower::node_::Gn>& gns_p1, const bool& is_gen_p2) {
    auto holds_p3 = fold(wx_p0.fields, Array<Text>{}, [&](const Array<Text>& acc_p7, const std::tuple<Text, crate::lower::model::OutTy, Text>& _p1) {
        auto&& f_p8 = std::get<0>(_p1);
        auto&& t_p9 = std::get<1>(_p1);
        return is_hold(t_p9) ? crate::prelude::push(acc_p7, f_p8) : acc_p7;
    });
    auto derived_p4 = keys(wx_p0.dyn_reads);
    auto roots_p5 = snap_names(wx_p0);
    auto own_p6 = fold(filter(gns_p1, [&](const crate::lower::node_::Gn& g_pa) { return prism_rtl::deref(g_pa).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUpdated{}); }), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc_pb, const crate::lower::node_::Gn& g_pc) {
        return fold(prism_rtl::deref(g_pc).reads, acc_pb, [&](const Array<crate::lower::model::Do>& a_pd, const crate::lower::node_::Read& r_pe) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
                if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r_pe)) {
                    auto&& f_pf = prism_rtl::as<crate::lower::node_::Read::ParentRead>(r_pe).a0;
                    _v.set(is_gen_p2
                        ? crate::prelude::push(a_pd, crate::lower::expr::refusal_do(prism_rtl::cat("`!Updated` of a dynamic in a generation that reads its block\'s `", f_pf, "`, which the block does not tell a generation of (gap DY)")))
                        : a_pd);
                    goto _done;
                }
                if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r_pe)) {
                    auto&& f_pg = prism_rtl::as<crate::lower::node_::Read::OwnRead>(r_pe).a0;
                    _v.set((crate::check::types::has_text(holds_p3, f_pg) || crate::check::types::has_text(derived_p4, f_pg)) || crate::check::types::has_text(roots_p5, f_pg)
                        ? a_pd
                        : crate::prelude::push(a_pd, crate::lower::expr::refusal_do(prism_rtl::cat("`!Updated` of a dynamic that reads `", f_pg, "`, which no sink of this node writes (no height for its event)"))));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    });
    return fold(wx_p0.pending, own_p6, [&](const Array<crate::lower::model::Do>& acc_ph, const crate::lower::node_::PendingRow& p_pi) {
        return fold(updated_hears(prism_rtl::deref(p_pi).wx), acc_ph, [&](const Array<crate::lower::model::Do>& a_pj, const Text& m_pk) {
            return ({
                auto behind_pl = reads_closed(wx_p0.dyn_reads, Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{m_pk})}));
                auto written_pm = fold(behind_pl, false, [&](const bool& w_pn, const crate::lower::node_::Read& r_po) {
                    return prism_rtl::deref(w_pn) || ({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r_po)) {
                            auto&& h_pp = prism_rtl::as<crate::lower::node_::Read::OwnRead>(r_po).a0;
                            _v.set(crate::check::types::has_text(holds_p3, h_pp));
                            goto _done;
                        }
                        if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r_po)) {
                            _v.set(true);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                });
                (crate::check::types::has_text(roots_p5, m_pk) || reaches_snap(roots_p5, behind_pl)
                ? crate::prelude::push(a_pj, crate::lower::expr::refusal_do(prism_rtl::cat("`!Updated` of a dynamic in a row that reads its block\'s `", m_pk, "`, a structural dynamic the block publishes at the start of a tick, not lowered for a row\'s `!Updated` (gap SU)")))
                : std::move(written_pm) || crate::check::types::has_text(derived_p4, m_pk)
                ? a_pj
                : crate::prelude::push(a_pj, crate::lower::expr::refusal_do(prism_rtl::cat("`!Updated` of a dynamic in a row that reads its block\'s `", m_pk, "`, which no sink of the block writes (no height for its event)"))));
            });
        });
    });
}


/// FinishPending: unbounded fn Wx, [Gn] -> (([NodeDef], [Gn]))
std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>> finish_pending(const crate::lower::node_::Wx& wx_p0, const Array<crate::lower::node_::Gn>& gns_p1) {
    return run_to_end(fold_job(wx_p0.pending, std::tuple{Array<crate::lower::model::NodeDef>{}, gns_p1}, ({
        auto wx_p0_1 = wx_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>>(std::tuple<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>, crate::lower::node_::PendingRow>)>>(prism_rtl::rc([=, wx_p0_1 = std::move(wx_p0_1)](std::tuple<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>, crate::lower::node_::PendingRow> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto wx_p0_1_2 = wx_p0_1;
            entered(once_job([=, wx_p0_1_2 = std::move(wx_p0_1_2)]() {
            return ({
                auto [defs_p2, cur_p3] = p0;
                auto p_p4 = p1;
                ({
                auto floors_p5 = fold(row_hears(prism_rtl::deref(p_p4).wx), Map<Text, Nat>{}, [&](const Map<Text, Nat>& acc_p9, const Text& m_pa) { return insert(acc_p9, m_pa, parent_floor(wx_p0_1_2, cur_p3, Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m_pa})}))); });
                auto floored_p6 = ({
                    crate::lower::node_::Wx this_ = prism_rtl::deref(p_p4).wx;
                    this_.floors = floors_p5;
                    this_.gns = each(this_.gns, [&](const crate::lower::node_::Gn& g_pb) {
                        return prism_rtl::deref(g_pb).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUpdated{})
                            ? with_floor(g_pb, parent_floor(wx_p0_1_2, cur_p3, reads_closed(prism_rtl::deref(prism_rtl::deref(p_p4).wx).dyn_reads, prism_rtl::deref(g_pb).reads)))
                            : g_pb;
                    });
                    (std::move(this_));
                });
                call_then(start_finish_node(floored_p6, prism_rtl::deref(p_p4).qk, prism_rtl::deref(p_p4).params, true), [=](crate::lower::model::NodeDef finish_node_39907) {
                return ({
                    auto def_p7 = finish_node_39907;
                    auto next_p8 = ({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::lower::node_::Gn>> _v;
                        auto&& _m = prism_rtl::deref(p_p4).gather;
                        if (prism_rtl::is_some(_m)) {
                            auto&& gid_pc = prism_rtl::some_of(_m);
                            _v.set(each(cur_p3, [&](const crate::lower::node_::Gn& g_pd) {
                                return prism_rtl::deref(g_pd).id == gid_pc
                                    ? with_height(g_pd, prism_rtl::deref(def_p7).top + Nat(1u))
                                    : g_pd;
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(cur_p3);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{crate::prelude::push(defs_p2, def_p7), next_p8}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>> FinishPending::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& gns_p1 = this->gns_p1;
    return fold_job(prism_rtl::deref(wx_p0).pending, std::tuple{Array<crate::lower::model::NodeDef>{}, gns_p1}, ({
        auto wx_p0_1 = wx_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>>(std::tuple<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>, crate::lower::node_::PendingRow>)>>(prism_rtl::rc([=, wx_p0_1 = std::move(wx_p0_1)](std::tuple<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>, crate::lower::node_::PendingRow> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto wx_p0_1_2 = wx_p0_1;
            entered(once_job([=, wx_p0_1_2 = std::move(wx_p0_1_2)]() {
            return ({
                auto [defs_p2, cur_p3] = p0;
                auto p_p4 = p1;
                ({
                auto floors_p5 = fold(row_hears(prism_rtl::deref(p_p4).wx), Map<Text, Nat>{}, [&](const Map<Text, Nat>& acc_p9, const Text& m_pa) { return insert(acc_p9, m_pa, parent_floor(wx_p0_1_2, cur_p3, Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m_pa})}))); });
                auto floored_p6 = ({
                    crate::lower::node_::Wx this_ = prism_rtl::deref(p_p4).wx;
                    this_.floors = floors_p5;
                    this_.gns = each(this_.gns, [&](const crate::lower::node_::Gn& g_pb) {
                        return prism_rtl::deref(g_pb).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUpdated{})
                            ? with_floor(g_pb, parent_floor(wx_p0_1_2, cur_p3, reads_closed(prism_rtl::deref(prism_rtl::deref(p_p4).wx).dyn_reads, prism_rtl::deref(g_pb).reads)))
                            : g_pb;
                    });
                    (std::move(this_));
                });
                call_then(start_finish_node(floored_p6, prism_rtl::deref(p_p4).qk, prism_rtl::deref(p_p4).params, true), [=](crate::lower::model::NodeDef finish_node_39907) {
                return ({
                    auto def_p7 = finish_node_39907;
                    auto next_p8 = ({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::lower::node_::Gn>> _v;
                        auto&& _m = prism_rtl::deref(p_p4).gather;
                        if (prism_rtl::is_some(_m)) {
                            auto&& gid_pc = prism_rtl::some_of(_m);
                            _v.set(each(cur_p3, [&](const crate::lower::node_::Gn& g_pd) {
                                return prism_rtl::deref(g_pd).id == gid_pc
                                    ? with_height(g_pd, prism_rtl::deref(def_p7).top + Nat(1u))
                                    : g_pd;
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(cur_p3);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{crate::prelude::push(defs_p2, def_p7), next_p8}));
                });
            });
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start FinishPending, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>> start_finish_pending(crate::lower::node_::Wx wx_p0, Array<crate::lower::node_::Gn> gns_p1) {
    return prism_rtl::make_rc<FinishPending>(wx_p0, gns_p1);
}


/// ParentFloor: fn Wx, [Gn], [Read] -> Nat
Nat parent_floor(const crate::lower::node_::Wx& wx_p0, const Array<crate::lower::node_::Gn>& gns_p1, const Array<crate::lower::node_::Read>& reads_p2) {
    return fold(reads_p2, Nat(0u), [&](const Nat& hi_p3, const crate::lower::node_::Read& r_p4) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Nat> _v;
            if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r_p4)) {
                auto&& m_p5 = prism_rtl::as<crate::lower::node_::Read::ParentRead>(r_p4).a0;
                _v.set(fold(reads_closed(wx_p0.dyn_reads, Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{m_p5})})), hi_p3, [&](const Nat& h2_p6, const crate::lower::node_::Read& hr_p7) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Nat> _v;
                        if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(hr_p7)) {
                            auto&& f_p8 = prism_rtl::as<crate::lower::node_::Read::OwnRead>(hr_p7).a0;
                            _v.set(fold(gns_p1, h2_p6, [&](const Nat& h3_p9, const crate::lower::node_::Gn& g_pa) {
                                return writes_hold(g_pa, f_p8)
                                    ? crate::prelude::max(h3_p9, prism_rtl::deref(g_pa).height + Nat(1u))
                                    : h3_p9;
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(hr_p7)) {
                            auto&& up_pb = prism_rtl::as<crate::lower::node_::Read::ParentRead>(hr_p7).a0;
                            _v.set(crate::prelude::max(h2_p6, or_(crate::prelude::get(wx_p0.floors, up_pb), Nat(0u))));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r_p4)) {
                _v.set(hi_p3);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// WritesHold: fn Gn, Text -> Bool
bool writes_hold(const crate::lower::node_::Gn& g_p0, const Text& f_p1) {
    return fold(g_p0.outs, false, [&](const bool& acc_p2, const crate::lower::node_::Out& o_p3) { return prism_rtl::deref(acc_p2) || sink_writes_hold(prism_rtl::deref(o_p3).sink, f_p1); });
}


/// SinkWritesHold: fn Sk, Text -> Bool
bool sink_writes_hold(const crate::lower::node_::Sk& sk0, const Text& f_p1) {
    if (prism_rtl::is<crate::lower::node_::Sk::SkHold>(sk0)) {
        auto&& h_p0 = prism_rtl::as<crate::lower::node_::Sk::SkHold>(sk0).a0;
        return h_p0 == f_p1;
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkDistinct>(sk0)) {
        auto&& h_p2 = prism_rtl::as<crate::lower::node_::Sk::SkDistinct>(sk0).a0;
        return h_p2 == f_p1;
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkPerKey>(sk0)) {
        auto&& h_p4 = prism_rtl::as<crate::lower::node_::Sk::SkPerKey>(sk0).a0;
        return h_p4 == f_p1;
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkMachine>(sk0)) {
        auto&& h_p6 = prism_rtl::as<crate::lower::node_::Sk::SkMachine>(sk0).a0;
        return h_p6 == f_p1;
    }
    {
        auto&& other_p8 = sk0;
        return false;
    }
}


/// WithFloor: fn Gn, Nat -> Gn
crate::lower::node_::Gn with_floor(const crate::lower::node_::Gn& g_p0, const Nat& h_p1) {
    crate::lower::node_::Gn this_ = g_p0;
    this_.floor = h_p1;
    return this_;
}


/// WithHeight: fn Gn, Nat -> Gn
crate::lower::node_::Gn with_height(const crate::lower::node_::Gn& g_p0, const Nat& h_p1) {
    crate::lower::node_::Gn this_ = g_p0;
    this_.height = h_p1;
    return this_;
}


/// RowHears: fn Wx -> [Text]
Array<Text> row_hears(const crate::lower::node_::Wx& wx_p0) {
    auto from_updated_p1 = fold(filter(wx_p0.gns, [&](const crate::lower::node_::Gn& g_p5) { return prism_rtl::deref(g_p5).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUpdated{}); }), Array<crate::lower::node_::Read>{}, [&](const Array<crate::lower::node_::Read>& acc_p6, const crate::lower::node_::Gn& g_p7) { return crate::lower::node_::union_reads(acc_p6, reads_closed(wx_p0.dyn_reads, prism_rtl::deref(g_p7).reads)); });
    auto from_rows_p2 = fold(wx_p0.row_marks, Array<crate::lower::node_::Read>{}, [&](const Array<crate::lower::node_::Read>& acc_p8, const crate::lower::node_::RowMarks& rm_p9) { return crate::lower::node_::union_reads(acc_p8, reads_closed(wx_p0.dyn_reads, append(prism_rtl::deref(rm_p9).reads, each(prism_rtl::deref(rm_p9).wrote, [&](const Text& m_pa) { return crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{m_pa}); })))); });
    auto from_builds_p3 = reads_closed(wx_p0.dyn_reads, wx_p0.build_holds);
    auto from_gens_p4 = fold(wx_p0.gen_holds, Array<crate::lower::node_::Read>{}, [&](const Array<crate::lower::node_::Read>& acc_pb, const std::tuple<Text, Array<crate::lower::node_::Read>>& _p1) {
        auto&& hs_pc = std::get<1>(_p1);
        return crate::lower::node_::union_reads(acc_pb, reads_closed(wx_p0.dyn_reads, hs_pc));
    });
    return fold(crate::lower::node_::union_reads(crate::lower::node_::union_reads(crate::lower::node_::union_reads(from_updated_p1, from_rows_p2), from_builds_p3), from_gens_p4), Array<Text>{}, [&](const Array<Text>& acc_pd, const crate::lower::node_::Read& r_pe) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r_pe)) {
                auto&& m_pf = prism_rtl::as<crate::lower::node_::Read::ParentRead>(r_pe).a0;
                _v.set(crate::check::types::add_text(acc_pd, m_pf));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r_pe)) {
                _v.set(acc_pd);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// UpdatedHears: fn Wx -> [Text]
Array<Text> updated_hears(const crate::lower::node_::Wx& wx_p0) {
    return fold(filter(wx_p0.gns, [&](const crate::lower::node_::Gn& g_p1) { return prism_rtl::deref(g_p1).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUpdated{}); }), Array<Text>{}, [&](const Array<Text>& acc_p2, const crate::lower::node_::Gn& g_p3) {
        return fold(reads_closed(wx_p0.dyn_reads, prism_rtl::deref(g_p3).reads), acc_p2, [&](const Array<Text>& a_p4, const crate::lower::node_::Read& r_p5) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r_p5)) {
                    auto&& m_p6 = prism_rtl::as<crate::lower::node_::Read::ParentRead>(r_p5).a0;
                    _v.set(crate::check::types::add_text(a_p4, m_p6));
                    goto _done;
                }
                if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r_p5)) {
                    _v.set(a_p4);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    });
}


/// RowWritten: fn Wx, RowMarks, Read -> [Do]
Array<crate::lower::model::Do> row_written(const crate::lower::node_::Wx& wx_p0, const crate::lower::node_::RowMarks& rm_p1, const crate::lower::node_::Read& r_p2) {
    auto dirty_p3 = crate::lower::node_::has_read(reads_closed(wx_p0.dyn_reads, rm_p1.reads), r_p2)
        ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("dirty"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")}))})})})})})
        : Array<crate::lower::model::Do>{};
    auto told_p4 = fold(rm_p1.wrote, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc_p6, const Text& m_p7) {
        return crate::lower::node_::has_read(reads_closed(wx_p0.dyn_reads, Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{m_p7})})), r_p2)
            ? crate::prelude::push(acc_p6, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), prism_rtl::cat("parent_wrote_", m_p7), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}))
            : acc_p6;
    });
    auto body_p5 = append(dirty_p3, told_p4);
    return len(body_p5) == Nat(0u)
        ? Array<crate::lower::model::Do>{}
        : ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
        auto&& _m = rm_p1.kind;
        if (prism_rtl::is<crate::lower::model::RowKind::GenerationRow>(_m)) {
            _v.set(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rm_p1.builder})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("as_ref"), Array<crate::lower::model::Ex>{}}), body_p5, Array<crate::lower::model::Do>{}})}));
            goto _done;
        }
        {
            _v.set(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rm_p1.builder})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("values"), Array<crate::lower::model::Ex>{}}), body_p5})}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// PatchPlace: fn Wx, Place -> [Do]
Array<crate::lower::model::Do> patch_place(const crate::lower::node_::Wx& wx_p0, const crate::lower::node_::Place& p_p1) {
    auto pull_p2 = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{p_p1.getter}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), p_p1.getter, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
    auto at_p3 = place_at(wx_p0, Text::lit("self"), p_p1.pos);
    auto sent_p4 = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("changed"), Array(std::vector{at_p3, crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{p_p1.getter})), Text::lit("level_pod"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})});
    auto renew_p5 = p_p1.watch == Text::lit("")
        ? Array<crate::lower::model::Do>{}
        : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), p_p1.watch})), Text::lit("renew"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{p_p1.getter}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Node"), Array<crate::lower::model::OutTy>{}}))})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})});
    return append(Array(std::vector{pull_p2, sent_p4}), renew_p5);
}


/// Emits: fn Wx, Pos -> Bool
bool emits(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::Pos_& pos_p1) {
    return (pos_p1.scope == Nat(0u)) && (wx_p0.hosted_by == std::optional<Text>{});
}


/// ResultTold: fn Ex -> [Do]
Array<crate::lower::model::Do> result_told(const crate::lower::model::Ex& node_p0) {
    auto r_p1 = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("r")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(node_p0), Text::lit("result_value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
    return Array(std::vector{r_p1, result_kept(node_p0), result_tell()});
}


/// ResultMoved: fn Ex -> [Do]
Array<crate::lower::model::Do> result_moved(const crate::lower::model::Ex& node_p0) {
    auto r_p1 = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("r")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(node_p0), Text::lit("result_value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
    auto last_p2 = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(node_p0), Text::lit("result_last")})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("as_ref"), Array<crate::lower::model::Ex>{}});
    auto differs_p3 = crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("!="), prism_rtl::rc(last_p2), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("r")}))})})}))});
    return Array(std::vector{r_p1, crate::lower::model::Do(crate::lower::model::Do::DoIf{differs_p3, Array(std::vector{result_kept(node_p0), result_tell()}), Array<crate::lower::model::Do>{}})});
}


/// ResultKept: fn Ex -> Do
crate::lower::model::Do result_kept(const crate::lower::model::Ex& node_p0) {
    return crate::lower::model::Do(crate::lower::model::Do::DoAssign{crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(node_p0), Text::lit("result_last")})), Text::lit("borrow_mut"), Array<crate::lower::model::Ex>{}}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("r")}))})})})});
}


/// let resultTell
crate::lower::model::Do result_tell() {
    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("result"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Outcome::Value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("r")})})})})})});
}


/// Adoption: fn FlatDef -> [Do]
Array<crate::lower::model::Do> adoption(const crate::lower::node_::FlatDef& fl_p0) {
    auto adopt_p1 = crate::lower::model::Ex(crate::lower::model::Ex::XLater{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(fl_p0.name, "_adopt"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))});
    return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("node")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("answer_later"), Array(std::vector{adopt_p1})})})});
}


/// PlaceAt: fn Wx, Text, Pos -> Ex
crate::lower::model::Ex place_at(const crate::lower::node_::Wx& wx_p0, const Text& recv_p1, const crate::lower::model::Pos_& pos_p2) {
    auto at_p3 = Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{pos_p2.at})});
    return emits(wx_p0, pos_p2)
        ? crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(recv_p1 == Text::lit("")
        ? crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("path")})
        : recv_p1 == Text::lit("self")
        ? crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("path")})
        : crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{recv_p1})), Text::lit("path")})), Text::lit("at"), at_p3})
        : crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Path::root"), Array<crate::lower::model::Ex>{}})), Text::lit("at"), at_p3});
}


/// PosPat: fn Pos, [Pa] -> Pa
crate::lower::model::Pa pos_pat(const crate::lower::model::Pos_& pos_p0, const Array<crate::lower::model::Pa>& tail_p1) {
    return crate::lower::model::Pa(crate::lower::model::Pa::PaSlice{append(Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Segment::Pos"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaIndex{pos_p0.at})})})}), tail_p1)});
}


/// let keyTail
Array<crate::lower::model::Pa> key_tail() {
    return Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Segment::Key"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("k")})})}), crate::lower::model::Pa(crate::lower::model::Pa::PaRest{Text::lit("rest")})});
}


/// let genTail
Array<crate::lower::model::Pa> gen_tail() {
    return Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Segment::Gen"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("g")})})}), crate::lower::model::Pa(crate::lower::model::Pa::PaRest{Text::lit("rest")})});
}


/// ?HostedRows: fn Wx -> ?Text
std::optional<Text> hosted_rows(const crate::lower::node_::Wx& wx_p0) {
    return prism_rtl::deref(wx_p0.pos).scope > Nat(0u)
        ? std::optional(prism_rtl::cat(or_(index(wx_p0.scopes, crate::syntax::lexer::chars::dec(prism_rtl::deref(wx_p0.pos).scope)), Text::lit("")), "_moved"))
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        auto&& _m = wx_p0.hosted_by;
        if (prism_rtl::is_some(_m)) {
            _v.set(std::optional(Text::lit("document_moved")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::optional<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// RootDynPatch: fn Wx -> [Do]
Array<crate::lower::model::Do> root_dyn_patch(const crate::lower::node_::Wx& wx_p0) {
    auto&& _m = wx_p0.root_dyn;
    if (prism_rtl::is_some(_m)) {
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLine{result_moved(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})});
    }
    if (prism_rtl::is_none(_m)) {
        return Array<crate::lower::model::Do>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// AnswerArm: fn Wx, Pos, Nat, OutTy -> ((Pa, Ex))
std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> answer_arm(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::Pos_& pos_p1, const Nat& id_p2, const crate::lower::model::OutTy& t_p3) {
    auto call_p4 = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::deref(crate::lower::node_::gn_of(wx_p0, id_p2)).name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XDecode{t_p3, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})});
    return std::tuple{pos_pat(pos_p1, Array<crate::lower::model::Pa>{}), call_p4};
}


/// TypedAnswerArm: fn Wx, Pos, Nat, Text -> ((Pa, [Do]))
std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_answer_arm(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::Pos_& pos_p1, const Nat& id_p2, const Text& acc_p3) {
    return std::tuple{pos_pat(pos_p1, Array<crate::lower::model::Pa>{}), Array(std::vector{self_call(prism_rtl::deref(crate::lower::node_::gn_of(wx_p0, id_p2)).name, Array(std::vector{crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})), acc_p3, Array<crate::lower::model::Ex>{}}))}))})};
}


/// TypedDynArm: fn Sinks, Pos, Text, Text -> ((Pa, [Do]))
std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_dyn_arm(const Sinks& sk_p0, const crate::lower::model::Pos_& pos_p1, const Text& f_p2, const Text& acc_p3) {
    return std::tuple{pos_pat(pos_p1, Array<crate::lower::model::Pa>{}), dyn_place_write(sk_p0, f_p2, crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})), acc_p3, Array<crate::lower::model::Ex>{}})))};
}


/// TypedForwardArm: fn ForDef, Ex -> ((Pa, [Do]))
std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_forward_arm(const crate::lower::model::ForDef& b_p0, const crate::lower::model::Ex& segs_p1) {
    auto row_of_p2 = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(b_p0.name)})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDecode{b_p0.key_ty, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("k")}))}))})})})), Text::lit("cloned"), Array<crate::lower::model::Ex>{}});
    return std::tuple{pos_pat(b_p0.pos, key_tail()), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")}), row_of_p2}), crate::lower::model::Do(crate::lower::model::Do::DoMatch{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")}), Array(std::vector{std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("deliver"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("rest")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})})}, std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoReturn{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Fault::answer"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XFormatStr{Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XText{Text::lit("no row ")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("k")}), crate::lower::model::Ex(crate::lower::model::Ex::XText{Text::lit(" under the hosted place ")}), crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Path"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(segs_p1), Text::lit("to_vec"), Array<crate::lower::model::Ex>{}})})})})})})})})})})})}})})})};
}


/// TypedGenArm: fn GenDef -> ((Pa, [Do]))
std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_gen_arm(const crate::lower::model::GenDef& gd_p0) {
    auto current_p1 = crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gd_p0.name)})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}}))});
    auto is_current_p2 = crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("+"), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("g")}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XIndex{Nat(1u)}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gd_p0.name, "_count")})), Text::lit("get"), Array<crate::lower::model::Ex>{}}))});
    return std::tuple{pos_pat(gd_p0.pos, gen_tail()), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")}), current_p1}), crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{is_current_p2, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("deliver"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("rest")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})}), Array<crate::lower::model::Do>{}})}), Array<crate::lower::model::Do>{}})})};
}


/// TypedDispatch: fn Sinks, Text, Nat -> MethDef
crate::lower::model::MethDef typed_dispatch(const Sinks& sk_p0, const Text& name_p1, const Nat& scope_p2) {
    auto wx_p3 = sk_p0.wx;
    auto in_scope_f4 = ({
        auto scope_p2_1 = scope_p2;
        static_cast<Fn<bool(const crate::lower::model::Pos_&)>>(prism_rtl::rc([=, scope_p2_1 = std::move(scope_p2_1)](const crate::lower::model::Pos_& p_pb) { return prism_rtl::deref(p_pb).scope == scope_p2_1; }));
    });
    auto [recv_pc, param_pd, segs_pe, doc_pf] = scope_p2 > Nat(0u)
        ? std::tuple{crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), std::tuple{Text::lit("place"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{}))})}, crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("place")})), Text::lit("segments"), Array<crate::lower::model::Ex>{}}), prism_rtl::cat("The host at place ", crate::lower::model::place_text(prism_rtl::deref(or_(index(prism_rtl::deref(wx_p3).hosts, crate::syntax::lexer::chars::dec(scope_p2)), dummy_host())).pos), " answers its child\'s place `place` (pick HO): into the child\'s input method, a hold the place\'s element answers, or the row of a `for` or `rebuild` under it.")}
        : std::tuple{crate::lower::model::Recv(crate::lower::model::Recv::RecvOwned{}), std::tuple{Text::lit("at"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutSlice{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Segment"), Array<crate::lower::model::OutTy>{}}))}))})}, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("at")}), Text::lit("A host\'s answer to a place of this row\'s own, `at` under the row (pick HO): into the input method, a hold, or a row under it.")};
    auto answers_p5 = each(filter(prism_rtl::deref(wx_p3).answers, [&](const std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos_pg = std::get<0>(_p0);
        return in_scope_f4(pos_pg);
    }), [&](const std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos_ph = std::get<0>(_p0);
        auto&& id_pi = std::get<1>(_p0);
        auto&& acc_pj = std::get<3>(_p0);
        return typed_answer_arm(wx_p3, pos_ph, id_pi, acc_pj);
    });
    auto dyns_p6 = each(filter(prism_rtl::deref(wx_p3).dyn_places, [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos_pk = std::get<0>(_p0);
        return in_scope_f4(pos_pk);
    }), [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos_pl = std::get<0>(_p0);
        auto&& f_pm = std::get<1>(_p0);
        auto&& acc_pn = std::get<3>(_p0);
        return typed_dyn_arm(sk_p0, pos_pl, f_pm, acc_pn);
    });
    auto rows_p7 = each(filter(prism_rtl::deref(wx_p3).builders, [&](const crate::lower::model::ForDef& b_po) { return in_scope_f4(prism_rtl::deref(b_po).pos); }), [&](const crate::lower::model::ForDef& b_pp) { return typed_forward_arm(b_pp, segs_pe); });
    auto gens_p8 = each(filter(prism_rtl::deref(wx_p3).gens, [&](const crate::lower::model::GenDef& gd_pq) { return in_scope_f4(prism_rtl::deref(gd_pq).pos); }), [&](const crate::lower::model::GenDef& gd_pr) { return typed_gen_arm(gd_pr); });
    auto none_p9 = std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoReturn{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Fault::answer"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XFormatStr{Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XText{Text::lit("no hosted place at ")}), crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Path"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(segs_pe), Text::lit("to_vec"), Array<crate::lower::model::Ex>{}})})}), crate::lower::model::Ex(crate::lower::model::Ex::XText{Text::lit(" to answer")})})})})})})})})})};
    auto arms_pa = crate::prelude::push(append(append(append(answers_p5, dyns_p6), rows_p7), gens_p8), none_p9);
    return crate::lower::model::MethDef{.name = name_p1, .recv = recv_pc, .params = Array(std::vector{param_pd, std::tuple{Text::lit("v"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::lower::types::answer_ty())})}}), .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Done"), Array<crate::lower::model::OutTy>{}}), .body = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoMatch{segs_pe, arms_pa})}), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})}), .doc = doc_pf};
}


/// let dummyHost
crate::lower::node_::HostDef dummy_host() {
    return crate::lower::node_::HostDef{.pos = crate::lower::model::pos0(), .name = Text::lit(""), .scope = Nat(0u)};
}


/// SortNats: fn [Nat] -> [Nat]
Array<Nat> sort_nats(const Array<Nat>& xs_p0) {
    return fold(xs_p0, Array<Nat>{}, [&](const Array<Nat>& acc_p1, const Nat& x_p2) { return append(crate::prelude::push(filter(acc_p1, [&](const Nat& y_p3) { return y_p3 < x_p2; }), x_p2), filter(acc_p1, [&](const Nat& y_p4) { return !(y_p4 < x_p2); })); });
}


/// AskWake: fn Sinks, Nat -> [Do]
Array<crate::lower::model::Do> ask_wake(const Sinks& sk_p0, const Nat& h_p1) {
    auto c_p2 = crate::lower::model::Ex(crate::lower::model::Ex::XConst{wake_const(sk_p0.heights, h_p1)});
    auto ask_p3 = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("wakes")})), Text::lit("ask"), Array(std::vector{c_p2})})});
    auto wake_p4 = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("wake"), Array(std::vector{c_p2, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})})});
    return sk_p0.many
        ? Array(std::vector{ask_p3, wake_p4})
        : Array(std::vector{wake_p4});
}


/// GatherIn: fn Sinks, Gn -> MethDef
crate::lower::model::MethDef gather_in(const Sinks& sk_p0, const crate::lower::node_::Gn& g_p1) {
    auto field_p2 = or_(index(g_p1.inputs, Nat(0u)), Text::lit(""));
    auto kt_p3 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        auto&& _m = g_p1.ty;
        if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(_m)) {
            auto&& k_p8 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(_m).a0;
            _v.set(prism_rtl::deref(prism_rtl::deref(k_p8)));
            goto _done;
        }
        {
            _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto vt_p4 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        auto&& _m = g_p1.ty;
        if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(_m)) {
            auto&& v_p9 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(_m).a1;
            _v.set(prism_rtl::deref(prism_rtl::deref(v_p9)));
            goto _done;
        }
        {
            _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto current_p5 = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(field_p2)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("unwrap_or_default"), Array<crate::lower::model::Ex>{}});
    auto collect_p6 = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("all")}), current_p5}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("all")})), Text::lit("insert"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("k")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})})})}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(field_p2)})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("all")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})});
    auto body_p7 = append(collect_p6, ask_wake(sk_p0, g_p1.height));
    return crate::lower::model::MethDef{.name = prism_rtl::cat(g_p1.name, "_in"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("k"), kt_p3}, std::tuple{Text::lit("v"), vt_p4}}), .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = body_p7, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("A row\'s firing, gathered by its key.")};
}


/// Decide: fn Gn -> Do
crate::lower::model::Do decide(const crate::lower::node_::Gn& g_p0) {
    auto&& _m = g_p0.kind;
    if (prism_rtl::is<crate::lower::node_::GnKind::GnGather>(_m)) {
        return crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(or_(index(g_p0.inputs, Nat(0u)), Text::lit("")))})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{self_call(g_p0.name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}))}), Array<crate::lower::model::Do>{}});
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnMerge>(_m)) {
        return merge_decide(g_p0);
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnUpdated>(_m)) {
        return updated_decide(g_p0);
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnMergeAll>(_m)) {
        auto pushes_p1 = each(g_p0.inputs, [&](const Text& f_p4) { return crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("x")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f_p4)})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("all")})), Text::lit("push_back"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("x")})})})})}), Array<crate::lower::model::Do>{}}); });
        auto start_p2 = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("all")})), g_p0.ty}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Array::new"), Array<crate::lower::model::Ex>{}})});
        auto fire_p3 = crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("!"), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("all")})), Text::lit("is_empty"), Array<crate::lower::model::Ex>{}}))}), Array(std::vector{self_call(g_p0.name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("all")})}))}), Array<crate::lower::model::Do>{}});
        return crate::lower::model::Do(crate::lower::model::Do::DoBlock{crate::prelude::push(append(Array(std::vector{start_p2}), pushes_p1), fire_p3)});
    }
    {
        auto&& kind_p5 = _m;
        return pair_decide(g_p0, kind_p5);
    }
}


/// UpdatedDecide: fn Gn -> Do
crate::lower::model::Do updated_decide(const crate::lower::node_::Gn& g_p0) {
    return crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(g_p0.name, "_moved")})), Text::lit("replace"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false})})}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("after")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("after"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(g_p0.name, "_value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})})})}), self_call(g_p0.name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("after")})}))}), Array<crate::lower::model::Do>{}});
}


/// PairDecide: fn Gn, GnKind -> Do
crate::lower::model::Do pair_decide(const crate::lower::node_::Gn& g_p0, const crate::lower::node_::GnKind& kind_p1) {
    auto get_l_p2 = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(or_(index(g_p0.inputs, Nat(0u)), Text::lit("")))})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})});
    auto get_r_p3 = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(or_(index(g_p0.inputs, Nat(1u)), Text::lit("")))})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})});
    auto both_p4 = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{get_l_p2, get_r_p3})});
    auto fire_f5 = ({
        auto g_p0_1 = g_p0;
        (static_cast<Fn<Array<crate::lower::model::Do>(const crate::lower::model::Ex&)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1)](const crate::lower::model::Ex& x_pc) { return Array(std::vector{self_call(g_p0_1.name, Array(std::vector{x_pc}))}); })));
    });
    auto sa_p6 = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a")})})});
    auto sb_p7 = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("b")})})});
    auto some2_p8 = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{sa_p6, sb_p7})});
    auto left_p9 = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{sa_p6, crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")})})});
    auto right_pa = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), sb_p7})});
    auto cases_pb = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>>> _v;
        if (prism_rtl::is<crate::lower::node_::GnKind::GnUnion>(kind_p1)) {
            _v.set(Array(std::vector{std::tuple{some2_p8, fire_f5(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("union"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("a")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("b")}))})})}))}, std::tuple{left_p9, fire_f5(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("a")}))}, std::tuple{right_pa, fire_f5(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("b")}))}, std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), Array<crate::lower::model::Do>{}}}));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::node_::GnKind::GnBoth>(kind_p1)) {
            _v.set(Array(std::vector{std::tuple{some2_p8, fire_f5(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("a")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("b")})})}))}, std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), Array<crate::lower::model::Do>{}}}));
            goto _done;
        }
        {
            _v.set(Array(std::vector{std::tuple{left_p9, fire_f5(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("a")}))}, std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), Array<crate::lower::model::Do>{}}}));
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::lower::model::Do(crate::lower::model::Do::DoMatch{both_p4, cases_pb});
}


/// WakeByHeight: fn [Gn], [Nat] -> Do
crate::lower::model::Do wake_by_height(const Array<crate::lower::node_::Gn>& combs_p0, const Array<Nat>& heights_p1) {
    return crate::lower::model::Do(crate::lower::model::Do::DoMatch{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("wakes")})), Text::lit("next"), Array<crate::lower::model::Ex>{}}), crate::prelude::push(each(heights_p1, [&](const Nat& h_p2) { return std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaConst{wake_const(heights_p1, h_p2)}), each(filter(combs_p0, [&](const crate::lower::node_::Gn& g_p3) { return prism_rtl::deref(g_p3).height == h_p2; }), [&](const crate::lower::node_::Gn& g_p4) { return decide(g_p4); })}; }), std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), Array<crate::lower::model::Do>{}})});
}


/// ForwardAnswer: fn ForDef -> Ex
crate::lower::model::Ex forward_answer(const crate::lower::model::ForDef& b_p0) {
    auto row_of_p1 = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(b_p0.name)})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDecode{b_p0.key_ty, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("k")}))}))})})})), Text::lit("cloned"), Array<crate::lower::model::Ex>{}});
    return crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")}), row_of_p1}), crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("answer"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("rest")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})}), Array<crate::lower::model::Do>{}})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))});
}


/// IsHold: fn OutTy -> Bool
bool is_hold(const crate::lower::model::OutTy& out_ty0) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutHold>(out_ty0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(out_ty0)) {
        auto&& c1_0_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(out_ty0).a0;
        if (c1_0_0 == Text::lit("prism_rtl::PerKey")) {
            return true;
        }
    }
    {
        auto&& other_p0 = out_ty0;
        return false;
    }
}


/// RowMethods: fn Wx -> [MethDef]
Array<crate::lower::model::MethDef> row_methods(const crate::lower::node_::Wx& wx_p0) {
    auto removes_p1 = fold(filter(wx_p0.places, [&](const crate::lower::node_::Place& p_p3) { return emits(wx_p0, prism_rtl::deref(p_p3).pos); }), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc_p4, const crate::lower::node_::Place& p_p5) {
        return append(acc_p4, append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("removed"), Array(std::vector{place_at(wx_p0, Text::lit("self"), prism_rtl::deref(p_p5).pos)})})})}), prism_rtl::deref(p_p5).watch == Text::lit("")
            ? Array<crate::lower::model::Do>{}
            : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::deref(p_p5).watch})), Text::lit("drop_all"), Array<crate::lower::model::Ex>{}})})})));
    });
    auto nested_p2 = append(each(wx_p0.builders, [&](const crate::lower::model::ForDef& b_p6) { return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::deref(b_p6).name})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("values"), Array<crate::lower::model::Ex>{}})), Text::lit("for_each"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("leave_row"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})})})}); }), each(wx_p0.gens, [&](const crate::lower::model::GenDef& gd_p7) { return crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::deref(gd_p7).name})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("as_ref"), Array<crate::lower::model::Ex>{}}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("leave_row"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), Array<crate::lower::model::Do>{}}); }));
    return Array(std::vector{crate::lower::model::MethDef{.name = Text::lit("remove_places"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = append(removes_p1, nested_p2), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("The row left: its places are torn down.")}});
}


/// GnDoc: fn Gn -> Text
Text gn_doc(const crate::lower::node_::Gn& g_p0) {
    auto&& _m = g_p0.kind;
    if (prism_rtl::is<crate::lower::node_::GnKind::GnAnswer>(_m)) {
        return prism_rtl::cat("`", g_p0.name, "`: an answer at its place.");
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnStarted>(_m)) {
        return Text::lit("`@started`, the tick after the build.");
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnDeferred>(_m)) {
        return Text::lit("An `@Defer` firing, the tick after it was armed.");
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnMerge>(_m)) {
        return prism_rtl::cat("The merge `", g_p0.name, "`, decided in the wake.");
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnUpdated>(_m)) {
        return Text::lit("`!Updated`: the dynamic\'s value after the tick, fired in the wake when a hold it reads was written (or a structural dynamic it reads was published, pick ST).");
    }
    {
        return prism_rtl::cat("`!", g_p0.name, "`.");
    }
}


/// MergeDecide: fn Gn -> Do
crate::lower::model::Do merge_decide(const crate::lower::node_::Gn& g_p0) {
    auto call_p1 = Array(std::vector{self_call(g_p0.name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}))});
    auto take_l_p2 = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("left")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(or_(index(g_p0.inputs, Nat(0u)), Text::lit("")))})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
    auto take_r_p3 = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("right")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(or_(index(g_p0.inputs, Nat(1u)), Text::lit("")))})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
    auto right_p4 = crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("right")}), call_p1, Array<crate::lower::model::Do>{}});
    return crate::lower::model::Do(crate::lower::model::Do::DoBlock{Array(std::vector{take_l_p2, take_r_p3, crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("left")}), call_p1, Array(std::vector{right_p4})})})});
}

}  // namespace crate::lower::node_::finish
