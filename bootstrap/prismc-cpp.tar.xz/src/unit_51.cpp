// The module `Lower.Templates`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/templates/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Templates`, from `target/bootstrap/cpp-src/prismc/lower/templates.prism`.
namespace crate::lower::templates {

/// TemplateValue: unbounded fn Lx, Env, Template -> Vl
crate::lower::types::Vl template_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Template& tp) {
    auto start = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("out")}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("String::new"), Array<crate::lower::model::Ex>{}})})});
    auto dos = run_to_end(fold_job(tp.parts, start, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto part = p1;
                call_then(start_template_part_dos(lx_1_3, env_2_3, part), [=](Array<crate::lower::model::Do> template_part_dos_1601) { return prism_rtl::finished(append(acc, template_part_dos_1601)); });
            });
        }));
        });
    })));
    })));
    return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Text::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})})}))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})});
}


prism_rtl::Turn<crate::lower::types::Vl> TemplateValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& tp = this->tp;
    auto start = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("out")}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("String::new"), Array<crate::lower::model::Ex>{}})})});
    auto env_1 = env;
    auto lx_2 = lx;
    auto tp_3 = tp;
    return call_value(fold_job(prism_rtl::val(tp_3).parts, start, ({
        auto lx_2_4 = lx_2;
        auto env_1_4 = env_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_2_4_4 = lx_2_4;
            auto env_1_4_4 = env_1_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto part = p1;
                call_then(start_template_part_dos(lx_2_4_4, env_1_4_4, part), [=](Array<crate::lower::model::Do> template_part_dos_1601) { return prism_rtl::finished(append(acc, template_part_dos_1601)); });
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::Do> fold_1553) {
        return ({
            auto dos = fold_1553;
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Text::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})})}))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})));
        });
    });
}


/// `Start TemplateValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_template_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Template tp) {
    return prism_rtl::make_rc<TemplateValue>(lx, env, tp);
}


/// TemplatePartDos: unbounded fn Lx, Env, TemplatePart -> [Do]
Array<crate::lower::model::Do> template_part_dos(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::TemplatePart& part) {
    if (prism_rtl::is<crate::syntax::TemplatePart::TpText>(part)) {
        auto&& t = prism_rtl::as<crate::syntax::TemplatePart::TpText>(part).a0;
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})), Text::lit("push_str"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{t})})})})});
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(part)) {
        auto&& x = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part).a0;
        auto&& col_opt = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part).a1;
        auto v_ = crate::lower::expr::value_of(lx, env, x);
        auto column = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::Ex> _v;
            if (prism_rtl::is_some(col_opt)) {
                auto&& c = prism_rtl::some_of(col_opt);
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{c})})}));
                goto _done;
            }
            if (prism_rtl::is_none(col_opt)) {
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XNone{}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("place"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), shown_text(v_), column})})})});
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(part)) {
        auto&& b = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(part).a0;
        auto v_ = crate::lower::expr::block_value(lx, env, b);
        return crate::lower::types::value_ty(v_) == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
            ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own(v_)})})
            : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("place"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), shown_text(v_), crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})})});
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpCall>(part)) {
        auto&& n = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a0;
        auto&& args = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a1;
        auto&& parts_opt = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a2;
        auto plain = crate::syntax::SName{.sigils = crate::syntax::lexer::chars::after_first(prism_rtl::val(n).sigils), .path_ = n->path_, .span = prism_rtl::val(n).span};
        auto&& _qk_opt = crate::check::env::names::resolve_value(lx.g, lx.home, n);
        auto&& qk_opt = std::get<0>(_qk_opt);
        auto&& _qk2_opt = crate::check::env::names::resolve_value(lx.g, lx.home, plain);
        auto&& qk2_opt = std::get<0>(_qk2_opt);
        auto callee = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(crate::lower::value_path(lx, q));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    if (prism_rtl::is_some(qk2_opt)) {
                        auto&& q = prism_rtl::some_of(qk2_opt);
                        _v.set(crate::lower::value_path(lx, q));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk2_opt)) {
                        _v.set(crate::lower::snake(crate::check::env::sname_key(n)));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto body = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
            if (prism_rtl::is_some(parts_opt)) {
                auto&& ps = prism_rtl::some_of(parts_opt);
                _v.set(({
                    auto inner = run_to_end(fold_job(ps, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("out")}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("String::new"), Array<crate::lower::model::Ex>{}})})}), ({
                        auto lx_1 = lx;
                        auto env_2 = env;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto lx_1_3 = lx_1;
                            auto env_2_3 = env_2;
                            entered(once_job([=]() {
                            return ({
                                auto acc = p0;
                                auto p_ = p1;
                                call_then(start_template_part_dos(lx_1_3, env_2_3, p_), [=](Array<crate::lower::model::Do> template_part_dos_2911) { return prism_rtl::finished(append(acc, template_part_dos_2911)); });
                            });
                        }));
                        });
                    })));
                    })));
                    (Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{inner, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Text::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})})}))}))})}));
                }));
                goto _done;
            }
            if (prism_rtl::is_none(parts_opt)) {
                _v.set(Array<crate::lower::model::Ex>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto passed = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(template_args(lx, env, q, args, body));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                    if (prism_rtl::is_some(qk2_opt)) {
                        auto&& q = prism_rtl::some_of(qk2_opt);
                        _v.set(template_args(lx, env, q, args, body));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk2_opt)) {
                        _v.set(append(run_to_end(each_job(args, ({
                            auto lx_1 = lx;
                            auto env_2 = env;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
                            return ({
                                auto lx_1_3 = lx_1;
                                auto env_2_3 = env_2;
                                entered(once_job([=]() {
                                return ({
                                    auto a = p0;
                                    (prism_rtl::more(prism_rtl::rc(crate::lower::expr::Argument(lx_1_3, env_2_3, a->value))));
                                });
                            }));
                            });
                        })));
                        }))), body));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto call = crate::lower::model::Ex(crate::lower::model::Ex::XCall{callee, passed});
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("place"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(call)}), crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})})});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::lower::model::Do>> TemplatePartDos::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& part = this->part;
    return ({
        prism_rtl::is<crate::syntax::TemplatePart::TpText>(part) ? ({
        auto&& t = prism_rtl::as<crate::syntax::TemplatePart::TpText>(part).a0;
        prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})), Text::lit("push_str"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{t})})})})}));
    })
        : prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(part) ? ({
        auto&& x = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part).a0;
        auto&& col_opt = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part).a1;
        ({
        auto col_opt_1 = col_opt;
        auto env_2 = env;
        auto lx_3 = lx;
        auto x_4 = x;
        call_then(crate::lower::expr::start_value_of(lx_3, env_2, x_4), [=](crate::lower::types::Vl value_of_1931) {
        return ({
            auto v_ = value_of_1931;
            auto column = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::Ex> _v;
                if (prism_rtl::is_some(col_opt_1)) {
                    auto&& c = prism_rtl::some_of(col_opt_1);
                    _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{c})})}));
                    goto _done;
                }
                if (prism_rtl::is_none(col_opt_1)) {
                    _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XNone{}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("place"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), shown_text(v_), column})})})})));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(part) ? ({
        auto&& b = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(part).a0;
        ({
        auto b_1 = b;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(crate::lower::expr::start_block_value(lx_3, env_2, b_1), [=](crate::lower::types::Vl block_value_2165) {
        return ({
            auto v_ = block_value_2165;
            (crate::lower::types::value_ty(v_) == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
            ? prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own(v_)})}))
            : prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("place"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), shown_text(v_), crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})})})));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TemplatePart::TpCall>(part) ? ({
        auto&& n = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a0;
        auto&& args = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a1;
        auto&& parts_opt = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a2;
        ({
        auto plain = crate::syntax::SName{.sigils = crate::syntax::lexer::chars::after_first(prism_rtl::val(n).sigils), .path_ = n->path_, .span = prism_rtl::val(n).span};
        auto&& _qk_opt = crate::check::env::names::resolve_value(prism_rtl::val(lx).g, prism_rtl::val(lx).home, n);
        auto&& qk_opt = std::get<0>(_qk_opt);
        auto&& _qk2_opt = crate::check::env::names::resolve_value(prism_rtl::val(lx).g, prism_rtl::val(lx).home, plain);
        auto&& qk2_opt = std::get<0>(_qk2_opt);
        auto callee = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(crate::lower::value_path(lx, q));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    if (prism_rtl::is_some(qk2_opt)) {
                        auto&& q = prism_rtl::some_of(qk2_opt);
                        _v.set(crate::lower::value_path(lx, q));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk2_opt)) {
                        _v.set(crate::lower::snake(crate::check::env::sname_key(n)));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto body = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
            if (prism_rtl::is_some(parts_opt)) {
                auto&& ps = prism_rtl::some_of(parts_opt);
                _v.set(({
                    auto inner = run_to_end(fold_job(ps, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("out")}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("String::new"), Array<crate::lower::model::Ex>{}})})}), ({
                        auto lx_1 = lx;
                        auto env_2 = env;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto lx_1_3 = lx_1;
                            auto env_2_3 = env_2;
                            entered(once_job([=]() {
                            return ({
                                auto acc = p0;
                                auto p_ = p1;
                                call_then(start_template_part_dos(lx_1_3, env_2_3, p_), [=](Array<crate::lower::model::Do> template_part_dos_2911) { return prism_rtl::finished(append(acc, template_part_dos_2911)); });
                            });
                        }));
                        });
                    })));
                    })));
                    (Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{inner, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Text::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})})}))}))})}));
                }));
                goto _done;
            }
            if (prism_rtl::is_none(parts_opt)) {
                _v.set(Array<crate::lower::model::Ex>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto passed = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(template_args(lx, env, q, args, body));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                    if (prism_rtl::is_some(qk2_opt)) {
                        auto&& q = prism_rtl::some_of(qk2_opt);
                        _v.set(template_args(lx, env, q, args, body));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk2_opt)) {
                        _v.set(append(run_to_end(each_job(args, ({
                            auto lx_1 = lx;
                            auto env_2 = env;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
                            return ({
                                auto lx_1_3 = lx_1;
                                auto env_2_3 = env_2;
                                entered(once_job([=]() {
                                return ({
                                    auto a = p0;
                                    (prism_rtl::more(prism_rtl::rc(crate::lower::expr::Argument(lx_1_3, env_2_3, a->value))));
                                });
                            }));
                            });
                        })));
                        }))), body));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto call = crate::lower::model::Ex(crate::lower::model::Ex::XCall{callee, passed});
        (prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("place"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(call)}), crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})})})));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplatePartDos, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Do>> start_template_part_dos(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::TemplatePart part) {
    return prism_rtl::make_rc<TemplatePartDos>(lx, env, part);
}


/// TemplateArgs: unbounded fn Lx, Env, Text, [Arg], [Ex] -> [Ex]
Array<crate::lower::model::Ex> template_args(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Text& qk, const Array<crate::syntax::Arg>& args, const Array<crate::lower::model::Ex>& body) {
    auto clauses = crate::lower::jobs::clauses_of(lx.g, qk);
    auto arity = len(prism_rtl::val(or_(index(clauses, Nat(0u)), crate::lower::functions::dummy_clause())).params);
    return run_to_end(each_job(crate::check::errors::range0(arity), ({
        auto body_1 = body;
        auto arity_2 = arity;
        auto clauses_3 = clauses;
        auto args_4 = args;
        auto lx_5 = lx;
        auto env_6 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto body_1_7 = body_1;
            auto arity_2_7 = arity_2;
            auto clauses_3_7 = clauses_3;
            auto args_4_7 = args_4;
            auto lx_5_7 = lx_5;
            auto env_6_7 = env_6;
            entered(once_job([=]() {
            return ({
                auto j = p0;
                (len(body_1_7) > Nat(0u)) && ((j + Nat(1u)) == arity_2_7)
                ? prism_rtl::finished(or_(index(body_1_7, Nat(0u)), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})))
                : ({
                auto&& _m = attr_at(clauses_3_7, j, args_4_7);
                prism_rtl::is_some(_m) ? ({
                auto&& a = prism_rtl::some_of(_m);
                prism_rtl::more(prism_rtl::rc(crate::lower::expr::Argument(lx_5_7, env_6_7, a->value)));
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::expr::refusal(prism_rtl::cat("a template call that fills no argument at place ", j)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Ex>> TemplateArgs::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& qk = this->qk;
    const auto& args = this->args;
    const auto& body = this->body;
    auto clauses = crate::lower::jobs::clauses_of(prism_rtl::val(lx).g, qk);
    auto arity = len(prism_rtl::val(or_(index(clauses, Nat(0u)), crate::lower::functions::dummy_clause())).params);
    return each_job(crate::check::errors::range0(arity), ({
        auto body_1 = body;
        auto arity_2 = arity;
        auto clauses_3 = clauses;
        auto args_4 = args;
        auto lx_5 = lx;
        auto env_6 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto body_1_7 = body_1;
            auto arity_2_7 = arity_2;
            auto clauses_3_7 = clauses_3;
            auto args_4_7 = args_4;
            auto lx_5_7 = lx_5;
            auto env_6_7 = env_6;
            entered(once_job([=]() {
            return ({
                auto j = p0;
                (len(body_1_7) > Nat(0u)) && ((j + Nat(1u)) == arity_2_7)
                ? prism_rtl::finished(or_(index(body_1_7, Nat(0u)), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})))
                : ({
                auto&& _m = attr_at(clauses_3_7, j, args_4_7);
                prism_rtl::is_some(_m) ? ({
                auto&& a = prism_rtl::some_of(_m);
                prism_rtl::more(prism_rtl::rc(crate::lower::expr::Argument(lx_5_7, env_6_7, a->value)));
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::expr::refusal(prism_rtl::cat("a template call that fills no argument at place ", j)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start TemplateArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_template_args(crate::lower::Lx lx, crate::lower::types::Env env, Text qk, Array<crate::syntax::Arg> args, Array<crate::lower::model::Ex> body) {
    return prism_rtl::make_rc<TemplateArgs>(lx, env, qk, args, body);
}


/// ?AttrAt: fn [FnClause], Nat, [Arg] -> ?Arg
std::optional<crate::syntax::Arg> attr_at(const Array<crate::syntax::decls::FnClause>& clauses, const Nat& j, const Array<crate::syntax::Arg>& args) {
    auto names = fold(clauses, Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::decls::FnClause& c) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = index(prism_rtl::val(c).params, j);
            if (prism_rtl::is_some(_m)) {
                auto&& p_ = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = place_name(p_);
                    if (prism_rtl::is_some(_m)) {
                        auto&& n = prism_rtl::some_of(_m);
                        _v.set(crate::check::types::add_text(acc, n));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    return fold(args, std::optional<crate::syntax::Arg>{}, [&](const std::optional<crate::syntax::Arg>& found_opt, const crate::syntax::Arg& a) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::syntax::Arg>> _v;
            auto&& _m = prism_rtl::val(a).name;
            if (prism_rtl::is_some(_m)) {
                auto&& n = prism_rtl::some_of(_m);
                _v.set(crate::check::types::has_text(names, prism_rtl::val(n).name)
                    ? std::optional(a)
                    : found_opt);
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(found_opt);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// ?PlaceName: fn Pattern -> ?Text
std::optional<Text> place_name(const crate::syntax::Pattern_& p_) {
    auto&& _m = prism_rtl::val(p_.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return std::optional(crate::check::env::dotted(n->path_));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return place_name(prism_rtl::val(prism_rtl::val(q)));
    }
    {
        return std::optional<Text>{};
    }
}


/// ShownText: fn Vl -> Ex
crate::lower::model::Ex shown_text(const crate::lower::types::Vl& v_) {
    auto&& _m = crate::lower::types::value_ty(v_);
    if (prism_rtl::is<crate::lower::model::OutTy::OutText>(_m)) {
        return crate::lower::types::ref_(v_);
    }
    {
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("show_text"), Array(std::vector{crate::lower::types::ref_(v_)})}))});
    }
}


/// GivenValue: unbounded fn Lx, Env, Block, OutTy, Range -> Vl
crate::lower::types::Vl given_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Block& b, const crate::lower::model::OutTy& t, const crate::syntax::Range& span) {
    auto label = prism_rtl::cat("\'g", span.start);
    auto is_try = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto n = len(b.stmts);
    auto [dos, env2, last_opt] = run_to_end(fold_job(crate::check::errors::range0(n), std::tuple{Array<crate::lower::model::Do>{}, env, std::optional<crate::lower::types::Vl>{}}, ({
        auto b_1 = b;
        auto is_try_2 = is_try;
        auto lx_3 = lx;
        auto label_4 = label;
        auto n_5 = n;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_6 = b_1;
            auto is_try_2_6 = is_try_2;
            auto lx_3_6 = lx_3;
            auto label_4_6 = label_4;
            auto n_5_6 = n_5;
            entered(once_job([=]() {
            return ({
                auto [acc, en, lv_opt] = p0;
                auto i = p1;
                ({
                auto s = or_(index(b_1_6.stmts, i), crate::lower::expr::dummy_stmt_l());
                auto fail = is_try_2_6
                    ? crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Error::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("Prelude.Unmet")}), crate::lower::model::Ex(crate::lower::model::Ex::XStr{source_text(lx_3_6, prism_rtl::val(s).span)})})})})})
                    : crate::lower::model::Ex(crate::lower::model::Ex::XNone{});
                ({
                auto&& _m = prism_rtl::val(s).kind;
                prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
                ({
                auto p__6 = p_;
                auto x_7 = x;
                call_then(crate::lower::expr::start_value_of(lx_3_6, en, x_7), [=](crate::lower::types::Vl value_of_5845) {
                return ({
                    auto v_ = value_of_5845;
                    call_then(crate::lower::patterns::start_rust_pat(lx_3_6, p__6, crate::lower::patterns::inner_ty(crate::lower::type_at(lx_3_6, prism_rtl::val(x_7).span)), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("g", prism_rtl::val(prism_rtl::val(s).span).start)), [=](crate::lower::patterns::PatOut rust_pat_5888) {
                    return ({
                        auto po = rust_pat_5888;
                        call_then(crate::lower::types::start_out_ty_of(lx_3_6, crate::lower::patterns::inner_ty(crate::lower::type_at(lx_3_6, prism_rtl::val(x_7).span))), [=](crate::lower::model::OutTy out_ty_of_6030) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, given_bind(is_try_2_6, prism_rtl::val(po).pa, crate::lower::types::own(v_), label_4_6, out_ty_of_6030)), crate::lower::expr::bind_all(en, prism_rtl::val(po).binds), lv_opt}); });
                    });
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m) ? ({
                auto&& c = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
                ({
                auto c_6 = c;
                call_then(crate::lower::expr::start_value_of(lx_3_6, en, c_6), [=](crate::lower::types::Vl value_of_6171) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("!"), prism_rtl::rc(crate::lower::types::as_bool(value_of_6171))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label_4_6, prism_rtl::rc(fail)})})}), Array<crate::lower::model::Do>{}})), en, lv_opt}); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m) ? ({
                auto&& c = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
                ({
                auto c_6 = c;
                call_then(crate::lower::expr::start_value_of(lx_3_6, en, c_6), [=](crate::lower::types::Vl value_of_6295) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::types::as_bool(value_of_6295), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label_4_6, prism_rtl::rc(fail)})})}), Array<crate::lower::model::Do>{}})), en, lv_opt}); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                (i + Nat(1u)) == n_5_6
                ? prism_rtl::finished(std::tuple{acc, en, std::optional(crate::lower::expr::value_of(lx_3_6, en, x))})
                : ({
                auto x_6 = x;
                call_then(crate::lower::expr::start_value_of(lx_3_6, en, x_6), [=](crate::lower::types::Vl value_of_6503) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own(value_of_6503)})), en, lv_opt}); });
            });
            })
                : call_then(crate::lower::expr::start_block_stmt(lx_3_6, en, s), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt_6595) {
                return ({
                    auto [more_, en2] = block_stmt_6595;
                    (prism_rtl::finished(std::tuple{append(acc, more_), en2, lv_opt}));
                });
            });
            });
            });
            });
        }));
        });
    }));
    })));
    auto last = or_(last_opt, crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XNone{}), t}));
    return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XLabeled{label, dos, prism_rtl::rc(crate::lower::types::own(last)), t}), t});
}


prism_rtl::Turn<crate::lower::types::Vl> GivenValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& b = this->b;
    const auto& t = this->t;
    const auto& span = this->span;
    auto label = prism_rtl::cat("\'g", prism_rtl::val(span).start);
    auto is_try = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto n = len(prism_rtl::val(b).stmts);
    auto b_1 = b;
    auto env_2 = env;
    auto lx_3 = lx;
    auto span_4 = span;
    auto t_5 = t;
    return call_value(fold_job(crate::check::errors::range0(n), std::tuple{Array<crate::lower::model::Do>{}, env_2, std::optional<crate::lower::types::Vl>{}}, ({
        auto b_1_6 = b_1;
        auto is_try_6 = is_try;
        auto lx_3_7 = lx_3;
        auto label_7 = label;
        auto n_8 = n;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_6_9 = b_1_6;
            auto is_try_6_9 = is_try_6;
            auto lx_3_7_9 = lx_3_7;
            auto label_7_9 = label_7;
            auto n_8_9 = n_8;
            entered(once_job([=]() {
            return ({
                auto [acc, en, lv_opt] = p0;
                auto i = p1;
                ({
                auto s = or_(index(prism_rtl::val(b_1_6_9).stmts, i), crate::lower::expr::dummy_stmt_l());
                auto fail = is_try_6_9
                    ? crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Error::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("Prelude.Unmet")}), crate::lower::model::Ex(crate::lower::model::Ex::XStr{source_text(lx_3_7_9, prism_rtl::val(s).span)})})})})})
                    : crate::lower::model::Ex(crate::lower::model::Ex::XNone{});
                ({
                auto&& _m = prism_rtl::val(s).kind;
                prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
                ({
                auto p__9 = p_;
                auto x_10 = x;
                call_then(crate::lower::expr::start_value_of(lx_3_7_9, en, x_10), [=](crate::lower::types::Vl value_of_5845) {
                return ({
                    auto v_ = value_of_5845;
                    call_then(crate::lower::patterns::start_rust_pat(lx_3_7_9, p__9, crate::lower::patterns::inner_ty(crate::lower::type_at(lx_3_7_9, prism_rtl::val(x_10).span)), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("g", prism_rtl::val(prism_rtl::val(s).span).start)), [=](crate::lower::patterns::PatOut rust_pat_5888) {
                    return ({
                        auto po = rust_pat_5888;
                        call_then(crate::lower::types::start_out_ty_of(lx_3_7_9, crate::lower::patterns::inner_ty(crate::lower::type_at(lx_3_7_9, prism_rtl::val(x_10).span))), [=](crate::lower::model::OutTy out_ty_of_6030) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, given_bind(is_try_6_9, prism_rtl::val(po).pa, crate::lower::types::own(v_), label_7_9, out_ty_of_6030)), crate::lower::expr::bind_all(en, prism_rtl::val(po).binds), lv_opt}); });
                    });
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m) ? ({
                auto&& c = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
                ({
                auto c_9 = c;
                call_then(crate::lower::expr::start_value_of(lx_3_7_9, en, c_9), [=](crate::lower::types::Vl value_of_6171) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("!"), prism_rtl::rc(crate::lower::types::as_bool(value_of_6171))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label_7_9, prism_rtl::rc(fail)})})}), Array<crate::lower::model::Do>{}})), en, lv_opt}); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m) ? ({
                auto&& c = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
                ({
                auto c_9 = c;
                call_then(crate::lower::expr::start_value_of(lx_3_7_9, en, c_9), [=](crate::lower::types::Vl value_of_6295) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::types::as_bool(value_of_6295), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label_7_9, prism_rtl::rc(fail)})})}), Array<crate::lower::model::Do>{}})), en, lv_opt}); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                (i + Nat(1u)) == n_8_9
                ? prism_rtl::finished(std::tuple{acc, en, std::optional(crate::lower::expr::value_of(lx_3_7_9, en, x))})
                : ({
                auto x_9 = x;
                call_then(crate::lower::expr::start_value_of(lx_3_7_9, en, x_9), [=](crate::lower::types::Vl value_of_6503) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own(value_of_6503)})), en, lv_opt}); });
            });
            })
                : call_then(crate::lower::expr::start_block_stmt(lx_3_7_9, en, s), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt_6595) {
                return ({
                    auto [more_, en2] = block_stmt_6595;
                    (prism_rtl::finished(std::tuple{append(acc, more_), en2, lv_opt}));
                });
            });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>> fold_5529) {
        return ({
            auto [dos, env2, last_opt] = fold_5529;
            auto last = or_(last_opt, crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XNone{}), t_5}));
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XLabeled{label, dos, prism_rtl::rc(crate::lower::types::own(last)), t_5}), t_5})));
        });
    });
}


/// `Start GivenValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_given_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Block b, crate::lower::model::OutTy t, crate::syntax::Range span) {
    return prism_rtl::make_rc<GivenValue>(lx, env, b, t, span);
}


/// GivenBind: fn Bool, Pa, Ex, Text, OutTy -> Do
crate::lower::model::Do given_bind(const bool& is_try, const crate::lower::model::Pa& pa, const crate::lower::model::Ex& x, const Text& label, const crate::lower::model::OutTy& t) {
    return prism_rtl::val(is_try)
        ? crate::lower::model::Do(crate::lower::model::Do::DoLet{pa, crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(x), Array(std::vector{crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Ok"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("e")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("e")})})}))})}}), false, t})})
        : crate::lower::model::Do(crate::lower::model::Do::DoLetElse{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{pa})}), x, crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNone{}))})});
}


/// SourceText: fn Lx, Range -> Text
Text source_text(const crate::lower::Lx& lx, const crate::syntax::Range& r) {
    auto&& _m = index(prism_rtl::val(lx.g).srcs, lx.file);
    if (prism_rtl::is_some(_m)) {
        auto&& src = prism_rtl::some_of(_m);
        return crate::check::errors::span_text(src, r);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// UpdateValue: unbounded fn Lx, Env, Expr, Block, OutTy, Range -> Vl
crate::lower::types::Vl update_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& target, const crate::syntax::Block& b, const crate::lower::model::OutTy& t, const crate::syntax::Range& span) {
    auto tv = crate::lower::expr::value_of(lx, env, target);
    auto env1 = crate::lower::types::bind(env, Text::lit("&_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t}));
    auto&& _dos = upd_stmts(lx, env1, b.stmts);
    auto&& dos = std::get<0>(_dos);
    return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("this")})), t}), crate::lower::types::own(tv)})}), dos), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}))}), t});
}


prism_rtl::Turn<crate::lower::types::Vl> UpdateValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& target = this->target;
    const auto& b = this->b;
    const auto& t = this->t;
    const auto& span = this->span;
    auto b_1 = b;
    auto env_2 = env;
    auto lx_3 = lx;
    auto t_4 = t;
    auto target_5 = target;
    return call_then(crate::lower::expr::start_value_of(lx_3, env_2, target_5), [=](crate::lower::types::Vl value_of_7794) {
        return ({
            auto tv = value_of_7794;
            auto env1 = crate::lower::types::bind(env_2, Text::lit("&_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_4}));
            call_then(start_upd_stmts(lx_3, env1, prism_rtl::val(b_1).stmts), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_7909) {
            return ({
                auto&& _dos = upd_stmts_7909;
                auto&& dos = std::get<0>(_dos);
                (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("this")})), t_4}), crate::lower::types::own(tv)})}), dos), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}))}), t_4})));
            });
        });
        });
    });
}


/// `Start UpdateValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_update_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr target, crate::syntax::Block b, crate::lower::model::OutTy t, crate::syntax::Range span) {
    return prism_rtl::make_rc<UpdateValue>(lx, env, target, b, t, span);
}


/// UpdStmts: unbounded fn Lx, Env, [Stmt] -> (([Do], Env))
std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Array<crate::syntax::Stmt>& stmts) {
    return run_to_end(fold_job(stmts, std::tuple{Array<crate::lower::model::Do>{}, env}, ({
        auto lx_1 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto [acc, en] = p0;
                auto s = p1;
                call_then(start_upd_stmt(lx_1_2, en, s), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmt_8194) {
                return ({
                    auto [more_, en2] = upd_stmt_8194;
                    (prism_rtl::finished(std::tuple{append(acc, more_), en2}));
                });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> UpdStmts::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& stmts = this->stmts;
    return fold_job(stmts, std::tuple{Array<crate::lower::model::Do>{}, env}, ({
        auto lx_1 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto [acc, en] = p0;
                auto s = p1;
                call_then(start_upd_stmt(lx_1_2, en, s), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmt_8194) {
                return ({
                    auto [more_, en2] = upd_stmt_8194;
                    (prism_rtl::finished(std::tuple{append(acc, more_), en2}));
                });
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start UpdStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_upd_stmts(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::Stmt> stmts) {
    return prism_rtl::make_rc<UpdStmts>(lx, env, stmts);
}


/// UpdStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmt(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
        auto&& target = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        auto v_ = crate::lower::types::own(crate::lower::expr::value_of(lx, env, value));
        return std::tuple{Array(std::vector{assign(lx, env, target, v_)}), env};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
        auto&& target = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& op = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a1;
        auto&& value = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        auto cur = place_of(lx, env, target);
        auto tt = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, prism_rtl::val(target).span)));
        auto rv = crate::lower::expr::value_of(lx, env, value);
        auto bin = crate::syntax::lexer::chars::head(op);
        auto next_ = crate::lower::expr::op_value(lx, bin, crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{cur, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), tt}), rv, s.span, tt);
        return std::tuple{Array(std::vector{assign(lx, env, target, crate::lower::types::own(next_))}), env};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto v_ = crate::lower::types::own(crate::lower::expr::value_of(lx, env, x));
        auto&& _m = prism_rtl::val(prism_rtl::val(p_).kind);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return crate::syntax::lexer::chars::has_prefix(prism_rtl::val(n).sigils, Text::lit("&"))
                ? ({
                auto rs = crate::lower::local_name(lx, crate::check::env::sname_key(n));
                auto bt = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::binder_ty(lx, prism_rtl::val(n).span)));
                auto pa = crate::lower::expr::is_known_ty(bt)
                    ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(rs)})), bt})
                    : crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(rs)});
                std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{pa, v_})}), crate::lower::types::bind(env, crate::check::env::sname_key(n), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}))};
            })
                : crate::lower::expr::block_stmt(lx, env, s);
        }
        {
            return crate::lower::expr::block_stmt(lx, env, s);
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        auto&& _inner = upd_stmts(lx, env, prism_rtl::val(body).stmts);
        auto&& inner = std::get<0>(_inner);
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
            auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
            return std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoWhile{crate::lower::types::as_bool(crate::lower::expr::value_of(lx, env, prism_rtl::val(prism_rtl::val(x)))), inner})}), env};
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
            auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
            auto&& g_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
            auto po = crate::lower::patterns::rust_pat(lx, p_, crate::lower::type_at(lx, prism_rtl::val(x).span), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("w", prism_rtl::val(s.span).start));
            auto env_b = crate::lower::expr::bind_all(env, prism_rtl::val(po).binds);
            auto&& _inner2 = upd_stmts(lx, env_b, prism_rtl::val(body).stmts);
            auto&& inner2 = std::get<0>(_inner2);
            auto conds = append(prism_rtl::val(po).conds, guard_conds(lx, env_b, prism_rtl::val(prism_rtl::val(g_opt))));
            auto tests = fold(conds, Array<crate::lower::model::Ex>{}, [&](const Array<crate::lower::model::Ex>& acc, const crate::lower::model::Cc& c) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(c)) {
                        auto&& t = prism_rtl::as<crate::lower::model::Cc::CcIf>(c).a0;
                        _v.set(crate::prelude::push(acc, t));
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            auto lets = fold(conds, false, [&](const bool& f, const crate::lower::model::Cc& c) { return prism_rtl::val(f) || crate::lower::expr::is_let_cond(c); });
            auto stop = len(tests) == Nat(0u)
                ? Array<crate::lower::model::Do>{}
                : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("!"), prism_rtl::rc(all_of(tests))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("break")})})}), Array<crate::lower::model::Do>{}})});
            auto body2 = lets
                ? Array(std::vector{crate::lower::expr::refusal_do(Text::lit("a `while` whose pattern matches through an `Rc`"))})
                : append(stop, inner2);
            return std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoWhileLet{prism_rtl::val(po).pa, crate::lower::types::own(crate::lower::expr::value_of(lx, env, prism_rtl::val(prism_rtl::val(x)))), body2})}), env};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        auto&& _m = prism_rtl::val(prism_rtl::val(x).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            return std::tuple{Array(std::vector{upd_if(lx, env, prism_rtl::val(prism_rtl::val(c)), then_b, else_b_opt)}), env};
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            return std::tuple{Array(std::vector{upd_match(lx, env, prism_rtl::val(prism_rtl::val(scrut)), arms)}), env};
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
            auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
            auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
            auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
            return std::tuple{Array(std::vector{upd_for(lx, env, binders_opt, prism_rtl::val(prism_rtl::val(source)), body, prism_rtl::val(x).span)}), env};
        }
        {
            return std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own(crate::lower::expr::value_of(lx, env, x))})}), env};
        }
    }
    {
        return crate::lower::expr::block_stmt(lx, env, s);
    }
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> UpdStmt::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& s = this->s;
    return ({
        auto&& _m = prism_rtl::val(s).kind;
        prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& target = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto target_3 = target;
        auto value_4 = value;
        call_then(crate::lower::expr::start_value_of(lx_2, env_1, value_4), [=](crate::lower::types::Vl value_of_8381) {
        return ({
            auto v_ = crate::lower::types::own(value_of_8381);
            call_then(start_assign(lx_2, env_1, target_3, v_), [=](crate::lower::model::Do assign_8418) { return prism_rtl::finished(std::tuple{Array(std::vector{assign_8418}), env_1}); });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& target = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& op = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a1;
        auto&& value = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto op_3 = op;
        auto s_4 = s;
        auto target_5 = target;
        auto value_6 = value;
        call_then(start_place_of(lx_2, env_1, target_5), [=](crate::lower::model::Ex place_of_8502) {
        return ({
            auto cur = place_of_8502;
            call_then(crate::lower::types::start_out_ty_of(lx_2, crate::lower::types::peel(crate::lower::type_at(lx_2, prism_rtl::val(target_5).span))), [=](crate::lower::model::OutTy out_ty_of_8543) {
            return ({
                auto tt = out_ty_of_8543;
                call_then(crate::lower::expr::start_value_of(lx_2, env_1, value_6), [=](crate::lower::types::Vl value_of_8604) {
                return ({
                    auto rv = value_of_8604;
                    auto bin = crate::syntax::lexer::chars::head(op_3);
                    auto next_ = crate::lower::expr::op_value(lx_2, bin, crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{cur, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), tt}), rv, prism_rtl::val(s_4).span, tt);
                    call_then(start_assign(lx_2, env_1, target_5, crate::lower::types::own(next_)), [=](crate::lower::model::Do assign_8743) { return prism_rtl::finished(std::tuple{Array(std::vector{assign_8743}), env_1}); });
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto p__3 = p_;
        auto s_4 = s;
        auto x_5 = x;
        call_then(crate::lower::expr::start_value_of(lx_2, env_1, x_5), [=](crate::lower::types::Vl value_of_8832) {
        return ({
            auto v_ = crate::lower::types::own(value_of_8832);
            ({
            auto&& _m = prism_rtl::val(prism_rtl::val(p__3).kind);
            prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            crate::syntax::lexer::chars::has_prefix(prism_rtl::val(n).sigils, Text::lit("&"))
            ? ({
            auto rs = crate::lower::local_name(lx_2, crate::check::env::sname_key(n));
            auto n_6 = n;
            call_then(crate::lower::types::start_out_ty_of(lx_2, crate::lower::types::peel(crate::lower::binder_ty(lx_2, prism_rtl::val(n_6).span))), [=](crate::lower::model::OutTy out_ty_of_9026) {
            return ({
                auto bt = out_ty_of_9026;
                call_then(crate::lower::expr::start_is_known_ty(bt), [=](bool is_known_ty_9099) {
                return ({
                    auto pa = is_known_ty_9099
                        ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(rs)})), bt})
                        : crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(rs)});
                    (prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{pa, v_})}), crate::lower::types::bind(env_1, crate::check::env::sname_key(n_6), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}))}));
                });
            });
            });
        });
        })
            : prism_rtl::more(prism_rtl::rc(crate::lower::expr::BlockStmt(lx_2, env_1, s_4)));
        })
            : prism_rtl::more(prism_rtl::rc(crate::lower::expr::BlockStmt(lx_2, env_1, s_4)));
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        ({
        auto body_1 = body;
        auto c_2 = c;
        auto env_3 = env;
        auto lx_4 = lx;
        auto s_5 = s;
        call_then(start_upd_stmts(lx_4, env_3, prism_rtl::val(body_1).stmts), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_9398) {
        return ({
            auto&& _inner = upd_stmts_9398;
            auto&& inner = std::get<0>(_inner);
            ({
            prism_rtl::is<crate::syntax::Cond::CondExpr>(c_2) ? ({
            auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_2).a0;
            ({
            auto x_6 = prism_rtl::val(prism_rtl::val(x));
            call_then(crate::lower::expr::start_value_of(lx_4, env_3, x_6), [=](crate::lower::types::Vl value_of_9490) { return prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoWhile{crate::lower::types::as_bool(value_of_9490), inner})}), env_3}); });
        });
        })
            : prism_rtl::is<crate::syntax::Cond::CondBind>(c_2) ? ({
            auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c_2).a0;
            auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c_2).a1;
            auto&& g_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c_2).a2;
            ({
            auto g_opt_6 = prism_rtl::val(prism_rtl::val(g_opt));
            auto p__7 = p_;
            auto x_8 = prism_rtl::val(prism_rtl::val(x));
            call_then(crate::lower::patterns::start_rust_pat(lx_4, p__7, crate::lower::type_at(lx_4, prism_rtl::val(x_8).span), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("w", prism_rtl::val(prism_rtl::val(s_5).span).start)), [=](crate::lower::patterns::PatOut rust_pat_9584) {
            return ({
                auto po = rust_pat_9584;
                auto env_b = crate::lower::expr::bind_all(env_3, prism_rtl::val(po).binds);
                call_then(start_upd_stmts(lx_4, env_b, prism_rtl::val(body_1).stmts), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_9735) {
                return ({
                    auto&& _inner2 = upd_stmts_9735;
                    auto&& inner2 = std::get<0>(_inner2);
                    call_then(start_guard_conds(lx_4, env_b, g_opt_6), [=](Array<crate::lower::model::Cc> guard_conds_9993) {
                    return ({
                        auto conds = append(prism_rtl::val(po).conds, guard_conds_9993);
                        auto tests = fold(conds, Array<crate::lower::model::Ex>{}, [&](const Array<crate::lower::model::Ex>& acc, const crate::lower::model::Cc& c) {
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                                if (prism_rtl::is<crate::lower::model::Cc::CcIf>(c)) {
                                    auto&& t = prism_rtl::as<crate::lower::model::Cc::CcIf>(c).a0;
                                    _v.set(crate::prelude::push(acc, t));
                                    goto _done;
                                }
                                {
                                    _v.set(acc);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        });
                        auto lets = fold(conds, false, [&](const bool& f, const crate::lower::model::Cc& c) { return prism_rtl::val(f) || crate::lower::expr::is_let_cond(c); });
                        auto stop = len(tests) == Nat(0u)
                            ? Array<crate::lower::model::Do>{}
                            : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("!"), prism_rtl::rc(all_of(tests))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("break")})})}), Array<crate::lower::model::Do>{}})});
                        auto body2 = lets
                            ? Array(std::vector{crate::lower::expr::refusal_do(Text::lit("a `while` whose pattern matches through an `Rc`"))})
                            : append(stop, inner2);
                        call_then(crate::lower::expr::start_value_of(lx_4, env_3, x_8), [=](crate::lower::types::Vl value_of_10532) { return prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoWhileLet{prism_rtl::val(po).pa, crate::lower::types::own(value_of_10532), body2})}), env_3}); });
                    });
                });
                });
            });
            });
        });
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        ({
        auto&& _m = prism_rtl::val(prism_rtl::val(x).kind);
        prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        ({
        auto else_b_opt_1 = else_b_opt;
        auto c_2 = prism_rtl::val(prism_rtl::val(c));
        auto env_3 = env;
        auto lx_4 = lx;
        auto then_b_5 = then_b;
        call_then(start_upd_if(lx_4, env_3, c_2, then_b_5, else_b_opt_1), [=](crate::lower::model::Do upd_if_10632) { return prism_rtl::finished(std::tuple{Array(std::vector{upd_if_10632}), env_3}); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        ({
        auto arms_1 = arms;
        auto env_2 = env;
        auto lx_3 = lx;
        auto scrut_4 = prism_rtl::val(prism_rtl::val(scrut));
        call_then(start_upd_match(lx_3, env_2, scrut_4, arms_1), [=](crate::lower::model::Do upd_match_10707) { return prism_rtl::finished(std::tuple{Array(std::vector{upd_match_10707}), env_2}); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        ({
        auto binders_opt_1 = binders_opt;
        auto body_2 = body;
        auto env_3 = env;
        auto lx_4 = lx;
        auto source_5 = prism_rtl::val(prism_rtl::val(source));
        auto x_6 = x;
        call_then(start_upd_for(lx_4, env_3, binders_opt_1, source_5, body_2, prism_rtl::val(x_6).span), [=](crate::lower::model::Do upd_for_10789) { return prism_rtl::finished(std::tuple{Array(std::vector{upd_for_10789}), env_3}); });
    });
    })
        : ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto x_3 = x;
        call_then(crate::lower::expr::start_value_of(lx_2, env_1, x_3), [=](crate::lower::types::Vl value_of_10882) { return prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own(value_of_10882)})}), env_1}); });
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(crate::lower::expr::BlockStmt(lx, env, s)));
    });
}


/// `Start UpdStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_upd_stmt(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Stmt s) {
    return prism_rtl::make_rc<UpdStmt>(lx, env, s);
}


/// UpdFor: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range -> Do
crate::lower::model::Do upd_for(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::syntax::Expr& source, const crate::syntax::Block& body, const crate::syntax::Range& span) {
    auto sty = crate::lower::types::peel(crate::lower::type_at(lx, source.span));
    auto&& _m = ref_binder(binders_opt);
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        return is_ref_path(source)
            ? upd_for_refs(lx, env, n, source, body, span, sty)
            : upd_for_values(lx, env, binders_opt, source, body, span, sty);
    }
    if (prism_rtl::is_none(_m)) {
        return upd_for_values(lx, env, binders_opt, source, body, span, sty);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Do> UpdFor::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& binders_opt = this->binders_opt;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& span = this->span;
    auto sty = crate::lower::types::peel(crate::lower::type_at(lx, prism_rtl::val(source).span));
    return ({
        auto&& _m = ref_binder(binders_opt);
        prism_rtl::is_some(_m) ? ({
        auto&& n = prism_rtl::some_of(_m);
        is_ref_path(source)
        ? prism_rtl::more(prism_rtl::rc(UpdForRefs(lx, env, n, source, body, span, sty)))
        : prism_rtl::more(prism_rtl::rc(UpdForValues(lx, env, binders_opt, source, body, span, sty)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(UpdForValues(lx, env, binders_opt, source, body, span, sty)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start UpdFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_upd_for(crate::lower::Lx lx, crate::lower::types::Env env, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span) {
    return prism_rtl::make_rc<UpdFor>(lx, env, binders_opt, source, body, span);
}


/// UpdForRefs: unbounded fn Lx, Env, SName, Expr, Block, Range, Ty -> Do
crate::lower::model::Do upd_for_refs(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::SName& n, const crate::syntax::Expr& source, const crate::syntax::Block& body, const crate::syntax::Range& span, const crate::check::types::Ty& sty) {
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty)) {
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(sty).a0;
        auto key_name = prism_rtl::cat("k", span.start);
        auto ref_name = prism_rtl::cat("r", span.start);
        auto env1 = crate::lower::types::bind(crate::lower::types::bind(crate::lower::types::bind(env, Text::lit("key"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})})), Text::lit("ix"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})})), crate::check::env::sname_key(n), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XTarget{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{ref_name}))}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::types::out_ty_of(lx, prism_rtl::val(prism_rtl::val(v_)))}));
        auto&& _dos = upd_stmts(lx, env1, body.stmts);
        auto&& dos = std::get<0>(_dos);
        auto head = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("nat_of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("i", span.start)})})})});
        return crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("i", span.start)}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{ref_name})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(place_of(lx, env, source)), Text::lit("iter_mut"), Array<crate::lower::model::Ex>{}})), Text::lit("enumerate"), Array<crate::lower::model::Ex>{}}), append(Array(std::vector{head}), dos)});
    }
    {
        return crate::lower::expr::refusal_do(Text::lit("a `for` by reference over what is not an array"));
    }
}


prism_rtl::Turn<crate::lower::model::Do> UpdForRefs::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& n = this->n;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& span = this->span;
    const auto& sty = this->sty;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyArray>(sty) ? ({
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(sty).a0;
        ({
        auto key_name = prism_rtl::cat("k", prism_rtl::val(span).start);
        auto ref_name = prism_rtl::cat("r", prism_rtl::val(span).start);
        auto body_1 = body;
        auto env_2 = env;
        auto lx_3 = lx;
        auto n_4 = n;
        auto source_5 = source;
        auto span_6 = span;
        auto v__7 = prism_rtl::val(prism_rtl::val(v_));
        call_then(crate::lower::types::start_out_ty_of(lx_3, v__7), [=](crate::lower::model::OutTy out_ty_of_12242) {
        return ({
            auto env1 = crate::lower::types::bind(crate::lower::types::bind(crate::lower::types::bind(env_2, Text::lit("key"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})})), Text::lit("ix"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})})), crate::check::env::sname_key(n_4), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XTarget{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{ref_name}))}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), out_ty_of_12242}));
            call_then(start_upd_stmts(lx_3, env1, prism_rtl::val(body_1).stmts), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_12288) {
            return ({
                auto&& _dos = upd_stmts_12288;
                auto&& dos = std::get<0>(_dos);
                auto head = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("nat_of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("i", prism_rtl::val(span_6).start)})})})});
                call_then(start_place_of(lx_3, env_2, source_5), [=](crate::lower::model::Ex place_of_12497) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("i", prism_rtl::val(span_6).start)}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{ref_name})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(place_of_12497), Text::lit("iter_mut"), Array<crate::lower::model::Ex>{}})), Text::lit("enumerate"), Array<crate::lower::model::Ex>{}}), append(Array(std::vector{head}), dos)})); });
            });
        });
        });
    });
    });
    })
        : prism_rtl::finished(crate::lower::expr::refusal_do(Text::lit("a `for` by reference over what is not an array")));
    });
}


/// `Start UpdForRefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_upd_for_refs(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::SName n, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span, crate::check::types::Ty sty) {
    return prism_rtl::make_rc<UpdForRefs>(lx, env, n, source, body, span, sty);
}


/// ?RefBinder: fn ?ForBinders -> ?SName
std::optional<crate::syntax::SName> ref_binder(const std::optional<crate::syntax::ForBinders>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& fb = prism_rtl::some_of(opt0);
        auto&& _m = prism_rtl::val(fb).second;
        if (prism_rtl::is_none(_m)) {
            auto&& _m = prism_rtl::val(prism_rtl::val(prism_rtl::val(fb).first).kind);
            if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                return crate::syntax::lexer::chars::has_prefix(prism_rtl::val(n).sigils, Text::lit("&"))
                    ? std::optional(n)
                    : std::optional<crate::syntax::SName>{};
            }
            {
                return std::optional<crate::syntax::SName>{};
            }
        }
        {
            return std::optional<crate::syntax::SName>{};
        }
    }
    if (prism_rtl::is_none(opt0)) {
        return std::optional<crate::syntax::SName>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsRefPath: fn Expr -> Bool
bool is_ref_path(const crate::syntax::Expr& e) {
    auto&& _m = prism_rtl::val(e.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix(prism_rtl::val(n).sigils, Text::lit("&"));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        return is_ref_path(prism_rtl::val(prism_rtl::val(r)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        return is_ref_path(prism_rtl::val(prism_rtl::val(r)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_ref_path(prism_rtl::val(prism_rtl::val(x)));
    }
    {
        return false;
    }
}


/// UpdForValues: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range, Ty -> Do
crate::lower::model::Do upd_for_values(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::syntax::Expr& source, const crate::syntax::Block& body, const crate::syntax::Range& span, const crate::check::types::Ty& sty) {
    auto src = crate::lower::types::own(crate::lower::expr::value_of(lx, env, source));
    auto [kt, vt, is_array] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy, bool>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty)) {
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(sty).a0;
            _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}), crate::lower::types::out_ty_of(lx, prism_rtl::val(prism_rtl::val(v_))), true});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty)) {
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a1;
            _v.set(std::tuple{crate::lower::types::out_ty_of(lx, prism_rtl::val(prism_rtl::val(k))), crate::lower::types::out_ty_of(lx, prism_rtl::val(prism_rtl::val(v_))), false});
            goto _done;
        }
        {
            _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), true});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [vty, kty] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::Ty>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty)) {
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(sty).a0;
            _v.set(std::tuple{prism_rtl::val(prism_rtl::val(v_)), crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Nat"), Array<crate::check::types::Ty>{}})});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty)) {
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a1;
            _v.set(std::tuple{prism_rtl::val(prism_rtl::val(v_)), prism_rtl::val(prism_rtl::val(k))});
            goto _done;
        }
        {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto key_name = prism_rtl::cat("k", span.start);
    auto val_name = prism_rtl::cat("v", span.start);
    auto env1 = crate::lower::types::bind(crate::lower::types::bind(env, Text::lit("key"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt})), Text::lit("_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), vt}));
    auto env2 = is_array
        ? crate::lower::types::bind(env1, Text::lit("ix"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt}))
        : env1;
    auto [binds, env3] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
        if (prism_rtl::is_none(binders_opt)) {
            _v.set(std::tuple{Array<crate::lower::model::Do>{}, env2});
            goto _done;
        }
        if (prism_rtl::is_some(binders_opt)) {
            auto&& fb = prism_rtl::some_of(binders_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                auto&& _m = prism_rtl::val(fb).second;
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto po = crate::lower::patterns::rust_pat(lx, prism_rtl::val(fb).first, vty, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("e", span.start));
                        std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::val(po).pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}))})})}), crate::lower::expr::bind_all(env2, prism_rtl::val(po).binds)};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_some(_m)) {
                    auto&& second = prism_rtl::some_of(_m);
                    _v.set(({
                        auto pk = crate::lower::patterns::rust_pat(lx, prism_rtl::val(fb).first, kty, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("k", span.start, "_"));
                        auto pv = crate::lower::patterns::rust_pat(lx, second, vty, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("e", span.start));
                        std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::val(pk).pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::val(pv).pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}))})})}), crate::lower::expr::bind_all(crate::lower::expr::bind_all(env2, prism_rtl::val(pk).binds), prism_rtl::val(pv).binds)};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _dos = upd_stmts(lx, env3, body.stmts);
    auto&& dos = std::get<0>(_dos);
    return is_array
        ? ({
        auto head = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("nat_of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("i", span.start)})})})});
        (crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("i", span.start)}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src), Text::lit("into_iter"), Array<crate::lower::model::Ex>{}})), Text::lit("enumerate"), Array<crate::lower::model::Ex>{}}), append(crate::prelude::push(Array<crate::lower::model::Do>{}, head), append(binds, dos))}));
    })
        : crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src), Text::lit("into_iter"), Array<crate::lower::model::Ex>{}}), append(binds, dos)});
}


prism_rtl::Turn<crate::lower::model::Do> UpdForValues::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& binders_opt = this->binders_opt;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& span = this->span;
    const auto& sty = this->sty;
    auto binders_opt_1 = binders_opt;
    auto body_2 = body;
    auto env_3 = env;
    auto lx_4 = lx;
    auto source_5 = source;
    auto span_6 = span;
    auto sty_7 = sty;
    return call_then(crate::lower::expr::start_value_of(lx_4, env_3, source_5), [=](crate::lower::types::Vl value_of_13392) {
        return ({
            auto src = crate::lower::types::own(value_of_13392);
            auto [kt, vt, is_array] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy, bool>> _v;
                if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty_7)) {
                    auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(sty_7).a0;
                    _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}), crate::lower::types::out_ty_of(lx_4, prism_rtl::val(prism_rtl::val(v_))), true});
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty_7)) {
                    auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_7).a0;
                    auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_7).a1;
                    _v.set(std::tuple{crate::lower::types::out_ty_of(lx_4, prism_rtl::val(prism_rtl::val(k))), crate::lower::types::out_ty_of(lx_4, prism_rtl::val(prism_rtl::val(v_))), false});
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), true});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [vty, kty] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::Ty>> _v;
                if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty_7)) {
                    auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(sty_7).a0;
                    _v.set(std::tuple{prism_rtl::val(prism_rtl::val(v_)), crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Nat"), Array<crate::check::types::Ty>{}})});
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty_7)) {
                    auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_7).a0;
                    auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_7).a1;
                    _v.set(std::tuple{prism_rtl::val(prism_rtl::val(v_)), prism_rtl::val(prism_rtl::val(k))});
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto key_name = prism_rtl::cat("k", prism_rtl::val(span_6).start);
            auto val_name = prism_rtl::cat("v", prism_rtl::val(span_6).start);
            auto env1 = crate::lower::types::bind(crate::lower::types::bind(env_3, Text::lit("key"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt})), Text::lit("_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), vt}));
            auto env2 = is_array
                ? crate::lower::types::bind(env1, Text::lit("ix"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt}))
                : env1;
            auto [binds, env3] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                if (prism_rtl::is_none(binders_opt_1)) {
                    _v.set(std::tuple{Array<crate::lower::model::Do>{}, env2});
                    goto _done;
                }
                if (prism_rtl::is_some(binders_opt_1)) {
                    auto&& fb = prism_rtl::some_of(binders_opt_1);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                        auto&& _m = prism_rtl::val(fb).second;
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                auto po = crate::lower::patterns::rust_pat(lx_4, prism_rtl::val(fb).first, vty, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("e", prism_rtl::val(span_6).start));
                                std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::val(po).pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}))})})}), crate::lower::expr::bind_all(env2, prism_rtl::val(po).binds)};
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_some(_m)) {
                            auto&& second = prism_rtl::some_of(_m);
                            _v.set(({
                                auto pk = crate::lower::patterns::rust_pat(lx_4, prism_rtl::val(fb).first, kty, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("k", prism_rtl::val(span_6).start, "_"));
                                auto pv = crate::lower::patterns::rust_pat(lx_4, second, vty, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("e", prism_rtl::val(span_6).start));
                                std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::val(pk).pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::val(pv).pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}))})})}), crate::lower::expr::bind_all(crate::lower::expr::bind_all(env2, prism_rtl::val(pk).binds), prism_rtl::val(pv).binds)};
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            call_then(start_upd_stmts(lx_4, env3, prism_rtl::val(body_2).stmts), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_14673) {
            return ({
                auto&& _dos = upd_stmts_14673;
                auto&& dos = std::get<0>(_dos);
                is_array
                ? ({
                auto head = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("nat_of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("i", prism_rtl::val(span_6).start)})})})});
                (prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("i", prism_rtl::val(span_6).start)}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src), Text::lit("into_iter"), Array<crate::lower::model::Ex>{}})), Text::lit("enumerate"), Array<crate::lower::model::Ex>{}}), append(crate::prelude::push(Array<crate::lower::model::Do>{}, head), append(binds, dos))})));
            })
                : prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src), Text::lit("into_iter"), Array<crate::lower::model::Ex>{}}), append(binds, dos)}));
            });
        });
        });
    });
}


/// `Start UpdForValues, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_upd_for_values(crate::lower::Lx lx, crate::lower::types::Env env, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span, crate::check::types::Ty sty) {
    return prism_rtl::make_rc<UpdForValues>(lx, env, binders_opt, source, body, span, sty);
}


/// UpdIf: unbounded fn Lx, Env, Cond, Block, ?Block -> Do
crate::lower::model::Do upd_if(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Cond& c, const crate::syntax::Block& then_b, const std::optional<crate::syntax::Block>& else_b_opt) {
    auto&& _else_dos = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
        if (prism_rtl::is_some(else_b_opt)) {
            auto&& b = prism_rtl::some_of(else_b_opt);
            _v.set(upd_stmts(lx, env, prism_rtl::val(b).stmts));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_opt)) {
            _v.set(std::tuple{Array<crate::lower::model::Do>{}, env});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& else_dos = std::get<0>(_else_dos);
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
        auto&& _then_dos = upd_stmts(lx, env, then_b.stmts);
        auto&& then_dos = std::get<0>(_then_dos);
        return crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::types::as_bool(crate::lower::expr::value_of(lx, env, prism_rtl::val(prism_rtl::val(x)))), then_dos, else_dos});
    }
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
        auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
        auto po = crate::lower::patterns::rust_pat(lx, p_, crate::lower::type_at(lx, prism_rtl::val(x).span), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("u", prism_rtl::val(prism_rtl::val(x).span).start));
        auto&& _then_dos = upd_stmts(lx, crate::lower::expr::bind_all(env, prism_rtl::val(po).binds), then_b.stmts);
        auto&& then_dos = std::get<0>(_then_dos);
        return crate::lower::model::Do(crate::lower::model::Do::DoIfLet{prism_rtl::val(po).pa, crate::lower::types::own(crate::lower::expr::value_of(lx, env, prism_rtl::val(prism_rtl::val(x)))), then_dos, else_dos});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Do> UpdIf::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& then_b = this->then_b;
    const auto& else_b_opt = this->else_b_opt;
    auto&& _else_dos = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
        if (prism_rtl::is_some(else_b_opt)) {
            auto&& b = prism_rtl::some_of(else_b_opt);
            _v.set(upd_stmts(lx, env, prism_rtl::val(b).stmts));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_opt)) {
            _v.set(std::tuple{Array<crate::lower::model::Do>{}, env});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& else_dos = std::get<0>(_else_dos);
    return ({
        prism_rtl::is<crate::syntax::Cond::CondExpr>(c) ? ({
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto then_b_3 = then_b;
        auto x_4 = prism_rtl::val(prism_rtl::val(x));
        call_then(start_upd_stmts(lx_2, env_1, prism_rtl::val(then_b_3).stmts), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_15383) {
        return ({
            auto&& _then_dos = upd_stmts_15383;
            auto&& then_dos = std::get<0>(_then_dos);
            call_then(crate::lower::expr::start_value_of(lx_2, env_1, x_4), [=](crate::lower::types::Vl value_of_15439) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::types::as_bool(value_of_15439), then_dos, else_dos})); });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::Cond::CondBind>(c) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto p__3 = p_;
        auto then_b_4 = then_b;
        auto x_5 = prism_rtl::val(prism_rtl::val(x));
        call_then(crate::lower::patterns::start_rust_pat(lx_2, p__3, crate::lower::type_at(lx_2, prism_rtl::val(x_5).span), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("u", prism_rtl::val(prism_rtl::val(x_5).span).start)), [=](crate::lower::patterns::PatOut rust_pat_15530) {
        return ({
            auto po = rust_pat_15530;
            call_then(start_upd_stmts(lx_2, crate::lower::expr::bind_all(env_1, prism_rtl::val(po).binds), prism_rtl::val(then_b_4).stmts), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_15629) {
            return ({
                auto&& _then_dos = upd_stmts_15629;
                auto&& then_dos = std::get<0>(_then_dos);
                call_then(crate::lower::expr::start_value_of(lx_2, env_1, x_5), [=](crate::lower::types::Vl value_of_15712) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoIfLet{prism_rtl::val(po).pa, crate::lower::types::own(value_of_15712), then_dos, else_dos})); });
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start UpdIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_upd_if(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt) {
    return prism_rtl::make_rc<UpdIf>(lx, env, c, then_b, else_b_opt);
}


/// UpdMatch: unbounded fn Lx, Env, Expr, [Arm] -> Do
crate::lower::model::Do upd_match(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& scrut, const Array<crate::syntax::Arm>& arms) {
    auto sv = crate::lower::expr::value_of(lx, env, scrut);
    auto sty = crate::lower::type_at(lx, scrut.span);
    auto arms3 = run_to_end(each_job(crate::check::errors::range0(len(arms)), ({
        auto arms_1 = arms;
        auto lx_2 = lx;
        auto sty_3 = sty;
        auto scrut_4 = scrut;
        auto env_5 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto arms_1_6 = arms_1;
            auto lx_2_6 = lx_2;
            auto sty_3_6 = sty_3;
            auto scrut_4_6 = scrut_4;
            auto env_5_6 = env_5;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto arm = or_(index(arms_1_6, i), crate::lower::expr::dummy_arm());
                call_then(crate::lower::expr::start_arm_pat(lx_2_6, prism_rtl::val(arm).pattern, sty_3_6, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat("u", prism_rtl::val(scrut_4_6.span).start, "_", i)), [=](crate::lower::patterns::PatOut arm_pat_16011) {
                return ({
                    auto po = arm_pat_16011;
                    call_then(start_upd_stmts(lx_2_6, crate::lower::expr::bind_all(env_5_6, prism_rtl::val(po).binds), prism_rtl::val(prism_rtl::val(arm).body).stmts), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_16104) {
                    return ({
                        auto&& _dos = upd_stmts_16104;
                        auto&& dos = std::get<0>(_dos);
                        call_then(start_guard_conds(lx_2_6, crate::lower::expr::bind_all(env_5_6, prism_rtl::val(po).binds), prism_rtl::val(arm).guard), [=](Array<crate::lower::model::Cc> guard_conds_16197) {
                        return ({
                            auto guarded = append(prism_rtl::val(po).conds, guard_conds_16197);
                            (prism_rtl::finished(crate::lower::model::XArm{.pat = prism_rtl::val(po).pa, .conds = guarded, .body = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))})}));
                        });
                    });
                    });
                });
                });
            });
            });
            });
        }));
        });
    })));
    })));
    return fold(arms3, false, [&](const bool& f, const crate::lower::model::XArm& a) { return prism_rtl::val(f) || (len(prism_rtl::val(a).conds) > Nat(0u)); })
        ? crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own(crate::lower::expr::arms_value(crate::lower::types::ref_(sv), arms3, prism_rtl::cat("\'u", prism_rtl::val(scrut.span).start), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})
        : crate::lower::model::Do(crate::lower::model::Do::DoMatch{crate::lower::types::ref_(sv), each(arms3, [&](const crate::lower::model::XArm& a) { return std::tuple{prism_rtl::val(a).pat, arm_dos(prism_rtl::val(a).body)}; })});
}


prism_rtl::Turn<crate::lower::model::Do> UpdMatch::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& scrut = this->scrut;
    const auto& arms = this->arms;
    auto arms_1 = arms;
    auto env_2 = env;
    auto lx_3 = lx;
    auto scrut_4 = scrut;
    return call_then(crate::lower::expr::start_value_of(lx_3, env_2, scrut_4), [=](crate::lower::types::Vl value_of_15849) {
        return ({
            auto sv = value_of_15849;
            auto sty = crate::lower::type_at(lx_3, prism_rtl::val(scrut_4).span);
            call_value(each_job(crate::check::errors::range0(len(arms_1)), ({
            auto arms_1_5 = arms_1;
            auto lx_3_5 = lx_3;
            auto sty_5 = sty;
            auto scrut_4_6 = scrut_4;
            auto env_2_6 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto arms_1_5_6 = arms_1_5;
                auto lx_3_5_6 = lx_3_5;
                auto sty_5_6 = sty_5;
                auto scrut_4_6_6 = scrut_4_6;
                auto env_2_6_6 = env_2_6;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    ({
                    auto arm = or_(index(arms_1_5_6, i), crate::lower::expr::dummy_arm());
                    call_then(crate::lower::expr::start_arm_pat(lx_3_5_6, prism_rtl::val(arm).pattern, sty_5_6, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat("u", prism_rtl::val(prism_rtl::val(scrut_4_6_6).span).start, "_", i)), [=](crate::lower::patterns::PatOut arm_pat_16011) {
                    return ({
                        auto po = arm_pat_16011;
                        call_then(start_upd_stmts(lx_3_5_6, crate::lower::expr::bind_all(env_2_6_6, prism_rtl::val(po).binds), prism_rtl::val(prism_rtl::val(arm).body).stmts), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_16104) {
                        return ({
                            auto&& _dos = upd_stmts_16104;
                            auto&& dos = std::get<0>(_dos);
                            call_then(start_guard_conds(lx_3_5_6, crate::lower::expr::bind_all(env_2_6_6, prism_rtl::val(po).binds), prism_rtl::val(arm).guard), [=](Array<crate::lower::model::Cc> guard_conds_16197) {
                            return ({
                                auto guarded = append(prism_rtl::val(po).conds, guard_conds_16197);
                                (prism_rtl::finished(crate::lower::model::XArm{.pat = prism_rtl::val(po).pa, .conds = guarded, .body = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))})}));
                            });
                        });
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::XArm> each_15924) {
            return ({
                auto arms3 = each_15924;
                fold(arms3, false, [&](const bool& f, const crate::lower::model::XArm& a) { return prism_rtl::val(f) || (len(prism_rtl::val(a).conds) > Nat(0u)); })
                ? prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own(crate::lower::expr::arms_value(crate::lower::types::ref_(sv), arms3, prism_rtl::cat("\'u", prism_rtl::val(prism_rtl::val(scrut_4).span).start), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))}))
                : prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoMatch{crate::lower::types::ref_(sv), each(arms3, [&](const crate::lower::model::XArm& a) { return std::tuple{prism_rtl::val(a).pat, arm_dos(prism_rtl::val(a).body)}; })}));
            });
        });
        });
    });
}


/// `Start UpdMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_upd_match(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr scrut, Array<crate::syntax::Arm> arms) {
    return prism_rtl::make_rc<UpdMatch>(lx, env, scrut, arms);
}


/// AllOf: fn [Ex] -> Ex
crate::lower::model::Ex all_of(const Array<crate::lower::model::Ex>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 1u) {
            {
                auto&& _c1 = index(c0_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one = prism_rtl::some_of(_c1);
                    return one;
                }
            }
        }
    }
    {
        auto&& xs = xs0;
        return fold(drop(xs, Nat(1u)), or_(index(xs, Nat(0u)), crate::lower::model::Ex(crate::lower::model::Ex::XBool{true})), [&](const crate::lower::model::Ex& acc, const crate::lower::model::Ex& x) { return crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("&&"), prism_rtl::rc(acc), prism_rtl::rc(x)}); });
    }
}


/// ArmDos: fn Ex -> [Do]
Array<crate::lower::model::Do> arm_dos(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(ex0)) {
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex0).a0;
        return dos;
    }
    {
        auto&& x = ex0;
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{x})});
    }
}


/// GuardConds: unbounded fn Lx, Env, ?Expr -> [Cc]
Array<crate::lower::model::Cc> guard_conds(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const std::optional<crate::syntax::Expr>& opt2) {
    if (prism_rtl::is_some(opt2)) {
        auto&& ge = prism_rtl::some_of(opt2);
        return Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::types::as_bool(crate::lower::expr::value_of(lx, env, ge))})});
    }
    if (prism_rtl::is_none(opt2)) {
        return Array<crate::lower::model::Cc>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::lower::model::Cc>> GuardConds::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& opt2 = this->opt2;
    return ({
        prism_rtl::is_some(opt2) ? ({
        auto&& ge = prism_rtl::some_of(opt2);
        ({
        auto env_1 = env;
        auto ge_2 = ge;
        auto lx_3 = lx;
        call_then(crate::lower::expr::start_value_of(lx_3, env_1, ge_2), [=](crate::lower::types::Vl value_of_17039) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::types::as_bool(value_of_17039)})})); });
    });
    })
        : prism_rtl::is_none(opt2) ? prism_rtl::finished(Array<crate::lower::model::Cc>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start GuardConds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Cc>> start_guard_conds(crate::lower::Lx lx, crate::lower::types::Env env, std::optional<crate::syntax::Expr> opt2) {
    return prism_rtl::make_rc<GuardConds>(lx, env, opt2);
}


/// PlaceOf: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex place_of(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e) {
    auto&& _m = prism_rtl::val(e.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto&& _m = crate::prelude::get(env.names, crate::check::env::sname_key(n));
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
            auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            return rs;
        }
        {
            return crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::snake(crate::check::env::sname_key(n))});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& name = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        return crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(place_of(lx, env, prism_rtl::val(prism_rtl::val(r)))), crate::lower::snake(prism_rtl::val(name).name)});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& k = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        auto rt = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, prism_rtl::val(r).span)));
        auto f = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt)) {
                _v.set(Text::lit("at_mut_map"));
                goto _done;
            }
            {
                _v.set(Text::lit("at_mut"));
                goto _done;
            }
        _done:
            _v.take();
        });
        return crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{f, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(place_of(lx, env, prism_rtl::val(prism_rtl::val(r))))}), crate::lower::expr::argument(lx, env, prism_rtl::val(prism_rtl::val(k)))})}))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return place_of(lx, env, prism_rtl::val(prism_rtl::val(x)));
    }
    {
        return crate::lower::expr::refusal(Text::lit("a reference path this back end does not lower"));
    }
}


prism_rtl::Turn<crate::lower::model::Ex> PlaceOf::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = prism_rtl::val(prism_rtl::val(e).kind);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto&& _m = crate::prelude::get(env->names, crate::check::env::sname_key(n));
        prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
        auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
        prism_rtl::finished(rs);
    })
        : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::snake(crate::check::env::sname_key(n))}));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& name = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto name_3 = name;
        auto r_4 = prism_rtl::val(prism_rtl::val(r));
        call_then(start_place_of(lx_2, env_1, r_4), [=](crate::lower::model::Ex place_of_17407) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(place_of_17407), crate::lower::snake(prism_rtl::val(name_3).name)})); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& k = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        ({
        auto env_1 = env;
        auto k_2 = prism_rtl::val(prism_rtl::val(k));
        auto lx_3 = lx;
        auto r_4 = prism_rtl::val(prism_rtl::val(r));
        call_then(crate::lower::types::start_out_ty_of(lx_3, crate::lower::types::peel(crate::lower::type_at(lx_3, prism_rtl::val(r_4).span))), [=](crate::lower::model::OutTy out_ty_of_17480) {
        return ({
            auto rt = out_ty_of_17480;
            auto f = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt)) {
                    _v.set(Text::lit("at_mut_map"));
                    goto _done;
                }
                {
                    _v.set(Text::lit("at_mut"));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_then(start_place_of(lx_3, env_1, r_4), [=](crate::lower::model::Ex place_of_17662) { return call_then(crate::lower::expr::start_argument(lx_3, env_1, k_2), [=](crate::lower::model::Ex argument_17685) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{f, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(place_of_17662)}), argument_17685})}))})); }); });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PlaceOf(lx, env, prism_rtl::val(prism_rtl::val(x)))));
    })
        : prism_rtl::finished(crate::lower::expr::refusal(Text::lit("a reference path this back end does not lower")));
    });
}


/// `Start PlaceOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_place_of(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<PlaceOf>(lx, env, e);
}


/// Assign: unbounded fn Lx, Env, Expr, Ex -> Do
crate::lower::model::Do assign(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& target, const crate::lower::model::Ex& v_) {
    auto&& _m = prism_rtl::val(target.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& k = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        auto rt = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, prism_rtl::val(r).span)));
        auto f = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt)) {
                _v.set(Text::lit("set_key"));
                goto _done;
            }
            {
                _v.set(Text::lit("set_index"));
                goto _done;
            }
        _done:
            _v.take();
        });
        return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{f, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(place_of(lx, env, prism_rtl::val(prism_rtl::val(r))))}), crate::lower::expr::argument(lx, env, prism_rtl::val(prism_rtl::val(k))), v_})})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return assign(lx, env, prism_rtl::val(prism_rtl::val(x)), v_);
    }
    {
        return crate::lower::model::Do(crate::lower::model::Do::DoAssign{place_of(lx, env, target), v_});
    }
}


prism_rtl::Turn<crate::lower::model::Do> Assign::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& target = this->target;
    const auto& v_ = this->v_;
    return ({
        auto&& _m = prism_rtl::val(prism_rtl::val(target).kind);
        prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& k = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        ({
        auto env_1 = env;
        auto k_2 = prism_rtl::val(prism_rtl::val(k));
        auto lx_3 = lx;
        auto r_4 = prism_rtl::val(prism_rtl::val(r));
        auto v__5 = v_;
        call_then(crate::lower::types::start_out_ty_of(lx_3, crate::lower::types::peel(crate::lower::type_at(lx_3, prism_rtl::val(r_4).span))), [=](crate::lower::model::OutTy out_ty_of_18093) {
        return ({
            auto rt = out_ty_of_18093;
            auto f = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt)) {
                    _v.set(Text::lit("set_key"));
                    goto _done;
                }
                {
                    _v.set(Text::lit("set_index"));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_then(start_place_of(lx_3, env_1, r_4), [=](crate::lower::model::Ex place_of_18275) { return call_then(crate::lower::expr::start_argument(lx_3, env_1, k_2), [=](crate::lower::model::Ex argument_18298) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{f, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(place_of_18275)}), argument_18298, v__5})})})); }); });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Assign(lx, env, prism_rtl::val(prism_rtl::val(x)), v_)));
    })
        : ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto target_3 = target;
        auto v__4 = v_;
        call_then(start_place_of(lx_2, env_1, target_3), [=](crate::lower::model::Ex place_of_18385) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoAssign{place_of_18385, v__4})); });
    });
    });
}


/// `Start Assign, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_assign(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr target, crate::lower::model::Ex v_) {
    return prism_rtl::make_rc<Assign>(lx, env, target, v_);
}

}  // namespace crate::lower::templates
