// The module `Syntax.Parser.Types`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/parser/types/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/sexp/module.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Syntax.Parser.Types`, from `target/bootstrap/cpp-src/prismc/syntax/parser/types.prism`.
namespace crate::syntax::parser::types {

bool FieldsRead::operator==(const FieldsRead& o) const { return fields == o.fields && rest == o.rest && p_ == o.p_ && going == o.going; }

void FieldsRead::show(Printer& p) const {
    p.record("FieldsRead", {{"fields", fields}, {"rest", rest}, {"p", p_}, {"going", going}});
}

Pod FieldsRead::to_pod() const {
    return Pod::record("FieldsRead", {{"fields", prism_rtl::to_pod(fields)}, {"rest", prism_rtl::to_pod(rest)}, {"p", prism_rtl::to_pod(p_)}, {"going", prism_rtl::to_pod(going)}});
}

Result<FieldsRead> FieldsRead::from_pod(const Pod& whole) {
    return FieldsRead{.fields = TRY(prism_rtl::from_pod<Array<crate::syntax::FieldPat>>(TRY(crate::prelude::field(whole, "fields")))), .rest = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "rest")))), .p_ = TRY(prism_rtl::from_pod<crate::syntax::parser::Ps>(TRY(crate::prelude::field(whole, "p")))), .going = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "going"))))};
}


/// ParseType: unbounded fn Ps -> ((Type, Ps))
std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type(const crate::syntax::parser::Ps& p_) {
    auto start = crate::syntax::parser::here(p_);
    auto color_var = is_plain_lower_one(crate::syntax::parser::kind(p_)) && is_fn_kw(crate::syntax::parser::kind_at(p_, Nat(1u)));
    auto [color, p1] = crate::syntax::parser::at_kw(p_, Text::lit("unbounded"))
        ? std::tuple{crate::syntax::Color(crate::syntax::Color::Unbounded{}), crate::syntax::parser::adv(p_)}
        : std::move(color_var)
        ? color_var_of(p_)
        : std::tuple{crate::syntax::Color(crate::syntax::Color::Bounded{}), p_};
    return crate::syntax::parser::at_kw(p1, Text::lit("fn"))
        ? ({
        auto p2 = crate::syntax::parser::adv(p1);
        auto [params, p3] = crate::syntax::parser::at_op(p2, Text::lit("->"))
            ? std::tuple{Array<crate::syntax::Type>{}, p2}
            : crate::syntax::parser::commas(p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_emit_type(a0)); })));
        auto [result, p4] = parse_type(crate::syntax::parser::expect_op(p3, Text::lit("->")));
        std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TFn{color, params, prism_rtl::rc(result)})), .span = crate::syntax::parser::to(start, prism_rtl::deref(result).span)}, p4};
    })
        : color != crate::syntax::Color(crate::syntax::Color::Bounded{})
        ? std::tuple{crate::syntax::parser::decls::no_type(), crate::syntax::parser::error_here(p1, Text::lit("a color (`unbounded`, or a color variable) is written before a function type\'s `fn`"))}
        : ({
        auto [t, q] = parse_emit_type(p1);
        crate::syntax::parser::at_op(q, Text::lit("->"))
        ? std::tuple{t, crate::syntax::parser::error_at(q, crate::syntax::parser::here(q), Text::lit("a function type begins with `fn`: `fn A -> B`"))}
        : std::tuple{t, q};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> ParseType::cycle() const {
    const auto& p_ = this->p_;
    auto start = crate::syntax::parser::here(p_);
    auto color_var = is_plain_lower_one(crate::syntax::parser::kind(p_)) && is_fn_kw(crate::syntax::parser::kind_at(p_, Nat(1u)));
    auto [color, p1] = crate::syntax::parser::at_kw(p_, Text::lit("unbounded"))
        ? std::tuple{crate::syntax::Color(crate::syntax::Color::Unbounded{}), crate::syntax::parser::adv(p_)}
        : std::move(color_var)
        ? color_var_of(p_)
        : std::tuple{crate::syntax::Color(crate::syntax::Color::Bounded{}), p_};
    return crate::syntax::parser::at_kw(p1, Text::lit("fn"))
        ? ({
        auto p2 = crate::syntax::parser::adv(p1);
        auto [params, p3] = crate::syntax::parser::at_op(p2, Text::lit("->"))
            ? std::tuple{Array<crate::syntax::Type>{}, p2}
            : crate::syntax::parser::commas(p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_emit_type(a0)); })));
        call_then(start_parse_type(crate::syntax::parser::expect_op(p3, Text::lit("->"))), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_1974) {
        return ({
            auto [result, p4] = parse_type_1974;
            (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TFn{color, params, prism_rtl::rc(result)})), .span = crate::syntax::parser::to(start, prism_rtl::deref(result).span)}, p4}));
        });
    });
    })
        : color != crate::syntax::Color(crate::syntax::Color::Bounded{})
        ? prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_type(), crate::syntax::parser::error_here(p1, Text::lit("a color (`unbounded`, or a color variable) is written before a function type\'s `fn`"))})
        : call_then(start_parse_emit_type(p1), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_emit_type_2267) {
        return ({
            auto [t, q] = parse_emit_type_2267;
            (crate::syntax::parser::at_op(q, Text::lit("->"))
            ? prism_rtl::finished(std::tuple{t, crate::syntax::parser::error_at(q, crate::syntax::parser::here(q), Text::lit("a function type begins with `fn`: `fn A -> B`"))})
            : prism_rtl::finished(std::tuple{t, q}));
        });
    });
}


/// `Start ParseType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_parse_type(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseType>(p_);
}


/// IsPlainLowerOne: fn TokKind -> Bool
bool is_plain_lower_one(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(tok_kind0)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(tok_kind0).a0;
        return ((prism_rtl::deref(n).sigils == Text::lit("")) && (prism_rtl::deref(n).case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) && (len(n->path_) == Nat(1u));
    }
    {
        return false;
    }
}


/// IsFnKw: fn TokKind -> Bool
bool is_fn_kw(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(tok_kind0)) {
        auto&& c0_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(tok_kind0).a0;
        if (c0_0_0 == Text::lit("fn")) {
            return true;
        }
    }
    {
        return false;
    }
}


/// ColorVarOf: fn Ps -> ((Color, Ps))
std::tuple<crate::syntax::Color, crate::syntax::parser::Ps> color_var_of(const crate::syntax::parser::Ps& p_) {
    auto [i, q] = crate::syntax::parser::parse_ident(p_);
    return std::tuple{crate::syntax::Color(crate::syntax::Color::ColorVar{i}), q};
}


/// ParseEmitType: unbounded fn Ps -> ((Type, Ps))
std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_emit_type(const crate::syntax::parser::Ps& p_) {
    auto start = crate::syntax::parser::here(p_);
    auto [t, p1] = parse_union_type(p_);
    return crate::syntax::parser::at_kw(p1, Text::lit("emit"))
        ? ({
        auto [r, q] = parse_union_type(crate::syntax::parser::adv(p1));
        std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TEmit{prism_rtl::rc(t), prism_rtl::rc(r)})), .span = crate::syntax::parser::to(start, prism_rtl::deref(r).span)}, q};
    })
        : std::tuple{t, p1};
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> ParseEmitType::cycle() const {
    const auto& p_ = this->p_;
    auto start = crate::syntax::parser::here(p_);
    auto p__1 = p_;
    return call_then(start_parse_union_type(p__1), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_union_type_2872) {
        return ({
            auto [t, p1] = parse_union_type_2872;
            (crate::syntax::parser::at_kw(p1, Text::lit("emit"))
            ? call_then(start_parse_union_type(crate::syntax::parser::adv(p1)), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_union_type_2936) {
            return ({
                auto [r, q] = parse_union_type_2936;
                (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TEmit{prism_rtl::rc(t), prism_rtl::rc(r)})), .span = crate::syntax::parser::to(start, prism_rtl::deref(r).span)}, q}));
            });
        })
            : prism_rtl::finished(std::tuple{t, p1}));
        });
    });
}


/// `Start ParseEmitType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_parse_emit_type(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseEmitType>(p_);
}


/// ParseUnionType: unbounded fn Ps -> ((Type, Ps))
std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_union_type(const crate::syntax::parser::Ps& p_) {
    auto start = crate::syntax::parser::here(p_);
    auto [first_, p1] = parse_map_type(p_);
    return crate::syntax::parser::kind(p1) != crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{})
        ? std::tuple{first_, p1}
        : ({
        auto r = ({
            std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<crate::syntax::Type> terms = Array(std::vector{first_});
            crate::syntax::parser::Ps q = p1;
            while ((crate::syntax::parser::kind(q) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{})) && (!q.bad)) {
                auto [t, q2] = parse_map_type(crate::syntax::parser::adv(q));
                terms = crate::prelude::push(terms, t);
                q = q2;
            }
            this_ = std::tuple{terms, q};
            (std::move(this_));
        });
        auto [terms, q] = r;
        std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TRowUnion{terms})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> ParseUnionType::cycle() const {
    const auto& p_ = this->p_;
    auto start = crate::syntax::parser::here(p_);
    auto p__1 = p_;
    return call_then(start_parse_map_type(p__1), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_map_type_3161) {
        return ({
            auto [first_, p1] = parse_map_type_3161;
            (crate::syntax::parser::kind(p1) != crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{})
            ? prism_rtl::finished(std::tuple{first_, p1})
            : ({
            std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<crate::syntax::Type> terms = Array(std::vector{first_});
            crate::syntax::parser::Ps q = p1;
            auto start_2 = start;
            call_then(loop_job(std::tuple{std::move(this_), std::move(q), std::move(terms)}, [=](std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Type>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q = std::get<1>(_p0);
            auto terms = std::get<2>(_p0);
            return (crate::syntax::parser::kind(q) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{})) && (!q->bad)
                ? ({
                auto [t, q2] = parse_map_type(crate::syntax::parser::adv(q));
                terms = crate::prelude::push(terms, t);
                q = q2;
                Expected<std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Type>>, std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Type>>>(std::tuple{this_, q, terms});
            })
                : Expected<std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Type>>, std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Type>>>(unexpected(std::tuple{this_, q, terms}));
        }), [=, start_2 = std::move(start_2)](std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Type>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q = std::get<1>(_p0);
            auto terms = std::get<2>(_p0);
            return ({
                this_ = std::tuple{terms, q};
                auto r = this_;
                auto [terms, q] = r;
                (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TRowUnion{terms})), .span = crate::syntax::parser::to(start_2, crate::syntax::parser::prev(q))}, q}));
            });
        });
        }));
        });
    });
}


/// `Start ParseUnionType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_parse_union_type(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseUnionType>(p_);
}


/// ParseMapType: unbounded fn Ps -> ((Type, Ps))
std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_map_type(const crate::syntax::parser::Ps& p_) {
    auto start = crate::syntax::parser::here(p_);
    auto [k, p1] = parse_sigiled_type(p_);
    return crate::syntax::parser::at_op(p1, Text::lit("==>"))
        ? ({
        auto [value, q] = parse_map_type(crate::syntax::parser::adv(p1));
        std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TMap{prism_rtl::rc(k), prism_rtl::rc(value)})), .span = crate::syntax::parser::to(start, prism_rtl::deref(value).span)}, q};
    })
        : std::tuple{k, p1};
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> ParseMapType::cycle() const {
    const auto& p_ = this->p_;
    auto start = crate::syntax::parser::here(p_);
    auto p__1 = p_;
    return call_then(start_parse_sigiled_type(p__1), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_sigiled_type_3741) {
        return ({
            auto [k, p1] = parse_sigiled_type_3741;
            (crate::syntax::parser::at_op(p1, Text::lit("==>"))
            ? call_then(start_parse_map_type(crate::syntax::parser::adv(p1)), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_map_type_3810) {
            return ({
                auto [value, q] = parse_map_type_3810;
                (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TMap{prism_rtl::rc(k), prism_rtl::rc(value)})), .span = crate::syntax::parser::to(start, prism_rtl::deref(value).span)}, q}));
            });
        })
            : prism_rtl::finished(std::tuple{k, p1}));
        });
    });
}


/// `Start ParseMapType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_parse_map_type(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseMapType>(p_);
}


/// ParseSigiledType: unbounded fn Ps -> ((Type, Ps))
std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_sigiled_type(const crate::syntax::parser::Ps& p_) {
    auto start = crate::syntax::parser::here(p_);
    auto [sigils, p1] = free_sigil_run(p_);
    auto [inner, q] = parse_app_type(p1);
    return sigils == Text::lit("")
        ? std::tuple{inner, q}
        : std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TSigiled{sigils, prism_rtl::rc(inner)})), .span = crate::syntax::parser::to(start, prism_rtl::deref(inner).span)}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> ParseSigiledType::cycle() const {
    const auto& p_ = this->p_;
    auto start = crate::syntax::parser::here(p_);
    auto [sigils, p1] = free_sigil_run(p_);
    return call_then(start_parse_app_type(p1), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_app_type_4083) {
        return ({
            auto [inner, q] = parse_app_type_4083;
            sigils == Text::lit("")
            ? prism_rtl::finished(std::tuple{inner, q})
            : prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TSigiled{sigils, prism_rtl::rc(inner)})), .span = crate::syntax::parser::to(start, prism_rtl::deref(inner).span)}, q});
        });
    });
}


/// `Start ParseSigiledType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_parse_sigiled_type(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseSigiledType>(p_);
}


/// FreeSigilRun: fn Ps -> ((Text, Ps))
std::tuple<Text, crate::syntax::parser::Ps> free_sigil_run(const crate::syntax::parser::Ps& p0) {
    std::tuple<Text, crate::syntax::parser::Ps> this_ = std::tuple{Text::lit(""), p0};
    Text sigils = Text::lit("");
    crate::syntax::parser::Ps p_ = p0;
    Nat fuel = len(p0.toks);
    while (true) {
        auto&& _m = fuel.checked_sub(Nat(1u));
        if (!(prism_rtl::is_some(_m))) break;
        auto&& left = prism_rtl::some_of(_m);
        fuel = left;
        {
            auto&& _m = crate::syntax::parser::kind(p_);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
                auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
                sigils = prism_rtl::cat(sigils, s);
                p_ = crate::syntax::parser::adv(p_);
            } else {
                fuel = Nat(0u);
            }
        }
    }
    this_ = std::tuple{sigils, p_};
    return this_;
}


/// ParseAppType: unbounded fn Ps -> ((Type, Ps))
std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_app_type(const crate::syntax::parser::Ps& p_) {
    auto start = crate::syntax::parser::here(p_);
    auto [head, p1] = parse_type_atom(p_);
    auto&& _m = prism_rtl::deref(prism_rtl::deref(head).kind);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& name = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m4714_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        if (m4714_0_1.size() == 0u) {
            if (type_atom_starts_here(p1)) {
                auto r = ({
                    std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Type>{}, p1};
                    Array<crate::syntax::Type> args = Array<crate::syntax::Type>{};
                    crate::syntax::parser::Ps q = p1;
                    while (type_atom_starts_here(q) && (!q.bad)) {
                        auto [a, q2] = parse_type_atom(q);
                        args = crate::prelude::push(args, a);
                        q = q2;
                    }
                    this_ = std::tuple{args, q};
                    (std::move(this_));
                });
                auto [args, q] = r;
                return std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TName{name, args})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
            }
        }
    }
    {
        return std::tuple{head, p1};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> ParseAppType::cycle() const {
    const auto& p_ = this->p_;
    auto start = crate::syntax::parser::here(p_);
    auto p__1 = p_;
    return call_then(start_parse_type_atom(p__1), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_atom_4694) {
        return ({
            auto [head, p1] = parse_type_atom_4694;
            ({
            auto&& _m = prism_rtl::deref(prism_rtl::deref(head).kind);
            prism_rtl::is<crate::syntax::TypeKind::TName>(_m) && ({
            auto&& name = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
            auto&& m4714_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
            (m4714_0_1.size() == 0u) && type_atom_starts_here(p1);
        }) ? ({
            auto&& name = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
            auto&& m4714_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
            ({
            std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Type>{}, p1};
            Array<crate::syntax::Type> args = Array<crate::syntax::Type>{};
            crate::syntax::parser::Ps q = p1;
            auto name_2 = name;
            auto start_3 = start;
            call_then(loop_job(std::tuple{std::move(this_), std::move(args), std::move(q)}, [=](std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, Array<crate::syntax::Type>, crate::syntax::parser::Ps> _p0) {
            auto this_ = std::get<0>(_p0);
            auto args = std::get<1>(_p0);
            auto q = std::get<2>(_p0);
            return type_atom_starts_here(q) && (!q->bad)
                ? ({
                auto [a, q2] = parse_type_atom(q);
                args = crate::prelude::push(args, a);
                q = q2;
                Expected<std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, Array<crate::syntax::Type>, crate::syntax::parser::Ps>, std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, Array<crate::syntax::Type>, crate::syntax::parser::Ps>>(std::tuple{this_, args, q});
            })
                : Expected<std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, Array<crate::syntax::Type>, crate::syntax::parser::Ps>, std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, Array<crate::syntax::Type>, crate::syntax::parser::Ps>>(unexpected(std::tuple{this_, args, q}));
        }), [=, name_2 = std::move(name_2), start_3 = std::move(start_3)](std::tuple<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>, Array<crate::syntax::Type>, crate::syntax::parser::Ps> _p0) {
            auto this_ = std::get<0>(_p0);
            auto args = std::get<1>(_p0);
            auto q = std::get<2>(_p0);
            return ({
                this_ = std::tuple{args, q};
                auto r = this_;
                auto [args, q] = r;
                (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TName{name_2, args})), .span = crate::syntax::parser::to(start_3, crate::syntax::parser::prev(q))}, q}));
            });
        });
        });
        })
            : prism_rtl::finished(std::tuple{head, p1});
        });
        });
    });
}


/// `Start ParseAppType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_parse_app_type(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseAppType>(p_);
}


/// TypeAtomStartsHere: fn Ps -> Bool
bool type_atom_starts_here(const crate::syntax::parser::Ps& p_) {
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        return (w == Text::lit("unit")) || (w == Text::lit("any"));
    }
    {
        return false;
    }
}


/// ParseTypeAtom: unbounded fn Ps -> ((Type, Ps))
std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_atom(const crate::syntax::parser::Ps& p_) {
    auto start = crate::syntax::parser::here(p_);
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
        return parse_sigiled_type(p_);
    }
    {
        auto [t, p1] = type_atom_body(p_, start);
        return crate::syntax::parser::kind(p1) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KNonEmpty{})
            ? ({
            auto m = crate::syntax::parser::here(p1);
            auto q = crate::syntax::parser::out_of_scope(crate::syntax::parser::adv(p1), m, Text::lit("non-empty arrays"), Text::lit("the non-empty array type `[a]+` is out of this compiler"));
            std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TNonEmpty{prism_rtl::rc(t)})), .span = crate::syntax::parser::to(start, m)}, q};
        })
            : std::tuple{t, p1};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> ParseTypeAtom::cycle() const {
    const auto& p_ = this->p_;
    auto start = crate::syntax::parser::here(p_);
    return ({
        auto&& _m = crate::syntax::parser::kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m) ? prism_rtl::more(prism_rtl::rc(ParseSigiledType(p_)))
        : ({
        auto p__1 = p_;
        call_then(start_type_atom_body(p__1, start), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> type_atom_body_5777) {
        return ({
            auto [t, p1] = type_atom_body_5777;
            (crate::syntax::parser::kind(p1) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KNonEmpty{})
            ? ({
            auto m = crate::syntax::parser::here(p1);
            auto q = crate::syntax::parser::out_of_scope(crate::syntax::parser::adv(p1), m, Text::lit("non-empty arrays"), Text::lit("the non-empty array type `[a]+` is out of this compiler"));
            (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TNonEmpty{prism_rtl::rc(t)})), .span = crate::syntax::parser::to(start, m)}, q}));
        })
            : prism_rtl::finished(std::tuple{t, p1}));
        });
    });
    });
    });
}


/// `Start ParseTypeAtom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_parse_type_atom(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseTypeAtom>(p_);
}


/// TypeAtomBody: unbounded fn Ps, Range -> ((Type, Ps))
std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> type_atom_body(const crate::syntax::parser::Ps& p_, const crate::syntax::Range& start) {
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        auto name = crate::syntax::SName{.sigils = prism_rtl::deref(n).sigils, .path_ = n->path_, .span = start};
        return (prism_rtl::deref(n).case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseTopic{})) || (prism_rtl::deref(n).case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseHole{}))
            ? std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::THole{name})), .span = start}, crate::syntax::parser::adv(p_)}
            : std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TName{name, Array<crate::syntax::Type>{}})), .span = start}, crate::syntax::parser::check_type_name_scope(crate::syntax::parser::adv(p_), name)};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m6173_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& sigils = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m6173_1_0 == Text::lit("unit")) {
            return std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TUnit{sigils})), .span = start}, crate::syntax::parser::adv(p_)};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m6173_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m6173_2_0 == Text::lit("any")) {
            auto [tr, q] = crate::syntax::parser::parse_trait_ref(crate::syntax::parser::adv(p_));
            return std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TAny{tr})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        auto&& path_ = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        return std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TFamily{crate::syntax::QualName{.path_ = path_, .span = start}})), .span = start}, crate::syntax::parser::adv(p_)};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KAbsent>(_m)) {
        return std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TAbsent{})), .span = start}, crate::syntax::parser::out_of_scope(crate::syntax::parser::adv(p_), start, Text::lit("sparse tuples"), Text::lit("a sparse tuple type is out of this compiler"))};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m6173_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m6173_5_0 == Text::lit("(")) {
            return crate::syntax::parser::at_double_open(p_, Text::lit("("))
                ? ({
                auto [elems, p1] = crate::syntax::parser::commas(crate::syntax::parser::open_double(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_type(a0)); })));
                auto p2 = crate::syntax::parser::close_double(p1, Text::lit("("));
                std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TTuple{elems})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p2))}, p2};
            })
                : ({
                auto [inner, p1] = parse_type(crate::syntax::parser::adv(p_));
                auto p2 = crate::syntax::parser::expect_close(p1, Text::lit("("));
                std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TGroup{prism_rtl::rc(inner)})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p2))}, p2};
            });
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m6173_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m6173_6_0 == Text::lit("[")) {
            auto doubled = crate::syntax::parser::at_double_open(p_, Text::lit("["));
            auto [elem, p1] = parse_type(std::move(doubled)
                ? crate::syntax::parser::open_double(p_)
                : crate::syntax::parser::adv(p_));
            auto p2 = std::move(doubled)
                ? crate::syntax::parser::close_double(p1, Text::lit("["))
                : crate::syntax::parser::expect_close(p1, Text::lit("["));
            return std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TArray{prism_rtl::rc(elem), std::move(doubled)})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p2))}, p2};
        }
    }
    {
        return std::tuple{crate::syntax::parser::decls::no_type(), crate::syntax::parser::error_here(p_, Text::lit("expected a type"))};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> TypeAtomBody::cycle() const {
    const auto& p_ = this->p_;
    const auto& start = this->start;
    return ({
        auto&& _m = crate::syntax::parser::kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ({
        auto name = crate::syntax::SName{.sigils = prism_rtl::deref(n).sigils, .path_ = n->path_, .span = start};
        (prism_rtl::deref(n).case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseTopic{})) || (prism_rtl::deref(n).case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseHole{}))
        ? prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::THole{name})), .span = start}, crate::syntax::parser::adv(p_)})
        : prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TName{name, Array<crate::syntax::Type>{}})), .span = start}, crate::syntax::parser::check_type_name_scope(crate::syntax::parser::adv(p_), name)});
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m6173_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& sigils = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m6173_1_0 == Text::lit("unit"));
    }) ? ({
        auto&& m6173_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& sigils = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TUnit{sigils})), .span = start}, crate::syntax::parser::adv(p_)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m6173_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m6173_2_0 == Text::lit("any"));
    }) ? ({
        auto&& m6173_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto [tr, q] = crate::syntax::parser::parse_trait_ref(crate::syntax::parser::adv(p_));
        (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TAny{tr})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q}));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m) ? ({
        auto&& path_ = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TFamily{crate::syntax::QualName{.path_ = path_, .span = start}})), .span = start}, crate::syntax::parser::adv(p_)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KAbsent>(_m) ? prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TAbsent{})), .span = start}, crate::syntax::parser::out_of_scope(crate::syntax::parser::adv(p_), start, Text::lit("sparse tuples"), Text::lit("a sparse tuple type is out of this compiler"))})
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && ({
        auto&& m6173_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        (m6173_5_0 == Text::lit("("));
    }) ? ({
        auto&& m6173_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        crate::syntax::parser::at_double_open(p_, Text::lit("("))
        ? ({
        auto p__1 = p_;
        auto start_2 = start;
        call_then(crate::syntax::parser::start_commas(crate::syntax::parser::open_double(p__1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_type(a0)); }))), [=, start_2 = std::move(start_2)](std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps> commas_7134) {
        return ({
            auto [elems, p1] = commas_7134;
            auto p2 = crate::syntax::parser::close_double(p1, Text::lit("("));
            (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TTuple{elems})), .span = crate::syntax::parser::to(start_2, crate::syntax::parser::prev(p2))}, p2}));
        });
    });
    })
        : ({
        auto p__1 = p_;
        auto start_2 = start;
        call_then(start_parse_type(crate::syntax::parser::adv(p__1)), [=, start_2 = std::move(start_2)](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_7328) {
        return ({
            auto [inner, p1] = parse_type_7328;
            auto p2 = crate::syntax::parser::expect_close(p1, Text::lit("("));
            (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TGroup{prism_rtl::rc(inner)})), .span = crate::syntax::parser::to(start_2, crate::syntax::parser::prev(p2))}, p2}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && ({
        auto&& m6173_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        (m6173_6_0 == Text::lit("["));
    }) ? ({
        auto&& m6173_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        ({
        auto doubled = crate::syntax::parser::at_double_open(p_, Text::lit("["));
        auto p__1 = p_;
        auto start_2 = start;
        call_then(start_parse_type(std::move(doubled)
        ? crate::syntax::parser::open_double(p__1)
        : crate::syntax::parser::adv(p__1)), [=, start_2 = std::move(start_2)](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_7553) {
        return ({
            auto [elem, p1] = parse_type_7553;
            auto p2 = doubled
                ? crate::syntax::parser::close_double(p1, Text::lit("["))
                : crate::syntax::parser::expect_close(p1, Text::lit("["));
            (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TArray{prism_rtl::rc(elem), doubled})), .span = crate::syntax::parser::to(start_2, crate::syntax::parser::prev(p2))}, p2}));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_type(), crate::syntax::parser::error_here(p_, Text::lit("expected a type"))});
    });
}


/// `Start TypeAtomBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_type_atom_body(crate::syntax::parser::Ps p_, crate::syntax::Range start) {
    return prism_rtl::make_rc<TypeAtomBody>(p_, start);
}


/// ParseBounds: unbounded fn Ps -> (([Bound], Ps))
std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps> parse_bounds(const crate::syntax::parser::Ps& p0) {
    std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::decls::Bound>{}, p0};
    Array<crate::syntax::decls::Bound> bounds = Array<crate::syntax::decls::Bound>{};
    crate::syntax::parser::Ps p_ = p0;
    bool going = true;
    while (std::move(going) && (!p_.bad)) {
        auto [b, q] = parse_bound(p_);
        bounds = crate::prelude::push(bounds, b);
        p_ = q;
        if ((crate::syntax::parser::at_comma(p_) && is_name_kind(crate::syntax::parser::kind_at(p_, Nat(1u)))) && (crate::syntax::parser::kind_at(p_, Nat(2u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}))) {
            p_ = crate::syntax::parser::adv(p_);
        } else  {
            going = false;
        }
    }
    this_ = std::tuple{bounds, p_};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>> ParseBounds::cycle() const {
    const auto& p0 = this->p0;
    std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::decls::Bound>{}, p0};
    Array<crate::syntax::decls::Bound> bounds = Array<crate::syntax::decls::Bound>{};
    crate::syntax::parser::Ps p_ = p0;
    bool going = true;
    return call_then(loop_job(std::tuple{std::move(this_), std::move(bounds), std::move(going), std::move(p_)}, [=](std::tuple<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>, Array<crate::syntax::decls::Bound>, bool, crate::syntax::parser::Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto bounds = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto p_ = std::get<3>(_p0);
        return going && (!p_->bad)
            ? ({
            auto [b, q] = parse_bound(p_);
            bounds = crate::prelude::push(bounds, b);
            p_ = q;
            if ((crate::syntax::parser::at_comma(p_) && is_name_kind(crate::syntax::parser::kind_at(p_, Nat(1u)))) && (crate::syntax::parser::kind_at(p_, Nat(2u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}))) {
                p_ = crate::syntax::parser::adv(p_);
            } else  {
                going = false;
            }
            Expected<std::tuple<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>, Array<crate::syntax::decls::Bound>, bool, crate::syntax::parser::Ps>, std::tuple<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>, Array<crate::syntax::decls::Bound>, bool, crate::syntax::parser::Ps>>(std::tuple{this_, bounds, going, p_});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>, Array<crate::syntax::decls::Bound>, bool, crate::syntax::parser::Ps>, std::tuple<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>, Array<crate::syntax::decls::Bound>, bool, crate::syntax::parser::Ps>>(unexpected(std::tuple{this_, bounds, going, p_}));
    }), [=](std::tuple<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>, Array<crate::syntax::decls::Bound>, bool, crate::syntax::parser::Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto bounds = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto p_ = std::get<3>(_p0);
        return ({
            this_ = std::tuple{bounds, p_};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start ParseBounds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>> start_parse_bounds(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseBounds>(p0);
}


/// IsNameKind: fn TokKind -> Bool
bool is_name_kind(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// IsTraitKind: fn TokKind -> Bool
bool is_trait_kind(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTrait>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// ParseBound: unbounded fn Ps -> ((Bound, Ps))
std::tuple<crate::syntax::decls::Bound, crate::syntax::parser::Ps> parse_bound(const crate::syntax::parser::Ps& p_) {
    auto start = crate::syntax::parser::here(p_);
    auto [var, p1] = crate::syntax::parser::parse_ident(p_);
    auto [first_, p2] = crate::syntax::parser::parse_trait_ref(crate::syntax::parser::expect_colon(p1));
    auto r = ({
        std::tuple<Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_}), p2};
        Array<crate::syntax::TraitRef> traits = Array(std::vector{first_});
        crate::syntax::parser::Ps q = p2;
        while ((crate::syntax::parser::at_comma(q) && is_trait_kind(crate::syntax::parser::kind_at(q, Nat(1u)))) && (!q.bad)) {
            auto [t, q2] = crate::syntax::parser::parse_trait_ref(crate::syntax::parser::adv(q));
            traits = crate::prelude::push(traits, t);
            q = q2;
        }
        this_ = std::tuple{traits, q};
        (std::move(this_));
    });
    auto [traits, q] = r;
    return std::tuple{crate::syntax::decls::Bound{.var = var, .traits = traits, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::Bound, crate::syntax::parser::Ps>> ParseBound::cycle() const {
    const auto& p_ = this->p_;
    auto start = crate::syntax::parser::here(p_);
    auto [var, p1] = crate::syntax::parser::parse_ident(p_);
    auto [first_, p2] = crate::syntax::parser::parse_trait_ref(crate::syntax::parser::expect_colon(p1));
    std::tuple<Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_}), p2};
    Array<crate::syntax::TraitRef> traits = Array(std::vector{first_});
    crate::syntax::parser::Ps q = p2;
    auto start_1 = start;
    auto var_2 = var;
    return call_then(loop_job(std::tuple{std::move(this_), std::move(q), std::move(traits)}, [=](std::tuple<std::tuple<Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::TraitRef>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto q = std::get<1>(_p0);
        auto traits = std::get<2>(_p0);
        return (crate::syntax::parser::at_comma(q) && is_trait_kind(crate::syntax::parser::kind_at(q, Nat(1u)))) && (!q->bad)
            ? ({
            auto [t, q2] = crate::syntax::parser::parse_trait_ref(crate::syntax::parser::adv(q));
            traits = crate::prelude::push(traits, t);
            q = q2;
            Expected<std::tuple<std::tuple<Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::TraitRef>>, std::tuple<std::tuple<Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::TraitRef>>>(std::tuple{this_, q, traits});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::TraitRef>>, std::tuple<std::tuple<Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::TraitRef>>>(unexpected(std::tuple{this_, q, traits}));
    }), [=](std::tuple<std::tuple<Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::TraitRef>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto q = std::get<1>(_p0);
        auto traits = std::get<2>(_p0);
        return ({
            this_ = std::tuple{traits, q};
            auto r = this_;
            auto [traits, q] = r;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::Bound{.var = var_2, .traits = traits, .span = crate::syntax::parser::to(start_1, crate::syntax::parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseBound, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::Bound, crate::syntax::parser::Ps>> start_parse_bound(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseBound>(p_);
}


/// ParseRow: unbounded fn Ps -> ((Row, Ps))
std::tuple<crate::syntax::Row_, crate::syntax::parser::Ps> parse_row(const crate::syntax::parser::Ps& p_) {
    auto start = crate::syntax::parser::here(p_);
    auto [first_, p1] = parse_row_term(p_);
    auto r = ({
        std::tuple<Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
        Array<crate::syntax::RowTerm> terms = Array(std::vector{first_});
        crate::syntax::parser::Ps q = p1;
        while ((crate::syntax::parser::kind(q) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{})) && (!q.bad)) {
            auto [t, q2] = parse_row_term(crate::syntax::parser::adv(q));
            terms = crate::prelude::push(terms, t);
            q = q2;
        }
        this_ = std::tuple{terms, q};
        (std::move(this_));
    });
    auto [terms, q] = r;
    return std::tuple{crate::syntax::Row_{.terms = terms, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Row_, crate::syntax::parser::Ps>> ParseRow::cycle() const {
    const auto& p_ = this->p_;
    auto start = crate::syntax::parser::here(p_);
    auto p__1 = p_;
    return call_then(start_parse_row_term(p__1), [=](std::tuple<crate::syntax::RowTerm, crate::syntax::parser::Ps> parse_row_term_9352) {
        return ({
            auto [first_, p1] = parse_row_term_9352;
            std::tuple<Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<crate::syntax::RowTerm> terms = Array(std::vector{first_});
            crate::syntax::parser::Ps q = p1;
            auto start_2 = start;
            call_then(loop_job(std::tuple{std::move(this_), std::move(q), std::move(terms)}, [=](std::tuple<std::tuple<Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::RowTerm>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q = std::get<1>(_p0);
            auto terms = std::get<2>(_p0);
            return (crate::syntax::parser::kind(q) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{})) && (!q->bad)
                ? ({
                auto [t, q2] = parse_row_term(crate::syntax::parser::adv(q));
                terms = crate::prelude::push(terms, t);
                q = q2;
                Expected<std::tuple<std::tuple<Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::RowTerm>>, std::tuple<std::tuple<Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::RowTerm>>>(std::tuple{this_, q, terms});
            })
                : Expected<std::tuple<std::tuple<Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::RowTerm>>, std::tuple<std::tuple<Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::RowTerm>>>(unexpected(std::tuple{this_, q, terms}));
        }), [=, start_2 = std::move(start_2)](std::tuple<std::tuple<Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::RowTerm>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q = std::get<1>(_p0);
            auto terms = std::get<2>(_p0);
            return ({
                this_ = std::tuple{terms, q};
                auto r = this_;
                auto [terms, q] = r;
                (prism_rtl::finished(std::tuple{crate::syntax::Row_{.terms = terms, .span = crate::syntax::parser::to(start_2, crate::syntax::parser::prev(q))}, q}));
            });
        });
        });
    });
}


/// `Start ParseRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Row_, crate::syntax::parser::Ps>> start_parse_row(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseRow>(p_);
}


/// ParseRowTerm: unbounded fn Ps -> ((RowTerm, Ps))
std::tuple<crate::syntax::RowTerm, crate::syntax::parser::Ps> parse_row_term(const crate::syntax::parser::Ps& p_) {
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        auto&& path_ = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        return std::tuple{crate::syntax::RowTerm(crate::syntax::RowTerm::RFamily{crate::syntax::QualName{.path_ = path_, .span = crate::syntax::parser::here(p_)}}), crate::syntax::parser::adv(p_)};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if (is_plain_lower_one(crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KName{n})) && (!type_atom_after_name(p_))) {
            return std::tuple{crate::syntax::RowTerm(crate::syntax::RowTerm::RVar{crate::syntax::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = crate::syntax::parser::here(p_)}}), crate::syntax::parser::adv(p_)};
        }
    }
    {
        auto [t, q] = parse_map_type(p_);
        return std::tuple{crate::syntax::RowTerm(crate::syntax::RowTerm::RType{t}), q};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::RowTerm, crate::syntax::parser::Ps>> ParseRowTerm::cycle() const {
    const auto& p_ = this->p_;
    return ({
        auto&& _m = crate::syntax::parser::kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m) ? ({
        auto&& path_ = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::RowTerm(crate::syntax::RowTerm::RFamily{crate::syntax::QualName{.path_ = path_, .span = crate::syntax::parser::here(p_)}}), crate::syntax::parser::adv(p_)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        (is_plain_lower_one(crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KName{n})) && (!type_atom_after_name(p_)));
    }) ? ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::RowTerm(crate::syntax::RowTerm::RVar{crate::syntax::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = crate::syntax::parser::here(p_)}}), crate::syntax::parser::adv(p_)});
    })
        : ({
        auto p__1 = p_;
        call_then(start_parse_map_type(p__1), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_map_type_10063) {
        return ({
            auto [t, q] = parse_map_type_10063;
            (prism_rtl::finished(std::tuple{crate::syntax::RowTerm(crate::syntax::RowTerm::RType{t}), q}));
        });
    });
    });
    });
}


/// `Start ParseRowTerm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::RowTerm, crate::syntax::parser::Ps>> start_parse_row_term(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseRowTerm>(p_);
}


/// TypeAtomAfterName: fn Ps -> Bool
bool type_atom_after_name(const crate::syntax::parser::Ps& p_) {
    auto&& _m = crate::syntax::parser::kind_at(p_, Nat(1u));
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// ParsePattern: unbounded fn Ps, Bool -> ((Pattern, Ps))
std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern(const crate::syntax::parser::Ps& p_, const bool& commas0) {
    auto commas = commas0 && (!p_.step_mode);
    auto start = crate::syntax::parser::here(p_);
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        if ((s == Text::lit("?")) || (s == Text::lit("~"))) {
            auto [inner, q] = parse_pattern(crate::syntax::parser::adv(p_), commas);
            return std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PSigil{s, prism_rtl::rc(inner)})), .span = crate::syntax::parser::to(start, prism_rtl::deref(inner).span)}, q};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        return std::tuple{crate::syntax::parser::decls::no_pattern(), crate::syntax::parser::error_at(p_, start, prism_rtl::cat("a free `", s, "` is not a pattern: only `? p` and `~ p` take a value apart"))};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        return name_pattern(p_, n, commas);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m10847_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m10847_3_0 == Text::lit("ignore")) {
            return std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = start}, crate::syntax::parser::adv(p_)};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m10847_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m10847_4_0 == Text::lit("unit")) {
            return std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PUnit{})), .span = start}, crate::syntax::parser::adv(p_)};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m10847_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m10847_5_0 == Text::lit("nil")) {
            return std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PNil{})), .span = start}, crate::syntax::parser::adv(p_)};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m)) {
        return literal_pattern(p_);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(_m)) {
        return literal_pattern(p_);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(_m)) {
        return literal_pattern(p_);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(_m)) {
        return literal_pattern(p_);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m)) {
        return literal_pattern(p_);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KRegex>(_m)) {
        return std::tuple{crate::syntax::parser::decls::no_pattern(), crate::syntax::parser::error_at(p_, start, Text::lit("a regular expression is not a pattern: match a text with `?Match` or `?Find`"))};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a1) {
        auto&& m10847_12_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        if (m10847_12_0 == Text::lit("-")) {
            auto p1 = crate::syntax::parser::adv(p_);
            return is_number_kind(crate::syntax::parser::kind(p1))
                ? ({
                auto [lit, q] = crate::syntax::parser::expr::parse_literal(p1);
                std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PNeg{lit})), .span = crate::syntax::parser::to(start, prism_rtl::deref(lit).span)}, q};
            })
                : std::tuple{crate::syntax::parser::decls::no_pattern(), crate::syntax::parser::error_here(p1, Text::lit("a `-` in a pattern is the sign of a number literal"))};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m10847_13_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m10847_13_0 == Text::lit("(")) {
            return crate::syntax::parser::at_double_open(p_, Text::lit("("))
                ? ({
                auto [elems, p1] = crate::syntax::parser::commas(crate::syntax::parser::open_double(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto q = p0;
                            (prism_rtl::more(prism_rtl::rc(ParsePattern(q, false))));
                        });
                    }));
                })));
                auto p2 = crate::syntax::parser::close_double(p1, Text::lit("("));
                std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PTuple{elems})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p2))}, p2};
            })
                : ({
                auto [inner, p1] = crate::syntax::parser::bracketed(crate::syntax::parser::adv(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto q = p0;
                            (prism_rtl::more(prism_rtl::rc(ParsePattern(q, true))));
                        });
                    }));
                })));
                auto p2 = crate::syntax::parser::expect_close(p1, Text::lit("("));
                std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PGroup{prism_rtl::rc(inner)})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p2))}, p2};
            });
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m10847_14_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m10847_14_0 == Text::lit("[")) {
            if (crate::syntax::parser::at_double_open(p_, Text::lit("["))) {
                auto p1 = crate::syntax::parser::open_double(p_);
                auto [elems, p2] = crate::syntax::parser::at_close(p1, Text::lit("["))
                    ? std::tuple{Array<crate::syntax::Pattern_>{}, p1}
                    : crate::syntax::parser::commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto q = p0;
                            (prism_rtl::more(prism_rtl::rc(ParsePattern(q, false))));
                        });
                    }));
                })));
                auto p3 = crate::syntax::parser::close_double(p2, Text::lit("["));
                return std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PArray{elems})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p3))}, p3};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        auto&& path_ = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        return std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PFamily{crate::syntax::QualName{.path_ = path_, .span = start}})), .span = start}, crate::syntax::parser::adv(p_)};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KAbsent>(_m)) {
        return std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = start}, crate::syntax::parser::out_of_scope(crate::syntax::parser::adv(p_), start, Text::lit("sparse tuples"), Text::lit("an absent component `-` is a sparse tuple\'s, out of this compiler"))};
    }
    {
        return std::tuple{crate::syntax::parser::decls::no_pattern(), crate::syntax::parser::error_here(p_, Text::lit("expected a pattern"))};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> ParsePattern::cycle() const {
    const auto& p_ = this->p_;
    const auto& commas0 = this->commas0;
    auto commas = prism_rtl::deref(commas0) && (!prism_rtl::deref(p_).step_mode);
    auto start = crate::syntax::parser::here(p_);
    return ({
        auto&& _m = crate::syntax::parser::kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m) && ({
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        ((s == Text::lit("?")) || (s == Text::lit("~")));
    }) ? ({
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_pattern(crate::syntax::parser::adv(p__1), std::move(commas)), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_10933) {
        return ({
            auto [inner, q] = parse_pattern_10933;
            (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PSigil{s, prism_rtl::rc(inner)})), .span = crate::syntax::parser::to(start, prism_rtl::deref(inner).span)}, q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_pattern(), crate::syntax::parser::error_at(p_, start, prism_rtl::cat("a free `", s, "` is not a pattern: only `? p` and `~ p` take a value apart"))});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(NamePattern(p_, n, std::move(commas))));
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m10847_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m10847_3_0 == Text::lit("ignore"));
    }) ? ({
        auto&& m10847_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = start}, crate::syntax::parser::adv(p_)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m10847_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m10847_4_0 == Text::lit("unit"));
    }) ? ({
        auto&& m10847_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PUnit{})), .span = start}, crate::syntax::parser::adv(p_)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m10847_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m10847_5_0 == Text::lit("nil"));
    }) ? ({
        auto&& m10847_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PNil{})), .span = start}, crate::syntax::parser::adv(p_)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPattern(p_)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPattern(p_)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPattern(p_)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPattern(p_)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPattern(p_)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KRegex>(_m) ? prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_pattern(), crate::syntax::parser::error_at(p_, start, Text::lit("a regular expression is not a pattern: match a text with `?Match` or `?Find`"))})
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a1 && ({
        auto&& m10847_12_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        (m10847_12_0 == Text::lit("-"));
    }) ? ({
        auto&& m10847_12_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        ({
        auto p1 = crate::syntax::parser::adv(p_);
        is_number_kind(crate::syntax::parser::kind(p1))
        ? call_then(crate::syntax::parser::expr::start_parse_literal(p1), [=](std::tuple<crate::syntax::Literal, crate::syntax::parser::Ps> parse_literal_11989) {
        return ({
            auto [lit, q] = parse_literal_11989;
            (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PNeg{lit})), .span = crate::syntax::parser::to(start, prism_rtl::deref(lit).span)}, q}));
        });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_pattern(), crate::syntax::parser::error_here(p1, Text::lit("a `-` in a pattern is the sign of a number literal"))});
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && ({
        auto&& m10847_13_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        (m10847_13_0 == Text::lit("("));
    }) ? ({
        auto&& m10847_13_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        crate::syntax::parser::at_double_open(p_, Text::lit("("))
        ? ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::start_commas(crate::syntax::parser::open_double(p__1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(ParsePattern(q, false))));
            });
        }));
    }))), [=](std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps> commas_12281) {
        return ({
            auto [elems, p1] = commas_12281;
            auto p2 = crate::syntax::parser::close_double(p1, Text::lit("("));
            (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PTuple{elems})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p2))}, p2}));
        });
    });
    })
        : ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::start_bracketed(crate::syntax::parser::adv(p__1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(ParsePattern(q, true))));
            });
        }));
    }))), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> bracketed_12668) {
        return ({
            auto [inner, p1] = bracketed_12668;
            auto p2 = crate::syntax::parser::expect_close(p1, Text::lit("("));
            (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PGroup{prism_rtl::rc(inner)})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p2))}, p2}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && ({
        auto&& m10847_14_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        (m10847_14_0 == Text::lit("[")) && crate::syntax::parser::at_double_open(p_, Text::lit("["));
    }) ? ({
        auto&& m10847_14_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        ({
        auto p1 = crate::syntax::parser::open_double(p_);
        auto [elems, p2] = crate::syntax::parser::at_close(p1, Text::lit("["))
            ? std::tuple{Array<crate::syntax::Pattern_>{}, p1}
            : crate::syntax::parser::commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
            return entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(ParsePattern(q, false))));
                });
            }));
        })));
        auto p3 = crate::syntax::parser::close_double(p2, Text::lit("["));
        (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PArray{elems})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p3))}, p3}));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m) ? ({
        auto&& path_ = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PFamily{crate::syntax::QualName{.path_ = path_, .span = start}})), .span = start}, crate::syntax::parser::adv(p_)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KAbsent>(_m) ? prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = start}, crate::syntax::parser::out_of_scope(crate::syntax::parser::adv(p_), start, Text::lit("sparse tuples"), Text::lit("an absent component `-` is a sparse tuple\'s, out of this compiler"))})
        : prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_pattern(), crate::syntax::parser::error_here(p_, Text::lit("expected a pattern"))});
    });
}


/// `Start ParsePattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> start_parse_pattern(crate::syntax::parser::Ps p_, bool commas0) {
    return prism_rtl::make_rc<ParsePattern>(p_, commas0);
}


/// IsNumberKind: fn TokKind -> Bool
bool is_number_kind(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// LiteralPattern: unbounded fn Ps -> ((Pattern, Ps))
std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> literal_pattern(const crate::syntax::parser::Ps& p_) {
    auto [lit, q] = crate::syntax::parser::expr::parse_literal(p_);
    return std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PLit{lit})), .span = prism_rtl::deref(lit).span}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> LiteralPattern::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(crate::syntax::parser::expr::start_parse_literal(p__1), [=](std::tuple<crate::syntax::Literal, crate::syntax::parser::Ps> parse_literal_13802) {
        return ({
            auto [lit, q] = parse_literal_13802;
            (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PLit{lit})), .span = prism_rtl::deref(lit).span}, q}));
        });
    });
}


/// `Start LiteralPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> start_literal_pattern(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<LiteralPattern>(p_);
}


/// NamePattern: unbounded fn Ps, NameTok, Bool -> ((Pattern, Ps))
std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> name_pattern(const crate::syntax::parser::Ps& p0, const crate::syntax::lexer::NameTok& n, const bool& commas) {
    auto start = crate::syntax::parser::here(p0);
    auto name = crate::syntax::SName{.sigils = n.sigils, .path_ = n.path_, .span = start};
    auto p_ = crate::syntax::parser::adv(p0);
    return (crate::syntax::parser::is_callee(name) && crate::syntax::parser::at_single_open(p_, Text::lit("("))) && prism_rtl::deref(crate::syntax::parser::tk(p_)).touches
        ? parse_record_pattern(p_, name)
        : crate::syntax::parser::is_callee(name) && pat_arg_starts_here(p_)
        ? ({
        auto [first_, p1] = parse_pattern(p_, false);
        auto r = ({
            std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<crate::syntax::Pattern_> args = Array(std::vector{first_});
            crate::syntax::parser::Ps q = p1;
            while ((commas && crate::syntax::parser::at_comma(q)) && (!q.bad)) {
                auto [a, q2] = parse_pattern(crate::syntax::parser::adv(q), false);
                args = crate::prelude::push(args, a);
                q = q2;
            }
            this_ = std::tuple{args, q};
            (std::move(this_));
        });
        auto [args, q] = r;
        std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PCtor{name, args})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
    })
        : std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PName{name})), .span = start}, p_};
}


prism_rtl::Turn<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> NamePattern::cycle() const {
    const auto& p0 = this->p0;
    const auto& n = this->n;
    const auto& commas = this->commas;
    auto start = crate::syntax::parser::here(p0);
    auto name = crate::syntax::SName{.sigils = prism_rtl::deref(n).sigils, .path_ = n->path_, .span = start};
    auto p_ = crate::syntax::parser::adv(p0);
    return (crate::syntax::parser::is_callee(name) && crate::syntax::parser::at_single_open(p_, Text::lit("("))) && prism_rtl::deref(crate::syntax::parser::tk(p_)).touches
        ? prism_rtl::more(prism_rtl::rc(ParseRecordPattern(p_, name)))
        : crate::syntax::parser::is_callee(name) && pat_arg_starts_here(p_)
        ? ({
        auto commas_1 = prism_rtl::deref(commas);
        call_then(start_parse_pattern(p_, false), [=, commas_1 = std::move(commas_1)](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_14247) {
        return ({
            auto [first_, p1] = parse_pattern_14247;
            std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<crate::syntax::Pattern_> args = Array(std::vector{first_});
            crate::syntax::parser::Ps q = p1;
            auto name_2 = name;
            auto start_3 = start;
            call_then(loop_job(std::tuple{std::move(this_), std::move(args), std::move(q)}, ({
            auto commas_1_4 = commas_1;
            [=, commas_1_4 = std::move(commas_1_4)](std::tuple<std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps>, Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps> _p0) {
            auto this_ = std::get<0>(_p0);
            auto args = std::get<1>(_p0);
            auto q = std::get<2>(_p0);
            return (commas_1_4 && crate::syntax::parser::at_comma(q)) && (!q->bad)
                ? ({
                auto [a, q2] = parse_pattern(crate::syntax::parser::adv(q), false);
                args = crate::prelude::push(args, a);
                q = q2;
                Expected<std::tuple<std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps>, Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps>, std::tuple<std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps>, Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps>>(std::tuple{this_, args, q});
            })
                : Expected<std::tuple<std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps>, Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps>, std::tuple<std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps>, Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps>>(unexpected(std::tuple{this_, args, q}));
        };
        })), [=, name_2 = std::move(name_2), start_3 = std::move(start_3)](std::tuple<std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps>, Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps> _p0) {
            auto this_ = std::get<0>(_p0);
            auto args = std::get<1>(_p0);
            auto q = std::get<2>(_p0);
            return ({
                this_ = std::tuple{args, q};
                auto r = this_;
                auto [args, q] = r;
                (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PCtor{name_2, args})), .span = crate::syntax::parser::to(start_3, crate::syntax::parser::prev(q))}, q}));
            });
        });
        });
    });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PName{name})), .span = start}, p_});
}


/// `Start NamePattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> start_name_pattern(crate::syntax::parser::Ps p0, crate::syntax::lexer::NameTok n, bool commas) {
    return prism_rtl::make_rc<NamePattern>(p0, n, commas);
}


/// PatArgStartsHere: fn Ps -> Bool
bool pat_arg_starts_here(const crate::syntax::parser::Ps& p_) {
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        return (s == Text::lit("?")) || (s == Text::lit("~"));
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m14865_8_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m14865_8_0 == Text::lit("(")) {
            return (!prism_rtl::deref(crate::syntax::parser::tk(p_)).touches) || crate::syntax::parser::at_double_open(p_, Text::lit("("));
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m14865_9_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m14865_9_0 == Text::lit("[")) {
            return crate::syntax::parser::at_double_open(p_, Text::lit("["));
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a1) {
        auto&& m14865_10_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        if (m14865_10_0 == Text::lit("-")) {
            return true;
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        return ((w == Text::lit("ignore")) || (w == Text::lit("unit"))) || (w == Text::lit("nil"));
    }
    {
        return false;
    }
}


/// ParseRecordPattern: unbounded fn Ps, SName -> ((Pattern, Ps))
std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_record_pattern(const crate::syntax::parser::Ps& p0, const crate::syntax::SName& name) {
    auto p_ = crate::syntax::parser::adv(p0);
    auto r = ({
        FieldsRead this_ = FieldsRead{.fields = Array<crate::syntax::FieldPat>{}, .rest = false, .p_ = p_, .going = !crate::syntax::parser::at_close(p_, Text::lit("("))};
        while (this_.going && (!this_.p_->bad)) {
            if (crate::syntax::parser::kind(this_.p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDotDot{})) {
                this_.p_ = crate::syntax::parser::adv(this_.p_);
                this_.rest = true;
            } else  {
                auto fstart = crate::syntax::parser::here(this_.p_);
                auto [fname_opt, p1] = crate::syntax::parser::expr::parse_arg_name(this_.p_);
                auto [pattern, p2] = parse_pattern(p1, false);
                this_.fields = crate::prelude::push(this_.fields, crate::syntax::FieldPat{.name = fname_opt, .pattern = pattern, .span = crate::syntax::parser::to(fstart, prism_rtl::deref(pattern).span)});
                this_.p_ = p2;
            }
            if (crate::syntax::parser::at_comma(this_.p_)) {
                this_.p_ = crate::syntax::parser::adv(this_.p_);
            } else  {
                this_.going = false;
            }
        }
        (std::move(this_));
    });
    auto q = crate::syntax::parser::expect_close(prism_rtl::deref(r).p_, Text::lit("("));
    return std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PRecord{name, prism_rtl::deref(r).fields, prism_rtl::deref(r).rest})), .span = crate::syntax::parser::to(name.span, crate::syntax::parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> ParseRecordPattern::cycle() const {
    const auto& p0 = this->p0;
    const auto& name = this->name;
    auto p_ = crate::syntax::parser::adv(p0);
    FieldsRead this_ = FieldsRead{.fields = Array<crate::syntax::FieldPat>{}, .rest = false, .p_ = p_, .going = !crate::syntax::parser::at_close(p_, Text::lit("("))};
    auto name_1 = name;
    auto p__2 = p_;
    return call_then(loop_job(std::tuple{std::move(this_)}, ({
        auto name_1_3 = name_1;
        auto p__2_3 = p__2;
        [=](std::tuple<FieldsRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return prism_rtl::deref(this_).going && (!prism_rtl::deref(this_).p_->bad)
            ? ({
            if (crate::syntax::parser::kind(prism_rtl::deref(this_).p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDotDot{})) {
                prism_rtl::deref(this_).p_ = crate::syntax::parser::adv(prism_rtl::deref(this_).p_);
                prism_rtl::deref(this_).rest = true;
            } else  {
                auto fstart = crate::syntax::parser::here(prism_rtl::deref(this_).p_);
                auto [fname_opt, p1] = crate::syntax::parser::expr::parse_arg_name(prism_rtl::deref(this_).p_);
                auto [pattern, p2] = parse_pattern(p1, false);
                prism_rtl::deref(this_).fields = crate::prelude::push(prism_rtl::deref(this_).fields, crate::syntax::FieldPat{.name = fname_opt, .pattern = pattern, .span = crate::syntax::parser::to(fstart, prism_rtl::deref(pattern).span)});
                prism_rtl::deref(this_).p_ = p2;
            }
            if (crate::syntax::parser::at_comma(prism_rtl::deref(this_).p_)) {
                prism_rtl::deref(this_).p_ = crate::syntax::parser::adv(prism_rtl::deref(this_).p_);
            } else  {
                prism_rtl::deref(this_).going = false;
            }
            Expected<std::tuple<FieldsRead>, std::tuple<FieldsRead>>(std::tuple{this_});
        })
            : Expected<std::tuple<FieldsRead>, std::tuple<FieldsRead>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<FieldsRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto r = this_;
            auto q = crate::syntax::parser::expect_close(prism_rtl::deref(r).p_, Text::lit("("));
            (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PRecord{name_1, prism_rtl::deref(r).fields, prism_rtl::deref(r).rest})), .span = crate::syntax::parser::to(prism_rtl::deref(name_1).span, crate::syntax::parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseRecordPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> start_parse_record_pattern(crate::syntax::parser::Ps p0, crate::syntax::SName name) {
    return prism_rtl::make_rc<ParseRecordPattern>(p0, name);
}

}  // namespace crate::syntax::parser::types
