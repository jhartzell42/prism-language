// The modules `Syntax.Lexer.Literals`, `Syntax.Lexer.Regexes`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/lexer/literals/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Syntax.Lexer.Literals`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/literals.prism`.
namespace crate::syntax::lexer::literals {

/// LexNumber: unbounded fn Lex, Text -> ((TokKind, Lex))
std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_number(const crate::syntax::lexer::Lex& l_p0, const Text& sigils_p1) {
    return (crate::syntax::lexer::chars::peek(l_p0) == Text::lit("0")) && crate::syntax::lexer::chars::contains(Text::lit("xob"), crate::syntax::lexer::chars::peek_at(l_p0, Nat(1u)))
        ? lex_radix(l_p0, sigils_p1)
        : lex_decimal(l_p0, sigils_p1);
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> LexNumber::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& sigils_p1 = this->sigils_p1;
    return (crate::syntax::lexer::chars::peek(l_p0) == Text::lit("0")) && crate::syntax::lexer::chars::contains(Text::lit("xob"), crate::syntax::lexer::chars::peek_at(l_p0, Nat(1u)))
        ? prism_rtl::more(prism_rtl::rc(LexRadix(l_p0, sigils_p1)))
        : prism_rtl::more(prism_rtl::rc(LexDecimal(l_p0, sigils_p1)));
}


/// `Start LexNumber, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_number(crate::syntax::lexer::Lex l_p0, Text sigils_p1) {
    return prism_rtl::make_rc<LexNumber>(l_p0, sigils_p1);
}


/// LexRadix: unbounded fn Lex, Text -> ((TokKind, Lex))
std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_radix(const crate::syntax::lexer::Lex& l0_p0, const Text& sigils_p1) {
    auto start_p2 = l0_p0.pos;
    auto radix_p3 = crate::syntax::lexer::chars::peek_at(l0_p0, Nat(1u));
    auto l1_p4 = crate::syntax::lexer::chars::forward(l0_p0, Nat(2u));
    auto digits_p5 = radix_p3 == Text::lit("x")
        ? ([]() -> const Regex& { static const Regex r = Regex::lit("[0-9a-fA-F_]*", ""); return r; }())
        : radix_p3 == Text::lit("o")
        ? ([]() -> const Regex& { static const Regex r = Regex::lit("[0-7_]*", ""); return r; }())
        : ([]() -> const Regex& { static const Regex r = Regex::lit("[01_]*", ""); return r; }());
    auto l2_p6 = ({
        crate::syntax::lexer::Lex this_ = l1_p4;
        this_.pos = crate::syntax::lexer::chars::match_end(digits_p5, this_.src, this_.pos);
        (std::move(this_));
    });
    auto l3_p7 = prism_rtl::deref(l2_p6).pos == prism_rtl::deref(l1_p4).pos
        ? crate::syntax::lexer::chars::lex_err(l2_p6, start_p2, prism_rtl::deref(l2_p6).pos, Text::lit("a radix prefix needs digits after it"))
        : l2_p6;
    auto l4_p8 = check_no_suffix(l3_p7, start_p2);
    auto kind_p9 = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KInt{sigils_p1, crate::syntax::lexer::chars::slice(l4_p8, start_p2, prism_rtl::deref(l4_p8).pos)});
    return std::tuple{kind_p9, l4_p8};
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> LexRadix::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    const auto& sigils_p1 = this->sigils_p1;
    auto start_p2 = prism_rtl::deref(l0_p0).pos;
    auto radix_p3 = crate::syntax::lexer::chars::peek_at(l0_p0, Nat(1u));
    auto l1_p4 = crate::syntax::lexer::chars::forward(l0_p0, Nat(2u));
    auto digits_p5 = radix_p3 == Text::lit("x")
        ? ([]() -> const Regex& { static const Regex r = Regex::lit("[0-9a-fA-F_]*", ""); return r; }())
        : radix_p3 == Text::lit("o")
        ? ([]() -> const Regex& { static const Regex r = Regex::lit("[0-7_]*", ""); return r; }())
        : ([]() -> const Regex& { static const Regex r = Regex::lit("[01_]*", ""); return r; }());
    auto l2_p6 = ({
        crate::syntax::lexer::Lex this_ = l1_p4;
        this_.pos = crate::syntax::lexer::chars::match_end(digits_p5, this_.src, this_.pos);
        (std::move(this_));
    });
    auto l3_p7 = prism_rtl::deref(l2_p6).pos == prism_rtl::deref(l1_p4).pos
        ? crate::syntax::lexer::chars::lex_err(l2_p6, start_p2, prism_rtl::deref(l2_p6).pos, Text::lit("a radix prefix needs digits after it"))
        : l2_p6;
    auto sigils_p1_1 = sigils_p1;
    return call_then(start_check_no_suffix(l3_p7, start_p2), [=](crate::syntax::lexer::Lex check_no_suffix_1221) {
        return ({
            auto l4_p8 = check_no_suffix_1221;
            auto kind_p9 = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KInt{sigils_p1_1, crate::syntax::lexer::chars::slice(l4_p8, start_p2, prism_rtl::deref(l4_p8).pos)});
            (prism_rtl::finished(std::tuple{kind_p9, l4_p8}));
        });
    });
}


/// `Start LexRadix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_radix(crate::syntax::lexer::Lex l0_p0, Text sigils_p1) {
    return prism_rtl::make_rc<LexRadix>(l0_p0, sigils_p1);
}


/// SkipDigits: unbounded fn Lex -> Lex
crate::syntax::lexer::Lex skip_digits(const crate::syntax::lexer::Lex& l_p0) {
    crate::syntax::lexer::Lex this_ = l_p0;
    this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9_]*", ""); return r; }()), this_.src, this_.pos);
    return this_;
}


prism_rtl::Turn<crate::syntax::lexer::Lex> SkipDigits::cycle() const {
    const auto& l_p0 = this->l_p0;
    return prism_rtl::finished(({
        crate::syntax::lexer::Lex this_ = l_p0;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9_]*", ""); return r; }()), this_.src, this_.pos);
        (std::move(this_));
    }));
}


/// `Start SkipDigits, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_skip_digits(crate::syntax::lexer::Lex l_p0) {
    return prism_rtl::make_rc<SkipDigits>(l_p0);
}


/// LexDecimal: unbounded fn Lex, Text -> ((TokKind, Lex))
std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_decimal(const crate::syntax::lexer::Lex& l0_p0, const Text& sigils_p1) {
    auto start_p2 = l0_p0.pos;
    auto l1_p3 = skip_digits(l0_p0);
    auto next_p4 = crate::syntax::lexer::chars::peek_at(l1_p3, Nat(1u));
    return (crate::syntax::lexer::chars::peek(l1_p3) == Text::lit(".")) && crate::syntax::lexer::chars::is_digit(next_p4)
        ? number_tail(skip_digits(crate::syntax::lexer::chars::bump(l1_p3)), sigils_p1, start_p2, true)
        : (((crate::syntax::lexer::chars::peek(l1_p3) == Text::lit(".")) && (next_p4 != Text::lit("."))) && (next_p4 != Text::lit(""))) && (!crate::syntax::lexer::chars::is_ident_start(next_p4))
        ? ({
        auto l2_p5 = crate::syntax::lexer::chars::bump(l1_p3);
        auto l3_p6 = crate::syntax::lexer::chars::lex_err(l2_p5, start_p2, prism_rtl::deref(l2_p5).pos, prism_rtl::cat("`", crate::syntax::lexer::chars::slice(l2_p5, start_p2, prism_rtl::deref(l2_p5).pos), "` is not a number: a decimal literal has digits on both sides of its point"));
        auto kind_p7 = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFloat{sigils_p1, crate::syntax::lexer::chars::slice(l3_p6, start_p2, crate::syntax::lexer::chars::dec(prism_rtl::deref(l2_p5).pos))});
        std::tuple{kind_p7, l3_p6};
    })
        : number_tail(l1_p3, sigils_p1, start_p2, false);
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> LexDecimal::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    const auto& sigils_p1 = this->sigils_p1;
    auto start_p2 = prism_rtl::deref(l0_p0).pos;
    auto l0_p0_1 = l0_p0;
    auto sigils_p1_2 = sigils_p1;
    return call_then(start_skip_digits(l0_p0_1), [=](crate::syntax::lexer::Lex skip_digits_1549) {
        return ({
            auto l1_p3 = skip_digits_1549;
            auto next_p4 = crate::syntax::lexer::chars::peek_at(l1_p3, Nat(1u));
            (crate::syntax::lexer::chars::peek(l1_p3) == Text::lit(".")) && crate::syntax::lexer::chars::is_digit(next_p4)
            ? call_then(start_skip_digits(crate::syntax::lexer::chars::bump(l1_p3)), [=](crate::syntax::lexer::Lex skip_digits_1647) { return prism_rtl::more(prism_rtl::rc(NumberTail(skip_digits_1647, sigils_p1_2, start_p2, true))); })
            : (((crate::syntax::lexer::chars::peek(l1_p3) == Text::lit(".")) && (next_p4 != Text::lit("."))) && (next_p4 != Text::lit(""))) && (!crate::syntax::lexer::chars::is_ident_start(next_p4))
            ? ({
            auto l2_p5 = crate::syntax::lexer::chars::bump(l1_p3);
            auto l3_p6 = crate::syntax::lexer::chars::lex_err(l2_p5, start_p2, prism_rtl::deref(l2_p5).pos, prism_rtl::cat("`", crate::syntax::lexer::chars::slice(l2_p5, start_p2, prism_rtl::deref(l2_p5).pos), "` is not a number: a decimal literal has digits on both sides of its point"));
            auto kind_p7 = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFloat{sigils_p1_2, crate::syntax::lexer::chars::slice(l3_p6, start_p2, crate::syntax::lexer::chars::dec(prism_rtl::deref(l2_p5).pos))});
            (prism_rtl::finished(std::tuple{kind_p7, l3_p6}));
        })
            : prism_rtl::more(prism_rtl::rc(NumberTail(l1_p3, sigils_p1_2, start_p2, false)));
        });
    });
}


/// `Start LexDecimal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_decimal(crate::syntax::lexer::Lex l0_p0, Text sigils_p1) {
    return prism_rtl::make_rc<LexDecimal>(l0_p0, sigils_p1);
}


/// let durationUnits
Array<std::tuple<Text, Nat>> duration_units() {
    return Array(std::vector{std::tuple{Text::lit("ns"), Nat(1u)}, std::tuple{Text::lit("us"), Nat(1000u)}, std::tuple{Text::lit("ms"), Nat(1000000u)}, std::tuple{Text::lit("min"), *Nat::from_int(Int(60000000000ll))}, std::tuple{Text::lit("s"), *Nat::from_int(Int(1000000000ll))}, std::tuple{Text::lit("h"), *Nat::from_int(Int(3600000000000ll))}});
}


/// ?UnitAt: fn Lex -> ?((Text, Nat))
std::optional<std::tuple<Text, Nat>> unit_at(const crate::syntax::lexer::Lex& l_p0) {
    auto&& _m = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("(?:ns|us|ms|min|s|h)\\b", ""); return r; }()), l_p0);
    {
        auto&& m2712_0 = _m;
        if (m2712_0 == Text::lit("")) {
            return std::optional<std::tuple<Text, Nat>>{};
        }
    }
    {
        auto&& u_p1 = _m;
        return fold(duration_units(), std::optional<std::tuple<Text, Nat>>{}, [&](const std::optional<std::tuple<Text, Nat>>& found_o2, const std::tuple<Text, Nat>& _p1) {
            auto&& name_p3 = std::get<0>(_p1);
            auto&& scale_p4 = std::get<1>(_p1);
            return name_p3 == u_p1 ? std::optional(std::tuple{name_p3, scale_p4}) : found_o2;
        });
    }
}


/// NumberTail: unbounded fn Lex, Text, Nat, Bool -> ((TokKind, Lex))
std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> number_tail(const crate::syntax::lexer::Lex& l_p0, const Text& sigils_p1, const Nat& start_p2, const bool& decimal_p3) {
    auto&& _m = unit_at(l_p0);
    if (prism_rtl::is_some(_m)) {
        auto&& u_p4 = std::get<0>(prism_rtl::some_of(_m));
        auto&& scale_p5 = std::get<1>(prism_rtl::some_of(_m));
        auto digits_p6 = crate::syntax::lexer::chars::slice(l_p0, start_p2, l_p0.pos);
        auto l2_p7 = crate::syntax::lexer::chars::forward(l_p0, len_text(u_p4));
        auto l3_p8 = whole_nanoseconds(digits_p6, scale_p5)
            ? l2_p7
            : crate::syntax::lexer::chars::lex_err(l2_p7, start_p2, prism_rtl::deref(l2_p7).pos, prism_rtl::cat("`", digits_p6, u_p4, "` does not name a whole number of nanoseconds"));
        auto kind_p9 = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDuration{sigils_p1, digits_p6, u_p4});
        return std::tuple{kind_p9, l3_p8};
    }
    if (prism_rtl::is_none(_m)) {
        auto [dec_pd, l2_pe] = exponent(l_p0, decimal_p3);
        auto l3_pa = check_no_suffix(l2_pe, start_p2);
        auto text_pb = crate::syntax::lexer::chars::slice(l3_pa, start_p2, prism_rtl::deref(l3_pa).pos);
        auto kind_pc = dec_pd
            ? crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFloat{sigils_p1, text_pb})
            : crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KInt{sigils_p1, text_pb});
        return std::tuple{kind_pc, l3_pa};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> NumberTail::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& sigils_p1 = this->sigils_p1;
    const auto& start_p2 = this->start_p2;
    const auto& decimal_p3 = this->decimal_p3;
    return ({
        auto&& _m = unit_at(l_p0);
        prism_rtl::is_some(_m) ? ({
        auto&& u_p4 = std::get<0>(prism_rtl::some_of(_m));
        auto&& scale_p5 = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto digits_p6 = crate::syntax::lexer::chars::slice(l_p0, start_p2, prism_rtl::deref(l_p0).pos);
        auto l2_p7 = crate::syntax::lexer::chars::forward(l_p0, len_text(u_p4));
        auto l3_p8 = whole_nanoseconds(digits_p6, scale_p5)
            ? l2_p7
            : crate::syntax::lexer::chars::lex_err(l2_p7, start_p2, prism_rtl::deref(l2_p7).pos, prism_rtl::cat("`", digits_p6, u_p4, "` does not name a whole number of nanoseconds"));
        auto kind_p9 = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDuration{sigils_p1, digits_p6, u_p4});
        (prism_rtl::finished(std::tuple{kind_p9, l3_p8}));
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto decimal_p3_1 = prism_rtl::deref(decimal_p3);
        auto l_p0_2 = l_p0;
        auto sigils_p1_3 = sigils_p1;
        auto start_p2_4 = start_p2;
        call_then(start_exponent(l_p0_2, std::move(decimal_p3_1)), [=, sigils_p1_3 = std::move(sigils_p1_3), start_p2_4 = std::move(start_p2_4)](std::tuple<bool, crate::syntax::lexer::Lex> exponent_3556) {
        return ({
            auto [dec_pd, l2_pe] = exponent_3556;
            call_then(start_check_no_suffix(l2_pe, start_p2_4), [=](crate::syntax::lexer::Lex check_no_suffix_3593) {
            return ({
                auto l3_pa = check_no_suffix_3593;
                auto text_pb = crate::syntax::lexer::chars::slice(l3_pa, start_p2_4, prism_rtl::deref(l3_pa).pos);
                auto kind_pc = dec_pd
                    ? crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFloat{sigils_p1_3, text_pb})
                    : crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KInt{sigils_p1_3, text_pb});
                (prism_rtl::finished(std::tuple{kind_pc, l3_pa}));
            });
        });
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start NumberTail, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_number_tail(crate::syntax::lexer::Lex l_p0, Text sigils_p1, Nat start_p2, bool decimal_p3) {
    return prism_rtl::make_rc<NumberTail>(l_p0, sigils_p1, start_p2, decimal_p3);
}


/// Exponent: unbounded fn Lex, Bool -> ((Bool, Lex))
std::tuple<bool, crate::syntax::lexer::Lex> exponent(const crate::syntax::lexer::Lex& l_p0, const bool& decimal_p1) {
    auto end_p2 = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[eE][+-]?[0-9][0-9_]*", ""); return r; }()), l_p0.src, l_p0.pos);
    return end_p2 > l_p0.pos
        ? ({
        auto l2_p3 = ({
            crate::syntax::lexer::Lex this_ = l_p0;
            this_.pos = end_p2;
            (std::move(this_));
        });
        std::tuple{true, l2_p3};
    })
        : std::tuple{decimal_p1, l_p0};
}


prism_rtl::Turn<std::tuple<bool, crate::syntax::lexer::Lex>> Exponent::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& decimal_p1 = this->decimal_p1;
    auto end_p2 = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[eE][+-]?[0-9][0-9_]*", ""); return r; }()), prism_rtl::deref(l_p0).src, prism_rtl::deref(l_p0).pos);
    return end_p2 > prism_rtl::deref(l_p0).pos
        ? ({
        auto l2_p3 = ({
            crate::syntax::lexer::Lex this_ = l_p0;
            this_.pos = end_p2;
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{true, l2_p3}));
    })
        : prism_rtl::finished(std::tuple{prism_rtl::deref(decimal_p1), l_p0});
}


/// `Start Exponent, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<bool, crate::syntax::lexer::Lex>> start_exponent(crate::syntax::lexer::Lex l_p0, bool decimal_p1) {
    return prism_rtl::make_rc<Exponent>(l_p0, decimal_p1);
}


/// WholeNanoseconds: fn Text, Nat -> Bool
bool whole_nanoseconds(const Text& text_p0, const Nat& scale_p1) {
    auto parts_p2 = split_on(concat(split_on(text_p0, Text::lit("_"))), Text::lit("."));
    auto&& _m = index(parts_p2, Nat(1u));
    if (prism_rtl::is_none(_m)) {
        return true;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& frac0_p3 = prism_rtl::some_of(_m);
        auto frac_p4 = trim_zeros(frac0_p3);
        auto k_p5 = len_text(frac_p4);
        auto f_p6 = frac_p4 == Text::lit("") ? Nat(0u) : or_(parse_nat_opt(frac_p4), Nat(1u));
        auto tens_p7 = crate::syntax::lexer::chars::fold_chars(frac_p4, Nat(1u), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=](std::tuple<Nat, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return once_job([=]() {
                return ({
                    auto p_p8 = p0;
                    static_cast<void>(p1);
                    (prism_rtl::finished(p_p8 * Nat(10u)));
                });
            });
        })));
        return (k_p5 <= Nat(30u)) && (or_(mod_(f_p6 * scale_p1, tens_p7), Nat(1u)) == Nat(0u));
    }
    prism_rtl::unreachable("no arm matched");
}


/// TrimZeros: fn Text -> Text
Text trim_zeros(const Text& t_p0) {
    return crate::syntax::lexer::chars::trim_trailing(t_p0, Text::lit("0"));
}


/// CheckNoSuffix: unbounded fn Lex, Nat -> Lex
crate::syntax::lexer::Lex check_no_suffix(const crate::syntax::lexer::Lex& l0_p0, const Nat& start_p1) {
    return crate::syntax::lexer::chars::is_ident_char(crate::syntax::lexer::chars::peek(l0_p0))
        ? ({
        auto l_p2 = ({
            crate::syntax::lexer::Lex this_ = l0_p0;
            this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_]*", ""); return r; }()), this_.src, this_.pos);
            (std::move(this_));
        });
        (crate::syntax::lexer::chars::lex_err(l_p2, start_p1, prism_rtl::deref(l_p2).pos, prism_rtl::cat("`", crate::syntax::lexer::chars::slice(l_p2, start_p1, prism_rtl::deref(l_p2).pos), "` is not a token: a number literal has no suffix (write a type annotation)")));
    })
        : l0_p0;
}


prism_rtl::Turn<crate::syntax::lexer::Lex> CheckNoSuffix::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    const auto& start_p1 = this->start_p1;
    return crate::syntax::lexer::chars::is_ident_char(crate::syntax::lexer::chars::peek(l0_p0))
        ? ({
        auto l_p2 = ({
            crate::syntax::lexer::Lex this_ = l0_p0;
            this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_]*", ""); return r; }()), this_.src, this_.pos);
            (std::move(this_));
        });
        (prism_rtl::finished(crate::syntax::lexer::chars::lex_err(l_p2, start_p1, prism_rtl::deref(l_p2).pos, prism_rtl::cat("`", crate::syntax::lexer::chars::slice(l_p2, start_p1, prism_rtl::deref(l_p2).pos), "` is not a token: a number literal has no suffix (write a type annotation)"))));
    })
        : prism_rtl::finished(l0_p0);
}


/// `Start CheckNoSuffix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_check_no_suffix(crate::syntax::lexer::Lex l0_p0, Nat start_p1) {
    return prism_rtl::make_rc<CheckNoSuffix>(l0_p0, start_p1);
}


/// LexEscape: unbounded fn Lex -> ((Text, Lex))
std::tuple<Text, crate::syntax::lexer::Lex> lex_escape(const crate::syntax::lexer::Lex& l0_p0) {
    auto start_p1 = l0_p0.pos;
    auto l1_p2 = crate::syntax::lexer::chars::bump(l0_p0);
    auto c_p3 = crate::syntax::lexer::chars::peek(l1_p2);
    auto l2_p4 = crate::syntax::lexer::chars::bump(l1_p2);
    {
        auto&& m5231_0 = c_p3;
        if (m5231_0 == Text::lit("\\")) {
            return std::tuple{Text::lit("\\"), l2_p4};
        }
    }
    {
        auto&& m5231_1 = c_p3;
        if (m5231_1 == Text::lit("\"")) {
            return std::tuple{Text::lit("\""), l2_p4};
        }
    }
    {
        auto&& m5231_2 = c_p3;
        if (m5231_2 == Text::lit("\'")) {
            return std::tuple{Text::lit("\'"), l2_p4};
        }
    }
    {
        auto&& m5231_3 = c_p3;
        if (m5231_3 == Text::lit("n")) {
            return std::tuple{Text::lit("\n"), l2_p4};
        }
    }
    {
        auto&& m5231_4 = c_p3;
        if (m5231_4 == Text::lit("t")) {
            return std::tuple{Text::lit("\t"), l2_p4};
        }
    }
    {
        auto&& m5231_5 = c_p3;
        if (m5231_5 == Text::lit("{")) {
            return std::tuple{Text::lit("{"), l2_p4};
        }
    }
    {
        auto&& m5231_6 = c_p3;
        if (m5231_6 == Text::lit("}")) {
            return std::tuple{Text::lit("}"), l2_p4};
        }
    }
    {
        auto&& m5231_7 = c_p3;
        if (m5231_7 == Text::lit("u")) {
            return unicode_escape(l2_p4, start_p1);
        }
    }
    {
        auto&& m5231_8 = c_p3;
        if (m5231_8 == Text::lit("")) {
            return std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l1_p2, start_p1, prism_rtl::deref(l1_p2).pos, Text::lit("a text literal ends inside an escape"))};
        }
    }
    {
        return std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l2_p4, start_p1, prism_rtl::deref(l2_p4).pos, prism_rtl::cat("`\\", c_p3, "` is not an escape: the escapes are \\\\ \\\" \\n \\t \\{ \\} \\u{hex}"))};
    }
}


prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> LexEscape::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    auto start_p1 = prism_rtl::deref(l0_p0).pos;
    auto l1_p2 = crate::syntax::lexer::chars::bump(l0_p0);
    auto c_p3 = crate::syntax::lexer::chars::peek(l1_p2);
    auto l2_p4 = crate::syntax::lexer::chars::bump(l1_p2);
    return ({
        ({
        auto&& m5231_0 = c_p3;
        (m5231_0 == Text::lit("\\"));
    }) ? ({
        auto&& m5231_0 = c_p3;
        prism_rtl::finished(std::tuple{Text::lit("\\"), l2_p4});
    })
        : ({
        auto&& m5231_1 = c_p3;
        (m5231_1 == Text::lit("\""));
    }) ? ({
        auto&& m5231_1 = c_p3;
        prism_rtl::finished(std::tuple{Text::lit("\""), l2_p4});
    })
        : ({
        auto&& m5231_2 = c_p3;
        (m5231_2 == Text::lit("\'"));
    }) ? ({
        auto&& m5231_2 = c_p3;
        prism_rtl::finished(std::tuple{Text::lit("\'"), l2_p4});
    })
        : ({
        auto&& m5231_3 = c_p3;
        (m5231_3 == Text::lit("n"));
    }) ? ({
        auto&& m5231_3 = c_p3;
        prism_rtl::finished(std::tuple{Text::lit("\n"), l2_p4});
    })
        : ({
        auto&& m5231_4 = c_p3;
        (m5231_4 == Text::lit("t"));
    }) ? ({
        auto&& m5231_4 = c_p3;
        prism_rtl::finished(std::tuple{Text::lit("\t"), l2_p4});
    })
        : ({
        auto&& m5231_5 = c_p3;
        (m5231_5 == Text::lit("{"));
    }) ? ({
        auto&& m5231_5 = c_p3;
        prism_rtl::finished(std::tuple{Text::lit("{"), l2_p4});
    })
        : ({
        auto&& m5231_6 = c_p3;
        (m5231_6 == Text::lit("}"));
    }) ? ({
        auto&& m5231_6 = c_p3;
        prism_rtl::finished(std::tuple{Text::lit("}"), l2_p4});
    })
        : ({
        auto&& m5231_7 = c_p3;
        (m5231_7 == Text::lit("u"));
    }) ? ({
        auto&& m5231_7 = c_p3;
        prism_rtl::more(prism_rtl::rc(UnicodeEscape(l2_p4, start_p1)));
    })
        : ({
        auto&& m5231_8 = c_p3;
        (m5231_8 == Text::lit(""));
    }) ? ({
        auto&& m5231_8 = c_p3;
        prism_rtl::finished(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l1_p2, start_p1, prism_rtl::deref(l1_p2).pos, Text::lit("a text literal ends inside an escape"))});
    })
        : prism_rtl::finished(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l2_p4, start_p1, prism_rtl::deref(l2_p4).pos, prism_rtl::cat("`\\", c_p3, "` is not an escape: the escapes are \\\\ \\\" \\n \\t \\{ \\} \\u{hex}"))});
    });
}


/// `Start LexEscape, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_lex_escape(crate::syntax::lexer::Lex l0_p0) {
    return prism_rtl::make_rc<LexEscape>(l0_p0);
}


/// UnicodeEscape: unbounded fn Lex, Nat -> ((Text, Lex))
std::tuple<Text, crate::syntax::lexer::Lex> unicode_escape(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1) {
    return crate::syntax::lexer::chars::peek(l_p0) != Text::lit("{")
        ? std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l_p0, start_p1, l_p0.pos, Text::lit("`\\u` is written `\\u{hex}`"))}
        : ({
        auto hs_p2 = l_p0.pos + Nat(1u);
        auto l1_p3 = ({
            crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l_p0);
            this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9a-fA-F]*", ""); return r; }()), this_.src, this_.pos);
            (std::move(this_));
        });
        auto hex_p4 = crate::syntax::lexer::chars::slice(l1_p3, hs_p2, prism_rtl::deref(l1_p3).pos);
        (crate::syntax::lexer::chars::peek(l1_p3) != Text::lit("}")
        ? std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l1_p3, start_p1, prism_rtl::deref(l1_p3).pos, Text::lit("`\\u{` needs its closing `}`"))}
        : ({
        auto l2_p5 = crate::syntax::lexer::chars::bump(l1_p3);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, crate::syntax::lexer::Lex>> _v;
        auto&& _m = char_of(or_(crate::syntax::lexer::chars::parse_hex(hex_p4), Nat(1114112u)));
        if (prism_rtl::is_some(_m)) {
            auto&& ch_p6 = prism_rtl::some_of(_m);
            _v.set(std::tuple{crate::prelude::text(ch_p6), l2_p5});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l2_p5, start_p1, prism_rtl::deref(l2_p5).pos, prism_rtl::cat("`\\u{", hex_p4, "}` is no Unicode scalar value: a code point is at most 10FFFF and no surrogate (D800 to DFFF)"))});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    }));
    });
}


prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> UnicodeEscape::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& start_p1 = this->start_p1;
    return crate::syntax::lexer::chars::peek(l_p0) != Text::lit("{")
        ? prism_rtl::finished(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l_p0, start_p1, prism_rtl::deref(l_p0).pos, Text::lit("`\\u` is written `\\u{hex}`"))})
        : ({
        auto hs_p2 = prism_rtl::deref(l_p0).pos + Nat(1u);
        auto l1_p3 = ({
            crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l_p0);
            this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9a-fA-F]*", ""); return r; }()), this_.src, this_.pos);
            (std::move(this_));
        });
        auto hex_p4 = crate::syntax::lexer::chars::slice(l1_p3, hs_p2, prism_rtl::deref(l1_p3).pos);
        (crate::syntax::lexer::chars::peek(l1_p3) != Text::lit("}")
        ? prism_rtl::finished(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l1_p3, start_p1, prism_rtl::deref(l1_p3).pos, Text::lit("`\\u{` needs its closing `}`"))})
        : ({
        auto l2_p5 = crate::syntax::lexer::chars::bump(l1_p3);
        ({
        auto&& _m = char_of(or_(crate::syntax::lexer::chars::parse_hex(hex_p4), Nat(1114112u)));
        prism_rtl::is_some(_m) ? ({
        auto&& ch_p6 = prism_rtl::some_of(_m);
        prism_rtl::finished(std::tuple{crate::prelude::text(ch_p6), l2_p5});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l2_p5, start_p1, prism_rtl::deref(l2_p5).pos, prism_rtl::cat("`\\u{", hex_p4, "}` is no Unicode scalar value: a code point is at most 10FFFF and no surrogate (D800 to DFFF)"))})
        : throw prism_rtl::Panic("no arm matched");
    });
    }));
    });
}


/// `Start UnicodeEscape, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_unicode_escape(crate::syntax::lexer::Lex l_p0, Nat start_p1) {
    return prism_rtl::make_rc<UnicodeEscape>(l_p0, start_p1);
}


/// LexText: unbounded fn Lex -> (([TextSegTok], Lex))
std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> lex_text(const crate::syntax::lexer::Lex& l0_p0) {
    std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<crate::syntax::lexer::TextSegTok>{}, l0_p0};
    auto start_p1 = l0_p0.pos;
    crate::syntax::lexer::Lex l_p2 = crate::syntax::lexer::chars::bump(l0_p0);
    Array<crate::syntax::lexer::TextSegTok> segs_p3 = Array<crate::syntax::lexer::TextSegTok>{};
    Text cur_p4 = Text::lit("");
    bool going_p5 = true;
    while (std::move(going_p5)) {
        auto c_p6 = crate::syntax::lexer::chars::peek(l_p2);
        if ((c_p6 == Text::lit("")) || (c_p6 == Text::lit("\n"))) {
            l_p2 = crate::syntax::lexer::chars::lex_err(l_p2, start_p1, l_p2.pos, Text::lit("a text literal ends on its line: close it with `\"`, or write a multiline text as `raw <markdown>...</markdown>`"));
            going_p5 = false;
        } else  {
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                {
                    auto&& u6987_0 = c_p6;
                    if (u6987_0 == Text::lit("\"")) {
                        _v.set(({
                            l_p2 = crate::syntax::lexer::chars::bump(l_p2);
                            going_p5 = false;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u6987_1 = c_p6;
                    if (u6987_1 == Text::lit("\\")) {
                        _v.set(({
                            auto [s_p7, l2_p8] = lex_escape(l_p2);
                            cur_p4 = prism_rtl::cat(cur_p4, s_p7);
                            l_p2 = l2_p8;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u6987_2 = c_p6;
                    if (u6987_2 == Text::lit("{")) {
                        _v.set(({
                            if (cur_p4 != Text::lit("")) {
                                segs_p3 = crate::prelude::push(segs_p3, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlain{cur_p4}));
                                cur_p4 = Text::lit("");
                            }
                            auto ps_p9 = l_p2.pos;
                            auto [toks_pa, l2_pb] = crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::bump(l_p2), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{Text::lit("single")}));
                            segs_p3 = crate::prelude::push(segs_p3, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlaceholder{toks_pa, crate::syntax::Range{.start = ps_p9, .end = prism_rtl::deref(l2_pb).pos}}));
                            l_p2 = l2_pb;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u6987_3 = c_p6;
                    if (u6987_3 == Text::lit("}")) {
                        _v.set(({
                            l_p2 = crate::syntax::lexer::chars::lex_err(crate::syntax::lexer::chars::bump(l_p2), l_p2.pos, l_p2.pos + Nat(1u), Text::lit("a `}` in text is written `\\}`"));
                            cur_p4 = prism_rtl::cat(cur_p4, "}");
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        auto run_pc = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("[^\"\\\\{}\\n]+", ""); return r; }()), l_p2);
                        l_p2.pos = l_p2.pos + len_text(run_pc);
                        cur_p4 = prism_rtl::cat(cur_p4, run_pc);
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
        }
    }
    if (cur_p4 != Text::lit("")) {
        segs_p3 = crate::prelude::push(segs_p3, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlain{cur_p4}));
    }
    this_ = std::tuple{segs_p3, l_p2};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>> LexText::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<crate::syntax::lexer::TextSegTok>{}, l0_p0};
    auto start_p1 = prism_rtl::deref(l0_p0).pos;
    crate::syntax::lexer::Lex l_p2 = crate::syntax::lexer::chars::bump(l0_p0);
    Array<crate::syntax::lexer::TextSegTok> segs_p3 = Array<crate::syntax::lexer::TextSegTok>{};
    Text cur_p4 = Text::lit("");
    bool going_p5 = true;
    return call_then(loop_job(std::tuple{std::move(this_), std::move(cur_p4), std::move(going_p5), std::move(l_p2), std::move(segs_p3)}, ({
        auto start_p1_1 = start_p1;
        [=, start_p1_1 = std::move(start_p1_1)](std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto cur_p4 = std::get<1>(_p0);
        auto going_p5 = std::get<2>(_p0);
        auto l_p2 = std::get<3>(_p0);
        auto segs_p3 = std::get<4>(_p0);
        return going_p5
            ? ({
            auto c_p6 = crate::syntax::lexer::chars::peek(l_p2);
            if ((c_p6 == Text::lit("")) || (c_p6 == Text::lit("\n"))) {
                l_p2 = crate::syntax::lexer::chars::lex_err(l_p2, start_p1_1, prism_rtl::deref(l_p2).pos, Text::lit("a text literal ends on its line: close it with `\"`, or write a multiline text as `raw <markdown>...</markdown>`"));
                going_p5 = false;
            } else  {
                ({
                    __label__ _done;
                    prism_rtl::Slot<Unit> _v;
                    {
                        auto&& u6987_0 = c_p6;
                        if (u6987_0 == Text::lit("\"")) {
                            _v.set(({
                                l_p2 = crate::syntax::lexer::chars::bump(l_p2);
                                going_p5 = false;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u6987_1 = c_p6;
                        if (u6987_1 == Text::lit("\\")) {
                            _v.set(({
                                auto [s_p7, l2_p8] = lex_escape(l_p2);
                                cur_p4 = prism_rtl::cat(cur_p4, s_p7);
                                l_p2 = l2_p8;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u6987_2 = c_p6;
                        if (u6987_2 == Text::lit("{")) {
                            _v.set(({
                                if (cur_p4 != Text::lit("")) {
                                    segs_p3 = crate::prelude::push(segs_p3, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlain{cur_p4}));
                                    cur_p4 = Text::lit("");
                                }
                                auto ps_p9 = prism_rtl::deref(l_p2).pos;
                                auto [toks_pa, l2_pb] = crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::bump(l_p2), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{Text::lit("single")}));
                                segs_p3 = crate::prelude::push(segs_p3, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlaceholder{toks_pa, crate::syntax::Range{.start = ps_p9, .end = prism_rtl::deref(l2_pb).pos}}));
                                l_p2 = l2_pb;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u6987_3 = c_p6;
                        if (u6987_3 == Text::lit("}")) {
                            _v.set(({
                                l_p2 = crate::syntax::lexer::chars::lex_err(crate::syntax::lexer::chars::bump(l_p2), prism_rtl::deref(l_p2).pos, prism_rtl::deref(l_p2).pos + Nat(1u), Text::lit("a `}` in text is written `\\}`"));
                                cur_p4 = prism_rtl::cat(cur_p4, "}");
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        _v.set(({
                            auto run_pc = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("[^\"\\\\{}\\n]+", ""); return r; }()), l_p2);
                            prism_rtl::deref(l_p2).pos = prism_rtl::deref(l_p2).pos + len_text(run_pc);
                            cur_p4 = prism_rtl::cat(cur_p4, run_pc);
                            Unit{};
                        }));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            }
            Expected<std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>>, std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>>>(std::tuple{this_, cur_p4, going_p5, l_p2, segs_p3});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>>, std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>>>(unexpected(std::tuple{this_, cur_p4, going_p5, l_p2, segs_p3}));
    };
    })), [=](std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto cur_p4 = std::get<1>(_p0);
        auto going_p5 = std::get<2>(_p0);
        auto l_p2 = std::get<3>(_p0);
        auto segs_p3 = std::get<4>(_p0);
        return ({
            if (cur_p4 != Text::lit("")) {
                segs_p3 = crate::prelude::push(segs_p3, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlain{cur_p4}));
            }
            this_ = std::tuple{segs_p3, l_p2};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start LexText, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>> start_lex_text(crate::syntax::lexer::Lex l0_p0) {
    return prism_rtl::make_rc<LexText>(l0_p0);
}


/// LexChar: unbounded fn Lex -> ((Text, Lex))
std::tuple<Text, crate::syntax::lexer::Lex> lex_char(const crate::syntax::lexer::Lex& l0_p0) {
    auto start_p1 = l0_p0.pos;
    auto l1_p2 = crate::syntax::lexer::chars::bump(l0_p0);
    auto c_p3 = crate::syntax::lexer::chars::peek(l1_p2);
    auto [s_p8, l2_p9] = c_p3 == Text::lit("\\")
        ? lex_escape(l1_p2)
        : ((c_p3 == Text::lit("\'")) || (c_p3 == Text::lit("\n"))) || (c_p3 == Text::lit(""))
        ? std::tuple{Text::lit(""), l1_p2}
        : std::tuple{c_p3, crate::syntax::lexer::chars::bump(l1_p2)};
    auto ok_p4 = crate::syntax::lexer::chars::peek(l2_p9) == Text::lit("\'");
    auto l3_p5 = std::move(ok_p4)
        ? crate::syntax::lexer::chars::bump(l2_p9)
        : char_tail(l2_p9, start_p1);
    auto l4_p6 = s_p8 == Text::lit("")
        ? crate::syntax::lexer::chars::lex_err(l3_p5, start_p1, prism_rtl::deref(l3_p5).pos, Text::lit("a character literal holds one code point: `\'c\'`"))
        : l3_p5;
    auto ch_p7 = s_p8 == Text::lit("") ? Text::lit("\000"sv) : s_p8;
    return std::tuple{ch_p7, l4_p6};
}


prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> LexChar::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    auto start_p1 = prism_rtl::deref(l0_p0).pos;
    auto l1_p2 = crate::syntax::lexer::chars::bump(l0_p0);
    auto c_p3 = crate::syntax::lexer::chars::peek(l1_p2);
    auto [s_p8, l2_p9] = c_p3 == Text::lit("\\")
        ? lex_escape(l1_p2)
        : ((c_p3 == Text::lit("\'")) || (c_p3 == Text::lit("\n"))) || (c_p3 == Text::lit(""))
        ? std::tuple{Text::lit(""), l1_p2}
        : std::tuple{c_p3, crate::syntax::lexer::chars::bump(l1_p2)};
    auto ok_p4 = crate::syntax::lexer::chars::peek(l2_p9) == Text::lit("\'");
    auto l3_p5 = std::move(ok_p4)
        ? crate::syntax::lexer::chars::bump(l2_p9)
        : char_tail(l2_p9, start_p1);
    auto l4_p6 = s_p8 == Text::lit("")
        ? crate::syntax::lexer::chars::lex_err(l3_p5, start_p1, prism_rtl::deref(l3_p5).pos, Text::lit("a character literal holds one code point: `\'c\'`"))
        : l3_p5;
    auto ch_p7 = s_p8 == Text::lit("") ? Text::lit("\000"sv) : s_p8;
    return prism_rtl::finished(std::tuple{ch_p7, l4_p6});
}


/// `Start LexChar, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_lex_char(crate::syntax::lexer::Lex l0_p0) {
    return prism_rtl::make_rc<LexChar>(l0_p0);
}


/// CharTail: unbounded fn Lex, Nat -> Lex
crate::syntax::lexer::Lex char_tail(const crate::syntax::lexer::Lex& l0_p0, const Nat& start_p1) {
    auto l1_p2 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[^\'\\n]*", ""); return r; }()), this_.src, this_.pos);
        (std::move(this_));
    });
    auto l2_p3 = crate::syntax::lexer::chars::peek(l1_p2) == Text::lit("\'")
        ? crate::syntax::lexer::chars::bump(l1_p2)
        : l1_p2;
    return crate::syntax::lexer::chars::lex_err(l2_p3, start_p1, prism_rtl::deref(l2_p3).pos, Text::lit("a character literal holds one code point: `\'c\'`"));
}


prism_rtl::Turn<crate::syntax::lexer::Lex> CharTail::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    const auto& start_p1 = this->start_p1;
    auto l1_p2 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[^\'\\n]*", ""); return r; }()), this_.src, this_.pos);
        (std::move(this_));
    });
    auto l2_p3 = crate::syntax::lexer::chars::peek(l1_p2) == Text::lit("\'")
        ? crate::syntax::lexer::chars::bump(l1_p2)
        : l1_p2;
    return prism_rtl::finished(crate::syntax::lexer::chars::lex_err(l2_p3, start_p1, prism_rtl::deref(l2_p3).pos, Text::lit("a character literal holds one code point: `\'c\'`")));
}


/// `Start CharTail, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_char_tail(crate::syntax::lexer::Lex l0_p0, Nat start_p1) {
    return prism_rtl::make_rc<CharTail>(l0_p0, start_p1);
}


/// LexPath: unbounded fn Lex -> (([PathSegTok], Lex))
std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex> lex_path(const crate::syntax::lexer::Lex& l0_p0) {
    std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<crate::syntax::lexer::PathSegTok>{}, l0_p0};
    crate::syntax::lexer::Lex l_p1 = l0_p0;
    Array<crate::syntax::lexer::PathSegTok> segs_p2 = Array<crate::syntax::lexer::PathSegTok>{};
    bool going_p3 = true;
    while (std::move(going_p3)) {
        auto s_p4 = l_p1.pos;
        auto c_p5 = crate::syntax::lexer::chars::peek(l_p1);
        if (c_p5 == Text::lit("#")) {
            auto digits_p6 = ({
                crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l_p1);
                this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9]*", ""); return r; }()), this_.src, this_.pos);
                (std::move(this_));
            });
            auto text_p7 = crate::syntax::lexer::chars::slice(digits_p6, s_p4 + Nat(1u), prism_rtl::deref(digits_p6).pos);
            l_p1 = text_p7 == Text::lit("")
                ? crate::syntax::lexer::chars::lex_err(digits_p6, s_p4, prism_rtl::deref(digits_p6).pos, Text::lit("a generation segment is `#` and a number"))
                : digits_p6;
            segs_p2 = crate::prelude::push(segs_p2, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstGen{or_(parse_nat_opt(text_p7), Nat(0u))}));
        } else if (crate::syntax::lexer::chars::is_digit(c_p5)) {
            auto digits_p8 = ({
                crate::syntax::lexer::Lex this_ = l_p1;
                this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9]*", ""); return r; }()), this_.src, this_.pos);
                (std::move(this_));
            });
            segs_p2 = crate::prelude::push(segs_p2, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstNum{or_(parse_nat_opt(crate::syntax::lexer::chars::slice(digits_p8, s_p4, prism_rtl::deref(digits_p8).pos)), Nat(0u))}));
            l_p1 = digits_p8;
        } else if (c_p5 == Text::lit("[")) {
            auto [toks_p9, l2_pa] = crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::bump(l_p1), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPathKey{}));
            segs_p2 = crate::prelude::push(segs_p2, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstKey{toks_p9}));
            l_p1 = l2_pa;
        } else  {
            l_p1 = crate::syntax::lexer::chars::lex_err(l_p1, s_p4, s_p4, Text::lit("expected a path segment: a number, `#` and a number, or `[key]`"));
            going_p3 = false;
        }
        if (std::move(going_p3)) {
            if (crate::syntax::lexer::chars::peek(l_p1) == Text::lit("/")) {
                l_p1 = crate::syntax::lexer::chars::bump(l_p1);
            } else  {
                going_p3 = false;
            }
        }
    }
    this_ = std::tuple{segs_p2, l_p1};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>> LexPath::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<crate::syntax::lexer::PathSegTok>{}, l0_p0};
    crate::syntax::lexer::Lex l_p1 = l0_p0;
    Array<crate::syntax::lexer::PathSegTok> segs_p2 = Array<crate::syntax::lexer::PathSegTok>{};
    bool going_p3 = true;
    return call_then(loop_job(std::tuple{std::move(this_), std::move(going_p3), std::move(l_p1), std::move(segs_p2)}, [=](std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going_p3 = std::get<1>(_p0);
        auto l_p1 = std::get<2>(_p0);
        auto segs_p2 = std::get<3>(_p0);
        return going_p3
            ? ({
            auto s_p4 = prism_rtl::deref(l_p1).pos;
            auto c_p5 = crate::syntax::lexer::chars::peek(l_p1);
            if (c_p5 == Text::lit("#")) {
                auto digits_p6 = ({
                    crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l_p1);
                    this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9]*", ""); return r; }()), this_.src, this_.pos);
                    (std::move(this_));
                });
                auto text_p7 = crate::syntax::lexer::chars::slice(digits_p6, s_p4 + Nat(1u), prism_rtl::deref(digits_p6).pos);
                l_p1 = text_p7 == Text::lit("")
                    ? crate::syntax::lexer::chars::lex_err(digits_p6, s_p4, prism_rtl::deref(digits_p6).pos, Text::lit("a generation segment is `#` and a number"))
                    : digits_p6;
                segs_p2 = crate::prelude::push(segs_p2, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstGen{or_(parse_nat_opt(text_p7), Nat(0u))}));
            } else if (crate::syntax::lexer::chars::is_digit(c_p5)) {
                auto digits_p8 = ({
                    crate::syntax::lexer::Lex this_ = l_p1;
                    this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9]*", ""); return r; }()), this_.src, this_.pos);
                    (std::move(this_));
                });
                segs_p2 = crate::prelude::push(segs_p2, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstNum{or_(parse_nat_opt(crate::syntax::lexer::chars::slice(digits_p8, s_p4, prism_rtl::deref(digits_p8).pos)), Nat(0u))}));
                l_p1 = digits_p8;
            } else if (c_p5 == Text::lit("[")) {
                auto [toks_p9, l2_pa] = crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::bump(l_p1), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPathKey{}));
                segs_p2 = crate::prelude::push(segs_p2, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstKey{toks_p9}));
                l_p1 = l2_pa;
            } else  {
                l_p1 = crate::syntax::lexer::chars::lex_err(l_p1, s_p4, s_p4, Text::lit("expected a path segment: a number, `#` and a number, or `[key]`"));
                going_p3 = false;
            }
            if (going_p3) {
                if (crate::syntax::lexer::chars::peek(l_p1) == Text::lit("/")) {
                    l_p1 = crate::syntax::lexer::chars::bump(l_p1);
                } else  {
                    going_p3 = false;
                }
            }
            Expected<std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>>, std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>>>(std::tuple{this_, going_p3, l_p1, segs_p2});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>>, std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>>>(unexpected(std::tuple{this_, going_p3, l_p1, segs_p2}));
    }), [=](std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going_p3 = std::get<1>(_p0);
        auto l_p1 = std::get<2>(_p0);
        auto segs_p2 = std::get<3>(_p0);
        return ({
            this_ = std::tuple{segs_p2, l_p1};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start LexPath, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>> start_lex_path(crate::syntax::lexer::Lex l0_p0) {
    return prism_rtl::make_rc<LexPath>(l0_p0);
}

}  // namespace crate::syntax::lexer::literals


// The module `Syntax.Lexer.Regexes`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/regexes.prism`.
namespace crate::syntax::lexer::regexes {

/// let percentMessage
Text percent_message() {
    return Text::lit("`%` is no operator: the remainder is `mod`, and `%` begins a regular expression only as `%/` or `%#/`");
}


/// LexRegex: unbounded fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex lex_regex(const crate::syntax::lexer::Lex& l_p0, const Text& sigils_p1, const Nat& start_p2) {
    auto pct_p3 = l_p0.pos;
    auto open_p4 = hashes_end(l_p0.src, pct_p3 + Nat(1u));
    auto hashes_p5 = crate::syntax::lexer::chars::between(l_p0.src, pct_p3 + Nat(1u), open_p4);
    return crate::syntax::lexer::chars::char_at_byte(l_p0.src, open_p4) != Text::lit("/")
        ? no_regex(l_p0, pct_p3, open_p4, hashes_p5)
        : ({
        auto close_p6 = prism_rtl::cat("/", hashes_p5);
        auto end_o7 = hashes_p5 == Text::lit("")
            ? plain_end(l_p0.src, open_p4 + Nat(1u))
            : hashed_end(l_p0.src, open_p4 + Nat(1u), close_p6);
        ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::lexer::Lex> _v;
        if (prism_rtl::is_some(end_o7)) {
            auto&& e_p8 = prism_rtl::some_of(end_o7);
            _v.set(after_pattern(l_p0, sigils_p1, start_p2, open_p4 + Nat(1u), e_p8, close_p6));
            goto _done;
        }
        if (prism_rtl::is_none(end_o7)) {
            _v.set(unclosed(l_p0, sigils_p1, start_p2, crate::syntax::lexer::chars::between(l_p0.src, open_p4 + Nat(1u), line_end_at(l_p0.src, open_p4)), open_p4 + Nat(1u), std::optional<Text>{}, Text::lit("pattern"), close_p6));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexRegex::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& sigils_p1 = this->sigils_p1;
    const auto& start_p2 = this->start_p2;
    auto pct_p3 = prism_rtl::deref(l_p0).pos;
    auto open_p4 = hashes_end(prism_rtl::deref(l_p0).src, pct_p3 + Nat(1u));
    auto hashes_p5 = crate::syntax::lexer::chars::between(prism_rtl::deref(l_p0).src, pct_p3 + Nat(1u), open_p4);
    return crate::syntax::lexer::chars::char_at_byte(prism_rtl::deref(l_p0).src, open_p4) != Text::lit("/")
        ? prism_rtl::finished(no_regex(l_p0, pct_p3, open_p4, hashes_p5))
        : ({
        auto close_p6 = prism_rtl::cat("/", hashes_p5);
        auto end_o7 = hashes_p5 == Text::lit("")
            ? plain_end(prism_rtl::deref(l_p0).src, open_p4 + Nat(1u))
            : hashed_end(prism_rtl::deref(l_p0).src, open_p4 + Nat(1u), close_p6);
        ({
        prism_rtl::is_some(end_o7) ? ({
        auto&& e_p8 = prism_rtl::some_of(end_o7);
        prism_rtl::more(prism_rtl::rc(AfterPattern(l_p0, sigils_p1, start_p2, open_p4 + Nat(1u), e_p8, close_p6)));
    })
        : prism_rtl::is_none(end_o7) ? prism_rtl::more(prism_rtl::rc(Unclosed(l_p0, sigils_p1, start_p2, crate::syntax::lexer::chars::between(prism_rtl::deref(l_p0).src, open_p4 + Nat(1u), line_end_at(prism_rtl::deref(l_p0).src, open_p4)), open_p4 + Nat(1u), std::optional<Text>{}, Text::lit("pattern"), close_p6)))
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start LexRegex, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_regex(crate::syntax::lexer::Lex l_p0, Text sigils_p1, Nat start_p2) {
    return prism_rtl::make_rc<LexRegex>(l_p0, sigils_p1, start_p2);
}


/// NoRegex: fn Lex, Nat, Nat, Text -> Lex
crate::syntax::lexer::Lex no_regex(const crate::syntax::lexer::Lex& l_p0, const Nat& pct_p1, const Nat& open_p2, const Text& hashes_p3) {
    auto end_p4 = hashes_p3 == Text::lit("") ? pct_p1 + Nat(1u) : open_p2;
    auto message_p5 = hashes_p3 == Text::lit("")
        ? percent_message()
        : Text::lit("a hashed regular expression opens with `%`, its hashes and `/`: `%#/.../#`");
    auto l1_p6 = ({
        crate::syntax::lexer::Lex this_ = l_p0;
        this_.pos = end_p4;
        (std::move(this_));
    });
    auto l2_p7 = crate::syntax::lexer::chars::lex_err(l1_p6, pct_p1, end_p4, message_p5);
    crate::syntax::lexer::Lex this_ = l2_p7;
    this_.last_ws = true;
    return this_;
}


/// AfterPattern: unbounded fn Lex, Text, Nat, Nat, Nat, Text -> Lex
crate::syntax::lexer::Lex after_pattern(const crate::syntax::lexer::Lex& l_p0, const Text& sigils_p1, const Nat& start_p2, const Nat& at_p3, const Nat& end_p4, const Text& close_p5) {
    auto src_p6 = l_p0.src;
    auto pattern_p7 = crate::syntax::lexer::chars::between(src_p6, at_p3, end_p4);
    auto after_p8 = end_p4 + len_text(close_p5);
    auto run_end_p9 = letters_end(src_p6, after_p8);
    auto run_pa = crate::syntax::lexer::chars::between(src_p6, after_p8, run_end_p9);
    auto c_pb = crate::syntax::lexer::chars::char_at_byte(src_p6, run_end_p9);
    auto plain_pc = close_p5 == Text::lit("/");
    return (((c_pb == Text::lit("")) || (c_pb == Text::lit("\n"))) || crate::syntax::lexer::chars::contains(Text::lit(",)]}:;"), c_pb)) || (std::move(plain_pc) && crate::syntax::lexer::chars::is_space_char(c_pb))
        ? finish(l_p0, sigils_p1, start_p2, pattern_p7, at_p3, std::optional<Text>{}, Nat(0u), after_p8)
        : crate::syntax::lexer::chars::has_prefix(text_from(src_p6, run_end_p9), close_p5)
        ? finish(l_p0, sigils_p1, start_p2, pattern_p7, at_p3, std::optional(run_pa), after_p8, run_end_p9 + len_text(close_p5))
        : std::move(plain_pc) && (run_pa == Text::lit(""))
        ? ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::lexer::Lex> _v;
        auto&& _m = plain_end(src_p6, after_p8);
        if (prism_rtl::is_some(_m)) {
            auto&& e_pd = prism_rtl::some_of(_m);
            _v.set(finish(l_p0, sigils_p1, start_p2, pattern_p7, at_p3, std::optional(crate::syntax::lexer::chars::between(src_p6, after_p8, e_pd)), after_p8, e_pd + Nat(1u)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(unclosed(l_p0, sigils_p1, start_p2, pattern_p7, at_p3, std::optional(crate::syntax::lexer::chars::between(src_p6, after_p8, line_end_at(src_p6, after_p8))), Text::lit("replacement"), close_p5));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    })
        : (!std::move(plain_pc)) && ((run_pa == Text::lit("")) || crate::syntax::lexer::chars::is_space_char(c_pb))
        ? ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::lexer::Lex> _v;
        auto&& _m = hashed_end(src_p6, after_p8, close_p5);
        if (prism_rtl::is_some(_m)) {
            auto&& e_pe = prism_rtl::some_of(_m);
            _v.set(finish(l_p0, sigils_p1, start_p2, pattern_p7, at_p3, std::optional(crate::syntax::lexer::chars::between(src_p6, after_p8, e_pe)), after_p8, e_pe + len_text(close_p5)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(finish(l_p0, sigils_p1, start_p2, pattern_p7, at_p3, std::optional<Text>{}, Nat(0u), after_p8));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    })
        : finish(l_p0, sigils_p1, start_p2, pattern_p7, at_p3, std::optional<Text>{}, Nat(0u), after_p8);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> AfterPattern::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& sigils_p1 = this->sigils_p1;
    const auto& start_p2 = this->start_p2;
    const auto& at_p3 = this->at_p3;
    const auto& end_p4 = this->end_p4;
    const auto& close_p5 = this->close_p5;
    auto src_p6 = prism_rtl::deref(l_p0).src;
    auto pattern_p7 = crate::syntax::lexer::chars::between(src_p6, at_p3, end_p4);
    auto after_p8 = end_p4 + len_text(close_p5);
    auto run_end_p9 = letters_end(src_p6, after_p8);
    auto run_pa = crate::syntax::lexer::chars::between(src_p6, after_p8, run_end_p9);
    auto c_pb = crate::syntax::lexer::chars::char_at_byte(src_p6, run_end_p9);
    auto plain_pc = close_p5 == Text::lit("/");
    return (((c_pb == Text::lit("")) || (c_pb == Text::lit("\n"))) || crate::syntax::lexer::chars::contains(Text::lit(",)]}:;"), c_pb)) || (std::move(plain_pc) && crate::syntax::lexer::chars::is_space_char(c_pb))
        ? prism_rtl::more(prism_rtl::rc(Finish(l_p0, sigils_p1, start_p2, pattern_p7, at_p3, std::optional<Text>{}, Nat(0u), after_p8)))
        : crate::syntax::lexer::chars::has_prefix(text_from(src_p6, run_end_p9), close_p5)
        ? prism_rtl::more(prism_rtl::rc(Finish(l_p0, sigils_p1, start_p2, pattern_p7, at_p3, std::optional(run_pa), after_p8, run_end_p9 + len_text(close_p5))))
        : std::move(plain_pc) && (run_pa == Text::lit(""))
        ? ({
        auto&& _m = plain_end(src_p6, after_p8);
        prism_rtl::is_some(_m) ? ({
        auto&& e_pd = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(Finish(l_p0, sigils_p1, start_p2, pattern_p7, at_p3, std::optional(crate::syntax::lexer::chars::between(src_p6, after_p8, e_pd)), after_p8, e_pd + Nat(1u))));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(Unclosed(l_p0, sigils_p1, start_p2, pattern_p7, at_p3, std::optional(crate::syntax::lexer::chars::between(src_p6, after_p8, line_end_at(src_p6, after_p8))), Text::lit("replacement"), close_p5)))
        : throw prism_rtl::Panic("no arm matched");
    })
        : (!std::move(plain_pc)) && ((run_pa == Text::lit("")) || crate::syntax::lexer::chars::is_space_char(c_pb))
        ? ({
        auto at_p3_1 = at_p3;
        auto close_p5_2 = close_p5;
        auto l_p0_3 = l_p0;
        auto sigils_p1_4 = sigils_p1;
        auto start_p2_5 = start_p2;
        call_then(start_hashed_end(src_p6, after_p8, close_p5_2), [=, at_p3_1 = std::move(at_p3_1), l_p0_3 = std::move(l_p0_3), sigils_p1_4 = std::move(sigils_p1_4), start_p2_5 = std::move(start_p2_5)](std::optional<Nat> hashed_end_3454) {
        return ({
            prism_rtl::is_some(hashed_end_3454) ? ({
            auto&& e_pe = prism_rtl::some_of(hashed_end_3454);
            prism_rtl::more(prism_rtl::rc(Finish(l_p0_3, sigils_p1_4, start_p2_5, pattern_p7, at_p3_1, std::optional(crate::syntax::lexer::chars::between(src_p6, after_p8, e_pe)), after_p8, e_pe + len_text(close_p5_2))));
        })
            : prism_rtl::is_none(hashed_end_3454) ? prism_rtl::more(prism_rtl::rc(Finish(l_p0_3, sigils_p1_4, start_p2_5, pattern_p7, at_p3_1, std::optional<Text>{}, Nat(0u), after_p8)))
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    })
        : prism_rtl::more(prism_rtl::rc(Finish(l_p0, sigils_p1, start_p2, pattern_p7, at_p3, std::optional<Text>{}, Nat(0u), after_p8)));
}


/// `Start AfterPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_after_pattern(crate::syntax::lexer::Lex l_p0, Text sigils_p1, Nat start_p2, Nat at_p3, Nat end_p4, Text close_p5) {
    return prism_rtl::make_rc<AfterPattern>(l_p0, sigils_p1, start_p2, at_p3, end_p4, close_p5);
}


/// Finish: unbounded fn Lex, Text, Nat, Text, Nat, ?Text, Nat, Nat -> Lex
crate::syntax::lexer::Lex finish(const crate::syntax::lexer::Lex& l_p0, const Text& sigils_p1, const Nat& start_p2, const Text& pattern_p3, const Nat& at_p4, const std::optional<Text>& replacement_o5, const Nat& replacement_at_p6, const Nat& flags_at_p7) {
    auto src_p8 = l_p0.src;
    auto flags_end_p9 = letters_end(src_p8, flags_at_p7);
    auto lit_pa = crate::syntax::RegexLit{.pattern = pattern_p3, .pattern_at = at_p4, .replacement = replacement_o5, .replacement_at = replacement_at_p6, .flags = crate::syntax::lexer::chars::between(src_p8, flags_at_p7, flags_end_p9), .flags_at = flags_at_p7};
    auto tail_pb = ident_end(src_p8, flags_end_p9);
    auto l1_pc = ({
        crate::syntax::lexer::Lex this_ = l_p0;
        this_.pos = tail_pb;
        (std::move(this_));
    });
    auto l2_pd = tail_pb > flags_end_p9
        ? crate::syntax::lexer::chars::lex_err(l1_pc, flags_end_p9, tail_pb, prism_rtl::cat("`", crate::syntax::lexer::chars::between(src_p8, flags_end_p9, tail_pb), "` touches the flags of a regular expression: the flags are letters, and no name character follows them"))
        : l1_pc;
    return crate::syntax::lexer::push_tok(l2_pd, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KRegex{sigils_p1, lit_pa}), start_p2, flags_end_p9);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> Finish::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& sigils_p1 = this->sigils_p1;
    const auto& start_p2 = this->start_p2;
    const auto& pattern_p3 = this->pattern_p3;
    const auto& at_p4 = this->at_p4;
    const auto& replacement_o5 = this->replacement_o5;
    const auto& replacement_at_p6 = this->replacement_at_p6;
    const auto& flags_at_p7 = this->flags_at_p7;
    auto src_p8 = prism_rtl::deref(l_p0).src;
    auto flags_end_p9 = letters_end(src_p8, flags_at_p7);
    auto lit_pa = crate::syntax::RegexLit{.pattern = pattern_p3, .pattern_at = at_p4, .replacement = replacement_o5, .replacement_at = replacement_at_p6, .flags = crate::syntax::lexer::chars::between(src_p8, flags_at_p7, flags_end_p9), .flags_at = flags_at_p7};
    auto tail_pb = ident_end(src_p8, flags_end_p9);
    auto l1_pc = ({
        crate::syntax::lexer::Lex this_ = l_p0;
        this_.pos = tail_pb;
        (std::move(this_));
    });
    auto l2_pd = tail_pb > flags_end_p9
        ? crate::syntax::lexer::chars::lex_err(l1_pc, flags_end_p9, tail_pb, prism_rtl::cat("`", crate::syntax::lexer::chars::between(src_p8, flags_end_p9, tail_pb), "` touches the flags of a regular expression: the flags are letters, and no name character follows them"))
        : l1_pc;
    return prism_rtl::finished(crate::syntax::lexer::push_tok(l2_pd, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KRegex{sigils_p1, lit_pa}), start_p2, flags_end_p9));
}


/// `Start Finish, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_finish(crate::syntax::lexer::Lex l_p0, Text sigils_p1, Nat start_p2, Text pattern_p3, Nat at_p4, std::optional<Text> replacement_o5, Nat replacement_at_p6, Nat flags_at_p7) {
    return prism_rtl::make_rc<Finish>(l_p0, sigils_p1, start_p2, pattern_p3, at_p4, replacement_o5, replacement_at_p6, flags_at_p7);
}


/// Unclosed: unbounded fn Lex, Text, Nat, Text, Nat, ?Text, Text, Text -> Lex
crate::syntax::lexer::Lex unclosed(const crate::syntax::lexer::Lex& l_p0, const Text& sigils_p1, const Nat& start_p2, const Text& pattern_p3, const Nat& at_p4, const std::optional<Text>& replacement_o5, const Text& what_p6, const Text& close_p7) {
    auto end_p8 = line_end_at(l_p0.src, at_p4);
    auto lit_p9 = crate::syntax::RegexLit{.pattern = pattern_p3, .pattern_at = at_p4, .replacement = replacement_o5, .replacement_at = at_p4, .flags = Text::lit(""), .flags_at = end_p8};
    auto l1_pa = ({
        crate::syntax::lexer::Lex this_ = l_p0;
        this_.pos = end_p8;
        (std::move(this_));
    });
    auto l2_pb = crate::syntax::lexer::chars::lex_err(l1_pa, start_p2, end_p8, prism_rtl::cat("a regular expression ends on its line: close its ", what_p6, " with `", close_p7, "`"));
    return crate::syntax::lexer::push_tok(l2_pb, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KRegex{sigils_p1, lit_p9}), start_p2, end_p8);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> Unclosed::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& sigils_p1 = this->sigils_p1;
    const auto& start_p2 = this->start_p2;
    const auto& pattern_p3 = this->pattern_p3;
    const auto& at_p4 = this->at_p4;
    const auto& replacement_o5 = this->replacement_o5;
    const auto& what_p6 = this->what_p6;
    const auto& close_p7 = this->close_p7;
    auto end_p8 = line_end_at(prism_rtl::deref(l_p0).src, at_p4);
    auto lit_p9 = crate::syntax::RegexLit{.pattern = pattern_p3, .pattern_at = at_p4, .replacement = replacement_o5, .replacement_at = at_p4, .flags = Text::lit(""), .flags_at = end_p8};
    auto l1_pa = ({
        crate::syntax::lexer::Lex this_ = l_p0;
        this_.pos = end_p8;
        (std::move(this_));
    });
    auto l2_pb = crate::syntax::lexer::chars::lex_err(l1_pa, start_p2, end_p8, prism_rtl::cat("a regular expression ends on its line: close its ", what_p6, " with `", close_p7, "`"));
    return prism_rtl::finished(crate::syntax::lexer::push_tok(l2_pb, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KRegex{sigils_p1, lit_p9}), start_p2, end_p8));
}


/// `Start Unclosed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_unclosed(crate::syntax::lexer::Lex l_p0, Text sigils_p1, Nat start_p2, Text pattern_p3, Nat at_p4, std::optional<Text> replacement_o5, Text what_p6, Text close_p7) {
    return prism_rtl::make_rc<Unclosed>(l_p0, sigils_p1, start_p2, pattern_p3, at_p4, replacement_o5, what_p6, close_p7);
}


/// ?PlainEnd: fn Text, Nat -> ?Nat
std::optional<Nat> plain_end(const Text& src_p0, const Nat& at_p1) {
    auto&& _m = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("(?:[^\\/\\\\\\n]|\\\\[^\\n])*\\/", ""); return r; }()), src_p0, at_p1);
    {
        auto&& e_p2 = _m;
        if (e_p2 > at_p1) {
            return e_p2.checked_sub(Nat(1u));
        }
    }
    {
        return std::optional<Nat>{};
    }
}


/// ?HashedEnd: unbounded fn Text, Nat, Text -> ?Nat
std::optional<Nat> hashed_end(const Text& src_p0, const Nat& at_p1, const Text& close_p2) {
    auto&& _found_o7 = ({
        std::tuple<std::optional<Nat>, Nat, bool> this_ = std::tuple{std::optional<Nat>{}, at_p1, true};
        Nat i_p3 = at_p1;
        bool going_p4 = true;
        std::optional<Nat> found_o5 = std::optional<Nat>{};
        while (std::move(going_p4)) {
            auto c_p6 = crate::syntax::lexer::chars::char_at_byte(src_p0, i_p3);
            if ((c_p6 == Text::lit("")) || (c_p6 == Text::lit("\n"))) {
                going_p4 = false;
            } else if ((c_p6 == Text::lit("/")) && crate::syntax::lexer::chars::has_prefix(text_from(src_p0, i_p3), close_p2)) {
                found_o5 = std::optional(i_p3);
                going_p4 = false;
            } else  {
                i_p3 = i_p3 + len_text(c_p6);
            }
        }
        this_ = std::tuple{found_o5, i_p3, std::move(going_p4)};
        (std::move(this_));
    });
    auto&& found_o7 = std::get<0>(_found_o7);
    return found_o7;
}


prism_rtl::Turn<std::optional<Nat>> HashedEnd::cycle() const {
    const auto& src_p0 = this->src_p0;
    const auto& at_p1 = this->at_p1;
    const auto& close_p2 = this->close_p2;
    std::tuple<std::optional<Nat>, Nat, bool> this_ = std::tuple{std::optional<Nat>{}, at_p1, true};
    Nat i_p3 = at_p1;
    bool going_p4 = true;
    std::optional<Nat> found_o5 = std::optional<Nat>{};
    auto at_p1_1 = at_p1;
    return call_then(loop_job(std::tuple{std::move(found_o5), std::move(this_), std::move(going_p4), std::move(i_p3)}, ({
        auto close_p2_2 = close_p2;
        auto src_p0_3 = src_p0;
        [=, close_p2_2 = std::move(close_p2_2), src_p0_3 = std::move(src_p0_3)](std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat> _p0) {
        auto found_o5 = std::get<0>(_p0);
        auto this_ = std::get<1>(_p0);
        auto going_p4 = std::get<2>(_p0);
        auto i_p3 = std::get<3>(_p0);
        return going_p4
            ? ({
            auto c_p6 = crate::syntax::lexer::chars::char_at_byte(src_p0_3, i_p3);
            if ((c_p6 == Text::lit("")) || (c_p6 == Text::lit("\n"))) {
                going_p4 = false;
            } else if ((c_p6 == Text::lit("/")) && crate::syntax::lexer::chars::has_prefix(text_from(src_p0_3, i_p3), close_p2_2)) {
                found_o5 = std::optional(i_p3);
                going_p4 = false;
            } else  {
                i_p3 = i_p3 + len_text(c_p6);
            }
            Expected<std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat>, std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat>>(std::tuple{found_o5, this_, going_p4, i_p3});
        })
            : Expected<std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat>, std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat>>(unexpected(std::tuple{found_o5, this_, going_p4, i_p3}));
    };
    })), [=](std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat> _p0) {
        auto found_o5 = std::get<0>(_p0);
        auto this_ = std::get<1>(_p0);
        auto going_p4 = std::get<2>(_p0);
        auto i_p3 = std::get<3>(_p0);
        return ({
            this_ = std::tuple{found_o5, i_p3, going_p4};
            auto&& _found_o7 = this_;
            auto&& found_o7 = std::get<0>(_found_o7);
            (prism_rtl::finished(found_o7));
        });
    });
}


/// `Start HashedEnd, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Nat>> start_hashed_end(Text src_p0, Nat at_p1, Text close_p2) {
    return prism_rtl::make_rc<HashedEnd>(src_p0, at_p1, close_p2);
}


/// HashesEnd: fn Text, Nat -> Nat
Nat hashes_end(const Text& src_p0, const Nat& at_p1) {
    return crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("#*", ""); return r; }()), src_p0, at_p1);
}


/// LettersEnd: fn Text, Nat -> Nat
Nat letters_end(const Text& src_p0, const Nat& at_p1) {
    return crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z]*", ""); return r; }()), src_p0, at_p1);
}


/// IdentEnd: fn Text, Nat -> Nat
Nat ident_end(const Text& src_p0, const Nat& at_p1) {
    return crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_]*", ""); return r; }()), src_p0, at_p1);
}


/// LineEndAt: fn Text, Nat -> Nat
Nat line_end_at(const Text& src_p0, const Nat& at_p1) {
    return crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[^\\n]*", ""); return r; }()), src_p0, at_p1);
}


/// TextFrom: fn Text, Nat -> Text
Text text_from(const Text& src_p0, const Nat& at_p1) {
    auto&& _m = cursor_at(src_p0, at_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& c_p2 = prism_rtl::some_of(_m);
        return after(c_p2);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::syntax::lexer::regexes
