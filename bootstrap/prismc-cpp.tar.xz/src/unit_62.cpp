// The module `Reading`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Reading`, from `target/bootstrap/cpp-src/prismc/reading.prism`.
namespace crate::reading {

bool Assembled::operator==(const Assembled& o) const { return units_p == o.units_p && prelude_p == o.prelude_p && scripts_p == o.scripts_p && errors_p == o.errors_p; }

void Assembled::show(Printer& p) const {
    p.record("Assembled", {{"units", units_p}, {"prelude", prelude_p}, {"scripts", scripts_p}, {"errors", errors_p}});
}

Pod Assembled::to_pod() const {
    return Pod::record("Assembled", {{"units", prism_rtl::to_pod(units_p)}, {"prelude", prism_rtl::to_pod(prelude_p)}, {"scripts", prism_rtl::to_pod(scripts_p)}, {"errors", prism_rtl::to_pod(errors_p)}});
}

Result<Assembled> Assembled::from_pod(const Pod& whole) {
    return Assembled{.units_p = TRY(prism_rtl::from_pod<Array<ModFiles>>(TRY(crate::prelude::field(whole, "units")))), .prelude_p = TRY(prism_rtl::from_pod<Array<ModFiles>>(TRY(crate::prelude::field(whole, "prelude")))), .scripts_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "scripts")))), .errors_p = TRY(prism_rtl::from_pod<Array<TreeDiag>>(TRY(crate::prelude::field(whole, "errors"))))};
}


void CheckOpts::show(Printer& p) const {
    p.record("CheckOpts", {{"world", world_p}, {"out", out_o}, {"typed", typed_p}, {"unused", unused_p}});
}

Pod CheckOpts::to_pod() const {
    return Pod::record("CheckOpts", {{"world", prism_rtl::to_pod(world_p)}, {"out", prism_rtl::to_pod(out_o)}, {"typed", prism_rtl::to_pod(typed_p)}, {"unused", prism_rtl::to_pod(unused_p)}});
}

Result<CheckOpts> CheckOpts::from_pod(const Pod& whole) {
    return CheckOpts{.world_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "world")))), .out_o = TRY(prism_rtl::from_pod<std::optional<Text>>(TRY(crate::prelude::field(whole, "out")))), .typed_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "typed")))), .unused_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "unused"))))};
}


void CompileSettings::show(Printer& p) const {
    p.record("CompileSettings", {{"out", out_p}, {"prelude", prelude_p}, {"name", name_p}, {"runtime", runtime_p}, {"target", target_p}});
}

Pod CompileSettings::to_pod() const {
    return Pod::record("CompileSettings", {{"out", prism_rtl::to_pod(out_p)}, {"prelude", prism_rtl::to_pod(prelude_p)}, {"name", prism_rtl::to_pod(name_p)}, {"runtime", prism_rtl::to_pod(runtime_p)}, {"target", prism_rtl::to_pod(target_p)}});
}

Result<CompileSettings> CompileSettings::from_pod(const Pod& whole) {
    return CompileSettings{.out_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "out")))), .prelude_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prelude")))), .name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .runtime_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "runtime")))), .target_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "target"))))};
}


void HeadLine::show(Printer& p) const {
    p.record("HeadLine", {{"word", word_p}, {"arg", arg_p}, {"span", span_p}});
}

Pod HeadLine::to_pod() const {
    return Pod::record("HeadLine", {{"word", prism_rtl::to_pod(word_p)}, {"arg", prism_rtl::to_pod(arg_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<HeadLine> HeadLine::from_pod(const Pod& whole) {
    return HeadLine{.word_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "word")))), .arg_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "arg")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool ModFiles::operator==(const ModFiles& o) const { return name_p == o.name_p && named_p == o.named_p && segs_p == o.segs_p && parent_p == o.parent_p; }

void ModFiles::show(Printer& p) const {
    p.record("ModFiles", {{"name", name_p}, {"named", named_p}, {"segs", segs_p}, {"parent", parent_p}});
}

Pod ModFiles::to_pod() const {
    return Pod::record("ModFiles", {{"name", prism_rtl::to_pod(name_p)}, {"named", prism_rtl::to_pod(named_p)}, {"segs", prism_rtl::to_pod(segs_p)}, {"parent", prism_rtl::to_pod(parent_p)}});
}

Result<ModFiles> ModFiles::from_pod(const Pod& whole) {
    return ModFiles{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .named_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "named")))), .segs_p = TRY(prism_rtl::from_pod<Array<Seg>>(TRY(crate::prelude::field(whole, "segs")))), .parent_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "parent"))))};
}


bool ParsedProgram::operator==(const ParsedProgram& o) const { return srcs_p == o.srcs_p && trees_p == o.trees_p && shown_p == o.shown_p && parents_p == o.parents_p && errors_p == o.errors_p; }

void ParsedProgram::show(Printer& p) const {
    p.record("ParsedProgram", {{"srcs", srcs_p}, {"trees", trees_p}, {"shown", shown_p}, {"parents", parents_p}, {"errors", errors_p}});
}

Pod ParsedProgram::to_pod() const {
    return Pod::record("ParsedProgram", {{"srcs", prism_rtl::to_pod(srcs_p)}, {"trees", prism_rtl::to_pod(trees_p)}, {"shown", prism_rtl::to_pod(shown_p)}, {"parents", prism_rtl::to_pod(parents_p)}, {"errors", prism_rtl::to_pod(errors_p)}});
}

Result<ParsedProgram> ParsedProgram::from_pod(const Pod& whole) {
    return ParsedProgram{.srcs_p = TRY(prism_rtl::from_pod<Array<crate::check::errors::Src>>(TRY(crate::prelude::field(whole, "srcs")))), .trees_p = TRY(prism_rtl::from_pod<Array<crate::syntax::Module>>(TRY(crate::prelude::field(whole, "trees")))), .shown_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "shown")))), .parents_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "parents")))), .errors_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "errors"))))};
}


void ReadInput::show(Printer& p) const {
    p.record("ReadInput", {{"args", args_p}, {"prelude", prelude_p}, {"listings", listings_p}, {"paths", paths_p}, {"texts", texts_p}, {"tests", tests_p}, {"compiling", compiling_p}});
}

Pod ReadInput::to_pod() const {
    return Pod::record("ReadInput", {{"args", prism_rtl::to_pod(args_p)}, {"prelude", prism_rtl::to_pod(prelude_p)}, {"listings", prism_rtl::to_pod(listings_p)}, {"paths", prism_rtl::to_pod(paths_p)}, {"texts", prism_rtl::to_pod(texts_p)}, {"tests", prism_rtl::to_pod(tests_p)}, {"compiling", prism_rtl::to_pod(compiling_p)}});
}

Result<ReadInput> ReadInput::from_pod(const Pod& whole) {
    return ReadInput{.args_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "args")))), .prelude_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prelude")))), .listings_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Array<Text>>>>(TRY(crate::prelude::field(whole, "listings")))), .paths_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "paths")))), .texts_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "texts")))), .tests_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "tests")))), .compiling_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "compiling"))))};
}


void ReadMode::show(Printer& p) const {
    if (auto c = std::get_if<Checking>(&cases())) p.choice("Checking", {c->a0});
    else if (auto c = std::get_if<Compiling>(&cases())) p.choice("Compiling", {c->a0});
}

Pod ReadMode::to_pod() const {
    return std::holds_alternative<Checking>(cases()) ? Pod::choice("Checking", {prism_rtl::to_pod(std::get<Checking>(cases()).a0)})
        : std::holds_alternative<Compiling>(cases()) ? Pod::choice("Compiling", {prism_rtl::to_pod(std::get<Compiling>(cases()).a0)})
        : Pod();
}

Result<ReadMode> ReadMode::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "Checking" && c->args.size() == 1) return ReadMode(Checking{TRY(prism_rtl::from_pod<CheckOpts>(c->args[0]))});
        if (c->ctor == "Compiling" && c->args.size() == 1) return ReadMode(Compiling{TRY(prism_rtl::from_pod<CompileSettings>(c->args[0]))});
    }
    return mismatch<ReadMode>("a ReadMode", p);
}


void Seg::show(Printer& p) const {
    p.record("Seg", {{"path", path_p}, {"text", text_p}, {"role", role_p}});
}

Pod Seg::to_pod() const {
    return Pod::record("Seg", {{"path", prism_rtl::to_pod(path_p)}, {"text", prism_rtl::to_pod(text_p)}, {"role", prism_rtl::to_pod(role_p)}});
}

Result<Seg> Seg::from_pod(const Pod& whole) {
    return Seg{.path_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .text_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "text")))), .role_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "role"))))};
}


bool TreeAcc::operator==(const TreeAcc& o) const { return units_p == o.units_p && declared_p == o.declared_p && diags_p == o.diags_p; }

void TreeAcc::show(Printer& p) const {
    p.record("TreeAcc", {{"units", units_p}, {"declared", declared_p}, {"diags", diags_p}});
}

Pod TreeAcc::to_pod() const {
    return Pod::record("TreeAcc", {{"units", prism_rtl::to_pod(units_p)}, {"declared", prism_rtl::to_pod(declared_p)}, {"diags", prism_rtl::to_pod(diags_p)}});
}

Result<TreeAcc> TreeAcc::from_pod(const Pod& whole) {
    return TreeAcc{.units_p = TRY(prism_rtl::from_pod<Array<ModFiles>>(TRY(crate::prelude::field(whole, "units")))), .declared_p = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "declared")))), .diags_p = TRY(prism_rtl::from_pod<Array<TreeDiag>>(TRY(crate::prelude::field(whole, "diags"))))};
}


void TreeDiag::show(Printer& p) const {
    p.record("TreeDiag", {{"path", path_p}, {"span", span_p}, {"code", code_p}, {"message", message_p}, {"fix", fix_p}});
}

Pod TreeDiag::to_pod() const {
    return Pod::record("TreeDiag", {{"path", prism_rtl::to_pod(path_p)}, {"span", prism_rtl::to_pod(span_p)}, {"code", prism_rtl::to_pod(code_p)}, {"message", prism_rtl::to_pod(message_p)}, {"fix", prism_rtl::to_pod(fix_p)}});
}

Result<TreeDiag> TreeDiag::from_pod(const Pod& whole) {
    return TreeDiag{.path_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .code_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "code")))), .message_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "message")))), .fix_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "fix"))))};
}


/// IsCompiling: fn ReadMode -> Bool
bool is_compiling_f(const ReadMode& read_mode0) {
    if (prism_rtl::is<ReadMode::Compiling>(read_mode0)) {
        return true;
    }
    if (prism_rtl::is<ReadMode::Checking>(read_mode0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


// `@ReadSources` is inlined where it is applied.

// `@ReadUp` is inlined where it is applied.

// `@ReadTexts` is inlined where it is applied.

// `@ReadRun` is inlined where it is applied.

// `@RunRead` is inlined where it is applied.

// `@CheckRun` is inlined where it is applied.

// `@CompileRun` is inlined where it is applied.

/// Pairs: fn [Text], (Nat ==> [Text]) -> [((Text, [Text]))]
Array<std::tuple<Text, Array<Text>>> pairs_f(const Array<Text>& ds_p0, const Map<Nat, Array<Text>>& m_p1) {
    return crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(ds_p0)), [&](const Nat& i_p2) { return std::tuple{crate::prelude::or_(crate::prelude::index(ds_p0, i_p2), Text::lit("")), crate::prelude::or_(crate::prelude::get(m_p1, i_p2), Array<Text>{})}; });
}


/// ReadFailure: fn ?~Contents -> Text
Text read_failure_f(const std::optional<Fallible<crate::fs::Contents>>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& c_r0 = prism_rtl::some_of(opt0);
        return contents_failure_f(c_r0);
    }
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("nothing was read");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ContentsFailure: fn ~Contents -> Text
Text contents_failure_f(const Fallible<crate::fs::Contents>& arg0) {
    if (prism_rtl::is_ok(arg0)) {
        auto&& c_p0 = *arg0;
        return Text::lit("");
    }
    if (prism_rtl::is_err(arg0)) {
        auto&& c1_0 = arg0.error();
        return prism_rtl::deref(c1_0).message_p;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ContentsText: fn ~Contents -> Text
Text contents_text_f(const Fallible<crate::fs::Contents>& arg0) {
    if (prism_rtl::is_ok(arg0)) {
        auto&& c_p0 = *arg0;
        return prism_rtl::deref(c_p0).text_p;
    }
    if (prism_rtl::is_err(arg0)) {
        auto&& c1_0 = arg0.error();
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsSourcePath: fn Text -> Bool
bool is_source_path_f(const Text& f_p0) {
    return crate::syntax::lexer::chars::has_suffix_f(f_p0, Text::lit(".prism")) || crate::syntax::lexer::chars::has_suffix_f(f_p0, Text::lit(".prismtest"));
}


/// DirOf: fn Text -> Text
Text dir_of_f(const Text& p_p0) {
    return crate::syntax::lexer::chars::join_f(crate::syntax::lexer::chars::pop_f(crate::prelude::split_on(p_p0, Text::lit("/"))), Text::lit("/"));
}


/// BaseOf: fn Text -> Text
Text base_of_f(const Text& p_p0) {
    return crate::prelude::or_(crate::syntax::lexer::chars::last_o(crate::prelude::split_on(p_p0, Text::lit("/"))), p_p0);
}


/// Under: fn Text, Text -> Text
Text under_f(const Text& d_p0, const Text& n_p1) {
    return (d_p0 == Text::lit("")) || (d_p0 == Text::lit("."))
        ? n_p1
        : prism_rtl::cat(d_p0, "/", n_p1);
}


/// Ancestors: fn Text -> [Text]
Array<Text> ancestors_f(const Text& d_p0) {
    auto parts_p1 = crate::prelude::split_on(d_p0, Text::lit("/"));
    auto n_p2 = crate::prelude::len(parts_p1);
    return crate::prelude::filter(crate::prelude::each(crate::check::errors::range0_f(crate::syntax::lexer::chars::dec_f(n_p2)), [&](const Nat& i_p3) { return crate::syntax::lexer::chars::join_f(crate::prelude::take(parts_p1, crate::prelude::or_(crate::syntax::lexer::chars::dec_f(n_p2).checked_sub(i_p3), Nat(0u))), Text::lit("/")); }), [&](const Text& a_p4) { return (a_p4 != Text::lit("")) && (a_p4 != Text::lit(".")); });
}


/// DirName: fn Text -> Text
Text dir_name_f(const Text& name_p0) {
    auto&& _out_p5 = crate::syntax::lexer::chars::fold_chars_f(name_p0, std::tuple{Text::lit(""), Text::lit("")}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(std::tuple<std::tuple<Text, Text>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Text, Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::once_job([=]() {
            return ({
                auto [acc_p1, prev_p2] = p0;
                auto c_p3 = p1;
                ({
                auto sep_p4 = crate::syntax::lexer::chars::is_upper_f(c_p3) && (crate::syntax::lexer::chars::is_lower_f(prev_p2) || crate::syntax::lexer::chars::is_digit_f(prev_p2))
                    ? Text::lit("_")
                    : Text::lit("");
                (prism_rtl::finished(std::tuple{prism_rtl::cat(acc_p1, sep_p4, crate::syntax::lexer::chars::is_upper_f(c_p3)
                ? crate::prelude::lower(c_p3)
                : c_p3), c_p3}));
            });
            });
        });
    })));
    auto&& out_p5 = std::get<0>(_out_p5);
    return out_p5;
}


/// ModOfDir: fn Text -> Text
Text mod_of_dir_f(const Text& d_p0) {
    return crate::prelude::concat(crate::prelude::each(crate::prelude::split_on(d_p0, Text::lit("_")), [&](const Text& w_p1) { return prism_rtl::cat(crate::prelude::upper(crate::syntax::lexer::chars::head_f(w_p1)), crate::syntax::lexer::chars::after_first_f(w_p1)); }));
}


/// HeaderLines: fn Text -> [HeadLine]
Array<HeadLine> header_lines_f(const Text& text_p0) {
    auto&& _lines_p7 = crate::prelude::fold(crate::prelude::split_on(text_p0, Text::lit("\n")), std::tuple{Array<HeadLine>{}, Nat(0u), true}, [&](const std::tuple<Array<HeadLine>, Nat, bool>& _p0, const Text& line_p4) {
        auto&& acc_p1 = std::get<0>(_p0);
        auto&& at_p2 = std::get<1>(_p0);
        auto&& open_p3 = std::get<2>(_p0);
        return ({
            auto next_p5 = (at_p2 + crate::prelude::len_text(line_p4)) + Nat(1u);
            (!prism_rtl::deref(open_p3)
            ? std::tuple{acc_p1, next_p5, false}
            : ((crate::syntax::lexer::chars::trim_f(line_p4) == Text::lit("")) || crate::syntax::lexer::chars::has_prefix_f(line_p4, Text::lit("#"))) || crate::syntax::lexer::chars::has_prefix_f(line_p4, Text::lit(" "))
            ? std::tuple{acc_p1, next_p5, true}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<HeadLine>, Nat, bool>> _v;
            auto&& _m = head_line_of_o(line_p4, at_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& h_p6 = prism_rtl::some_of(_m);
                _v.set(std::tuple{crate::prelude::push(acc_p1, h_p6), next_p5, true});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::tuple{acc_p1, next_p5, false});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        }));
        });
    });
    auto&& lines_p7 = std::get<0>(_lines_p7);
    return lines_p7;
}


/// ?HeadLineOf: fn Text, Nat -> ?HeadLine
std::optional<HeadLine> head_line_of_o(const Text& line_p0, const Nat& at_p1) {
    auto code_p2 = crate::syntax::lexer::chars::trim_end_f(crate::prelude::or_(crate::prelude::index(crate::prelude::split_on(line_p0, Text::lit(" #")), Nat(0u)), line_p0));
    auto words_p4 = crate::prelude::filter(crate::prelude::split_on(code_p2, Text::lit(" ")), [&](const Text& w_p3) { return w_p3 != Text::lit(""); });
    auto first_p5 = crate::prelude::or_(crate::prelude::index(words_p4, Nat(0u)), Text::lit(""));
    auto second_p6 = crate::prelude::or_(crate::prelude::index(words_p4, Nat(1u)), Text::lit(""));
    auto span_p7 = crate::syntax::Range{.start_p = at_p1, .end_p = at_p1 + crate::prelude::len_text(code_p2)};
    return (first_p5 == Text::lit("test")) && (second_p6 == Text::lit("mod"))
        ? std::optional(HeadLine{.word_p = Text::lit("test mod"), .arg_p = crate::prelude::or_(crate::prelude::index(words_p4, Nat(2u)), Text::lit("")), .span_p = span_p7})
        : crate::check::types::has_text_f(Array(std::vector{Text::lit("module"), Text::lit("emit"), Text::lit("mod"), Text::lit("use")}), first_p5)
        ? std::optional(HeadLine{.word_p = first_p5, .arg_p = crate::prelude::or_(crate::syntax::lexer::chars::before_suffix_o(second_p6, Text::lit(".*")), second_p6), .span_p = span_p7})
        : std::optional<HeadLine>{};
}


/// ?FirstDeclLine: fn Text -> ?Range
std::optional<crate::syntax::Range> first_decl_line_o(const Text& text_p0) {
    auto&& _found_o5 = crate::prelude::fold(crate::prelude::split_on(text_p0, Text::lit("\n")), std::tuple{std::optional<crate::syntax::Range>{}, Nat(0u)}, [&](const std::tuple<std::optional<crate::syntax::Range>, Nat>& _p0, const Text& line_p3) {
        auto&& f_o1 = std::get<0>(_p0);
        auto&& at_p2 = std::get<1>(_p0);
        return ({
            auto next_p4 = (at_p2 + crate::prelude::len_text(line_p3)) + Nat(1u);
            ((((f_o1 != std::optional<crate::syntax::Range>{}) || (crate::syntax::lexer::chars::trim_f(line_p3) == Text::lit(""))) || crate::syntax::lexer::chars::has_prefix_f(line_p3, Text::lit("#"))) || crate::syntax::lexer::chars::has_prefix_f(line_p3, Text::lit(" "))) || (head_line_of_o(line_p3, at_p2) != std::optional<HeadLine>{})
            ? std::tuple{f_o1, next_p4}
            : std::tuple{std::optional(crate::syntax::Range{.start_p = at_p2, .end_p = at_p2 + crate::prelude::len_text(crate::syntax::lexer::chars::trim_end_f(line_p3))}), next_p4};
        });
    });
    auto&& found_o5 = std::get<0>(_found_o5);
    return found_o5;
}


/// let noAssembly
Assembled no_assembly_p() {
    return Assembled{.units_p = Array<ModFiles>{}, .prelude_p = Array<ModFiles>{}, .scripts_p = Array<Text>{}, .errors_p = Array<TreeDiag>{}};
}


/// let noSpan
crate::syntax::Range no_span_p() {
    return crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)};
}


/// AddTreeDiag: fn TreeAcc, Text, Range, Text, Text, Text -> TreeAcc
TreeAcc add_tree_diag_f(const TreeAcc& acc_p0, const Text& path_p1, const crate::syntax::Range& span_p2, const Text& code_p3, const Text& message_p4, const Text& fix_p5) {
    TreeAcc this_ = acc_p0;
    this_.diags_p = crate::prelude::push(this_.diags_p, TreeDiag{.path_p = path_p1, .span_p = span_p2, .code_p = code_p3, .message_p = message_p4, .fix_p = fix_p5});
    return this_;
}


/// IsModuleDir: fn Text, [Text] -> Bool
bool is_module_dir_f(const Text& d_p0, const Array<Text>& files_p1) {
    return (crate::check::types::has_text_f(files_p1, under_f(d_p0, Text::lit("mod.prism"))) && (!crate::check::types::has_text_f(files_p1, under_f(d_p0, Text::lit("app.prism"))))) && (!crate::check::types::has_text_f(files_p1, under_f(d_p0, Text::lit("lib.prism"))));
}


/// IsRootDir: fn Text, [Text] -> Bool
bool is_root_dir_f(const Text& d_p0, const Array<Text>& files_p1) {
    return crate::check::types::has_text_f(files_p1, under_f(d_p0, Text::lit("app.prism"))) || crate::check::types::has_text_f(files_p1, under_f(d_p0, Text::lit("lib.prism")));
}


/// ?TreeRootOf: fn Text, (Text ==> [Text]) -> ?Text
std::optional<Text> tree_root_of_o(const Text& d_p0, const Map<Text, Array<Text>>& listings_p1) {
    auto files_p2 = crate::prelude::or_(crate::prelude::get(listings_p1, d_p0), Array<Text>{});
    return is_root_dir_f(d_p0, files_p2)
        ? std::optional(d_p0)
        : is_module_dir_f(d_p0, files_p2)
        ? crate::prelude::fold(ancestors_f(d_p0), std::optional<Text>{}, [&](const std::optional<Text>& found_o3, const Text& a_p4) {
        return (found_o3 == std::optional<Text>{}) && is_root_dir_f(a_p4, crate::prelude::or_(crate::prelude::get(listings_p1, a_p4), Array<Text>{}))
            ? std::optional(a_p4)
            : found_o3;
    })
        : std::optional<Text>{};
}


/// ToRead: fn [Text], (Text ==> [Text]) -> [Text]
Array<Text> to_read_f(const Array<Text>& args_p0, const Map<Text, Array<Text>>& listings_p1) {
    return crate::prelude::fold(args_p0, Array<Text>{}, [&](const Array<Text>& acc_p2, const Text& a_p3) {
        return is_source_path_f(a_p3)
            ? crate::check::types::add_text_f(acc_p2, a_p3)
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = tree_root_of_o(a_p3, listings_p1);
            if (prism_rtl::is_some(_m)) {
                auto&& root_p4 = prism_rtl::some_of(_m);
                _v.set(crate::check::types::union_texts_f(acc_p2, crate::prelude::or_(crate::prelude::get(listings_p1, root_p4), Array<Text>{})));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc_p2);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// Assemble: unbounded fn ReadInput -> Assembled
Assembled assemble_f(const ReadInput& input_p0) {
    auto listings_p1 = crate::prelude::map(input_p0.listings_p);
    auto texts_p2 = crate::prelude::map(input_p0.texts_p);
    auto progs_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(input_p0.args_p, no_assembly_p(), ({
        auto listings_p1x = listings_p1;
        auto texts_p2x = texts_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Assembled>(std::tuple<Assembled, Text>)>>(prism_rtl::rc([=, listings_p1x = std::move(listings_p1x), texts_p2x = std::move(texts_p2x)](std::tuple<Assembled, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto listings_p1xy = listings_p1x;
            auto texts_p2xy = texts_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, listings_p1xy = std::move(listings_p1xy), texts_p2xy = std::move(texts_p2xy)]() {
            return ({
                auto acc_p7 = p0;
                auto a_p8 = p1;
                (prism_rtl::more(prism_rtl::rc(AddArg(acc_p7, listings_p1xy, texts_p2xy, a_p8))));
            });
        })));
        });
    })));
    })));
    auto pre_p4 = add_arg_f(no_assembly_p(), listings_p1, texts_p2, input_p0.prelude_p);
    auto units_p5 = crate::prelude::filter(crate::prelude::each(prism_rtl::deref(progs_p3).units_p, [&](const ModFiles& u_p9) { return kept_segs_f(u_p9, input_p0.tests_p); }), [&](const ModFiles& u_pa) { return crate::prelude::len(prism_rtl::deref(u_pa).segs_p) > Nat(0u); });
    auto kept_p6 = crate::prelude::fold(units_p5, Array<Text>{}, [&](const Array<Text>& acc_pb, const ModFiles& u_pc) { return crate::prelude::append(acc_pb, crate::prelude::each(prism_rtl::deref(u_pc).segs_p, [&](const Seg& s_pd) { return prism_rtl::deref(s_pd).path_p; })); });
    Assembled this_ = progs_p3;
    this_.units_p = units_p5;
    this_.prelude_p = crate::prelude::filter(crate::prelude::each(prism_rtl::deref(pre_p4).units_p, [&](const ModFiles& u_pe) { return kept_segs_f(u_pe, false); }), [&](const ModFiles& u_pf) { return crate::prelude::len(prism_rtl::deref(u_pf).segs_p) > Nat(0u); });
    this_.scripts_p = crate::prelude::filter(this_.scripts_p, [&](const Text& p_pg) { return crate::check::types::has_text_f(kept_p6, p_pg); });
    this_.errors_p = crate::prelude::append(this_.errors_p, prism_rtl::deref(pre_p4).errors_p);
    return this_;
}


prism_rtl::Turn<Assembled> Assemble::cycle() const {
    const auto& input_p0 = this->input_p0;
    auto listings_p1 = crate::prelude::map(prism_rtl::deref(input_p0).listings_p);
    auto texts_p2 = crate::prelude::map(prism_rtl::deref(input_p0).texts_p);
    auto input_p0x = input_p0;
    return crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(input_p0x).args_p, no_assembly_p(), ({
        auto listings_p1x = listings_p1;
        auto texts_p2x = texts_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Assembled>(std::tuple<Assembled, Text>)>>(prism_rtl::rc([=, listings_p1x = std::move(listings_p1x), texts_p2x = std::move(texts_p2x)](std::tuple<Assembled, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto listings_p1xy = listings_p1x;
            auto texts_p2xy = texts_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, listings_p1xy = std::move(listings_p1xy), texts_p2xy = std::move(texts_p2xy)]() {
            return ({
                auto acc_p7 = p0;
                auto a_p8 = p1;
                (prism_rtl::more(prism_rtl::rc(AddArg(acc_p7, listings_p1xy, texts_p2xy, a_p8))));
            });
        })));
        });
    })));
    })), [=](Assembled fold_12106) {
        return ({
            auto progs_p3 = fold_12106;
            (crate::prelude::call_then(start_add_arg_f(no_assembly_p(), listings_p1, texts_p2, prism_rtl::deref(input_p0x).prelude_p), [=, progs_p3 = std::move(progs_p3)](Assembled add_arg_f_12190) {
            return ({
                auto pre_p4 = add_arg_f_12190;
                auto units_p5 = crate::prelude::filter(crate::prelude::each(prism_rtl::deref(progs_p3).units_p, [&](const ModFiles& u_p9) { return kept_segs_f(u_p9, prism_rtl::deref(input_p0x).tests_p); }), [&](const ModFiles& u_pa) { return crate::prelude::len(prism_rtl::deref(u_pa).segs_p) > Nat(0u); });
                auto kept_p6 = crate::prelude::fold(units_p5, Array<Text>{}, [&](const Array<Text>& acc_pb, const ModFiles& u_pc) { return crate::prelude::append(acc_pb, crate::prelude::each(prism_rtl::deref(u_pc).segs_p, [&](const Seg& s_pd) { return prism_rtl::deref(s_pd).path_p; })); });
                (prism_rtl::finished(({
                Assembled this_ = progs_p3;
                this_.units_p = units_p5;
                this_.prelude_p = crate::prelude::filter(crate::prelude::each(prism_rtl::deref(pre_p4).units_p, [&](const ModFiles& u_pe) { return kept_segs_f(u_pe, false); }), [&](const ModFiles& u_pf) { return crate::prelude::len(prism_rtl::deref(u_pf).segs_p) > Nat(0u); });
                this_.scripts_p = crate::prelude::filter(this_.scripts_p, [&](const Text& p_pg) { return crate::check::types::has_text_f(kept_p6, p_pg); });
                this_.errors_p = crate::prelude::append(this_.errors_p, prism_rtl::deref(pre_p4).errors_p);
                (std::move(this_));
            })));
            });
        }));
        });
    });
}


/// `Start Assemble, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Assembled> start_assemble_f(ReadInput input_p0) {
    return prism_rtl::make_rc<Assemble>(input_p0);
}


/// KeptSegs: fn ModFiles, Bool -> ModFiles
ModFiles kept_segs_f(const ModFiles& u_p0, const bool& tests_p1) {
    ModFiles this_ = u_p0;
    this_.segs_p = crate::prelude::filter(this_.segs_p, [&](const Seg& s_p2) { return (prism_rtl::deref(s_p2).role_p != Text::lit("test")) || tests_p1; });
    return this_;
}


/// AddArg: unbounded fn Assembled, (Text ==> [Text]), (Text ==> Text), Text -> Assembled
Assembled add_arg_f(const Assembled& acc_p0, const Map<Text, Array<Text>>& listings_p1, const Map<Text, Text>& texts_p2, const Text& a_p3) {
    return crate::syntax::lexer::chars::has_suffix_f(a_p3, Text::lit(".prismtest"))
        ? ({
        Assembled this_ = acc_p0;
        this_.errors_p = crate::prelude::push(this_.errors_p, TreeDiag{.path_p = a_p3, .span_p = no_span_p(), .code_p = Text::lit("prismtest"), .message_p = prism_rtl::cat("`", a_p3, "`: a `.prismtest` is not read: a module\'s tests are in its test modules, a loose file\'s inline"), .fix_p = Text::lit("move its declarations into a test module (`test mod tests`), or into the file it tests")});
        (std::move(this_));
    })
        : crate::syntax::lexer::chars::has_suffix_f(a_p3, Text::lit(".prism"))
        ? ({
        Assembled this_ = acc_p0;
        this_.units_p = crate::prelude::push(this_.units_p, ModFiles{.name_p = Text::lit(""), .named_p = false, .segs_p = Array(std::vector{Seg{.path_p = a_p3, .text_p = crate::prelude::or_(crate::prelude::get(texts_p2, a_p3), Text::lit("")), .role_p = Text::lit("loose")}}), .parent_p = Text::lit("")});
        (std::move(this_));
    })
        : ({
        __label__ _done;
        prism_rtl::Slot<Assembled> _v;
        auto&& _m = tree_root_of_o(a_p3, listings_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& root_p4 = prism_rtl::some_of(_m);
            _v.set(({
                auto tree_p5 = walk_tree_f(root_p4, crate::prelude::or_(crate::prelude::get(listings_p1, root_p4), Array<Text>{}), texts_p2);
                auto start_p6 = under_f(a_p3, Text::lit("mod.prism"));
                auto units_p7 = root_p4 == a_p3
                    ? prism_rtl::deref(tree_p5).units_p
                    : reach_tree_f(prism_rtl::deref(tree_p5).units_p, start_p6);
                auto scripts_p8 = root_p4 == a_p3
                    ? crate::prelude::fold(units_p7, Array<Text>{}, [&](const Array<Text>& s_p9, const ModFiles& u_pa) { return crate::prelude::append(s_p9, test_paths_f(u_pa)); })
                    : crate::prelude::fold(crate::prelude::filter(units_p7, [&](const ModFiles& u_pb) { return (main_path_f(u_pb) == start_p6) || (prism_rtl::deref(u_pb).parent_p == start_p6); }), Array<Text>{}, [&](const Array<Text>& s_pc, const ModFiles& u_pd) { return crate::prelude::append(s_pc, test_paths_f(u_pd)); });
                ({
                Assembled this_ = acc_p0;
                this_.units_p = crate::prelude::append(this_.units_p, units_p7);
                this_.scripts_p = crate::prelude::append(this_.scripts_p, scripts_p8);
                this_.errors_p = crate::prelude::append(this_.errors_p, prism_rtl::deref(tree_p5).diags_p);
                (std::move(this_));
            });
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                Assembled this_ = acc_p0;
                this_.errors_p = crate::prelude::push(this_.errors_p, TreeDiag{.path_p = a_p3, .span_p = no_span_p(), .code_p = Text::lit("no-root"), .message_p = prism_rtl::cat("`", a_p3, "` holds no app.prism, lib.prism or mod.prism, and a directory argument is a tree"), .fix_p = Text::lit("give it a root, or name its files")});
                (std::move(this_));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Assembled> AddArg::cycle() const {
    const auto& acc_p0 = this->acc_p0;
    const auto& listings_p1 = this->listings_p1;
    const auto& texts_p2 = this->texts_p2;
    const auto& a_p3 = this->a_p3;
    return crate::syntax::lexer::chars::has_suffix_f(a_p3, Text::lit(".prismtest"))
        ? prism_rtl::finished(({
        Assembled this_ = acc_p0;
        this_.errors_p = crate::prelude::push(this_.errors_p, TreeDiag{.path_p = a_p3, .span_p = no_span_p(), .code_p = Text::lit("prismtest"), .message_p = prism_rtl::cat("`", a_p3, "`: a `.prismtest` is not read: a module\'s tests are in its test modules, a loose file\'s inline"), .fix_p = Text::lit("move its declarations into a test module (`test mod tests`), or into the file it tests")});
        (std::move(this_));
    }))
        : crate::syntax::lexer::chars::has_suffix_f(a_p3, Text::lit(".prism"))
        ? prism_rtl::finished(({
        Assembled this_ = acc_p0;
        this_.units_p = crate::prelude::push(this_.units_p, ModFiles{.name_p = Text::lit(""), .named_p = false, .segs_p = Array(std::vector{Seg{.path_p = a_p3, .text_p = crate::prelude::or_(crate::prelude::get(texts_p2, a_p3), Text::lit("")), .role_p = Text::lit("loose")}}), .parent_p = Text::lit("")});
        (std::move(this_));
    }))
        : ({
        auto&& _m = tree_root_of_o(a_p3, listings_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& root_p4 = prism_rtl::some_of(_m);
        ({
        auto a_p3x = a_p3;
        auto acc_p0x = acc_p0;
        auto listings_p1x = listings_p1;
        auto texts_p2x = texts_p2;
        (crate::prelude::call_then(start_walk_tree_f(root_p4, crate::prelude::or_(crate::prelude::get(listings_p1x, root_p4), Array<Text>{}), texts_p2x), [=, a_p3x = std::move(a_p3x), acc_p0x = std::move(acc_p0x)](TreeAcc walk_tree_f_13644) {
        return ({
            auto tree_p5 = walk_tree_f_13644;
            auto start_p6 = under_f(a_p3x, Text::lit("mod.prism"));
            auto units_p7 = root_p4 == a_p3x
                ? prism_rtl::deref(tree_p5).units_p
                : reach_tree_f(prism_rtl::deref(tree_p5).units_p, start_p6);
            auto scripts_p8 = root_p4 == a_p3x
                ? crate::prelude::fold(units_p7, Array<Text>{}, [&](const Array<Text>& s_p9, const ModFiles& u_pa) { return crate::prelude::append(s_p9, test_paths_f(u_pa)); })
                : crate::prelude::fold(crate::prelude::filter(units_p7, [&](const ModFiles& u_pb) { return (main_path_f(u_pb) == start_p6) || (prism_rtl::deref(u_pb).parent_p == start_p6); }), Array<Text>{}, [&](const Array<Text>& s_pc, const ModFiles& u_pd) { return crate::prelude::append(s_pc, test_paths_f(u_pd)); });
            (prism_rtl::finished(({
            Assembled this_ = acc_p0x;
            this_.units_p = crate::prelude::append(this_.units_p, units_p7);
            this_.scripts_p = crate::prelude::append(this_.scripts_p, scripts_p8);
            this_.errors_p = crate::prelude::append(this_.errors_p, prism_rtl::deref(tree_p5).diags_p);
            (std::move(this_));
        })));
        });
    }));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(({
        Assembled this_ = acc_p0;
        this_.errors_p = crate::prelude::push(this_.errors_p, TreeDiag{.path_p = a_p3, .span_p = no_span_p(), .code_p = Text::lit("no-root"), .message_p = prism_rtl::cat("`", a_p3, "` holds no app.prism, lib.prism or mod.prism, and a directory argument is a tree"), .fix_p = Text::lit("give it a root, or name its files")});
        (std::move(this_));
    }))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start AddArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Assembled> start_add_arg_f(Assembled acc_p0, Map<Text, Array<Text>> listings_p1, Map<Text, Text> texts_p2, Text a_p3) {
    return prism_rtl::make_rc<AddArg>(acc_p0, listings_p1, texts_p2, a_p3);
}


/// MainPath: fn ModFiles -> Text
Text main_path_f(const ModFiles& u_p0) {
    auto&& _m = crate::prelude::index(u_p0.segs_p, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& s_p1 = prism_rtl::some_of(_m);
        return prism_rtl::deref(s_p1).path_p;
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// MainText: fn ModFiles -> Text
Text main_text_f(const ModFiles& u_p0) {
    auto&& _m = crate::prelude::index(u_p0.segs_p, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& s_p1 = prism_rtl::some_of(_m);
        return prism_rtl::deref(s_p1).text_p;
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// TestPaths: fn ModFiles -> [Text]
Array<Text> test_paths_f(const ModFiles& u_p0) {
    return crate::prelude::each(crate::prelude::filter(u_p0.segs_p, [&](const Seg& s_p1) { return prism_rtl::deref(s_p1).role_p == Text::lit("test"); }), [&](const Seg& s_p2) { return prism_rtl::deref(s_p2).path_p; });
}


/// WalkTree: unbounded fn Text, [Text], (Text ==> Text) -> TreeAcc
TreeAcc walk_tree_f(const Text& root_p0, const Array<Text>& files_p1, const Map<Text, Text>& texts_p2) {
    auto has_p3 = crate::prelude::fold(files_p1, Map<Text, bool>{}, [&](const Map<Text, bool>& m_pa, const Text& f_pb) { return crate::prelude::insert(m_pa, f_pb, true); });
    auto app_p4 = under_f(root_p0, Text::lit("app.prism"));
    auto lib_p5 = under_f(root_p0, Text::lit("lib.prism"));
    auto acc0_p6 = TreeAcc{.units_p = Array<ModFiles>{}, .declared_p = Map<Text, bool>{}, .diags_p = Array<TreeDiag>{}};
    auto acc1_p7 = crate::check::env::has_key_f(has_p3, app_p4) && crate::check::env::has_key_f(has_p3, lib_p5)
        ? add_tree_diag_f(acc0_p6, lib_p5, no_span_p(), Text::lit("two-roots"), Text::lit("`app.prism` and `lib.prism` in one directory: a tree has one root"), Text::lit("keep app.prism for a program or lib.prism for a library"))
        : acc0_p6;
    auto acc2_p8 = crate::check::env::has_key_f(has_p3, app_p4)
        ? walk_module_f(has_p3, texts_p2, acc1_p7, app_p4, Text::lit(""), Text::lit(""), false)
        : walk_lib_f(has_p3, texts_p2, acc1_p7, lib_p5);
    auto acc3_p9 = ({
        TreeAcc this_ = acc2_p8;
        this_.declared_p = crate::prelude::insert(this_.declared_p, lib_p5, true);
        (std::move(this_));
    });
    return crate::prelude::fold(files_p1, acc3_p9, [&](const TreeAcc& a_pc, const Text& f_pd) {
        return crate::check::env::has_key_f(prism_rtl::deref(a_pc).declared_p, f_pd)
            ? a_pc
            : stray_f(has_p3, texts_p2, a_pc, f_pd);
    });
}


prism_rtl::Turn<TreeAcc> WalkTree::cycle() const {
    const auto& root_p0 = this->root_p0;
    const auto& files_p1 = this->files_p1;
    const auto& texts_p2 = this->texts_p2;
    auto has_p3 = crate::prelude::fold(files_p1, Map<Text, bool>{}, [&](const Map<Text, bool>& m_pa, const Text& f_pb) { return crate::prelude::insert(m_pa, f_pb, true); });
    auto app_p4 = under_f(root_p0, Text::lit("app.prism"));
    auto lib_p5 = under_f(root_p0, Text::lit("lib.prism"));
    auto acc0_p6 = TreeAcc{.units_p = Array<ModFiles>{}, .declared_p = Map<Text, bool>{}, .diags_p = Array<TreeDiag>{}};
    auto acc1_p7 = crate::check::env::has_key_f(has_p3, app_p4) && crate::check::env::has_key_f(has_p3, lib_p5)
        ? add_tree_diag_f(acc0_p6, lib_p5, no_span_p(), Text::lit("two-roots"), Text::lit("`app.prism` and `lib.prism` in one directory: a tree has one root"), Text::lit("keep app.prism for a program or lib.prism for a library"))
        : acc0_p6;
    auto acc2_p8 = crate::check::env::has_key_f(has_p3, app_p4)
        ? walk_module_f(has_p3, texts_p2, acc1_p7, app_p4, Text::lit(""), Text::lit(""), false)
        : walk_lib_f(has_p3, texts_p2, acc1_p7, lib_p5);
    auto acc3_p9 = ({
        TreeAcc this_ = acc2_p8;
        this_.declared_p = crate::prelude::insert(this_.declared_p, lib_p5, true);
        (std::move(this_));
    });
    return prism_rtl::finished(crate::prelude::fold(files_p1, acc3_p9, [&](const TreeAcc& a_pc, const Text& f_pd) {
        return crate::check::env::has_key_f(prism_rtl::deref(a_pc).declared_p, f_pd)
            ? a_pc
            : stray_f(has_p3, texts_p2, a_pc, f_pd);
    }));
}


/// `Start WalkTree, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TreeAcc> start_walk_tree_f(Text root_p0, Array<Text> files_p1, Map<Text, Text> texts_p2) {
    return prism_rtl::make_rc<WalkTree>(root_p0, files_p1, texts_p2);
}


/// WalkLib: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
TreeAcc walk_lib_f(const Map<Text, bool>& has_p0, const Map<Text, Text>& texts_p1, const TreeAcc& acc_p2, const Text& lib_p3) {
    auto text_p4 = crate::prelude::or_(crate::prelude::get(texts_p1, lib_p3), Text::lit(""));
    auto heads_p5 = header_lines_f(text_p4);
    auto bad_p6 = crate::prelude::filter(heads_p5, [&](const HeadLine& h_pa) { return !((prism_rtl::deref(h_pa).word_p == Text::lit("mod")) && crate::check::env::is_upper_text_f(prism_rtl::deref(h_pa).arg_p)); });
    auto acc1_p7 = crate::prelude::fold(bad_p6, acc_p2, [&](const TreeAcc& a_pb, const HeadLine& h_pc) { return add_tree_diag_f(a_pb, lib_p3, prism_rtl::deref(h_pc).span_p, Text::lit("lib-header"), prism_rtl::cat("lib.prism holds only `mod Name` lines, the library\'s modules: `", prism_rtl::deref(h_pc).word_p, "` belongs in a module"), Text::lit("move the line to a module\'s mod.prism")); });
    auto acc2_p8 = ({
        __label__ _done;
        prism_rtl::Slot<TreeAcc> _v;
        auto&& _m = first_decl_line_o(text_p4);
        if (prism_rtl::is_some(_m)) {
            auto&& r_pd = prism_rtl::some_of(_m);
            _v.set(add_tree_diag_f(acc1_p7, lib_p3, r_pd, Text::lit("lib-header"), Text::lit("lib.prism holds only `mod Name` lines, the library\'s modules"), Text::lit("move the declaration to a module")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(acc1_p7);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto dir_p9 = dir_of_f(lib_p3);
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::filter(heads_p5, [&](const HeadLine& h_pe) { return (prism_rtl::deref(h_pe).word_p == Text::lit("mod")) && crate::check::env::is_upper_text_f(prism_rtl::deref(h_pe).arg_p); }), acc2_p8, ({
        auto has_p0x = has_p0;
        auto texts_p1x = texts_p1;
        auto lib_p3x = lib_p3;
        auto dir_p9x = dir_p9;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<TreeAcc>(std::tuple<TreeAcc, HeadLine>)>>(prism_rtl::rc([=, has_p0x = std::move(has_p0x), texts_p1x = std::move(texts_p1x), lib_p3x = std::move(lib_p3x), dir_p9x = std::move(dir_p9x)](std::tuple<TreeAcc, HeadLine> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto has_p0xy = has_p0x;
            auto texts_p1xy = texts_p1x;
            auto lib_p3xy = lib_p3x;
            auto dir_p9xy = dir_p9x;
            (crate::prelude::entered(crate::prelude::once_job([=, has_p0xy = std::move(has_p0xy), texts_p1xy = std::move(texts_p1xy), lib_p3xy = std::move(lib_p3xy), dir_p9xy = std::move(dir_p9xy)]() {
            return ({
                auto a_pf = p0;
                auto h_pg = p1;
                (prism_rtl::more(prism_rtl::rc(Child(has_p0xy, texts_p1xy, a_pf, lib_p3xy, dir_p9xy, h_pg, Text::lit(""), false))));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<TreeAcc> WalkLib::cycle() const {
    const auto& has_p0 = this->has_p0;
    const auto& texts_p1 = this->texts_p1;
    const auto& acc_p2 = this->acc_p2;
    const auto& lib_p3 = this->lib_p3;
    auto text_p4 = crate::prelude::or_(crate::prelude::get(texts_p1, lib_p3), Text::lit(""));
    auto heads_p5 = header_lines_f(text_p4);
    auto bad_p6 = crate::prelude::filter(heads_p5, [&](const HeadLine& h_pa) { return !((prism_rtl::deref(h_pa).word_p == Text::lit("mod")) && crate::check::env::is_upper_text_f(prism_rtl::deref(h_pa).arg_p)); });
    auto acc1_p7 = crate::prelude::fold(bad_p6, acc_p2, [&](const TreeAcc& a_pb, const HeadLine& h_pc) { return add_tree_diag_f(a_pb, lib_p3, prism_rtl::deref(h_pc).span_p, Text::lit("lib-header"), prism_rtl::cat("lib.prism holds only `mod Name` lines, the library\'s modules: `", prism_rtl::deref(h_pc).word_p, "` belongs in a module"), Text::lit("move the line to a module\'s mod.prism")); });
    auto acc2_p8 = ({
        __label__ _done;
        prism_rtl::Slot<TreeAcc> _v;
        auto&& _m = first_decl_line_o(text_p4);
        if (prism_rtl::is_some(_m)) {
            auto&& r_pd = prism_rtl::some_of(_m);
            _v.set(add_tree_diag_f(acc1_p7, lib_p3, r_pd, Text::lit("lib-header"), Text::lit("lib.prism holds only `mod Name` lines, the library\'s modules"), Text::lit("move the declaration to a module")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(acc1_p7);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto dir_p9 = dir_of_f(lib_p3);
    return crate::prelude::fold_job(crate::prelude::filter(heads_p5, [&](const HeadLine& h_pe) { return (prism_rtl::deref(h_pe).word_p == Text::lit("mod")) && crate::check::env::is_upper_text_f(prism_rtl::deref(h_pe).arg_p); }), acc2_p8, ({
        auto has_p0x = has_p0;
        auto texts_p1x = texts_p1;
        auto lib_p3x = lib_p3;
        auto dir_p9x = dir_p9;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<TreeAcc>(std::tuple<TreeAcc, HeadLine>)>>(prism_rtl::rc([=, has_p0x = std::move(has_p0x), texts_p1x = std::move(texts_p1x), lib_p3x = std::move(lib_p3x), dir_p9x = std::move(dir_p9x)](std::tuple<TreeAcc, HeadLine> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto has_p0xy = has_p0x;
            auto texts_p1xy = texts_p1x;
            auto lib_p3xy = lib_p3x;
            auto dir_p9xy = dir_p9x;
            (crate::prelude::entered(crate::prelude::once_job([=, has_p0xy = std::move(has_p0xy), texts_p1xy = std::move(texts_p1xy), lib_p3xy = std::move(lib_p3xy), dir_p9xy = std::move(dir_p9xy)]() {
            return ({
                auto a_pf = p0;
                auto h_pg = p1;
                (prism_rtl::more(prism_rtl::rc(Child(has_p0xy, texts_p1xy, a_pf, lib_p3xy, dir_p9xy, h_pg, Text::lit(""), false))));
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start WalkLib, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TreeAcc> start_walk_lib_f(Map<Text, bool> has_p0, Map<Text, Text> texts_p1, TreeAcc acc_p2, Text lib_p3) {
    return prism_rtl::make_rc<WalkLib>(has_p0, texts_p1, acc_p2, lib_p3);
}


/// WalkModule: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, Text, Bool -> TreeAcc
TreeAcc walk_module_f(const Map<Text, bool>& has_p0, const Map<Text, Text>& texts_p1, const TreeAcc& acc_p2, const Text& main_p3, const Text& name_p4, const Text& parent_p5, const bool& in_test_p6) {
    auto dir_p7 = dir_of_f(main_p3);
    auto text_p8 = crate::prelude::or_(crate::prelude::get(texts_p1, main_p3), Text::lit(""));
    auto heads_p9 = header_lines_f(text_p8);
    auto mods_pa = crate::prelude::filter(heads_p9, [&](const HeadLine& h_pk) { return (prism_rtl::deref(h_pk).word_p == Text::lit("mod")) || (prism_rtl::deref(h_pk).word_p == Text::lit("test mod")); });
    auto subs_pb = crate::prelude::filter(mods_pa, [&](const HeadLine& h_pl) { return crate::check::env::is_upper_text_f(prism_rtl::deref(h_pl).arg_p); });
    auto lower_pc = crate::prelude::filter(mods_pa, [&](const HeadLine& h_pm) { return !crate::check::env::is_upper_text_f(prism_rtl::deref(h_pm).arg_p); });
    auto named_pd = name_p4 == Text::lit("")
        ? Text::lit("its path makes it the root")
        : prism_rtl::cat("its path names the module `", name_p4, "`");
    auto acc1_pe = crate::prelude::fold(crate::prelude::filter(heads_p9, [&](const HeadLine& h_pn) { return prism_rtl::deref(h_pn).word_p == Text::lit("module"); }), acc_p2, [&](const TreeAcc& a_po, const HeadLine& h_pp) { return add_tree_diag_f(a_po, main_p3, prism_rtl::deref(h_pp).span_p, Text::lit("module-line"), prism_rtl::cat("a module\'s file has no `module` line: ", named_pd), Text::lit("delete the line")); });
    auto leaf_pf = !crate::check::types::has_text_f(Array(std::vector{Text::lit("mod.prism"), Text::lit("app.prism"), Text::lit("lib.prism")}), base_of_f(main_p3));
    auto stem_pg = crate::prelude::or_(crate::syntax::lexer::chars::before_suffix_o(base_of_f(main_p3), Text::lit(".prism")), main_p3);
    auto acc2_ph = std::move(leaf_pf)
        ? crate::prelude::fold(mods_pa, acc1_pe, [&](const TreeAcc& a_pq, const HeadLine& h_pr) { return add_tree_diag_f(a_pq, main_p3, prism_rtl::deref(h_pr).span_p, Text::lit("mod-leaf"), prism_rtl::cat("`", base_of_f(main_p3), "` declares `", prism_rtl::deref(h_pr).word_p, " ", prism_rtl::deref(h_pr).arg_p, "`, and a module with children is a directory"), prism_rtl::cat("move ", base_of_f(main_p3), " to ", stem_pg, "/mod.prism")); })
        : acc1_pe;
    auto acc3_pi = crate::prelude::fold(lower_pc, acc2_ph, [&](const TreeAcc& a_ps, const HeadLine& h_pt) { return lowercase_f(a_ps, main_p3, dir_p7, h_pt); });
    auto acc4_pj = ({
        TreeAcc this_ = acc3_pi;
        this_.declared_p = crate::prelude::insert(this_.declared_p, main_p3, true);
        this_.units_p = crate::prelude::push(this_.units_p, ModFiles{.name_p = name_p4, .named_p = true, .segs_p = Array(std::vector{Seg{.path_p = main_p3, .text_p = text_p8, .role_p = in_test_p6 ? Text::lit("test") : Text::lit("main")}}), .parent_p = parent_p5});
        (std::move(this_));
    });
    return std::move(leaf_pf)
        ? acc4_pj
        : crate::prelude::run_to_end(crate::prelude::fold_job(subs_pb, acc4_pj, ({
        auto has_p0x = has_p0;
        auto texts_p1x = texts_p1;
        auto main_p3x = main_p3;
        auto dir_p7x = dir_p7;
        auto name_p4x = name_p4;
        auto in_test_p6x = in_test_p6;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<TreeAcc>(std::tuple<TreeAcc, HeadLine>)>>(prism_rtl::rc([=, has_p0x = std::move(has_p0x), texts_p1x = std::move(texts_p1x), main_p3x = std::move(main_p3x), dir_p7x = std::move(dir_p7x), name_p4x = std::move(name_p4x), in_test_p6x = std::move(in_test_p6x)](std::tuple<TreeAcc, HeadLine> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto has_p0xy = has_p0x;
            auto texts_p1xy = texts_p1x;
            auto main_p3xy = main_p3x;
            auto dir_p7xy = dir_p7x;
            auto name_p4xy = name_p4x;
            auto in_test_p6xy = in_test_p6x;
            (crate::prelude::entered(crate::prelude::once_job([=, has_p0xy = std::move(has_p0xy), texts_p1xy = std::move(texts_p1xy), main_p3xy = std::move(main_p3xy), dir_p7xy = std::move(dir_p7xy), name_p4xy = std::move(name_p4xy), in_test_p6xy = std::move(in_test_p6xy)]() {
            return ({
                auto a_pu = p0;
                auto h_pv = p1;
                (prism_rtl::more(prism_rtl::rc(Child(has_p0xy, texts_p1xy, a_pu, main_p3xy, dir_p7xy, h_pv, name_p4xy, in_test_p6xy))));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<TreeAcc> WalkModule::cycle() const {
    const auto& has_p0 = this->has_p0;
    const auto& texts_p1 = this->texts_p1;
    const auto& acc_p2 = this->acc_p2;
    const auto& main_p3 = this->main_p3;
    const auto& name_p4 = this->name_p4;
    const auto& parent_p5 = this->parent_p5;
    const auto& in_test_p6 = this->in_test_p6;
    auto dir_p7 = dir_of_f(main_p3);
    auto text_p8 = crate::prelude::or_(crate::prelude::get(texts_p1, main_p3), Text::lit(""));
    auto heads_p9 = header_lines_f(text_p8);
    auto mods_pa = crate::prelude::filter(heads_p9, [&](const HeadLine& h_pk) { return (prism_rtl::deref(h_pk).word_p == Text::lit("mod")) || (prism_rtl::deref(h_pk).word_p == Text::lit("test mod")); });
    auto subs_pb = crate::prelude::filter(mods_pa, [&](const HeadLine& h_pl) { return crate::check::env::is_upper_text_f(prism_rtl::deref(h_pl).arg_p); });
    auto lower_pc = crate::prelude::filter(mods_pa, [&](const HeadLine& h_pm) { return !crate::check::env::is_upper_text_f(prism_rtl::deref(h_pm).arg_p); });
    auto named_pd = name_p4 == Text::lit("")
        ? Text::lit("its path makes it the root")
        : prism_rtl::cat("its path names the module `", name_p4, "`");
    auto acc1_pe = crate::prelude::fold(crate::prelude::filter(heads_p9, [&](const HeadLine& h_pn) { return prism_rtl::deref(h_pn).word_p == Text::lit("module"); }), acc_p2, [&](const TreeAcc& a_po, const HeadLine& h_pp) { return add_tree_diag_f(a_po, main_p3, prism_rtl::deref(h_pp).span_p, Text::lit("module-line"), prism_rtl::cat("a module\'s file has no `module` line: ", named_pd), Text::lit("delete the line")); });
    auto leaf_pf = !crate::check::types::has_text_f(Array(std::vector{Text::lit("mod.prism"), Text::lit("app.prism"), Text::lit("lib.prism")}), base_of_f(main_p3));
    auto stem_pg = crate::prelude::or_(crate::syntax::lexer::chars::before_suffix_o(base_of_f(main_p3), Text::lit(".prism")), main_p3);
    auto acc2_ph = std::move(leaf_pf)
        ? crate::prelude::fold(mods_pa, acc1_pe, [&](const TreeAcc& a_pq, const HeadLine& h_pr) { return add_tree_diag_f(a_pq, main_p3, prism_rtl::deref(h_pr).span_p, Text::lit("mod-leaf"), prism_rtl::cat("`", base_of_f(main_p3), "` declares `", prism_rtl::deref(h_pr).word_p, " ", prism_rtl::deref(h_pr).arg_p, "`, and a module with children is a directory"), prism_rtl::cat("move ", base_of_f(main_p3), " to ", stem_pg, "/mod.prism")); })
        : acc1_pe;
    auto acc3_pi = crate::prelude::fold(lower_pc, acc2_ph, [&](const TreeAcc& a_ps, const HeadLine& h_pt) { return lowercase_f(a_ps, main_p3, dir_p7, h_pt); });
    auto acc4_pj = ({
        TreeAcc this_ = acc3_pi;
        this_.declared_p = crate::prelude::insert(this_.declared_p, main_p3, true);
        this_.units_p = crate::prelude::push(this_.units_p, ModFiles{.name_p = name_p4, .named_p = true, .segs_p = Array(std::vector{Seg{.path_p = main_p3, .text_p = text_p8, .role_p = prism_rtl::deref(in_test_p6) ? Text::lit("test") : Text::lit("main")}}), .parent_p = parent_p5});
        (std::move(this_));
    });
    return std::move(leaf_pf)
        ? prism_rtl::finished(acc4_pj)
        : crate::prelude::fold_job(subs_pb, acc4_pj, ({
        auto has_p0x = has_p0;
        auto texts_p1x = texts_p1;
        auto main_p3x = main_p3;
        auto dir_p7x = dir_p7;
        auto name_p4x = name_p4;
        auto in_test_p6x = prism_rtl::deref(in_test_p6);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<TreeAcc>(std::tuple<TreeAcc, HeadLine>)>>(prism_rtl::rc([=, has_p0x = std::move(has_p0x), texts_p1x = std::move(texts_p1x), main_p3x = std::move(main_p3x), dir_p7x = std::move(dir_p7x), name_p4x = std::move(name_p4x), in_test_p6x = std::move(in_test_p6x)](std::tuple<TreeAcc, HeadLine> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto has_p0xy = has_p0x;
            auto texts_p1xy = texts_p1x;
            auto main_p3xy = main_p3x;
            auto dir_p7xy = dir_p7x;
            auto name_p4xy = name_p4x;
            auto in_test_p6xy = in_test_p6x;
            (crate::prelude::entered(crate::prelude::once_job([=, has_p0xy = std::move(has_p0xy), texts_p1xy = std::move(texts_p1xy), main_p3xy = std::move(main_p3xy), dir_p7xy = std::move(dir_p7xy), name_p4xy = std::move(name_p4xy), in_test_p6xy = std::move(in_test_p6xy)]() {
            return ({
                auto a_pu = p0;
                auto h_pv = p1;
                (prism_rtl::more(prism_rtl::rc(Child(has_p0xy, texts_p1xy, a_pu, main_p3xy, dir_p7xy, h_pv, name_p4xy, in_test_p6xy))));
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start WalkModule, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TreeAcc> start_walk_module_f(Map<Text, bool> has_p0, Map<Text, Text> texts_p1, TreeAcc acc_p2, Text main_p3, Text name_p4, Text parent_p5, bool in_test_p6) {
    return prism_rtl::make_rc<WalkModule>(has_p0, texts_p1, acc_p2, main_p3, name_p4, parent_p5, in_test_p6);
}


/// Lowercase: fn TreeAcc, Text, Text, HeadLine -> TreeAcc
TreeAcc lowercase_f(const TreeAcc& a_p0, const Text& main_p1, const Text& dir_p2, const HeadLine& h_p3) {
    auto up_p4 = prism_rtl::cat(crate::prelude::upper(crate::syntax::lexer::chars::head_f(h_p3.arg_p)), crate::syntax::lexer::chars::after_first_f(h_p3.arg_p));
    auto marked_p5 = ({
        TreeAcc this_ = a_p0;
        this_.declared_p = crate::prelude::insert(this_.declared_p, under_f(dir_p2, prism_rtl::cat(h_p3.arg_p, ".prism")), true);
        (std::move(this_));
    });
    return add_tree_diag_f(marked_p5, main_p1, h_p3.span_p, Text::lit("mod-lowercase"), prism_rtl::cat("`", h_p3.word_p, " ", h_p3.arg_p, "`: a module\'s name is capitalised, and every `mod` line declares a module with a namespace of its own"), prism_rtl::cat("write `", h_p3.word_p, " ", up_p4, "` (its file ", h_p3.arg_p, ".prism, with a header of its own)"));
}


/// Child: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, HeadLine, Text, Bool -> TreeAcc
TreeAcc child_f(const Map<Text, bool>& has_p0, const Map<Text, Text>& texts_p1, const TreeAcc& acc_p2, const Text& main_p3, const Text& dir_p4, const HeadLine& h_p5, const Text& parent_p6, const bool& in_test_p7) {
    auto snake_p8 = dir_name_f(h_p5.arg_p);
    auto file_p9 = under_f(dir_p4, prism_rtl::cat(snake_p8, ".prism"));
    auto nested_pa = under_f(dir_p4, prism_rtl::cat(snake_p8, "/mod.prism"));
    auto name_pb = parent_p6 == Text::lit("")
        ? h_p5.arg_p
        : prism_rtl::cat(parent_p6, ".", h_p5.arg_p);
    auto is_test_pc = in_test_p7 || (h_p5.word_p == Text::lit("test mod"));
    auto line_pd = prism_rtl::cat(h_p5.word_p, " ", h_p5.arg_p);
    return (file_p9 == main_p3) || (nested_pa == main_p3)
        ? add_tree_diag_f(acc_p2, main_p3, h_p5.span_p, Text::lit("mod-self"), prism_rtl::cat("`", line_pd, "` names `", base_of_f(main_p3), "`, the file that declares it"), Text::lit("rename the module"))
        : crate::check::env::has_key_f(has_p0, file_p9) && crate::check::env::has_key_f(has_p0, nested_pa)
        ? ({
        auto both_pe = ({
            TreeAcc this_ = acc_p2;
            this_.declared_p = crate::prelude::insert(crate::prelude::insert(this_.declared_p, file_p9, true), nested_pa, true);
            (std::move(this_));
        });
        add_tree_diag_f(both_pe, main_p3, h_p5.span_p, Text::lit("mod-both"), prism_rtl::cat("`", line_pd, "` declares `", snake_p8, ".prism` or `", snake_p8, "/mod.prism`, and both are there"), prism_rtl::cat("keep one: ", snake_p8, "/mod.prism when the module has children, else ", snake_p8, ".prism"));
    })
        : crate::check::env::has_key_f(has_p0, file_p9)
        ? walk_module_f(has_p0, texts_p1, acc_p2, file_p9, name_pb, main_p3, is_test_pc)
        : crate::check::env::has_key_f(has_p0, nested_pa)
        ? walk_module_f(has_p0, texts_p1, acc_p2, nested_pa, name_pb, main_p3, is_test_pc)
        : add_tree_diag_f(acc_p2, main_p3, h_p5.span_p, Text::lit("mod-missing"), prism_rtl::cat("`", line_pd, "` declares `", snake_p8, ".prism` or `", snake_p8, "/mod.prism`, and neither is there"), prism_rtl::cat("create ", snake_p8, ".prism, or delete the line"));
}


prism_rtl::Turn<TreeAcc> Child::cycle() const {
    const auto& has_p0 = this->has_p0;
    const auto& texts_p1 = this->texts_p1;
    const auto& acc_p2 = this->acc_p2;
    const auto& main_p3 = this->main_p3;
    const auto& dir_p4 = this->dir_p4;
    const auto& h_p5 = this->h_p5;
    const auto& parent_p6 = this->parent_p6;
    const auto& in_test_p7 = this->in_test_p7;
    auto snake_p8 = dir_name_f(prism_rtl::deref(h_p5).arg_p);
    auto file_p9 = under_f(dir_p4, prism_rtl::cat(snake_p8, ".prism"));
    auto nested_pa = under_f(dir_p4, prism_rtl::cat(snake_p8, "/mod.prism"));
    auto name_pb = parent_p6 == Text::lit("")
        ? prism_rtl::deref(h_p5).arg_p
        : prism_rtl::cat(parent_p6, ".", prism_rtl::deref(h_p5).arg_p);
    auto is_test_pc = prism_rtl::deref(in_test_p7) || (prism_rtl::deref(h_p5).word_p == Text::lit("test mod"));
    auto line_pd = prism_rtl::cat(prism_rtl::deref(h_p5).word_p, " ", prism_rtl::deref(h_p5).arg_p);
    return (file_p9 == main_p3) || (nested_pa == main_p3)
        ? prism_rtl::finished(add_tree_diag_f(acc_p2, main_p3, prism_rtl::deref(h_p5).span_p, Text::lit("mod-self"), prism_rtl::cat("`", line_pd, "` names `", base_of_f(main_p3), "`, the file that declares it"), Text::lit("rename the module")))
        : crate::check::env::has_key_f(has_p0, file_p9) && crate::check::env::has_key_f(has_p0, nested_pa)
        ? ({
        auto both_pe = ({
            TreeAcc this_ = acc_p2;
            this_.declared_p = crate::prelude::insert(crate::prelude::insert(this_.declared_p, file_p9, true), nested_pa, true);
            (std::move(this_));
        });
        (prism_rtl::finished(add_tree_diag_f(both_pe, main_p3, prism_rtl::deref(h_p5).span_p, Text::lit("mod-both"), prism_rtl::cat("`", line_pd, "` declares `", snake_p8, ".prism` or `", snake_p8, "/mod.prism`, and both are there"), prism_rtl::cat("keep one: ", snake_p8, "/mod.prism when the module has children, else ", snake_p8, ".prism"))));
    })
        : crate::check::env::has_key_f(has_p0, file_p9)
        ? prism_rtl::more(prism_rtl::rc(WalkModule(has_p0, texts_p1, acc_p2, file_p9, name_pb, main_p3, std::move(is_test_pc))))
        : crate::check::env::has_key_f(has_p0, nested_pa)
        ? prism_rtl::more(prism_rtl::rc(WalkModule(has_p0, texts_p1, acc_p2, nested_pa, name_pb, main_p3, std::move(is_test_pc))))
        : prism_rtl::finished(add_tree_diag_f(acc_p2, main_p3, prism_rtl::deref(h_p5).span_p, Text::lit("mod-missing"), prism_rtl::cat("`", line_pd, "` declares `", snake_p8, ".prism` or `", snake_p8, "/mod.prism`, and neither is there"), prism_rtl::cat("create ", snake_p8, ".prism, or delete the line")));
}


/// `Start Child, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TreeAcc> start_child_f(Map<Text, bool> has_p0, Map<Text, Text> texts_p1, TreeAcc acc_p2, Text main_p3, Text dir_p4, HeadLine h_p5, Text parent_p6, bool in_test_p7) {
    return prism_rtl::make_rc<Child>(has_p0, texts_p1, acc_p2, main_p3, dir_p4, h_p5, parent_p6, in_test_p7);
}


/// Stray: fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
TreeAcc stray_f(const Map<Text, bool>& has_p0, const Map<Text, Text>& texts_p1, const TreeAcc& acc_p2, const Text& f_p3) {
    auto text_p4 = crate::prelude::or_(crate::prelude::get(texts_p1, f_p3), Text::lit(""));
    return crate::syntax::lexer::chars::has_suffix_f(f_p3, Text::lit(".prismtest"))
        ? add_tree_diag_f(acc_p2, f_p3, no_span_p(), Text::lit("mod-stray"), prism_rtl::cat("`", base_of_f(f_p3), "` is a test script in a tree, where tests are in test modules"), Text::lit("put its declarations in a test module, declared by `test mod Tests`"))
        : ({
        auto dir_p5 = dir_of_f(f_p3);
        auto is_main_p6 = base_of_f(f_p3) == Text::lit("mod.prism");
        auto home_p7 = std::move(is_main_p6) ? dir_of_f(dir_p5) : dir_p5;
        auto main_p8 = crate::prelude::fold(Array(std::vector{Text::lit("mod.prism"), Text::lit("app.prism"), Text::lit("lib.prism")}), Text::lit(""), [&](const Text& m_pb, const Text& n_pc) {
            return (m_pb == Text::lit("")) && crate::check::env::has_key_f(has_p0, under_f(home_p7, n_pc))
                ? n_pc
                : m_pb;
        });
        auto line_p9 = std::move(is_main_p6)
            ? prism_rtl::cat("mod ", mod_of_dir_f(base_of_f(dir_p5)))
            : prism_rtl::cat("mod ", mod_of_dir_f(crate::prelude::or_(crate::syntax::lexer::chars::before_suffix_o(base_of_f(f_p3), Text::lit(".prism")), f_p3)));
        auto shown_pa = std::move(is_main_p6)
            ? prism_rtl::cat(base_of_f(dir_p5), "/mod.prism")
            : base_of_f(f_p3);
        main_p8 == Text::lit("")
        ? add_tree_diag_f(acc_p2, f_p3, no_span_p(), Text::lit("mod-stray"), prism_rtl::cat("`", f_p3, "` is in a tree, in no module\'s directory"), Text::lit("move it into a module\'s directory and declare it with a `mod` line"))
        : add_tree_diag_f(acc_p2, f_p3, no_span_p(), Text::lit("mod-stray"), prism_rtl::cat("`", shown_pa, "` is in the directory of `", main_p8, "`, which declares no `", line_p9, "`"), prism_rtl::cat("declare it with `", line_p9, "` in ", main_p8, ", or move it out of the directory"));
    });
}


/// ReachTree: unbounded fn [ModFiles], Text -> [ModFiles]
Array<ModFiles> reach_tree_f(const Array<ModFiles>& units_p0, const Text& main_p1) {
    auto by_name_p2 = crate::prelude::fold(units_p0, Map<Text, ModFiles>{}, [&](const Map<Text, ModFiles>& m_p5, const ModFiles& u_p6) { return crate::prelude::insert(m_p5, unit_name_f(u_p6), u_p6); });
    auto start_p3 = crate::prelude::fold(units_p0, Array<Text>{}, [&](const Array<Text>& s_p7, const ModFiles& u_p8) {
        return (main_path_f(u_p8) == main_p1) || ((prism_rtl::deref(u_p8).parent_p == main_p1) && is_test_unit_f(u_p8))
            ? crate::prelude::push(s_p7, unit_name_f(u_p8))
            : s_p7;
    });
    auto reached_p4 = reach_names_f(by_name_p2, start_p3, start_p3);
    return crate::prelude::filter(units_p0, [&](const ModFiles& u_p9) { return crate::check::types::has_text_f(reached_p4, unit_name_f(u_p9)); });
}


prism_rtl::Turn<Array<ModFiles>> ReachTree::cycle() const {
    const auto& units_p0 = this->units_p0;
    const auto& main_p1 = this->main_p1;
    auto by_name_p2 = crate::prelude::fold(units_p0, Map<Text, ModFiles>{}, [&](const Map<Text, ModFiles>& m_p5, const ModFiles& u_p6) { return crate::prelude::insert(m_p5, unit_name_f(u_p6), u_p6); });
    auto start_p3 = crate::prelude::fold(units_p0, Array<Text>{}, [&](const Array<Text>& s_p7, const ModFiles& u_p8) {
        return (main_path_f(u_p8) == main_p1) || ((prism_rtl::deref(u_p8).parent_p == main_p1) && is_test_unit_f(u_p8))
            ? crate::prelude::push(s_p7, unit_name_f(u_p8))
            : s_p7;
    });
    auto units_p0x = units_p0;
    return crate::prelude::call_then(start_reach_names_f(by_name_p2, start_p3, start_p3), [=](Array<Text> reach_names_f_22458) {
        return ({
            auto reached_p4 = reach_names_f_22458;
            (prism_rtl::finished(crate::prelude::filter(units_p0x, [&](const ModFiles& u_p9) { return crate::check::types::has_text_f(reached_p4, unit_name_f(u_p9)); })));
        });
    });
}


/// `Start ReachTree, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<ModFiles>> start_reach_tree_f(Array<ModFiles> units_p0, Text main_p1) {
    return prism_rtl::make_rc<ReachTree>(units_p0, main_p1);
}


/// ReachNames: unbounded fn (Text ==> ModFiles), [Text], [Text] -> [Text]
Array<Text> reach_names_f(const Map<Text, ModFiles>& by_name_p0, const Array<Text>& seen_p1, const Array<Text>& todo_p2) {
    auto&& _m = crate::prelude::index(todo_p2, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return seen_p1;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& n_p3 = prism_rtl::some_of(_m);
        auto uses_p4 = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = crate::prelude::get(by_name_p0, n_p3);
            if (prism_rtl::is_some(_m)) {
                auto&& u_p6 = prism_rtl::some_of(_m);
                _v.set(crate::prelude::each(crate::prelude::filter(header_lines_f(main_text_f(u_p6)), [&](const HeadLine& h_p7) { return prism_rtl::deref(h_p7).word_p == Text::lit("use"); }), [&](const HeadLine& h_p8) { return use_target_f(by_name_p0, prism_rtl::deref(h_p8).arg_p); }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto fresh_p5 = crate::prelude::filter(uses_p4, [&](const Text& x_p9) { return (!crate::check::types::has_text_f(seen_p1, x_p9)) && crate::check::env::has_key_f(by_name_p0, x_p9); });
        return reach_names_f(by_name_p0, crate::check::types::union_texts_f(seen_p1, fresh_p5), crate::prelude::append(crate::prelude::drop(todo_p2, Nat(1u)), fresh_p5));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> ReachNames::cycle() const {
    const auto& by_name_p0 = this->by_name_p0;
    const auto& seen_p1 = this->seen_p1;
    const auto& todo_p2 = this->todo_p2;
    return ({
        auto&& _m = crate::prelude::index(todo_p2, Nat(0u));
        prism_rtl::is_none(_m) ? prism_rtl::finished(seen_p1)
        : prism_rtl::is_some(_m) ? ({
        auto&& n_p3 = prism_rtl::some_of(_m);
        ({
        auto uses_p4 = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = crate::prelude::get(by_name_p0, n_p3);
            if (prism_rtl::is_some(_m)) {
                auto&& u_p6 = prism_rtl::some_of(_m);
                _v.set(crate::prelude::each(crate::prelude::filter(header_lines_f(main_text_f(u_p6)), [&](const HeadLine& h_p7) { return prism_rtl::deref(h_p7).word_p == Text::lit("use"); }), [&](const HeadLine& h_p8) { return use_target_f(by_name_p0, prism_rtl::deref(h_p8).arg_p); }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto fresh_p5 = crate::prelude::filter(uses_p4, [&](const Text& x_p9) { return (!crate::check::types::has_text_f(seen_p1, x_p9)) && crate::check::env::has_key_f(by_name_p0, x_p9); });
        (prism_rtl::more(prism_rtl::rc(ReachNames(by_name_p0, crate::check::types::union_texts_f(seen_p1, fresh_p5), crate::prelude::append(crate::prelude::drop(todo_p2, Nat(1u)), fresh_p5)))));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ReachNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_reach_names_f(Map<Text, ModFiles> by_name_p0, Array<Text> seen_p1, Array<Text> todo_p2) {
    return prism_rtl::make_rc<ReachNames>(by_name_p0, seen_p1, todo_p2);
}


/// UseTarget: fn (Text ==> ModFiles), Text -> Text
Text use_target_f(const Map<Text, ModFiles>& by_name_p0, const Text& u_p1) {
    return (u_p1 == Text::lit("App")) && (!crate::check::env::has_key_f(by_name_p0, Text::lit("App")))
        ? Text::lit("")
        : u_p1;
}


/// IsTestUnit: fn ModFiles -> Bool
bool is_test_unit_f(const ModFiles& u_p0) {
    auto&& _m = crate::prelude::index(u_p0.segs_p, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& s_p1 = prism_rtl::some_of(_m);
        return prism_rtl::deref(s_p1).role_p == Text::lit("test");
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// UnitName: fn ModFiles -> Text
Text unit_name_f(const ModFiles& u_p0) {
    return u_p0.named_p
        ? u_p0.name_p
        : crate::prelude::fold(header_lines_f(main_text_f(u_p0)), Text::lit(""), [&](const Text& n_p1, const HeadLine& h_p2) {
        return prism_rtl::deref(h_p2).word_p == Text::lit("module")
            ? prism_rtl::deref(h_p2).arg_p
            : n_p1;
    });
}


/// RenderTreeDiag: fn (Text ==> Text), TreeDiag -> Text
Text render_tree_diag_f(const Map<Text, Text>& texts_p0, const TreeDiag& d_p1) {
    return crate::check::errors::render_cdiag_f(Array(std::vector{crate::check::errors::mk_src_f(d_p1.path_p, crate::prelude::or_(crate::prelude::get(texts_p0, d_p1.path_p), Text::lit("")))}), crate::check::errors::CDiag{.code_p = d_p1.code_p, .file_p = Nat(0u), .span_p = d_p1.span_p, .message_p = d_p1.message_p, .fix_p = d_p1.fix_p});
}


/// TreeReport: fn ReadInput, [TreeDiag] -> Text
Text tree_report_f(const ReadInput& input_p0, const Array<TreeDiag>& ds_p1) {
    auto texts_p2 = crate::prelude::map(input_p0.texts_p);
    auto n_p3 = crate::prelude::len(ds_p1);
    return prism_rtl::cat(crate::prelude::concat(crate::prelude::each(ds_p1, [&](const TreeDiag& d_p4) { return render_tree_diag_f(texts_p2, d_p4); })), n_p3, " error", n_p3 == Nat(1u) ? Text::lit("") : Text::lit("s"));
}


/// ParseUnit: unbounded fn ModFiles -> ((Src, Parsed))
std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed> parse_unit_f(const ModFiles& u_p0) {
    auto src_p1 = crate::check::errors::mk_joined_src_f(crate::prelude::each(u_p0.segs_p, [&](const Seg& s_p5) { return std::tuple{prism_rtl::deref(s_p5).path_p, prism_rtl::deref(s_p5).text_p, prism_rtl::deref(s_p5).role_p}; }));
    auto parsed_p2 = crate::syntax::parser::parse_file_f(prism_rtl::deref(src_p1).text_p);
    auto t0_p3 = prism_rtl::deref(parsed_p2).tree_p;
    auto tree_p4 = !u_p0.named_p
        ? t0_p3
        : ({
        crate::syntax::Module this_ = t0_p3;
        this_.name_o = u_p0.name_p == Text::lit("")
            ? std::optional<crate::syntax::QualName>{}
            : std::optional(crate::syntax::QualName{.path_p = crate::prelude::split_on(u_p0.name_p, Text::lit(".")), .span_p = no_span_p()});
        (std::move(this_));
    });
    return std::tuple{src_p1, crate::syntax::parser::Parsed{.tree_p = tree_p4, .diags_p = prism_rtl::deref(parsed_p2).diags_p}};
}


prism_rtl::Turn<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> ParseUnit::cycle() const {
    const auto& u_p0 = this->u_p0;
    auto src_p1 = crate::check::errors::mk_joined_src_f(crate::prelude::each(prism_rtl::deref(u_p0).segs_p, [&](const Seg& s_p5) { return std::tuple{prism_rtl::deref(s_p5).path_p, prism_rtl::deref(s_p5).text_p, prism_rtl::deref(s_p5).role_p}; }));
    auto u_p0x = u_p0;
    return crate::prelude::call_then(crate::syntax::parser::start_parse_file_f(prism_rtl::deref(src_p1).text_p), [=](crate::syntax::parser::Parsed parse_file_f_24471) {
        return ({
            auto parsed_p2 = parse_file_f_24471;
            auto t0_p3 = prism_rtl::deref(parsed_p2).tree_p;
            auto tree_p4 = !prism_rtl::deref(u_p0x).named_p
                ? t0_p3
                : ({
                crate::syntax::Module this_ = t0_p3;
                this_.name_o = prism_rtl::deref(u_p0x).name_p == Text::lit("")
                    ? std::optional<crate::syntax::QualName>{}
                    : std::optional(crate::syntax::QualName{.path_p = crate::prelude::split_on(prism_rtl::deref(u_p0x).name_p, Text::lit(".")), .span_p = no_span_p()});
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{src_p1, crate::syntax::parser::Parsed{.tree_p = tree_p4, .diags_p = prism_rtl::deref(parsed_p2).diags_p}}));
        });
    });
}


/// `Start ParseUnit, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> start_parse_unit_f(ModFiles u_p0) {
    return prism_rtl::make_rc<ParseUnit>(u_p0);
}


/// ParseProgram: unbounded fn Assembled -> ParsedProgram
ParsedProgram parse_program_f(const Assembled& read_p0) {
    auto parsed_p1 = crate::prelude::run_to_end(crate::prelude::each_job(read_p0.units_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>>(ModFiles)>>(prism_rtl::rc([=](ModFiles p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto u_p8 = p0;
                (prism_rtl::more(prism_rtl::rc(ParseUnit(u_p8))));
            });
        }));
    }))));
    auto user_mods_p2 = crate::prelude::fold(parsed_p1, Array<Text>{}, [&](const Array<Text>& acc_p9, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
        auto&& p_pa = std::get<1>(_p1);
        return crate::prelude::push(acc_p9, crate::check::env::mod_name_f(prism_rtl::deref(p_pa).tree_p));
    });
    auto user_fams_p3 = crate::prelude::fold(parsed_p1, Array<Text>{}, [&](const Array<Text>& acc_pb, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
        auto&& p_pc = std::get<1>(_p1);
        return crate::prelude::append(acc_pb, tag_families_f(prism_rtl::deref(p_pc).tree_p));
    });
    auto pre_parsed_p4 = crate::prelude::run_to_end(crate::prelude::each_job(read_p0.prelude_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>>(ModFiles)>>(prism_rtl::rc([=](ModFiles p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto u_pd = p0;
                (prism_rtl::more(prism_rtl::rc(ParseUnit(u_pd))));
            });
        }));
    }))));
    auto kept_p5 = crate::prelude::filter(pre_parsed_p4, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
        auto&& p_pe = std::get<1>(_p0);
        return (!crate::check::types::has_text_f(user_mods_p2, crate::check::env::mod_name_f(prism_rtl::deref(p_pe).tree_p))) && (!any_in_f(tag_families_f(prism_rtl::deref(p_pe).tree_p), user_fams_p3));
    });
    auto all_p6 = crate::prelude::append(parsed_p1, kept_p5);
    auto errors_p7 = crate::prelude::fold(all_p6, Text::lit(""), [&](const Text& acc_pf, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
        auto&& src_pg = std::get<0>(_p1);
        auto&& p_ph = std::get<1>(_p1);
        return crate::program::any_errors_f(prism_rtl::deref(p_ph).diags_p)
            ? prism_rtl::cat(acc_pf, render_parse_f(src_pg, prism_rtl::deref(p_ph).diags_p))
            : acc_pf;
    });
    return ParsedProgram{.srcs_p = crate::prelude::each(all_p6, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
        auto&& s_pi = std::get<0>(_p0);
        return s_pi;
    }), .trees_p = crate::prelude::each(all_p6, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
        auto&& p_pj = std::get<1>(_p0);
        return prism_rtl::deref(p_pj).tree_p;
    }), .shown_p = crate::prelude::len(parsed_p1), .parents_p = crate::prelude::each(read_p0.units_p, [&](const ModFiles& u_pk) { return prism_rtl::deref(u_pk).parent_p; }), .errors_p = errors_p7};
}


prism_rtl::Turn<ParsedProgram> ParseProgram::cycle() const {
    const auto& read_p0 = this->read_p0;
    auto read_p0x = read_p0;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(read_p0x).units_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>>(ModFiles)>>(prism_rtl::rc([=](ModFiles p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto u_p8 = p0;
                (prism_rtl::more(prism_rtl::rc(ParseUnit(u_p8))));
            });
        }));
    }))), [=](Array<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> each_25155) {
        return ({
            auto parsed_p1 = each_25155;
            auto user_mods_p2 = crate::prelude::fold(parsed_p1, Array<Text>{}, [&](const Array<Text>& acc_p9, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
                auto&& p_pa = std::get<1>(_p1);
                return crate::prelude::push(acc_p9, crate::check::env::mod_name_f(prism_rtl::deref(p_pa).tree_p));
            });
            auto user_fams_p3 = crate::prelude::fold(parsed_p1, Array<Text>{}, [&](const Array<Text>& acc_pb, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
                auto&& p_pc = std::get<1>(_p1);
                return crate::prelude::append(acc_pb, tag_families_f(prism_rtl::deref(p_pc).tree_p));
            });
            (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(read_p0x).prelude_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>>(ModFiles)>>(prism_rtl::rc([=](ModFiles p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto u_pd = p0;
                    (prism_rtl::more(prism_rtl::rc(ParseUnit(u_pd))));
                });
            }));
        }))), [=, parsed_p1 = std::move(parsed_p1), user_mods_p2 = std::move(user_mods_p2), user_fams_p3 = std::move(user_fams_p3)](Array<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> each_25389) {
            return ({
                auto pre_parsed_p4 = each_25389;
                auto kept_p5 = crate::prelude::filter(pre_parsed_p4, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
                    auto&& p_pe = std::get<1>(_p0);
                    return (!crate::check::types::has_text_f(user_mods_p2, crate::check::env::mod_name_f(prism_rtl::deref(p_pe).tree_p))) && (!any_in_f(tag_families_f(prism_rtl::deref(p_pe).tree_p), user_fams_p3));
                });
                auto all_p6 = crate::prelude::append(parsed_p1, kept_p5);
                auto errors_p7 = crate::prelude::fold(all_p6, Text::lit(""), [&](const Text& acc_pf, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
                    auto&& src_pg = std::get<0>(_p1);
                    auto&& p_ph = std::get<1>(_p1);
                    return crate::program::any_errors_f(prism_rtl::deref(p_ph).diags_p)
                        ? prism_rtl::cat(acc_pf, render_parse_f(src_pg, prism_rtl::deref(p_ph).diags_p))
                        : acc_pf;
                });
                (prism_rtl::finished(ParsedProgram{.srcs_p = crate::prelude::each(all_p6, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
                auto&& s_pi = std::get<0>(_p0);
                return s_pi;
            }), .trees_p = crate::prelude::each(all_p6, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
                auto&& p_pj = std::get<1>(_p0);
                return prism_rtl::deref(p_pj).tree_p;
            }), .shown_p = crate::prelude::len(parsed_p1), .parents_p = crate::prelude::each(prism_rtl::deref(read_p0x).units_p, [&](const ModFiles& u_pk) { return prism_rtl::deref(u_pk).parent_p; }), .errors_p = errors_p7}));
            });
        }));
        });
    });
}


/// `Start ParseProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<ParsedProgram> start_parse_program_f(Assembled read_p0) {
    return prism_rtl::make_rc<ParseProgram>(read_p0);
}


/// TreeDeclDiags: fn ParsedProgram -> [CDiag]
Array<crate::check::errors::CDiag> tree_decl_diags_f(const ParsedProgram& pp_p0) {
    return crate::prelude::fold(crate::check::errors::range0_f(pp_p0.shown_p), Array<crate::check::errors::CDiag>{}, [&](const Array<crate::check::errors::CDiag>& acc_p1, const Nat& i_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::errors::CDiag>> _v;
            auto&& _m = crate::prelude::index(pp_p0.srcs_p, i_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& src_p3 = prism_rtl::some_of(_m);
                _v.set(crate::prelude::fold(prism_rtl::deref(crate::prelude::or_(crate::prelude::index(pp_p0.trees_p, i_p2), crate::check::env::empty_module_p())).decls_p, acc_p1, [&](const Array<crate::check::errors::CDiag>& a_p4, const crate::syntax::decls::Decl& d_p5) { return crate::prelude::append(a_p4, decl_role_diags_f(src_p3, crate::prelude::or_(crate::prelude::index(pp_p0.parents_p, i_p2), Text::lit("")), i_p2, d_p5)); }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc_p1);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// DeclRoleDiags: fn Src, Text, Nat, Decl -> [CDiag]
Array<crate::check::errors::CDiag> decl_role_diags_f(const crate::check::errors::Src& src_p0, const Text& parent_p1, const Nat& i_p2, const crate::syntax::decls::Decl& d_p3) {
    auto seg_p4 = crate::check::errors::seg_at_f(src_p0, prism_rtl::deref(d_p3.span_p).start_p);
    auto role_p5 = prism_rtl::deref(seg_p4).role_p;
    auto main_p6 = base_of_f(src_p0.path_p);
    auto tested_p7 = (prism_rtl::deref(seg_p4).path_p == src_p0.path_p) && (parent_p1 != Text::lit(""))
        ? base_of_f(parent_p1)
        : main_p6;
    auto what_p8 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = d_p3.kind_p;
        if (prism_rtl::is<crate::syntax::decls::DeclKind::DTest>(_m)) {
            _v.set(Text::lit("test"));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::DeclKind::DCheck>(_m)) {
            _v.set(Text::lit("check"));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::DeclKind::DTag>(_m)) {
            _v.set(Text::lit("tag"));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m)) {
            _v.set(Text::lit("trait"));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::DeclKind::DImpl>(_m)) {
            _v.set(Text::lit("impl"));
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    return (role_p5 == Text::lit("main")) && ((what_p8 == Text::lit("test")) || (what_p8 == Text::lit("check")))
        ? Array(std::vector{crate::check::errors::CDiag{.code_p = Text::lit("test-outside"), .file_p = i_p2, .span_p = d_p3.span_p, .message_p = prism_rtl::cat("a `", what_p8, "` in a tree stands only in a test module"), .fix_p = prism_rtl::cat("move it to a test module: `test mod Tests` in ", main_p6, ", and tests.prism")}})
        : (role_p5 == Text::lit("test")) && (((what_p8 == Text::lit("tag")) || (what_p8 == Text::lit("trait"))) || (what_p8 == Text::lit("impl")))
        ? Array(std::vector{crate::check::errors::CDiag{.code_p = Text::lit("test-declares"), .file_p = i_p2, .span_p = d_p3.span_p, .message_p = Text::lit("a test module declares no tag, trait or impl"), .fix_p = prism_rtl::cat("declare it in ", tested_p7, ", the module the test module tests")}})
        : Array<crate::check::errors::CDiag>{};
}


/// TagFamilies: fn Module -> [Text]
Array<Text> tag_families_f(const crate::syntax::Module& m_p0) {
    return crate::prelude::fold(m_p0.decls_p, Array<Text>{}, [&](const Array<Text>& acc_p1, const crate::syntax::decls::Decl& d_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(d_p2).kind_p;
            if (prism_rtl::is<crate::syntax::decls::DeclKind::DTag>(_m)) {
                auto&& t_p3 = prism_rtl::as<crate::syntax::decls::DeclKind::DTag>(_m).a0;
                _v.set(crate::prelude::push(acc_p1, crate::syntax::lexer::chars::join_f(crate::prelude::take(prism_rtl::deref(prism_rtl::deref(t_p3).name_p).path_p, crate::syntax::lexer::chars::dec_f(crate::prelude::len(prism_rtl::deref(prism_rtl::deref(t_p3).name_p).path_p))), Text::lit("."))));
                goto _done;
            }
            {
                _v.set(acc_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// AnyIn: fn [Text], [Text] -> Bool
bool any_in_f(const Array<Text>& xs_p0, const Array<Text>& ys_p1) {
    return crate::prelude::fold(xs_p0, false, [&](const bool& seen_p2, const Text& x_p3) { return prism_rtl::deref(seen_p2) || crate::check::types::has_text_f(ys_p1, x_p3); });
}


/// RenderParse: fn Src, [Diag] -> Text
Text render_parse_f(const crate::check::errors::Src& src_p0, const Array<crate::syntax::Diag>& ds_p1) {
    return crate::prelude::concat(crate::prelude::each(crate::prelude::filter(ds_p1, [&](const crate::syntax::Diag& d_p2) { return prism_rtl::deref(d_p2).stage_p != Text::lit("out"); }), [&](const crate::syntax::Diag& d_p3) { return prism_rtl::cat(crate::check::errors::src_place_f(src_p0, prism_rtl::deref(prism_rtl::deref(d_p3).span_p).start_p), ":", crate::syntax::lexer::chars::column_of_f(src_p0.text_p, crate::prelude::or_(crate::prelude::index(src_p0.starts_p, crate::check::errors::cline_of_f(src_p0.starts_p, prism_rtl::deref(prism_rtl::deref(d_p3).span_p).start_p)), Nat(0u)), prism_rtl::deref(prism_rtl::deref(d_p3).span_p).start_p) + Nat(1u), ": ", prism_rtl::deref(d_p3).message_p, "\n"); }));
}

}  // namespace crate::reading
