// The modules `Check.Blocks.Borrows`, `Check.Blocks.Structure`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/blocks/borrows/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Blocks.Borrows`, from `target/bootstrap/cpp-src/prismc/check/blocks/borrows.prism`.
namespace crate::check::blocks::borrows {

/// InferUpdate: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_update(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& target, const crate::syntax::Block& body, const crate::syntax::Range& span) {
    auto [t, st1] = crate::check::expr::infer(env, st, target);
    auto sh = crate::check::types::head_sigil(st1, t);
    auto st2 = crate::check::expr::is_time_sigil(sh) || (sh == Text::lit("@"))
        ? crate::check::types::recording::err_fix(st1, Text::lit("time-in-update"), target.span, prism_rtl::cat("`update` over a `", crate::check::types::show_ty(st1, t), "`"), Text::lit("update the plain value, and lift the function that does it"))
        : st1;
    auto env2 = ({
        crate::check::expr::Env this_ = crate::check::blocks::structure::with_topic(env, Text::lit("&_"), t);
        this_.in_update = true;
        this_;
    });
    auto&& _st3 = update_stmts(env2, st2, body.stmts);
    auto&& st3 = std::get<1>(_st3);
    auto st4 = crate::check::passes::borrows::and_block_checks(env2, st3, body, t);
    return std::tuple{t, st4};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferUpdate::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& target = this->target;
    const auto& body = this->body;
    const auto& span = this->span;
    auto body_1 = body;
    auto env_2 = env;
    auto span_3 = span;
    auto st_4 = st;
    auto target_5 = target;
    return call_then(crate::check::expr::start_infer(env_2, st_4, target_5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_1577) {
        return ({
            auto [t, st1] = infer_1577;
            call_then(crate::check::types::start_head_sigil(st1, t), [=](Text head_sigil_1612) {
            return ({
                auto sh = head_sigil_1612;
                auto st2 = crate::check::expr::is_time_sigil(sh) || (sh == Text::lit("@"))
                    ? crate::check::types::recording::err_fix(st1, Text::lit("time-in-update"), target_5.span, prism_rtl::cat("`update` over a `", crate::check::types::show_ty(st1, t), "`"), Text::lit("update the plain value, and lift the function that does it"))
                    : st1;
                auto env2 = ({
                    crate::check::expr::Env this_ = crate::check::blocks::structure::with_topic(env_2, Text::lit("&_"), t);
                    this_.in_update = true;
                    this_;
                });
                call_then(start_update_stmts(env2, st2, body_1.stmts), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_1930) {
                return ({
                    auto&& _st3 = update_stmts_1930;
                    auto&& st3 = std::get<1>(_st3);
                    call_then(crate::check::passes::borrows::start_and_block_checks(env2, st3, body_1, t), [=](crate::check::types::St and_block_checks_1978) {
                    return ({
                        auto st4 = and_block_checks_1978;
                        (prism_rtl::finished(std::tuple{t, st4}));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start InferUpdate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_update(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr target, crate::syntax::Block body, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferUpdate>(env, st, target, body, span);
}


/// UpdateStmts: unbounded fn Env, St, [Stmt] -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::Stmt>& stmts) {
    return run_to_end(fold_job(stmts, std::tuple{env, st}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto stmt = p1;
                (prism_rtl::more(prism_rtl::rc(UpdateStmt(en, s, stmt))));
            });
        }));
    }))));
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> UpdateStmts::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& stmts = this->stmts;
    return fold_job(stmts, std::tuple{env, st}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto stmt = p1;
                (prism_rtl::more(prism_rtl::rc(UpdateStmt(en, s, stmt))));
            });
        }));
    })))->cycle();
}


/// `Start UpdateStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_update_stmts(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts) {
    return prism_rtl::make_rc<UpdateStmts>(env, st, stmts);
}


/// UpdateStmt: unbounded fn Env, St, Stmt -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmt(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
        auto&& target = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        auto [tt, st1] = crate::check::expr::infer(env, st, target);
        auto st2 = ref_target(env, st1, target);
        return std::tuple{env, crate::check::expr::check(env, st2, value, tt)};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
        auto&& target = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& op = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a1;
        auto&& value = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        auto [tt, st1] = crate::check::expr::infer(env, st, target);
        auto st2 = ref_target(env, st1, target);
        auto st3 = crate::check::expr::check(env, st2, value, tt);
        auto st4 = crate::check::expr::add_want(st3, Text::lit("Prelude.Num"), tt, s.span);
        auto st5 = op == Text::lit("-=")
            ? crate::check::expr::add_want(st4, Text::lit("Prelude.Sub"), tt, s.span)
            : st4;
        return std::tuple{env, st5};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto [t, st1] = crate::check::expr::infer(env, st, e);
        auto st2 = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            if (prism_rtl::is_some(ty_opt)) {
                auto&& ty = prism_rtl::some_of(ty_opt);
                _v.set(({
                    auto [at_, s2] = crate::check::env::reading::conv_type(crate::check::expr::env_cx(env), st1, ty);
                    (crate::check::types::unify::unify(s2, at_, t, e.span));
                }));
                goto _done;
            }
            if (prism_rtl::is_none(ty_opt)) {
                _v.set(st1);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto [env2, st3] = crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env), st2, p_, t, false);
        return std::tuple{env2, st3};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        return std::tuple{env, update_while(env, st, c, body)};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            return std::tuple{env, update_if(env, st, c, then_b, else_b_opt)};
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            return std::tuple{env, update_match(env, st, scrut, arms, e.span)};
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
            auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
            auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
            auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
            return std::tuple{env, update_for(env, st, binders_opt, source, body, e.span)};
        }
        {
            auto [t, st1] = crate::check::expr::infer(env, st, e);
            return std::tuple{env, crate::check::blocks::discarded(st1, t, e.span)};
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        auto [env1, st1] = crate::check::expr::lets::pre_bind(env, st, s);
        return crate::check::expr::lets::check_local_fn(env1, st1, f, s.span);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        return crate::check::expr::lets::pre_bind(env, st, s);
    }
    {
        return std::tuple{env, crate::check::types::recording::err(st, Text::lit("mismatch"), s.span, Text::lit("this statement belongs in a widget or `given:` block"))};
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> UpdateStmt::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& target = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        ({
        auto env_1 = env;
        auto st_2 = st;
        auto target_3 = target;
        auto value_4 = value;
        call_then(crate::check::expr::start_infer(env_1, st_2, target_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_2330) {
        return ({
            auto [tt, st1] = infer_2330;
            auto st2 = ref_target(env_1, st1, target_3);
            call_then(crate::check::expr::start_check(env_1, st2, value_4, tt), [=](crate::check::types::St check_2413) { return prism_rtl::finished(std::tuple{env_1, check_2413}); });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& target = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& op = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a1;
        auto&& value = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        ({
        auto env_1 = env;
        auto op_2 = op;
        auto s_3 = s;
        auto st_4 = st;
        auto target_5 = target;
        auto value_6 = value;
        call_then(crate::check::expr::start_infer(env_1, st_4, target_5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_2498) {
        return ({
            auto [tt, st1] = infer_2498;
            auto st2 = ref_target(env_1, st1, target_5);
            call_then(crate::check::expr::start_check(env_1, st2, value_6, tt), [=](crate::check::types::St check_2583) {
            return ({
                auto st3 = check_2583;
                auto st4 = crate::check::expr::add_want(st3, Text::lit("Prelude.Num"), tt, s_3.span);
                auto st5 = op_2 == Text::lit("-=")
                    ? crate::check::expr::add_want(st4, Text::lit("Prelude.Sub"), tt, s_3.span)
                    : st4;
                (prism_rtl::finished(std::tuple{env_1, st5}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto ty_opt_1 = ty_opt;
        auto e_2 = e;
        auto env_3 = env;
        auto p__4 = p_;
        auto st_5 = st;
        call_then(crate::check::expr::start_infer(env_3, st_5, e_2), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_2814) {
        return ({
            auto [t, st1] = infer_2814;
            auto st2 = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                if (prism_rtl::is_some(ty_opt)) {
                    auto&& ty = prism_rtl::some_of(ty_opt);
                    _v.set(({
                        auto [at_, s2] = crate::check::env::reading::conv_type(crate::check::expr::env_cx(env_3), st1, ty);
                        (crate::check::types::unify::unify(s2, at_, t, e_2.span));
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(ty_opt)) {
                    _v.set(st1);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            call_then(crate::check::expr::patterns::start_bind_pattern(crate::check::blocks::structure::unpending(env_3), st2, p__4, t, false), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_3030) {
            return ({
                auto [env2, st3] = bind_pattern_3030;
                (prism_rtl::finished(std::tuple{env2, st3}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        ({
        auto body_1 = body;
        auto c_2 = c;
        auto env_3 = env;
        auto st_4 = st;
        call_then(start_update_while(env_3, st_4, c_2, body_1), [=](crate::check::types::St update_while_3126) { return prism_rtl::finished(std::tuple{env_3, update_while_3126}); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        ({
        auto else_b_opt_1 = else_b_opt;
        auto c_2 = c;
        auto env_3 = env;
        auto st_4 = st;
        auto then_b_5 = then_b;
        call_then(start_update_if(env_3, st_4, c_2, then_b_5, else_b_opt_1), [=](crate::check::types::St update_if_3223) { return prism_rtl::finished(std::tuple{env_3, update_if_3223}); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        ({
        auto arms_1 = arms;
        auto e_2 = e;
        auto env_3 = env;
        auto scrut_4 = scrut;
        auto st_5 = st;
        call_then(start_update_match(env_3, st_5, scrut_4, arms_1, e_2.span), [=](crate::check::types::St update_match_3297) { return prism_rtl::finished(std::tuple{env_3, update_match_3297}); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        ({
        auto binders_opt_1 = binders_opt;
        auto body_2 = body;
        auto e_3 = e;
        auto env_4 = env;
        auto source_5 = source;
        auto st_6 = st;
        call_then(start_update_for(env_4, st_6, binders_opt_1, source_5, body_2, e_3.span), [=](crate::check::types::St update_for_3386) { return prism_rtl::finished(std::tuple{env_4, update_for_3386}); });
    });
    })
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto st_3 = st;
        call_then(crate::check::expr::start_infer(env_2, st_3, e_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_3487) {
        return ({
            auto [t, st1] = infer_3487;
            call_then(crate::check::blocks::start_discarded(st1, t, e_1.span), [=](crate::check::types::St discarded_3524) { return prism_rtl::finished(std::tuple{env_2, discarded_3524}); });
        });
    });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        ({
        auto env_1 = env;
        auto f_2 = f;
        auto s_3 = s;
        auto st_4 = st;
        call_then(crate::check::expr::lets::start_pre_bind(env_1, st_4, s_3), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> pre_bind_3591) {
        return ({
            auto [env1, st1] = pre_bind_3591;
            (prism_rtl::more(prism_rtl::rc(crate::check::expr::lets::CheckLocalFn(env1, st1, f_2, s_3.span))));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? prism_rtl::more(prism_rtl::rc(crate::check::expr::lets::PreBind(env, st, s)))
        : prism_rtl::finished(std::tuple{env, crate::check::types::recording::err(st, Text::lit("mismatch"), s.span, Text::lit("this statement belongs in a widget or `given:` block"))});
    });
}


/// `Start UpdateStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_update_stmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Stmt s) {
    return prism_rtl::make_rc<UpdateStmt>(env, st, s);
}


/// RefTarget: fn Env, St, Expr -> St
crate::check::types::St ref_target(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e) {
    return is_ref(e)
        ? st
        : crate::check::types::recording::err_fix(st, Text::lit("mismatch"), e.span, Text::lit("the left of `<=` is a reference: `&_`, a local `&x`, or a path from one"), prism_rtl::cat("write `&_.", crate::check::expr::src_text(env, e.span), "`, or make a local with `let &x = ...`"));
}


/// IsRef: fn Expr -> Bool
bool is_ref(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix(n.sigils, Text::lit("&"));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        return is_ref(r);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        return is_ref(r);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_ref(x);
    }
    {
        return false;
    }
}


/// UpdateIf: unbounded fn Env, St, Cond, Block, ?Block -> St
crate::check::types::St update_if(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Cond& c, const crate::syntax::Block& then_b, const std::optional<crate::syntax::Block>& else_b_opt) {
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
            auto&& e = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
            _v.set(std::tuple{env, crate::check::expr::lifting::check_cond(env, st, e)});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
            auto&& e = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
            auto&& gd_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
            _v.set(({
                auto [et, s1] = crate::check::expr::infer(env, st, e);
                auto [en, s2] = crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env), s1, p_, et, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                auto&& _m = gd_opt;
                if (prism_rtl::is_some(_m)) {
                    auto&& g = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en, crate::check::expr::lifting::check_cond(en, s2, g)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en, s2});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _st2 = update_stmts(env2, st1, then_b.stmts);
    auto&& st2 = std::get<1>(_st2);
    if (prism_rtl::is_some(else_b_opt)) {
        auto&& b = prism_rtl::some_of(else_b_opt);
        auto&& _st3 = update_stmts(env, st2, b.stmts);
        auto&& st3 = std::get<1>(_st3);
        return st3;
    }
    if (prism_rtl::is_none(else_b_opt)) {
        return st2;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> UpdateIf::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& then_b = this->then_b;
    const auto& else_b_opt = this->else_b_opt;
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
            auto&& e = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
            _v.set(std::tuple{env, crate::check::expr::lifting::check_cond(env, st, e)});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
            auto&& e = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
            auto&& gd_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
            _v.set(({
                auto [et, s1] = crate::check::expr::infer(env, st, e);
                auto [en, s2] = crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env), s1, p_, et, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                auto&& _m = gd_opt;
                if (prism_rtl::is_some(_m)) {
                    auto&& g = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en, crate::check::expr::lifting::check_cond(en, s2, g)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en, s2});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto else_b_opt_1 = else_b_opt;
    auto env_2 = env;
    auto then_b_3 = then_b;
    return call_then(start_update_stmts(env2, st1, then_b_3.stmts), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_4808) {
        return ({
            auto&& _st2 = update_stmts_4808;
            auto&& st2 = std::get<1>(_st2);
            ({
            prism_rtl::is_some(else_b_opt_1) ? ({
            auto&& b = prism_rtl::some_of(else_b_opt_1);
            ({
            auto b_4 = b;
            call_then(start_update_stmts(env_2, st2, b_4.stmts), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_4908) {
            return ({
                auto&& _st3 = update_stmts_4908;
                auto&& st3 = std::get<1>(_st3);
                (prism_rtl::finished(st3));
            });
        });
        });
        })
            : prism_rtl::is_none(else_b_opt_1) ? prism_rtl::finished(st2)
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start UpdateIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_update_if(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt) {
    return prism_rtl::make_rc<UpdateIf>(env, st, c, then_b, else_b_opt);
}


/// UpdateMatch: unbounded fn Env, St, Expr, [Arm], Range -> St
crate::check::types::St update_match(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& scrut, const Array<crate::syntax::Arm>& arms, const crate::syntax::Range& span) {
    auto [t, st1] = crate::check::expr::infer(env, st, scrut);
    auto st2 = run_to_end(fold_job(arms, st1, ({
        auto env_1 = env;
        auto t_2 = t;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_3 = env_1;
            auto t_2_3 = t_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto arm = p1;
                ({
                auto [env2, s1] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                    auto&& _m = arm.pattern;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p_ = prism_rtl::some_of(_m);
                        _v.set(crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env_1_3), s, p_, t_2_3, true));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::tuple{env_1_3, s});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto s2 = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    auto&& _m = arm.guard;
                    if (prism_rtl::is_some(_m)) {
                        auto&& gd = prism_rtl::some_of(_m);
                        _v.set(crate::check::expr::lifting::check_cond(env2, s1, gd));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s1);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_update_stmts(env2, s2, arm.body.stmts), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_5417) {
                return ({
                    auto&& _s3 = update_stmts_5417;
                    auto&& s3 = std::get<1>(_s3);
                    (prism_rtl::finished(s3));
                });
            });
            });
            });
        }));
        });
    })));
    })));
    return crate::check::passes::match_coverage(env, st2, t, arms, span);
}


prism_rtl::Turn<crate::check::types::St> UpdateMatch::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& scrut = this->scrut;
    const auto& arms = this->arms;
    const auto& span = this->span;
    auto arms_1 = arms;
    auto env_2 = env;
    auto scrut_3 = scrut;
    auto span_4 = span;
    auto st_5 = st;
    return call_then(crate::check::expr::start_infer(env_2, st_5, scrut_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_5096) {
        return ({
            auto [t, st1] = infer_5096;
            call_value(fold_job(arms_1, st1, ({
            auto env_2_6 = env_2;
            auto t_6 = t;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_2_6_7 = env_2_6;
                auto t_6_7 = t_6;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto arm = p1;
                    ({
                    auto [env2, s1] = ({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                        auto&& _m = arm.pattern;
                        if (prism_rtl::is_some(_m)) {
                            auto&& p_ = prism_rtl::some_of(_m);
                            _v.set(crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env_2_6_7), s, p_, t_6_7, true));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::tuple{env_2_6_7, s});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    auto s2 = ({
                        __label__ _done;
                        prism_rtl::Slot<crate::check::types::St> _v;
                        auto&& _m = arm.guard;
                        if (prism_rtl::is_some(_m)) {
                            auto&& gd = prism_rtl::some_of(_m);
                            _v.set(crate::check::expr::lifting::check_cond(env2, s1, gd));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(s1);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    call_then(start_update_stmts(env2, s2, arm.body.stmts), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_5417) {
                    return ({
                        auto&& _s3 = update_stmts_5417;
                        auto&& s3 = std::get<1>(_s3);
                        (prism_rtl::finished(s3));
                    });
                });
                });
                });
            }));
            });
        })));
        })), [=](crate::check::types::St fold_5131) {
            return ({
                auto st2 = fold_5131;
                (prism_rtl::more(prism_rtl::rc(crate::check::passes::MatchCoverage(env_2, st2, t, arms_1, span_4))));
            });
        });
        });
    });
}


/// `Start UpdateMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_update_match(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr scrut, Array<crate::syntax::Arm> arms, crate::syntax::Range span) {
    return prism_rtl::make_rc<UpdateMatch>(env, st, scrut, arms, span);
}


/// UpdateWhile: unbounded fn Env, St, Cond, Block -> St
crate::check::types::St update_while(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Cond& c, const crate::syntax::Block& body) {
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
            auto&& e = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
            _v.set(std::tuple{env, crate::check::expr::lifting::check_cond(env, st, e)});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
            auto&& e = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
            auto&& gd_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
            _v.set(({
                auto [et, s1] = crate::check::expr::infer(env, st, e);
                auto [en, s2] = crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env), s1, p_, et, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                auto&& _m = gd_opt;
                if (prism_rtl::is_some(_m)) {
                    auto&& g = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en, crate::check::expr::lifting::check_cond(en, s2, g)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en, s2});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _st2 = update_stmts(env2, st1, body.stmts);
    auto&& st2 = std::get<1>(_st2);
    return st2;
}


prism_rtl::Turn<crate::check::types::St> UpdateWhile::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& body = this->body;
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
            auto&& e = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
            _v.set(std::tuple{env, crate::check::expr::lifting::check_cond(env, st, e)});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
            auto&& e = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
            auto&& gd_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
            _v.set(({
                auto [et, s1] = crate::check::expr::infer(env, st, e);
                auto [en, s2] = crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env), s1, p_, et, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                auto&& _m = gd_opt;
                if (prism_rtl::is_some(_m)) {
                    auto&& g = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en, crate::check::expr::lifting::check_cond(en, s2, g)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en, s2});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto body_1 = body;
    return call_then(start_update_stmts(env2, st1, body_1.stmts), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_6052) {
        return ({
            auto&& _st2 = update_stmts_6052;
            auto&& st2 = std::get<1>(_st2);
            (prism_rtl::finished(st2));
        });
    });
}


/// `Start UpdateWhile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_update_while(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Cond c, crate::syntax::Block body) {
    return prism_rtl::make_rc<UpdateWhile>(env, st, c, body);
}


/// UpdateFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> St
crate::check::types::St update_for(const crate::check::expr::Env& env, const crate::check::types::St& st, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::syntax::Expr& source, const crate::syntax::Block& body, const crate::syntax::Range& span) {
    auto [t, st1] = crate::check::expr::infer(env, st, source);
    auto [k, v_, st2] = crate::check::blocks::structure::coll_parts(st1, t, source.span);
    auto env1 = crate::check::blocks::structure::loop_indices(env);
    auto [env2, st3] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        if (prism_rtl::is_none(binders_opt)) {
            _v.set(std::tuple{crate::check::blocks::structure::with_topic(env1, Text::lit("&_"), v_), st2});
            goto _done;
        }
        if (prism_rtl::is_some(binders_opt)) {
            auto&& bs = prism_rtl::some_of(binders_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                auto&& _m = bs.second;
                if (prism_rtl::is_some(_m)) {
                    auto&& second = prism_rtl::some_of(_m);
                    _v.set(({
                        auto [e1, s1] = crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env1), st2, bs.first, k, false);
                        (crate::check::expr::patterns::bind_pattern(e1, s1, second, v_, false));
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env1), st2, bs.first, v_, false));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _st4 = update_stmts(env2, st3, body.stmts);
    auto&& st4 = std::get<1>(_st4);
    return st4;
}


prism_rtl::Turn<crate::check::types::St> UpdateFor::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& binders_opt = this->binders_opt;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& span = this->span;
    auto binders_opt_1 = binders_opt;
    auto body_2 = body;
    auto env_3 = env;
    auto source_4 = source;
    auto span_5 = span;
    auto st_6 = st;
    return call_then(crate::check::expr::start_infer(env_3, st_6, source_4), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_6360) {
        return ({
            auto [t, st1] = infer_6360;
            call_then(crate::check::blocks::structure::start_coll_parts(st1, t, source_4.span), [=](std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St> coll_parts_6406) {
            return ({
                auto [k, v_, st2] = coll_parts_6406;
                auto env1 = crate::check::blocks::structure::loop_indices(env_3);
                auto [env2, st3] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                    if (prism_rtl::is_none(binders_opt)) {
                        _v.set(std::tuple{crate::check::blocks::structure::with_topic(env1, Text::lit("&_"), v_), st2});
                        goto _done;
                    }
                    if (prism_rtl::is_some(binders_opt)) {
                        auto&& bs = prism_rtl::some_of(binders_opt);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                            auto&& _m = bs.second;
                            if (prism_rtl::is_some(_m)) {
                                auto&& second = prism_rtl::some_of(_m);
                                _v.set(({
                                    auto [e1, s1] = crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env1), st2, bs.first, k, false);
                                    (crate::check::expr::patterns::bind_pattern(e1, s1, second, v_, false));
                                }));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env1), st2, bs.first, v_, false));
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_update_stmts(env2, st3, body_2.stmts), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_6846) {
                return ({
                    auto&& _st4 = update_stmts_6846;
                    auto&& st4 = std::get<1>(_st4);
                    (prism_rtl::finished(st4));
                });
            });
            });
        });
        });
    });
}


/// `Start UpdateFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_update_for(crate::check::expr::Env env, crate::check::types::St st, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span) {
    return prism_rtl::make_rc<UpdateFor>(env, st, binders_opt, source, body, span);
}

}  // namespace crate::check::blocks::borrows


// The module `Check.Blocks.Structure`, from `target/bootstrap/cpp-src/prismc/check/blocks/structure.prism`.
namespace crate::check::blocks::structure {

/// InferRebuild: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_rebuild(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& scrut, const crate::syntax::Block& body, const crate::syntax::Range& span) {
    auto [t, st1] = crate::check::expr::infer(env, st, scrut);
    auto [inner, st2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = crate::check::types::recording::walk(st1, t);
        if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
            auto&& m1650_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
            auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
            if (m1650_0_0 == Text::lit("$")) {
                _v.set(std::tuple{i, st1});
                goto _done;
            }
        }
        if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st1});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
            _v.set(({
                auto [v_, s2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
                std::tuple{v_, crate::check::types::unify::unify(s2, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(v_)}), t, scrut.span)};
            }));
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix(st1, Text::lit("mismatch"), scrut.span, prism_rtl::cat("`rebuild` builds over a dynamic; this is `", crate::check::types::show_ty(st1, other), "`"), Text::lit("a plain value is built once: write the block\'s lines in place"))});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto env2 = with_topic(env, Text::lit("_"), inner);
    auto [res, st3] = crate::check::blocks::infer_widget_block(env2, st2, body);
    auto&& _m = crate::check::types::recording::walk(st3, res);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m2163_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m2163_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m2163_0_0 == Text::lit("unit")) {
            if (m2163_0_1.size() == 0u) {
                return std::tuple{crate::check::types::t_unit(), st3};
            }
        }
    }
    {
        auto&& other = _m;
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(other)}), st3};
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferRebuild::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& scrut = this->scrut;
    const auto& body = this->body;
    const auto& span = this->span;
    auto body_1 = body;
    auto env_2 = env;
    auto scrut_3 = scrut;
    auto span_4 = span;
    auto st_5 = st;
    return call_then(crate::check::expr::start_infer(env_2, st_5, scrut_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_1604) {
        return ({
            auto [t, st1] = infer_1604;
            call_then(crate::check::types::recording::start_walk(st1, t), [=](crate::check::types::Ty walk_1656) {
            return ({
                auto [inner, st2] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                    if (prism_rtl::is<crate::check::types::Ty::TySig>(walk_1656)) {
                        auto&& m1650_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_1656).a0;
                        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(walk_1656).a1;
                        if (m1650_0_0 == Text::lit("$")) {
                            _v.set(std::tuple{i, st1});
                            goto _done;
                        }
                    }
                    if (prism_rtl::is<crate::check::types::Ty::TyErr>(walk_1656)) {
                        _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st1});
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_1656)) {
                        _v.set(({
                            auto [v_, s2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
                            std::tuple{v_, crate::check::types::unify::unify(s2, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(v_)}), t, scrut_3.span)};
                        }));
                        goto _done;
                    }
                    {
                        auto&& other = walk_1656;
                        _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix(st1, Text::lit("mismatch"), scrut_3.span, prism_rtl::cat("`rebuild` builds over a dynamic; this is `", crate::check::types::show_ty(st1, other), "`"), Text::lit("a plain value is built once: write the block\'s lines in place"))});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto env2 = with_topic(env_2, Text::lit("_"), inner);
                call_then(crate::check::blocks::start_infer_widget_block(env2, st2, body_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block_2126) {
                return ({
                    auto [res, st3] = infer_widget_block_2126;
                    call_then(crate::check::types::recording::start_walk(st3, res), [=](crate::check::types::Ty walk_2169) {
                    return ({
                        prism_rtl::is<crate::check::types::Ty::TyCon>(walk_2169) && ({
                        auto&& m2163_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2169).a0;
                        auto&& m2163_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2169).a1;
                        (m2163_0_0 == Text::lit("unit")) && (m2163_0_1.size() == 0u);
                    }) ? ({
                        auto&& m2163_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2169).a0;
                        auto&& m2163_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2169).a1;
                        prism_rtl::finished(std::tuple{crate::check::types::t_unit(), st3});
                    })
                        : ({
                        auto&& other = walk_2169;
                        prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(other)}), st3});
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start InferRebuild, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_rebuild(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr scrut, crate::syntax::Block body, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferRebuild>(env, st, scrut, body, span);
}


/// WithTopic: fn Env, Text, Ty -> Env
crate::check::expr::Env with_topic(const crate::check::expr::Env& env, const Text& name, const crate::check::types::Ty& t) {
    crate::check::expr::Env this_ = crate::check::expr::with_local(env, name, crate::check::types::schemes::mono(t));
    this_.pending = filter(this_.pending, [&](const Text& x) { return x != name; });
    return this_;
}


/// InferFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_for(const crate::check::expr::Env& env, const crate::check::types::St& st, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::syntax::Expr& source, const crate::syntax::Block& body, const crate::syntax::Range& span) {
    return env.in_update
        ? std::tuple{crate::check::types::t_unit(), crate::check::blocks::borrows::update_for(env, st, binders_opt, source, body, span)}
        : ({
        auto [t, st1] = crate::check::expr::infer(env, st, source);
        auto sh = crate::check::types::head_sigil(st1, t);
        auto coll = sh == Text::lit("$") ? crate::check::expr::inner_of(st1, t) : t;
        auto st2 = (sh == Text::lit("!")) || (sh == Text::lit("@"))
            ? crate::check::types::recording::err(st1, Text::lit("mismatch"), source.span, prism_rtl::cat("`for` runs over a map or an array, plain or dynamic; this is `", crate::check::types::show_ty(st1, t), "`"))
            : st1;
        auto [k, v_, st3] = coll_parts(st2, coll, source.span);
        auto live = sh == Text::lit("$");
        auto env1 = loop_indices(env);
        auto [env2, st4] = bind_for_binders(env1, st3, binders_opt, k, v_, live);
        auto [res, st5] = crate::check::blocks::infer_widget_block(env2, st4, body);
        gather(st5, res, k, live);
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferFor::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& binders_opt = this->binders_opt;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& span = this->span;
    return env.in_update
        ? ({
        auto binders_opt_1 = binders_opt;
        auto body_2 = body;
        auto env_3 = env;
        auto source_4 = source;
        auto span_5 = span;
        auto st_6 = st;
        call_then(crate::check::blocks::borrows::start_update_for(env_3, st_6, binders_opt_1, source_4, body_2, span_5), [=](crate::check::types::St update_for_2754) { return prism_rtl::finished(std::tuple{crate::check::types::t_unit(), update_for_2754}); });
    })
        : ({
        auto binders_opt_1 = binders_opt;
        auto body_2 = body;
        auto env_3 = env;
        auto source_4 = source;
        auto span_5 = span;
        auto st_6 = st;
        call_then(crate::check::expr::start_infer(env_3, st_6, source_4), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_2840) {
        return ({
            auto [t, st1] = infer_2840;
            call_then(crate::check::types::start_head_sigil(st1, t), [=](Text head_sigil_2879) {
            return ({
                auto sh = head_sigil_2879;
                auto coll = sh == Text::lit("$") ? crate::check::expr::inner_of(st1, t) : t;
                auto st2 = (sh == Text::lit("!")) || (sh == Text::lit("@"))
                    ? crate::check::types::recording::err(st1, Text::lit("mismatch"), source_4.span, prism_rtl::cat("`for` runs over a map or an array, plain or dynamic; this is `", crate::check::types::show_ty(st1, t), "`"))
                    : st1;
                call_then(start_coll_parts(st2, coll, source_4.span), [=](std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St> coll_parts_3150) {
                return ({
                    auto [k, v_, st3] = coll_parts_3150;
                    auto live = sh == Text::lit("$");
                    auto env1 = loop_indices(env_3);
                    call_then(start_bind_for_binders(env1, st3, binders_opt_1, k, v_, live), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_for_binders_3275) {
                    return ({
                        auto [env2, st4] = bind_for_binders_3275;
                        call_then(crate::check::blocks::start_infer_widget_block(env2, st4, body_2), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block_3349) {
                        return ({
                            auto [res, st5] = infer_widget_block_3349;
                            (prism_rtl::more(prism_rtl::rc(Gather(st5, res, k, live))));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
    });
}


/// `Start InferFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_for(crate::check::expr::Env env, crate::check::types::St st, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferFor>(env, st, binders_opt, source, body, span);
}


/// CollParts: unbounded fn St, Ty, Range -> ((Ty, Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St> coll_parts(const crate::check::types::St& st, const crate::check::types::Ty& t, const crate::syntax::Range& span) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return std::tuple{k, v_, st};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        return std::tuple{crate::check::types::t_nat(), v_, st};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m3542_2_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m3542_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m3542_2_0 == Text::lit("Buffer")) {
            if (m3542_2_1.size() == 1u) {
                {
                    auto&& _c1 = index(m3542_2_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& v_ = prism_rtl::some_of(_c1);
                        return std::tuple{crate::check::types::t_nat(), v_, st};
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        return std::tuple{crate::check::types::t_nat(), v_, crate::check::types::unify::unify(st2, crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_)}), t, span)};
    }
    {
        auto&& other = _m;
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`for` runs over a map or an array; this is `", crate::check::types::show_ty(st, other), "`"))};
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St>> CollParts::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& span = this->span;
    auto span_1 = span;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(crate::check::types::recording::start_walk(st_2, t_3), [=](crate::check::types::Ty walk_3548) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyMap>(walk_3548) ? ({
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_3548).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_3548).a1;
            prism_rtl::finished(std::tuple{k, v_, st_2});
        })
            : prism_rtl::is<crate::check::types::Ty::TyArray>(walk_3548) ? ({
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(walk_3548).a0;
            prism_rtl::finished(std::tuple{crate::check::types::t_nat(), v_, st_2});
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_3548) && ({
            auto&& m3542_2_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_3548).a0;
            auto&& m3542_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_3548).a1;
            (m3542_2_0 == Text::lit("Buffer")) && (m3542_2_1.size() == 1u) && ({
            auto&& _c1 = index(m3542_2_1, Nat(0u));
            prism_rtl::is_some(_c1);
        });
        }) ? ({
            auto&& m3542_2_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_3548).a0;
            auto&& m3542_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_3548).a1;
            auto&& _c1 = index(m3542_2_1, Nat(0u));
            auto&& v_ = prism_rtl::some_of(_c1);
            prism_rtl::finished(std::tuple{crate::check::types::t_nat(), v_, st_2});
        })
            : prism_rtl::is<crate::check::types::Ty::TyErr>(walk_3548) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st_2})
            : prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_3548) ? ({
            auto [v_, st2] = crate::check::types::fresh_var(st_2, false, Text::lit(""));
            call_then(crate::check::types::unify::start_unify(st2, crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_)}), t_3, span_1), [=](crate::check::types::St unify_3782) { return prism_rtl::finished(std::tuple{crate::check::types::t_nat(), v_, unify_3782}); });
        })
            : ({
            auto&& other = walk_3548;
            ({
            auto other_4 = other;
            call_then(crate::check::types::start_show_ty(st_2, other_4), [=](Text show_ty_3917) { return prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_2, Text::lit("mismatch"), span_1, prism_rtl::cat("`for` runs over a map or an array; this is `", show_ty_3917, "`"))}); });
        });
        });
        });
    });
}


/// `Start CollParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St>> start_coll_parts(crate::check::types::St st, crate::check::types::Ty t, crate::syntax::Range span) {
    return prism_rtl::make_rc<CollParts>(st, t, span);
}


/// LoopIndices: fn Env -> Env
crate::check::expr::Env loop_indices(const crate::check::expr::Env& env) {
    auto outer1_opt = crate::prelude::get(env.locals, Text::lit("ix"));
    auto outer2_opt = crate::prelude::get(env.locals, Text::lit("jx"));
    auto e1 = crate::check::expr::with_local(env, Text::lit("ix"), crate::check::types::schemes::mono(crate::check::types::t_nat()));
    auto e2 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::expr::Env> _v;
        if (prism_rtl::is_some(outer1_opt)) {
            auto&& sc = prism_rtl::some_of(outer1_opt);
            _v.set(crate::check::expr::with_local(e1, Text::lit("jx"), sc));
            goto _done;
        }
        if (prism_rtl::is_none(outer1_opt)) {
            _v.set(e1);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is_some(outer2_opt)) {
        auto&& sc = prism_rtl::some_of(outer2_opt);
        return crate::check::expr::with_local(e2, Text::lit("kx"), sc);
    }
    if (prism_rtl::is_none(outer2_opt)) {
        return e2;
    }
    prism_rtl::unreachable("no arm matched");
}


/// BindForBinders: unbounded fn Env, St, ?ForBinders, Ty, Ty, Bool -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_for_binders(const crate::check::expr::Env& env, const crate::check::types::St& st, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::check::types::Ty& k, const crate::check::types::Ty& v_, const bool& live) {
    auto vt = live
        ? crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(v_)})
        : v_;
    if (prism_rtl::is_none(binders_opt)) {
        auto e1 = with_topic(env, live ? Text::lit("$_") : Text::lit("_"), vt);
        return std::tuple{with_topic(e1, Text::lit("key"), k), st};
    }
    if (prism_rtl::is_some(binders_opt)) {
        auto&& bs = prism_rtl::some_of(binders_opt);
        auto&& _m = bs.second;
        if (prism_rtl::is_some(_m)) {
            auto&& second = prism_rtl::some_of(_m);
            auto [e1, st1] = crate::check::expr::patterns::bind_pattern(unpending(env), st, bs.first, k, false);
            return crate::check::expr::patterns::bind_pattern(e1, st1, second, vt, false);
        }
        if (prism_rtl::is_none(_m)) {
            auto e1 = with_topic(env, Text::lit("key"), k);
            return crate::check::expr::patterns::bind_pattern(unpending(e1), st, bs.first, vt, false);
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindForBinders::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& binders_opt = this->binders_opt;
    const auto& k = this->k;
    const auto& v_ = this->v_;
    const auto& live = this->live;
    auto vt = live
        ? crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(v_)})
        : v_;
    return ({
        prism_rtl::is_none(binders_opt) ? ({
        auto e1 = with_topic(env, live ? Text::lit("$_") : Text::lit("_"), vt);
        (prism_rtl::finished(std::tuple{with_topic(e1, Text::lit("key"), k), st}));
    })
        : prism_rtl::is_some(binders_opt) ? ({
        auto&& bs = prism_rtl::some_of(binders_opt);
        ({
        auto&& _m = bs.second;
        prism_rtl::is_some(_m) ? ({
        auto&& second = prism_rtl::some_of(_m);
        ({
        auto bs_1 = bs;
        auto env_2 = env;
        auto k_3 = k;
        auto second_4 = second;
        auto st_5 = st;
        call_then(crate::check::expr::patterns::start_bind_pattern(unpending(env_2), st_5, bs_1.first, k_3, false), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_4913) {
        return ({
            auto [e1, st1] = bind_pattern_4913;
            (prism_rtl::more(prism_rtl::rc(crate::check::expr::patterns::BindPattern(e1, st1, second_4, vt, false))));
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto e1 = with_topic(env, Text::lit("key"), k);
        (prism_rtl::more(prism_rtl::rc(crate::check::expr::patterns::BindPattern(unpending(e1), st, bs.first, vt, false))));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindForBinders, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_for_binders(crate::check::expr::Env env, crate::check::types::St st, std::optional<crate::syntax::ForBinders> binders_opt, crate::check::types::Ty k, crate::check::types::Ty v_, bool live) {
    return prism_rtl::make_rc<BindForBinders>(env, st, binders_opt, k, v_, live);
}


/// Unpending: fn Env -> Env
crate::check::expr::Env unpending(const crate::check::expr::Env& env) {
    crate::check::expr::Env this_ = env;
    this_.pending = Array<Text>{};
    return this_;
}


/// Gather: unbounded fn St, Ty, Ty, Bool -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> gather(const crate::check::types::St& st, const crate::check::types::Ty& res, const crate::check::types::Ty& k, const bool& live) {
    auto&& _m = crate::check::types::recording::walk(st, res);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m5579_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m5579_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m5579_0_0 == Text::lit("unit")) {
            if (m5579_0_1.size() == 0u) {
                return std::tuple{crate::check::types::t_unit(), st};
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& m5579_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& t = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (m5579_1_0 == Text::lit("!")) {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(t)}))}), st};
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& m5579_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& t = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (m5579_2_0 == Text::lit("$")) {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(t)}))}), st};
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return run_to_end(fold_job(ts, false, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto x = p1;
                    (prism_rtl::finished(seen || crate::check::expr::is_time_sigil(crate::check::types::head_sigil(st_1_2, x))));
                });
            }));
            });
        })));
        })))
            ? ({
            auto [parts, st2] = run_to_end(fold_job(ts, std::tuple{Array<crate::check::types::Ty>{}, st}, ({
                auto k_1 = k;
                auto live_2 = live;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto k_1_3 = k_1;
                    auto live_2_3 = live_2;
                    entered(once_job([=]() {
                    return ({
                        auto [acc, s] = p0;
                        auto x = p1;
                        call_then(start_gather(s, x, k_1_3, live_2_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> gather_5939) {
                        return ({
                            auto [g, s2] = gather_5939;
                            (prism_rtl::finished(std::tuple{crate::prelude::push(acc, g), s2}));
                        });
                    });
                    });
                }));
                });
            }));
            })));
            std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyTuple{parts}), st2};
        })
            : std::tuple{live_map(live, k, crate::check::types::Ty(crate::check::types::Ty::TyTuple{ts})), st};
    }
    {
        auto&& other = _m;
        return std::tuple{live_map(live, k, other), st};
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> Gather::cycle() const {
    const auto& st = this->st;
    const auto& res = this->res;
    const auto& k = this->k;
    const auto& live = this->live;
    auto k_1 = k;
    auto live_2 = live;
    auto res_3 = res;
    auto st_4 = st;
    return call_then(crate::check::types::recording::start_walk(st_4, res_3), [=](crate::check::types::Ty walk_5585) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_5585) && ({
            auto&& m5579_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_5585).a0;
            auto&& m5579_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_5585).a1;
            (m5579_0_0 == Text::lit("unit")) && (m5579_0_1.size() == 0u);
        }) ? ({
            auto&& m5579_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_5585).a0;
            auto&& m5579_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_5585).a1;
            prism_rtl::finished(std::tuple{crate::check::types::t_unit(), st_4});
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_5585) && ({
            auto&& m5579_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_5585).a0;
            auto&& t = prism_rtl::as<crate::check::types::Ty::TySig>(walk_5585).a1;
            (m5579_1_0 == Text::lit("!"));
        }) ? ({
            auto&& m5579_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_5585).a0;
            auto&& t = prism_rtl::as<crate::check::types::Ty::TySig>(walk_5585).a1;
            prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k_1), prism_rtl::rc(t)}))}), st_4});
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_5585) && ({
            auto&& m5579_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_5585).a0;
            auto&& t = prism_rtl::as<crate::check::types::Ty::TySig>(walk_5585).a1;
            (m5579_2_0 == Text::lit("$"));
        }) ? ({
            auto&& m5579_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_5585).a0;
            auto&& t = prism_rtl::as<crate::check::types::Ty::TySig>(walk_5585).a1;
            prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k_1), prism_rtl::rc(t)}))}), st_4});
        })
            : prism_rtl::is<crate::check::types::Ty::TyTuple>(walk_5585) ? ({
            auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(walk_5585).a0;
            call_value(fold_job(ts, false, ({
            auto st_4_5 = st_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_4_5_5 = st_4_5;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto x = p1;
                    (prism_rtl::finished(seen || crate::check::expr::is_time_sigil(crate::check::types::head_sigil(st_4_5_5, x))));
                });
            }));
            });
        })));
        })), [=](bool fold_5768) {
            return fold_5768
                ? call_value(fold_job(ts, std::tuple{Array<crate::check::types::Ty>{}, st_4}, ({
                auto k_1_5 = k_1;
                auto live_2_5 = live_2;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto k_1_5_5 = k_1_5;
                    auto live_2_5_5 = live_2_5;
                    entered(once_job([=]() {
                    return ({
                        auto [acc, s] = p0;
                        auto x = p1;
                        call_then(start_gather(s, x, k_1_5_5, live_2_5_5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> gather_5939) {
                        return ({
                            auto [g, s2] = gather_5939;
                            (prism_rtl::finished(std::tuple{crate::prelude::push(acc, g), s2}));
                        });
                    });
                    });
                }));
                });
            }));
            })), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> fold_5867) {
                return ({
                    auto [parts, st2] = fold_5867;
                    (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyTuple{parts}), st2}));
                });
            })
                : prism_rtl::finished(std::tuple{live_map(live_2, k_1, crate::check::types::Ty(crate::check::types::Ty::TyTuple{ts})), st_4});
        });
        })
            : ({
            auto&& other = walk_5585;
            prism_rtl::finished(std::tuple{live_map(live_2, k_1, other), st_4});
        });
        });
    });
}


/// `Start Gather, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_gather(crate::check::types::St st, crate::check::types::Ty res, crate::check::types::Ty k, bool live) {
    return prism_rtl::make_rc<Gather>(st, res, k, live);
}


/// LiveMap: fn Bool, Ty, Ty -> Ty
crate::check::types::Ty live_map(const bool& live, const crate::check::types::Ty& k, const crate::check::types::Ty& v_) {
    return live
        ? crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)}))})
        : crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)});
}


/// InferGiven: unbounded fn Env, St, Block, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_given(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Block& b, const crate::syntax::Range& span) {
    auto mark = (env.mark == Text::lit("?")) || (env.mark == Text::lit("~"))
        ? env.mark
        : given_mark_of(b.stmts);
    return infer_given_block(env, st, b, mark);
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferGiven::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& b = this->b;
    const auto& span = this->span;
    auto mark = (env.mark == Text::lit("?")) || (env.mark == Text::lit("~"))
        ? env.mark
        : given_mark_of(b.stmts);
    return prism_rtl::more(prism_rtl::rc(InferGivenBlock(env, st, b, mark)));
}


/// `Start InferGiven, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_given(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferGiven>(env, st, b, span);
}


/// GivenMarkOf: fn [Stmt] -> Text
Text given_mark_of(const Array<crate::syntax::Stmt>& stmts) {
    return fold(stmts, Text::lit("?"), [&](const Text& m, const crate::syntax::Stmt& s) { return m; });
}


/// InferGivenBlock: unbounded fn Env, St, Block, Text -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_given_block(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Block& b, const Text& mark) {
    auto n = len(b.stmts);
    auto [env2, st2, res_opt] = run_to_end(fold_job(crate::check::errors::range0(n), std::tuple{env, st, std::optional<crate::check::types::Ty>{}}, ({
        auto b_1 = b;
        auto mark_2 = mark;
        auto n_3 = n;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_4 = b_1;
            auto mark_2_4 = mark_2;
            auto n_3_4 = n_3;
            entered(once_job([=]() {
            return ({
                auto [en, s, r_opt] = p0;
                auto i = p1;
                ({
                auto stmt = or_(index(b_1_4.stmts, i), crate::check::blocks::dummy_stmt2());
                (prism_rtl::more(prism_rtl::rc(GivenStmt(en, s, stmt, mark_2_4, (i + Nat(1u)) == n_3_4, r_opt))));
            });
            });
        }));
        });
    }));
    })));
    if (prism_rtl::is_some(res_opt)) {
        auto&& t = prism_rtl::some_of(res_opt);
        return std::tuple{t, st2};
    }
    if (prism_rtl::is_none(res_opt)) {
        auto [v_, st3] = crate::check::types::fresh_var(st2, false, Text::lit(""));
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{mark, prism_rtl::rc(v_)}), st3};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferGivenBlock::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& b = this->b;
    const auto& mark = this->mark;
    auto n = len(b.stmts);
    auto b_1 = b;
    auto env_2 = env;
    auto mark_3 = mark;
    auto st_4 = st;
    return call_value(fold_job(crate::check::errors::range0(n), std::tuple{env_2, st_4, std::optional<crate::check::types::Ty>{}}, ({
        auto b_1_5 = b_1;
        auto mark_3_5 = mark_3;
        auto n_5 = n;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_5_6 = b_1_5;
            auto mark_3_5_6 = mark_3_5;
            auto n_5_6 = n_5;
            entered(once_job([=]() {
            return ({
                auto [en, s, r_opt] = p0;
                auto i = p1;
                ({
                auto stmt = or_(index(b_1_5_6.stmts, i), crate::check::blocks::dummy_stmt2());
                (prism_rtl::more(prism_rtl::rc(GivenStmt(en, s, stmt, mark_3_5_6, (i + Nat(1u)) == n_5_6, r_opt))));
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>> fold_7136) {
        return ({
            auto [env2, st2, res_opt] = fold_7136;
            ({
            prism_rtl::is_some(res_opt) ? ({
            auto&& t = prism_rtl::some_of(res_opt);
            prism_rtl::finished(std::tuple{t, st2});
        })
            : prism_rtl::is_none(res_opt) ? ({
            auto [v_, st3] = crate::check::types::fresh_var(st2, false, Text::lit(""));
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{mark_3, prism_rtl::rc(v_)}), st3}));
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start InferGivenBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_given_block(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b, Text mark) {
    return prism_rtl::make_rc<InferGivenBlock>(env, st, b, mark);
}


/// GivenStmt: unbounded fn Env, St, Stmt, Text, Bool, ?Ty -> ((Env, St, ?Ty))
std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>> given_stmt(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Stmt& s, const Text& mark, const bool& last, const std::optional<crate::check::types::Ty>& res_opt) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto [t, st1] = crate::check::expr::infer(env, st, e);
        auto [v_, st2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
        auto st3 = crate::check::types::unify::unify(st2, crate::check::types::Ty(crate::check::types::Ty::TySig{mark, prism_rtl::rc(v_)}), t, e.span);
        auto [env2, st4] = crate::check::expr::patterns::bind_pattern(unpending(env), st3, p_, v_, true);
        return std::tuple{env2, st4, res_opt};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
        return std::tuple{env, crate::check::expr::lifting::check_cond(env, st, c), res_opt};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
        return std::tuple{env, crate::check::expr::lifting::check_cond(env, st, c), res_opt};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto [env2, st2] = crate::check::expr::lets::check_let(env, st, p_, ty_opt, e, s.span);
        return std::tuple{env2, st2, res_opt};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        auto [env1, st1] = crate::check::expr::lets::pre_bind(env, st, s);
        auto [env2, st2] = crate::check::expr::lets::check_local_fn(env1, st1, f, s.span);
        return std::tuple{env2, st2, res_opt};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        auto [env2, st2] = crate::check::expr::lets::pre_bind(env, st, s);
        return std::tuple{env2, st2, res_opt};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return last
            ? ({
            auto [t, st1] = crate::check::expr::infer(env, st, e);
            auto [v_, st2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
            auto st3 = crate::check::types::unify::unify(st2, crate::check::types::Ty(crate::check::types::Ty::TySig{mark, prism_rtl::rc(v_)}), t, e.span);
            std::tuple{env, st3, std::optional(crate::check::types::Ty(crate::check::types::Ty::TySig{mark, prism_rtl::rc(v_)}))};
        })
            : ({
            auto [t, st1] = crate::check::expr::infer(env, st, e);
            std::tuple{env, crate::check::blocks::discarded(st1, t, e.span), res_opt};
        });
    }
    {
        return std::tuple{env, crate::check::types::recording::err(st, Text::lit("mismatch"), s.span, Text::lit("this statement belongs in a widget or `update` block")), res_opt};
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>> GivenStmt::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& s = this->s;
    const auto& mark = this->mark;
    const auto& last = this->last;
    const auto& res_opt = this->res_opt;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        ({
        auto res_opt_1 = res_opt;
        auto e_2 = e;
        auto env_3 = env;
        auto mark_4 = mark;
        auto p__5 = p_;
        auto st_6 = st;
        call_then(crate::check::expr::start_infer(env_3, st_6, e_2), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_7611) {
        return ({
            auto [t, st1] = infer_7611;
            auto [v_, st2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
            call_then(crate::check::types::unify::start_unify(st2, crate::check::types::Ty(crate::check::types::Ty::TySig{mark_4, prism_rtl::rc(v_)}), t, e_2.span), [=](crate::check::types::St unify_7695) {
            return ({
                auto st3 = unify_7695;
                call_then(crate::check::expr::patterns::start_bind_pattern(unpending(env_3), st3, p__5, v_, true), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_7761) {
                return ({
                    auto [env2, st4] = bind_pattern_7761;
                    (prism_rtl::finished(std::tuple{env2, st4, res_opt_1}));
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
        ({
        auto res_opt_1 = res_opt;
        auto c_2 = c;
        auto env_3 = env;
        auto st_4 = st;
        call_then(crate::check::expr::lifting::start_check_cond(env_3, st_4, c_2), [=](crate::check::types::St check_cond_7858) { return prism_rtl::finished(std::tuple{env_3, check_cond_7858, res_opt_1}); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
        ({
        auto res_opt_1 = res_opt;
        auto c_2 = c;
        auto env_3 = env;
        auto st_4 = st;
        call_then(crate::check::expr::lifting::start_check_cond(env_3, st_4, c_2), [=](crate::check::types::St check_cond_7911) { return prism_rtl::finished(std::tuple{env_3, check_cond_7911, res_opt_1}); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto res_opt_1 = res_opt;
        auto ty_opt_2 = ty_opt;
        auto e_3 = e;
        auto env_4 = env;
        auto p__5 = p_;
        auto s_6 = s;
        auto st_7 = st;
        call_then(crate::check::expr::lets::start_check_let(env_4, st_7, p__5, ty_opt_2, e_3, s_6.span), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> check_let_7989) {
        return ({
            auto [env2, st2] = check_let_7989;
            (prism_rtl::finished(std::tuple{env2, st2, res_opt_1}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        ({
        auto res_opt_1 = res_opt;
        auto env_2 = env;
        auto f_3 = f;
        auto s_4 = s;
        auto st_5 = st;
        call_then(crate::check::expr::lets::start_pre_bind(env_2, st_5, s_4), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> pre_bind_8092) {
        return ({
            auto [env1, st1] = pre_bind_8092;
            call_then(crate::check::expr::lets::start_check_local_fn(env1, st1, f_3, s_4.span), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> check_local_fn_8139) {
            return ({
                auto [env2, st2] = check_local_fn_8139;
                (prism_rtl::finished(std::tuple{env2, st2, res_opt_1}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? ({
        auto res_opt_1 = res_opt;
        auto env_2 = env;
        auto s_3 = s;
        auto st_4 = st;
        call_then(crate::check::expr::lets::start_pre_bind(env_2, st_4, s_3), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> pre_bind_8252) {
        return ({
            auto [env2, st2] = pre_bind_8252;
            (prism_rtl::finished(std::tuple{env2, st2, res_opt_1}));
        });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        last
        ? ({
        auto e_1 = e;
        auto env_2 = env;
        auto last_3 = last;
        auto mark_4 = mark;
        auto st_5 = st;
        call_then(crate::check::expr::start_infer(env_2, st_5, e_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_8358) {
        return ({
            auto [t, st1] = infer_8358;
            auto [v_, st2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
            call_then(crate::check::types::unify::start_unify(st2, crate::check::types::Ty(crate::check::types::Ty::TySig{mark_4, prism_rtl::rc(v_)}), t, e_1.span), [=](crate::check::types::St unify_8450) {
            return ({
                auto st3 = unify_8450;
                (prism_rtl::finished(std::tuple{env_2, st3, std::optional(crate::check::types::Ty(crate::check::types::Ty::TySig{mark_4, prism_rtl::rc(v_)}))}));
            });
        });
        });
    });
    })
        : ({
        auto res_opt_1 = res_opt;
        auto e_2 = e;
        auto env_3 = env;
        auto st_4 = st;
        call_then(crate::check::expr::start_infer(env_3, st_4, e_2), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_8717) {
        return ({
            auto [t, st1] = infer_8717;
            call_then(crate::check::blocks::start_discarded(st1, t, e_2.span), [=](crate::check::types::St discarded_8754) { return prism_rtl::finished(std::tuple{env_3, discarded_8754, res_opt_1}); });
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{env, crate::check::types::recording::err(st, Text::lit("mismatch"), s.span, Text::lit("this statement belongs in a widget or `update` block")), res_opt});
    });
}


/// `Start GivenStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>> start_given_stmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Stmt s, Text mark, bool last, std::optional<crate::check::types::Ty> res_opt) {
    return prism_rtl::make_rc<GivenStmt>(env, st, s, mark, last, res_opt);
}

}  // namespace crate::check::blocks::structure
