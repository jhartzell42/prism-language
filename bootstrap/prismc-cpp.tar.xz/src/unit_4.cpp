// The modules `Check.Blocks.Borrows`, `Check.Blocks.Structure`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/blocks/borrows/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Blocks.Borrows`, from `target/bootstrap/cpp-src/prismc/check/blocks/borrows.prism`.
namespace crate::check::blocks::borrows {

/// InferUpdate: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_update_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& target_p2, const crate::syntax::Block& body_p3, const crate::syntax::Range& span_p4) {
    auto [t_p9, st1_pa] = crate::check::expr::infer_f(env_p0, st_p1, target_p2);
    auto sh_p5 = crate::check::types::head_sigil_f(st1_pa, t_p9);
    auto st2_p6 = crate::check::expr::is_time_sigil_f(sh_p5) || (sh_p5 == Text::lit("@"))
        ? crate::check::types::recording::err_fix_f(st1_pa, Text::lit("time-in-update"), target_p2.span_p, prism_rtl::cat("`update` over a `", crate::check::types::show_ty_f(st1_pa, t_p9), "`"), Text::lit("update the plain value, and lift the function that does it"))
        : st1_pa;
    auto env2_p7 = ({
        crate::check::expr::Env this_ = crate::check::blocks::structure::with_topic_f(env_p0, Text::lit("&_"), t_p9);
        this_.in_update_p = true;
        (std::move(this_));
    });
    auto&& _st3_pb = update_stmts_f(env2_p7, st2_p6, body_p3.stmts_p);
    auto&& st3_pb = std::get<1>(_st3_pb);
    auto st4_p8 = crate::check::passes::borrows::and_block_checks_f(env2_p7, st3_pb, body_p3, t_p9);
    return std::tuple{t_p9, st4_p8};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferUpdate::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& target_p2 = this->target_p2;
    const auto& body_p3 = this->body_p3;
    const auto& span_p4 = this->span_p4;
    auto body_p3x = body_p3;
    auto env_p0x = env_p0;
    auto span_p4x = span_p4;
    auto st_p1x = st_p1;
    auto target_p2x = target_p2;
    return crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, target_p2x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_1577) {
        return ({
            auto [t_p9, st1_pa] = infer_f_1577;
            (crate::prelude::call_then(crate::check::types::start_head_sigil_f(st1_pa, t_p9), [=](Text head_sigil_f_1612) {
            return ({
                auto sh_p5 = head_sigil_f_1612;
                auto st2_p6 = crate::check::expr::is_time_sigil_f(sh_p5) || (sh_p5 == Text::lit("@"))
                    ? crate::check::types::recording::err_fix_f(st1_pa, Text::lit("time-in-update"), prism_rtl::deref(target_p2x).span_p, prism_rtl::cat("`update` over a `", crate::check::types::show_ty_f(st1_pa, t_p9), "`"), Text::lit("update the plain value, and lift the function that does it"))
                    : st1_pa;
                auto env2_p7 = ({
                    crate::check::expr::Env this_ = crate::check::blocks::structure::with_topic_f(env_p0x, Text::lit("&_"), t_p9);
                    this_.in_update_p = true;
                    (std::move(this_));
                });
                (crate::prelude::call_then(start_update_stmts_f(env2_p7, st2_p6, prism_rtl::deref(body_p3x).stmts_p), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_f_1930) {
                return ({
                    auto&& _st3_pb = update_stmts_f_1930;
                    auto&& st3_pb = std::get<1>(_st3_pb);
                    (crate::prelude::call_then(crate::check::passes::borrows::start_and_block_checks_f(env2_p7, st3_pb, body_p3x, t_p9), [=](crate::check::types::St and_block_checks_f_1978) {
                    return ({
                        auto st4_p8 = and_block_checks_f_1978;
                        (prism_rtl::finished(std::tuple{t_p9, st4_p8}));
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start InferUpdate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_update_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr target_p2, crate::syntax::Block body_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<InferUpdate>(env_p0, st_p1, target_p2, body_p3, span_p4);
}


/// UpdateStmts: unbounded fn Env, St, [Stmt] -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Stmt>& stmts_p2) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p2, std::tuple{env_p0, st_p1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [en_p3, s_p4] = p0;
                auto stmt_p5 = p1;
                (prism_rtl::more(prism_rtl::rc(UpdateStmt(en_p3, s_p4, stmt_p5))));
            });
        }));
    }))));
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> UpdateStmts::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& stmts_p2 = this->stmts_p2;
    return crate::prelude::fold_job(stmts_p2, std::tuple{env_p0, st_p1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [en_p3, s_p4] = p0;
                auto stmt_p5 = p1;
                (prism_rtl::more(prism_rtl::rc(UpdateStmt(en_p3, s_p4, stmt_p5))));
            });
        }));
    })))->cycle();
}


/// `Start UpdateStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_update_stmts_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2) {
    return prism_rtl::make_rc<UpdateStmts>(env_p0, st_p1, stmts_p2);
}


/// UpdateStmt: unbounded fn Env, St, Stmt -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmt_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Stmt& s_p2) {
    auto&& _m = s_p2.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
        auto&& target_p3 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value_p4 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        auto [tt_p6, st1_p7] = crate::check::expr::infer_f(env_p0, st_p1, target_p3);
        auto st2_p5 = ref_target_f(env_p0, st1_p7, target_p3);
        return std::tuple{env_p0, crate::check::expr::check_f(env_p0, st2_p5, value_p4, tt_p6)};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
        auto&& target_p8 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& op_p9 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a1;
        auto&& value_pa = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        auto [tt_pf, st1_pg] = crate::check::expr::infer_f(env_p0, st_p1, target_p8);
        auto st2_pb = ref_target_f(env_p0, st1_pg, target_p8);
        auto st3_pc = crate::check::expr::check_f(env_p0, st2_pb, value_pa, tt_pf);
        auto st4_pd = crate::check::expr::add_want_f(st3_pc, Text::lit("Prelude.Num"), tt_pf, s_p2.span_p);
        auto st5_pe = op_p9 == Text::lit("-=")
            ? crate::check::expr::add_want_f(st4_pd, Text::lit("Prelude.Sub"), tt_pf, s_p2.span_p)
            : st4_pd;
        return std::tuple{env_p0, st5_pe};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ph = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_oi = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& e_pj = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto [t_pl, st1_pm] = crate::check::expr::infer_f(env_p0, st_p1, e_pj);
        auto st2_pk = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            if (prism_rtl::is_some(ty_oi)) {
                auto&& ty_pn = prism_rtl::some_of(ty_oi);
                _v.set(({
                    auto [at_po, s2_pp] = crate::check::env::reading::conv_type_f(crate::check::expr::env_cx_f(env_p0), st1_pm, ty_pn);
                    (crate::check::types::unify::unify_f(s2_pp, at_po, t_pl, prism_rtl::deref(e_pj).span_p));
                }));
                goto _done;
            }
            if (prism_rtl::is_none(ty_oi)) {
                _v.set(st1_pm);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto [env2_pq, st3_pr] = crate::check::expr::patterns::bind_pattern_f(crate::check::blocks::structure::unpending_f(env_p0), st2_pk, p_ph, t_pl, false);
        return std::tuple{env2_pq, st3_pr};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& c_ps = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& body_pt = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        return std::tuple{env_p0, update_while_f(env_p0, st_p1, c_ps, body_pt)};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e_pu = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_pu).kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& c_pv = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& then_b_p10 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b_o11 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            return std::tuple{env_p0, update_if_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(c_pv)), then_b_p10, else_b_o11)};
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& scrut_p12 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms_p13 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            return std::tuple{env_p0, update_match_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(scrut_p12)), arms_p13, prism_rtl::deref(e_pu).span_p)};
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
            auto&& binders_o14 = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
            auto&& source_p15 = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
            auto&& body_p16 = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
            return std::tuple{env_p0, update_for_f(env_p0, st_p1, binders_o14, prism_rtl::deref(prism_rtl::deref(source_p15)), body_p16, prism_rtl::deref(e_pu).span_p)};
        }
        {
            auto [t_p17, st1_p18] = crate::check::expr::infer_f(env_p0, st_p1, e_pu);
            return std::tuple{env_p0, crate::check::blocks::discarded_f(st1_p18, t_p17, prism_rtl::deref(e_pu).span_p)};
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f_p19 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        auto [env1_p1a, st1_p1b] = crate::check::expr::lets::pre_bind_f(env_p0, st_p1, s_p2);
        return crate::check::expr::lets::check_local_fn_f(env1_p1a, st1_p1b, f_p19, s_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        return crate::check::expr::lets::pre_bind_f(env_p0, st_p1, s_p2);
    }
    {
        return std::tuple{env_p0, crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), s_p2.span_p, Text::lit("this statement belongs in a widget or `given:` block"))};
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> UpdateStmt::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& s_p2 = this->s_p2;
    return ({
        auto&& _m = prism_rtl::deref(s_p2).kind_p;
        prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& target_p3 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value_p4 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        ({
        auto env_p0x = env_p0;
        auto st_p1x = st_p1;
        auto target_p3x = target_p3;
        auto value_p4x = value_p4;
        (crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, target_p3x), [=, value_p4x = std::move(value_p4x)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_2330) {
        return ({
            auto [tt_p6, st1_p7] = infer_f_2330;
            auto st2_p5 = ref_target_f(env_p0x, st1_p7, target_p3x);
            (crate::prelude::call_then(crate::check::expr::start_check_f(env_p0x, st2_p5, value_p4x, tt_p6), [=](crate::check::types::St check_f_2413) { return prism_rtl::finished(std::tuple{env_p0x, check_f_2413}); }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& target_p8 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& op_p9 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a1;
        auto&& value_pa = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        ({
        auto env_p0x = env_p0;
        auto op_p9x = op_p9;
        auto s_p2x = s_p2;
        auto st_p1x = st_p1;
        auto target_p8x = target_p8;
        auto value_pax = value_pa;
        (crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, target_p8x), [=, op_p9x = std::move(op_p9x), s_p2x = std::move(s_p2x), value_pax = std::move(value_pax)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_2498) {
        return ({
            auto [tt_pf, st1_pg] = infer_f_2498;
            auto st2_pb = ref_target_f(env_p0x, st1_pg, target_p8x);
            (crate::prelude::call_then(crate::check::expr::start_check_f(env_p0x, st2_pb, value_pax, tt_pf), [=](crate::check::types::St check_f_2583) {
            return ({
                auto st3_pc = check_f_2583;
                auto st4_pd = crate::check::expr::add_want_f(st3_pc, Text::lit("Prelude.Num"), tt_pf, prism_rtl::deref(s_p2x).span_p);
                auto st5_pe = op_p9x == Text::lit("-=")
                    ? crate::check::expr::add_want_f(st4_pd, Text::lit("Prelude.Sub"), tt_pf, prism_rtl::deref(s_p2x).span_p)
                    : st4_pd;
                (prism_rtl::finished(std::tuple{env_p0x, st5_pe}));
            });
        }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ph = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_oi = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& e_pj = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto ty_oix = ty_oi;
        auto e_pjx = e_pj;
        auto env_p0x = env_p0;
        auto p_phx = p_ph;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, e_pjx), [=, ty_oix = std::move(ty_oix), p_phx = std::move(p_phx)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_2814) {
        return ({
            auto [t_pl, st1_pm] = infer_f_2814;
            auto st2_pk = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                if (prism_rtl::is_some(ty_oix)) {
                    auto&& ty_pn = prism_rtl::some_of(ty_oix);
                    _v.set(({
                        auto [at_po, s2_pp] = crate::check::env::reading::conv_type_f(crate::check::expr::env_cx_f(env_p0x), st1_pm, ty_pn);
                        (crate::check::types::unify::unify_f(s2_pp, at_po, t_pl, prism_rtl::deref(e_pjx).span_p));
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(ty_oix)) {
                    _v.set(st1_pm);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(crate::check::blocks::structure::unpending_f(env_p0x), st2_pk, p_phx, t_pl, false), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_f_3030) {
            return ({
                auto [env2_pq, st3_pr] = bind_pattern_f_3030;
                (prism_rtl::finished(std::tuple{env2_pq, st3_pr}));
            });
        }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
        auto&& c_ps = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& body_pt = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        ({
        auto body_ptx = body_pt;
        auto c_psx = c_ps;
        auto env_p0x = env_p0;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_update_while_f(env_p0x, st_p1x, c_psx, body_ptx), [=](crate::check::types::St update_while_f_3126) { return prism_rtl::finished(std::tuple{env_p0x, update_while_f_3126}); }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& e_pu = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_pu).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c_pv = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_p10 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_o11 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        ({
        auto else_b_o11x = else_b_o11;
        auto c_pvx = prism_rtl::deref(prism_rtl::deref(c_pv));
        auto env_p0x = env_p0;
        auto st_p1x = st_p1;
        auto then_b_p10x = then_b_p10;
        (crate::prelude::call_then(start_update_if_f(env_p0x, st_p1x, c_pvx, then_b_p10x, else_b_o11x), [=](crate::check::types::St update_if_f_3223) { return prism_rtl::finished(std::tuple{env_p0x, update_if_f_3223}); }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& scrut_p12 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p13 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        ({
        auto arms_p13x = arms_p13;
        auto e_pux = e_pu;
        auto env_p0x = env_p0;
        auto scrut_p12x = prism_rtl::deref(prism_rtl::deref(scrut_p12));
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_update_match_f(env_p0x, st_p1x, scrut_p12x, arms_p13x, prism_rtl::deref(e_pux).span_p), [=](crate::check::types::St update_match_f_3297) { return prism_rtl::finished(std::tuple{env_p0x, update_match_f_3297}); }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& binders_o14 = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source_p15 = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body_p16 = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        ({
        auto binders_o14x = binders_o14;
        auto body_p16x = body_p16;
        auto e_pux = e_pu;
        auto env_p0x = env_p0;
        auto source_p15x = prism_rtl::deref(prism_rtl::deref(source_p15));
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_update_for_f(env_p0x, st_p1x, binders_o14x, source_p15x, body_p16x, prism_rtl::deref(e_pux).span_p), [=](crate::check::types::St update_for_f_3386) { return prism_rtl::finished(std::tuple{env_p0x, update_for_f_3386}); }));
    });
    })
        : ({
        auto e_pux = e_pu;
        auto env_p0x = env_p0;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, e_pux), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_3487) {
        return ({
            auto [t_p17, st1_p18] = infer_f_3487;
            (crate::prelude::call_then(crate::check::blocks::start_discarded_f(st1_p18, t_p17, prism_rtl::deref(e_pux).span_p), [=](crate::check::types::St discarded_f_3524) { return prism_rtl::finished(std::tuple{env_p0x, discarded_f_3524}); }));
        });
    }));
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f_p19 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        ({
        auto env_p0x = env_p0;
        auto f_p19x = f_p19;
        auto s_p2x = s_p2;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::expr::lets::start_pre_bind_f(env_p0x, st_p1x, s_p2x), [=, f_p19x = std::move(f_p19x)](std::tuple<crate::check::expr::Env, crate::check::types::St> pre_bind_f_3591) {
        return ({
            auto [env1_p1a, st1_p1b] = pre_bind_f_3591;
            (prism_rtl::more(prism_rtl::rc(crate::check::expr::lets::CheckLocalFn(env1_p1a, st1_p1b, f_p19x, prism_rtl::deref(s_p2x).span_p))));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? prism_rtl::more(prism_rtl::rc(crate::check::expr::lets::PreBind(env_p0, st_p1, s_p2)))
        : prism_rtl::finished(std::tuple{env_p0, crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), prism_rtl::deref(s_p2).span_p, Text::lit("this statement belongs in a widget or `given:` block"))});
    });
}


/// `Start UpdateStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_update_stmt_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Stmt s_p2) {
    return prism_rtl::make_rc<UpdateStmt>(env_p0, st_p1, s_p2);
}


/// RefTarget: fn Env, St, Expr -> St
crate::check::types::St ref_target_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2) {
    return is_ref_f(e_p2)
        ? st_p1
        : crate::check::types::recording::err_fix_f(st_p1, Text::lit("mismatch"), e_p2.span_p, Text::lit("the left of `<=` is a reference: `&_`, a local `&x`, or a path from one"), prism_rtl::cat("write `&_.", crate::check::expr::src_text_f(env_p0, e_p2.span_p), "`, or make a local with `let &x = ...`"));
}


/// IsRef: fn Expr -> Bool
bool is_ref_f(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(n_p1).sigils_p, Text::lit("&"));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r_p2 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        return is_ref_f(prism_rtl::deref(prism_rtl::deref(r_p2)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r_p3 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        return is_ref_f(prism_rtl::deref(prism_rtl::deref(r_p3)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_ref_f(prism_rtl::deref(prism_rtl::deref(x_p4)));
    }
    {
        return false;
    }
}


/// UpdateIf: unbounded fn Env, St, Cond, Block, ?Block -> St
crate::check::types::St update_if_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Cond& c_p2, const crate::syntax::Block& then_b_p3, const std::optional<crate::syntax::Block>& else_b_o4) {
    auto [env2_pe, st1_pf] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p2)) {
            auto&& e_p5 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p2).a0;
            _v.set(std::tuple{env_p0, crate::check::expr::lifting::check_cond_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(e_p5)))});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c_p2)) {
            auto&& p_p6 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a0;
            auto&& e_p7 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a1;
            auto&& gd_o8 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a2;
            _v.set(({
                auto [et_p9, s1_pa] = crate::check::expr::infer_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(e_p7)));
                auto [en_pb, s2_pc] = crate::check::expr::patterns::bind_pattern_f(crate::check::blocks::structure::unpending_f(env_p0), s1_pa, p_p6, et_p9, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(gd_o8));
                if (prism_rtl::is_some(_m)) {
                    auto&& g_pd = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en_pb, crate::check::expr::lifting::check_cond_f(en_pb, s2_pc, g_pd)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en_pb, s2_pc});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _st2_pg = update_stmts_f(env2_pe, st1_pf, then_b_p3.stmts_p);
    auto&& st2_pg = std::get<1>(_st2_pg);
    if (prism_rtl::is_some(else_b_o4)) {
        auto&& b_ph = prism_rtl::some_of(else_b_o4);
        auto&& _st3_pi = update_stmts_f(env_p0, st2_pg, prism_rtl::deref(b_ph).stmts_p);
        auto&& st3_pi = std::get<1>(_st3_pi);
        return st3_pi;
    }
    if (prism_rtl::is_none(else_b_o4)) {
        return st2_pg;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> UpdateIf::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& c_p2 = this->c_p2;
    const auto& then_b_p3 = this->then_b_p3;
    const auto& else_b_o4 = this->else_b_o4;
    auto [env2_pe, st1_pf] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p2)) {
            auto&& e_p5 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p2).a0;
            _v.set(std::tuple{env_p0, crate::check::expr::lifting::check_cond_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(e_p5)))});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c_p2)) {
            auto&& p_p6 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a0;
            auto&& e_p7 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a1;
            auto&& gd_o8 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a2;
            _v.set(({
                auto [et_p9, s1_pa] = crate::check::expr::infer_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(e_p7)));
                auto [en_pb, s2_pc] = crate::check::expr::patterns::bind_pattern_f(crate::check::blocks::structure::unpending_f(env_p0), s1_pa, p_p6, et_p9, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(gd_o8));
                if (prism_rtl::is_some(_m)) {
                    auto&& g_pd = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en_pb, crate::check::expr::lifting::check_cond_f(en_pb, s2_pc, g_pd)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en_pb, s2_pc});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto else_b_o4x = else_b_o4;
    auto env_p0x = env_p0;
    auto then_b_p3x = then_b_p3;
    return crate::prelude::call_then(start_update_stmts_f(env2_pe, st1_pf, prism_rtl::deref(then_b_p3x).stmts_p), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_f_4808) {
        return ({
            auto&& _st2_pg = update_stmts_f_4808;
            auto&& st2_pg = std::get<1>(_st2_pg);
            ({
            prism_rtl::is_some(else_b_o4x) ? ({
            auto&& b_ph = prism_rtl::some_of(else_b_o4x);
            ({
            auto b_phx = b_ph;
            (crate::prelude::call_then(start_update_stmts_f(env_p0x, st2_pg, prism_rtl::deref(b_phx).stmts_p), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_f_4908) {
            return ({
                auto&& _st3_pi = update_stmts_f_4908;
                auto&& st3_pi = std::get<1>(_st3_pi);
                (prism_rtl::finished(st3_pi));
            });
        }));
        });
        })
            : prism_rtl::is_none(else_b_o4x) ? prism_rtl::finished(st2_pg)
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start UpdateIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_update_if_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Cond c_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4) {
    return prism_rtl::make_rc<UpdateIf>(env_p0, st_p1, c_p2, then_b_p3, else_b_o4);
}


/// UpdateMatch: unbounded fn Env, St, Expr, [Arm], Range -> St
crate::check::types::St update_match_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& scrut_p2, const Array<crate::syntax::Arm>& arms_p3, const crate::syntax::Range& span_p4) {
    auto [t_p6, st1_p7] = crate::check::expr::infer_f(env_p0, st_p1, scrut_p2);
    auto st2_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(arms_p3, st1_p7, ({
        auto env_p0x = env_p0;
        auto t_p6x = t_p6;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x), t_p6x = std::move(t_p6x)](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0xy = env_p0x;
            auto t_p6xy = t_p6x;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy), t_p6xy = std::move(t_p6xy)]() {
            return ({
                auto s_p8 = p0;
                auto arm_p9 = p1;
                ({
                auto [env2_pc, s1_pd] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                    auto&& _m = prism_rtl::deref(arm_p9).pattern_o;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p_pb = prism_rtl::some_of(_m);
                        _v.set(crate::check::expr::patterns::bind_pattern_f(crate::check::blocks::structure::unpending_f(env_p0xy), s_p8, p_pb, t_p6xy, true));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::tuple{env_p0xy, s_p8});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto s2_pa = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    auto&& _m = prism_rtl::deref(arm_p9).guard_o;
                    if (prism_rtl::is_some(_m)) {
                        auto&& gd_pe = prism_rtl::some_of(_m);
                        _v.set(crate::check::expr::lifting::check_cond_f(env2_pc, s1_pd, gd_pe));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s1_pd);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (crate::prelude::call_then(start_update_stmts_f(env2_pc, s2_pa, prism_rtl::deref(prism_rtl::deref(arm_p9).body_p).stmts_p), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_f_5417) {
                return ({
                    auto&& _s3_pf = update_stmts_f_5417;
                    auto&& s3_pf = std::get<1>(_s3_pf);
                    (prism_rtl::finished(s3_pf));
                });
            }));
            });
            });
        })));
        });
    })));
    })));
    return crate::check::passes::match_coverage_f(env_p0, st2_p5, t_p6, arms_p3, span_p4);
}


prism_rtl::Turn<crate::check::types::St> UpdateMatch::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& scrut_p2 = this->scrut_p2;
    const auto& arms_p3 = this->arms_p3;
    const auto& span_p4 = this->span_p4;
    auto arms_p3x = arms_p3;
    auto env_p0x = env_p0;
    auto scrut_p2x = scrut_p2;
    auto span_p4x = span_p4;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, scrut_p2x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_5096) {
        return ({
            auto [t_p6, st1_p7] = infer_f_5096;
            (crate::prelude::call_value(crate::prelude::fold_job(arms_p3x, st1_p7, ({
            auto env_p0xx = env_p0x;
            auto t_p6x = t_p6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=, env_p0xx = std::move(env_p0xx), t_p6x = std::move(t_p6x)](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_p0xxy = env_p0xx;
                auto t_p6xy = t_p6x;
                (crate::prelude::entered(crate::prelude::once_job([=, env_p0xxy = std::move(env_p0xxy), t_p6xy = std::move(t_p6xy)]() {
                return ({
                    auto s_p8 = p0;
                    auto arm_p9 = p1;
                    ({
                    auto [env2_pc, s1_pd] = ({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                        auto&& _m = prism_rtl::deref(arm_p9).pattern_o;
                        if (prism_rtl::is_some(_m)) {
                            auto&& p_pb = prism_rtl::some_of(_m);
                            _v.set(crate::check::expr::patterns::bind_pattern_f(crate::check::blocks::structure::unpending_f(env_p0xxy), s_p8, p_pb, t_p6xy, true));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::tuple{env_p0xxy, s_p8});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    auto s2_pa = ({
                        __label__ _done;
                        prism_rtl::Slot<crate::check::types::St> _v;
                        auto&& _m = prism_rtl::deref(arm_p9).guard_o;
                        if (prism_rtl::is_some(_m)) {
                            auto&& gd_pe = prism_rtl::some_of(_m);
                            _v.set(crate::check::expr::lifting::check_cond_f(env2_pc, s1_pd, gd_pe));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(s1_pd);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    (crate::prelude::call_then(start_update_stmts_f(env2_pc, s2_pa, prism_rtl::deref(prism_rtl::deref(arm_p9).body_p).stmts_p), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_f_5417) {
                    return ({
                        auto&& _s3_pf = update_stmts_f_5417;
                        auto&& s3_pf = std::get<1>(_s3_pf);
                        (prism_rtl::finished(s3_pf));
                    });
                }));
                });
                });
            })));
            });
        })));
        })), [=](crate::check::types::St fold_5131) {
            return ({
                auto st2_p5 = fold_5131;
                (prism_rtl::more(prism_rtl::rc(crate::check::passes::MatchCoverage(env_p0x, st2_p5, t_p6, arms_p3x, span_p4x))));
            });
        }));
        });
    });
}


/// `Start UpdateMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_update_match_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr scrut_p2, Array<crate::syntax::Arm> arms_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<UpdateMatch>(env_p0, st_p1, scrut_p2, arms_p3, span_p4);
}


/// UpdateWhile: unbounded fn Env, St, Cond, Block -> St
crate::check::types::St update_while_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Cond& c_p2, const crate::syntax::Block& body_p3) {
    auto [env2_pd, st1_pe] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p2)) {
            auto&& e_p4 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p2).a0;
            _v.set(std::tuple{env_p0, crate::check::expr::lifting::check_cond_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(e_p4)))});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c_p2)) {
            auto&& p_p5 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a0;
            auto&& e_p6 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a1;
            auto&& gd_o7 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a2;
            _v.set(({
                auto [et_p8, s1_p9] = crate::check::expr::infer_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(e_p6)));
                auto [en_pa, s2_pb] = crate::check::expr::patterns::bind_pattern_f(crate::check::blocks::structure::unpending_f(env_p0), s1_p9, p_p5, et_p8, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(gd_o7));
                if (prism_rtl::is_some(_m)) {
                    auto&& g_pc = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en_pa, crate::check::expr::lifting::check_cond_f(en_pa, s2_pb, g_pc)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en_pa, s2_pb});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _st2_pf = update_stmts_f(env2_pd, st1_pe, body_p3.stmts_p);
    auto&& st2_pf = std::get<1>(_st2_pf);
    return st2_pf;
}


prism_rtl::Turn<crate::check::types::St> UpdateWhile::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& c_p2 = this->c_p2;
    const auto& body_p3 = this->body_p3;
    auto [env2_pd, st1_pe] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p2)) {
            auto&& e_p4 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p2).a0;
            _v.set(std::tuple{env_p0, crate::check::expr::lifting::check_cond_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(e_p4)))});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c_p2)) {
            auto&& p_p5 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a0;
            auto&& e_p6 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a1;
            auto&& gd_o7 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a2;
            _v.set(({
                auto [et_p8, s1_p9] = crate::check::expr::infer_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(e_p6)));
                auto [en_pa, s2_pb] = crate::check::expr::patterns::bind_pattern_f(crate::check::blocks::structure::unpending_f(env_p0), s1_p9, p_p5, et_p8, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(gd_o7));
                if (prism_rtl::is_some(_m)) {
                    auto&& g_pc = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en_pa, crate::check::expr::lifting::check_cond_f(en_pa, s2_pb, g_pc)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en_pa, s2_pb});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto body_p3x = body_p3;
    return crate::prelude::call_then(start_update_stmts_f(env2_pd, st1_pe, prism_rtl::deref(body_p3x).stmts_p), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_f_6052) {
        return ({
            auto&& _st2_pf = update_stmts_f_6052;
            auto&& st2_pf = std::get<1>(_st2_pf);
            (prism_rtl::finished(st2_pf));
        });
    });
}


/// `Start UpdateWhile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_update_while_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Cond c_p2, crate::syntax::Block body_p3) {
    return prism_rtl::make_rc<UpdateWhile>(env_p0, st_p1, c_p2, body_p3);
}


/// UpdateFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> St
crate::check::types::St update_for_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const std::optional<crate::syntax::ForBinders>& binders_o2, const crate::syntax::Expr& source_p3, const crate::syntax::Block& body_p4, const crate::syntax::Range& span_p5) {
    auto [t_p7, st1_p8] = crate::check::expr::infer_f(env_p0, st_p1, source_p3);
    auto [k_p9, v_pa, st2_pb] = crate::check::blocks::structure::coll_parts_f(st1_p8, t_p7, source_p3.span_p);
    auto env1_p6 = crate::check::blocks::structure::loop_indices_f(env_p0);
    auto [env2_pg, st3_ph] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        if (prism_rtl::is_none(binders_o2)) {
            _v.set(std::tuple{crate::check::blocks::structure::with_topic_f(env1_p6, Text::lit("&_"), v_pa), st2_pb});
            goto _done;
        }
        if (prism_rtl::is_some(binders_o2)) {
            auto&& bs_pc = prism_rtl::some_of(binders_o2);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                auto&& _m = prism_rtl::deref(bs_pc).second_o;
                if (prism_rtl::is_some(_m)) {
                    auto&& second_pd = prism_rtl::some_of(_m);
                    _v.set(({
                        auto [e1_pe, s1_pf] = crate::check::expr::patterns::bind_pattern_f(crate::check::blocks::structure::unpending_f(env1_p6), st2_pb, prism_rtl::deref(bs_pc).first_p, k_p9, false);
                        (crate::check::expr::patterns::bind_pattern_f(e1_pe, s1_pf, second_pd, v_pa, false));
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::check::expr::patterns::bind_pattern_f(crate::check::blocks::structure::unpending_f(env1_p6), st2_pb, prism_rtl::deref(bs_pc).first_p, v_pa, false));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _st4_pi = update_stmts_f(env2_pg, st3_ph, body_p4.stmts_p);
    auto&& st4_pi = std::get<1>(_st4_pi);
    return st4_pi;
}


prism_rtl::Turn<crate::check::types::St> UpdateFor::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& binders_o2 = this->binders_o2;
    const auto& source_p3 = this->source_p3;
    const auto& body_p4 = this->body_p4;
    const auto& span_p5 = this->span_p5;
    auto binders_o2x = binders_o2;
    auto body_p4x = body_p4;
    auto env_p0x = env_p0;
    auto source_p3x = source_p3;
    auto span_p5x = span_p5;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, source_p3x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_6360) {
        return ({
            auto [t_p7, st1_p8] = infer_f_6360;
            (crate::prelude::call_then(crate::check::blocks::structure::start_coll_parts_f(st1_p8, t_p7, prism_rtl::deref(source_p3x).span_p), [=](std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St> coll_parts_f_6406) {
            return ({
                auto [k_p9, v_pa, st2_pb] = coll_parts_f_6406;
                auto env1_p6 = crate::check::blocks::structure::loop_indices_f(env_p0x);
                auto [env2_pg, st3_ph] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                    if (prism_rtl::is_none(binders_o2x)) {
                        _v.set(std::tuple{crate::check::blocks::structure::with_topic_f(env1_p6, Text::lit("&_"), v_pa), st2_pb});
                        goto _done;
                    }
                    if (prism_rtl::is_some(binders_o2x)) {
                        auto&& bs_pc = prism_rtl::some_of(binders_o2x);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                            auto&& _m = prism_rtl::deref(bs_pc).second_o;
                            if (prism_rtl::is_some(_m)) {
                                auto&& second_pd = prism_rtl::some_of(_m);
                                _v.set(({
                                    auto [e1_pe, s1_pf] = crate::check::expr::patterns::bind_pattern_f(crate::check::blocks::structure::unpending_f(env1_p6), st2_pb, prism_rtl::deref(bs_pc).first_p, k_p9, false);
                                    (crate::check::expr::patterns::bind_pattern_f(e1_pe, s1_pf, second_pd, v_pa, false));
                                }));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(crate::check::expr::patterns::bind_pattern_f(crate::check::blocks::structure::unpending_f(env1_p6), st2_pb, prism_rtl::deref(bs_pc).first_p, v_pa, false));
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (crate::prelude::call_then(start_update_stmts_f(env2_pg, st3_ph, prism_rtl::deref(body_p4x).stmts_p), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_f_6846) {
                return ({
                    auto&& _st4_pi = update_stmts_f_6846;
                    auto&& st4_pi = std::get<1>(_st4_pi);
                    (prism_rtl::finished(st4_pi));
                });
            }));
            });
        }));
        });
    });
}


/// `Start UpdateFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_update_for_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, std::optional<crate::syntax::ForBinders> binders_o2, crate::syntax::Expr source_p3, crate::syntax::Block body_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<UpdateFor>(env_p0, st_p1, binders_o2, source_p3, body_p4, span_p5);
}

}  // namespace crate::check::blocks::borrows


// The module `Check.Blocks.Structure`, from `target/bootstrap/cpp-src/prismc/check/blocks/structure.prism`.
namespace crate::check::blocks::structure {

/// InferRebuild: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_rebuild_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& scrut_p2, const crate::syntax::Block& body_p3, const crate::syntax::Range& span_p4) {
    auto [t_p6, st1_p7] = crate::check::expr::infer_f(env_p0, st_p1, scrut_p2);
    auto [inner_pc, st2_pd] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = crate::check::types::recording::walk_f(st1_p7, t_p6);
        if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
            auto&& m1650_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
            auto&& i_p8 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
            if (m1650_0_0 == Text::lit("$")) {
                _v.set(std::tuple{prism_rtl::deref(i_p8), st1_p7});
                goto _done;
            }
        }
        if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st1_p7});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
            _v.set(({
                auto [v_p9, s2_pa] = crate::check::types::fresh_var_f(st1_p7, false, Text::lit(""));
                std::tuple{v_p9, crate::check::types::unify::unify_f(s2_pa, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(v_p9)}), t_p6, scrut_p2.span_p)};
            }));
            goto _done;
        }
        {
            auto&& other_pb = _m;
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix_f(st1_p7, Text::lit("mismatch"), scrut_p2.span_p, prism_rtl::cat("`rebuild` builds over a dynamic; this is `", crate::check::types::show_ty_f(st1_p7, other_pb), "`"), Text::lit("a plain value is built once: write the block\'s lines in place"))});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto env2_p5 = with_topic_f(env_p0, Text::lit("_"), inner_pc);
    auto [res_pe, st3_pf] = crate::check::blocks::infer_widget_block_f(env2_p5, st2_pd, body_p3);
    auto&& _m = crate::check::types::recording::walk_f(st3_pf, res_pe);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m2163_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m2163_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m2163_0_0 == Text::lit("unit")) {
            if (m2163_0_1.size() == 0u) {
                return std::tuple{crate::check::types::t_unit_p(), st3_pf};
            }
        }
    }
    {
        auto&& other_pg = _m;
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(other_pg)}), st3_pf};
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferRebuild::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& scrut_p2 = this->scrut_p2;
    const auto& body_p3 = this->body_p3;
    const auto& span_p4 = this->span_p4;
    auto body_p3x = body_p3;
    auto env_p0x = env_p0;
    auto scrut_p2x = scrut_p2;
    auto span_p4x = span_p4;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, scrut_p2x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_1604) {
        return ({
            auto [t_p6, st1_p7] = infer_f_1604;
            (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st1_p7, t_p6), [=](crate::check::types::Ty walk_f_1656) {
            return ({
                auto [inner_pc, st2_pd] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                    if (prism_rtl::is<crate::check::types::Ty::TySig>(walk_f_1656)) {
                        auto&& m1650_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_1656).a0;
                        auto&& i_p8 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_1656).a1;
                        if (m1650_0_0 == Text::lit("$")) {
                            _v.set(std::tuple{prism_rtl::deref(i_p8), st1_p7});
                            goto _done;
                        }
                    }
                    if (prism_rtl::is<crate::check::types::Ty::TyErr>(walk_f_1656)) {
                        _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st1_p7});
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_f_1656)) {
                        _v.set(({
                            auto [v_p9, s2_pa] = crate::check::types::fresh_var_f(st1_p7, false, Text::lit(""));
                            std::tuple{v_p9, crate::check::types::unify::unify_f(s2_pa, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(v_p9)}), t_p6, prism_rtl::deref(scrut_p2x).span_p)};
                        }));
                        goto _done;
                    }
                    {
                        auto&& other_pb = walk_f_1656;
                        _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix_f(st1_p7, Text::lit("mismatch"), prism_rtl::deref(scrut_p2x).span_p, prism_rtl::cat("`rebuild` builds over a dynamic; this is `", crate::check::types::show_ty_f(st1_p7, other_pb), "`"), Text::lit("a plain value is built once: write the block\'s lines in place"))});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto env2_p5 = with_topic_f(env_p0x, Text::lit("_"), inner_pc);
                (crate::prelude::call_then(crate::check::blocks::start_infer_widget_block_f(env2_p5, st2_pd, body_p3x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block_f_2126) {
                return ({
                    auto [res_pe, st3_pf] = infer_widget_block_f_2126;
                    (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st3_pf, res_pe), [=](crate::check::types::Ty walk_f_2169) {
                    return ({
                        prism_rtl::is<crate::check::types::Ty::TyCon>(walk_f_2169) && ({
                        auto&& m2163_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2169).a0;
                        auto&& m2163_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2169).a1;
                        (m2163_0_0 == Text::lit("unit")) && (m2163_0_1.size() == 0u);
                    }) ? ({
                        auto&& m2163_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2169).a0;
                        auto&& m2163_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2169).a1;
                        prism_rtl::finished(std::tuple{crate::check::types::t_unit_p(), st3_pf});
                    })
                        : ({
                        auto&& other_pg = walk_f_2169;
                        prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(other_pg)}), st3_pf});
                    });
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start InferRebuild, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_rebuild_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr scrut_p2, crate::syntax::Block body_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<InferRebuild>(env_p0, st_p1, scrut_p2, body_p3, span_p4);
}


/// WithTopic: fn Env, Text, Ty -> Env
crate::check::expr::Env with_topic_f(const crate::check::expr::Env& env_p0, const Text& name_p1, const crate::check::types::Ty& t_p2) {
    crate::check::expr::Env this_ = crate::check::expr::with_local_f(env_p0, name_p1, crate::check::types::schemes::mono_f(t_p2));
    this_.pending_p = crate::prelude::filter(this_.pending_p, [&](const Text& x_p3) { return x_p3 != name_p1; });
    return this_;
}


/// InferFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_for_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const std::optional<crate::syntax::ForBinders>& binders_o2, const crate::syntax::Expr& source_p3, const crate::syntax::Block& body_p4, const crate::syntax::Range& span_p5) {
    return env_p0.in_update_p
        ? std::tuple{crate::check::types::t_unit_p(), crate::check::blocks::borrows::update_for_f(env_p0, st_p1, binders_o2, source_p3, body_p4, span_p5)}
        : ({
        auto [t_pb, st1_pc] = crate::check::expr::infer_f(env_p0, st_p1, source_p3);
        auto sh_p6 = crate::check::types::head_sigil_f(st1_pc, t_pb);
        auto coll_p7 = sh_p6 == Text::lit("$")
            ? crate::check::expr::inner_of_f(st1_pc, t_pb)
            : t_pb;
        auto st2_p8 = (sh_p6 == Text::lit("!")) || (sh_p6 == Text::lit("@"))
            ? crate::check::types::recording::err_f(st1_pc, Text::lit("mismatch"), source_p3.span_p, prism_rtl::cat("`for` runs over a map or an array, plain or dynamic; this is `", crate::check::types::show_ty_f(st1_pc, t_pb), "`"))
            : st1_pc;
        auto [k_pd, v_pe, st3_pf] = coll_parts_f(st2_p8, coll_p7, source_p3.span_p);
        auto live_p9 = sh_p6 == Text::lit("$");
        auto env1_pa = loop_indices_f(env_p0);
        auto [env2_pg, st4_ph] = bind_for_binders_f(env1_pa, st3_pf, binders_o2, k_pd, v_pe, live_p9);
        auto [res_pi, st5_pj] = crate::check::blocks::infer_widget_block_f(env2_pg, st4_ph, body_p4);
        gather_f(st5_pj, res_pi, k_pd, live_p9);
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferFor::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& binders_o2 = this->binders_o2;
    const auto& source_p3 = this->source_p3;
    const auto& body_p4 = this->body_p4;
    const auto& span_p5 = this->span_p5;
    return prism_rtl::deref(env_p0).in_update_p
        ? ({
        auto binders_o2x = binders_o2;
        auto body_p4x = body_p4;
        auto env_p0x = env_p0;
        auto source_p3x = source_p3;
        auto span_p5x = span_p5;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::blocks::borrows::start_update_for_f(env_p0x, st_p1x, binders_o2x, source_p3x, body_p4x, span_p5x), [=](crate::check::types::St update_for_f_2754) { return prism_rtl::finished(std::tuple{crate::check::types::t_unit_p(), update_for_f_2754}); }));
    })
        : ({
        auto binders_o2x = binders_o2;
        auto body_p4x = body_p4;
        auto env_p0x = env_p0;
        auto source_p3x = source_p3;
        auto span_p5x = span_p5;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, source_p3x), [=, binders_o2x = std::move(binders_o2x), body_p4x = std::move(body_p4x)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_2840) {
        return ({
            auto [t_pb, st1_pc] = infer_f_2840;
            (crate::prelude::call_then(crate::check::types::start_head_sigil_f(st1_pc, t_pb), [=](Text head_sigil_f_2879) {
            return ({
                auto sh_p6 = head_sigil_f_2879;
                auto coll_p7 = sh_p6 == Text::lit("$")
                    ? crate::check::expr::inner_of_f(st1_pc, t_pb)
                    : t_pb;
                auto st2_p8 = (sh_p6 == Text::lit("!")) || (sh_p6 == Text::lit("@"))
                    ? crate::check::types::recording::err_f(st1_pc, Text::lit("mismatch"), prism_rtl::deref(source_p3x).span_p, prism_rtl::cat("`for` runs over a map or an array, plain or dynamic; this is `", crate::check::types::show_ty_f(st1_pc, t_pb), "`"))
                    : st1_pc;
                (crate::prelude::call_then(start_coll_parts_f(st2_p8, coll_p7, prism_rtl::deref(source_p3x).span_p), [=, sh_p6 = std::move(sh_p6)](std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St> coll_parts_f_3150) {
                return ({
                    auto [k_pd, v_pe, st3_pf] = coll_parts_f_3150;
                    auto live_p9 = sh_p6 == Text::lit("$");
                    auto env1_pa = loop_indices_f(env_p0x);
                    (crate::prelude::call_then(start_bind_for_binders_f(env1_pa, st3_pf, binders_o2x, k_pd, v_pe, std::move(live_p9)), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_for_binders_f_3275) {
                    return ({
                        auto [env2_pg, st4_ph] = bind_for_binders_f_3275;
                        (crate::prelude::call_then(crate::check::blocks::start_infer_widget_block_f(env2_pg, st4_ph, body_p4x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block_f_3349) {
                        return ({
                            auto [res_pi, st5_pj] = infer_widget_block_f_3349;
                            (prism_rtl::more(prism_rtl::rc(Gather(st5_pj, res_pi, k_pd, live_p9))));
                        });
                    }));
                    });
                }));
                });
            }));
            });
        }));
        });
    }));
    });
}


/// `Start InferFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_for_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, std::optional<crate::syntax::ForBinders> binders_o2, crate::syntax::Expr source_p3, crate::syntax::Block body_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<InferFor>(env_p0, st_p1, binders_o2, source_p3, body_p4, span_p5);
}


/// CollParts: unbounded fn St, Ty, Range -> ((Ty, Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St> coll_parts_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1, const crate::syntax::Range& span_p2) {
    auto&& _m = crate::check::types::recording::walk_f(st_p0, t_p1);
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k_p3 = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_p4 = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return std::tuple{prism_rtl::deref(prism_rtl::deref(k_p3)), prism_rtl::deref(prism_rtl::deref(v_p4)), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& v_p5 = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        return std::tuple{crate::check::types::t_nat_p(), prism_rtl::deref(prism_rtl::deref(v_p5)), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m3542_2_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m3542_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m3542_2_0 == Text::lit("Buffer")) {
            if (m3542_2_1.size() == 1u) {
                {
                    auto&& _c1 = crate::prelude::index(m3542_2_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& v_p6 = prism_rtl::some_of(_c1);
                        return std::tuple{crate::check::types::t_nat_p(), v_p6, st_p0};
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        auto [v_p7, st2_p8] = crate::check::types::fresh_var_f(st_p0, false, Text::lit(""));
        return std::tuple{crate::check::types::t_nat_p(), v_p7, crate::check::types::unify::unify_f(st2_p8, crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_p7)}), t_p1, span_p2)};
    }
    {
        auto&& other_p9 = _m;
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p0, Text::lit("mismatch"), span_p2, prism_rtl::cat("`for` runs over a map or an array; this is `", crate::check::types::show_ty_f(st_p0, other_p9), "`"))};
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St>> CollParts::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    const auto& span_p2 = this->span_p2;
    auto span_p2x = span_p2;
    auto st_p0x = st_p0;
    auto t_p1x = t_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x, t_p1x), [=](crate::check::types::Ty walk_f_3548) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyMap>(walk_f_3548) ? ({
            auto&& k_p3 = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_f_3548).a0;
            auto&& v_p4 = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_f_3548).a1;
            prism_rtl::finished(std::tuple{prism_rtl::deref(prism_rtl::deref(k_p3)), prism_rtl::deref(prism_rtl::deref(v_p4)), st_p0x});
        })
            : prism_rtl::is<crate::check::types::Ty::TyArray>(walk_f_3548) ? ({
            auto&& v_p5 = prism_rtl::as<crate::check::types::Ty::TyArray>(walk_f_3548).a0;
            prism_rtl::finished(std::tuple{crate::check::types::t_nat_p(), prism_rtl::deref(prism_rtl::deref(v_p5)), st_p0x});
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_f_3548) && ({
            auto&& m3542_2_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_3548).a0;
            auto&& m3542_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_3548).a1;
            (m3542_2_0 == Text::lit("Buffer")) && (m3542_2_1.size() == 1u) && ({
            auto&& _c1 = crate::prelude::index(m3542_2_1, Nat(0u));
            prism_rtl::is_some(_c1);
        });
        }) ? ({
            auto&& m3542_2_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_3548).a0;
            auto&& m3542_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_3548).a1;
            auto&& _c1 = crate::prelude::index(m3542_2_1, Nat(0u));
            auto&& v_p6 = prism_rtl::some_of(_c1);
            prism_rtl::finished(std::tuple{crate::check::types::t_nat_p(), v_p6, st_p0x});
        })
            : prism_rtl::is<crate::check::types::Ty::TyErr>(walk_f_3548) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st_p0x})
            : prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_f_3548) ? ({
            auto [v_p7, st2_p8] = crate::check::types::fresh_var_f(st_p0x, false, Text::lit(""));
            (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_p8, crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_p7)}), t_p1x, span_p2x), [=](crate::check::types::St unify_f_3782) { return prism_rtl::finished(std::tuple{crate::check::types::t_nat_p(), v_p7, unify_f_3782}); }));
        })
            : ({
            auto&& other_p9 = walk_f_3548;
            ({
            auto other_p9x = other_p9;
            (crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p0x, other_p9x), [=](Text show_ty_f_3917) { return prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p0x, Text::lit("mismatch"), span_p2x, prism_rtl::cat("`for` runs over a map or an array; this is `", show_ty_f_3917, "`"))}); }));
        });
        });
        });
    });
}


/// `Start CollParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St>> start_coll_parts_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1, crate::syntax::Range span_p2) {
    return prism_rtl::make_rc<CollParts>(st_p0, t_p1, span_p2);
}


/// LoopIndices: fn Env -> Env
crate::check::expr::Env loop_indices_f(const crate::check::expr::Env& env_p0) {
    auto outer1_o1 = crate::prelude::get(env_p0.locals_p, Text::lit("ix"));
    auto outer2_o2 = crate::prelude::get(env_p0.locals_p, Text::lit("jx"));
    auto e1_p3 = crate::check::expr::with_local_f(env_p0, Text::lit("ix"), crate::check::types::schemes::mono_f(crate::check::types::t_nat_p()));
    auto e2_p4 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::expr::Env> _v;
        if (prism_rtl::is_some(outer1_o1)) {
            auto&& sc_p5 = prism_rtl::some_of(outer1_o1);
            _v.set(crate::check::expr::with_local_f(e1_p3, Text::lit("jx"), sc_p5));
            goto _done;
        }
        if (prism_rtl::is_none(outer1_o1)) {
            _v.set(e1_p3);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is_some(outer2_o2)) {
        auto&& sc_p6 = prism_rtl::some_of(outer2_o2);
        return crate::check::expr::with_local_f(e2_p4, Text::lit("kx"), sc_p6);
    }
    if (prism_rtl::is_none(outer2_o2)) {
        return e2_p4;
    }
    prism_rtl::unreachable("no arm matched");
}


/// BindForBinders: unbounded fn Env, St, ?ForBinders, Ty, Ty, Bool -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_for_binders_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const std::optional<crate::syntax::ForBinders>& binders_o2, const crate::check::types::Ty& k_p3, const crate::check::types::Ty& v_p4, const bool& live_p5) {
    auto inner_p6 = live_p5 && (crate::check::types::head_sigil_f(st_p1, v_p4) == Text::lit("$"));
    auto vt_p7 = live_p5 && (!std::move(inner_p6))
        ? crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(v_p4)})
        : v_p4;
    if (prism_rtl::is_none(binders_o2)) {
        auto e1_p8 = with_topic_f(env_p0, live_p5 ? Text::lit("$_") : Text::lit("_"), vt_p7);
        return std::tuple{with_topic_f(e1_p8, Text::lit("key"), k_p3), st_p1};
    }
    if (prism_rtl::is_some(binders_o2)) {
        auto&& bs_p9 = prism_rtl::some_of(binders_o2);
        auto&& _m = prism_rtl::deref(bs_p9).second_o;
        if (prism_rtl::is_some(_m)) {
            auto&& second_pa = prism_rtl::some_of(_m);
            auto [e1_pb, st1_pc] = crate::check::expr::patterns::bind_pattern_f(unpending_f(env_p0), st_p1, prism_rtl::deref(bs_p9).first_p, k_p3, false);
            auto [st2_pd, vt2_pe] = for_inner_mark_f(st1_pc, inner_p6, second_pa, v_p4, vt_p7);
            return crate::check::expr::patterns::bind_pattern_f(e1_pb, st2_pd, second_pa, vt2_pe, false);
        }
        if (prism_rtl::is_none(_m)) {
            auto e1_pf = with_topic_f(env_p0, Text::lit("key"), k_p3);
            auto [st2_pg, vt2_ph] = for_inner_mark_f(st_p1, inner_p6, prism_rtl::deref(bs_p9).first_p, v_p4, vt_p7);
            return crate::check::expr::patterns::bind_pattern_f(unpending_f(e1_pf), st2_pg, prism_rtl::deref(bs_p9).first_p, vt2_ph, false);
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindForBinders::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& binders_o2 = this->binders_o2;
    const auto& k_p3 = this->k_p3;
    const auto& v_p4 = this->v_p4;
    const auto& live_p5 = this->live_p5;
    auto inner_p6 = prism_rtl::deref(live_p5) && (crate::check::types::head_sigil_f(st_p1, v_p4) == Text::lit("$"));
    auto vt_p7 = prism_rtl::deref(live_p5) && (!std::move(inner_p6))
        ? crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(v_p4)})
        : v_p4;
    return ({
        prism_rtl::is_none(binders_o2) ? ({
        auto e1_p8 = with_topic_f(env_p0, prism_rtl::deref(live_p5) ? Text::lit("$_") : Text::lit("_"), vt_p7);
        (prism_rtl::finished(std::tuple{with_topic_f(e1_p8, Text::lit("key"), k_p3), st_p1}));
    })
        : prism_rtl::is_some(binders_o2) ? ({
        auto&& bs_p9 = prism_rtl::some_of(binders_o2);
        ({
        auto&& _m = prism_rtl::deref(bs_p9).second_o;
        prism_rtl::is_some(_m) ? ({
        auto&& second_pa = prism_rtl::some_of(_m);
        ({
        auto bs_p9x = bs_p9;
        auto env_p0x = env_p0;
        auto k_p3x = k_p3;
        auto second_pax = second_pa;
        auto st_p1x = st_p1;
        auto v_p4x = v_p4;
        (crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(unpending_f(env_p0x), st_p1x, prism_rtl::deref(bs_p9x).first_p, k_p3x, false), [=, second_pax = std::move(second_pax), v_p4x = std::move(v_p4x)](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_f_5167) {
        return ({
            auto [e1_pb, st1_pc] = bind_pattern_f_5167;
            auto [st2_pd, vt2_pe] = for_inner_mark_f(st1_pc, inner_p6, second_pax, v_p4x, vt_p7);
            (prism_rtl::more(prism_rtl::rc(crate::check::expr::patterns::BindPattern(e1_pb, st2_pd, second_pax, vt2_pe, false))));
        });
    }));
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto e1_pf = with_topic_f(env_p0, Text::lit("key"), k_p3);
        auto [st2_pg, vt2_ph] = for_inner_mark_f(st_p1, inner_p6, prism_rtl::deref(bs_p9).first_p, v_p4, vt_p7);
        (prism_rtl::more(prism_rtl::rc(crate::check::expr::patterns::BindPattern(unpending_f(e1_pf), st2_pg, prism_rtl::deref(bs_p9).first_p, vt2_ph, false))));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindForBinders, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_for_binders_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, std::optional<crate::syntax::ForBinders> binders_o2, crate::check::types::Ty k_p3, crate::check::types::Ty v_p4, bool live_p5) {
    return prism_rtl::make_rc<BindForBinders>(env_p0, st_p1, binders_o2, k_p3, v_p4, live_p5);
}


/// ForInnerMark: fn St, Bool, Pattern, Ty, Ty -> ((St, Ty))
std::tuple<crate::check::types::St, crate::check::types::Ty> for_inner_mark_f(const crate::check::types::St& st_p0, const bool& inner_p1, const crate::syntax::Pattern_& p_p2, const crate::check::types::Ty& v_p3, const crate::check::types::Ty& vt_p4) {
    auto&& _m = prism_rtl::deref(p_p2.kind_p);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p5 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return inner_p1 && (prism_rtl::deref(n_p5).sigils_p == Text::lit("$$"))
            ? ({
            auto name_p6 = crate::check::env::sname_key_f(n_p5);
            auto bare_p7 = crate::syntax::lexer::chars::drop_prefix_f(name_p6, Text::lit("$$"));
            std::tuple{crate::check::types::recording::err_fix_f(st_p0, Text::lit("mark-stack"), prism_rtl::deref(n_p5).span_p, prism_rtl::cat("`", name_p6, "` shows `$$`, a dynamic of a dynamic; a `for` over `$(k ==> $v)` binds the value under the row\'s key, which follows a replaced dynamic (Semantics ch. 4)"), prism_rtl::cat("write `$", bare_p7, "`, and read it where `@Flatten ", name_p6, "` was")), crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(v_p3)})};
        })
            : std::tuple{st_p0, vt_p4};
    }
    {
        return std::tuple{st_p0, vt_p4};
    }
}


/// Unpending: fn Env -> Env
crate::check::expr::Env unpending_f(const crate::check::expr::Env& env_p0) {
    crate::check::expr::Env this_ = env_p0;
    this_.pending_p = Array<Text>{};
    return this_;
}


/// Gather: unbounded fn St, Ty, Ty, Bool -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> gather_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& res_p1, const crate::check::types::Ty& k_p2, const bool& live_p3) {
    auto&& _m = crate::check::types::recording::walk_f(st_p0, res_p1);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m6848_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m6848_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m6848_0_0 == Text::lit("unit")) {
            if (m6848_0_1.size() == 0u) {
                return std::tuple{crate::check::types::t_unit_p(), st_p0};
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& m6848_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& t_p4 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (m6848_1_0 == Text::lit("!")) {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k_p2), prism_rtl::rc(prism_rtl::deref(t_p4))}))}), st_p0};
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& m6848_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& t_p5 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (m6848_2_0 == Text::lit("$")) {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k_p2), prism_rtl::rc(prism_rtl::deref(t_p5))}))}), st_p0};
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts_p6 = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_p6, false, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto seen_p7 = p0;
                    auto x_p8 = p1;
                    (prism_rtl::finished(std::move(seen_p7) || crate::check::expr::is_time_sigil_f(crate::check::types::head_sigil_f(st_p0xy, x_p8))));
                });
            })));
            });
        })));
        })))
            ? ({
            auto [parts_pe, st2_pf] = crate::prelude::run_to_end(crate::prelude::fold_job(ts_p6, std::tuple{Array<crate::check::types::Ty>{}, st_p0}, ({
                auto k_p2x = k_p2;
                auto live_p3x = live_p3;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::check::types::Ty>)>>(prism_rtl::rc([=, k_p2x = std::move(k_p2x), live_p3x = std::move(live_p3x)](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto k_p2xy = k_p2x;
                    auto live_p3xy = live_p3x;
                    (crate::prelude::entered(crate::prelude::once_job([=, k_p2xy = std::move(k_p2xy), live_p3xy = std::move(live_p3xy)]() {
                    return ({
                        auto [acc_p9, s_pa] = p0;
                        auto x_pb = p1;
                        (crate::prelude::call_then(start_gather_f(s_pa, x_pb, k_p2xy, live_p3xy), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> gather_f_7208) {
                        return ({
                            auto [g_pc, s2_pd] = gather_f_7208;
                            (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, g_pc), s2_pd}));
                        });
                    }));
                    });
                })));
                });
            }));
            })));
            std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyTuple{parts_pe}), st2_pf};
        })
            : std::tuple{live_map_f(live_p3, k_p2, crate::check::types::Ty(crate::check::types::Ty::TyTuple{ts_p6})), st_p0};
    }
    {
        auto&& other_pg = _m;
        return std::tuple{live_map_f(live_p3, k_p2, other_pg), st_p0};
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> Gather::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& res_p1 = this->res_p1;
    const auto& k_p2 = this->k_p2;
    const auto& live_p3 = this->live_p3;
    auto k_p2x = k_p2;
    auto live_p3x = prism_rtl::deref(live_p3);
    auto res_p1x = res_p1;
    auto st_p0x = st_p0;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x, res_p1x), [=](crate::check::types::Ty walk_f_6854) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_f_6854) && ({
            auto&& m6848_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_6854).a0;
            auto&& m6848_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_6854).a1;
            (m6848_0_0 == Text::lit("unit")) && (m6848_0_1.size() == 0u);
        }) ? ({
            auto&& m6848_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_6854).a0;
            auto&& m6848_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_6854).a1;
            prism_rtl::finished(std::tuple{crate::check::types::t_unit_p(), st_p0x});
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_f_6854) && ({
            auto&& m6848_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_6854).a0;
            auto&& t_p4 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_6854).a1;
            (m6848_1_0 == Text::lit("!"));
        }) ? ({
            auto&& m6848_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_6854).a0;
            auto&& t_p4 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_6854).a1;
            prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k_p2x), prism_rtl::rc(prism_rtl::deref(t_p4))}))}), st_p0x});
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_f_6854) && ({
            auto&& m6848_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_6854).a0;
            auto&& t_p5 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_6854).a1;
            (m6848_2_0 == Text::lit("$"));
        }) ? ({
            auto&& m6848_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_6854).a0;
            auto&& t_p5 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_6854).a1;
            prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k_p2x), prism_rtl::rc(prism_rtl::deref(t_p5))}))}), st_p0x});
        })
            : prism_rtl::is<crate::check::types::Ty::TyTuple>(walk_f_6854) ? ({
            auto&& ts_p6 = prism_rtl::as<crate::check::types::Ty::TyTuple>(walk_f_6854).a0;
            crate::prelude::call_value(crate::prelude::fold_job(ts_p6, false, ({
            auto st_p0xx = st_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xxy = st_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
                return ({
                    auto seen_p7 = p0;
                    auto x_p8 = p1;
                    (prism_rtl::finished(std::move(seen_p7) || crate::check::expr::is_time_sigil_f(crate::check::types::head_sigil_f(st_p0xxy, x_p8))));
                });
            })));
            });
        })));
        })), [=](bool fold_7037) {
            return fold_7037
                ? crate::prelude::call_value(crate::prelude::fold_job(ts_p6, std::tuple{Array<crate::check::types::Ty>{}, st_p0x}, ({
                auto k_p2xx = k_p2x;
                auto live_p3xx = live_p3x;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::check::types::Ty>)>>(prism_rtl::rc([=, k_p2xx = std::move(k_p2xx), live_p3xx = std::move(live_p3xx)](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto k_p2xxy = k_p2xx;
                    auto live_p3xxy = live_p3xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, k_p2xxy = std::move(k_p2xxy), live_p3xxy = std::move(live_p3xxy)]() {
                    return ({
                        auto [acc_p9, s_pa] = p0;
                        auto x_pb = p1;
                        (crate::prelude::call_then(start_gather_f(s_pa, x_pb, k_p2xxy, live_p3xxy), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> gather_f_7208) {
                        return ({
                            auto [g_pc, s2_pd] = gather_f_7208;
                            (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, g_pc), s2_pd}));
                        });
                    }));
                    });
                })));
                });
            }));
            })), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> fold_7136) {
                return ({
                    auto [parts_pe, st2_pf] = fold_7136;
                    (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyTuple{parts_pe}), st2_pf}));
                });
            })
                : prism_rtl::finished(std::tuple{live_map_f(live_p3x, k_p2x, crate::check::types::Ty(crate::check::types::Ty::TyTuple{ts_p6})), st_p0x});
        });
        })
            : ({
            auto&& other_pg = walk_f_6854;
            prism_rtl::finished(std::tuple{live_map_f(live_p3x, k_p2x, other_pg), st_p0x});
        });
        });
    });
}


/// `Start Gather, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_gather_f(crate::check::types::St st_p0, crate::check::types::Ty res_p1, crate::check::types::Ty k_p2, bool live_p3) {
    return prism_rtl::make_rc<Gather>(st_p0, res_p1, k_p2, live_p3);
}


/// LiveMap: fn Bool, Ty, Ty -> Ty
crate::check::types::Ty live_map_f(const bool& live_p0, const crate::check::types::Ty& k_p1, const crate::check::types::Ty& v_p2) {
    return live_p0
        ? crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k_p1), prism_rtl::rc(v_p2)}))})
        : crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k_p1), prism_rtl::rc(v_p2)});
}


/// InferGiven: unbounded fn Env, St, Block, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_given_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Block& b_p2, const crate::syntax::Range& span_p3) {
    auto mark_p4 = (env_p0.mark_p == Text::lit("?")) || (env_p0.mark_p == Text::lit("~"))
        ? env_p0.mark_p
        : given_mark_of_f(b_p2.stmts_p);
    return infer_given_block_f(env_p0, st_p1, b_p2, mark_p4);
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferGiven::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& b_p2 = this->b_p2;
    const auto& span_p3 = this->span_p3;
    auto mark_p4 = (prism_rtl::deref(env_p0).mark_p == Text::lit("?")) || (prism_rtl::deref(env_p0).mark_p == Text::lit("~"))
        ? prism_rtl::deref(env_p0).mark_p
        : given_mark_of_f(prism_rtl::deref(b_p2).stmts_p);
    return prism_rtl::more(prism_rtl::rc(InferGivenBlock(env_p0, st_p1, b_p2, mark_p4)));
}


/// `Start InferGiven, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_given_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<InferGiven>(env_p0, st_p1, b_p2, span_p3);
}


/// GivenMarkOf: fn [Stmt] -> Text
Text given_mark_of_f(const Array<crate::syntax::Stmt>& stmts_p0) {
    return crate::prelude::fold(stmts_p0, Text::lit("?"), [&](const Text& m_p1, const crate::syntax::Stmt& s_p2) { return m_p1; });
}


/// InferGivenBlock: unbounded fn Env, St, Block, Text -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_given_block_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Block& b_p2, const Text& mark_p3) {
    auto n_p4 = crate::prelude::len(b_p2.stmts_p);
    auto [env2_pa, st2_pb, res_oc] = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(n_p4), std::tuple{env_p0, st_p1, std::optional<crate::check::types::Ty>{}}, ({
        auto b_p2x = b_p2;
        auto mark_p3x = mark_p3;
        auto n_p4x = n_p4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>, Nat>)>>(prism_rtl::rc([=, b_p2x = std::move(b_p2x), mark_p3x = std::move(mark_p3x), n_p4x = std::move(n_p4x)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_p2xy = b_p2x;
            auto mark_p3xy = mark_p3x;
            auto n_p4xy = n_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, b_p2xy = std::move(b_p2xy), mark_p3xy = std::move(mark_p3xy), n_p4xy = std::move(n_p4xy)]() {
            return ({
                auto [en_p5, s_p6, r_o7] = p0;
                auto i_p8 = p1;
                ({
                auto stmt_p9 = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(b_p2xy).stmts_p, i_p8), crate::check::blocks::dummy_stmt2_p());
                (prism_rtl::more(prism_rtl::rc(GivenStmt(en_p5, s_p6, stmt_p9, mark_p3xy, (i_p8 + Nat(1u)) == n_p4xy, r_o7))));
            });
            });
        })));
        });
    }));
    })));
    if (prism_rtl::is_some(res_oc)) {
        auto&& t_pd = prism_rtl::some_of(res_oc);
        return std::tuple{t_pd, st2_pb};
    }
    if (prism_rtl::is_none(res_oc)) {
        auto [v_pe, st3_pf] = crate::check::types::fresh_var_f(st2_pb, false, Text::lit(""));
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{mark_p3, prism_rtl::rc(v_pe)}), st3_pf};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferGivenBlock::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& b_p2 = this->b_p2;
    const auto& mark_p3 = this->mark_p3;
    auto n_p4 = crate::prelude::len(prism_rtl::deref(b_p2).stmts_p);
    auto b_p2x = b_p2;
    auto env_p0x = env_p0;
    auto mark_p3x = mark_p3;
    auto st_p1x = st_p1;
    return crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(n_p4), std::tuple{env_p0x, st_p1x, std::optional<crate::check::types::Ty>{}}, ({
        auto b_p2xx = b_p2x;
        auto mark_p3xx = mark_p3x;
        auto n_p4x = n_p4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>, Nat>)>>(prism_rtl::rc([=, b_p2xx = std::move(b_p2xx), mark_p3xx = std::move(mark_p3xx), n_p4x = std::move(n_p4x)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_p2xxy = b_p2xx;
            auto mark_p3xxy = mark_p3xx;
            auto n_p4xy = n_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, b_p2xxy = std::move(b_p2xxy), mark_p3xxy = std::move(mark_p3xxy), n_p4xy = std::move(n_p4xy)]() {
            return ({
                auto [en_p5, s_p6, r_o7] = p0;
                auto i_p8 = p1;
                ({
                auto stmt_p9 = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(b_p2xxy).stmts_p, i_p8), crate::check::blocks::dummy_stmt2_p());
                (prism_rtl::more(prism_rtl::rc(GivenStmt(en_p5, s_p6, stmt_p9, mark_p3xxy, (i_p8 + Nat(1u)) == n_p4xy, r_o7))));
            });
            });
        })));
        });
    }));
    })), [=](std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>> fold_8405) {
        return ({
            auto [env2_pa, st2_pb, res_oc] = fold_8405;
            ({
            prism_rtl::is_some(res_oc) ? ({
            auto&& t_pd = prism_rtl::some_of(res_oc);
            prism_rtl::finished(std::tuple{t_pd, st2_pb});
        })
            : prism_rtl::is_none(res_oc) ? ({
            auto [v_pe, st3_pf] = crate::check::types::fresh_var_f(st2_pb, false, Text::lit(""));
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{mark_p3x, prism_rtl::rc(v_pe)}), st3_pf}));
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start InferGivenBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_given_block_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2, Text mark_p3) {
    return prism_rtl::make_rc<InferGivenBlock>(env_p0, st_p1, b_p2, mark_p3);
}


/// GivenStmt: unbounded fn Env, St, Stmt, Text, Bool, ?Ty -> ((Env, St, ?Ty))
std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>> given_stmt_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Stmt& s_p2, const Text& mark_p3, const bool& last_p4, const std::optional<crate::check::types::Ty>& res_o5) {
    auto&& _m = s_p2.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_p6 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e_p7 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto [t_p9, st1_pa] = crate::check::expr::infer_f(env_p0, st_p1, e_p7);
        auto [v_pb, st2_pc] = crate::check::types::fresh_var_f(st1_pa, false, Text::lit(""));
        auto st3_p8 = crate::check::types::unify::unify_f(st2_pc, crate::check::types::Ty(crate::check::types::Ty::TySig{mark_p3, prism_rtl::rc(v_pb)}), t_p9, prism_rtl::deref(e_p7).span_p);
        auto [env2_pd, st4_pe] = crate::check::expr::patterns::bind_pattern_f(unpending_f(env_p0), st3_p8, p_p6, v_pb, true);
        return std::tuple{env2_pd, st4_pe, res_o5};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m)) {
        auto&& c_pf = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
        return std::tuple{env_p0, crate::check::expr::lifting::check_cond_f(env_p0, st_p1, c_pf), res_o5};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m)) {
        auto&& c_pg = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
        return std::tuple{env_p0, crate::check::expr::lifting::check_cond_f(env_p0, st_p1, c_pg), res_o5};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ph = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_oi = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& e_pj = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto [env2_pk, st2_pl] = crate::check::expr::lets::check_let_f(env_p0, st_p1, p_ph, ty_oi, e_pj, s_p2.span_p);
        return std::tuple{env2_pk, st2_pl, res_o5};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f_pm = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        auto [env1_pn, st1_po] = crate::check::expr::lets::pre_bind_f(env_p0, st_p1, s_p2);
        auto [env2_pp, st2_pq] = crate::check::expr::lets::check_local_fn_f(env1_pn, st1_po, f_pm, s_p2.span_p);
        return std::tuple{env2_pp, st2_pq, res_o5};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        auto [env2_pr, st2_ps] = crate::check::expr::lets::pre_bind_f(env_p0, st_p1, s_p2);
        return std::tuple{env2_pr, st2_ps, res_o5};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e_pt = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return last_p4
            ? ({
            auto [t_pv, st1_p10] = crate::check::expr::infer_f(env_p0, st_p1, e_pt);
            auto [v_p11, st2_p12] = crate::check::types::fresh_var_f(st1_p10, false, Text::lit(""));
            auto st3_pu = crate::check::types::unify::unify_f(st2_p12, crate::check::types::Ty(crate::check::types::Ty::TySig{mark_p3, prism_rtl::rc(v_p11)}), t_pv, prism_rtl::deref(e_pt).span_p);
            std::tuple{env_p0, st3_pu, std::optional(crate::check::types::Ty(crate::check::types::Ty::TySig{mark_p3, prism_rtl::rc(v_p11)}))};
        })
            : ({
            auto [t_p13, st1_p14] = crate::check::expr::infer_f(env_p0, st_p1, e_pt);
            std::tuple{env_p0, crate::check::blocks::discarded_f(st1_p14, t_p13, prism_rtl::deref(e_pt).span_p), res_o5};
        });
    }
    {
        return std::tuple{env_p0, crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), s_p2.span_p, Text::lit("this statement belongs in a widget or `update` block")), res_o5};
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>> GivenStmt::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& s_p2 = this->s_p2;
    const auto& mark_p3 = this->mark_p3;
    const auto& last_p4 = this->last_p4;
    const auto& res_o5 = this->res_o5;
    return ({
        auto&& _m = prism_rtl::deref(s_p2).kind_p;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_p6 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e_p7 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        ({
        auto res_o5x = res_o5;
        auto e_p7x = e_p7;
        auto env_p0x = env_p0;
        auto mark_p3x = mark_p3;
        auto p_p6x = p_p6;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, e_p7x), [=, res_o5x = std::move(res_o5x), mark_p3x = std::move(mark_p3x), p_p6x = std::move(p_p6x)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_8880) {
        return ({
            auto [t_p9, st1_pa] = infer_f_8880;
            auto [v_pb, st2_pc] = crate::check::types::fresh_var_f(st1_pa, false, Text::lit(""));
            (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pc, crate::check::types::Ty(crate::check::types::Ty::TySig{mark_p3x, prism_rtl::rc(v_pb)}), t_p9, prism_rtl::deref(e_p7x).span_p), [=](crate::check::types::St unify_f_8964) {
            return ({
                auto st3_p8 = unify_f_8964;
                (crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(unpending_f(env_p0x), st3_p8, p_p6x, v_pb, true), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_f_9030) {
                return ({
                    auto [env2_pd, st4_pe] = bind_pattern_f_9030;
                    (prism_rtl::finished(std::tuple{env2_pd, st4_pe, res_o5x}));
                });
            }));
            });
        }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m) ? ({
        auto&& c_pf = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
        ({
        auto res_o5x = res_o5;
        auto c_pfx = c_pf;
        auto env_p0x = env_p0;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::expr::lifting::start_check_cond_f(env_p0x, st_p1x, c_pfx), [=, res_o5x = std::move(res_o5x)](crate::check::types::St check_cond_f_9127) { return prism_rtl::finished(std::tuple{env_p0x, check_cond_f_9127, res_o5x}); }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m) ? ({
        auto&& c_pg = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
        ({
        auto res_o5x = res_o5;
        auto c_pgx = c_pg;
        auto env_p0x = env_p0;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::expr::lifting::start_check_cond_f(env_p0x, st_p1x, c_pgx), [=, res_o5x = std::move(res_o5x)](crate::check::types::St check_cond_f_9180) { return prism_rtl::finished(std::tuple{env_p0x, check_cond_f_9180, res_o5x}); }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ph = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_oi = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& e_pj = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto res_o5x = res_o5;
        auto ty_oix = ty_oi;
        auto e_pjx = e_pj;
        auto env_p0x = env_p0;
        auto p_phx = p_ph;
        auto s_p2x = s_p2;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::expr::lets::start_check_let_f(env_p0x, st_p1x, p_phx, ty_oix, e_pjx, prism_rtl::deref(s_p2x).span_p), [=, res_o5x = std::move(res_o5x)](std::tuple<crate::check::expr::Env, crate::check::types::St> check_let_f_9258) {
        return ({
            auto [env2_pk, st2_pl] = check_let_f_9258;
            (prism_rtl::finished(std::tuple{env2_pk, st2_pl, res_o5x}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f_pm = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        ({
        auto res_o5x = res_o5;
        auto env_p0x = env_p0;
        auto f_pmx = f_pm;
        auto s_p2x = s_p2;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::expr::lets::start_pre_bind_f(env_p0x, st_p1x, s_p2x), [=, res_o5x = std::move(res_o5x), f_pmx = std::move(f_pmx)](std::tuple<crate::check::expr::Env, crate::check::types::St> pre_bind_f_9361) {
        return ({
            auto [env1_pn, st1_po] = pre_bind_f_9361;
            (crate::prelude::call_then(crate::check::expr::lets::start_check_local_fn_f(env1_pn, st1_po, f_pmx, prism_rtl::deref(s_p2x).span_p), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> check_local_fn_f_9408) {
            return ({
                auto [env2_pp, st2_pq] = check_local_fn_f_9408;
                (prism_rtl::finished(std::tuple{env2_pp, st2_pq, res_o5x}));
            });
        }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? ({
        auto res_o5x = res_o5;
        auto env_p0x = env_p0;
        auto s_p2x = s_p2;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::expr::lets::start_pre_bind_f(env_p0x, st_p1x, s_p2x), [=, res_o5x = std::move(res_o5x)](std::tuple<crate::check::expr::Env, crate::check::types::St> pre_bind_f_9521) {
        return ({
            auto [env2_pr, st2_ps] = pre_bind_f_9521;
            (prism_rtl::finished(std::tuple{env2_pr, st2_ps, res_o5x}));
        });
    }));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& e_pt = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        prism_rtl::deref(last_p4)
        ? ({
        auto e_ptx = e_pt;
        auto env_p0x = env_p0;
        auto last_p4x = prism_rtl::deref(last_p4);
        auto mark_p3x = mark_p3;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, e_ptx), [=, mark_p3x = std::move(mark_p3x)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_9627) {
        return ({
            auto [t_pv, st1_p10] = infer_f_9627;
            auto [v_p11, st2_p12] = crate::check::types::fresh_var_f(st1_p10, false, Text::lit(""));
            (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_p12, crate::check::types::Ty(crate::check::types::Ty::TySig{mark_p3x, prism_rtl::rc(v_p11)}), t_pv, prism_rtl::deref(e_ptx).span_p), [=](crate::check::types::St unify_f_9719) {
            return ({
                auto st3_pu = unify_f_9719;
                (prism_rtl::finished(std::tuple{env_p0x, st3_pu, std::optional(crate::check::types::Ty(crate::check::types::Ty::TySig{mark_p3x, prism_rtl::rc(v_p11)}))}));
            });
        }));
        });
    }));
    })
        : ({
        auto res_o5x = res_o5;
        auto e_ptx = e_pt;
        auto env_p0x = env_p0;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, e_ptx), [=, res_o5x = std::move(res_o5x)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_9986) {
        return ({
            auto [t_p13, st1_p14] = infer_f_9986;
            (crate::prelude::call_then(crate::check::blocks::start_discarded_f(st1_p14, t_p13, prism_rtl::deref(e_ptx).span_p), [=](crate::check::types::St discarded_f_10023) { return prism_rtl::finished(std::tuple{env_p0x, discarded_f_10023, res_o5x}); }));
        });
    }));
    });
    })
        : prism_rtl::finished(std::tuple{env_p0, crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), prism_rtl::deref(s_p2).span_p, Text::lit("this statement belongs in a widget or `update` block")), res_o5});
    });
}


/// `Start GivenStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>> start_given_stmt_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Stmt s_p2, Text mark_p3, bool last_p4, std::optional<crate::check::types::Ty> res_o5) {
    return prism_rtl::make_rc<GivenStmt>(env_p0, st_p1, s_p2, mark_p3, last_p4, res_o5);
}

}  // namespace crate::check::blocks::structure
