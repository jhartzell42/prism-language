// The module `Emit`, from `target/bootstrap/cpp-src/prismc/emit.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include "emit.hpp"
#include "ast.hpp"
#include "check_env.hpp"
#include "check_errors.hpp"
#include "check_types.hpp"
#include "lexer.hpp"
#include "lower.hpp"
#include "prelude_template.hpp"
#include "rust_templates.hpp"
#include "typed.hpp"
#include "check_env.generic.hpp"
#include "lexer.generic.hpp"
#include "lower.generic.hpp"

namespace crate::emit {

/// Type: unbounded fn OutTy -> Text
Text type_(const lower::OutTy& t) {
    if (prism_rtl::is<lower::OutTy::OutNat>(t)) {
        return Text::lit("Nat");
    }
    if (prism_rtl::is<lower::OutTy::OutInt>(t)) {
        return Text::lit("Int");
    }
    if (prism_rtl::is<lower::OutTy::OutU8>(t)) {
        return Text::lit("u8");
    }
    if (prism_rtl::is<lower::OutTy::OutFloat>(t)) {
        return Text::lit("f64");
    }
    if (prism_rtl::is<lower::OutTy::OutBool>(t)) {
        return Text::lit("bool");
    }
    if (prism_rtl::is<lower::OutTy::OutChar>(t)) {
        return Text::lit("char");
    }
    if (prism_rtl::is<lower::OutTy::OutText>(t)) {
        return Text::lit("Text");
    }
    if (prism_rtl::is<lower::OutTy::OutCursor>(t)) {
        return Text::lit("Cursor");
    }
    if (prism_rtl::is<lower::OutTy::OutUnit>(t)) {
        return Text::lit("()");
    }
    if (prism_rtl::is<lower::OutTy::OutPath>(t)) {
        return Text::lit("Path");
    }
    if (prism_rtl::is<lower::OutTy::OutDuration>(t)) {
        return Text::lit("Duration");
    }
    if (prism_rtl::is<lower::OutTy::OutError>(t)) {
        return Text::lit("Error");
    }
    if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m1006_12_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        if (m1006_12_1.size() == 0u) {
            return n;
        }
    }
    if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& args_ = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        return prism_rtl::cat(n, "<", types(args_), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutOpt>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutOpt>(t).a0;
        return prism_rtl::cat("Option<", type_(i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutRes>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutRes>(t).a0;
        return prism_rtl::cat("Result<", type_(i), ", Error>");
    }
    if (prism_rtl::is<lower::OutTy::OutTuple>(t)) {
        auto&& m1006_16_0 = prism_rtl::as<lower::OutTy::OutTuple>(t).a0;
        if (m1006_16_0.size() == 1u) {
            {
                auto&& _c1 = index(m1006_16_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one = prism_rtl::some_of(_c1);
                    return prism_rtl::cat("(", type_(one), ",)");
                }
            }
        }
    }
    if (prism_rtl::is<lower::OutTy::OutTuple>(t)) {
        auto&& ts = prism_rtl::as<lower::OutTy::OutTuple>(t).a0;
        return prism_rtl::cat("(", types(ts), ")");
    }
    if (prism_rtl::is<lower::OutTy::OutArray>(t)) {
        auto&& e = prism_rtl::as<lower::OutTy::OutArray>(t).a0;
        return prism_rtl::cat("Array<", type_(e), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutMap>(t)) {
        auto&& k = prism_rtl::as<lower::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<lower::OutTy::OutMap>(t).a1;
        return prism_rtl::cat("Map<", type_(k), ", ", type_(v_), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutFn>(t)) {
        auto&& ps = prism_rtl::as<lower::OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<lower::OutTy::OutFn>(t).a1;
        return prism_rtl::cat("Rc<dyn Fn(", ref_types(ps), ") -> ", type_(r), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutRef>(t)) {
        auto&& m1006_21_0 = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
        if (prism_rtl::is<lower::OutTy::OutFn>(m1006_21_0)) {
            auto&& ps = prism_rtl::as<lower::OutTy::OutFn>(m1006_21_0).a0;
            auto&& r = prism_rtl::as<lower::OutTy::OutFn>(m1006_21_0).a1;
            return prism_rtl::cat("&dyn Fn(", ref_types(ps), ") -> ", type_(r));
        }
    }
    if (prism_rtl::is<lower::OutTy::OutRef>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
        return prism_rtl::cat("&", type_(i));
    }
    if (prism_rtl::is<lower::OutTy::OutJobFn>(t)) {
        auto&& a = prism_rtl::as<lower::OutTy::OutJobFn>(t).a0;
        auto&& b = prism_rtl::as<lower::OutTy::OutJobFn>(t).a1;
        return prism_rtl::cat("Rc<dyn Fn(", type_(a), ") -> Rc<dyn prism_rtl::Job<", type_(b), ">>>");
    }
    if (prism_rtl::is<lower::OutTy::OutJob>(t)) {
        auto&& b = prism_rtl::as<lower::OutTy::OutJob>(t).a0;
        return prism_rtl::cat("Rc<dyn prism_rtl::Job<", type_(b), ">>");
    }
    if (prism_rtl::is<lower::OutTy::OutEvent>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutEvent>(t).a0;
        return prism_rtl::cat("Event<", type_(i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutDyn>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutDyn>(t).a0;
        return prism_rtl::cat("Dynamic<", type_(i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutGen>(t)) {
        auto&& n = prism_rtl::as<lower::OutTy::OutGen>(t).a0;
        return n;
    }
    if (prism_rtl::is<lower::OutTy::OutRc>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutRc>(t).a0;
        return prism_rtl::cat("Rc<", type_(i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutPod>(t)) {
        return Text::lit("Pod");
    }
    if (prism_rtl::is<lower::OutTy::OutShowAny>(t)) {
        return Text::lit("Rc<dyn Show>");
    }
    if (prism_rtl::is<lower::OutTy::OutHold>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutHold>(t).a0;
        return prism_rtl::cat("Hold<", type_(i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutStamped>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutStamped>(t).a0;
        return prism_rtl::cat("Stamped<", type_(i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutSnapshot>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutSnapshot>(t).a0;
        return prism_rtl::cat("Snapshot<", type_(i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutDefer>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutDefer>(t).a0;
        return prism_rtl::cat("Defer<", type_(i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutWeak>(t)) {
        auto&& n = prism_rtl::as<lower::OutTy::OutWeak>(t).a0;
        return prism_rtl::cat("Weak<", n, ">");
    }
    if (prism_rtl::is<lower::OutTy::OutCell>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutCell>(t).a0;
        return prism_rtl::cat("RefCell<", type_(i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutWakes>(t)) {
        return Text::lit("Wakes");
    }
    if (prism_rtl::is<lower::OutTy::OutCount>(t)) {
        return Text::lit("u32");
    }
    if (prism_rtl::is<lower::OutTy::OutObj>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutObj>(t).a0;
        return prism_rtl::cat("Rc<dyn ", type_(i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutSlice>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutSlice>(t).a0;
        return prism_rtl::cat("[", type_(i), "]");
    }
    if (prism_rtl::is<lower::OutTy::OutPort>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutPort>(t).a0;
        return prism_rtl::cat("Port<", type_(i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutLive>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutLive>(t).a0;
        return prism_rtl::cat("Live<", type_(i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutUnknown>(t)) {
        auto&& what = prism_rtl::as<lower::OutTy::OutUnknown>(t).a0;
        return prism_rtl::cat("() /* ", what, " */");
    }
    if (prism_rtl::is<lower::OutTy::OutQuantified>(t)) {
        auto&& b = prism_rtl::as<lower::OutTy::OutQuantified>(t).a0;
        return prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), "a quantified type variable of `", b, "`: no instantiation gives it a type\")");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> Type::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<lower::OutTy::OutNat>(t) ? prism_rtl::finished(Text::lit("Nat"))
        : prism_rtl::is<lower::OutTy::OutInt>(t) ? prism_rtl::finished(Text::lit("Int"))
        : prism_rtl::is<lower::OutTy::OutU8>(t) ? prism_rtl::finished(Text::lit("u8"))
        : prism_rtl::is<lower::OutTy::OutFloat>(t) ? prism_rtl::finished(Text::lit("f64"))
        : prism_rtl::is<lower::OutTy::OutBool>(t) ? prism_rtl::finished(Text::lit("bool"))
        : prism_rtl::is<lower::OutTy::OutChar>(t) ? prism_rtl::finished(Text::lit("char"))
        : prism_rtl::is<lower::OutTy::OutText>(t) ? prism_rtl::finished(Text::lit("Text"))
        : prism_rtl::is<lower::OutTy::OutCursor>(t) ? prism_rtl::finished(Text::lit("Cursor"))
        : prism_rtl::is<lower::OutTy::OutUnit>(t) ? prism_rtl::finished(Text::lit("()"))
        : prism_rtl::is<lower::OutTy::OutPath>(t) ? prism_rtl::finished(Text::lit("Path"))
        : prism_rtl::is<lower::OutTy::OutDuration>(t) ? prism_rtl::finished(Text::lit("Duration"))
        : prism_rtl::is<lower::OutTy::OutError>(t) ? prism_rtl::finished(Text::lit("Error"))
        : prism_rtl::is<lower::OutTy::OutNamed>(t) && ({
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m1006_12_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        (m1006_12_1.size() == 0u);
    }) ? ({
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m1006_12_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<lower::OutTy::OutNamed>(t) ? ({
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& args_ = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        ({
        auto args__1 = args_;
        auto n_2 = n;
        call_then(start_types(args__1), [=](Text types_1311) { return prism_rtl::finished(prism_rtl::cat(n_2, "<", types_1311, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutOpt>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutOpt>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__1348) { return prism_rtl::finished(prism_rtl::cat("Option<", type__1348, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutRes>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutRes>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__1381) { return prism_rtl::finished(prism_rtl::cat("Result<", type__1381, ", Error>")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutTuple>(t) && ({
        auto&& m1006_16_0 = prism_rtl::as<lower::OutTy::OutTuple>(t).a0;
        (m1006_16_0.size() == 1u) && ({
        auto&& _c1 = index(m1006_16_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m1006_16_0 = prism_rtl::as<lower::OutTy::OutTuple>(t).a0;
        auto&& _c1 = index(m1006_16_0, Nat(0u));
        auto&& one = prism_rtl::some_of(_c1);
        call_then(start_type_(one), [=](Text type__1423) { return prism_rtl::finished(prism_rtl::cat("(", type__1423, ",)")); });
    })
        : prism_rtl::is<lower::OutTy::OutTuple>(t) ? ({
        auto&& ts = prism_rtl::as<lower::OutTy::OutTuple>(t).a0;
        ({
        auto ts_1 = ts;
        call_then(start_types(ts_1), [=](Text types_1456) { return prism_rtl::finished(prism_rtl::cat("(", types_1456, ")")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutArray>(t) ? ({
        auto&& e = prism_rtl::as<lower::OutTy::OutArray>(t).a0;
        ({
        auto e_1 = e;
        call_then(start_type_(e_1), [=](Text type__1492) { return prism_rtl::finished(prism_rtl::cat("Array<", type__1492, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutMap>(t) ? ({
        auto&& k = prism_rtl::as<lower::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<lower::OutTy::OutMap>(t).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_type_(k_1), [=](Text type__1525) { return call_then(start_type_(v__2), [=](Text type__1535) { return prism_rtl::finished(prism_rtl::cat("Map<", type__1525, ", ", type__1535, ">")); }); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutFn>(t) ? ({
        auto&& ps = prism_rtl::as<lower::OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<lower::OutTy::OutFn>(t).a1;
        ({
        auto ps_1 = ps;
        auto r_2 = r;
        call_then(start_ref_types(ps_1), [=](Text ref_types_1574) { return call_then(start_type_(r_2), [=](Text type__1592) { return prism_rtl::finished(prism_rtl::cat("Rc<dyn Fn(", ref_types_1574, ") -> ", type__1592, ">")); }); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutRef>(t) && ({
        auto&& m1006_21_0 = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
        prism_rtl::is<lower::OutTy::OutFn>(m1006_21_0);
    }) ? ({
        auto&& m1006_21_0 = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
        auto&& ps = prism_rtl::as<lower::OutTy::OutFn>(m1006_21_0).a0;
        auto&& r = prism_rtl::as<lower::OutTy::OutFn>(m1006_21_0).a1;
        ({
        auto ps_1 = ps;
        auto r_2 = r;
        call_then(start_ref_types(ps_1), [=](Text ref_types_1638) { return call_then(start_type_(r_2), [=](Text type__1656) { return prism_rtl::finished(prism_rtl::cat("&dyn Fn(", ref_types_1638, ") -> ", type__1656)); }); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutRef>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__1682) { return prism_rtl::finished(prism_rtl::cat("&", type__1682)); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutJobFn>(t) ? ({
        auto&& a = prism_rtl::as<lower::OutTy::OutJobFn>(t).a0;
        auto&& b = prism_rtl::as<lower::OutTy::OutJobFn>(t).a1;
        ({
        auto a_1 = a;
        auto b_2 = b;
        call_then(start_type_(a_1), [=](Text type__1722) { return call_then(start_type_(b_2), [=](Text type__1757) { return prism_rtl::finished(prism_rtl::cat("Rc<dyn Fn(", type__1722, ") -> Rc<dyn prism_rtl::Job<", type__1757, ">>>")); }); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutJob>(t) ? ({
        auto&& b = prism_rtl::as<lower::OutTy::OutJob>(t).a0;
        ({
        auto b_1 = b;
        call_then(start_type_(b_1), [=](Text type__1807) { return prism_rtl::finished(prism_rtl::cat("Rc<dyn prism_rtl::Job<", type__1807, ">>")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutEvent>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutEvent>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__1842) { return prism_rtl::finished(prism_rtl::cat("Event<", type__1842, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutDyn>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutDyn>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__1876) { return prism_rtl::finished(prism_rtl::cat("Dynamic<", type__1876, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutGen>(t) ? ({
        auto&& n = prism_rtl::as<lower::OutTy::OutGen>(t).a0;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<lower::OutTy::OutRc>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutRc>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__1920) { return prism_rtl::finished(prism_rtl::cat("Rc<", type__1920, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutPod>(t) ? prism_rtl::finished(Text::lit("Pod"))
        : prism_rtl::is<lower::OutTy::OutShowAny>(t) ? prism_rtl::finished(Text::lit("Rc<dyn Show>"))
        : prism_rtl::is<lower::OutTy::OutHold>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutHold>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2001) { return prism_rtl::finished(prism_rtl::cat("Hold<", type__2001, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutStamped>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutStamped>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2039) { return prism_rtl::finished(prism_rtl::cat("Stamped<", type__2039, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutSnapshot>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutSnapshot>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2079) { return prism_rtl::finished(prism_rtl::cat("Snapshot<", type__2079, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutDefer>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutDefer>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2113) { return prism_rtl::finished(prism_rtl::cat("Defer<", type__2113, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutWeak>(t) ? ({
        auto&& n = prism_rtl::as<lower::OutTy::OutWeak>(t).a0;
        prism_rtl::finished(prism_rtl::cat("Weak<", n, ">"));
    })
        : prism_rtl::is<lower::OutTy::OutCell>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutCell>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2175) { return prism_rtl::finished(prism_rtl::cat("RefCell<", type__2175, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutWakes>(t) ? prism_rtl::finished(Text::lit("Wakes"))
        : prism_rtl::is<lower::OutTy::OutCount>(t) ? prism_rtl::finished(Text::lit("u32"))
        : prism_rtl::is<lower::OutTy::OutObj>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutObj>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2250) { return prism_rtl::finished(prism_rtl::cat("Rc<dyn ", type__2250, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutSlice>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutSlice>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2279) { return prism_rtl::finished(prism_rtl::cat("[", type__2279, "]")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutPort>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutPort>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2311) { return prism_rtl::finished(prism_rtl::cat("Port<", type__2311, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutLive>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutLive>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2343) { return prism_rtl::finished(prism_rtl::cat("Live<", type__2343, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutUnknown>(t) ? ({
        auto&& what = prism_rtl::as<lower::OutTy::OutUnknown>(t).a0;
        prism_rtl::finished(prism_rtl::cat("() /* ", what, " */"));
    })
        : prism_rtl::is<lower::OutTy::OutQuantified>(t) ? ({
        auto&& b = prism_rtl::as<lower::OutTy::OutQuantified>(t).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), "a quantified type variable of `", b, "`: no instantiation gives it a type\")"));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Type, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_type_(lower::OutTy t) {
    return prism_rtl::make_rc<Type>(t);
}


/// Types: unbounded fn [OutTy] -> Text
Text types(const Array<lower::OutTy>& ts) {
    return lexer::join(run_to_end(each_job(ts, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::OutTy)>>(prism_rtl::rc([=](lower::OutTy p0) {
        return entered(once_job([=]() {
            return ({
                auto t = p0;
                (prism_rtl::more(prism_rtl::rc(Type(t))));
            });
        }));
    })))), Text::lit(", "));
}


prism_rtl::Turn<Text> Types::cycle() const {
    const auto& ts = this->ts;
    auto ts_1 = ts;
    return call_value(each_job(ts_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::OutTy)>>(prism_rtl::rc([=](lower::OutTy p0) {
        return entered(once_job([=]() {
            return ({
                auto t = p0;
                (prism_rtl::more(prism_rtl::rc(Type(t))));
            });
        }));
    }))), [=](Array<Text> each_2579) { return prism_rtl::finished(lexer::join(each_2579, Text::lit(", "))); });
}


/// `Start Types, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_types(Array<lower::OutTy> ts) {
    return prism_rtl::make_rc<Types>(ts);
}


/// RefTypes: unbounded fn [OutTy] -> Text
Text ref_types(const Array<lower::OutTy>& ts) {
    return lexer::join(run_to_end(each_job(ts, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::OutTy)>>(prism_rtl::rc([=](lower::OutTy p0) {
        return entered(once_job([=]() {
            return ({
                auto t = p0;
                call_then(start_type_(t), [=](Text type__2687) { return prism_rtl::finished(prism_rtl::cat("&", type__2687)); });
            });
        }));
    })))), Text::lit(", "));
}


prism_rtl::Turn<Text> RefTypes::cycle() const {
    const auto& ts = this->ts;
    auto ts_1 = ts;
    return call_value(each_job(ts_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::OutTy)>>(prism_rtl::rc([=](lower::OutTy p0) {
        return entered(once_job([=]() {
            return ({
                auto t = p0;
                call_then(start_type_(t), [=](Text type__2687) { return prism_rtl::finished(prism_rtl::cat("&", type__2687)); });
            });
        }));
    }))), [=](Array<Text> each_2670) { return prism_rtl::finished(lexer::join(each_2670, Text::lit(", "))); });
}


/// `Start RefTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ref_types(Array<lower::OutTy> ts) {
    return prism_rtl::make_rc<RefTypes>(ts);
}


/// IsLoose: fn Ex -> Bool
bool is_loose(const lower::Ex& x) {
    if (prism_rtl::is<lower::Ex::XBlock>(x)) {
        auto&& m3012_0_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& inner = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        if (m3012_0_0.size() == 0u) {
            return is_loose(inner);
        }
    }
    if (prism_rtl::is<lower::Ex::XTyped>(x)) {
        auto&& inner = prism_rtl::as<lower::Ex::XTyped>(x).a0;
        return is_loose(inner);
    }
    if (prism_rtl::is<lower::Ex::XBin>(x)) {
        return true;
    }
    if (prism_rtl::is<lower::Ex::XUnary>(x)) {
        return true;
    }
    if (prism_rtl::is<lower::Ex::XClosure>(x)) {
        return true;
    }
    if (prism_rtl::is<lower::Ex::XIf>(x)) {
        return true;
    }
    if (prism_rtl::is<lower::Ex::XMatch>(x)) {
        return true;
    }
    if (prism_rtl::is<lower::Ex::XChain>(x)) {
        return true;
    }
    if (prism_rtl::is<lower::Ex::XCast>(x)) {
        return true;
    }
    if (prism_rtl::is<lower::Ex::XRef>(x)) {
        return true;
    }
    if (prism_rtl::is<lower::Ex::XRefMut>(x)) {
        return true;
    }
    if (prism_rtl::is<lower::Ex::XDeref>(x)) {
        return true;
    }
    {
        return false;
    }
}


/// Tight: unbounded fn Ex -> Text
Text tight(const lower::Ex& x) {
    return is_loose(x) ? prism_rtl::cat("(", expression(x), ")") : expression(x);
}


prism_rtl::Turn<Text> Tight::cycle() const {
    const auto& x = this->x;
    return is_loose(x)
        ? ({
        auto x_1 = x;
        call_then(start_expression(x_1), [=](Text expression_3529) { return prism_rtl::finished(prism_rtl::cat("(", expression_3529, ")")); });
    })
        : prism_rtl::more(prism_rtl::rc(Expression(x)));
}


/// `Start Tight, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_tight(lower::Ex x) {
    return prism_rtl::make_rc<Tight>(x);
}


/// Operand: unbounded fn Ex -> Text
Text operand(const lower::Ex& x) {
    if (prism_rtl::is<lower::Ex::XBlock>(x)) {
        auto&& m3613_0_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& inner = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        if (m3613_0_0.size() == 0u) {
            return operand(inner);
        }
    }
    if (prism_rtl::is<lower::Ex::XTyped>(x)) {
        auto&& inner = prism_rtl::as<lower::Ex::XTyped>(x).a0;
        return operand(inner);
    }
    if (prism_rtl::is<lower::Ex::XBin>(x)) {
        return prism_rtl::cat("(", expression(x), ")");
    }
    if (prism_rtl::is<lower::Ex::XClosure>(x)) {
        return prism_rtl::cat("(", expression(x), ")");
    }
    if (prism_rtl::is<lower::Ex::XIf>(x)) {
        return prism_rtl::cat("(", expression(x), ")");
    }
    if (prism_rtl::is<lower::Ex::XCast>(x)) {
        return prism_rtl::cat("(", expression(x), ")");
    }
    {
        return expression(x);
    }
}


prism_rtl::Turn<Text> Operand::cycle() const {
    const auto& x = this->x;
    return ({
        prism_rtl::is<lower::Ex::XBlock>(x) && ({
        auto&& m3613_0_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& inner = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        (m3613_0_0.size() == 0u);
    }) ? ({
        auto&& m3613_0_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& inner = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        prism_rtl::more(prism_rtl::rc(Operand(inner)));
    })
        : prism_rtl::is<lower::Ex::XTyped>(x) ? ({
        auto&& inner = prism_rtl::as<lower::Ex::XTyped>(x).a0;
        prism_rtl::more(prism_rtl::rc(Operand(inner)));
    })
        : prism_rtl::is<lower::Ex::XBin>(x) ? ({
        auto x_1 = x;
        call_then(start_expression(x_1), [=](Text expression_3736) { return prism_rtl::finished(prism_rtl::cat("(", expression_3736, ")")); });
    })
        : prism_rtl::is<lower::Ex::XClosure>(x) ? ({
        auto x_1 = x;
        call_then(start_expression(x_1), [=](Text expression_3792) { return prism_rtl::finished(prism_rtl::cat("(", expression_3792, ")")); });
    })
        : prism_rtl::is<lower::Ex::XIf>(x) ? ({
        auto x_1 = x;
        call_then(start_expression(x_1), [=](Text expression_3843) { return prism_rtl::finished(prism_rtl::cat("(", expression_3843, ")")); });
    })
        : prism_rtl::is<lower::Ex::XCast>(x) ? ({
        auto x_1 = x;
        call_then(start_expression(x_1), [=](Text expression_3888) { return prism_rtl::finished(prism_rtl::cat("(", expression_3888, ")")); });
    })
        : prism_rtl::more(prism_rtl::rc(Expression(x)));
    });
}


/// `Start Operand, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_operand(lower::Ex x) {
    return prism_rtl::make_rc<Operand>(x);
}


/// Args: unbounded fn [Ex] -> Text
Text args(const Array<lower::Ex>& xs) {
    return lexer::join(run_to_end(each_job(xs, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
        return entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(Expression(x))));
            });
        }));
    })))), Text::lit(", "));
}


prism_rtl::Turn<Text> Args::cycle() const {
    const auto& xs = this->xs;
    auto xs_1 = xs;
    return call_value(each_job(xs_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
        return entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(Expression(x))));
            });
        }));
    }))), [=](Array<Text> each_3984) { return prism_rtl::finished(lexer::join(each_3984, Text::lit(", "))); });
}


/// `Start Args, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_args(Array<lower::Ex> xs) {
    return prism_rtl::make_rc<Args>(xs);
}


/// Expression: unbounded fn Ex -> Text
Text expression(const lower::Ex& x) {
    if (prism_rtl::is<lower::Ex::XVar>(x)) {
        auto&& n = prism_rtl::as<lower::Ex::XVar>(x).a0;
        return n;
    }
    if (prism_rtl::is<lower::Ex::XPath>(x)) {
        auto&& p_ = prism_rtl::as<lower::Ex::XPath>(x).a0;
        return p_;
    }
    if (prism_rtl::is<lower::Ex::XSelf>(x)) {
        return Text::lit("self");
    }
    if (prism_rtl::is<lower::Ex::XCx>(x)) {
        return Text::lit("cx");
    }
    if (prism_rtl::is<lower::Ex::XConst>(x)) {
        auto&& n = prism_rtl::as<lower::Ex::XConst>(x).a0;
        return prism_rtl::cat("Self::", n);
    }
    if (prism_rtl::is<lower::Ex::XUnit>(x)) {
        return Text::lit("()");
    }
    if (prism_rtl::is<lower::Ex::XNone>(x)) {
        return Text::lit("None");
    }
    if (prism_rtl::is<lower::Ex::XBool>(x)) {
        auto&& b = prism_rtl::as<lower::Ex::XBool>(x).a0;
        return b ? Text::lit("true") : Text::lit("false");
    }
    if (prism_rtl::is<lower::Ex::XNat>(x)) {
        auto&& d = prism_rtl::as<lower::Ex::XNat>(x).a0;
        return len_text(d) <= Nat(9u)
            ? prism_rtl::cat("Nat::from(", d, "u32)")
            : len_text(d) <= Nat(18u)
            ? prism_rtl::cat("Nat::from_int(Int::from(", d, "i64)).unwrap()")
            : prism_rtl::cat("Nat::from_int(Int::parse(\"", d, "\").unwrap()).unwrap()");
    }
    if (prism_rtl::is<lower::Ex::XInt>(x)) {
        auto&& d = prism_rtl::as<lower::Ex::XInt>(x).a0;
        return len_text(lexer::has_prefix(d, Text::lit("-")) ? lexer::after_first(d) : d) <= Nat(18u)
            ? prism_rtl::cat("Int::from(", d, ")")
            : prism_rtl::cat("Int::parse(\"", d, "\").unwrap()");
    }
    if (prism_rtl::is<lower::Ex::XByte>(x)) {
        auto&& d = prism_rtl::as<lower::Ex::XByte>(x).a0;
        return prism_rtl::cat(d, "u8");
    }
    if (prism_rtl::is<lower::Ex::XFloat>(x)) {
        auto&& d = prism_rtl::as<lower::Ex::XFloat>(x).a0;
        return d;
    }
    if (prism_rtl::is<lower::Ex::XIndex>(x)) {
        auto&& n = prism_rtl::as<lower::Ex::XIndex>(x).a0;
        return prism_rtl::cat(n);
    }
    if (prism_rtl::is<lower::Ex::XChar>(x)) {
        auto&& c = prism_rtl::as<lower::Ex::XChar>(x).a0;
        return prism_rtl::cat("'", lower::char_escape(c), "'");
    }
    if (prism_rtl::is<lower::Ex::XStr>(x)) {
        auto&& t = prism_rtl::as<lower::Ex::XStr>(x).a0;
        return prism_rtl::cat("\"", lower::escape(t), "\"");
    }
    if (prism_rtl::is<lower::Ex::XRef>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XRef>(x).a0;
        return prism_rtl::cat("&", operand(y));
    }
    if (prism_rtl::is<lower::Ex::XRefMut>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XRefMut>(x).a0;
        return prism_rtl::cat("&mut ", operand(y));
    }
    if (prism_rtl::is<lower::Ex::XDeref>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XDeref>(x).a0;
        return prism_rtl::cat("*", operand(y));
    }
    if (prism_rtl::is<lower::Ex::XTarget>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XTarget>(x).a0;
        return prism_rtl::cat("(*", expression(y), ")");
    }
    if (prism_rtl::is<lower::Ex::XClone>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XClone>(x).a0;
        return prism_rtl::cat(tight(y), ".clone()");
    }
    if (prism_rtl::is<lower::Ex::XWeak>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XWeak>(x).a0;
        return prism_rtl::cat("Rc::downgrade(", expression(y), ")");
    }
    if (prism_rtl::is<lower::Ex::XUpgrade>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XUpgrade>(x).a0;
        return prism_rtl::cat(tight(y), ".upgrade()");
    }
    if (prism_rtl::is<lower::Ex::XBreak>(x)) {
        auto&& l = prism_rtl::as<lower::Ex::XBreak>(x).a0;
        auto&& y = prism_rtl::as<lower::Ex::XBreak>(x).a1;
        return prism_rtl::cat("break ", label(l), " ", expression(y));
    }
    if (prism_rtl::is<lower::Ex::XBreakLoop>(x)) {
        return Text::lit("break");
    }
    if (prism_rtl::is<lower::Ex::XLater>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XLater>(x).a0;
        return prism_rtl::cat("Box::new(move |cx| { ", expression(y), "; Ok(()) })");
    }
    if (prism_rtl::is<lower::Ex::XFormatStr>(x)) {
        auto&& parts = prism_rtl::as<lower::Ex::XFormatStr>(x).a0;
        return format_str(parts);
    }
    if (prism_rtl::is<lower::Ex::XIsCase>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XIsCase>(x).a0;
        auto&& m4073_26_1 = prism_rtl::as<lower::Ex::XIsCase>(x).a1;
        if (m4073_26_1.size() == 0u) {
            return Text::lit("false");
        }
    }
    if (prism_rtl::is<lower::Ex::XIsCase>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XIsCase>(x).a0;
        auto&& cs = prism_rtl::as<lower::Ex::XIsCase>(x).a1;
        return prism_rtl::cat("matches!(", expression(y), ", ", lexer::join(each(cs, [&](const Text& c) { return prism_rtl::cat(c, "(..)"); }), Text::lit(" | ")), ")");
    }
    if (prism_rtl::is<lower::Ex::XRefusal>(x)) {
        auto&& what = prism_rtl::as<lower::Ex::XRefusal>(x).a0;
        return prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), lower::escape(what), "\")");
    }
    if (prism_rtl::is<lower::Ex::XUnreachable>(x)) {
        return Text::lit("unreachable!()");
    }
    if (prism_rtl::is<lower::Ex::XCall>(x)) {
        auto&& f = prism_rtl::as<lower::Ex::XCall>(x).a0;
        auto&& args_ = prism_rtl::as<lower::Ex::XCall>(x).a1;
        return prism_rtl::cat(f, "(", emit::args(args_), ")");
    }
    if (prism_rtl::is<lower::Ex::XApply>(x)) {
        auto&& f = prism_rtl::as<lower::Ex::XApply>(x).a0;
        auto&& args_ = prism_rtl::as<lower::Ex::XApply>(x).a1;
        return prism_rtl::cat(tight(f), "(", emit::args(args_), ")");
    }
    if (prism_rtl::is<lower::Ex::XMethod>(x)) {
        auto&& r = prism_rtl::as<lower::Ex::XMethod>(x).a0;
        auto&& m = prism_rtl::as<lower::Ex::XMethod>(x).a1;
        auto&& args_ = prism_rtl::as<lower::Ex::XMethod>(x).a2;
        return prism_rtl::cat(tight(r), ".", m, "(", emit::args(args_), ")");
    }
    if (prism_rtl::is<lower::Ex::XBin>(x)) {
        auto&& op = prism_rtl::as<lower::Ex::XBin>(x).a0;
        auto&& l = prism_rtl::as<lower::Ex::XBin>(x).a1;
        auto&& r = prism_rtl::as<lower::Ex::XBin>(x).a2;
        return prism_rtl::cat(operand(l), " ", op, " ", operand(r));
    }
    if (prism_rtl::is<lower::Ex::XUnary>(x)) {
        auto&& op = prism_rtl::as<lower::Ex::XUnary>(x).a0;
        auto&& y = prism_rtl::as<lower::Ex::XUnary>(x).a1;
        return prism_rtl::cat(op, operand(y));
    }
    if (prism_rtl::is<lower::Ex::XCtor>(x)) {
        auto&& p_ = prism_rtl::as<lower::Ex::XCtor>(x).a0;
        auto&& args_ = prism_rtl::as<lower::Ex::XCtor>(x).a1;
        return prism_rtl::cat(p_, "(", emit::args(args_), ")");
    }
    if (prism_rtl::is<lower::Ex::XRecord>(x)) {
        auto&& p_ = prism_rtl::as<lower::Ex::XRecord>(x).a0;
        auto&& fs = prism_rtl::as<lower::Ex::XRecord>(x).a1;
        return prism_rtl::cat(p_, " { ", lexer::join(run_to_end(each_job(fs, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Ex> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [f, v_] = p0;
                    (prism_rtl::more(prism_rtl::rc(FieldInit(f, v_))));
                });
            }));
        })))), Text::lit(", ")), " }");
    }
    if (prism_rtl::is<lower::Ex::XTuple>(x)) {
        auto&& m4073_37_0 = prism_rtl::as<lower::Ex::XTuple>(x).a0;
        if (m4073_37_0.size() == 1u) {
            {
                auto&& _c1 = index(m4073_37_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one = prism_rtl::some_of(_c1);
                    return prism_rtl::cat("(", expression(one), ",)");
                }
            }
        }
    }
    if (prism_rtl::is<lower::Ex::XTuple>(x)) {
        auto&& xs = prism_rtl::as<lower::Ex::XTuple>(x).a0;
        return prism_rtl::cat("(", emit::args(xs), ")");
    }
    if (prism_rtl::is<lower::Ex::XVec>(x)) {
        auto&& xs = prism_rtl::as<lower::Ex::XVec>(x).a0;
        return prism_rtl::cat("vec![", emit::args(xs), "]");
    }
    if (prism_rtl::is<lower::Ex::XText>(x)) {
        auto&& t = prism_rtl::as<lower::Ex::XText>(x).a0;
        return prism_rtl::cat("Text::lit(\"", lower::escape(t), "\")");
    }
    if (prism_rtl::is<lower::Ex::XFormat>(x)) {
        auto&& parts = prism_rtl::as<lower::Ex::XFormat>(x).a0;
        return format(parts);
    }
    if (prism_rtl::is<lower::Ex::XMatch>(x)) {
        auto&& s = prism_rtl::as<lower::Ex::XMatch>(x).a0;
        auto&& arms_ = prism_rtl::as<lower::Ex::XMatch>(x).a1;
        auto&& fallback = prism_rtl::as<lower::Ex::XMatch>(x).a2;
        return rust_templates::match_(expression(s), arms(arms_, fallback));
    }
    if (prism_rtl::is<lower::Ex::XChain>(x)) {
        auto&& label_ = prism_rtl::as<lower::Ex::XChain>(x).a0;
        auto&& s = prism_rtl::as<lower::Ex::XChain>(x).a1;
        auto&& arms_ = prism_rtl::as<lower::Ex::XChain>(x).a2;
        return chain(label(label_), s, arms_);
    }
    if (prism_rtl::is<lower::Ex::XIf>(x)) {
        auto&& c = prism_rtl::as<lower::Ex::XIf>(x).a0;
        auto&& t = prism_rtl::as<lower::Ex::XIf>(x).a1;
        auto&& e = prism_rtl::as<lower::Ex::XIf>(x).a2;
        return if_expression(c, t, e);
    }
    if (prism_rtl::is<lower::Ex::XBlock>(x)) {
        auto&& m4073_45_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        if (m4073_45_0.size() == 0u) {
            return expression(e);
        }
    }
    if (prism_rtl::is<lower::Ex::XBlock>(x)) {
        auto&& dos = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        return rust_templates::block(statements(dos), expression(e));
    }
    if (prism_rtl::is<lower::Ex::XLabeled>(x)) {
        auto&& label_ = prism_rtl::as<lower::Ex::XLabeled>(x).a0;
        auto&& dos = prism_rtl::as<lower::Ex::XLabeled>(x).a1;
        auto&& e = prism_rtl::as<lower::Ex::XLabeled>(x).a2;
        return rust_templates::labeled(label(label_), statements(dos), expression(e));
    }
    if (prism_rtl::is<lower::Ex::XClosure>(x)) {
        auto&& mv = prism_rtl::as<lower::Ex::XClosure>(x).a0;
        auto&& ps = prism_rtl::as<lower::Ex::XClosure>(x).a1;
        auto&& body = prism_rtl::as<lower::Ex::XClosure>(x).a2;
        return prism_rtl::cat(mv ? Text::lit("move ") : Text::lit(""), "|", lexer::join(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
            return entered(once_job([=]() {
                return ({
                    auto p_ = p0;
                    (prism_rtl::more(prism_rtl::rc(Pattern_(p_))));
                });
            }));
        })))), Text::lit(", ")), "| ", expression(body));
    }
    if (prism_rtl::is<lower::Ex::XTry>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XTry>(x).a0;
        return prism_rtl::cat(tight(y), "?");
    }
    if (prism_rtl::is<lower::Ex::XField>(x)) {
        auto&& r = prism_rtl::as<lower::Ex::XField>(x).a0;
        auto&& f = prism_rtl::as<lower::Ex::XField>(x).a1;
        return prism_rtl::cat(tight(r), ".", f);
    }
    if (prism_rtl::is<lower::Ex::XPart>(x)) {
        auto&& r = prism_rtl::as<lower::Ex::XPart>(x).a0;
        auto&& k = prism_rtl::as<lower::Ex::XPart>(x).a1;
        return prism_rtl::cat(tight(r), ".", k);
    }
    if (prism_rtl::is<lower::Ex::XDecode>(x)) {
        auto&& t = prism_rtl::as<lower::Ex::XDecode>(x).a0;
        auto&& y = prism_rtl::as<lower::Ex::XDecode>(x).a1;
        return prism_rtl::cat(decode_head(t), "::from_pod(", expression(y), ")?");
    }
    if (prism_rtl::is<lower::Ex::XCast>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XCast>(x).a0;
        auto&& t = prism_rtl::as<lower::Ex::XCast>(x).a1;
        return prism_rtl::cat(tight(y), " as ", type_(t));
    }
    if (prism_rtl::is<lower::Ex::XTyped>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XTyped>(x).a0;
        return expression(y);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> Expression::cycle() const {
    const auto& x = this->x;
    return ({
        prism_rtl::is<lower::Ex::XVar>(x) ? ({
        auto&& n = prism_rtl::as<lower::Ex::XVar>(x).a0;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<lower::Ex::XPath>(x) ? ({
        auto&& p_ = prism_rtl::as<lower::Ex::XPath>(x).a0;
        prism_rtl::finished(p_);
    })
        : prism_rtl::is<lower::Ex::XSelf>(x) ? prism_rtl::finished(Text::lit("self"))
        : prism_rtl::is<lower::Ex::XCx>(x) ? prism_rtl::finished(Text::lit("cx"))
        : prism_rtl::is<lower::Ex::XConst>(x) ? ({
        auto&& n = prism_rtl::as<lower::Ex::XConst>(x).a0;
        prism_rtl::finished(prism_rtl::cat("Self::", n));
    })
        : prism_rtl::is<lower::Ex::XUnit>(x) ? prism_rtl::finished(Text::lit("()"))
        : prism_rtl::is<lower::Ex::XNone>(x) ? prism_rtl::finished(Text::lit("None"))
        : prism_rtl::is<lower::Ex::XBool>(x) ? ({
        auto&& b = prism_rtl::as<lower::Ex::XBool>(x).a0;
        b
        ? prism_rtl::finished(Text::lit("true"))
        : prism_rtl::finished(Text::lit("false"));
    })
        : prism_rtl::is<lower::Ex::XNat>(x) ? ({
        auto&& d = prism_rtl::as<lower::Ex::XNat>(x).a0;
        len_text(d) <= Nat(9u)
        ? prism_rtl::finished(prism_rtl::cat("Nat::from(", d, "u32)"))
        : len_text(d) <= Nat(18u)
        ? prism_rtl::finished(prism_rtl::cat("Nat::from_int(Int::from(", d, "i64)).unwrap()"))
        : prism_rtl::finished(prism_rtl::cat("Nat::from_int(Int::parse(\"", d, "\").unwrap()).unwrap()"));
    })
        : prism_rtl::is<lower::Ex::XInt>(x) ? ({
        auto&& d = prism_rtl::as<lower::Ex::XInt>(x).a0;
        len_text(lexer::has_prefix(d, Text::lit("-")) ? lexer::after_first(d) : d) <= Nat(18u)
        ? prism_rtl::finished(prism_rtl::cat("Int::from(", d, ")"))
        : prism_rtl::finished(prism_rtl::cat("Int::parse(\"", d, "\").unwrap()"));
    })
        : prism_rtl::is<lower::Ex::XByte>(x) ? ({
        auto&& d = prism_rtl::as<lower::Ex::XByte>(x).a0;
        prism_rtl::finished(prism_rtl::cat(d, "u8"));
    })
        : prism_rtl::is<lower::Ex::XFloat>(x) ? ({
        auto&& d = prism_rtl::as<lower::Ex::XFloat>(x).a0;
        prism_rtl::finished(d);
    })
        : prism_rtl::is<lower::Ex::XIndex>(x) ? ({
        auto&& n = prism_rtl::as<lower::Ex::XIndex>(x).a0;
        prism_rtl::finished(prism_rtl::cat(n));
    })
        : prism_rtl::is<lower::Ex::XChar>(x) ? ({
        auto&& c = prism_rtl::as<lower::Ex::XChar>(x).a0;
        prism_rtl::finished(prism_rtl::cat("'", lower::char_escape(c), "'"));
    })
        : prism_rtl::is<lower::Ex::XStr>(x) ? ({
        auto&& t = prism_rtl::as<lower::Ex::XStr>(x).a0;
        prism_rtl::finished(prism_rtl::cat("\"", lower::escape(t), "\""));
    })
        : prism_rtl::is<lower::Ex::XRef>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XRef>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_operand(y_1), [=](Text operand_4682) { return prism_rtl::finished(prism_rtl::cat("&", operand_4682)); });
    });
    })
        : prism_rtl::is<lower::Ex::XRefMut>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XRefMut>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_operand(y_1), [=](Text operand_4716) { return prism_rtl::finished(prism_rtl::cat("&mut ", operand_4716)); });
    });
    })
        : prism_rtl::is<lower::Ex::XDeref>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XDeref>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_operand(y_1), [=](Text operand_4745) { return prism_rtl::finished(prism_rtl::cat("*", operand_4745)); });
    });
    })
        : prism_rtl::is<lower::Ex::XTarget>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XTarget>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_expression(y_1), [=](Text expression_4776) { return prism_rtl::finished(prism_rtl::cat("(*", expression_4776, ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XClone>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XClone>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_tight(y_1), [=](Text tight_4808) { return prism_rtl::finished(prism_rtl::cat(tight_4808, ".clone()")); });
    });
    })
        : prism_rtl::is<lower::Ex::XWeak>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XWeak>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_expression(y_1), [=](Text expression_4855) { return prism_rtl::finished(prism_rtl::cat("Rc::downgrade(", expression_4855, ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XUpgrade>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XUpgrade>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_tight(y_1), [=](Text tight_4889) { return prism_rtl::finished(prism_rtl::cat(tight_4889, ".upgrade()")); });
    });
    })
        : prism_rtl::is<lower::Ex::XBreak>(x) ? ({
        auto&& l = prism_rtl::as<lower::Ex::XBreak>(x).a0;
        auto&& y = prism_rtl::as<lower::Ex::XBreak>(x).a1;
        ({
        auto l_1 = l;
        auto y_2 = y;
        call_then(start_expression(y_2), [=](Text expression_4944) { return prism_rtl::finished(prism_rtl::cat("break ", label(l_1), " ", expression_4944)); });
    });
    })
        : prism_rtl::is<lower::Ex::XBreakLoop>(x) ? prism_rtl::finished(Text::lit("break"))
        : prism_rtl::is<lower::Ex::XLater>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XLater>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_expression(y_1), [=](Text expression_5021) { return prism_rtl::finished(prism_rtl::cat("Box::new(move |cx| { ", expression_5021, "; Ok(()) })")); });
    });
    })
        : prism_rtl::is<lower::Ex::XFormatStr>(x) ? ({
        auto&& parts = prism_rtl::as<lower::Ex::XFormatStr>(x).a0;
        prism_rtl::more(prism_rtl::rc(FormatStr(parts)));
    })
        : prism_rtl::is<lower::Ex::XIsCase>(x) && ({
        auto&& y = prism_rtl::as<lower::Ex::XIsCase>(x).a0;
        auto&& m4073_26_1 = prism_rtl::as<lower::Ex::XIsCase>(x).a1;
        (m4073_26_1.size() == 0u);
    }) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XIsCase>(x).a0;
        auto&& m4073_26_1 = prism_rtl::as<lower::Ex::XIsCase>(x).a1;
        prism_rtl::finished(Text::lit("false"));
    })
        : prism_rtl::is<lower::Ex::XIsCase>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XIsCase>(x).a0;
        auto&& cs = prism_rtl::as<lower::Ex::XIsCase>(x).a1;
        ({
        auto cs_1 = cs;
        auto y_2 = y;
        call_then(start_expression(y_2), [=](Text expression_5145) { return prism_rtl::finished(prism_rtl::cat("matches!(", expression_5145, ", ", lexer::join(each(cs_1, [&](const Text& c) { return prism_rtl::cat(c, "(..)"); }), Text::lit(" | ")), ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XRefusal>(x) ? ({
        auto&& what = prism_rtl::as<lower::Ex::XRefusal>(x).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), lower::escape(what), "\")"));
    })
        : prism_rtl::is<lower::Ex::XUnreachable>(x) ? prism_rtl::finished(Text::lit("unreachable!()"))
        : prism_rtl::is<lower::Ex::XCall>(x) ? ({
        auto&& f = prism_rtl::as<lower::Ex::XCall>(x).a0;
        auto&& args_ = prism_rtl::as<lower::Ex::XCall>(x).a1;
        ({
        auto args__1 = args_;
        auto f_2 = f;
        call_then(start_args(args__1), [=](Text args_5334) { return prism_rtl::finished(prism_rtl::cat(f_2, "(", args_5334, ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XApply>(x) ? ({
        auto&& f = prism_rtl::as<lower::Ex::XApply>(x).a0;
        auto&& args_ = prism_rtl::as<lower::Ex::XApply>(x).a1;
        ({
        auto args__1 = args_;
        auto f_2 = f;
        call_then(start_tight(f_2), [=](Text tight_5369) { return call_then(start_args(args__1), [=](Text args_5379) { return prism_rtl::finished(prism_rtl::cat(tight_5369, "(", args_5379, ")")); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XMethod>(x) ? ({
        auto&& r = prism_rtl::as<lower::Ex::XMethod>(x).a0;
        auto&& m = prism_rtl::as<lower::Ex::XMethod>(x).a1;
        auto&& args_ = prism_rtl::as<lower::Ex::XMethod>(x).a2;
        ({
        auto args__1 = args_;
        auto m_2 = m;
        auto r_3 = r;
        call_then(start_tight(r_3), [=](Text tight_5418) { return call_then(start_args(args__1), [=](Text args_5432) { return prism_rtl::finished(prism_rtl::cat(tight_5418, ".", m_2, "(", args_5432, ")")); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XBin>(x) ? ({
        auto&& op = prism_rtl::as<lower::Ex::XBin>(x).a0;
        auto&& l = prism_rtl::as<lower::Ex::XBin>(x).a1;
        auto&& r = prism_rtl::as<lower::Ex::XBin>(x).a2;
        ({
        auto l_1 = l;
        auto op_2 = op;
        auto r_3 = r;
        call_then(start_operand(l_1), [=](Text operand_5466) { return call_then(start_operand(r_3), [=](Text operand_5483) { return prism_rtl::finished(prism_rtl::cat(operand_5466, " ", op_2, " ", operand_5483)); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XUnary>(x) ? ({
        auto&& op = prism_rtl::as<lower::Ex::XUnary>(x).a0;
        auto&& y = prism_rtl::as<lower::Ex::XUnary>(x).a1;
        ({
        auto op_1 = op;
        auto y_2 = y;
        call_then(start_operand(y_2), [=](Text operand_5519) { return prism_rtl::finished(prism_rtl::cat(op_1, operand_5519)); });
    });
    })
        : prism_rtl::is<lower::Ex::XCtor>(x) ? ({
        auto&& p_ = prism_rtl::as<lower::Ex::XCtor>(x).a0;
        auto&& args_ = prism_rtl::as<lower::Ex::XCtor>(x).a1;
        ({
        auto args__1 = args_;
        auto p__2 = p_;
        call_then(start_args(args__1), [=](Text args_5556) { return prism_rtl::finished(prism_rtl::cat(p__2, "(", args_5556, ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XRecord>(x) ? ({
        auto&& p_ = prism_rtl::as<lower::Ex::XRecord>(x).a0;
        auto&& fs = prism_rtl::as<lower::Ex::XRecord>(x).a1;
        ({
        auto fs_1 = fs;
        auto p__2 = p_;
        call_value(each_job(fs_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Ex> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f, v_] = p0;
                (prism_rtl::more(prism_rtl::rc(FieldInit(f, v_))));
            });
        }));
    }))), [=](Array<Text> each_5603) { return prism_rtl::finished(prism_rtl::cat(p__2, " { ", lexer::join(each_5603, Text::lit(", ")), " }")); });
    });
    })
        : prism_rtl::is<lower::Ex::XTuple>(x) && ({
        auto&& m4073_37_0 = prism_rtl::as<lower::Ex::XTuple>(x).a0;
        (m4073_37_0.size() == 1u) && ({
        auto&& _c1 = index(m4073_37_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m4073_37_0 = prism_rtl::as<lower::Ex::XTuple>(x).a0;
        auto&& _c1 = index(m4073_37_0, Nat(0u));
        auto&& one = prism_rtl::some_of(_c1);
        call_then(start_expression(one), [=](Text expression_5674) { return prism_rtl::finished(prism_rtl::cat("(", expression_5674, ",)")); });
    })
        : prism_rtl::is<lower::Ex::XTuple>(x) ? ({
        auto&& xs = prism_rtl::as<lower::Ex::XTuple>(x).a0;
        ({
        auto xs_1 = xs;
        call_then(start_args(xs_1), [=](Text args_5711) { return prism_rtl::finished(prism_rtl::cat("(", args_5711, ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XVec>(x) ? ({
        auto&& xs = prism_rtl::as<lower::Ex::XVec>(x).a0;
        ({
        auto xs_1 = xs;
        call_then(start_args(xs_1), [=](Text args_5742) { return prism_rtl::finished(prism_rtl::cat("vec![", args_5742, "]")); });
    });
    })
        : prism_rtl::is<lower::Ex::XText>(x) ? ({
        auto&& t = prism_rtl::as<lower::Ex::XText>(x).a0;
        prism_rtl::finished(prism_rtl::cat("Text::lit(\"", lower::escape(t), "\")"));
    })
        : prism_rtl::is<lower::Ex::XFormat>(x) ? ({
        auto&& parts = prism_rtl::as<lower::Ex::XFormat>(x).a0;
        prism_rtl::more(prism_rtl::rc(Format(parts)));
    })
        : prism_rtl::is<lower::Ex::XMatch>(x) ? ({
        auto&& s = prism_rtl::as<lower::Ex::XMatch>(x).a0;
        auto&& arms_ = prism_rtl::as<lower::Ex::XMatch>(x).a1;
        auto&& fallback = prism_rtl::as<lower::Ex::XMatch>(x).a2;
        ({
        auto arms__1 = arms_;
        auto fallback_2 = fallback;
        auto s_3 = s;
        call_then(start_expression(s_3), [=](Text expression_5871) { return call_then(start_arms(arms__1, fallback_2), [=](Text arms_5887) { return prism_rtl::finished(rust_templates::match_(expression_5871, arms_5887)); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XChain>(x) ? ({
        auto&& label_ = prism_rtl::as<lower::Ex::XChain>(x).a0;
        auto&& s = prism_rtl::as<lower::Ex::XChain>(x).a1;
        auto&& arms_ = prism_rtl::as<lower::Ex::XChain>(x).a2;
        prism_rtl::more(prism_rtl::rc(Chain(label(label_), s, arms_)));
    })
        : prism_rtl::is<lower::Ex::XIf>(x) ? ({
        auto&& c = prism_rtl::as<lower::Ex::XIf>(x).a0;
        auto&& t = prism_rtl::as<lower::Ex::XIf>(x).a1;
        auto&& e = prism_rtl::as<lower::Ex::XIf>(x).a2;
        prism_rtl::more(prism_rtl::rc(IfExpression(c, t, e)));
    })
        : prism_rtl::is<lower::Ex::XBlock>(x) && ({
        auto&& m4073_45_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        (m4073_45_0.size() == 0u);
    }) ? ({
        auto&& m4073_45_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        prism_rtl::more(prism_rtl::rc(Expression(e)));
    })
        : prism_rtl::is<lower::Ex::XBlock>(x) ? ({
        auto&& dos = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        ({
        auto dos_1 = dos;
        auto e_2 = e;
        call_then(start_statements(dos_1), [=](Text statements_6069) { return call_then(start_expression(e_2), [=](Text expression_6087) { return prism_rtl::finished(rust_templates::block(statements_6069, expression_6087)); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XLabeled>(x) ? ({
        auto&& label_ = prism_rtl::as<lower::Ex::XLabeled>(x).a0;
        auto&& dos = prism_rtl::as<lower::Ex::XLabeled>(x).a1;
        auto&& e = prism_rtl::as<lower::Ex::XLabeled>(x).a2;
        ({
        auto dos_1 = dos;
        auto e_2 = e;
        auto label__3 = label_;
        call_then(start_statements(dos_1), [=](Text statements_6161) { return call_then(start_expression(e_2), [=](Text expression_6179) { return prism_rtl::finished(rust_templates::labeled(label(label__3), statements_6161, expression_6179)); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XClosure>(x) ? ({
        auto&& mv = prism_rtl::as<lower::Ex::XClosure>(x).a0;
        auto&& ps = prism_rtl::as<lower::Ex::XClosure>(x).a1;
        auto&& body = prism_rtl::as<lower::Ex::XClosure>(x).a2;
        ({
        auto body_1 = body;
        auto mv_2 = mv;
        auto ps_3 = ps;
        call_value(each_job(ps_3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(Pattern_(p_))));
            });
        }));
    }))), [=](Array<Text> each_6254) { return call_then(start_expression(body_1), [=](Text expression_6288) { return prism_rtl::finished(prism_rtl::cat(mv_2 ? Text::lit("move ") : Text::lit(""), "|", lexer::join(each_6254, Text::lit(", ")), "| ", expression_6288)); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XTry>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XTry>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_tight(y_1), [=](Text tight_6320) { return prism_rtl::finished(prism_rtl::cat(tight_6320, "?")); });
    });
    })
        : prism_rtl::is<lower::Ex::XField>(x) ? ({
        auto&& r = prism_rtl::as<lower::Ex::XField>(x).a0;
        auto&& f = prism_rtl::as<lower::Ex::XField>(x).a1;
        ({
        auto f_1 = f;
        auto r_2 = r;
        call_then(start_tight(r_2), [=](Text tight_6350) { return prism_rtl::finished(prism_rtl::cat(tight_6350, ".", f_1)); });
    });
    })
        : prism_rtl::is<lower::Ex::XPart>(x) ? ({
        auto&& r = prism_rtl::as<lower::Ex::XPart>(x).a0;
        auto&& k = prism_rtl::as<lower::Ex::XPart>(x).a1;
        ({
        auto k_1 = k;
        auto r_2 = r;
        call_then(start_tight(r_2), [=](Text tight_6382) { return prism_rtl::finished(prism_rtl::cat(tight_6382, ".", k_1)); });
    });
    })
        : prism_rtl::is<lower::Ex::XDecode>(x) ? ({
        auto&& t = prism_rtl::as<lower::Ex::XDecode>(x).a0;
        auto&& y = prism_rtl::as<lower::Ex::XDecode>(x).a1;
        ({
        auto t_1 = t;
        auto y_2 = y;
        call_then(start_decode_head(t_1), [=](Text decode_head_6416) { return call_then(start_expression(y_2), [=](Text expression_6441) { return prism_rtl::finished(prism_rtl::cat(decode_head_6416, "::from_pod(", expression_6441, ")?")); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XCast>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XCast>(x).a0;
        auto&& t = prism_rtl::as<lower::Ex::XCast>(x).a1;
        ({
        auto t_1 = t;
        auto y_2 = y;
        call_then(start_tight(y_2), [=](Text tight_6476) { return call_then(start_type_(t_1), [=](Text type__6489) { return prism_rtl::finished(prism_rtl::cat(tight_6476, " as ", type__6489)); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XTyped>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XTyped>(x).a0;
        prism_rtl::more(prism_rtl::rc(Expression(y)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Expression, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_expression(lower::Ex x) {
    return prism_rtl::make_rc<Expression>(x);
}


/// FieldInit: unbounded fn Text, Ex -> Text
Text field_init(const Text& f, const lower::Ex& ex1) {
    if (prism_rtl::is<lower::Ex::XVar>(ex1)) {
        auto&& v_ = prism_rtl::as<lower::Ex::XVar>(ex1).a0;
        return v_ == f ? f : prism_rtl::cat(f, ": ", v_);
    }
    {
        auto&& v_ = ex1;
        return prism_rtl::cat(f, ": ", expression(v_));
    }
}


prism_rtl::Turn<Text> FieldInit::cycle() const {
    const auto& f = this->f;
    const auto& ex1 = this->ex1;
    return ({
        prism_rtl::is<lower::Ex::XVar>(ex1) ? ({
        auto&& v_ = prism_rtl::as<lower::Ex::XVar>(ex1).a0;
        v_ == f
        ? prism_rtl::finished(f)
        : prism_rtl::finished(prism_rtl::cat(f, ": ", v_));
    })
        : ({
        auto&& v_ = ex1;
        ({
        auto f_1 = f;
        auto v__2 = v_;
        call_then(start_expression(v__2), [=](Text expression_6659) { return prism_rtl::finished(prism_rtl::cat(f_1, ": ", expression_6659)); });
    });
    });
    });
}


/// `Start FieldInit, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_field_init(Text f, lower::Ex ex1) {
    return prism_rtl::make_rc<FieldInit>(f, ex1);
}


/// DecodeHead: unbounded fn OutTy -> Text
Text decode_head(const lower::OutTy& t) {
    if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m6732_0_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        if (m6732_0_1.size() == 0u) {
            return n;
        }
    }
    if (prism_rtl::is<lower::OutTy::OutNat>(t)) {
        return Text::lit("Nat");
    }
    if (prism_rtl::is<lower::OutTy::OutInt>(t)) {
        return Text::lit("Int");
    }
    if (prism_rtl::is<lower::OutTy::OutText>(t)) {
        return Text::lit("Text");
    }
    {
        return prism_rtl::cat("<", type_(t), ">");
    }
}


prism_rtl::Turn<Text> DecodeHead::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<lower::OutTy::OutNamed>(t) && ({
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m6732_0_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        (m6732_0_1.size() == 0u);
    }) ? ({
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m6732_0_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<lower::OutTy::OutNat>(t) ? prism_rtl::finished(Text::lit("Nat"))
        : prism_rtl::is<lower::OutTy::OutInt>(t) ? prism_rtl::finished(Text::lit("Int"))
        : prism_rtl::is<lower::OutTy::OutText>(t) ? prism_rtl::finished(Text::lit("Text"))
        : ({
        auto t_1 = t;
        call_then(start_type_(t_1), [=](Text type__6839) { return prism_rtl::finished(prism_rtl::cat("<", type__6839, ">")); });
    });
    });
}


/// `Start DecodeHead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_decode_head(lower::OutTy t) {
    return prism_rtl::make_rc<DecodeHead>(t);
}


/// Label: fn Text -> Text
Text label(const Text& l) {
    return lexer::has_prefix(l, Text::lit("'")) ? l : prism_rtl::cat("'", l);
}


/// Format: unbounded fn [Ex] -> Text
Text format(const Array<lower::Ex>& parts) {
    auto lit = concat(each(parts, [&](const lower::Ex& p_) { return format_piece(p_); }));
    auto vals = filter(parts, [&](const lower::Ex& p_) { return !is_text(p_); });
    return len(vals) == Nat(0u)
        ? prism_rtl::cat("Text::lit(\"", lower::escape(concat(each(parts, [&](const lower::Ex& p_) { return plain_piece(p_); }))), "\")")
        : prism_rtl::cat("Text::from(format!(\"", lit, "\", ", emit::args(vals), "))");
}


prism_rtl::Turn<Text> Format::cycle() const {
    const auto& parts = this->parts;
    auto lit = concat(each(parts, [&](const lower::Ex& p_) { return format_piece(p_); }));
    auto vals = filter(parts, [&](const lower::Ex& p_) { return !is_text(p_); });
    return len(vals) == Nat(0u)
        ? prism_rtl::finished(prism_rtl::cat("Text::lit(\"", lower::escape(concat(each(parts, [&](const lower::Ex& p_) { return plain_piece(p_); }))), "\")"))
        : call_then(start_args(vals), [=](Text args_7354) { return prism_rtl::finished(prism_rtl::cat("Text::from(format!(\"", lit, "\", ", args_7354, "))")); });
}


/// `Start Format, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_format(Array<lower::Ex> parts) {
    return prism_rtl::make_rc<Format>(parts);
}


/// PlainPiece: fn Ex -> Text
Text plain_piece(const lower::Ex& ex0) {
    if (prism_rtl::is<lower::Ex::XText>(ex0)) {
        auto&& t = prism_rtl::as<lower::Ex::XText>(ex0).a0;
        return t;
    }
    {
        auto&& other = ex0;
        return Text::lit("");
    }
}


/// FormatStr: unbounded fn [Ex] -> Text
Text format_str(const Array<lower::Ex>& parts) {
    auto lit = concat(each(parts, [&](const lower::Ex& p_) { return str_piece(p_); }));
    auto vals = filter(parts, [&](const lower::Ex& p_) { return (!is_text(p_)) && (!is_var(p_)); });
    return len(vals) == Nat(0u)
        ? prism_rtl::cat("\"", lit, "\"")
        : prism_rtl::cat("format!(\"", lit, "\", ", emit::args(vals), ")");
}


prism_rtl::Turn<Text> FormatStr::cycle() const {
    const auto& parts = this->parts;
    auto lit = concat(each(parts, [&](const lower::Ex& p_) { return str_piece(p_); }));
    auto vals = filter(parts, [&](const lower::Ex& p_) { return (!is_text(p_)) && (!is_var(p_)); });
    return len(vals) == Nat(0u)
        ? prism_rtl::finished(prism_rtl::cat("\"", lit, "\""))
        : call_then(start_args(vals), [=](Text args_7819) { return prism_rtl::finished(prism_rtl::cat("format!(\"", lit, "\", ", args_7819, ")")); });
}


/// `Start FormatStr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_format_str(Array<lower::Ex> parts) {
    return prism_rtl::make_rc<FormatStr>(parts);
}


/// IsVar: fn Ex -> Bool
bool is_var(const lower::Ex& ex0) {
    if (prism_rtl::is<lower::Ex::XVar>(ex0)) {
        return true;
    }
    {
        auto&& other = ex0;
        return false;
    }
}


/// StrPiece: fn Ex -> Text
Text str_piece(const lower::Ex& ex0) {
    if (prism_rtl::is<lower::Ex::XVar>(ex0)) {
        auto&& n = prism_rtl::as<lower::Ex::XVar>(ex0).a0;
        return prism_rtl::cat("{", n, "}");
    }
    {
        auto&& other = ex0;
        return format_piece(other);
    }
}


/// IsText: fn Ex -> Bool
bool is_text(const lower::Ex& ex0) {
    if (prism_rtl::is<lower::Ex::XText>(ex0)) {
        return true;
    }
    {
        auto&& other = ex0;
        return false;
    }
}


/// FormatPiece: fn Ex -> Text
Text format_piece(const lower::Ex& ex0) {
    if (prism_rtl::is<lower::Ex::XText>(ex0)) {
        auto&& t = prism_rtl::as<lower::Ex::XText>(ex0).a0;
        return format_escape(lower::escape(t));
    }
    {
        auto&& other = ex0;
        return Text::lit("{}");
    }
}


/// FormatEscape: fn Text -> Text
Text format_escape(const Text& t) {
    return lexer::map_chars(t, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::finished(format_escape_char(c)));
            });
        });
    })));
}


/// FormatEscapeChar: fn Text -> Text
Text format_escape_char(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("{")) {
            return Text::lit("{{");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("}")) {
            return Text::lit("}}");
        }
    }
    {
        auto&& c = text0;
        return c;
    }
}


/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
Text if_expression(const lower::Ex& c, const lower::Ex& t, const lower::Ex& e) {
    auto ct = expression(c);
    auto tt = expression(t);
    auto et = expression(e);
    auto short_ = (!lexer::contains(prism_rtl::cat(tt, et), Text::lit("\n"))) && (len_text(prism_rtl::cat(ct, tt, et)) < Nat(70u));
    return short_
        ? prism_rtl::cat("if ", ct, " { ", tt, " } else { ", et, " }")
        : rust_templates::if_(ct, tt, et);
}


prism_rtl::Turn<Text> IfExpression::cycle() const {
    const auto& c = this->c;
    const auto& t = this->t;
    const auto& e = this->e;
    auto c_1 = c;
    auto e_2 = e;
    auto t_3 = t;
    return call_then(start_expression(c_1), [=](Text expression_8557) {
        return ({
            auto ct = expression_8557;
            call_then(start_expression(t_3), [=](Text expression_8583) {
            return ({
                auto tt = expression_8583;
                call_then(start_expression(e_2), [=](Text expression_8609) {
                return ({
                    auto et = expression_8609;
                    auto short_ = (!lexer::contains(prism_rtl::cat(tt, et), Text::lit("\n"))) && (len_text(prism_rtl::cat(ct, tt, et)) < Nat(70u));
                    short_
                    ? prism_rtl::finished(prism_rtl::cat("if ", ct, " { ", tt, " } else { ", et, " }"))
                    : prism_rtl::finished(rust_templates::if_(ct, tt, et));
                });
            });
            });
        });
        });
    });
}


/// `Start IfExpression, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_if_expression(lower::Ex c, lower::Ex t, lower::Ex e) {
    return prism_rtl::make_rc<IfExpression>(c, t, e);
}


/// Arms: unbounded fn [XArm], Bool -> Text
Text arms(const Array<lower::XArm>& arms_, const bool& fallback) {
    auto lines = run_to_end(each_job(arms_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::XArm)>>(prism_rtl::rc([=](lower::XArm p0) {
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(Arm(a))));
            });
        }));
    }))));
    auto all = fallback
        ? prelude::push(lines, Text::lit("_ => unreachable!(\"no arm matched\"),"))
        : lines;
    return lexer::join(all, Text::lit("\n"));
}


prism_rtl::Turn<Text> Arms::cycle() const {
    const auto& arms_ = this->arms_;
    const auto& fallback = this->fallback;
    auto arms__1 = arms_;
    auto fallback_2 = fallback;
    return call_value(each_job(arms__1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::XArm)>>(prism_rtl::rc([=](lower::XArm p0) {
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(Arm(a))));
            });
        }));
    }))), [=](Array<Text> each_8940) {
        return ({
            auto lines = each_8940;
            auto all = fallback_2
                ? prelude::push(lines, Text::lit("_ => unreachable!(\"no arm matched\"),"))
                : lines;
            (prism_rtl::finished(lexer::join(all, Text::lit("\n"))));
        });
    });
}


/// `Start Arms, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_arms(Array<lower::XArm> arms_, bool fallback) {
    return prism_rtl::make_rc<Arms>(arms_, fallback);
}


/// Arm: unbounded fn XArm -> Text
Text arm(const lower::XArm& a) {
    auto guard = len(a.conds) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" if ", lexer::join(run_to_end(each_job(a.conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Cc)>>(prism_rtl::rc([=](lower::Cc p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::more(prism_rtl::rc(Condition(c))));
            });
        }));
    })))), Text::lit(" && ")));
    auto body = expression(a.body);
    return prism_rtl::cat(pattern(a.pat), guard, " => ", body, ",");
}


prism_rtl::Turn<Text> Arm::cycle() const {
    const auto& a = this->a;
    auto guard = len(a.conds) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" if ", lexer::join(run_to_end(each_job(a.conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Cc)>>(prism_rtl::rc([=](lower::Cc p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::more(prism_rtl::rc(Condition(c))));
            });
        }));
    })))), Text::lit(" && ")));
    auto a_1 = a;
    return call_then(start_expression(a_1.body), [=](Text expression_9232) {
        return ({
            auto body = expression_9232;
            call_then(start_pattern(a_1.pat), [=](Text pattern_9256) { return prism_rtl::finished(prism_rtl::cat(pattern_9256, guard, " => ", body, ",")); });
        });
    });
}


/// `Start Arm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_arm(lower::XArm a) {
    return prism_rtl::make_rc<Arm>(a);
}


/// Condition: unbounded fn Cc -> Text
Text condition(const lower::Cc& cc0) {
    if (prism_rtl::is<lower::Cc::CcIf>(cc0)) {
        auto&& x = prism_rtl::as<lower::Cc::CcIf>(cc0).a0;
        return operand(x);
    }
    if (prism_rtl::is<lower::Cc::CcLet>(cc0)) {
        auto&& p_ = prism_rtl::as<lower::Cc::CcLet>(cc0).a0;
        auto&& x = prism_rtl::as<lower::Cc::CcLet>(cc0).a1;
        return prism_rtl::cat("let ", pattern(p_), " = ", expression(x));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> Condition::cycle() const {
    const auto& cc0 = this->cc0;
    return ({
        prism_rtl::is<lower::Cc::CcIf>(cc0) ? ({
        auto&& x = prism_rtl::as<lower::Cc::CcIf>(cc0).a0;
        prism_rtl::more(prism_rtl::rc(Operand(x)));
    })
        : prism_rtl::is<lower::Cc::CcLet>(cc0) ? ({
        auto&& p_ = prism_rtl::as<lower::Cc::CcLet>(cc0).a0;
        auto&& x = prism_rtl::as<lower::Cc::CcLet>(cc0).a1;
        ({
        auto p__1 = p_;
        auto x_2 = x;
        call_then(start_pattern(p__1), [=](Text pattern_9394) { return call_then(start_expression(x_2), [=](Text expression_9408) { return prism_rtl::finished(prism_rtl::cat("let ", pattern_9394, " = ", expression_9408)); }); });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Condition, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_condition(lower::Cc cc0) {
    return prism_rtl::make_rc<Condition>(cc0);
}


/// Chain: unbounded fn Text, Ex, [XArm] -> Text
Text chain(const Text& label_, const lower::Ex& s, const Array<lower::XArm>& arms_) {
    auto in_place = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lower::Ex::XRef>(s)) {
            auto&& y = prism_rtl::as<lower::Ex::XRef>(s).a0;
            _v.set(is_bound(y));
            goto _done;
        }
        {
            _v.set(is_bound(s));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [bind, scrut] = in_place
        ? std::tuple{Array<Text>{}, expression(s)}
        : std::tuple{Array(std::vector{prism_rtl::cat("let scrutinee = ", expression(s), ";")}), Text::lit("scrutinee")};
    auto n = len(arms_);
    auto lines = run_to_end(each_job(check_errors::range0(n), ({
        auto arms__1 = arms_;
        auto scrut_2 = scrut;
        auto label__3 = label_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto arms__1_4 = arms__1;
            auto scrut_2_4 = scrut_2;
            auto label__3_4 = label__3;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(arms__1_4, i), lower::XArm{.pat = lower::Pa(lower::Pa::PaWild{}), .conds = Array<lower::Cc>{}, .body = lower::Ex(lower::Ex::XUnit{})});
                auto catch_all = (a.pat == lower::Pa(lower::Pa::PaWild{})) && (len(a.conds) == Nat(0u));
                catch_all
                ? prism_rtl::more(prism_rtl::rc(Expression(a.body)))
                : call_then(start_pattern(a.pat), [=](Text pattern_10121) {
                return call_value(each_job(a.conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Cc)>>(prism_rtl::rc([=](lower::Cc p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            (prism_rtl::more(prism_rtl::rc(Condition(c))));
                        });
                    }));
                }))), [=](Array<Text> each_10151) {
                    return ({
                        auto head = lexer::join(append(Array(std::vector{prism_rtl::cat("let ", pattern_10121, " = ", scrut_2_4)}), each_10151), Text::lit(" && "));
                        call_then(start_expression(a.body), [=](Text expression_10238) { return prism_rtl::finished(rust_templates::chain_arm(head, label__3_4, continued(expression_10238, Text::lit("    ")))); });
                    });
                });
            });
            });
            });
        }));
        });
    })));
    })));
    auto ends = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = lexer::last(arms_);
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set((a.pat == lower::Pa(lower::Pa::PaWild{})) && (len(a.conds) == Nat(0u)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto tail = ends
        ? Array<Text>{}
        : Array(std::vector{Text::lit("unreachable!(\"no clause matched\")")});
    return prism_rtl::cat(label_, ": {\n", indent(lexer::join(append(append(bind, lines), tail), Text::lit("\n"))), "\n}");
}


prism_rtl::Turn<Text> Chain::cycle() const {
    const auto& label_ = this->label_;
    const auto& s = this->s;
    const auto& arms_ = this->arms_;
    auto in_place = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lower::Ex::XRef>(s)) {
            auto&& y = prism_rtl::as<lower::Ex::XRef>(s).a0;
            _v.set(is_bound(y));
            goto _done;
        }
        {
            _v.set(is_bound(s));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [bind, scrut] = in_place
        ? std::tuple{Array<Text>{}, expression(s)}
        : std::tuple{Array(std::vector{prism_rtl::cat("let scrutinee = ", expression(s), ";")}), Text::lit("scrutinee")};
    auto n = len(arms_);
    auto arms__1 = arms_;
    auto label__2 = label_;
    auto s_3 = s;
    return call_value(each_job(check_errors::range0(n), ({
        auto arms__1_4 = arms__1;
        auto scrut_4 = scrut;
        auto label__2_5 = label__2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto arms__1_4_5 = arms__1_4;
            auto scrut_4_5 = scrut_4;
            auto label__2_5_5 = label__2_5;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(arms__1_4_5, i), lower::XArm{.pat = lower::Pa(lower::Pa::PaWild{}), .conds = Array<lower::Cc>{}, .body = lower::Ex(lower::Ex::XUnit{})});
                auto catch_all = (a.pat == lower::Pa(lower::Pa::PaWild{})) && (len(a.conds) == Nat(0u));
                catch_all
                ? prism_rtl::more(prism_rtl::rc(Expression(a.body)))
                : call_then(start_pattern(a.pat), [=](Text pattern_10121) {
                return call_value(each_job(a.conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Cc)>>(prism_rtl::rc([=](lower::Cc p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            (prism_rtl::more(prism_rtl::rc(Condition(c))));
                        });
                    }));
                }))), [=](Array<Text> each_10151) {
                    return ({
                        auto head = lexer::join(append(Array(std::vector{prism_rtl::cat("let ", pattern_10121, " = ", scrut_4_5)}), each_10151), Text::lit(" && "));
                        call_then(start_expression(a.body), [=](Text expression_10238) { return prism_rtl::finished(rust_templates::chain_arm(head, label__2_5_5, continued(expression_10238, Text::lit("    ")))); });
                    });
                });
            });
            });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_9867) {
        return ({
            auto lines = each_9867;
            auto ends = ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = lexer::last(arms__1);
                if (prism_rtl::is_some(_m)) {
                    auto&& a = prism_rtl::some_of(_m);
                    _v.set((a.pat == lower::Pa(lower::Pa::PaWild{})) && (len(a.conds) == Nat(0u)));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(false);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto tail = ends
                ? Array<Text>{}
                : Array(std::vector{Text::lit("unreachable!(\"no clause matched\")")});
            (prism_rtl::finished(prism_rtl::cat(label__2, ": {\n", indent(lexer::join(append(append(bind, lines), tail), Text::lit("\n"))), "\n}")));
        });
    });
}


/// `Start Chain, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_chain(Text label_, lower::Ex s, Array<lower::XArm> arms_) {
    return prism_rtl::make_rc<Chain>(label_, s, arms_);
}


/// IsBound: fn Ex -> Bool
bool is_bound(const lower::Ex& x) {
    if (prism_rtl::is<lower::Ex::XVar>(x)) {
        return true;
    }
    if (prism_rtl::is<lower::Ex::XField>(x)) {
        auto&& m10742_1_0 = prism_rtl::as<lower::Ex::XField>(x).a0;
        if (prism_rtl::is<lower::Ex::XSelf>(m10742_1_0)) {
            return true;
        }
    }
    if (prism_rtl::is<lower::Ex::XField>(x)) {
        auto&& m10742_2_0 = prism_rtl::as<lower::Ex::XField>(x).a0;
        if (prism_rtl::is<lower::Ex::XMethod>(m10742_2_0)) {
            auto&& m10742_2_0_r_0 = prism_rtl::as<lower::Ex::XMethod>(m10742_2_0).a0;
            if (prism_rtl::is<lower::Ex::XUpgrade>(m10742_2_0_r_0)) {
                return true;
            }
        }
    }
    if (prism_rtl::is<lower::Ex::XTarget>(x)) {
        return true;
    }
    if (prism_rtl::is<lower::Ex::XPart>(x)) {
        auto&& m10742_4_0 = prism_rtl::as<lower::Ex::XPart>(x).a0;
        if (prism_rtl::is<lower::Ex::XVar>(m10742_4_0)) {
            return true;
        }
    }
    {
        return false;
    }
}


/// Continued: fn Text, Text -> Text
Text continued(const Text& t, const Text& pad) {
    auto ls = split(t, Text::lit("\n"));
    return lexer::join(each(check_errors::range0(len(ls)), [&](const Nat& i) {
        return (i == Nat(0u)) || (or_(index(ls, i), Text::lit("")) == Text::lit(""))
            ? or_(index(ls, i), Text::lit(""))
            : prism_rtl::cat(pad, or_(index(ls, i), Text::lit("")));
    }), Text::lit("\n"));
}


/// BodyLines: unbounded fn Ex -> Text
Text body_lines(const lower::Ex& ex0) {
    if (prism_rtl::is<lower::Ex::XBlock>(ex0)) {
        auto&& dos = prism_rtl::as<lower::Ex::XBlock>(ex0).a0;
        auto&& e = prism_rtl::as<lower::Ex::XBlock>(ex0).a1;
        return len(dos) == Nat(0u)
            ? body_lines(e)
            : prism_rtl::cat(statements(dos), "\n", body_lines(e));
    }
    {
        auto&& x = ex0;
        return expression(x);
    }
}


prism_rtl::Turn<Text> BodyLines::cycle() const {
    const auto& ex0 = this->ex0;
    return ({
        prism_rtl::is<lower::Ex::XBlock>(ex0) ? ({
        auto&& dos = prism_rtl::as<lower::Ex::XBlock>(ex0).a0;
        auto&& e = prism_rtl::as<lower::Ex::XBlock>(ex0).a1;
        len(dos) == Nat(0u)
        ? prism_rtl::more(prism_rtl::rc(BodyLines(e)))
        : ({
        auto dos_1 = dos;
        auto e_2 = e;
        call_then(start_statements(dos_1), [=](Text statements_11426) { return call_then(start_body_lines(e_2), [=](Text body_lines_11444) { return prism_rtl::finished(prism_rtl::cat(statements_11426, "\n", body_lines_11444)); }); });
    });
    })
        : ({
        auto&& x = ex0;
        prism_rtl::more(prism_rtl::rc(Expression(x)));
    });
    });
}


/// `Start BodyLines, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_body_lines(lower::Ex ex0) {
    return prism_rtl::make_rc<BodyLines>(ex0);
}


/// Indent: fn Text -> Text
Text indent(const Text& t) {
    return lexer::join(each(split(t, Text::lit("\n")), [&](const Text& l) { return l == Text::lit("") ? Text::lit("") : prism_rtl::cat("    ", l); }), Text::lit("\n"));
}


/// Pattern: unbounded fn Pa -> Text
Text pattern(const lower::Pa& p_) {
    if (prism_rtl::is<lower::Pa::PaWild>(p_)) {
        return Text::lit("_");
    }
    if (prism_rtl::is<lower::Pa::PaBind>(p_)) {
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(p_).a0;
        return n;
    }
    if (prism_rtl::is<lower::Pa::PaMut>(p_)) {
        auto&& n = prism_rtl::as<lower::Pa::PaMut>(p_).a0;
        return prism_rtl::cat("mut ", n);
    }
    if (prism_rtl::is<lower::Pa::PaCtor>(p_)) {
        auto&& c = prism_rtl::as<lower::Pa::PaCtor>(p_).a0;
        auto&& ps = prism_rtl::as<lower::Pa::PaCtor>(p_).a1;
        return prism_rtl::cat(c, "(", lexer::join(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
            return entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(Pattern_(q))));
                });
            }));
        })))), Text::lit(", ")), ")");
    }
    if (prism_rtl::is<lower::Pa::PaUnit>(p_)) {
        auto&& c = prism_rtl::as<lower::Pa::PaUnit>(p_).a0;
        return c;
    }
    if (prism_rtl::is<lower::Pa::PaRecord>(p_)) {
        auto&& c = prism_rtl::as<lower::Pa::PaRecord>(p_).a0;
        auto&& fs = prism_rtl::as<lower::Pa::PaRecord>(p_).a1;
        auto&& rest = prism_rtl::as<lower::Pa::PaRecord>(p_).a2;
        auto parts = run_to_end(each_job(fs, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Pa> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [f, q] = p0;
                    ({
                    prism_rtl::is<lower::Pa::PaBind>(q) ? ({
                    auto&& n = prism_rtl::as<lower::Pa::PaBind>(q).a0;
                    n == f
                    ? prism_rtl::finished(f)
                    : prism_rtl::finished(prism_rtl::cat(f, ": ", n));
                })
                    : call_then(start_pattern(q), [=](Text pattern_12195) { return prism_rtl::finished(prism_rtl::cat(f, ": ", pattern_12195)); });
                });
                });
            }));
        }))));
        auto all = rest ? prelude::push(parts, Text::lit("..")) : parts;
        return prism_rtl::cat(c, " { ", lexer::join(all, Text::lit(", ")), " }");
    }
    if (prism_rtl::is<lower::Pa::PaTuple>(p_)) {
        auto&& m11893_6_0 = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
        if (m11893_6_0.size() == 1u) {
            {
                auto&& _c1 = index(m11893_6_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one = prism_rtl::some_of(_c1);
                    return prism_rtl::cat("(", pattern(one), ",)");
                }
            }
        }
    }
    if (prism_rtl::is<lower::Pa::PaTuple>(p_)) {
        auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
        return prism_rtl::cat("(", lexer::join(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
            return entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(Pattern_(q))));
                });
            }));
        })))), Text::lit(", ")), ")");
    }
    if (prism_rtl::is<lower::Pa::PaChar>(p_)) {
        auto&& c = prism_rtl::as<lower::Pa::PaChar>(p_).a0;
        return prism_rtl::cat("'", lower::char_escape(c), "'");
    }
    if (prism_rtl::is<lower::Pa::PaBool>(p_)) {
        auto&& b = prism_rtl::as<lower::Pa::PaBool>(p_).a0;
        return b ? Text::lit("true") : Text::lit("false");
    }
    if (prism_rtl::is<lower::Pa::PaIndex>(p_)) {
        auto&& n = prism_rtl::as<lower::Pa::PaIndex>(p_).a0;
        return prism_rtl::cat(n);
    }
    if (prism_rtl::is<lower::Pa::PaConst>(p_)) {
        auto&& n = prism_rtl::as<lower::Pa::PaConst>(p_).a0;
        return prism_rtl::cat("Self::", n);
    }
    if (prism_rtl::is<lower::Pa::PaSlice>(p_)) {
        auto&& ps = prism_rtl::as<lower::Pa::PaSlice>(p_).a0;
        return prism_rtl::cat("[", lexer::join(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
            return entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(Pattern_(q))));
                });
            }));
        })))), Text::lit(", ")), "]");
    }
    if (prism_rtl::is<lower::Pa::PaRest>(p_)) {
        auto&& m11893_13_0 = prism_rtl::as<lower::Pa::PaRest>(p_).a0;
        if (m11893_13_0 == Text::lit("")) {
            return Text::lit("..");
        }
    }
    if (prism_rtl::is<lower::Pa::PaRest>(p_)) {
        auto&& n = prism_rtl::as<lower::Pa::PaRest>(p_).a0;
        return prism_rtl::cat(n, " @ ..");
    }
    if (prism_rtl::is<lower::Pa::PaTyped>(p_)) {
        auto&& q = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(p_).a1;
        return prism_rtl::cat(pattern(q), ": ", type_(t));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> Pattern_::cycle() const {
    const auto& p_ = this->p_;
    return ({
        prism_rtl::is<lower::Pa::PaWild>(p_) ? prism_rtl::finished(Text::lit("_"))
        : prism_rtl::is<lower::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(p_).a0;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<lower::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaMut>(p_).a0;
        prism_rtl::finished(prism_rtl::cat("mut ", n));
    })
        : prism_rtl::is<lower::Pa::PaCtor>(p_) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaCtor>(p_).a0;
        auto&& ps = prism_rtl::as<lower::Pa::PaCtor>(p_).a1;
        ({
        auto c_1 = c;
        auto ps_2 = ps;
        call_value(each_job(ps_2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(Pattern_(q))));
            });
        }));
    }))), [=](Array<Text> each_11987) { return prism_rtl::finished(prism_rtl::cat(c_1, "(", lexer::join(each_11987, Text::lit(", ")), ")")); });
    });
    })
        : prism_rtl::is<lower::Pa::PaUnit>(p_) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaUnit>(p_).a0;
        prism_rtl::finished(c);
    })
        : prism_rtl::is<lower::Pa::PaRecord>(p_) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaRecord>(p_).a0;
        auto&& fs = prism_rtl::as<lower::Pa::PaRecord>(p_).a1;
        auto&& rest = prism_rtl::as<lower::Pa::PaRecord>(p_).a2;
        ({
        auto c_1 = c;
        auto fs_2 = fs;
        auto rest_3 = rest;
        call_value(each_job(fs_2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Pa> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f, q] = p0;
                ({
                prism_rtl::is<lower::Pa::PaBind>(q) ? ({
                auto&& n = prism_rtl::as<lower::Pa::PaBind>(q).a0;
                n == f
                ? prism_rtl::finished(f)
                : prism_rtl::finished(prism_rtl::cat(f, ": ", n));
            })
                : call_then(start_pattern(q), [=](Text pattern_12195) { return prism_rtl::finished(prism_rtl::cat(f, ": ", pattern_12195)); });
            });
            });
        }));
    }))), [=](Array<Text> each_12083) {
        return ({
            auto parts = each_12083;
            auto all = rest_3 ? prelude::push(parts, Text::lit("..")) : parts;
            (prism_rtl::finished(prism_rtl::cat(c_1, " { ", lexer::join(all, Text::lit(", ")), " }")));
        });
    });
    });
    })
        : prism_rtl::is<lower::Pa::PaTuple>(p_) && ({
        auto&& m11893_6_0 = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
        (m11893_6_0.size() == 1u) && ({
        auto&& _c1 = index(m11893_6_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m11893_6_0 = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
        auto&& _c1 = index(m11893_6_0, Nat(0u));
        auto&& one = prism_rtl::some_of(_c1);
        call_then(start_pattern(one), [=](Text pattern_12324) { return prism_rtl::finished(prism_rtl::cat("(", pattern_12324, ",)")); });
    })
        : prism_rtl::is<lower::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
        ({
        auto ps_1 = ps;
        call_value(each_job(ps_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(Pattern_(q))));
            });
        }));
    }))), [=](Array<Text> each_12365) { return prism_rtl::finished(prism_rtl::cat("(", lexer::join(each_12365, Text::lit(", ")), ")")); });
    });
    })
        : prism_rtl::is<lower::Pa::PaChar>(p_) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaChar>(p_).a0;
        prism_rtl::finished(prism_rtl::cat("'", lower::char_escape(c), "'"));
    })
        : prism_rtl::is<lower::Pa::PaBool>(p_) ? ({
        auto&& b = prism_rtl::as<lower::Pa::PaBool>(p_).a0;
        b
        ? prism_rtl::finished(Text::lit("true"))
        : prism_rtl::finished(Text::lit("false"));
    })
        : prism_rtl::is<lower::Pa::PaIndex>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaIndex>(p_).a0;
        prism_rtl::finished(prism_rtl::cat(n));
    })
        : prism_rtl::is<lower::Pa::PaConst>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaConst>(p_).a0;
        prism_rtl::finished(prism_rtl::cat("Self::", n));
    })
        : prism_rtl::is<lower::Pa::PaSlice>(p_) ? ({
        auto&& ps = prism_rtl::as<lower::Pa::PaSlice>(p_).a0;
        ({
        auto ps_1 = ps;
        call_value(each_job(ps_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(Pattern_(q))));
            });
        }));
    }))), [=](Array<Text> each_12546) { return prism_rtl::finished(prism_rtl::cat("[", lexer::join(each_12546, Text::lit(", ")), "]")); });
    });
    })
        : prism_rtl::is<lower::Pa::PaRest>(p_) && ({
        auto&& m11893_13_0 = prism_rtl::as<lower::Pa::PaRest>(p_).a0;
        (m11893_13_0 == Text::lit(""));
    }) ? ({
        auto&& m11893_13_0 = prism_rtl::as<lower::Pa::PaRest>(p_).a0;
        prism_rtl::finished(Text::lit(".."));
    })
        : prism_rtl::is<lower::Pa::PaRest>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaRest>(p_).a0;
        prism_rtl::finished(prism_rtl::cat(n, " @ .."));
    })
        : prism_rtl::is<lower::Pa::PaTyped>(p_) ? ({
        auto&& q = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(p_).a1;
        ({
        auto q_1 = q;
        auto t_2 = t;
        call_then(start_pattern(q_1), [=](Text pattern_12645) { return call_then(start_type_(t_2), [=](Text type__12658) { return prism_rtl::finished(prism_rtl::cat(pattern_12645, ": ", type__12658)); }); });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Pattern_, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_pattern(lower::Pa p_) {
    return prism_rtl::make_rc<Pattern_>(p_);
}


/// Statements: unbounded fn [Do] -> Text
Text statements(const Array<lower::Do>& dos) {
    return lexer::join(run_to_end(each_job(dos, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Do)>>(prism_rtl::rc([=](lower::Do p0) {
        return entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(Statement(d))));
            });
        }));
    })))), Text::lit("\n"));
}


prism_rtl::Turn<Text> Statements::cycle() const {
    const auto& dos = this->dos;
    auto dos_1 = dos;
    return call_value(each_job(dos_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Do)>>(prism_rtl::rc([=](lower::Do p0) {
        return entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(Statement(d))));
            });
        }));
    }))), [=](Array<Text> each_12732) { return prism_rtl::finished(lexer::join(each_12732, Text::lit("\n"))); });
}


/// `Start Statements, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_statements(Array<lower::Do> dos) {
    return prism_rtl::make_rc<Statements>(dos);
}


/// Statement: unbounded fn Do -> Text
Text statement(const lower::Do& d) {
    if (prism_rtl::is<lower::Do::DoLet>(d)) {
        auto&& p_ = prism_rtl::as<lower::Do::DoLet>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoLet>(d).a1;
        return prism_rtl::cat("let ", pattern(p_), " = ", expression(x), ";");
    }
    if (prism_rtl::is<lower::Do::DoLetElse>(d)) {
        auto&& p_ = prism_rtl::as<lower::Do::DoLetElse>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoLetElse>(d).a1;
        auto&& e = prism_rtl::as<lower::Do::DoLetElse>(d).a2;
        return prism_rtl::cat("let ", pattern(p_), " = ", expression(x), " else { ", expression(e), " };");
    }
    if (prism_rtl::is<lower::Do::DoAssign>(d)) {
        auto&& p_ = prism_rtl::as<lower::Do::DoAssign>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoAssign>(d).a1;
        return prism_rtl::cat(expression(p_), " = ", expression(x), ";");
    }
    if (prism_rtl::is<lower::Do::DoWhile>(d)) {
        auto&& c = prism_rtl::as<lower::Do::DoWhile>(d).a0;
        auto&& body = prism_rtl::as<lower::Do::DoWhile>(d).a1;
        return rust_templates::if_stmt(prism_rtl::cat("while ", expression(c)), statements(body));
    }
    if (prism_rtl::is<lower::Do::DoWhileLet>(d)) {
        auto&& p_ = prism_rtl::as<lower::Do::DoWhileLet>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoWhileLet>(d).a1;
        auto&& body = prism_rtl::as<lower::Do::DoWhileLet>(d).a2;
        return rust_templates::if_stmt(prism_rtl::cat("while let ", pattern(p_), " = ", expression(x)), statements(body));
    }
    if (prism_rtl::is<lower::Do::DoFor>(d)) {
        auto&& p_ = prism_rtl::as<lower::Do::DoFor>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoFor>(d).a1;
        auto&& body = prism_rtl::as<lower::Do::DoFor>(d).a2;
        return rust_templates::if_stmt(prism_rtl::cat("for ", pattern(p_), " in ", expression(x)), statements(body));
    }
    if (prism_rtl::is<lower::Do::DoExpr>(d)) {
        auto&& x = prism_rtl::as<lower::Do::DoExpr>(d).a0;
        return prism_rtl::cat(expression(x), ";");
    }
    if (prism_rtl::is<lower::Do::DoIf>(d)) {
        auto&& c = prism_rtl::as<lower::Do::DoIf>(d).a0;
        auto&& t = prism_rtl::as<lower::Do::DoIf>(d).a1;
        auto&& e = prism_rtl::as<lower::Do::DoIf>(d).a2;
        return prism_rtl::cat(rust_templates::if_stmt(prism_rtl::cat("if ", expression(c)), statements(t)), else_branch(e));
    }
    if (prism_rtl::is<lower::Do::DoIfLet>(d)) {
        auto&& p_ = prism_rtl::as<lower::Do::DoIfLet>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoIfLet>(d).a1;
        auto&& t = prism_rtl::as<lower::Do::DoIfLet>(d).a2;
        auto&& e = prism_rtl::as<lower::Do::DoIfLet>(d).a3;
        return prism_rtl::cat(rust_templates::if_stmt(prism_rtl::cat("if let ", pattern(p_), " = ", expression(x)), statements(t)), else_branch(e));
    }
    if (prism_rtl::is<lower::Do::DoMatch>(d)) {
        auto&& x = prism_rtl::as<lower::Do::DoMatch>(d).a0;
        auto&& cases = prism_rtl::as<lower::Do::DoMatch>(d).a1;
        return rust_templates::match_(expression(x), lexer::join(run_to_end(each_job(cases, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<lower::Pa, Array<lower::Do>>)>>(prism_rtl::rc([=](std::tuple<lower::Pa, Array<lower::Do>> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [p_, body] = p0;
                    call_then(start_pattern(p_), [=](Text pattern_13569) { return call_then(start_statements(body), [=](Text statements_13582) { return prism_rtl::finished(rust_templates::arm_block(pattern_13569, statements_13582)); }); });
                });
            }));
        })))), Text::lit("\n")));
    }
    if (prism_rtl::is<lower::Do::DoReturn>(d)) {
        auto&& x = prism_rtl::as<lower::Do::DoReturn>(d).a0;
        return prism_rtl::cat("return ", expression(x), ";");
    }
    if (prism_rtl::is<lower::Do::DoBlock>(d)) {
        auto&& body = prism_rtl::as<lower::Do::DoBlock>(d).a0;
        return rust_templates::scope(statements(body));
    }
    if (prism_rtl::is<lower::Do::DoScope>(d)) {
        auto&& body = prism_rtl::as<lower::Do::DoScope>(d).a0;
        return prism_rtl::cat("{ ", inline_statements(body), " };");
    }
    if (prism_rtl::is<lower::Do::DoLine>(d)) {
        auto&& body = prism_rtl::as<lower::Do::DoLine>(d).a0;
        return prism_rtl::cat(inline_statements(body), ";");
    }
    if (prism_rtl::is<lower::Do::DoNote>(d)) {
        auto&& t = prism_rtl::as<lower::Do::DoNote>(d).a0;
        return prism_rtl::cat("// ", t);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> Statement::cycle() const {
    const auto& d = this->d;
    return ({
        prism_rtl::is<lower::Do::DoLet>(d) ? ({
        auto&& p_ = prism_rtl::as<lower::Do::DoLet>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoLet>(d).a1;
        ({
        auto p__1 = p_;
        auto x_2 = x;
        call_then(start_pattern(p__1), [=](Text pattern_12850) { return call_then(start_expression(x_2), [=](Text expression_12864) { return prism_rtl::finished(prism_rtl::cat("let ", pattern_12850, " = ", expression_12864, ";")); }); });
    });
    })
        : prism_rtl::is<lower::Do::DoLetElse>(d) ? ({
        auto&& p_ = prism_rtl::as<lower::Do::DoLetElse>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoLetElse>(d).a1;
        auto&& e = prism_rtl::as<lower::Do::DoLetElse>(d).a2;
        ({
        auto e_1 = e;
        auto p__2 = p_;
        auto x_3 = x;
        call_then(start_pattern(p__2), [=](Text pattern_12909) { return call_then(start_expression(x_3), [=](Text expression_12923) { return call_then(start_expression(e_1), [=](Text expression_12946) { return prism_rtl::finished(prism_rtl::cat("let ", pattern_12909, " = ", expression_12923, " else { ", expression_12946, " };")); }); }); });
    });
    })
        : prism_rtl::is<lower::Do::DoAssign>(d) ? ({
        auto&& p_ = prism_rtl::as<lower::Do::DoAssign>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoAssign>(d).a1;
        ({
        auto p__1 = p_;
        auto x_2 = x;
        call_then(start_expression(p__1), [=](Text expression_12986) { return call_then(start_expression(x_2), [=](Text expression_13003) { return prism_rtl::finished(prism_rtl::cat(expression_12986, " = ", expression_13003, ";")); }); });
    });
    })
        : prism_rtl::is<lower::Do::DoWhile>(d) ? ({
        auto&& c = prism_rtl::as<lower::Do::DoWhile>(d).a0;
        auto&& body = prism_rtl::as<lower::Do::DoWhile>(d).a1;
        ({
        auto body_1 = body;
        auto c_2 = c;
        call_then(start_expression(c_2), [=](Text expression_13055) { return call_then(start_statements(body_1), [=](Text statements_13072) { return prism_rtl::finished(rust_templates::if_stmt(prism_rtl::cat("while ", expression_13055), statements_13072)); }); });
    });
    })
        : prism_rtl::is<lower::Do::DoWhileLet>(d) ? ({
        auto&& p_ = prism_rtl::as<lower::Do::DoWhileLet>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoWhileLet>(d).a1;
        auto&& body = prism_rtl::as<lower::Do::DoWhileLet>(d).a2;
        ({
        auto body_1 = body;
        auto p__2 = p_;
        auto x_3 = x;
        call_then(start_pattern(p__2), [=](Text pattern_13135) { return call_then(start_expression(x_3), [=](Text expression_13149) { return call_then(start_statements(body_1), [=](Text statements_13166) { return prism_rtl::finished(rust_templates::if_stmt(prism_rtl::cat("while let ", pattern_13135, " = ", expression_13149), statements_13166)); }); }); });
    });
    })
        : prism_rtl::is<lower::Do::DoFor>(d) ? ({
        auto&& p_ = prism_rtl::as<lower::Do::DoFor>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoFor>(d).a1;
        auto&& body = prism_rtl::as<lower::Do::DoFor>(d).a2;
        ({
        auto body_1 = body;
        auto p__2 = p_;
        auto x_3 = x;
        call_then(start_pattern(p__2), [=](Text pattern_13218) { return call_then(start_expression(x_3), [=](Text expression_13233) { return call_then(start_statements(body_1), [=](Text statements_13250) { return prism_rtl::finished(rust_templates::if_stmt(prism_rtl::cat("for ", pattern_13218, " in ", expression_13233), statements_13250)); }); }); });
    });
    })
        : prism_rtl::is<lower::Do::DoExpr>(d) ? ({
        auto&& x = prism_rtl::as<lower::Do::DoExpr>(d).a0;
        ({
        auto x_1 = x;
        call_then(start_expression(x_1), [=](Text expression_13283) { return prism_rtl::finished(prism_rtl::cat(expression_13283, ";")); });
    });
    })
        : prism_rtl::is<lower::Do::DoIf>(d) ? ({
        auto&& c = prism_rtl::as<lower::Do::DoIf>(d).a0;
        auto&& t = prism_rtl::as<lower::Do::DoIf>(d).a1;
        auto&& e = prism_rtl::as<lower::Do::DoIf>(d).a2;
        ({
        auto c_1 = c;
        auto e_2 = e;
        auto t_3 = t;
        call_then(start_expression(c_1), [=](Text expression_13331) { return call_then(start_statements(t_3), [=](Text statements_13348) { return call_then(start_else_branch(e_2), [=](Text else_branch_13363) { return prism_rtl::finished(prism_rtl::cat(rust_templates::if_stmt(prism_rtl::cat("if ", expression_13331), statements_13348), else_branch_13363)); }); }); });
    });
    })
        : prism_rtl::is<lower::Do::DoIfLet>(d) ? ({
        auto&& p_ = prism_rtl::as<lower::Do::DoIfLet>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoIfLet>(d).a1;
        auto&& t = prism_rtl::as<lower::Do::DoIfLet>(d).a2;
        auto&& e = prism_rtl::as<lower::Do::DoIfLet>(d).a3;
        ({
        auto e_1 = e;
        auto p__2 = p_;
        auto t_3 = t;
        auto x_4 = x;
        call_then(start_pattern(p__2), [=](Text pattern_13420) { return call_then(start_expression(x_4), [=](Text expression_13434) { return call_then(start_statements(t_3), [=](Text statements_13451) { return call_then(start_else_branch(e_1), [=](Text else_branch_13466) { return prism_rtl::finished(prism_rtl::cat(rust_templates::if_stmt(prism_rtl::cat("if let ", pattern_13420, " = ", expression_13434), statements_13451), else_branch_13466)); }); }); }); });
    });
    })
        : prism_rtl::is<lower::Do::DoMatch>(d) ? ({
        auto&& x = prism_rtl::as<lower::Do::DoMatch>(d).a0;
        auto&& cases = prism_rtl::as<lower::Do::DoMatch>(d).a1;
        ({
        auto cases_1 = cases;
        auto x_2 = x;
        call_then(start_expression(x_2), [=](Text expression_13510) {
        return call_value(each_job(cases_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<lower::Pa, Array<lower::Do>>)>>(prism_rtl::rc([=](std::tuple<lower::Pa, Array<lower::Do>> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [p_, body] = p0;
                    call_then(start_pattern(p_), [=](Text pattern_13569) { return call_then(start_statements(body), [=](Text statements_13582) { return prism_rtl::finished(rust_templates::arm_block(pattern_13569, statements_13582)); }); });
                });
            }));
        }))), [=](Array<Text> each_13532) { return prism_rtl::finished(rust_templates::match_(expression_13510, lexer::join(each_13532, Text::lit("\n")))); });
    });
    });
    })
        : prism_rtl::is<lower::Do::DoReturn>(d) ? ({
        auto&& x = prism_rtl::as<lower::Do::DoReturn>(d).a0;
        ({
        auto x_1 = x;
        call_then(start_expression(x_1), [=](Text expression_13632) { return prism_rtl::finished(prism_rtl::cat("return ", expression_13632, ";")); });
    });
    })
        : prism_rtl::is<lower::Do::DoBlock>(d) ? ({
        auto&& body = prism_rtl::as<lower::Do::DoBlock>(d).a0;
        ({
        auto body_1 = body;
        call_then(start_statements(body_1), [=](Text statements_13673) { return prism_rtl::finished(rust_templates::scope(statements_13673)); });
    });
    })
        : prism_rtl::is<lower::Do::DoScope>(d) ? ({
        auto&& body = prism_rtl::as<lower::Do::DoScope>(d).a0;
        ({
        auto body_1 = body;
        call_then(start_inline_statements(body_1), [=](Text inline_statements_13713) { return prism_rtl::finished(prism_rtl::cat("{ ", inline_statements_13713, " };")); });
    });
    })
        : prism_rtl::is<lower::Do::DoLine>(d) ? ({
        auto&& body = prism_rtl::as<lower::Do::DoLine>(d).a0;
        ({
        auto body_1 = body;
        call_then(start_inline_statements(body_1), [=](Text inline_statements_13760) { return prism_rtl::finished(prism_rtl::cat(inline_statements_13760, ";")); });
    });
    })
        : prism_rtl::is<lower::Do::DoNote>(d) ? ({
        auto&& t = prism_rtl::as<lower::Do::DoNote>(d).a0;
        prism_rtl::finished(prism_rtl::cat("// ", t));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Statement, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_statement(lower::Do d) {
    return prism_rtl::make_rc<Statement>(d);
}


/// InlineStatements: unbounded fn [Do] -> Text
Text inline_statements(const Array<lower::Do>& dos) {
    return lexer::join(run_to_end(each_job(dos, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Do)>>(prism_rtl::rc([=](lower::Do p0) {
        return entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(InlineStatement(d))));
            });
        }));
    })))), Text::lit(" "));
}


prism_rtl::Turn<Text> InlineStatements::cycle() const {
    const auto& dos = this->dos;
    auto dos_1 = dos;
    return call_value(each_job(dos_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Do)>>(prism_rtl::rc([=](lower::Do p0) {
        return entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(InlineStatement(d))));
            });
        }));
    }))), [=](Array<Text> each_13933) { return prism_rtl::finished(lexer::join(each_13933, Text::lit(" "))); });
}


/// `Start InlineStatements, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_inline_statements(Array<lower::Do> dos) {
    return prism_rtl::make_rc<InlineStatements>(dos);
}


/// InlineStatement: unbounded fn Do -> Text
Text inline_statement(const lower::Do& do_0) {
    if (prism_rtl::is<lower::Do::DoIf>(do_0)) {
        auto&& c = prism_rtl::as<lower::Do::DoIf>(do_0).a0;
        auto&& t = prism_rtl::as<lower::Do::DoIf>(do_0).a1;
        auto&& c0_0_2 = prism_rtl::as<lower::Do::DoIf>(do_0).a2;
        if (c0_0_2.size() == 0u) {
            return prism_rtl::cat("if ", expression(c), " { ", inline_statements(t), " }");
        }
    }
    {
        auto&& d = do_0;
        return statement(d);
    }
}


prism_rtl::Turn<Text> InlineStatement::cycle() const {
    const auto& do_0 = this->do_0;
    return ({
        prism_rtl::is<lower::Do::DoIf>(do_0) && ({
        auto&& c = prism_rtl::as<lower::Do::DoIf>(do_0).a0;
        auto&& t = prism_rtl::as<lower::Do::DoIf>(do_0).a1;
        auto&& j0_0_2 = prism_rtl::as<lower::Do::DoIf>(do_0).a2;
        (j0_0_2.size() == 0u);
    }) ? ({
        auto&& c = prism_rtl::as<lower::Do::DoIf>(do_0).a0;
        auto&& t = prism_rtl::as<lower::Do::DoIf>(do_0).a1;
        auto&& j0_0_2 = prism_rtl::as<lower::Do::DoIf>(do_0).a2;
        ({
        auto c_1 = c;
        auto t_2 = t;
        call_then(start_expression(c_1), [=](Text expression_14058) { return call_then(start_inline_statements(t_2), [=](Text inline_statements_14076) { return prism_rtl::finished(prism_rtl::cat("if ", expression_14058, " { ", inline_statements_14076, " }")); }); });
    });
    })
        : ({
        auto&& d = do_0;
        prism_rtl::more(prism_rtl::rc(Statement(d)));
    });
    });
}


/// `Start InlineStatement, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_inline_statement(lower::Do do_0) {
    return prism_rtl::make_rc<InlineStatement>(do_0);
}


/// ElseBranch: unbounded fn [Do] -> Text
Text else_branch(const Array<lower::Do>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& c1_0 = xs0;
        if (c1_0.size() == 1u) {
            {
                auto&& _c1 = index(c1_0, Nat(0u));
                if (prism_rtl::is_some(_c1) && prism_rtl::is<lower::Do::DoIf>(prism_rtl::some_of(_c1))) {
                    auto&& c = prism_rtl::as<lower::Do::DoIf>(prism_rtl::some_of(_c1)).a0;
                    auto&& t = prism_rtl::as<lower::Do::DoIf>(prism_rtl::some_of(_c1)).a1;
                    auto&& e = prism_rtl::as<lower::Do::DoIf>(prism_rtl::some_of(_c1)).a2;
                    return prism_rtl::cat(" else ", statement(lower::Do(lower::Do::DoIf{c, t, e})));
                }
            }
        }
    }
    {
        auto&& c2_0 = xs0;
        if (c2_0.size() == 1u) {
            {
                auto&& _c1 = index(c2_0, Nat(0u));
                if (prism_rtl::is_some(_c1) && prism_rtl::is<lower::Do::DoIfLet>(prism_rtl::some_of(_c1))) {
                    auto&& p_ = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a0;
                    auto&& x = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a1;
                    auto&& t = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a2;
                    auto&& e = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a3;
                    return prism_rtl::cat(" else ", statement(lower::Do(lower::Do::DoIfLet{p_, x, t, e})));
                }
            }
        }
    }
    {
        auto&& body = xs0;
        return rust_templates::else_(statements(body));
    }
}


prism_rtl::Turn<Text> ElseBranch::cycle() const {
    const auto& xs0 = this->xs0;
    return ({
        ({
        auto&& j0_0 = xs0;
        (j0_0.size() == 0u);
    }) ? ({
        auto&& j0_0 = xs0;
        prism_rtl::finished(Text::lit(""));
    })
        : ({
        auto&& j1_0 = xs0;
        (j1_0.size() == 1u) && ({
        auto&& _c1 = index(j1_0, Nat(0u));
        prism_rtl::is_some(_c1) && prism_rtl::is<lower::Do::DoIf>(prism_rtl::some_of(_c1));
    });
    }) ? ({
        auto&& j1_0 = xs0;
        auto&& _c1 = index(j1_0, Nat(0u));
        auto&& c = prism_rtl::as<lower::Do::DoIf>(prism_rtl::some_of(_c1)).a0;
        auto&& t = prism_rtl::as<lower::Do::DoIf>(prism_rtl::some_of(_c1)).a1;
        auto&& e = prism_rtl::as<lower::Do::DoIf>(prism_rtl::some_of(_c1)).a2;
        call_then(start_statement(lower::Do(lower::Do::DoIf{c, t, e})), [=](Text statement_14288) { return prism_rtl::finished(prism_rtl::cat(" else ", statement_14288)); });
    })
        : ({
        auto&& j2_0 = xs0;
        (j2_0.size() == 1u) && ({
        auto&& _c1 = index(j2_0, Nat(0u));
        prism_rtl::is_some(_c1) && prism_rtl::is<lower::Do::DoIfLet>(prism_rtl::some_of(_c1));
    });
    }) ? ({
        auto&& j2_0 = xs0;
        auto&& _c1 = index(j2_0, Nat(0u));
        auto&& p_ = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a0;
        auto&& x = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a1;
        auto&& t = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a2;
        auto&& e = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a3;
        call_then(start_statement(lower::Do(lower::Do::DoIfLet{p_, x, t, e})), [=](Text statement_14364) { return prism_rtl::finished(prism_rtl::cat(" else ", statement_14364)); });
    })
        : ({
        auto&& body = xs0;
        ({
        auto body_1 = body;
        call_then(start_statements(body_1), [=](Text statements_14424) { return prism_rtl::finished(rust_templates::else_(statements_14424)); });
    });
    });
    });
}


/// `Start ElseBranch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_else_branch(Array<lower::Do> xs0) {
    return prism_rtl::make_rc<ElseBranch>(xs0);
}


/// Generics: fn [((Text, [Text]))] -> Text
Text generics(const Array<std::tuple<Text, Array<Text>>>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& gs = xs0;
        return prism_rtl::cat("<", lexer::join(each(gs, [&](const std::tuple<Text, Array<Text>>& _p0) {
            auto&& g = std::get<0>(_p0);
            auto&& bs = std::get<1>(_p0);
            return len(bs) == Nat(0u)
                ? g
                : prism_rtl::cat(g, ": ", lexer::join(bs, Text::lit(" + ")));
        }), Text::lit(", ")), ">");
    }
}


/// GenericNames: fn [Text] -> Text
Text generic_names(const Array<Text>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& ps = xs0;
        return prism_rtl::cat("<", lexer::join(ps, Text::lit(", ")), ">");
    }
}


/// Bounded: fn [Text], Text -> Text
Text bounded(const Array<Text>& xs0, const Text& text1) {
    auto&& _m = std::tuple{xs0, text1};
    {
        auto&& c0_0 = std::get<0>(_m);
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& ps = std::get<0>(_m);
        auto&& tr = std::get<1>(_m);
        return prism_rtl::cat("<", lexer::join(each(ps, [&](const Text& p_) { return prism_rtl::cat(p_, ": ", tr); }), Text::lit(", ")), ">");
    }
    prism_rtl::unreachable("no arm matched");
}


/// RustItem: unbounded fn Item -> Text
Text rust_item(const lower::Item& it) {
    if (prism_rtl::is<lower::Item::ItTrait>(it)) {
        auto&& t = prism_rtl::as<lower::Item::ItTrait>(it).a0;
        return rust_trait(t);
    }
    if (prism_rtl::is<lower::Item::ItImpl>(it)) {
        auto&& i = prism_rtl::as<lower::Item::ItImpl>(it).a0;
        return rust_impl(i);
    }
    if (prism_rtl::is<lower::Item::ItType>(it)) {
        auto&& t = prism_rtl::as<lower::Item::ItType>(it).a0;
        return type_decl(t);
    }
    if (prism_rtl::is<lower::Item::ItTag>(it)) {
        auto&& t = prism_rtl::as<lower::Item::ItTag>(it).a0;
        return rust_tag(t);
    }
    if (prism_rtl::is<lower::Item::ItRow>(it)) {
        auto&& r = prism_rtl::as<lower::Item::ItRow>(it).a0;
        return rust_row(r);
    }
    if (prism_rtl::is<lower::Item::ItFn>(it)) {
        auto&& f = prism_rtl::as<lower::Item::ItFn>(it).a0;
        return rust_fn(f);
    }
    if (prism_rtl::is<lower::Item::ItJob>(it)) {
        auto&& j = prism_rtl::as<lower::Item::ItJob>(it).a0;
        return rust_job(j);
    }
    if (prism_rtl::is<lower::Item::ItNode>(it)) {
        auto&& n = prism_rtl::as<lower::Item::ItNode>(it).a0;
        return rust_node(n);
    }
    if (prism_rtl::is<lower::Item::ItNote>(it)) {
        auto&& t = prism_rtl::as<lower::Item::ItNote>(it).a0;
        return prism_rtl::cat("// ", t, "\n");
    }
    if (prism_rtl::is<lower::Item::ItRefused>(it)) {
        auto&& t = prism_rtl::as<lower::Item::ItRefused>(it).a0;
        return prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), lower::escape(t), "\");\n");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> RustItem::cycle() const {
    const auto& it = this->it;
    return ({
        prism_rtl::is<lower::Item::ItTrait>(it) ? ({
        auto&& t = prism_rtl::as<lower::Item::ItTrait>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustTrait(t)));
    })
        : prism_rtl::is<lower::Item::ItImpl>(it) ? ({
        auto&& i = prism_rtl::as<lower::Item::ItImpl>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustImpl(i)));
    })
        : prism_rtl::is<lower::Item::ItType>(it) ? ({
        auto&& t = prism_rtl::as<lower::Item::ItType>(it).a0;
        prism_rtl::more(prism_rtl::rc(TypeDecl(t)));
    })
        : prism_rtl::is<lower::Item::ItTag>(it) ? ({
        auto&& t = prism_rtl::as<lower::Item::ItTag>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustTag(t)));
    })
        : prism_rtl::is<lower::Item::ItRow>(it) ? ({
        auto&& r = prism_rtl::as<lower::Item::ItRow>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustRow(r)));
    })
        : prism_rtl::is<lower::Item::ItFn>(it) ? ({
        auto&& f = prism_rtl::as<lower::Item::ItFn>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustFn(f)));
    })
        : prism_rtl::is<lower::Item::ItJob>(it) ? ({
        auto&& j = prism_rtl::as<lower::Item::ItJob>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustJob(j)));
    })
        : prism_rtl::is<lower::Item::ItNode>(it) ? ({
        auto&& n = prism_rtl::as<lower::Item::ItNode>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustNode(n)));
    })
        : prism_rtl::is<lower::Item::ItNote>(it) ? ({
        auto&& t = prism_rtl::as<lower::Item::ItNote>(it).a0;
        prism_rtl::finished(prism_rtl::cat("// ", t, "\n"));
    })
        : prism_rtl::is<lower::Item::ItRefused>(it) ? ({
        auto&& t = prism_rtl::as<lower::Item::ItRefused>(it).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), lower::escape(t), "\");\n"));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RustItem, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_item(lower::Item it) {
    return prism_rtl::make_rc<RustItem>(it);
}


/// RustTrait: unbounded fn TraitDef -> Text
Text rust_trait(const lower::TraitDef& t) {
    auto ms = lexer::join(run_to_end(each_job(t.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
        return entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(TraitMethod(f))));
            });
        }));
    })))), Text::lit("\n"));
    return prism_rtl::cat(rust_templates::source_doc(Text::lit(""), t.doc), "pub trait ", t.name, " {\n", indent(ms), "\n}\n");
}


prism_rtl::Turn<Text> RustTrait::cycle() const {
    const auto& t = this->t;
    auto t_1 = t;
    return call_value(each_job(t_1.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
        return entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(TraitMethod(f))));
            });
        }));
    }))), [=](Array<Text> each_15457) {
        return ({
            auto ms = lexer::join(each_15457, Text::lit("\n"));
            (prism_rtl::finished(prism_rtl::cat(rust_templates::source_doc(Text::lit(""), t_1.doc), "pub trait ", t_1.name, " {\n", indent(ms), "\n}\n")));
        });
    });
}


/// `Start RustTrait, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_trait(lower::TraitDef t) {
    return prism_rtl::make_rc<RustTrait>(t);
}


/// Signature: unbounded fn FnDef, Text -> Text
Text signature(const lower::FnDef& f, const Text& vis) {
    auto params = lexer::join(run_to_end(each_job(f.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_type_(t), [=](Text type__15690) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__15690)); });
            });
        }));
    })))), Text::lit(", "));
    return prism_rtl::cat(vis, "fn ", f.name, generics(f.generics), "(", params, ") -> ", type_(f.ret));
}


prism_rtl::Turn<Text> Signature::cycle() const {
    const auto& f = this->f;
    const auto& vis = this->vis;
    auto f_1 = f;
    auto vis_2 = vis;
    return call_value(each_job(f_1.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_type_(t), [=](Text type__15690) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__15690)); });
            });
        }));
    }))), [=](Array<Text> each_15656) {
        return ({
            auto params = lexer::join(each_15656, Text::lit(", "));
            call_then(start_type_(f_1.ret), [=](Text type__15763) { return prism_rtl::finished(prism_rtl::cat(vis_2, "fn ", f_1.name, generics(f_1.generics), "(", params, ") -> ", type__15763)); });
        });
    });
}


/// `Start Signature, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_signature(lower::FnDef f, Text vis) {
    return prism_rtl::make_rc<Signature>(f, vis);
}


/// TraitMethod: unbounded fn FnDef -> Text
Text trait_method(const lower::FnDef& f) {
    return f.public_
        ? rust_templates::fn_(Text::lit(""), signature(f, Text::lit("")), body_lines(f.body))
        : prism_rtl::cat(signature(f, Text::lit("")), ";");
}


prism_rtl::Turn<Text> TraitMethod::cycle() const {
    const auto& f = this->f;
    return f.public_
        ? ({
        auto f_1 = f;
        call_then(start_signature(f_1, Text::lit("")), [=](Text signature_15857) { return call_then(start_body_lines(f_1.body), [=](Text body_lines_15876) { return prism_rtl::finished(rust_templates::fn_(Text::lit(""), signature_15857, body_lines_15876)); }); });
    })
        : ({
        auto f_1 = f;
        call_then(start_signature(f_1, Text::lit("")), [=](Text signature_15902) { return prism_rtl::finished(prism_rtl::cat(signature_15902, ";")); });
    });
}


/// `Start TraitMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_trait_method(lower::FnDef f) {
    return prism_rtl::make_rc<TraitMethod>(f);
}


/// RustImpl: unbounded fn ImplDef -> Text
Text rust_impl(const lower::ImplDef& i) {
    auto head = type_(i.head);
    auto gens = generics(i.generics);
    auto&& _m = i.cls;
    {
        auto&& m16177_0 = _m;
        if (m16177_0 == Text::lit("Prelude.Show")) {
            auto fns = lexer::join(run_to_end(each_job(i.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
                return entered(once_job([=]() {
                    return ({
                        auto f = p0;
                        (prism_rtl::more(prism_rtl::rc(RustFn(f))));
                    });
                }));
            })))), Text::lit("\n"));
            auto shown = or_(index(each(i.methods, [&](const lower::FnDef& f) { return f.name; }), Nat(0u)), Text::lit("show"));
            return prism_rtl::cat(fns, "\n", rust_templates::impl_(gens, Text::lit("Show"), head, Text::lit("fn show(&self, p: &mut Printer)"), prism_rtl::cat("p.raw(&", shown, "(self).to_string());")));
        }
    }
    {
        auto&& m16177_1 = _m;
        if (m16177_1 == Text::lit("Prelude.Eq")) {
            auto fns = lexer::join(run_to_end(each_job(i.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
                return entered(once_job([=]() {
                    return ({
                        auto f = p0;
                        (prism_rtl::more(prism_rtl::rc(RustFn(f))));
                    });
                }));
            })))), Text::lit("\n"));
            auto eq = fold(i.methods, Text::lit(""), [&](const Text& acc, const lower::FnDef& f) {
                return (!lexer::has_prefix(f.name, Text::lit("ne"))) && (acc == Text::lit(""))
                    ? f.name
                    : acc;
            });
            return prism_rtl::cat(fns, "\n", rust_templates::impl_(gens, Text::lit("PartialEq"), head, Text::lit("fn eq(&self, other: &Self) -> bool"), prism_rtl::cat(eq, "(self, other)")));
        }
    }
    {
        return prism_rtl::cat("impl", gens, " ", i.tr, " for ", head, " {\n", indent(lexer::join(run_to_end(each_job(i.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto f = p0;
                    call_then(start_signature(f, Text::lit("")), [=](Text signature_16879) { return call_then(start_body_lines(f.body), [=](Text body_lines_16898) { return prism_rtl::finished(rust_templates::fn_(Text::lit(""), signature_16879, body_lines_16898)); }); });
                });
            }));
        })))), Text::lit("\n"))), "\n}\n");
    }
}


prism_rtl::Turn<Text> RustImpl::cycle() const {
    const auto& i = this->i;
    auto i_1 = i;
    return call_then(start_type_(i_1.head), [=](Text type__16126) {
        return ({
            auto head = type__16126;
            auto gens = generics(i_1.generics);
            ({
            auto&& _m = i_1.cls;
            ({
            auto&& m16177_0 = _m;
            (m16177_0 == Text::lit("Prelude.Show"));
        }) ? ({
            auto&& m16177_0 = _m;
            call_value(each_job(i_1.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto f = p0;
                    (prism_rtl::more(prism_rtl::rc(RustFn(f))));
                });
            }));
        }))), [=](Array<Text> each_16242) {
            return ({
                auto fns = lexer::join(each_16242, Text::lit("\n"));
                auto shown = or_(index(each(i_1.methods, [&](const lower::FnDef& f) { return f.name; }), Nat(0u)), Text::lit("show"));
                (prism_rtl::finished(prism_rtl::cat(fns, "\n", rust_templates::impl_(gens, Text::lit("Show"), head, Text::lit("fn show(&self, p: &mut Printer)"), prism_rtl::cat("p.raw(&", shown, "(self).to_string());")))));
            });
        });
        })
            : ({
            auto&& m16177_1 = _m;
            (m16177_1 == Text::lit("Prelude.Eq"));
        }) ? ({
            auto&& m16177_1 = _m;
            call_value(each_job(i_1.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto f = p0;
                    (prism_rtl::more(prism_rtl::rc(RustFn(f))));
                });
            }));
        }))), [=](Array<Text> each_16517) {
            return ({
                auto fns = lexer::join(each_16517, Text::lit("\n"));
                auto eq = fold(i_1.methods, Text::lit(""), [&](const Text& acc, const lower::FnDef& f) {
                    return (!lexer::has_prefix(f.name, Text::lit("ne"))) && (acc == Text::lit(""))
                        ? f.name
                        : acc;
                });
                (prism_rtl::finished(prism_rtl::cat(fns, "\n", rust_templates::impl_(gens, Text::lit("PartialEq"), head, Text::lit("fn eq(&self, other: &Self) -> bool"), prism_rtl::cat(eq, "(self, other)")))));
            });
        });
        })
            : call_value(each_job(i_1.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto f = p0;
                    call_then(start_signature(f, Text::lit("")), [=](Text signature_16879) { return call_then(start_body_lines(f.body), [=](Text body_lines_16898) { return prism_rtl::finished(rust_templates::fn_(Text::lit(""), signature_16879, body_lines_16898)); }); });
                });
            }));
        }))), [=](Array<Text> each_16850) { return prism_rtl::finished(prism_rtl::cat("impl", gens, " ", i_1.tr, " for ", head, " {\n", indent(lexer::join(each_16850, Text::lit("\n"))), "\n}\n")); });
        });
        });
    });
}


/// `Start RustImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_impl(lower::ImplDef i) {
    return prism_rtl::make_rc<RustImpl>(i);
}


/// RustFn: unbounded fn FnDef -> Text
Text rust_fn(const lower::FnDef& f) {
    auto params = lexer::join(run_to_end(each_job(f.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_type_(t), [=](Text type__17038) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__17038)); });
            });
        }));
    })))), Text::lit(", "));
    auto sig = prism_rtl::cat("pub fn ", f.name, static_generics(f.generics), "(", params, ") -> ", type_(f.ret));
    return rust_templates::fn_(rust_templates::source_doc(Text::lit(""), f.doc), sig, body_lines(f.body));
}


prism_rtl::Turn<Text> RustFn::cycle() const {
    const auto& f = this->f;
    auto f_1 = f;
    return call_value(each_job(f_1.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_type_(t), [=](Text type__17038) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__17038)); });
            });
        }));
    }))), [=](Array<Text> each_17004) {
        return ({
            auto params = lexer::join(each_17004, Text::lit(", "));
            call_then(start_type_(f_1.ret), [=](Text type__17268) {
            return ({
                auto sig = prism_rtl::cat("pub fn ", f_1.name, static_generics(f_1.generics), "(", params, ") -> ", type__17268);
                call_then(start_body_lines(f_1.body), [=](Text body_lines_17317) { return prism_rtl::finished(rust_templates::fn_(rust_templates::source_doc(Text::lit(""), f_1.doc), sig, body_lines_17317)); });
            });
        });
        });
    });
}


/// `Start RustFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_fn(lower::FnDef f) {
    return prism_rtl::make_rc<RustFn>(f);
}


/// StaticGenerics: fn [((Text, [Text]))] -> Text
Text static_generics(const Array<std::tuple<Text, Array<Text>>>& gs) {
    return generics(each(gs, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g = std::get<0>(_p0);
        auto&& bs = std::get<1>(_p0);
        return std::tuple{g, prelude::push(bs, Text::lit("'static"))};
    }));
}


/// RustJob: unbounded fn JobDef -> Text
Text rust_job(const lower::JobDef& j) {
    auto gnames = generic_names(each(j.generics, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g = std::get<0>(_p0);
        return g;
    }));
    auto fields = lexer::join(run_to_end(each_job(j.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_type_(t), [=](Text type__17723) { return prism_rtl::finished(prism_rtl::cat("pub ", n, ": ", type__17723, ",")); });
            });
        }));
    })))), Text::lit("\n"));
    auto params = lexer::join(run_to_end(each_job(j.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_type_(t), [=](Text type__17797) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__17797)); });
            });
        }));
    })))), Text::lit(", "));
    auto bounded_ = static_generics(j.generics);
    auto start = prism_rtl::cat("pub fn ", j.start, bounded_, "(", params, ") -> Rc<dyn prism_rtl::Job<", type_(j.ret), ">>");
    auto start_body = prism_rtl::cat("Rc::new(", j.name, " { ", lexer::join(each(j.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
        auto&& n = std::get<0>(_p0);
        return n;
    }), Text::lit(", ")), " })");
    return rust_templates::job(rust_templates::source_doc(Text::lit(""), j.doc), j.name, gnames, bounded_, fields, type_(j.ret), body_lines(j.body), start, start_body);
}


prism_rtl::Turn<Text> RustJob::cycle() const {
    const auto& j = this->j;
    auto gnames = generic_names(each(j.generics, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g = std::get<0>(_p0);
        return g;
    }));
    auto j_1 = j;
    return call_value(each_job(j_1.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_type_(t), [=](Text type__17723) { return prism_rtl::finished(prism_rtl::cat("pub ", n, ": ", type__17723, ",")); });
            });
        }));
    }))), [=](Array<Text> each_17685) {
        return ({
            auto fields = lexer::join(each_17685, Text::lit("\n"));
            call_value(each_job(j_1.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [n, t] = p0;
                    call_then(start_type_(t), [=](Text type__17797) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__17797)); });
                });
            }));
        }))), [=](Array<Text> each_17763) {
            return ({
                auto params = lexer::join(each_17763, Text::lit(", "));
                auto bounded_ = static_generics(j_1.generics);
                call_then(start_type_(j_1.ret), [=](Text type__18021) {
                return ({
                    auto start = prism_rtl::cat("pub fn ", j_1.start, bounded_, "(", params, ") -> Rc<dyn prism_rtl::Job<", type__18021, ">>");
                    auto start_body = prism_rtl::cat("Rc::new(", j_1.name, " { ", lexer::join(each(j_1.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                        auto&& n = std::get<0>(_p0);
                        return n;
                    }), Text::lit(", ")), " })");
                    call_then(start_type_(j_1.ret), [=](Text type__18196) { return call_then(start_body_lines(j_1.body), [=](Text body_lines_18210) { return prism_rtl::finished(rust_templates::job(rust_templates::source_doc(Text::lit(""), j_1.doc), j_1.name, gnames, bounded_, fields, type__18196, body_lines_18210, start, start_body)); }); });
                });
            });
            });
        });
        });
    });
}


/// `Start RustJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_job(lower::JobDef j) {
    return prism_rtl::make_rc<RustJob>(j);
}


/// TypeDecl: unbounded fn TyDef -> Text
Text type_decl(const lower::TyDef& t) {
    auto eq = t.eq && (!t.floaty);
    auto ord = t.ord && (!t.floaty);
    auto derives = lexer::join(filter(Array(std::vector{Text::lit("Clone"), t.eq || t.ord ? Text::lit("PartialEq") : Text::lit(""), eq || ord ? Text::lit("Eq") : Text::lit(""), t.ord ? Text::lit("PartialOrd") : Text::lit(""), ord ? Text::lit("Ord") : Text::lit("")}), [&](const Text& d) { return d != Text::lit(""); }), Text::lit(", "));
    auto head = prism_rtl::cat(t.name, generic_names(t.params));
    auto doc = rust_templates::source_doc(prism_rtl::cat("`", t.prism, "`:"), t.doc);
    auto decl = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (rust_templates::struct_(doc, derives, head, lexer::join(run_to_end(each_job(c.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto [f, ft] = p0;
                        call_then(start_type_(ft), [=](Text type__18970) { return prism_rtl::finished(prism_rtl::cat("pub ", f, ": ", type__18970, ",")); });
                    });
                }));
            })))), Text::lit("\n"))));
            }));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeUnit>(_m)) {
            _v.set(rust_templates::tuple_struct(doc, derives, head, Text::lit("")));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeNewtype>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (rust_templates::tuple_struct(doc, derives, head, prism_rtl::cat("(", lexer::join(run_to_end(each_job(c.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto&& _ft = p0;
                        auto&& ft = std::get<1>(_ft);
                        call_then(start_type_(ft), [=](Text type__19234) { return prism_rtl::finished(prism_rtl::cat("pub ", type__19234)); });
                    });
                }));
            })))), Text::lit(", ")), ")")));
            }));
            goto _done;
        }
        {
            _v.set(rust_templates::enum_(doc, derives, head, lexer::join(run_to_end(each_job(t.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::CaseDef)>>(prism_rtl::rc([=](lower::CaseDef p0) {
                return entered(once_job([=]() {
                    return ({
                        auto c = p0;
                        (prism_rtl::more(prism_rtl::rc(EnumCase(c))));
                    });
                }));
            })))), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto show_ = t.show_ == lower::Shown(lower::Shown::ShownDerived{})
        ? prism_rtl::cat("\n", show_impl(t, head))
        : Text::lit("");
    auto pod = t.pod
        ? prism_rtl::cat("\n", to_pod_impl(t, head), "\n", from_pod_impl(t, head))
        : Text::lit("");
    return prism_rtl::cat(decl, show_, pod);
}


prism_rtl::Turn<Text> TypeDecl::cycle() const {
    const auto& t = this->t;
    auto eq = t.eq && (!t.floaty);
    auto ord = t.ord && (!t.floaty);
    auto derives = lexer::join(filter(Array(std::vector{Text::lit("Clone"), t.eq || t.ord ? Text::lit("PartialEq") : Text::lit(""), eq || ord ? Text::lit("Eq") : Text::lit(""), t.ord ? Text::lit("PartialOrd") : Text::lit(""), ord ? Text::lit("Ord") : Text::lit("")}), [&](const Text& d) { return d != Text::lit(""); }), Text::lit(", "));
    auto head = prism_rtl::cat(t.name, generic_names(t.params));
    auto doc = rust_templates::source_doc(prism_rtl::cat("`", t.prism, "`:"), t.doc);
    auto decl = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (rust_templates::struct_(doc, derives, head, lexer::join(run_to_end(each_job(c.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto [f, ft] = p0;
                        call_then(start_type_(ft), [=](Text type__18970) { return prism_rtl::finished(prism_rtl::cat("pub ", f, ": ", type__18970, ",")); });
                    });
                }));
            })))), Text::lit("\n"))));
            }));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeUnit>(_m)) {
            _v.set(rust_templates::tuple_struct(doc, derives, head, Text::lit("")));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeNewtype>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (rust_templates::tuple_struct(doc, derives, head, prism_rtl::cat("(", lexer::join(run_to_end(each_job(c.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto&& _ft = p0;
                        auto&& ft = std::get<1>(_ft);
                        call_then(start_type_(ft), [=](Text type__19234) { return prism_rtl::finished(prism_rtl::cat("pub ", type__19234)); });
                    });
                }));
            })))), Text::lit(", ")), ")")));
            }));
            goto _done;
        }
        {
            _v.set(rust_templates::enum_(doc, derives, head, lexer::join(run_to_end(each_job(t.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::CaseDef)>>(prism_rtl::rc([=](lower::CaseDef p0) {
                return entered(once_job([=]() {
                    return ({
                        auto c = p0;
                        (prism_rtl::more(prism_rtl::rc(EnumCase(c))));
                    });
                }));
            })))), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto show_ = t.show_ == lower::Shown(lower::Shown::ShownDerived{})
        ? prism_rtl::cat("\n", show_impl(t, head))
        : Text::lit("");
    auto pod = t.pod
        ? prism_rtl::cat("\n", to_pod_impl(t, head), "\n", from_pod_impl(t, head))
        : Text::lit("");
    return prism_rtl::finished(prism_rtl::cat(decl, show_, pod));
}


/// `Start TypeDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_type_decl(lower::TyDef t) {
    return prism_rtl::make_rc<TypeDecl>(t);
}


/// EnumCase: unbounded fn CaseDef -> Text
Text enum_case(const lower::CaseDef& c) {
    return len(c.fields) == Nat(0u)
        ? prism_rtl::cat(c.name, ",")
        : prism_rtl::cat(c.name, "(", lexer::join(run_to_end(each_job(c.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _ft = p0;
                auto&& ft = std::get<1>(_ft);
                (prism_rtl::more(prism_rtl::rc(Type(ft))));
            });
        }));
    })))), Text::lit(", ")), "),");
}


prism_rtl::Turn<Text> EnumCase::cycle() const {
    const auto& c = this->c;
    return len(c.fields) == Nat(0u)
        ? prism_rtl::finished(prism_rtl::cat(c.name, ","))
        : ({
        auto c_1 = c;
        call_value(each_job(c_1.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _ft = p0;
                auto&& ft = std::get<1>(_ft);
                (prism_rtl::more(prism_rtl::rc(Type(ft))));
            });
        }));
    }))), [=](Array<Text> each_19636) { return prism_rtl::finished(prism_rtl::cat(c_1.name, "(", lexer::join(each_19636, Text::lit(", ")), "),")); });
    });
}


/// `Start EnumCase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_enum_case(lower::CaseDef c) {
    return prism_rtl::make_rc<EnumCase>(c);
}


/// Binders: fn Nat -> [Text]
Array<Text> binders(const Nat& n) {
    return each(check_errors::range0(n), [&](const Nat& i) { return prism_rtl::cat("a", i); });
}


/// CasePattern: fn TyDef, CaseDef -> Text
Text case_pattern(const lower::TyDef& t, const lower::CaseDef& c) {
    auto&& _m = t.shape;
    if (prism_rtl::is<lower::TyShape::ShapeNewtype>(_m)) {
        return prism_rtl::cat(t.name, "(", lexer::join(binders(len(c.fields)), Text::lit(", ")), ")");
    }
    if (prism_rtl::is<lower::TyShape::ShapeUnit>(_m)) {
        return t.name;
    }
    {
        return len(c.fields) == Nat(0u)
            ? prism_rtl::cat(t.name, "::", c.name)
            : prism_rtl::cat(t.name, "::", c.name, "(", lexer::join(binders(len(c.fields)), Text::lit(", ")), ")");
    }
}


/// ShowImpl: unbounded fn TyDef, Text -> Text
Text show_impl(const lower::TyDef& t, const Text& head) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (prism_rtl::cat("p.record(\"", t.prism, "\", &[", lexer::join(each(c.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field(f), "\", &self.", f, ")");
            }), Text::lit(", ")), "]);"));
            }));
            goto _done;
        }
        {
            _v.set(rust_templates::match_self(lexer::join(each(t.cases_, [&](const lower::CaseDef& c) { return prism_rtl::cat(case_pattern(t, c), " => p.choice(\"", c.prism, "\", &[", lexer::join(binders(len(c.fields)), Text::lit(", ")), "]),"); }), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    return rust_templates::impl_(bounded(t.params, Text::lit("Show")), Text::lit("Show"), head, Text::lit("fn show(&self, p: &mut Printer)"), body);
}


prism_rtl::Turn<Text> ShowImpl::cycle() const {
    const auto& t = this->t;
    const auto& head = this->head;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (prism_rtl::cat("p.record(\"", t.prism, "\", &[", lexer::join(each(c.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field(f), "\", &self.", f, ")");
            }), Text::lit(", ")), "]);"));
            }));
            goto _done;
        }
        {
            _v.set(rust_templates::match_self(lexer::join(each(t.cases_, [&](const lower::CaseDef& c) { return prism_rtl::cat(case_pattern(t, c), " => p.choice(\"", c.prism, "\", &[", lexer::join(binders(len(c.fields)), Text::lit(", ")), "]),"); }), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(rust_templates::impl_(bounded(t.params, Text::lit("Show")), Text::lit("Show"), head, Text::lit("fn show(&self, p: &mut Printer)"), body));
}


/// `Start ShowImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_impl(lower::TyDef t, Text head) {
    return prism_rtl::make_rc<ShowImpl>(t, head);
}


/// PrismField: fn Text -> Text
Text prism_field(const Text& f) {
    return lexer::last_char(f) == Text::lit("_") ? lexer::before_last(f) : f;
}


/// ToPodImpl: unbounded fn TyDef, Text -> Text
Text to_pod_impl(const lower::TyDef& t, const Text& head) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (prism_rtl::cat("Pod::record(\"", t.prism, "\", vec![", lexer::join(each(c.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field(f), "\", self.", f, ".to_pod())");
            }), Text::lit(", ")), "])"));
            }));
            goto _done;
        }
        {
            _v.set(rust_templates::match_self(lexer::join(each(t.cases_, [&](const lower::CaseDef& c) { return prism_rtl::cat(case_pattern(t, c), " => Pod::Choice(\"", c.prism, "\".into(), vec![", lexer::join(each(binders(len(c.fields)), [&](const Text& b) { return prism_rtl::cat(b, ".to_pod()"); }), Text::lit(", ")), "]),"); }), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto shown = t.show_ == lower::Shown(lower::Shown::ShownOwn{})
        ? rust_templates::shown_pod(body)
        : body;
    return rust_templates::impl_(bounded(t.params, Text::lit("ToPod")), Text::lit("ToPod"), head, Text::lit("fn to_pod(&self) -> Pod"), shown);
}


prism_rtl::Turn<Text> ToPodImpl::cycle() const {
    const auto& t = this->t;
    const auto& head = this->head;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (prism_rtl::cat("Pod::record(\"", t.prism, "\", vec![", lexer::join(each(c.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field(f), "\", self.", f, ".to_pod())");
            }), Text::lit(", ")), "])"));
            }));
            goto _done;
        }
        {
            _v.set(rust_templates::match_self(lexer::join(each(t.cases_, [&](const lower::CaseDef& c) { return prism_rtl::cat(case_pattern(t, c), " => Pod::Choice(\"", c.prism, "\".into(), vec![", lexer::join(each(binders(len(c.fields)), [&](const Text& b) { return prism_rtl::cat(b, ".to_pod()"); }), Text::lit(", ")), "]),"); }), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto shown = t.show_ == lower::Shown(lower::Shown::ShownOwn{})
        ? rust_templates::shown_pod(body)
        : body;
    return prism_rtl::finished(rust_templates::impl_(bounded(t.params, Text::lit("ToPod")), Text::lit("ToPod"), head, Text::lit("fn to_pod(&self) -> Pod"), shown));
}


/// `Start ToPodImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_to_pod_impl(lower::TyDef t, Text head) {
    return prism_rtl::make_rc<ToPodImpl>(t, head);
}


/// FromPodImpl: unbounded fn TyDef, Text -> Text
Text from_pod_impl(const lower::TyDef& t, const Text& head) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (prism_rtl::cat("Ok(", t.name, " { ", lexer::join(each(c.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat(f, ": FromPod::from_pod(field(p, \"", prism_field(f), "\")?)?");
            }), Text::lit(", ")), " })"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms_ = each(t.cases_, [&](const lower::CaseDef& c) {
                    return ({
                        auto n = len(c.fields);
                        auto made = n == Nat(0u)
                            ? t.shape == lower::TyShape(lower::TyShape::ShapeUnit{})
                            ? t.name
                            : prism_rtl::cat(t.name, "::", c.name)
                            : prism_rtl::cat(t.shape == lower::TyShape(lower::TyShape::ShapeNewtype{})
                            ? t.name
                            : prism_rtl::cat(t.name, "::", c.name), "(", lexer::join(each(check_errors::range0(n), [&](const Nat& i) { return prism_rtl::cat("FromPod::from_pod(&a[", i, "])?"); }), Text::lit(", ")), ")");
                        (prism_rtl::cat("Pod::Choice(c, a) if &**c == \"", c.prism, "\" && a.len() == ", n, " => Ok(", made, "),"));
                    });
                });
                (rust_templates::from_pod_body(lexer::join(arms_, Text::lit("\n")), prism_rtl::cat("a ", t.prism)));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return rust_templates::impl_(bounded(t.params, Text::lit("FromPod")), Text::lit("FromPod"), head, Text::lit("fn from_pod(p: &Pod) -> Result<Self, Fault>"), body);
}


prism_rtl::Turn<Text> FromPodImpl::cycle() const {
    const auto& t = this->t;
    const auto& head = this->head;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (prism_rtl::cat("Ok(", t.name, " { ", lexer::join(each(c.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat(f, ": FromPod::from_pod(field(p, \"", prism_field(f), "\")?)?");
            }), Text::lit(", ")), " })"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms_ = each(t.cases_, [&](const lower::CaseDef& c) {
                    return ({
                        auto n = len(c.fields);
                        auto made = n == Nat(0u)
                            ? t.shape == lower::TyShape(lower::TyShape::ShapeUnit{})
                            ? t.name
                            : prism_rtl::cat(t.name, "::", c.name)
                            : prism_rtl::cat(t.shape == lower::TyShape(lower::TyShape::ShapeNewtype{})
                            ? t.name
                            : prism_rtl::cat(t.name, "::", c.name), "(", lexer::join(each(check_errors::range0(n), [&](const Nat& i) { return prism_rtl::cat("FromPod::from_pod(&a[", i, "])?"); }), Text::lit(", ")), ")");
                        (prism_rtl::cat("Pod::Choice(c, a) if &**c == \"", c.prism, "\" && a.len() == ", n, " => Ok(", made, "),"));
                    });
                });
                (rust_templates::from_pod_body(lexer::join(arms_, Text::lit("\n")), prism_rtl::cat("a ", t.prism)));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(rust_templates::impl_(bounded(t.params, Text::lit("FromPod")), Text::lit("FromPod"), head, Text::lit("fn from_pod(p: &Pod) -> Result<Self, Fault>"), body));
}


/// `Start FromPodImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_from_pod_impl(lower::TyDef t, Text head) {
    return prism_rtl::make_rc<FromPodImpl>(t, head);
}


/// RustTag: unbounded fn TagDef -> Text
Text rust_tag(const lower::TagDef& t) {
    auto fields = lexer::join(run_to_end(each_job(t.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _f = p0;
                auto&& f = std::get<1>(_f);
                auto&& ft = std::get<2>(_f);
                call_then(start_type_(ft), [=](Text type__22643) { return prism_rtl::finished(prism_rtl::cat("pub ", f, ": ", type__22643, ",")); });
            });
        }));
    })))), Text::lit("\n"));
    auto pods = lexer::join(each(t.fields, [&](const std::tuple<Text, Text, lower::OutTy>& _p0) {
        auto&& p_ = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        return prism_rtl::cat("(\"", p_, "\", self.", f, ".to_pod())");
    }), Text::lit(", "));
    auto derives = t.pod ? Text::lit("Clone, PartialEq") : Text::lit("Clone");
    auto reads = lexer::join(each(t.fields, [&](const std::tuple<Text, Text, lower::OutTy>& _p0) {
        auto&& p_ = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        return prism_rtl::cat(f, ": FromPod::from_pod(field(p, \"", p_, "\")?)?");
    }), Text::lit(", "));
    auto back_ = t.pod
        ? prism_rtl::cat("\n", rust_templates::tag_from_pod(t.name, t.tag_name, reads))
        : Text::lit("");
    return prism_rtl::cat(rust_templates::tag(rust_templates::source_doc(prism_rtl::cat("The `Level` of `", t.tag_name, "`:"), t.doc), derives, t.name, fields, t.tag_name, pods), back_);
}


prism_rtl::Turn<Text> RustTag::cycle() const {
    const auto& t = this->t;
    auto t_1 = t;
    return call_value(each_job(t_1.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _f = p0;
                auto&& f = std::get<1>(_f);
                auto&& ft = std::get<2>(_f);
                call_then(start_type_(ft), [=](Text type__22643) { return prism_rtl::finished(prism_rtl::cat("pub ", f, ": ", type__22643, ",")); });
            });
        }));
    }))), [=](Array<Text> each_22596) {
        return ({
            auto fields = lexer::join(each_22596, Text::lit("\n"));
            auto pods = lexer::join(each(t_1.fields, [&](const std::tuple<Text, Text, lower::OutTy>& _p0) {
                auto&& p_ = std::get<0>(_p0);
                auto&& f = std::get<1>(_p0);
                return prism_rtl::cat("(\"", p_, "\", self.", f, ".to_pod())");
            }), Text::lit(", "));
            auto derives = t_1.pod ? Text::lit("Clone, PartialEq") : Text::lit("Clone");
            auto reads = lexer::join(each(t_1.fields, [&](const std::tuple<Text, Text, lower::OutTy>& _p0) {
                auto&& p_ = std::get<0>(_p0);
                auto&& f = std::get<1>(_p0);
                return prism_rtl::cat(f, ": FromPod::from_pod(field(p, \"", p_, "\")?)?");
            }), Text::lit(", "));
            auto back_ = t_1.pod
                ? prism_rtl::cat("\n", rust_templates::tag_from_pod(t_1.name, t_1.tag_name, reads))
                : Text::lit("");
            (prism_rtl::finished(prism_rtl::cat(rust_templates::tag(rust_templates::source_doc(prism_rtl::cat("The `Level` of `", t_1.tag_name, "`:"), t_1.doc), derives, t_1.name, fields, t_1.tag_name, pods), back_)));
        });
    });
}


/// `Start RustTag, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_tag(lower::TagDef t) {
    return prism_rtl::make_rc<RustTag>(t);
}


/// RustRow: unbounded fn RowDef -> Text
Text rust_row(const lower::RowDef& r) {
    auto derives = r.pod ? Text::lit("Clone, PartialEq") : Text::lit("Clone");
    auto cases = lexer::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat(v_, "(", st, "),");
    }), Text::lit("\n"));
    auto pods = lexer::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        return prism_rtl::cat(r.name, "::", v_, "(x) => x.to_pod(),");
    }), Text::lit("\n"));
    auto reads = lexer::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat("Some(t) if t == ", st, "::TAG => Ok(", r.name, "::", v_, "(FromPod::from_pod(p)?)),");
    }), Text::lit("\n"));
    auto back_ = r.pod
        ? prism_rtl::cat("\n", rust_templates::row_from_pod(r.name, reads))
        : Text::lit("");
    auto pods2 = len(r.cases_) == Nat(0u) ? Text::lit("_ => unreachable!(),") : pods;
    return prism_rtl::cat(rust_templates::row(rust_templates::source_doc(prism_rtl::cat("`", r.prism, "`, a row kind's values:"), r.doc), derives, r.name, cases, pods2), back_);
}


prism_rtl::Turn<Text> RustRow::cycle() const {
    const auto& r = this->r;
    auto derives = r.pod ? Text::lit("Clone, PartialEq") : Text::lit("Clone");
    auto cases = lexer::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat(v_, "(", st, "),");
    }), Text::lit("\n"));
    auto pods = lexer::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        return prism_rtl::cat(r.name, "::", v_, "(x) => x.to_pod(),");
    }), Text::lit("\n"));
    auto reads = lexer::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat("Some(t) if t == ", st, "::TAG => Ok(", r.name, "::", v_, "(FromPod::from_pod(p)?)),");
    }), Text::lit("\n"));
    auto back_ = r.pod
        ? prism_rtl::cat("\n", rust_templates::row_from_pod(r.name, reads))
        : Text::lit("");
    auto pods2 = len(r.cases_) == Nat(0u) ? Text::lit("_ => unreachable!(),") : pods;
    return prism_rtl::finished(prism_rtl::cat(rust_templates::row(rust_templates::source_doc(prism_rtl::cat("`", r.prism, "`, a row kind's values:"), r.doc), derives, r.name, cases, pods2), back_));
}


/// `Start RustRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_row(lower::RowDef r) {
    return prism_rtl::make_rc<RustRow>(r);
}


/// RustAnswer: unbounded fn AnswerDef -> Text
Text rust_answer(const lower::AnswerDef& a) {
    auto cases = lexer::join(run_to_end(each_job(a.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::AnswerCase)>>(prism_rtl::rc([=](lower::AnswerCase p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(start_type_(c.ty), [=](Text type__24300) { return prism_rtl::finished(prism_rtl::cat(c.variant, "(", type__24300, "),")); });
            });
        }));
    })))), Text::lit("\n"));
    auto tags = len(a.cases_) == Nat(0u)
        ? Text::lit("_ => unreachable!(),")
        : lexer::join(each(a.cases_, [&](const lower::AnswerCase& c) { return prism_rtl::cat("Answer::", c.variant, "(_) => ", c.struct_path, "::TAG,"); }), Text::lit("\n"));
    auto accessors = lexer::join(run_to_end(each_job(a.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::AnswerCase)>>(prism_rtl::rc([=](lower::AnswerCase p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(start_type_(c.ty), [=](Text type__24562) { return prism_rtl::finished(rust_templates::answer_getter(c.accessor, c.variant, c.tag_name, type__24562)); });
            });
        }));
    })))), Text::lit("\n"));
    auto decodes = len(a.cases_) == Nat(0u)
        ? Text::lit("_ => unreachable!(),")
        : lexer::join(run_to_end(each_job(a.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::AnswerCase)>>(prism_rtl::rc([=](lower::AnswerCase p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(start_decode_head(c.ty), [=](Text decode_head_24725) { return prism_rtl::finished(prism_rtl::cat("Elem::", c.variant, "(..) => Ok(Answer::", c.variant, "(", decode_head_24725, "::from_pod(v)?)),")); });
            });
        }));
    })))), Text::lit("\n"));
    return rust_templates::answer_type(cases, tags, accessors, decodes);
}


prism_rtl::Turn<Text> RustAnswer::cycle() const {
    const auto& a = this->a;
    auto a_1 = a;
    return call_value(each_job(a_1.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::AnswerCase)>>(prism_rtl::rc([=](lower::AnswerCase p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(start_type_(c.ty), [=](Text type__24300) { return prism_rtl::finished(prism_rtl::cat(c.variant, "(", type__24300, "),")); });
            });
        }));
    }))), [=](Array<Text> each_24267) {
        return ({
            auto cases = lexer::join(each_24267, Text::lit("\n"));
            auto tags = len(a_1.cases_) == Nat(0u)
                ? Text::lit("_ => unreachable!(),")
                : lexer::join(each(a_1.cases_, [&](const lower::AnswerCase& c) { return prism_rtl::cat("Answer::", c.variant, "(_) => ", c.struct_path, "::TAG,"); }), Text::lit("\n"));
            call_value(each_job(a_1.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::AnswerCase)>>(prism_rtl::rc([=](lower::AnswerCase p0) {
            return entered(once_job([=]() {
                return ({
                    auto c = p0;
                    call_then(start_type_(c.ty), [=](Text type__24562) { return prism_rtl::finished(rust_templates::answer_getter(c.accessor, c.variant, c.tag_name, type__24562)); });
                });
            }));
        }))), [=](Array<Text> each_24495) {
            return ({
                auto accessors = lexer::join(each_24495, Text::lit("\n"));
                auto decodes = len(a_1.cases_) == Nat(0u)
                    ? Text::lit("_ => unreachable!(),")
                    : lexer::join(run_to_end(each_job(a_1.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::AnswerCase)>>(prism_rtl::rc([=](lower::AnswerCase p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            call_then(start_decode_head(c.ty), [=](Text decode_head_24725) { return prism_rtl::finished(prism_rtl::cat("Elem::", c.variant, "(..) => Ok(Answer::", c.variant, "(", decode_head_24725, "::from_pod(v)?)),")); });
                        });
                    }));
                })))), Text::lit("\n"));
                (prism_rtl::finished(rust_templates::answer_type(cases, tags, accessors, decodes)));
            });
        });
        });
    });
}


/// `Start RustAnswer, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_answer(lower::AnswerDef a) {
    return prism_rtl::make_rc<RustAnswer>(a);
}


/// RustNode: unbounded fn NodeDef -> Text
Text rust_node(const lower::NodeDef& n) {
    auto fields = lexer::join(run_to_end(each_job(n.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy, Text>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy, Text> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f, t, doc] = p0;
                call_then(start_type_(t), [=](Text type__25142) { return prism_rtl::finished(prism_rtl::cat(rust_templates::doc(doc), f, ": ", type__25142, ",")); });
            });
        }));
    })))), Text::lit("\n"));
    auto consts = concat(each(n.consts, [&](const std::tuple<Text, Nat, Text>& _p0) {
        auto&& c = std::get<0>(_p0);
        auto&& h = std::get<1>(_p0);
        auto&& doc = std::get<2>(_p0);
        return prism_rtl::cat(rust_templates::doc(prism_rtl::cat("The ", doc, ".")), "const ", c, ": u32 = ", h, ";\n");
    }));
    auto params = concat(run_to_end(each_job(n.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [p_, t] = p0;
                call_then(start_type_(t), [=](Text type__25320) { return prism_rtl::finished(prism_rtl::cat(p_, ": ", type__25320, ", ")); });
            });
        }));
    })))));
    auto ret = n.fallible
        ? prism_rtl::cat("Result<Rc<", n.name, ">, Fault>")
        : prism_rtl::cat("Rc<", n.name, ">");
    auto inits = lexer::join(append(Array(std::vector{Text::lit("path")}), run_to_end(each_job(n.inits, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Ex> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f, v_] = p0;
                (prism_rtl::more(prism_rtl::rc(FieldInit(f, v_))));
            });
        }));
    }))))), Text::lit(", "));
    auto tail = n.fallible ? Text::lit("Ok(node)") : Text::lit("node");
    auto rest_text = len(n->build) == Nat(0u)
        ? tail
        : prism_rtl::cat(statements(n->build), "\n", tail);
    auto build_1 = rust_templates::build(n.name, params, ret, statements(n.lets), inits, rest_text);
    auto methods = lexer::join(run_to_end(each_job(n.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::MethDef)>>(prism_rtl::rc([=](lower::MethDef p0) {
        return entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(RustMethod(m))));
            });
        }));
    })))), Text::lit("\n"));
    auto answer_2 = len(n.answers) == Nat(0u)
        ? Text::lit("")
        : rust_templates::answer(lexer::join(run_to_end(each_job(n.answers, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<lower::Pa, lower::Ex>)>>(prism_rtl::rc([=](std::tuple<lower::Pa, lower::Ex> p0) {
        return entered(once_job([=]() {
            return ({
                auto [pat, call] = p0;
                call_then(start_pattern(pat), [=](Text pattern_25886) { return call_then(start_expression(call), [=](Text expression_25903) { return prism_rtl::finished(prism_rtl::cat(pattern_25886, " => ", expression_25903, ",")); }); });
            });
        }));
    })))), Text::lit("\n")));
    auto builders = concat(append(run_to_end(each_job(n.builders, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::ForDef)>>(prism_rtl::rc([=](lower::ForDef p0) {
        return entered(once_job([=]() {
            return ({
                auto b = p0;
                call_then(start_for_builder(b), [=](Text for_builder_25991) { return prism_rtl::finished(prism_rtl::cat("\n", for_builder_25991)); });
            });
        }));
    })))), run_to_end(each_job(n.gens, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::GenDef)>>(prism_rtl::rc([=](lower::GenDef p0) {
        return entered(once_job([=]() {
            return ({
                auto gd = p0;
                call_then(start_gen_builder(gd), [=](Text gen_builder_26032) { return prism_rtl::finished(prism_rtl::cat("\n", gen_builder_26032)); });
            });
        }));
    }))))));
    auto row_impl = n.row_kind == lower::RowKind(lower::RowKind::NotARow{})
        ? Text::lit("")
        : prism_rtl::cat("\n", rust_row_impl(n));
    auto hooks = lexer::join(run_to_end(each_job(n.hooks, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<lower::Do>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<lower::Do>> p0) {
        return entered(once_job([=]() {
            return ({
                auto [h, body] = p0;
                h == Text::lit("push")
                ? call_then(start_statements(body), [=](Text statements_26199) { return prism_rtl::finished(rust_templates::push_hook(statements_26199)); })
                : call_then(start_statements(body), [=](Text statements_26231) { return prism_rtl::finished(rust_templates::hook(h, statements_26231)); });
            });
        }));
    })))), Text::lit("\n"));
    auto doc = rust_templates::source_doc(prism_rtl::cat("`", n.prism, "`: a node of its own (claude/backend.md, \"A widget block\")."), n.doc);
    return prism_rtl::cat(rust_templates::node_(doc, n.name, fields, consts, build_1, prism_rtl::cat(methods, builders), hooks, answer_2), row_impl);
}


prism_rtl::Turn<Text> RustNode::cycle() const {
    const auto& n = this->n;
    auto n_1 = n;
    return call_value(each_job(n_1.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy, Text>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy, Text> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f, t, doc] = p0;
                call_then(start_type_(t), [=](Text type__25142) { return prism_rtl::finished(prism_rtl::cat(rust_templates::doc(doc), f, ": ", type__25142, ",")); });
            });
        }));
    }))), [=](Array<Text> each_25094) {
        return ({
            auto fields = lexer::join(each_25094, Text::lit("\n"));
            auto consts = concat(each(n_1.consts, [&](const std::tuple<Text, Nat, Text>& _p0) {
                auto&& c = std::get<0>(_p0);
                auto&& h = std::get<1>(_p0);
                auto&& doc = std::get<2>(_p0);
                return prism_rtl::cat(rust_templates::doc(prism_rtl::cat("The ", doc, ".")), "const ", c, ": u32 = ", h, ";\n");
            }));
            call_value(each_job(n_1.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [p_, t] = p0;
                    call_then(start_type_(t), [=](Text type__25320) { return prism_rtl::finished(prism_rtl::cat(p_, ": ", type__25320, ", ")); });
                });
            }));
        }))), [=](Array<Text> each_25286) {
            return ({
                auto params = concat(each_25286);
                auto ret = n_1.fallible
                    ? prism_rtl::cat("Result<Rc<", n_1.name, ">, Fault>")
                    : prism_rtl::cat("Rc<", n_1.name, ">");
                call_value(each_job(n_1.inits, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Ex> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto [f, v_] = p0;
                        (prism_rtl::more(prism_rtl::rc(FieldInit(f, v_))));
                    });
                }));
            }))), [=](Array<Text> each_25454) {
                return ({
                    auto inits = lexer::join(append(Array(std::vector{Text::lit("path")}), each_25454), Text::lit(", "));
                    auto tail = n_1.fallible ? Text::lit("Ok(node)") : Text::lit("node");
                    auto rest_text = len(n_1->build) == Nat(0u)
                        ? tail
                        : prism_rtl::cat(statements(n_1->build), "\n", tail);
                    call_then(start_statements(n_1.lets), [=](Text statements_25685) {
                    return ({
                        auto build_2 = rust_templates::build(n_1.name, params, ret, statements_25685, inits, rest_text);
                        call_value(each_job(n_1.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::MethDef)>>(prism_rtl::rc([=](lower::MethDef p0) {
                        return entered(once_job([=]() {
                            return ({
                                auto m = p0;
                                (prism_rtl::more(prism_rtl::rc(RustMethod(m))));
                            });
                        }));
                    }))), [=](Array<Text> each_25745) {
                        return ({
                            auto methods = lexer::join(each_25745, Text::lit("\n"));
                            auto answer_3 = len(n_1.answers) == Nat(0u)
                                ? Text::lit("")
                                : rust_templates::answer(lexer::join(run_to_end(each_job(n_1.answers, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<lower::Pa, lower::Ex>)>>(prism_rtl::rc([=](std::tuple<lower::Pa, lower::Ex> p0) {
                                return entered(once_job([=]() {
                                    return ({
                                        auto [pat, call] = p0;
                                        call_then(start_pattern(pat), [=](Text pattern_25886) { return call_then(start_expression(call), [=](Text expression_25903) { return prism_rtl::finished(prism_rtl::cat(pattern_25886, " => ", expression_25903, ",")); }); });
                                    });
                                }));
                            })))), Text::lit("\n")));
                            call_value(each_job(n_1.builders, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::ForDef)>>(prism_rtl::rc([=](lower::ForDef p0) {
                            return entered(once_job([=]() {
                                return ({
                                    auto b = p0;
                                    call_then(start_for_builder(b), [=](Text for_builder_25991) { return prism_rtl::finished(prism_rtl::cat("\n", for_builder_25991)); });
                                });
                            }));
                        }))), [=](Array<Text> each_25965) {
                            return call_value(each_job(n_1.gens, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::GenDef)>>(prism_rtl::rc([=](lower::GenDef p0) {
                                return entered(once_job([=]() {
                                    return ({
                                        auto gd = p0;
                                        call_then(start_gen_builder(gd), [=](Text gen_builder_26032) { return prism_rtl::finished(prism_rtl::cat("\n", gen_builder_26032)); });
                                    });
                                }));
                            }))), [=](Array<Text> each_26009) {
                                return ({
                                    auto builders = concat(append(each_25965, each_26009));
                                    auto row_impl = n_1.row_kind == lower::RowKind(lower::RowKind::NotARow{})
                                        ? Text::lit("")
                                        : prism_rtl::cat("\n", rust_row_impl(n_1));
                                    call_value(each_job(n_1.hooks, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<lower::Do>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<lower::Do>> p0) {
                                    return entered(once_job([=]() {
                                        return ({
                                            auto [h, body] = p0;
                                            h == Text::lit("push")
                                            ? call_then(start_statements(body), [=](Text statements_26199) { return prism_rtl::finished(rust_templates::push_hook(statements_26199)); })
                                            : call_then(start_statements(body), [=](Text statements_26231) { return prism_rtl::finished(rust_templates::hook(h, statements_26231)); });
                                        });
                                    }));
                                }))), [=](Array<Text> each_26144) {
                                    return ({
                                        auto hooks = lexer::join(each_26144, Text::lit("\n"));
                                        auto doc = rust_templates::source_doc(prism_rtl::cat("`", n_1.prism, "`: a node of its own (claude/backend.md, \"A widget block\")."), n_1.doc);
                                        (prism_rtl::finished(prism_rtl::cat(rust_templates::node_(doc, n_1.name, fields, consts, build_2, prism_rtl::cat(methods, builders), hooks, answer_3), row_impl)));
                                    });
                                });
                                });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start RustNode, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_node(lower::NodeDef n) {
    return prism_rtl::make_rc<RustNode>(n);
}


/// ForBuilder: unbounded fn ForDef -> Text
Text for_builder(const lower::ForDef& b) {
    return rust_templates::for_build(b.name, expression(b.at), type_(b.key_ty), type_(b.value_ty), b.row_node, b->source, expression(b->parent), concat(run_to_end(each_job(b.passed, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
        return entered(once_job([=]() {
            return ({
                auto x = p0;
                call_then(start_expression(x), [=](Text expression_26724) { return prism_rtl::finished(prism_rtl::cat(", ", expression_26724)); });
            });
        }));
    }))))));
}


prism_rtl::Turn<Text> ForBuilder::cycle() const {
    const auto& b = this->b;
    auto b_1 = b;
    return call_then(start_expression(b_1.at), [=](Text expression_26595) {
        return call_then(start_type_(b_1.key_ty), [=](Text type__26614) {
            return call_then(start_type_(b_1.value_ty), [=](Text type__26630) {
                return call_then(start_expression(b_1->parent), [=](Text expression_26669) {
                    return call_value(each_job(b_1.passed, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
                        return entered(once_job([=]() {
                            return ({
                                auto x = p0;
                                call_then(start_expression(x), [=](Text expression_26724) { return prism_rtl::finished(prism_rtl::cat(", ", expression_26724)); });
                            });
                        }));
                    }))), [=](Array<Text> each_26700) { return prism_rtl::finished(rust_templates::for_build(b_1.name, expression_26595, type__26614, type__26630, b_1.row_node, b_1->source, expression_26669, concat(each_26700))); });
                });
            });
        });
    });
}


/// `Start ForBuilder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_for_builder(lower::ForDef b) {
    return prism_rtl::make_rc<ForBuilder>(b);
}


/// GenBuilder: unbounded fn GenDef -> Text
Text gen_builder(const lower::GenDef& gd) {
    auto path_ = gd.transparent
        ? Text::lit("self.path.clone()")
        : prism_rtl::cat(expression(gd.at), ".child(Segment::Gen(g))");
    return rust_templates::gen_build(gd.name, expression(gd.at), path_, expression(gd->source), type_(gd.value_ty), expression(gd.select));
}


prism_rtl::Turn<Text> GenBuilder::cycle() const {
    const auto& gd = this->gd;
    auto path_ = gd.transparent
        ? Text::lit("self.path.clone()")
        : prism_rtl::cat(expression(gd.at), ".child(Segment::Gen(g))");
    auto gd_1 = gd;
    return call_then(start_expression(gd_1.at), [=](Text expression_27118) { return call_then(start_expression(gd_1->source), [=](Text expression_27144) { return call_then(start_type_(gd_1.value_ty), [=](Text type__27168) { return call_then(start_expression(gd_1.select), [=](Text expression_27187) { return prism_rtl::finished(rust_templates::gen_build(gd_1.name, expression_27118, path_, expression_27144, type__27168, expression_27187)); }); }); }); });
}


/// `Start GenBuilder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_gen_builder(lower::GenDef gd) {
    return prism_rtl::make_rc<GenBuilder>(gd);
}


/// RustRowImpl: unbounded fn NodeDef -> Text
Text rust_row_impl(const lower::NodeDef& n) {
    auto kept = n.row_kind == lower::RowKind(lower::RowKind::ForRow{})
        ? Array(std::vector{Text::lit("*self.left_entry.borrow_mut() = Some(self.entry(cx));")})
        : Array<Text>{};
    auto unsubscribe = each(n.subs, [&](const std::tuple<Text, Text, lower::OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        return prism_rtl::cat("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.", m, "_sub.take()) {\n    p.", ev, "_port.unsubscribe(h);\n}");
    });
    return rust_templates::row_impl(n.name, lexer::join(append(prelude::push(kept, Text::lit("self.remove_places(cx);")), unsubscribe), Text::lit("\n")), lexer::join(run_to_end(each_job(n.hosted, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::MethDef)>>(prism_rtl::rc([=](lower::MethDef p0) {
        return entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(RustMethod(m))));
            });
        }));
    })))), Text::lit("\n")));
}


prism_rtl::Turn<Text> RustRowImpl::cycle() const {
    const auto& n = this->n;
    auto kept = n.row_kind == lower::RowKind(lower::RowKind::ForRow{})
        ? Array(std::vector{Text::lit("*self.left_entry.borrow_mut() = Some(self.entry(cx));")})
        : Array<Text>{};
    auto unsubscribe = each(n.subs, [&](const std::tuple<Text, Text, lower::OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        return prism_rtl::cat("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.", m, "_sub.take()) {\n    p.", ev, "_port.unsubscribe(h);\n}");
    });
    auto n_1 = n;
    return call_value(each_job(n_1.hosted, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::MethDef)>>(prism_rtl::rc([=](lower::MethDef p0) {
        return entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(RustMethod(m))));
            });
        }));
    }))), [=](Array<Text> each_27885) { return prism_rtl::finished(rust_templates::row_impl(n_1.name, lexer::join(append(prelude::push(kept, Text::lit("self.remove_places(cx);")), unsubscribe), Text::lit("\n")), lexer::join(each_27885, Text::lit("\n")))); });
}


/// `Start RustRowImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_row_impl(lower::NodeDef n) {
    return prism_rtl::make_rc<RustRowImpl>(n);
}


/// RustMethod: unbounded fn MethDef -> Text
Text rust_method(const lower::MethDef& m) {
    auto recv = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.recv;
        if (prism_rtl::is<lower::Recv::RecvRc>(_m)) {
            _v.set(Text::lit("self: &Rc<Self>"));
            goto _done;
        }
        if (prism_rtl::is<lower::Recv::RecvRef>(_m)) {
            _v.set(Text::lit("&self"));
            goto _done;
        }
        if (prism_rtl::is<lower::Recv::RecvOwned>(_m)) {
            _v.set(Text::lit("self: Rc<Self>"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cx_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.cx_;
        if (prism_rtl::is<lower::CxArg::CxMut>(_m)) {
            _v.set(Text::lit(", cx: &mut Cx"));
            goto _done;
        }
        if (prism_rtl::is<lower::CxArg::CxRef>(_m)) {
            _v.set(Text::lit(", cx: &Cx"));
            goto _done;
        }
        if (prism_rtl::is<lower::CxArg::CxNone>(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto params = concat(run_to_end(each_job(m.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [p_, t] = p0;
                call_then(start_type_(t), [=](Text type__28272) { return prism_rtl::finished(prism_rtl::cat(", ", p_, ": ", type__28272)); });
            });
        }));
    })))));
    auto ret = m.ret == lower::OutTy(lower::OutTy::OutUnit{})
        ? Text::lit("")
        : prism_rtl::cat(" -> ", type_(m.ret));
    auto sig = prism_rtl::cat("fn ", m.name, "(", recv, params, cx_, ")", ret);
    auto body = m.ret == lower::OutTy(lower::OutTy::OutUnit{})
        ? statements(m.body)
        : len(m.body) == Nat(0u)
        ? body_lines(m.tail)
        : prism_rtl::cat(statements(m.body), "\n", body_lines(m.tail));
    return rust_templates::method(rust_templates::doc(m.doc), sig, body);
}


prism_rtl::Turn<Text> RustMethod::cycle() const {
    const auto& m = this->m;
    auto recv = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.recv;
        if (prism_rtl::is<lower::Recv::RecvRc>(_m)) {
            _v.set(Text::lit("self: &Rc<Self>"));
            goto _done;
        }
        if (prism_rtl::is<lower::Recv::RecvRef>(_m)) {
            _v.set(Text::lit("&self"));
            goto _done;
        }
        if (prism_rtl::is<lower::Recv::RecvOwned>(_m)) {
            _v.set(Text::lit("self: Rc<Self>"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cx_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.cx_;
        if (prism_rtl::is<lower::CxArg::CxMut>(_m)) {
            _v.set(Text::lit(", cx: &mut Cx"));
            goto _done;
        }
        if (prism_rtl::is<lower::CxArg::CxRef>(_m)) {
            _v.set(Text::lit(", cx: &Cx"));
            goto _done;
        }
        if (prism_rtl::is<lower::CxArg::CxNone>(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto m_1 = m;
    return call_value(each_job(m_1.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [p_, t] = p0;
                call_then(start_type_(t), [=](Text type__28272) { return prism_rtl::finished(prism_rtl::cat(", ", p_, ": ", type__28272)); });
            });
        }));
    }))), [=](Array<Text> each_28236) {
        return ({
            auto params = concat(each_28236);
            auto ret = m_1.ret == lower::OutTy(lower::OutTy::OutUnit{})
                ? Text::lit("")
                : prism_rtl::cat(" -> ", type_(m_1.ret));
            auto sig = prism_rtl::cat("fn ", m_1.name, "(", recv, params, cx_, ")", ret);
            auto body = m_1.ret == lower::OutTy(lower::OutTy::OutUnit{})
                ? statements(m_1.body)
                : len(m_1.body) == Nat(0u)
                ? body_lines(m_1.tail)
                : prism_rtl::cat(statements(m_1.body), "\n", body_lines(m_1.tail));
            (prism_rtl::finished(rust_templates::method(rust_templates::doc(m_1.doc), sig, body)));
        });
    });
}


/// `Start RustMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_method(lower::MethDef m) {
    return prism_rtl::make_rc<RustMethod>(m);
}


/// RustProgram: unbounded fn ProgDef, Bool -> Text
Text rust_program(const lower::ProgDef& p_, const bool& fallible) {
    auto n = len(p_.params);
    auto names = each(p_.params, [&](const std::tuple<Text, lower::OutTy>& _p0) {
        auto&& a = std::get<0>(_p0);
        return a;
    });
    auto decode = n == Nat(0u) ? Text::lit("let _ = args;") : decode_args(p_, names);
    auto call = prism_rtl::cat(p_.node_, "::build(Path::root(), ", concat(each(names, [&](const Text& a) { return prism_rtl::cat(a, ", "); })), "&mut cx)", fallible ? Text::lit("?") : Text::lit(""));
    return rust_templates::program(p_.name, p_.prism, p_.node_, decode, call);
}


prism_rtl::Turn<Text> RustProgram::cycle() const {
    const auto& p_ = this->p_;
    const auto& fallible = this->fallible;
    auto n = len(p_.params);
    auto names = each(p_.params, [&](const std::tuple<Text, lower::OutTy>& _p0) {
        auto&& a = std::get<0>(_p0);
        return a;
    });
    auto decode = n == Nat(0u) ? Text::lit("let _ = args;") : decode_args(p_, names);
    auto call = prism_rtl::cat(p_.node_, "::build(Path::root(), ", concat(each(names, [&](const Text& a) { return prism_rtl::cat(a, ", "); })), "&mut cx)", fallible ? Text::lit("?") : Text::lit(""));
    return prism_rtl::finished(rust_templates::program(p_.name, p_.prism, p_.node_, decode, call));
}


/// `Start RustProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_program(lower::ProgDef p_, bool fallible) {
    return prism_rtl::make_rc<RustProgram>(p_, fallible);
}


/// DecodeArgs: unbounded fn ProgDef, [Text] -> Text
Text decode_args(const lower::ProgDef& p_, const Array<Text>& names) {
    auto n = len(names);
    auto plural = n == Nat(1u) ? Text::lit("") : Text::lit("s");
    auto head = prism_rtl::cat("let [", lexer::join(names, Text::lit(", ")), "] = args else { return Err(Fault::answer(\"@", p_.prism, " takes ", n, " argument", plural, "\")) };");
    return lexer::join(append(Array(std::vector{head}), run_to_end(each_job(p_.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [a, t] = p0;
                call_then(start_decode_head(t), [=](Text decode_head_29303) { return prism_rtl::finished(prism_rtl::cat("let ", a, " = ", decode_head_29303, "::from_pod(", a, ")?;")); });
            });
        }));
    }))))), Text::lit("\n"));
}


prism_rtl::Turn<Text> DecodeArgs::cycle() const {
    const auto& p_ = this->p_;
    const auto& names = this->names;
    auto n = len(names);
    auto plural = n == Nat(1u) ? Text::lit("") : Text::lit("s");
    auto head = prism_rtl::cat("let [", lexer::join(names, Text::lit(", ")), "] = args else { return Err(Fault::answer(\"@", p_.prism, " takes ", n, " argument", plural, "\")) };");
    auto p__1 = p_;
    return call_value(each_job(p__1.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [a, t] = p0;
                call_then(start_decode_head(t), [=](Text decode_head_29303) { return prism_rtl::finished(prism_rtl::cat("let ", a, " = ", decode_head_29303, "::from_pod(", a, ")?;")); });
            });
        }));
    }))), [=](Array<Text> each_29264) { return prism_rtl::finished(lexer::join(append(Array(std::vector{head}), each_29264), Text::lit("\n"))); });
}


/// `Start DecodeArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_decode_args(lower::ProgDef p_, Array<Text> names) {
    return prism_rtl::make_rc<DecodeArgs>(p_, names);
}


/// RustModule: unbounded fn ModDef -> Text
Text rust_module(const lower::ModDef& m) {
    auto uses = len(m.uses) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat("#[allow(unused_imports)]\nuse crate::{", lexer::join(m.uses, Text::lit(", ")), "};");
    return rust_templates::module(m.prism == Text::lit("")
        ? Text::lit("The root module")
        : prism_rtl::cat("The module `", m.prism, "`"), m->path_, uses, lexer::join(run_to_end(each_job(m.items, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Item)>>(prism_rtl::rc([=](lower::Item p0) {
        return entered(once_job([=]() {
            return ({
                auto it = p0;
                (prism_rtl::more(prism_rtl::rc(RustItem(it))));
            });
        }));
    })))), Text::lit("\n")));
}


prism_rtl::Turn<Text> RustModule::cycle() const {
    const auto& m = this->m;
    auto uses = len(m.uses) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat("#[allow(unused_imports)]\nuse crate::{", lexer::join(m.uses, Text::lit(", ")), "};");
    auto m_1 = m;
    return call_value(each_job(m_1.items, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Item)>>(prism_rtl::rc([=](lower::Item p0) {
        return entered(once_job([=]() {
            return ({
                auto it = p0;
                (prism_rtl::more(prism_rtl::rc(RustItem(it))));
            });
        }));
    }))), [=](Array<Text> each_29806) {
        return prism_rtl::finished(rust_templates::module(m_1.prism == Text::lit("")
            ? Text::lit("The root module")
            : prism_rtl::cat("The module `", m_1.prism, "`"), m_1->path_, uses, lexer::join(each_29806, Text::lit("\n"))));
    });
}


/// `Start RustModule, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_module(lower::ModDef m) {
    return prism_rtl::make_rc<RustModule>(m);
}


/// NodeFallible: fn Model, Text -> Bool
bool node_fallible(const lower::Model& model, const Text& path_) {
    return fold(model.mods, false, [&](const bool& f, const lower::ModDef& m) {
        return fold(m.items, f, [&](const bool& f2, const lower::Item& it) {
            return ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                if (prism_rtl::is<lower::Item::ItNode>(it)) {
                    auto&& n = prism_rtl::as<lower::Item::ItNode>(it).a0;
                    _v.set(f2 || ((prism_rtl::cat(m.name, "::", n.name) == path_) && n.fallible));
                    goto _done;
                }
                {
                    _v.set(f2);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
    });
}


/// EmitCrate: unbounded fn Model, Text, [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> emit_crate(const lower::Model& model, const Text& runtime, const Array<Text>& scripts) {
    auto gui = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(r->world == Text::lit("canvas"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cargo_1 = rust_templates::cargo(model.name, runtime, gui ? Text::lit("\"canvas\"") : Text::lit(""));
    auto mods = concat(each(model.mods, [&](const lower::ModDef& m) { return prism_rtl::cat("mod ", m.name, ";\n"); }));
    auto programs = lexer::join(run_to_end(each_job(all_programs(model), ({
        auto model_2 = model;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::ProgDef)>>(prism_rtl::rc([=](lower::ProgDef p0) {
        return ({
            auto model_2_3 = model_2;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(RustProgram(p_, node_fallible(model_2_3, p_.node_)))));
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto regs = concat(each(model.programs, [&](const lower::ProgDef& p_) { return prism_rtl::cat(".program::<", p_.name, ">(\"", p_.prism, "\")\n"); }));
    auto checks = concat(run_to_end(each_job(model.checks, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::CheckDef)>>(prism_rtl::rc([=](lower::CheckDef p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                call_value(each_job(c.lines, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
                return entered(once_job([=]() {
                    return ({
                        auto l = p0;
                        (prism_rtl::more(prism_rtl::rc(Expression(l))));
                    });
                }));
            }))), [=](Array<Text> each_30768) { return prism_rtl::finished(prism_rtl::cat(".check(\"", c.name, "\", || vec![", lexer::join(each_30768, Text::lit(", ")), "])\n")); });
            });
        }));
    })))));
    auto script_list = concat(each(scripts, [&](const Text& s) { return prism_rtl::cat("\"", lower::escape(s), "\",\n"); }));
    auto run_root_2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(rust_templates::run_root(r.name));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(rust_templates::no_root(model.name));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto world = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(r->world);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit("test"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto main_3 = rust_templates::main(model.name, prism_rtl::cat("mod prelude;\n", mods), prism_rtl::cat(rust_row(model.elem), "\n", rust_answer(model->answer), "\n", programs), prism_rtl::cat(regs, checks), script_list, run_root_2, world);
    auto files = run_to_end(each_job(model.mods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(lower::ModDef)>>(prism_rtl::rc([=](lower::ModDef p0) {
        return entered(once_job([=]() {
            return ({
                auto m = p0;
                call_then(start_rust_module(m), [=](Text rust_module_31279) { return prism_rtl::finished(std::tuple{prism_rtl::cat("src/", m.name, ".rs"), rust_module_31279}); });
            });
        }));
    }))));
    return append(Array(std::vector{std::tuple{Text::lit("Cargo.toml"), cargo_1}, std::tuple{Text::lit("src/main.rs"), main_3}, std::tuple{Text::lit("src/prelude.rs"), prelude_template::prelude_source(Text::lit(""))}}), files);
}


prism_rtl::Turn<Array<std::tuple<Text, Text>>> EmitCrate::cycle() const {
    const auto& model = this->model;
    const auto& runtime = this->runtime;
    const auto& scripts = this->scripts;
    auto gui = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(r->world == Text::lit("canvas"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cargo_1 = rust_templates::cargo(model.name, runtime, gui ? Text::lit("\"canvas\"") : Text::lit(""));
    auto mods = concat(each(model.mods, [&](const lower::ModDef& m) { return prism_rtl::cat("mod ", m.name, ";\n"); }));
    auto model_2 = model;
    auto scripts_3 = scripts;
    return call_value(each_job(all_programs(model_2), ({
        auto model_2_4 = model_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::ProgDef)>>(prism_rtl::rc([=](lower::ProgDef p0) {
        return ({
            auto model_2_4_4 = model_2_4;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(RustProgram(p_, node_fallible(model_2_4_4, p_.node_)))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_30510) {
        return ({
            auto programs = lexer::join(each_30510, Text::lit("\n"));
            auto regs = concat(each(model_2.programs, [&](const lower::ProgDef& p_) { return prism_rtl::cat(".program::<", p_.name, ">(\"", p_.prism, "\")\n"); }));
            call_value(each_job(model_2.checks, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::CheckDef)>>(prism_rtl::rc([=](lower::CheckDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto c = p0;
                    call_value(each_job(c.lines, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto l = p0;
                            (prism_rtl::more(prism_rtl::rc(Expression(l))));
                        });
                    }));
                }))), [=](Array<Text> each_30768) { return prism_rtl::finished(prism_rtl::cat(".check(\"", c.name, "\", || vec![", lexer::join(each_30768, Text::lit(", ")), "])\n")); });
                });
            }));
        }))), [=](Array<Text> each_30707) {
            return ({
                auto checks = concat(each_30707);
                auto script_list = concat(each(scripts_3, [&](const Text& s) { return prism_rtl::cat("\"", lower::escape(s), "\",\n"); }));
                auto run_root_4 = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = model_2.root;
                    if (prism_rtl::is_some(_m)) {
                        auto&& r = prism_rtl::some_of(_m);
                        _v.set(rust_templates::run_root(r.name));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(rust_templates::no_root(model_2.name));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto world = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = model_2.root;
                    if (prism_rtl::is_some(_m)) {
                        auto&& r = prism_rtl::some_of(_m);
                        _v.set(r->world);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit("test"));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_rust_row(model_2.elem), [=](Text rust_row_31113) {
                return call_then(start_rust_answer(model_2->answer), [=](Text rust_answer_31135) {
                    return ({
                        auto main_5 = rust_templates::main(model_2.name, prism_rtl::cat("mod prelude;\n", mods), prism_rtl::cat(rust_row_31113, "\n", rust_answer_31135, "\n", programs), prism_rtl::cat(regs, checks), script_list, run_root_4, world);
                        call_value(each_job(model_2.mods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(lower::ModDef)>>(prism_rtl::rc([=](lower::ModDef p0) {
                        return entered(once_job([=]() {
                            return ({
                                auto m = p0;
                                call_then(start_rust_module(m), [=](Text rust_module_31279) { return prism_rtl::finished(std::tuple{prism_rtl::cat("src/", m.name, ".rs"), rust_module_31279}); });
                            });
                        }));
                    }))), [=](Array<std::tuple<Text, Text>> each_31235) {
                        return ({
                            auto files = each_31235;
                            (prism_rtl::finished(append(Array(std::vector{std::tuple{Text::lit("Cargo.toml"), cargo_1}, std::tuple{Text::lit("src/main.rs"), main_5}, std::tuple{Text::lit("src/prelude.rs"), prelude_template::prelude_source(Text::lit(""))}}), files)));
                        });
                    });
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start EmitCrate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_emit_crate(lower::Model model, Text runtime, Array<Text> scripts) {
    return prism_rtl::make_rc<EmitCrate>(model, runtime, scripts);
}


/// AllPrograms: fn Model -> [ProgDef]
Array<lower::ProgDef> all_programs(const lower::Model& model) {
    auto&& _m = model.root;
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return fold(model.programs, false, [&](const bool& f, const lower::ProgDef& p_) { return f || (p_.name == r.name); })
            ? model.programs
            : prelude::push(model.programs, r);
    }
    if (prism_rtl::is_none(_m)) {
        return model.programs;
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::emit
