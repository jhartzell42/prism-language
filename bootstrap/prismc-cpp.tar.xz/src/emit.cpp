// The module `Emit`, from `target/bootstrap/cpp-src/prismc/emit.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "crate.hpp"

namespace crate::emit {

/// Type: unbounded fn OutTy -> Text
Text type_(const lower::OutTy& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::OutTy::OutNat>(t)) {
            _v.set(Text("Nat"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutInt>(t)) {
            _v.set(Text("Int"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutU8>(t)) {
            _v.set(Text("u8"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutFloat>(t)) {
            _v.set(Text("f64"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutBool>(t)) {
            _v.set(Text("bool"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutChar>(t)) {
            _v.set(Text("char"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutText>(t)) {
            _v.set(Text("Text"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutUnit>(t)) {
            _v.set(Text("()"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutPath>(t)) {
            _v.set(Text("Path"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutDuration>(t)) {
            _v.set(Text("Duration"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutError>(t)) {
            _v.set(Text("Error"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
            auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
            auto&& m1006_11_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
            if (m1006_11_1.size() == 0u) {
                _v.set(n);
                goto _done;
            }
        }
        if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
            auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
            auto&& args_ = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
            _v.set(prism_rtl::cat(n, "<", types(args_), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutOpt>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutOpt>(t).a0;
            _v.set(prism_rtl::cat("Option<", type_(i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutRes>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutRes>(t).a0;
            _v.set(prism_rtl::cat("Result<", type_(i), ", Error>"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutTuple>(t)) {
            auto&& m1006_15_0 = prism_rtl::as<lower::OutTy::OutTuple>(t).a0;
            if (m1006_15_0.size() == 1u) {
                {
                    auto&& _c1 = index(m1006_15_0, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& one = prism_rtl::some_of(_c1);
                        _v.set(prism_rtl::cat("(", type_(one), ",)"));
                        goto _done;
                    }
                }
            }
        }
        if (prism_rtl::is<lower::OutTy::OutTuple>(t)) {
            auto&& ts = prism_rtl::as<lower::OutTy::OutTuple>(t).a0;
            _v.set(prism_rtl::cat("(", types(ts), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutArray>(t)) {
            auto&& e = prism_rtl::as<lower::OutTy::OutArray>(t).a0;
            _v.set(prism_rtl::cat("Array<", type_(e), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutMap>(t)) {
            auto&& k = prism_rtl::as<lower::OutTy::OutMap>(t).a0;
            auto&& v_ = prism_rtl::as<lower::OutTy::OutMap>(t).a1;
            _v.set(prism_rtl::cat("Map<", type_(k), ", ", type_(v_), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutFn>(t)) {
            auto&& ps = prism_rtl::as<lower::OutTy::OutFn>(t).a0;
            auto&& r = prism_rtl::as<lower::OutTy::OutFn>(t).a1;
            _v.set(prism_rtl::cat("Rc<dyn Fn(", ref_types(ps), ") -> ", type_(r), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutRef>(t)) {
            auto&& m1006_20_0 = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
            if (prism_rtl::is<lower::OutTy::OutFn>(m1006_20_0)) {
                auto&& ps = prism_rtl::as<lower::OutTy::OutFn>(m1006_20_0).a0;
                auto&& r = prism_rtl::as<lower::OutTy::OutFn>(m1006_20_0).a1;
                _v.set(prism_rtl::cat("&dyn Fn(", ref_types(ps), ") -> ", type_(r)));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::OutTy::OutRef>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
            _v.set(prism_rtl::cat("&", type_(i)));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutJobFn>(t)) {
            auto&& a = prism_rtl::as<lower::OutTy::OutJobFn>(t).a0;
            auto&& b = prism_rtl::as<lower::OutTy::OutJobFn>(t).a1;
            _v.set(prism_rtl::cat("Rc<dyn Fn(", type_(a), ") -> Rc<dyn prism_rtl::Job<", type_(b), ">>>"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutJob>(t)) {
            auto&& b = prism_rtl::as<lower::OutTy::OutJob>(t).a0;
            _v.set(prism_rtl::cat("Rc<dyn prism_rtl::Job<", type_(b), ">>"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutEvent>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutEvent>(t).a0;
            _v.set(prism_rtl::cat("Event<", type_(i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutDyn>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutDyn>(t).a0;
            _v.set(prism_rtl::cat("Dynamic<", type_(i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutGen>(t)) {
            auto&& n = prism_rtl::as<lower::OutTy::OutGen>(t).a0;
            _v.set(n);
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutRc>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutRc>(t).a0;
            _v.set(prism_rtl::cat("Rc<", type_(i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutPod>(t)) {
            _v.set(Text("Pod"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutShowAny>(t)) {
            _v.set(Text("Rc<dyn Show>"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutHold>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutHold>(t).a0;
            _v.set(prism_rtl::cat("Hold<", type_(i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutStamped>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutStamped>(t).a0;
            _v.set(prism_rtl::cat("Stamped<", type_(i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutSnapshot>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutSnapshot>(t).a0;
            _v.set(prism_rtl::cat("Snapshot<", type_(i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutDefer>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutDefer>(t).a0;
            _v.set(prism_rtl::cat("Defer<", type_(i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutWeak>(t)) {
            auto&& n = prism_rtl::as<lower::OutTy::OutWeak>(t).a0;
            _v.set(prism_rtl::cat("Weak<", n, ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutCell>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutCell>(t).a0;
            _v.set(prism_rtl::cat("RefCell<", type_(i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutWakes>(t)) {
            _v.set(Text("Wakes"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutCount>(t)) {
            _v.set(Text("u32"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutObj>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutObj>(t).a0;
            _v.set(prism_rtl::cat("Rc<dyn ", type_(i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutSlice>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutSlice>(t).a0;
            _v.set(prism_rtl::cat("[", type_(i), "]"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutPort>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutPort>(t).a0;
            _v.set(prism_rtl::cat("Port<", type_(i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutLive>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutLive>(t).a0;
            _v.set(prism_rtl::cat("Live<", type_(i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutUnknown>(t)) {
            auto&& what = prism_rtl::as<lower::OutTy::OutUnknown>(t).a0;
            _v.set(prism_rtl::cat("() /* ", what, " */"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutQuantified>(t)) {
            auto&& b = prism_rtl::as<lower::OutTy::OutQuantified>(t).a0;
            _v.set(prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), "a quantified type variable of `", b, "`: no instantiation gives it a type\")"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> Type::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<lower::OutTy::OutNat>(t) ? prism_rtl::finished(Text("Nat"))
        : prism_rtl::is<lower::OutTy::OutInt>(t) ? prism_rtl::finished(Text("Int"))
        : prism_rtl::is<lower::OutTy::OutU8>(t) ? prism_rtl::finished(Text("u8"))
        : prism_rtl::is<lower::OutTy::OutFloat>(t) ? prism_rtl::finished(Text("f64"))
        : prism_rtl::is<lower::OutTy::OutBool>(t) ? prism_rtl::finished(Text("bool"))
        : prism_rtl::is<lower::OutTy::OutChar>(t) ? prism_rtl::finished(Text("char"))
        : prism_rtl::is<lower::OutTy::OutText>(t) ? prism_rtl::finished(Text("Text"))
        : prism_rtl::is<lower::OutTy::OutUnit>(t) ? prism_rtl::finished(Text("()"))
        : prism_rtl::is<lower::OutTy::OutPath>(t) ? prism_rtl::finished(Text("Path"))
        : prism_rtl::is<lower::OutTy::OutDuration>(t) ? prism_rtl::finished(Text("Duration"))
        : prism_rtl::is<lower::OutTy::OutError>(t) ? prism_rtl::finished(Text("Error"))
        : prism_rtl::is<lower::OutTy::OutNamed>(t) && ({
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m1006_11_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        (m1006_11_1.size() == 0u);
    }) ? ({
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m1006_11_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<lower::OutTy::OutNamed>(t) ? ({
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& args_ = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        ({
        auto args__1 = args_;
        auto n_2 = n;
        call_then(start_types(args__1), [=](Text types_1287) { return prism_rtl::finished(prism_rtl::cat(n_2, "<", types_1287, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutOpt>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutOpt>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__1324) { return prism_rtl::finished(prism_rtl::cat("Option<", type__1324, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutRes>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutRes>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__1357) { return prism_rtl::finished(prism_rtl::cat("Result<", type__1357, ", Error>")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutTuple>(t) && ({
        auto&& m1006_15_0 = prism_rtl::as<lower::OutTy::OutTuple>(t).a0;
        (m1006_15_0.size() == 1u) && ({
        auto&& _c1 = index(m1006_15_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m1006_15_0 = prism_rtl::as<lower::OutTy::OutTuple>(t).a0;
        auto&& _c1 = index(m1006_15_0, Nat(0u));
        auto&& one = prism_rtl::some_of(_c1);
        call_then(start_type_(one), [=](Text type__1399) { return prism_rtl::finished(prism_rtl::cat("(", type__1399, ",)")); });
    })
        : prism_rtl::is<lower::OutTy::OutTuple>(t) ? ({
        auto&& ts = prism_rtl::as<lower::OutTy::OutTuple>(t).a0;
        ({
        auto ts_1 = ts;
        call_then(start_types(ts_1), [=](Text types_1432) { return prism_rtl::finished(prism_rtl::cat("(", types_1432, ")")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutArray>(t) ? ({
        auto&& e = prism_rtl::as<lower::OutTy::OutArray>(t).a0;
        ({
        auto e_1 = e;
        call_then(start_type_(e_1), [=](Text type__1468) { return prism_rtl::finished(prism_rtl::cat("Array<", type__1468, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutMap>(t) ? ({
        auto&& k = prism_rtl::as<lower::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<lower::OutTy::OutMap>(t).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_type_(k_1), [=](Text type__1501) { return call_then(start_type_(v__2), [=](Text type__1511) { return prism_rtl::finished(prism_rtl::cat("Map<", type__1501, ", ", type__1511, ">")); }); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutFn>(t) ? ({
        auto&& ps = prism_rtl::as<lower::OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<lower::OutTy::OutFn>(t).a1;
        ({
        auto ps_1 = ps;
        auto r_2 = r;
        call_then(start_ref_types(ps_1), [=](Text ref_types_1550) { return call_then(start_type_(r_2), [=](Text type__1568) { return prism_rtl::finished(prism_rtl::cat("Rc<dyn Fn(", ref_types_1550, ") -> ", type__1568, ">")); }); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutRef>(t) && ({
        auto&& m1006_20_0 = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
        prism_rtl::is<lower::OutTy::OutFn>(m1006_20_0);
    }) ? ({
        auto&& m1006_20_0 = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
        auto&& ps = prism_rtl::as<lower::OutTy::OutFn>(m1006_20_0).a0;
        auto&& r = prism_rtl::as<lower::OutTy::OutFn>(m1006_20_0).a1;
        ({
        auto ps_1 = ps;
        auto r_2 = r;
        call_then(start_ref_types(ps_1), [=](Text ref_types_1614) { return call_then(start_type_(r_2), [=](Text type__1632) { return prism_rtl::finished(prism_rtl::cat("&dyn Fn(", ref_types_1614, ") -> ", type__1632)); }); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutRef>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__1658) { return prism_rtl::finished(prism_rtl::cat("&", type__1658)); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutJobFn>(t) ? ({
        auto&& a = prism_rtl::as<lower::OutTy::OutJobFn>(t).a0;
        auto&& b = prism_rtl::as<lower::OutTy::OutJobFn>(t).a1;
        ({
        auto a_1 = a;
        auto b_2 = b;
        call_then(start_type_(a_1), [=](Text type__1698) { return call_then(start_type_(b_2), [=](Text type__1733) { return prism_rtl::finished(prism_rtl::cat("Rc<dyn Fn(", type__1698, ") -> Rc<dyn prism_rtl::Job<", type__1733, ">>>")); }); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutJob>(t) ? ({
        auto&& b = prism_rtl::as<lower::OutTy::OutJob>(t).a0;
        ({
        auto b_1 = b;
        call_then(start_type_(b_1), [=](Text type__1783) { return prism_rtl::finished(prism_rtl::cat("Rc<dyn prism_rtl::Job<", type__1783, ">>")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutEvent>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutEvent>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__1818) { return prism_rtl::finished(prism_rtl::cat("Event<", type__1818, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutDyn>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutDyn>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__1852) { return prism_rtl::finished(prism_rtl::cat("Dynamic<", type__1852, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutGen>(t) ? ({
        auto&& n = prism_rtl::as<lower::OutTy::OutGen>(t).a0;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<lower::OutTy::OutRc>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutRc>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__1896) { return prism_rtl::finished(prism_rtl::cat("Rc<", type__1896, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutPod>(t) ? prism_rtl::finished(Text("Pod"))
        : prism_rtl::is<lower::OutTy::OutShowAny>(t) ? prism_rtl::finished(Text("Rc<dyn Show>"))
        : prism_rtl::is<lower::OutTy::OutHold>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutHold>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__1977) { return prism_rtl::finished(prism_rtl::cat("Hold<", type__1977, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutStamped>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutStamped>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2015) { return prism_rtl::finished(prism_rtl::cat("Stamped<", type__2015, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutSnapshot>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutSnapshot>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2055) { return prism_rtl::finished(prism_rtl::cat("Snapshot<", type__2055, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutDefer>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutDefer>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2089) { return prism_rtl::finished(prism_rtl::cat("Defer<", type__2089, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutWeak>(t) ? ({
        auto&& n = prism_rtl::as<lower::OutTy::OutWeak>(t).a0;
        prism_rtl::finished(prism_rtl::cat("Weak<", n, ">"));
    })
        : prism_rtl::is<lower::OutTy::OutCell>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutCell>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2151) { return prism_rtl::finished(prism_rtl::cat("RefCell<", type__2151, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutWakes>(t) ? prism_rtl::finished(Text("Wakes"))
        : prism_rtl::is<lower::OutTy::OutCount>(t) ? prism_rtl::finished(Text("u32"))
        : prism_rtl::is<lower::OutTy::OutObj>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutObj>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2226) { return prism_rtl::finished(prism_rtl::cat("Rc<dyn ", type__2226, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutSlice>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutSlice>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2255) { return prism_rtl::finished(prism_rtl::cat("[", type__2255, "]")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutPort>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutPort>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2287) { return prism_rtl::finished(prism_rtl::cat("Port<", type__2287, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutLive>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutLive>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2319) { return prism_rtl::finished(prism_rtl::cat("Live<", type__2319, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutUnknown>(t) ? ({
        auto&& what = prism_rtl::as<lower::OutTy::OutUnknown>(t).a0;
        prism_rtl::finished(prism_rtl::cat("() /* ", what, " */"));
    })
        : prism_rtl::is<lower::OutTy::OutQuantified>(t) ? ({
        auto&& b = prism_rtl::as<lower::OutTy::OutQuantified>(t).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), "a quantified type variable of `", b, "`: no instantiation gives it a type\")"));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Type, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_type_(lower::OutTy t) {
    return std::make_shared<Type>(t);
}


/// Types: unbounded fn [OutTy] -> Text
Text types(const Array<lower::OutTy>& ts) {
    return lexer::join(run_to_end(each_job(ts, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::OutTy)>>(prism_rtl::rc([=](lower::OutTy p0) {
        return entered(once_job([=]() {
            return ({
                auto t = p0;
                (prism_rtl::more(prism_rtl::rc(Type(t))));
            });
        }));
    })))), Text(", "));
}


prism_rtl::Turn<Text> Types::cycle() const {
    const auto& ts = this->ts;
    auto ts_1 = ts;
    return call_value(each_job(ts_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::OutTy)>>(prism_rtl::rc([=](lower::OutTy p0) {
        return entered(once_job([=]() {
            return ({
                auto t = p0;
                (prism_rtl::more(prism_rtl::rc(Type(t))));
            });
        }));
    }))), [=](Array<Text> each_2555) { return prism_rtl::finished(lexer::join(each_2555, Text(", "))); });
}


/// `Start Types, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_types(Array<lower::OutTy> ts) {
    return std::make_shared<Types>(ts);
}


/// RefTypes: unbounded fn [OutTy] -> Text
Text ref_types(const Array<lower::OutTy>& ts) {
    return lexer::join(run_to_end(each_job(ts, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::OutTy)>>(prism_rtl::rc([=](lower::OutTy p0) {
        return entered(once_job([=]() {
            return ({
                auto t = p0;
                call_then(start_type_(t), [=](Text type__2663) { return prism_rtl::finished(prism_rtl::cat("&", type__2663)); });
            });
        }));
    })))), Text(", "));
}


prism_rtl::Turn<Text> RefTypes::cycle() const {
    const auto& ts = this->ts;
    auto ts_1 = ts;
    return call_value(each_job(ts_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::OutTy)>>(prism_rtl::rc([=](lower::OutTy p0) {
        return entered(once_job([=]() {
            return ({
                auto t = p0;
                call_then(start_type_(t), [=](Text type__2663) { return prism_rtl::finished(prism_rtl::cat("&", type__2663)); });
            });
        }));
    }))), [=](Array<Text> each_2646) { return prism_rtl::finished(lexer::join(each_2646, Text(", "))); });
}


/// `Start RefTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ref_types(Array<lower::OutTy> ts) {
    return std::make_shared<RefTypes>(ts);
}


/// IsLoose: fn Ex -> Bool
bool is_loose(const lower::Ex& x) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lower::Ex::XBlock>(x)) {
            auto&& m2988_0_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
            auto&& inner = prism_rtl::as<lower::Ex::XBlock>(x).a1;
            if (m2988_0_0.size() == 0u) {
                _v.set(is_loose(inner));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::Ex::XTyped>(x)) {
            auto&& inner = prism_rtl::as<lower::Ex::XTyped>(x).a0;
            _v.set(is_loose(inner));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XBin>(x)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XUnary>(x)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XClosure>(x)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XIf>(x)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XMatch>(x)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XChain>(x)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XCast>(x)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XRef>(x)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XRefMut>(x)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XDeref>(x)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// Tight: unbounded fn Ex -> Text
Text tight(const lower::Ex& x) {
    return is_loose(x) ? prism_rtl::cat("(", expression(x), ")") : expression(x);
}


prism_rtl::Turn<Text> Tight::cycle() const {
    const auto& x = this->x;
    return is_loose(x)
        ? ({
        auto x_1 = x;
        call_then(start_expression(x_1), [=](Text expression_3505) { return prism_rtl::finished(prism_rtl::cat("(", expression_3505, ")")); });
    })
        : prism_rtl::more(prism_rtl::rc(Expression(x)));
}


/// `Start Tight, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_tight(lower::Ex x) {
    return std::make_shared<Tight>(x);
}


/// Operand: unbounded fn Ex -> Text
Text operand(const lower::Ex& x) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Ex::XBlock>(x)) {
            auto&& m3589_0_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
            auto&& inner = prism_rtl::as<lower::Ex::XBlock>(x).a1;
            if (m3589_0_0.size() == 0u) {
                _v.set(operand(inner));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::Ex::XTyped>(x)) {
            auto&& inner = prism_rtl::as<lower::Ex::XTyped>(x).a0;
            _v.set(operand(inner));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XBin>(x)) {
            _v.set(prism_rtl::cat("(", expression(x), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XClosure>(x)) {
            _v.set(prism_rtl::cat("(", expression(x), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XIf>(x)) {
            _v.set(prism_rtl::cat("(", expression(x), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XCast>(x)) {
            _v.set(prism_rtl::cat("(", expression(x), ")"));
            goto _done;
        }
        {
            _v.set(expression(x));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> Operand::cycle() const {
    const auto& x = this->x;
    return ({
        prism_rtl::is<lower::Ex::XBlock>(x) && ({
        auto&& m3589_0_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& inner = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        (m3589_0_0.size() == 0u);
    }) ? ({
        auto&& m3589_0_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& inner = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        prism_rtl::more(prism_rtl::rc(Operand(inner)));
    })
        : prism_rtl::is<lower::Ex::XTyped>(x) ? ({
        auto&& inner = prism_rtl::as<lower::Ex::XTyped>(x).a0;
        prism_rtl::more(prism_rtl::rc(Operand(inner)));
    })
        : prism_rtl::is<lower::Ex::XBin>(x) ? ({
        auto x_1 = x;
        call_then(start_expression(x_1), [=](Text expression_3712) { return prism_rtl::finished(prism_rtl::cat("(", expression_3712, ")")); });
    })
        : prism_rtl::is<lower::Ex::XClosure>(x) ? ({
        auto x_1 = x;
        call_then(start_expression(x_1), [=](Text expression_3768) { return prism_rtl::finished(prism_rtl::cat("(", expression_3768, ")")); });
    })
        : prism_rtl::is<lower::Ex::XIf>(x) ? ({
        auto x_1 = x;
        call_then(start_expression(x_1), [=](Text expression_3819) { return prism_rtl::finished(prism_rtl::cat("(", expression_3819, ")")); });
    })
        : prism_rtl::is<lower::Ex::XCast>(x) ? ({
        auto x_1 = x;
        call_then(start_expression(x_1), [=](Text expression_3864) { return prism_rtl::finished(prism_rtl::cat("(", expression_3864, ")")); });
    })
        : prism_rtl::more(prism_rtl::rc(Expression(x)));
    });
}


/// `Start Operand, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_operand(lower::Ex x) {
    return std::make_shared<Operand>(x);
}


/// Args: unbounded fn [Ex] -> Text
Text args(const Array<lower::Ex>& xs) {
    return lexer::join(run_to_end(each_job(xs, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
        return entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(Expression(x))));
            });
        }));
    })))), Text(", "));
}


prism_rtl::Turn<Text> Args::cycle() const {
    const auto& xs = this->xs;
    auto xs_1 = xs;
    return call_value(each_job(xs_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
        return entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(Expression(x))));
            });
        }));
    }))), [=](Array<Text> each_3960) { return prism_rtl::finished(lexer::join(each_3960, Text(", "))); });
}


/// `Start Args, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_args(Array<lower::Ex> xs) {
    return std::make_shared<Args>(xs);
}


/// Expression: unbounded fn Ex -> Text
Text expression(const lower::Ex& x) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Ex::XVar>(x)) {
            auto&& n = prism_rtl::as<lower::Ex::XVar>(x).a0;
            _v.set(n);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XPath>(x)) {
            auto&& p_ = prism_rtl::as<lower::Ex::XPath>(x).a0;
            _v.set(p_);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XSelf>(x)) {
            _v.set(Text("self"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XCx>(x)) {
            _v.set(Text("cx"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XConst>(x)) {
            auto&& n = prism_rtl::as<lower::Ex::XConst>(x).a0;
            _v.set(prism_rtl::cat("Self::", n));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XUnit>(x)) {
            _v.set(Text("()"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XNone>(x)) {
            _v.set(Text("None"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XBool>(x)) {
            auto&& b = prism_rtl::as<lower::Ex::XBool>(x).a0;
            _v.set(b ? Text("true") : Text("false"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XNat>(x)) {
            auto&& d = prism_rtl::as<lower::Ex::XNat>(x).a0;
            _v.set(len_text(d) <= Nat(9u)
                ? prism_rtl::cat("Nat::from(", d, "u32)")
                : prism_rtl::cat("Nat::from_int(Int::from(", d, "i64)).unwrap()"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XInt>(x)) {
            auto&& d = prism_rtl::as<lower::Ex::XInt>(x).a0;
            _v.set(len_text(take_text(d, Nat(1u)) == Text("-") ? drop_text(d, Nat(1u)) : d) <= Nat(18u)
                ? prism_rtl::cat("Int::from(", d, ")")
                : prism_rtl::cat("Int::from(", d, "i64)"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XByte>(x)) {
            auto&& d = prism_rtl::as<lower::Ex::XByte>(x).a0;
            _v.set(prism_rtl::cat(d, "u8"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XFloat>(x)) {
            auto&& d = prism_rtl::as<lower::Ex::XFloat>(x).a0;
            _v.set(d);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XIndex>(x)) {
            auto&& n = prism_rtl::as<lower::Ex::XIndex>(x).a0;
            _v.set(prism_rtl::cat(n));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XChar>(x)) {
            auto&& c = prism_rtl::as<lower::Ex::XChar>(x).a0;
            _v.set(prism_rtl::cat("'", lower::char_escape(c), "'"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XStr>(x)) {
            auto&& t = prism_rtl::as<lower::Ex::XStr>(x).a0;
            _v.set(prism_rtl::cat("\"", lower::escape(t), "\""));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XRef>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XRef>(x).a0;
            _v.set(prism_rtl::cat("&", operand(y)));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XRefMut>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XRefMut>(x).a0;
            _v.set(prism_rtl::cat("&mut ", operand(y)));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XDeref>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XDeref>(x).a0;
            _v.set(prism_rtl::cat("*", operand(y)));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XTarget>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XTarget>(x).a0;
            _v.set(prism_rtl::cat("(*", expression(y), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XClone>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XClone>(x).a0;
            _v.set(prism_rtl::cat(tight(y), ".clone()"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XWeak>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XWeak>(x).a0;
            _v.set(prism_rtl::cat("Rc::downgrade(", expression(y), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XUpgrade>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XUpgrade>(x).a0;
            _v.set(prism_rtl::cat(tight(y), ".upgrade()"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XBreak>(x)) {
            auto&& l = prism_rtl::as<lower::Ex::XBreak>(x).a0;
            auto&& y = prism_rtl::as<lower::Ex::XBreak>(x).a1;
            _v.set(prism_rtl::cat("break ", label(l), " ", expression(y)));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XBreakLoop>(x)) {
            _v.set(Text("break"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XLater>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XLater>(x).a0;
            _v.set(prism_rtl::cat("Box::new(move |cx| { ", expression(y), "; Ok(()) })"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XFormatStr>(x)) {
            auto&& parts = prism_rtl::as<lower::Ex::XFormatStr>(x).a0;
            _v.set(format_str(parts));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XIsCase>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XIsCase>(x).a0;
            auto&& m4049_26_1 = prism_rtl::as<lower::Ex::XIsCase>(x).a1;
            if (m4049_26_1.size() == 0u) {
                _v.set(Text("false"));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::Ex::XIsCase>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XIsCase>(x).a0;
            auto&& cs = prism_rtl::as<lower::Ex::XIsCase>(x).a1;
            _v.set(prism_rtl::cat("matches!(", expression(y), ", ", lexer::join(each(cs, [&](const Text& c) { return prism_rtl::cat(c, "(..)"); }), Text(" | ")), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XRefusal>(x)) {
            auto&& what = prism_rtl::as<lower::Ex::XRefusal>(x).a0;
            _v.set(prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), lower::escape(what), "\")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XUnreachable>(x)) {
            _v.set(Text("unreachable!()"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XCall>(x)) {
            auto&& f = prism_rtl::as<lower::Ex::XCall>(x).a0;
            auto&& args_ = prism_rtl::as<lower::Ex::XCall>(x).a1;
            _v.set(prism_rtl::cat(f, "(", emit::args(args_), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XApply>(x)) {
            auto&& f = prism_rtl::as<lower::Ex::XApply>(x).a0;
            auto&& args_ = prism_rtl::as<lower::Ex::XApply>(x).a1;
            _v.set(prism_rtl::cat(tight(f), "(", emit::args(args_), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XMethod>(x)) {
            auto&& r = prism_rtl::as<lower::Ex::XMethod>(x).a0;
            auto&& m = prism_rtl::as<lower::Ex::XMethod>(x).a1;
            auto&& args_ = prism_rtl::as<lower::Ex::XMethod>(x).a2;
            _v.set(prism_rtl::cat(tight(r), ".", m, "(", emit::args(args_), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XBin>(x)) {
            auto&& op = prism_rtl::as<lower::Ex::XBin>(x).a0;
            auto&& l = prism_rtl::as<lower::Ex::XBin>(x).a1;
            auto&& r = prism_rtl::as<lower::Ex::XBin>(x).a2;
            _v.set(prism_rtl::cat(operand(l), " ", op, " ", operand(r)));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XUnary>(x)) {
            auto&& op = prism_rtl::as<lower::Ex::XUnary>(x).a0;
            auto&& y = prism_rtl::as<lower::Ex::XUnary>(x).a1;
            _v.set(prism_rtl::cat(op, operand(y)));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XCtor>(x)) {
            auto&& p_ = prism_rtl::as<lower::Ex::XCtor>(x).a0;
            auto&& args_ = prism_rtl::as<lower::Ex::XCtor>(x).a1;
            _v.set(prism_rtl::cat(p_, "(", emit::args(args_), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XRecord>(x)) {
            auto&& p_ = prism_rtl::as<lower::Ex::XRecord>(x).a0;
            auto&& fs = prism_rtl::as<lower::Ex::XRecord>(x).a1;
            _v.set(prism_rtl::cat(p_, " { ", lexer::join(run_to_end(each_job(fs, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Ex> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto [f, v_] = p0;
                        (prism_rtl::more(prism_rtl::rc(FieldInit(f, v_))));
                    });
                }));
            })))), Text(", ")), " }"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XTuple>(x)) {
            auto&& m4049_37_0 = prism_rtl::as<lower::Ex::XTuple>(x).a0;
            if (m4049_37_0.size() == 1u) {
                {
                    auto&& _c1 = index(m4049_37_0, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& one = prism_rtl::some_of(_c1);
                        _v.set(prism_rtl::cat("(", expression(one), ",)"));
                        goto _done;
                    }
                }
            }
        }
        if (prism_rtl::is<lower::Ex::XTuple>(x)) {
            auto&& xs = prism_rtl::as<lower::Ex::XTuple>(x).a0;
            _v.set(prism_rtl::cat("(", emit::args(xs), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XVec>(x)) {
            auto&& xs = prism_rtl::as<lower::Ex::XVec>(x).a0;
            _v.set(prism_rtl::cat("vec![", emit::args(xs), "]"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XText>(x)) {
            auto&& t = prism_rtl::as<lower::Ex::XText>(x).a0;
            _v.set(prism_rtl::cat("Text::from(\"", lower::escape(t), "\")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XFormat>(x)) {
            auto&& parts = prism_rtl::as<lower::Ex::XFormat>(x).a0;
            _v.set(format(parts));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XMatch>(x)) {
            auto&& s = prism_rtl::as<lower::Ex::XMatch>(x).a0;
            auto&& arms_ = prism_rtl::as<lower::Ex::XMatch>(x).a1;
            auto&& fallback = prism_rtl::as<lower::Ex::XMatch>(x).a2;
            _v.set(rust_templates::match_(expression(s), arms(arms_, fallback)));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XChain>(x)) {
            auto&& label_ = prism_rtl::as<lower::Ex::XChain>(x).a0;
            auto&& s = prism_rtl::as<lower::Ex::XChain>(x).a1;
            auto&& arms_ = prism_rtl::as<lower::Ex::XChain>(x).a2;
            _v.set(chain(label(label_), s, arms_));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XIf>(x)) {
            auto&& c = prism_rtl::as<lower::Ex::XIf>(x).a0;
            auto&& t = prism_rtl::as<lower::Ex::XIf>(x).a1;
            auto&& e = prism_rtl::as<lower::Ex::XIf>(x).a2;
            _v.set(if_expression(c, t, e));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XBlock>(x)) {
            auto&& m4049_45_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
            auto&& e = prism_rtl::as<lower::Ex::XBlock>(x).a1;
            if (m4049_45_0.size() == 0u) {
                _v.set(expression(e));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::Ex::XBlock>(x)) {
            auto&& dos = prism_rtl::as<lower::Ex::XBlock>(x).a0;
            auto&& e = prism_rtl::as<lower::Ex::XBlock>(x).a1;
            _v.set(rust_templates::block(statements(dos), expression(e)));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XLabeled>(x)) {
            auto&& label_ = prism_rtl::as<lower::Ex::XLabeled>(x).a0;
            auto&& dos = prism_rtl::as<lower::Ex::XLabeled>(x).a1;
            auto&& e = prism_rtl::as<lower::Ex::XLabeled>(x).a2;
            _v.set(rust_templates::labeled(label(label_), statements(dos), expression(e)));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XClosure>(x)) {
            auto&& mv = prism_rtl::as<lower::Ex::XClosure>(x).a0;
            auto&& ps = prism_rtl::as<lower::Ex::XClosure>(x).a1;
            auto&& body = prism_rtl::as<lower::Ex::XClosure>(x).a2;
            _v.set(prism_rtl::cat(mv ? Text("move ") : Text(""), "|", lexer::join(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
                return entered(once_job([=]() {
                    return ({
                        auto p_ = p0;
                        (prism_rtl::more(prism_rtl::rc(Pattern_(p_))));
                    });
                }));
            })))), Text(", ")), "| ", expression(body)));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XTry>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XTry>(x).a0;
            _v.set(prism_rtl::cat(tight(y), "?"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XField>(x)) {
            auto&& r = prism_rtl::as<lower::Ex::XField>(x).a0;
            auto&& f = prism_rtl::as<lower::Ex::XField>(x).a1;
            _v.set(prism_rtl::cat(tight(r), ".", f));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XPart>(x)) {
            auto&& r = prism_rtl::as<lower::Ex::XPart>(x).a0;
            auto&& k = prism_rtl::as<lower::Ex::XPart>(x).a1;
            _v.set(prism_rtl::cat(tight(r), ".", k));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XDecode>(x)) {
            auto&& t = prism_rtl::as<lower::Ex::XDecode>(x).a0;
            auto&& y = prism_rtl::as<lower::Ex::XDecode>(x).a1;
            _v.set(prism_rtl::cat(decode_head(t), "::from_pod(", expression(y), ")?"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XCast>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XCast>(x).a0;
            auto&& t = prism_rtl::as<lower::Ex::XCast>(x).a1;
            _v.set(prism_rtl::cat(tight(y), " as ", type_(t)));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XTyped>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XTyped>(x).a0;
            _v.set(expression(y));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> Expression::cycle() const {
    const auto& x = this->x;
    return ({
        prism_rtl::is<lower::Ex::XVar>(x) ? ({
        auto&& n = prism_rtl::as<lower::Ex::XVar>(x).a0;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<lower::Ex::XPath>(x) ? ({
        auto&& p_ = prism_rtl::as<lower::Ex::XPath>(x).a0;
        prism_rtl::finished(p_);
    })
        : prism_rtl::is<lower::Ex::XSelf>(x) ? prism_rtl::finished(Text("self"))
        : prism_rtl::is<lower::Ex::XCx>(x) ? prism_rtl::finished(Text("cx"))
        : prism_rtl::is<lower::Ex::XConst>(x) ? ({
        auto&& n = prism_rtl::as<lower::Ex::XConst>(x).a0;
        prism_rtl::finished(prism_rtl::cat("Self::", n));
    })
        : prism_rtl::is<lower::Ex::XUnit>(x) ? prism_rtl::finished(Text("()"))
        : prism_rtl::is<lower::Ex::XNone>(x) ? prism_rtl::finished(Text("None"))
        : prism_rtl::is<lower::Ex::XBool>(x) ? ({
        auto&& b = prism_rtl::as<lower::Ex::XBool>(x).a0;
        b ? prism_rtl::finished(Text("true")) : prism_rtl::finished(Text("false"));
    })
        : prism_rtl::is<lower::Ex::XNat>(x) ? ({
        auto&& d = prism_rtl::as<lower::Ex::XNat>(x).a0;
        len_text(d) <= Nat(9u)
        ? prism_rtl::finished(prism_rtl::cat("Nat::from(", d, "u32)"))
        : prism_rtl::finished(prism_rtl::cat("Nat::from_int(Int::from(", d, "i64)).unwrap()"));
    })
        : prism_rtl::is<lower::Ex::XInt>(x) ? ({
        auto&& d = prism_rtl::as<lower::Ex::XInt>(x).a0;
        len_text(take_text(d, Nat(1u)) == Text("-") ? drop_text(d, Nat(1u)) : d) <= Nat(18u)
        ? prism_rtl::finished(prism_rtl::cat("Int::from(", d, ")"))
        : prism_rtl::finished(prism_rtl::cat("Int::from(", d, "i64)"));
    })
        : prism_rtl::is<lower::Ex::XByte>(x) ? ({
        auto&& d = prism_rtl::as<lower::Ex::XByte>(x).a0;
        prism_rtl::finished(prism_rtl::cat(d, "u8"));
    })
        : prism_rtl::is<lower::Ex::XFloat>(x) ? ({
        auto&& d = prism_rtl::as<lower::Ex::XFloat>(x).a0;
        prism_rtl::finished(d);
    })
        : prism_rtl::is<lower::Ex::XIndex>(x) ? ({
        auto&& n = prism_rtl::as<lower::Ex::XIndex>(x).a0;
        prism_rtl::finished(prism_rtl::cat(n));
    })
        : prism_rtl::is<lower::Ex::XChar>(x) ? ({
        auto&& c = prism_rtl::as<lower::Ex::XChar>(x).a0;
        prism_rtl::finished(prism_rtl::cat("'", lower::char_escape(c), "'"));
    })
        : prism_rtl::is<lower::Ex::XStr>(x) ? ({
        auto&& t = prism_rtl::as<lower::Ex::XStr>(x).a0;
        prism_rtl::finished(prism_rtl::cat("\"", lower::escape(t), "\""));
    })
        : prism_rtl::is<lower::Ex::XRef>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XRef>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_operand(y_1), [=](Text operand_4565) { return prism_rtl::finished(prism_rtl::cat("&", operand_4565)); });
    });
    })
        : prism_rtl::is<lower::Ex::XRefMut>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XRefMut>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_operand(y_1), [=](Text operand_4599) { return prism_rtl::finished(prism_rtl::cat("&mut ", operand_4599)); });
    });
    })
        : prism_rtl::is<lower::Ex::XDeref>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XDeref>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_operand(y_1), [=](Text operand_4628) { return prism_rtl::finished(prism_rtl::cat("*", operand_4628)); });
    });
    })
        : prism_rtl::is<lower::Ex::XTarget>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XTarget>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_expression(y_1), [=](Text expression_4659) { return prism_rtl::finished(prism_rtl::cat("(*", expression_4659, ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XClone>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XClone>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_tight(y_1), [=](Text tight_4691) { return prism_rtl::finished(prism_rtl::cat(tight_4691, ".clone()")); });
    });
    })
        : prism_rtl::is<lower::Ex::XWeak>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XWeak>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_expression(y_1), [=](Text expression_4738) { return prism_rtl::finished(prism_rtl::cat("Rc::downgrade(", expression_4738, ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XUpgrade>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XUpgrade>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_tight(y_1), [=](Text tight_4772) { return prism_rtl::finished(prism_rtl::cat(tight_4772, ".upgrade()")); });
    });
    })
        : prism_rtl::is<lower::Ex::XBreak>(x) ? ({
        auto&& l = prism_rtl::as<lower::Ex::XBreak>(x).a0;
        auto&& y = prism_rtl::as<lower::Ex::XBreak>(x).a1;
        ({
        auto l_1 = l;
        auto y_2 = y;
        call_then(start_expression(y_2), [=](Text expression_4827) { return prism_rtl::finished(prism_rtl::cat("break ", label(l_1), " ", expression_4827)); });
    });
    })
        : prism_rtl::is<lower::Ex::XBreakLoop>(x) ? prism_rtl::finished(Text("break"))
        : prism_rtl::is<lower::Ex::XLater>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XLater>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_expression(y_1), [=](Text expression_4904) { return prism_rtl::finished(prism_rtl::cat("Box::new(move |cx| { ", expression_4904, "; Ok(()) })")); });
    });
    })
        : prism_rtl::is<lower::Ex::XFormatStr>(x) ? ({
        auto&& parts = prism_rtl::as<lower::Ex::XFormatStr>(x).a0;
        prism_rtl::more(prism_rtl::rc(FormatStr(parts)));
    })
        : prism_rtl::is<lower::Ex::XIsCase>(x) && ({
        auto&& y = prism_rtl::as<lower::Ex::XIsCase>(x).a0;
        auto&& m4049_26_1 = prism_rtl::as<lower::Ex::XIsCase>(x).a1;
        (m4049_26_1.size() == 0u);
    }) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XIsCase>(x).a0;
        auto&& m4049_26_1 = prism_rtl::as<lower::Ex::XIsCase>(x).a1;
        prism_rtl::finished(Text("false"));
    })
        : prism_rtl::is<lower::Ex::XIsCase>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XIsCase>(x).a0;
        auto&& cs = prism_rtl::as<lower::Ex::XIsCase>(x).a1;
        ({
        auto cs_1 = cs;
        auto y_2 = y;
        call_then(start_expression(y_2), [=](Text expression_5028) { return prism_rtl::finished(prism_rtl::cat("matches!(", expression_5028, ", ", lexer::join(each(cs_1, [&](const Text& c) { return prism_rtl::cat(c, "(..)"); }), Text(" | ")), ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XRefusal>(x) ? ({
        auto&& what = prism_rtl::as<lower::Ex::XRefusal>(x).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), lower::escape(what), "\")"));
    })
        : prism_rtl::is<lower::Ex::XUnreachable>(x) ? prism_rtl::finished(Text("unreachable!()"))
        : prism_rtl::is<lower::Ex::XCall>(x) ? ({
        auto&& f = prism_rtl::as<lower::Ex::XCall>(x).a0;
        auto&& args_ = prism_rtl::as<lower::Ex::XCall>(x).a1;
        ({
        auto args__1 = args_;
        auto f_2 = f;
        call_then(start_args(args__1), [=](Text args_5217) { return prism_rtl::finished(prism_rtl::cat(f_2, "(", args_5217, ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XApply>(x) ? ({
        auto&& f = prism_rtl::as<lower::Ex::XApply>(x).a0;
        auto&& args_ = prism_rtl::as<lower::Ex::XApply>(x).a1;
        ({
        auto args__1 = args_;
        auto f_2 = f;
        call_then(start_tight(f_2), [=](Text tight_5252) { return call_then(start_args(args__1), [=](Text args_5262) { return prism_rtl::finished(prism_rtl::cat(tight_5252, "(", args_5262, ")")); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XMethod>(x) ? ({
        auto&& r = prism_rtl::as<lower::Ex::XMethod>(x).a0;
        auto&& m = prism_rtl::as<lower::Ex::XMethod>(x).a1;
        auto&& args_ = prism_rtl::as<lower::Ex::XMethod>(x).a2;
        ({
        auto args__1 = args_;
        auto m_2 = m;
        auto r_3 = r;
        call_then(start_tight(r_3), [=](Text tight_5301) { return call_then(start_args(args__1), [=](Text args_5315) { return prism_rtl::finished(prism_rtl::cat(tight_5301, ".", m_2, "(", args_5315, ")")); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XBin>(x) ? ({
        auto&& op = prism_rtl::as<lower::Ex::XBin>(x).a0;
        auto&& l = prism_rtl::as<lower::Ex::XBin>(x).a1;
        auto&& r = prism_rtl::as<lower::Ex::XBin>(x).a2;
        ({
        auto l_1 = l;
        auto op_2 = op;
        auto r_3 = r;
        call_then(start_operand(l_1), [=](Text operand_5349) { return call_then(start_operand(r_3), [=](Text operand_5366) { return prism_rtl::finished(prism_rtl::cat(operand_5349, " ", op_2, " ", operand_5366)); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XUnary>(x) ? ({
        auto&& op = prism_rtl::as<lower::Ex::XUnary>(x).a0;
        auto&& y = prism_rtl::as<lower::Ex::XUnary>(x).a1;
        ({
        auto op_1 = op;
        auto y_2 = y;
        call_then(start_operand(y_2), [=](Text operand_5402) { return prism_rtl::finished(prism_rtl::cat(op_1, operand_5402)); });
    });
    })
        : prism_rtl::is<lower::Ex::XCtor>(x) ? ({
        auto&& p_ = prism_rtl::as<lower::Ex::XCtor>(x).a0;
        auto&& args_ = prism_rtl::as<lower::Ex::XCtor>(x).a1;
        ({
        auto args__1 = args_;
        auto p__2 = p_;
        call_then(start_args(args__1), [=](Text args_5439) { return prism_rtl::finished(prism_rtl::cat(p__2, "(", args_5439, ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XRecord>(x) ? ({
        auto&& p_ = prism_rtl::as<lower::Ex::XRecord>(x).a0;
        auto&& fs = prism_rtl::as<lower::Ex::XRecord>(x).a1;
        ({
        auto fs_1 = fs;
        auto p__2 = p_;
        call_value(each_job(fs_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Ex> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f, v_] = p0;
                (prism_rtl::more(prism_rtl::rc(FieldInit(f, v_))));
            });
        }));
    }))), [=](Array<Text> each_5486) { return prism_rtl::finished(prism_rtl::cat(p__2, " { ", lexer::join(each_5486, Text(", ")), " }")); });
    });
    })
        : prism_rtl::is<lower::Ex::XTuple>(x) && ({
        auto&& m4049_37_0 = prism_rtl::as<lower::Ex::XTuple>(x).a0;
        (m4049_37_0.size() == 1u) && ({
        auto&& _c1 = index(m4049_37_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m4049_37_0 = prism_rtl::as<lower::Ex::XTuple>(x).a0;
        auto&& _c1 = index(m4049_37_0, Nat(0u));
        auto&& one = prism_rtl::some_of(_c1);
        call_then(start_expression(one), [=](Text expression_5557) { return prism_rtl::finished(prism_rtl::cat("(", expression_5557, ",)")); });
    })
        : prism_rtl::is<lower::Ex::XTuple>(x) ? ({
        auto&& xs = prism_rtl::as<lower::Ex::XTuple>(x).a0;
        ({
        auto xs_1 = xs;
        call_then(start_args(xs_1), [=](Text args_5594) { return prism_rtl::finished(prism_rtl::cat("(", args_5594, ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XVec>(x) ? ({
        auto&& xs = prism_rtl::as<lower::Ex::XVec>(x).a0;
        ({
        auto xs_1 = xs;
        call_then(start_args(xs_1), [=](Text args_5625) { return prism_rtl::finished(prism_rtl::cat("vec![", args_5625, "]")); });
    });
    })
        : prism_rtl::is<lower::Ex::XText>(x) ? ({
        auto&& t = prism_rtl::as<lower::Ex::XText>(x).a0;
        prism_rtl::finished(prism_rtl::cat("Text::from(\"", lower::escape(t), "\")"));
    })
        : prism_rtl::is<lower::Ex::XFormat>(x) ? ({
        auto&& parts = prism_rtl::as<lower::Ex::XFormat>(x).a0;
        prism_rtl::more(prism_rtl::rc(Format(parts)));
    })
        : prism_rtl::is<lower::Ex::XMatch>(x) ? ({
        auto&& s = prism_rtl::as<lower::Ex::XMatch>(x).a0;
        auto&& arms_ = prism_rtl::as<lower::Ex::XMatch>(x).a1;
        auto&& fallback = prism_rtl::as<lower::Ex::XMatch>(x).a2;
        ({
        auto arms__1 = arms_;
        auto fallback_2 = fallback;
        auto s_3 = s;
        call_then(start_expression(s_3), [=](Text expression_5755) { return call_then(start_arms(arms__1, fallback_2), [=](Text arms_5771) { return prism_rtl::finished(rust_templates::match_(expression_5755, arms_5771)); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XChain>(x) ? ({
        auto&& label_ = prism_rtl::as<lower::Ex::XChain>(x).a0;
        auto&& s = prism_rtl::as<lower::Ex::XChain>(x).a1;
        auto&& arms_ = prism_rtl::as<lower::Ex::XChain>(x).a2;
        prism_rtl::more(prism_rtl::rc(Chain(label(label_), s, arms_)));
    })
        : prism_rtl::is<lower::Ex::XIf>(x) ? ({
        auto&& c = prism_rtl::as<lower::Ex::XIf>(x).a0;
        auto&& t = prism_rtl::as<lower::Ex::XIf>(x).a1;
        auto&& e = prism_rtl::as<lower::Ex::XIf>(x).a2;
        prism_rtl::more(prism_rtl::rc(IfExpression(c, t, e)));
    })
        : prism_rtl::is<lower::Ex::XBlock>(x) && ({
        auto&& m4049_45_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        (m4049_45_0.size() == 0u);
    }) ? ({
        auto&& m4049_45_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        prism_rtl::more(prism_rtl::rc(Expression(e)));
    })
        : prism_rtl::is<lower::Ex::XBlock>(x) ? ({
        auto&& dos = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        ({
        auto dos_1 = dos;
        auto e_2 = e;
        call_then(start_statements(dos_1), [=](Text statements_5953) { return call_then(start_expression(e_2), [=](Text expression_5971) { return prism_rtl::finished(rust_templates::block(statements_5953, expression_5971)); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XLabeled>(x) ? ({
        auto&& label_ = prism_rtl::as<lower::Ex::XLabeled>(x).a0;
        auto&& dos = prism_rtl::as<lower::Ex::XLabeled>(x).a1;
        auto&& e = prism_rtl::as<lower::Ex::XLabeled>(x).a2;
        ({
        auto dos_1 = dos;
        auto e_2 = e;
        auto label__3 = label_;
        call_then(start_statements(dos_1), [=](Text statements_6045) { return call_then(start_expression(e_2), [=](Text expression_6063) { return prism_rtl::finished(rust_templates::labeled(label(label__3), statements_6045, expression_6063)); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XClosure>(x) ? ({
        auto&& mv = prism_rtl::as<lower::Ex::XClosure>(x).a0;
        auto&& ps = prism_rtl::as<lower::Ex::XClosure>(x).a1;
        auto&& body = prism_rtl::as<lower::Ex::XClosure>(x).a2;
        ({
        auto body_1 = body;
        auto mv_2 = mv;
        auto ps_3 = ps;
        call_value(each_job(ps_3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(Pattern_(p_))));
            });
        }));
    }))), [=](Array<Text> each_6138) { return call_then(start_expression(body_1), [=](Text expression_6172) { return prism_rtl::finished(prism_rtl::cat(mv_2 ? Text("move ") : Text(""), "|", lexer::join(each_6138, Text(", ")), "| ", expression_6172)); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XTry>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XTry>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_tight(y_1), [=](Text tight_6204) { return prism_rtl::finished(prism_rtl::cat(tight_6204, "?")); });
    });
    })
        : prism_rtl::is<lower::Ex::XField>(x) ? ({
        auto&& r = prism_rtl::as<lower::Ex::XField>(x).a0;
        auto&& f = prism_rtl::as<lower::Ex::XField>(x).a1;
        ({
        auto f_1 = f;
        auto r_2 = r;
        call_then(start_tight(r_2), [=](Text tight_6234) { return prism_rtl::finished(prism_rtl::cat(tight_6234, ".", f_1)); });
    });
    })
        : prism_rtl::is<lower::Ex::XPart>(x) ? ({
        auto&& r = prism_rtl::as<lower::Ex::XPart>(x).a0;
        auto&& k = prism_rtl::as<lower::Ex::XPart>(x).a1;
        ({
        auto k_1 = k;
        auto r_2 = r;
        call_then(start_tight(r_2), [=](Text tight_6266) { return prism_rtl::finished(prism_rtl::cat(tight_6266, ".", k_1)); });
    });
    })
        : prism_rtl::is<lower::Ex::XDecode>(x) ? ({
        auto&& t = prism_rtl::as<lower::Ex::XDecode>(x).a0;
        auto&& y = prism_rtl::as<lower::Ex::XDecode>(x).a1;
        ({
        auto t_1 = t;
        auto y_2 = y;
        call_then(start_decode_head(t_1), [=](Text decode_head_6300) { return call_then(start_expression(y_2), [=](Text expression_6325) { return prism_rtl::finished(prism_rtl::cat(decode_head_6300, "::from_pod(", expression_6325, ")?")); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XCast>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XCast>(x).a0;
        auto&& t = prism_rtl::as<lower::Ex::XCast>(x).a1;
        ({
        auto t_1 = t;
        auto y_2 = y;
        call_then(start_tight(y_2), [=](Text tight_6360) { return call_then(start_type_(t_1), [=](Text type__6373) { return prism_rtl::finished(prism_rtl::cat(tight_6360, " as ", type__6373)); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XTyped>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XTyped>(x).a0;
        prism_rtl::more(prism_rtl::rc(Expression(y)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Expression, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_expression(lower::Ex x) {
    return std::make_shared<Expression>(x);
}


/// FieldInit: unbounded fn Text, Ex -> Text
Text field_init(const Text& f, const lower::Ex& ex1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Ex::XVar>(ex1)) {
            auto&& v_ = prism_rtl::as<lower::Ex::XVar>(ex1).a0;
            _v.set(v_ == f ? f : prism_rtl::cat(f, ": ", v_));
            goto _done;
        }
        {
            auto&& v_ = ex1;
            _v.set(prism_rtl::cat(f, ": ", expression(v_)));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> FieldInit::cycle() const {
    const auto& f = this->f;
    const auto& ex1 = this->ex1;
    return ({
        prism_rtl::is<lower::Ex::XVar>(ex1) ? ({
        auto&& v_ = prism_rtl::as<lower::Ex::XVar>(ex1).a0;
        v_ == f
        ? prism_rtl::finished(f)
        : prism_rtl::finished(prism_rtl::cat(f, ": ", v_));
    })
        : ({
        auto&& v_ = ex1;
        ({
        auto f_1 = f;
        auto v__2 = v_;
        call_then(start_expression(v__2), [=](Text expression_6543) { return prism_rtl::finished(prism_rtl::cat(f_1, ": ", expression_6543)); });
    });
    });
    });
}


/// `Start FieldInit, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_field_init(Text f, lower::Ex ex1) {
    return std::make_shared<FieldInit>(f, ex1);
}


/// DecodeHead: unbounded fn OutTy -> Text
Text decode_head(const lower::OutTy& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
            auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
            auto&& m6616_0_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
            if (m6616_0_1.size() == 0u) {
                _v.set(n);
                goto _done;
            }
        }
        if (prism_rtl::is<lower::OutTy::OutNat>(t)) {
            _v.set(Text("Nat"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutInt>(t)) {
            _v.set(Text("Int"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutText>(t)) {
            _v.set(Text("Text"));
            goto _done;
        }
        {
            _v.set(prism_rtl::cat("<", type_(t), ">"));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> DecodeHead::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<lower::OutTy::OutNamed>(t) && ({
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m6616_0_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        (m6616_0_1.size() == 0u);
    }) ? ({
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m6616_0_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<lower::OutTy::OutNat>(t) ? prism_rtl::finished(Text("Nat"))
        : prism_rtl::is<lower::OutTy::OutInt>(t) ? prism_rtl::finished(Text("Int"))
        : prism_rtl::is<lower::OutTy::OutText>(t) ? prism_rtl::finished(Text("Text"))
        : ({
        auto t_1 = t;
        call_then(start_type_(t_1), [=](Text type__6723) { return prism_rtl::finished(prism_rtl::cat("<", type__6723, ">")); });
    });
    });
}


/// `Start DecodeHead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_decode_head(lower::OutTy t) {
    return std::make_shared<DecodeHead>(t);
}


/// Label: fn Text -> Text
Text label(const Text& l) {
    return take_text(l, Nat(1u)) == Text("'") ? l : prism_rtl::cat("'", l);
}


/// Format: unbounded fn [Ex] -> Text
Text format(const Array<lower::Ex>& parts) {
    auto lit = concat(each(parts, [&](const lower::Ex& p_) { return format_piece(p_); }));
    auto vals = filter(parts, [&](const lower::Ex& p_) { return !is_text(p_); });
    return len(vals) == Nat(0u)
        ? prism_rtl::cat("Text::from(\"", lit, "\")")
        : prism_rtl::cat("Text::from(format!(\"", lit, "\", ", emit::args(vals), "))");
}


prism_rtl::Turn<Text> Format::cycle() const {
    const auto& parts = this->parts;
    auto lit = concat(each(parts, [&](const lower::Ex& p_) { return format_piece(p_); }));
    auto vals = filter(parts, [&](const lower::Ex& p_) { return !is_text(p_); });
    return len(vals) == Nat(0u)
        ? prism_rtl::finished(prism_rtl::cat("Text::from(\"", lit, "\")"))
        : call_then(start_args(vals), [=](Text args_7144) { return prism_rtl::finished(prism_rtl::cat("Text::from(format!(\"", lit, "\", ", args_7144, "))")); });
}


/// `Start Format, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_format(Array<lower::Ex> parts) {
    return std::make_shared<Format>(parts);
}


/// FormatStr: unbounded fn [Ex] -> Text
Text format_str(const Array<lower::Ex>& parts) {
    auto lit = concat(each(parts, [&](const lower::Ex& p_) { return str_piece(p_); }));
    auto vals = filter(parts, [&](const lower::Ex& p_) { return (!is_text(p_)) && (!is_var(p_)); });
    return len(vals) == Nat(0u)
        ? prism_rtl::cat("\"", lit, "\"")
        : prism_rtl::cat("format!(\"", lit, "\", ", emit::args(vals), ")");
}


prism_rtl::Turn<Text> FormatStr::cycle() const {
    const auto& parts = this->parts;
    auto lit = concat(each(parts, [&](const lower::Ex& p_) { return str_piece(p_); }));
    auto vals = filter(parts, [&](const lower::Ex& p_) { return (!is_text(p_)) && (!is_var(p_)); });
    return len(vals) == Nat(0u)
        ? prism_rtl::finished(prism_rtl::cat("\"", lit, "\""))
        : call_then(start_args(vals), [=](Text args_7529) { return prism_rtl::finished(prism_rtl::cat("format!(\"", lit, "\", ", args_7529, ")")); });
}


/// `Start FormatStr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_format_str(Array<lower::Ex> parts) {
    return std::make_shared<FormatStr>(parts);
}


/// IsVar: fn Ex -> Bool
bool is_var(const lower::Ex& ex0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lower::Ex::XVar>(ex0)) {
            _v.set(true);
            goto _done;
        }
        {
            auto&& other = ex0;
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// StrPiece: fn Ex -> Text
Text str_piece(const lower::Ex& ex0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Ex::XVar>(ex0)) {
            auto&& n = prism_rtl::as<lower::Ex::XVar>(ex0).a0;
            _v.set(prism_rtl::cat("{", n, "}"));
            goto _done;
        }
        {
            auto&& other = ex0;
            _v.set(format_piece(other));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// IsText: fn Ex -> Bool
bool is_text(const lower::Ex& ex0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lower::Ex::XText>(ex0)) {
            _v.set(true);
            goto _done;
        }
        {
            auto&& other = ex0;
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// FormatPiece: fn Ex -> Text
Text format_piece(const lower::Ex& ex0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Ex::XText>(ex0)) {
            auto&& t = prism_rtl::as<lower::Ex::XText>(ex0).a0;
            _v.set(format_escape(lower::escape(t)));
            goto _done;
        }
        {
            auto&& other = ex0;
            _v.set(Text("{}"));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// FormatEscape: fn Text -> Text
Text format_escape(const Text& t) {
    return concat(each(lexer::chars(t), [&](const Text& c) { return format_escape_char(c); }));
}


/// FormatEscapeChar: fn Text -> Text
Text format_escape_char(const Text& text0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& c0_0 = text0;
            if (c0_0 == Text("{")) {
                _v.set(Text("{{"));
                goto _done;
            }
        }
        {
            auto&& c1_0 = text0;
            if (c1_0 == Text("}")) {
                _v.set(Text("}}"));
                goto _done;
            }
        }
        {
            auto&& c = text0;
            _v.set(c);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
Text if_expression(const lower::Ex& c, const lower::Ex& t, const lower::Ex& e) {
    auto ct = expression(c);
    auto tt = expression(t);
    auto et = expression(e);
    auto short_ = (!lexer::contains(prism_rtl::cat(tt, et), Text("\n"))) && (len_text(prism_rtl::cat(ct, tt, et)) < Nat(70u));
    return short_
        ? prism_rtl::cat("if ", ct, " { ", tt, " } else { ", et, " }")
        : rust_templates::if_(ct, tt, et);
}


prism_rtl::Turn<Text> IfExpression::cycle() const {
    const auto& c = this->c;
    const auto& t = this->t;
    const auto& e = this->e;
    auto c_1 = c;
    auto e_2 = e;
    auto t_3 = t;
    return call_then(start_expression(c_1), [=](Text expression_8280) {
        return ({
            auto ct = expression_8280;
            call_then(start_expression(t_3), [=](Text expression_8306) {
            return ({
                auto tt = expression_8306;
                call_then(start_expression(e_2), [=](Text expression_8332) {
                return ({
                    auto et = expression_8332;
                    auto short_ = (!lexer::contains(prism_rtl::cat(tt, et), Text("\n"))) && (len_text(prism_rtl::cat(ct, tt, et)) < Nat(70u));
                    short_
                    ? prism_rtl::finished(prism_rtl::cat("if ", ct, " { ", tt, " } else { ", et, " }"))
                    : prism_rtl::finished(rust_templates::if_(ct, tt, et));
                });
            });
            });
        });
        });
    });
}


/// `Start IfExpression, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_if_expression(lower::Ex c, lower::Ex t, lower::Ex e) {
    return std::make_shared<IfExpression>(c, t, e);
}


/// Arms: unbounded fn [XArm], Bool -> Text
Text arms(const Array<lower::XArm>& arms_, const bool& fallback) {
    auto lines = run_to_end(each_job(arms_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::XArm)>>(prism_rtl::rc([=](lower::XArm p0) {
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(Arm(a))));
            });
        }));
    }))));
    auto all = fallback
        ? prelude::push(lines, Text("_ => unreachable!(\"no arm matched\"),"))
        : lines;
    return lexer::join(all, Text("\n"));
}


prism_rtl::Turn<Text> Arms::cycle() const {
    const auto& arms_ = this->arms_;
    const auto& fallback = this->fallback;
    auto arms__1 = arms_;
    auto fallback_2 = fallback;
    return call_value(each_job(arms__1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::XArm)>>(prism_rtl::rc([=](lower::XArm p0) {
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(Arm(a))));
            });
        }));
    }))), [=](Array<Text> each_8663) {
        return ({
            auto lines = each_8663;
            auto all = fallback_2
                ? prelude::push(lines, Text("_ => unreachable!(\"no arm matched\"),"))
                : lines;
            (prism_rtl::finished(lexer::join(all, Text("\n"))));
        });
    });
}


/// `Start Arms, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_arms(Array<lower::XArm> arms_, bool fallback) {
    return std::make_shared<Arms>(arms_, fallback);
}


/// Arm: unbounded fn XArm -> Text
Text arm(const lower::XArm& a) {
    auto guard = len(a.conds) == Nat(0u)
        ? Text("")
        : prism_rtl::cat(" if ", lexer::join(run_to_end(each_job(a.conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Cc)>>(prism_rtl::rc([=](lower::Cc p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::more(prism_rtl::rc(Condition(c))));
            });
        }));
    })))), Text(" && ")));
    auto body = expression(a.body);
    return prism_rtl::cat(pattern(a.pat), guard, " => ", body, ",");
}


prism_rtl::Turn<Text> Arm::cycle() const {
    const auto& a = this->a;
    auto guard = len(a.conds) == Nat(0u)
        ? Text("")
        : prism_rtl::cat(" if ", lexer::join(run_to_end(each_job(a.conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Cc)>>(prism_rtl::rc([=](lower::Cc p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::more(prism_rtl::rc(Condition(c))));
            });
        }));
    })))), Text(" && ")));
    auto a_1 = a;
    return call_then(start_expression(a_1.body), [=](Text expression_8955) {
        return ({
            auto body = expression_8955;
            call_then(start_pattern(a_1.pat), [=](Text pattern_8979) { return prism_rtl::finished(prism_rtl::cat(pattern_8979, guard, " => ", body, ",")); });
        });
    });
}


/// `Start Arm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_arm(lower::XArm a) {
    return std::make_shared<Arm>(a);
}


/// Condition: unbounded fn Cc -> Text
Text condition(const lower::Cc& cc0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Cc::CcIf>(cc0)) {
            auto&& x = prism_rtl::as<lower::Cc::CcIf>(cc0).a0;
            _v.set(operand(x));
            goto _done;
        }
        if (prism_rtl::is<lower::Cc::CcLet>(cc0)) {
            auto&& p_ = prism_rtl::as<lower::Cc::CcLet>(cc0).a0;
            auto&& x = prism_rtl::as<lower::Cc::CcLet>(cc0).a1;
            _v.set(prism_rtl::cat("let ", pattern(p_), " = ", expression(x)));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> Condition::cycle() const {
    const auto& cc0 = this->cc0;
    return ({
        prism_rtl::is<lower::Cc::CcIf>(cc0) ? ({
        auto&& x = prism_rtl::as<lower::Cc::CcIf>(cc0).a0;
        prism_rtl::more(prism_rtl::rc(Operand(x)));
    })
        : prism_rtl::is<lower::Cc::CcLet>(cc0) ? ({
        auto&& p_ = prism_rtl::as<lower::Cc::CcLet>(cc0).a0;
        auto&& x = prism_rtl::as<lower::Cc::CcLet>(cc0).a1;
        ({
        auto p__1 = p_;
        auto x_2 = x;
        call_then(start_pattern(p__1), [=](Text pattern_9117) { return call_then(start_expression(x_2), [=](Text expression_9131) { return prism_rtl::finished(prism_rtl::cat("let ", pattern_9117, " = ", expression_9131)); }); });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Condition, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_condition(lower::Cc cc0) {
    return std::make_shared<Condition>(cc0);
}


/// Chain: unbounded fn Text, Ex, [XArm] -> Text
Text chain(const Text& label_, const lower::Ex& s, const Array<lower::XArm>& arms_) {
    auto in_place = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lower::Ex::XRef>(s)) {
            auto&& y = prism_rtl::as<lower::Ex::XRef>(s).a0;
            _v.set(is_bound(y));
            goto _done;
        }
        {
            _v.set(is_bound(s));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [bind, scrut] = in_place
        ? std::tuple{Array<Text>{}, expression(s)}
        : std::tuple{Array(std::vector{prism_rtl::cat("let scrutinee = ", expression(s), ";")}), Text("scrutinee")};
    auto n = len(arms_);
    auto lines = run_to_end(each_job(check_errors::range0(n), ({
        auto arms__1 = arms_;
        auto scrut_2 = scrut;
        auto label__3 = label_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto arms__1_4 = arms__1;
            auto scrut_2_4 = scrut_2;
            auto label__3_4 = label__3;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(arms__1_4, i), lower::XArm{.pat = lower::Pa(lower::Pa::PaWild{}), .conds = Array<lower::Cc>{}, .body = lower::Ex(lower::Ex::XUnit{})});
                auto catch_all = (a.pat == lower::Pa(lower::Pa::PaWild{})) && (len(a.conds) == Nat(0u));
                catch_all
                ? prism_rtl::more(prism_rtl::rc(Expression(a.body)))
                : call_then(start_pattern(a.pat), [=](Text pattern_9844) {
                return call_value(each_job(a.conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Cc)>>(prism_rtl::rc([=](lower::Cc p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            (prism_rtl::more(prism_rtl::rc(Condition(c))));
                        });
                    }));
                }))), [=](Array<Text> each_9874) {
                    return ({
                        auto head = lexer::join(append(Array(std::vector{prism_rtl::cat("let ", pattern_9844, " = ", scrut_2_4)}), each_9874), Text(" && "));
                        call_then(start_expression(a.body), [=](Text expression_9961) { return prism_rtl::finished(rust_templates::chain_arm(head, label__3_4, continued(expression_9961, Text("    ")))); });
                    });
                });
            });
            });
            });
        }));
        });
    })));
    })));
    auto ends = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = lexer::last(arms_);
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set((a.pat == lower::Pa(lower::Pa::PaWild{})) && (len(a.conds) == Nat(0u)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto tail = ends
        ? Array<Text>{}
        : Array(std::vector{Text("unreachable!(\"no clause matched\")")});
    return prism_rtl::cat(label_, ": {\n", indent(lexer::join(append(append(bind, lines), tail), Text("\n"))), "\n}");
}


prism_rtl::Turn<Text> Chain::cycle() const {
    const auto& label_ = this->label_;
    const auto& s = this->s;
    const auto& arms_ = this->arms_;
    auto in_place = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lower::Ex::XRef>(s)) {
            auto&& y = prism_rtl::as<lower::Ex::XRef>(s).a0;
            _v.set(is_bound(y));
            goto _done;
        }
        {
            _v.set(is_bound(s));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [bind, scrut] = in_place
        ? std::tuple{Array<Text>{}, expression(s)}
        : std::tuple{Array(std::vector{prism_rtl::cat("let scrutinee = ", expression(s), ";")}), Text("scrutinee")};
    auto n = len(arms_);
    auto arms__1 = arms_;
    auto label__2 = label_;
    auto s_3 = s;
    return call_value(each_job(check_errors::range0(n), ({
        auto arms__1_4 = arms__1;
        auto scrut_4 = scrut;
        auto label__2_5 = label__2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto arms__1_4_5 = arms__1_4;
            auto scrut_4_5 = scrut_4;
            auto label__2_5_5 = label__2_5;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(arms__1_4_5, i), lower::XArm{.pat = lower::Pa(lower::Pa::PaWild{}), .conds = Array<lower::Cc>{}, .body = lower::Ex(lower::Ex::XUnit{})});
                auto catch_all = (a.pat == lower::Pa(lower::Pa::PaWild{})) && (len(a.conds) == Nat(0u));
                catch_all
                ? prism_rtl::more(prism_rtl::rc(Expression(a.body)))
                : call_then(start_pattern(a.pat), [=](Text pattern_9844) {
                return call_value(each_job(a.conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Cc)>>(prism_rtl::rc([=](lower::Cc p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            (prism_rtl::more(prism_rtl::rc(Condition(c))));
                        });
                    }));
                }))), [=](Array<Text> each_9874) {
                    return ({
                        auto head = lexer::join(append(Array(std::vector{prism_rtl::cat("let ", pattern_9844, " = ", scrut_4_5)}), each_9874), Text(" && "));
                        call_then(start_expression(a.body), [=](Text expression_9961) { return prism_rtl::finished(rust_templates::chain_arm(head, label__2_5_5, continued(expression_9961, Text("    ")))); });
                    });
                });
            });
            });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_9590) {
        return ({
            auto lines = each_9590;
            auto ends = ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = lexer::last(arms__1);
                if (prism_rtl::is_some(_m)) {
                    auto&& a = prism_rtl::some_of(_m);
                    _v.set((a.pat == lower::Pa(lower::Pa::PaWild{})) && (len(a.conds) == Nat(0u)));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(false);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto tail = ends
                ? Array<Text>{}
                : Array(std::vector{Text("unreachable!(\"no clause matched\")")});
            (prism_rtl::finished(prism_rtl::cat(label__2, ": {\n", indent(lexer::join(append(append(bind, lines), tail), Text("\n"))), "\n}")));
        });
    });
}


/// `Start Chain, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_chain(Text label_, lower::Ex s, Array<lower::XArm> arms_) {
    return std::make_shared<Chain>(label_, s, arms_);
}


/// IsBound: fn Ex -> Bool
bool is_bound(const lower::Ex& x) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lower::Ex::XVar>(x)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XField>(x)) {
            auto&& m10465_1_0 = prism_rtl::as<lower::Ex::XField>(x).a0;
            if (prism_rtl::is<lower::Ex::XSelf>(m10465_1_0)) {
                _v.set(true);
                goto _done;
            }
        }
        if (prism_rtl::is<lower::Ex::XField>(x)) {
            auto&& m10465_2_0 = prism_rtl::as<lower::Ex::XField>(x).a0;
            if (prism_rtl::is<lower::Ex::XMethod>(m10465_2_0)) {
                auto&& m10465_2_0_r_0 = prism_rtl::as<lower::Ex::XMethod>(m10465_2_0).a0;
                if (prism_rtl::is<lower::Ex::XUpgrade>(m10465_2_0_r_0)) {
                    _v.set(true);
                    goto _done;
                }
            }
        }
        if (prism_rtl::is<lower::Ex::XTarget>(x)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XPart>(x)) {
            auto&& m10465_4_0 = prism_rtl::as<lower::Ex::XPart>(x).a0;
            if (prism_rtl::is<lower::Ex::XVar>(m10465_4_0)) {
                _v.set(true);
                goto _done;
            }
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// Continued: fn Text, Text -> Text
Text continued(const Text& t, const Text& pad) {
    auto ls = split(t, Text("\n"));
    return lexer::join(each(check_errors::range0(len(ls)), [&](const Nat& i) {
        return (i == Nat(0u)) || (or_(index(ls, i), Text("")) == Text(""))
            ? or_(index(ls, i), Text(""))
            : prism_rtl::cat(pad, or_(index(ls, i), Text("")));
    }), Text("\n"));
}


/// BodyLines: unbounded fn Ex -> Text
Text body_lines(const lower::Ex& ex0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Ex::XBlock>(ex0)) {
            auto&& dos = prism_rtl::as<lower::Ex::XBlock>(ex0).a0;
            auto&& e = prism_rtl::as<lower::Ex::XBlock>(ex0).a1;
            _v.set(len(dos) == Nat(0u)
                ? body_lines(e)
                : prism_rtl::cat(statements(dos), "\n", body_lines(e)));
            goto _done;
        }
        {
            auto&& x = ex0;
            _v.set(expression(x));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> BodyLines::cycle() const {
    const auto& ex0 = this->ex0;
    return ({
        prism_rtl::is<lower::Ex::XBlock>(ex0) ? ({
        auto&& dos = prism_rtl::as<lower::Ex::XBlock>(ex0).a0;
        auto&& e = prism_rtl::as<lower::Ex::XBlock>(ex0).a1;
        len(dos) == Nat(0u)
        ? prism_rtl::more(prism_rtl::rc(BodyLines(e)))
        : ({
        auto dos_1 = dos;
        auto e_2 = e;
        call_then(start_statements(dos_1), [=](Text statements_11149) { return call_then(start_body_lines(e_2), [=](Text body_lines_11167) { return prism_rtl::finished(prism_rtl::cat(statements_11149, "\n", body_lines_11167)); }); });
    });
    })
        : ({
        auto&& x = ex0;
        prism_rtl::more(prism_rtl::rc(Expression(x)));
    });
    });
}


/// `Start BodyLines, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_body_lines(lower::Ex ex0) {
    return std::make_shared<BodyLines>(ex0);
}


/// Indent: fn Text -> Text
Text indent(const Text& t) {
    return lexer::join(each(split(t, Text("\n")), [&](const Text& l) { return l == Text("") ? Text("") : prism_rtl::cat("    ", l); }), Text("\n"));
}


/// Pattern: unbounded fn Pa -> Text
Text pattern(const lower::Pa& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Pa::PaWild>(p_)) {
            _v.set(Text("_"));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaBind>(p_)) {
            auto&& n = prism_rtl::as<lower::Pa::PaBind>(p_).a0;
            _v.set(n);
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaMut>(p_)) {
            auto&& n = prism_rtl::as<lower::Pa::PaMut>(p_).a0;
            _v.set(prism_rtl::cat("mut ", n));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaCtor>(p_)) {
            auto&& c = prism_rtl::as<lower::Pa::PaCtor>(p_).a0;
            auto&& ps = prism_rtl::as<lower::Pa::PaCtor>(p_).a1;
            _v.set(prism_rtl::cat(c, "(", lexer::join(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
                return entered(once_job([=]() {
                    return ({
                        auto q = p0;
                        (prism_rtl::more(prism_rtl::rc(Pattern_(q))));
                    });
                }));
            })))), Text(", ")), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaUnit>(p_)) {
            auto&& c = prism_rtl::as<lower::Pa::PaUnit>(p_).a0;
            _v.set(c);
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaRecord>(p_)) {
            auto&& c = prism_rtl::as<lower::Pa::PaRecord>(p_).a0;
            auto&& fs = prism_rtl::as<lower::Pa::PaRecord>(p_).a1;
            auto&& rest = prism_rtl::as<lower::Pa::PaRecord>(p_).a2;
            _v.set(({
                auto parts = run_to_end(each_job(fs, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Pa> p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto [f, q] = p0;
                            ({
                            prism_rtl::is<lower::Pa::PaBind>(q) ? ({
                            auto&& n = prism_rtl::as<lower::Pa::PaBind>(q).a0;
                            n == f
                            ? prism_rtl::finished(f)
                            : prism_rtl::finished(prism_rtl::cat(f, ": ", n));
                        })
                            : call_then(start_pattern(q), [=](Text pattern_11918) { return prism_rtl::finished(prism_rtl::cat(f, ": ", pattern_11918)); });
                        });
                        });
                    }));
                }))));
                auto all = rest ? prelude::push(parts, Text("..")) : parts;
                (prism_rtl::cat(c, " { ", lexer::join(all, Text(", ")), " }"));
            }));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaTuple>(p_)) {
            auto&& m11616_6_0 = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
            if (m11616_6_0.size() == 1u) {
                {
                    auto&& _c1 = index(m11616_6_0, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& one = prism_rtl::some_of(_c1);
                        _v.set(prism_rtl::cat("(", pattern(one), ",)"));
                        goto _done;
                    }
                }
            }
        }
        if (prism_rtl::is<lower::Pa::PaTuple>(p_)) {
            auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
            _v.set(prism_rtl::cat("(", lexer::join(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
                return entered(once_job([=]() {
                    return ({
                        auto q = p0;
                        (prism_rtl::more(prism_rtl::rc(Pattern_(q))));
                    });
                }));
            })))), Text(", ")), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaChar>(p_)) {
            auto&& c = prism_rtl::as<lower::Pa::PaChar>(p_).a0;
            _v.set(prism_rtl::cat("'", lower::char_escape(c), "'"));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaBool>(p_)) {
            auto&& b = prism_rtl::as<lower::Pa::PaBool>(p_).a0;
            _v.set(b ? Text("true") : Text("false"));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaIndex>(p_)) {
            auto&& n = prism_rtl::as<lower::Pa::PaIndex>(p_).a0;
            _v.set(prism_rtl::cat(n));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaConst>(p_)) {
            auto&& n = prism_rtl::as<lower::Pa::PaConst>(p_).a0;
            _v.set(prism_rtl::cat("Self::", n));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaSlice>(p_)) {
            auto&& ps = prism_rtl::as<lower::Pa::PaSlice>(p_).a0;
            _v.set(prism_rtl::cat("[", lexer::join(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
                return entered(once_job([=]() {
                    return ({
                        auto q = p0;
                        (prism_rtl::more(prism_rtl::rc(Pattern_(q))));
                    });
                }));
            })))), Text(", ")), "]"));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaRest>(p_)) {
            auto&& m11616_13_0 = prism_rtl::as<lower::Pa::PaRest>(p_).a0;
            if (m11616_13_0 == Text("")) {
                _v.set(Text(".."));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::Pa::PaRest>(p_)) {
            auto&& n = prism_rtl::as<lower::Pa::PaRest>(p_).a0;
            _v.set(prism_rtl::cat(n, " @ .."));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaTyped>(p_)) {
            auto&& q = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
            auto&& t = prism_rtl::as<lower::Pa::PaTyped>(p_).a1;
            _v.set(prism_rtl::cat(pattern(q), ": ", type_(t)));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> Pattern_::cycle() const {
    const auto& p_ = this->p_;
    return ({
        prism_rtl::is<lower::Pa::PaWild>(p_) ? prism_rtl::finished(Text("_"))
        : prism_rtl::is<lower::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(p_).a0;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<lower::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaMut>(p_).a0;
        prism_rtl::finished(prism_rtl::cat("mut ", n));
    })
        : prism_rtl::is<lower::Pa::PaCtor>(p_) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaCtor>(p_).a0;
        auto&& ps = prism_rtl::as<lower::Pa::PaCtor>(p_).a1;
        ({
        auto c_1 = c;
        auto ps_2 = ps;
        call_value(each_job(ps_2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(Pattern_(q))));
            });
        }));
    }))), [=](Array<Text> each_11710) { return prism_rtl::finished(prism_rtl::cat(c_1, "(", lexer::join(each_11710, Text(", ")), ")")); });
    });
    })
        : prism_rtl::is<lower::Pa::PaUnit>(p_) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaUnit>(p_).a0;
        prism_rtl::finished(c);
    })
        : prism_rtl::is<lower::Pa::PaRecord>(p_) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaRecord>(p_).a0;
        auto&& fs = prism_rtl::as<lower::Pa::PaRecord>(p_).a1;
        auto&& rest = prism_rtl::as<lower::Pa::PaRecord>(p_).a2;
        ({
        auto c_1 = c;
        auto fs_2 = fs;
        auto rest_3 = rest;
        call_value(each_job(fs_2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Pa> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f, q] = p0;
                ({
                prism_rtl::is<lower::Pa::PaBind>(q) ? ({
                auto&& n = prism_rtl::as<lower::Pa::PaBind>(q).a0;
                n == f
                ? prism_rtl::finished(f)
                : prism_rtl::finished(prism_rtl::cat(f, ": ", n));
            })
                : call_then(start_pattern(q), [=](Text pattern_11918) { return prism_rtl::finished(prism_rtl::cat(f, ": ", pattern_11918)); });
            });
            });
        }));
    }))), [=](Array<Text> each_11806) {
        return ({
            auto parts = each_11806;
            auto all = rest_3 ? prelude::push(parts, Text("..")) : parts;
            (prism_rtl::finished(prism_rtl::cat(c_1, " { ", lexer::join(all, Text(", ")), " }")));
        });
    });
    });
    })
        : prism_rtl::is<lower::Pa::PaTuple>(p_) && ({
        auto&& m11616_6_0 = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
        (m11616_6_0.size() == 1u) && ({
        auto&& _c1 = index(m11616_6_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m11616_6_0 = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
        auto&& _c1 = index(m11616_6_0, Nat(0u));
        auto&& one = prism_rtl::some_of(_c1);
        call_then(start_pattern(one), [=](Text pattern_12047) { return prism_rtl::finished(prism_rtl::cat("(", pattern_12047, ",)")); });
    })
        : prism_rtl::is<lower::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
        ({
        auto ps_1 = ps;
        call_value(each_job(ps_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(Pattern_(q))));
            });
        }));
    }))), [=](Array<Text> each_12088) { return prism_rtl::finished(prism_rtl::cat("(", lexer::join(each_12088, Text(", ")), ")")); });
    });
    })
        : prism_rtl::is<lower::Pa::PaChar>(p_) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaChar>(p_).a0;
        prism_rtl::finished(prism_rtl::cat("'", lower::char_escape(c), "'"));
    })
        : prism_rtl::is<lower::Pa::PaBool>(p_) ? ({
        auto&& b = prism_rtl::as<lower::Pa::PaBool>(p_).a0;
        b ? prism_rtl::finished(Text("true")) : prism_rtl::finished(Text("false"));
    })
        : prism_rtl::is<lower::Pa::PaIndex>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaIndex>(p_).a0;
        prism_rtl::finished(prism_rtl::cat(n));
    })
        : prism_rtl::is<lower::Pa::PaConst>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaConst>(p_).a0;
        prism_rtl::finished(prism_rtl::cat("Self::", n));
    })
        : prism_rtl::is<lower::Pa::PaSlice>(p_) ? ({
        auto&& ps = prism_rtl::as<lower::Pa::PaSlice>(p_).a0;
        ({
        auto ps_1 = ps;
        call_value(each_job(ps_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(Pattern_(q))));
            });
        }));
    }))), [=](Array<Text> each_12269) { return prism_rtl::finished(prism_rtl::cat("[", lexer::join(each_12269, Text(", ")), "]")); });
    });
    })
        : prism_rtl::is<lower::Pa::PaRest>(p_) && ({
        auto&& m11616_13_0 = prism_rtl::as<lower::Pa::PaRest>(p_).a0;
        (m11616_13_0 == Text(""));
    }) ? ({
        auto&& m11616_13_0 = prism_rtl::as<lower::Pa::PaRest>(p_).a0;
        prism_rtl::finished(Text(".."));
    })
        : prism_rtl::is<lower::Pa::PaRest>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaRest>(p_).a0;
        prism_rtl::finished(prism_rtl::cat(n, " @ .."));
    })
        : prism_rtl::is<lower::Pa::PaTyped>(p_) ? ({
        auto&& q = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(p_).a1;
        ({
        auto q_1 = q;
        auto t_2 = t;
        call_then(start_pattern(q_1), [=](Text pattern_12368) { return call_then(start_type_(t_2), [=](Text type__12381) { return prism_rtl::finished(prism_rtl::cat(pattern_12368, ": ", type__12381)); }); });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Pattern_, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_pattern(lower::Pa p_) {
    return std::make_shared<Pattern_>(p_);
}


/// Statements: unbounded fn [Do] -> Text
Text statements(const Array<lower::Do>& dos) {
    return lexer::join(run_to_end(each_job(dos, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Do)>>(prism_rtl::rc([=](lower::Do p0) {
        return entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(Statement(d))));
            });
        }));
    })))), Text("\n"));
}


prism_rtl::Turn<Text> Statements::cycle() const {
    const auto& dos = this->dos;
    auto dos_1 = dos;
    return call_value(each_job(dos_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Do)>>(prism_rtl::rc([=](lower::Do p0) {
        return entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(Statement(d))));
            });
        }));
    }))), [=](Array<Text> each_12455) { return prism_rtl::finished(lexer::join(each_12455, Text("\n"))); });
}


/// `Start Statements, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_statements(Array<lower::Do> dos) {
    return std::make_shared<Statements>(dos);
}


/// Statement: unbounded fn Do -> Text
Text statement(const lower::Do& d) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Do::DoLet>(d)) {
            auto&& p_ = prism_rtl::as<lower::Do::DoLet>(d).a0;
            auto&& x = prism_rtl::as<lower::Do::DoLet>(d).a1;
            _v.set(prism_rtl::cat("let ", pattern(p_), " = ", expression(x), ";"));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoLetElse>(d)) {
            auto&& p_ = prism_rtl::as<lower::Do::DoLetElse>(d).a0;
            auto&& x = prism_rtl::as<lower::Do::DoLetElse>(d).a1;
            auto&& e = prism_rtl::as<lower::Do::DoLetElse>(d).a2;
            _v.set(prism_rtl::cat("let ", pattern(p_), " = ", expression(x), " else { ", expression(e), " };"));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoAssign>(d)) {
            auto&& p_ = prism_rtl::as<lower::Do::DoAssign>(d).a0;
            auto&& x = prism_rtl::as<lower::Do::DoAssign>(d).a1;
            _v.set(prism_rtl::cat(expression(p_), " = ", expression(x), ";"));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoWhile>(d)) {
            auto&& c = prism_rtl::as<lower::Do::DoWhile>(d).a0;
            auto&& body = prism_rtl::as<lower::Do::DoWhile>(d).a1;
            _v.set(rust_templates::if_stmt(prism_rtl::cat("while ", expression(c)), statements(body)));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoWhileLet>(d)) {
            auto&& p_ = prism_rtl::as<lower::Do::DoWhileLet>(d).a0;
            auto&& x = prism_rtl::as<lower::Do::DoWhileLet>(d).a1;
            auto&& body = prism_rtl::as<lower::Do::DoWhileLet>(d).a2;
            _v.set(rust_templates::if_stmt(prism_rtl::cat("while let ", pattern(p_), " = ", expression(x)), statements(body)));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoFor>(d)) {
            auto&& p_ = prism_rtl::as<lower::Do::DoFor>(d).a0;
            auto&& x = prism_rtl::as<lower::Do::DoFor>(d).a1;
            auto&& body = prism_rtl::as<lower::Do::DoFor>(d).a2;
            _v.set(rust_templates::if_stmt(prism_rtl::cat("for ", pattern(p_), " in ", expression(x)), statements(body)));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoExpr>(d)) {
            auto&& x = prism_rtl::as<lower::Do::DoExpr>(d).a0;
            _v.set(prism_rtl::cat(expression(x), ";"));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoIf>(d)) {
            auto&& c = prism_rtl::as<lower::Do::DoIf>(d).a0;
            auto&& t = prism_rtl::as<lower::Do::DoIf>(d).a1;
            auto&& e = prism_rtl::as<lower::Do::DoIf>(d).a2;
            _v.set(prism_rtl::cat(rust_templates::if_stmt(prism_rtl::cat("if ", expression(c)), statements(t)), else_branch(e)));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoIfLet>(d)) {
            auto&& p_ = prism_rtl::as<lower::Do::DoIfLet>(d).a0;
            auto&& x = prism_rtl::as<lower::Do::DoIfLet>(d).a1;
            auto&& t = prism_rtl::as<lower::Do::DoIfLet>(d).a2;
            auto&& e = prism_rtl::as<lower::Do::DoIfLet>(d).a3;
            _v.set(prism_rtl::cat(rust_templates::if_stmt(prism_rtl::cat("if let ", pattern(p_), " = ", expression(x)), statements(t)), else_branch(e)));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoMatch>(d)) {
            auto&& x = prism_rtl::as<lower::Do::DoMatch>(d).a0;
            auto&& cases = prism_rtl::as<lower::Do::DoMatch>(d).a1;
            _v.set(rust_templates::match_(expression(x), lexer::join(run_to_end(each_job(cases, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<lower::Pa, Array<lower::Do>>)>>(prism_rtl::rc([=](std::tuple<lower::Pa, Array<lower::Do>> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto [p_, body] = p0;
                        call_then(start_pattern(p_), [=](Text pattern_13292) { return call_then(start_statements(body), [=](Text statements_13305) { return prism_rtl::finished(rust_templates::arm_block(pattern_13292, statements_13305)); }); });
                    });
                }));
            })))), Text("\n"))));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoReturn>(d)) {
            auto&& x = prism_rtl::as<lower::Do::DoReturn>(d).a0;
            _v.set(prism_rtl::cat("return ", expression(x), ";"));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoScope>(d)) {
            auto&& body = prism_rtl::as<lower::Do::DoScope>(d).a0;
            _v.set(prism_rtl::cat("{ ", inline_statements(body), " };"));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoLine>(d)) {
            auto&& body = prism_rtl::as<lower::Do::DoLine>(d).a0;
            _v.set(prism_rtl::cat(inline_statements(body), ";"));
            goto _done;
        }
        if (prism_rtl::is<lower::Do::DoNote>(d)) {
            auto&& t = prism_rtl::as<lower::Do::DoNote>(d).a0;
            _v.set(prism_rtl::cat("// ", t));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> Statement::cycle() const {
    const auto& d = this->d;
    return ({
        prism_rtl::is<lower::Do::DoLet>(d) ? ({
        auto&& p_ = prism_rtl::as<lower::Do::DoLet>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoLet>(d).a1;
        ({
        auto p__1 = p_;
        auto x_2 = x;
        call_then(start_pattern(p__1), [=](Text pattern_12573) { return call_then(start_expression(x_2), [=](Text expression_12587) { return prism_rtl::finished(prism_rtl::cat("let ", pattern_12573, " = ", expression_12587, ";")); }); });
    });
    })
        : prism_rtl::is<lower::Do::DoLetElse>(d) ? ({
        auto&& p_ = prism_rtl::as<lower::Do::DoLetElse>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoLetElse>(d).a1;
        auto&& e = prism_rtl::as<lower::Do::DoLetElse>(d).a2;
        ({
        auto e_1 = e;
        auto p__2 = p_;
        auto x_3 = x;
        call_then(start_pattern(p__2), [=](Text pattern_12632) { return call_then(start_expression(x_3), [=](Text expression_12646) { return call_then(start_expression(e_1), [=](Text expression_12669) { return prism_rtl::finished(prism_rtl::cat("let ", pattern_12632, " = ", expression_12646, " else { ", expression_12669, " };")); }); }); });
    });
    })
        : prism_rtl::is<lower::Do::DoAssign>(d) ? ({
        auto&& p_ = prism_rtl::as<lower::Do::DoAssign>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoAssign>(d).a1;
        ({
        auto p__1 = p_;
        auto x_2 = x;
        call_then(start_expression(p__1), [=](Text expression_12709) { return call_then(start_expression(x_2), [=](Text expression_12726) { return prism_rtl::finished(prism_rtl::cat(expression_12709, " = ", expression_12726, ";")); }); });
    });
    })
        : prism_rtl::is<lower::Do::DoWhile>(d) ? ({
        auto&& c = prism_rtl::as<lower::Do::DoWhile>(d).a0;
        auto&& body = prism_rtl::as<lower::Do::DoWhile>(d).a1;
        ({
        auto body_1 = body;
        auto c_2 = c;
        call_then(start_expression(c_2), [=](Text expression_12778) { return call_then(start_statements(body_1), [=](Text statements_12795) { return prism_rtl::finished(rust_templates::if_stmt(prism_rtl::cat("while ", expression_12778), statements_12795)); }); });
    });
    })
        : prism_rtl::is<lower::Do::DoWhileLet>(d) ? ({
        auto&& p_ = prism_rtl::as<lower::Do::DoWhileLet>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoWhileLet>(d).a1;
        auto&& body = prism_rtl::as<lower::Do::DoWhileLet>(d).a2;
        ({
        auto body_1 = body;
        auto p__2 = p_;
        auto x_3 = x;
        call_then(start_pattern(p__2), [=](Text pattern_12858) { return call_then(start_expression(x_3), [=](Text expression_12872) { return call_then(start_statements(body_1), [=](Text statements_12889) { return prism_rtl::finished(rust_templates::if_stmt(prism_rtl::cat("while let ", pattern_12858, " = ", expression_12872), statements_12889)); }); }); });
    });
    })
        : prism_rtl::is<lower::Do::DoFor>(d) ? ({
        auto&& p_ = prism_rtl::as<lower::Do::DoFor>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoFor>(d).a1;
        auto&& body = prism_rtl::as<lower::Do::DoFor>(d).a2;
        ({
        auto body_1 = body;
        auto p__2 = p_;
        auto x_3 = x;
        call_then(start_pattern(p__2), [=](Text pattern_12941) { return call_then(start_expression(x_3), [=](Text expression_12956) { return call_then(start_statements(body_1), [=](Text statements_12973) { return prism_rtl::finished(rust_templates::if_stmt(prism_rtl::cat("for ", pattern_12941, " in ", expression_12956), statements_12973)); }); }); });
    });
    })
        : prism_rtl::is<lower::Do::DoExpr>(d) ? ({
        auto&& x = prism_rtl::as<lower::Do::DoExpr>(d).a0;
        ({
        auto x_1 = x;
        call_then(start_expression(x_1), [=](Text expression_13006) { return prism_rtl::finished(prism_rtl::cat(expression_13006, ";")); });
    });
    })
        : prism_rtl::is<lower::Do::DoIf>(d) ? ({
        auto&& c = prism_rtl::as<lower::Do::DoIf>(d).a0;
        auto&& t = prism_rtl::as<lower::Do::DoIf>(d).a1;
        auto&& e = prism_rtl::as<lower::Do::DoIf>(d).a2;
        ({
        auto c_1 = c;
        auto e_2 = e;
        auto t_3 = t;
        call_then(start_expression(c_1), [=](Text expression_13054) { return call_then(start_statements(t_3), [=](Text statements_13071) { return call_then(start_else_branch(e_2), [=](Text else_branch_13086) { return prism_rtl::finished(prism_rtl::cat(rust_templates::if_stmt(prism_rtl::cat("if ", expression_13054), statements_13071), else_branch_13086)); }); }); });
    });
    })
        : prism_rtl::is<lower::Do::DoIfLet>(d) ? ({
        auto&& p_ = prism_rtl::as<lower::Do::DoIfLet>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoIfLet>(d).a1;
        auto&& t = prism_rtl::as<lower::Do::DoIfLet>(d).a2;
        auto&& e = prism_rtl::as<lower::Do::DoIfLet>(d).a3;
        ({
        auto e_1 = e;
        auto p__2 = p_;
        auto t_3 = t;
        auto x_4 = x;
        call_then(start_pattern(p__2), [=](Text pattern_13143) { return call_then(start_expression(x_4), [=](Text expression_13157) { return call_then(start_statements(t_3), [=](Text statements_13174) { return call_then(start_else_branch(e_1), [=](Text else_branch_13189) { return prism_rtl::finished(prism_rtl::cat(rust_templates::if_stmt(prism_rtl::cat("if let ", pattern_13143, " = ", expression_13157), statements_13174), else_branch_13189)); }); }); }); });
    });
    })
        : prism_rtl::is<lower::Do::DoMatch>(d) ? ({
        auto&& x = prism_rtl::as<lower::Do::DoMatch>(d).a0;
        auto&& cases = prism_rtl::as<lower::Do::DoMatch>(d).a1;
        ({
        auto cases_1 = cases;
        auto x_2 = x;
        call_then(start_expression(x_2), [=](Text expression_13233) {
        return call_value(each_job(cases_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<lower::Pa, Array<lower::Do>>)>>(prism_rtl::rc([=](std::tuple<lower::Pa, Array<lower::Do>> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [p_, body] = p0;
                    call_then(start_pattern(p_), [=](Text pattern_13292) { return call_then(start_statements(body), [=](Text statements_13305) { return prism_rtl::finished(rust_templates::arm_block(pattern_13292, statements_13305)); }); });
                });
            }));
        }))), [=](Array<Text> each_13255) { return prism_rtl::finished(rust_templates::match_(expression_13233, lexer::join(each_13255, Text("\n")))); });
    });
    });
    })
        : prism_rtl::is<lower::Do::DoReturn>(d) ? ({
        auto&& x = prism_rtl::as<lower::Do::DoReturn>(d).a0;
        ({
        auto x_1 = x;
        call_then(start_expression(x_1), [=](Text expression_13355) { return prism_rtl::finished(prism_rtl::cat("return ", expression_13355, ";")); });
    });
    })
        : prism_rtl::is<lower::Do::DoScope>(d) ? ({
        auto&& body = prism_rtl::as<lower::Do::DoScope>(d).a0;
        ({
        auto body_1 = body;
        call_then(start_inline_statements(body_1), [=](Text inline_statements_13394) { return prism_rtl::finished(prism_rtl::cat("{ ", inline_statements_13394, " };")); });
    });
    })
        : prism_rtl::is<lower::Do::DoLine>(d) ? ({
        auto&& body = prism_rtl::as<lower::Do::DoLine>(d).a0;
        ({
        auto body_1 = body;
        call_then(start_inline_statements(body_1), [=](Text inline_statements_13441) { return prism_rtl::finished(prism_rtl::cat(inline_statements_13441, ";")); });
    });
    })
        : prism_rtl::is<lower::Do::DoNote>(d) ? ({
        auto&& t = prism_rtl::as<lower::Do::DoNote>(d).a0;
        prism_rtl::finished(prism_rtl::cat("// ", t));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Statement, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_statement(lower::Do d) {
    return std::make_shared<Statement>(d);
}


/// InlineStatements: unbounded fn [Do] -> Text
Text inline_statements(const Array<lower::Do>& dos) {
    return lexer::join(run_to_end(each_job(dos, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Do)>>(prism_rtl::rc([=](lower::Do p0) {
        return entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(InlineStatement(d))));
            });
        }));
    })))), Text(" "));
}


prism_rtl::Turn<Text> InlineStatements::cycle() const {
    const auto& dos = this->dos;
    auto dos_1 = dos;
    return call_value(each_job(dos_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Do)>>(prism_rtl::rc([=](lower::Do p0) {
        return entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(InlineStatement(d))));
            });
        }));
    }))), [=](Array<Text> each_13614) { return prism_rtl::finished(lexer::join(each_13614, Text(" "))); });
}


/// `Start InlineStatements, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_inline_statements(Array<lower::Do> dos) {
    return std::make_shared<InlineStatements>(dos);
}


/// InlineStatement: unbounded fn Do -> Text
Text inline_statement(const lower::Do& do_0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Do::DoIf>(do_0)) {
            auto&& c = prism_rtl::as<lower::Do::DoIf>(do_0).a0;
            auto&& t = prism_rtl::as<lower::Do::DoIf>(do_0).a1;
            auto&& c0_0_2 = prism_rtl::as<lower::Do::DoIf>(do_0).a2;
            if (c0_0_2.size() == 0u) {
                _v.set(prism_rtl::cat("if ", expression(c), " { ", inline_statements(t), " }"));
                goto _done;
            }
        }
        {
            auto&& d = do_0;
            _v.set(statement(d));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> InlineStatement::cycle() const {
    const auto& do_0 = this->do_0;
    return ({
        prism_rtl::is<lower::Do::DoIf>(do_0) && ({
        auto&& c = prism_rtl::as<lower::Do::DoIf>(do_0).a0;
        auto&& t = prism_rtl::as<lower::Do::DoIf>(do_0).a1;
        auto&& j0_0_2 = prism_rtl::as<lower::Do::DoIf>(do_0).a2;
        (j0_0_2.size() == 0u);
    }) ? ({
        auto&& c = prism_rtl::as<lower::Do::DoIf>(do_0).a0;
        auto&& t = prism_rtl::as<lower::Do::DoIf>(do_0).a1;
        auto&& j0_0_2 = prism_rtl::as<lower::Do::DoIf>(do_0).a2;
        ({
        auto c_1 = c;
        auto t_2 = t;
        call_then(start_expression(c_1), [=](Text expression_13739) { return call_then(start_inline_statements(t_2), [=](Text inline_statements_13757) { return prism_rtl::finished(prism_rtl::cat("if ", expression_13739, " { ", inline_statements_13757, " }")); }); });
    });
    })
        : ({
        auto&& d = do_0;
        prism_rtl::more(prism_rtl::rc(Statement(d)));
    });
    });
}


/// `Start InlineStatement, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_inline_statement(lower::Do do_0) {
    return std::make_shared<InlineStatement>(do_0);
}


/// ElseBranch: unbounded fn [Do] -> Text
Text else_branch(const Array<lower::Do>& xs0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& c0_0 = xs0;
            if (c0_0.size() == 0u) {
                _v.set(Text(""));
                goto _done;
            }
        }
        {
            auto&& c1_0 = xs0;
            if (c1_0.size() == 1u) {
                {
                    auto&& _c1 = index(c1_0, Nat(0u));
                    if (prism_rtl::is_some(_c1) && prism_rtl::is<lower::Do::DoIf>(prism_rtl::some_of(_c1))) {
                        auto&& c = prism_rtl::as<lower::Do::DoIf>(prism_rtl::some_of(_c1)).a0;
                        auto&& t = prism_rtl::as<lower::Do::DoIf>(prism_rtl::some_of(_c1)).a1;
                        auto&& e = prism_rtl::as<lower::Do::DoIf>(prism_rtl::some_of(_c1)).a2;
                        _v.set(prism_rtl::cat(" else ", statement(lower::Do(lower::Do::DoIf{c, t, e}))));
                        goto _done;
                    }
                }
            }
        }
        {
            auto&& c2_0 = xs0;
            if (c2_0.size() == 1u) {
                {
                    auto&& _c1 = index(c2_0, Nat(0u));
                    if (prism_rtl::is_some(_c1) && prism_rtl::is<lower::Do::DoIfLet>(prism_rtl::some_of(_c1))) {
                        auto&& p_ = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a0;
                        auto&& x = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a1;
                        auto&& t = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a2;
                        auto&& e = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a3;
                        _v.set(prism_rtl::cat(" else ", statement(lower::Do(lower::Do::DoIfLet{p_, x, t, e}))));
                        goto _done;
                    }
                }
            }
        }
        {
            auto&& body = xs0;
            _v.set(rust_templates::else_(statements(body)));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> ElseBranch::cycle() const {
    const auto& xs0 = this->xs0;
    return ({
        ({
        auto&& j0_0 = xs0;
        (j0_0.size() == 0u);
    }) ? ({
        auto&& j0_0 = xs0;
        prism_rtl::finished(Text(""));
    })
        : ({
        auto&& j1_0 = xs0;
        (j1_0.size() == 1u) && ({
        auto&& _c1 = index(j1_0, Nat(0u));
        prism_rtl::is_some(_c1) && prism_rtl::is<lower::Do::DoIf>(prism_rtl::some_of(_c1));
    });
    }) ? ({
        auto&& j1_0 = xs0;
        auto&& _c1 = index(j1_0, Nat(0u));
        auto&& c = prism_rtl::as<lower::Do::DoIf>(prism_rtl::some_of(_c1)).a0;
        auto&& t = prism_rtl::as<lower::Do::DoIf>(prism_rtl::some_of(_c1)).a1;
        auto&& e = prism_rtl::as<lower::Do::DoIf>(prism_rtl::some_of(_c1)).a2;
        call_then(start_statement(lower::Do(lower::Do::DoIf{c, t, e})), [=](Text statement_13969) { return prism_rtl::finished(prism_rtl::cat(" else ", statement_13969)); });
    })
        : ({
        auto&& j2_0 = xs0;
        (j2_0.size() == 1u) && ({
        auto&& _c1 = index(j2_0, Nat(0u));
        prism_rtl::is_some(_c1) && prism_rtl::is<lower::Do::DoIfLet>(prism_rtl::some_of(_c1));
    });
    }) ? ({
        auto&& j2_0 = xs0;
        auto&& _c1 = index(j2_0, Nat(0u));
        auto&& p_ = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a0;
        auto&& x = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a1;
        auto&& t = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a2;
        auto&& e = prism_rtl::as<lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a3;
        call_then(start_statement(lower::Do(lower::Do::DoIfLet{p_, x, t, e})), [=](Text statement_14045) { return prism_rtl::finished(prism_rtl::cat(" else ", statement_14045)); });
    })
        : ({
        auto&& body = xs0;
        ({
        auto body_1 = body;
        call_then(start_statements(body_1), [=](Text statements_14105) { return prism_rtl::finished(rust_templates::else_(statements_14105)); });
    });
    });
    });
}


/// `Start ElseBranch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_else_branch(Array<lower::Do> xs0) {
    return std::make_shared<ElseBranch>(xs0);
}


/// Generics: fn [((Text, [Text]))] -> Text
Text generics(const Array<std::tuple<Text, Array<Text>>>& xs0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& c0_0 = xs0;
            if (c0_0.size() == 0u) {
                _v.set(Text(""));
                goto _done;
            }
        }
        {
            auto&& gs = xs0;
            _v.set(prism_rtl::cat("<", lexer::join(each(gs, [&](const std::tuple<Text, Array<Text>>& _p0) {
                auto&& g = std::get<0>(_p0);
                auto&& bs = std::get<1>(_p0);
                return len(bs) == Nat(0u)
                    ? g
                    : prism_rtl::cat(g, ": ", lexer::join(bs, Text(" + ")));
            }), Text(", ")), ">"));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// GenericNames: fn [Text] -> Text
Text generic_names(const Array<Text>& xs0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& c0_0 = xs0;
            if (c0_0.size() == 0u) {
                _v.set(Text(""));
                goto _done;
            }
        }
        {
            auto&& ps = xs0;
            _v.set(prism_rtl::cat("<", lexer::join(ps, Text(", ")), ">"));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// Bounded: fn [Text], Text -> Text
Text bounded(const Array<Text>& xs0, const Text& text1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = std::tuple{xs0, text1};
        {
            auto&& c0_0 = std::get<0>(_m);
            if (c0_0.size() == 0u) {
                _v.set(Text(""));
                goto _done;
            }
        }
        {
            auto&& ps = std::get<0>(_m);
            auto&& tr = std::get<1>(_m);
            _v.set(prism_rtl::cat("<", lexer::join(each(ps, [&](const Text& p_) { return prism_rtl::cat(p_, ": ", tr); }), Text(", ")), ">"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// RustItem: unbounded fn Item -> Text
Text rust_item(const lower::Item& it) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Item::ItTrait>(it)) {
            auto&& t = prism_rtl::as<lower::Item::ItTrait>(it).a0;
            _v.set(rust_trait(t));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItImpl>(it)) {
            auto&& i = prism_rtl::as<lower::Item::ItImpl>(it).a0;
            _v.set(rust_impl(i));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItType>(it)) {
            auto&& t = prism_rtl::as<lower::Item::ItType>(it).a0;
            _v.set(type_decl(t));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItTag>(it)) {
            auto&& t = prism_rtl::as<lower::Item::ItTag>(it).a0;
            _v.set(rust_tag(t));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItRow>(it)) {
            auto&& r = prism_rtl::as<lower::Item::ItRow>(it).a0;
            _v.set(rust_row(r));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItFn>(it)) {
            auto&& f = prism_rtl::as<lower::Item::ItFn>(it).a0;
            _v.set(rust_fn(f));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItJob>(it)) {
            auto&& j = prism_rtl::as<lower::Item::ItJob>(it).a0;
            _v.set(rust_job(j));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItNode>(it)) {
            auto&& n = prism_rtl::as<lower::Item::ItNode>(it).a0;
            _v.set(rust_node(n));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItNote>(it)) {
            auto&& t = prism_rtl::as<lower::Item::ItNote>(it).a0;
            _v.set(prism_rtl::cat("// ", t, "\n"));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItRefused>(it)) {
            auto&& t = prism_rtl::as<lower::Item::ItRefused>(it).a0;
            _v.set(prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), lower::escape(t), "\");\n"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> RustItem::cycle() const {
    const auto& it = this->it;
    return ({
        prism_rtl::is<lower::Item::ItTrait>(it) ? ({
        auto&& t = prism_rtl::as<lower::Item::ItTrait>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustTrait(t)));
    })
        : prism_rtl::is<lower::Item::ItImpl>(it) ? ({
        auto&& i = prism_rtl::as<lower::Item::ItImpl>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustImpl(i)));
    })
        : prism_rtl::is<lower::Item::ItType>(it) ? ({
        auto&& t = prism_rtl::as<lower::Item::ItType>(it).a0;
        prism_rtl::more(prism_rtl::rc(TypeDecl(t)));
    })
        : prism_rtl::is<lower::Item::ItTag>(it) ? ({
        auto&& t = prism_rtl::as<lower::Item::ItTag>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustTag(t)));
    })
        : prism_rtl::is<lower::Item::ItRow>(it) ? ({
        auto&& r = prism_rtl::as<lower::Item::ItRow>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustRow(r)));
    })
        : prism_rtl::is<lower::Item::ItFn>(it) ? ({
        auto&& f = prism_rtl::as<lower::Item::ItFn>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustFn(f)));
    })
        : prism_rtl::is<lower::Item::ItJob>(it) ? ({
        auto&& j = prism_rtl::as<lower::Item::ItJob>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustJob(j)));
    })
        : prism_rtl::is<lower::Item::ItNode>(it) ? ({
        auto&& n = prism_rtl::as<lower::Item::ItNode>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustNode(n)));
    })
        : prism_rtl::is<lower::Item::ItNote>(it) ? ({
        auto&& t = prism_rtl::as<lower::Item::ItNote>(it).a0;
        prism_rtl::finished(prism_rtl::cat("// ", t, "\n"));
    })
        : prism_rtl::is<lower::Item::ItRefused>(it) ? ({
        auto&& t = prism_rtl::as<lower::Item::ItRefused>(it).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), lower::escape(t), "\");\n"));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RustItem, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_item(lower::Item it) {
    return std::make_shared<RustItem>(it);
}


/// RustTrait: unbounded fn TraitDef -> Text
Text rust_trait(const lower::TraitDef& t) {
    auto ms = lexer::join(run_to_end(each_job(t.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
        return entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(TraitMethod(f))));
            });
        }));
    })))), Text("\n"));
    return prism_rtl::cat(rust_templates::source_doc(Text(""), t.doc), "pub trait ", t.name, " {\n", indent(ms), "\n}\n");
}


prism_rtl::Turn<Text> RustTrait::cycle() const {
    const auto& t = this->t;
    auto t_1 = t;
    return call_value(each_job(t_1.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
        return entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(TraitMethod(f))));
            });
        }));
    }))), [=](Array<Text> each_15138) {
        return ({
            auto ms = lexer::join(each_15138, Text("\n"));
            (prism_rtl::finished(prism_rtl::cat(rust_templates::source_doc(Text(""), t_1.doc), "pub trait ", t_1.name, " {\n", indent(ms), "\n}\n")));
        });
    });
}


/// `Start RustTrait, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_trait(lower::TraitDef t) {
    return std::make_shared<RustTrait>(t);
}


/// Signature: unbounded fn FnDef, Text -> Text
Text signature(const lower::FnDef& f, const Text& vis) {
    auto params = lexer::join(run_to_end(each_job(f.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_type_(t), [=](Text type__15371) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__15371)); });
            });
        }));
    })))), Text(", "));
    return prism_rtl::cat(vis, "fn ", f.name, generics(f.generics), "(", params, ") -> ", type_(f.ret));
}


prism_rtl::Turn<Text> Signature::cycle() const {
    const auto& f = this->f;
    const auto& vis = this->vis;
    auto f_1 = f;
    auto vis_2 = vis;
    return call_value(each_job(f_1.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_type_(t), [=](Text type__15371) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__15371)); });
            });
        }));
    }))), [=](Array<Text> each_15337) {
        return ({
            auto params = lexer::join(each_15337, Text(", "));
            call_then(start_type_(f_1.ret), [=](Text type__15444) { return prism_rtl::finished(prism_rtl::cat(vis_2, "fn ", f_1.name, generics(f_1.generics), "(", params, ") -> ", type__15444)); });
        });
    });
}


/// `Start Signature, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_signature(lower::FnDef f, Text vis) {
    return std::make_shared<Signature>(f, vis);
}


/// TraitMethod: unbounded fn FnDef -> Text
Text trait_method(const lower::FnDef& f) {
    return f.public_
        ? rust_templates::fn_(Text(""), signature(f, Text("")), body_lines(f.body))
        : prism_rtl::cat(signature(f, Text("")), ";");
}


prism_rtl::Turn<Text> TraitMethod::cycle() const {
    const auto& f = this->f;
    return f.public_
        ? ({
        auto f_1 = f;
        call_then(start_signature(f_1, Text("")), [=](Text signature_15538) { return call_then(start_body_lines(f_1.body), [=](Text body_lines_15557) { return prism_rtl::finished(rust_templates::fn_(Text(""), signature_15538, body_lines_15557)); }); });
    })
        : ({
        auto f_1 = f;
        call_then(start_signature(f_1, Text("")), [=](Text signature_15583) { return prism_rtl::finished(prism_rtl::cat(signature_15583, ";")); });
    });
}


/// `Start TraitMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_trait_method(lower::FnDef f) {
    return std::make_shared<TraitMethod>(f);
}


/// RustImpl: unbounded fn ImplDef -> Text
Text rust_impl(const lower::ImplDef& i) {
    auto head = type_(i.head);
    auto gens = generics(i.generics);
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = i.cls;
        {
            auto&& m15858_0 = _m;
            if (m15858_0 == Text("Prelude.Show")) {
                _v.set(({
                    auto fns = lexer::join(run_to_end(each_job(i.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
                        return entered(once_job([=]() {
                            return ({
                                auto f = p0;
                                (prism_rtl::more(prism_rtl::rc(RustFn(f))));
                            });
                        }));
                    })))), Text("\n"));
                    auto shown = or_(index(each(i.methods, [&](const lower::FnDef& f) { return f.name; }), Nat(0u)), Text("show"));
                    (prism_rtl::cat(fns, "\n", rust_templates::impl_(gens, Text("Show"), head, Text("fn show(&self, p: &mut Printer)"), prism_rtl::cat("p.raw(&", shown, "(self).to_string());"))));
                }));
                goto _done;
            }
        }
        {
            auto&& m15858_1 = _m;
            if (m15858_1 == Text("Prelude.Eq")) {
                _v.set(({
                    auto fns = lexer::join(run_to_end(each_job(i.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
                        return entered(once_job([=]() {
                            return ({
                                auto f = p0;
                                (prism_rtl::more(prism_rtl::rc(RustFn(f))));
                            });
                        }));
                    })))), Text("\n"));
                    auto eq = fold(i.methods, Text(""), [&](const Text& acc, const lower::FnDef& f) {
                        return (take_text(f.name, Nat(2u)) != Text("ne")) && (acc == Text(""))
                            ? f.name
                            : acc;
                    });
                    (prism_rtl::cat(fns, "\n", rust_templates::impl_(gens, Text("PartialEq"), head, Text("fn eq(&self, other: &Self) -> bool"), prism_rtl::cat(eq, "(self, other)"))));
                }));
                goto _done;
            }
        }
        {
            _v.set(prism_rtl::cat("impl", gens, " ", i.tr, " for ", head, " {\n", indent(lexer::join(run_to_end(each_job(i.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
                return entered(once_job([=]() {
                    return ({
                        auto f = p0;
                        call_then(start_signature(f, Text("")), [=](Text signature_16554) { return call_then(start_body_lines(f.body), [=](Text body_lines_16573) { return prism_rtl::finished(rust_templates::fn_(Text(""), signature_16554, body_lines_16573)); }); });
                    });
                }));
            })))), Text("\n"))), "\n}\n"));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> RustImpl::cycle() const {
    const auto& i = this->i;
    auto i_1 = i;
    return call_then(start_type_(i_1.head), [=](Text type__15807) {
        return ({
            auto head = type__15807;
            auto gens = generics(i_1.generics);
            ({
            auto&& _m = i_1.cls;
            ({
            auto&& m15858_0 = _m;
            (m15858_0 == Text("Prelude.Show"));
        }) ? ({
            auto&& m15858_0 = _m;
            call_value(each_job(i_1.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto f = p0;
                    (prism_rtl::more(prism_rtl::rc(RustFn(f))));
                });
            }));
        }))), [=](Array<Text> each_15923) {
            return ({
                auto fns = lexer::join(each_15923, Text("\n"));
                auto shown = or_(index(each(i_1.methods, [&](const lower::FnDef& f) { return f.name; }), Nat(0u)), Text("show"));
                (prism_rtl::finished(prism_rtl::cat(fns, "\n", rust_templates::impl_(gens, Text("Show"), head, Text("fn show(&self, p: &mut Printer)"), prism_rtl::cat("p.raw(&", shown, "(self).to_string());")))));
            });
        });
        })
            : ({
            auto&& m15858_1 = _m;
            (m15858_1 == Text("Prelude.Eq"));
        }) ? ({
            auto&& m15858_1 = _m;
            call_value(each_job(i_1.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto f = p0;
                    (prism_rtl::more(prism_rtl::rc(RustFn(f))));
                });
            }));
        }))), [=](Array<Text> each_16198) {
            return ({
                auto fns = lexer::join(each_16198, Text("\n"));
                auto eq = fold(i_1.methods, Text(""), [&](const Text& acc, const lower::FnDef& f) {
                    return (take_text(f.name, Nat(2u)) != Text("ne")) && (acc == Text(""))
                        ? f.name
                        : acc;
                });
                (prism_rtl::finished(prism_rtl::cat(fns, "\n", rust_templates::impl_(gens, Text("PartialEq"), head, Text("fn eq(&self, other: &Self) -> bool"), prism_rtl::cat(eq, "(self, other)")))));
            });
        });
        })
            : call_value(each_job(i_1.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::FnDef)>>(prism_rtl::rc([=](lower::FnDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto f = p0;
                    call_then(start_signature(f, Text("")), [=](Text signature_16554) { return call_then(start_body_lines(f.body), [=](Text body_lines_16573) { return prism_rtl::finished(rust_templates::fn_(Text(""), signature_16554, body_lines_16573)); }); });
                });
            }));
        }))), [=](Array<Text> each_16525) { return prism_rtl::finished(prism_rtl::cat("impl", gens, " ", i_1.tr, " for ", head, " {\n", indent(lexer::join(each_16525, Text("\n"))), "\n}\n")); });
        });
        });
    });
}


/// `Start RustImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_impl(lower::ImplDef i) {
    return std::make_shared<RustImpl>(i);
}


/// RustFn: unbounded fn FnDef -> Text
Text rust_fn(const lower::FnDef& f) {
    auto params = lexer::join(run_to_end(each_job(f.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_type_(t), [=](Text type__16713) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__16713)); });
            });
        }));
    })))), Text(", "));
    auto sig = prism_rtl::cat("pub fn ", f.name, static_generics(f.generics), "(", params, ") -> ", type_(f.ret));
    return rust_templates::fn_(rust_templates::source_doc(Text(""), f.doc), sig, body_lines(f.body));
}


prism_rtl::Turn<Text> RustFn::cycle() const {
    const auto& f = this->f;
    auto f_1 = f;
    return call_value(each_job(f_1.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_type_(t), [=](Text type__16713) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__16713)); });
            });
        }));
    }))), [=](Array<Text> each_16679) {
        return ({
            auto params = lexer::join(each_16679, Text(", "));
            call_then(start_type_(f_1.ret), [=](Text type__16943) {
            return ({
                auto sig = prism_rtl::cat("pub fn ", f_1.name, static_generics(f_1.generics), "(", params, ") -> ", type__16943);
                call_then(start_body_lines(f_1.body), [=](Text body_lines_16992) { return prism_rtl::finished(rust_templates::fn_(rust_templates::source_doc(Text(""), f_1.doc), sig, body_lines_16992)); });
            });
        });
        });
    });
}


/// `Start RustFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_fn(lower::FnDef f) {
    return std::make_shared<RustFn>(f);
}


/// StaticGenerics: fn [((Text, [Text]))] -> Text
Text static_generics(const Array<std::tuple<Text, Array<Text>>>& gs) {
    return generics(each(gs, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g = std::get<0>(_p0);
        auto&& bs = std::get<1>(_p0);
        return std::tuple{g, prelude::push(bs, Text("'static"))};
    }));
}


/// RustJob: unbounded fn JobDef -> Text
Text rust_job(const lower::JobDef& j) {
    auto gnames = generic_names(each(j.generics, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g = std::get<0>(_p0);
        return g;
    }));
    auto fields = lexer::join(run_to_end(each_job(j.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_type_(t), [=](Text type__17398) { return prism_rtl::finished(prism_rtl::cat("pub ", n, ": ", type__17398, ",")); });
            });
        }));
    })))), Text("\n"));
    auto params = lexer::join(run_to_end(each_job(j.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_type_(t), [=](Text type__17472) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__17472)); });
            });
        }));
    })))), Text(", "));
    auto bounded_ = static_generics(j.generics);
    auto start = prism_rtl::cat("pub fn ", j.start, bounded_, "(", params, ") -> Rc<dyn prism_rtl::Job<", type_(j.ret), ">>");
    auto start_body = prism_rtl::cat("Rc::new(", j.name, " { ", lexer::join(each(j.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
        auto&& n = std::get<0>(_p0);
        return n;
    }), Text(", ")), " })");
    return rust_templates::job(rust_templates::source_doc(Text(""), j.doc), j.name, gnames, bounded_, fields, type_(j.ret), body_lines(j.body), start, start_body);
}


prism_rtl::Turn<Text> RustJob::cycle() const {
    const auto& j = this->j;
    auto gnames = generic_names(each(j.generics, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g = std::get<0>(_p0);
        return g;
    }));
    auto j_1 = j;
    return call_value(each_job(j_1.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_type_(t), [=](Text type__17398) { return prism_rtl::finished(prism_rtl::cat("pub ", n, ": ", type__17398, ",")); });
            });
        }));
    }))), [=](Array<Text> each_17360) {
        return ({
            auto fields = lexer::join(each_17360, Text("\n"));
            call_value(each_job(j_1.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [n, t] = p0;
                    call_then(start_type_(t), [=](Text type__17472) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__17472)); });
                });
            }));
        }))), [=](Array<Text> each_17438) {
            return ({
                auto params = lexer::join(each_17438, Text(", "));
                auto bounded_ = static_generics(j_1.generics);
                call_then(start_type_(j_1.ret), [=](Text type__17696) {
                return ({
                    auto start = prism_rtl::cat("pub fn ", j_1.start, bounded_, "(", params, ") -> Rc<dyn prism_rtl::Job<", type__17696, ">>");
                    auto start_body = prism_rtl::cat("Rc::new(", j_1.name, " { ", lexer::join(each(j_1.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                        auto&& n = std::get<0>(_p0);
                        return n;
                    }), Text(", ")), " })");
                    call_then(start_type_(j_1.ret), [=](Text type__17871) { return call_then(start_body_lines(j_1.body), [=](Text body_lines_17885) { return prism_rtl::finished(rust_templates::job(rust_templates::source_doc(Text(""), j_1.doc), j_1.name, gnames, bounded_, fields, type__17871, body_lines_17885, start, start_body)); }); });
                });
            });
            });
        });
        });
    });
}


/// `Start RustJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_job(lower::JobDef j) {
    return std::make_shared<RustJob>(j);
}


/// TypeDecl: unbounded fn TyDef -> Text
Text type_decl(const lower::TyDef& t) {
    auto eq = t.eq && (!t.floaty);
    auto ord = t.ord && (!t.floaty);
    auto derives = lexer::join(filter(Array(std::vector{Text("Clone"), t.eq || t.ord ? Text("PartialEq") : Text(""), eq || ord ? Text("Eq") : Text(""), t.ord ? Text("PartialOrd") : Text(""), ord ? Text("Ord") : Text("")}), [&](const Text& d) { return d != Text(""); }), Text(", "));
    auto head = prism_rtl::cat(t.name, generic_names(t.params));
    auto doc = rust_templates::source_doc(prism_rtl::cat("`", t.prism, "`:"), t.doc);
    auto decl = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (rust_templates::struct_(doc, derives, head, lexer::join(run_to_end(each_job(c.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto [f, ft] = p0;
                        call_then(start_type_(ft), [=](Text type__18643) { return prism_rtl::finished(prism_rtl::cat("pub ", f, ": ", type__18643, ",")); });
                    });
                }));
            })))), Text("\n"))));
            }));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeUnit>(_m)) {
            _v.set(rust_templates::tuple_struct(doc, derives, head, Text("")));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeNewtype>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (rust_templates::tuple_struct(doc, derives, head, prism_rtl::cat("(", lexer::join(run_to_end(each_job(c.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto&& _ft = p0;
                        auto&& ft = std::get<1>(_ft);
                        call_then(start_type_(ft), [=](Text type__18907) { return prism_rtl::finished(prism_rtl::cat("pub ", type__18907)); });
                    });
                }));
            })))), Text(", ")), ")")));
            }));
            goto _done;
        }
        {
            _v.set(rust_templates::enum_(doc, derives, head, lexer::join(run_to_end(each_job(t.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::CaseDef)>>(prism_rtl::rc([=](lower::CaseDef p0) {
                return entered(once_job([=]() {
                    return ({
                        auto c = p0;
                        (prism_rtl::more(prism_rtl::rc(EnumCase(c))));
                    });
                }));
            })))), Text("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto show_ = t.show_ == lower::Shown(lower::Shown::ShownDerived{})
        ? prism_rtl::cat("\n", show_impl(t, head))
        : Text("");
    auto pod = t.pod
        ? prism_rtl::cat("\n", to_pod_impl(t, head), "\n", from_pod_impl(t, head))
        : Text("");
    return prism_rtl::cat(decl, show_, pod);
}


prism_rtl::Turn<Text> TypeDecl::cycle() const {
    const auto& t = this->t;
    auto eq = t.eq && (!t.floaty);
    auto ord = t.ord && (!t.floaty);
    auto derives = lexer::join(filter(Array(std::vector{Text("Clone"), t.eq || t.ord ? Text("PartialEq") : Text(""), eq || ord ? Text("Eq") : Text(""), t.ord ? Text("PartialOrd") : Text(""), ord ? Text("Ord") : Text("")}), [&](const Text& d) { return d != Text(""); }), Text(", "));
    auto head = prism_rtl::cat(t.name, generic_names(t.params));
    auto doc = rust_templates::source_doc(prism_rtl::cat("`", t.prism, "`:"), t.doc);
    auto decl = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (rust_templates::struct_(doc, derives, head, lexer::join(run_to_end(each_job(c.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto [f, ft] = p0;
                        call_then(start_type_(ft), [=](Text type__18643) { return prism_rtl::finished(prism_rtl::cat("pub ", f, ": ", type__18643, ",")); });
                    });
                }));
            })))), Text("\n"))));
            }));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeUnit>(_m)) {
            _v.set(rust_templates::tuple_struct(doc, derives, head, Text("")));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeNewtype>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (rust_templates::tuple_struct(doc, derives, head, prism_rtl::cat("(", lexer::join(run_to_end(each_job(c.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto&& _ft = p0;
                        auto&& ft = std::get<1>(_ft);
                        call_then(start_type_(ft), [=](Text type__18907) { return prism_rtl::finished(prism_rtl::cat("pub ", type__18907)); });
                    });
                }));
            })))), Text(", ")), ")")));
            }));
            goto _done;
        }
        {
            _v.set(rust_templates::enum_(doc, derives, head, lexer::join(run_to_end(each_job(t.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::CaseDef)>>(prism_rtl::rc([=](lower::CaseDef p0) {
                return entered(once_job([=]() {
                    return ({
                        auto c = p0;
                        (prism_rtl::more(prism_rtl::rc(EnumCase(c))));
                    });
                }));
            })))), Text("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto show_ = t.show_ == lower::Shown(lower::Shown::ShownDerived{})
        ? prism_rtl::cat("\n", show_impl(t, head))
        : Text("");
    auto pod = t.pod
        ? prism_rtl::cat("\n", to_pod_impl(t, head), "\n", from_pod_impl(t, head))
        : Text("");
    return prism_rtl::finished(prism_rtl::cat(decl, show_, pod));
}


/// `Start TypeDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_type_decl(lower::TyDef t) {
    return std::make_shared<TypeDecl>(t);
}


/// EnumCase: unbounded fn CaseDef -> Text
Text enum_case(const lower::CaseDef& c) {
    return len(c.fields) == Nat(0u)
        ? prism_rtl::cat(c.name, ",")
        : prism_rtl::cat(c.name, "(", lexer::join(run_to_end(each_job(c.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _ft = p0;
                auto&& ft = std::get<1>(_ft);
                (prism_rtl::more(prism_rtl::rc(Type(ft))));
            });
        }));
    })))), Text(", ")), "),");
}


prism_rtl::Turn<Text> EnumCase::cycle() const {
    const auto& c = this->c;
    return len(c.fields) == Nat(0u)
        ? prism_rtl::finished(prism_rtl::cat(c.name, ","))
        : ({
        auto c_1 = c;
        call_value(each_job(c_1.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _ft = p0;
                auto&& ft = std::get<1>(_ft);
                (prism_rtl::more(prism_rtl::rc(Type(ft))));
            });
        }));
    }))), [=](Array<Text> each_19309) { return prism_rtl::finished(prism_rtl::cat(c_1.name, "(", lexer::join(each_19309, Text(", ")), "),")); });
    });
}


/// `Start EnumCase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_enum_case(lower::CaseDef c) {
    return std::make_shared<EnumCase>(c);
}


/// Binders: fn Nat -> [Text]
Array<Text> binders(const Nat& n) {
    return each(check_errors::range0(n), [&](const Nat& i) { return prism_rtl::cat("a", i); });
}


/// CasePattern: fn TyDef, CaseDef -> Text
Text case_pattern(const lower::TyDef& t, const lower::CaseDef& c) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat(t.name, "(", lexer::join(binders(len(c.fields)), Text(", ")), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeUnit>(_m)) {
            _v.set(t.name);
            goto _done;
        }
        {
            _v.set(len(c.fields) == Nat(0u)
                ? prism_rtl::cat(t.name, "::", c.name)
                : prism_rtl::cat(t.name, "::", c.name, "(", lexer::join(binders(len(c.fields)), Text(", ")), ")"));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ShowImpl: unbounded fn TyDef, Text -> Text
Text show_impl(const lower::TyDef& t, const Text& head) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (prism_rtl::cat("p.record(\"", t.prism, "\", &[", lexer::join(each(c.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field(f), "\", &self.", f, ")");
            }), Text(", ")), "]);"));
            }));
            goto _done;
        }
        {
            _v.set(rust_templates::match_self(lexer::join(each(t.cases_, [&](const lower::CaseDef& c) { return prism_rtl::cat(case_pattern(t, c), " => p.choice(\"", c.prism, "\", &[", lexer::join(binders(len(c.fields)), Text(", ")), "]),"); }), Text("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    return rust_templates::impl_(bounded(t.params, Text("Show")), Text("Show"), head, Text("fn show(&self, p: &mut Printer)"), body);
}


prism_rtl::Turn<Text> ShowImpl::cycle() const {
    const auto& t = this->t;
    const auto& head = this->head;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (prism_rtl::cat("p.record(\"", t.prism, "\", &[", lexer::join(each(c.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field(f), "\", &self.", f, ")");
            }), Text(", ")), "]);"));
            }));
            goto _done;
        }
        {
            _v.set(rust_templates::match_self(lexer::join(each(t.cases_, [&](const lower::CaseDef& c) { return prism_rtl::cat(case_pattern(t, c), " => p.choice(\"", c.prism, "\", &[", lexer::join(binders(len(c.fields)), Text(", ")), "]),"); }), Text("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(rust_templates::impl_(bounded(t.params, Text("Show")), Text("Show"), head, Text("fn show(&self, p: &mut Printer)"), body));
}


/// `Start ShowImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_impl(lower::TyDef t, Text head) {
    return std::make_shared<ShowImpl>(t, head);
}


/// PrismField: fn Text -> Text
Text prism_field(const Text& f) {
    return drop_text(f, lexer::dec(len_text(f))) == Text("_")
        ? take_text(f, lexer::dec(len_text(f)))
        : f;
}


/// ToPodImpl: unbounded fn TyDef, Text -> Text
Text to_pod_impl(const lower::TyDef& t, const Text& head) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (prism_rtl::cat("Pod::record(\"", t.prism, "\", vec![", lexer::join(each(c.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field(f), "\", self.", f, ".to_pod())");
            }), Text(", ")), "])"));
            }));
            goto _done;
        }
        {
            _v.set(rust_templates::match_self(lexer::join(each(t.cases_, [&](const lower::CaseDef& c) { return prism_rtl::cat(case_pattern(t, c), " => Pod::Choice(\"", c.prism, "\".into(), vec![", lexer::join(each(binders(len(c.fields)), [&](const Text& b) { return prism_rtl::cat(b, ".to_pod()"); }), Text(", ")), "]),"); }), Text("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto shown = t.show_ == lower::Shown(lower::Shown::ShownOwn{})
        ? rust_templates::shown_pod(body)
        : body;
    return rust_templates::impl_(bounded(t.params, Text("ToPod")), Text("ToPod"), head, Text("fn to_pod(&self) -> Pod"), shown);
}


prism_rtl::Turn<Text> ToPodImpl::cycle() const {
    const auto& t = this->t;
    const auto& head = this->head;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (prism_rtl::cat("Pod::record(\"", t.prism, "\", vec![", lexer::join(each(c.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field(f), "\", self.", f, ".to_pod())");
            }), Text(", ")), "])"));
            }));
            goto _done;
        }
        {
            _v.set(rust_templates::match_self(lexer::join(each(t.cases_, [&](const lower::CaseDef& c) { return prism_rtl::cat(case_pattern(t, c), " => Pod::Choice(\"", c.prism, "\".into(), vec![", lexer::join(each(binders(len(c.fields)), [&](const Text& b) { return prism_rtl::cat(b, ".to_pod()"); }), Text(", ")), "]),"); }), Text("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto shown = t.show_ == lower::Shown(lower::Shown::ShownOwn{})
        ? rust_templates::shown_pod(body)
        : body;
    return prism_rtl::finished(rust_templates::impl_(bounded(t.params, Text("ToPod")), Text("ToPod"), head, Text("fn to_pod(&self) -> Pod"), shown));
}


/// `Start ToPodImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_to_pod_impl(lower::TyDef t, Text head) {
    return std::make_shared<ToPodImpl>(t, head);
}


/// FromPodImpl: unbounded fn TyDef, Text -> Text
Text from_pod_impl(const lower::TyDef& t, const Text& head) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (prism_rtl::cat("Ok(", t.name, " { ", lexer::join(each(c.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat(f, ": FromPod::from_pod(field(p, \"", prism_field(f), "\")?)?");
            }), Text(", ")), " })"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms_ = each(t.cases_, [&](const lower::CaseDef& c) {
                    return ({
                        auto n = len(c.fields);
                        auto made = n == Nat(0u)
                            ? t.shape == lower::TyShape(lower::TyShape::ShapeUnit{})
                            ? t.name
                            : prism_rtl::cat(t.name, "::", c.name)
                            : prism_rtl::cat(t.shape == lower::TyShape(lower::TyShape::ShapeNewtype{})
                            ? t.name
                            : prism_rtl::cat(t.name, "::", c.name), "(", lexer::join(each(check_errors::range0(n), [&](const Nat& i) { return prism_rtl::cat("FromPod::from_pod(&a[", i, "])?"); }), Text(", ")), ")");
                        (prism_rtl::cat("Pod::Choice(c, a) if &**c == \"", c.prism, "\" && a.len() == ", n, " => Ok(", made, "),"));
                    });
                });
                (rust_templates::from_pod_body(lexer::join(arms_, Text("\n")), prism_rtl::cat("a ", t.prism)));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return rust_templates::impl_(bounded(t.params, Text("FromPod")), Text("FromPod"), head, Text("fn from_pod(p: &Pod) -> Result<Self, Fault>"), body);
}


prism_rtl::Turn<Text> FromPodImpl::cycle() const {
    const auto& t = this->t;
    const auto& head = this->head;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
                (prism_rtl::cat("Ok(", t.name, " { ", lexer::join(each(c.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat(f, ": FromPod::from_pod(field(p, \"", prism_field(f), "\")?)?");
            }), Text(", ")), " })"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms_ = each(t.cases_, [&](const lower::CaseDef& c) {
                    return ({
                        auto n = len(c.fields);
                        auto made = n == Nat(0u)
                            ? t.shape == lower::TyShape(lower::TyShape::ShapeUnit{})
                            ? t.name
                            : prism_rtl::cat(t.name, "::", c.name)
                            : prism_rtl::cat(t.shape == lower::TyShape(lower::TyShape::ShapeNewtype{})
                            ? t.name
                            : prism_rtl::cat(t.name, "::", c.name), "(", lexer::join(each(check_errors::range0(n), [&](const Nat& i) { return prism_rtl::cat("FromPod::from_pod(&a[", i, "])?"); }), Text(", ")), ")");
                        (prism_rtl::cat("Pod::Choice(c, a) if &**c == \"", c.prism, "\" && a.len() == ", n, " => Ok(", made, "),"));
                    });
                });
                (rust_templates::from_pod_body(lexer::join(arms_, Text("\n")), prism_rtl::cat("a ", t.prism)));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(rust_templates::impl_(bounded(t.params, Text("FromPod")), Text("FromPod"), head, Text("fn from_pod(p: &Pod) -> Result<Self, Fault>"), body));
}


/// `Start FromPodImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_from_pod_impl(lower::TyDef t, Text head) {
    return std::make_shared<FromPodImpl>(t, head);
}


/// RustTag: unbounded fn TagDef -> Text
Text rust_tag(const lower::TagDef& t) {
    auto fields = lexer::join(run_to_end(each_job(t.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _f = p0;
                auto&& f = std::get<1>(_f);
                auto&& ft = std::get<2>(_f);
                call_then(start_type_(ft), [=](Text type__22336) { return prism_rtl::finished(prism_rtl::cat("pub ", f, ": ", type__22336, ",")); });
            });
        }));
    })))), Text("\n"));
    auto pods = lexer::join(each(t.fields, [&](const std::tuple<Text, Text, lower::OutTy>& _p0) {
        auto&& p_ = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        return prism_rtl::cat("(\"", p_, "\", self.", f, ".to_pod())");
    }), Text(", "));
    auto derives = t.pod ? Text("Clone, PartialEq") : Text("Clone");
    auto reads = lexer::join(each(t.fields, [&](const std::tuple<Text, Text, lower::OutTy>& _p0) {
        auto&& p_ = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        return prism_rtl::cat(f, ": FromPod::from_pod(field(p, \"", p_, "\")?)?");
    }), Text(", "));
    auto back = t.pod
        ? prism_rtl::cat("\n", rust_templates::tag_from_pod(t.name, t.tag_name, reads))
        : Text("");
    return prism_rtl::cat(rust_templates::tag(rust_templates::source_doc(prism_rtl::cat("The `Level` of `", t.tag_name, "`:"), t.doc), derives, t.name, fields, t.tag_name, pods), back);
}


prism_rtl::Turn<Text> RustTag::cycle() const {
    const auto& t = this->t;
    auto t_1 = t;
    return call_value(each_job(t_1.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _f = p0;
                auto&& f = std::get<1>(_f);
                auto&& ft = std::get<2>(_f);
                call_then(start_type_(ft), [=](Text type__22336) { return prism_rtl::finished(prism_rtl::cat("pub ", f, ": ", type__22336, ",")); });
            });
        }));
    }))), [=](Array<Text> each_22289) {
        return ({
            auto fields = lexer::join(each_22289, Text("\n"));
            auto pods = lexer::join(each(t_1.fields, [&](const std::tuple<Text, Text, lower::OutTy>& _p0) {
                auto&& p_ = std::get<0>(_p0);
                auto&& f = std::get<1>(_p0);
                return prism_rtl::cat("(\"", p_, "\", self.", f, ".to_pod())");
            }), Text(", "));
            auto derives = t_1.pod ? Text("Clone, PartialEq") : Text("Clone");
            auto reads = lexer::join(each(t_1.fields, [&](const std::tuple<Text, Text, lower::OutTy>& _p0) {
                auto&& p_ = std::get<0>(_p0);
                auto&& f = std::get<1>(_p0);
                return prism_rtl::cat(f, ": FromPod::from_pod(field(p, \"", p_, "\")?)?");
            }), Text(", "));
            auto back = t_1.pod
                ? prism_rtl::cat("\n", rust_templates::tag_from_pod(t_1.name, t_1.tag_name, reads))
                : Text("");
            (prism_rtl::finished(prism_rtl::cat(rust_templates::tag(rust_templates::source_doc(prism_rtl::cat("The `Level` of `", t_1.tag_name, "`:"), t_1.doc), derives, t_1.name, fields, t_1.tag_name, pods), back)));
        });
    });
}


/// `Start RustTag, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_tag(lower::TagDef t) {
    return std::make_shared<RustTag>(t);
}


/// RustRow: unbounded fn RowDef -> Text
Text rust_row(const lower::RowDef& r) {
    auto derives = r.pod ? Text("Clone, PartialEq") : Text("Clone");
    auto cases = lexer::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat(v_, "(", st, "),");
    }), Text("\n"));
    auto pods = lexer::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        return prism_rtl::cat(r.name, "::", v_, "(x) => x.to_pod(),");
    }), Text("\n"));
    auto reads = lexer::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat("Some(t) if t == ", st, "::TAG => Ok(", r.name, "::", v_, "(FromPod::from_pod(p)?)),");
    }), Text("\n"));
    auto back = r.pod
        ? prism_rtl::cat("\n", rust_templates::row_from_pod(r.name, reads))
        : Text("");
    auto pods2 = len(r.cases_) == Nat(0u) ? Text("_ => unreachable!(),") : pods;
    return prism_rtl::cat(rust_templates::row(rust_templates::source_doc(prism_rtl::cat("`", r.prism, "`, a row kind's values:"), r.doc), derives, r.name, cases, pods2), back);
}


prism_rtl::Turn<Text> RustRow::cycle() const {
    const auto& r = this->r;
    auto derives = r.pod ? Text("Clone, PartialEq") : Text("Clone");
    auto cases = lexer::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat(v_, "(", st, "),");
    }), Text("\n"));
    auto pods = lexer::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        return prism_rtl::cat(r.name, "::", v_, "(x) => x.to_pod(),");
    }), Text("\n"));
    auto reads = lexer::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat("Some(t) if t == ", st, "::TAG => Ok(", r.name, "::", v_, "(FromPod::from_pod(p)?)),");
    }), Text("\n"));
    auto back = r.pod
        ? prism_rtl::cat("\n", rust_templates::row_from_pod(r.name, reads))
        : Text("");
    auto pods2 = len(r.cases_) == Nat(0u) ? Text("_ => unreachable!(),") : pods;
    return prism_rtl::finished(prism_rtl::cat(rust_templates::row(rust_templates::source_doc(prism_rtl::cat("`", r.prism, "`, a row kind's values:"), r.doc), derives, r.name, cases, pods2), back));
}


/// `Start RustRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_row(lower::RowDef r) {
    return std::make_shared<RustRow>(r);
}


/// RustAnswer: unbounded fn AnswerDef -> Text
Text rust_answer(const lower::AnswerDef& a) {
    auto cases = lexer::join(run_to_end(each_job(a.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::AnswerCase)>>(prism_rtl::rc([=](lower::AnswerCase p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(start_type_(c.ty), [=](Text type__23993) { return prism_rtl::finished(prism_rtl::cat(c.variant, "(", type__23993, "),")); });
            });
        }));
    })))), Text("\n"));
    auto tags = len(a.cases_) == Nat(0u)
        ? Text("_ => unreachable!(),")
        : lexer::join(each(a.cases_, [&](const lower::AnswerCase& c) { return prism_rtl::cat("Answer::", c.variant, "(_) => ", c.struct_path, "::TAG,"); }), Text("\n"));
    auto accessors = lexer::join(run_to_end(each_job(a.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::AnswerCase)>>(prism_rtl::rc([=](lower::AnswerCase p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(start_type_(c.ty), [=](Text type__24255) { return prism_rtl::finished(rust_templates::answer_getter(c.accessor, c.variant, c.tag_name, type__24255)); });
            });
        }));
    })))), Text("\n"));
    auto decodes = len(a.cases_) == Nat(0u)
        ? Text("_ => unreachable!(),")
        : lexer::join(run_to_end(each_job(a.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::AnswerCase)>>(prism_rtl::rc([=](lower::AnswerCase p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(start_decode_head(c.ty), [=](Text decode_head_24418) { return prism_rtl::finished(prism_rtl::cat("Elem::", c.variant, "(..) => Ok(Answer::", c.variant, "(", decode_head_24418, "::from_pod(v)?)),")); });
            });
        }));
    })))), Text("\n"));
    return rust_templates::answer_type(cases, tags, accessors, decodes);
}


prism_rtl::Turn<Text> RustAnswer::cycle() const {
    const auto& a = this->a;
    auto a_1 = a;
    return call_value(each_job(a_1.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::AnswerCase)>>(prism_rtl::rc([=](lower::AnswerCase p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(start_type_(c.ty), [=](Text type__23993) { return prism_rtl::finished(prism_rtl::cat(c.variant, "(", type__23993, "),")); });
            });
        }));
    }))), [=](Array<Text> each_23960) {
        return ({
            auto cases = lexer::join(each_23960, Text("\n"));
            auto tags = len(a_1.cases_) == Nat(0u)
                ? Text("_ => unreachable!(),")
                : lexer::join(each(a_1.cases_, [&](const lower::AnswerCase& c) { return prism_rtl::cat("Answer::", c.variant, "(_) => ", c.struct_path, "::TAG,"); }), Text("\n"));
            call_value(each_job(a_1.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::AnswerCase)>>(prism_rtl::rc([=](lower::AnswerCase p0) {
            return entered(once_job([=]() {
                return ({
                    auto c = p0;
                    call_then(start_type_(c.ty), [=](Text type__24255) { return prism_rtl::finished(rust_templates::answer_getter(c.accessor, c.variant, c.tag_name, type__24255)); });
                });
            }));
        }))), [=](Array<Text> each_24188) {
            return ({
                auto accessors = lexer::join(each_24188, Text("\n"));
                auto decodes = len(a_1.cases_) == Nat(0u)
                    ? Text("_ => unreachable!(),")
                    : lexer::join(run_to_end(each_job(a_1.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::AnswerCase)>>(prism_rtl::rc([=](lower::AnswerCase p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            call_then(start_decode_head(c.ty), [=](Text decode_head_24418) { return prism_rtl::finished(prism_rtl::cat("Elem::", c.variant, "(..) => Ok(Answer::", c.variant, "(", decode_head_24418, "::from_pod(v)?)),")); });
                        });
                    }));
                })))), Text("\n"));
                (prism_rtl::finished(rust_templates::answer_type(cases, tags, accessors, decodes)));
            });
        });
        });
    });
}


/// `Start RustAnswer, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_answer(lower::AnswerDef a) {
    return std::make_shared<RustAnswer>(a);
}


/// RustNode: unbounded fn NodeDef -> Text
Text rust_node(const lower::NodeDef& n) {
    auto fields = lexer::join(run_to_end(each_job(n.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy, Text>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy, Text> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f, t, doc] = p0;
                call_then(start_type_(t), [=](Text type__24835) { return prism_rtl::finished(prism_rtl::cat(rust_templates::doc(doc), f, ": ", type__24835, ",")); });
            });
        }));
    })))), Text("\n"));
    auto consts = concat(each(n.consts, [&](const std::tuple<Text, Nat, Text>& _p0) {
        auto&& c = std::get<0>(_p0);
        auto&& h = std::get<1>(_p0);
        auto&& doc = std::get<2>(_p0);
        return prism_rtl::cat(rust_templates::doc(prism_rtl::cat("The ", doc, ".")), "const ", c, ": u32 = ", h, ";\n");
    }));
    auto params = concat(run_to_end(each_job(n.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [p_, t] = p0;
                call_then(start_type_(t), [=](Text type__25013) { return prism_rtl::finished(prism_rtl::cat(p_, ": ", type__25013, ", ")); });
            });
        }));
    })))));
    auto ret = n.fallible
        ? prism_rtl::cat("Result<Rc<", n.name, ">, Fault>")
        : prism_rtl::cat("Rc<", n.name, ">");
    auto inits = lexer::join(append(Array(std::vector{Text("path")}), run_to_end(each_job(n.inits, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Ex> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f, v_] = p0;
                (prism_rtl::more(prism_rtl::rc(FieldInit(f, v_))));
            });
        }));
    }))))), Text(", "));
    auto tail = n.fallible ? Text("Ok(node)") : Text("node");
    auto rest_text = len(n->build) == Nat(0u)
        ? tail
        : prism_rtl::cat(statements(n->build), "\n", tail);
    auto build_1 = rust_templates::build(n.name, params, ret, statements(n.lets), inits, rest_text);
    auto methods = lexer::join(run_to_end(each_job(n.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::MethDef)>>(prism_rtl::rc([=](lower::MethDef p0) {
        return entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(RustMethod(m))));
            });
        }));
    })))), Text("\n"));
    auto answer_2 = len(n.answers) == Nat(0u)
        ? Text("")
        : rust_templates::answer(lexer::join(run_to_end(each_job(n.answers, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<lower::Pa, lower::Ex>)>>(prism_rtl::rc([=](std::tuple<lower::Pa, lower::Ex> p0) {
        return entered(once_job([=]() {
            return ({
                auto [pat, call] = p0;
                call_then(start_pattern(pat), [=](Text pattern_25579) { return call_then(start_expression(call), [=](Text expression_25596) { return prism_rtl::finished(prism_rtl::cat(pattern_25579, " => ", expression_25596, ",")); }); });
            });
        }));
    })))), Text("\n")));
    auto builders = concat(append(run_to_end(each_job(n.builders, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::ForDef)>>(prism_rtl::rc([=](lower::ForDef p0) {
        return entered(once_job([=]() {
            return ({
                auto b = p0;
                call_then(start_for_builder(b), [=](Text for_builder_25684) { return prism_rtl::finished(prism_rtl::cat("\n", for_builder_25684)); });
            });
        }));
    })))), run_to_end(each_job(n.gens, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::GenDef)>>(prism_rtl::rc([=](lower::GenDef p0) {
        return entered(once_job([=]() {
            return ({
                auto gd = p0;
                call_then(start_gen_builder(gd), [=](Text gen_builder_25725) { return prism_rtl::finished(prism_rtl::cat("\n", gen_builder_25725)); });
            });
        }));
    }))))));
    auto row_impl = n.row_kind == lower::RowKind(lower::RowKind::NotARow{})
        ? Text("")
        : prism_rtl::cat("\n", rust_row_impl(n));
    auto hooks = lexer::join(run_to_end(each_job(n.hooks, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<lower::Do>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<lower::Do>> p0) {
        return entered(once_job([=]() {
            return ({
                auto [h, body] = p0;
                h == Text("push")
                ? call_then(start_statements(body), [=](Text statements_25892) { return prism_rtl::finished(rust_templates::push_hook(statements_25892)); })
                : call_then(start_statements(body), [=](Text statements_25924) { return prism_rtl::finished(rust_templates::hook(h, statements_25924)); });
            });
        }));
    })))), Text("\n"));
    auto doc = rust_templates::source_doc(prism_rtl::cat("`", n.prism, "`: a node of its own (docs/backend.md, \"A widget block\")."), n.doc);
    return prism_rtl::cat(rust_templates::node_(doc, n.name, fields, consts, build_1, prism_rtl::cat(methods, builders), hooks, answer_2), row_impl);
}


prism_rtl::Turn<Text> RustNode::cycle() const {
    const auto& n = this->n;
    auto n_1 = n;
    return call_value(each_job(n_1.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy, Text>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy, Text> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f, t, doc] = p0;
                call_then(start_type_(t), [=](Text type__24835) { return prism_rtl::finished(prism_rtl::cat(rust_templates::doc(doc), f, ": ", type__24835, ",")); });
            });
        }));
    }))), [=](Array<Text> each_24787) {
        return ({
            auto fields = lexer::join(each_24787, Text("\n"));
            auto consts = concat(each(n_1.consts, [&](const std::tuple<Text, Nat, Text>& _p0) {
                auto&& c = std::get<0>(_p0);
                auto&& h = std::get<1>(_p0);
                auto&& doc = std::get<2>(_p0);
                return prism_rtl::cat(rust_templates::doc(prism_rtl::cat("The ", doc, ".")), "const ", c, ": u32 = ", h, ";\n");
            }));
            call_value(each_job(n_1.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [p_, t] = p0;
                    call_then(start_type_(t), [=](Text type__25013) { return prism_rtl::finished(prism_rtl::cat(p_, ": ", type__25013, ", ")); });
                });
            }));
        }))), [=](Array<Text> each_24979) {
            return ({
                auto params = concat(each_24979);
                auto ret = n_1.fallible
                    ? prism_rtl::cat("Result<Rc<", n_1.name, ">, Fault>")
                    : prism_rtl::cat("Rc<", n_1.name, ">");
                call_value(each_job(n_1.inits, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Ex> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto [f, v_] = p0;
                        (prism_rtl::more(prism_rtl::rc(FieldInit(f, v_))));
                    });
                }));
            }))), [=](Array<Text> each_25147) {
                return ({
                    auto inits = lexer::join(append(Array(std::vector{Text("path")}), each_25147), Text(", "));
                    auto tail = n_1.fallible ? Text("Ok(node)") : Text("node");
                    auto rest_text = len(n_1->build) == Nat(0u)
                        ? tail
                        : prism_rtl::cat(statements(n_1->build), "\n", tail);
                    call_then(start_statements(n_1.lets), [=](Text statements_25378) {
                    return ({
                        auto build_2 = rust_templates::build(n_1.name, params, ret, statements_25378, inits, rest_text);
                        call_value(each_job(n_1.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::MethDef)>>(prism_rtl::rc([=](lower::MethDef p0) {
                        return entered(once_job([=]() {
                            return ({
                                auto m = p0;
                                (prism_rtl::more(prism_rtl::rc(RustMethod(m))));
                            });
                        }));
                    }))), [=](Array<Text> each_25438) {
                        return ({
                            auto methods = lexer::join(each_25438, Text("\n"));
                            auto answer_3 = len(n_1.answers) == Nat(0u)
                                ? Text("")
                                : rust_templates::answer(lexer::join(run_to_end(each_job(n_1.answers, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<lower::Pa, lower::Ex>)>>(prism_rtl::rc([=](std::tuple<lower::Pa, lower::Ex> p0) {
                                return entered(once_job([=]() {
                                    return ({
                                        auto [pat, call] = p0;
                                        call_then(start_pattern(pat), [=](Text pattern_25579) { return call_then(start_expression(call), [=](Text expression_25596) { return prism_rtl::finished(prism_rtl::cat(pattern_25579, " => ", expression_25596, ",")); }); });
                                    });
                                }));
                            })))), Text("\n")));
                            call_value(each_job(n_1.builders, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::ForDef)>>(prism_rtl::rc([=](lower::ForDef p0) {
                            return entered(once_job([=]() {
                                return ({
                                    auto b = p0;
                                    call_then(start_for_builder(b), [=](Text for_builder_25684) { return prism_rtl::finished(prism_rtl::cat("\n", for_builder_25684)); });
                                });
                            }));
                        }))), [=](Array<Text> each_25658) {
                            return call_value(each_job(n_1.gens, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::GenDef)>>(prism_rtl::rc([=](lower::GenDef p0) {
                                return entered(once_job([=]() {
                                    return ({
                                        auto gd = p0;
                                        call_then(start_gen_builder(gd), [=](Text gen_builder_25725) { return prism_rtl::finished(prism_rtl::cat("\n", gen_builder_25725)); });
                                    });
                                }));
                            }))), [=](Array<Text> each_25702) {
                                return ({
                                    auto builders = concat(append(each_25658, each_25702));
                                    auto row_impl = n_1.row_kind == lower::RowKind(lower::RowKind::NotARow{})
                                        ? Text("")
                                        : prism_rtl::cat("\n", rust_row_impl(n_1));
                                    call_value(each_job(n_1.hooks, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<lower::Do>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<lower::Do>> p0) {
                                    return entered(once_job([=]() {
                                        return ({
                                            auto [h, body] = p0;
                                            h == Text("push")
                                            ? call_then(start_statements(body), [=](Text statements_25892) { return prism_rtl::finished(rust_templates::push_hook(statements_25892)); })
                                            : call_then(start_statements(body), [=](Text statements_25924) { return prism_rtl::finished(rust_templates::hook(h, statements_25924)); });
                                        });
                                    }));
                                }))), [=](Array<Text> each_25837) {
                                    return ({
                                        auto hooks = lexer::join(each_25837, Text("\n"));
                                        auto doc = rust_templates::source_doc(prism_rtl::cat("`", n_1.prism, "`: a node of its own (docs/backend.md, \"A widget block\")."), n_1.doc);
                                        (prism_rtl::finished(prism_rtl::cat(rust_templates::node_(doc, n_1.name, fields, consts, build_2, prism_rtl::cat(methods, builders), hooks, answer_3), row_impl)));
                                    });
                                });
                                });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start RustNode, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_node(lower::NodeDef n) {
    return std::make_shared<RustNode>(n);
}


/// ForBuilder: unbounded fn ForDef -> Text
Text for_builder(const lower::ForDef& b) {
    return rust_templates::for_build(b.name, expression(b.at), type_(b.key_ty), type_(b.value_ty), b.row_node, b->source, expression(b->parent), concat(run_to_end(each_job(b.passed, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
        return entered(once_job([=]() {
            return ({
                auto x = p0;
                call_then(start_expression(x), [=](Text expression_26415) { return prism_rtl::finished(prism_rtl::cat(", ", expression_26415)); });
            });
        }));
    }))))));
}


prism_rtl::Turn<Text> ForBuilder::cycle() const {
    const auto& b = this->b;
    auto b_1 = b;
    return call_then(start_expression(b_1.at), [=](Text expression_26286) {
        return call_then(start_type_(b_1.key_ty), [=](Text type__26305) {
            return call_then(start_type_(b_1.value_ty), [=](Text type__26321) {
                return call_then(start_expression(b_1->parent), [=](Text expression_26360) {
                    return call_value(each_job(b_1.passed, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
                        return entered(once_job([=]() {
                            return ({
                                auto x = p0;
                                call_then(start_expression(x), [=](Text expression_26415) { return prism_rtl::finished(prism_rtl::cat(", ", expression_26415)); });
                            });
                        }));
                    }))), [=](Array<Text> each_26391) { return prism_rtl::finished(rust_templates::for_build(b_1.name, expression_26286, type__26305, type__26321, b_1.row_node, b_1->source, expression_26360, concat(each_26391))); });
                });
            });
        });
    });
}


/// `Start ForBuilder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_for_builder(lower::ForDef b) {
    return std::make_shared<ForBuilder>(b);
}


/// GenBuilder: unbounded fn GenDef -> Text
Text gen_builder(const lower::GenDef& gd) {
    auto path_ = gd.transparent
        ? Text("self.path.clone()")
        : prism_rtl::cat(expression(gd.at), ".child(Segment::Gen(g))");
    return rust_templates::gen_build(gd.name, expression(gd.at), path_, expression(gd->source), type_(gd.value_ty), expression(gd.select));
}


prism_rtl::Turn<Text> GenBuilder::cycle() const {
    const auto& gd = this->gd;
    auto path_ = gd.transparent
        ? Text("self.path.clone()")
        : prism_rtl::cat(expression(gd.at), ".child(Segment::Gen(g))");
    auto gd_1 = gd;
    return call_then(start_expression(gd_1.at), [=](Text expression_26809) { return call_then(start_expression(gd_1->source), [=](Text expression_26835) { return call_then(start_type_(gd_1.value_ty), [=](Text type__26859) { return call_then(start_expression(gd_1.select), [=](Text expression_26878) { return prism_rtl::finished(rust_templates::gen_build(gd_1.name, expression_26809, path_, expression_26835, type__26859, expression_26878)); }); }); }); });
}


/// `Start GenBuilder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_gen_builder(lower::GenDef gd) {
    return std::make_shared<GenBuilder>(gd);
}


/// RustRowImpl: unbounded fn NodeDef -> Text
Text rust_row_impl(const lower::NodeDef& n) {
    auto kept = n.row_kind == lower::RowKind(lower::RowKind::ForRow{})
        ? Array(std::vector{Text("*self.left_entry.borrow_mut() = Some(self.entry(cx));")})
        : Array<Text>{};
    auto unsubscribe = each(n.subs, [&](const std::tuple<Text, Text, lower::OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        return prism_rtl::cat("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.", m, "_sub.take()) {\n    p.", ev, "_port.unsubscribe(h);\n}");
    });
    return rust_templates::row_impl(n.name, lexer::join(append(prelude::push(kept, Text("self.remove_places(cx);")), unsubscribe), Text("\n")), lexer::join(run_to_end(each_job(n.hosted, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::MethDef)>>(prism_rtl::rc([=](lower::MethDef p0) {
        return entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(RustMethod(m))));
            });
        }));
    })))), Text("\n")));
}


prism_rtl::Turn<Text> RustRowImpl::cycle() const {
    const auto& n = this->n;
    auto kept = n.row_kind == lower::RowKind(lower::RowKind::ForRow{})
        ? Array(std::vector{Text("*self.left_entry.borrow_mut() = Some(self.entry(cx));")})
        : Array<Text>{};
    auto unsubscribe = each(n.subs, [&](const std::tuple<Text, Text, lower::OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        return prism_rtl::cat("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.", m, "_sub.take()) {\n    p.", ev, "_port.unsubscribe(h);\n}");
    });
    auto n_1 = n;
    return call_value(each_job(n_1.hosted, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::MethDef)>>(prism_rtl::rc([=](lower::MethDef p0) {
        return entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(RustMethod(m))));
            });
        }));
    }))), [=](Array<Text> each_27576) { return prism_rtl::finished(rust_templates::row_impl(n_1.name, lexer::join(append(prelude::push(kept, Text("self.remove_places(cx);")), unsubscribe), Text("\n")), lexer::join(each_27576, Text("\n")))); });
}


/// `Start RustRowImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_row_impl(lower::NodeDef n) {
    return std::make_shared<RustRowImpl>(n);
}


/// RustMethod: unbounded fn MethDef -> Text
Text rust_method(const lower::MethDef& m) {
    auto recv = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.recv;
        if (prism_rtl::is<lower::Recv::RecvRc>(_m)) {
            _v.set(Text("self: &Rc<Self>"));
            goto _done;
        }
        if (prism_rtl::is<lower::Recv::RecvRef>(_m)) {
            _v.set(Text("&self"));
            goto _done;
        }
        if (prism_rtl::is<lower::Recv::RecvOwned>(_m)) {
            _v.set(Text("self: Rc<Self>"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cx_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.cx_;
        if (prism_rtl::is<lower::CxArg::CxMut>(_m)) {
            _v.set(Text(", cx: &mut Cx"));
            goto _done;
        }
        if (prism_rtl::is<lower::CxArg::CxRef>(_m)) {
            _v.set(Text(", cx: &Cx"));
            goto _done;
        }
        if (prism_rtl::is<lower::CxArg::CxNone>(_m)) {
            _v.set(Text(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto params = concat(run_to_end(each_job(m.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [p_, t] = p0;
                call_then(start_type_(t), [=](Text type__27963) { return prism_rtl::finished(prism_rtl::cat(", ", p_, ": ", type__27963)); });
            });
        }));
    })))));
    auto ret = m.ret == lower::OutTy(lower::OutTy::OutUnit{})
        ? Text("")
        : prism_rtl::cat(" -> ", type_(m.ret));
    auto sig = prism_rtl::cat("fn ", m.name, "(", recv, params, cx_, ")", ret);
    auto body = m.ret == lower::OutTy(lower::OutTy::OutUnit{})
        ? statements(m.body)
        : len(m.body) == Nat(0u)
        ? body_lines(m.tail)
        : prism_rtl::cat(statements(m.body), "\n", body_lines(m.tail));
    return rust_templates::method(rust_templates::doc(m.doc), sig, body);
}


prism_rtl::Turn<Text> RustMethod::cycle() const {
    const auto& m = this->m;
    auto recv = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.recv;
        if (prism_rtl::is<lower::Recv::RecvRc>(_m)) {
            _v.set(Text("self: &Rc<Self>"));
            goto _done;
        }
        if (prism_rtl::is<lower::Recv::RecvRef>(_m)) {
            _v.set(Text("&self"));
            goto _done;
        }
        if (prism_rtl::is<lower::Recv::RecvOwned>(_m)) {
            _v.set(Text("self: Rc<Self>"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cx_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.cx_;
        if (prism_rtl::is<lower::CxArg::CxMut>(_m)) {
            _v.set(Text(", cx: &mut Cx"));
            goto _done;
        }
        if (prism_rtl::is<lower::CxArg::CxRef>(_m)) {
            _v.set(Text(", cx: &Cx"));
            goto _done;
        }
        if (prism_rtl::is<lower::CxArg::CxNone>(_m)) {
            _v.set(Text(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto m_1 = m;
    return call_value(each_job(m_1.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [p_, t] = p0;
                call_then(start_type_(t), [=](Text type__27963) { return prism_rtl::finished(prism_rtl::cat(", ", p_, ": ", type__27963)); });
            });
        }));
    }))), [=](Array<Text> each_27927) {
        return ({
            auto params = concat(each_27927);
            auto ret = m_1.ret == lower::OutTy(lower::OutTy::OutUnit{})
                ? Text("")
                : prism_rtl::cat(" -> ", type_(m_1.ret));
            auto sig = prism_rtl::cat("fn ", m_1.name, "(", recv, params, cx_, ")", ret);
            auto body = m_1.ret == lower::OutTy(lower::OutTy::OutUnit{})
                ? statements(m_1.body)
                : len(m_1.body) == Nat(0u)
                ? body_lines(m_1.tail)
                : prism_rtl::cat(statements(m_1.body), "\n", body_lines(m_1.tail));
            (prism_rtl::finished(rust_templates::method(rust_templates::doc(m_1.doc), sig, body)));
        });
    });
}


/// `Start RustMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_method(lower::MethDef m) {
    return std::make_shared<RustMethod>(m);
}


/// RustProgram: unbounded fn ProgDef, Bool -> Text
Text rust_program(const lower::ProgDef& p_, const bool& fallible) {
    auto n = len(p_.params);
    auto names = each(p_.params, [&](const std::tuple<Text, lower::OutTy>& _p0) {
        auto&& a = std::get<0>(_p0);
        return a;
    });
    auto decode = n == Nat(0u) ? Text("let _ = args;") : decode_args(p_, names);
    auto call = prism_rtl::cat(p_.node_, "::build(Path::root(), ", concat(each(names, [&](const Text& a) { return prism_rtl::cat(a, ", "); })), "&mut cx)", fallible ? Text("?") : Text(""));
    return rust_templates::program(p_.name, p_.prism, p_.node_, decode, call);
}


prism_rtl::Turn<Text> RustProgram::cycle() const {
    const auto& p_ = this->p_;
    const auto& fallible = this->fallible;
    auto n = len(p_.params);
    auto names = each(p_.params, [&](const std::tuple<Text, lower::OutTy>& _p0) {
        auto&& a = std::get<0>(_p0);
        return a;
    });
    auto decode = n == Nat(0u) ? Text("let _ = args;") : decode_args(p_, names);
    auto call = prism_rtl::cat(p_.node_, "::build(Path::root(), ", concat(each(names, [&](const Text& a) { return prism_rtl::cat(a, ", "); })), "&mut cx)", fallible ? Text("?") : Text(""));
    return prism_rtl::finished(rust_templates::program(p_.name, p_.prism, p_.node_, decode, call));
}


/// `Start RustProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_program(lower::ProgDef p_, bool fallible) {
    return std::make_shared<RustProgram>(p_, fallible);
}


/// DecodeArgs: unbounded fn ProgDef, [Text] -> Text
Text decode_args(const lower::ProgDef& p_, const Array<Text>& names) {
    auto n = len(names);
    auto plural = n == Nat(1u) ? Text("") : Text("s");
    auto head = prism_rtl::cat("let [", lexer::join(names, Text(", ")), "] = args else { return Err(Fault::answer(\"@", p_.prism, " takes ", n, " argument", plural, "\")) };");
    return lexer::join(append(Array(std::vector{head}), run_to_end(each_job(p_.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [a, t] = p0;
                call_then(start_decode_head(t), [=](Text decode_head_28994) { return prism_rtl::finished(prism_rtl::cat("let ", a, " = ", decode_head_28994, "::from_pod(", a, ")?;")); });
            });
        }));
    }))))), Text("\n"));
}


prism_rtl::Turn<Text> DecodeArgs::cycle() const {
    const auto& p_ = this->p_;
    const auto& names = this->names;
    auto n = len(names);
    auto plural = n == Nat(1u) ? Text("") : Text("s");
    auto head = prism_rtl::cat("let [", lexer::join(names, Text(", ")), "] = args else { return Err(Fault::answer(\"@", p_.prism, " takes ", n, " argument", plural, "\")) };");
    auto p__1 = p_;
    return call_value(each_job(p__1.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, lower::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [a, t] = p0;
                call_then(start_decode_head(t), [=](Text decode_head_28994) { return prism_rtl::finished(prism_rtl::cat("let ", a, " = ", decode_head_28994, "::from_pod(", a, ")?;")); });
            });
        }));
    }))), [=](Array<Text> each_28955) { return prism_rtl::finished(lexer::join(append(Array(std::vector{head}), each_28955), Text("\n"))); });
}


/// `Start DecodeArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_decode_args(lower::ProgDef p_, Array<Text> names) {
    return std::make_shared<DecodeArgs>(p_, names);
}


/// RustModule: unbounded fn ModDef -> Text
Text rust_module(const lower::ModDef& m) {
    auto uses = len(m.uses) == Nat(0u)
        ? Text("")
        : prism_rtl::cat("#[allow(unused_imports)]\nuse crate::{", lexer::join(m.uses, Text(", ")), "};");
    return rust_templates::module(m.prism == Text("")
        ? Text("The root module")
        : prism_rtl::cat("The module `", m.prism, "`"), m->path_, uses, lexer::join(run_to_end(each_job(m.items, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Item)>>(prism_rtl::rc([=](lower::Item p0) {
        return entered(once_job([=]() {
            return ({
                auto it = p0;
                (prism_rtl::more(prism_rtl::rc(RustItem(it))));
            });
        }));
    })))), Text("\n")));
}


prism_rtl::Turn<Text> RustModule::cycle() const {
    const auto& m = this->m;
    auto uses = len(m.uses) == Nat(0u)
        ? Text("")
        : prism_rtl::cat("#[allow(unused_imports)]\nuse crate::{", lexer::join(m.uses, Text(", ")), "};");
    auto m_1 = m;
    return call_value(each_job(m_1.items, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Item)>>(prism_rtl::rc([=](lower::Item p0) {
        return entered(once_job([=]() {
            return ({
                auto it = p0;
                (prism_rtl::more(prism_rtl::rc(RustItem(it))));
            });
        }));
    }))), [=](Array<Text> each_29497) {
        return prism_rtl::finished(rust_templates::module(m_1.prism == Text("")
            ? Text("The root module")
            : prism_rtl::cat("The module `", m_1.prism, "`"), m_1->path_, uses, lexer::join(each_29497, Text("\n"))));
    });
}


/// `Start RustModule, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_module(lower::ModDef m) {
    return std::make_shared<RustModule>(m);
}


/// NodeFallible: fn Model, Text -> Bool
bool node_fallible(const lower::Model& model, const Text& path_) {
    return fold(model.mods, false, [&](const bool& f, const lower::ModDef& m) {
        return fold(m.items, f, [&](const bool& f2, const lower::Item& it) {
            return ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                if (prism_rtl::is<lower::Item::ItNode>(it)) {
                    auto&& n = prism_rtl::as<lower::Item::ItNode>(it).a0;
                    _v.set(f2 || ((prism_rtl::cat(m.name, "::", n.name) == path_) && n.fallible));
                    goto _done;
                }
                {
                    _v.set(f2);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
    });
}


/// EmitCrate: unbounded fn Model, Text, [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> emit_crate(const lower::Model& model, const Text& runtime, const Array<Text>& scripts) {
    auto gui = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(r->world == Text("canvas"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cargo_1 = rust_templates::cargo(model.name, runtime, gui ? Text("\"canvas\"") : Text(""));
    auto mods = concat(each(model.mods, [&](const lower::ModDef& m) { return prism_rtl::cat("mod ", m.name, ";\n"); }));
    auto programs = lexer::join(run_to_end(each_job(all_programs(model), ({
        auto model_2 = model;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::ProgDef)>>(prism_rtl::rc([=](lower::ProgDef p0) {
        return ({
            auto model_2_3 = model_2;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(RustProgram(p_, node_fallible(model_2_3, p_.node_)))));
            });
        }));
        });
    })));
    }))), Text("\n"));
    auto regs = concat(each(model.programs, [&](const lower::ProgDef& p_) { return prism_rtl::cat(".program::<", p_.name, ">(\"", p_.prism, "\")\n"); }));
    auto checks = concat(run_to_end(each_job(model.checks, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::CheckDef)>>(prism_rtl::rc([=](lower::CheckDef p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                call_value(each_job(c.lines, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
                return entered(once_job([=]() {
                    return ({
                        auto l = p0;
                        (prism_rtl::more(prism_rtl::rc(Expression(l))));
                    });
                }));
            }))), [=](Array<Text> each_30459) { return prism_rtl::finished(prism_rtl::cat(".check(\"", c.name, "\", || vec![", lexer::join(each_30459, Text(", ")), "])\n")); });
            });
        }));
    })))));
    auto script_list = concat(each(scripts, [&](const Text& s) { return prism_rtl::cat("\"", lower::escape(s), "\",\n"); }));
    auto run_root_2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(rust_templates::run_root(r.name));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(rust_templates::no_root(model.name));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto world = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(r->world);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text("test"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto main_3 = rust_templates::main(model.name, prism_rtl::cat("mod prelude;\n", mods), prism_rtl::cat(rust_row(model.elem), "\n", rust_answer(model->answer), "\n", programs), prism_rtl::cat(regs, checks), script_list, run_root_2, world);
    auto files = run_to_end(each_job(model.mods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(lower::ModDef)>>(prism_rtl::rc([=](lower::ModDef p0) {
        return entered(once_job([=]() {
            return ({
                auto m = p0;
                call_then(start_rust_module(m), [=](Text rust_module_30970) { return prism_rtl::finished(std::tuple{prism_rtl::cat("src/", m.name, ".rs"), rust_module_30970}); });
            });
        }));
    }))));
    return append(Array(std::vector{std::tuple{Text("Cargo.toml"), cargo_1}, std::tuple{Text("src/main.rs"), main_3}, std::tuple{Text("src/prelude.rs"), prelude_template::prelude_source(Text(""))}}), files);
}


prism_rtl::Turn<Array<std::tuple<Text, Text>>> EmitCrate::cycle() const {
    const auto& model = this->model;
    const auto& runtime = this->runtime;
    const auto& scripts = this->scripts;
    auto gui = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(r->world == Text("canvas"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cargo_1 = rust_templates::cargo(model.name, runtime, gui ? Text("\"canvas\"") : Text(""));
    auto mods = concat(each(model.mods, [&](const lower::ModDef& m) { return prism_rtl::cat("mod ", m.name, ";\n"); }));
    auto model_2 = model;
    auto scripts_3 = scripts;
    return call_value(each_job(all_programs(model_2), ({
        auto model_2_4 = model_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::ProgDef)>>(prism_rtl::rc([=](lower::ProgDef p0) {
        return ({
            auto model_2_4_4 = model_2_4;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(RustProgram(p_, node_fallible(model_2_4_4, p_.node_)))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_30201) {
        return ({
            auto programs = lexer::join(each_30201, Text("\n"));
            auto regs = concat(each(model_2.programs, [&](const lower::ProgDef& p_) { return prism_rtl::cat(".program::<", p_.name, ">(\"", p_.prism, "\")\n"); }));
            call_value(each_job(model_2.checks, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::CheckDef)>>(prism_rtl::rc([=](lower::CheckDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto c = p0;
                    call_value(each_job(c.lines, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto l = p0;
                            (prism_rtl::more(prism_rtl::rc(Expression(l))));
                        });
                    }));
                }))), [=](Array<Text> each_30459) { return prism_rtl::finished(prism_rtl::cat(".check(\"", c.name, "\", || vec![", lexer::join(each_30459, Text(", ")), "])\n")); });
                });
            }));
        }))), [=](Array<Text> each_30398) {
            return ({
                auto checks = concat(each_30398);
                auto script_list = concat(each(scripts_3, [&](const Text& s) { return prism_rtl::cat("\"", lower::escape(s), "\",\n"); }));
                auto run_root_4 = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = model_2.root;
                    if (prism_rtl::is_some(_m)) {
                        auto&& r = prism_rtl::some_of(_m);
                        _v.set(rust_templates::run_root(r.name));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(rust_templates::no_root(model_2.name));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto world = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = model_2.root;
                    if (prism_rtl::is_some(_m)) {
                        auto&& r = prism_rtl::some_of(_m);
                        _v.set(r->world);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text("test"));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_rust_row(model_2.elem), [=](Text rust_row_30804) {
                return call_then(start_rust_answer(model_2->answer), [=](Text rust_answer_30826) {
                    return ({
                        auto main_5 = rust_templates::main(model_2.name, prism_rtl::cat("mod prelude;\n", mods), prism_rtl::cat(rust_row_30804, "\n", rust_answer_30826, "\n", programs), prism_rtl::cat(regs, checks), script_list, run_root_4, world);
                        call_value(each_job(model_2.mods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(lower::ModDef)>>(prism_rtl::rc([=](lower::ModDef p0) {
                        return entered(once_job([=]() {
                            return ({
                                auto m = p0;
                                call_then(start_rust_module(m), [=](Text rust_module_30970) { return prism_rtl::finished(std::tuple{prism_rtl::cat("src/", m.name, ".rs"), rust_module_30970}); });
                            });
                        }));
                    }))), [=](Array<std::tuple<Text, Text>> each_30926) {
                        return ({
                            auto files = each_30926;
                            (prism_rtl::finished(append(Array(std::vector{std::tuple{Text("Cargo.toml"), cargo_1}, std::tuple{Text("src/main.rs"), main_5}, std::tuple{Text("src/prelude.rs"), prelude_template::prelude_source(Text(""))}}), files)));
                        });
                    });
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start EmitCrate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_emit_crate(lower::Model model, Text runtime, Array<Text> scripts) {
    return std::make_shared<EmitCrate>(model, runtime, scripts);
}


/// AllPrograms: fn Model -> [ProgDef]
Array<lower::ProgDef> all_programs(const lower::Model& model) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<lower::ProgDef>> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(fold(model.programs, false, [&](const bool& f, const lower::ProgDef& p_) { return f || (p_.name == r.name); })
                ? model.programs
                : prelude::push(model.programs, r));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(model.programs);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}

}  // namespace crate::emit
