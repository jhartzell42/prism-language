// The module `Check.Types.Recording`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/types/recording/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Types.Recording`, from `target/bootstrap/cpp-src/prismc/check/types/recording.prism`.
namespace crate::check::types::recording {

/// AtHere: fn St, Range -> SrcAt
crate::check::typed::SrcAt at_here(const crate::check::types::St& st, const crate::syntax::Range& span) {
    return crate::check::typed::SrcAt{.file = st.file, .span = span};
}


/// NoteTy: fn St, Range, Ty -> St
crate::check::types::St note_ty(const crate::check::types::St& st, const crate::syntax::Range& span, const crate::check::types::Ty& t) {
    return !st.recording
        ? st
        : ({
        crate::check::types::St this_ = st;
        prism_rtl::deref(this_.typed).exprs = crate::prelude::push(prism_rtl::deref(this_.typed).exprs, crate::check::typed::TyNote{.at = at_here(st, span), .ty = t});
        (std::move(this_));
    });
}


/// NoteBinder: fn St, Range, Text, Ty -> St
crate::check::types::St note_binder(const crate::check::types::St& st, const crate::syntax::Range& span, const Text& name, const crate::check::types::Ty& t) {
    return !st.recording
        ? st
        : ({
        crate::check::types::St this_ = st;
        prism_rtl::deref(this_.typed).binders = crate::prelude::push(prism_rtl::deref(this_.typed).binders, crate::check::typed::BinderNote{.at = at_here(st, span), .name = name, .ty = t});
        (std::move(this_));
    });
}


/// NoteGen: fn St, Range, Text, Scheme -> St
crate::check::types::St note_gen(const crate::check::types::St& st, const crate::syntax::Range& span, const Text& name, const crate::check::types::Scheme& sc) {
    return (!st.recording) || ((len(sc.qs) == Nat(0u)) && (len(sc.cqs) == Nat(0u)))
        ? st
        : ({
        crate::check::types::St this_ = st;
        prism_rtl::deref(this_.typed).gens = crate::prelude::push(prism_rtl::deref(this_.typed).gens, crate::check::typed::GenNote{.at = at_here(st, span), .name = name, .tys = sc.qs, .cols = sc.cqs});
        (std::move(this_));
    });
}


/// NoteInst: fn St, Range, Text, Scheme, Inst -> St
crate::check::types::St note_inst(const crate::check::types::St& st, const crate::syntax::Range& span, const Text& name, const crate::check::types::Scheme& sc, const crate::check::types::schemes::Inst& inst) {
    return !st.recording
        ? st
        : ({
        crate::check::types::St this_ = st;
        prism_rtl::deref(this_.typed).insts = crate::prelude::push(prism_rtl::deref(this_.typed).insts, crate::check::typed::InstNote{.at = at_here(st, span), .name = name, .tys = each(sc.qs, [&](const Text& q) { return std::tuple{q, or_(crate::prelude::get(inst.tys, q), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))}; }), .cols = each(sc.cqs, [&](const Text& q) { return std::tuple{q, or_(crate::prelude::get(inst.cols, q), crate::check::types::Col(crate::check::types::Col::CBound{}))}; })});
        (std::move(this_));
    });
}


/// NoteApp: fn St, Range, Text, Text, Text, [Nat], Text, Col -> St
crate::check::types::St note_app(const crate::check::types::St& st, const crate::syntax::Range& span, const Text& callee, const Text& kind, const Text& layer, const Array<Nat>& lifted, const Text& inner, const crate::check::types::Col& col) {
    return !st.recording
        ? st
        : ({
        crate::check::types::St this_ = st;
        prism_rtl::deref(this_.typed).apps = crate::prelude::push(prism_rtl::deref(this_.typed).apps, crate::check::typed::AppNote{.at = at_here(st, span), .callee = callee, .kind = kind, .layer = layer, .lifted = lifted, .inner = inner, .color = col});
        (std::move(this_));
    });
}


/// NoteLift: fn St, Range, Text, [Range] -> St
crate::check::types::St note_lift(const crate::check::types::St& st, const crate::syntax::Range& span, const Text& sigil, const Array<crate::syntax::Range>& operands) {
    return (!st.recording) || (len(operands) == Nat(0u))
        ? st
        : ({
        crate::check::types::St this_ = st;
        prism_rtl::deref(this_.typed).lifts = crate::prelude::push(prism_rtl::deref(this_.typed).lifts, crate::check::typed::LiftNote{.at = at_here(st, span), .sigil = sigil, .operands = operands});
        (std::move(this_));
    });
}


/// NoteFn: fn St, Range, Text, Col, Col -> St
crate::check::types::St note_fn(const crate::check::types::St& st, const crate::syntax::Range& span, const Text& name, const crate::check::types::Col& declared, const crate::check::types::Col& body) {
    return !st.recording
        ? st
        : ({
        crate::check::types::St this_ = st;
        prism_rtl::deref(this_.typed).fns = crate::prelude::push(prism_rtl::deref(this_.typed).fns, crate::check::typed::FnNote{.at = at_here(st, span), .name = name, .declared = declared, .body = body});
        (std::move(this_));
    });
}


/// NoteImpl: fn St, Nat, Range, Text, Ty, Text -> St
crate::check::types::St note_impl(const crate::check::types::St& st, const Nat& file, const crate::syntax::Range& span, const Text& cls, const crate::check::types::Ty& t, const Text& how) {
    return (((!st.recording) || crate::syntax::lexer::chars::has_prefix(cls, Text::lit("Range "))) || (cls == Text::lit("Prelude.Sub"))) || (cls == Text::lit("Prelude.Signed"))
        ? st
        : ({
        crate::check::types::St this_ = st;
        prism_rtl::deref(this_.typed).impls = crate::prelude::push(prism_rtl::deref(this_.typed).impls, crate::check::typed::ImplNote{.at = crate::check::typed::SrcAt{.file = file, .span = span}, .cls = cls, .ty = t, .how = how});
        (std::move(this_));
    });
}


/// NoteChoice: fn St, Nat, Range, Text, Text -> St
crate::check::types::St note_choice(const crate::check::types::St& st, const Nat& file, const crate::syntax::Range& span, const Text& cls, const Text& ch) {
    auto k = choice_key(file, span, cls);
    return (crate::syntax::lexer::chars::has_prefix(cls, Text::lit("Range ")) || (cls == Text::lit("Prelude.Sub"))) || (cls == Text::lit("Prelude.Signed"))
        ? st
        : ({
        crate::check::types::St this_ = st;
        this_.choices = insert(this_.choices, k, crate::check::types::add_text(or_(crate::prelude::get(this_.choices, k), Array<Text>{}), ch));
        (std::move(this_));
    });
}


/// NoteSizeTy: fn St, Range, Ty -> St
crate::check::types::St note_size_ty(const crate::check::types::St& st, const crate::syntax::Range& span, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& _m = index(ps, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            crate::check::types::St this_ = st;
            this_.size_tys = insert(this_.size_tys, prism_rtl::cat(st.file, ":", span.start, ":", span.end), p_);
            return this_;
        }
        if (prism_rtl::is_none(_m)) {
            return st;
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return st;
    }
}


/// ChoiceKey: fn Nat, Range, Text -> Text
Text choice_key(const Nat& file, const crate::syntax::Range& span, const Text& cls) {
    return prism_rtl::cat(file, ":", span.start, ":", span.end, ":", cls);
}


/// NoteMethod: fn St, Range, Text, Text -> St
crate::check::types::St note_method(const crate::check::types::St& st, const crate::syntax::Range& span, const Text& method, const Text& cls) {
    return !st.recording
        ? st
        : ({
        crate::check::types::St this_ = st;
        prism_rtl::deref(this_.typed).methods = crate::prelude::push(prism_rtl::deref(this_.typed).methods, crate::check::typed::MethodNote{.at = at_here(st, span), .method = method, .cls = cls});
        (std::move(this_));
    });
}


/// NoteGroup: fn St, Range, Text, [ [Nat] ] -> St
crate::check::types::St note_group(const crate::check::types::St& st, const crate::syntax::Range& span, const Text& kind, const Array<Array<Nat>>& order) {
    return !st.recording
        ? st
        : ({
        crate::check::types::St this_ = st;
        prism_rtl::deref(this_.typed).groups = crate::prelude::push(prism_rtl::deref(this_.typed).groups, crate::check::typed::GroupNote{.at = at_here(st, span), .kind = kind, .order = order});
        (std::move(this_));
    });
}


/// ZonkTyped: unbounded fn St -> TProgram
crate::check::typed::TProgram zonk_typed(const crate::check::types::St& st) {
    auto t = st.typed;
    crate::check::typed::TProgram this_ = t;
    this_.exprs = run_to_end(each_job(this_.exprs, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::TyNote>(crate::check::typed::TyNote)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](crate::check::typed::TyNote p0) {
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
            return ({
                auto n = p0;
                call_then(start_resolve_ty(st_1_2, prism_rtl::deref(n).ty), [=](crate::check::types::Ty resolve_ty_5437) { return prism_rtl::finished(crate::check::typed::TyNote{.at = prism_rtl::deref(n).at, .ty = resolve_ty_5437}); });
            });
        }));
        });
    })));
    })));
    this_.binders = run_to_end(each_job(this_.binders, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::BinderNote>(crate::check::typed::BinderNote)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](crate::check::typed::BinderNote p0) {
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
            return ({
                auto n = p0;
                call_then(start_resolve_ty(st_1_2, prism_rtl::deref(n).ty), [=](crate::check::types::Ty resolve_ty_5539) { return prism_rtl::finished(crate::check::typed::BinderNote{.at = prism_rtl::deref(n).at, .name = prism_rtl::deref(n).name, .ty = resolve_ty_5539}); });
            });
        }));
        });
    })));
    })));
    this_.insts = run_to_end(each_job(this_.insts, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::InstNote>(crate::check::typed::InstNote)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](crate::check::typed::InstNote p0) {
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
            return ({
                auto n = p0;
                call_value(each_job(prism_rtl::deref(n).tys, ({
                auto st_1_2_2 = st_1_2;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::check::types::Ty>>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_1_2_2 = std::move(st_1_2_2)](std::tuple<Text, crate::check::types::Ty> p0) {
                return ({
                    auto st_1_2_2_2 = st_1_2_2;
                    entered(once_job([=, st_1_2_2_2 = std::move(st_1_2_2_2)]() {
                    return ({
                        auto [q, x] = p0;
                        call_then(start_resolve_ty(st_1_2_2_2, x), [=](crate::check::types::Ty resolve_ty_5666) { return prism_rtl::finished(std::tuple{q, resolve_ty_5666}); });
                    });
                }));
                });
            }));
            })), [=](Array<std::tuple<Text, crate::check::types::Ty>> each_5636) {
                return call_value(each_job(prism_rtl::deref(n).cols, ({
                    auto st_1_2_2 = st_1_2;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::check::types::Col>>(std::tuple<Text, crate::check::types::Col>)>>(prism_rtl::rc([=, st_1_2_2 = std::move(st_1_2_2)](std::tuple<Text, crate::check::types::Col> p0) {
                    return ({
                        auto st_1_2_2_2 = st_1_2_2;
                        entered(once_job([=, st_1_2_2_2 = std::move(st_1_2_2_2)]() {
                        return ({
                            auto [q, c] = p0;
                            call_then(start_resolve_col(st_1_2_2_2, c), [=](crate::check::types::Col resolve_col_5724) { return prism_rtl::finished(std::tuple{q, resolve_col_5724}); });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Text, crate::check::types::Col>> each_5693) { return prism_rtl::finished(crate::check::typed::InstNote{.at = prism_rtl::deref(n).at, .name = prism_rtl::deref(n).name, .tys = each_5636, .cols = each_5693}); });
            });
            });
        }));
        });
    })));
    })));
    this_.impls = run_to_end(each_job(this_.impls, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::ImplNote>(crate::check::typed::ImplNote)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](crate::check::typed::ImplNote p0) {
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
            return ({
                auto n = p0;
                call_then(start_resolve_ty(st_1_2, prism_rtl::deref(n).ty), [=](crate::check::types::Ty resolve_ty_5819) { return prism_rtl::finished(crate::check::typed::ImplNote{.at = prism_rtl::deref(n).at, .cls = prism_rtl::deref(n).cls, .ty = resolve_ty_5819, .how = prism_rtl::deref(n).how}); });
            });
        }));
        });
    })));
    })));
    this_.apps = run_to_end(each_job(this_.apps, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::AppNote>(crate::check::typed::AppNote)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](crate::check::typed::AppNote p0) {
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
            return ({
                auto n = p0;
                call_then(start_resolve_col(st_1_2, prism_rtl::deref(n).color), [=](crate::check::types::Col resolve_col_5990) { return prism_rtl::finished(crate::check::typed::AppNote{.at = prism_rtl::deref(n).at, .callee = prism_rtl::deref(n).callee, .kind = prism_rtl::deref(n).kind, .layer = prism_rtl::deref(n).layer, .lifted = prism_rtl::deref(n).lifted, .inner = prism_rtl::deref(n).inner, .color = resolve_col_5990}); });
            });
        }));
        });
    })));
    })));
    this_.fns = run_to_end(each_job(this_.fns, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::FnNote>(crate::check::typed::FnNote)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](crate::check::typed::FnNote p0) {
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
            return ({
                auto n = p0;
                call_then(start_resolve_col(st_1_2, prism_rtl::deref(n).declared), [=](crate::check::types::Col resolve_col_6090) { return call_then(start_resolve_col(st_1_2, prism_rtl::deref(n).body), [=](crate::check::types::Col resolve_col_6124) { return prism_rtl::finished(crate::check::typed::FnNote{.at = prism_rtl::deref(n).at, .name = prism_rtl::deref(n).name, .declared = resolve_col_6090, .body = resolve_col_6124}); }); });
            });
        }));
        });
    })));
    })));
    return this_;
}


prism_rtl::Turn<crate::check::typed::TProgram> ZonkTyped::cycle() const {
    const auto& st = this->st;
    auto t = prism_rtl::deref(st).typed;
    return prism_rtl::finished(({
        crate::check::typed::TProgram this_ = t;
        this_.exprs = run_to_end(each_job(this_.exprs, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::TyNote>(crate::check::typed::TyNote)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](crate::check::typed::TyNote p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
                return ({
                    auto n = p0;
                    call_then(start_resolve_ty(st_1_2, prism_rtl::deref(n).ty), [=](crate::check::types::Ty resolve_ty_5437) { return prism_rtl::finished(crate::check::typed::TyNote{.at = prism_rtl::deref(n).at, .ty = resolve_ty_5437}); });
                });
            }));
            });
        })));
        })));
        this_.binders = run_to_end(each_job(this_.binders, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::BinderNote>(crate::check::typed::BinderNote)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](crate::check::typed::BinderNote p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
                return ({
                    auto n = p0;
                    call_then(start_resolve_ty(st_1_2, prism_rtl::deref(n).ty), [=](crate::check::types::Ty resolve_ty_5539) { return prism_rtl::finished(crate::check::typed::BinderNote{.at = prism_rtl::deref(n).at, .name = prism_rtl::deref(n).name, .ty = resolve_ty_5539}); });
                });
            }));
            });
        })));
        })));
        this_.insts = run_to_end(each_job(this_.insts, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::InstNote>(crate::check::typed::InstNote)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](crate::check::typed::InstNote p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
                return ({
                    auto n = p0;
                    call_value(each_job(prism_rtl::deref(n).tys, ({
                    auto st_1_2_2 = st_1_2;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::check::types::Ty>>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_1_2_2 = std::move(st_1_2_2)](std::tuple<Text, crate::check::types::Ty> p0) {
                    return ({
                        auto st_1_2_2_2 = st_1_2_2;
                        entered(once_job([=, st_1_2_2_2 = std::move(st_1_2_2_2)]() {
                        return ({
                            auto [q, x] = p0;
                            call_then(start_resolve_ty(st_1_2_2_2, x), [=](crate::check::types::Ty resolve_ty_5666) { return prism_rtl::finished(std::tuple{q, resolve_ty_5666}); });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Text, crate::check::types::Ty>> each_5636) {
                    return call_value(each_job(prism_rtl::deref(n).cols, ({
                        auto st_1_2_2 = st_1_2;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::check::types::Col>>(std::tuple<Text, crate::check::types::Col>)>>(prism_rtl::rc([=, st_1_2_2 = std::move(st_1_2_2)](std::tuple<Text, crate::check::types::Col> p0) {
                        return ({
                            auto st_1_2_2_2 = st_1_2_2;
                            entered(once_job([=, st_1_2_2_2 = std::move(st_1_2_2_2)]() {
                            return ({
                                auto [q, c] = p0;
                                call_then(start_resolve_col(st_1_2_2_2, c), [=](crate::check::types::Col resolve_col_5724) { return prism_rtl::finished(std::tuple{q, resolve_col_5724}); });
                            });
                        }));
                        });
                    }));
                    })), [=](Array<std::tuple<Text, crate::check::types::Col>> each_5693) { return prism_rtl::finished(crate::check::typed::InstNote{.at = prism_rtl::deref(n).at, .name = prism_rtl::deref(n).name, .tys = each_5636, .cols = each_5693}); });
                });
                });
            }));
            });
        })));
        })));
        this_.impls = run_to_end(each_job(this_.impls, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::ImplNote>(crate::check::typed::ImplNote)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](crate::check::typed::ImplNote p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
                return ({
                    auto n = p0;
                    call_then(start_resolve_ty(st_1_2, prism_rtl::deref(n).ty), [=](crate::check::types::Ty resolve_ty_5819) { return prism_rtl::finished(crate::check::typed::ImplNote{.at = prism_rtl::deref(n).at, .cls = prism_rtl::deref(n).cls, .ty = resolve_ty_5819, .how = prism_rtl::deref(n).how}); });
                });
            }));
            });
        })));
        })));
        this_.apps = run_to_end(each_job(this_.apps, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::AppNote>(crate::check::typed::AppNote)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](crate::check::typed::AppNote p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
                return ({
                    auto n = p0;
                    call_then(start_resolve_col(st_1_2, prism_rtl::deref(n).color), [=](crate::check::types::Col resolve_col_5990) { return prism_rtl::finished(crate::check::typed::AppNote{.at = prism_rtl::deref(n).at, .callee = prism_rtl::deref(n).callee, .kind = prism_rtl::deref(n).kind, .layer = prism_rtl::deref(n).layer, .lifted = prism_rtl::deref(n).lifted, .inner = prism_rtl::deref(n).inner, .color = resolve_col_5990}); });
                });
            }));
            });
        })));
        })));
        this_.fns = run_to_end(each_job(this_.fns, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::FnNote>(crate::check::typed::FnNote)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](crate::check::typed::FnNote p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
                return ({
                    auto n = p0;
                    call_then(start_resolve_col(st_1_2, prism_rtl::deref(n).declared), [=](crate::check::types::Col resolve_col_6090) { return call_then(start_resolve_col(st_1_2, prism_rtl::deref(n).body), [=](crate::check::types::Col resolve_col_6124) { return prism_rtl::finished(crate::check::typed::FnNote{.at = prism_rtl::deref(n).at, .name = prism_rtl::deref(n).name, .declared = resolve_col_6090, .body = resolve_col_6124}); }); });
                });
            }));
            });
        })));
        })));
        (std::move(this_));
    }));
}


/// `Start ZonkTyped, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::typed::TProgram> start_zonk_typed(crate::check::types::St st) {
    return prism_rtl::make_rc<ZonkTyped>(st);
}


/// ResolveCol: unbounded fn St, Col -> Col
crate::check::types::Col resolve_col(const crate::check::types::St& st, const crate::check::types::Col& c) {
    auto&& _m = crate::check::types::colors::walk_col(st, c);
    if (prism_rtl::is<crate::check::types::Col::CFlex>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(_m).a0;
        auto&& _m = crate::prelude::get(st.col_q, n);
        if (prism_rtl::is_some(_m)) {
            auto&& q = prism_rtl::some_of(_m);
            return crate::check::types::Col(crate::check::types::Col::CQ{q});
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::Col(crate::check::types::Col::CBound{});
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        auto&& other = _m;
        return other;
    }
}


prism_rtl::Turn<crate::check::types::Col> ResolveCol::cycle() const {
    const auto& st = this->st;
    const auto& c = this->c;
    auto c_1 = c;
    auto st_2 = st;
    return call_then(crate::check::types::colors::start_walk_col(st_2, c_1), [=](crate::check::types::Col walk_col_6359) {
        return ({
            prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_6359) ? ({
            auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_6359).a0;
            ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(st_2).col_q, n);
            prism_rtl::is_some(_m) ? ({
            auto&& q = prism_rtl::some_of(_m);
            prism_rtl::finished(crate::check::types::Col(crate::check::types::Col::CQ{q}));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::Col(crate::check::types::Col::CBound{}))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : ({
            auto&& other = walk_col_6359;
            prism_rtl::finished(other);
        });
        });
    });
}


/// `Start ResolveCol, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Col> start_resolve_col(crate::check::types::St st, crate::check::types::Col c) {
    return prism_rtl::make_rc<ResolveCol>(st, c);
}


/// ResolveTy: unbounded fn St, Ty -> Ty
crate::check::types::Ty resolve_ty(const crate::check::types::St& st, const crate::check::types::Ty& t) {
    return resolve_in(st, zonk(st, t));
}


prism_rtl::Turn<crate::check::types::Ty> ResolveTy::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(start_zonk(st_1, t_2), [=](crate::check::types::Ty zonk_6572) { return prism_rtl::more(prism_rtl::rc(ResolveIn(st_1, zonk_6572))); });
}


/// `Start ResolveTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_resolve_ty(crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<ResolveTy>(st, t);
}


/// ResolveIn: unbounded fn St, Ty -> Ty
crate::check::types::Ty resolve_in(const crate::check::types::St& st, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n, run_to_end(each_job(args, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](crate::check::types::Ty p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(ResolveIn(st_1_2, a))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{resolve_col(st, c), run_to_end(each_job(ps, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](crate::check::types::Ty p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
                return ({
                    auto p_ = p0;
                    (prism_rtl::more(prism_rtl::rc(ResolveIn(st_1_2, p_))));
                });
            }));
            });
        })));
        }))), prism_rtl::rc(resolve_in(st, prism_rtl::deref(prism_rtl::deref(res))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{run_to_end(each_job(ts, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](crate::check::types::Ty p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(ResolveIn(st_1_2, a))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(resolve_in(st, prism_rtl::deref(prism_rtl::deref(e))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(resolve_in(st, prism_rtl::deref(prism_rtl::deref(k)))), prism_rtl::rc(resolve_in(st, prism_rtl::deref(prism_rtl::deref(v_))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s, prism_rtl::rc(resolve_in(st, prism_rtl::deref(prism_rtl::deref(i))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(resolve_in(st, prism_rtl::deref(prism_rtl::deref(i)))), rw});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyElem{rw, prism_rtl::rc(resolve_in(st, prism_rtl::deref(prism_rtl::deref(o))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n, prism_rtl::rc(resolve_in(st, prism_rtl::deref(prism_rtl::deref(a))))});
    }
    {
        auto&& other = t;
        return other;
    }
}


prism_rtl::Turn<crate::check::types::Ty> ResolveIn::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto n_2 = n;
        auto st_3 = st;
        call_value(each_job(args_1, ({
        auto st_3_4 = st_3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_3_4 = std::move(st_3_4)](crate::check::types::Ty p0) {
        return ({
            auto st_3_4_4 = st_3_4;
            entered(once_job([=, st_3_4_4 = std::move(st_3_4_4)]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ResolveIn(st_3_4_4, a))));
            });
        }));
        });
    })));
    })), [=, n_2 = std::move(n_2)](Array<crate::check::types::Ty> each_6681) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_2, each_6681})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? ({
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        ({
        auto c_1 = c;
        auto ps_2 = ps;
        auto res_3 = prism_rtl::deref(prism_rtl::deref(res));
        auto st_4 = st;
        call_then(start_resolve_col(st_4, c_1), [=, ps_2 = std::move(ps_2), res_3 = std::move(res_3)](crate::check::types::Col resolve_col_6741) {
        return call_value(each_job(ps_2, ({
            auto st_4_5 = st_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_4_5 = std::move(st_4_5)](crate::check::types::Ty p0) {
            return ({
                auto st_4_5_5 = st_4_5;
                entered(once_job([=, st_4_5_5 = std::move(st_4_5_5)]() {
                return ({
                    auto p_ = p0;
                    (prism_rtl::more(prism_rtl::rc(ResolveIn(st_4_5_5, p_))));
                });
            }));
            });
        })));
        })), [=](Array<crate::check::types::Ty> each_6761) { return call_then(start_resolve_in(st_4, res_3), [=](crate::check::types::Ty resolve_in_6794) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{resolve_col_6741, each_6761, prism_rtl::rc(resolve_in_6794)})); }); });
    });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        ({
        auto st_1 = st;
        auto ts_2 = ts;
        call_value(each_job(ts_2, ({
        auto st_1_3 = st_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_1_3 = std::move(st_1_3)](crate::check::types::Ty p0) {
        return ({
            auto st_1_3_3 = st_1_3;
            entered(once_job([=, st_1_3_3 = std::move(st_1_3_3)]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ResolveIn(st_1_3_3, a))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_6838) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyTuple{each_6838})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        ({
        auto e_1 = prism_rtl::deref(prism_rtl::deref(e));
        auto st_2 = st;
        call_then(start_resolve_in(st_2, e_1), [=](crate::check::types::Ty resolve_in_6893) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(resolve_in_6893)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = prism_rtl::deref(prism_rtl::deref(k));
        auto st_2 = st;
        auto v__3 = prism_rtl::deref(prism_rtl::deref(v_));
        call_then(start_resolve_in(st_2, k_1), [=, v__3 = std::move(v__3)](crate::check::types::Ty resolve_in_6933) { return call_then(start_resolve_in(st_2, v__3), [=](crate::check::types::Ty resolve_in_6952) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(resolve_in_6933), prism_rtl::rc(resolve_in_6952)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        ({
        auto i_1 = prism_rtl::deref(prism_rtl::deref(i));
        auto s_2 = s;
        auto st_3 = st;
        call_then(start_resolve_in(st_3, i_1), [=, s_2 = std::move(s_2)](crate::check::types::Ty resolve_in_6995) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{s_2, prism_rtl::rc(resolve_in_6995)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a1;
        ({
        auto i_1 = prism_rtl::deref(prism_rtl::deref(i));
        auto rw_2 = rw;
        auto st_3 = st;
        call_then(start_resolve_in(st_3, i_1), [=, rw_2 = std::move(rw_2)](crate::check::types::Ty resolve_in_7034) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(resolve_in_7034), rw_2})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t) ? ({
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        ({
        auto o_1 = prism_rtl::deref(prism_rtl::deref(o));
        auto rw_2 = rw;
        auto st_3 = st;
        call_then(start_resolve_in(st_3, o_1), [=, rw_2 = std::move(rw_2)](crate::check::types::Ty resolve_in_7085) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyElem{rw_2, prism_rtl::rc(resolve_in_7085)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        ({
        auto a_1 = prism_rtl::deref(prism_rtl::deref(a));
        auto n_2 = n;
        auto st_3 = st;
        call_then(start_resolve_in(st_3, a_1), [=, n_2 = std::move(n_2)](crate::check::types::Ty resolve_in_7132) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n_2, prism_rtl::rc(resolve_in_7132)})); });
    });
    })
        : ({
        auto&& other = t;
        prism_rtl::finished(other);
    });
    });
}


/// `Start ResolveIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_resolve_in(crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<ResolveIn>(st, t);
}


/// AtBinder: fn St, Ty, Range -> St
crate::check::types::St at_binder(const crate::check::types::St& st, const crate::check::types::Ty& ty1, const crate::syntax::Range& range2) {
    auto&& _m = std::tuple{ty1, range2};
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<0>(_m))) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<0>(_m)).a0;
        auto&& span = std::get<1>(_m);
        crate::check::types::St this_ = st;
        this_.binder_at = insert(this_.binder_at, n, span);
        return this_;
    }
    {
        return st;
    }
    prism_rtl::unreachable("no arm matched");
}


/// FreshRow: fn St, [Text] -> ((Rw, St))
std::tuple<crate::check::types::Rw, crate::check::types::St> fresh_row(const crate::check::types::St& st, const Array<Text>& lacking) {
    auto n = st.next;
    auto st2 = ({
        crate::check::types::St this_ = st;
        this_.next = this_.next + Nat(1u);
        this_.lacks = insert(this_.lacks, n, lacking);
        (std::move(this_));
    });
    return std::tuple{crate::check::types::Rw{.fams = Array<Text>{}, .minus = Array<Text>{}, .tail = crate::check::types::Tail(crate::check::types::Tail::TlFlex{n})}, st2};
}


/// AddDiag: fn St, CDiag -> St
crate::check::types::St add_diag(const crate::check::types::St& st, const crate::check::errors::CDiag& d) {
    crate::check::types::St this_ = st;
    this_.diags = crate::prelude::push(this_.diags, d);
    return this_;
}


/// Err: fn St, Text, Range, Text -> St
crate::check::types::St err(const crate::check::types::St& st, const Text& code, const crate::syntax::Range& span, const Text& message) {
    return add_diag(st, crate::check::errors::diag0(code, st.file, span, message));
}


/// ErrFix: fn St, Text, Range, Text, Text -> St
crate::check::types::St err_fix(const crate::check::types::St& st, const Text& code, const crate::syntax::Range& span, const Text& message, const Text& fix) {
    return add_diag(st, crate::check::errors::diag_fix(code, st.file, span, message, fix));
}


/// InfoOf: fn St, Nat -> VInfo
crate::check::types::VInfo info_of(const crate::check::types::St& st, const Nat& n) {
    return or_(crate::prelude::get(st.infos, n), crate::check::types::VInfo{.plain = false, .level = Nat(0u), .name = Text::lit("")});
}


/// Walk: unbounded fn St, Ty -> Ty
crate::check::types::Ty walk(const crate::check::types::St& st, const crate::check::types::Ty& ty1) {
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(ty1)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(ty1).a0;
        auto&& _m = crate::prelude::get(st.tys, n);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            return walk(st, t);
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::Ty(crate::check::types::Ty::TyFlex{n});
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        auto&& t = ty1;
        return t;
    }
}


prism_rtl::Turn<crate::check::types::Ty> Walk::cycle() const {
    const auto& st = this->st;
    const auto& ty1 = this->ty1;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFlex>(ty1) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(ty1).a0;
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(st).tys, n);
        prism_rtl::is_some(_m) ? ({
        auto&& t = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(Walk(st, t)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFlex{n}))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : ({
        auto&& t = ty1;
        prism_rtl::finished(t);
    });
    });
}


/// `Start Walk, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_walk(crate::check::types::St st, crate::check::types::Ty ty1) {
    return prism_rtl::make_rc<Walk>(st, ty1);
}


/// WalkRow: unbounded fn St, Rw -> Rw
crate::check::types::Rw walk_row(const crate::check::types::St& st, const crate::check::types::Rw& r) {
    auto&& _m = r.tail;
    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
        auto&& _m = crate::prelude::get(st.rows, n);
        if (prism_rtl::is_some(_m)) {
            auto&& r2 = prism_rtl::some_of(_m);
            auto w = walk_row(st, r2);
            return crate::check::types::Rw{.fams = crate::check::types::sort_texts(crate::check::types::union_texts(r.fams, prism_rtl::deref(w).fams)), .minus = crate::check::types::union_texts(r.minus, prism_rtl::deref(w).minus), .tail = prism_rtl::deref(w).tail};
        }
        if (prism_rtl::is_none(_m)) {
            return r;
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return r;
    }
}


prism_rtl::Turn<crate::check::types::Rw> WalkRow::cycle() const {
    const auto& st = this->st;
    const auto& r = this->r;
    return ({
        auto&& _m = prism_rtl::deref(r).tail;
        prism_rtl::is<crate::check::types::Tail::TlFlex>(_m) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
        ({
        auto&& _m = crate::prelude::get(st->rows, n);
        prism_rtl::is_some(_m) ? ({
        auto&& r2 = prism_rtl::some_of(_m);
        ({
        auto r_1 = r;
        auto st_2 = st;
        call_then(start_walk_row(st_2, r2), [=, r_1 = std::move(r_1)](crate::check::types::Rw walk_row_8499) {
        return ({
            auto w = walk_row_8499;
            (prism_rtl::finished(crate::check::types::Rw{.fams = crate::check::types::sort_texts(crate::check::types::union_texts(prism_rtl::deref(r_1).fams, prism_rtl::deref(w).fams)), .minus = crate::check::types::union_texts(prism_rtl::deref(r_1).minus, prism_rtl::deref(w).minus), .tail = prism_rtl::deref(w).tail}));
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(r)
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(r);
    });
}


/// `Start WalkRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Rw> start_walk_row(crate::check::types::St st, crate::check::types::Rw r) {
    return prism_rtl::make_rc<WalkRow>(st, r);
}


/// Zonk: unbounded fn St, Ty -> Ty
crate::check::types::Ty zonk(const crate::check::types::St& st, const crate::check::types::Ty& t) {
    auto&& _m = crate::check::types::unify::norm_assoc(st, walk(st, t));
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n, run_to_end(each_job(args, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](crate::check::types::Ty p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(Zonk(st_1_2, a))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::colors::walk_col(st, c), run_to_end(each_job(ps, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](crate::check::types::Ty p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
                return ({
                    auto p_ = p0;
                    (prism_rtl::more(prism_rtl::rc(Zonk(st_1_2, p_))));
                });
            }));
            });
        })));
        }))), prism_rtl::rc(zonk(st, prism_rtl::deref(res)))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{run_to_end(each_job(ts, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](crate::check::types::Ty p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(Zonk(st_1_2, a))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(zonk(st, prism_rtl::deref(e)))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(zonk(st, prism_rtl::deref(k))), prism_rtl::rc(zonk(st, prism_rtl::deref(v_)))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s, prism_rtl::rc(zonk(st, prism_rtl::deref(i)))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(zonk(st, prism_rtl::deref(i))), walk_row(st, rw)});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyElem{walk_row(st, rw), prism_rtl::rc(zonk(st, prism_rtl::deref(o)))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElemAny>(_m).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyElemAny{walk_row(st, rw)});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyAssoc>(_m).a0;
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(_m).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n, prism_rtl::rc(zonk(st, prism_rtl::deref(a)))});
    }
    {
        auto&& w = _m;
        return w;
    }
}


prism_rtl::Turn<crate::check::types::Ty> Zonk::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(start_walk(st_1, t_2), [=](crate::check::types::Ty walk_8790) {
        return call_then(crate::check::types::unify::start_norm_assoc(st_1, walk_8790), [=](crate::check::types::Ty norm_assoc_8775) {
            return ({
                prism_rtl::is<crate::check::types::Ty::TyCon>(norm_assoc_8775) ? ({
                auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(norm_assoc_8775).a0;
                auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(norm_assoc_8775).a1;
                call_value(each_job(args, ({
                auto st_1_3 = st_1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_1_3 = std::move(st_1_3)](crate::check::types::Ty p0) {
                return ({
                    auto st_1_3_3 = st_1_3;
                    entered(once_job([=, st_1_3_3 = std::move(st_1_3_3)]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(Zonk(st_1_3_3, a))));
                    });
                }));
                });
            })));
            })), [=](Array<crate::check::types::Ty> each_8832) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyCon{n, each_8832})); });
            })
                : prism_rtl::is<crate::check::types::Ty::TyFn>(norm_assoc_8775) ? ({
                auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(norm_assoc_8775).a0;
                auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(norm_assoc_8775).a1;
                auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(norm_assoc_8775).a2;
                call_then(crate::check::types::colors::start_walk_col(st_1, c), [=](crate::check::types::Col walk_col_8887) {
                return call_value(each_job(ps, ({
                    auto st_1_3 = st_1;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_1_3 = std::move(st_1_3)](crate::check::types::Ty p0) {
                    return ({
                        auto st_1_3_3 = st_1_3;
                        entered(once_job([=, st_1_3_3 = std::move(st_1_3_3)]() {
                        return ({
                            auto p_ = p0;
                            (prism_rtl::more(prism_rtl::rc(Zonk(st_1_3_3, p_))));
                        });
                    }));
                    });
                })));
                })), [=](Array<crate::check::types::Ty> each_8904) { return call_then(start_zonk(st_1, prism_rtl::deref(res)), [=](crate::check::types::Ty zonk_8932) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{walk_col_8887, each_8904, prism_rtl::rc(zonk_8932)})); }); });
            });
            })
                : prism_rtl::is<crate::check::types::Ty::TyTuple>(norm_assoc_8775) ? ({
                auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(norm_assoc_8775).a0;
                call_value(each_job(ts, ({
                auto st_1_3 = st_1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_1_3 = std::move(st_1_3)](crate::check::types::Ty p0) {
                return ({
                    auto st_1_3_3 = st_1_3;
                    entered(once_job([=, st_1_3_3 = std::move(st_1_3_3)]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(Zonk(st_1_3_3, a))));
                    });
                }));
                });
            })));
            })), [=](Array<crate::check::types::Ty> each_8971) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyTuple{each_8971})); });
            })
                : prism_rtl::is<crate::check::types::Ty::TyArray>(norm_assoc_8775) ? ({
                auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(norm_assoc_8775).a0;
                call_then(start_zonk(st_1, prism_rtl::deref(e)), [=](crate::check::types::Ty zonk_9021) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(zonk_9021)})); });
            })
                : prism_rtl::is<crate::check::types::Ty::TyMap>(norm_assoc_8775) ? ({
                auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(norm_assoc_8775).a0;
                auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(norm_assoc_8775).a1;
                call_then(start_zonk(st_1, prism_rtl::deref(k)), [=](crate::check::types::Ty zonk_9056) { return call_then(start_zonk(st_1, prism_rtl::deref(v_)), [=](crate::check::types::Ty zonk_9070) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(zonk_9056), prism_rtl::rc(zonk_9070)})); }); });
            })
                : prism_rtl::is<crate::check::types::Ty::TySig>(norm_assoc_8775) ? ({
                auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(norm_assoc_8775).a0;
                auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(norm_assoc_8775).a1;
                call_then(start_zonk(st_1, prism_rtl::deref(i)), [=](crate::check::types::Ty zonk_9108) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{s, prism_rtl::rc(zonk_9108)})); });
            })
                : prism_rtl::is<crate::check::types::Ty::TyAt>(norm_assoc_8775) ? ({
                auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(norm_assoc_8775).a0;
                auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(norm_assoc_8775).a1;
                call_then(start_zonk(st_1, prism_rtl::deref(i)), [=](crate::check::types::Ty zonk_9142) { return call_then(start_walk_row(st_1, rw), [=](crate::check::types::Rw walk_row_9156) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(zonk_9142), walk_row_9156})); }); });
            })
                : prism_rtl::is<crate::check::types::Ty::TyElem>(norm_assoc_8775) ? ({
                auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(norm_assoc_8775).a0;
                auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(norm_assoc_8775).a1;
                call_then(start_walk_row(st_1, rw), [=](crate::check::types::Rw walk_row_9198) { return call_then(start_zonk(st_1, prism_rtl::deref(o)), [=](crate::check::types::Ty zonk_9216) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyElem{walk_row_9198, prism_rtl::rc(zonk_9216)})); }); });
            })
                : prism_rtl::is<crate::check::types::Ty::TyElemAny>(norm_assoc_8775) ? ({
                auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElemAny>(norm_assoc_8775).a0;
                call_then(start_walk_row(st_1, rw), [=](crate::check::types::Rw walk_row_9257) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyElemAny{walk_row_9257})); });
            })
                : prism_rtl::is<crate::check::types::Ty::TyAssoc>(norm_assoc_8775) ? ({
                auto&& n = prism_rtl::as<crate::check::types::Ty::TyAssoc>(norm_assoc_8775).a0;
                auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(norm_assoc_8775).a1;
                call_then(start_zonk(st_1, prism_rtl::deref(a)), [=](crate::check::types::Ty zonk_9303) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n, prism_rtl::rc(zonk_9303)})); });
            })
                : ({
                auto&& w = norm_assoc_8775;
                prism_rtl::finished(w);
            });
            });
        });
    });
}


/// `Start Zonk, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_zonk(crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<Zonk>(st, t);
}


/// FreeVars: unbounded fn St, Ty -> [Nat]
Array<Nat> free_vars(const crate::check::types::St& st, const crate::check::types::Ty& t) {
    return free_vars_into(st, Array<Nat>{}, t);
}


prism_rtl::Turn<Array<Nat>> FreeVars::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    return prism_rtl::more(prism_rtl::rc(FreeVarsInto(st, Array<Nat>{}, t)));
}


/// `Start FreeVars, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_free_vars(crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<FreeVars>(st, t);
}


/// FreeVarsInto: unbounded fn St, [Nat], Ty -> [Nat]
Array<Nat> free_vars_into(const crate::check::types::St& st, const Array<Nat>& acc, const crate::check::types::Ty& t) {
    auto&& _m = walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(_m).a0;
        return crate::check::types::add_nat(acc, n);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        return run_to_end(fold_job(args, acc, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_1_2, a, x))));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        return free_vars_into(st, run_to_end(fold_job(ps, acc, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_1_2, a, x))));
                });
            }));
            });
        })));
        }))), prism_rtl::deref(res));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return run_to_end(fold_job(ts, acc, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_1 = std::move(st_1)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=, st_1_2 = std::move(st_1_2)]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_1_2, a, x))));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        return free_vars_into(st, acc, prism_rtl::deref(e));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return free_vars_into(st, free_vars_into(st, acc, prism_rtl::deref(k)), prism_rtl::deref(v_));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return free_vars_into(st, acc, prism_rtl::deref(i));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
        return free_vars_into(st, acc, prism_rtl::deref(i));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
        return free_vars_into(st, acc, prism_rtl::deref(o));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(_m)) {
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(_m).a1;
        return free_vars_into(st, acc, prism_rtl::deref(a));
    }
    {
        return acc;
    }
}


prism_rtl::Turn<Array<Nat>> FreeVarsInto::cycle() const {
    const auto& st = this->st;
    const auto& acc = this->acc;
    const auto& t = this->t;
    auto acc_1 = acc;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(start_walk(st_2, t_3), [=](crate::check::types::Ty walk_9536) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_9536) ? ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_9536).a0;
            prism_rtl::finished(crate::check::types::add_nat(acc_1, n));
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_9536) ? ({
            auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_9536).a1;
            fold_job(args, acc_1, ({
            auto st_2_4 = st_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_2_4 = std::move(st_2_4)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_2_4_4 = st_2_4;
                entered(once_job([=, st_2_4_4 = std::move(st_2_4_4)]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_2_4_4, a, x))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::types::Ty::TyFn>(walk_9536) ? ({
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_9536).a1;
            auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_9536).a2;
            call_value(fold_job(ps, acc_1, ({
            auto st_2_4 = st_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_2_4 = std::move(st_2_4)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_2_4_4 = st_2_4;
                entered(once_job([=, st_2_4_4 = std::move(st_2_4_4)]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_2_4_4, a, x))));
                });
            }));
            });
        })));
        })), [=](Array<Nat> fold_9690) { return prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_2, fold_9690, prism_rtl::deref(res)))); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyTuple>(walk_9536) ? ({
            auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(walk_9536).a0;
            fold_job(ts, acc_1, ({
            auto st_2_4 = st_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_2_4 = std::move(st_2_4)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_2_4_4 = st_2_4;
                entered(once_job([=, st_2_4_4 = std::move(st_2_4_4)]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_2_4_4, a, x))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::types::Ty::TyArray>(walk_9536) ? ({
            auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(walk_9536).a0;
            prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_2, acc_1, prism_rtl::deref(e))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyMap>(walk_9536) ? ({
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_9536).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_9536).a1;
            call_then(start_free_vars_into(st_2, acc_1, prism_rtl::deref(k)), [=](Array<Nat> free_vars_into_9873) { return prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_2, free_vars_into_9873, prism_rtl::deref(v_)))); });
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_9536) ? ({
            auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(walk_9536).a1;
            prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_2, acc_1, prism_rtl::deref(i))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyAt>(walk_9536) ? ({
            auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_9536).a0;
            prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_2, acc_1, prism_rtl::deref(i))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyElem>(walk_9536) ? ({
            auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_9536).a1;
            prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_2, acc_1, prism_rtl::deref(o))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyAssoc>(walk_9536) ? ({
            auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(walk_9536).a1;
            prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_2, acc_1, prism_rtl::deref(a))));
        })
            : prism_rtl::finished(acc_1);
        });
    });
}


/// `Start FreeVarsInto, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_free_vars_into(crate::check::types::St st, Array<Nat> acc, crate::check::types::Ty t) {
    return prism_rtl::make_rc<FreeVarsInto>(st, acc, t);
}

}  // namespace crate::check::types::recording
