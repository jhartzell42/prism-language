// The module `Check.Typed`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/typed/module.hpp>
#include <check/types/module.hpp>
#include <syntax/module.hpp>
#include <check/errors/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Typed`, from `target/bootstrap/cpp-src/prismc/check/typed/mod.prism`.
namespace crate::check::typed {

void AppNote::show(Printer& p) const {
    p.record("AppNote", {{"at", at_p}, {"callee", callee_p}, {"kind", kind_p}, {"layer", layer_p}, {"lifted", lifted_p}, {"inner", inner_p}, {"color", color_p}});
}

Pod AppNote::to_pod() const {
    return Pod::record("AppNote", {{"at", prism_rtl::to_pod(at_p)}, {"callee", prism_rtl::to_pod(callee_p)}, {"kind", prism_rtl::to_pod(kind_p)}, {"layer", prism_rtl::to_pod(layer_p)}, {"lifted", prism_rtl::to_pod(lifted_p)}, {"inner", prism_rtl::to_pod(inner_p)}, {"color", prism_rtl::to_pod(color_p)}});
}

Result<AppNote> AppNote::from_pod(const Pod& whole) {
    return AppNote{.at_p = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .callee_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "callee")))), .kind_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "kind")))), .layer_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "layer")))), .lifted_p = TRY(prism_rtl::from_pod<Array<Nat>>(TRY(crate::prelude::field(whole, "lifted")))), .inner_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "inner")))), .color_p = TRY(prism_rtl::from_pod<crate::check::types::Col>(TRY(crate::prelude::field(whole, "color"))))};
}


void BinderNote::show(Printer& p) const {
    p.record("BinderNote", {{"at", at_p}, {"name", name_p}, {"ty", ty_p}});
}

Pod BinderNote::to_pod() const {
    return Pod::record("BinderNote", {{"at", prism_rtl::to_pod(at_p)}, {"name", prism_rtl::to_pod(name_p)}, {"ty", prism_rtl::to_pod(ty_p)}});
}

Result<BinderNote> BinderNote::from_pod(const Pod& whole) {
    return BinderNote{.at_p = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .ty_p = TRY(prism_rtl::from_pod<crate::check::types::Ty>(TRY(crate::prelude::field(whole, "ty"))))};
}


void DefNote::show(Printer& p) const {
    p.record("DefNote", {{"at", at_p}, {"name", name_p}, {"scheme", scheme_p}});
}

Pod DefNote::to_pod() const {
    return Pod::record("DefNote", {{"at", prism_rtl::to_pod(at_p)}, {"name", prism_rtl::to_pod(name_p)}, {"scheme", prism_rtl::to_pod(scheme_p)}});
}

Result<DefNote> DefNote::from_pod(const Pod& whole) {
    return DefNote{.at_p = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .scheme_p = TRY(prism_rtl::from_pod<crate::check::types::Scheme>(TRY(crate::prelude::field(whole, "scheme"))))};
}


void FnNote::show(Printer& p) const {
    p.record("FnNote", {{"at", at_p}, {"name", name_p}, {"declared", declared_p}, {"body", body_p}});
}

Pod FnNote::to_pod() const {
    return Pod::record("FnNote", {{"at", prism_rtl::to_pod(at_p)}, {"name", prism_rtl::to_pod(name_p)}, {"declared", prism_rtl::to_pod(declared_p)}, {"body", prism_rtl::to_pod(body_p)}});
}

Result<FnNote> FnNote::from_pod(const Pod& whole) {
    return FnNote{.at_p = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .declared_p = TRY(prism_rtl::from_pod<crate::check::types::Col>(TRY(crate::prelude::field(whole, "declared")))), .body_p = TRY(prism_rtl::from_pod<crate::check::types::Col>(TRY(crate::prelude::field(whole, "body"))))};
}


void GenNote::show(Printer& p) const {
    p.record("GenNote", {{"at", at_p}, {"name", name_p}, {"tys", tys_p}, {"cols", cols_p}});
}

Pod GenNote::to_pod() const {
    return Pod::record("GenNote", {{"at", prism_rtl::to_pod(at_p)}, {"name", prism_rtl::to_pod(name_p)}, {"tys", prism_rtl::to_pod(tys_p)}, {"cols", prism_rtl::to_pod(cols_p)}});
}

Result<GenNote> GenNote::from_pod(const Pod& whole) {
    return GenNote{.at_p = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .tys_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "tys")))), .cols_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "cols"))))};
}


void GlobalNote::show(Printer& p) const {
    p.record("GlobalNote", {{"at", at_p}, {"target", target_p}});
}

Pod GlobalNote::to_pod() const {
    return Pod::record("GlobalNote", {{"at", prism_rtl::to_pod(at_p)}, {"target", prism_rtl::to_pod(target_p)}});
}

Result<GlobalNote> GlobalNote::from_pod(const Pod& whole) {
    return GlobalNote{.at_p = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .target_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "target"))))};
}


void GroupNote::show(Printer& p) const {
    p.record("GroupNote", {{"at", at_p}, {"kind", kind_p}, {"order", order_p}});
}

Pod GroupNote::to_pod() const {
    return Pod::record("GroupNote", {{"at", prism_rtl::to_pod(at_p)}, {"kind", prism_rtl::to_pod(kind_p)}, {"order", prism_rtl::to_pod(order_p)}});
}

Result<GroupNote> GroupNote::from_pod(const Pod& whole) {
    return GroupNote{.at_p = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .kind_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "kind")))), .order_p = TRY(prism_rtl::from_pod<Array<Array<Nat>>>(TRY(crate::prelude::field(whole, "order"))))};
}


void ImplNote::show(Printer& p) const {
    p.record("ImplNote", {{"at", at_p}, {"cls", cls_p}, {"ty", ty_p}, {"how", how_p}});
}

Pod ImplNote::to_pod() const {
    return Pod::record("ImplNote", {{"at", prism_rtl::to_pod(at_p)}, {"cls", prism_rtl::to_pod(cls_p)}, {"ty", prism_rtl::to_pod(ty_p)}, {"how", prism_rtl::to_pod(how_p)}});
}

Result<ImplNote> ImplNote::from_pod(const Pod& whole) {
    return ImplNote{.at_p = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .cls_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "cls")))), .ty_p = TRY(prism_rtl::from_pod<crate::check::types::Ty>(TRY(crate::prelude::field(whole, "ty")))), .how_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "how"))))};
}


bool InstNote::operator==(const InstNote& o) const { return at_p == o.at_p && name_p == o.name_p && tys_p == o.tys_p && cols_p == o.cols_p; }

void InstNote::show(Printer& p) const {
    p.record("InstNote", {{"at", at_p}, {"name", name_p}, {"tys", tys_p}, {"cols", cols_p}});
}

Pod InstNote::to_pod() const {
    return Pod::record("InstNote", {{"at", prism_rtl::to_pod(at_p)}, {"name", prism_rtl::to_pod(name_p)}, {"tys", prism_rtl::to_pod(tys_p)}, {"cols", prism_rtl::to_pod(cols_p)}});
}

Result<InstNote> InstNote::from_pod(const Pod& whole) {
    return InstNote{.at_p = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .tys_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, crate::check::types::Ty>>>(TRY(crate::prelude::field(whole, "tys")))), .cols_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, crate::check::types::Col>>>(TRY(crate::prelude::field(whole, "cols"))))};
}


bool LiftNote::operator==(const LiftNote& o) const { return at_p == o.at_p && sigil_p == o.sigil_p && operands_p == o.operands_p; }

void LiftNote::show(Printer& p) const {
    p.record("LiftNote", {{"at", at_p}, {"sigil", sigil_p}, {"operands", operands_p}});
}

Pod LiftNote::to_pod() const {
    return Pod::record("LiftNote", {{"at", prism_rtl::to_pod(at_p)}, {"sigil", prism_rtl::to_pod(sigil_p)}, {"operands", prism_rtl::to_pod(operands_p)}});
}

Result<LiftNote> LiftNote::from_pod(const Pod& whole) {
    return LiftNote{.at_p = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .sigil_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "sigil")))), .operands_p = TRY(prism_rtl::from_pod<Array<crate::syntax::Range>>(TRY(crate::prelude::field(whole, "operands"))))};
}


void LocalNote::show(Printer& p) const {
    p.record("LocalNote", {{"at", at_p}, {"id", id_p}});
}

Pod LocalNote::to_pod() const {
    return Pod::record("LocalNote", {{"at", prism_rtl::to_pod(at_p)}, {"id", prism_rtl::to_pod(id_p)}});
}

Result<LocalNote> LocalNote::from_pod(const Pod& whole) {
    return LocalNote{.at_p = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .id_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "id"))))};
}


void MethodNote::show(Printer& p) const {
    p.record("MethodNote", {{"at", at_p}, {"method", method_p}, {"cls", cls_p}});
}

Pod MethodNote::to_pod() const {
    return Pod::record("MethodNote", {{"at", prism_rtl::to_pod(at_p)}, {"method", prism_rtl::to_pod(method_p)}, {"cls", prism_rtl::to_pod(cls_p)}});
}

Result<MethodNote> MethodNote::from_pod(const Pod& whole) {
    return MethodNote{.at_p = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .method_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "method")))), .cls_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "cls"))))};
}


void SrcAt::show(Printer& p) const {
    p.record("SrcAt", {{"file", file_p}, {"span", span_p}});
}

Pod SrcAt::to_pod() const {
    return Pod::record("SrcAt", {{"file", prism_rtl::to_pod(file_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<SrcAt> SrcAt::from_pod(const Pod& whole) {
    return SrcAt{.file_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool TProgram::operator==(const TProgram& o) const { return exprs_p == o.exprs_p && apps_p == o.apps_p && lifts_p == o.lifts_p && fns_p == o.fns_p && impls_p == o.impls_p && methods_p == o.methods_p && groups_p == o.groups_p && binders_p == o.binders_p && locals_p == o.locals_p && uses_p == o.uses_p && calls_p == o.calls_p && globals_p == o.globals_p && gens_p == o.gens_p && insts_p == o.insts_p && defs_p == o.defs_p && unshrunk_p == o.unshrunk_p; }

void TProgram::show(Printer& p) const {
    p.record("TProgram", {{"exprs", exprs_p}, {"apps", apps_p}, {"lifts", lifts_p}, {"fns", fns_p}, {"impls", impls_p}, {"methods", methods_p}, {"groups", groups_p}, {"binders", binders_p}, {"locals", locals_p}, {"uses", uses_p}, {"calls", calls_p}, {"globals", globals_p}, {"gens", gens_p}, {"insts", insts_p}, {"defs", defs_p}, {"unshrunk", unshrunk_p}});
}

Pod TProgram::to_pod() const {
    return Pod::record("TProgram", {{"exprs", prism_rtl::to_pod(exprs_p)}, {"apps", prism_rtl::to_pod(apps_p)}, {"lifts", prism_rtl::to_pod(lifts_p)}, {"fns", prism_rtl::to_pod(fns_p)}, {"impls", prism_rtl::to_pod(impls_p)}, {"methods", prism_rtl::to_pod(methods_p)}, {"groups", prism_rtl::to_pod(groups_p)}, {"binders", prism_rtl::to_pod(binders_p)}, {"locals", prism_rtl::to_pod(locals_p)}, {"uses", prism_rtl::to_pod(uses_p)}, {"calls", prism_rtl::to_pod(calls_p)}, {"globals", prism_rtl::to_pod(globals_p)}, {"gens", prism_rtl::to_pod(gens_p)}, {"insts", prism_rtl::to_pod(insts_p)}, {"defs", prism_rtl::to_pod(defs_p)}, {"unshrunk", prism_rtl::to_pod(unshrunk_p)}});
}

Result<TProgram> TProgram::from_pod(const Pod& whole) {
    return TProgram{.exprs_p = TRY(prism_rtl::from_pod<Array<TyNote>>(TRY(crate::prelude::field(whole, "exprs")))), .apps_p = TRY(prism_rtl::from_pod<Array<AppNote>>(TRY(crate::prelude::field(whole, "apps")))), .lifts_p = TRY(prism_rtl::from_pod<Array<LiftNote>>(TRY(crate::prelude::field(whole, "lifts")))), .fns_p = TRY(prism_rtl::from_pod<Array<FnNote>>(TRY(crate::prelude::field(whole, "fns")))), .impls_p = TRY(prism_rtl::from_pod<Array<ImplNote>>(TRY(crate::prelude::field(whole, "impls")))), .methods_p = TRY(prism_rtl::from_pod<Array<MethodNote>>(TRY(crate::prelude::field(whole, "methods")))), .groups_p = TRY(prism_rtl::from_pod<Array<GroupNote>>(TRY(crate::prelude::field(whole, "groups")))), .binders_p = TRY(prism_rtl::from_pod<Array<BinderNote>>(TRY(crate::prelude::field(whole, "binders")))), .locals_p = TRY(prism_rtl::from_pod<Array<LocalNote>>(TRY(crate::prelude::field(whole, "locals")))), .uses_p = TRY(prism_rtl::from_pod<Array<LocalNote>>(TRY(crate::prelude::field(whole, "uses")))), .calls_p = TRY(prism_rtl::from_pod<Array<LocalNote>>(TRY(crate::prelude::field(whole, "calls")))), .globals_p = TRY(prism_rtl::from_pod<Array<GlobalNote>>(TRY(crate::prelude::field(whole, "globals")))), .gens_p = TRY(prism_rtl::from_pod<Array<GenNote>>(TRY(crate::prelude::field(whole, "gens")))), .insts_p = TRY(prism_rtl::from_pod<Array<InstNote>>(TRY(crate::prelude::field(whole, "insts")))), .defs_p = TRY(prism_rtl::from_pod<Array<DefNote>>(TRY(crate::prelude::field(whole, "defs")))), .unshrunk_p = TRY(prism_rtl::from_pod<Array<SrcAt>>(TRY(crate::prelude::field(whole, "unshrunk"))))};
}


void TyNote::show(Printer& p) const {
    p.record("TyNote", {{"at", at_p}, {"ty", ty_p}});
}

Pod TyNote::to_pod() const {
    return Pod::record("TyNote", {{"at", prism_rtl::to_pod(at_p)}, {"ty", prism_rtl::to_pod(ty_p)}});
}

Result<TyNote> TyNote::from_pod(const Pod& whole) {
    return TyNote{.at_p = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .ty_p = TRY(prism_rtl::from_pod<crate::check::types::Ty>(TRY(crate::prelude::field(whole, "ty"))))};
}


/// let emptyTyped
TProgram empty_typed_p() {
    return TProgram{.exprs_p = Array<TyNote>{}, .apps_p = Array<AppNote>{}, .lifts_p = Array<LiftNote>{}, .fns_p = Array<FnNote>{}, .impls_p = Array<ImplNote>{}, .methods_p = Array<MethodNote>{}, .groups_p = Array<GroupNote>{}, .binders_p = Array<BinderNote>{}, .locals_p = Array<LocalNote>{}, .uses_p = Array<LocalNote>{}, .calls_p = Array<LocalNote>{}, .globals_p = Array<GlobalNote>{}, .gens_p = Array<GenNote>{}, .insts_p = Array<InstNote>{}, .defs_p = Array<DefNote>{}, .unshrunk_p = Array<SrcAt>{}};
}


/// AtKey: fn SrcAt -> Text
Text at_key_f(const SrcAt& a_p0) {
    return prism_rtl::cat(a_p0.file_p, ":", prism_rtl::deref(a_p0.span_p).start_p, ":", prism_rtl::deref(a_p0.span_p).end_p);
}

}  // namespace crate::check::typed
