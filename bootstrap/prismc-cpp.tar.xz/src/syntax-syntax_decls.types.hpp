// The modules `syntax`, `syntax::decls`: its value types (records, tags, newtypes and choices with their cases), each
// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism
// source, not this file.
#pragma once

#include <syntax/decl.hpp>
#include <syntax/decls/decl.hpp>
#include "elem.decl.hpp"

namespace crate {

using namespace prelude;

namespace syntax {

/// `Range`:
///
/// ```prism
/// type Range = record:
/// ```
struct Range {
    using prism_value = void;
    Nat start;
    Nat end;
    const Range* operator->() const { return this; }
    Range* operator->() { return this; }
    bool operator==(const Range&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Range> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax {

/// `RegexLit`:
///
/// ```prism
/// type RegexLit = record:
/// ```
struct RegexLit {
    using prism_value = void;
    Text pattern;
    Nat pattern_at;
    std::optional<Text> replacement;
    Nat replacement_at;
    Text flags;
    Nat flags_at;
    const RegexLit* operator->() const { return this; }
    RegexLit* operator->() { return this; }
    bool operator==(const RegexLit&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<RegexLit> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax {

/// `Block`:
///
/// ```prism
/// type Block = record:
/// ```
struct Block {
    using prism_value = void;
    Array<Stmt> stmts;
    bool inline_;
    Range span;
    const Block* operator->() const { return this; }
    Block* operator->() { return this; }
    bool operator==(const Block&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Block> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax {

/// `Diag`:
///
/// ```prism
/// type Diag = record:
/// ```
struct Diag {
    using prism_value = void;
    Text stage;
    Range span;
    Text message;
    std::optional<Text> feature;
    const Diag* operator->() const { return this; }
    Diag* operator->() { return this; }
    bool operator==(const Diag&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Diag> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax {

/// `Expr`:
///
/// ```prism
/// type Expr = record:
/// ```
struct Expr {
    using prism_value = void;
    prism_rtl::Val<ExprKind> kind;
    Range span;
    const Expr* operator->() const { return this; }
    Expr* operator->() { return this; }
    bool operator==(const Expr&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Expr> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax {

/// `Ident`:
///
/// ```prism
/// type Ident = record:
/// ```
struct Ident {
    using prism_value = void;
    Text name;
    Range span;
    const Ident* operator->() const { return this; }
    Ident* operator->() { return this; }
    bool operator==(const Ident&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Ident> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax {

/// `LitKind`:
///
/// ```prism
/// type LitKind = choice:
/// ```
class LitKind {
public:
    using prism_value = void;
    struct LInt {
        Text a0;
        bool operator==(const LInt&) const = default;
    };

    struct LFloat {
        Text a0;
        bool operator==(const LFloat&) const = default;
    };

    struct LDuration {
        Text a0;
        Text a1;
        bool operator==(const LDuration&) const = default;
    };

    struct LChar {
        Text a0;
        bool operator==(const LChar&) const = default;
    };

    struct LText {
        Array<TextSeg> a0;
        bool operator==(const LText&) const;
    };

    struct LRegex {
        RegexLit a0;
        bool operator==(const LRegex&) const = default;
    };
    using Cases = std::variant<LInt, LFloat, LDuration, LChar, LText, LRegex>;
    template <class C>
        requires prism_rtl::one_of<C, LInt, LFloat, LDuration, LChar, LText, LRegex>
    LitKind(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<LitKind> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const LitKind& a, const LitKind& b) { return a.cases() == b.cases(); }

}  // namespace syntax

namespace syntax {

/// `Pattern`:
///
/// ```prism
/// type Pattern = record:
/// ```
struct Pattern_ {
    using prism_value = void;
    prism_rtl::Val<PatternKind> kind;
    Range span;
    const Pattern_* operator->() const { return this; }
    Pattern_* operator->() { return this; }
    bool operator==(const Pattern_&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Pattern_> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax {

/// `QualName`:
///
/// ```prism
/// type QualName = record:
/// ```
struct QualName {
    using prism_value = void;
    Array<Text> path_;
    Range span;
    const QualName* operator->() const { return this; }
    QualName* operator->() { return this; }
    bool operator==(const QualName&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<QualName> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax {

/// `Row`:
///
/// ```prism
/// type Row = record:
/// ```
struct Row_ {
    using prism_value = void;
    Array<RowTerm> terms;
    Range span;
    const Row_* operator->() const { return this; }
    Row_* operator->() { return this; }
    bool operator==(const Row_&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Row_> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax {

/// `SName`:
///
/// ```prism
/// type SName = record:
/// ```
struct SName {
    using prism_value = void;
    Text sigils;
    Array<Text> path_;
    Range span;
    const SName* operator->() const { return this; }
    SName* operator->() { return this; }
    bool operator==(const SName&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<SName> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax {

/// `Template`:
///
/// ```prism
/// type Template = record:
/// ```
struct Template {
    using prism_value = void;
    Text keyword;
    Text lang;
    Text delims;
    Array<TemplatePart> parts;
    Range span;
    const Template* operator->() const { return this; }
    Template* operator->() { return this; }
    bool operator==(const Template&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Template> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax {

/// `TraitRef`:
///
/// ```prism
/// type TraitRef = record:
/// ```
struct TraitRef {
    using prism_value = void;
    Array<Text> path_;
    Range span;
    const TraitRef* operator->() const { return this; }
    TraitRef* operator->() { return this; }
    bool operator==(const TraitRef&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TraitRef> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax {

/// `Type`:
///
/// ```prism
/// type Type = record:
/// ```
struct Type {
    using prism_value = void;
    prism_rtl::Val<TypeKind> kind;
    Range span;
    const Type* operator->() const { return this; }
    Type* operator->() { return this; }
    bool operator==(const Type&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Type> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax::decls {

/// `TestPath`:
///
/// ```prism
/// type TestPath = record:
/// ```
struct TestPath {
    using prism_value = void;
    Array<PathSeg> segments;
    crate::syntax::Range span;
    const TestPath* operator->() const { return this; }
    TestPath* operator->() { return this; }
    bool operator==(const TestPath&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TestPath> from_pod(const Pod& whole);
};


}  // namespace syntax::decls

namespace syntax {

/// `Arg`:
///
/// ```prism
/// type Arg = record:
/// ```
struct Arg {
    using prism_value = void;
    std::optional<Ident> name;
    Expr value;
    Range span;
    const Arg* operator->() const { return this; }
    Arg* operator->() { return this; }
    bool operator==(const Arg&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Arg> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax {

/// `Arm`:
///
/// ```prism
/// type Arm = record:
/// ```
struct Arm {
    using prism_value = void;
    std::optional<Pattern_> pattern;
    std::optional<Expr> guard;
    Block body;
    Range span;
    const Arm* operator->() const { return this; }
    Arm* operator->() { return this; }
    bool operator==(const Arm&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Arm> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax {

/// `Color`:
///
/// ```prism
/// type Color = choice:
/// ```
class Color {
public:
    using prism_value = void;
    struct Bounded {
        bool operator==(const Bounded&) const = default;
    };

    struct Unbounded {
        bool operator==(const Unbounded&) const = default;
    };

    struct ColorVar {
        Ident a0;
        bool operator==(const ColorVar&) const = default;
    };
    using Cases = std::variant<Bounded, Unbounded, ColorVar>;
    template <class C>
        requires prism_rtl::one_of<C, Bounded, Unbounded, ColorVar>
    Color(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Color> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const Color& a, const Color& b) { return a.cases() == b.cases(); }

}  // namespace syntax

namespace syntax {

/// `Cond`:
///
/// ```prism
/// type Cond = choice:
/// ```
class Cond {
public:
    using prism_value = void;
    struct CondExpr {
        prism_rtl::Val<Expr> a0;
        bool operator==(const CondExpr&) const;
    };

    struct CondBind {
        Pattern_ a0;
        prism_rtl::Val<Expr> a1;
        prism_rtl::Val<std::optional<Expr>> a2;
        bool operator==(const CondBind&) const;
    };
    using Cases = std::variant<CondExpr, CondBind>;
    template <class C>
        requires prism_rtl::one_of<C, CondExpr, CondBind>
    Cond(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Cond> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const Cond& a, const Cond& b) { return a.cases() == b.cases(); }

}  // namespace syntax

namespace syntax {

/// `FieldPat`:
///
/// ```prism
/// type FieldPat = record:
/// ```
struct FieldPat {
    using prism_value = void;
    std::optional<Ident> name;
    Pattern_ pattern;
    Range span;
    const FieldPat* operator->() const { return this; }
    FieldPat* operator->() { return this; }
    bool operator==(const FieldPat&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<FieldPat> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax {

/// `ForBinders`:
///
/// ```prism
/// type ForBinders = record:
/// ```
struct ForBinders {
    using prism_value = void;
    Pattern_ first;
    std::optional<Pattern_> second;
    const ForBinders* operator->() const { return this; }
    ForBinders* operator->() { return this; }
    bool operator==(const ForBinders&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ForBinders> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax {

/// `LambdaBody`:
///
/// ```prism
/// type LambdaBody = choice:
/// ```
class LambdaBody {
public:
    using prism_value = void;
    struct LbExpr {
        prism_rtl::Val<Expr> a0;
        bool operator==(const LbExpr&) const;
    };

    struct LbBlock {
        Block a0;
        bool operator==(const LbBlock&) const = default;
    };
    using Cases = std::variant<LbExpr, LbBlock>;
    template <class C>
        requires prism_rtl::one_of<C, LbExpr, LbBlock>
    LambdaBody(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<LambdaBody> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const LambdaBody& a, const LambdaBody& b) { return a.cases() == b.cases(); }

}  // namespace syntax

namespace syntax {

/// `Literal`:
///
/// ```prism
/// type Literal = record:
/// ```
struct Literal {
    using prism_value = void;
    Text marks;
    LitKind kind;
    Range span;
    const Literal* operator->() const { return this; }
    Literal* operator->() { return this; }
    bool operator==(const Literal&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Literal> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax {

/// `ModLine`:
///
/// ```prism
/// type ModLine = record:
/// ```
struct ModLine {
    using prism_value = void;
    Ident name;
    bool is_test;
    Range span;
    const ModLine* operator->() const { return this; }
    ModLine* operator->() { return this; }
    bool operator==(const ModLine&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ModLine> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax {

/// `Module`:
///
/// ```prism
/// type Module = record:
/// ```
struct Module {
    using prism_value = void;
    std::optional<QualName> name;
    std::optional<Row_> emit_row;
    Array<ModLine> mods;
    Array<Use> uses;
    Array<crate::syntax::decls::Decl> decls;
    std::optional<Template> template_;
    Range span;
    const Module* operator->() const { return this; }
    Module* operator->() { return this; }
    bool operator==(const Module&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Module> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax {

/// `RowTerm`:
///
/// ```prism
/// type RowTerm = choice:
/// ```
class RowTerm {
public:
    using prism_value = void;
    struct RFamily {
        QualName a0;
        bool operator==(const RFamily&) const = default;
    };

    struct RType {
        Type a0;
        bool operator==(const RType&) const = default;
    };

    struct RVar {
        Ident a0;
        bool operator==(const RVar&) const = default;
    };
    using Cases = std::variant<RFamily, RType, RVar>;
    template <class C>
        requires prism_rtl::one_of<C, RFamily, RType, RVar>
    RowTerm(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<RowTerm> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const RowTerm& a, const RowTerm& b) { return a.cases() == b.cases(); }

}  // namespace syntax

namespace syntax {

/// `TemplatePart`:
///
/// ```prism
/// type TemplatePart = choice:
/// ```
class TemplatePart {
public:
    using prism_value = void;
    struct TpText {
        Text a0;
        bool operator==(const TpText&) const = default;
    };

    struct TpPlaceholder {
        Expr a0;
        std::optional<Nat> a1;
        bool operator==(const TpPlaceholder&) const = default;
    };

    struct TpBlock {
        Block a0;
        bool operator==(const TpBlock&) const = default;
    };

    struct TpCall {
        SName a0;
        Array<Arg> a1;
        std::optional<Array<TemplatePart>> a2;
        Range a3;
        bool operator==(const TpCall&) const;
    };
    using Cases = std::variant<TpText, TpPlaceholder, TpBlock, TpCall>;
    template <class C>
        requires prism_rtl::one_of<C, TpText, TpPlaceholder, TpBlock, TpCall>
    TemplatePart(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TemplatePart> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const TemplatePart& a, const TemplatePart& b) { return a.cases() == b.cases(); }

}  // namespace syntax

namespace syntax {

/// `TextSeg`:
///
/// ```prism
/// type TextSeg = choice:
/// ```
class TextSeg {
public:
    using prism_value = void;
    struct SegPlain {
        Text a0;
        bool operator==(const SegPlain&) const = default;
    };

    struct SegPlaceholder {
        Expr a0;
        bool operator==(const SegPlaceholder&) const = default;
    };
    using Cases = std::variant<SegPlain, SegPlaceholder>;
    template <class C>
        requires prism_rtl::one_of<C, SegPlain, SegPlaceholder>
    TextSeg(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TextSeg> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const TextSeg& a, const TextSeg& b) { return a.cases() == b.cases(); }

}  // namespace syntax

namespace syntax {

/// `Use`:
///
/// ```prism
/// type Use = record:
/// ```
struct Use {
    using prism_value = void;
    QualName target;
    bool star;
    Range span;
    const Use* operator->() const { return this; }
    Use* operator->() { return this; }
    bool operator==(const Use&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Use> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax::decls {

/// `Bound`:
///
/// ```prism
/// type Bound = record:
/// ```
struct Bound {
    using prism_value = void;
    crate::syntax::Ident var;
    Array<crate::syntax::TraitRef> traits;
    crate::syntax::Range span;
    const Bound* operator->() const { return this; }
    Bound* operator->() { return this; }
    bool operator==(const Bound&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Bound> from_pod(const Pod& whole);
};


}  // namespace syntax::decls

namespace syntax::decls {

/// `Case`:
///
/// ```prism
/// type Case = record:
/// ```
struct Case_ {
    using prism_value = void;
    crate::syntax::SName name;
    Array<crate::syntax::Type> args;
    std::optional<crate::syntax::Type> indexed;
    crate::syntax::Range span;
    const Case_* operator->() const { return this; }
    Case_* operator->() { return this; }
    bool operator==(const Case_&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Case_> from_pod(const Pod& whole);
};


}  // namespace syntax::decls

namespace syntax::decls {

/// `CheckDecl`:
///
/// ```prism
/// type CheckDecl = record:
/// ```
struct CheckDecl {
    using prism_value = void;
    crate::syntax::Ident name;
    Array<CheckLine> lines;
    crate::syntax::Range span;
    const CheckDecl* operator->() const { return this; }
    CheckDecl* operator->() { return this; }
    bool operator==(const CheckDecl&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CheckDecl> from_pod(const Pod& whole);
};


}  // namespace syntax::decls

namespace syntax::decls {

/// `CheckLine`:
///
/// ```prism
/// type CheckLine = record:
/// ```
struct CheckLine {
    using prism_value = void;
    crate::syntax::Expr expr;
    std::optional<crate::syntax::Pattern_> pattern;
    crate::syntax::Range span;
    const CheckLine* operator->() const { return this; }
    CheckLine* operator->() { return this; }
    bool operator==(const CheckLine&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CheckLine> from_pod(const Pod& whole);
};


}  // namespace syntax::decls

namespace syntax::decls {

/// `DefName`:
///
/// ```prism
/// type DefName = choice:
/// ```
class DefName {
public:
    using prism_value = void;
    struct DefSName {
        crate::syntax::SName a0;
        bool operator==(const DefSName&) const = default;
    };

    struct DefOp {
        Text a0;
        crate::syntax::Range a1;
        bool operator==(const DefOp&) const = default;
    };
    using Cases = std::variant<DefSName, DefOp>;
    template <class C>
        requires prism_rtl::one_of<C, DefSName, DefOp>
    DefName(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<DefName> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const DefName& a, const DefName& b) { return a.cases() == b.cases(); }

}  // namespace syntax::decls

namespace syntax::decls {

/// `DeliveryKind`:
///
/// ```prism
/// type DeliveryKind = choice:
/// ```
class DeliveryKind {
public:
    using prism_value = void;
    struct DkSend {
        crate::syntax::Expr a0;
        bool operator==(const DkSend&) const = default;
    };

    struct DkClick {
        bool operator==(const DkClick&) const = default;
    };

    struct DkAnswer {
        bool operator==(const DkAnswer&) const = default;
    };
    using Cases = std::variant<DkSend, DkClick, DkAnswer>;
    template <class C>
        requires prism_rtl::one_of<C, DkSend, DkClick, DkAnswer>
    DeliveryKind(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<DeliveryKind> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const DeliveryKind& a, const DeliveryKind& b) { return a.cases() == b.cases(); }

}  // namespace syntax::decls

namespace syntax::decls {

/// `Entry`:
///
/// ```prism
/// type Entry = record:
/// ```
struct Entry {
    using prism_value = void;
    crate::syntax::Expr element;
    crate::syntax::Expr value;
    crate::syntax::Range span;
    const Entry* operator->() const { return this; }
    Entry* operator->() { return this; }
    bool operator==(const Entry&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Entry> from_pod(const Pod& whole);
};


}  // namespace syntax::decls

namespace syntax::decls {

/// `Field`:
///
/// ```prism
/// type Field = record:
/// ```
struct Field {
    using prism_value = void;
    crate::syntax::Ident name;
    crate::syntax::Type ty;
    crate::syntax::Range span;
    const Field* operator->() const { return this; }
    Field* operator->() { return this; }
    bool operator==(const Field&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Field> from_pod(const Pod& whole);
};


}  // namespace syntax::decls

namespace syntax::decls {

/// `FnBody`:
///
/// ```prism
/// type FnBody = choice:
/// ```
class FnBody {
public:
    using prism_value = void;
    struct BodyExpr {
        crate::syntax::Expr a0;
        bool operator==(const BodyExpr&) const = default;
    };

    struct BodyBlock {
        crate::syntax::Block a0;
        bool operator==(const BodyBlock&) const = default;
    };
    using Cases = std::variant<BodyExpr, BodyBlock>;
    template <class C>
        requires prism_rtl::one_of<C, BodyExpr, BodyBlock>
    FnBody(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<FnBody> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const FnBody& a, const FnBody& b) { return a.cases() == b.cases(); }

}  // namespace syntax::decls

namespace syntax::decls {

/// `ImplDecl`:
///
/// ```prism
/// type ImplDecl = record:
/// ```
struct ImplDecl {
    using prism_value = void;
    crate::syntax::TraitRef trait_ref;
    crate::syntax::Type ty;
    Array<Bound> bounds;
    Array<TraitItem> items;
    crate::syntax::Range span;
    const ImplDecl* operator->() const { return this; }
    ImplDecl* operator->() { return this; }
    bool operator==(const ImplDecl&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ImplDecl> from_pod(const Pod& whole);
};


}  // namespace syntax::decls

namespace syntax::decls {

/// `LetDecl`:
///
/// ```prism
/// type LetDecl = record:
/// ```
struct LetDecl {
    using prism_value = void;
    crate::syntax::Pattern_ pattern;
    std::optional<crate::syntax::Type> ty;
    crate::syntax::Expr value;
    crate::syntax::Range span;
    const LetDecl* operator->() const { return this; }
    LetDecl* operator->() { return this; }
    bool operator==(const LetDecl&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<LetDecl> from_pod(const Pod& whole);
};


}  // namespace syntax::decls

namespace syntax::decls {

/// `PathSeg`:
///
/// ```prism
/// type PathSeg = choice:
/// ```
class PathSeg {
public:
    using prism_value = void;
    struct PsNum {
        Nat a0;
        bool operator==(const PsNum&) const = default;
    };

    struct PsGen {
        Nat a0;
        bool operator==(const PsGen&) const = default;
    };

    struct PsKey {
        crate::syntax::Expr a0;
        bool operator==(const PsKey&) const = default;
    };
    using Cases = std::variant<PsNum, PsGen, PsKey>;
    template <class C>
        requires prism_rtl::one_of<C, PsNum, PsGen, PsKey>
    PathSeg(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<PathSeg> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const PathSeg& a, const PathSeg& b) { return a.cases() == b.cases(); }

}  // namespace syntax::decls

namespace syntax::decls {

/// `TagDecl`:
///
/// ```prism
/// type TagDecl = record:
/// ```
struct TagDecl {
    using prism_value = void;
    crate::syntax::QualName name;
    crate::syntax::Type of_type;
    Array<Bound> bounds;
    Array<Field> fields;
    crate::syntax::Range span;
    const TagDecl* operator->() const { return this; }
    TagDecl* operator->() { return this; }
    bool operator==(const TagDecl&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TagDecl> from_pod(const Pod& whole);
};


}  // namespace syntax::decls

namespace syntax::decls {

/// `Target`:
///
/// ```prism
/// type Target = choice:
/// ```
class Target {
public:
    using prism_value = void;
    struct TgPattern {
        crate::syntax::Pattern_ a0;
        bool operator==(const TgPattern&) const = default;
    };

    struct TgPath {
        TestPath a0;
        bool operator==(const TgPath&) const = default;
    };

    struct TgElement {
        TestPath a0;
        bool operator==(const TgElement&) const = default;
    };
    using Cases = std::variant<TgPattern, TgPath, TgElement>;
    template <class C>
        requires prism_rtl::one_of<C, TgPattern, TgPath, TgElement>
    Target(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Target> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const Target& a, const Target& b) { return a.cases() == b.cases(); }

}  // namespace syntax::decls

namespace syntax::decls {

/// `TestCheckKind`:
///
/// ```prism
/// type TestCheckKind = choice:
/// ```
class TestCheckKind {
public:
    using prism_value = void;
    struct CkExpect {
        crate::syntax::Pattern_ a0;
        bool operator==(const CkExpect&) const = default;
    };

    struct CkExpectNone {
        crate::syntax::Pattern_ a0;
        bool operator==(const CkExpectNone&) const = default;
    };

    struct CkExpectCount {
        crate::syntax::Pattern_ a0;
        Nat a1;
        bool operator==(const CkExpectCount&) const = default;
    };

    struct CkExpectTop {
        crate::syntax::Pattern_ a0;
        bool operator==(const CkExpectTop&) const = default;
    };

    struct CkExpectTopNone {
        crate::syntax::Pattern_ a0;
        bool operator==(const CkExpectTopNone&) const = default;
    };

    struct CkRequested {
        crate::syntax::Pattern_ a0;
        crate::syntax::Pattern_ a1;
        bool operator==(const CkRequested&) const = default;
    };

    struct CkUnrequested {
        crate::syntax::Pattern_ a0;
        bool operator==(const CkUnrequested&) const = default;
    };

    struct CkReturns {
        crate::syntax::Pattern_ a0;
        bool operator==(const CkReturns&) const = default;
    };

    struct CkFired {
        crate::syntax::Pattern_ a0;
        bool operator==(const CkFired&) const = default;
    };

    struct CkQuiet {
        bool operator==(const CkQuiet&) const = default;
    };

    struct CkSettles {
        bool operator==(const CkSettles&) const = default;
    };

    struct CkAborted {
        bool operator==(const CkAborted&) const = default;
    };

    struct CkSnapshot {
        Text a0;
        bool operator==(const CkSnapshot&) const = default;
    };
    using Cases = std::variant<CkExpect, CkExpectNone, CkExpectCount, CkExpectTop, CkExpectTopNone, CkRequested, CkUnrequested, CkReturns, CkFired, CkQuiet, CkSettles, CkAborted, CkSnapshot>;
    template <class C>
        requires prism_rtl::one_of<C, CkExpect, CkExpectNone, CkExpectCount, CkExpectTop, CkExpectTopNone, CkRequested, CkUnrequested, CkReturns, CkFired, CkQuiet, CkSettles, CkAborted, CkSnapshot>
    TestCheckKind(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TestCheckKind> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const TestCheckKind& a, const TestCheckKind& b) { return a.cases() == b.cases(); }

}  // namespace syntax::decls

namespace syntax::decls {

/// `TestDecl`:
///
/// ```prism
/// type TestDecl = record:
/// ```
struct TestDecl {
    using prism_value = void;
    crate::syntax::Ident name;
    crate::syntax::Expr blueprint;
    std::optional<Nat> seed;
    Array<TestStep> steps;
    crate::syntax::Range span;
    const TestDecl* operator->() const { return this; }
    TestDecl* operator->() { return this; }
    bool operator==(const TestDecl&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TestDecl> from_pod(const Pod& whole);
};


}  // namespace syntax::decls

namespace syntax::decls {

/// `TraitDecl`:
///
/// ```prism
/// type TraitDecl = record:
/// ```
struct TraitDecl {
    using prism_value = void;
    crate::syntax::TraitRef name;
    Array<crate::syntax::Ident> params;
    Array<Bound> bounds;
    Array<TraitItem> items;
    crate::syntax::Range span;
    const TraitDecl* operator->() const { return this; }
    TraitDecl* operator->() { return this; }
    bool operator==(const TraitDecl&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TraitDecl> from_pod(const Pod& whole);
};


}  // namespace syntax::decls

namespace syntax::decls {

/// `WidgetDecl`:
///
/// ```prism
/// type WidgetDecl = record:
/// ```
struct WidgetDecl {
    using prism_value = void;
    crate::syntax::SName name;
    crate::syntax::Block body;
    crate::syntax::Range span;
    const WidgetDecl* operator->() const { return this; }
    WidgetDecl* operator->() { return this; }
    bool operator==(const WidgetDecl&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<WidgetDecl> from_pod(const Pod& whole);
};


}  // namespace syntax::decls

namespace syntax {

/// `ExprKind`:
///
/// ```prism
/// type ExprKind = choice:
/// ```
class ExprKind {
public:
    using prism_value = void;
    struct EName {
        SName a0;
        bool operator==(const EName&) const = default;
    };

    struct ELit {
        Literal a0;
        bool operator==(const ELit&) const = default;
    };

    struct EUnit {
        Text a0;
        bool operator==(const EUnit&) const = default;
    };

    struct ENil {
        Text a0;
        bool operator==(const ENil&) const = default;
    };

    struct EBound {
        Text a0;
        bool operator==(const EBound&) const = default;
    };

    struct ETuple {
        Array<Expr> a0;
        bool operator==(const ETuple&) const;
    };

    struct EArray {
        Array<Expr> a0;
        bool operator==(const EArray&) const;
    };

    struct EMap {
        Array<std::tuple<Expr, Expr>> a0;
        bool operator==(const EMap&) const;
    };

    struct EGroup {
        prism_rtl::Val<Expr> a0;
        bool operator==(const EGroup&) const;
    };

    struct ECall {
        prism_rtl::Val<Expr> a0;
        Array<Arg> a1;
        bool a2;
        bool a3;
        bool operator==(const ECall&) const;
    };

    struct EBinary {
        Text a0;
        prism_rtl::Val<Expr> a1;
        prism_rtl::Val<Expr> a2;
        bool operator==(const EBinary&) const;
    };

    struct EUnary {
        Text a0;
        prism_rtl::Val<Expr> a1;
        bool operator==(const EUnary&) const;
    };

    struct ESuffixed {
        Text a0;
        QualName a1;
        prism_rtl::Val<Expr> a2;
        prism_rtl::Val<Expr> a3;
        bool operator==(const ESuffixed&) const;
    };

    struct EFreeSigil {
        Text a0;
        prism_rtl::Val<Expr> a1;
        bool operator==(const EFreeSigil&) const;
    };

    struct EField {
        prism_rtl::Val<Expr> a0;
        Text a1;
        Ident a2;
        bool operator==(const EField&) const;
    };

    struct EIndex {
        prism_rtl::Val<Expr> a0;
        prism_rtl::Val<Expr> a1;
        bool operator==(const EIndex&) const;
    };

    struct ETopicField {
        Ident a0;
        bool operator==(const ETopicField&) const = default;
    };

    struct ETopicIndex {
        prism_rtl::Val<Expr> a0;
        bool operator==(const ETopicIndex&) const;
    };

    struct EMethod {
        prism_rtl::Val<Expr> a0;
        SName a1;
        Array<Arg> a2;
        bool operator==(const EMethod&) const;
    };

    struct ETypeArgs {
        prism_rtl::Val<Expr> a0;
        Array<Type> a1;
        bool operator==(const ETypeArgs&) const;
    };

    struct ECast {
        prism_rtl::Val<Expr> a0;
        Type a1;
        bool a2;
        bool operator==(const ECast&) const;
    };

    struct ENonEmpty {
        prism_rtl::Val<Expr> a0;
        bool operator==(const ENonEmpty&) const;
    };

    struct EAbsent {
        bool operator==(const EAbsent&) const = default;
    };

    struct ERest {
        bool operator==(const ERest&) const = default;
    };

    struct ELambda {
        std::optional<Array<Pattern_>> a0;
        prism_rtl::Val<LambdaBody> a1;
        bool operator==(const ELambda&) const;
    };

    struct EIf {
        prism_rtl::Val<Cond> a0;
        Block a1;
        std::optional<Block> a2;
        bool operator==(const EIf&) const;
    };

    struct EMatch {
        prism_rtl::Val<Expr> a0;
        Array<Arm> a1;
        bool operator==(const EMatch&) const;
    };

    struct ERebuild {
        prism_rtl::Val<Expr> a0;
        Block a1;
        bool operator==(const ERebuild&) const;
    };

    struct EFor {
        std::optional<ForBinders> a0;
        prism_rtl::Val<Expr> a1;
        Block a2;
        bool operator==(const EFor&) const;
    };

    struct EGiven {
        Block a0;
        bool operator==(const EGiven&) const = default;
    };

    struct EUpdate {
        prism_rtl::Val<Expr> a0;
        Block a1;
        bool operator==(const EUpdate&) const;
    };

    struct EWidgetBlock {
        Block a0;
        bool operator==(const EWidgetBlock&) const = default;
    };

    struct EMonad {
        prism_rtl::Val<Expr> a0;
        Block a1;
        bool operator==(const EMonad&) const;
    };

    struct ETemplate {
        Template a0;
        bool operator==(const ETemplate&) const = default;
    };

    struct EAny {
        prism_rtl::Val<Expr> a0;
        bool operator==(const EAny&) const;
    };

    struct ELens {
        Array<Ident> a0;
        bool operator==(const ELens&) const;
    };

    struct EError {
        bool operator==(const EError&) const = default;
    };
    using Cases = std::variant<EName, ELit, EUnit, ENil, EBound, ETuple, EArray, EMap, EGroup, ECall, EBinary, EUnary, ESuffixed, EFreeSigil, EField, EIndex, ETopicField, ETopicIndex, EMethod, ETypeArgs, ECast, ENonEmpty, EAbsent, ERest, ELambda, EIf, EMatch, ERebuild, EFor, EGiven, EUpdate, EWidgetBlock, EMonad, ETemplate, EAny, ELens, EError>;
    template <class C>
        requires prism_rtl::one_of<C, EName, ELit, EUnit, ENil, EBound, ETuple, EArray, EMap, EGroup, ECall, EBinary, EUnary, ESuffixed, EFreeSigil, EField, EIndex, ETopicField, ETopicIndex, EMethod, ETypeArgs, ECast, ENonEmpty, EAbsent, ERest, ELambda, EIf, EMatch, ERebuild, EFor, EGiven, EUpdate, EWidgetBlock, EMonad, ETemplate, EAny, ELens, EError>
    ExprKind(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ExprKind> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const ExprKind& a, const ExprKind& b) { return a.cases() == b.cases(); }

}  // namespace syntax

namespace syntax {

/// `PatternKind`:
///
/// ```prism
/// type PatternKind = choice:
/// ```
class PatternKind {
public:
    using prism_value = void;
    struct PName {
        SName a0;
        bool operator==(const PName&) const = default;
    };

    struct PIgnore {
        bool operator==(const PIgnore&) const = default;
    };

    struct PLit {
        Literal a0;
        bool operator==(const PLit&) const = default;
    };

    struct PNeg {
        Literal a0;
        bool operator==(const PNeg&) const = default;
    };

    struct PUnit {
        bool operator==(const PUnit&) const = default;
    };

    struct PNil {
        bool operator==(const PNil&) const = default;
    };

    struct PCtor {
        SName a0;
        Array<Pattern_> a1;
        bool operator==(const PCtor&) const;
    };

    struct PRecord {
        SName a0;
        Array<FieldPat> a1;
        bool a2;
        bool operator==(const PRecord&) const;
    };

    struct PSigil {
        Text a0;
        prism_rtl::Val<Pattern_> a1;
        bool operator==(const PSigil&) const;
    };

    struct PTuple {
        Array<Pattern_> a0;
        bool operator==(const PTuple&) const;
    };

    struct PArray {
        Array<Pattern_> a0;
        bool operator==(const PArray&) const;
    };

    struct PGroup {
        prism_rtl::Val<Pattern_> a0;
        bool operator==(const PGroup&) const;
    };

    struct PFamily {
        QualName a0;
        bool operator==(const PFamily&) const = default;
    };
    using Cases = std::variant<PName, PIgnore, PLit, PNeg, PUnit, PNil, PCtor, PRecord, PSigil, PTuple, PArray, PGroup, PFamily>;
    template <class C>
        requires prism_rtl::one_of<C, PName, PIgnore, PLit, PNeg, PUnit, PNil, PCtor, PRecord, PSigil, PTuple, PArray, PGroup, PFamily>
    PatternKind(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<PatternKind> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const PatternKind& a, const PatternKind& b) { return a.cases() == b.cases(); }

}  // namespace syntax

namespace syntax {

/// `TypeKind`:
///
/// ```prism
/// type TypeKind = choice:
/// ```
class TypeKind {
public:
    using prism_value = void;
    struct TName {
        SName a0;
        Array<Type> a1;
        bool operator==(const TName&) const;
    };

    struct TSigiled {
        Text a0;
        prism_rtl::Val<Type> a1;
        bool operator==(const TSigiled&) const;
    };

    struct TArray {
        prism_rtl::Val<Type> a0;
        bool a1;
        bool operator==(const TArray&) const;
    };

    struct TTuple {
        Array<Type> a0;
        bool operator==(const TTuple&) const;
    };

    struct TGroup {
        prism_rtl::Val<Type> a0;
        bool operator==(const TGroup&) const;
    };

    struct TMap {
        prism_rtl::Val<Type> a0;
        prism_rtl::Val<Type> a1;
        bool operator==(const TMap&) const;
    };

    struct TFn {
        Color a0;
        Array<Type> a1;
        prism_rtl::Val<Type> a2;
        bool operator==(const TFn&) const;
    };

    struct TEmit {
        prism_rtl::Val<Type> a0;
        prism_rtl::Val<Type> a1;
        bool operator==(const TEmit&) const;
    };

    struct TRowUnion {
        Array<Type> a0;
        bool operator==(const TRowUnion&) const;
    };

    struct TFamily {
        QualName a0;
        bool operator==(const TFamily&) const = default;
    };

    struct TAny {
        TraitRef a0;
        bool operator==(const TAny&) const = default;
    };

    struct TUnit {
        Text a0;
        bool operator==(const TUnit&) const = default;
    };

    struct THole {
        SName a0;
        bool operator==(const THole&) const = default;
    };

    struct TAbsent {
        bool operator==(const TAbsent&) const = default;
    };

    struct TNonEmpty {
        prism_rtl::Val<Type> a0;
        bool operator==(const TNonEmpty&) const;
    };
    using Cases = std::variant<TName, TSigiled, TArray, TTuple, TGroup, TMap, TFn, TEmit, TRowUnion, TFamily, TAny, TUnit, THole, TAbsent, TNonEmpty>;
    template <class C>
        requires prism_rtl::one_of<C, TName, TSigiled, TArray, TTuple, TGroup, TMap, TFn, TEmit, TRowUnion, TFamily, TAny, TUnit, THole, TAbsent, TNonEmpty>
    TypeKind(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TypeKind> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const TypeKind& a, const TypeKind& b) { return a.cases() == b.cases(); }

}  // namespace syntax

namespace syntax::decls {

/// `Delivery`:
///
/// ```prism
/// type Delivery = record:
/// ```
struct Delivery {
    using prism_value = void;
    DeliveryKind kind;
    Target target;
    crate::syntax::Range span;
    const Delivery* operator->() const { return this; }
    Delivery* operator->() { return this; }
    bool operator==(const Delivery&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Delivery> from_pod(const Pod& whole);
};


}  // namespace syntax::decls

namespace syntax::decls {

/// `FnClause`:
///
/// ```prism
/// type FnClause = record:
/// ```
struct FnClause {
    using prism_value = void;
    DefName name;
    Array<crate::syntax::Pattern_> params;
    FnBody body;
    crate::syntax::Range span;
    const FnClause* operator->() const { return this; }
    FnClause* operator->() { return this; }
    bool operator==(const FnClause&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<FnClause> from_pod(const Pod& whole);
};


}  // namespace syntax::decls

namespace syntax::decls {

/// `Signature`:
///
/// ```prism
/// type Signature = record:
/// ```
struct Signature {
    using prism_value = void;
    DefName name;
    crate::syntax::Type ty;
    Array<Bound> bounds;
    crate::syntax::Range span;
    const Signature* operator->() const { return this; }
    Signature* operator->() { return this; }
    bool operator==(const Signature&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Signature> from_pod(const Pod& whole);
};


}  // namespace syntax::decls

namespace syntax::decls {

/// `StepAction`:
///
/// ```prism
/// type StepAction = choice:
/// ```
class StepAction {
public:
    using prism_value = void;
    struct SaBuild {
        bool operator==(const SaBuild&) const = default;
    };

    struct SaTick {
        bool operator==(const SaTick&) const = default;
    };

    struct SaCompute {
        bool a0;
        bool operator==(const SaCompute&) const = default;
    };

    struct SaPush {
        Entry a0;
        bool operator==(const SaPush&) const = default;
    };

    struct SaDeliver {
        Array<Delivery> a0;
        bool operator==(const SaDeliver&) const;
    };

    struct SaWithOnly {
        bool operator==(const SaWithOnly&) const = default;
    };
    using Cases = std::variant<SaBuild, SaTick, SaCompute, SaPush, SaDeliver, SaWithOnly>;
    template <class C>
        requires prism_rtl::one_of<C, SaBuild, SaTick, SaCompute, SaPush, SaDeliver, SaWithOnly>
    StepAction(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<StepAction> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const StepAction& a, const StepAction& b) { return a.cases() == b.cases(); }

}  // namespace syntax::decls

namespace syntax::decls {

/// `TestCheck`:
///
/// ```prism
/// type TestCheck = record:
/// ```
struct TestCheck {
    using prism_value = void;
    TestCheckKind kind;
    crate::syntax::Range span;
    const TestCheck* operator->() const { return this; }
    TestCheck* operator->() { return this; }
    bool operator==(const TestCheck&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TestCheck> from_pod(const Pod& whole);
};


}  // namespace syntax::decls

namespace syntax::decls {

/// `TypeBody`:
///
/// ```prism
/// type TypeBody = choice:
/// ```
class TypeBody {
public:
    using prism_value = void;
    struct TbRecord {
        Array<Field> a0;
        bool operator==(const TbRecord&) const;
    };

    struct TbChoice {
        Array<Case_> a0;
        bool operator==(const TbChoice&) const;
    };

    struct TbRow {
        bool operator==(const TbRow&) const = default;
    };

    struct TbNewtype {
        Case_ a0;
        bool operator==(const TbNewtype&) const = default;
    };

    struct TbUnit {
        crate::syntax::Ident a0;
        bool operator==(const TbUnit&) const = default;
    };

    struct TbAlias {
        crate::syntax::Type a0;
        bool operator==(const TbAlias&) const = default;
    };
    using Cases = std::variant<TbRecord, TbChoice, TbRow, TbNewtype, TbUnit, TbAlias>;
    template <class C>
        requires prism_rtl::one_of<C, TbRecord, TbChoice, TbRow, TbNewtype, TbUnit, TbAlias>
    TypeBody(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TypeBody> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const TypeBody& a, const TypeBody& b) { return a.cases() == b.cases(); }

}  // namespace syntax::decls

namespace syntax {

/// `StmtKind`:
///
/// ```prism
/// type StmtKind = choice:
/// ```
class StmtKind {
public:
    using prism_value = void;
    struct SEmit {
        Row_ a0;
        bool operator==(const SEmit&) const = default;
    };

    struct SBind {
        Pattern_ a0;
        Expr a1;
        std::optional<Expr> a2;
        bool operator==(const SBind&) const = default;
    };

    struct SIgnore {
        Expr a0;
        bool operator==(const SIgnore&) const = default;
    };

    struct SLet {
        Pattern_ a0;
        std::optional<Type> a1;
        Expr a2;
        bool operator==(const SLet&) const = default;
    };

    struct SSignature {
        crate::syntax::decls::Signature a0;
        bool operator==(const SSignature&) const = default;
    };

    struct SFn {
        crate::syntax::decls::FnClause a0;
        bool operator==(const SFn&) const = default;
    };

    struct SWidget {
        crate::syntax::decls::WidgetDecl a0;
        bool operator==(const SWidget&) const = default;
    };

    struct SSet {
        Expr a0;
        Expr a1;
        bool operator==(const SSet&) const = default;
    };

    struct SAccum {
        Expr a0;
        Text a1;
        Expr a2;
        bool operator==(const SAccum&) const = default;
    };

    struct SRequire {
        Expr a0;
        bool operator==(const SRequire&) const = default;
    };

    struct SForbid {
        Expr a0;
        bool operator==(const SForbid&) const = default;
    };

    struct SWhile {
        Cond a0;
        Block a1;
        bool operator==(const SWhile&) const = default;
    };

    struct SReturn {
        Expr a0;
        bool operator==(const SReturn&) const = default;
    };

    struct SExpr {
        Expr a0;
        bool operator==(const SExpr&) const = default;
    };
    using Cases = std::variant<SEmit, SBind, SIgnore, SLet, SSignature, SFn, SWidget, SSet, SAccum, SRequire, SForbid, SWhile, SReturn, SExpr>;
    template <class C>
        requires prism_rtl::one_of<C, SEmit, SBind, SIgnore, SLet, SSignature, SFn, SWidget, SSet, SAccum, SRequire, SForbid, SWhile, SReturn, SExpr>
    StmtKind(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<StmtKind> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const StmtKind& a, const StmtKind& b) { return a.cases() == b.cases(); }

}  // namespace syntax

namespace syntax::decls {

/// `TestStep`:
///
/// ```prism
/// type TestStep = record:
/// ```
struct TestStep {
    using prism_value = void;
    Array<Entry> withs;
    StepAction action;
    Array<TestCheck> checks;
    crate::syntax::Range span;
    const TestStep* operator->() const { return this; }
    TestStep* operator->() { return this; }
    bool operator==(const TestStep&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TestStep> from_pod(const Pod& whole);
};


}  // namespace syntax::decls

namespace syntax::decls {

/// `TraitItem`:
///
/// ```prism
/// type TraitItem = choice:
/// ```
class TraitItem {
public:
    using prism_value = void;
    struct TiSignature {
        Signature a0;
        bool operator==(const TiSignature&) const = default;
    };

    struct TiFn {
        FnClause a0;
        bool operator==(const TiFn&) const = default;
    };

    struct TiAssocType {
        crate::syntax::Ident a0;
        Array<crate::syntax::Ident> a1;
        std::optional<crate::syntax::Type> a2;
        crate::syntax::Range a3;
        bool operator==(const TiAssocType&) const;
    };

    struct TiAssocRow {
        crate::syntax::SName a0;
        crate::syntax::Range a1;
        bool operator==(const TiAssocRow&) const = default;
    };
    using Cases = std::variant<TiSignature, TiFn, TiAssocType, TiAssocRow>;
    template <class C>
        requires prism_rtl::one_of<C, TiSignature, TiFn, TiAssocType, TiAssocRow>
    TraitItem(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TraitItem> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const TraitItem& a, const TraitItem& b) { return a.cases() == b.cases(); }

}  // namespace syntax::decls

namespace syntax::decls {

/// `TypeDecl`:
///
/// ```prism
/// type TypeDecl = record:
/// ```
struct TypeDecl {
    using prism_value = void;
    crate::syntax::QualName name;
    Array<crate::syntax::Ident> params;
    std::optional<TypeBody> body;
    crate::syntax::Range span;
    const TypeDecl* operator->() const { return this; }
    TypeDecl* operator->() { return this; }
    bool operator==(const TypeDecl&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TypeDecl> from_pod(const Pod& whole);
};


}  // namespace syntax::decls

namespace syntax {

/// `Stmt`:
///
/// ```prism
/// type Stmt = record:
/// ```
struct Stmt {
    using prism_value = void;
    StmtKind kind;
    Range span;
    const Stmt* operator->() const { return this; }
    Stmt* operator->() { return this; }
    bool operator==(const Stmt&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Stmt> from_pod(const Pod& whole);
};


}  // namespace syntax

namespace syntax::decls {

/// `DeclKind`:
///
/// ```prism
/// type DeclKind = choice:
/// ```
class DeclKind {
public:
    using prism_value = void;
    struct DSignature {
        Signature a0;
        bool operator==(const DSignature&) const = default;
    };

    struct DFn {
        FnClause a0;
        bool operator==(const DFn&) const = default;
    };

    struct DLet {
        LetDecl a0;
        bool operator==(const DLet&) const = default;
    };

    struct DWidget {
        WidgetDecl a0;
        bool operator==(const DWidget&) const = default;
    };

    struct DType {
        TypeDecl a0;
        bool operator==(const DType&) const = default;
    };

    struct DTag {
        TagDecl a0;
        bool operator==(const DTag&) const = default;
    };

    struct DDerive {
        Array<crate::syntax::TraitRef> a0;
        bool operator==(const DDerive&) const;
    };

    struct DTrait {
        TraitDecl a0;
        bool operator==(const DTrait&) const = default;
    };

    struct DImpl {
        ImplDecl a0;
        bool operator==(const DImpl&) const = default;
    };

    struct DCheck {
        CheckDecl a0;
        bool operator==(const DCheck&) const = default;
    };

    struct DTest {
        TestDecl a0;
        bool operator==(const DTest&) const = default;
    };

    struct DStmt {
        crate::syntax::Stmt a0;
        bool operator==(const DStmt&) const = default;
    };
    using Cases = std::variant<DSignature, DFn, DLet, DWidget, DType, DTag, DDerive, DTrait, DImpl, DCheck, DTest, DStmt>;
    template <class C>
        requires prism_rtl::one_of<C, DSignature, DFn, DLet, DWidget, DType, DTag, DDerive, DTrait, DImpl, DCheck, DTest, DStmt>
    DeclKind(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<DeclKind> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const DeclKind& a, const DeclKind& b) { return a.cases() == b.cases(); }

}  // namespace syntax::decls

namespace syntax::decls {

/// `Decl`:
///
/// ```prism
/// type Decl = record:
/// ```
struct Decl {
    using prism_value = void;
    DeclKind kind;
    crate::syntax::Range span;
    const Decl* operator->() const { return this; }
    Decl* operator->() { return this; }
    bool operator==(const Decl&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Decl> from_pod(const Pod& whole);
};


}  // namespace syntax::decls

}  // namespace crate
