// The module `Lower`, from `target/bootstrap/cpp-src/prismc/lower.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include "lower.hpp"
#include "ast.hpp"
#include "check_env.hpp"
#include "check_errors.hpp"
#include "check_types.hpp"
#include "lexer.hpp"
#include "typed.hpp"
#include "lower.generic.hpp"
#include "check_env.generic.hpp"
#include "lexer.generic.hpp"

namespace crate::lower {

void AnswerCase::show(Printer& p) const {
    p.record("AnswerCase", {{"variant", variant}, {"accessor", accessor}, {"struct_path", struct_path}, {"tag_name", tag_name}, {"ty", ty}});
}

Pod AnswerCase::to_pod() const {
    return Pod::record("AnswerCase", {{"variant", prism_rtl::to_pod(variant)}, {"accessor", prism_rtl::to_pod(accessor)}, {"struct_path", prism_rtl::to_pod(struct_path)}, {"tag_name", prism_rtl::to_pod(tag_name)}, {"ty", prism_rtl::to_pod(ty)}});
}

Result<AnswerCase> AnswerCase::from_pod(const Pod& whole) {
    return AnswerCase{.variant = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "variant")))), .accessor = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "accessor")))), .struct_path = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "struct_path")))), .tag_name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "tag_name")))), .ty = TRY(prism_rtl::from_pod<OutTy>(TRY(prelude::field(whole, "ty"))))};
}


void AnswerDef::show(Printer& p) const {
    p.record("AnswerDef", {{"cases", cases_}});
}

Pod AnswerDef::to_pod() const {
    return Pod::record("AnswerDef", {{"cases", prism_rtl::to_pod(cases_)}});
}

Result<AnswerDef> AnswerDef::from_pod(const Pod& whole) {
    return AnswerDef{.cases_ = TRY(prism_rtl::from_pod<Array<AnswerCase>>(TRY(prelude::field(whole, "cases"))))};
}




void CaseDef::show(Printer& p) const {
    p.record("CaseDef", {{"name", name}, {"prism", prism}, {"fields", fields}});
}

Pod CaseDef::to_pod() const {
    return Pod::record("CaseDef", {{"name", prism_rtl::to_pod(name)}, {"prism", prism_rtl::to_pod(prism)}, {"fields", prism_rtl::to_pod(fields)}});
}

Result<CaseDef> CaseDef::from_pod(const Pod& whole) {
    return CaseDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .prism = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "prism")))), .fields = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy>>>(TRY(prelude::field(whole, "fields"))))};
}


void Cc::show(Printer& p) const {
    if (auto c = std::get_if<CcIf>(&cases())) p.choice("CcIf", {c->a0});
    else if (auto c = std::get_if<CcLet>(&cases())) p.choice("CcLet", {c->a0, c->a1});
}

Pod Cc::to_pod() const {
    return std::holds_alternative<CcIf>(cases()) ? Pod::choice("CcIf", {prism_rtl::to_pod(std::get<CcIf>(cases()).a0)})
        : std::holds_alternative<CcLet>(cases()) ? Pod::choice("CcLet", {prism_rtl::to_pod(std::get<CcLet>(cases()).a0), prism_rtl::to_pod(std::get<CcLet>(cases()).a1)})
        : Pod();
}

Result<Cc> Cc::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "CcIf" && c->args.size() == 1) return Cc(CcIf{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "CcLet" && c->args.size() == 2) return Cc(CcLet{TRY(prism_rtl::from_pod<Pa>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1]))});
    }
    return mismatch<Cc>("a Cc", p);
}


void CheckDef::show(Printer& p) const {
    p.record("CheckDef", {{"name", name}, {"lines", lines}});
}

Pod CheckDef::to_pod() const {
    return Pod::record("CheckDef", {{"name", prism_rtl::to_pod(name)}, {"lines", prism_rtl::to_pod(lines)}});
}

Result<CheckDef> CheckDef::from_pod(const Pod& whole) {
    return CheckDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .lines = TRY(prism_rtl::from_pod<Array<Ex>>(TRY(prelude::field(whole, "lines"))))};
}




void CxArg::show(Printer& p) const {
    if (auto c = std::get_if<CxMut>(&cases())) p.choice("CxMut", {});
    else if (auto c = std::get_if<CxRef>(&cases())) p.choice("CxRef", {});
    else if (auto c = std::get_if<CxNone>(&cases())) p.choice("CxNone", {});
}

Pod CxArg::to_pod() const {
    return std::holds_alternative<CxMut>(cases()) ? Pod::choice("CxMut", {})
        : std::holds_alternative<CxRef>(cases()) ? Pod::choice("CxRef", {})
        : std::holds_alternative<CxNone>(cases()) ? Pod::choice("CxNone", {})
        : Pod();
}

Result<CxArg> CxArg::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "CxMut" && c->args.size() == 0) return CxArg(CxMut{});
        if (c->ctor == "CxRef" && c->args.size() == 0) return CxArg(CxRef{});
        if (c->ctor == "CxNone" && c->args.size() == 0) return CxArg(CxNone{});
    }
    return mismatch<CxArg>("a CxArg", p);
}


void Do::show(Printer& p) const {
    if (auto c = std::get_if<DoLet>(&cases())) p.choice("DoLet", {c->a0, c->a1});
    else if (auto c = std::get_if<DoLetElse>(&cases())) p.choice("DoLetElse", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<DoAssign>(&cases())) p.choice("DoAssign", {c->a0, c->a1});
    else if (auto c = std::get_if<DoWhile>(&cases())) p.choice("DoWhile", {c->a0, c->a1});
    else if (auto c = std::get_if<DoWhileLet>(&cases())) p.choice("DoWhileLet", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<DoFor>(&cases())) p.choice("DoFor", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<DoExpr>(&cases())) p.choice("DoExpr", {c->a0});
    else if (auto c = std::get_if<DoIf>(&cases())) p.choice("DoIf", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<DoIfLet>(&cases())) p.choice("DoIfLet", {c->a0, c->a1, c->a2, c->a3});
    else if (auto c = std::get_if<DoMatch>(&cases())) p.choice("DoMatch", {c->a0, c->a1});
    else if (auto c = std::get_if<DoReturn>(&cases())) p.choice("DoReturn", {c->a0});
    else if (auto c = std::get_if<DoBlock>(&cases())) p.choice("DoBlock", {c->a0});
    else if (auto c = std::get_if<DoScope>(&cases())) p.choice("DoScope", {c->a0});
    else if (auto c = std::get_if<DoLine>(&cases())) p.choice("DoLine", {c->a0});
    else if (auto c = std::get_if<DoNote>(&cases())) p.choice("DoNote", {c->a0});
}

Pod Do::to_pod() const {
    return std::holds_alternative<DoLet>(cases()) ? Pod::choice("DoLet", {prism_rtl::to_pod(std::get<DoLet>(cases()).a0), prism_rtl::to_pod(std::get<DoLet>(cases()).a1)})
        : std::holds_alternative<DoLetElse>(cases()) ? Pod::choice("DoLetElse", {prism_rtl::to_pod(std::get<DoLetElse>(cases()).a0), prism_rtl::to_pod(std::get<DoLetElse>(cases()).a1), prism_rtl::to_pod(std::get<DoLetElse>(cases()).a2)})
        : std::holds_alternative<DoAssign>(cases()) ? Pod::choice("DoAssign", {prism_rtl::to_pod(std::get<DoAssign>(cases()).a0), prism_rtl::to_pod(std::get<DoAssign>(cases()).a1)})
        : std::holds_alternative<DoWhile>(cases()) ? Pod::choice("DoWhile", {prism_rtl::to_pod(std::get<DoWhile>(cases()).a0), prism_rtl::to_pod(std::get<DoWhile>(cases()).a1)})
        : std::holds_alternative<DoWhileLet>(cases()) ? Pod::choice("DoWhileLet", {prism_rtl::to_pod(std::get<DoWhileLet>(cases()).a0), prism_rtl::to_pod(std::get<DoWhileLet>(cases()).a1), prism_rtl::to_pod(std::get<DoWhileLet>(cases()).a2)})
        : std::holds_alternative<DoFor>(cases()) ? Pod::choice("DoFor", {prism_rtl::to_pod(std::get<DoFor>(cases()).a0), prism_rtl::to_pod(std::get<DoFor>(cases()).a1), prism_rtl::to_pod(std::get<DoFor>(cases()).a2)})
        : std::holds_alternative<DoExpr>(cases()) ? Pod::choice("DoExpr", {prism_rtl::to_pod(std::get<DoExpr>(cases()).a0)})
        : std::holds_alternative<DoIf>(cases()) ? Pod::choice("DoIf", {prism_rtl::to_pod(std::get<DoIf>(cases()).a0), prism_rtl::to_pod(std::get<DoIf>(cases()).a1), prism_rtl::to_pod(std::get<DoIf>(cases()).a2)})
        : std::holds_alternative<DoIfLet>(cases()) ? Pod::choice("DoIfLet", {prism_rtl::to_pod(std::get<DoIfLet>(cases()).a0), prism_rtl::to_pod(std::get<DoIfLet>(cases()).a1), prism_rtl::to_pod(std::get<DoIfLet>(cases()).a2), prism_rtl::to_pod(std::get<DoIfLet>(cases()).a3)})
        : std::holds_alternative<DoMatch>(cases()) ? Pod::choice("DoMatch", {prism_rtl::to_pod(std::get<DoMatch>(cases()).a0), prism_rtl::to_pod(std::get<DoMatch>(cases()).a1)})
        : std::holds_alternative<DoReturn>(cases()) ? Pod::choice("DoReturn", {prism_rtl::to_pod(std::get<DoReturn>(cases()).a0)})
        : std::holds_alternative<DoBlock>(cases()) ? Pod::choice("DoBlock", {prism_rtl::to_pod(std::get<DoBlock>(cases()).a0)})
        : std::holds_alternative<DoScope>(cases()) ? Pod::choice("DoScope", {prism_rtl::to_pod(std::get<DoScope>(cases()).a0)})
        : std::holds_alternative<DoLine>(cases()) ? Pod::choice("DoLine", {prism_rtl::to_pod(std::get<DoLine>(cases()).a0)})
        : std::holds_alternative<DoNote>(cases()) ? Pod::choice("DoNote", {prism_rtl::to_pod(std::get<DoNote>(cases()).a0)})
        : Pod();
}

Result<Do> Do::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "DoLet" && c->args.size() == 2) return Do(DoLet{TRY(prism_rtl::from_pod<Pa>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1]))});
        if (c->ctor == "DoLetElse" && c->args.size() == 3) return Do(DoLetElse{TRY(prism_rtl::from_pod<Pa>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1])), TRY(prism_rtl::from_pod<Ex>(c->args[2]))});
        if (c->ctor == "DoAssign" && c->args.size() == 2) return Do(DoAssign{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1]))});
        if (c->ctor == "DoWhile" && c->args.size() == 2) return Do(DoWhile{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[1]))});
        if (c->ctor == "DoWhileLet" && c->args.size() == 3) return Do(DoWhileLet{TRY(prism_rtl::from_pod<Pa>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[2]))});
        if (c->ctor == "DoFor" && c->args.size() == 3) return Do(DoFor{TRY(prism_rtl::from_pod<Pa>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[2]))});
        if (c->ctor == "DoExpr" && c->args.size() == 1) return Do(DoExpr{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "DoIf" && c->args.size() == 3) return Do(DoIf{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[1])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[2]))});
        if (c->ctor == "DoIfLet" && c->args.size() == 4) return Do(DoIfLet{TRY(prism_rtl::from_pod<Pa>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[2])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[3]))});
        if (c->ctor == "DoMatch" && c->args.size() == 2) return Do(DoMatch{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Array<std::tuple<Pa, Array<Do>>>>(c->args[1]))});
        if (c->ctor == "DoReturn" && c->args.size() == 1) return Do(DoReturn{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "DoBlock" && c->args.size() == 1) return Do(DoBlock{TRY(prism_rtl::from_pod<Array<Do>>(c->args[0]))});
        if (c->ctor == "DoScope" && c->args.size() == 1) return Do(DoScope{TRY(prism_rtl::from_pod<Array<Do>>(c->args[0]))});
        if (c->ctor == "DoLine" && c->args.size() == 1) return Do(DoLine{TRY(prism_rtl::from_pod<Array<Do>>(c->args[0]))});
        if (c->ctor == "DoNote" && c->args.size() == 1) return Do(DoNote{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Do>("a Do", p);
}






void Ex::show(Printer& p) const {
    if (auto c = std::get_if<XVar>(&cases())) p.choice("XVar", {c->a0});
    else if (auto c = std::get_if<XPath>(&cases())) p.choice("XPath", {c->a0});
    else if (auto c = std::get_if<XSelf>(&cases())) p.choice("XSelf", {});
    else if (auto c = std::get_if<XCx>(&cases())) p.choice("XCx", {});
    else if (auto c = std::get_if<XConst>(&cases())) p.choice("XConst", {c->a0});
    else if (auto c = std::get_if<XUnit>(&cases())) p.choice("XUnit", {});
    else if (auto c = std::get_if<XNone>(&cases())) p.choice("XNone", {});
    else if (auto c = std::get_if<XBool>(&cases())) p.choice("XBool", {c->a0});
    else if (auto c = std::get_if<XNat>(&cases())) p.choice("XNat", {c->a0});
    else if (auto c = std::get_if<XInt>(&cases())) p.choice("XInt", {c->a0});
    else if (auto c = std::get_if<XByte>(&cases())) p.choice("XByte", {c->a0});
    else if (auto c = std::get_if<XFloat>(&cases())) p.choice("XFloat", {c->a0});
    else if (auto c = std::get_if<XIndex>(&cases())) p.choice("XIndex", {c->a0});
    else if (auto c = std::get_if<XChar>(&cases())) p.choice("XChar", {c->a0});
    else if (auto c = std::get_if<XStr>(&cases())) p.choice("XStr", {c->a0});
    else if (auto c = std::get_if<XRef>(&cases())) p.choice("XRef", {c->a0});
    else if (auto c = std::get_if<XRefMut>(&cases())) p.choice("XRefMut", {c->a0});
    else if (auto c = std::get_if<XDeref>(&cases())) p.choice("XDeref", {c->a0});
    else if (auto c = std::get_if<XTarget>(&cases())) p.choice("XTarget", {c->a0});
    else if (auto c = std::get_if<XClone>(&cases())) p.choice("XClone", {c->a0});
    else if (auto c = std::get_if<XWeak>(&cases())) p.choice("XWeak", {c->a0});
    else if (auto c = std::get_if<XUpgrade>(&cases())) p.choice("XUpgrade", {c->a0});
    else if (auto c = std::get_if<XBreak>(&cases())) p.choice("XBreak", {c->a0, c->a1});
    else if (auto c = std::get_if<XBreakLoop>(&cases())) p.choice("XBreakLoop", {});
    else if (auto c = std::get_if<XLater>(&cases())) p.choice("XLater", {c->a0});
    else if (auto c = std::get_if<XFormatStr>(&cases())) p.choice("XFormatStr", {c->a0});
    else if (auto c = std::get_if<XIsCase>(&cases())) p.choice("XIsCase", {c->a0, c->a1});
    else if (auto c = std::get_if<XRefusal>(&cases())) p.choice("XRefusal", {c->a0});
    else if (auto c = std::get_if<XUnreachable>(&cases())) p.choice("XUnreachable", {});
    else if (auto c = std::get_if<XCall>(&cases())) p.choice("XCall", {c->a0, c->a1});
    else if (auto c = std::get_if<XApply>(&cases())) p.choice("XApply", {c->a0, c->a1});
    else if (auto c = std::get_if<XMethod>(&cases())) p.choice("XMethod", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<XBin>(&cases())) p.choice("XBin", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<XUnary>(&cases())) p.choice("XUnary", {c->a0, c->a1});
    else if (auto c = std::get_if<XCtor>(&cases())) p.choice("XCtor", {c->a0, c->a1});
    else if (auto c = std::get_if<XRecord>(&cases())) p.choice("XRecord", {c->a0, c->a1});
    else if (auto c = std::get_if<XTuple>(&cases())) p.choice("XTuple", {c->a0});
    else if (auto c = std::get_if<XVec>(&cases())) p.choice("XVec", {c->a0});
    else if (auto c = std::get_if<XText>(&cases())) p.choice("XText", {c->a0});
    else if (auto c = std::get_if<XFormat>(&cases())) p.choice("XFormat", {c->a0});
    else if (auto c = std::get_if<XMatch>(&cases())) p.choice("XMatch", {c->a0, c->a1, c->a2, c->a3});
    else if (auto c = std::get_if<XChain>(&cases())) p.choice("XChain", {c->a0, c->a1, c->a2, c->a3});
    else if (auto c = std::get_if<XIf>(&cases())) p.choice("XIf", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<XBlock>(&cases())) p.choice("XBlock", {c->a0, c->a1});
    else if (auto c = std::get_if<XLabeled>(&cases())) p.choice("XLabeled", {c->a0, c->a1, c->a2, c->a3});
    else if (auto c = std::get_if<XClosure>(&cases())) p.choice("XClosure", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<XTry>(&cases())) p.choice("XTry", {c->a0});
    else if (auto c = std::get_if<XField>(&cases())) p.choice("XField", {c->a0, c->a1});
    else if (auto c = std::get_if<XPart>(&cases())) p.choice("XPart", {c->a0, c->a1});
    else if (auto c = std::get_if<XDecode>(&cases())) p.choice("XDecode", {c->a0, c->a1});
    else if (auto c = std::get_if<XCast>(&cases())) p.choice("XCast", {c->a0, c->a1});
    else if (auto c = std::get_if<XTyped>(&cases())) p.choice("XTyped", {c->a0, c->a1});
}

Pod Ex::to_pod() const {
    return std::holds_alternative<XVar>(cases()) ? Pod::choice("XVar", {prism_rtl::to_pod(std::get<XVar>(cases()).a0)})
        : std::holds_alternative<XPath>(cases()) ? Pod::choice("XPath", {prism_rtl::to_pod(std::get<XPath>(cases()).a0)})
        : std::holds_alternative<XSelf>(cases()) ? Pod::choice("XSelf", {})
        : std::holds_alternative<XCx>(cases()) ? Pod::choice("XCx", {})
        : std::holds_alternative<XConst>(cases()) ? Pod::choice("XConst", {prism_rtl::to_pod(std::get<XConst>(cases()).a0)})
        : std::holds_alternative<XUnit>(cases()) ? Pod::choice("XUnit", {})
        : std::holds_alternative<XNone>(cases()) ? Pod::choice("XNone", {})
        : std::holds_alternative<XBool>(cases()) ? Pod::choice("XBool", {prism_rtl::to_pod(std::get<XBool>(cases()).a0)})
        : std::holds_alternative<XNat>(cases()) ? Pod::choice("XNat", {prism_rtl::to_pod(std::get<XNat>(cases()).a0)})
        : std::holds_alternative<XInt>(cases()) ? Pod::choice("XInt", {prism_rtl::to_pod(std::get<XInt>(cases()).a0)})
        : std::holds_alternative<XByte>(cases()) ? Pod::choice("XByte", {prism_rtl::to_pod(std::get<XByte>(cases()).a0)})
        : std::holds_alternative<XFloat>(cases()) ? Pod::choice("XFloat", {prism_rtl::to_pod(std::get<XFloat>(cases()).a0)})
        : std::holds_alternative<XIndex>(cases()) ? Pod::choice("XIndex", {prism_rtl::to_pod(std::get<XIndex>(cases()).a0)})
        : std::holds_alternative<XChar>(cases()) ? Pod::choice("XChar", {prism_rtl::to_pod(std::get<XChar>(cases()).a0)})
        : std::holds_alternative<XStr>(cases()) ? Pod::choice("XStr", {prism_rtl::to_pod(std::get<XStr>(cases()).a0)})
        : std::holds_alternative<XRef>(cases()) ? Pod::choice("XRef", {prism_rtl::to_pod(std::get<XRef>(cases()).a0)})
        : std::holds_alternative<XRefMut>(cases()) ? Pod::choice("XRefMut", {prism_rtl::to_pod(std::get<XRefMut>(cases()).a0)})
        : std::holds_alternative<XDeref>(cases()) ? Pod::choice("XDeref", {prism_rtl::to_pod(std::get<XDeref>(cases()).a0)})
        : std::holds_alternative<XTarget>(cases()) ? Pod::choice("XTarget", {prism_rtl::to_pod(std::get<XTarget>(cases()).a0)})
        : std::holds_alternative<XClone>(cases()) ? Pod::choice("XClone", {prism_rtl::to_pod(std::get<XClone>(cases()).a0)})
        : std::holds_alternative<XWeak>(cases()) ? Pod::choice("XWeak", {prism_rtl::to_pod(std::get<XWeak>(cases()).a0)})
        : std::holds_alternative<XUpgrade>(cases()) ? Pod::choice("XUpgrade", {prism_rtl::to_pod(std::get<XUpgrade>(cases()).a0)})
        : std::holds_alternative<XBreak>(cases()) ? Pod::choice("XBreak", {prism_rtl::to_pod(std::get<XBreak>(cases()).a0), prism_rtl::to_pod(std::get<XBreak>(cases()).a1)})
        : std::holds_alternative<XBreakLoop>(cases()) ? Pod::choice("XBreakLoop", {})
        : std::holds_alternative<XLater>(cases()) ? Pod::choice("XLater", {prism_rtl::to_pod(std::get<XLater>(cases()).a0)})
        : std::holds_alternative<XFormatStr>(cases()) ? Pod::choice("XFormatStr", {prism_rtl::to_pod(std::get<XFormatStr>(cases()).a0)})
        : std::holds_alternative<XIsCase>(cases()) ? Pod::choice("XIsCase", {prism_rtl::to_pod(std::get<XIsCase>(cases()).a0), prism_rtl::to_pod(std::get<XIsCase>(cases()).a1)})
        : std::holds_alternative<XRefusal>(cases()) ? Pod::choice("XRefusal", {prism_rtl::to_pod(std::get<XRefusal>(cases()).a0)})
        : std::holds_alternative<XUnreachable>(cases()) ? Pod::choice("XUnreachable", {})
        : std::holds_alternative<XCall>(cases()) ? Pod::choice("XCall", {prism_rtl::to_pod(std::get<XCall>(cases()).a0), prism_rtl::to_pod(std::get<XCall>(cases()).a1)})
        : std::holds_alternative<XApply>(cases()) ? Pod::choice("XApply", {prism_rtl::to_pod(std::get<XApply>(cases()).a0), prism_rtl::to_pod(std::get<XApply>(cases()).a1)})
        : std::holds_alternative<XMethod>(cases()) ? Pod::choice("XMethod", {prism_rtl::to_pod(std::get<XMethod>(cases()).a0), prism_rtl::to_pod(std::get<XMethod>(cases()).a1), prism_rtl::to_pod(std::get<XMethod>(cases()).a2)})
        : std::holds_alternative<XBin>(cases()) ? Pod::choice("XBin", {prism_rtl::to_pod(std::get<XBin>(cases()).a0), prism_rtl::to_pod(std::get<XBin>(cases()).a1), prism_rtl::to_pod(std::get<XBin>(cases()).a2)})
        : std::holds_alternative<XUnary>(cases()) ? Pod::choice("XUnary", {prism_rtl::to_pod(std::get<XUnary>(cases()).a0), prism_rtl::to_pod(std::get<XUnary>(cases()).a1)})
        : std::holds_alternative<XCtor>(cases()) ? Pod::choice("XCtor", {prism_rtl::to_pod(std::get<XCtor>(cases()).a0), prism_rtl::to_pod(std::get<XCtor>(cases()).a1)})
        : std::holds_alternative<XRecord>(cases()) ? Pod::choice("XRecord", {prism_rtl::to_pod(std::get<XRecord>(cases()).a0), prism_rtl::to_pod(std::get<XRecord>(cases()).a1)})
        : std::holds_alternative<XTuple>(cases()) ? Pod::choice("XTuple", {prism_rtl::to_pod(std::get<XTuple>(cases()).a0)})
        : std::holds_alternative<XVec>(cases()) ? Pod::choice("XVec", {prism_rtl::to_pod(std::get<XVec>(cases()).a0)})
        : std::holds_alternative<XText>(cases()) ? Pod::choice("XText", {prism_rtl::to_pod(std::get<XText>(cases()).a0)})
        : std::holds_alternative<XFormat>(cases()) ? Pod::choice("XFormat", {prism_rtl::to_pod(std::get<XFormat>(cases()).a0)})
        : std::holds_alternative<XMatch>(cases()) ? Pod::choice("XMatch", {prism_rtl::to_pod(std::get<XMatch>(cases()).a0), prism_rtl::to_pod(std::get<XMatch>(cases()).a1), prism_rtl::to_pod(std::get<XMatch>(cases()).a2), prism_rtl::to_pod(std::get<XMatch>(cases()).a3)})
        : std::holds_alternative<XChain>(cases()) ? Pod::choice("XChain", {prism_rtl::to_pod(std::get<XChain>(cases()).a0), prism_rtl::to_pod(std::get<XChain>(cases()).a1), prism_rtl::to_pod(std::get<XChain>(cases()).a2), prism_rtl::to_pod(std::get<XChain>(cases()).a3)})
        : std::holds_alternative<XIf>(cases()) ? Pod::choice("XIf", {prism_rtl::to_pod(std::get<XIf>(cases()).a0), prism_rtl::to_pod(std::get<XIf>(cases()).a1), prism_rtl::to_pod(std::get<XIf>(cases()).a2)})
        : std::holds_alternative<XBlock>(cases()) ? Pod::choice("XBlock", {prism_rtl::to_pod(std::get<XBlock>(cases()).a0), prism_rtl::to_pod(std::get<XBlock>(cases()).a1)})
        : std::holds_alternative<XLabeled>(cases()) ? Pod::choice("XLabeled", {prism_rtl::to_pod(std::get<XLabeled>(cases()).a0), prism_rtl::to_pod(std::get<XLabeled>(cases()).a1), prism_rtl::to_pod(std::get<XLabeled>(cases()).a2), prism_rtl::to_pod(std::get<XLabeled>(cases()).a3)})
        : std::holds_alternative<XClosure>(cases()) ? Pod::choice("XClosure", {prism_rtl::to_pod(std::get<XClosure>(cases()).a0), prism_rtl::to_pod(std::get<XClosure>(cases()).a1), prism_rtl::to_pod(std::get<XClosure>(cases()).a2)})
        : std::holds_alternative<XTry>(cases()) ? Pod::choice("XTry", {prism_rtl::to_pod(std::get<XTry>(cases()).a0)})
        : std::holds_alternative<XField>(cases()) ? Pod::choice("XField", {prism_rtl::to_pod(std::get<XField>(cases()).a0), prism_rtl::to_pod(std::get<XField>(cases()).a1)})
        : std::holds_alternative<XPart>(cases()) ? Pod::choice("XPart", {prism_rtl::to_pod(std::get<XPart>(cases()).a0), prism_rtl::to_pod(std::get<XPart>(cases()).a1)})
        : std::holds_alternative<XDecode>(cases()) ? Pod::choice("XDecode", {prism_rtl::to_pod(std::get<XDecode>(cases()).a0), prism_rtl::to_pod(std::get<XDecode>(cases()).a1)})
        : std::holds_alternative<XCast>(cases()) ? Pod::choice("XCast", {prism_rtl::to_pod(std::get<XCast>(cases()).a0), prism_rtl::to_pod(std::get<XCast>(cases()).a1)})
        : std::holds_alternative<XTyped>(cases()) ? Pod::choice("XTyped", {prism_rtl::to_pod(std::get<XTyped>(cases()).a0), prism_rtl::to_pod(std::get<XTyped>(cases()).a1)})
        : Pod();
}

Result<Ex> Ex::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "XVar" && c->args.size() == 1) return Ex(XVar{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XPath" && c->args.size() == 1) return Ex(XPath{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XSelf" && c->args.size() == 0) return Ex(XSelf{});
        if (c->ctor == "XCx" && c->args.size() == 0) return Ex(XCx{});
        if (c->ctor == "XConst" && c->args.size() == 1) return Ex(XConst{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XUnit" && c->args.size() == 0) return Ex(XUnit{});
        if (c->ctor == "XNone" && c->args.size() == 0) return Ex(XNone{});
        if (c->ctor == "XBool" && c->args.size() == 1) return Ex(XBool{TRY(prism_rtl::from_pod<bool>(c->args[0]))});
        if (c->ctor == "XNat" && c->args.size() == 1) return Ex(XNat{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XInt" && c->args.size() == 1) return Ex(XInt{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XByte" && c->args.size() == 1) return Ex(XByte{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XFloat" && c->args.size() == 1) return Ex(XFloat{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XIndex" && c->args.size() == 1) return Ex(XIndex{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "XChar" && c->args.size() == 1) return Ex(XChar{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XStr" && c->args.size() == 1) return Ex(XStr{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XRef" && c->args.size() == 1) return Ex(XRef{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "XRefMut" && c->args.size() == 1) return Ex(XRefMut{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "XDeref" && c->args.size() == 1) return Ex(XDeref{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "XTarget" && c->args.size() == 1) return Ex(XTarget{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "XClone" && c->args.size() == 1) return Ex(XClone{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "XWeak" && c->args.size() == 1) return Ex(XWeak{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "XUpgrade" && c->args.size() == 1) return Ex(XUpgrade{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "XBreak" && c->args.size() == 2) return Ex(XBreak{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1]))});
        if (c->ctor == "XBreakLoop" && c->args.size() == 0) return Ex(XBreakLoop{});
        if (c->ctor == "XLater" && c->args.size() == 1) return Ex(XLater{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "XFormatStr" && c->args.size() == 1) return Ex(XFormatStr{TRY(prism_rtl::from_pod<Array<Ex>>(c->args[0]))});
        if (c->ctor == "XIsCase" && c->args.size() == 2) return Ex(XIsCase{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Array<Text>>(c->args[1]))});
        if (c->ctor == "XRefusal" && c->args.size() == 1) return Ex(XRefusal{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XUnreachable" && c->args.size() == 0) return Ex(XUnreachable{});
        if (c->ctor == "XCall" && c->args.size() == 2) return Ex(XCall{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Ex>>(c->args[1]))});
        if (c->ctor == "XApply" && c->args.size() == 2) return Ex(XApply{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Array<Ex>>(c->args[1]))});
        if (c->ctor == "XMethod" && c->args.size() == 3) return Ex(XMethod{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Array<Ex>>(c->args[2]))});
        if (c->ctor == "XBin" && c->args.size() == 3) return Ex(XBin{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1])), TRY(prism_rtl::from_pod<Ex>(c->args[2]))});
        if (c->ctor == "XUnary" && c->args.size() == 2) return Ex(XUnary{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1]))});
        if (c->ctor == "XCtor" && c->args.size() == 2) return Ex(XCtor{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Ex>>(c->args[1]))});
        if (c->ctor == "XRecord" && c->args.size() == 2) return Ex(XRecord{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<std::tuple<Text, Ex>>>(c->args[1]))});
        if (c->ctor == "XTuple" && c->args.size() == 1) return Ex(XTuple{TRY(prism_rtl::from_pod<Array<Ex>>(c->args[0]))});
        if (c->ctor == "XVec" && c->args.size() == 1) return Ex(XVec{TRY(prism_rtl::from_pod<Array<Ex>>(c->args[0]))});
        if (c->ctor == "XText" && c->args.size() == 1) return Ex(XText{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XFormat" && c->args.size() == 1) return Ex(XFormat{TRY(prism_rtl::from_pod<Array<Ex>>(c->args[0]))});
        if (c->ctor == "XMatch" && c->args.size() == 4) return Ex(XMatch{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Array<XArm>>(c->args[1])), TRY(prism_rtl::from_pod<bool>(c->args[2])), TRY(prism_rtl::from_pod<OutTy>(c->args[3]))});
        if (c->ctor == "XChain" && c->args.size() == 4) return Ex(XChain{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1])), TRY(prism_rtl::from_pod<Array<XArm>>(c->args[2])), TRY(prism_rtl::from_pod<OutTy>(c->args[3]))});
        if (c->ctor == "XIf" && c->args.size() == 3) return Ex(XIf{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1])), TRY(prism_rtl::from_pod<Ex>(c->args[2]))});
        if (c->ctor == "XBlock" && c->args.size() == 2) return Ex(XBlock{TRY(prism_rtl::from_pod<Array<Do>>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1]))});
        if (c->ctor == "XLabeled" && c->args.size() == 4) return Ex(XLabeled{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[1])), TRY(prism_rtl::from_pod<Ex>(c->args[2])), TRY(prism_rtl::from_pod<OutTy>(c->args[3]))});
        if (c->ctor == "XClosure" && c->args.size() == 3) return Ex(XClosure{TRY(prism_rtl::from_pod<bool>(c->args[0])), TRY(prism_rtl::from_pod<Array<Pa>>(c->args[1])), TRY(prism_rtl::from_pod<Ex>(c->args[2]))});
        if (c->ctor == "XTry" && c->args.size() == 1) return Ex(XTry{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "XField" && c->args.size() == 2) return Ex(XField{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "XPart" && c->args.size() == 2) return Ex(XPart{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Nat>(c->args[1]))});
        if (c->ctor == "XDecode" && c->args.size() == 2) return Ex(XDecode{TRY(prism_rtl::from_pod<OutTy>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1]))});
        if (c->ctor == "XCast" && c->args.size() == 2) return Ex(XCast{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<OutTy>(c->args[1]))});
        if (c->ctor == "XTyped" && c->args.size() == 2) return Ex(XTyped{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<OutTy>(c->args[1]))});
    }
    return mismatch<Ex>("a Ex", p);
}


Pod FlatDef::to_pod() const {
    return Pod::record("FlatDef", {{"name", prism_rtl::to_pod(name)}, {"outer", prism_rtl::to_pod(outer)}, {"generation", prism_rtl::to_pod(generation)}, {"ty", prism_rtl::to_pod(ty)}});
}

Result<FlatDef> FlatDef::from_pod(const Pod& whole) {
    return FlatDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .outer = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "outer")))), .generation = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "generation")))), .ty = TRY(prism_rtl::from_pod<OutTy>(TRY(prelude::field(whole, "ty"))))};
}


void FnDef::show(Printer& p) const {
    p.record("FnDef", {{"name", name}, {"generics", generics}, {"params", params}, {"ret", ret}, {"body", body}, {"doc", doc}, {"public", public_}});
}

Pod FnDef::to_pod() const {
    return Pod::record("FnDef", {{"name", prism_rtl::to_pod(name)}, {"generics", prism_rtl::to_pod(generics)}, {"params", prism_rtl::to_pod(params)}, {"ret", prism_rtl::to_pod(ret)}, {"body", prism_rtl::to_pod(body)}, {"doc", prism_rtl::to_pod(doc)}, {"public", prism_rtl::to_pod(public_)}});
}

Result<FnDef> FnDef::from_pod(const Pod& whole) {
    return FnDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .generics = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Array<Text>>>>(TRY(prelude::field(whole, "generics")))), .params = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy>>>(TRY(prelude::field(whole, "params")))), .ret = TRY(prism_rtl::from_pod<OutTy>(TRY(prelude::field(whole, "ret")))), .body = TRY(prism_rtl::from_pod<Ex>(TRY(prelude::field(whole, "body")))), .doc = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "doc")))), .public_ = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "public"))))};
}


void ForDef::show(Printer& p) const {
    p.record("ForDef", {{"name", name}, {"pos", pos}, {"at", at}, {"key_ty", key_ty}, {"value_ty", value_ty}, {"row_node", row_node}, {"keyed", keyed}, {"source", source}, {"parent", parent}, {"passed", passed}});
}

Pod ForDef::to_pod() const {
    return Pod::record("ForDef", {{"name", prism_rtl::to_pod(name)}, {"pos", prism_rtl::to_pod(pos)}, {"at", prism_rtl::to_pod(at)}, {"key_ty", prism_rtl::to_pod(key_ty)}, {"value_ty", prism_rtl::to_pod(value_ty)}, {"row_node", prism_rtl::to_pod(row_node)}, {"keyed", prism_rtl::to_pod(keyed)}, {"source", prism_rtl::to_pod(source)}, {"parent", prism_rtl::to_pod(parent)}, {"passed", prism_rtl::to_pod(passed)}});
}

Result<ForDef> ForDef::from_pod(const Pod& whole) {
    return ForDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .pos = TRY(prism_rtl::from_pod<Pos_>(TRY(prelude::field(whole, "pos")))), .at = TRY(prism_rtl::from_pod<Ex>(TRY(prelude::field(whole, "at")))), .key_ty = TRY(prism_rtl::from_pod<OutTy>(TRY(prelude::field(whole, "key_ty")))), .value_ty = TRY(prism_rtl::from_pod<OutTy>(TRY(prelude::field(whole, "value_ty")))), .row_node = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "row_node")))), .keyed = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "keyed")))), .source = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "source")))), .parent = TRY(prism_rtl::from_pod<Ex>(TRY(prelude::field(whole, "parent")))), .passed = TRY(prism_rtl::from_pod<Array<Ex>>(TRY(prelude::field(whole, "passed"))))};
}


Pod GenCase::to_pod() const {
    return Pod::record("GenCase", {{"node", prism_rtl::to_pod(node_)}, {"params", prism_rtl::to_pod(params)}, {"pat", prism_rtl::to_pod(pat)}, {"conds", prism_rtl::to_pod(conds)}, {"passed", prism_rtl::to_pod(passed)}});
}

Result<GenCase> GenCase::from_pod(const Pod& whole) {
    return GenCase{.node_ = TRY(prism_rtl::from_pod<NodeDef>(TRY(prelude::field(whole, "node")))), .params = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy>>>(TRY(prelude::field(whole, "params")))), .pat = TRY(prism_rtl::from_pod<Pa>(TRY(prelude::field(whole, "pat")))), .conds = TRY(prism_rtl::from_pod<Array<Cc>>(TRY(prelude::field(whole, "conds")))), .passed = TRY(prism_rtl::from_pod<Array<Ex>>(TRY(prelude::field(whole, "passed"))))};
}


void GenDef::show(Printer& p) const {
    p.record("GenDef", {{"name", name}, {"pos", pos}, {"at", at}, {"source", source}, {"value_ty", value_ty}, {"select", select}, {"transparent", transparent}, {"width", width}});
}

Pod GenDef::to_pod() const {
    return Pod::record("GenDef", {{"name", prism_rtl::to_pod(name)}, {"pos", prism_rtl::to_pod(pos)}, {"at", prism_rtl::to_pod(at)}, {"source", prism_rtl::to_pod(source)}, {"value_ty", prism_rtl::to_pod(value_ty)}, {"select", prism_rtl::to_pod(select)}, {"transparent", prism_rtl::to_pod(transparent)}, {"width", prism_rtl::to_pod(width)}});
}

Result<GenDef> GenDef::from_pod(const Pod& whole) {
    return GenDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .pos = TRY(prism_rtl::from_pod<Pos_>(TRY(prelude::field(whole, "pos")))), .at = TRY(prism_rtl::from_pod<Ex>(TRY(prelude::field(whole, "at")))), .source = TRY(prism_rtl::from_pod<Ex>(TRY(prelude::field(whole, "source")))), .value_ty = TRY(prism_rtl::from_pod<OutTy>(TRY(prelude::field(whole, "value_ty")))), .select = TRY(prism_rtl::from_pod<Ex>(TRY(prelude::field(whole, "select")))), .transparent = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "transparent")))), .width = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "width"))))};
}






void GnKind::show(Printer& p) const {
    if (auto c = std::get_if<GnNamed>(&cases())) p.choice("GnNamed", {});
    else if (auto c = std::get_if<GnAnswer>(&cases())) p.choice("GnAnswer", {});
    else if (auto c = std::get_if<GnStarted>(&cases())) p.choice("GnStarted", {});
    else if (auto c = std::get_if<GnDeferred>(&cases())) p.choice("GnDeferred", {});
    else if (auto c = std::get_if<GnPort>(&cases())) p.choice("GnPort", {});
    else if (auto c = std::get_if<GnMerge>(&cases())) p.choice("GnMerge", {});
    else if (auto c = std::get_if<GnUnion>(&cases())) p.choice("GnUnion", {});
    else if (auto c = std::get_if<GnBoth>(&cases())) p.choice("GnBoth", {});
    else if (auto c = std::get_if<GnExcept>(&cases())) p.choice("GnExcept", {});
    else if (auto c = std::get_if<GnMergeAll>(&cases())) p.choice("GnMergeAll", {});
    else if (auto c = std::get_if<GnGather>(&cases())) p.choice("GnGather", {});
    else if (auto c = std::get_if<GnUpdated>(&cases())) p.choice("GnUpdated", {});
    else if (auto c = std::get_if<GnNever>(&cases())) p.choice("GnNever", {});
}

Pod GnKind::to_pod() const {
    return std::holds_alternative<GnNamed>(cases()) ? Pod::choice("GnNamed", {})
        : std::holds_alternative<GnAnswer>(cases()) ? Pod::choice("GnAnswer", {})
        : std::holds_alternative<GnStarted>(cases()) ? Pod::choice("GnStarted", {})
        : std::holds_alternative<GnDeferred>(cases()) ? Pod::choice("GnDeferred", {})
        : std::holds_alternative<GnPort>(cases()) ? Pod::choice("GnPort", {})
        : std::holds_alternative<GnMerge>(cases()) ? Pod::choice("GnMerge", {})
        : std::holds_alternative<GnUnion>(cases()) ? Pod::choice("GnUnion", {})
        : std::holds_alternative<GnBoth>(cases()) ? Pod::choice("GnBoth", {})
        : std::holds_alternative<GnExcept>(cases()) ? Pod::choice("GnExcept", {})
        : std::holds_alternative<GnMergeAll>(cases()) ? Pod::choice("GnMergeAll", {})
        : std::holds_alternative<GnGather>(cases()) ? Pod::choice("GnGather", {})
        : std::holds_alternative<GnUpdated>(cases()) ? Pod::choice("GnUpdated", {})
        : std::holds_alternative<GnNever>(cases()) ? Pod::choice("GnNever", {})
        : Pod();
}

Result<GnKind> GnKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "GnNamed" && c->args.size() == 0) return GnKind(GnNamed{});
        if (c->ctor == "GnAnswer" && c->args.size() == 0) return GnKind(GnAnswer{});
        if (c->ctor == "GnStarted" && c->args.size() == 0) return GnKind(GnStarted{});
        if (c->ctor == "GnDeferred" && c->args.size() == 0) return GnKind(GnDeferred{});
        if (c->ctor == "GnPort" && c->args.size() == 0) return GnKind(GnPort{});
        if (c->ctor == "GnMerge" && c->args.size() == 0) return GnKind(GnMerge{});
        if (c->ctor == "GnUnion" && c->args.size() == 0) return GnKind(GnUnion{});
        if (c->ctor == "GnBoth" && c->args.size() == 0) return GnKind(GnBoth{});
        if (c->ctor == "GnExcept" && c->args.size() == 0) return GnKind(GnExcept{});
        if (c->ctor == "GnMergeAll" && c->args.size() == 0) return GnKind(GnMergeAll{});
        if (c->ctor == "GnGather" && c->args.size() == 0) return GnKind(GnGather{});
        if (c->ctor == "GnUpdated" && c->args.size() == 0) return GnKind(GnUpdated{});
        if (c->ctor == "GnNever" && c->args.size() == 0) return GnKind(GnNever{});
    }
    return mismatch<GnKind>("a GnKind", p);
}


void Holding::show(Printer& p) const {
    if (auto c = std::get_if<ByRef>(&cases())) p.choice("ByRef", {});
    else if (auto c = std::get_if<Owned>(&cases())) p.choice("Owned", {});
    else if (auto c = std::get_if<RcRef>(&cases())) p.choice("RcRef", {});
    else if (auto c = std::get_if<RcOwned>(&cases())) p.choice("RcOwned", {});
}

Pod Holding::to_pod() const {
    return std::holds_alternative<ByRef>(cases()) ? Pod::choice("ByRef", {})
        : std::holds_alternative<Owned>(cases()) ? Pod::choice("Owned", {})
        : std::holds_alternative<RcRef>(cases()) ? Pod::choice("RcRef", {})
        : std::holds_alternative<RcOwned>(cases()) ? Pod::choice("RcOwned", {})
        : Pod();
}

Result<Holding> Holding::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "ByRef" && c->args.size() == 0) return Holding(ByRef{});
        if (c->ctor == "Owned" && c->args.size() == 0) return Holding(Owned{});
        if (c->ctor == "RcRef" && c->args.size() == 0) return Holding(RcRef{});
        if (c->ctor == "RcOwned" && c->args.size() == 0) return Holding(RcOwned{});
    }
    return mismatch<Holding>("a Holding", p);
}


Pod HostDef::to_pod() const {
    return Pod::record("HostDef", {{"pos", prism_rtl::to_pod(pos)}, {"name", prism_rtl::to_pod(name)}, {"scope", prism_rtl::to_pod(scope)}});
}

Result<HostDef> HostDef::from_pod(const Pod& whole) {
    return HostDef{.pos = TRY(prism_rtl::from_pod<Pos_>(TRY(prelude::field(whole, "pos")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .scope = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "scope"))))};
}


void HostForm::show(Printer& p) const {
    if (auto c = std::get_if<HostEach>(&cases())) p.choice("HostEach", {});
    else if (auto c = std::get_if<HostSome>(&cases())) p.choice("HostSome", {});
}

Pod HostForm::to_pod() const {
    return std::holds_alternative<HostEach>(cases()) ? Pod::choice("HostEach", {})
        : std::holds_alternative<HostSome>(cases()) ? Pod::choice("HostSome", {})
        : Pod();
}

Result<HostForm> HostForm::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "HostEach" && c->args.size() == 0) return HostForm(HostEach{});
        if (c->ctor == "HostSome" && c->args.size() == 0) return HostForm(HostSome{});
    }
    return mismatch<HostForm>("a HostForm", p);
}


void HowBound::show(Printer& p) const {
    if (auto c = std::get_if<AsHold>(&cases())) p.choice("AsHold", {});
    else if (auto c = std::get_if<AsBind>(&cases())) p.choice("AsBind", {});
    else if (auto c = std::get_if<AsLet>(&cases())) p.choice("AsLet", {});
}

Pod HowBound::to_pod() const {
    return std::holds_alternative<AsHold>(cases()) ? Pod::choice("AsHold", {})
        : std::holds_alternative<AsBind>(cases()) ? Pod::choice("AsBind", {})
        : std::holds_alternative<AsLet>(cases()) ? Pod::choice("AsLet", {})
        : Pod();
}

Result<HowBound> HowBound::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "AsHold" && c->args.size() == 0) return HowBound(AsHold{});
        if (c->ctor == "AsBind" && c->args.size() == 0) return HowBound(AsBind{});
        if (c->ctor == "AsLet" && c->args.size() == 0) return HowBound(AsLet{});
    }
    return mismatch<HowBound>("a HowBound", p);
}


void ImplDef::show(Printer& p) const {
    p.record("ImplDef", {{"cls", cls}, {"tr", tr}, {"head", head}, {"generics", generics}, {"methods", methods}, {"doc", doc}});
}

Pod ImplDef::to_pod() const {
    return Pod::record("ImplDef", {{"cls", prism_rtl::to_pod(cls)}, {"tr", prism_rtl::to_pod(tr)}, {"head", prism_rtl::to_pod(head)}, {"generics", prism_rtl::to_pod(generics)}, {"methods", prism_rtl::to_pod(methods)}, {"doc", prism_rtl::to_pod(doc)}});
}

Result<ImplDef> ImplDef::from_pod(const Pod& whole) {
    return ImplDef{.cls = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "cls")))), .tr = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "tr")))), .head = TRY(prism_rtl::from_pod<OutTy>(TRY(prelude::field(whole, "head")))), .generics = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Array<Text>>>>(TRY(prelude::field(whole, "generics")))), .methods = TRY(prism_rtl::from_pod<Array<FnDef>>(TRY(prelude::field(whole, "methods")))), .doc = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "doc"))))};
}


void Item::show(Printer& p) const {
    if (auto c = std::get_if<ItTrait>(&cases())) p.choice("ItTrait", {c->a0});
    else if (auto c = std::get_if<ItImpl>(&cases())) p.choice("ItImpl", {c->a0});
    else if (auto c = std::get_if<ItType>(&cases())) p.choice("ItType", {c->a0});
    else if (auto c = std::get_if<ItTag>(&cases())) p.choice("ItTag", {c->a0});
    else if (auto c = std::get_if<ItRow>(&cases())) p.choice("ItRow", {c->a0});
    else if (auto c = std::get_if<ItFn>(&cases())) p.choice("ItFn", {c->a0});
    else if (auto c = std::get_if<ItJob>(&cases())) p.choice("ItJob", {c->a0});
    else if (auto c = std::get_if<ItNode>(&cases())) p.choice("ItNode", {c->a0});
    else if (auto c = std::get_if<ItNote>(&cases())) p.choice("ItNote", {c->a0});
    else if (auto c = std::get_if<ItRefused>(&cases())) p.choice("ItRefused", {c->a0});
}

Pod Item::to_pod() const {
    return std::holds_alternative<ItTrait>(cases()) ? Pod::choice("ItTrait", {prism_rtl::to_pod(std::get<ItTrait>(cases()).a0)})
        : std::holds_alternative<ItImpl>(cases()) ? Pod::choice("ItImpl", {prism_rtl::to_pod(std::get<ItImpl>(cases()).a0)})
        : std::holds_alternative<ItType>(cases()) ? Pod::choice("ItType", {prism_rtl::to_pod(std::get<ItType>(cases()).a0)})
        : std::holds_alternative<ItTag>(cases()) ? Pod::choice("ItTag", {prism_rtl::to_pod(std::get<ItTag>(cases()).a0)})
        : std::holds_alternative<ItRow>(cases()) ? Pod::choice("ItRow", {prism_rtl::to_pod(std::get<ItRow>(cases()).a0)})
        : std::holds_alternative<ItFn>(cases()) ? Pod::choice("ItFn", {prism_rtl::to_pod(std::get<ItFn>(cases()).a0)})
        : std::holds_alternative<ItJob>(cases()) ? Pod::choice("ItJob", {prism_rtl::to_pod(std::get<ItJob>(cases()).a0)})
        : std::holds_alternative<ItNode>(cases()) ? Pod::choice("ItNode", {prism_rtl::to_pod(std::get<ItNode>(cases()).a0)})
        : std::holds_alternative<ItNote>(cases()) ? Pod::choice("ItNote", {prism_rtl::to_pod(std::get<ItNote>(cases()).a0)})
        : std::holds_alternative<ItRefused>(cases()) ? Pod::choice("ItRefused", {prism_rtl::to_pod(std::get<ItRefused>(cases()).a0)})
        : Pod();
}

Result<Item> Item::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "ItTrait" && c->args.size() == 1) return Item(ItTrait{TRY(prism_rtl::from_pod<TraitDef>(c->args[0]))});
        if (c->ctor == "ItImpl" && c->args.size() == 1) return Item(ItImpl{TRY(prism_rtl::from_pod<ImplDef>(c->args[0]))});
        if (c->ctor == "ItType" && c->args.size() == 1) return Item(ItType{TRY(prism_rtl::from_pod<TyDef>(c->args[0]))});
        if (c->ctor == "ItTag" && c->args.size() == 1) return Item(ItTag{TRY(prism_rtl::from_pod<TagDef>(c->args[0]))});
        if (c->ctor == "ItRow" && c->args.size() == 1) return Item(ItRow{TRY(prism_rtl::from_pod<RowDef>(c->args[0]))});
        if (c->ctor == "ItFn" && c->args.size() == 1) return Item(ItFn{TRY(prism_rtl::from_pod<FnDef>(c->args[0]))});
        if (c->ctor == "ItJob" && c->args.size() == 1) return Item(ItJob{TRY(prism_rtl::from_pod<JobDef>(c->args[0]))});
        if (c->ctor == "ItNode" && c->args.size() == 1) return Item(ItNode{TRY(prism_rtl::from_pod<NodeDef>(c->args[0]))});
        if (c->ctor == "ItNote" && c->args.size() == 1) return Item(ItNote{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "ItRefused" && c->args.size() == 1) return Item(ItRefused{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Item>("a Item", p);
}


void JobDef::show(Printer& p) const {
    p.record("JobDef", {{"name", name}, {"start", start}, {"generics", generics}, {"fields", fields}, {"ret", ret}, {"body", body}, {"doc", doc}});
}

Pod JobDef::to_pod() const {
    return Pod::record("JobDef", {{"name", prism_rtl::to_pod(name)}, {"start", prism_rtl::to_pod(start)}, {"generics", prism_rtl::to_pod(generics)}, {"fields", prism_rtl::to_pod(fields)}, {"ret", prism_rtl::to_pod(ret)}, {"body", prism_rtl::to_pod(body)}, {"doc", prism_rtl::to_pod(doc)}});
}

Result<JobDef> JobDef::from_pod(const Pod& whole) {
    return JobDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .start = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "start")))), .generics = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Array<Text>>>>(TRY(prelude::field(whole, "generics")))), .fields = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy>>>(TRY(prelude::field(whole, "fields")))), .ret = TRY(prism_rtl::from_pod<OutTy>(TRY(prelude::field(whole, "ret")))), .body = TRY(prism_rtl::from_pod<Ex>(TRY(prelude::field(whole, "body")))), .doc = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "doc"))))};
}


void Layer::show(Printer& p) const {
    if (auto c = std::get_if<LyPlain>(&cases())) p.choice("LyPlain", {});
    else if (auto c = std::get_if<LyDyn>(&cases())) p.choice("LyDyn", {});
    else if (auto c = std::get_if<LyEv>(&cases())) p.choice("LyEv", {});
    else if (auto c = std::get_if<LyBlueprint>(&cases())) p.choice("LyBlueprint", {});
}

Pod Layer::to_pod() const {
    return std::holds_alternative<LyPlain>(cases()) ? Pod::choice("LyPlain", {})
        : std::holds_alternative<LyDyn>(cases()) ? Pod::choice("LyDyn", {})
        : std::holds_alternative<LyEv>(cases()) ? Pod::choice("LyEv", {})
        : std::holds_alternative<LyBlueprint>(cases()) ? Pod::choice("LyBlueprint", {})
        : Pod();
}

Result<Layer> Layer::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "LyPlain" && c->args.size() == 0) return Layer(LyPlain{});
        if (c->ctor == "LyDyn" && c->args.size() == 0) return Layer(LyDyn{});
        if (c->ctor == "LyEv" && c->args.size() == 0) return Layer(LyEv{});
        if (c->ctor == "LyBlueprint" && c->args.size() == 0) return Layer(LyBlueprint{});
    }
    return mismatch<Layer>("a Layer", p);
}


void Lx::show(Printer& p) const {
    p.record("Lx", {{"g", g}, {"tys", tys}, {"apps", apps}, {"binders", binders}, {"impls", impls}, {"file", file}, {"home", home}, {"site", site}, {"rs_mods", rs_mods}, {"rs_names", rs_names}, {"layouts", layouts}, {"unbs", unbs}, {"notes", notes}, {"globals", globals}, {"in_node", in_node}, {"unshrunk", unshrunk}, {"gens", gens}, {"insts", insts}, {"quants", quants}, {"gen_of_q", gen_of_q}, {"use_insts", use_insts}, {"subst", subst}, {"csubst", csubst}});
}

Pod Lx::to_pod() const {
    return Pod::record("Lx", {{"g", prism_rtl::to_pod(g)}, {"tys", prism_rtl::to_pod(tys)}, {"apps", prism_rtl::to_pod(apps)}, {"binders", prism_rtl::to_pod(binders)}, {"impls", prism_rtl::to_pod(impls)}, {"file", prism_rtl::to_pod(file)}, {"home", prism_rtl::to_pod(home)}, {"site", prism_rtl::to_pod(site)}, {"rs_mods", prism_rtl::to_pod(rs_mods)}, {"rs_names", prism_rtl::to_pod(rs_names)}, {"layouts", prism_rtl::to_pod(layouts)}, {"unbs", prism_rtl::to_pod(unbs)}, {"notes", prism_rtl::to_pod(notes)}, {"globals", prism_rtl::to_pod(globals)}, {"in_node", prism_rtl::to_pod(in_node)}, {"unshrunk", prism_rtl::to_pod(unshrunk)}, {"gens", prism_rtl::to_pod(gens)}, {"insts", prism_rtl::to_pod(insts)}, {"quants", prism_rtl::to_pod(quants)}, {"gen_of_q", prism_rtl::to_pod(gen_of_q)}, {"use_insts", prism_rtl::to_pod(use_insts)}, {"subst", prism_rtl::to_pod(subst)}, {"csubst", prism_rtl::to_pod(csubst)}});
}

Result<Lx> Lx::from_pod(const Pod& whole) {
    return Lx{.g = TRY(prism_rtl::from_pod<check_env::G>(TRY(prelude::field(whole, "g")))), .tys = TRY(prism_rtl::from_pod<Map<Text, check_types::Ty>>(TRY(prelude::field(whole, "tys")))), .apps = TRY(prism_rtl::from_pod<Map<Text, typed::AppNote>>(TRY(prelude::field(whole, "apps")))), .binders = TRY(prism_rtl::from_pod<Map<Text, check_types::Ty>>(TRY(prelude::field(whole, "binders")))), .impls = TRY(prism_rtl::from_pod<Map<Text, Array<typed::ImplNote>>>(TRY(prelude::field(whole, "impls")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "file")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "home")))), .site = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "site")))), .rs_mods = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(prelude::field(whole, "rs_mods")))), .rs_names = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(prelude::field(whole, "rs_names")))), .layouts = TRY(prism_rtl::from_pod<Map<Text, Array<bool>>>(TRY(prelude::field(whole, "layouts")))), .unbs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "unbs")))), .notes = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "notes")))), .globals = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(prelude::field(whole, "globals")))), .in_node = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "in_node")))), .unshrunk = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(prelude::field(whole, "unshrunk")))), .gens = TRY(prism_rtl::from_pod<Map<Text, typed::GenNote>>(TRY(prelude::field(whole, "gens")))), .insts = TRY(prism_rtl::from_pod<Map<Text, Array<typed::InstNote>>>(TRY(prelude::field(whole, "insts")))), .quants = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(prelude::field(whole, "quants")))), .gen_of_q = TRY(prism_rtl::from_pod<Map<Text, typed::GenNote>>(TRY(prelude::field(whole, "gen_of_q")))), .use_insts = TRY(prism_rtl::from_pod<Map<Text, typed::InstNote>>(TRY(prelude::field(whole, "use_insts")))), .subst = TRY(prism_rtl::from_pod<Map<Text, check_types::Ty>>(TRY(prelude::field(whole, "subst")))), .csubst = TRY(prism_rtl::from_pod<Map<Text, check_types::Col>>(TRY(prelude::field(whole, "csubst"))))};
}


void MethDef::show(Printer& p) const {
    p.record("MethDef", {{"name", name}, {"recv", recv}, {"params", params}, {"cx", cx_}, {"ret", ret}, {"body", body}, {"tail", tail}, {"doc", doc}});
}

Pod MethDef::to_pod() const {
    return Pod::record("MethDef", {{"name", prism_rtl::to_pod(name)}, {"recv", prism_rtl::to_pod(recv)}, {"params", prism_rtl::to_pod(params)}, {"cx", prism_rtl::to_pod(cx_)}, {"ret", prism_rtl::to_pod(ret)}, {"body", prism_rtl::to_pod(body)}, {"tail", prism_rtl::to_pod(tail)}, {"doc", prism_rtl::to_pod(doc)}});
}

Result<MethDef> MethDef::from_pod(const Pod& whole) {
    return MethDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .recv = TRY(prism_rtl::from_pod<Recv>(TRY(prelude::field(whole, "recv")))), .params = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy>>>(TRY(prelude::field(whole, "params")))), .cx_ = TRY(prism_rtl::from_pod<CxArg>(TRY(prelude::field(whole, "cx")))), .ret = TRY(prism_rtl::from_pod<OutTy>(TRY(prelude::field(whole, "ret")))), .body = TRY(prism_rtl::from_pod<Array<Do>>(TRY(prelude::field(whole, "body")))), .tail = TRY(prism_rtl::from_pod<Ex>(TRY(prelude::field(whole, "tail")))), .doc = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "doc"))))};
}


void ModDef::show(Printer& p) const {
    p.record("ModDef", {{"name", name}, {"prism", prism}, {"path", path_}, {"uses", uses}, {"complete", complete}, {"declared", declared}, {"types_with", types_with}, {"items", items}});
}

Pod ModDef::to_pod() const {
    return Pod::record("ModDef", {{"name", prism_rtl::to_pod(name)}, {"prism", prism_rtl::to_pod(prism)}, {"path", prism_rtl::to_pod(path_)}, {"uses", prism_rtl::to_pod(uses)}, {"complete", prism_rtl::to_pod(complete)}, {"declared", prism_rtl::to_pod(declared)}, {"types_with", prism_rtl::to_pod(types_with)}, {"items", prism_rtl::to_pod(items)}});
}

Result<ModDef> ModDef::from_pod(const Pod& whole) {
    return ModDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .prism = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "prism")))), .path_ = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "path")))), .uses = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "uses")))), .complete = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "complete")))), .declared = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "declared")))), .types_with = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "types_with")))), .items = TRY(prism_rtl::from_pod<Array<Item>>(TRY(prelude::field(whole, "items"))))};
}


void Model::show(Printer& p) const {
    p.record("Model", {{"name", name}, {"mods", mods}, {"programs", programs}, {"root", root}, {"checks", checks}, {"elem", elem}, {"answer", answer}, {"elem_complete", elem_complete}, {"elem_declared", elem_declared}, {"scripts", scripts}, {"notes", notes}});
}

Pod Model::to_pod() const {
    return Pod::record("Model", {{"name", prism_rtl::to_pod(name)}, {"mods", prism_rtl::to_pod(mods)}, {"programs", prism_rtl::to_pod(programs)}, {"root", prism_rtl::to_pod(root)}, {"checks", prism_rtl::to_pod(checks)}, {"elem", prism_rtl::to_pod(elem)}, {"answer", prism_rtl::to_pod(answer)}, {"elem_complete", prism_rtl::to_pod(elem_complete)}, {"elem_declared", prism_rtl::to_pod(elem_declared)}, {"scripts", prism_rtl::to_pod(scripts)}, {"notes", prism_rtl::to_pod(notes)}});
}

Result<Model> Model::from_pod(const Pod& whole) {
    return Model{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .mods = TRY(prism_rtl::from_pod<Array<ModDef>>(TRY(prelude::field(whole, "mods")))), .programs = TRY(prism_rtl::from_pod<Array<ProgDef>>(TRY(prelude::field(whole, "programs")))), .root = TRY(prism_rtl::from_pod<std::optional<ProgDef>>(TRY(prelude::field(whole, "root")))), .checks = TRY(prism_rtl::from_pod<Array<CheckDef>>(TRY(prelude::field(whole, "checks")))), .elem = TRY(prism_rtl::from_pod<RowDef>(TRY(prelude::field(whole, "elem")))), .answer = TRY(prism_rtl::from_pod<AnswerDef>(TRY(prelude::field(whole, "answer")))), .elem_complete = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "elem_complete")))), .elem_declared = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "elem_declared")))), .scripts = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "scripts")))), .notes = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "notes"))))};
}


void NodeDef::show(Printer& p) const {
    p.record("NodeDef", {{"name", name}, {"prism", prism}, {"doc", doc}, {"params", params}, {"fields", fields}, {"consts", consts}, {"lets", lets}, {"inits", inits}, {"build", build}, {"fallible", fallible}, {"methods", methods}, {"answers", answers}, {"hooks", hooks}, {"builders", builders}, {"wakes", wakes}, {"children", children}, {"gens", gens}, {"subs", subs}, {"top", top}, {"row_kind", row_kind}, {"hosted", hosted}});
}

Pod NodeDef::to_pod() const {
    return Pod::record("NodeDef", {{"name", prism_rtl::to_pod(name)}, {"prism", prism_rtl::to_pod(prism)}, {"doc", prism_rtl::to_pod(doc)}, {"params", prism_rtl::to_pod(params)}, {"fields", prism_rtl::to_pod(fields)}, {"consts", prism_rtl::to_pod(consts)}, {"lets", prism_rtl::to_pod(lets)}, {"inits", prism_rtl::to_pod(inits)}, {"build", prism_rtl::to_pod(build)}, {"fallible", prism_rtl::to_pod(fallible)}, {"methods", prism_rtl::to_pod(methods)}, {"answers", prism_rtl::to_pod(answers)}, {"hooks", prism_rtl::to_pod(hooks)}, {"builders", prism_rtl::to_pod(builders)}, {"wakes", prism_rtl::to_pod(wakes)}, {"children", prism_rtl::to_pod(children)}, {"gens", prism_rtl::to_pod(gens)}, {"subs", prism_rtl::to_pod(subs)}, {"top", prism_rtl::to_pod(top)}, {"row_kind", prism_rtl::to_pod(row_kind)}, {"hosted", prism_rtl::to_pod(hosted)}});
}

Result<NodeDef> NodeDef::from_pod(const Pod& whole) {
    return NodeDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .prism = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "prism")))), .doc = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "doc")))), .params = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy>>>(TRY(prelude::field(whole, "params")))), .fields = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy, Text>>>(TRY(prelude::field(whole, "fields")))), .consts = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Nat, Text>>>(TRY(prelude::field(whole, "consts")))), .lets = TRY(prism_rtl::from_pod<Array<Do>>(TRY(prelude::field(whole, "lets")))), .inits = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Ex>>>(TRY(prelude::field(whole, "inits")))), .build = TRY(prism_rtl::from_pod<Array<Do>>(TRY(prelude::field(whole, "build")))), .fallible = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "fallible")))), .methods = TRY(prism_rtl::from_pod<Array<MethDef>>(TRY(prelude::field(whole, "methods")))), .answers = TRY(prism_rtl::from_pod<Array<std::tuple<Pa, Ex>>>(TRY(prelude::field(whole, "answers")))), .hooks = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Array<Do>>>>(TRY(prelude::field(whole, "hooks")))), .builders = TRY(prism_rtl::from_pod<Array<ForDef>>(TRY(prelude::field(whole, "builders")))), .wakes = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "wakes")))), .children = TRY(prism_rtl::from_pod<Array<NodeDef>>(TRY(prelude::field(whole, "children")))), .gens = TRY(prism_rtl::from_pod<Array<GenDef>>(TRY(prelude::field(whole, "gens")))), .subs = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text, OutTy>>>(TRY(prelude::field(whole, "subs")))), .top = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "top")))), .row_kind = TRY(prism_rtl::from_pod<RowKind>(TRY(prelude::field(whole, "row_kind")))), .hosted = TRY(prism_rtl::from_pod<Array<MethDef>>(TRY(prelude::field(whole, "hosted"))))};
}




void OutTy::show(Printer& p) const {
    if (auto c = std::get_if<OutNat>(&cases())) p.choice("OutNat", {});
    else if (auto c = std::get_if<OutInt>(&cases())) p.choice("OutInt", {});
    else if (auto c = std::get_if<OutU8>(&cases())) p.choice("OutU8", {});
    else if (auto c = std::get_if<OutFloat>(&cases())) p.choice("OutFloat", {});
    else if (auto c = std::get_if<OutBool>(&cases())) p.choice("OutBool", {});
    else if (auto c = std::get_if<OutChar>(&cases())) p.choice("OutChar", {});
    else if (auto c = std::get_if<OutText>(&cases())) p.choice("OutText", {});
    else if (auto c = std::get_if<OutCursor>(&cases())) p.choice("OutCursor", {});
    else if (auto c = std::get_if<OutUnit>(&cases())) p.choice("OutUnit", {});
    else if (auto c = std::get_if<OutPath>(&cases())) p.choice("OutPath", {});
    else if (auto c = std::get_if<OutDuration>(&cases())) p.choice("OutDuration", {});
    else if (auto c = std::get_if<OutError>(&cases())) p.choice("OutError", {});
    else if (auto c = std::get_if<OutNamed>(&cases())) p.choice("OutNamed", {c->a0, c->a1});
    else if (auto c = std::get_if<OutOpt>(&cases())) p.choice("OutOpt", {c->a0});
    else if (auto c = std::get_if<OutRes>(&cases())) p.choice("OutRes", {c->a0});
    else if (auto c = std::get_if<OutTuple>(&cases())) p.choice("OutTuple", {c->a0});
    else if (auto c = std::get_if<OutArray>(&cases())) p.choice("OutArray", {c->a0});
    else if (auto c = std::get_if<OutMap>(&cases())) p.choice("OutMap", {c->a0, c->a1});
    else if (auto c = std::get_if<OutFn>(&cases())) p.choice("OutFn", {c->a0, c->a1});
    else if (auto c = std::get_if<OutJobFn>(&cases())) p.choice("OutJobFn", {c->a0, c->a1});
    else if (auto c = std::get_if<OutJob>(&cases())) p.choice("OutJob", {c->a0});
    else if (auto c = std::get_if<OutEvent>(&cases())) p.choice("OutEvent", {c->a0});
    else if (auto c = std::get_if<OutDyn>(&cases())) p.choice("OutDyn", {c->a0});
    else if (auto c = std::get_if<OutGen>(&cases())) p.choice("OutGen", {c->a0});
    else if (auto c = std::get_if<OutRc>(&cases())) p.choice("OutRc", {c->a0});
    else if (auto c = std::get_if<OutRef>(&cases())) p.choice("OutRef", {c->a0});
    else if (auto c = std::get_if<OutPod>(&cases())) p.choice("OutPod", {});
    else if (auto c = std::get_if<OutShowAny>(&cases())) p.choice("OutShowAny", {});
    else if (auto c = std::get_if<OutHold>(&cases())) p.choice("OutHold", {c->a0});
    else if (auto c = std::get_if<OutStamped>(&cases())) p.choice("OutStamped", {c->a0});
    else if (auto c = std::get_if<OutSnapshot>(&cases())) p.choice("OutSnapshot", {c->a0});
    else if (auto c = std::get_if<OutDefer>(&cases())) p.choice("OutDefer", {c->a0});
    else if (auto c = std::get_if<OutWeak>(&cases())) p.choice("OutWeak", {c->a0});
    else if (auto c = std::get_if<OutCell>(&cases())) p.choice("OutCell", {c->a0});
    else if (auto c = std::get_if<OutWakes>(&cases())) p.choice("OutWakes", {});
    else if (auto c = std::get_if<OutCount>(&cases())) p.choice("OutCount", {});
    else if (auto c = std::get_if<OutObj>(&cases())) p.choice("OutObj", {c->a0});
    else if (auto c = std::get_if<OutSlice>(&cases())) p.choice("OutSlice", {c->a0});
    else if (auto c = std::get_if<OutPort>(&cases())) p.choice("OutPort", {c->a0});
    else if (auto c = std::get_if<OutLive>(&cases())) p.choice("OutLive", {c->a0});
    else if (auto c = std::get_if<OutQuantified>(&cases())) p.choice("OutQuantified", {c->a0});
    else if (auto c = std::get_if<OutUnknown>(&cases())) p.choice("OutUnknown", {c->a0});
}

Pod OutTy::to_pod() const {
    return std::holds_alternative<OutNat>(cases()) ? Pod::choice("OutNat", {})
        : std::holds_alternative<OutInt>(cases()) ? Pod::choice("OutInt", {})
        : std::holds_alternative<OutU8>(cases()) ? Pod::choice("OutU8", {})
        : std::holds_alternative<OutFloat>(cases()) ? Pod::choice("OutFloat", {})
        : std::holds_alternative<OutBool>(cases()) ? Pod::choice("OutBool", {})
        : std::holds_alternative<OutChar>(cases()) ? Pod::choice("OutChar", {})
        : std::holds_alternative<OutText>(cases()) ? Pod::choice("OutText", {})
        : std::holds_alternative<OutCursor>(cases()) ? Pod::choice("OutCursor", {})
        : std::holds_alternative<OutUnit>(cases()) ? Pod::choice("OutUnit", {})
        : std::holds_alternative<OutPath>(cases()) ? Pod::choice("OutPath", {})
        : std::holds_alternative<OutDuration>(cases()) ? Pod::choice("OutDuration", {})
        : std::holds_alternative<OutError>(cases()) ? Pod::choice("OutError", {})
        : std::holds_alternative<OutNamed>(cases()) ? Pod::choice("OutNamed", {prism_rtl::to_pod(std::get<OutNamed>(cases()).a0), prism_rtl::to_pod(std::get<OutNamed>(cases()).a1)})
        : std::holds_alternative<OutOpt>(cases()) ? Pod::choice("OutOpt", {prism_rtl::to_pod(std::get<OutOpt>(cases()).a0)})
        : std::holds_alternative<OutRes>(cases()) ? Pod::choice("OutRes", {prism_rtl::to_pod(std::get<OutRes>(cases()).a0)})
        : std::holds_alternative<OutTuple>(cases()) ? Pod::choice("OutTuple", {prism_rtl::to_pod(std::get<OutTuple>(cases()).a0)})
        : std::holds_alternative<OutArray>(cases()) ? Pod::choice("OutArray", {prism_rtl::to_pod(std::get<OutArray>(cases()).a0)})
        : std::holds_alternative<OutMap>(cases()) ? Pod::choice("OutMap", {prism_rtl::to_pod(std::get<OutMap>(cases()).a0), prism_rtl::to_pod(std::get<OutMap>(cases()).a1)})
        : std::holds_alternative<OutFn>(cases()) ? Pod::choice("OutFn", {prism_rtl::to_pod(std::get<OutFn>(cases()).a0), prism_rtl::to_pod(std::get<OutFn>(cases()).a1)})
        : std::holds_alternative<OutJobFn>(cases()) ? Pod::choice("OutJobFn", {prism_rtl::to_pod(std::get<OutJobFn>(cases()).a0), prism_rtl::to_pod(std::get<OutJobFn>(cases()).a1)})
        : std::holds_alternative<OutJob>(cases()) ? Pod::choice("OutJob", {prism_rtl::to_pod(std::get<OutJob>(cases()).a0)})
        : std::holds_alternative<OutEvent>(cases()) ? Pod::choice("OutEvent", {prism_rtl::to_pod(std::get<OutEvent>(cases()).a0)})
        : std::holds_alternative<OutDyn>(cases()) ? Pod::choice("OutDyn", {prism_rtl::to_pod(std::get<OutDyn>(cases()).a0)})
        : std::holds_alternative<OutGen>(cases()) ? Pod::choice("OutGen", {prism_rtl::to_pod(std::get<OutGen>(cases()).a0)})
        : std::holds_alternative<OutRc>(cases()) ? Pod::choice("OutRc", {prism_rtl::to_pod(std::get<OutRc>(cases()).a0)})
        : std::holds_alternative<OutRef>(cases()) ? Pod::choice("OutRef", {prism_rtl::to_pod(std::get<OutRef>(cases()).a0)})
        : std::holds_alternative<OutPod>(cases()) ? Pod::choice("OutPod", {})
        : std::holds_alternative<OutShowAny>(cases()) ? Pod::choice("OutShowAny", {})
        : std::holds_alternative<OutHold>(cases()) ? Pod::choice("OutHold", {prism_rtl::to_pod(std::get<OutHold>(cases()).a0)})
        : std::holds_alternative<OutStamped>(cases()) ? Pod::choice("OutStamped", {prism_rtl::to_pod(std::get<OutStamped>(cases()).a0)})
        : std::holds_alternative<OutSnapshot>(cases()) ? Pod::choice("OutSnapshot", {prism_rtl::to_pod(std::get<OutSnapshot>(cases()).a0)})
        : std::holds_alternative<OutDefer>(cases()) ? Pod::choice("OutDefer", {prism_rtl::to_pod(std::get<OutDefer>(cases()).a0)})
        : std::holds_alternative<OutWeak>(cases()) ? Pod::choice("OutWeak", {prism_rtl::to_pod(std::get<OutWeak>(cases()).a0)})
        : std::holds_alternative<OutCell>(cases()) ? Pod::choice("OutCell", {prism_rtl::to_pod(std::get<OutCell>(cases()).a0)})
        : std::holds_alternative<OutWakes>(cases()) ? Pod::choice("OutWakes", {})
        : std::holds_alternative<OutCount>(cases()) ? Pod::choice("OutCount", {})
        : std::holds_alternative<OutObj>(cases()) ? Pod::choice("OutObj", {prism_rtl::to_pod(std::get<OutObj>(cases()).a0)})
        : std::holds_alternative<OutSlice>(cases()) ? Pod::choice("OutSlice", {prism_rtl::to_pod(std::get<OutSlice>(cases()).a0)})
        : std::holds_alternative<OutPort>(cases()) ? Pod::choice("OutPort", {prism_rtl::to_pod(std::get<OutPort>(cases()).a0)})
        : std::holds_alternative<OutLive>(cases()) ? Pod::choice("OutLive", {prism_rtl::to_pod(std::get<OutLive>(cases()).a0)})
        : std::holds_alternative<OutQuantified>(cases()) ? Pod::choice("OutQuantified", {prism_rtl::to_pod(std::get<OutQuantified>(cases()).a0)})
        : std::holds_alternative<OutUnknown>(cases()) ? Pod::choice("OutUnknown", {prism_rtl::to_pod(std::get<OutUnknown>(cases()).a0)})
        : Pod();
}

Result<OutTy> OutTy::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "OutNat" && c->args.size() == 0) return OutTy(OutNat{});
        if (c->ctor == "OutInt" && c->args.size() == 0) return OutTy(OutInt{});
        if (c->ctor == "OutU8" && c->args.size() == 0) return OutTy(OutU8{});
        if (c->ctor == "OutFloat" && c->args.size() == 0) return OutTy(OutFloat{});
        if (c->ctor == "OutBool" && c->args.size() == 0) return OutTy(OutBool{});
        if (c->ctor == "OutChar" && c->args.size() == 0) return OutTy(OutChar{});
        if (c->ctor == "OutText" && c->args.size() == 0) return OutTy(OutText{});
        if (c->ctor == "OutCursor" && c->args.size() == 0) return OutTy(OutCursor{});
        if (c->ctor == "OutUnit" && c->args.size() == 0) return OutTy(OutUnit{});
        if (c->ctor == "OutPath" && c->args.size() == 0) return OutTy(OutPath{});
        if (c->ctor == "OutDuration" && c->args.size() == 0) return OutTy(OutDuration{});
        if (c->ctor == "OutError" && c->args.size() == 0) return OutTy(OutError{});
        if (c->ctor == "OutNamed" && c->args.size() == 2) return OutTy(OutNamed{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<OutTy>>(c->args[1]))});
        if (c->ctor == "OutOpt" && c->args.size() == 1) return OutTy(OutOpt{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutRes" && c->args.size() == 1) return OutTy(OutRes{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutTuple" && c->args.size() == 1) return OutTy(OutTuple{TRY(prism_rtl::from_pod<Array<OutTy>>(c->args[0]))});
        if (c->ctor == "OutArray" && c->args.size() == 1) return OutTy(OutArray{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutMap" && c->args.size() == 2) return OutTy(OutMap{TRY(prism_rtl::from_pod<OutTy>(c->args[0])), TRY(prism_rtl::from_pod<OutTy>(c->args[1]))});
        if (c->ctor == "OutFn" && c->args.size() == 2) return OutTy(OutFn{TRY(prism_rtl::from_pod<Array<OutTy>>(c->args[0])), TRY(prism_rtl::from_pod<OutTy>(c->args[1]))});
        if (c->ctor == "OutJobFn" && c->args.size() == 2) return OutTy(OutJobFn{TRY(prism_rtl::from_pod<OutTy>(c->args[0])), TRY(prism_rtl::from_pod<OutTy>(c->args[1]))});
        if (c->ctor == "OutJob" && c->args.size() == 1) return OutTy(OutJob{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutEvent" && c->args.size() == 1) return OutTy(OutEvent{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutDyn" && c->args.size() == 1) return OutTy(OutDyn{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutGen" && c->args.size() == 1) return OutTy(OutGen{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "OutRc" && c->args.size() == 1) return OutTy(OutRc{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutRef" && c->args.size() == 1) return OutTy(OutRef{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutPod" && c->args.size() == 0) return OutTy(OutPod{});
        if (c->ctor == "OutShowAny" && c->args.size() == 0) return OutTy(OutShowAny{});
        if (c->ctor == "OutHold" && c->args.size() == 1) return OutTy(OutHold{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutStamped" && c->args.size() == 1) return OutTy(OutStamped{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutSnapshot" && c->args.size() == 1) return OutTy(OutSnapshot{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutDefer" && c->args.size() == 1) return OutTy(OutDefer{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutWeak" && c->args.size() == 1) return OutTy(OutWeak{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "OutCell" && c->args.size() == 1) return OutTy(OutCell{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutWakes" && c->args.size() == 0) return OutTy(OutWakes{});
        if (c->ctor == "OutCount" && c->args.size() == 0) return OutTy(OutCount{});
        if (c->ctor == "OutObj" && c->args.size() == 1) return OutTy(OutObj{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutSlice" && c->args.size() == 1) return OutTy(OutSlice{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutPort" && c->args.size() == 1) return OutTy(OutPort{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutLive" && c->args.size() == 1) return OutTy(OutLive{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutQuantified" && c->args.size() == 1) return OutTy(OutQuantified{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "OutUnknown" && c->args.size() == 1) return OutTy(OutUnknown{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<OutTy>("a OutTy", p);
}


void Pa::show(Printer& p) const {
    if (auto c = std::get_if<PaWild>(&cases())) p.choice("PaWild", {});
    else if (auto c = std::get_if<PaBind>(&cases())) p.choice("PaBind", {c->a0});
    else if (auto c = std::get_if<PaMut>(&cases())) p.choice("PaMut", {c->a0});
    else if (auto c = std::get_if<PaCtor>(&cases())) p.choice("PaCtor", {c->a0, c->a1});
    else if (auto c = std::get_if<PaUnit>(&cases())) p.choice("PaUnit", {c->a0});
    else if (auto c = std::get_if<PaRecord>(&cases())) p.choice("PaRecord", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<PaTuple>(&cases())) p.choice("PaTuple", {c->a0});
    else if (auto c = std::get_if<PaChar>(&cases())) p.choice("PaChar", {c->a0});
    else if (auto c = std::get_if<PaBool>(&cases())) p.choice("PaBool", {c->a0});
    else if (auto c = std::get_if<PaIndex>(&cases())) p.choice("PaIndex", {c->a0});
    else if (auto c = std::get_if<PaConst>(&cases())) p.choice("PaConst", {c->a0});
    else if (auto c = std::get_if<PaSlice>(&cases())) p.choice("PaSlice", {c->a0});
    else if (auto c = std::get_if<PaRest>(&cases())) p.choice("PaRest", {c->a0});
    else if (auto c = std::get_if<PaTyped>(&cases())) p.choice("PaTyped", {c->a0, c->a1});
}

Pod Pa::to_pod() const {
    return std::holds_alternative<PaWild>(cases()) ? Pod::choice("PaWild", {})
        : std::holds_alternative<PaBind>(cases()) ? Pod::choice("PaBind", {prism_rtl::to_pod(std::get<PaBind>(cases()).a0)})
        : std::holds_alternative<PaMut>(cases()) ? Pod::choice("PaMut", {prism_rtl::to_pod(std::get<PaMut>(cases()).a0)})
        : std::holds_alternative<PaCtor>(cases()) ? Pod::choice("PaCtor", {prism_rtl::to_pod(std::get<PaCtor>(cases()).a0), prism_rtl::to_pod(std::get<PaCtor>(cases()).a1)})
        : std::holds_alternative<PaUnit>(cases()) ? Pod::choice("PaUnit", {prism_rtl::to_pod(std::get<PaUnit>(cases()).a0)})
        : std::holds_alternative<PaRecord>(cases()) ? Pod::choice("PaRecord", {prism_rtl::to_pod(std::get<PaRecord>(cases()).a0), prism_rtl::to_pod(std::get<PaRecord>(cases()).a1), prism_rtl::to_pod(std::get<PaRecord>(cases()).a2)})
        : std::holds_alternative<PaTuple>(cases()) ? Pod::choice("PaTuple", {prism_rtl::to_pod(std::get<PaTuple>(cases()).a0)})
        : std::holds_alternative<PaChar>(cases()) ? Pod::choice("PaChar", {prism_rtl::to_pod(std::get<PaChar>(cases()).a0)})
        : std::holds_alternative<PaBool>(cases()) ? Pod::choice("PaBool", {prism_rtl::to_pod(std::get<PaBool>(cases()).a0)})
        : std::holds_alternative<PaIndex>(cases()) ? Pod::choice("PaIndex", {prism_rtl::to_pod(std::get<PaIndex>(cases()).a0)})
        : std::holds_alternative<PaConst>(cases()) ? Pod::choice("PaConst", {prism_rtl::to_pod(std::get<PaConst>(cases()).a0)})
        : std::holds_alternative<PaSlice>(cases()) ? Pod::choice("PaSlice", {prism_rtl::to_pod(std::get<PaSlice>(cases()).a0)})
        : std::holds_alternative<PaRest>(cases()) ? Pod::choice("PaRest", {prism_rtl::to_pod(std::get<PaRest>(cases()).a0)})
        : std::holds_alternative<PaTyped>(cases()) ? Pod::choice("PaTyped", {prism_rtl::to_pod(std::get<PaTyped>(cases()).a0), prism_rtl::to_pod(std::get<PaTyped>(cases()).a1)})
        : Pod();
}

Result<Pa> Pa::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "PaWild" && c->args.size() == 0) return Pa(PaWild{});
        if (c->ctor == "PaBind" && c->args.size() == 1) return Pa(PaBind{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PaMut" && c->args.size() == 1) return Pa(PaMut{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PaCtor" && c->args.size() == 2) return Pa(PaCtor{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Pa>>(c->args[1]))});
        if (c->ctor == "PaUnit" && c->args.size() == 1) return Pa(PaUnit{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PaRecord" && c->args.size() == 3) return Pa(PaRecord{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<std::tuple<Text, Pa>>>(c->args[1])), TRY(prism_rtl::from_pod<bool>(c->args[2]))});
        if (c->ctor == "PaTuple" && c->args.size() == 1) return Pa(PaTuple{TRY(prism_rtl::from_pod<Array<Pa>>(c->args[0]))});
        if (c->ctor == "PaChar" && c->args.size() == 1) return Pa(PaChar{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PaBool" && c->args.size() == 1) return Pa(PaBool{TRY(prism_rtl::from_pod<bool>(c->args[0]))});
        if (c->ctor == "PaIndex" && c->args.size() == 1) return Pa(PaIndex{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "PaConst" && c->args.size() == 1) return Pa(PaConst{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PaSlice" && c->args.size() == 1) return Pa(PaSlice{TRY(prism_rtl::from_pod<Array<Pa>>(c->args[0]))});
        if (c->ctor == "PaRest" && c->args.size() == 1) return Pa(PaRest{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PaTyped" && c->args.size() == 2) return Pa(PaTyped{TRY(prism_rtl::from_pod<Pa>(c->args[0])), TRY(prism_rtl::from_pod<OutTy>(c->args[1]))});
    }
    return mismatch<Pa>("a Pa", p);
}






Pod Place::to_pod() const {
    return Pod::record("Place", {{"pos", prism_rtl::to_pod(pos)}, {"level", prism_rtl::to_pod(level)}, {"getter", prism_rtl::to_pod(getter)}, {"reads", prism_rtl::to_pod(reads)}});
}

Result<Place> Place::from_pod(const Pod& whole) {
    return Place{.pos = TRY(prism_rtl::from_pod<Pos_>(TRY(prelude::field(whole, "pos")))), .level = TRY(prism_rtl::from_pod<Ex>(TRY(prelude::field(whole, "level")))), .getter = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "getter")))), .reads = TRY(prism_rtl::from_pod<Array<Read>>(TRY(prelude::field(whole, "reads"))))};
}


void Pos_::show(Printer& p) const {
    p.record("Pos", {{"scope", scope}, {"at", at}});
}

Pod Pos_::to_pod() const {
    return Pod::record("Pos", {{"scope", prism_rtl::to_pod(scope)}, {"at", prism_rtl::to_pod(at)}});
}

Result<Pos_> Pos_::from_pod(const Pod& whole) {
    return Pos_{.scope = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "scope")))), .at = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "at"))))};
}


void ProgDef::show(Printer& p) const {
    p.record("ProgDef", {{"name", name}, {"prism", prism}, {"node", node_}, {"params", params}, {"fallible", fallible}, {"world", world}});
}

Pod ProgDef::to_pod() const {
    return Pod::record("ProgDef", {{"name", prism_rtl::to_pod(name)}, {"prism", prism_rtl::to_pod(prism)}, {"node", prism_rtl::to_pod(node_)}, {"params", prism_rtl::to_pod(params)}, {"fallible", prism_rtl::to_pod(fallible)}, {"world", prism_rtl::to_pod(world)}});
}

Result<ProgDef> ProgDef::from_pod(const Pod& whole) {
    return ProgDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .prism = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "prism")))), .node_ = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "node")))), .params = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy>>>(TRY(prelude::field(whole, "params")))), .fallible = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "fallible")))), .world = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "world"))))};
}


void Read::show(Printer& p) const {
    if (auto c = std::get_if<OwnRead>(&cases())) p.choice("OwnRead", {c->a0});
    else if (auto c = std::get_if<ParentRead>(&cases())) p.choice("ParentRead", {c->a0});
}

Pod Read::to_pod() const {
    return std::holds_alternative<OwnRead>(cases()) ? Pod::choice("OwnRead", {prism_rtl::to_pod(std::get<OwnRead>(cases()).a0)})
        : std::holds_alternative<ParentRead>(cases()) ? Pod::choice("ParentRead", {prism_rtl::to_pod(std::get<ParentRead>(cases()).a0)})
        : Pod();
}

Result<Read> Read::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "OwnRead" && c->args.size() == 1) return Read(OwnRead{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "ParentRead" && c->args.size() == 1) return Read(ParentRead{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Read>("a Read", p);
}


void Recv::show(Printer& p) const {
    if (auto c = std::get_if<RecvRc>(&cases())) p.choice("RecvRc", {});
    else if (auto c = std::get_if<RecvRef>(&cases())) p.choice("RecvRef", {});
    else if (auto c = std::get_if<RecvOwned>(&cases())) p.choice("RecvOwned", {});
}

Pod Recv::to_pod() const {
    return std::holds_alternative<RecvRc>(cases()) ? Pod::choice("RecvRc", {})
        : std::holds_alternative<RecvRef>(cases()) ? Pod::choice("RecvRef", {})
        : std::holds_alternative<RecvOwned>(cases()) ? Pod::choice("RecvOwned", {})
        : Pod();
}

Result<Recv> Recv::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "RecvRc" && c->args.size() == 0) return Recv(RecvRc{});
        if (c->ctor == "RecvRef" && c->args.size() == 0) return Recv(RecvRef{});
        if (c->ctor == "RecvOwned" && c->args.size() == 0) return Recv(RecvOwned{});
    }
    return mismatch<Recv>("a Recv", p);
}


void RowDef::show(Printer& p) const {
    p.record("RowDef", {{"name", name}, {"prism", prism}, {"cases", cases_}, {"pod", pod}, {"doc", doc}});
}

Pod RowDef::to_pod() const {
    return Pod::record("RowDef", {{"name", prism_rtl::to_pod(name)}, {"prism", prism_rtl::to_pod(prism)}, {"cases", prism_rtl::to_pod(cases_)}, {"pod", prism_rtl::to_pod(pod)}, {"doc", prism_rtl::to_pod(doc)}});
}

Result<RowDef> RowDef::from_pod(const Pod& whole) {
    return RowDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .prism = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "prism")))), .cases_ = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(prelude::field(whole, "cases")))), .pod = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "pod")))), .doc = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "doc"))))};
}


void RowKind::show(Printer& p) const {
    if (auto c = std::get_if<ForRow>(&cases())) p.choice("ForRow", {});
    else if (auto c = std::get_if<GenerationRow>(&cases())) p.choice("GenerationRow", {});
    else if (auto c = std::get_if<NotARow>(&cases())) p.choice("NotARow", {});
}

Pod RowKind::to_pod() const {
    return std::holds_alternative<ForRow>(cases()) ? Pod::choice("ForRow", {})
        : std::holds_alternative<GenerationRow>(cases()) ? Pod::choice("GenerationRow", {})
        : std::holds_alternative<NotARow>(cases()) ? Pod::choice("NotARow", {})
        : Pod();
}

Result<RowKind> RowKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "ForRow" && c->args.size() == 0) return RowKind(ForRow{});
        if (c->ctor == "GenerationRow" && c->args.size() == 0) return RowKind(GenerationRow{});
        if (c->ctor == "NotARow" && c->args.size() == 0) return RowKind(NotARow{});
    }
    return mismatch<RowKind>("a RowKind", p);
}


Pod RowLocal::to_pod() const {
    return Pod::record("RowLocal", {{"name", prism_rtl::to_pod(name)}, {"field", prism_rtl::to_pod(field)}, {"ty", prism_rtl::to_pod(ty)}, {"passed", prism_rtl::to_pod(passed)}});
}

Result<RowLocal> RowLocal::from_pod(const Pod& whole) {
    return RowLocal{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .field = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "field")))), .ty = TRY(prism_rtl::from_pod<OutTy>(TRY(prelude::field(whole, "ty")))), .passed = TRY(prism_rtl::from_pod<Ex>(TRY(prelude::field(whole, "passed"))))};
}


Pod RowMarks::to_pod() const {
    return Pod::record("RowMarks", {{"builder", prism_rtl::to_pod(builder)}, {"reads", prism_rtl::to_pod(reads)}, {"wrote", prism_rtl::to_pod(wrote)}, {"kind", prism_rtl::to_pod(kind)}});
}

Result<RowMarks> RowMarks::from_pod(const Pod& whole) {
    return RowMarks{.builder = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "builder")))), .reads = TRY(prism_rtl::from_pod<Array<Read>>(TRY(prelude::field(whole, "reads")))), .wrote = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "wrote")))), .kind = TRY(prism_rtl::from_pod<RowKind>(TRY(prelude::field(whole, "kind"))))};
}


void Shown::show(Printer& p) const {
    if (auto c = std::get_if<ShownOwn>(&cases())) p.choice("ShownOwn", {});
    else if (auto c = std::get_if<ShownDerived>(&cases())) p.choice("ShownDerived", {});
    else if (auto c = std::get_if<NotShown>(&cases())) p.choice("NotShown", {});
}

Pod Shown::to_pod() const {
    return std::holds_alternative<ShownOwn>(cases()) ? Pod::choice("ShownOwn", {})
        : std::holds_alternative<ShownDerived>(cases()) ? Pod::choice("ShownDerived", {})
        : std::holds_alternative<NotShown>(cases()) ? Pod::choice("NotShown", {})
        : Pod();
}

Result<Shown> Shown::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "ShownOwn" && c->args.size() == 0) return Shown(ShownOwn{});
        if (c->ctor == "ShownDerived" && c->args.size() == 0) return Shown(ShownDerived{});
        if (c->ctor == "NotShown" && c->args.size() == 0) return Shown(NotShown{});
    }
    return mismatch<Shown>("a Shown", p);
}




Pod Sk::to_pod() const {
    return std::holds_alternative<SkNode>(cases()) ? Pod::choice("SkNode", {prism_rtl::to_pod(std::get<SkNode>(cases()).a0)})
        : std::holds_alternative<SkIn>(cases()) ? Pod::choice("SkIn", {prism_rtl::to_pod(std::get<SkIn>(cases()).a0), prism_rtl::to_pod(std::get<SkIn>(cases()).a1)})
        : std::holds_alternative<SkHold>(cases()) ? Pod::choice("SkHold", {prism_rtl::to_pod(std::get<SkHold>(cases()).a0)})
        : std::holds_alternative<SkRequest>(cases()) ? Pod::choice("SkRequest", {prism_rtl::to_pod(std::get<SkRequest>(cases()).a0), prism_rtl::to_pod(std::get<SkRequest>(cases()).a1)})
        : std::holds_alternative<SkResult>(cases()) ? Pod::choice("SkResult", {})
        : std::holds_alternative<SkArm>(cases()) ? Pod::choice("SkArm", {prism_rtl::to_pod(std::get<SkArm>(cases()).a0)})
        : std::holds_alternative<SkCycle>(cases()) ? Pod::choice("SkCycle", {prism_rtl::to_pod(std::get<SkCycle>(cases()).a0), prism_rtl::to_pod(std::get<SkCycle>(cases()).a1), prism_rtl::to_pod(std::get<SkCycle>(cases()).a2)})
        : std::holds_alternative<SkUp>(cases()) ? Pod::choice("SkUp", {prism_rtl::to_pod(std::get<SkUp>(cases()).a0)})
        : std::holds_alternative<SkPort>(cases()) ? Pod::choice("SkPort", {prism_rtl::to_pod(std::get<SkPort>(cases()).a0)})
        : std::holds_alternative<SkMachine>(cases()) ? Pod::choice("SkMachine", {prism_rtl::to_pod(std::get<SkMachine>(cases()).a0), prism_rtl::to_pod(std::get<SkMachine>(cases()).a1), prism_rtl::to_pod(std::get<SkMachine>(cases()).a2)})
        : Pod();
}

Result<Sk> Sk::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "SkNode" && c->args.size() == 1) return Sk(SkNode{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "SkIn" && c->args.size() == 2) return Sk(SkIn{TRY(prism_rtl::from_pod<Nat>(c->args[0])), TRY(prism_rtl::from_pod<Nat>(c->args[1]))});
        if (c->ctor == "SkHold" && c->args.size() == 1) return Sk(SkHold{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SkRequest" && c->args.size() == 2) return Sk(SkRequest{TRY(prism_rtl::from_pod<Pos_>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "SkResult" && c->args.size() == 0) return Sk(SkResult{});
        if (c->ctor == "SkArm" && c->args.size() == 1) return Sk(SkArm{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SkCycle" && c->args.size() == 3) return Sk(SkCycle{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Nat>(c->args[2]))});
        if (c->ctor == "SkUp" && c->args.size() == 1) return Sk(SkUp{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SkPort" && c->args.size() == 1) return Sk(SkPort{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SkMachine" && c->args.size() == 3) return Sk(SkMachine{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Nat>(c->args[2]))});
    }
    return mismatch<Sk>("a Sk", p);
}


Pod SnapDef::to_pod() const {
    return Pod::record("SnapDef", {{"name", prism_rtl::to_pod(name)}, {"live", prism_rtl::to_pod(live)}, {"ty", prism_rtl::to_pod(ty)}, {"eq", prism_rtl::to_pod(eq)}, {"builder", prism_rtl::to_pod(builder)}, {"before", prism_rtl::to_pod(before)}, {"what", prism_rtl::to_pod(what)}});
}

Result<SnapDef> SnapDef::from_pod(const Pod& whole) {
    return SnapDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .live = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "live")))), .ty = TRY(prism_rtl::from_pod<OutTy>(TRY(prelude::field(whole, "ty")))), .eq = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "eq")))), .builder = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "builder")))), .before = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "before")))), .what = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "what"))))};
}


void TagDef::show(Printer& p) const {
    p.record("TagDef", {{"name", name}, {"tag_name", tag_name}, {"fields", fields}, {"doc", doc}, {"pod", pod}});
}

Pod TagDef::to_pod() const {
    return Pod::record("TagDef", {{"name", prism_rtl::to_pod(name)}, {"tag_name", prism_rtl::to_pod(tag_name)}, {"fields", prism_rtl::to_pod(fields)}, {"doc", prism_rtl::to_pod(doc)}, {"pod", prism_rtl::to_pod(pod)}});
}

Result<TagDef> TagDef::from_pod(const Pod& whole) {
    return TagDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .tag_name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "tag_name")))), .fields = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text, OutTy>>>(TRY(prelude::field(whole, "fields")))), .doc = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "doc")))), .pod = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "pod"))))};
}


void TraitDef::show(Printer& p) const {
    p.record("TraitDef", {{"name", name}, {"methods", methods}, {"defaults", defaults}, {"doc", doc}});
}

Pod TraitDef::to_pod() const {
    return Pod::record("TraitDef", {{"name", prism_rtl::to_pod(name)}, {"methods", prism_rtl::to_pod(methods)}, {"defaults", prism_rtl::to_pod(defaults)}, {"doc", prism_rtl::to_pod(doc)}});
}

Result<TraitDef> TraitDef::from_pod(const Pod& whole) {
    return TraitDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .methods = TRY(prism_rtl::from_pod<Array<FnDef>>(TRY(prelude::field(whole, "methods")))), .defaults = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "defaults")))), .doc = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "doc"))))};
}


void TyDef::show(Printer& p) const {
    p.record("TyDef", {{"name", name}, {"prism", prism}, {"params", params}, {"shape", shape}, {"cases", cases_}, {"eq", eq}, {"ord", ord}, {"floaty", floaty}, {"show", show_}, {"pod", pod}, {"doc", doc}});
}

Pod TyDef::to_pod() const {
    return Pod::record("TyDef", {{"name", prism_rtl::to_pod(name)}, {"prism", prism_rtl::to_pod(prism)}, {"params", prism_rtl::to_pod(params)}, {"shape", prism_rtl::to_pod(shape)}, {"cases", prism_rtl::to_pod(cases_)}, {"eq", prism_rtl::to_pod(eq)}, {"ord", prism_rtl::to_pod(ord)}, {"floaty", prism_rtl::to_pod(floaty)}, {"show", prism_rtl::to_pod(show_)}, {"pod", prism_rtl::to_pod(pod)}, {"doc", prism_rtl::to_pod(doc)}});
}

Result<TyDef> TyDef::from_pod(const Pod& whole) {
    return TyDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .prism = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "prism")))), .params = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "params")))), .shape = TRY(prism_rtl::from_pod<TyShape>(TRY(prelude::field(whole, "shape")))), .cases_ = TRY(prism_rtl::from_pod<Array<CaseDef>>(TRY(prelude::field(whole, "cases")))), .eq = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "eq")))), .ord = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "ord")))), .floaty = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "floaty")))), .show_ = TRY(prism_rtl::from_pod<Shown>(TRY(prelude::field(whole, "show")))), .pod = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "pod")))), .doc = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "doc"))))};
}


void TyShape::show(Printer& p) const {
    if (auto c = std::get_if<ShapeRecord>(&cases())) p.choice("ShapeRecord", {});
    else if (auto c = std::get_if<ShapeChoice>(&cases())) p.choice("ShapeChoice", {});
    else if (auto c = std::get_if<ShapeNewtype>(&cases())) p.choice("ShapeNewtype", {});
    else if (auto c = std::get_if<ShapeUnit>(&cases())) p.choice("ShapeUnit", {});
}

Pod TyShape::to_pod() const {
    return std::holds_alternative<ShapeRecord>(cases()) ? Pod::choice("ShapeRecord", {})
        : std::holds_alternative<ShapeChoice>(cases()) ? Pod::choice("ShapeChoice", {})
        : std::holds_alternative<ShapeNewtype>(cases()) ? Pod::choice("ShapeNewtype", {})
        : std::holds_alternative<ShapeUnit>(cases()) ? Pod::choice("ShapeUnit", {})
        : Pod();
}

Result<TyShape> TyShape::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "ShapeRecord" && c->args.size() == 0) return TyShape(ShapeRecord{});
        if (c->ctor == "ShapeChoice" && c->args.size() == 0) return TyShape(ShapeChoice{});
        if (c->ctor == "ShapeNewtype" && c->args.size() == 0) return TyShape(ShapeNewtype{});
        if (c->ctor == "ShapeUnit" && c->args.size() == 0) return TyShape(ShapeUnit{});
    }
    return mismatch<TyShape>("a TyShape", p);
}


Pod Vl::to_pod() const {
    return std::holds_alternative<VlPlace>(cases()) ? Pod::choice("VlPlace", {prism_rtl::to_pod(std::get<VlPlace>(cases()).a0), prism_rtl::to_pod(std::get<VlPlace>(cases()).a1), prism_rtl::to_pod(std::get<VlPlace>(cases()).a2)})
        : std::holds_alternative<VlOwned>(cases()) ? Pod::choice("VlOwned", {prism_rtl::to_pod(std::get<VlOwned>(cases()).a0), prism_rtl::to_pod(std::get<VlOwned>(cases()).a1)})
        : Pod();
}

Result<Vl> Vl::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "VlPlace" && c->args.size() == 3) return Vl(VlPlace{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Holding>(c->args[1])), TRY(prism_rtl::from_pod<OutTy>(c->args[2]))});
        if (c->ctor == "VlOwned" && c->args.size() == 2) return Vl(VlOwned{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<OutTy>(c->args[1]))});
    }
    return mismatch<Vl>("a Vl", p);
}






void XArm::show(Printer& p) const {
    p.record("XArm", {{"pat", pat}, {"conds", conds}, {"body", body}});
}

Pod XArm::to_pod() const {
    return Pod::record("XArm", {{"pat", prism_rtl::to_pod(pat)}, {"conds", prism_rtl::to_pod(conds)}, {"body", prism_rtl::to_pod(body)}});
}

Result<XArm> XArm::from_pod(const Pod& whole) {
    return XArm{.pat = TRY(prism_rtl::from_pod<Pa>(TRY(prelude::field(whole, "pat")))), .conds = TRY(prism_rtl::from_pod<Array<Cc>>(TRY(prelude::field(whole, "conds")))), .body = TRY(prism_rtl::from_pod<Ex>(TRY(prelude::field(whole, "body"))))};
}


/// let pos0
Pos_ pos0() {
    return Pos_{.scope = Nat(0u), .at = Nat(0u)};
}


/// NextPos: fn Pos -> Pos
Pos_ next_pos(const Pos_& p_) {
    Pos_ this_ = p_;
    this_.at = this_.at + Nat(1u);
    return this_;
}


/// ScopePos: fn Nat -> Pos
Pos_ scope_pos(const Nat& k) {
    return Pos_{.scope = k, .at = Nat(0u)};
}


/// PlaceText: fn Pos -> Text
Text place_text(const Pos_& p_) {
    return p_.scope == Nat(0u)
        ? prism_rtl::cat(p_.at)
        : prism_rtl::cat("h", p_.scope, "_", p_.at);
}


/// PlaceKey: fn Lx, Range -> Text
Text place_key(const Lx& lx, const ast::Range& r) {
    return prism_rtl::cat(lx->file, ":", r.start, ":", r.end);
}


/// TypeAt: fn Lx, Range -> Ty
check_types::Ty type_at(const Lx& lx, const ast::Range& r) {
    return subst_ty(lx, or_(prelude::get(lx.tys, place_key(lx, r)), check_types::Ty(check_types::Ty::TyErr{})));
}


/// BinderTy: fn Lx, Range -> Ty
check_types::Ty binder_ty(const Lx& lx, const ast::Range& r) {
    auto&& _m = prelude::get(lx.binders, place_key(lx, r));
    if (prism_rtl::is_some(_m)) {
        auto&& t = prism_rtl::some_of(_m);
        return subst_ty(lx, t);
    }
    if (prism_rtl::is_none(_m)) {
        return type_at(lx, r);
    }
    prism_rtl::unreachable("no arm matched");
}


/// SubstTy: fn Lx, Ty -> Ty
check_types::Ty subst_ty(const Lx& lx, const check_types::Ty& t) {
    return (len(keys(lx.subst)) == Nat(0u)) && (len(keys(lx.csubst)) == Nat(0u))
        ? t
        : subst_ty_in(lx, t);
}


/// SubstTyIn: fn Lx, Ty -> Ty
check_types::Ty subst_ty_in(const Lx& lx, const check_types::Ty& t) {
    if (prism_rtl::is<check_types::Ty::TyFlex>(t)) {
        auto&& n = prism_rtl::as<check_types::Ty::TyFlex>(t).a0;
        return or_(prelude::get(lx.subst, prism_rtl::cat("'", n)), t);
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        return check_types::Ty(check_types::Ty::TyCon{n, each(args, [&](const check_types::Ty& a) { return subst_ty_in(lx, a); })});
    }
    if (prism_rtl::is<check_types::Ty::TyFn>(t)) {
        auto&& c = prism_rtl::as<check_types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<check_types::Ty::TyFn>(t).a2;
        return check_types::Ty(check_types::Ty::TyFn{inst_col(lx, c), each(ps, [&](const check_types::Ty& p_) { return subst_ty_in(lx, p_); }), prism_rtl::rc(subst_ty_in(lx, res))});
    }
    if (prism_rtl::is<check_types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        return check_types::Ty(check_types::Ty::TyTuple{each(ts, [&](const check_types::Ty& a) { return subst_ty_in(lx, a); })});
    }
    if (prism_rtl::is<check_types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
        return check_types::Ty(check_types::Ty::TyArray{prism_rtl::rc(subst_ty_in(lx, e))});
    }
    if (prism_rtl::is<check_types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
        return check_types::Ty(check_types::Ty::TyMap{prism_rtl::rc(subst_ty_in(lx, k)), prism_rtl::rc(subst_ty_in(lx, v_))});
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& s = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        return check_types::Ty(check_types::Ty::TySig{s, prism_rtl::rc(subst_ty_in(lx, i))});
    }
    if (prism_rtl::is<check_types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<check_types::Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<check_types::Ty::TyAt>(t).a1;
        return check_types::Ty(check_types::Ty::TyAt{prism_rtl::rc(subst_ty_in(lx, i)), rw});
    }
    if (prism_rtl::is<check_types::Ty::TyElem>(t)) {
        auto&& rw = prism_rtl::as<check_types::Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<check_types::Ty::TyElem>(t).a1;
        return check_types::Ty(check_types::Ty::TyElem{rw, prism_rtl::rc(subst_ty_in(lx, o))});
    }
    if (prism_rtl::is<check_types::Ty::TyAssoc>(t)) {
        auto&& n = prism_rtl::as<check_types::Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<check_types::Ty::TyAssoc>(t).a1;
        return check_types::Ty(check_types::Ty::TyAssoc{n, prism_rtl::rc(subst_ty_in(lx, a))});
    }
    {
        auto&& other = t;
        return other;
    }
}


/// InstCol: fn Lx, Col -> Col
check_types::Col inst_col(const Lx& lx, const check_types::Col& col1) {
    if (prism_rtl::is<check_types::Col::CQ>(col1)) {
        auto&& q = prism_rtl::as<check_types::Col::CQ>(col1).a0;
        return or_(prelude::get(lx.csubst, q), check_types::Col(check_types::Col::CQ{q}));
    }
    {
        auto&& c = col1;
        return c;
    }
}


/// IsQuantCol: fn Lx, Col -> Bool
bool is_quant_col(const Lx& lx, const check_types::Col& col1) {
    if (prism_rtl::is<check_types::Col::CQ>(col1)) {
        auto&& q = prism_rtl::as<check_types::Col::CQ>(col1).a0;
        return check_env::has_key(lx.quants, q);
    }
    {
        auto&& c = col1;
        return false;
    }
}


/// TypedTables: fn TProgram -> (((Text ==> Ty), (Text ==> AppNote), (Text ==> Ty), (Text ==> [ImplNote])))
std::tuple<Map<Text, check_types::Ty>, Map<Text, typed::AppNote>, Map<Text, check_types::Ty>, Map<Text, Array<typed::ImplNote>>> typed_tables(const typed::TProgram& tp) {
    auto tys = fold(tp.exprs, Map<Text, check_types::Ty>{}, [&](const Map<Text, check_types::Ty>& m, const typed::TyNote& n) { return insert(m, typed::at_key(n.at), n.ty); });
    auto apps = fold(tp.apps, Map<Text, typed::AppNote>{}, [&](const Map<Text, typed::AppNote>& m, const typed::AppNote& n) { return insert(m, typed::at_key(n.at), n); });
    auto bs = fold(tp.binders, Map<Text, check_types::Ty>{}, [&](const Map<Text, check_types::Ty>& m, const typed::BinderNote& n) { return insert(m, typed::at_key(n.at), n.ty); });
    auto ims = fold(tp.impls, Map<Text, Array<typed::ImplNote>>{}, [&](const Map<Text, Array<typed::ImplNote>>& m, const typed::ImplNote& n) { return insert(m, typed::at_key(n.at), prelude::push(or_(prelude::get(m, typed::at_key(n.at)), Array<typed::ImplNote>{}), n)); });
    return std::tuple{tys, apps, bs, ims};
}


/// let rustKeywords
Array<Text> rust_keywords() {
    return Array(std::vector{Text::lit("as"), Text::lit("async"), Text::lit("await"), Text::lit("box"), Text::lit("break"), Text::lit("const"), Text::lit("continue"), Text::lit("crate"), Text::lit("do"), Text::lit("dyn"), Text::lit("else"), Text::lit("enum"), Text::lit("extern"), Text::lit("false"), Text::lit("final"), Text::lit("fn"), Text::lit("for"), Text::lit("gen"), Text::lit("if"), Text::lit("impl"), Text::lit("in"), Text::lit("let"), Text::lit("loop"), Text::lit("macro"), Text::lit("match"), Text::lit("mod"), Text::lit("move"), Text::lit("mut"), Text::lit("override"), Text::lit("priv"), Text::lit("pub"), Text::lit("ref"), Text::lit("return"), Text::lit("self"), Text::lit("static"), Text::lit("struct"), Text::lit("super"), Text::lit("trait"), Text::lit("true"), Text::lit("try"), Text::lit("type"), Text::lit("typeof"), Text::lit("unsafe"), Text::lit("unsized"), Text::lit("use"), Text::lit("virtual"), Text::lit("where"), Text::lit("while"), Text::lit("yield"), Text::lit("u8"), Text::lit("u16"), Text::lit("u32"), Text::lit("u64"), Text::lit("i8"), Text::lit("i16"), Text::lit("i32"), Text::lit("i64"), Text::lit("f32"), Text::lit("f64"), Text::lit("bool"), Text::lit("char"), Text::lit("str"), Text::lit("usize"), Text::lit("isize"), Text::lit("cx"), Text::lit("node"), Text::lit("path"), Text::lit("v"), Text::lit("p")});
}


/// Base: fn Text -> Text
Text base(const Text& name) {
    return lexer::drop_prefix(name, check_types::marks_of(name));
}


/// Snake: fn Text -> Text
Text snake(const Text& name) {
    auto&& _out = lexer::fold_chars(base(name), std::tuple{Text::lit(""), Text::lit("")}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(std::tuple<std::tuple<Text, Text>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Text, Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto [acc, prev] = p0;
                auto c = p1;
                ({
                auto sep = lexer::is_upper(c) && (lexer::is_lower(prev) || lexer::is_digit(prev))
                    ? Text::lit("_")
                    : Text::lit("");
                (prism_rtl::finished(std::tuple{prism_rtl::cat(acc, sep, lower_char(c)), c}));
            });
            });
        });
    })));
    auto&& out = std::get<0>(_out);
    auto plain = out == Text::lit("") ? Text::lit("x") : out;
    return check_types::has_text(rust_keywords(), plain)
        ? prism_rtl::cat(plain, "_")
        : plain;
}


/// LowerChar: fn Text -> Text
Text lower_char(const Text& c) {
    return lexer::is_upper(c) ? prelude::lower(c) : c;
}


/// Camel: fn Text -> Text
Text camel(const Text& name) {
    auto b = base(name);
    auto first_ = lexer::head(b);
    auto fixed = lexer::is_lower(first_)
        ? prism_rtl::cat(upper(first_), lexer::after_first(b))
        : b;
    return (fixed == Text::lit("Self")) || check_types::has_text(runtime_names(), fixed)
        ? prism_rtl::cat(fixed, "_")
        : fixed;
}


/// let runtimeNames
Array<Text> runtime_names() {
    return Array(std::vector{Text::lit("AnswerOf"), Text::lit("BigInt"), Text::lit("Blueprint"), Text::lit("Box"), Text::lit("Built"), Text::lit("Cache"), Text::lit("Case"), Text::lit("Cell"), Text::lit("Clickable"), Text::lit("Collector"), Text::lit("Cursor"), Text::lit("Cx"), Text::lit("Defer"), Text::lit("Demand"), Text::lit("Document"), Text::lit("Done"), Text::lit("DynShow"), Text::lit("Dynamic"), Text::lit("Edit"), Text::lit("Err"), Text::lit("Event"), Text::lit("F64"), Text::lit("Fallible"), Text::lit("Fields"), Text::lit("Finishing"), Text::lit("Fn"), Text::lit("Forward"), Text::lit("FromPod"), Text::lit("Gathered"), Text::lit("Gen"), Text::lit("Handle"), Text::lit("Hold"), Text::lit("Host"), Text::lit("HostOf"), Text::lit("HostRow"), Text::lit("Inert"), Text::lit("IsShared"), Text::lit("IsValue"), Text::lit("Job"), Text::lit("JobRef"), Text::lit("Later"), Text::lit("Link"), Text::lit("List"), Text::lit("Live"), Text::lit("MakeNew"), Text::lit("MutElements"), Text::lit("Nanos"), Text::lit("NeverEvent"), Text::lit("NewSnapshot"), Text::lit("Node"), Text::lit("NodeRef"), Text::lit("None"), Text::lit("Ok"), Text::lit("OkUnit"), Text::lit("Option"), Text::lit("Outcome"), Text::lit("Panic"), Text::lit("Patch"), Text::lit("Path"), Text::lit("Pattern"), Text::lit("Pod"), Text::lit("Port"), Text::lit("Pos"), Text::lit("Printer"), Text::lit("Program"), Text::lit("Rc"), Text::lit("ReadyMap"), Text::lit("ReadyState"), Text::lit("RefCell"), Text::lit("Report"), Text::lit("Request"), Text::lit("Result"), Text::lit("Row"), Text::lit("Rows"), Text::lit("Runtime"), Text::lit("Scope"), Text::lit("Segment"), Text::lit("ShowRef"), Text::lit("ShownText"), Text::lit("Sink"), Text::lit("Slot"), Text::lit("Snapshot"), Text::lit("Some"), Text::lit("Stamped"), Text::lit("String"), Text::lit("Subscribed"), Text::lit("Subscriber"), Text::lit("Supplied"), Text::lit("Supplier"), Text::lit("TestWorld"), Text::lit("Tick"), Text::lit("TickIn"), Text::lit("TickOut"), Text::lit("ToPod"), Text::lit("Unexpected"), Text::lit("Unit"), Text::lit("Vec"), Text::lit("Weak"), Text::lit("World"), Text::lit("XorShift")});
}


/// RustModName: fn Text -> Text
Text rust_mod_name(const Text& m) {
    return m == Text::lit("")
        ? Text::lit("program")
        : snake(lexer::join(split(m, Text::lit(".")), Text::lit("_")));
}


/// PathIn: fn Lx, Text, Text -> Text
Text path_in(const Lx& lx, const Text& owner, const Text& name) {
    return owner == lx.site
        ? name
        : owner == Text::lit("Prelude")
        ? prelude_path(lx, name)
        : prism_rtl::cat(or_(prelude::get(lx.rs_mods, owner), rust_mod_name(owner)), "::", name);
}


/// PreludePath: fn Lx, Text -> Text
Text prelude_path(const Lx& lx, const Text& name) {
    return check_env::has_key(lx.globals, prism_rtl::cat(lx.site, ".", name))
        ? prism_rtl::cat("crate::prelude::", name)
        : name;
}


/// ValueNames: fn G -> (Text ==> Text)
Map<Text, Text> value_names(const check_env::G& g) {
    auto lets = fold(g.defs, Array<Text>{}, [&](const Array<Text>& acc, const check_env::Def& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = d.body;
            if (prism_rtl::is<check_env::DefBody::DbLet>(_m)) {
                _v.set(check_types::add_text(acc, d.qk));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto keys_ = check_types::union_texts(keys(g.vals), lets);
    auto bases = fold(keys_, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m, const Text& k) { return insert(m, base_key(k), prelude::push(or_(prelude::get(m, base_key(k)), Array<Text>{}), k)); });
    return fold(keys_, Map<Text, Text>{}, [&](const Map<Text, Text>& m, const Text& k) { return insert(m, k, value_name(k, len(or_(prelude::get(bases, base_key(k)), Array<Text>{})))); });
}


/// GlobalNames: fn G -> (Text ==> Bool)
Map<Text, bool> global_names(const check_env::G& g) {
    auto names = value_names(g);
    return fold(keys(names), Map<Text, bool>{}, [&](const Map<Text, bool>& m, const Text& k) { return insert(m, prism_rtl::cat(owner_of(k), ".", or_(prelude::get(names, k), Text::lit(""))), true); });
}


/// LocalName: fn Lx, Text -> Text
Text local_name(const Lx& lx, const Text& nkey) {
    auto marks = check_types::marks_of(nkey);
    auto base_ = snake(nkey);
    auto bare = lexer::drop_prefix(nkey, marks);
    auto s0 = lexer::contains(marks, Text::lit("?"))
        ? prism_rtl::cat(base_, "_opt")
        : lexer::contains(marks, Text::lit("~"))
        ? prism_rtl::cat(base_, "_try")
        : base_;
    auto s1 = check_env::is_upper_text(lexer::head(bare))
        ? prism_rtl::cat(s0, "_fn")
        : s0;
    return check_env::has_key(lx.globals, prism_rtl::cat(lx.site, ".", s1)) || check_env::has_key(lx.globals, prism_rtl::cat("Prelude.", s1))
        ? prism_rtl::cat(s1, "_")
        : s1;
}


/// BaseKey: fn Text -> Text
Text base_key(const Text& k) {
    auto parts = split(k, Text::lit("."));
    auto last_1 = or_(lexer::last(parts), k);
    return prism_rtl::cat(lexer::join(take(parts, lexer::dec(len(parts))), Text::lit(".")), ".", snake(last_1));
}


/// ValueName: fn Text, Nat -> Text
Text value_name(const Text& k, const Nat& count) {
    auto last = check_types::bare_name(k);
    auto marks = check_types::marks_of(last);
    auto base_ = snake(last);
    return (count > Nat(1u)) && (marks != Text::lit(""))
        ? prism_rtl::cat(base_, "_", sigil_word(lexer::head(marks)))
        : (count > Nat(1u)) && (!check_env::is_upper_text(lexer::head(last)))
        ? prism_rtl::cat(base_, "_value")
        : base_;
}


/// SigilWord: fn Text -> Text
Text sigil_word(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("?")) {
            return Text::lit("opt");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("~")) {
            return Text::lit("try");
        }
    }
    {
        auto&& c2_0 = text0;
        if (c2_0 == Text::lit("!")) {
            return Text::lit("ev");
        }
    }
    {
        auto&& c3_0 = text0;
        if (c3_0 == Text::lit("$")) {
            return Text::lit("dyn");
        }
    }
    {
        auto&& c4_0 = text0;
        if (c4_0 == Text::lit("@")) {
            return Text::lit("widget");
        }
    }
    {
        auto&& c5_0 = text0;
        if (c5_0 == Text::lit("&")) {
            return Text::lit("ref");
        }
    }
    {
        auto&& other = text0;
        return Text::lit("x");
    }
}


/// ValuePath: fn Lx, Text -> Text
Text value_path(const Lx& lx, const Text& qk) {
    auto owner = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prelude::get(lx.g.vals, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(v_.home);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(owner_of(qk));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return path_in(lx, owner, or_(prelude::get(lx.rs_names, qk), snake(check_types::bare_name(qk))));
}


/// OwnerOf: fn Text -> Text
Text owner_of(const Text& qk) {
    auto parts = split(qk, Text::lit("."));
    return lexer::join(take(parts, lexer::dec(len(parts))), Text::lit("."));
}


/// TagStruct: fn Text -> Text
Text tag_struct(const Text& tn) {
    return concat(each(split(tn, Text::lit(".")), [&](const Text& p_) { return camel(p_); }));
}


/// OutTyOf: unbounded fn Lx, Ty -> OutTy
OutTy out_ty_of(const Lx& lx, const check_types::Ty& t) {
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& m27725_0_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_0_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        if (m27725_0_0 == Text::lit("Nat")) {
            if (m27725_0_1.size() == 0u) {
                return OutTy(OutTy::OutNat{});
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& m27725_1_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_1_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        if (m27725_1_0 == Text::lit("Int")) {
            if (m27725_1_1.size() == 0u) {
                return OutTy(OutTy::OutInt{});
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& m27725_2_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_2_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        if (m27725_2_0 == Text::lit("U8")) {
            if (m27725_2_1.size() == 0u) {
                return OutTy(OutTy::OutU8{});
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& m27725_3_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_3_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        if (m27725_3_0 == Text::lit("Float")) {
            if (m27725_3_1.size() == 0u) {
                return OutTy(OutTy::OutFloat{});
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& m27725_4_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_4_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        if (m27725_4_0 == Text::lit("Bool")) {
            if (m27725_4_1.size() == 0u) {
                return OutTy(OutTy::OutBool{});
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& m27725_5_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_5_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        if (m27725_5_0 == Text::lit("Char")) {
            if (m27725_5_1.size() == 0u) {
                return OutTy(OutTy::OutChar{});
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& m27725_6_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_6_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        if (m27725_6_0 == Text::lit("Text")) {
            if (m27725_6_1.size() == 0u) {
                return OutTy(OutTy::OutText{});
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& m27725_7_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_7_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        if (m27725_7_0 == Text::lit("unit")) {
            if (m27725_7_1.size() == 0u) {
                return OutTy(OutTy::OutUnit{});
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& m27725_8_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_8_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        if (m27725_8_0 == Text::lit("Path")) {
            if (m27725_8_1.size() == 0u) {
                return OutTy(OutTy::OutPath{});
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& m27725_9_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_9_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        if (m27725_9_0 == Text::lit("Cursor")) {
            if (m27725_9_1.size() == 0u) {
                return OutTy(OutTy::OutCursor{});
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& m27725_10_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_10_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        if (m27725_10_0 == Text::lit("Duration")) {
            if (m27725_10_1.size() == 0u) {
                return OutTy(OutTy::OutDuration{});
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& m27725_11_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_11_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        if (m27725_11_0 == Text::lit("Prelude.Error")) {
            if (m27725_11_1.size() == 0u) {
                return OutTy(OutTy::OutError{});
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& m27725_12_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_12_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        if (m27725_12_0 == Text::lit("\000Self"sv)) {
            if (m27725_12_1.size() == 0u) {
                return OutTy(OutTy::OutNamed{Text::lit("Self"), Array<OutTy>{}});
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& m27725_13_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_13_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        if (m27725_13_0 == Text::lit("Buffer")) {
            if (m27725_13_1.size() == 1u) {
                {
                    auto&& _c1 = index(m27725_13_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& a = prism_rtl::some_of(_c1);
                        return OutTy(OutTy::OutArray{prism_rtl::rc(out_ty_of(lx, a))});
                    }
                }
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& m27725_14_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_14_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        if (m27725_14_0 == Text::lit("Table")) {
            if (m27725_14_1.size() == 2u) {
                {
                    auto&& _c2 = index(m27725_14_1, Nat(0u));
                    if (prism_rtl::is_some(_c2)) {
                        auto&& k = prism_rtl::some_of(_c2);
                        {
                            auto&& _c1 = index(m27725_14_1, Nat(1u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& v_ = prism_rtl::some_of(_c1);
                                return OutTy(OutTy::OutArray{prism_rtl::rc(OutTy(OutTy::OutTuple{Array(std::vector{out_ty_of(lx, k), out_ty_of(lx, v_)})}))});
                            }
                        }
                    }
                }
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& m27725_15_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_15_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        if (m27725_15_0 == Text::lit("\000Event"sv)) {
            if (m27725_15_1.size() == 1u) {
                {
                    auto&& _c1 = index(m27725_15_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& a = prism_rtl::some_of(_c1);
                        return OutTy(OutTy::OutEvent{prism_rtl::rc(out_ty_of(lx, a))});
                    }
                }
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        return named_ty(lx, n, run_to_end(each_job(args, ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, a))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<check_types::Ty::TyFn>(t)) {
        auto&& c = prism_rtl::as<check_types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<check_types::Ty::TyFn>(t).a2;
        auto c2 = inst_col(lx, c);
        return c2 == check_types::Col(check_types::Col::CBound{})
            ? OutTy(OutTy::OutFn{run_to_end(each_job(ps, ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto p_ = p0;
                    (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, p_))));
                });
            }));
            });
        })));
        }))), prism_rtl::rc(out_ty_of(lx, res))})
            : is_quant_col(lx, c2)
            ? OutTy(OutTy::OutQuantified{or_(prelude::get(lx.quants, col_name(c2)), Text::lit(""))})
            : OutTy(OutTy::OutJobFn{prism_rtl::rc(rust_ty_of_params(lx, each(ps, [&](const check_types::Ty& p_) { return job_param(p_); }))), prism_rtl::rc(out_ty_of(lx, res))});
    }
    if (prism_rtl::is<check_types::Ty::TyTuple>(t)) {
        auto&& m27725_18_0 = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        if (m27725_18_0.size() == 0u) {
            return OutTy(OutTy::OutUnit{});
        }
    }
    if (prism_rtl::is<check_types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        return OutTy(OutTy::OutTuple{run_to_end(each_job(ts, ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, a))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<check_types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
        return OutTy(OutTy::OutArray{prism_rtl::rc(out_ty_of(lx, e))});
    }
    if (prism_rtl::is<check_types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
        return OutTy(OutTy::OutMap{prism_rtl::rc(out_ty_of(lx, k)), prism_rtl::rc(out_ty_of(lx, v_))});
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& m27725_22_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        if (m27725_22_0 == Text::lit("?")) {
            return OutTy(OutTy::OutOpt{prism_rtl::rc(out_ty_of(lx, i))});
        }
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& m27725_23_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        if (m27725_23_0 == Text::lit("~")) {
            return OutTy(OutTy::OutRes{prism_rtl::rc(out_ty_of(lx, i))});
        }
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& m27725_24_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        if (m27725_24_0 == Text::lit("!")) {
            return OutTy(OutTy::OutEvent{prism_rtl::rc(out_ty_of(lx, i))});
        }
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& m27725_25_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        if (m27725_25_0 == Text::lit("$")) {
            return OutTy(OutTy::OutDyn{prism_rtl::rc(out_ty_of(lx, i))});
        }
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& m27725_26_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        if (m27725_26_0 == Text::lit("&")) {
            return out_ty_of(lx, i);
        }
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        return out_ty_of(lx, i);
    }
    if (prism_rtl::is<check_types::Ty::TyQ>(t)) {
        auto&& n = prism_rtl::as<check_types::Ty::TyQ>(t).a0;
        return OutTy(OutTy::OutGen{camel(n)});
    }
    if (prism_rtl::is<check_types::Ty::TyRigid>(t)) {
        auto&& n = prism_rtl::as<check_types::Ty::TyRigid>(t).a0;
        return OutTy(OutTy::OutGen{camel(n)});
    }
    if (prism_rtl::is<check_types::Ty::TyFlex>(t)) {
        auto&& n = prism_rtl::as<check_types::Ty::TyFlex>(t).a0;
        auto&& _m = prelude::get(lx.subst, prism_rtl::cat("'", n));
        if (prism_rtl::is_some(_m)) {
            auto&& x = prism_rtl::some_of(_m);
            return out_ty_of(lx, x);
        }
        if (prism_rtl::is_none(_m)) {
            auto&& _m = prelude::get(lx.quants, prism_rtl::cat("'", n));
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                return OutTy(OutTy::OutQuantified{b});
            }
            if (prism_rtl::is_none(_m)) {
                return OutTy(OutTy::OutUnit{});
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<check_types::Ty::TyAny>(t)) {
        return OutTy(OutTy::OutShowAny{});
    }
    if (prism_rtl::is<check_types::Ty::TyElem>(t)) {
        return OutTy(OutTy::OutLive{prism_rtl::rc(OutTy(OutTy::OutNamed{Text::lit("crate::Elem"), Array<OutTy>{}}))});
    }
    if (prism_rtl::is<check_types::Ty::TyElemAny>(t)) {
        return OutTy(OutTy::OutNamed{Text::lit("crate::Elem"), Array<OutTy>{}});
    }
    if (prism_rtl::is<check_types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<check_types::Ty::TyAt>(t).a0;
        return blueprint_ty();
    }
    if (prism_rtl::is<check_types::Ty::TyAssoc>(t)) {
        return OutTy(OutTy::OutUnknown{Text::lit("an associated type")});
    }
    if (prism_rtl::is<check_types::Ty::TyErr>(t)) {
        return OutTy(OutTy::OutUnknown{Text::lit("a type the checker did not find")});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<OutTy> OutTyOf::cycle() const {
    const auto& lx = this->lx;
    const auto& t = this->t;
    return ({
        prism_rtl::is<check_types::Ty::TyCon>(t) && ({
        auto&& m27725_0_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_0_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        (m27725_0_0 == Text::lit("Nat")) && (m27725_0_1.size() == 0u);
    }) ? ({
        auto&& m27725_0_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_0_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        prism_rtl::finished(OutTy(OutTy::OutNat{}));
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) && ({
        auto&& m27725_1_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_1_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        (m27725_1_0 == Text::lit("Int")) && (m27725_1_1.size() == 0u);
    }) ? ({
        auto&& m27725_1_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_1_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        prism_rtl::finished(OutTy(OutTy::OutInt{}));
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) && ({
        auto&& m27725_2_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_2_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        (m27725_2_0 == Text::lit("U8")) && (m27725_2_1.size() == 0u);
    }) ? ({
        auto&& m27725_2_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_2_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        prism_rtl::finished(OutTy(OutTy::OutU8{}));
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) && ({
        auto&& m27725_3_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_3_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        (m27725_3_0 == Text::lit("Float")) && (m27725_3_1.size() == 0u);
    }) ? ({
        auto&& m27725_3_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_3_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        prism_rtl::finished(OutTy(OutTy::OutFloat{}));
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) && ({
        auto&& m27725_4_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_4_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        (m27725_4_0 == Text::lit("Bool")) && (m27725_4_1.size() == 0u);
    }) ? ({
        auto&& m27725_4_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_4_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        prism_rtl::finished(OutTy(OutTy::OutBool{}));
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) && ({
        auto&& m27725_5_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_5_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        (m27725_5_0 == Text::lit("Char")) && (m27725_5_1.size() == 0u);
    }) ? ({
        auto&& m27725_5_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_5_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        prism_rtl::finished(OutTy(OutTy::OutChar{}));
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) && ({
        auto&& m27725_6_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_6_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        (m27725_6_0 == Text::lit("Text")) && (m27725_6_1.size() == 0u);
    }) ? ({
        auto&& m27725_6_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_6_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        prism_rtl::finished(OutTy(OutTy::OutText{}));
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) && ({
        auto&& m27725_7_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_7_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        (m27725_7_0 == Text::lit("unit")) && (m27725_7_1.size() == 0u);
    }) ? ({
        auto&& m27725_7_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_7_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        prism_rtl::finished(OutTy(OutTy::OutUnit{}));
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) && ({
        auto&& m27725_8_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_8_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        (m27725_8_0 == Text::lit("Path")) && (m27725_8_1.size() == 0u);
    }) ? ({
        auto&& m27725_8_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_8_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        prism_rtl::finished(OutTy(OutTy::OutPath{}));
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) && ({
        auto&& m27725_9_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_9_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        (m27725_9_0 == Text::lit("Cursor")) && (m27725_9_1.size() == 0u);
    }) ? ({
        auto&& m27725_9_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_9_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        prism_rtl::finished(OutTy(OutTy::OutCursor{}));
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) && ({
        auto&& m27725_10_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_10_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        (m27725_10_0 == Text::lit("Duration")) && (m27725_10_1.size() == 0u);
    }) ? ({
        auto&& m27725_10_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_10_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        prism_rtl::finished(OutTy(OutTy::OutDuration{}));
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) && ({
        auto&& m27725_11_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_11_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        (m27725_11_0 == Text::lit("Prelude.Error")) && (m27725_11_1.size() == 0u);
    }) ? ({
        auto&& m27725_11_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_11_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        prism_rtl::finished(OutTy(OutTy::OutError{}));
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) && ({
        auto&& m27725_12_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_12_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        (m27725_12_0 == Text::lit("\000Self"sv)) && (m27725_12_1.size() == 0u);
    }) ? ({
        auto&& m27725_12_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_12_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        prism_rtl::finished(OutTy(OutTy::OutNamed{Text::lit("Self"), Array<OutTy>{}}));
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) && ({
        auto&& m27725_13_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_13_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        (m27725_13_0 == Text::lit("Buffer")) && (m27725_13_1.size() == 1u) && ({
        auto&& _c1 = index(m27725_13_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m27725_13_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_13_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        auto&& _c1 = index(m27725_13_1, Nat(0u));
        auto&& a = prism_rtl::some_of(_c1);
        ({
        auto lx_1 = lx;
        call_then(start_out_ty_of(lx_1, a), [=](OutTy out_ty_of_28222) { return prism_rtl::finished(OutTy(OutTy::OutArray{prism_rtl::rc(out_ty_of_28222)})); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) && ({
        auto&& m27725_14_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_14_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        (m27725_14_0 == Text::lit("Table")) && (m27725_14_1.size() == 2u) && ({
        auto&& _c2 = index(m27725_14_1, Nat(0u));
        prism_rtl::is_some(_c2) && ({
        auto&& k = prism_rtl::some_of(_c2);
        ({
        auto&& _c1 = index(m27725_14_1, Nat(1u));
        prism_rtl::is_some(_c1);
    });
    });
    });
    }) ? ({
        auto&& m27725_14_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_14_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        auto&& _c2 = index(m27725_14_1, Nat(0u));
        auto&& k = prism_rtl::some_of(_c2);
        auto&& _c1 = index(m27725_14_1, Nat(1u));
        auto&& v_ = prism_rtl::some_of(_c1);
        ({
        auto lx_1 = lx;
        call_then(start_out_ty_of(lx_1, k), [=](OutTy out_ty_of_28288) { return call_then(start_out_ty_of(lx_1, v_), [=](OutTy out_ty_of_28305) { return prism_rtl::finished(OutTy(OutTy::OutArray{prism_rtl::rc(OutTy(OutTy::OutTuple{Array(std::vector{out_ty_of_28288, out_ty_of_28305})}))})); }); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) && ({
        auto&& m27725_15_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_15_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        (m27725_15_0 == Text::lit("\000Event"sv)) && (m27725_15_1.size() == 1u) && ({
        auto&& _c1 = index(m27725_15_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m27725_15_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m27725_15_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        auto&& _c1 = index(m27725_15_1, Nat(0u));
        auto&& a = prism_rtl::some_of(_c1);
        ({
        auto lx_1 = lx;
        call_then(start_out_ty_of(lx_1, a), [=](OutTy out_ty_of_28364) { return prism_rtl::finished(OutTy(OutTy::OutEvent{prism_rtl::rc(out_ty_of_28364)})); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto lx_2 = lx;
        auto n_3 = n;
        call_value(each_job(args_1, ({
        auto lx_2_4 = lx_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto lx_2_4_4 = lx_2_4;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_2_4_4, a))));
            });
        }));
        });
    })));
    })), [=](Array<OutTy> each_28414) { return prism_rtl::more(prism_rtl::rc(NamedTy(lx_2, n_3, each_28414))); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyFn>(t) ? ({
        auto&& c = prism_rtl::as<check_types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<check_types::Ty::TyFn>(t).a2;
        ({
        auto c2 = inst_col(lx, c);
        c2 == check_types::Col(check_types::Col::CBound{})
        ? ({
        auto lx_1 = lx;
        auto ps_2 = ps;
        auto res_3 = res;
        call_value(each_job(ps_2, ({
        auto lx_1_4 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto lx_1_4_4 = lx_1_4;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_4_4, p_))));
            });
        }));
        });
    })));
    })), [=](Array<OutTy> each_28695) { return call_then(start_out_ty_of(lx_1, res_3), [=](OutTy out_ty_of_28726) { return prism_rtl::finished(OutTy(OutTy::OutFn{each_28695, prism_rtl::rc(out_ty_of_28726)})); }); });
    })
        : is_quant_col(lx, c2)
        ? prism_rtl::finished(OutTy(OutTy::OutQuantified{or_(prelude::get(lx.quants, col_name(c2)), Text::lit(""))}))
        : ({
        auto lx_1 = lx;
        auto ps_2 = ps;
        auto res_3 = res;
        call_then(start_rust_ty_of_params(lx_1, each(ps_2, [&](const check_types::Ty& p_) { return job_param(p_); })), [=](OutTy rust_ty_of_params_28848) { return call_then(start_out_ty_of(lx_1, res_3), [=](OutTy out_ty_of_28897) { return prism_rtl::finished(OutTy(OutTy::OutJobFn{prism_rtl::rc(rust_ty_of_params_28848), prism_rtl::rc(out_ty_of_28897)})); }); });
    });
    });
    })
        : prism_rtl::is<check_types::Ty::TyTuple>(t) && ({
        auto&& m27725_18_0 = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        (m27725_18_0.size() == 0u);
    }) ? ({
        auto&& m27725_18_0 = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        prism_rtl::finished(OutTy(OutTy::OutUnit{}));
    })
        : prism_rtl::is<check_types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        ({
        auto lx_1 = lx;
        auto ts_2 = ts;
        call_value(each_job(ts_2, ({
        auto lx_1_3 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto lx_1_3_3 = lx_1_3;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_3_3, a))));
            });
        }));
        });
    })));
    })), [=](Array<OutTy> each_28966) { return prism_rtl::finished(OutTy(OutTy::OutTuple{each_28966})); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
        ({
        auto e_1 = e;
        auto lx_2 = lx;
        call_then(start_out_ty_of(lx_2, e_1), [=](OutTy out_ty_of_29020) { return prism_rtl::finished(OutTy(OutTy::OutArray{prism_rtl::rc(out_ty_of_29020)})); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto lx_2 = lx;
        auto v__3 = v_;
        call_then(start_out_ty_of(lx_2, k_1), [=](OutTy out_ty_of_29059) { return call_then(start_out_ty_of(lx_2, v__3), [=](OutTy out_ty_of_29076) { return prism_rtl::finished(OutTy(OutTy::OutMap{prism_rtl::rc(out_ty_of_29059), prism_rtl::rc(out_ty_of_29076)})); }); });
    });
    })
        : prism_rtl::is<check_types::Ty::TySig>(t) && ({
        auto&& m27725_22_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        (m27725_22_0 == Text::lit("?"));
    }) ? ({
        auto&& m27725_22_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        ({
        auto i_1 = i;
        auto lx_2 = lx;
        call_then(start_out_ty_of(lx_2, i_1), [=](OutTy out_ty_of_29117) { return prism_rtl::finished(OutTy(OutTy::OutOpt{prism_rtl::rc(out_ty_of_29117)})); });
    });
    })
        : prism_rtl::is<check_types::Ty::TySig>(t) && ({
        auto&& m27725_23_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        (m27725_23_0 == Text::lit("~"));
    }) ? ({
        auto&& m27725_23_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        ({
        auto i_1 = i;
        auto lx_2 = lx;
        call_then(start_out_ty_of(lx_2, i_1), [=](OutTy out_ty_of_29158) { return prism_rtl::finished(OutTy(OutTy::OutRes{prism_rtl::rc(out_ty_of_29158)})); });
    });
    })
        : prism_rtl::is<check_types::Ty::TySig>(t) && ({
        auto&& m27725_24_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        (m27725_24_0 == Text::lit("!"));
    }) ? ({
        auto&& m27725_24_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        ({
        auto i_1 = i;
        auto lx_2 = lx;
        call_then(start_out_ty_of(lx_2, i_1), [=](OutTy out_ty_of_29201) { return prism_rtl::finished(OutTy(OutTy::OutEvent{prism_rtl::rc(out_ty_of_29201)})); });
    });
    })
        : prism_rtl::is<check_types::Ty::TySig>(t) && ({
        auto&& m27725_25_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        (m27725_25_0 == Text::lit("$"));
    }) ? ({
        auto&& m27725_25_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        ({
        auto i_1 = i;
        auto lx_2 = lx;
        call_then(start_out_ty_of(lx_2, i_1), [=](OutTy out_ty_of_29242) { return prism_rtl::finished(OutTy(OutTy::OutDyn{prism_rtl::rc(out_ty_of_29242)})); });
    });
    })
        : prism_rtl::is<check_types::Ty::TySig>(t) && ({
        auto&& m27725_26_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        (m27725_26_0 == Text::lit("&"));
    }) ? ({
        auto&& m27725_26_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx, i)));
    })
        : prism_rtl::is<check_types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx, i)));
    })
        : prism_rtl::is<check_types::Ty::TyQ>(t) ? ({
        auto&& n = prism_rtl::as<check_types::Ty::TyQ>(t).a0;
        prism_rtl::finished(OutTy(OutTy::OutGen{camel(n)}));
    })
        : prism_rtl::is<check_types::Ty::TyRigid>(t) ? ({
        auto&& n = prism_rtl::as<check_types::Ty::TyRigid>(t).a0;
        prism_rtl::finished(OutTy(OutTy::OutGen{camel(n)}));
    })
        : prism_rtl::is<check_types::Ty::TyFlex>(t) ? ({
        auto&& n = prism_rtl::as<check_types::Ty::TyFlex>(t).a0;
        ({
        auto&& _m = prelude::get(lx.subst, prism_rtl::cat("'", n));
        prism_rtl::is_some(_m) ? ({
        auto&& x = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx, x)));
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = prelude::get(lx.quants, prism_rtl::cat("'", n));
        prism_rtl::is_some(_m) ? ({
        auto&& b = prism_rtl::some_of(_m);
        prism_rtl::finished(OutTy(OutTy::OutQuantified{b}));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(OutTy(OutTy::OutUnit{}))
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<check_types::Ty::TyAny>(t) ? prism_rtl::finished(OutTy(OutTy::OutShowAny{}))
        : prism_rtl::is<check_types::Ty::TyElem>(t) ? prism_rtl::finished(OutTy(OutTy::OutLive{prism_rtl::rc(OutTy(OutTy::OutNamed{Text::lit("crate::Elem"), Array<OutTy>{}}))}))
        : prism_rtl::is<check_types::Ty::TyElemAny>(t) ? prism_rtl::finished(OutTy(OutTy::OutNamed{Text::lit("crate::Elem"), Array<OutTy>{}}))
        : prism_rtl::is<check_types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<check_types::Ty::TyAt>(t).a0;
        prism_rtl::finished(blueprint_ty());
    })
        : prism_rtl::is<check_types::Ty::TyAssoc>(t) ? prism_rtl::finished(OutTy(OutTy::OutUnknown{Text::lit("an associated type")}))
        : prism_rtl::is<check_types::Ty::TyErr>(t) ? prism_rtl::finished(OutTy(OutTy::OutUnknown{Text::lit("a type the checker did not find")}))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start OutTyOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<OutTy> start_out_ty_of(Lx lx, check_types::Ty t) {
    return prism_rtl::make_rc<OutTyOf>(lx, t);
}


/// let blueprintTy
OutTy blueprint_ty() {
    return OutTy(OutTy::OutNamed{Text::lit("prism_rtl::Blueprint"), Array(std::vector{OutTy(OutTy::OutNamed{Text::lit("crate::Elem"), Array<OutTy>{}}), OutTy(OutTy::OutNamed{Text::lit("crate::Answer"), Array<OutTy>{}})})});
}


/// let elemTy
OutTy elem_ty() {
    return OutTy(OutTy::OutNamed{Text::lit("crate::Elem"), Array<OutTy>{}});
}


/// let answerTy
OutTy answer_ty_value() {
    return OutTy(OutTy::OutNamed{Text::lit("crate::Answer"), Array<OutTy>{}});
}


/// let hostOfTy
OutTy host_of_ty() {
    return OutTy(OutTy::OutObj{prism_rtl::rc(OutTy(OutTy::OutNamed{Text::lit("prism_rtl::HostOf"), Array(std::vector{OutTy(OutTy::OutNamed{Text::lit("crate::Elem"), Array<OutTy>{}}), OutTy(OutTy::OutNamed{Text::lit("crate::Answer"), Array<OutTy>{}})})}))});
}


/// HasBlueprint: fn Ty -> Bool
bool has_blueprint(const check_types::Ty& t) {
    if (prism_rtl::is<check_types::Ty::TyAt>(t)) {
        return true;
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        return has_blueprint(i);
    }
    {
        return false;
    }
}


/// EventParam: fn Ty -> Ty
check_types::Ty event_param(const check_types::Ty& t) {
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& m30748_0_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        if (m30748_0_0 == Text::lit("!")) {
            return check_types::Ty(check_types::Ty::TyCon{Text::lit("\000Event"sv), Array(std::vector{peel(i)})});
        }
    }
    {
        return t;
    }
}


/// JobParam: fn Ty -> Ty
check_types::Ty job_param(const check_types::Ty& ty0) {
    if (prism_rtl::is<check_types::Ty::TyFn>(ty0)) {
        auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(ty0).a1;
        auto&& r = prism_rtl::as<check_types::Ty::TyFn>(ty0).a2;
        return check_types::Ty(check_types::Ty::TyFn{check_types::Col(check_types::Col::CUnbound{}), ps, prism_rtl::rc(r)});
    }
    {
        auto&& t = ty0;
        return t;
    }
}


/// RustTyOfParams: unbounded fn Lx, [Ty] -> OutTy
OutTy rust_ty_of_params(const Lx& lx, const Array<check_types::Ty>& ps) {
    {
        auto&& m31311_0 = ps;
        if (m31311_0.size() == 1u) {
            {
                auto&& _c1 = index(m31311_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& p_ = prism_rtl::some_of(_c1);
                    return out_ty_of(lx, p_);
                }
            }
        }
    }
    {
        return OutTy(OutTy::OutTuple{run_to_end(each_job(ps, ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto p_ = p0;
                    (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, p_))));
                });
            }));
            });
        })));
        })))});
    }
}


prism_rtl::Turn<OutTy> RustTyOfParams::cycle() const {
    const auto& lx = this->lx;
    const auto& ps = this->ps;
    return ({
        ({
        auto&& m31311_0 = ps;
        (m31311_0.size() == 1u) && ({
        auto&& _c1 = index(m31311_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m31311_0 = ps;
        auto&& _c1 = index(m31311_0, Nat(0u));
        auto&& p_ = prism_rtl::some_of(_c1);
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx, p_)));
    })
        : ({
        auto lx_1 = lx;
        auto ps_2 = ps;
        call_value(each_job(ps_2, ({
        auto lx_1_3 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto lx_1_3_3 = lx_1_3;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_3_3, p_))));
            });
        }));
        });
    })));
    })), [=](Array<OutTy> each_31371) { return prism_rtl::finished(OutTy(OutTy::OutTuple{each_31371})); });
    });
    });
}


/// `Start RustTyOfParams, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<OutTy> start_rust_ty_of_params(Lx lx, Array<check_types::Ty> ps) {
    return prism_rtl::make_rc<RustTyOfParams>(lx, ps);
}


/// NamedTy: unbounded fn Lx, Text, [OutTy] -> OutTy
OutTy named_ty(const Lx& lx, const Text& n, const Array<OutTy>& args) {
    auto&& _m = prelude::get(lx.g.types, n);
    if (prism_rtl::is_some(_m)) {
        auto&& ti = prism_rtl::some_of(_m);
        auto&& _m = ti.body;
        if (prism_rtl::is<check_env::TyBody::BAlias>(_m)) {
            auto&& a = prism_rtl::as<check_env::TyBody::BAlias>(_m).a0;
            return out_ty_of(lx, a);
        }
        if (prism_rtl::is<check_env::TyBody::BRowKind>(_m)) {
            return n == Text::lit("Prelude.Fault")
                ? OutTy(OutTy::OutPod{})
                : OutTy(OutTy::OutNamed{path_in(lx, ti.home, camel(check_types::bare_name(n))), Array<OutTy>{}});
        }
        {
            return OutTy(OutTy::OutNamed{path_in(lx, ti.home, camel(check_types::bare_name(n))), args});
        }
    }
    if (prism_rtl::is_none(_m)) {
        return check_env::has_key(lx.g.families, n)
            ? OutTy(OutTy::OutPod{})
            : OutTy(OutTy::OutNamed{camel(check_types::bare_name(n)), args});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<OutTy> NamedTy::cycle() const {
    const auto& lx = this->lx;
    const auto& n = this->n;
    const auto& args = this->args;
    return ({
        auto&& _m = prelude::get(lx.g.types, n);
        prism_rtl::is_some(_m) ? ({
        auto&& ti = prism_rtl::some_of(_m);
        ({
        auto&& _m = ti.body;
        prism_rtl::is<check_env::TyBody::BAlias>(_m) ? ({
        auto&& a = prism_rtl::as<check_env::TyBody::BAlias>(_m).a0;
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx, a)));
    })
        : prism_rtl::is<check_env::TyBody::BRowKind>(_m) ? n == Text::lit("Prelude.Fault")
        ? prism_rtl::finished(OutTy(OutTy::OutPod{}))
        : prism_rtl::finished(OutTy(OutTy::OutNamed{path_in(lx, ti.home, camel(check_types::bare_name(n))), Array<OutTy>{}}))
        : prism_rtl::finished(OutTy(OutTy::OutNamed{path_in(lx, ti.home, camel(check_types::bare_name(n))), args}));
    });
    })
        : prism_rtl::is_none(_m) ? check_env::has_key(lx.g.families, n)
        ? prism_rtl::finished(OutTy(OutTy::OutPod{}))
        : prism_rtl::finished(OutTy(OutTy::OutNamed{camel(check_types::bare_name(n)), args}))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start NamedTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<OutTy> start_named_ty(Lx lx, Text n, Array<OutTy> args) {
    return prism_rtl::make_rc<NamedTy>(lx, n, args);
}


/// Peel: fn Ty -> Ty
check_types::Ty peel(const check_types::Ty& t) {
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& m32109_0_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        if (m32109_0_0 == Text::lit("$")) {
            return peel(i);
        }
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& m32109_1_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        if (m32109_1_0 == Text::lit("!")) {
            return peel(i);
        }
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& m32109_2_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        if (m32109_2_0 == Text::lit("&")) {
            return peel(i);
        }
    }
    {
        return t;
    }
}


/// OutOf: fn Ty -> Ty
check_types::Ty out_of(const check_types::Ty& t) {
    if (prism_rtl::is<check_types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<check_types::Ty::TyAt>(t).a0;
        return peel(i);
    }
    {
        return peel(t);
    }
}


/// LayerOf: fn Ty -> Layer
Layer layer_of(const check_types::Ty& t) {
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& m32625_0_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        if (m32625_0_0 == Text::lit("$")) {
            return Layer(Layer::LyDyn{});
        }
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& m32625_1_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        if (m32625_1_0 == Text::lit("!")) {
            return Layer(Layer::LyEv{});
        }
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& m32625_2_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        if (m32625_2_0 == Text::lit("&")) {
            return layer_of(i);
        }
    }
    if (prism_rtl::is<check_types::Ty::TyAt>(t)) {
        return Layer(Layer::LyBlueprint{});
    }
    {
        return Layer(Layer::LyPlain{});
    }
}


/// Layouts: unbounded fn G -> (Text ==> [Bool])
Map<Text, Array<bool>> layouts(const check_env::G& g) {
    return run_to_end(fold_job(values(g.ctors), Map<Text, Array<bool>>{}, ({
        auto g_1 = g;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<bool>>>(std::tuple<Map<Text, Array<bool>>, check_env::CtorInfo>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<bool>>, check_env::CtorInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto c = p1;
                call_value(each_job(c->args, ({
                auto g_1_2_2 = g_1_2;
                auto c_2 = c;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
                return ({
                    auto g_1_2_2_3 = g_1_2_2;
                    auto c_2_3 = c_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(Reaches(g_1_2_2_3, a, c_2_3.owner, Array<Text>{}))));
                    });
                }));
                });
            })));
            })), [=](Array<bool> each_33133) { return prism_rtl::finished(insert(m, c.name, each_33133)); });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, Array<bool>>> Layouts::cycle() const {
    const auto& g = this->g;
    return fold_job(values(g.ctors), Map<Text, Array<bool>>{}, ({
        auto g_1 = g;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<bool>>>(std::tuple<Map<Text, Array<bool>>, check_env::CtorInfo>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<bool>>, check_env::CtorInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto c = p1;
                call_value(each_job(c->args, ({
                auto g_1_2_2 = g_1_2;
                auto c_2 = c;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
                return ({
                    auto g_1_2_2_3 = g_1_2_2;
                    auto c_2_3 = c_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(Reaches(g_1_2_2_3, a, c_2_3.owner, Array<Text>{}))));
                    });
                }));
                });
            })));
            })), [=](Array<bool> each_33133) { return prism_rtl::finished(insert(m, c.name, each_33133)); });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start Layouts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Array<bool>>> start_layouts(check_env::G g) {
    return prism_rtl::make_rc<Layouts>(g);
}


/// Reaches: unbounded fn G, Ty, Text, [Text] -> Bool
bool reaches(const check_env::G& g, const check_types::Ty& t, const Text& target, const Array<Text>& seen) {
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        return n == target
            ? true
            : check_types::has_text(seen, n)
            ? false
            : run_to_end(fold_job(args, false, ({
            auto g_1 = g;
            auto target_2 = target;
            auto seen_3 = seen;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_1_4 = g_1;
                auto target_2_4 = target_2;
                auto seen_3_4 = seen_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto a = p1;
                    (prism_rtl::finished(f || reaches(g_1_4, a, target_2_4, seen_3_4)));
                });
            }));
            });
        })));
        })))
            ? true
            : ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = prelude::get(g.types, n);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = ti.body;
                    if (prism_rtl::is<check_env::TyBody::BRecord>(_m)) {
                        auto&& fs = prism_rtl::as<check_env::TyBody::BRecord>(_m).a0;
                        _v.set(run_to_end(fold_job(fs, false, ({
                            auto g_1 = g;
                            auto target_2 = target;
                            auto seen_3 = seen;
                            auto n_4 = n;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, check_types::Ty>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, check_types::Ty>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto g_1_5 = g_1;
                                auto target_2_5 = target_2;
                                auto seen_3_5 = seen_3;
                                auto n_4_5 = n_4;
                                entered(once_job([=]() {
                                return ({
                                    auto f = p0;
                                    auto&& _ft = p1;
                                    auto&& ft = std::get<1>(_ft);
                                    (prism_rtl::finished(f || reaches(g_1_5, ft, target_2_5, prelude::push(seen_3_5, n_4_5))));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<check_env::TyBody::BChoice>(_m)) {
                        auto&& cs = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
                        _v.set(run_to_end(fold_job(cs, false, ({
                            auto g_1 = g;
                            auto target_2 = target;
                            auto seen_3 = seen;
                            auto n_4 = n;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<check_types::Ty>>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Array<check_types::Ty>>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto g_1_5 = g_1;
                                auto target_2_5 = target_2;
                                auto seen_3_5 = seen_3;
                                auto n_4_5 = n_4;
                                entered(once_job([=]() {
                                return ({
                                    auto f = p0;
                                    auto&& _ats = p1;
                                    auto&& ats = std::get<1>(_ats);
                                    (prism_rtl::finished(f || run_to_end(fold_job(ats, false, ({
                                    auto g_1_5_5 = g_1_5;
                                    auto target_2_5_5 = target_2_5;
                                    auto seen_3_5_5 = seen_3_5;
                                    auto n_4_5_5 = n_4_5;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto g_1_5_5_5 = g_1_5_5;
                                        auto target_2_5_5_5 = target_2_5_5;
                                        auto seen_3_5_5_5 = seen_3_5_5;
                                        auto n_4_5_5_5 = n_4_5_5;
                                        entered(once_job([=]() {
                                        return ({
                                            auto f2 = p0;
                                            auto at_ = p1;
                                            (prism_rtl::finished(f2 || reaches(g_1_5_5_5, at_, target_2_5_5_5, prelude::push(seen_3_5_5_5, n_4_5_5_5))));
                                        });
                                    }));
                                    });
                                })));
                                })))));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<check_env::TyBody::BAlias>(_m)) {
                        auto&& a = prism_rtl::as<check_env::TyBody::BAlias>(_m).a0;
                        _v.set(reaches(g, a, target, prelude::push(seen, n)));
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& m33263_1_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        if (m33263_1_0 == Text::lit("?")) {
            return reaches(g, i, target, seen);
        }
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& m33263_2_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        if (m33263_2_0 == Text::lit("~")) {
            return reaches(g, i, target, seen);
        }
    }
    if (prism_rtl::is<check_types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, false, ({
            auto g_1 = g;
            auto target_2 = target;
            auto seen_3 = seen;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_1_4 = g_1;
                auto target_2_4 = target_2;
                auto seen_3_4 = seen_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto a = p1;
                    (prism_rtl::finished(f || reaches(g_1_4, a, target_2_4, seen_3_4)));
                });
            }));
            });
        })));
        })));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> Reaches::cycle() const {
    const auto& g = this->g;
    const auto& t = this->t;
    const auto& target = this->target;
    const auto& seen = this->seen;
    return ({
        prism_rtl::is<check_types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        n == target
        ? prism_rtl::finished(true)
        : check_types::has_text(seen, n)
        ? prism_rtl::finished(false)
        : ({
        auto args_1 = args;
        auto g_2 = g;
        auto n_3 = n;
        auto seen_4 = seen;
        auto target_5 = target;
        call_value(fold_job(args_1, false, ({
        auto g_2_6 = g_2;
        auto target_5_6 = target_5;
        auto seen_4_6 = seen_4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_2_6_6 = g_2_6;
            auto target_5_6_6 = target_5_6;
            auto seen_4_6_6 = seen_4_6;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                auto a = p1;
                (prism_rtl::finished(f || reaches(g_2_6_6, a, target_5_6_6, seen_4_6_6)));
            });
        }));
        });
    })));
    })), [=](bool fold_33377) {
        return fold_33377
            ? prism_rtl::finished(true)
            : ({
            auto&& _m = prelude::get(g_2.types, n_3);
            prism_rtl::is_some(_m) ? ({
            auto&& ti = prism_rtl::some_of(_m);
            ({
            auto&& _m = ti.body;
            prism_rtl::is<check_env::TyBody::BRecord>(_m) ? ({
            auto&& fs = prism_rtl::as<check_env::TyBody::BRecord>(_m).a0;
            fold_job(fs, false, ({
            auto g_2_6 = g_2;
            auto target_5_6 = target_5;
            auto seen_4_6 = seen_4;
            auto n_3_6 = n_3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, check_types::Ty>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, check_types::Ty>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_2_6_6 = g_2_6;
                auto target_5_6_6 = target_5_6;
                auto seen_4_6_6 = seen_4_6;
                auto n_3_6_6 = n_3_6;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto&& _ft = p1;
                    auto&& ft = std::get<1>(_ft);
                    (prism_rtl::finished(f || reaches(g_2_6_6, ft, target_5_6_6, prelude::push(seen_4_6_6, n_3_6_6))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<check_env::TyBody::BChoice>(_m) ? ({
            auto&& cs = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
            fold_job(cs, false, ({
            auto g_2_6 = g_2;
            auto target_5_6 = target_5;
            auto seen_4_6 = seen_4;
            auto n_3_6 = n_3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<check_types::Ty>>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Array<check_types::Ty>>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_2_6_6 = g_2_6;
                auto target_5_6_6 = target_5_6;
                auto seen_4_6_6 = seen_4_6;
                auto n_3_6_6 = n_3_6;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto&& _ats = p1;
                    auto&& ats = std::get<1>(_ats);
                    (prism_rtl::finished(f || run_to_end(fold_job(ats, false, ({
                    auto g_2_6_6_6 = g_2_6_6;
                    auto target_5_6_6_6 = target_5_6_6;
                    auto seen_4_6_6_6 = seen_4_6_6;
                    auto n_3_6_6_6 = n_3_6_6;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto g_2_6_6_6_6 = g_2_6_6_6;
                        auto target_5_6_6_6_6 = target_5_6_6_6;
                        auto seen_4_6_6_6_6 = seen_4_6_6_6;
                        auto n_3_6_6_6_6 = n_3_6_6_6;
                        entered(once_job([=]() {
                        return ({
                            auto f2 = p0;
                            auto at_ = p1;
                            (prism_rtl::finished(f2 || reaches(g_2_6_6_6_6, at_, target_5_6_6_6_6, prelude::push(seen_4_6_6_6_6, n_3_6_6_6_6))));
                        });
                    }));
                    });
                })));
                })))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<check_env::TyBody::BAlias>(_m) ? ({
            auto&& a = prism_rtl::as<check_env::TyBody::BAlias>(_m).a0;
            prism_rtl::more(prism_rtl::rc(Reaches(g_2, a, target_5, prelude::push(seen_4, n_3))));
        })
            : prism_rtl::finished(false);
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is<check_types::Ty::TySig>(t) && ({
        auto&& m33263_1_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        (m33263_1_0 == Text::lit("?"));
    }) ? ({
        auto&& m33263_1_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(Reaches(g, i, target, seen)));
    })
        : prism_rtl::is<check_types::Ty::TySig>(t) && ({
        auto&& m33263_2_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        (m33263_2_0 == Text::lit("~"));
    }) ? ({
        auto&& m33263_2_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(Reaches(g, i, target, seen)));
    })
        : prism_rtl::is<check_types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        fold_job(ts, false, ({
        auto g_1 = g;
        auto target_2 = target;
        auto seen_3 = seen;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_4 = g_1;
            auto target_2_4 = target_2;
            auto seen_3_4 = seen_3;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                auto a = p1;
                (prism_rtl::finished(f || reaches(g_1_4, a, target_2_4, seen_3_4)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::finished(false);
    });
}


/// `Start Reaches, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_reaches(check_env::G g, check_types::Ty t, Text target, Array<Text> seen) {
    return prism_rtl::make_rc<Reaches>(g, t, target, seen);
}


/// RcField: fn Lx, Text, Nat -> Bool
bool rc_field(const Lx& lx, const Text& ctor, const Nat& i) {
    return or_(index(or_(prelude::get(lx.layouts, ctor), Array<bool>{}), i), false);
}


/// Floaty: unbounded fn G, Ty, [Text] -> Bool
bool floaty(const check_env::G& g, const check_types::Ty& t, const Array<Text>& seen) {
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& m34367_0_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m34367_0_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        if (m34367_0_0 == Text::lit("Float")) {
            if (m34367_0_1.size() == 0u) {
                return true;
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        return run_to_end(fold_job(args, false, ({
            auto g_1 = g;
            auto seen_2 = seen;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_1_3 = g_1;
                auto seen_2_3 = seen_2;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto a = p1;
                    (prism_rtl::finished(f || floaty(g_1_3, a, seen_2_3)));
                });
            }));
            });
        })));
        })))
            ? true
            : check_types::has_text(seen, n)
            ? false
            : ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = prelude::get(g.types, n);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = ti.body;
                    if (prism_rtl::is<check_env::TyBody::BRecord>(_m)) {
                        auto&& fs = prism_rtl::as<check_env::TyBody::BRecord>(_m).a0;
                        _v.set(run_to_end(fold_job(fs, false, ({
                            auto g_1 = g;
                            auto seen_2 = seen;
                            auto n_3 = n;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, check_types::Ty>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, check_types::Ty>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto g_1_4 = g_1;
                                auto seen_2_4 = seen_2;
                                auto n_3_4 = n_3;
                                entered(once_job([=]() {
                                return ({
                                    auto f = p0;
                                    auto&& _ft = p1;
                                    auto&& ft = std::get<1>(_ft);
                                    (prism_rtl::finished(f || floaty(g_1_4, ft, prelude::push(seen_2_4, n_3_4))));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<check_env::TyBody::BChoice>(_m)) {
                        auto&& cs = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
                        _v.set(run_to_end(fold_job(cs, false, ({
                            auto g_1 = g;
                            auto seen_2 = seen;
                            auto n_3 = n;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<check_types::Ty>>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Array<check_types::Ty>>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto g_1_4 = g_1;
                                auto seen_2_4 = seen_2;
                                auto n_3_4 = n_3;
                                entered(once_job([=]() {
                                return ({
                                    auto f = p0;
                                    auto&& _ats = p1;
                                    auto&& ats = std::get<1>(_ats);
                                    (prism_rtl::finished(f || run_to_end(fold_job(ats, false, ({
                                    auto g_1_4_4 = g_1_4;
                                    auto seen_2_4_4 = seen_2_4;
                                    auto n_3_4_4 = n_3_4;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto g_1_4_4_4 = g_1_4_4;
                                        auto seen_2_4_4_4 = seen_2_4_4;
                                        auto n_3_4_4_4 = n_3_4_4;
                                        entered(once_job([=]() {
                                        return ({
                                            auto f2 = p0;
                                            auto at_ = p1;
                                            (prism_rtl::finished(f2 || floaty(g_1_4_4_4, at_, prelude::push(seen_2_4_4_4, n_3_4_4_4))));
                                        });
                                    }));
                                    });
                                })));
                                })))));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        return floaty(g, i, seen);
    }
    if (prism_rtl::is<check_types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, false, ({
            auto g_1 = g;
            auto seen_2 = seen;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_1_3 = g_1;
                auto seen_2_3 = seen_2;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto a = p1;
                    (prism_rtl::finished(f || floaty(g_1_3, a, seen_2_3)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<check_types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
        return floaty(g, e, seen);
    }
    if (prism_rtl::is<check_types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
        return floaty(g, k, seen) || floaty(g, v_, seen);
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> Floaty::cycle() const {
    const auto& g = this->g;
    const auto& t = this->t;
    const auto& seen = this->seen;
    return ({
        prism_rtl::is<check_types::Ty::TyCon>(t) && ({
        auto&& m34367_0_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m34367_0_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        (m34367_0_0 == Text::lit("Float")) && (m34367_0_1.size() == 0u);
    }) ? ({
        auto&& m34367_0_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m34367_0_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        prism_rtl::finished(true);
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto g_2 = g;
        auto n_3 = n;
        auto seen_4 = seen;
        call_value(fold_job(args_1, false, ({
        auto g_2_5 = g_2;
        auto seen_4_5 = seen_4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_2_5_5 = g_2_5;
            auto seen_4_5_5 = seen_4_5;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                auto a = p1;
                (prism_rtl::finished(f || floaty(g_2_5_5, a, seen_4_5_5)));
            });
        }));
        });
    })));
    })), [=](bool fold_34436) {
        return fold_34436
            ? prism_rtl::finished(true)
            : check_types::has_text(seen_4, n_3)
            ? prism_rtl::finished(false)
            : ({
            auto&& _m = prelude::get(g_2.types, n_3);
            prism_rtl::is_some(_m) ? ({
            auto&& ti = prism_rtl::some_of(_m);
            ({
            auto&& _m = ti.body;
            prism_rtl::is<check_env::TyBody::BRecord>(_m) ? ({
            auto&& fs = prism_rtl::as<check_env::TyBody::BRecord>(_m).a0;
            fold_job(fs, false, ({
            auto g_2_5 = g_2;
            auto seen_4_5 = seen_4;
            auto n_3_5 = n_3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, check_types::Ty>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, check_types::Ty>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_2_5_5 = g_2_5;
                auto seen_4_5_5 = seen_4_5;
                auto n_3_5_5 = n_3_5;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto&& _ft = p1;
                    auto&& ft = std::get<1>(_ft);
                    (prism_rtl::finished(f || floaty(g_2_5_5, ft, prelude::push(seen_4_5_5, n_3_5_5))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<check_env::TyBody::BChoice>(_m) ? ({
            auto&& cs = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
            fold_job(cs, false, ({
            auto g_2_5 = g_2;
            auto seen_4_5 = seen_4;
            auto n_3_5 = n_3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<check_types::Ty>>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Array<check_types::Ty>>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_2_5_5 = g_2_5;
                auto seen_4_5_5 = seen_4_5;
                auto n_3_5_5 = n_3_5;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto&& _ats = p1;
                    auto&& ats = std::get<1>(_ats);
                    (prism_rtl::finished(f || run_to_end(fold_job(ats, false, ({
                    auto g_2_5_5_5 = g_2_5_5;
                    auto seen_4_5_5_5 = seen_4_5_5;
                    auto n_3_5_5_5 = n_3_5_5;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto g_2_5_5_5_5 = g_2_5_5_5;
                        auto seen_4_5_5_5_5 = seen_4_5_5_5;
                        auto n_3_5_5_5_5 = n_3_5_5_5;
                        entered(once_job([=]() {
                        return ({
                            auto f2 = p0;
                            auto at_ = p1;
                            (prism_rtl::finished(f2 || floaty(g_2_5_5_5_5, at_, prelude::push(seen_4_5_5_5_5, n_3_5_5_5_5))));
                        });
                    }));
                    });
                })));
                })))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::finished(false);
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is<check_types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(Floaty(g, i, seen)));
    })
        : prism_rtl::is<check_types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        fold_job(ts, false, ({
        auto g_1 = g;
        auto seen_2 = seen;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto seen_2_3 = seen_2;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                auto a = p1;
                (prism_rtl::finished(f || floaty(g_1_3, a, seen_2_3)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<check_types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(Floaty(g, e, seen)));
    })
        : prism_rtl::is<check_types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
        ({
        auto g_1 = g;
        auto k_2 = k;
        auto seen_3 = seen;
        auto v__4 = v_;
        call_then(start_floaty(g_1, k_2, seen_3), [=](bool floaty_35036) { return prism_rtl::finished(floaty_35036 || floaty(g_1, v__4, seen_3)); });
    });
    })
        : prism_rtl::finished(false);
    });
}


/// `Start Floaty, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_floaty(check_env::G g, check_types::Ty t, Array<Text> seen) {
    return prism_rtl::make_rc<Floaty>(g, t, seen);
}


/// Podable: unbounded fn OutTy -> Bool
bool podable(const OutTy& t) {
    if (prism_rtl::is<OutTy::OutFn>(t)) {
        return false;
    }
    if (prism_rtl::is<OutTy::OutJobFn>(t)) {
        return false;
    }
    if (prism_rtl::is<OutTy::OutJob>(t)) {
        return false;
    }
    if (prism_rtl::is<OutTy::OutEvent>(t)) {
        return false;
    }
    if (prism_rtl::is<OutTy::OutDyn>(t)) {
        return false;
    }
    if (prism_rtl::is<OutTy::OutShowAny>(t)) {
        return false;
    }
    if (prism_rtl::is<OutTy::OutLive>(t)) {
        return false;
    }
    if (prism_rtl::is<OutTy::OutUnknown>(t)) {
        return false;
    }
    if (prism_rtl::is<OutTy::OutGen>(t)) {
        return true;
    }
    if (prism_rtl::is<OutTy::OutNamed>(t)) {
        auto&& args = prism_rtl::as<OutTy::OutNamed>(t).a1;
        return run_to_end(fold_job(args, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto a = p1;
                    (prism_rtl::finished(ok && podable(a)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<OutTy::OutOpt>(t)) {
        auto&& i = prism_rtl::as<OutTy::OutOpt>(t).a0;
        return podable(i);
    }
    if (prism_rtl::is<OutTy::OutRes>(t)) {
        auto&& i = prism_rtl::as<OutTy::OutRes>(t).a0;
        return podable(i);
    }
    if (prism_rtl::is<OutTy::OutRc>(t)) {
        auto&& i = prism_rtl::as<OutTy::OutRc>(t).a0;
        return podable(i);
    }
    if (prism_rtl::is<OutTy::OutTuple>(t)) {
        auto&& ts = prism_rtl::as<OutTy::OutTuple>(t).a0;
        return run_to_end(fold_job(ts, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto a = p1;
                    (prism_rtl::finished(ok && podable(a)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<OutTy::OutArray>(t)) {
        auto&& e = prism_rtl::as<OutTy::OutArray>(t).a0;
        return podable(e);
    }
    if (prism_rtl::is<OutTy::OutMap>(t)) {
        auto&& k = prism_rtl::as<OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<OutTy::OutMap>(t).a1;
        return podable(k) && podable(v_);
    }
    {
        return true;
    }
}


prism_rtl::Turn<bool> Podable::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<OutTy::OutFn>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<OutTy::OutJobFn>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<OutTy::OutJob>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<OutTy::OutEvent>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<OutTy::OutDyn>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<OutTy::OutShowAny>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<OutTy::OutLive>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<OutTy::OutUnknown>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<OutTy::OutGen>(t) ? prism_rtl::finished(true)
        : prism_rtl::is<OutTy::OutNamed>(t) ? ({
        auto&& args = prism_rtl::as<OutTy::OutNamed>(t).a1;
        fold_job(args, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto a = p1;
                (prism_rtl::finished(ok && podable(a)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<OutTy::OutOpt>(t) ? ({
        auto&& i = prism_rtl::as<OutTy::OutOpt>(t).a0;
        prism_rtl::more(prism_rtl::rc(Podable(i)));
    })
        : prism_rtl::is<OutTy::OutRes>(t) ? ({
        auto&& i = prism_rtl::as<OutTy::OutRes>(t).a0;
        prism_rtl::more(prism_rtl::rc(Podable(i)));
    })
        : prism_rtl::is<OutTy::OutRc>(t) ? ({
        auto&& i = prism_rtl::as<OutTy::OutRc>(t).a0;
        prism_rtl::more(prism_rtl::rc(Podable(i)));
    })
        : prism_rtl::is<OutTy::OutTuple>(t) ? ({
        auto&& ts = prism_rtl::as<OutTy::OutTuple>(t).a0;
        fold_job(ts, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto a = p1;
                (prism_rtl::finished(ok && podable(a)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<OutTy::OutArray>(t) ? ({
        auto&& e = prism_rtl::as<OutTy::OutArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(Podable(e)));
    })
        : prism_rtl::is<OutTy::OutMap>(t) ? ({
        auto&& k = prism_rtl::as<OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<OutTy::OutMap>(t).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_podable(k_1), [=](bool podable_35711) { return prism_rtl::finished(podable_35711 && podable(v__2)); });
    });
    })
        : prism_rtl::finished(true);
    });
}


/// `Start Podable, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_podable(OutTy t) {
    return prism_rtl::make_rc<Podable>(t);
}


/// let emptyEnv
Env empty_env() {
    return Env{.names = Map<Text, Bn>{}, .spans = Map<Text, Vl>{}, .uses = Map<Text, Text>{}};
}


/// NameKeyAt: fn Lx, Env, SName, Range -> Text
Text name_key_at(const Lx& lx, const Env& env, const ast::SName& n, const ast::Range& span) {
    auto&& _m = prelude::get(lx.use_insts, place_key(lx, span));
    if (prism_rtl::is_some(_m)) {
        auto&& u = prism_rtl::some_of(_m);
        return or_(prelude::get(env.uses, prism_rtl::cat(check_env::sname_key(n), "#", show_text(inst_at(lx, u)))), check_env::sname_key(n));
    }
    if (prism_rtl::is_none(_m)) {
        return check_env::sname_key(n);
    }
    prism_rtl::unreachable("no arm matched");
}


/// WithInstances: fn Env, [Text] -> [Text]
Array<Text> with_instances(const Env& env, const Array<Text>& names) {
    return fold(names, names, [&](const Array<Text>& acc, const Text& n) { return append(acc, filter(keys(env->names), [&](const Text& k) { return lexer::has_prefix(k, prism_rtl::cat(n, "#inst")); })); });
}


/// BindSpan: fn Env, Text, Vl -> Env
Env bind_span(const Env& env, const Text& nkey, const Vl& v_) {
    Env this_ = env;
    this_.spans = insert(this_.spans, nkey, v_);
    return this_;
}


/// Bind: fn Env, Text, Bn -> Env
Env bind(const Env& env, const Text& name, const Bn& b) {
    Env this_ = env;
    this_.names = insert(this_.names, name, b);
    return this_;
}


/// ValueTy: fn Vl -> OutTy
OutTy value_ty(const Vl& vl0) {
    if (prism_rtl::is<Vl::VlPlace>(vl0)) {
        auto&& t = prism_rtl::as<Vl::VlPlace>(vl0).a2;
        return t;
    }
    if (prism_rtl::is<Vl::VlOwned>(vl0)) {
        auto&& t = prism_rtl::as<Vl::VlOwned>(vl0).a1;
        return t;
    }
    prism_rtl::unreachable("no arm matched");
}


/// LocalPlace: fn Ex, Holding, OutTy -> Vl
Vl local_place(const Ex& x, const Holding& mode, const OutTy& t) {
    return Vl(Vl::VlPlace{x, mode, t});
}


/// PlaceStem: fn Ex -> Text
Text place_stem(const Ex& x) {
    if (prism_rtl::is<Ex::XVar>(x)) {
        auto&& n = prism_rtl::as<Ex::XVar>(x).a0;
        return n;
    }
    if (prism_rtl::is<Ex::XField>(x)) {
        auto&& f = prism_rtl::as<Ex::XField>(x).a1;
        return f;
    }
    if (prism_rtl::is<Ex::XTarget>(x)) {
        auto&& y = prism_rtl::as<Ex::XTarget>(x).a0;
        return place_stem(y);
    }
    if (prism_rtl::is<Ex::XPart>(x)) {
        auto&& y = prism_rtl::as<Ex::XPart>(x).a0;
        auto&& k = prism_rtl::as<Ex::XPart>(x).a1;
        return prism_rtl::cat(place_stem(y), "_", k);
    }
    {
        return Text::lit("place");
    }
}


/// OnSelf: fn Ex -> Bool
bool on_self(const Ex& x) {
    if (prism_rtl::is<Ex::XField>(x)) {
        auto&& m39198_0_0 = prism_rtl::as<Ex::XField>(x).a0;
        if (prism_rtl::is<Ex::XSelf>(m39198_0_0)) {
            return true;
        }
    }
    if (prism_rtl::is<Ex::XField>(x)) {
        auto&& y = prism_rtl::as<Ex::XField>(x).a0;
        return on_self(y);
    }
    if (prism_rtl::is<Ex::XPart>(x)) {
        auto&& y = prism_rtl::as<Ex::XPart>(x).a0;
        return on_self(y);
    }
    if (prism_rtl::is<Ex::XMethod>(x)) {
        auto&& y = prism_rtl::as<Ex::XMethod>(x).a0;
        return on_self(y);
    }
    if (prism_rtl::is<Ex::XUpgrade>(x)) {
        auto&& y = prism_rtl::as<Ex::XUpgrade>(x).a0;
        return on_self(y);
    }
    {
        return false;
    }
}


/// ?ThroughParent: fn Ex -> ?Ex
std::optional<Ex> through_parent(const Ex& x) {
    if (prism_rtl::is<Ex::XField>(x)) {
        auto&& m39602_0_0 = prism_rtl::as<Ex::XField>(x).a0;
        auto&& m39602_0_1 = prism_rtl::as<Ex::XField>(x).a1;
        if (prism_rtl::is<Ex::XSelf>(m39602_0_0)) {
            if (m39602_0_1 == Text::lit("parent")) {
                return std::optional(Ex(Ex::XVar{Text::lit("parent")}));
            }
        }
    }
    if (prism_rtl::is<Ex::XField>(x)) {
        auto&& y = prism_rtl::as<Ex::XField>(x).a0;
        auto&& f = prism_rtl::as<Ex::XField>(x).a1;
        auto&& _m = through_parent(y);
        if (prism_rtl::is_some(_m)) {
            auto&& z = prism_rtl::some_of(_m);
            return std::optional(Ex(Ex::XField{prism_rtl::rc(z), f}));
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<Ex>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<Ex::XPart>(x)) {
        auto&& y = prism_rtl::as<Ex::XPart>(x).a0;
        auto&& k = prism_rtl::as<Ex::XPart>(x).a1;
        auto&& _m = through_parent(y);
        if (prism_rtl::is_some(_m)) {
            auto&& z = prism_rtl::some_of(_m);
            return std::optional(Ex(Ex::XPart{prism_rtl::rc(z), k}));
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<Ex>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<Ex::XMethod>(x)) {
        auto&& y = prism_rtl::as<Ex::XMethod>(x).a0;
        auto&& m = prism_rtl::as<Ex::XMethod>(x).a1;
        auto&& xs = prism_rtl::as<Ex::XMethod>(x).a2;
        auto&& _m = through_parent(y);
        if (prism_rtl::is_some(_m)) {
            auto&& z = prism_rtl::some_of(_m);
            return std::optional(Ex(Ex::XMethod{prism_rtl::rc(z), m, xs}));
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<Ex>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<Ex::XUpgrade>(x)) {
        auto&& y = prism_rtl::as<Ex::XUpgrade>(x).a0;
        auto&& _m = through_parent(y);
        if (prism_rtl::is_some(_m)) {
            auto&& z = prism_rtl::some_of(_m);
            return std::optional(Ex(Ex::XUpgrade{prism_rtl::rc(z)}));
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<Ex>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return std::optional<Ex>{};
    }
}


/// Own: fn Vl -> Ex
Ex own(const Vl& vl0) {
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::RcRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XDeref{prism_rtl::rc(Ex(Ex::XDeref{prism_rtl::rc(x)}))}))});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::RcOwned>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XDeref{prism_rtl::rc(x)}))});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        auto&& mode = prism_rtl::as<Vl::VlPlace>(vl0).a1;
        auto&& t = prism_rtl::as<Vl::VlPlace>(vl0).a2;
        return is_copy(t)
            ? lower::copy(Vl(Vl::VlPlace{x, mode, t}))
            : Ex(Ex::XClone{prism_rtl::rc(x)});
    }
    if (prism_rtl::is<Vl::VlOwned>(vl0)) {
        auto&& e = prism_rtl::as<Vl::VlOwned>(vl0).a0;
        return e;
    }
    prism_rtl::unreachable("no arm matched");
}


/// Ref: fn Vl -> Ex
Ex ref_(const Vl& vl0) {
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::ByRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return x;
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::RcRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XDeref{prism_rtl::rc(Ex(Ex::XDeref{prism_rtl::rc(x)}))}))});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::RcOwned>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XDeref{prism_rtl::rc(x)}))});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return Ex(Ex::XRef{prism_rtl::rc(x)});
    }
    if (prism_rtl::is<Vl::VlOwned>(vl0)) {
        auto&& e = prism_rtl::as<Vl::VlOwned>(vl0).a0;
        return Ex(Ex::XRef{prism_rtl::rc(e)});
    }
    prism_rtl::unreachable("no arm matched");
}


/// Copy: fn Vl -> Ex
Ex copy(const Vl& vl0) {
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::ByRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return Ex(Ex::XDeref{prism_rtl::rc(x)});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::RcRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return Ex(Ex::XDeref{prism_rtl::rc(Ex(Ex::XDeref{prism_rtl::rc(Ex(Ex::XDeref{prism_rtl::rc(x)}))}))});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return x;
    }
    if (prism_rtl::is<Vl::VlOwned>(vl0)) {
        auto&& e = prism_rtl::as<Vl::VlOwned>(vl0).a0;
        return e;
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsCopy: fn OutTy -> Bool
bool is_copy(const OutTy& t) {
    return ((((t == OutTy(OutTy::OutBool{})) || (t == OutTy(OutTy::OutFloat{}))) || (t == OutTy(OutTy::OutU8{}))) || (t == OutTy(OutTy::OutChar{}))) || (t == OutTy(OutTy::OutUnit{}));
}


/// AsBool: fn Vl -> Ex
Ex as_bool(const Vl& v_) {
    return lower::copy(v_);
}


/// Escape: fn Text -> Text
Text escape(const Text& t) {
    return lexer::map_chars(t, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::finished(char_escape(c)));
            });
        });
    })));
}


/// CharEscape: fn Text -> Text
Text char_escape(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("\\")) {
            return Text::lit("\\\\");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("\"")) {
            return Text::lit("\\\"");
        }
    }
    {
        auto&& c2_0 = text0;
        if (c2_0 == Text::lit("\n")) {
            return Text::lit("\\n");
        }
    }
    {
        auto&& c3_0 = text0;
        if (c3_0 == Text::lit("\t")) {
            return Text::lit("\\t");
        }
    }
    {
        auto&& c4_0 = text0;
        if (c4_0 == Text::lit("\r")) {
            return Text::lit("\\r");
        }
    }
    {
        auto&& c5_0 = text0;
        if (c5_0 == Text::lit("\000"sv)) {
            return Text::lit("\\0");
        }
    }
    {
        auto&& c = text0;
        return c;
    }
}


/// Number: fn OutTy, Text, Bool -> Ex
Ex number(const OutTy& t, const Text& digits, const bool& neg) {
    auto clean = decimal_digits(concat(split(digits, Text::lit("_"))));
    auto signed_ = neg ? prism_rtl::cat("-", clean) : clean;
    if (prism_rtl::is<OutTy::OutNat>(t)) {
        return Ex(Ex::XNat{clean});
    }
    if (prism_rtl::is<OutTy::OutInt>(t)) {
        return Ex(Ex::XInt{signed_});
    }
    if (prism_rtl::is<OutTy::OutU8>(t)) {
        return Ex(Ex::XByte{clean});
    }
    if (prism_rtl::is<OutTy::OutFloat>(t)) {
        return Ex(Ex::XFloat{lexer::contains(clean, Text::lit("."))
            ? signed_
            : prism_rtl::cat(signed_, ".0")});
    }
    {
        return Ex(Ex::XInt{signed_});
    }
}


/// DecimalDigits: fn Text -> Text
Text decimal_digits(const Text& d) {
    auto r = lexer::head(d) == Text::lit("0")
        ? lexer::head(lexer::after_first(d))
        : Text::lit("");
    auto base_ = r == Text::lit("x")
        ? Nat(16u)
        : r == Text::lit("o") ? Nat(8u) : r == Text::lit("b") ? Nat(2u) : Nat(10u);
    auto ds = base_ == Nat(10u) ? d : lexer::after_first(lexer::after_first(d));
    return (lexer::contains(d, Text::lit(".")) || (lexer::head(d) != Text::lit("0"))) || (d == Text::lit("0"))
        ? d
        : prism_rtl::cat(lexer::fold_chars(ds, Nat(0u), ({
        auto base__1 = base_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=](std::tuple<Nat, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto base__1_2 = base__1;
            once_job([=]() {
            return ({
                auto n = p0;
                auto c = p1;
                (prism_rtl::finished((n * base__1_2) + lexer::hex_value(c)));
            });
        });
        });
    })));
    })));
}


/// LiteralValue: unbounded fn Lx, Env, Literal, Range, Bool -> Vl
Vl literal_value(const Lx& lx, const Env& env, const ast::Literal& l, const ast::Range& span, const bool& neg) {
    auto t = out_ty_of(lx, peel(type_at(lx, span)));
    auto&& _m = l.kind;
    if (prism_rtl::is<ast::LitKind::LInt>(_m)) {
        auto&& d = prism_rtl::as<ast::LitKind::LInt>(_m).a0;
        return Vl(Vl::VlOwned{number(t, d, neg), t});
    }
    if (prism_rtl::is<ast::LitKind::LFloat>(_m)) {
        auto&& d = prism_rtl::as<ast::LitKind::LFloat>(_m).a0;
        return Vl(Vl::VlOwned{Ex(Ex::XFloat{neg ? prism_rtl::cat("-", d) : d}), OutTy(OutTy::OutFloat{})});
    }
    if (prism_rtl::is<ast::LitKind::LChar>(_m)) {
        auto&& c = prism_rtl::as<ast::LitKind::LChar>(_m).a0;
        return Vl(Vl::VlOwned{Ex(Ex::XChar{c}), OutTy(OutTy::OutChar{})});
    }
    if (prism_rtl::is<ast::LitKind::LDuration>(_m)) {
        auto&& d = prism_rtl::as<ast::LitKind::LDuration>(_m).a0;
        auto&& u = prism_rtl::as<ast::LitKind::LDuration>(_m).a1;
        return Vl(Vl::VlOwned{refusal(Text::lit("a Duration literal")), OutTy(OutTy::OutDuration{})});
    }
    if (prism_rtl::is<ast::LitKind::LText>(_m)) {
        auto&& segs = prism_rtl::as<ast::LitKind::LText>(_m).a0;
        return text_value(lx, env, segs);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Vl> LiteralValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& l = this->l;
    const auto& span = this->span;
    const auto& neg = this->neg;
    auto env_1 = env;
    auto l_2 = l;
    auto lx_3 = lx;
    auto neg_4 = neg;
    auto span_5 = span;
    return call_then(start_out_ty_of(lx_3, peel(type_at(lx_3, span_5))), [=](OutTy out_ty_of_42894) {
        return ({
            auto t = out_ty_of_42894;
            ({
            auto&& _m = l_2.kind;
            prism_rtl::is<ast::LitKind::LInt>(_m) ? ({
            auto&& d = prism_rtl::as<ast::LitKind::LInt>(_m).a0;
            prism_rtl::finished(Vl(Vl::VlOwned{number(t, d, neg_4), t}));
        })
            : prism_rtl::is<ast::LitKind::LFloat>(_m) ? ({
            auto&& d = prism_rtl::as<ast::LitKind::LFloat>(_m).a0;
            prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XFloat{neg_4 ? prism_rtl::cat("-", d) : d}), OutTy(OutTy::OutFloat{})}));
        })
            : prism_rtl::is<ast::LitKind::LChar>(_m) ? ({
            auto&& c = prism_rtl::as<ast::LitKind::LChar>(_m).a0;
            prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XChar{c}), OutTy(OutTy::OutChar{})}));
        })
            : prism_rtl::is<ast::LitKind::LDuration>(_m) ? ({
            auto&& d = prism_rtl::as<ast::LitKind::LDuration>(_m).a0;
            auto&& u = prism_rtl::as<ast::LitKind::LDuration>(_m).a1;
            prism_rtl::finished(Vl(Vl::VlOwned{refusal(Text::lit("a Duration literal")), OutTy(OutTy::OutDuration{})}));
        })
            : prism_rtl::is<ast::LitKind::LText>(_m) ? ({
            auto&& segs = prism_rtl::as<ast::LitKind::LText>(_m).a0;
            prism_rtl::more(prism_rtl::rc(TextValue(lx_3, env_1, segs)));
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start LiteralValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_literal_value(Lx lx, Env env, ast::Literal l, ast::Range span, bool neg) {
    return prism_rtl::make_rc<LiteralValue>(lx, env, l, span, neg);
}


/// TextValue: unbounded fn Lx, Env, [TextSeg] -> Vl
Vl text_value(const Lx& lx, const Env& env, const Array<ast::TextSeg>& segs) {
    auto plain = fold(segs, true, [&](const bool& ok, const ast::TextSeg& s) { return ok && is_plain_seg(s); });
    return plain
        ? Vl(Vl::VlOwned{Ex(Ex::XText{concat(each(segs, [&](const ast::TextSeg& s) { return plain_text(s); }))}), OutTy(OutTy::OutText{})})
        : Vl(Vl::VlOwned{Ex(Ex::XFormat{run_to_end(each_job(segs, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::TextSeg)>>(prism_rtl::rc([=](ast::TextSeg p0) {
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                (prism_rtl::more(prism_rtl::rc(SegEx(lx_1_3, env_2_3, s))));
            });
        }));
        });
    })));
    })))}), OutTy(OutTy::OutText{})});
}


prism_rtl::Turn<Vl> TextValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& segs = this->segs;
    auto plain = fold(segs, true, [&](const bool& ok, const ast::TextSeg& s) { return ok && is_plain_seg(s); });
    return plain
        ? prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XText{concat(each(segs, [&](const ast::TextSeg& s) { return plain_text(s); }))}), OutTy(OutTy::OutText{})}))
        : ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto segs_3 = segs;
        call_value(each_job(segs_3, ({
        auto lx_2_4 = lx_2;
        auto env_1_4 = env_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::TextSeg)>>(prism_rtl::rc([=](ast::TextSeg p0) {
        return ({
            auto lx_2_4_4 = lx_2_4;
            auto env_1_4_4 = env_1_4;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                (prism_rtl::more(prism_rtl::rc(SegEx(lx_2_4_4, env_1_4_4, s))));
            });
        }));
        });
    })));
    })), [=](Array<Ex> each_43610) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XFormat{each_43610}), OutTy(OutTy::OutText{})})); });
    });
}


/// `Start TextValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_text_value(Lx lx, Env env, Array<ast::TextSeg> segs) {
    return prism_rtl::make_rc<TextValue>(lx, env, segs);
}


/// IsPlainSeg: fn TextSeg -> Bool
bool is_plain_seg(const ast::TextSeg& text_seg0) {
    if (prism_rtl::is<ast::TextSeg::SegPlain>(text_seg0)) {
        return true;
    }
    if (prism_rtl::is<ast::TextSeg::SegPlaceholder>(text_seg0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// PlainText: fn TextSeg -> Text
Text plain_text(const ast::TextSeg& text_seg0) {
    if (prism_rtl::is<ast::TextSeg::SegPlain>(text_seg0)) {
        auto&& t = prism_rtl::as<ast::TextSeg::SegPlain>(text_seg0).a0;
        return t;
    }
    if (prism_rtl::is<ast::TextSeg::SegPlaceholder>(text_seg0)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SegEx: unbounded fn Lx, Env, TextSeg -> Ex
Ex seg_ex(const Lx& lx, const Env& env, const ast::TextSeg& text_seg2) {
    if (prism_rtl::is<ast::TextSeg::SegPlain>(text_seg2)) {
        auto&& t = prism_rtl::as<ast::TextSeg::SegPlain>(text_seg2).a0;
        return Ex(Ex::XText{t});
    }
    if (prism_rtl::is<ast::TextSeg::SegPlaceholder>(text_seg2)) {
        auto&& e = prism_rtl::as<ast::TextSeg::SegPlaceholder>(text_seg2).a0;
        auto v_ = value_of(lx, env, e);
        return shown_part(v_);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Ex> SegEx::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& text_seg2 = this->text_seg2;
    return ({
        prism_rtl::is<ast::TextSeg::SegPlain>(text_seg2) ? ({
        auto&& t = prism_rtl::as<ast::TextSeg::SegPlain>(text_seg2).a0;
        prism_rtl::finished(Ex(Ex::XText{t}));
    })
        : prism_rtl::is<ast::TextSeg::SegPlaceholder>(text_seg2) ? ({
        auto&& e = prism_rtl::as<ast::TextSeg::SegPlaceholder>(text_seg2).a0;
        ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](Vl value_of_44009) {
        return ({
            auto v_ = value_of_44009;
            (prism_rtl::finished(shown_part(v_)));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SegEx, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_seg_ex(Lx lx, Env env, ast::TextSeg text_seg2) {
    return prism_rtl::make_rc<SegEx>(lx, env, text_seg2);
}


/// ShownPart: fn Vl -> Ex
Ex shown_part(const Vl& v_) {
    auto&& _m = value_ty(v_);
    if (prism_rtl::is<OutTy::OutText>(_m)) {
        return ref_(v_);
    }
    if (prism_rtl::is<OutTy::OutNat>(_m)) {
        return ref_(v_);
    }
    if (prism_rtl::is<OutTy::OutInt>(_m)) {
        return ref_(v_);
    }
    if (prism_rtl::is<OutTy::OutU8>(_m)) {
        return ref_(v_);
    }
    {
        return Ex(Ex::XCall{Text::lit("show"), Array(std::vector{ref_(v_)})});
    }
}


/// Refusal: fn Text -> Ex
Ex refusal(const Text& what) {
    return Ex(Ex::XRefusal{what});
}


/// TryOf: fn Ex -> Ex
Ex try_of(const Ex& x) {
    return is_named_place(x)
        ? refusal(prism_rtl::cat("`?` of the place `", place_stem(x), "`, which C++'s TRY would move out of (only a temporary may be tried)"))
        : Ex(Ex::XTry{prism_rtl::rc(x)});
}


/// IsNamedPlace: fn Ex -> Bool
bool is_named_place(const Ex& x) {
    if (prism_rtl::is<Ex::XVar>(x)) {
        return true;
    }
    if (prism_rtl::is<Ex::XField>(x)) {
        return true;
    }
    if (prism_rtl::is<Ex::XPart>(x)) {
        return true;
    }
    if (prism_rtl::is<Ex::XTarget>(x)) {
        return true;
    }
    if (prism_rtl::is<Ex::XRef>(x)) {
        auto&& y = prism_rtl::as<Ex::XRef>(x).a0;
        return is_named_place(y);
    }
    if (prism_rtl::is<Ex::XDeref>(x)) {
        auto&& y = prism_rtl::as<Ex::XDeref>(x).a0;
        return is_named_place(y);
    }
    {
        return false;
    }
}


/// let loweringRefusal
Text lowering_refusal() {
    return Text::lit("prismc does not lower ");
}


/// RefusalDo: fn Text -> Do
Do refusal_do(const Text& what) {
    return Do(Do::DoExpr{refusal(what)});
}


/// ValueOf: unbounded fn Lx, Env, Expr -> Vl
Vl value_of(const Lx& lx, const Env& env, const ast::Expr& e) {
    auto&& _m = prelude::get(env.spans, place_key(lx, e.span));
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        return v_;
    }
    if (prism_rtl::is_none(_m)) {
        return unbound_value_of(lx, env, e);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Vl> ValueOf::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = prelude::get(env.spans, place_key(lx, e.span));
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        prism_rtl::finished(v_);
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(UnboundValueOf(lx, env, e)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ValueOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_value_of(Lx lx, Env env, ast::Expr e) {
    return prism_rtl::make_rc<ValueOf>(lx, env, e);
}


/// UnboundValueOf: unbounded fn Lx, Env, Expr -> Vl
Vl unbound_value_of(const Lx& lx, const Env& env, const ast::Expr& e) {
    return is_event_value(lx, env, e)
        ? event_value_of(lx, env, e)
        : value_by_kind(lx, env, e);
}


prism_rtl::Turn<Vl> UnboundValueOf::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    auto e_1 = e;
    auto env_2 = env;
    auto lx_3 = lx;
    return call_then(start_is_event_value(lx_3, env_2, e_1), [=](bool is_event_value_45984) {
        return is_event_value_45984
            ? prism_rtl::more(prism_rtl::rc(EventValueOf(lx_3, env_2, e_1)))
            : prism_rtl::more(prism_rtl::rc(ValueByKind(lx_3, env_2, e_1)));
    });
}


/// `Start UnboundValueOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_unbound_value_of(Lx lx, Env env, ast::Expr e) {
    return prism_rtl::make_rc<UnboundValueOf>(lx, env, e);
}


/// IsEventValue: unbounded fn Lx, Env, Expr -> Bool
bool is_event_value(const Lx& lx, const Env& env, const ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
        return false;
    }
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        return false;
    }
    {
        return ((layer_of(type_at(lx, e.span)) == Layer(Layer::LyEv{})) && (!fold(operands(e), false, [&](const bool& bound, const ast::Expr& c) { return bound || check_env::has_key(env.spans, place_key(lx, c.span)); }))) && has_event_source(lx, env, e);
    }
}


prism_rtl::Turn<bool> IsEventValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EName>(_m) ? prism_rtl::finished(false)
        : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? prism_rtl::finished(false)
        : prism_rtl::finished(((layer_of(type_at(lx, e.span)) == Layer(Layer::LyEv{})) && (!fold(operands(e), false, [&](const bool& bound, const ast::Expr& c) { return bound || check_env::has_key(env.spans, place_key(lx, c.span)); }))) && has_event_source(lx, env, e));
    });
}


/// `Start IsEventValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_event_value(Lx lx, Env env, ast::Expr e) {
    return prism_rtl::make_rc<IsEventValue>(lx, env, e);
}


/// HasEventSource: unbounded fn Lx, Env, Expr -> Bool
bool has_event_source(const Lx& lx, const Env& env, const ast::Expr& e) {
    return run_to_end(fold_job(operands(e), false, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto found = p0;
                auto c = p1;
                (prism_rtl::finished(found || is_event_source(lx_1_3, env_2_3, c)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> HasEventSource::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return fold_job(operands(e), false, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto found = p0;
                auto c = p1;
                (prism_rtl::finished(found || is_event_source(lx_1_3, env_2_3, c)));
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start HasEventSource, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_has_event_source(Lx lx, Env env, ast::Expr e) {
    return prism_rtl::make_rc<HasEventSource>(lx, env, e);
}


/// IsEventSource: unbounded fn Lx, Env, Expr -> Bool
bool is_event_source(const Lx& lx, const Env& env, const ast::Expr& c) {
    return layer_of(type_at(lx, c.span)) != Layer(Layer::LyEv{})
        ? false
        : ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = c.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = prelude::get(env->names, check_env::sname_key(n));
                if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m)) && prism_rtl::is<OutTy::OutEvent>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2)) {
                    _v.set(true);
                    goto _done;
                }
                if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(_m))) {
                    _v.set(check_env::has_key(env->names, prism_rtl::cat(check_env::sname_key(n), "#port")));
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(is_event_source(lx, env, x));
            goto _done;
        }
        {
            _v.set(has_event_source(lx, env, c));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> IsEventSource::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    return layer_of(type_at(lx, c.span)) != Layer(Layer::LyEv{})
        ? prism_rtl::finished(false)
        : ({
        auto&& _m = c.kind;
        prism_rtl::is<ast::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        ({
        auto&& _m = prelude::get(env->names, check_env::sname_key(n));
        prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m)) && prism_rtl::is<OutTy::OutEvent>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2) ? prism_rtl::finished(true)
        : prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(_m)) ? prism_rtl::finished(check_env::has_key(env->names, prism_rtl::cat(check_env::sname_key(n), "#port")))
        : prism_rtl::finished(false);
    });
    })
        : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(IsEventSource(lx, env, x)));
    })
        : prism_rtl::more(prism_rtl::rc(HasEventSource(lx, env, c)));
    });
}


/// `Start IsEventSource, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_event_source(Lx lx, Env env, ast::Expr c) {
    return prism_rtl::make_rc<IsEventSource>(lx, env, c);
}


/// EventValueOf: unbounded fn Lx, Env, Expr -> Vl
Vl event_value_of(const Lx& lx, const Env& env, const ast::Expr& e) {
    auto t = out_ty_of(lx, peel(type_at(lx, e.span)));
    auto et = OutTy(OutTy::OutEvent{prism_rtl::rc(t)});
    auto filtered_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<ast::Arg>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            _v.set(callee_key(lx, c) == Text::lit("Prelude.!Filter")
                ? index(args, Nat(0u))
                : std::optional<ast::Arg>{});
            goto _done;
        }
        {
            _v.set(std::optional<ast::Arg>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    if (prism_rtl::is_some(filtered_opt)) {
        auto&& a = prism_rtl::some_of(filtered_opt);
        return Vl(Vl::VlOwned{Ex(Ex::XMethod{prism_rtl::rc(own(value_of(lx, env, a->value))), Text::lit("filter_some"), Array<Ex>{}}), et});
    }
    if (prism_rtl::is_none(filtered_opt)) {
        auto evs = filter(operands(e), [&](const ast::Expr& x) { return layer_of(type_at(lx, x.span)) == Layer(Layer::LyEv{}); });
        {
            auto&& m48051_0 = evs;
            if (m48051_0.size() == 1u) {
                {
                    auto&& _c1 = index(m48051_0, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& one = prism_rtl::some_of(_c1);
                        auto src = own(value_of(lx, env, one));
                        auto it = out_ty_of(lx, peel(type_at(lx, one.span)));
                        auto caps = filter(with_instances(env, read_names(typed::exprs_in(e))), [&](const Text& n) {
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<bool> _v;
                                auto&& _m = prelude::get(env->names, n);
                                if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                                    _v.set(true);
                                    goto _done;
                                }
                                {
                                    _v.set(false);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        });
                        auto [dos, env1] = fold(caps, std::tuple{Array<Do>{}, env}, [&](const std::tuple<Array<Do>, Env>& _p0, const Text& n) {
                            auto&& acc = std::get<0>(_p0);
                            auto&& en = std::get<1>(_p0);
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
                                auto&& _m = prelude::get(env->names, n);
                                if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                                    auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                                    auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                                    auto&& ct = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                                    _v.set(({
                                        auto local = prism_rtl::cat(place_stem(rs), "_c");
                                        std::tuple{prelude::push(acc, Do(Do::DoLet{Pa(Pa::PaBind{local}), own(local_place(rs, mode, ct))})), bind(en, n, Bn(Bn::BnLocal{Ex(Ex::XVar{local}), Holding(Holding::Owned{}), ct}))};
                                    }));
                                    goto _done;
                                }
                                {
                                    _v.set(std::tuple{acc, en});
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        });
                        auto env2 = bind_span(env1, place_key(lx, one.span), Vl(Vl::VlPlace{Ex(Ex::XVar{Text::lit("y_ev")}), Holding(Holding::ByRef{}), it}));
                        auto body = own(value_by_kind(lx, env2, e));
                        auto mapped = Ex(Ex::XMethod{prism_rtl::rc(src), Text::lit("map"), Array(std::vector{Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{Text::lit("y_ev")})), OutTy(OutTy::OutRef{prism_rtl::rc(it)})})}), prism_rtl::rc(body)})})});
                        return Vl(Vl::VlOwned{Ex(Ex::XBlock{prelude::push(dos, Do(Do::DoLet{Pa(Pa::PaBind{Text::lit("src_ev")}), src})), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("src_ev")})), Text::lit("map"), Array(std::vector{Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{Text::lit("y_ev")})), OutTy(OutTy::OutRef{prism_rtl::rc(it)})})}), prism_rtl::rc(body)})})}))}), et});
                    }
                }
            }
        }
        {
            return Vl(Vl::VlOwned{refusal(Text::lit("an event value of several events")), et});
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Vl> EventValueOf::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    auto e_1 = e;
    auto env_2 = env;
    auto lx_3 = lx;
    return call_then(start_out_ty_of(lx_3, peel(type_at(lx_3, e_1.span))), [=](OutTy out_ty_of_47610) {
        return ({
            auto t = out_ty_of_47610;
            auto et = OutTy(OutTy::OutEvent{prism_rtl::rc(t)});
            auto filtered_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<ast::Arg>> _v;
                auto&& _m = e_1.kind;
                if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
                    auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
                    auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
                    _v.set(callee_key(lx_3, c) == Text::lit("Prelude.!Filter")
                        ? index(args, Nat(0u))
                        : std::optional<ast::Arg>{});
                    goto _done;
                }
                {
                    _v.set(std::optional<ast::Arg>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            ({
            prism_rtl::is_some(filtered_opt) ? ({
            auto&& a = prism_rtl::some_of(filtered_opt);
            ({
            auto a_4 = a;
            call_then(start_value_of(lx_3, env_2, a_4->value), [=](Vl value_of_47887) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XMethod{prism_rtl::rc(own(value_of_47887)), Text::lit("filter_some"), Array<Ex>{}}), et})); });
        });
        })
            : prism_rtl::is_none(filtered_opt) ? ({
            auto evs = filter(operands(e_1), [&](const ast::Expr& x) { return layer_of(type_at(lx_3, x.span)) == Layer(Layer::LyEv{}); });
            ({
            ({
            auto&& m48051_0 = evs;
            (m48051_0.size() == 1u) && ({
            auto&& _c1 = index(m48051_0, Nat(0u));
            prism_rtl::is_some(_c1);
        });
        }) ? ({
            auto&& m48051_0 = evs;
            auto&& _c1 = index(m48051_0, Nat(0u));
            auto&& one = prism_rtl::some_of(_c1);
            call_then(start_value_of(lx_3, env_2, one), [=](Vl value_of_48122) {
            return ({
                auto src = own(value_of_48122);
                call_then(start_out_ty_of(lx_3, peel(type_at(lx_3, one.span))), [=](OutTy out_ty_of_48173) {
                return ({
                    auto it = out_ty_of_48173;
                    call_then(typed::start_exprs_in(e_1), [=](Array<ast::Expr> exprs_in_48284) {
                    return call_then(start_read_names(exprs_in_48284), [=](Array<Text> read_names_48273) {
                        return ({
                            auto caps = filter(with_instances(env_2, read_names_48273), [&](const Text& n) {
                                return ({
                                    __label__ _done;
                                    prism_rtl::Slot<bool> _v;
                                    auto&& _m = prelude::get(env_2->names, n);
                                    if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                                        _v.set(true);
                                        goto _done;
                                    }
                                    {
                                        _v.set(false);
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                            });
                            auto [dos, env1] = fold(caps, std::tuple{Array<Do>{}, env_2}, [&](const std::tuple<Array<Do>, Env>& _p0, const Text& n) {
                                auto&& acc = std::get<0>(_p0);
                                auto&& en = std::get<1>(_p0);
                                return ({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
                                    auto&& _m = prelude::get(env_2->names, n);
                                    if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                                        auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                                        auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                                        auto&& ct = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                                        _v.set(({
                                            auto local = prism_rtl::cat(place_stem(rs), "_c");
                                            std::tuple{prelude::push(acc, Do(Do::DoLet{Pa(Pa::PaBind{local}), own(local_place(rs, mode, ct))})), bind(en, n, Bn(Bn::BnLocal{Ex(Ex::XVar{local}), Holding(Holding::Owned{}), ct}))};
                                        }));
                                        goto _done;
                                    }
                                    {
                                        _v.set(std::tuple{acc, en});
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                            });
                            auto env2 = bind_span(env1, place_key(lx_3, one.span), Vl(Vl::VlPlace{Ex(Ex::XVar{Text::lit("y_ev")}), Holding(Holding::ByRef{}), it}));
                            call_then(start_value_by_kind(lx_3, env2, e_1), [=](Vl value_by_kind_48980) {
                            return ({
                                auto body = own(value_by_kind_48980);
                                auto mapped = Ex(Ex::XMethod{prism_rtl::rc(src), Text::lit("map"), Array(std::vector{Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{Text::lit("y_ev")})), OutTy(OutTy::OutRef{prism_rtl::rc(it)})})}), prism_rtl::rc(body)})})});
                                (prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XBlock{prelude::push(dos, Do(Do::DoLet{Pa(Pa::PaBind{Text::lit("src_ev")}), src})), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("src_ev")})), Text::lit("map"), Array(std::vector{Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{Text::lit("y_ev")})), OutTy(OutTy::OutRef{prism_rtl::rc(it)})})}), prism_rtl::rc(body)})})}))}), et})));
                            });
                        });
                        });
                    });
                });
                });
            });
            });
        });
        })
            : prism_rtl::finished(Vl(Vl::VlOwned{refusal(Text::lit("an event value of several events")), et}));
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start EventValueOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_event_value_of(Lx lx, Env env, ast::Expr e) {
    return prism_rtl::make_rc<EventValueOf>(lx, env, e);
}


/// ValueByKind: unbounded fn Lx, Env, Expr -> Vl
Vl value_by_kind(const Lx& lx, const Env& env, const ast::Expr& e) {
    auto t = out_ty_of(lx, peel(type_at(lx, e.span)));
    auto&& _m = e.kind;
    if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        return name_value(lx, env, n, e.span);
    }
    if (prism_rtl::is<ast::ExprKind::ELit>(_m)) {
        auto&& l = prism_rtl::as<ast::ExprKind::ELit>(_m).a0;
        return literal_value(lx, env, l, e.span, false);
    }
    if (prism_rtl::is<ast::ExprKind::EUnit>(_m)) {
        return Vl(Vl::VlOwned{Ex(Ex::XUnit{}), OutTy(OutTy::OutUnit{})});
    }
    if (prism_rtl::is<ast::ExprKind::EBound>(_m)) {
        auto&& b = prism_rtl::as<ast::ExprKind::EBound>(_m).a0;
        auto&& _m = prelude::get(env->names, b);
        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
            auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
            auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
            return local_place(rs, mode, bt);
        }
        {
            return Vl(Vl::VlOwned{refusal(prism_rtl::cat("`", b, "` outside a `for`")), t});
        }
    }
    if (prism_rtl::is<ast::ExprKind::ENil>(_m)) {
        return Vl(Vl::VlOwned{Ex(Ex::XTyped{prism_rtl::rc(Ex(Ex::XNone{})), t}), t});
    }
    if (prism_rtl::is<ast::ExprKind::ETuple>(_m)) {
        auto&& es = prism_rtl::as<ast::ExprKind::ETuple>(_m).a0;
        return Vl(Vl::VlOwned{Ex(Ex::XTuple{run_to_end(each_job(es, ({
            auto lx_1 = lx;
            auto env_2 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Expr)>>(prism_rtl::rc([=](ast::Expr p0) {
            return ({
                auto lx_1_3 = lx_1;
                auto env_2_3 = env_2;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    call_then(start_value_of(lx_1_3, env_2_3, x), [=](Vl value_of_49967) { return prism_rtl::finished(own(value_of_49967)); });
                });
            }));
            });
        })));
        })))}), t});
    }
    if (prism_rtl::is<ast::ExprKind::EArray>(_m)) {
        auto&& m49530_6_0 = prism_rtl::as<ast::ExprKind::EArray>(_m).a0;
        if (m49530_6_0.size() == 0u) {
            return Vl(Vl::VlOwned{Ex(Ex::XTyped{prism_rtl::rc(Ex(Ex::XCall{Text::lit("Array::new"), Array<Ex>{}})), t}), t});
        }
    }
    if (prism_rtl::is<ast::ExprKind::EArray>(_m)) {
        auto&& es = prism_rtl::as<ast::ExprKind::EArray>(_m).a0;
        return Vl(Vl::VlOwned{Ex(Ex::XCall{Text::lit("Array::from"), Array(std::vector{Ex(Ex::XVec{run_to_end(each_job(es, ({
            auto lx_1 = lx;
            auto env_2 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Expr)>>(prism_rtl::rc([=](ast::Expr p0) {
            return ({
                auto lx_1_3 = lx_1;
                auto env_2_3 = env_2;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    call_then(start_value_of(lx_1_3, env_2_3, x), [=](Vl value_of_50139) { return prism_rtl::finished(own(value_of_50139)); });
                });
            }));
            });
        })));
        })))})})}), t});
    }
    if (prism_rtl::is<ast::ExprKind::EMap>(_m)) {
        auto&& m49530_8_0 = prism_rtl::as<ast::ExprKind::EMap>(_m).a0;
        if (m49530_8_0.size() == 0u) {
            return Vl(Vl::VlOwned{Ex(Ex::XTyped{prism_rtl::rc(Ex(Ex::XCall{Text::lit("Map::new"), Array<Ex>{}})), t}), t});
        }
    }
    if (prism_rtl::is<ast::ExprKind::EMap>(_m)) {
        auto&& kvs = prism_rtl::as<ast::ExprKind::EMap>(_m).a0;
        return Vl(Vl::VlOwned{Ex(Ex::XCall{Text::lit("map_of"), Array(std::vector{Ex(Ex::XVec{run_to_end(each_job(kvs, ({
            auto lx_1 = lx;
            auto env_2 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<ast::Expr, ast::Expr>)>>(prism_rtl::rc([=](std::tuple<ast::Expr, ast::Expr> p0) {
            return ({
                auto lx_1_3 = lx_1;
                auto env_2_3 = env_2;
                entered(once_job([=]() {
                return ({
                    auto [k, v_] = p0;
                    call_then(start_value_of(lx_1_3, env_2_3, k), [=](Vl value_of_50320) { return call_then(start_value_of(lx_1_3, env_2_3, v_), [=](Vl value_of_50346) { return prism_rtl::finished(Ex(Ex::XTuple{Array(std::vector{own(value_of_50320), own(value_of_50346)})})); }); });
                });
            }));
            });
        })));
        })))})})}), t});
    }
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        return value_of(lx, env, x);
    }
    if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
        return application(lx, env, c, args, e.span);
    }
    if (prism_rtl::is<ast::ExprKind::EMethod>(_m)) {
        auto&& r = prism_rtl::as<ast::ExprKind::EMethod>(_m).a0;
        auto&& m = prism_rtl::as<ast::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<ast::ExprKind::EMethod>(_m).a2;
        return application(lx, env, ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EName{m})), .span = m.span}, append(Array(std::vector{ast::Arg{.name = std::optional<ast::Ident>{}, .value = r, .span = r.span}}), args), e.span);
    }
    if (prism_rtl::is<ast::ExprKind::EBinary>(_m)) {
        auto&& op = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
        return binary_value(lx, env, op, l, r, e.span);
    }
    if (prism_rtl::is<ast::ExprKind::EUnary>(_m)) {
        auto&& m49530_14_0 = prism_rtl::as<ast::ExprKind::EUnary>(_m).a0;
        auto&& x = prism_rtl::as<ast::ExprKind::EUnary>(_m).a1;
        if (m49530_14_0 == Text::lit("not")) {
            return Vl(Vl::VlOwned{Ex(Ex::XUnary{Text::lit("!"), prism_rtl::rc(as_bool(value_of(lx, env, x)))}), OutTy(OutTy::OutBool{})});
        }
    }
    if (prism_rtl::is<ast::ExprKind::EUnary>(_m)) {
        auto&& m49530_15_0 = prism_rtl::as<ast::ExprKind::EUnary>(_m).a0;
        auto&& x = prism_rtl::as<ast::ExprKind::EUnary>(_m).a1;
        if (m49530_15_0 == Text::lit("neg")) {
            auto&& _m = x.kind;
            if (prism_rtl::is<ast::ExprKind::ELit>(_m)) {
                auto&& l = prism_rtl::as<ast::ExprKind::ELit>(_m).a0;
                return literal_value(lx, env, l, x.span, true);
            }
            {
                auto v_ = value_of(lx, env, x);
                return is_copy(t)
                    ? Vl(Vl::VlOwned{Ex(Ex::XUnary{Text::lit("-"), prism_rtl::rc(lower::copy(v_))}), t})
                    : Vl(Vl::VlOwned{Ex(Ex::XUnary{Text::lit("-"), prism_rtl::rc(ref_(v_))}), t});
            }
        }
    }
    if (prism_rtl::is<ast::ExprKind::EUnary>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EUnary>(_m).a1;
        return value_of(lx, env, x);
    }
    if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
        auto&& m49530_17_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
        if (m49530_17_0 == Text::lit("?")) {
            return Vl(Vl::VlOwned{Ex(Ex::XCtor{Text::lit("Some"), Array(std::vector{own(value_of(lx, env, x))})}), t});
        }
    }
    if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
        auto&& m49530_18_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
        if (m49530_18_0 == Text::lit("~")) {
            return Vl(Vl::VlOwned{Ex(Ex::XCtor{Text::lit("Ok"), Array(std::vector{own(value_of(lx, env, x))})}), t});
        }
    }
    if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
        auto&& m49530_19_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
        if (m49530_19_0 == Text::lit("@")) {
            return pure_blueprint(lx, env, x, t);
        }
    }
    if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
        return value_of(lx, env, x);
    }
    if (prism_rtl::is<ast::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
        auto&& name = prism_rtl::as<ast::ExprKind::EField>(_m).a2;
        return field_value(lx, env, r, name.name);
    }
    if (prism_rtl::is<ast::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
        auto&& i = prism_rtl::as<ast::ExprKind::EIndex>(_m).a1;
        return index_value(lx, env, r, i, t);
    }
    if (prism_rtl::is<ast::ExprKind::ELambda>(_m)) {
        auto&& ps_opt = prism_rtl::as<ast::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<ast::ExprKind::ELambda>(_m).a1;
        return lambda_value(lx, env, e, or_(ps_opt, Array<ast::Pattern_>{}), body);
    }
    if (prism_rtl::is<ast::ExprKind::EIf>(_m)) {
        auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
        return if_value(lx, env, c, then_b, else_b_opt, t);
    }
    if (prism_rtl::is<ast::ExprKind::EMatch>(_m)) {
        auto&& s = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
        return match_value(lx, env, s, arms, t, e.span);
    }
    if (prism_rtl::is<ast::ExprKind::ETemplate>(_m)) {
        auto&& tp = prism_rtl::as<ast::ExprKind::ETemplate>(_m).a0;
        return template_value(lx, env, tp);
    }
    if (prism_rtl::is<ast::ExprKind::ECast>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::ECast>(_m).a0;
        return value_of(lx, env, x);
    }
    if (prism_rtl::is<ast::ExprKind::ETypeArgs>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::ETypeArgs>(_m).a0;
        return value_of(lx, env, x);
    }
    if (prism_rtl::is<ast::ExprKind::EGiven>(_m)) {
        auto&& b = prism_rtl::as<ast::ExprKind::EGiven>(_m).a0;
        return given_value(lx, env, b, t, e.span);
    }
    if (prism_rtl::is<ast::ExprKind::EUpdate>(_m)) {
        auto&& target = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a0;
        auto&& b = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a1;
        return update_value(lx, env, target, b, t, e.span);
    }
    if (prism_rtl::is<ast::ExprKind::EAny>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EAny>(_m).a0;
        return Vl(Vl::VlOwned{Ex(Ex::XCall{Text::lit("Rc::new"), Array(std::vector{own(value_of(lx, env, x))})}), OutTy(OutTy::OutShowAny{})});
    }
    {
        return Vl(Vl::VlOwned{refusal(prism_rtl::cat(kind_words(e.kind), " as a value")), t});
    }
}

}  // namespace crate::lower
