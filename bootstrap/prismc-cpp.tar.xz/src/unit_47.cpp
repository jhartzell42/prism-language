// The module `Lower.Node.Static`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/node_/static_/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Node.Static`, from `target/bootstrap/cpp-src/prismc/lower/node/static.prism`.
namespace crate::lower::node_::static_ {

void HostForm::show(Printer& p) const {
    if (auto c = std::get_if<HostEach>(&cases())) p.choice("HostEach", {});
    else if (auto c = std::get_if<HostSome>(&cases())) p.choice("HostSome", {});
}

Pod HostForm::to_pod() const {
    return std::holds_alternative<HostEach>(cases()) ? Pod::choice("HostEach", {})
        : std::holds_alternative<HostSome>(cases()) ? Pod::choice("HostSome", {})
        : Pod();
}

Result<HostForm> HostForm::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "HostEach" && c->args.size() == 0) return HostForm(HostEach{});
        if (c->ctor == "HostSome" && c->args.size() == 0) return HostForm(HostSome{});
    }
    return mismatch<HostForm>("a HostForm", p);
}


/// WidgetLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> widget_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Expr& e, const std::optional<crate::lower::types::Bn>& bound_opt) {
    auto lx = wx.lx;
    auto [callee, args] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::syntax::Expr, Array<crate::syntax::Arg>>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& xs = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{c, xs});
            goto _done;
        }
        {
            _v.set(std::tuple{e, Array<crate::syntax::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto qk = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = callee.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _q_opt = crate::check::env::names::resolve_value(lx.g, lx.home, n);
                auto&& q_opt = std::get<0>(_q_opt);
                or_(q_opt, Text::lit(""));
            }));
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto target_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Nat>> _v;
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
            auto&& er = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
            _v.set(std::optional(er.node_));
            goto _done;
        }
        {
            _v.set(std::optional<Nat>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto param_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::lower::types::Bn>> _v;
        auto&& _m = callee.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(len(n->path_) == Nat(1u)
                ? crate::prelude::get(menv->names, crate::check::env::sname_key(n))
                : std::optional<crate::lower::types::Bn>{});
            goto _done;
        }
        {
            _v.set(std::optional<crate::lower::types::Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    if (prism_rtl::is_some(param_opt) && prism_rtl::is<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_opt))) {
        auto&& x = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_opt)).a0;
        auto&& cbenv = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_opt)).a1;
        auto&& cmenv = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_opt)).a2;
        auto&& clx = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_opt)).a3;
        return apply_widget_param(wx, x, cbenv, cmenv, clx, len(args));
    }
    {
        return widget_call(wx, benv, menv, e, bound_opt, qk, args, target_opt);
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> WidgetLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& e = this->e;
    const auto& bound_opt = this->bound_opt;
    auto lx = wx.lx;
    auto [callee, args] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::syntax::Expr, Array<crate::syntax::Arg>>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& xs = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{c, xs});
            goto _done;
        }
        {
            _v.set(std::tuple{e, Array<crate::syntax::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto qk = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = callee.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _q_opt = crate::check::env::names::resolve_value(lx.g, lx.home, n);
                auto&& q_opt = std::get<0>(_q_opt);
                or_(q_opt, Text::lit(""));
            }));
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto target_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Nat>> _v;
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
            auto&& er = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
            _v.set(std::optional(er.node_));
            goto _done;
        }
        {
            _v.set(std::optional<Nat>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto param_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::lower::types::Bn>> _v;
        auto&& _m = callee.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(len(n->path_) == Nat(1u)
                ? crate::prelude::get(menv->names, crate::check::env::sname_key(n))
                : std::optional<crate::lower::types::Bn>{});
            goto _done;
        }
        {
            _v.set(std::optional<crate::lower::types::Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return ({
        prism_rtl::is_some(param_opt) && prism_rtl::is<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_opt)) ? ({
        auto&& x = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_opt)).a0;
        auto&& cbenv = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_opt)).a1;
        auto&& cmenv = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_opt)).a2;
        auto&& clx = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_opt)).a3;
        prism_rtl::finished(apply_widget_param(wx, x, cbenv, cmenv, clx, len(args)));
    })
        : prism_rtl::finished(widget_call(wx, benv, menv, e, bound_opt, qk, args, target_opt));
    });
}


/// `Start WidgetLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_widget_line(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Expr e, std::optional<crate::lower::types::Bn> bound_opt) {
    return prism_rtl::make_rc<WidgetLine>(wx, benv, menv, e, bound_opt);
}


/// ApplyWidgetParam: unbounded fn Wx, Expr, Env, Env, Lx, Nat -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> apply_widget_param(const crate::lower::node_::Wx& wx, const crate::syntax::Expr& x, const crate::lower::types::Env& cbenv, const crate::lower::types::Env& cmenv, const crate::lower::Lx& clx, const Nat& nargs) {
    return nargs > Nat(0u)
        ? ({
        auto wx2 = ({
            crate::lower::node_::Wx this_ = wx;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a widget parameter applied to arguments")));
            this_;
        });
        std::tuple{wx2, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    })
        : wx.depth > Nat(32u)
        ? std::tuple{wx, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})}
        : ({
        auto lx = wx.lx;
        auto inner = ({
            crate::lower::node_::Wx this_ = wx;
            this_.lx = clx;
            this_.depth = this_.depth + Nat(1u);
            this_;
        });
        auto [done, res] = crate::lower::node_::def::build_line(inner, cbenv, cmenv, x, std::optional<crate::lower::types::Bn>{});
        auto back_ = ({
            crate::lower::node_::Wx this_ = done;
            this_.lx = lx;
            this_.depth = wx.depth;
            this_;
        });
        std::tuple{back_, res};
    });
}


/// InlineBlock: unbounded fn Wx, Env, Env, Block, Lx -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> inline_block(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Block& b, const crate::lower::Lx& lx) {
    auto inner = ({
        crate::lower::node_::Wx this_ = wx;
        this_.result = crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{});
        this_;
    });
    auto done = crate::lower::node_::def::block_into(inner, benv, menv, b);
    auto back_ = ({
        crate::lower::node_::Wx this_ = done;
        this_.result = wx->result;
        this_;
    });
    return std::tuple{back_, done->result};
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> InlineBlock::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& b = this->b;
    const auto& lx = this->lx;
    auto inner = ({
        crate::lower::node_::Wx this_ = wx;
        this_.result = crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{});
        this_;
    });
    auto b_1 = b;
    auto benv_2 = benv;
    auto menv_3 = menv;
    auto wx_4 = wx;
    return call_then(crate::lower::node_::def::start_block_into(inner, benv_2, menv_3, b_1), [=](crate::lower::node_::Wx block_into_3333) {
        return ({
            auto done = block_into_3333;
            auto back_ = ({
                crate::lower::node_::Wx this_ = done;
                this_.result = wx_4->result;
                this_;
            });
            (prism_rtl::finished(std::tuple{back_, done->result}));
        });
    });
}


/// `Start InlineBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_inline_block(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Block b, crate::lower::Lx lx) {
    return prism_rtl::make_rc<InlineBlock>(wx, benv, menv, b, lx);
}


/// WidgetCall: unbounded fn Wx, Env, Env, Expr, ?Bn, Text, [Arg], ?Nat -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> widget_call(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Expr& e, const std::optional<crate::lower::types::Bn>& bound_opt, const Text& qk, const Array<crate::syntax::Arg>& args, const std::optional<Nat>& target_opt) {
    auto lx = wx.lx;
    {
        auto&& m3617_0 = qk;
        if (m3617_0 == Text::lit("Prelude.@started")) {
            return started_line(wx, bound_opt);
        }
    }
    {
        auto&& m3617_1 = qk;
        if (m3617_1 == Text::lit("Prelude.@Switch")) {
            return crate::lower::node_::switch_::switch_line(wx, menv, args);
        }
    }
    {
        auto&& m3617_2 = qk;
        if (m3617_2 == Text::lit("Prelude.@Flatten")) {
            return crate::lower::node_::switch_::flatten_line(wx, menv, args, bound_opt);
        }
    }
    {
        auto&& m3617_3 = qk;
        if (m3617_3 == Text::lit("Prelude.@Defer")) {
            return defer_line(wx, menv, args, e, target_opt);
        }
    }
    {
        auto&& m3617_4 = qk;
        if (m3617_4 == Text::lit("Prelude.@Distinct")) {
            return distinct_line(wx, menv, args, e, bound_opt);
        }
    }
    {
        auto&& m3617_5 = qk;
        if (m3617_5 == Text::lit("Prelude.@Run")) {
            return run_line(wx, benv, args, e, target_opt);
        }
    }
    {
        auto&& m3617_6 = qk;
        if (m3617_6 == Text::lit("Prelude.@Machine")) {
            return machine_line(wx, benv, menv, args, e, target_opt);
        }
    }
    {
        auto&& m3617_7 = qk;
        if (m3617_7 == Text::lit("Prelude.@HostDocument")) {
            return host_line(wx, benv, menv, HostForm(HostForm::HostEach{}), args, bound_opt);
        }
    }
    {
        auto&& m3617_8 = qk;
        if (m3617_8 == Text::lit("Prelude.@HostSome")) {
            return host_line(wx, benv, menv, HostForm(HostForm::HostSome{}), args, bound_opt);
        }
    }
    {
        auto&& _m = crate::prelude::get(lx.g.vals, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            return inline_widget(wx, benv, menv, qk, v_, args, e);
        }
        if (prism_rtl::is_none(_m)) {
            auto wx2 = ({
                crate::lower::node_::Wx this_ = wx;
                this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a widget this back end does not lower yet")));
                this_;
            });
            return std::tuple{wx2, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
        }
        prism_rtl::unreachable("no arm matched");
    }
}


/// HostLine: unbounded fn Wx, Env, Env, HostForm, [Arg], ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> host_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const HostForm& form, const Array<crate::syntax::Arg>& args, const std::optional<crate::lower::types::Bn>& bound_opt) {
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto k = len(wx.scopes) + Nat(1u);
    auto hf = prism_rtl::cat("host_", k);
    auto rows_name = prism_rtl::cat(hf, "_rows");
    auto doc_getter = prism_rtl::cat(hf, "_doc");
    auto wx1 = ({
        crate::lower::node_::Wx this_ = wx;
        this_.taken = append(this_.taken, Array(std::vector{hf, rows_name, doc_getter, prism_rtl::cat(doc_getter, "_now"), prism_rtl::cat(doc_getter, "_snap"), prism_rtl::cat(doc_getter, "_direct"), prism_rtl::cat(doc_getter, "_publish"), prism_rtl::cat(hf, "_answer"), prism_rtl::cat(hf, "_moved")}));
        this_;
    });
    auto named_ = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = index(args, Nat(1u));
        if (prism_rtl::is_some(_m)) {
            auto&& sup = prism_rtl::some_of(_m);
            _v.set(is_widget_name(sup->value));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _m = std::tuple{index(args, Nat(0u)), index(args, Nat(1u))};
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        if (named_) {
            auto wx2 = ({
                crate::lower::node_::Wx this_ = wx1;
                this_.pos = crate::lower::model::next_pos(this_.pos);
                this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a named widget function as a host\'s supplier (gap NS): a lambda supplier is lowered, a widget function is not a value")));
                this_;
            });
            return std::tuple{wx2, crate::lower::node_::Wres(crate::lower::node_::Wres::WrHosted{prism_rtl::rc(crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})})})};
        }
    }
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        auto&& child = prism_rtl::some_of(std::get<0>(_m));
        auto&& sup = prism_rtl::some_of(std::get<1>(_m));
        auto [wxd, dyn_env, dyn_lets] = dynamic_answers(wx1, benv, menv, hf, sup->value);
        auto offered = crate::lower::types::own(crate::lower::expr::value_of(lx, dyn_env, sup->value));
        auto supplier0 = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::Ex> _v;
            if (prism_rtl::is<HostForm::HostEach>(form)) {
                _v.set(offered);
                goto _done;
            }
            if (prism_rtl::is<HostForm::HostSome>(form)) {
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::forward_on_none"), Array(std::vector{offered})}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto supplier = len(dyn_lets) == Nat(0u)
            ? supplier0
            : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dyn_lets, prism_rtl::rc(supplier0)});
        auto enclosing = crate::lower::node_::finish::emits(wx, pos)
            ? crate::lower::model::Ex(crate::lower::model::Ex::XNone{})
            : crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::node_::elements::host_local(wx, pos)}))})), crate::lower::types::host_of_ty()})})});
        auto made = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Host::new"), Array(std::vector{crate::lower::node_::finish::place_at(wx, Text::lit(""), pos), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{rows_name}))}), supplier, enclosing, crate::lower::model::Ex(crate::lower::model::Ex::XPath{prism_rtl::cat(wx.node_, "::", doc_getter, "_direct")}), crate::lower::model::Ex(crate::lower::model::Ex::XPath{prism_rtl::cat(wx.node_, "::", hf, "_answer")})})});
        auto host_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Host"), Array(std::vector{crate::lower::types::elem_ty(), crate::lower::types::answer_ty(), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{wx.node_, Array<crate::lower::model::OutTy>{}})})}))});
        auto rows_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Rows"), Array(std::vector{crate::lower::types::elem_ty(), crate::lower::types::answer_ty()})});
        auto doc_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{})), prism_rtl::rc(crate::lower::types::elem_ty())});
        auto what = prism_rtl::cat("the document of the child hosted at place ", crate::lower::model::place_text(pos));
        auto wx2 = ({
            crate::lower::node_::Wx this_ = wxd;
            this_.pos = crate::lower::model::next_pos(this_.pos);
            this_.lets = append(this_.lets, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rows_name})), rows_ty}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Map::new"), Array<crate::lower::model::Ex>{}})})})})})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{hf}), made})}));
            this_.fields = append(this_.fields, Array(std::vector{std::tuple{hf, host_ty, prism_rtl::cat("the host at place ", crate::lower::model::place_text(pos), ": its supplier, its rows, and the way back into its child (pick HO)")}, std::tuple{rows_name, rows_ty, prism_rtl::cat("the rows of the host at place ", crate::lower::model::place_text(pos), ": `for p, e <- $doc`, one supplier blueprint per child place")}, std::tuple{prism_rtl::cat(doc_getter, "_snap"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutSnapshot{prism_rtl::rc(doc_ty)}), prism_rtl::cat("`$doc` of the host at place ", crate::lower::model::place_text(pos), ", a structural dynamic: its snapshots, the structure and the lagged dynamic (pick ST)")}}));
            this_.moves = append(this_.moves, Array(std::vector{std::tuple{hf, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{hf}))})}, std::tuple{rows_name, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{rows_name}))})}}));
            this_.inits = crate::prelude::push(this_.inits, std::tuple{prism_rtl::cat(doc_getter, "_snap"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Snapshot::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{what})})})});
            this_.hosts = crate::prelude::push(this_.hosts, crate::lower::node_::HostDef{.pos = pos, .name = hf, .scope = k});
            this_.snaps = crate::prelude::push(this_.snaps, crate::lower::node_::SnapDef{.name = doc_getter, .live = prism_rtl::cat(doc_getter, "_now"), .ty = doc_ty, .eq = true, .builder = rows_name, .before = true, .what = what});
            this_.getters = append(this_.getters, Array(std::vector{snap_getter(doc_getter, doc_ty, prism_rtl::cat("The document of the child hosted at place ", crate::lower::model::place_text(pos), ", `$doc`, a structural dynamic (pick ST): one tick behind the child\'s structure, the snapshot of the tick before the tick the read point is after.")), crate::lower::model::MethDef{.name = prism_rtl::cat(doc_getter, "_direct"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = doc_ty, .body = Array<crate::lower::model::Do>{}, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(doc_getter, "_snap")})), Text::lit("current"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), .doc = prism_rtl::cat("The structure of the child hosted at place ", crate::lower::model::place_text(pos), ", not the lagged `$doc`: the snapshot taken in this tick\'s construction step, the document as the tick opened during propagation. The host\'s own `for` and its rows\' entries read it, so a newborn child place gets its row in the tick it is born (pick ST).")}}));
            this_.scopes = crate::prelude::push(this_.scopes, hf);
            this_.builders = crate::prelude::push(this_.builders, crate::lower::model::ForDef{.name = rows_name, .pos = pos, .at = crate::lower::node_::finish::place_at(wx, Text::lit("self"), pos), .key_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{}), .value_ty = crate::lower::types::elem_ty(), .row_node = Text::lit("prism_rtl::HostRow::<crate::Elem, crate::Answer>"), .keyed = true, .source = prism_rtl::cat(doc_getter, "_direct"), .parent = crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), hf}))}), .passed = Array<crate::lower::model::Ex>{}});
            this_.build_holds = crate::lower::node_::add_read(this_.build_holds, crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{prism_rtl::cat(doc_getter, "_now")}));
            this_.row_marks = crate::prelude::push(this_.row_marks, crate::lower::node_::RowMarks{.builder = rows_name, .reads = Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{prism_rtl::cat(doc_getter, "_now")})}), .wrote = Array<Text>{}, .kind = crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})});
            this_.fallible = true;
            this_;
        });
        auto inner = ({
            crate::lower::node_::Wx this_ = wx2;
            this_.pos = crate::lower::model::scope_pos(k);
            this_.result = crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{});
            this_;
        });
        auto [done, res] = crate::lower::node_::def::build_line(inner, benv, menv, child->value, std::optional<crate::lower::types::Bn>{});
        auto child_places = drop(done.places, len(wx2.places));
        auto child_builds = filter(done.build_holds, [&](const crate::lower::node_::Read& h) { return !crate::lower::node_::has_read(wx2.build_holds, h); });
        auto child_gens = fold(drop(done.gen_holds, len(wx2.gen_holds)), Array<crate::lower::node_::Read>{}, [&](const Array<crate::lower::node_::Read>& acc, const std::tuple<Text, Array<crate::lower::node_::Read>>& _p1) {
            auto&& hs = std::get<1>(_p1);
            return crate::lower::node_::union_reads(acc, hs);
        });
        auto child_rows = fold(drop(done.row_marks, len(wx2.row_marks)), Array<crate::lower::node_::Read>{}, [&](const Array<crate::lower::node_::Read>& acc, const crate::lower::node_::RowMarks& rm) { return crate::lower::node_::union_reads(acc, rm.reads); });
        auto doc_reads = fold(child_places, crate::lower::node_::union_reads(crate::lower::node_::union_reads(child_builds, child_gens), child_rows), [&](const Array<crate::lower::node_::Read>& acc, const crate::lower::node_::Place& pl) { return crate::lower::node_::union_reads(acc, pl.reads); });
        auto in_scope_fn = ({
            auto k_1 = k;
            (prism_rtl::rc([=](const crate::lower::model::Pos_& p_) { return p_.scope == k_1; }));
        });
        auto getter = host_doc_getter(prism_rtl::cat(doc_getter, "_now"), pos, filter(child_places, [&](const crate::lower::node_::Place& pl) { return in_scope_fn(pl.pos); }), filter(drop(done.builders, len(wx2.builders)), [&](const crate::lower::model::ForDef& b) { return in_scope_fn(b.pos); }), filter(drop(done.gens, len(wx2.gens)), [&](const crate::lower::model::GenDef& gd) { return in_scope_fn(gd.pos); }));
        auto back_ = ({
            crate::lower::node_::Wx this_ = done;
            this_.pos = wx2.pos;
            this_.result = wx->result;
            this_.getters = crate::prelude::push(this_.getters, getter);
            this_.dyn_reads = insert(this_.dyn_reads, prism_rtl::cat(doc_getter, "_now"), doc_reads);
            this_;
        });
        auto doc_bn = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), doc_getter, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{doc_getter})}), doc_ty});
        return std::tuple{back_, crate::lower::node_::Wres(crate::lower::node_::Wres::WrHosted{prism_rtl::rc(res), doc_bn})};
    }
    {
        auto wx2 = ({
            crate::lower::node_::Wx this_ = wx1;
            this_.pos = crate::lower::model::next_pos(this_.pos);
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a host without its child or its supplier")));
            this_;
        });
        return std::tuple{wx2, crate::lower::node_::Wres(crate::lower::node_::Wres::WrHosted{prism_rtl::rc(crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})})})};
    }
}


/// IsWidgetName: fn Expr -> Bool
bool is_widget_name(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix(crate::check::env::sname_key(n), Text::lit("@"));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_widget_name(x);
    }
    {
        return false;
    }
}


/// DynamicAnswers: unbounded fn Wx, Env, Env, Text, Expr -> ((Wx, Env, [Do]))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>> dynamic_answers(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const Text& hf, const crate::syntax::Expr& sup) {
    auto lx = wx.lx;
    auto dyns = fold(crate::check::typed::print::exprs_in(sup), Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>{}, [&](const Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>& acc, const crate::syntax::Expr& x) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>> _v;
            auto&& _m = x.kind;
            if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
                auto&& m13848_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
                auto&& y = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
                if (m13848_0_0 == Text::lit("@")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>> _v;
                        auto&& _m = dynamic_answer(lx, y);
                        if (prism_rtl::is_some(_m)) {
                            auto&& d = prism_rtl::some_of(_m);
                            _v.set(crate::prelude::push(acc, std::tuple{y, d}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(acc);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return len(dyns) == Nat(0u)
        ? std::tuple{wx, benv, Array<crate::lower::model::Do>{}}
        : ({
        auto owner = prism_rtl::cat(hf, "_owner");
        auto wx1 = ({
            crate::lower::node_::Wx this_ = wx;
            this_.taken = crate::prelude::push(this_.taken, owner);
            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{owner}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat("prism_rtl::Link::<", wx.node_, ">::new"), Array<crate::lower::model::Ex>{}})}));
            this_.build = crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{owner})), Text::lit("link"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})})})}));
            this_;
        });
        auto env0 = crate::lower::types::bind(benv, Text::lit("#owner"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{owner}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
        auto lets0 = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{owner}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{owner}))})})});
        run_to_end(fold_job(crate::check::errors::range0(len(dyns)), std::tuple{wx1, env0, lets0}, ({
        auto dyns_1 = dyns;
        auto hf_2 = hf;
        auto menv_3 = menv;
        auto lx_4 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto dyns_1_5 = dyns_1;
            auto hf_2_5 = hf_2;
            auto menv_3_5 = menv_3;
            auto lx_4_5 = lx_4;
            entered(once_job([=]() {
            return ({
                auto [w, en, ls] = p0;
                auto j = p1;
                ({
                auto&& _m = index(dyns_1_5, j);
                prism_rtl::is_some(_m) ? ({
                auto&& y = std::get<0>(prism_rtl::some_of(_m));
                auto&& d = std::get<1>(prism_rtl::some_of(_m));
                ({
                auto name = prism_rtl::cat(hf_2_5, "_dyn_", j + Nat(1u));
                auto port = prism_rtl::cat(name, "_port");
                call_then(crate::lower::node_::dynamics::start_dynamic_expr(w, menv_3_5, d), [=](std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>> dynamic_expr_14760) {
                return ({
                    auto [ex, reads] = dynamic_expr_14760;
                    call_then(crate::lower::types::start_out_ty_of(lx_4_5, crate::lower::types::peel(crate::lower::type_at(lx_4_5, d.span))), [=](crate::lower::model::OutTy out_ty_of_14807) {
                    return ({
                        auto t = out_ty_of_14807;
                        (!crate::lower::node_::def::all_inited(w, reads)
                        ? prism_rtl::finished(std::tuple{w, en, ls})
                        : ({
                        auto w2 = ({
                            crate::lower::node_::Wx this_ = w;
                            this_.taken = append(this_.taken, Array(std::vector{name, port}));
                            this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = name, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t, .body = Array<crate::lower::model::Do>{}, .tail = ex, .doc = prism_rtl::cat("The host at `", hf_2_5, "`\'s dynamic answer `", crate::lower::functions::src_text(lx_4_5, lx_4_5->file, y.span), "`, read at the read point (round 3 DY).")});
                            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{port})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPort{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))}))})}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Port::new"), Array<crate::lower::model::Ex>{}})})})}));
                            this_.fields = crate::prelude::push(this_.fields, std::tuple{port, crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPort{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))}))}), prism_rtl::cat("the dynamic answer `", name, "` moved: its blueprints push the child\'s place next tick")});
                            this_.moves = crate::prelude::push(this_.moves, std::tuple{port, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{port}))})});
                            this_.dyn_answers = crate::prelude::push(this_.dyn_answers, std::tuple{name, reads});
                            this_;
                        });
                        (prism_rtl::finished(std::tuple{w2, crate::lower::types::bind(en, prism_rtl::cat("#dyn", dyn_key(y)), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{name}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t})), crate::prelude::push(ls, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{port}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{port}))})}))}));
                    }));
                    });
                });
                });
            });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{w, en, ls})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
    });
}


/// ?DynamicAnswer: fn Lx, Expr -> ?Expr
std::optional<crate::syntax::Expr> dynamic_answer(const crate::lower::Lx& lx, const crate::syntax::Expr& x) {
    return crate::lower::types::layer_of(crate::lower::type_at(lx, x.span)) != crate::lower::types::Layer(crate::lower::types::Layer::LyDyn{})
        ? std::optional<crate::syntax::Expr>{}
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
        auto&& _m = x.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
            auto&& m16237_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& inner = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            if (m16237_0_0 == Text::lit("$")) {
                _v.set(crate::lower::types::layer_of(crate::lower::type_at(lx, inner.span)) == crate::lower::types::Layer(crate::lower::types::Layer::LyDyn{})
                    ? std::optional(inner)
                    : std::optional<crate::syntax::Expr>{});
                goto _done;
            }
        }
        {
            _v.set(std::optional(x));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// DynKey: fn Expr -> Text
Text dyn_key(const crate::syntax::Expr& x) {
    return prism_rtl::cat(x.span.start, ":", x.span.end);
}


/// HostDocGetter: fn Text, Pos, [Place], [ForDef], [GenDef] -> MethDef
crate::lower::model::MethDef host_doc_getter(const Text& name, const crate::lower::model::Pos_& pos, const Array<crate::lower::node_::Place>& places, const Array<crate::lower::model::ForDef>& builders, const Array<crate::lower::model::GenDef>& gens) {
    auto start = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("doc")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{})), prism_rtl::rc(crate::lower::types::elem_ty())})}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Map::new"), Array<crate::lower::model::Ex>{}})});
    auto body = crate::lower::node_::finish::document_body(({
        auto f = prism_rtl::rc(crate::lower::node_::finish::map_insert);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(std::tuple<crate::lower::model::Ex, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Ex, crate::lower::model::Ex> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0, a1)); });
        });
    })));
    }), places, builders, gens);
    return crate::lower::model::MethDef{.name = name, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{})), prism_rtl::rc(crate::lower::types::elem_ty())}), .body = append(Array(std::vector{start}), body), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("doc")}), .doc = prism_rtl::cat("The document of the child hosted at place ", crate::lower::model::place_text(pos), " computed live: each of its places by its path relative to the child, its level at the read point (pick HO). Read only by the snapshot `$doc` answers from (pick ST).")};
}


/// SnapGetter: fn Text, OutTy, Text -> MethDef
crate::lower::model::MethDef snap_getter(const Text& name, const crate::lower::model::OutTy& t, const Text& doc) {
    return crate::lower::model::MethDef{.name = name, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t, .body = Array<crate::lower::model::Do>{}, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(name, "_snap")})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), .doc = doc};
}


/// StartedLine: fn Wx, ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> started_line(const crate::lower::node_::Wx& wx, const std::optional<crate::lower::types::Bn>& bound_opt) {
    auto wx1 = ({
        crate::lower::node_::Wx this_ = wx;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        this_;
    });
    auto [id, wx2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
            auto&& er = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
            _v.set(std::tuple{er.node_, wx1});
            goto _done;
        }
        {
            _v.set(({
                auto [nm, w] = crate::lower::node_::fresh_name(wx1, Text::lit("started"));
                (crate::lower::node_::add_gn(w, nm, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnStarted{}), Nat(0u)));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto wx3 = ({
        crate::lower::node_::Wx this_ = wx2;
        this_.started = crate::prelude::push(this_.started, id);
        this_;
    });
    return std::tuple{wx3, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of(wx3, id)})};
}


/// DeferLine: unbounded fn Wx, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> defer_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const Array<crate::syntax::Arg>& args, const crate::syntax::Expr& e, const std::optional<Nat>& target_opt) {
    auto lx = wx.lx;
    auto t = crate::lower::types::out_ty_of(lx, crate::lower::types::out_of(crate::lower::type_at(lx, e.span)));
    auto [field_, wx1] = crate::lower::node_::fresh_name(wx, Text::lit("deferred"));
    auto [id, wx2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
        if (prism_rtl::is_some(target_opt)) {
            auto&& n = prism_rtl::some_of(target_opt);
            _v.set(std::tuple{n, wx1});
            goto _done;
        }
        if (prism_rtl::is_none(target_opt)) {
            _v.set(crate::lower::node_::add_gn(wx1, prism_rtl::cat(field_, "_fired"), t, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnDeferred{}), Nat(0u)));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto wx3 = crate::lower::node_::add_field_last(wx2, field_, crate::lower::model::OutTy(crate::lower::model::OutTy::OutDefer{prism_rtl::rc(t)}), Text::lit("`@Defer`"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Defer::new"), Array<crate::lower::model::Ex>{}}));
    auto wx4 = ({
        crate::lower::node_::Wx this_ = wx3;
        this_.defers = crate::prelude::push(this_.defers, std::tuple{field_, id});
        this_;
    });
    auto&& _m = index(args, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& a = prism_rtl::some_of(_m);
        auto [r, wx5] = crate::lower::node_::dynamics::event_ref(wx4, menv, a->value);
        return std::tuple{crate::lower::node_::connect(wx5, r, crate::lower::node_::Sk(crate::lower::node_::Sk::SkArm{field_})), crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of(wx5, id)})};
    }
    if (prism_rtl::is_none(_m)) {
        return std::tuple{wx4, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of(wx4, id)})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// DistinctLine: unbounded fn Wx, Env, [Arg], Expr, ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> distinct_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const Array<crate::syntax::Arg>& args, const crate::syntax::Expr& e, const std::optional<crate::lower::types::Bn>& bound_opt) {
    auto lx = wx.lx;
    auto&& _m = index(args, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        auto wx2 = ({
            crate::lower::node_::Wx this_ = wx;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("an `@Distinct` without its dynamic")));
            this_;
        });
        return std::tuple{wx2, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& a = prism_rtl::some_of(_m);
        auto t = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, a->value.span)));
        auto [name, wx1] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, crate::lower::node_::Wx>> _v;
            if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_opt))) {
                auto&& f = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_opt)).a0;
                _v.set(std::tuple{f, wx});
                goto _done;
            }
            {
                _v.set(crate::lower::node_::fresh_name(wx, Text::lit("distinct")));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto kept = prism_rtl::cat(name, "_kept");
        auto source = prism_rtl::cat(name, "_source");
        auto [ex, reads] = crate::lower::node_::dynamics::dynamic_expr(wx1, menv, a->value);
        auto first_ = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), kept})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), source, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
        auto sample = crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), kept})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Array(std::vector{crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), source, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}}), false, t});
        auto wx2 = ({
            crate::lower::node_::Wx this_ = wx1;
            this_.taken = append(this_.taken, Array(std::vector{kept, source}));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{kept, crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(t)}))}), Text::lit("`@Distinct`\'s value: its source\'s, written only when it changes")});
            this_.moves = crate::prelude::push(this_.moves, std::tuple{kept, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
            this_.build = crate::prelude::push(this_.build, first_);
            this_.getters = append(this_.getters, Array(std::vector{crate::lower::model::MethDef{.name = source, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t, .body = Array<crate::lower::model::Do>{}, .tail = ex, .doc = Text::lit("`@Distinct`\'s source, read at the build.")}, crate::lower::model::MethDef{.name = name, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t, .body = Array<crate::lower::model::Do>{}, .tail = sample, .doc = Text::lit("`@Distinct`\'s dynamic: the value it holds at the read point.")}}));
            this_.dyn_reads = insert(insert(this_.dyn_reads, name, Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{kept})})), source, reads);
            this_;
        });
        auto [r, wx3] = crate::lower::node_::dynamics::updated_event(wx2, menv, args, t);
        return std::tuple{crate::lower::node_::connect(wx3, r, crate::lower::node_::Sk(crate::lower::node_::Sk::SkDistinct{kept})), crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{kept})}), t})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// RunLine: unbounded fn Wx, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> run_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const Array<crate::syntax::Arg>& args, const crate::syntax::Expr& e, const std::optional<Nat>& target_opt) {
    auto lx = wx.lx;
    auto t = crate::lower::types::out_ty_of(lx, crate::lower::types::out_of(crate::lower::type_at(lx, e.span)));
    auto [p_, wx1] = crate::lower::node_::fresh_name(wx, Text::lit("run"));
    auto wx2 = ({
        crate::lower::node_::Wx this_ = wx1;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        this_.taken = append(this_.taken, Array(std::vector{prism_rtl::cat(p_, "_job"), prism_rtl::cat(p_, "_again"), prism_rtl::cat(p_, "_started"), prism_rtl::cat(p_, "_turn")}));
        this_;
    });
    auto start = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        auto&& _m = index(args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::Ex> _v;
                auto&& _m = a->value.kind;
                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                    auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                    _v.set(({
                        auto&& _q_opt = crate::check::env::names::resolve_value(lx.g, lx.home, n);
                        auto&& q_opt = std::get<0>(_q_opt);
                        (crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::expr::start_path(lx, or_(q_opt, Text::lit("")))}));
                    }));
                    goto _done;
                }
                {
                    _v.set(crate::lower::expr::refusal(Text::lit("an `@Run` of a function value that is not a name")));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::expr::refusal(Text::lit("an `@Run` without its function")));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto x = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        auto&& _m = index(args, Nat(1u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(crate::lower::types::own(crate::lower::expr::value_of(lx, benv, a->value)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto wx3 = crate::lower::node_::add_field(wx2, prism_rtl::cat(p_, "_job"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutJob{prism_rtl::rc(t)}))}), Text::lit("`@Run`\'s job (`@Machine`\'s state)"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(start), Array(std::vector{x})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}));
    auto wx4 = crate::lower::node_::add_field_last(wx3, prism_rtl::cat(p_, "_again"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutDefer{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))}), Text::lit("`@Run`\'s `!again`"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Defer::new"), Array<crate::lower::model::Ex>{}}));
    auto [s, wx5] = crate::lower::node_::add_gn(wx4, prism_rtl::cat(p_, "_started"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnStarted{}), Nat(0u));
    auto [a, wx6] = crate::lower::node_::add_gn(wx5, prism_rtl::cat(p_, "_again"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnDeferred{}), Nat(0u));
    auto [m, wx7] = crate::lower::node_::dynamics::merge(wx6, prism_rtl::cat(p_, "_turn"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::node_::ev_ref_of(wx6, s), crate::lower::node_::ev_ref_of(wx6, a));
    auto [res, wx8] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
        if (prism_rtl::is_some(target_opt)) {
            auto&& n = prism_rtl::some_of(target_opt);
            _v.set(std::tuple{n, wx7});
            goto _done;
        }
        if (prism_rtl::is_none(target_opt)) {
            _v.set(crate::lower::node_::add_gn(wx7, prism_rtl::cat(p_, "_done"), t, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNamed{}), Nat(0u)));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto wx9 = ({
        crate::lower::node_::Wx this_ = crate::lower::node_::connect(wx8, crate::lower::node_::ev_ref_of(wx8, m), crate::lower::node_::Sk(crate::lower::node_::Sk::SkCycle{prism_rtl::cat(p_, "_job"), prism_rtl::cat(p_, "_again"), res}));
        this_.started = crate::prelude::push(this_.started, s);
        this_.defers = crate::prelude::push(this_.defers, std::tuple{prism_rtl::cat(p_, "_again"), a});
        this_;
    });
    return std::tuple{wx9, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of(wx9, res)})};
}


/// MachineLine: unbounded fn Wx, Env, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> machine_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const Array<crate::syntax::Arg>& args, const crate::syntax::Expr& e, const std::optional<Nat>& target_opt) {
    auto lx = wx.lx;
    auto t = crate::lower::types::out_ty_of(lx, crate::lower::types::out_of(crate::lower::type_at(lx, e.span)));
    auto [f, wx1] = crate::lower::node_::fresh_name(wx, Text::lit("machine"));
    auto step_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = a->value.kind;
                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                    auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                    _v.set(({
                        auto&& _q_opt = crate::check::env::names::resolve_value(lx.g, lx.home, n);
                        auto&& q_opt = std::get<0>(_q_opt);
                        ({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        if (prism_rtl::is_some(q_opt)) {
                            auto&& q = prism_rtl::some_of(q_opt);
                            _v.set(crate::lower::value_path(lx, q));
                            goto _done;
                        }
                        if (prism_rtl::is_none(q_opt)) {
                            _v.set(Text::lit(""));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                {
                    _v.set(Text::lit(""));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _m = std::tuple{step_, index(args, Nat(1u)), index(args, Nat(2u))};
    if (prism_rtl::is_some(std::get<1>(_m)) && prism_rtl::is_some(std::get<2>(_m))) {
        auto&& sp = std::get<0>(_m);
        auto&& init = prism_rtl::some_of(std::get<1>(_m));
        auto&& ev = prism_rtl::some_of(std::get<2>(_m));
        if (sp != Text::lit("")) {
            auto st = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, init->value.span)));
            auto x = crate::lower::types::own(crate::lower::expr::value_of(lx, benv, init->value));
            auto wx2 = crate::lower::node_::add_field(wx1, prism_rtl::cat(f, "_state"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(st)}), Text::lit("`@Machine`\'s state"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{x, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}));
            auto [out, wx3] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
                if (prism_rtl::is_some(target_opt)) {
                    auto&& n = prism_rtl::some_of(target_opt);
                    _v.set(std::tuple{n, wx2});
                    goto _done;
                }
                if (prism_rtl::is_none(target_opt)) {
                    _v.set(crate::lower::node_::add_gn(wx2, prism_rtl::cat(f, "_fired"), t, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNamed{}), Nat(0u)));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto [r, wx4] = crate::lower::node_::dynamics::event_ref(wx3, menv, ev->value);
            return std::tuple{crate::lower::node_::connect(wx4, r, crate::lower::node_::Sk(crate::lower::node_::Sk::SkMachine{prism_rtl::cat(f, "_state"), sp, out})), crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of(wx4, out)})};
        }
    }
    {
        auto wx2 = ({
            crate::lower::node_::Wx this_ = wx1;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("an `@Machine` whose step is not a named function")));
            this_;
        });
        return std::tuple{wx2, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    }
}


/// InlineWidget: unbounded fn Wx, Env, Env, Text, ValInfo, [Arg], Expr -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> inline_widget(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const Text& qk, const crate::check::env::ValInfo& v_, const Array<crate::syntax::Arg>& args, const crate::syntax::Expr& e) {
    auto lx = wx.lx;
    auto clauses = crate::lower::jobs::clauses_of(lx.g, qk);
    auto w_opt = widget_decl_of(lx.g, qk);
    auto [params, body_opt] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::syntax::Pattern_>, std::optional<crate::syntax::Block>>> _v;
        if (prism_rtl::is_some(w_opt)) {
            auto&& wd = prism_rtl::some_of(w_opt);
            _v.set(std::tuple{Array<crate::syntax::Pattern_>{}, std::optional(wd.body)});
            goto _done;
        }
        if (prism_rtl::is_none(w_opt)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::syntax::Pattern_>, std::optional<crate::syntax::Block>>> _v;
                {
                    auto&& m25904_0 = clauses;
                    if (m25904_0.size() == 1u) {
                        {
                            auto&& _c1 = index(m25904_0, Nat(0u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& c = prism_rtl::some_of(_c1);
                                _v.set(({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<Array<crate::syntax::Pattern_>, std::optional<crate::syntax::Block>>> _v;
                                    auto&& _m = c.body;
                                    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m)) {
                                        auto&& b = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
                                        _v.set(std::tuple{c.params, std::optional(b)});
                                        goto _done;
                                    }
                                    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(_m)) {
                                        auto&& x = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(_m).a0;
                                        _v.set(std::tuple{c.params, std::optional(crate::syntax::Block{.stmts = Array(std::vector{crate::syntax::Stmt{.kind = crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{x}), .span = x.span}}), .inline_ = true, .span = x.span})});
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                }));
                                goto _done;
                            }
                        }
                    }
                }
                {
                    _v.set(std::tuple{Array<crate::syntax::Pattern_>{}, std::optional<crate::syntax::Block>{}});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is_none(body_opt)) {
        return len(clauses) == Nat(0u)
            ? ({
            auto wx2 = ({
                crate::lower::node_::Wx this_ = wx;
                this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(prism_rtl::cat("the builtin widget ", crate::check::types::bare_name(qk))));
                this_;
            });
            std::tuple{wx2, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
        })
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> _v;
            auto&& _m = index(args, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& a = prism_rtl::some_of(_m);
                _v.set(({
                    auto call = crate::syntax::Block{.stmts = Array(std::vector{crate::syntax::Stmt{.kind = crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e}), .span = e.span}}), .inline_ = true, .span = e.span};
                    (crate::lower::node_::switch_::clause_widget_line(wx, menv, a->value, call, qk, v_, e));
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    auto wx2 = ({
                        crate::lower::node_::Wx this_ = wx;
                        this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a widget of several clauses that takes no arguments")));
                        this_;
                    });
                    std::tuple{wx2, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_some(body_opt)) {
        auto&& body = prism_rtl::some_of(body_opt);
        return wx.depth > Nat(16u)
            ? std::tuple{wx, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})}
            : ({
            auto lxc = crate::lower::program::in_module_at(lx, v_->file, v_.home, lx.site);
            auto ptys = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
                auto&& _m = v_.scheme.ty;
                if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                    auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
                    _v.set(ps);
                    goto _done;
                }
                {
                    _v.set(Array<crate::check::types::Ty>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [wx1, be1, me1] = run_to_end(fold_job(crate::check::errors::range0(len(params)), std::tuple{wx, crate::lower::types::empty_env(), crate::lower::types::empty_env()}, ({
                auto params_1 = params;
                auto lxc_2 = lxc;
                auto ptys_3 = ptys;
                auto args_4 = args;
                auto benv_5 = benv;
                auto menv_6 = menv;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto params_1_7 = params_1;
                    auto lxc_2_7 = lxc_2;
                    auto ptys_3_7 = ptys_3;
                    auto args_4_7 = args_4;
                    auto benv_5_7 = benv_5;
                    auto menv_6_7 = menv_6;
                    entered(once_job([=]() {
                    return ({
                        auto [w, be, me] = p0;
                        auto i = p1;
                        ({
                        auto p_ = or_(index(params_1_7, i), crate::lower::patterns::dummy_pat());
                        auto nkey = crate::lower::functions::plain_binder(lxc_2_7, p_);
                        auto pty = or_(index(ptys_3_7, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                        ({
                        auto&& _m = index(args_4_7, i);
                        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{w, be, me})
                        : prism_rtl::is_some(_m) ? ({
                        auto&& a = prism_rtl::some_of(_m);
                        prism_rtl::finished(bind_param(w, benv_5_7, menv_6_7, be, me, nkey, pty, a->value));
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                    });
                }));
                });
            }));
            })));
            auto inner = ({
                crate::lower::node_::Wx this_ = wx1;
                this_.lx = lxc;
                this_.depth = this_.depth + Nat(1u);
                this_.result = crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{});
                this_;
            });
            auto done = crate::lower::node_::def::block_into(inner, be1, me1, body);
            auto back_ = ({
                crate::lower::node_::Wx this_ = done;
                this_.lx = lx;
                this_.depth = wx.depth;
                this_.result = wx->result;
                this_;
            });
            std::tuple{back_, done->result};
        });
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?WidgetDeclOf: fn G, Text -> ?WidgetDecl
std::optional<crate::syntax::decls::WidgetDecl> widget_decl_of(const crate::check::env::G& g, const Text& qk) {
    return fold(g.defs, std::optional<crate::syntax::decls::WidgetDecl>{}, [&](const std::optional<crate::syntax::decls::WidgetDecl>& found_opt, const crate::check::env::Def& d) { return d.qk == qk ? def_widget(d, found_opt) : found_opt; });
}


/// ?DefWidget: fn Def, ?WidgetDecl -> ?WidgetDecl
std::optional<crate::syntax::decls::WidgetDecl> def_widget(const crate::check::env::Def& d, const std::optional<crate::syntax::decls::WidgetDecl>& other_opt) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
        auto&& w = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
        return std::optional(w);
    }
    {
        return other_opt;
    }
}


/// BindParam: unbounded fn Wx, Env, Env, Env, Env, Text, Ty, Expr -> ((Wx, Env, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> bind_param(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& cbenv, const crate::lower::types::Env& cmenv, const crate::lower::types::Env& be, const crate::lower::types::Env& me, const Text& nkey, const crate::check::types::Ty& pty, const crate::syntax::Expr& arg) {
    auto lx = wx.lx;
    auto t = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(pty));
    auto&& _m = crate::lower::types::layer_of(pty);
    if (prism_rtl::is<crate::lower::types::Layer::LyBlueprint>(_m)) {
        auto b = crate::lower::types::Bn(crate::lower::types::Bn::BnWidget{arg, cbenv, cmenv, lx});
        return std::tuple{wx, crate::lower::types::bind(be, nkey, b), crate::lower::types::bind(me, nkey, b)};
    }
    if (prism_rtl::is<crate::lower::types::Layer::LyEv>(_m)) {
        auto [r, wx2] = crate::lower::node_::dynamics::event_ref(wx, cmenv, arg);
        auto b = crate::lower::types::Bn(crate::lower::types::Bn::BnEv{r, t});
        return std::tuple{wx2, crate::lower::types::bind(be, nkey, b), crate::lower::types::bind(me, nkey, b)};
    }
    if (prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m)) {
        auto [ex, reads] = crate::lower::node_::dynamics::dynamic_expr(wx, cmenv, arg);
        auto b = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{ex, reads, t});
        return std::tuple{wx, crate::lower::types::bind(be, nkey, b), crate::lower::types::bind(me, nkey, b)};
    }
    {
        auto [rs, wx2] = crate::lower::node_::fresh_name(wx, crate::lower::snake(nkey));
        auto v_ = crate::lower::types::own(crate::lower::expr::value_of(lx, cbenv, arg));
        auto wx3 = ({
            crate::lower::node_::Wx this_ = wx2;
            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs}), v_}));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{rs, t, prism_rtl::cat("`", nkey, "`")});
            this_.inits = crate::prelude::push(this_.inits, std::tuple{rs, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}))})});
            this_;
        });
        auto [be2, me2] = crate::lower::node_::bind_plain(be, me, nkey, rs, t);
        return std::tuple{wx3, be2, me2};
    }
}

}  // namespace crate::lower::node_::static_
