// The module `Lower.Jobs`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/jobs/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Lower.Jobs`, from `target/bootstrap/cpp-src/prismc/lower/jobs.prism`.
namespace crate::lower::jobs {

/// Tail: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex tail_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = frame_call_o(lx_p0, env_p1, e_p2, true);
    if (prism_rtl::is_some(_m)) {
        auto&& c_p3 = prism_rtl::some_of(_m);
        return frame_f(lx_p0, env_p1, c_p3, rest_text_f(lx_p0, e_p2.span_p, prism_rtl::deref(c_p3).span_p, e_p2.span_p), ({
            auto lx_p0x = lx_p0;
            auto e_p2x = e_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), e_p2x = std::move(e_p2x)](crate::lower::types::Env p0) {
            return ({
                auto lx_p0xy = lx_p0x;
                auto e_p2xy = e_p2x;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), e_p2xy = std::move(e_p2xy)]() {
                return ({
                    auto env2_p4 = p0;
                    (prism_rtl::more(prism_rtl::rc(Tail(lx_p0xy, env2_p4, e_p2xy))));
                });
            })));
            });
        })));
        }));
    }
    if (prism_rtl::is_none(_m)) {
        return tail_here_f(lx_p0, env_p1, e_p2);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Ex> Tail::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    auto e_p2x = e_p2;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    return crate::prelude::call_then(start_frame_call_o(lx_p0x, env_p1x, e_p2x, true), [=](std::optional<crate::syntax::Expr> frame_call_o_1854) {
        return ({
            prism_rtl::is_some(frame_call_o_1854) ? ({
            auto&& c_p3 = prism_rtl::some_of(frame_call_o_1854);
            prism_rtl::more(prism_rtl::rc(Frame(lx_p0x, env_p1x, c_p3, rest_text_f(lx_p0x, prism_rtl::deref(e_p2x).span_p, prism_rtl::deref(c_p3).span_p, prism_rtl::deref(e_p2x).span_p), ({
            auto lx_p0xx = lx_p0x;
            auto e_p2xx = e_p2x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), e_p2xx = std::move(e_p2xx)](crate::lower::types::Env p0) {
            return ({
                auto lx_p0xxy = lx_p0xx;
                auto e_p2xxy = e_p2xx;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), e_p2xxy = std::move(e_p2xxy)]() {
                return ({
                    auto env2_p4 = p0;
                    (prism_rtl::more(prism_rtl::rc(Tail(lx_p0xxy, env2_p4, e_p2xxy))));
                });
            })));
            });
        })));
        }))));
        })
            : prism_rtl::is_none(frame_call_o_1854) ? prism_rtl::more(prism_rtl::rc(TailHere(lx_p0x, env_p1x, e_p2x)))
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start Tail, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_tail_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<Tail>(lx_p0, env_p1, e_p2);
}


/// TailHere: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex tail_here_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = prism_rtl::deref(e_p2.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p3 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return tail_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p3)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
        auto&& target_p4 = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& b_p5 = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        return has_top_while_f(lx_p0, b_p5)
            ? upd_tail_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(target_p4)), b_p5, e_p2.span_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::once_job([=]() {
                return ({
                    auto en_p6 = p0;
                    auto v_p7 = p1;
                    (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{v_p7})})));
                });
            });
        })))
            : crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{crate::lower::types::own_f(crate::lower::expr::value_of_f(lx_p0, env_p1, e_p2))})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& s_p8 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p9 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return tail_match_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(s_p8)), arms_p9, e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2)) {
        auto&& m2072_3_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_pb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_pc = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(prism_rtl::deref(prism_rtl::deref(m2072_3_0)))) {
            auto&& c_pa = prism_rtl::as<crate::syntax::Cond::CondExpr>(prism_rtl::deref(prism_rtl::deref(m2072_3_0))).a0;
            return crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(crate::lower::types::as_bool_f(crate::lower::expr::value_of_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(c_pa))))), prism_rtl::rc(tail_block_f(lx_p0, env_p1, then_b_pb)), prism_rtl::rc(tail_block_f(lx_p0, env_p1, else_b_pc))});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& callee_pd = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_pe = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        auto&& _m = tail_callee_o(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(callee_pd)));
        if (prism_rtl::is_some(_m)) {
            auto&& qk_pf = prism_rtl::some_of(_m);
            auto job_pg = crate::prelude::or_(crate::prelude::get(lx_p0.rs_names_p, qk_pf), crate::lower::snake_f(crate::check::types::bare_name_f(qk_pf)));
            auto job_name_ph = crate::lower::path_in_f(lx_p0, crate::lower::owner_of_f(qk_pf), crate::lower::camel_f(crate::check::types::bare_name_f(qk_pf)));
            auto&& _ptys_pk = scheme_parts_f(lx_p0, qk_pf);
            auto&& ptys_pk = std::get<0>(_ptys_pk);
            auto fields_pi = job_field_names_f(lx_p0, qk_pf);
            auto vals_pj = crate::lower::expr::named_args_owned_f(lx_p0, env_p1, qk_pf, args_pe);
            return crate::lower::program::enters_at_once_f(lx_p0, qk_pf, args_pe)
                ? crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::path_in_f(lx_p0, crate::lower::owner_of_f(qk_pf), prism_rtl::cat("start_", job_pg)), vals_pj})), Text::lit("cycle"), Array<crate::lower::model::Ex>{}})
                : crate::lower::program::is_color_poly_f(lx_p0, qk_pf)
                ? crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::More"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::path_in_f(lx_p0, crate::lower::owner_of_f(qk_pf), prism_rtl::cat("start_", job_pg)), vals_pj})})})
                : crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::More"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{job_name_ph, crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(vals_pj)), [&](const Nat& i_pl) { return std::tuple{crate::prelude::or_(crate::prelude::index(fields_pi, i_pl), Text::lit("arg")), crate::prelude::or_(crate::prelude::index(vals_pj, i_pl), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))}; })})})})})});
        }
        if (prism_rtl::is_none(_m)) {
            auto&& _m = local_job_fn_o(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(callee_pd)));
            if (prism_rtl::is_some(_m)) {
                auto&& f_pm = prism_rtl::some_of(_m);
                return crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(start_call_f(f_pm, crate::lower::expr::start_args_f(lx_p0, env_p1, f_pm, args_pe))), Text::lit("cycle"), Array<crate::lower::model::Ex>{}});
            }
            if (prism_rtl::is_none(_m)) {
                auto&& _m = crate::lower::expr::prelude_job_call_o(lx_p0, env_p1, e_p2);
                if (prism_rtl::is_some(_m)) {
                    auto&& job_pn = prism_rtl::some_of(_m);
                    return crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(job_pn), Text::lit("cycle"), Array<crate::lower::model::Ex>{}});
                }
                if (prism_rtl::is_none(_m)) {
                    return crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{crate::lower::types::own_f(crate::lower::expr::value_of_f(lx_p0, env_p1, e_p2))})});
                }
                prism_rtl::unreachable("no arm matched");
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{crate::lower::types::own_f(crate::lower::expr::value_of_f(lx_p0, env_p1, e_p2))})});
    }
}


prism_rtl::Turn<crate::lower::model::Ex> TailHere::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p3 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Tail(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p3)))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m) ? ({
        auto&& target_p4 = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& b_p5 = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        has_top_while_f(lx_p0, b_p5)
        ? prism_rtl::more(prism_rtl::rc(UpdTail(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(target_p4)), b_p5, prism_rtl::deref(e_p2).span_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::once_job([=]() {
            return ({
                auto en_p6 = p0;
                auto v_p7 = p1;
                (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{v_p7})})));
            });
        });
    })))))
        : ({
        auto e_p2x = e_p2;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p1x, e_p2x), [=](crate::lower::types::Vl value_of_f_2311) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{crate::lower::types::own_f(value_of_f_2311)})})); }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& s_p8 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p9 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        prism_rtl::more(prism_rtl::rc(TailMatch(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(s_p8)), arms_p9, prism_rtl::deref(e_p2).span_p)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2) && ({
        auto&& m2072_3_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_pb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_pc = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        prism_rtl::is<crate::syntax::Cond::CondExpr>(prism_rtl::deref(prism_rtl::deref(m2072_3_0)));
    }) ? ({
        auto&& m2072_3_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_pb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_pc = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        auto&& c_pa = prism_rtl::as<crate::syntax::Cond::CondExpr>(prism_rtl::deref(prism_rtl::deref(m2072_3_0))).a0;
        ({
        auto c_pax = prism_rtl::deref(prism_rtl::deref(c_pa));
        auto else_b_pcx = else_b_pc;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto then_b_pbx = then_b_pb;
        (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p1x, c_pax), [=, else_b_pcx = std::move(else_b_pcx), then_b_pbx = std::move(then_b_pbx)](crate::lower::types::Vl value_of_f_2441) { return crate::prelude::call_then(start_tail_block_f(lx_p0x, env_p1x, then_b_pbx), [=](crate::lower::model::Ex tail_block_f_2464) { return crate::prelude::call_then(start_tail_block_f(lx_p0x, env_p1x, else_b_pcx), [=](crate::lower::model::Ex tail_block_f_2492) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(crate::lower::types::as_bool_f(value_of_f_2441)), prism_rtl::rc(tail_block_f_2464), prism_rtl::rc(tail_block_f_2492)})); }); }); }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& callee_pd = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_pe = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        ({
        auto&& _m = tail_callee_o(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(callee_pd)));
        prism_rtl::is_some(_m) ? ({
        auto&& qk_pf = prism_rtl::some_of(_m);
        ({
        auto job_pg = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0).rs_names_p, qk_pf), crate::lower::snake_f(crate::check::types::bare_name_f(qk_pf)));
        auto job_name_ph = crate::lower::path_in_f(lx_p0, crate::lower::owner_of_f(qk_pf), crate::lower::camel_f(crate::check::types::bare_name_f(qk_pf)));
        auto&& _ptys_pk = scheme_parts_f(lx_p0, qk_pf);
        auto&& ptys_pk = std::get<0>(_ptys_pk);
        auto args_pex = args_pe;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(start_job_field_names_f(lx_p0x, qk_pf), [=, job_pg = std::move(job_pg), job_name_ph = std::move(job_name_ph), args_pex = std::move(args_pex), env_p1x = std::move(env_p1x)](Array<Text> job_field_names_f_2822) {
        return ({
            auto fields_pi = job_field_names_f_2822;
            (crate::prelude::call_then(crate::lower::expr::start_named_args_owned_f(lx_p0x, env_p1x, qk_pf, args_pex), [=, fields_pi = std::move(fields_pi)](Array<crate::lower::model::Ex> named_args_owned_f_2866) {
            return ({
                auto vals_pj = named_args_owned_f_2866;
                (crate::lower::program::enters_at_once_f(lx_p0x, qk_pf, args_pex)
                ? prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::path_in_f(lx_p0x, crate::lower::owner_of_f(qk_pf), prism_rtl::cat("start_", job_pg)), vals_pj})), Text::lit("cycle"), Array<crate::lower::model::Ex>{}}))
                : crate::lower::program::is_color_poly_f(lx_p0x, qk_pf)
                ? prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::More"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::path_in_f(lx_p0x, crate::lower::owner_of_f(qk_pf), prism_rtl::cat("start_", job_pg)), vals_pj})})}))
                : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::More"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{job_name_ph, crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(vals_pj)), [&](const Nat& i_pl) { return std::tuple{crate::prelude::or_(crate::prelude::index(fields_pi, i_pl), Text::lit("arg")), crate::prelude::or_(crate::prelude::index(vals_pj, i_pl), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))}; })})})})})})));
            });
        }));
        });
    }));
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto args_pex = args_pe;
        auto callee_pdx = prism_rtl::deref(prism_rtl::deref(callee_pd));
        auto e_p2x = e_p2;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(start_local_job_fn_o(lx_p0x, env_p1x, callee_pdx), [=, args_pex = std::move(args_pex), e_p2x = std::move(e_p2x)](std::optional<crate::lower::types::Vl> local_job_fn_o_3346) {
        return ({
            prism_rtl::is_some(local_job_fn_o_3346) ? ({
            auto&& f_pm = prism_rtl::some_of(local_job_fn_o_3346);
            crate::prelude::call_then(crate::lower::expr::start_start_args_f(lx_p0x, env_p1x, f_pm, args_pex), [=](Array<crate::lower::model::Ex> start_args_f_3415) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(start_call_f(f_pm, start_args_f_3415)), Text::lit("cycle"), Array<crate::lower::model::Ex>{}})); });
        })
            : prism_rtl::is_none(local_job_fn_o_3346) ? crate::prelude::call_then(crate::lower::expr::start_prelude_job_call_o(lx_p0x, env_p1x, e_p2x), [=](std::optional<crate::lower::model::Ex> prelude_job_call_o_3482) {
            return ({
                prism_rtl::is_some(prelude_job_call_o_3482) ? ({
                auto&& job_pn = prism_rtl::some_of(prelude_job_call_o_3482);
                prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(job_pn), Text::lit("cycle"), Array<crate::lower::model::Ex>{}}));
            })
                : prism_rtl::is_none(prelude_job_call_o_3482) ? crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p1x, e_p2x), [=](crate::lower::types::Vl value_of_f_3623) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{crate::lower::types::own_f(value_of_f_3623)})})); })
                : throw prism_rtl::Panic("no arm matched");
            });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    }));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : ({
        auto e_p2x = e_p2;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p1x, e_p2x), [=](crate::lower::types::Vl value_of_f_3702) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{crate::lower::types::own_f(value_of_f_3702)})})); }));
    });
    });
}


/// `Start TailHere, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_tail_here_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<TailHere>(lx_p0, env_p1, e_p2);
}


/// TailBlock: unbounded fn Lx, Env, Block -> Ex
crate::lower::model::Ex tail_block_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Block& b_p2) {
    return tail_from_f(lx_p0, env_p1, b_p2, Nat(0u));
}


prism_rtl::Turn<crate::lower::model::Ex> TailBlock::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& b_p2 = this->b_p2;
    return prism_rtl::more(prism_rtl::rc(TailFrom(lx_p0, env_p1, b_p2, Nat(0u))));
}


/// `Start TailBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_tail_block_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Block b_p2) {
    return prism_rtl::make_rc<TailBlock>(lx_p0, env_p1, b_p2);
}


/// TailFrom: unbounded fn Lx, Env, Block, Nat -> Ex
crate::lower::model::Ex tail_from_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Block& b_p2, const Nat& i_p3) {
    auto s_p4 = crate::prelude::or_(crate::prelude::index(b_p2.stmts_p, i_p3), crate::lower::expr::dummy_stmt_l_p());
    return (i_p3 + Nat(1u)) >= crate::prelude::len(b_p2.stmts_p)
        ? ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        auto&& _m = prism_rtl::deref(s_p4).kind_p;
        if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
            auto&& x_p5 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
            _v.set(tail_f(lx_p0, env_p1, x_p5));
            goto _done;
        }
        {
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})}));
            goto _done;
        }
    _done:
        _v.take();
    })
        : ({
        auto found_o6 = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
            auto&& _m = prism_rtl::deref(s_p4).kind_p;
            if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                auto&& x_p8 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                _v.set(frame_call_o(lx_p0, env_p1, x_p8, false));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
                auto&& x_p9 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                _v.set(frame_call_o(lx_p0, env_p1, x_p9, false));
                goto _done;
            }
            {
                _v.set(std::optional<crate::syntax::Expr>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto looping_o7 = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>> _v;
            auto&& _m = prism_rtl::deref(s_p4).kind_p;
            if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                auto&& p_pa = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                auto&& x_pb = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>> _v;
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(x_pb).kind_p);
                    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
                        auto&& target_pc = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
                        auto&& ub_pd = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
                        _v.set(has_top_while_f(lx_p0, ub_pd)
                            ? std::optional(std::tuple{p_pa, prism_rtl::deref(prism_rtl::deref(target_pc)), ub_pd, x_pb})
                            : std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>{});
                        goto _done;
                    }
                    {
                        _v.set(std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is_some(looping_o7)) {
            auto&& p_pe = std::get<0>(prism_rtl::some_of(looping_o7));
            auto&& target_pf = std::get<1>(prism_rtl::some_of(looping_o7));
            auto&& ub_pg = std::get<2>(prism_rtl::some_of(looping_o7));
            auto&& x_ph = std::get<3>(prism_rtl::some_of(looping_o7));
            _v.set(upd_tail_f(lx_p0, env_p1, target_pf, ub_pg, b_p2.span_p, ({
                auto lx_p0x = lx_p0;
                auto p_pex = p_pe;
                auto x_phx = x_ph;
                auto s_p4x = s_p4;
                auto b_p2x = b_p2;
                auto i_p3x = i_p3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), p_pex = std::move(p_pex), x_phx = std::move(x_phx), s_p4x = std::move(s_p4x), b_p2x = std::move(b_p2x), i_p3x = std::move(i_p3x)](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_p0xy = lx_p0x;
                    auto p_pexy = p_pex;
                    auto x_phxy = x_phx;
                    auto s_p4xy = s_p4x;
                    auto b_p2xy = b_p2x;
                    auto i_p3xy = i_p3x;
                    (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), p_pexy = std::move(p_pexy), x_phxy = std::move(x_phxy), s_p4xy = std::move(s_p4xy), b_p2xy = std::move(b_p2xy), i_p3xy = std::move(i_p3xy)]() {
                    return ({
                        auto en_pi = p0;
                        auto v_pj = p1;
                        (crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0xy, p_pexy, crate::lower::type_at_f(lx_p0xy, prism_rtl::deref(x_phxy).span_p), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("l", prism_rtl::deref(prism_rtl::deref(s_p4xy).span_p).start_p)), [=, en_pi = std::move(en_pi), v_pj = std::move(v_pj)](crate::lower::patterns::PatOut rust_pat_f_4825) {
                        return ({
                            auto po_pk = rust_pat_f_4825;
                            (crate::prelude::call_then(start_tail_from_f(lx_p0xy, crate::lower::expr::bind_all_f(en_pi, prism_rtl::deref(po_pk).binds_p), b_p2xy, i_p3xy + Nat(1u)), [=](crate::lower::model::Ex tail_from_f_4917) {
                            return ({
                                auto rest_pl = tail_from_f_4917;
                                (prism_rtl::finished(prepend_f(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(po_pk).pa_p, v_pj})}), rest_pl)));
                            });
                        }));
                        });
                    }));
                    });
                })));
                });
            })));
            })));
            goto _done;
        }
        if (prism_rtl::is_none(looping_o7)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::Ex> _v;
                if (prism_rtl::is_some(found_o6)) {
                    auto&& c_pm = prism_rtl::some_of(found_o6);
                    _v.set(frame_f(lx_p0, env_p1, c_pm, rest_text_f(lx_p0, prism_rtl::deref(s_p4).span_p, prism_rtl::deref(c_pm).span_p, b_p2.span_p), ({
                        auto lx_p0x = lx_p0;
                        auto b_p2x = b_p2;
                        auto i_p3x = i_p3;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), b_p2x = std::move(b_p2x), i_p3x = std::move(i_p3x)](crate::lower::types::Env p0) {
                        return ({
                            auto lx_p0xy = lx_p0x;
                            auto b_p2xy = b_p2x;
                            auto i_p3xy = i_p3x;
                            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), b_p2xy = std::move(b_p2xy), i_p3xy = std::move(i_p3xy)]() {
                            return ({
                                auto env2_pn = p0;
                                (prism_rtl::more(prism_rtl::rc(TailFrom(lx_p0xy, env2_pn, b_p2xy, i_p3xy))));
                            });
                        })));
                        });
                    })));
                    })));
                    goto _done;
                }
                if (prism_rtl::is_none(found_o6)) {
                    _v.set(({
                        auto [dos_po, env2_pp] = crate::lower::expr::block_stmt_f(lx_p0, env_p1, s_p4);
                        ({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::model::Ex> _v;
                        auto&& _m = tail_from_f(lx_p0, env2_pp, b_p2, i_p3 + Nat(1u));
                        if (prism_rtl::is<crate::lower::model::Ex::XBlock>(_m)) {
                            auto&& more_pq = prism_rtl::as<crate::lower::model::Ex::XBlock>(_m).a0;
                            auto&& last_pr = prism_rtl::as<crate::lower::model::Ex::XBlock>(_m).a1;
                            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{crate::prelude::append(dos_po, more_pq), prism_rtl::rc(prism_rtl::deref(last_pr))}));
                            goto _done;
                        }
                        {
                            auto&& last_ps = _m;
                            _v.set(crate::prelude::len(dos_po) == Nat(0u)
                                ? last_ps
                                : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_po, prism_rtl::rc(last_ps)}));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<crate::lower::model::Ex> TailFrom::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& b_p2 = this->b_p2;
    const auto& i_p3 = this->i_p3;
    auto s_p4 = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(b_p2).stmts_p, i_p3), crate::lower::expr::dummy_stmt_l_p());
    return (i_p3 + Nat(1u)) >= crate::prelude::len(prism_rtl::deref(b_p2).stmts_p)
        ? ({
        auto&& _m = prism_rtl::deref(s_p4).kind_p;
        prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& x_p5 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Tail(lx_p0, env_p1, x_p5)));
    })
        : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})}));
    })
        : ({
        auto found_o6 = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
            auto&& _m = prism_rtl::deref(s_p4).kind_p;
            if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                auto&& x_p8 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                _v.set(frame_call_o(lx_p0, env_p1, x_p8, false));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
                auto&& x_p9 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                _v.set(frame_call_o(lx_p0, env_p1, x_p9, false));
                goto _done;
            }
            {
                _v.set(std::optional<crate::syntax::Expr>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto looping_o7 = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>> _v;
            auto&& _m = prism_rtl::deref(s_p4).kind_p;
            if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                auto&& p_pa = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                auto&& x_pb = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>> _v;
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(x_pb).kind_p);
                    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
                        auto&& target_pc = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
                        auto&& ub_pd = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
                        _v.set(has_top_while_f(lx_p0, ub_pd)
                            ? std::optional(std::tuple{p_pa, prism_rtl::deref(prism_rtl::deref(target_pc)), ub_pd, x_pb})
                            : std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>{});
                        goto _done;
                    }
                    {
                        _v.set(std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        prism_rtl::is_some(looping_o7) ? ({
        auto&& p_pe = std::get<0>(prism_rtl::some_of(looping_o7));
        auto&& target_pf = std::get<1>(prism_rtl::some_of(looping_o7));
        auto&& ub_pg = std::get<2>(prism_rtl::some_of(looping_o7));
        auto&& x_ph = std::get<3>(prism_rtl::some_of(looping_o7));
        prism_rtl::more(prism_rtl::rc(UpdTail(lx_p0, env_p1, target_pf, ub_pg, prism_rtl::deref(b_p2).span_p, ({
        auto lx_p0x = lx_p0;
        auto p_pex = p_pe;
        auto x_phx = x_ph;
        auto s_p4x = s_p4;
        auto b_p2x = b_p2;
        auto i_p3x = i_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), p_pex = std::move(p_pex), x_phx = std::move(x_phx), s_p4x = std::move(s_p4x), b_p2x = std::move(b_p2x), i_p3x = std::move(i_p3x)](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            auto p_pexy = p_pex;
            auto x_phxy = x_phx;
            auto s_p4xy = s_p4x;
            auto b_p2xy = b_p2x;
            auto i_p3xy = i_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), p_pexy = std::move(p_pexy), x_phxy = std::move(x_phxy), s_p4xy = std::move(s_p4xy), b_p2xy = std::move(b_p2xy), i_p3xy = std::move(i_p3xy)]() {
            return ({
                auto en_pi = p0;
                auto v_pj = p1;
                (crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0xy, p_pexy, crate::lower::type_at_f(lx_p0xy, prism_rtl::deref(x_phxy).span_p), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("l", prism_rtl::deref(prism_rtl::deref(s_p4xy).span_p).start_p)), [=, en_pi = std::move(en_pi), v_pj = std::move(v_pj)](crate::lower::patterns::PatOut rust_pat_f_4825) {
                return ({
                    auto po_pk = rust_pat_f_4825;
                    (crate::prelude::call_then(start_tail_from_f(lx_p0xy, crate::lower::expr::bind_all_f(en_pi, prism_rtl::deref(po_pk).binds_p), b_p2xy, i_p3xy + Nat(1u)), [=](crate::lower::model::Ex tail_from_f_4917) {
                    return ({
                        auto rest_pl = tail_from_f_4917;
                        (prism_rtl::finished(prepend_f(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(po_pk).pa_p, v_pj})}), rest_pl)));
                    });
                }));
                });
            }));
            });
        })));
        });
    })));
    }))));
    })
        : prism_rtl::is_none(looping_o7) ? ({
        prism_rtl::is_some(found_o6) ? ({
        auto&& c_pm = prism_rtl::some_of(found_o6);
        prism_rtl::more(prism_rtl::rc(Frame(lx_p0, env_p1, c_pm, rest_text_f(lx_p0, prism_rtl::deref(s_p4).span_p, prism_rtl::deref(c_pm).span_p, prism_rtl::deref(b_p2).span_p), ({
        auto lx_p0x = lx_p0;
        auto b_p2x = b_p2;
        auto i_p3x = i_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), b_p2x = std::move(b_p2x), i_p3x = std::move(i_p3x)](crate::lower::types::Env p0) {
        return ({
            auto lx_p0xy = lx_p0x;
            auto b_p2xy = b_p2x;
            auto i_p3xy = i_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), b_p2xy = std::move(b_p2xy), i_p3xy = std::move(i_p3xy)]() {
            return ({
                auto env2_pn = p0;
                (prism_rtl::more(prism_rtl::rc(TailFrom(lx_p0xy, env2_pn, b_p2xy, i_p3xy))));
            });
        })));
        });
    })));
    }))));
    })
        : prism_rtl::is_none(found_o6) ? ({
        auto b_p2x = b_p2;
        auto env_p1x = env_p1;
        auto i_p3x = i_p3;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(crate::lower::expr::start_block_stmt_f(lx_p0x, env_p1x, s_p4), [=, b_p2x = std::move(b_p2x), i_p3x = std::move(i_p3x)](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt_f_5220) {
        return ({
            auto [dos_po, env2_pp] = block_stmt_f_5220;
            (crate::prelude::call_then(start_tail_from_f(lx_p0x, env2_pp, b_p2x, i_p3x + Nat(1u)), [=](crate::lower::model::Ex tail_from_f_5267) {
            return ({
                prism_rtl::is<crate::lower::model::Ex::XBlock>(tail_from_f_5267) ? ({
                auto&& more_pq = prism_rtl::as<crate::lower::model::Ex::XBlock>(tail_from_f_5267).a0;
                auto&& last_pr = prism_rtl::as<crate::lower::model::Ex::XBlock>(tail_from_f_5267).a1;
                prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{crate::prelude::append(dos_po, more_pq), prism_rtl::rc(prism_rtl::deref(last_pr))}));
            })
                : ({
                auto&& last_ps = tail_from_f_5267;
                crate::prelude::len(dos_po) == Nat(0u)
                ? prism_rtl::finished(last_ps)
                : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_po, prism_rtl::rc(last_ps)}));
            });
            });
        }));
        });
    }));
    })
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start TailFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_tail_from_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Block b_p2, Nat i_p3) {
    return prism_rtl::make_rc<TailFrom>(lx_p0, env_p1, b_p2, i_p3);
}


/// HasTopWhile: fn Lx, Block -> Bool
bool has_top_while_f(const crate::lower::Lx& lx_p0, const crate::syntax::Block& b_p1) {
    return crate::prelude::fold(b_p1.stmts_p, false, [&](const bool& f_p2, const crate::syntax::Stmt& st_p3) { return (prism_rtl::deref(f_p2) || is_cycle_while_f(lx_p0, st_p3)) || holds_cycle_while_f(lx_p0, st_p3); });
}


/// IsCycleWhile: fn Lx, Stmt -> Bool
bool is_cycle_while_f(const crate::lower::Lx& lx_p0, const crate::syntax::Stmt& st_p1) {
    auto&& _m = st_p1.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        return crate::check::env::has_key_f(lx_p0.unshrunk_p, crate::lower::place_key_f(lx_p0, st_p1.span_p));
    }
    {
        return false;
    }
}


/// ElseHasTopWhile: fn Lx, ?Block -> Bool
bool else_has_top_while_f(const crate::lower::Lx& lx_p0, const std::optional<crate::syntax::Block>& opt1) {
    if (prism_rtl::is_some(opt1)) {
        auto&& b_p1 = prism_rtl::some_of(opt1);
        return has_top_while_f(lx_p0, b_p1);
    }
    if (prism_rtl::is_none(opt1)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// HoldsCycleWhile: fn Lx, Stmt -> Bool
bool holds_cycle_while_f(const crate::lower::Lx& lx_p0, const crate::syntax::Stmt& st_p1) {
    auto&& _m = st_p1.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& wb_p2 = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        return has_top_while_f(lx_p0, wb_p2);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& x_p3 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p3).kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& then_b_p4 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b_o5 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            return has_top_while_f(lx_p0, then_b_p4) || else_has_top_while_f(lx_p0, else_b_o5);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& arms_p6 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            return crate::prelude::fold(arms_p6, false, [&](const bool& f_p7, const crate::syntax::Arm& a_p8) { return prism_rtl::deref(f_p7) || has_top_while_f(lx_p0, prism_rtl::deref(a_p8).body_p); });
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
            auto&& fb_p9 = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
            return has_top_while_f(lx_p0, fb_p9);
        }
        {
            return false;
        }
    }
    {
        return false;
    }
}


/// UpdTail: unbounded fn Lx, Env, Expr, Block, Range, (unbounded fn Env, Ex -> Ex) -> Ex
crate::lower::model::Ex upd_tail_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& target_p2, const crate::syntax::Block& b_p3, const crate::syntax::Range& to_p4, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>& cont_f5) {
    auto t_p6 = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, target_p2.span_p)));
    auto tv_p7 = crate::lower::expr::value_of_f(lx_p0, env_p1, target_p2);
    auto env1_p8 = crate::lower::types::bind_f(env_p1, Text::lit("&_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_p6}));
    return prepend_f(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("this")})), t_p6}), crate::lower::types::own_f(tv_p7)})}), upd_tail_from_f(lx_p0, env_p1, env1_p8, b_p3, Nat(0u), to_p4, cont_f5));
}


prism_rtl::Turn<crate::lower::model::Ex> UpdTail::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& target_p2 = this->target_p2;
    const auto& b_p3 = this->b_p3;
    const auto& to_p4 = this->to_p4;
    const auto& cont_f5 = this->cont_f5;
    auto cont_f5x = cont_f5;
    auto b_p3x = b_p3;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    auto target_p2x = target_p2;
    auto to_p4x = to_p4;
    return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0x, prism_rtl::deref(target_p2x).span_p))), [=](crate::lower::model::OutTy out_ty_of_f_7825) {
        return ({
            auto t_p6 = out_ty_of_f_7825;
            (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p1x, target_p2x), [=, t_p6 = std::move(t_p6)](crate::lower::types::Vl value_of_f_7882) {
            return ({
                auto tv_p7 = value_of_f_7882;
                auto env1_p8 = crate::lower::types::bind_f(env_p1x, Text::lit("&_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_p6}));
                (crate::prelude::call_then(start_upd_tail_from_f(lx_p0x, env_p1x, env1_p8, b_p3x, Nat(0u), to_p4x, cont_f5x), [=, tv_p7 = std::move(tv_p7)](crate::lower::model::Ex upd_tail_from_f_8035) { return prism_rtl::finished(prepend_f(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("this")})), t_p6}), crate::lower::types::own_f(tv_p7)})}), upd_tail_from_f_8035)); }));
            });
        }));
        });
    });
}


/// `Start UpdTail, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_upd_tail_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr target_p2, crate::syntax::Block b_p3, crate::syntax::Range to_p4, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)> cont_f5) {
    return prism_rtl::make_rc<UpdTail>(lx_p0, env_p1, target_p2, b_p3, to_p4, cont_f5);
}


/// UpdTailFrom: unbounded fn Lx, Env, Env, Block, Nat, Range, (unbounded fn Env, Ex -> Ex) -> Ex
crate::lower::model::Ex upd_tail_from_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& outer_p1, const crate::lower::types::Env& env_p2, const crate::syntax::Block& b_p3, const Nat& i_p4, const crate::syntax::Range& to_p5, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>& cont_f6) {
    return i_p4 >= crate::prelude::len(b_p3.stmts_p)
        ? crate::prelude::run_to_end(cont_f6(std::tuple{outer_p1, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")})}))
        : ({
        auto s_p7 = crate::prelude::or_(crate::prelude::index(b_p3.stmts_p, i_p4), crate::lower::expr::dummy_stmt_l_p());
        auto rest_p8 = rest_text_f(lx_p0, crate::syntax::Range{.start_p = prism_rtl::deref(prism_rtl::deref(s_p7).span_p).end_p, .end_p = prism_rtl::deref(prism_rtl::deref(s_p7).span_p).end_p}, crate::syntax::Range{.start_p = prism_rtl::deref(prism_rtl::deref(s_p7).span_p).end_p, .end_p = prism_rtl::deref(prism_rtl::deref(s_p7).span_p).end_p}, to_p5);
        auto next_f9 = ({
            auto lx_p0x = lx_p0;
            auto b_p3x = b_p3;
            auto i_p4x = i_p4;
            auto to_p5x = to_p5;
            auto cont_f6x = cont_f6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), b_p3x = std::move(b_p3x), i_p4x = std::move(i_p4x), to_p5x = std::move(to_p5x), cont_f6x = std::move(cont_f6x)](std::tuple<crate::lower::types::Env, crate::lower::types::Env> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_p0xy = lx_p0x;
                auto b_p3xy = b_p3x;
                auto i_p4xy = i_p4x;
                auto to_p5xy = to_p5x;
                auto cont_f6xy = cont_f6x;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), b_p3xy = std::move(b_p3xy), i_p4xy = std::move(i_p4xy), to_p5xy = std::move(to_p5xy), cont_f6xy = std::move(cont_f6xy)]() {
                return ({
                    auto o2_pa = p0;
                    auto e2_pb = p1;
                    (prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_p0xy, o2_pa, e2_pb, b_p3xy, i_p4xy + Nat(1u), to_p5xy, cont_f6xy))));
                });
            })));
            });
        })));
        });
        is_cycle_while_f(lx_p0, s_p7) || holds_cycle_while_f(lx_p0, s_p7)
        ? stmt_job_f(lx_p0, outer_p1, env_p2, s_p7, rest_p8, next_f9)
        : ({
        auto [dos_pc, env2_pd] = crate::lower::templates::upd_stmt_f(lx_p0, env_p2, s_p7);
        prepend_f(dos_pc, upd_tail_from_f(lx_p0, outer_p1, env2_pd, b_p3, i_p4 + Nat(1u), to_p5, cont_f6));
    });
    });
}


prism_rtl::Turn<crate::lower::model::Ex> UpdTailFrom::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& outer_p1 = this->outer_p1;
    const auto& env_p2 = this->env_p2;
    const auto& b_p3 = this->b_p3;
    const auto& i_p4 = this->i_p4;
    const auto& to_p5 = this->to_p5;
    const auto& cont_f6 = this->cont_f6;
    return i_p4 >= crate::prelude::len(prism_rtl::deref(b_p3).stmts_p)
        ? cont_f6(std::tuple{outer_p1, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")})})->cycle()
        : ({
        auto s_p7 = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(b_p3).stmts_p, i_p4), crate::lower::expr::dummy_stmt_l_p());
        auto rest_p8 = rest_text_f(lx_p0, crate::syntax::Range{.start_p = prism_rtl::deref(prism_rtl::deref(s_p7).span_p).end_p, .end_p = prism_rtl::deref(prism_rtl::deref(s_p7).span_p).end_p}, crate::syntax::Range{.start_p = prism_rtl::deref(prism_rtl::deref(s_p7).span_p).end_p, .end_p = prism_rtl::deref(prism_rtl::deref(s_p7).span_p).end_p}, to_p5);
        auto next_f9 = ({
            auto lx_p0x = lx_p0;
            auto b_p3x = b_p3;
            auto i_p4x = i_p4;
            auto to_p5x = to_p5;
            auto cont_f6x = cont_f6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), b_p3x = std::move(b_p3x), i_p4x = std::move(i_p4x), to_p5x = std::move(to_p5x), cont_f6x = std::move(cont_f6x)](std::tuple<crate::lower::types::Env, crate::lower::types::Env> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_p0xy = lx_p0x;
                auto b_p3xy = b_p3x;
                auto i_p4xy = i_p4x;
                auto to_p5xy = to_p5x;
                auto cont_f6xy = cont_f6x;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), b_p3xy = std::move(b_p3xy), i_p4xy = std::move(i_p4xy), to_p5xy = std::move(to_p5xy), cont_f6xy = std::move(cont_f6xy)]() {
                return ({
                    auto o2_pa = p0;
                    auto e2_pb = p1;
                    (prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_p0xy, o2_pa, e2_pb, b_p3xy, i_p4xy + Nat(1u), to_p5xy, cont_f6xy))));
                });
            })));
            });
        })));
        });
        is_cycle_while_f(lx_p0, s_p7) || holds_cycle_while_f(lx_p0, s_p7)
        ? prism_rtl::more(prism_rtl::rc(StmtJob(lx_p0, outer_p1, env_p2, s_p7, rest_p8, next_f9)))
        : ({
        auto cont_f6x = cont_f6;
        auto b_p3x = b_p3;
        auto env_p2x = env_p2;
        auto i_p4x = i_p4;
        auto lx_p0x = lx_p0;
        auto outer_p1x = outer_p1;
        auto to_p5x = to_p5;
        (crate::prelude::call_then(crate::lower::templates::start_upd_stmt_f(lx_p0x, env_p2x, s_p7), [=, cont_f6x = std::move(cont_f6x), b_p3x = std::move(b_p3x), i_p4x = std::move(i_p4x), outer_p1x = std::move(outer_p1x), to_p5x = std::move(to_p5x)](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmt_f_8662) {
        return ({
            auto [dos_pc, env2_pd] = upd_stmt_f_8662;
            (crate::prelude::call_then(start_upd_tail_from_f(lx_p0x, outer_p1x, env2_pd, b_p3x, i_p4x + Nat(1u), to_p5x, cont_f6x), [=](crate::lower::model::Ex upd_tail_from_f_8707) { return prism_rtl::finished(prepend_f(dos_pc, upd_tail_from_f_8707)); }));
        });
    }));
    });
    });
}


/// `Start UpdTailFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_upd_tail_from_f(crate::lower::Lx lx_p0, crate::lower::types::Env outer_p1, crate::lower::types::Env env_p2, crate::syntax::Block b_p3, Nat i_p4, crate::syntax::Range to_p5, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)> cont_f6) {
    return prism_rtl::make_rc<UpdTailFrom>(lx_p0, outer_p1, env_p2, b_p3, i_p4, to_p5, cont_f6);
}


/// StmtJob: unbounded fn Lx, Env, Env, Stmt, Text, (unbounded fn Env, Env -> Ex) -> Ex
crate::lower::model::Ex stmt_job_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& outer_p1, const crate::lower::types::Env& env_p2, const crate::syntax::Stmt& s_p3, const Text& rest_p4, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>& cont_f5) {
    auto&& _m = s_p3.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& c_p6 = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& wb_p7 = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        return while_job_f(lx_p0, outer_p1, env_p2, c_p6, wb_p7, s_p3.span_p, rest_p4, cont_f5);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& x_p8 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p8).kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& c_p9 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& then_b_pa = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b_ob = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            return if_job_f(lx_p0, outer_p1, env_p2, prism_rtl::deref(prism_rtl::deref(c_p9)), then_b_pa, else_b_ob, s_p3.span_p, rest_p4, cont_f5);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& scrut_pc = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms_pd = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            return match_job_f(lx_p0, outer_p1, env_p2, prism_rtl::deref(prism_rtl::deref(scrut_pc)), arms_pd, s_p3.span_p, rest_p4, cont_f5);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
            auto&& binders_oe = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
            auto&& source_pf = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
            auto&& body_pg = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
            auto&& _m = crate::lower::templates::ref_binder_o(binders_oe);
            if (prism_rtl::is_some(_m)) {
                return crate::lower::expr::refusal_f(Text::lit("a cycle-point `while` in a `for &` of an `update` block, whose references a job cannot keep (gap LP)"));
            }
            if (prism_rtl::is_none(_m)) {
                return for_job_f(lx_p0, outer_p1, env_p2, binders_oe, prism_rtl::deref(prism_rtl::deref(source_pf)), body_pg, s_p3.span_p, rest_p4, cont_f5);
            }
            prism_rtl::unreachable("no arm matched");
        }
        {
            return crate::lower::expr::refusal_f(prism_rtl::cat("a cycle-point `while` in ", crate::lower::expr::kind_words_f(prism_rtl::deref(prism_rtl::deref(x_p8).kind_p)), " (gap LP)"));
        }
    }
    {
        return crate::lower::expr::refusal_f(Text::lit("a cycle-point `while` in this statement (gap LP)"));
    }
}


prism_rtl::Turn<crate::lower::model::Ex> StmtJob::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& outer_p1 = this->outer_p1;
    const auto& env_p2 = this->env_p2;
    const auto& s_p3 = this->s_p3;
    const auto& rest_p4 = this->rest_p4;
    const auto& cont_f5 = this->cont_f5;
    return ({
        auto&& _m = prism_rtl::deref(s_p3).kind_p;
        prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
        auto&& c_p6 = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& wb_p7 = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        prism_rtl::more(prism_rtl::rc(WhileJob(lx_p0, outer_p1, env_p2, c_p6, wb_p7, prism_rtl::deref(s_p3).span_p, rest_p4, cont_f5)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& x_p8 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p8).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c_p9 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_pa = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_ob = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        prism_rtl::more(prism_rtl::rc(IfJob(lx_p0, outer_p1, env_p2, prism_rtl::deref(prism_rtl::deref(c_p9)), then_b_pa, else_b_ob, prism_rtl::deref(s_p3).span_p, rest_p4, cont_f5)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& scrut_pc = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_pd = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        prism_rtl::more(prism_rtl::rc(MatchJob(lx_p0, outer_p1, env_p2, prism_rtl::deref(prism_rtl::deref(scrut_pc)), arms_pd, prism_rtl::deref(s_p3).span_p, rest_p4, cont_f5)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& binders_oe = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source_pf = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body_pg = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        ({
        auto&& _m = crate::lower::templates::ref_binder_o(binders_oe);
        prism_rtl::is_some(_m) ? prism_rtl::finished(crate::lower::expr::refusal_f(Text::lit("a cycle-point `while` in a `for &` of an `update` block, whose references a job cannot keep (gap LP)")))
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(ForJob(lx_p0, outer_p1, env_p2, binders_oe, prism_rtl::deref(prism_rtl::deref(source_pf)), body_pg, prism_rtl::deref(s_p3).span_p, rest_p4, cont_f5)))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(crate::lower::expr::refusal_f(prism_rtl::cat("a cycle-point `while` in ", crate::lower::expr::kind_words_f(prism_rtl::deref(prism_rtl::deref(x_p8).kind_p)), " (gap LP)")));
    });
    })
        : prism_rtl::finished(crate::lower::expr::refusal_f(Text::lit("a cycle-point `while` in this statement (gap LP)")));
    });
}


/// `Start StmtJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_stmt_job_f(crate::lower::Lx lx_p0, crate::lower::types::Env outer_p1, crate::lower::types::Env env_p2, crate::syntax::Stmt s_p3, Text rest_p4, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_f5) {
    return prism_rtl::make_rc<StmtJob>(lx_p0, outer_p1, env_p2, s_p3, rest_p4, cont_f5);
}


/// Prepend: fn [Do], Ex -> Ex
crate::lower::model::Ex prepend_f(const Array<crate::lower::model::Do>& dos_p0, const crate::lower::model::Ex& ex1) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(ex1)) {
        auto&& more_p1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex1).a0;
        auto&& last_p2 = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex1).a1;
        return crate::lower::model::Ex(crate::lower::model::Ex::XBlock{crate::prelude::append(dos_p0, more_p1), prism_rtl::rc(prism_rtl::deref(prism_rtl::deref(last_p2)))});
    }
    {
        auto&& x_p4 = ex1;
        return crate::prelude::len(dos_p0) == Nat(0u)
            ? x_p4
            : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_p0, prism_rtl::rc(x_p4)});
    }
}


/// WhileJob: unbounded fn Lx, Env, Env, Cond, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
crate::lower::model::Ex while_job_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& outer_p1, const crate::lower::types::Env& env_p2, const crate::syntax::Cond& c_p3, const crate::syntax::Block& wb_p4, const crate::syntax::Range& span_p5, const Text& rest_text_p6, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>& cont_f7) {
    auto state_p8 = crate::prelude::fold(crate::prelude::keys(env_p2.names_p), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc_p11, const Text& k_p12) {
        return !crate::syntax::lexer::chars::has_prefix_f(k_p12, Text::lit("&"))
            ? acc_p11
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env_p2.names_p, k_p12);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_p13 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt_p14 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc_p11, std::tuple{k_p12, crate::lower::types::place_stem_f(rs_p13), bt_p14}));
                goto _done;
            }
            {
                _v.set(acc_p11);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names_p9 = crate::prelude::each(state_p8, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs_p15 = std::get<1>(_p0);
        return rs_p15;
    });
    auto st_ty_pa = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{crate::prelude::each(state_p8, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt_p16 = std::get<2>(_p0);
        return bt_p16;
    })});
    auto pat_pb = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{crate::prelude::each(names_p9, [&](const Text& n_p17) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n_p17)}); })});
    auto pack_pc = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{crate::prelude::each(names_p9, [&](const Text& n_p18) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n_p18}); })});
    auto env_s_pd = crate::prelude::fold(state_p8, env_p2, [&](const crate::lower::types::Env& en_p19, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k_p1a = std::get<0>(_p1);
        auto&& rs_p1b = std::get<1>(_p1);
        auto&& bt_p1c = std::get<2>(_p1);
        return crate::lower::types::bind_f(en_p19, k_p1a, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_p1b}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p1c}));
    });
    auto loop_text_pe = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::prelude::index(prism_rtl::deref(lx_p0.g_p).srcs_p, lx_p0.file_p);
        if (prism_rtl::is_some(_m)) {
            auto&& src_p1d = prism_rtl::some_of(_m);
            _v.set(crate::check::errors::span_text_f(src_p1d, span_p5));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto caps_pf = caps_in_f(env_s_pd, loop_text_pe, names_p9);
    auto cap_dos_pg = crate::prelude::each(caps_pf, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs_p1e = std::get<1>(_p0);
        auto&& mode_p1f = std::get<2>(_p0);
        auto&& bt_p1g = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::expr::capture_name_f(rs_p1e)}), crate::lower::types::own_f(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs_p1e, mode_p1f, bt_p1g}))});
    });
    auto env_c_ph = crate::prelude::fold(caps_pf, env_s_pd, [&](const crate::lower::types::Env& en_p1h, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k_p1i = std::get<0>(_p1);
        auto&& rs_p1j = std::get<1>(_p1);
        auto&& bt_p1k = std::get<3>(_p1);
        return crate::lower::types::bind_f(en_p1h, k_p1i, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::capture_name_f(rs_p1j)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p1k}));
    });
    auto jobs_pi = has_top_while_f(lx_p0, wb_p4);
    auto finish_fj = ({
        auto jobs_pix = std::move(jobs_pi);
        (static_cast<Fn<crate::lower::model::Ex(const crate::lower::model::Ex&)>>(prism_rtl::rc([=, jobs_pix = std::move(jobs_pix)](const crate::lower::model::Ex& x_p1l) {
        return jobs_pix
            ? crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{x_p1l})})
            : x_p1l;
    })));
    });
    auto step_ty_pk = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Result"), Array(std::vector{st_ty_pa, st_ty_pa})});
    auto again_pl = finish_fj(crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{pack_pc})})), step_ty_pk}));
    auto stop_pm = finish_fj(crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{pack_pc})})), step_ty_pk}));
    auto body_fn = ({
        auto jobs_pix = std::move(jobs_pi);
        auto lx_p0x = lx_p0;
        auto wb_p4x = wb_p4;
        auto again_plx = again_pl;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)>>(prism_rtl::rc([=, jobs_pix = std::move(jobs_pix), lx_p0x = std::move(lx_p0x), wb_p4x = std::move(wb_p4x), again_plx = std::move(again_plx)](crate::lower::types::Env p0) {
        return ({
            auto jobs_pixy = jobs_pix;
            auto lx_p0xy = lx_p0x;
            auto wb_p4xy = wb_p4x;
            auto again_plxy = again_plx;
            (crate::prelude::entered(crate::prelude::once_job([=, jobs_pixy = std::move(jobs_pixy), lx_p0xy = std::move(lx_p0xy), wb_p4xy = std::move(wb_p4xy), again_plxy = std::move(again_plxy)]() {
            return ({
                auto en_p1m = p0;
                jobs_pixy
                ? prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_p0xy, en_p1m, en_p1m, wb_p4xy, Nat(0u), prism_rtl::deref(wb_p4xy).span_p, ({
                auto again_plxyx = again_plxy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=, again_plxyx = std::move(again_plxyx)](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto again_plxyxy = again_plxyx;
                    (crate::prelude::once_job([=, again_plxyxy = std::move(again_plxyxy)]() {
                    return ({
                        auto o2_p1n = p0;
                        auto e2_p1o = p1;
                        (prism_rtl::finished(again_plxyxy));
                    });
                }));
                });
            })));
            }))))
                : prism_rtl::more(prism_rtl::rc(StmtsThen(lx_p0xy, en_p1m, wb_p4xy, again_plxy)));
            });
        })));
        });
    })));
    });
    auto res_ty_po = std::move(jobs_pi)
        ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Turn"), Array(std::vector{step_ty_pk})})
        : st_ty_pa;
    auto turn_pp = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p3)) {
            auto&& x_p1p = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p3).a0;
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(crate::lower::types::as_bool_f(crate::lower::expr::value_of_f(lx_p0, env_c_ph, prism_rtl::deref(prism_rtl::deref(x_p1p))))), prism_rtl::rc(crate::prelude::run_to_end(body_fn(env_c_ph))), prism_rtl::rc(stop_pm)}));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c_p3)) {
            auto&& p_p1q = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p3).a0;
            auto&& x_p1r = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p3).a1;
            auto&& g_o1s = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p3).a2;
            _v.set(({
                auto po_p1t = crate::lower::patterns::rust_pat_f(lx_p0, p_p1q, crate::lower::type_at_f(lx_p0, prism_rtl::deref(x_p1r).span_p), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("w", span_p5.start_p));
                auto env_b_p1u = crate::lower::expr::bind_all_f(env_c_ph, prism_rtl::deref(po_p1t).binds_p);
                auto conds_p1v = crate::prelude::append(prism_rtl::deref(po_p1t).conds_p, crate::lower::templates::guard_conds_f(lx_p0, env_b_p1u, prism_rtl::deref(prism_rtl::deref(g_o1s))));
                (crate::lower::types::own_f(crate::lower::expr::arms_value_f(crate::lower::types::own_f(crate::lower::expr::value_of_f(lx_p0, env_c_ph, prism_rtl::deref(prism_rtl::deref(x_p1r)))), Array(std::vector{crate::lower::model::XArm{.pat_p = prism_rtl::deref(po_p1t).pa_p, .conds_p = conds_p1v, .body_p = crate::prelude::run_to_end(body_fn(env_b_p1u))}, crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = stop_pm}}), prism_rtl::cat("\'w", span_p5.start_p), res_ty_po)));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto out_caps_pq = caps_in_f(outer_p1, rest_text_p6, names_p9);
    auto out_dos_pr = crate::prelude::each(out_caps_pq, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs_p20 = std::get<1>(_p0);
        auto&& mode_p21 = std::get<2>(_p0);
        auto&& bt_p22 = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::expr::outer_name_f(rs_p20)}), crate::lower::types::own_f(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs_p20, mode_p21, bt_p22}))});
    });
    auto outer2_ps = crate::prelude::fold(out_caps_pq, outer_p1, [&](const crate::lower::types::Env& en_p23, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k_p24 = std::get<0>(_p1);
        auto&& rs_p25 = std::get<1>(_p1);
        auto&& bt_p26 = std::get<3>(_p1);
        return crate::lower::types::bind_f(en_p23, k_p24, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::outer_name_f(rs_p25)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p26}));
    });
    auto env2_pt = crate::prelude::fold(out_caps_pq, env_s_pd, [&](const crate::lower::types::Env& en_p27, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k_p28 = std::get<0>(_p1);
        auto&& rs_p29 = std::get<1>(_p1);
        auto&& bt_p2a = std::get<3>(_p1);
        return crate::lower::types::bind_f(en_p27, k_p28, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::outer_name_f(rs_p29)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p2a}));
    });
    auto step_fn_pu = prepend_f(cap_dos_pg, crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat_pb), st_ty_pa})}), prism_rtl::rc(turn_pp)}));
    auto looping_pv = crate::lower::helper_f(std::move(jobs_pi) ? Text::lit("loop_turns") : Text::lit("loop_job"));
    auto enter_p10 = crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("call_then")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{looping_pv, Array(std::vector{pack_pc, step_fn_pu})}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat_pb), st_ty_pa})}), prism_rtl::rc(crate::prelude::run_to_end(cont_f7(std::tuple{outer2_ps, env2_pt})))})})});
    return prepend_f(out_dos_pr, enter_p10);
}


prism_rtl::Turn<crate::lower::model::Ex> WhileJob::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& outer_p1 = this->outer_p1;
    const auto& env_p2 = this->env_p2;
    const auto& c_p3 = this->c_p3;
    const auto& wb_p4 = this->wb_p4;
    const auto& span_p5 = this->span_p5;
    const auto& rest_text_p6 = this->rest_text_p6;
    const auto& cont_f7 = this->cont_f7;
    auto state_p8 = crate::prelude::fold(crate::prelude::keys(prism_rtl::deref(env_p2).names_p), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc_p11, const Text& k_p12) {
        return !crate::syntax::lexer::chars::has_prefix_f(k_p12, Text::lit("&"))
            ? acc_p11
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p2).names_p, k_p12);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_p13 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt_p14 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc_p11, std::tuple{k_p12, crate::lower::types::place_stem_f(rs_p13), bt_p14}));
                goto _done;
            }
            {
                _v.set(acc_p11);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names_p9 = crate::prelude::each(state_p8, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs_p15 = std::get<1>(_p0);
        return rs_p15;
    });
    auto st_ty_pa = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{crate::prelude::each(state_p8, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt_p16 = std::get<2>(_p0);
        return bt_p16;
    })});
    auto pat_pb = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{crate::prelude::each(names_p9, [&](const Text& n_p17) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n_p17)}); })});
    auto pack_pc = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{crate::prelude::each(names_p9, [&](const Text& n_p18) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n_p18}); })});
    auto env_s_pd = crate::prelude::fold(state_p8, env_p2, [&](const crate::lower::types::Env& en_p19, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k_p1a = std::get<0>(_p1);
        auto&& rs_p1b = std::get<1>(_p1);
        auto&& bt_p1c = std::get<2>(_p1);
        return crate::lower::types::bind_f(en_p19, k_p1a, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_p1b}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p1c}));
    });
    auto loop_text_pe = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::prelude::index(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).srcs_p, prism_rtl::deref(lx_p0).file_p);
        if (prism_rtl::is_some(_m)) {
            auto&& src_p1d = prism_rtl::some_of(_m);
            _v.set(crate::check::errors::span_text_f(src_p1d, span_p5));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto caps_pf = caps_in_f(env_s_pd, loop_text_pe, names_p9);
    auto cap_dos_pg = crate::prelude::each(caps_pf, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs_p1e = std::get<1>(_p0);
        auto&& mode_p1f = std::get<2>(_p0);
        auto&& bt_p1g = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::expr::capture_name_f(rs_p1e)}), crate::lower::types::own_f(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs_p1e, mode_p1f, bt_p1g}))});
    });
    auto env_c_ph = crate::prelude::fold(caps_pf, env_s_pd, [&](const crate::lower::types::Env& en_p1h, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k_p1i = std::get<0>(_p1);
        auto&& rs_p1j = std::get<1>(_p1);
        auto&& bt_p1k = std::get<3>(_p1);
        return crate::lower::types::bind_f(en_p1h, k_p1i, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::capture_name_f(rs_p1j)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p1k}));
    });
    auto jobs_pi = has_top_while_f(lx_p0, wb_p4);
    auto finish_fj = ({
        auto jobs_pix = std::move(jobs_pi);
        (static_cast<Fn<crate::lower::model::Ex(const crate::lower::model::Ex&)>>(prism_rtl::rc([=, jobs_pix = std::move(jobs_pix)](const crate::lower::model::Ex& x_p1l) {
        return jobs_pix
            ? crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{x_p1l})})
            : x_p1l;
    })));
    });
    auto step_ty_pk = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Result"), Array(std::vector{st_ty_pa, st_ty_pa})});
    auto again_pl = finish_fj(crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{pack_pc})})), step_ty_pk}));
    auto stop_pm = finish_fj(crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{pack_pc})})), step_ty_pk}));
    auto body_fn = ({
        auto jobs_pix = std::move(jobs_pi);
        auto lx_p0x = lx_p0;
        auto wb_p4x = wb_p4;
        auto again_plx = again_pl;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)>>(prism_rtl::rc([=, jobs_pix = std::move(jobs_pix), lx_p0x = std::move(lx_p0x), wb_p4x = std::move(wb_p4x), again_plx = std::move(again_plx)](crate::lower::types::Env p0) {
        return ({
            auto jobs_pixy = jobs_pix;
            auto lx_p0xy = lx_p0x;
            auto wb_p4xy = wb_p4x;
            auto again_plxy = again_plx;
            (crate::prelude::entered(crate::prelude::once_job([=, jobs_pixy = std::move(jobs_pixy), lx_p0xy = std::move(lx_p0xy), wb_p4xy = std::move(wb_p4xy), again_plxy = std::move(again_plxy)]() {
            return ({
                auto en_p1m = p0;
                jobs_pixy
                ? prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_p0xy, en_p1m, en_p1m, wb_p4xy, Nat(0u), prism_rtl::deref(wb_p4xy).span_p, ({
                auto again_plxyx = again_plxy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=, again_plxyx = std::move(again_plxyx)](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto again_plxyxy = again_plxyx;
                    (crate::prelude::once_job([=, again_plxyxy = std::move(again_plxyxy)]() {
                    return ({
                        auto o2_p1n = p0;
                        auto e2_p1o = p1;
                        (prism_rtl::finished(again_plxyxy));
                    });
                }));
                });
            })));
            }))))
                : prism_rtl::more(prism_rtl::rc(StmtsThen(lx_p0xy, en_p1m, wb_p4xy, again_plxy)));
            });
        })));
        });
    })));
    });
    auto res_ty_po = std::move(jobs_pi)
        ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Turn"), Array(std::vector{step_ty_pk})})
        : st_ty_pa;
    auto turn_pp = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p3)) {
            auto&& x_p1p = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p3).a0;
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(crate::lower::types::as_bool_f(crate::lower::expr::value_of_f(lx_p0, env_c_ph, prism_rtl::deref(prism_rtl::deref(x_p1p))))), prism_rtl::rc(crate::prelude::run_to_end(body_fn(env_c_ph))), prism_rtl::rc(stop_pm)}));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c_p3)) {
            auto&& p_p1q = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p3).a0;
            auto&& x_p1r = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p3).a1;
            auto&& g_o1s = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p3).a2;
            _v.set(({
                auto po_p1t = crate::lower::patterns::rust_pat_f(lx_p0, p_p1q, crate::lower::type_at_f(lx_p0, prism_rtl::deref(x_p1r).span_p), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("w", prism_rtl::deref(span_p5).start_p));
                auto env_b_p1u = crate::lower::expr::bind_all_f(env_c_ph, prism_rtl::deref(po_p1t).binds_p);
                auto conds_p1v = crate::prelude::append(prism_rtl::deref(po_p1t).conds_p, crate::lower::templates::guard_conds_f(lx_p0, env_b_p1u, prism_rtl::deref(prism_rtl::deref(g_o1s))));
                (crate::lower::types::own_f(crate::lower::expr::arms_value_f(crate::lower::types::own_f(crate::lower::expr::value_of_f(lx_p0, env_c_ph, prism_rtl::deref(prism_rtl::deref(x_p1r)))), Array(std::vector{crate::lower::model::XArm{.pat_p = prism_rtl::deref(po_p1t).pa_p, .conds_p = conds_p1v, .body_p = crate::prelude::run_to_end(body_fn(env_b_p1u))}, crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = stop_pm}}), prism_rtl::cat("\'w", prism_rtl::deref(span_p5).start_p), res_ty_po)));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto out_caps_pq = caps_in_f(outer_p1, rest_text_p6, names_p9);
    auto out_dos_pr = crate::prelude::each(out_caps_pq, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs_p20 = std::get<1>(_p0);
        auto&& mode_p21 = std::get<2>(_p0);
        auto&& bt_p22 = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::expr::outer_name_f(rs_p20)}), crate::lower::types::own_f(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs_p20, mode_p21, bt_p22}))});
    });
    auto outer2_ps = crate::prelude::fold(out_caps_pq, outer_p1, [&](const crate::lower::types::Env& en_p23, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k_p24 = std::get<0>(_p1);
        auto&& rs_p25 = std::get<1>(_p1);
        auto&& bt_p26 = std::get<3>(_p1);
        return crate::lower::types::bind_f(en_p23, k_p24, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::outer_name_f(rs_p25)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p26}));
    });
    auto env2_pt = crate::prelude::fold(out_caps_pq, env_s_pd, [&](const crate::lower::types::Env& en_p27, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k_p28 = std::get<0>(_p1);
        auto&& rs_p29 = std::get<1>(_p1);
        auto&& bt_p2a = std::get<3>(_p1);
        return crate::lower::types::bind_f(en_p27, k_p28, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::outer_name_f(rs_p29)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p2a}));
    });
    auto step_fn_pu = prepend_f(cap_dos_pg, crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat_pb), st_ty_pa})}), prism_rtl::rc(turn_pp)}));
    auto looping_pv = crate::lower::helper_f(std::move(jobs_pi) ? Text::lit("loop_turns") : Text::lit("loop_job"));
    auto cont_f7x = cont_f7;
    return crate::prelude::call_value(cont_f7x(std::tuple{outer2_ps, env2_pt}), [=](crate::lower::model::Ex cont_13234) {
        return ({
            auto enter_p10 = crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("call_then")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{looping_pv, Array(std::vector{pack_pc, step_fn_pu})}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat_pb), st_ty_pa})}), prism_rtl::rc(cont_13234)})})});
            (prism_rtl::finished(prepend_f(out_dos_pr, enter_p10)));
        });
    });
}


/// `Start WhileJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_while_job_f(crate::lower::Lx lx_p0, crate::lower::types::Env outer_p1, crate::lower::types::Env env_p2, crate::syntax::Cond c_p3, crate::syntax::Block wb_p4, crate::syntax::Range span_p5, Text rest_text_p6, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_f7) {
    return prism_rtl::make_rc<WhileJob>(lx_p0, outer_p1, env_p2, c_p3, wb_p4, span_p5, rest_text_p6, cont_f7);
}


/// StmtsThen: unbounded fn Lx, Env, Block, Ex -> Ex
crate::lower::model::Ex stmts_then_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Block& b_p2, const crate::lower::model::Ex& last_p3) {
    auto&& _dos_p4 = crate::lower::templates::upd_stmts_f(lx_p0, env_p1, b_p2.stmts_p);
    auto&& dos_p4 = std::get<0>(_dos_p4);
    return crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_p4, prism_rtl::rc(last_p3)});
}


prism_rtl::Turn<crate::lower::model::Ex> StmtsThen::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& b_p2 = this->b_p2;
    const auto& last_p3 = this->last_p3;
    auto b_p2x = b_p2;
    auto env_p1x = env_p1;
    auto last_p3x = last_p3;
    auto lx_p0x = lx_p0;
    return crate::prelude::call_then(crate::lower::templates::start_upd_stmts_f(lx_p0x, env_p1x, prism_rtl::deref(b_p2x).stmts_p), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_f_13447) {
        return ({
            auto&& _dos_p4 = upd_stmts_f_13447;
            auto&& dos_p4 = std::get<0>(_dos_p4);
            (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_p4, prism_rtl::rc(last_p3x)})));
        });
    });
}


/// `Start StmtsThen, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_stmts_then_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Block b_p2, crate::lower::model::Ex last_p3) {
    return prism_rtl::make_rc<StmtsThen>(lx_p0, env_p1, b_p2, last_p3);
}


/// IfJob: unbounded fn Lx, Env, Env, Cond, Block, ?Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
crate::lower::model::Ex if_job_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& outer_p1, const crate::lower::types::Env& env_p2, const crate::syntax::Cond& c_p3, const crate::syntax::Block& then_b_p4, const std::optional<crate::syntax::Block>& else_b_o5, const crate::syntax::Range& span_p6, const Text& rest_text_p7, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>& cont_f8) {
    auto state_p9 = crate::prelude::fold(crate::prelude::keys(env_p2.names_p), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc_pp, const Text& k_pq) {
        return !crate::syntax::lexer::chars::has_prefix_f(k_pq, Text::lit("&"))
            ? acc_pp
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env_p2.names_p, k_pq);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_pr = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt_ps = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc_pp, std::tuple{k_pq, crate::lower::types::place_stem_f(rs_pr), bt_ps}));
                goto _done;
            }
            {
                _v.set(acc_pp);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names_pa = crate::prelude::each(state_p9, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs_pt = std::get<1>(_p0);
        return rs_pt;
    });
    auto st_ty_pb = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{crate::prelude::each(state_p9, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt_pu = std::get<2>(_p0);
        return bt_pu;
    })});
    auto pat_pc = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{crate::prelude::each(names_pa, [&](const Text& n_pv) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n_pv)}); })});
    auto pack_pd = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{crate::prelude::each(names_pa, [&](const Text& n_p10) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n_p10}); })});
    auto env_s_pe = crate::prelude::fold(state_p9, env_p2, [&](const crate::lower::types::Env& en_p11, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k_p12 = std::get<0>(_p1);
        auto&& rs_p13 = std::get<1>(_p1);
        auto&& bt_p14 = std::get<2>(_p1);
        return crate::lower::types::bind_f(en_p11, k_p12, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_p13}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p14}));
    });
    auto out_caps_pf = caps_in_f(outer_p1, rest_text_p7, names_pa);
    auto out_dos_pg = crate::prelude::each(out_caps_pf, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs_p15 = std::get<1>(_p0);
        auto&& mode_p16 = std::get<2>(_p0);
        auto&& bt_p17 = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::expr::outer_name_f(rs_p15)}), crate::lower::types::own_f(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs_p15, mode_p16, bt_p17}))});
    });
    auto outer2_ph = crate::prelude::fold(out_caps_pf, outer_p1, [&](const crate::lower::types::Env& en_p18, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k_p19 = std::get<0>(_p1);
        auto&& rs_p1a = std::get<1>(_p1);
        auto&& bt_p1b = std::get<3>(_p1);
        return crate::lower::types::bind_f(en_p18, k_p19, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::outer_name_f(rs_p1a)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p1b}));
    });
    auto env2_pi = crate::prelude::fold(out_caps_pf, env_s_pe, [&](const crate::lower::types::Env& en_p1c, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k_p1d = std::get<0>(_p1);
        auto&& rs_p1e = std::get<1>(_p1);
        auto&& bt_p1f = std::get<3>(_p1);
        return crate::lower::types::bind_f(en_p1c, k_p1d, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::outer_name_f(rs_p1e)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p1f}));
    });
    auto k_name_pj = prism_rtl::cat("k_if", span_p6.start_p);
    auto k_do_pk = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{k_name_pj}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat_pc), st_ty_pb})}), prism_rtl::rc(crate::prelude::run_to_end(cont_f8(std::tuple{outer2_ph, env2_pi})))})});
    auto to_k_fl = ({
        auto k_name_pjx = k_name_pj;
        auto pack_pdx = pack_pd;
        (static_cast<Fn<crate::lower::model::Ex(const crate::lower::types::Env&, const crate::lower::model::Ex&)>>(prism_rtl::rc([=, k_name_pjx = std::move(k_name_pjx), pack_pdx = std::move(pack_pdx)](const crate::lower::types::Env& o2_p1g, const crate::lower::model::Ex& e2_p1h) { return crate::lower::model::Ex(crate::lower::model::Ex::XCall{k_name_pjx, Array(std::vector{pack_pdx})}); })));
    });
    auto branch_fm = ({
        auto lx_p0x = lx_p0;
        auto env_p2x = env_p2;
        auto to_k_flx = to_k_fl;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Block)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), env_p2x = std::move(env_p2x), to_k_flx = std::move(to_k_flx)](crate::syntax::Block p0) {
        return ({
            auto lx_p0xy = lx_p0x;
            auto env_p2xy = env_p2x;
            auto to_k_flxy = to_k_flx;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), env_p2xy = std::move(env_p2xy), to_k_flxy = std::move(to_k_flxy)]() {
            return ({
                auto b_p1i = p0;
                (prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_p0xy, env_p2xy, env_p2xy, b_p1i, Nat(0u), prism_rtl::deref(b_p1i).span_p, ({
                auto f = to_k_flxy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=, f = std::move(f)](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
                auto&& a0 = std::get<0>(_p0);
                auto&& a1 = std::get<1>(_p0);
                return ({
                    auto fy = f;
                    (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0, a1)); }));
                });
            })));
            })))));
            });
        })));
        });
    })));
    });
    auto else_x_pn = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is_some(else_b_o5)) {
            auto&& eb_p1j = prism_rtl::some_of(else_b_o5);
            _v.set(crate::prelude::run_to_end(branch_fm(eb_p1j)));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_o5)) {
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCall{k_name_pj, Array(std::vector{pack_pd})}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto choose_po = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p3)) {
            auto&& x_p1k = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p3).a0;
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(crate::lower::types::as_bool_f(crate::lower::expr::value_of_f(lx_p0, env_p2, prism_rtl::deref(prism_rtl::deref(x_p1k))))), prism_rtl::rc(crate::prelude::run_to_end(branch_fm(then_b_p4))), prism_rtl::rc(else_x_pn)}));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c_p3)) {
            auto&& p_p1l = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p3).a0;
            auto&& x_p1m = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p3).a1;
            _v.set(({
                auto po_p1n = crate::lower::patterns::rust_pat_f(lx_p0, p_p1l, crate::lower::type_at_f(lx_p0, prism_rtl::deref(x_p1m).span_p), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("u", prism_rtl::deref(prism_rtl::deref(x_p1m).span_p).start_p));
                auto then_x_p1o = upd_tail_from_f(lx_p0, crate::lower::expr::bind_all_f(env_p2, prism_rtl::deref(po_p1n).binds_p), crate::lower::expr::bind_all_f(env_p2, prism_rtl::deref(po_p1n).binds_p), then_b_p4, Nat(0u), then_b_p4.span_p, ({
                    auto f = to_k_fl;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=, f = std::move(f)](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
                    auto&& a0 = std::get<0>(_p0);
                    auto&& a1 = std::get<1>(_p0);
                    return ({
                        auto fy = f;
                        (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0, a1)); }));
                    });
                })));
                }));
                (crate::lower::types::own_f(crate::lower::expr::arms_value_f(crate::lower::types::own_f(crate::lower::expr::value_of_f(lx_p0, env_p2, prism_rtl::deref(prism_rtl::deref(x_p1m)))), Array(std::vector{crate::lower::model::XArm{.pat_p = prism_rtl::deref(po_p1n).pa_p, .conds_p = prism_rtl::deref(po_p1n).conds_p, .body_p = then_x_p1o}, crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = else_x_pn}}), prism_rtl::cat("\'u", prism_rtl::deref(prism_rtl::deref(x_p1m).span_p).start_p), crate::lower::model::OutTy(crate::lower::model::OutTy::OutTurn{}))));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prepend_f(crate::prelude::push(out_dos_pg, k_do_pk), choose_po);
}


prism_rtl::Turn<crate::lower::model::Ex> IfJob::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& outer_p1 = this->outer_p1;
    const auto& env_p2 = this->env_p2;
    const auto& c_p3 = this->c_p3;
    const auto& then_b_p4 = this->then_b_p4;
    const auto& else_b_o5 = this->else_b_o5;
    const auto& span_p6 = this->span_p6;
    const auto& rest_text_p7 = this->rest_text_p7;
    const auto& cont_f8 = this->cont_f8;
    auto state_p9 = crate::prelude::fold(crate::prelude::keys(prism_rtl::deref(env_p2).names_p), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc_pp, const Text& k_pq) {
        return !crate::syntax::lexer::chars::has_prefix_f(k_pq, Text::lit("&"))
            ? acc_pp
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p2).names_p, k_pq);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_pr = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt_ps = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc_pp, std::tuple{k_pq, crate::lower::types::place_stem_f(rs_pr), bt_ps}));
                goto _done;
            }
            {
                _v.set(acc_pp);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names_pa = crate::prelude::each(state_p9, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs_pt = std::get<1>(_p0);
        return rs_pt;
    });
    auto st_ty_pb = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{crate::prelude::each(state_p9, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt_pu = std::get<2>(_p0);
        return bt_pu;
    })});
    auto pat_pc = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{crate::prelude::each(names_pa, [&](const Text& n_pv) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n_pv)}); })});
    auto pack_pd = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{crate::prelude::each(names_pa, [&](const Text& n_p10) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n_p10}); })});
    auto env_s_pe = crate::prelude::fold(state_p9, env_p2, [&](const crate::lower::types::Env& en_p11, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k_p12 = std::get<0>(_p1);
        auto&& rs_p13 = std::get<1>(_p1);
        auto&& bt_p14 = std::get<2>(_p1);
        return crate::lower::types::bind_f(en_p11, k_p12, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_p13}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p14}));
    });
    auto out_caps_pf = caps_in_f(outer_p1, rest_text_p7, names_pa);
    auto out_dos_pg = crate::prelude::each(out_caps_pf, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs_p15 = std::get<1>(_p0);
        auto&& mode_p16 = std::get<2>(_p0);
        auto&& bt_p17 = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::expr::outer_name_f(rs_p15)}), crate::lower::types::own_f(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs_p15, mode_p16, bt_p17}))});
    });
    auto outer2_ph = crate::prelude::fold(out_caps_pf, outer_p1, [&](const crate::lower::types::Env& en_p18, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k_p19 = std::get<0>(_p1);
        auto&& rs_p1a = std::get<1>(_p1);
        auto&& bt_p1b = std::get<3>(_p1);
        return crate::lower::types::bind_f(en_p18, k_p19, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::outer_name_f(rs_p1a)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p1b}));
    });
    auto env2_pi = crate::prelude::fold(out_caps_pf, env_s_pe, [&](const crate::lower::types::Env& en_p1c, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k_p1d = std::get<0>(_p1);
        auto&& rs_p1e = std::get<1>(_p1);
        auto&& bt_p1f = std::get<3>(_p1);
        return crate::lower::types::bind_f(en_p1c, k_p1d, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::outer_name_f(rs_p1e)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p1f}));
    });
    auto k_name_pj = prism_rtl::cat("k_if", prism_rtl::deref(span_p6).start_p);
    auto else_b_o5x = else_b_o5;
    auto cont_f8x = cont_f8;
    auto c_p3x = c_p3;
    auto env_p2x = env_p2;
    auto lx_p0x = lx_p0;
    auto span_p6x = span_p6;
    auto then_b_p4x = then_b_p4;
    return crate::prelude::call_value(cont_f8x(std::tuple{outer2_ph, env2_pi}), [=](crate::lower::model::Ex cont_15159) {
        return ({
            auto k_do_pk = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{k_name_pj}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat_pc), st_ty_pb})}), prism_rtl::rc(cont_15159)})});
            auto to_k_fl = ({
                auto k_name_pjx = k_name_pj;
                auto pack_pdx = pack_pd;
                (static_cast<Fn<crate::lower::model::Ex(const crate::lower::types::Env&, const crate::lower::model::Ex&)>>(prism_rtl::rc([=, k_name_pjx = std::move(k_name_pjx), pack_pdx = std::move(pack_pdx)](const crate::lower::types::Env& o2_p1g, const crate::lower::model::Ex& e2_p1h) { return crate::lower::model::Ex(crate::lower::model::Ex::XCall{k_name_pjx, Array(std::vector{pack_pdx})}); })));
            });
            auto branch_fm = ({
                auto lx_p0xx = lx_p0x;
                auto env_p2xx = env_p2x;
                auto to_k_flx = to_k_fl;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Block)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), env_p2xx = std::move(env_p2xx), to_k_flx = std::move(to_k_flx)](crate::syntax::Block p0) {
                return ({
                    auto lx_p0xxy = lx_p0xx;
                    auto env_p2xxy = env_p2xx;
                    auto to_k_flxy = to_k_flx;
                    (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), env_p2xxy = std::move(env_p2xxy), to_k_flxy = std::move(to_k_flxy)]() {
                    return ({
                        auto b_p1i = p0;
                        (prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_p0xxy, env_p2xxy, env_p2xxy, b_p1i, Nat(0u), prism_rtl::deref(b_p1i).span_p, ({
                        auto f = to_k_flxy;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=, f = std::move(f)](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
                        auto&& a0 = std::get<0>(_p0);
                        auto&& a1 = std::get<1>(_p0);
                        return ({
                            auto fy = f;
                            (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0, a1)); }));
                        });
                    })));
                    })))));
                    });
                })));
                });
            })));
            });
            auto else_x_pn = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::Ex> _v;
                if (prism_rtl::is_some(else_b_o5x)) {
                    auto&& eb_p1j = prism_rtl::some_of(else_b_o5x);
                    _v.set(crate::prelude::run_to_end(branch_fm(eb_p1j)));
                    goto _done;
                }
                if (prism_rtl::is_none(else_b_o5x)) {
                    _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCall{k_name_pj, Array(std::vector{pack_pd})}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto choose_po = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::Ex> _v;
                if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p3x)) {
                    auto&& x_p1k = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p3x).a0;
                    _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(crate::lower::types::as_bool_f(crate::lower::expr::value_of_f(lx_p0x, env_p2x, prism_rtl::deref(prism_rtl::deref(x_p1k))))), prism_rtl::rc(crate::prelude::run_to_end(branch_fm(then_b_p4x))), prism_rtl::rc(else_x_pn)}));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::Cond::CondBind>(c_p3x)) {
                    auto&& p_p1l = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p3x).a0;
                    auto&& x_p1m = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p3x).a1;
                    _v.set(({
                        auto po_p1n = crate::lower::patterns::rust_pat_f(lx_p0x, p_p1l, crate::lower::type_at_f(lx_p0x, prism_rtl::deref(x_p1m).span_p), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("u", prism_rtl::deref(prism_rtl::deref(x_p1m).span_p).start_p));
                        auto then_x_p1o = upd_tail_from_f(lx_p0x, crate::lower::expr::bind_all_f(env_p2x, prism_rtl::deref(po_p1n).binds_p), crate::lower::expr::bind_all_f(env_p2x, prism_rtl::deref(po_p1n).binds_p), then_b_p4x, Nat(0u), prism_rtl::deref(then_b_p4x).span_p, ({
                            auto f = to_k_fl;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=, f = std::move(f)](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
                            auto&& a0 = std::get<0>(_p0);
                            auto&& a1 = std::get<1>(_p0);
                            return ({
                                auto fy = f;
                                (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0, a1)); }));
                            });
                        })));
                        }));
                        (crate::lower::types::own_f(crate::lower::expr::arms_value_f(crate::lower::types::own_f(crate::lower::expr::value_of_f(lx_p0x, env_p2x, prism_rtl::deref(prism_rtl::deref(x_p1m)))), Array(std::vector{crate::lower::model::XArm{.pat_p = prism_rtl::deref(po_p1n).pa_p, .conds_p = prism_rtl::deref(po_p1n).conds_p, .body_p = then_x_p1o}, crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = else_x_pn}}), prism_rtl::cat("\'u", prism_rtl::deref(prism_rtl::deref(x_p1m).span_p).start_p), crate::lower::model::OutTy(crate::lower::model::OutTy::OutTurn{}))));
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(prepend_f(crate::prelude::push(out_dos_pg, k_do_pk), choose_po)));
        });
    });
}


/// `Start IfJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_if_job_f(crate::lower::Lx lx_p0, crate::lower::types::Env outer_p1, crate::lower::types::Env env_p2, crate::syntax::Cond c_p3, crate::syntax::Block then_b_p4, std::optional<crate::syntax::Block> else_b_o5, crate::syntax::Range span_p6, Text rest_text_p7, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_f8) {
    return prism_rtl::make_rc<IfJob>(lx_p0, outer_p1, env_p2, c_p3, then_b_p4, else_b_o5, span_p6, rest_text_p7, cont_f8);
}


/// MatchJob: unbounded fn Lx, Env, Env, Expr, [Arm], Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
crate::lower::model::Ex match_job_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& outer_p1, const crate::lower::types::Env& env_p2, const crate::syntax::Expr& scrut_p3, const Array<crate::syntax::Arm>& arms_p4, const crate::syntax::Range& span_p5, const Text& rest_text_p6, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>& cont_f7) {
    auto state_p8 = crate::prelude::fold(crate::prelude::keys(env_p2.names_p), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc_pn, const Text& k_po) {
        return !crate::syntax::lexer::chars::has_prefix_f(k_po, Text::lit("&"))
            ? acc_pn
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env_p2.names_p, k_po);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_pp = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt_pq = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc_pn, std::tuple{k_po, crate::lower::types::place_stem_f(rs_pp), bt_pq}));
                goto _done;
            }
            {
                _v.set(acc_pn);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names_p9 = crate::prelude::each(state_p8, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs_pr = std::get<1>(_p0);
        return rs_pr;
    });
    auto st_ty_pa = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{crate::prelude::each(state_p8, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt_ps = std::get<2>(_p0);
        return bt_ps;
    })});
    auto pat_pb = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{crate::prelude::each(names_p9, [&](const Text& n_pt) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n_pt)}); })});
    auto pack_pc = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{crate::prelude::each(names_p9, [&](const Text& n_pu) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n_pu}); })});
    auto env_s_pd = crate::prelude::fold(state_p8, env_p2, [&](const crate::lower::types::Env& en_pv, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k_p10 = std::get<0>(_p1);
        auto&& rs_p11 = std::get<1>(_p1);
        auto&& bt_p12 = std::get<2>(_p1);
        return crate::lower::types::bind_f(en_pv, k_p10, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_p11}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p12}));
    });
    auto out_caps_pe = caps_in_f(outer_p1, rest_text_p6, names_p9);
    auto out_dos_pf = crate::prelude::each(out_caps_pe, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs_p13 = std::get<1>(_p0);
        auto&& mode_p14 = std::get<2>(_p0);
        auto&& bt_p15 = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::expr::outer_name_f(rs_p13)}), crate::lower::types::own_f(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs_p13, mode_p14, bt_p15}))});
    });
    auto outer2_pg = crate::prelude::fold(out_caps_pe, outer_p1, [&](const crate::lower::types::Env& en_p16, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k_p17 = std::get<0>(_p1);
        auto&& rs_p18 = std::get<1>(_p1);
        auto&& bt_p19 = std::get<3>(_p1);
        return crate::lower::types::bind_f(en_p16, k_p17, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::outer_name_f(rs_p18)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p19}));
    });
    auto env2_ph = crate::prelude::fold(out_caps_pe, env_s_pd, [&](const crate::lower::types::Env& en_p1a, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k_p1b = std::get<0>(_p1);
        auto&& rs_p1c = std::get<1>(_p1);
        auto&& bt_p1d = std::get<3>(_p1);
        return crate::lower::types::bind_f(en_p1a, k_p1b, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::outer_name_f(rs_p1c)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p1d}));
    });
    auto k_name_pi = prism_rtl::cat("k_match", span_p5.start_p);
    auto k_do_pj = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{k_name_pi}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat_pb), st_ty_pa})}), prism_rtl::rc(crate::prelude::run_to_end(cont_f7(std::tuple{outer2_pg, env2_ph})))})});
    auto to_k_fk = ({
        auto k_name_pix = k_name_pi;
        auto pack_pcx = pack_pc;
        (static_cast<Fn<crate::lower::model::Ex(const crate::lower::types::Env&, const crate::lower::model::Ex&)>>(prism_rtl::rc([=, k_name_pix = std::move(k_name_pix), pack_pcx = std::move(pack_pcx)](const crate::lower::types::Env& o2_p1e, const crate::lower::model::Ex& e2_p1f) { return crate::lower::model::Ex(crate::lower::model::Ex::XCall{k_name_pix, Array(std::vector{pack_pcx})}); })));
    });
    auto sty_pl = crate::lower::type_at_f(lx_p0, scrut_p3.span_p);
    auto xarms_pm = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(arms_p4)), ({
        auto arms_p4x = arms_p4;
        auto lx_p0x = lx_p0;
        auto sty_plx = sty_pl;
        auto scrut_p3x = scrut_p3;
        auto env_p2x = env_p2;
        auto to_k_fkx = to_k_fk;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=, arms_p4x = std::move(arms_p4x), lx_p0x = std::move(lx_p0x), sty_plx = std::move(sty_plx), scrut_p3x = std::move(scrut_p3x), env_p2x = std::move(env_p2x), to_k_fkx = std::move(to_k_fkx)](Nat p0) {
        return ({
            auto arms_p4xy = arms_p4x;
            auto lx_p0xy = lx_p0x;
            auto sty_plxy = sty_plx;
            auto scrut_p3xy = scrut_p3x;
            auto env_p2xy = env_p2x;
            auto to_k_fkxy = to_k_fkx;
            (crate::prelude::entered(crate::prelude::once_job([=, arms_p4xy = std::move(arms_p4xy), lx_p0xy = std::move(lx_p0xy), sty_plxy = std::move(sty_plxy), scrut_p3xy = std::move(scrut_p3xy), env_p2xy = std::move(env_p2xy), to_k_fkxy = std::move(to_k_fkxy)]() {
            return ({
                auto i_p1g = p0;
                ({
                auto arm_p1h = crate::prelude::or_(crate::prelude::index(arms_p4xy, i_p1g), crate::lower::expr::dummy_arm_p());
                (crate::prelude::call_then(crate::lower::expr::start_arm_pat_f(lx_p0xy, prism_rtl::deref(arm_p1h).pattern_o, sty_plxy, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("u", prism_rtl::deref(prism_rtl::deref(scrut_p3xy).span_p).start_p, "_", i_p1g)), [=](crate::lower::patterns::PatOut arm_pat_f_17706) {
                return ({
                    auto po_p1i = arm_pat_f_17706;
                    auto env_a_p1j = crate::lower::expr::bind_all_f(env_p2xy, prism_rtl::deref(po_p1i).binds_p);
                    (crate::prelude::call_then(crate::lower::templates::start_guard_conds_f(lx_p0xy, env_a_p1j, prism_rtl::deref(arm_p1h).guard_o), [=, po_p1i = std::move(po_p1i)](Array<crate::lower::model::Cc> guard_conds_f_17850) {
                    return ({
                        auto guarded_p1k = crate::prelude::append(prism_rtl::deref(po_p1i).conds_p, guard_conds_f_17850);
                        (crate::prelude::call_then(start_upd_tail_from_f(lx_p0xy, env_a_p1j, env_a_p1j, prism_rtl::deref(arm_p1h).body_p, Nat(0u), prism_rtl::deref(prism_rtl::deref(arm_p1h).body_p).span_p, ({
                        auto f = to_k_fkxy;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=, f = std::move(f)](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
                        auto&& a0 = std::get<0>(_p0);
                        auto&& a1 = std::get<1>(_p0);
                        return ({
                            auto fy = f;
                            (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0, a1)); }));
                        });
                    })));
                    })), [=, guarded_p1k = std::move(guarded_p1k)](crate::lower::model::Ex upd_tail_from_f_17928) { return prism_rtl::finished(crate::lower::model::XArm{.pat_p = prism_rtl::deref(po_p1i).pa_p, .conds_p = guarded_p1k, .body_p = upd_tail_from_f_17928}); }));
                    });
                }));
                });
            }));
            });
            });
        })));
        });
    })));
    })));
    return prepend_f(crate::prelude::push(out_dos_pf, k_do_pj), crate::lower::types::own_f(crate::lower::expr::arms_value_f(crate::lower::types::own_f(crate::lower::expr::value_of_f(lx_p0, env_p2, scrut_p3)), xarms_pm, prism_rtl::cat("\'u", prism_rtl::deref(scrut_p3.span_p).start_p), crate::lower::model::OutTy(crate::lower::model::OutTy::OutTurn{}))));
}


prism_rtl::Turn<crate::lower::model::Ex> MatchJob::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& outer_p1 = this->outer_p1;
    const auto& env_p2 = this->env_p2;
    const auto& scrut_p3 = this->scrut_p3;
    const auto& arms_p4 = this->arms_p4;
    const auto& span_p5 = this->span_p5;
    const auto& rest_text_p6 = this->rest_text_p6;
    const auto& cont_f7 = this->cont_f7;
    auto state_p8 = crate::prelude::fold(crate::prelude::keys(prism_rtl::deref(env_p2).names_p), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc_pn, const Text& k_po) {
        return !crate::syntax::lexer::chars::has_prefix_f(k_po, Text::lit("&"))
            ? acc_pn
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p2).names_p, k_po);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_pp = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt_pq = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc_pn, std::tuple{k_po, crate::lower::types::place_stem_f(rs_pp), bt_pq}));
                goto _done;
            }
            {
                _v.set(acc_pn);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names_p9 = crate::prelude::each(state_p8, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs_pr = std::get<1>(_p0);
        return rs_pr;
    });
    auto st_ty_pa = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{crate::prelude::each(state_p8, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt_ps = std::get<2>(_p0);
        return bt_ps;
    })});
    auto pat_pb = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{crate::prelude::each(names_p9, [&](const Text& n_pt) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n_pt)}); })});
    auto pack_pc = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{crate::prelude::each(names_p9, [&](const Text& n_pu) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n_pu}); })});
    auto env_s_pd = crate::prelude::fold(state_p8, env_p2, [&](const crate::lower::types::Env& en_pv, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k_p10 = std::get<0>(_p1);
        auto&& rs_p11 = std::get<1>(_p1);
        auto&& bt_p12 = std::get<2>(_p1);
        return crate::lower::types::bind_f(en_pv, k_p10, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_p11}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p12}));
    });
    auto out_caps_pe = caps_in_f(outer_p1, rest_text_p6, names_p9);
    auto out_dos_pf = crate::prelude::each(out_caps_pe, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs_p13 = std::get<1>(_p0);
        auto&& mode_p14 = std::get<2>(_p0);
        auto&& bt_p15 = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::expr::outer_name_f(rs_p13)}), crate::lower::types::own_f(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs_p13, mode_p14, bt_p15}))});
    });
    auto outer2_pg = crate::prelude::fold(out_caps_pe, outer_p1, [&](const crate::lower::types::Env& en_p16, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k_p17 = std::get<0>(_p1);
        auto&& rs_p18 = std::get<1>(_p1);
        auto&& bt_p19 = std::get<3>(_p1);
        return crate::lower::types::bind_f(en_p16, k_p17, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::outer_name_f(rs_p18)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p19}));
    });
    auto env2_ph = crate::prelude::fold(out_caps_pe, env_s_pd, [&](const crate::lower::types::Env& en_p1a, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k_p1b = std::get<0>(_p1);
        auto&& rs_p1c = std::get<1>(_p1);
        auto&& bt_p1d = std::get<3>(_p1);
        return crate::lower::types::bind_f(en_p1a, k_p1b, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::outer_name_f(rs_p1c)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p1d}));
    });
    auto k_name_pi = prism_rtl::cat("k_match", prism_rtl::deref(span_p5).start_p);
    auto cont_f7x = cont_f7;
    auto arms_p4x = arms_p4;
    auto env_p2x = env_p2;
    auto lx_p0x = lx_p0;
    auto scrut_p3x = scrut_p3;
    auto span_p5x = span_p5;
    return crate::prelude::call_value(cont_f7x(std::tuple{outer2_pg, env2_ph}), [=](crate::lower::model::Ex cont_17501) {
        return ({
            auto k_do_pj = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{k_name_pi}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat_pb), st_ty_pa})}), prism_rtl::rc(cont_17501)})});
            auto to_k_fk = ({
                auto k_name_pix = k_name_pi;
                auto pack_pcx = pack_pc;
                (static_cast<Fn<crate::lower::model::Ex(const crate::lower::types::Env&, const crate::lower::model::Ex&)>>(prism_rtl::rc([=, k_name_pix = std::move(k_name_pix), pack_pcx = std::move(pack_pcx)](const crate::lower::types::Env& o2_p1e, const crate::lower::model::Ex& e2_p1f) { return crate::lower::model::Ex(crate::lower::model::Ex::XCall{k_name_pix, Array(std::vector{pack_pcx})}); })));
            });
            auto sty_pl = crate::lower::type_at_f(lx_p0x, prism_rtl::deref(scrut_p3x).span_p);
            (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(arms_p4x)), ({
            auto arms_p4xx = arms_p4x;
            auto lx_p0xx = lx_p0x;
            auto sty_plx = sty_pl;
            auto scrut_p3xx = scrut_p3x;
            auto env_p2xx = env_p2x;
            auto to_k_fkx = to_k_fk;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=, arms_p4xx = std::move(arms_p4xx), lx_p0xx = std::move(lx_p0xx), sty_plx = std::move(sty_plx), scrut_p3xx = std::move(scrut_p3xx), env_p2xx = std::move(env_p2xx), to_k_fkx = std::move(to_k_fkx)](Nat p0) {
            return ({
                auto arms_p4xxy = arms_p4xx;
                auto lx_p0xxy = lx_p0xx;
                auto sty_plxy = sty_plx;
                auto scrut_p3xxy = scrut_p3xx;
                auto env_p2xxy = env_p2xx;
                auto to_k_fkxy = to_k_fkx;
                (crate::prelude::entered(crate::prelude::once_job([=, arms_p4xxy = std::move(arms_p4xxy), lx_p0xxy = std::move(lx_p0xxy), sty_plxy = std::move(sty_plxy), scrut_p3xxy = std::move(scrut_p3xxy), env_p2xxy = std::move(env_p2xxy), to_k_fkxy = std::move(to_k_fkxy)]() {
                return ({
                    auto i_p1g = p0;
                    ({
                    auto arm_p1h = crate::prelude::or_(crate::prelude::index(arms_p4xxy, i_p1g), crate::lower::expr::dummy_arm_p());
                    (crate::prelude::call_then(crate::lower::expr::start_arm_pat_f(lx_p0xxy, prism_rtl::deref(arm_p1h).pattern_o, sty_plxy, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("u", prism_rtl::deref(prism_rtl::deref(scrut_p3xxy).span_p).start_p, "_", i_p1g)), [=](crate::lower::patterns::PatOut arm_pat_f_17706) {
                    return ({
                        auto po_p1i = arm_pat_f_17706;
                        auto env_a_p1j = crate::lower::expr::bind_all_f(env_p2xxy, prism_rtl::deref(po_p1i).binds_p);
                        (crate::prelude::call_then(crate::lower::templates::start_guard_conds_f(lx_p0xxy, env_a_p1j, prism_rtl::deref(arm_p1h).guard_o), [=, po_p1i = std::move(po_p1i)](Array<crate::lower::model::Cc> guard_conds_f_17850) {
                        return ({
                            auto guarded_p1k = crate::prelude::append(prism_rtl::deref(po_p1i).conds_p, guard_conds_f_17850);
                            (crate::prelude::call_then(start_upd_tail_from_f(lx_p0xxy, env_a_p1j, env_a_p1j, prism_rtl::deref(arm_p1h).body_p, Nat(0u), prism_rtl::deref(prism_rtl::deref(arm_p1h).body_p).span_p, ({
                            auto f = to_k_fkxy;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=, f = std::move(f)](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
                            auto&& a0 = std::get<0>(_p0);
                            auto&& a1 = std::get<1>(_p0);
                            return ({
                                auto fy = f;
                                (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0, a1)); }));
                            });
                        })));
                        })), [=, guarded_p1k = std::move(guarded_p1k)](crate::lower::model::Ex upd_tail_from_f_17928) { return prism_rtl::finished(crate::lower::model::XArm{.pat_p = prism_rtl::deref(po_p1i).pa_p, .conds_p = guarded_p1k, .body_p = upd_tail_from_f_17928}); }));
                        });
                    }));
                    });
                }));
                });
                });
            })));
            });
        })));
        })), [=, k_do_pj = std::move(k_do_pj)](Array<crate::lower::model::XArm> each_17619) {
            return ({
                auto xarms_pm = each_17619;
                (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p2x, scrut_p3x), [=, xarms_pm = std::move(xarms_pm)](crate::lower::types::Vl value_of_f_18044) { return prism_rtl::finished(prepend_f(crate::prelude::push(out_dos_pf, k_do_pj), crate::lower::types::own_f(crate::lower::expr::arms_value_f(crate::lower::types::own_f(value_of_f_18044), xarms_pm, prism_rtl::cat("\'u", prism_rtl::deref(prism_rtl::deref(scrut_p3x).span_p).start_p), crate::lower::model::OutTy(crate::lower::model::OutTy::OutTurn{}))))); }));
            });
        }));
        });
    });
}


/// `Start MatchJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_match_job_f(crate::lower::Lx lx_p0, crate::lower::types::Env outer_p1, crate::lower::types::Env env_p2, crate::syntax::Expr scrut_p3, Array<crate::syntax::Arm> arms_p4, crate::syntax::Range span_p5, Text rest_text_p6, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_f7) {
    return prism_rtl::make_rc<MatchJob>(lx_p0, outer_p1, env_p2, scrut_p3, arms_p4, span_p5, rest_text_p6, cont_f7);
}


/// ForJob: unbounded fn Lx, Env, Env, ?ForBinders, Expr, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
crate::lower::model::Ex for_job_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& outer_p1, const crate::lower::types::Env& env_p2, const std::optional<crate::syntax::ForBinders>& binders_o3, const crate::syntax::Expr& source_p4, const crate::syntax::Block& body_p5, const crate::syntax::Range& span_p6, const Text& rest_text_p7, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>& cont_f8) {
    auto state_p9 = crate::prelude::fold(crate::prelude::keys(env_p2.names_p), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc_p11, const Text& k_p12) {
        return !crate::syntax::lexer::chars::has_prefix_f(k_p12, Text::lit("&"))
            ? acc_p11
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env_p2.names_p, k_p12);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_p13 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt_p14 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc_p11, std::tuple{k_p12, crate::lower::types::place_stem_f(rs_p13), bt_p14}));
                goto _done;
            }
            {
                _v.set(acc_p11);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names_pa = crate::prelude::each(state_p9, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs_p15 = std::get<1>(_p0);
        return rs_p15;
    });
    auto st_ty_pb = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{crate::prelude::each(state_p9, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt_p16 = std::get<2>(_p0);
        return bt_p16;
    })});
    auto pat_pc = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{crate::prelude::each(names_pa, [&](const Text& n_p17) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n_p17)}); })});
    auto pack_pd = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{crate::prelude::each(names_pa, [&](const Text& n_p18) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n_p18}); })});
    auto env_s_pe = crate::prelude::fold(state_p9, env_p2, [&](const crate::lower::types::Env& en_p19, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k_p1a = std::get<0>(_p1);
        auto&& rs_p1b = std::get<1>(_p1);
        auto&& bt_p1c = std::get<2>(_p1);
        return crate::lower::types::bind_f(en_p19, k_p1a, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_p1b}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p1c}));
    });
    auto src_pf = crate::lower::types::own_f(crate::lower::expr::value_of_f(lx_p0, env_p2, source_p4));
    auto sty_pg = crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, source_p4.span_p));
    auto [kt_p1g, vt_p1h, is_array_p1i] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy, bool>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty_pg)) {
            auto&& v_p1d = prism_rtl::as<crate::check::types::Ty::TyArray>(sty_pg).a0;
            _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}), crate::lower::types::out_ty_of_f(lx_p0, prism_rtl::deref(prism_rtl::deref(v_p1d))), true});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty_pg)) {
            auto&& k_p1e = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_pg).a0;
            auto&& v_p1f = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_pg).a1;
            _v.set(std::tuple{crate::lower::types::out_ty_of_f(lx_p0, prism_rtl::deref(prism_rtl::deref(k_p1e))), crate::lower::types::out_ty_of_f(lx_p0, prism_rtl::deref(prism_rtl::deref(v_p1f))), false});
            goto _done;
        }
        {
            _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), true});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [vty_p1m, kty_p1n] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::Ty>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty_pg)) {
            auto&& v_p1j = prism_rtl::as<crate::check::types::Ty::TyArray>(sty_pg).a0;
            _v.set(std::tuple{prism_rtl::deref(prism_rtl::deref(v_p1j)), crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Nat"), Array<crate::check::types::Ty>{}})});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty_pg)) {
            auto&& k_p1k = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_pg).a0;
            auto&& v_p1l = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_pg).a1;
            _v.set(std::tuple{prism_rtl::deref(prism_rtl::deref(v_p1l)), prism_rtl::deref(prism_rtl::deref(k_p1k))});
            goto _done;
        }
        {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto key_name_ph = prism_rtl::cat("k", span_p6.start_p);
    auto val_name_pi = prism_rtl::cat("v", span_p6.start_p);
    auto loop_text_pj = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::prelude::index(prism_rtl::deref(lx_p0.g_p).srcs_p, lx_p0.file_p);
        if (prism_rtl::is_some(_m)) {
            auto&& src2_p1o = prism_rtl::some_of(_m);
            _v.set(crate::check::errors::span_text_f(src2_p1o, span_p6));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto caps_pk = caps_in_f(env_s_pe, loop_text_pj, names_pa);
    auto cap_dos_pl = crate::prelude::each(caps_pk, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs_p1p = std::get<1>(_p0);
        auto&& mode_p1q = std::get<2>(_p0);
        auto&& bt_p1r = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::expr::capture_name_f(rs_p1p)}), crate::lower::types::own_f(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs_p1p, mode_p1q, bt_p1r}))});
    });
    auto env_c_pm = crate::prelude::fold(caps_pk, env_s_pe, [&](const crate::lower::types::Env& en_p1s, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k_p1t = std::get<0>(_p1);
        auto&& rs_p1u = std::get<1>(_p1);
        auto&& bt_p1v = std::get<3>(_p1);
        return crate::lower::types::bind_f(en_p1s, k_p1t, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::capture_name_f(rs_p1u)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p1v}));
    });
    auto env1_pn = crate::lower::types::bind_f(crate::lower::types::bind_f(env_c_pm, Text::lit("key"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_ph}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt_p1g})), Text::lit("_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name_pi}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), vt_p1h}));
    auto env_k_po = is_array_p1i
        ? crate::lower::types::bind_f(env1_pn, Text::lit("ix"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_ph}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt_p1g}))
        : env1_pn;
    auto [binds_p25, env_b_p26] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
        if (prism_rtl::is_none(binders_o3)) {
            _v.set(std::tuple{Array<crate::lower::model::Do>{}, env_k_po});
            goto _done;
        }
        if (prism_rtl::is_some(binders_o3)) {
            auto&& fb_p20 = prism_rtl::some_of(binders_o3);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                auto&& _m = prism_rtl::deref(fb_p20).second_o;
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto po_p21 = crate::lower::patterns::rust_pat_f(lx_p0, prism_rtl::deref(fb_p20).first_p, vty_p1m, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("e", span_p6.start_p));
                        std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(po_p21).pa_p, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name_pi}))})})}), crate::lower::expr::bind_all_f(env_k_po, prism_rtl::deref(po_p21).binds_p)};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_some(_m)) {
                    auto&& second_p22 = prism_rtl::some_of(_m);
                    _v.set(({
                        auto pk_p23 = crate::lower::patterns::rust_pat_f(lx_p0, prism_rtl::deref(fb_p20).first_p, kty_p1n, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("k", span_p6.start_p, "_"));
                        auto pv_p24 = crate::lower::patterns::rust_pat_f(lx_p0, second_p22, vty_p1m, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("e", span_p6.start_p));
                        std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(pk_p23).pa_p, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_ph}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(pv_p24).pa_p, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name_pi}))})})}), crate::lower::expr::bind_all_f(crate::lower::expr::bind_all_f(env_k_po, prism_rtl::deref(pk_p23).binds_p), prism_rtl::deref(pv_p24).binds_p)};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto turn_pp = prepend_f(binds_p25, upd_tail_from_f(lx_p0, env_b_p26, env_b_p26, body_p5, Nat(0u), body_p5.span_p, ({
        auto pack_pdx = pack_pd;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=, pack_pdx = std::move(pack_pdx)](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto pack_pdxy = pack_pdx;
            (crate::prelude::once_job([=, pack_pdxy = std::move(pack_pdxy)]() {
            return ({
                auto o2_p27 = p0;
                auto e2_p28 = p1;
                (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{pack_pdxy})})));
            });
        }));
        });
    })));
    })));
    auto step_fn_pq = prepend_f(cap_dos_pl, crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat_pc), st_ty_pb}), crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name_ph})), kt_p1g}), crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name_pi})), vt_p1h})}), prism_rtl::rc(turn_pp)}));
    auto out_caps_pr = caps_in_f(outer_p1, rest_text_p7, names_pa);
    auto out_dos_ps = crate::prelude::each(out_caps_pr, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs_p29 = std::get<1>(_p0);
        auto&& mode_p2a = std::get<2>(_p0);
        auto&& bt_p2b = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::expr::outer_name_f(rs_p29)}), crate::lower::types::own_f(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs_p29, mode_p2a, bt_p2b}))});
    });
    auto outer2_pt = crate::prelude::fold(out_caps_pr, outer_p1, [&](const crate::lower::types::Env& en_p2c, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k_p2d = std::get<0>(_p1);
        auto&& rs_p2e = std::get<1>(_p1);
        auto&& bt_p2f = std::get<3>(_p1);
        return crate::lower::types::bind_f(en_p2c, k_p2d, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::outer_name_f(rs_p2e)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p2f}));
    });
    auto env2_pu = crate::prelude::fold(out_caps_pr, env_s_pe, [&](const crate::lower::types::Env& en_p2g, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k_p2h = std::get<0>(_p1);
        auto&& rs_p2i = std::get<1>(_p1);
        auto&& bt_p2j = std::get<3>(_p1);
        return crate::lower::types::bind_f(en_p2g, k_p2h, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::outer_name_f(rs_p2i)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p2j}));
    });
    auto looping_pv = is_array_p1i
        ? Text::lit("for_turns_indexed")
        : Text::lit("for_turns_keyed");
    auto enter_p10 = crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("call_then")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{looping_pv, Array(std::vector{src_pf, pack_pd, step_fn_pq})}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat_pc), st_ty_pb})}), prism_rtl::rc(crate::prelude::run_to_end(cont_f8(std::tuple{outer2_pt, env2_pu})))})})});
    return prepend_f(out_dos_ps, enter_p10);
}


prism_rtl::Turn<crate::lower::model::Ex> ForJob::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& outer_p1 = this->outer_p1;
    const auto& env_p2 = this->env_p2;
    const auto& binders_o3 = this->binders_o3;
    const auto& source_p4 = this->source_p4;
    const auto& body_p5 = this->body_p5;
    const auto& span_p6 = this->span_p6;
    const auto& rest_text_p7 = this->rest_text_p7;
    const auto& cont_f8 = this->cont_f8;
    auto state_p9 = crate::prelude::fold(crate::prelude::keys(prism_rtl::deref(env_p2).names_p), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc_p11, const Text& k_p12) {
        return !crate::syntax::lexer::chars::has_prefix_f(k_p12, Text::lit("&"))
            ? acc_p11
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p2).names_p, k_p12);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_p13 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt_p14 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc_p11, std::tuple{k_p12, crate::lower::types::place_stem_f(rs_p13), bt_p14}));
                goto _done;
            }
            {
                _v.set(acc_p11);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names_pa = crate::prelude::each(state_p9, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs_p15 = std::get<1>(_p0);
        return rs_p15;
    });
    auto st_ty_pb = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{crate::prelude::each(state_p9, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt_p16 = std::get<2>(_p0);
        return bt_p16;
    })});
    auto pat_pc = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{crate::prelude::each(names_pa, [&](const Text& n_p17) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n_p17)}); })});
    auto pack_pd = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{crate::prelude::each(names_pa, [&](const Text& n_p18) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n_p18}); })});
    auto env_s_pe = crate::prelude::fold(state_p9, env_p2, [&](const crate::lower::types::Env& en_p19, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k_p1a = std::get<0>(_p1);
        auto&& rs_p1b = std::get<1>(_p1);
        auto&& bt_p1c = std::get<2>(_p1);
        return crate::lower::types::bind_f(en_p19, k_p1a, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_p1b}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p1c}));
    });
    auto binders_o3x = binders_o3;
    auto cont_f8x = cont_f8;
    auto body_p5x = body_p5;
    auto env_p2x = env_p2;
    auto lx_p0x = lx_p0;
    auto outer_p1x = outer_p1;
    auto rest_text_p7x = rest_text_p7;
    auto source_p4x = source_p4;
    auto span_p6x = span_p6;
    return crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p2x, source_p4x), [=](crate::lower::types::Vl value_of_f_19261) {
        return ({
            auto src_pf = crate::lower::types::own_f(value_of_f_19261);
            auto sty_pg = crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0x, prism_rtl::deref(source_p4x).span_p));
            auto [kt_p1g, vt_p1h, is_array_p1i] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy, bool>> _v;
                if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty_pg)) {
                    auto&& v_p1d = prism_rtl::as<crate::check::types::Ty::TyArray>(sty_pg).a0;
                    _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}), crate::lower::types::out_ty_of_f(lx_p0x, prism_rtl::deref(prism_rtl::deref(v_p1d))), true});
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty_pg)) {
                    auto&& k_p1e = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_pg).a0;
                    auto&& v_p1f = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_pg).a1;
                    _v.set(std::tuple{crate::lower::types::out_ty_of_f(lx_p0x, prism_rtl::deref(prism_rtl::deref(k_p1e))), crate::lower::types::out_ty_of_f(lx_p0x, prism_rtl::deref(prism_rtl::deref(v_p1f))), false});
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), true});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [vty_p1m, kty_p1n] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::Ty>> _v;
                if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty_pg)) {
                    auto&& v_p1j = prism_rtl::as<crate::check::types::Ty::TyArray>(sty_pg).a0;
                    _v.set(std::tuple{prism_rtl::deref(prism_rtl::deref(v_p1j)), crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Nat"), Array<crate::check::types::Ty>{}})});
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty_pg)) {
                    auto&& k_p1k = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_pg).a0;
                    auto&& v_p1l = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_pg).a1;
                    _v.set(std::tuple{prism_rtl::deref(prism_rtl::deref(v_p1l)), prism_rtl::deref(prism_rtl::deref(k_p1k))});
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto key_name_ph = prism_rtl::cat("k", prism_rtl::deref(span_p6x).start_p);
            auto val_name_pi = prism_rtl::cat("v", prism_rtl::deref(span_p6x).start_p);
            auto loop_text_pj = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = crate::prelude::index(prism_rtl::deref(prism_rtl::deref(lx_p0x).g_p).srcs_p, prism_rtl::deref(lx_p0x).file_p);
                if (prism_rtl::is_some(_m)) {
                    auto&& src2_p1o = prism_rtl::some_of(_m);
                    _v.set(crate::check::errors::span_text_f(src2_p1o, span_p6x));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto caps_pk = caps_in_f(env_s_pe, loop_text_pj, names_pa);
            auto cap_dos_pl = crate::prelude::each(caps_pk, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
                auto&& rs_p1p = std::get<1>(_p0);
                auto&& mode_p1q = std::get<2>(_p0);
                auto&& bt_p1r = std::get<3>(_p0);
                return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::expr::capture_name_f(rs_p1p)}), crate::lower::types::own_f(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs_p1p, mode_p1q, bt_p1r}))});
            });
            auto env_c_pm = crate::prelude::fold(caps_pk, env_s_pe, [&](const crate::lower::types::Env& en_p1s, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
                auto&& k_p1t = std::get<0>(_p1);
                auto&& rs_p1u = std::get<1>(_p1);
                auto&& bt_p1v = std::get<3>(_p1);
                return crate::lower::types::bind_f(en_p1s, k_p1t, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::capture_name_f(rs_p1u)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p1v}));
            });
            auto env1_pn = crate::lower::types::bind_f(crate::lower::types::bind_f(env_c_pm, Text::lit("key"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_ph}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt_p1g})), Text::lit("_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name_pi}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), vt_p1h}));
            auto env_k_po = is_array_p1i
                ? crate::lower::types::bind_f(env1_pn, Text::lit("ix"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_ph}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt_p1g}))
                : env1_pn;
            auto [binds_p25, env_b_p26] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                if (prism_rtl::is_none(binders_o3x)) {
                    _v.set(std::tuple{Array<crate::lower::model::Do>{}, env_k_po});
                    goto _done;
                }
                if (prism_rtl::is_some(binders_o3x)) {
                    auto&& fb_p20 = prism_rtl::some_of(binders_o3x);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                        auto&& _m = prism_rtl::deref(fb_p20).second_o;
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                auto po_p21 = crate::lower::patterns::rust_pat_f(lx_p0x, prism_rtl::deref(fb_p20).first_p, vty_p1m, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("e", prism_rtl::deref(span_p6x).start_p));
                                std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(po_p21).pa_p, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name_pi}))})})}), crate::lower::expr::bind_all_f(env_k_po, prism_rtl::deref(po_p21).binds_p)};
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_some(_m)) {
                            auto&& second_p22 = prism_rtl::some_of(_m);
                            _v.set(({
                                auto pk_p23 = crate::lower::patterns::rust_pat_f(lx_p0x, prism_rtl::deref(fb_p20).first_p, kty_p1n, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("k", prism_rtl::deref(span_p6x).start_p, "_"));
                                auto pv_p24 = crate::lower::patterns::rust_pat_f(lx_p0x, second_p22, vty_p1m, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("e", prism_rtl::deref(span_p6x).start_p));
                                std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(pk_p23).pa_p, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_ph}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(pv_p24).pa_p, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name_pi}))})})}), crate::lower::expr::bind_all_f(crate::lower::expr::bind_all_f(env_k_po, prism_rtl::deref(pk_p23).binds_p), prism_rtl::deref(pv_p24).binds_p)};
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (crate::prelude::call_then(start_upd_tail_from_f(lx_p0x, env_b_p26, env_b_p26, body_p5x, Nat(0u), prism_rtl::deref(body_p5x).span_p, ({
            auto pack_pdx = pack_pd;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=, pack_pdx = std::move(pack_pdx)](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto pack_pdxy = pack_pdx;
                (crate::prelude::once_job([=, pack_pdxy = std::move(pack_pdxy)]() {
                return ({
                    auto o2_p27 = p0;
                    auto e2_p28 = p1;
                    (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{pack_pdxy})})));
                });
            }));
            });
        })));
        })), [=, src_pf = std::move(src_pf), key_name_ph = std::move(key_name_ph), val_name_pi = std::move(val_name_pi), cap_dos_pl = std::move(cap_dos_pl)](crate::lower::model::Ex upd_tail_from_f_21030) {
            return ({
                auto turn_pp = prepend_f(binds_p25, upd_tail_from_f_21030);
                auto step_fn_pq = prepend_f(cap_dos_pl, crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat_pc), st_ty_pb}), crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name_ph})), kt_p1g}), crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name_pi})), vt_p1h})}), prism_rtl::rc(turn_pp)}));
                auto out_caps_pr = caps_in_f(outer_p1x, rest_text_p7x, names_pa);
                auto out_dos_ps = crate::prelude::each(out_caps_pr, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
                    auto&& rs_p29 = std::get<1>(_p0);
                    auto&& mode_p2a = std::get<2>(_p0);
                    auto&& bt_p2b = std::get<3>(_p0);
                    return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::expr::outer_name_f(rs_p29)}), crate::lower::types::own_f(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs_p29, mode_p2a, bt_p2b}))});
                });
                auto outer2_pt = crate::prelude::fold(out_caps_pr, outer_p1x, [&](const crate::lower::types::Env& en_p2c, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
                    auto&& k_p2d = std::get<0>(_p1);
                    auto&& rs_p2e = std::get<1>(_p1);
                    auto&& bt_p2f = std::get<3>(_p1);
                    return crate::lower::types::bind_f(en_p2c, k_p2d, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::outer_name_f(rs_p2e)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p2f}));
                });
                auto env2_pu = crate::prelude::fold(out_caps_pr, env_s_pe, [&](const crate::lower::types::Env& en_p2g, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
                    auto&& k_p2h = std::get<0>(_p1);
                    auto&& rs_p2i = std::get<1>(_p1);
                    auto&& bt_p2j = std::get<3>(_p1);
                    return crate::lower::types::bind_f(en_p2g, k_p2h, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::outer_name_f(rs_p2i)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_p2j}));
                });
                auto looping_pv = is_array_p1i
                    ? Text::lit("for_turns_indexed")
                    : Text::lit("for_turns_keyed");
                (crate::prelude::call_value(cont_f8x(std::tuple{outer2_pt, env2_pu}), [=, step_fn_pq = std::move(step_fn_pq), out_dos_ps = std::move(out_dos_ps), looping_pv = std::move(looping_pv)](crate::lower::model::Ex cont_21887) {
                return ({
                    auto enter_p10 = crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("call_then")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{looping_pv, Array(std::vector{src_pf, pack_pd, step_fn_pq})}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat_pc), st_ty_pb})}), prism_rtl::rc(cont_21887)})})});
                    (prism_rtl::finished(prepend_f(out_dos_ps, enter_p10)));
                });
            }));
            });
        }));
        });
    });
}


/// `Start ForJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_for_job_f(crate::lower::Lx lx_p0, crate::lower::types::Env outer_p1, crate::lower::types::Env env_p2, std::optional<crate::syntax::ForBinders> binders_o3, crate::syntax::Expr source_p4, crate::syntax::Block body_p5, crate::syntax::Range span_p6, Text rest_text_p7, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_f8) {
    return prism_rtl::make_rc<ForJob>(lx_p0, outer_p1, env_p2, binders_o3, source_p4, body_p5, span_p6, rest_text_p7, cont_f8);
}


/// InstanceOf: fn Text -> Text
Text instance_of_f(const Text& k_p0) {
    return crate::prelude::or_(crate::prelude::index(crate::prelude::split_on(k_p0, Text::lit("#inst")), Nat(0u)), k_p0);
}


/// CapsIn: fn Env, Text, [Text] -> [((Text, Ex, Holding, OutTy))]
Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>> caps_in_f(const crate::lower::types::Env& env_p0, const Text& text_p1, const Array<Text>& skip_p2) {
    return crate::prelude::fold(crate::prelude::keys(env_p0.names_p), Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>>& acc_p3, const Text& k_p4) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env_p0.names_p, k_p4);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_p5 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode_p6 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& bt_p7 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set((crate::check::types::has_text_f(skip_p2, crate::lower::types::place_stem_f(rs_p5)) || crate::lower::types::on_self_f(rs_p5)) || (!mentions_f(text_p1, crate::syntax::lexer::chars::drop_prefix_f(instance_of_f(k_p4), crate::check::types::unify::marks_of_f(k_p4))))
                    ? acc_p3
                    : crate::prelude::push(acc_p3, std::tuple{k_p4, rs_p5, mode_p6, bt_p7}));
                goto _done;
            }
            {
                _v.set(acc_p3);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// ?FrameCall: unbounded fn Lx, Env, Expr, Bool -> ?Expr
std::optional<crate::syntax::Expr> frame_call_o(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2, const bool& top_p3) {
    return crate::check::env::has_key_f(env_p1.spans_p, crate::lower::place_key_f(lx_p0, e_p2.span_p))
        ? std::optional<crate::syntax::Expr>{}
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
        auto&& _m = prism_rtl::deref(e_p2.kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
            auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            _v.set(frame_call_o(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p4)), top_p3));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c_p5 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args_p6 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                auto&& _m = first_frame_o(lx_p0, env_p1, crate::prelude::each(args_p6, [&](const crate::syntax::Arg& a_p7) { return prism_rtl::deref(a_p7).value_p; }));
                if (prism_rtl::is_some(_m)) {
                    auto&& x_p8 = prism_rtl::some_of(_m);
                    _v.set(std::optional(x_p8));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(top_p3
                        ? std::optional<crate::syntax::Expr>{}
                        : ({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                        auto&& _m = tail_callee_o(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(c_p5)));
                        if (prism_rtl::is_some(_m)) {
                            _v.set(std::optional(e_p2));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                                auto&& _m = local_job_fn_o(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(c_p5)));
                                if (prism_rtl::is_some(_m)) {
                                    _v.set(std::optional(e_p2));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(({
                                        __label__ _done;
                                        prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                                        auto&& _m = crate::lower::expr::prelude_job_call_o(lx_p0, env_p1, e_p2);
                                        if (prism_rtl::is_some(_m)) {
                                            _v.set(std::optional(e_p2));
                                            goto _done;
                                        }
                                        if (prism_rtl::is_none(_m)) {
                                            _v.set(std::optional<crate::syntax::Expr>{});
                                            goto _done;
                                        }
                                        prism_rtl::unreachable("no arm matched");
                                    _done:
                                        _v.take();
                                    }));
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& x_p9 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            _v.set(frame_call_o(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p9)), false));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& m23055_3_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            if (prism_rtl::is<crate::syntax::Cond::CondExpr>(prism_rtl::deref(prism_rtl::deref(m23055_3_0)))) {
                auto&& x_pa = prism_rtl::as<crate::syntax::Cond::CondExpr>(prism_rtl::deref(prism_rtl::deref(m23055_3_0))).a0;
                _v.set(frame_call_o(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pa)), false));
                goto _done;
            }
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
            auto&& op_pb = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l_pc = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r_pd = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            _v.set((op_pb == Text::lit("and")) || (op_pb == Text::lit("or"))
                ? frame_call_o(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(l_pc)), false)
                : first_frame_o(lx_p0, env_p1, Array(std::vector{prism_rtl::deref(prism_rtl::deref(l_pc)), prism_rtl::deref(prism_rtl::deref(r_pd))})));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
            auto&& es_pe = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
            _v.set(first_frame_o(lx_p0, env_p1, es_pe));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
            auto&& es_pf = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            _v.set(first_frame_o(lx_p0, env_p1, es_pf));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
            auto&& x_pg = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            _v.set(frame_call_o(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pg)), false));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
            auto&& x_ph = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
            _v.set(frame_call_o(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_ph)), false));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
            auto&& x_pi = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
            auto&& i_pj = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
            _v.set(first_frame_o(lx_p0, env_p1, Array(std::vector{prism_rtl::deref(prism_rtl::deref(x_pi)), prism_rtl::deref(prism_rtl::deref(i_pj))})));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
            auto&& x_pk = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
            auto&& args_pl = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
            _v.set(first_frame_o(lx_p0, env_p1, crate::prelude::append(Array(std::vector{prism_rtl::deref(prism_rtl::deref(x_pk))}), crate::prelude::each(args_pl, [&](const crate::syntax::Arg& a_pm) { return prism_rtl::deref(a_pm).value_p; }))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
            auto&& x_pn = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
            _v.set(frame_call_o(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pn)), false));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
            auto&& l_po = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                auto&& _m = prism_rtl::deref(l_po).kind_p;
                if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
                    auto&& segs_pp = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
                    _v.set(first_frame_o(lx_p0, env_p1, placeholders_f(segs_pp)));
                    goto _done;
                }
                {
                    _v.set(std::optional<crate::syntax::Expr>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(std::optional<crate::syntax::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::optional<crate::syntax::Expr>> FrameCall::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    const auto& top_p3 = this->top_p3;
    return crate::check::env::has_key_f(prism_rtl::deref(env_p1).spans_p, crate::lower::place_key_f(lx_p0, prism_rtl::deref(e_p2).span_p))
        ? prism_rtl::finished(std::optional<crate::syntax::Expr>{})
        : ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p4)), prism_rtl::deref(top_p3))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& c_p5 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_p6 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        ({
        auto args_p6x = args_p6;
        auto c_p5x = prism_rtl::deref(prism_rtl::deref(c_p5));
        auto e_p2x = e_p2;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto top_p3x = prism_rtl::deref(top_p3);
        (crate::prelude::call_then(start_first_frame_o(lx_p0x, env_p1x, crate::prelude::each(args_p6x, [&](const crate::syntax::Arg& a_p7) { return prism_rtl::deref(a_p7).value_p; })), [=, c_p5x = std::move(c_p5x), e_p2x = std::move(e_p2x), top_p3x = std::move(top_p3x)](std::optional<crate::syntax::Expr> first_frame_o_23159) {
        return ({
            prism_rtl::is_some(first_frame_o_23159) ? ({
            auto&& x_p8 = prism_rtl::some_of(first_frame_o_23159);
            prism_rtl::finished(std::optional(x_p8));
        })
            : prism_rtl::is_none(first_frame_o_23159) ? top_p3x
            ? prism_rtl::finished(std::optional<crate::syntax::Expr>{})
            : ({
            auto&& _m = tail_callee_o(lx_p0x, env_p1x, c_p5x);
            prism_rtl::is_some(_m) ? prism_rtl::finished(std::optional(e_p2x))
            : prism_rtl::is_none(_m) ? crate::prelude::call_then(start_local_job_fn_o(lx_p0x, env_p1x, c_p5x), [=](std::optional<crate::lower::types::Vl> local_job_fn_o_23390) {
            return ({
                prism_rtl::is_some(local_job_fn_o_23390) ? prism_rtl::finished(std::optional(e_p2x))
                : prism_rtl::is_none(local_job_fn_o_23390) ? crate::prelude::call_then(crate::lower::expr::start_prelude_job_call_o(lx_p0x, env_p1x, e_p2x), [=](std::optional<crate::lower::model::Ex> prelude_job_call_o_23487) {
                return ({
                    prism_rtl::is_some(prelude_job_call_o_23487) ? prism_rtl::finished(std::optional(e_p2x))
                    : prism_rtl::is_none(prelude_job_call_o_23487) ? prism_rtl::finished(std::optional<crate::syntax::Expr>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
        })
            : throw prism_rtl::Panic("no arm matched");
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& x_p9 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p9)), false)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && ({
        auto&& m23055_3_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        prism_rtl::is<crate::syntax::Cond::CondExpr>(prism_rtl::deref(prism_rtl::deref(m23055_3_0)));
    }) ? ({
        auto&& m23055_3_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& x_pa = prism_rtl::as<crate::syntax::Cond::CondExpr>(prism_rtl::deref(prism_rtl::deref(m23055_3_0))).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pa)), false)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) ? ({
        auto&& op_pb = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l_pc = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_pd = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        (op_pb == Text::lit("and")) || (op_pb == Text::lit("or"))
        ? prism_rtl::more(prism_rtl::rc(FrameCall(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(l_pc)), false)))
        : prism_rtl::more(prism_rtl::rc(FirstFrame(lx_p0, env_p1, Array(std::vector{prism_rtl::deref(prism_rtl::deref(l_pc)), prism_rtl::deref(prism_rtl::deref(r_pd))}))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m) ? ({
        auto&& es_pe = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx_p0, env_p1, es_pe)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) ? ({
        auto&& es_pf = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx_p0, env_p1, es_pf)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) ? ({
        auto&& x_pg = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pg)), false)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& x_ph = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_ph)), false)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& x_pi = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i_pj = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx_p0, env_p1, Array(std::vector{prism_rtl::deref(prism_rtl::deref(x_pi)), prism_rtl::deref(prism_rtl::deref(i_pj))}))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m) ? ({
        auto&& x_pk = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& args_pl = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx_p0, env_p1, crate::prelude::append(Array(std::vector{prism_rtl::deref(prism_rtl::deref(x_pk))}), crate::prelude::each(args_pl, [&](const crate::syntax::Arg& a_pm) { return prism_rtl::deref(a_pm).value_p; })))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECast>(_m) ? ({
        auto&& x_pn = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pn)), false)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
        auto&& l_po = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        ({
        auto&& _m = prism_rtl::deref(l_po).kind_p;
        prism_rtl::is<crate::syntax::LitKind::LText>(_m) ? ({
        auto&& segs_pp = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx_p0, env_p1, placeholders_f(segs_pp))));
    })
        : prism_rtl::finished(std::optional<crate::syntax::Expr>{});
    });
    })
        : prism_rtl::finished(std::optional<crate::syntax::Expr>{});
    });
}


/// `Start FrameCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::syntax::Expr>> start_frame_call_o(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2, bool top_p3) {
    return prism_rtl::make_rc<FrameCall>(lx_p0, env_p1, e_p2, top_p3);
}


/// Placeholders: fn [TextSeg] -> [Expr]
Array<crate::syntax::Expr> placeholders_f(const Array<crate::syntax::TextSeg>& segs_p0) {
    return crate::prelude::fold(segs_p0, Array<crate::syntax::Expr>{}, [&](const Array<crate::syntax::Expr>& acc_p1, const crate::syntax::TextSeg& sg_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
            if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg_p2)) {
                auto&& x_p3 = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg_p2).a0;
                _v.set(crate::prelude::push(acc_p1, x_p3));
                goto _done;
            }
            {
                _v.set(acc_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// ?FirstFrame: unbounded fn Lx, Env, [Expr] -> ?Expr
std::optional<crate::syntax::Expr> first_frame_o(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::Expr>& es_p2) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(es_p2, std::optional<crate::syntax::Expr>{}, ({
        auto lx_p0x = lx_p0;
        auto env_p1x = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<crate::syntax::Expr>>(std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::Expr>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            auto env_p1xy = env_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
            return ({
                auto found_o3 = p0;
                auto x_p4 = p1;
                ({
                prism_rtl::is_some(found_o3) ? ({
                auto&& f_p5 = prism_rtl::some_of(found_o3);
                prism_rtl::finished(std::optional(f_p5));
            })
                : prism_rtl::is_none(found_o3) ? prism_rtl::more(prism_rtl::rc(FrameCall(lx_p0xy, env_p1xy, x_p4, false)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<std::optional<crate::syntax::Expr>> FirstFrame::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& es_p2 = this->es_p2;
    return crate::prelude::fold_job(es_p2, std::optional<crate::syntax::Expr>{}, ({
        auto lx_p0x = lx_p0;
        auto env_p1x = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<crate::syntax::Expr>>(std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::Expr>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            auto env_p1xy = env_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
            return ({
                auto found_o3 = p0;
                auto x_p4 = p1;
                ({
                prism_rtl::is_some(found_o3) ? ({
                auto&& f_p5 = prism_rtl::some_of(found_o3);
                prism_rtl::finished(std::optional(f_p5));
            })
                : prism_rtl::is_none(found_o3) ? prism_rtl::more(prism_rtl::rc(FrameCall(lx_p0xy, env_p1xy, x_p4, false)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start FirstFrame, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::syntax::Expr>> start_first_frame_o(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Expr> es_p2) {
    return prism_rtl::make_rc<FirstFrame>(lx_p0, env_p1, es_p2);
}


/// Frame: unbounded fn Lx, Env, Expr, Text, (unbounded fn Env -> Ex) -> Ex
crate::lower::model::Ex frame_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& call_p2, const Text& rest_text_p3, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)>& cont_f4) {
    auto&& _m = prism_rtl::deref(call_p2.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_p5 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_p6 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        auto qk_o7 = tail_callee_o(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(c_p5)));
        auto qk_p8 = crate::prelude::or_(qk_o7, Text::lit(""));
        auto base_p9 = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(qk_o7)) {
                auto&& q_pj = prism_rtl::some_of(qk_o7);
                _v.set(crate::prelude::or_(crate::prelude::get(lx_p0.rs_names_p, q_pj), crate::lower::snake_f(crate::check::types::bare_name_f(q_pj))));
                goto _done;
            }
            if (prism_rtl::is_none(qk_o7)) {
                _v.set(crate::lower::snake_f(callee_text_f(prism_rtl::deref(prism_rtl::deref(c_p5)))));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto v_pa = prism_rtl::cat(base_p9, "_", prism_rtl::deref(call_p2.span_p).start_p);
        auto t_pb = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, call_p2.span_p)));
        auto caps_pc = crate::prelude::fold(crate::prelude::keys(env_p1.names_p), Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>>& acc_pk, const Text& k_pl) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>>> _v;
                auto&& _m = crate::prelude::get(env_p1.names_p, k_pl);
                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                    auto&& rs_pm = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                    auto&& mode_pn = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                    auto&& bt_po = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                    _v.set(((mode_pn == crate::lower::types::Holding(crate::lower::types::Holding::ByRef{})) || (mode_pn == crate::lower::types::Holding(crate::lower::types::Holding::RcRef{}))) && mentions_f(rest_text_p3, instance_of_f(k_pl))
                        ? crate::prelude::push(acc_pk, std::tuple{k_pl, rs_pm, mode_pn, bt_po})
                        : acc_pk);
                    goto _done;
                }
                {
                    _v.set(acc_pk);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
        auto dos_pd = crate::prelude::each(caps_pc, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
            auto&& rs_pp = std::get<1>(_p0);
            auto&& mode_pq = std::get<2>(_p0);
            auto&& bt_pr = std::get<3>(_p0);
            return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::expr::capture_name_f(rs_pp)}), crate::lower::types::own_f(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs_pp, mode_pq, bt_pr}))});
        });
        auto env2_pe = crate::prelude::fold(caps_pc, env_p1, [&](const crate::lower::types::Env& en_ps, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
            auto&& k_pt = std::get<0>(_p1);
            auto&& rs_pu = std::get<1>(_p1);
            auto&& bt_pv = std::get<3>(_p1);
            return crate::lower::types::bind_f(en_ps, k_pt, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::capture_name_f(rs_pu)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_pv}));
        });
        auto vals_pf = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
            if (prism_rtl::is_some(qk_o7)) {
                auto&& q_p10 = prism_rtl::some_of(qk_o7);
                _v.set(crate::lower::expr::named_args_owned_f(lx_p0, env2_pe, q_p10, args_p6));
                goto _done;
            }
            if (prism_rtl::is_none(qk_o7)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                    auto&& _m = local_job_fn_o(lx_p0, env2_pe, prism_rtl::deref(prism_rtl::deref(c_p5)));
                    if (prism_rtl::is_some(_m)) {
                        auto&& f_p11 = prism_rtl::some_of(_m);
                        _v.set(crate::lower::expr::start_args_f(lx_p0, env2_pe, f_p11, args_p6));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(crate::prelude::run_to_end(crate::prelude::each_job(args_p6, ({
                            auto lx_p0x = lx_p0;
                            auto env2_pex = env2_pe;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), env2_pex = std::move(env2_pex)](crate::syntax::Arg p0) {
                            return ({
                                auto lx_p0xy = lx_p0x;
                                auto env2_pexy = env2_pex;
                                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), env2_pexy = std::move(env2_pexy)]() {
                                return ({
                                    auto a_p12 = p0;
                                    (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xy, env2_pexy, prism_rtl::deref(a_p12).value_p), [=](crate::lower::types::Vl value_of_f_26214) { return prism_rtl::finished(crate::lower::types::own_f(value_of_f_26214)); }));
                                });
                            })));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto env3_pg = crate::lower::types::bind_span_f(env2_pe, crate::lower::place_key_f(lx_p0, call_p2.span_p), crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XVar{v_pa}), t_pb}));
        auto body_ph = crate::prelude::run_to_end(cont_f4(env3_pg));
        auto [job_p16, how_p17] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::lower::model::Ex, Text>> _v;
            if (prism_rtl::is_some(qk_o7)) {
                auto&& q_p13 = prism_rtl::some_of(qk_o7);
                _v.set(std::tuple{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::path_in_f(lx_p0, crate::lower::owner_of_f(q_p13), prism_rtl::cat("start_", base_p9)), vals_pf}), crate::lower::helper_f(crate::lower::program::enters_at_once_f(lx_p0, q_p13, args_p6)
                    ? Text::lit("call_value")
                    : Text::lit("call_then"))});
                goto _done;
            }
            if (prism_rtl::is_none(qk_o7)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::lower::model::Ex, Text>> _v;
                    auto&& _m = local_job_fn_o(lx_p0, env2_pe, prism_rtl::deref(prism_rtl::deref(c_p5)));
                    if (prism_rtl::is_some(_m)) {
                        auto&& f_p14 = prism_rtl::some_of(_m);
                        _v.set(std::tuple{start_call_f(f_p14, vals_pf), crate::lower::helper_f(Text::lit("call_value"))});
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<crate::lower::model::Ex, Text>> _v;
                            auto&& _m = crate::lower::expr::prelude_job_call_o(lx_p0, env2_pe, call_p2);
                            if (prism_rtl::is_some(_m)) {
                                auto&& pj_p15 = prism_rtl::some_of(_m);
                                _v.set(std::tuple{pj_p15, crate::lower::helper_f(Text::lit("call_value"))});
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(std::tuple{crate::lower::expr::refusal_f(Text::lit("a call this frame cannot enter")), crate::lower::helper_f(Text::lit("call_then"))});
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto enter_pi = crate::lower::expr::is_lifted_at_f(lx_p0, call_p2.span_p)
            ? crate::lower::expr::refusal_f(prism_rtl::cat("an unbounded call lifted over `?` or `~` (`", crate::lower::functions::src_text_f(lx_p0, lx_p0.file_p, call_p2.span_p), "`)"))
            : crate::lower::model::Ex(crate::lower::model::Ex::XCall{how_p17, Array(std::vector{job_p16, crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{v_pa})), t_pb})}), prism_rtl::rc(body_ph)})})});
        return crate::prelude::len(dos_pd) == Nat(0u)
            ? enter_pi
            : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_pd, prism_rtl::rc(enter_pi)});
    }
    {
        return crate::prelude::run_to_end(cont_f4(env_p1));
    }
}


prism_rtl::Turn<crate::lower::model::Ex> Frame::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& call_p2 = this->call_p2;
    const auto& rest_text_p3 = this->rest_text_p3;
    const auto& cont_f4 = this->cont_f4;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(call_p2).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& c_p5 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_p6 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        ({
        auto qk_o7 = tail_callee_o(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(c_p5)));
        auto qk_p8 = crate::prelude::or_(qk_o7, Text::lit(""));
        auto base_p9 = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(qk_o7)) {
                auto&& q_pj = prism_rtl::some_of(qk_o7);
                _v.set(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0).rs_names_p, q_pj), crate::lower::snake_f(crate::check::types::bare_name_f(q_pj))));
                goto _done;
            }
            if (prism_rtl::is_none(qk_o7)) {
                _v.set(crate::lower::snake_f(callee_text_f(prism_rtl::deref(prism_rtl::deref(c_p5)))));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto v_pa = prism_rtl::cat(base_p9, "_", prism_rtl::deref(prism_rtl::deref(call_p2).span_p).start_p);
        auto cont_f4x = cont_f4;
        auto args_p6x = args_p6;
        auto c_p5x = prism_rtl::deref(prism_rtl::deref(c_p5));
        auto call_p2x = call_p2;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto rest_text_p3x = rest_text_p3;
        (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0x, prism_rtl::deref(call_p2x).span_p))), [=, qk_o7 = std::move(qk_o7), base_p9 = std::move(base_p9), v_pa = std::move(v_pa), cont_f4x = std::move(cont_f4x), args_p6x = std::move(args_p6x), c_p5x = std::move(c_p5x), env_p1x = std::move(env_p1x), rest_text_p3x = std::move(rest_text_p3x)](crate::lower::model::OutTy out_ty_of_f_25455) {
        return ({
            auto t_pb = out_ty_of_f_25455;
            auto caps_pc = crate::prelude::fold(crate::prelude::keys(prism_rtl::deref(env_p1x).names_p), Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>>& acc_pk, const Text& k_pl) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>>> _v;
                    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p1x).names_p, k_pl);
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                        auto&& rs_pm = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                        auto&& mode_pn = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                        auto&& bt_po = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                        _v.set(((mode_pn == crate::lower::types::Holding(crate::lower::types::Holding::ByRef{})) || (mode_pn == crate::lower::types::Holding(crate::lower::types::Holding::RcRef{}))) && mentions_f(rest_text_p3x, instance_of_f(k_pl))
                            ? crate::prelude::push(acc_pk, std::tuple{k_pl, rs_pm, mode_pn, bt_po})
                            : acc_pk);
                        goto _done;
                    }
                    {
                        _v.set(acc_pk);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            auto dos_pd = crate::prelude::each(caps_pc, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
                auto&& rs_pp = std::get<1>(_p0);
                auto&& mode_pq = std::get<2>(_p0);
                auto&& bt_pr = std::get<3>(_p0);
                return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::expr::capture_name_f(rs_pp)}), crate::lower::types::own_f(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs_pp, mode_pq, bt_pr}))});
            });
            auto env2_pe = crate::prelude::fold(caps_pc, env_p1x, [&](const crate::lower::types::Env& en_ps, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
                auto&& k_pt = std::get<0>(_p1);
                auto&& rs_pu = std::get<1>(_p1);
                auto&& bt_pv = std::get<3>(_p1);
                return crate::lower::types::bind_f(en_ps, k_pt, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::expr::capture_name_f(rs_pu)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_pv}));
            });
            auto vals_pf = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                if (prism_rtl::is_some(qk_o7)) {
                    auto&& q_p10 = prism_rtl::some_of(qk_o7);
                    _v.set(crate::lower::expr::named_args_owned_f(lx_p0x, env2_pe, q_p10, args_p6x));
                    goto _done;
                }
                if (prism_rtl::is_none(qk_o7)) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                        auto&& _m = local_job_fn_o(lx_p0x, env2_pe, c_p5x);
                        if (prism_rtl::is_some(_m)) {
                            auto&& f_p11 = prism_rtl::some_of(_m);
                            _v.set(crate::lower::expr::start_args_f(lx_p0x, env2_pe, f_p11, args_p6x));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(crate::prelude::run_to_end(crate::prelude::each_job(args_p6x, ({
                                auto lx_p0xx = lx_p0x;
                                auto env2_pex = env2_pe;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), env2_pex = std::move(env2_pex)](crate::syntax::Arg p0) {
                                return ({
                                    auto lx_p0xxy = lx_p0xx;
                                    auto env2_pexy = env2_pex;
                                    (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), env2_pexy = std::move(env2_pexy)]() {
                                    return ({
                                        auto a_p12 = p0;
                                        (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xxy, env2_pexy, prism_rtl::deref(a_p12).value_p), [=](crate::lower::types::Vl value_of_f_26214) { return prism_rtl::finished(crate::lower::types::own_f(value_of_f_26214)); }));
                                    });
                                })));
                                });
                            })));
                            }))));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto env3_pg = crate::lower::types::bind_span_f(env2_pe, crate::lower::place_key_f(lx_p0x, prism_rtl::deref(call_p2x).span_p), crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XVar{v_pa}), t_pb}));
            (crate::prelude::call_value(cont_f4x(env3_pg), [=, t_pb = std::move(t_pb), dos_pd = std::move(dos_pd), env2_pe = std::move(env2_pe), vals_pf = std::move(vals_pf)](crate::lower::model::Ex cont_26342) {
            return ({
                auto body_ph = cont_26342;
                auto [job_p16, how_p17] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::lower::model::Ex, Text>> _v;
                    if (prism_rtl::is_some(qk_o7)) {
                        auto&& q_p13 = prism_rtl::some_of(qk_o7);
                        _v.set(std::tuple{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::path_in_f(lx_p0x, crate::lower::owner_of_f(q_p13), prism_rtl::cat("start_", base_p9)), vals_pf}), crate::lower::helper_f(crate::lower::program::enters_at_once_f(lx_p0x, q_p13, args_p6x)
                            ? Text::lit("call_value")
                            : Text::lit("call_then"))});
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk_o7)) {
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<crate::lower::model::Ex, Text>> _v;
                            auto&& _m = local_job_fn_o(lx_p0x, env2_pe, c_p5x);
                            if (prism_rtl::is_some(_m)) {
                                auto&& f_p14 = prism_rtl::some_of(_m);
                                _v.set(std::tuple{start_call_f(f_p14, vals_pf), crate::lower::helper_f(Text::lit("call_value"))});
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<crate::lower::model::Ex, Text>> _v;
                                    auto&& _m = crate::lower::expr::prelude_job_call_o(lx_p0x, env2_pe, call_p2x);
                                    if (prism_rtl::is_some(_m)) {
                                        auto&& pj_p15 = prism_rtl::some_of(_m);
                                        _v.set(std::tuple{pj_p15, crate::lower::helper_f(Text::lit("call_value"))});
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(_m)) {
                                        _v.set(std::tuple{crate::lower::expr::refusal_f(Text::lit("a call this frame cannot enter")), crate::lower::helper_f(Text::lit("call_then"))});
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                }));
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto enter_pi = crate::lower::expr::is_lifted_at_f(lx_p0x, prism_rtl::deref(call_p2x).span_p)
                    ? crate::lower::expr::refusal_f(prism_rtl::cat("an unbounded call lifted over `?` or `~` (`", crate::lower::functions::src_text_f(lx_p0x, prism_rtl::deref(lx_p0x).file_p, prism_rtl::deref(call_p2x).span_p), "`)"))
                    : crate::lower::model::Ex(crate::lower::model::Ex::XCall{how_p17, Array(std::vector{job_p16, crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{v_pa})), t_pb})}), prism_rtl::rc(body_ph)})})});
                (crate::prelude::len(dos_pd) == Nat(0u)
                ? prism_rtl::finished(enter_pi)
                : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_pd, prism_rtl::rc(enter_pi)})));
            });
        }));
        });
    }));
    });
    })
        : cont_f4(env_p1)->cycle();
    });
}


/// `Start Frame, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_frame_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr call_p2, Text rest_text_p3, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)> cont_f4) {
    return prism_rtl::make_rc<Frame>(lx_p0, env_p1, call_p2, rest_text_p3, cont_f4);
}


/// ?LocalJobFn: unbounded fn Lx, Env, Expr -> ?Vl
std::optional<crate::lower::types::Vl> local_job_fn_o(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& c_p2) {
    auto&& _m = prism_rtl::deref(c_p2.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return (crate::prelude::len(prism_rtl::deref(n_p3).path_p) == Nat(1u)) && crate::check::env::has_key_f(env_p1.names_p, crate::check::env::sname_key_f(n_p3))
            ? job_value_o(crate::lower::expr::name_value_f(lx_p0, env_p1, n_p3, c_p2.span_p))
            : std::optional<crate::lower::types::Vl>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return local_job_fn_o(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p4)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        return job_value_o(crate::lower::expr::value_of_f(lx_p0, env_p1, c_p2));
    }
    {
        return std::optional<crate::lower::types::Vl>{};
    }
}


prism_rtl::Turn<std::optional<crate::lower::types::Vl>> LocalJobFn::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& c_p2 = this->c_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(c_p2).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        (crate::prelude::len(prism_rtl::deref(n_p3).path_p) == Nat(1u)) && crate::check::env::has_key_f(prism_rtl::deref(env_p1).names_p, crate::check::env::sname_key_f(n_p3))
        ? ({
        auto c_p2x = c_p2;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto n_p3x = n_p3;
        (crate::prelude::call_then(crate::lower::expr::start_name_value_f(lx_p0x, env_p1x, n_p3x, prism_rtl::deref(c_p2x).span_p), [=](crate::lower::types::Vl name_value_f_27562) { return prism_rtl::finished(job_value_o(name_value_f_27562)); }));
    })
        : prism_rtl::finished(std::optional<crate::lower::types::Vl>{});
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(LocalJobFn(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p4)))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto c_p2x = c_p2;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p1x, c_p2x), [=](crate::lower::types::Vl value_of_f_27693) { return prism_rtl::finished(job_value_o(value_of_f_27693)); }));
    })
        : prism_rtl::finished(std::optional<crate::lower::types::Vl>{});
    });
}


/// `Start LocalJobFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::lower::types::Vl>> start_local_job_fn_o(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr c_p2) {
    return prism_rtl::make_rc<LocalJobFn>(lx_p0, env_p1, c_p2);
}


/// ?JobValue: fn Vl -> ?Vl
std::optional<crate::lower::types::Vl> job_value_o(const crate::lower::types::Vl& f_p0) {
    auto&& _m = crate::lower::types::value_ty_f(f_p0);
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
        return std::optional(f_p0);
    }
    {
        return std::optional<crate::lower::types::Vl>{};
    }
}


/// StartCall: fn Vl, [Ex] -> Ex
crate::lower::model::Ex start_call_f(const crate::lower::types::Vl& f_p0, const Array<crate::lower::model::Ex>& vals_p1) {
    return crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(crate::lower::types::ref_f(f_p0)), Array(std::vector{one_or_tuple_f(vals_p1)})});
}


/// OneOrTuple: fn [Ex] -> Ex
crate::lower::model::Ex one_or_tuple_f(const Array<crate::lower::model::Ex>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 1u) {
            {
                auto&& _c1 = crate::prelude::index(c0_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one_p0 = prism_rtl::some_of(_c1);
                    return one_p0;
                }
            }
        }
    }
    {
        auto&& vals_p1 = xs0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XTuple{vals_p1});
    }
}


/// CalleeText: fn Expr -> Text
Text callee_text_f(const crate::syntax::Expr& c_p0) {
    auto&& _m = prism_rtl::deref(c_p0.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::check::env::dotted_f(prism_rtl::deref(n_p1).path_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p2 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return callee_text_f(prism_rtl::deref(prism_rtl::deref(x_p2)));
    }
    {
        return Text::lit("call");
    }
}


/// RestText: fn Lx, Range, Range, Range -> Text
Text rest_text_f(const crate::lower::Lx& lx_p0, const crate::syntax::Range& from_p1, const crate::syntax::Range& call_p2, const crate::syntax::Range& to_p3) {
    auto&& _m = crate::prelude::index(prism_rtl::deref(lx_p0.g_p).srcs_p, lx_p0.file_p);
    if (prism_rtl::is_some(_m)) {
        auto&& src_p4 = prism_rtl::some_of(_m);
        return crate::check::errors::span_text_f(src_p4, crate::syntax::Range{.start_p = from_p1.start_p, .end_p = to_p3.end_p});
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Mentions: fn Text, Text -> Bool
bool mentions_f(const Text& text_p0, const Text& name_p1) {
    auto parts_p2 = crate::prelude::split_on(text_p0, name_p1);
    auto last_p3 = crate::syntax::lexer::chars::dec_f(crate::prelude::len(parts_p2));
    return crate::prelude::fold(crate::check::errors::range0_f(last_p3), false, [&](const bool& found_p4, const Nat& i_p5) {
        return ({
            auto before_p6 = crate::prelude::or_(crate::prelude::index(parts_p2, i_p5), Text::lit(""));
            auto after_p7 = crate::prelude::or_(crate::prelude::index(parts_p2, i_p5 + Nat(1u)), Text::lit(""));
            auto left_word_p8 = before_p6 != Text::lit("")
                ? ends_ident_f(before_p6)
                : (i_p5 > Nat(0u)) && ends_ident_f(name_p1);
            auto right_word_p9 = after_p7 != Text::lit("")
                ? starts_ident_f(after_p7)
                : ((i_p5 + Nat(1u)) < last_p3) && starts_ident_f(name_p1);
            (prism_rtl::deref(found_p4) || ((!std::move(left_word_p8)) && (!std::move(right_word_p9))));
        });
    });
}


/// EndsIdent: fn Text -> Bool
bool ends_ident_f(const Text& t_p0) {
    return (crate::prelude::len_text(t_p0) > Nat(0u)) && crate::syntax::lexer::chars::is_ident_char_f(crate::syntax::lexer::chars::last_char_f(t_p0));
}


/// StartsIdent: fn Text -> Bool
bool starts_ident_f(const Text& t_p0) {
    return (crate::prelude::len_text(t_p0) > Nat(0u)) && crate::syntax::lexer::chars::is_ident_char_f(crate::syntax::lexer::chars::head_f(t_p0));
}


/// TailBody: unbounded fn Lx, Env, FnBody -> Ex
crate::lower::model::Ex tail_body_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::decls::FnBody& fn_body2) {
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body2)) {
        auto&& x_p2 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body2).a0;
        return tail_f(lx_p0, env_p1, x_p2);
    }
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body2)) {
        auto&& b_p5 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body2).a0;
        return tail_block_f(lx_p0, env_p1, b_p5);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Ex> TailBody::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& fn_body2 = this->fn_body2;
    return ({
        prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body2) ? ({
        auto&& x_p2 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body2).a0;
        prism_rtl::more(prism_rtl::rc(Tail(lx_p0, env_p1, x_p2)));
    })
        : prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body2) ? ({
        auto&& b_p5 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body2).a0;
        prism_rtl::more(prism_rtl::rc(TailBlock(lx_p0, env_p1, b_p5)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TailBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_tail_body_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::decls::FnBody fn_body2) {
    return prism_rtl::make_rc<TailBody>(lx_p0, env_p1, fn_body2);
}


/// TailMatch: unbounded fn Lx, Env, Expr, [Arm], Range -> Ex
crate::lower::model::Ex tail_match_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& s_p2, const Array<crate::syntax::Arm>& arms_p3, const crate::syntax::Range& span_p4) {
    auto sv_p5 = crate::lower::expr::value_of_f(lx_p0, env_p1, s_p2);
    auto sty_p6 = crate::lower::type_at_f(lx_p0, s_p2.span_p);
    auto label_p7 = prism_rtl::cat("m", span_p4.start_p);
    auto by_ref_p8 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(arms_p3)), ({
        auto lx_p0x = lx_p0;
        auto arms_p3x = arms_p3;
        auto sty_p6x = sty_p6;
        auto label_p7x = label_p7;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), arms_p3x = std::move(arms_p3x), sty_p6x = std::move(sty_p6x), label_p7x = std::move(label_p7x)](Nat p0) {
        return ({
            auto lx_p0xy = lx_p0x;
            auto arms_p3xy = arms_p3x;
            auto sty_p6xy = sty_p6x;
            auto label_p7xy = label_p7x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), arms_p3xy = std::move(arms_p3xy), sty_p6xy = std::move(sty_p6xy), label_p7xy = std::move(label_p7xy)]() {
            return ({
                auto i_pe = p0;
                (prism_rtl::more(prism_rtl::rc(crate::lower::expr::ArmPat(lx_p0xy, prism_rtl::deref(crate::prelude::or_(crate::prelude::index(arms_p3xy, i_pe), crate::lower::expr::dummy_arm_p())).pattern_o, sty_p6xy, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(label_p7xy, "_", i_pe)))));
            });
        })));
        });
    })));
    })));
    auto chain_p9 = crate::prelude::fold(by_ref_p8, false, [&](const bool& f_pf, const crate::lower::patterns::PatOut& po_pg) { return prism_rtl::deref(f_pf) || crate::prelude::fold(prism_rtl::deref(po_pg).conds_p, false, [&](const bool& f2_ph, const crate::lower::model::Cc& c_pi) { return prism_rtl::deref(f2_ph) || crate::lower::expr::is_let_cond_f(c_pi); }); });
    auto owned_pa = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::types::Vl::VlOwned>(sv_p5)) {
            _v.set(!std::move(chain_p9));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto pats_pb = std::move(owned_pa)
        ? crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(arms_p3)), ({
        auto lx_p0x = lx_p0;
        auto arms_p3x = arms_p3;
        auto sty_p6x = sty_p6;
        auto label_p7x = label_p7;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), arms_p3x = std::move(arms_p3x), sty_p6x = std::move(sty_p6x), label_p7x = std::move(label_p7x)](Nat p0) {
        return ({
            auto lx_p0xy = lx_p0x;
            auto arms_p3xy = arms_p3x;
            auto sty_p6xy = sty_p6x;
            auto label_p7xy = label_p7x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), arms_p3xy = std::move(arms_p3xy), sty_p6xy = std::move(sty_p6xy), label_p7xy = std::move(label_p7xy)]() {
            return ({
                auto i_pj = p0;
                (prism_rtl::more(prism_rtl::rc(crate::lower::expr::ArmPat(lx_p0xy, prism_rtl::deref(crate::prelude::or_(crate::prelude::index(arms_p3xy, i_pj), crate::lower::expr::dummy_arm_p())).pattern_o, sty_p6xy, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat(label_p7xy, "_", i_pj)))));
            });
        })));
        });
    })));
    })))
        : by_ref_p8;
    auto xarms_pc = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(arms_p3)), ({
        auto arms_p3x = arms_p3;
        auto pats_pbx = pats_pb;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=, arms_p3x = std::move(arms_p3x), pats_pbx = std::move(pats_pbx), env_p1x = std::move(env_p1x), lx_p0x = std::move(lx_p0x)](Nat p0) {
        return ({
            auto arms_p3xy = arms_p3x;
            auto pats_pbxy = pats_pbx;
            auto env_p1xy = env_p1x;
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, arms_p3xy = std::move(arms_p3xy), pats_pbxy = std::move(pats_pbxy), env_p1xy = std::move(env_p1xy), lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto i_pk = p0;
                ({
                auto arm_pl = crate::prelude::or_(crate::prelude::index(arms_p3xy, i_pk), crate::lower::expr::dummy_arm_p());
                auto po_pm = crate::prelude::or_(crate::prelude::index(pats_pbxy, i_pk), crate::lower::patterns::PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array<crate::lower::model::Cc>{}, .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                auto env2_pn = crate::lower::expr::bind_all_f(env_p1xy, prism_rtl::deref(po_pm).binds_p);
                (crate::prelude::call_then(crate::lower::templates::start_guard_conds_f(lx_p0xy, env2_pn, prism_rtl::deref(arm_pl).guard_o), [=, po_pm = std::move(po_pm)](Array<crate::lower::model::Cc> guard_conds_f_30605) { return crate::prelude::call_then(start_tail_block_f(lx_p0xy, env2_pn, prism_rtl::deref(arm_pl).body_p), [=](crate::lower::model::Ex tail_block_f_30646) { return prism_rtl::finished(crate::lower::model::XArm{.pat_p = prism_rtl::deref(po_pm).pa_p, .conds_p = crate::prelude::append(prism_rtl::deref(po_pm).conds_p, guard_conds_f_30605), .body_p = tail_block_f_30646}); }); }));
            });
            });
        })));
        });
    })));
    })));
    auto scrut_pd = std::move(owned_pa)
        ? crate::lower::types::own_f(sv_p5)
        : crate::lower::types::ref_f(sv_p5);
    return crate::lower::types::own_f(crate::lower::expr::arms_value_f(scrut_pd, xarms_pc, prism_rtl::cat("\'", label_p7), crate::lower::model::OutTy(crate::lower::model::OutTy::OutTurn{})));
}


prism_rtl::Turn<crate::lower::model::Ex> TailMatch::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& s_p2 = this->s_p2;
    const auto& arms_p3 = this->arms_p3;
    const auto& span_p4 = this->span_p4;
    auto arms_p3x = arms_p3;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    auto s_p2x = s_p2;
    auto span_p4x = span_p4;
    return crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p1x, s_p2x), [=](crate::lower::types::Vl value_of_f_29827) {
        return ({
            auto sv_p5 = value_of_f_29827;
            auto sty_p6 = crate::lower::type_at_f(lx_p0x, prism_rtl::deref(s_p2x).span_p);
            auto label_p7 = prism_rtl::cat("m", prism_rtl::deref(span_p4x).start_p);
            (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(arms_p3x)), ({
            auto lx_p0xx = lx_p0x;
            auto arms_p3xx = arms_p3x;
            auto sty_p6x = sty_p6;
            auto label_p7x = label_p7;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), arms_p3xx = std::move(arms_p3xx), sty_p6x = std::move(sty_p6x), label_p7x = std::move(label_p7x)](Nat p0) {
            return ({
                auto lx_p0xxy = lx_p0xx;
                auto arms_p3xxy = arms_p3xx;
                auto sty_p6xy = sty_p6x;
                auto label_p7xy = label_p7x;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), arms_p3xxy = std::move(arms_p3xxy), sty_p6xy = std::move(sty_p6xy), label_p7xy = std::move(label_p7xy)]() {
                return ({
                    auto i_pe = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::lower::expr::ArmPat(lx_p0xxy, prism_rtl::deref(crate::prelude::or_(crate::prelude::index(arms_p3xxy, i_pe), crate::lower::expr::dummy_arm_p())).pattern_o, sty_p6xy, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(label_p7xy, "_", i_pe)))));
                });
            })));
            });
        })));
        })), [=, sv_p5 = std::move(sv_p5)](Array<crate::lower::patterns::PatOut> each_29926) {
            return ({
                auto by_ref_p8 = each_29926;
                auto chain_p9 = crate::prelude::fold(by_ref_p8, false, [&](const bool& f_pf, const crate::lower::patterns::PatOut& po_pg) { return prism_rtl::deref(f_pf) || crate::prelude::fold(prism_rtl::deref(po_pg).conds_p, false, [&](const bool& f2_ph, const crate::lower::model::Cc& c_pi) { return prism_rtl::deref(f2_ph) || crate::lower::expr::is_let_cond_f(c_pi); }); });
                auto owned_pa = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    if (prism_rtl::is<crate::lower::types::Vl::VlOwned>(sv_p5)) {
                        _v.set(!std::move(chain_p9));
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto pats_pb = std::move(owned_pa)
                    ? crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(arms_p3x)), ({
                    auto lx_p0xx = lx_p0x;
                    auto arms_p3xx = arms_p3x;
                    auto sty_p6x = sty_p6;
                    auto label_p7x = label_p7;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), arms_p3xx = std::move(arms_p3xx), sty_p6x = std::move(sty_p6x), label_p7x = std::move(label_p7x)](Nat p0) {
                    return ({
                        auto lx_p0xxy = lx_p0xx;
                        auto arms_p3xxy = arms_p3xx;
                        auto sty_p6xy = sty_p6x;
                        auto label_p7xy = label_p7x;
                        (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), arms_p3xxy = std::move(arms_p3xxy), sty_p6xy = std::move(sty_p6xy), label_p7xy = std::move(label_p7xy)]() {
                        return ({
                            auto i_pj = p0;
                            (prism_rtl::more(prism_rtl::rc(crate::lower::expr::ArmPat(lx_p0xxy, prism_rtl::deref(crate::prelude::or_(crate::prelude::index(arms_p3xxy, i_pj), crate::lower::expr::dummy_arm_p())).pattern_o, sty_p6xy, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat(label_p7xy, "_", i_pj)))));
                        });
                    })));
                    });
                })));
                })))
                    : by_ref_p8;
                (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(arms_p3x)), ({
                auto arms_p3xx = arms_p3x;
                auto pats_pbx = pats_pb;
                auto env_p1xx = env_p1x;
                auto lx_p0xx = lx_p0x;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=, arms_p3xx = std::move(arms_p3xx), pats_pbx = std::move(pats_pbx), env_p1xx = std::move(env_p1xx), lx_p0xx = std::move(lx_p0xx)](Nat p0) {
                return ({
                    auto arms_p3xxy = arms_p3xx;
                    auto pats_pbxy = pats_pbx;
                    auto env_p1xxy = env_p1xx;
                    auto lx_p0xxy = lx_p0xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, arms_p3xxy = std::move(arms_p3xxy), pats_pbxy = std::move(pats_pbxy), env_p1xxy = std::move(env_p1xxy), lx_p0xxy = std::move(lx_p0xxy)]() {
                    return ({
                        auto i_pk = p0;
                        ({
                        auto arm_pl = crate::prelude::or_(crate::prelude::index(arms_p3xxy, i_pk), crate::lower::expr::dummy_arm_p());
                        auto po_pm = crate::prelude::or_(crate::prelude::index(pats_pbxy, i_pk), crate::lower::patterns::PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array<crate::lower::model::Cc>{}, .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                        auto env2_pn = crate::lower::expr::bind_all_f(env_p1xxy, prism_rtl::deref(po_pm).binds_p);
                        (crate::prelude::call_then(crate::lower::templates::start_guard_conds_f(lx_p0xxy, env2_pn, prism_rtl::deref(arm_pl).guard_o), [=, po_pm = std::move(po_pm)](Array<crate::lower::model::Cc> guard_conds_f_30605) { return crate::prelude::call_then(start_tail_block_f(lx_p0xxy, env2_pn, prism_rtl::deref(arm_pl).body_p), [=](crate::lower::model::Ex tail_block_f_30646) { return prism_rtl::finished(crate::lower::model::XArm{.pat_p = prism_rtl::deref(po_pm).pa_p, .conds_p = crate::prelude::append(prism_rtl::deref(po_pm).conds_p, guard_conds_f_30605), .body_p = tail_block_f_30646}); }); }));
                    });
                    });
                })));
                });
            })));
            })), [=, owned_pa = std::move(owned_pa)](Array<crate::lower::model::XArm> each_30372) {
                return ({
                    auto xarms_pc = each_30372;
                    auto scrut_pd = owned_pa
                        ? crate::lower::types::own_f(sv_p5)
                        : crate::lower::types::ref_f(sv_p5);
                    (prism_rtl::finished(crate::lower::types::own_f(crate::lower::expr::arms_value_f(scrut_pd, xarms_pc, prism_rtl::cat("\'", label_p7), crate::lower::model::OutTy(crate::lower::model::OutTy::OutTurn{})))));
                });
            }));
            });
        }));
        });
    });
}


/// `Start TailMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_tail_match_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr s_p2, Array<crate::syntax::Arm> arms_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<TailMatch>(lx_p0, env_p1, s_p2, arms_p3, span_p4);
}


/// ?TailCallee: fn Lx, Env, Expr -> ?Text
std::optional<Text> tail_callee_o(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& callee_p2) {
    auto&& _m = prism_rtl::deref(callee_p2.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return (crate::prelude::len(prism_rtl::deref(n_p3).path_p) == Nat(1u)) && crate::check::env::has_key_f(env_p1.names_p, crate::check::env::sname_key_f(n_p3))
            ? std::optional<Text>{}
            : ({
            auto&& _qk_o4 = crate::check::env::names::resolve_value_f(lx_p0.g_p, lx_p0.home_p, n_p3);
            auto&& qk_o4 = std::get<0>(_qk_o4);
            ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is_some(qk_o4)) {
                auto&& qk_p5 = prism_rtl::some_of(qk_o4);
                _v.set(crate::check::types::has_text_f(lx_p0.unbs_p, qk_p5) && (!crate::lower::program::in_prelude_f(lx_p0, qk_p5))
                    ? std::optional(qk_p5)
                    : std::optional<Text>{});
                goto _done;
            }
            if (prism_rtl::is_none(qk_o4)) {
                _v.set(std::optional<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    }
    {
        return std::optional<Text>{};
    }
}


/// SchemeParts: fn Lx, Text -> (([Ty], Ty))
std::tuple<Array<crate::check::types::Ty>, crate::check::types::Ty> scheme_parts_f(const crate::lower::Lx& lx_p0, const Text& qk_p1) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).vals_p, qk_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& v_p2 = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p2).scheme_p).ty_p;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps_p3 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            auto&& r_p4 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
            return std::tuple{ps_p3, prism_rtl::deref(prism_rtl::deref(r_p4))};
        }
        {
            auto&& other_p5 = _m;
            return std::tuple{Array<crate::check::types::Ty>{}, other_p5};
        }
    }
    if (prism_rtl::is_none(_m)) {
        return std::tuple{Array<crate::check::types::Ty>{}, crate::check::types::Ty(crate::check::types::Ty::TyErr{})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// JobFieldNames: unbounded fn Lx, Text -> [Text]
Array<Text> job_field_names_f(const crate::lower::Lx& lx_p0, const Text& qk_p1) {
    auto clauses_p2 = clauses_of_f(lx_p0.g_p, qk_p1);
    auto&& _ptys_p5 = scheme_parts_f(lx_p0, qk_p1);
    auto&& ptys_p5 = std::get<0>(_ptys_p5);
    auto pts_p3 = crate::prelude::run_to_end(crate::prelude::each_job(ptys_p5, ({
        auto lx_p0x = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](crate::check::types::Ty p0) {
        return ({
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto p_p6 = p0;
                (prism_rtl::more(prism_rtl::rc(crate::lower::types::OutTyOf(lx_p0xy, crate::lower::types::peel_f(p_p6)))));
            });
        })));
        });
    })));
    })));
    auto lxf_p4 = ({
        crate::lower::Lx this_ = lx_p0;
        this_.file_p = crate::prelude::fold(prism_rtl::deref(lx_p0.g_p).defs_p, lx_p0.file_p, [&](const Nat& f_p7, const crate::check::env::Def& d_p8) { return prism_rtl::deref(d_p8).qk_p == qk_p1 ? prism_rtl::deref(d_p8).file_p : f_p7; });
        (std::move(this_));
    });
    return crate::prelude::each(crate::lower::functions::param_names_f(lxf_p4, clauses_p2, pts_p3), [&](const std::tuple<Text, bool>& _p0) {
        auto&& n_p9 = std::get<0>(_p0);
        return n_p9;
    });
}


prism_rtl::Turn<Array<Text>> JobFieldNames::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& qk_p1 = this->qk_p1;
    auto clauses_p2 = clauses_of_f(prism_rtl::deref(lx_p0).g_p, qk_p1);
    auto&& _ptys_p5 = scheme_parts_f(lx_p0, qk_p1);
    auto&& ptys_p5 = std::get<0>(_ptys_p5);
    auto lx_p0x = lx_p0;
    auto qk_p1x = qk_p1;
    return crate::prelude::call_value(crate::prelude::each_job(ptys_p5, ({
        auto lx_p0xx = lx_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx)](crate::check::types::Ty p0) {
        return ({
            auto lx_p0xxy = lx_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy)]() {
            return ({
                auto p_p6 = p0;
                (prism_rtl::more(prism_rtl::rc(crate::lower::types::OutTyOf(lx_p0xxy, crate::lower::types::peel_f(p_p6)))));
            });
        })));
        });
    })));
    })), [=](Array<crate::lower::model::OutTy> each_31693) {
        return ({
            auto pts_p3 = each_31693;
            auto lxf_p4 = ({
                crate::lower::Lx this_ = lx_p0x;
                this_.file_p = crate::prelude::fold(prism_rtl::deref(prism_rtl::deref(lx_p0x).g_p).defs_p, prism_rtl::deref(lx_p0x).file_p, [&](const Nat& f_p7, const crate::check::env::Def& d_p8) {
                    return prism_rtl::deref(d_p8).qk_p == qk_p1x
                        ? prism_rtl::deref(d_p8).file_p
                        : f_p7;
                });
                (std::move(this_));
            });
            (crate::prelude::call_then(crate::lower::functions::start_param_names_f(lxf_p4, clauses_p2, pts_p3), [=](Array<std::tuple<Text, bool>> param_names_f_31927) {
            return prism_rtl::finished(crate::prelude::each(param_names_f_31927, [&](const std::tuple<Text, bool>& _p0) {
                auto&& n_p9 = std::get<0>(_p0);
                return n_p9;
            }));
        }));
        });
    });
}


/// `Start JobFieldNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_job_field_names_f(crate::lower::Lx lx_p0, Text qk_p1) {
    return prism_rtl::make_rc<JobFieldNames>(lx_p0, qk_p1);
}


/// ClausesOf: fn G, Text -> [FnClause]
Array<crate::syntax::decls::FnClause> clauses_of_f(const crate::check::env::G& g_p0, const Text& qk_p1) {
    return crate::prelude::fold(g_p0.defs_p, Array<crate::syntax::decls::FnClause>{}, [&](const Array<crate::syntax::decls::FnClause>& acc_p2, const crate::check::env::Def& d_p3) { return prism_rtl::deref(d_p3).qk_p == qk_p1 ? def_clauses_f(d_p3, acc_p2) : acc_p2; });
}


/// DefClauses: fn Def, [FnClause] -> [FnClause]
Array<crate::syntax::decls::FnClause> def_clauses_f(const crate::check::env::Def& d_p0, const Array<crate::syntax::decls::FnClause>& other_p1) {
    auto&& _m = d_p0.body_p;
    if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
        auto&& cs_p2 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
        return cs_p2;
    }
    {
        return other_p1;
    }
}

}  // namespace crate::lower::jobs
