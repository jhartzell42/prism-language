// The module `Fs`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace fs {

struct Contents;

class FileRequest;

class WriteState;

struct FsContents;

struct FsFile;

struct FsList_;

struct FsOutput;

}  // namespace fs

namespace fs {

/// `FileRequest`:
///
/// ```prism
/// type FileRequest = choice:
/// ```
class FileRequest {
public:
    using prism_value = void;
    struct Read;
    struct Write;
    using Cases = std::variant<Read, Write>;
    template <class C>
        requires prism_rtl::one_of<C, Read, Write>
    FileRequest(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<FileRequest> from_pod(const Pod& whole);
    friend inline bool operator==(const FileRequest& a, const FileRequest& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `WriteState`:
///
/// ```prism
/// type WriteState = choice:
/// ```
class WriteState {
public:
    using prism_value = void;
    struct Writing;
    struct Written;
    struct WriteFailed;
    using Cases = std::variant<Writing, Written, WriteFailed>;
    template <class C>
        requires prism_rtl::one_of<C, Writing, Written, WriteFailed>
    WriteState(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<WriteState> from_pod(const Pod& whole);
    friend inline bool operator==(const WriteState& a, const WriteState& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


}  // namespace fs

}  // namespace crate
