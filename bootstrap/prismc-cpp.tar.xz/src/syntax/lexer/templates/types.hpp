// The module `Syntax.Lexer.Templates`: its value types (records, tags, newtypes and choices with their cases), each
// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism
// source, not this file.
#pragma once

#include <syntax/lexer/templates/decl.hpp>
#include "elem.decl.hpp"
#include <syntax/decls/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/regexes/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::lexer::templates {

/// `CallRead`:
///
/// ```prism
/// type CallRead = record:
/// ```
struct CallRead {
    using prism_value = void;
    crate::syntax::lexer::Lex l;
    Array<crate::syntax::lexer::AttrTok> attrs;
    std::optional<Array<crate::syntax::lexer::TPartTok>> body;
    bool going;
    const CallRead* operator->() const { return this; }
    CallRead* operator->() { return this; }
    bool operator==(const CallRead&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CallRead> from_pod(const Pod& whole);
};


}  // namespace syntax::lexer::templates

namespace syntax::lexer::templates {

/// `RawItem`:
///
/// ```prism
/// type RawItem = choice:
/// ```
class RawItem {
public:
    using prism_value = void;
    struct RiText {
        Text a0;
        bool operator==(const RiText&) const = default;
    };

    struct RiPlaceholder {
        Array<crate::syntax::lexer::Tok> a0;
        crate::syntax::Range a1;
        bool operator==(const RiPlaceholder&) const;
    };

    struct RiBlock {
        Array<crate::syntax::lexer::Tok> a0;
        crate::syntax::Range a1;
        bool operator==(const RiBlock&) const;
    };

    struct RiCall {
        crate::syntax::lexer::NameTok a0;
        Array<crate::syntax::lexer::AttrTok> a1;
        std::optional<Array<crate::syntax::lexer::TPartTok>> a2;
        crate::syntax::Range a3;
        bool operator==(const RiCall&) const;
    };
    using Cases = std::variant<RiText, RiPlaceholder, RiBlock, RiCall>;
    template <class C>
        requires prism_rtl::one_of<C, RiText, RiPlaceholder, RiBlock, RiCall>
    RawItem(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<RawItem> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const RawItem& a, const RawItem& b) { return a.cases() == b.cases(); }

}  // namespace syntax::lexer::templates

namespace syntax::lexer::templates {

/// `RawLine`:
///
/// ```prism
/// type RawLine = record:
/// ```
struct RawLine {
    using prism_value = void;
    Array<RawItem> items;
    bool newline;
    bool block;
    const RawLine* operator->() const { return this; }
    RawLine* operator->() { return this; }
    bool operator==(const RawLine&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<RawLine> from_pod(const Pod& whole);
};


}  // namespace syntax::lexer::templates

namespace syntax::lexer::templates {

/// `TplHow`:
///
/// ```prism
/// type TplHow = record:
/// ```
struct TplHow {
    using prism_value = void;
    Text close;
    Text delims;
    Text open;
    bool is_raw;
    bool first_continues;
    const TplHow* operator->() const { return this; }
    TplHow* operator->() { return this; }
    bool operator==(const TplHow&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TplHow> from_pod(const Pod& whole);
};


}  // namespace syntax::lexer::templates

namespace syntax::lexer::templates {

/// `TplRead`:
///
/// ```prism
/// type TplRead = record:
/// ```
struct TplRead {
    using prism_value = void;
    crate::syntax::lexer::Lex l;
    Array<RawLine> lines;
    RawLine cur;
    std::optional<Nat> closing_col;
    bool closed;
    bool at_line_start;
    bool going;
    const TplRead* operator->() const { return this; }
    TplRead* operator->() { return this; }
    bool operator==(const TplRead&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TplRead> from_pod(const Pod& whole);
};


}  // namespace syntax::lexer::templates

}  // namespace crate
