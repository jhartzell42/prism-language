// The module `Syntax.Lexer.Templates`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace syntax::lexer::templates {

struct CallRead;

class RawItem;

struct RawLine;

struct TplHow;

struct TplRead;

struct MaybeTemplate;

struct TemplateTagAhead;

struct LexTemplate;

struct TemplateBody;

struct TemplateStep;

struct BraceBlockLine;

struct TemplateItem;

struct TemplateCall;

struct CallStep;

}  // namespace syntax::lexer::templates

namespace syntax::lexer::templates {

/// `RawItem`:
///
/// ```prism
/// type RawItem = choice:
/// ```
class RawItem {
public:
    using prism_value = void;
    struct RiText;
    struct RiPlaceholder;
    struct RiBlock;
    struct RiCall;
    using Cases = std::variant<RiText, RiPlaceholder, RiBlock, RiCall>;
    template <class C>
        requires prism_rtl::one_of<C, RiText, RiPlaceholder, RiBlock, RiCall>
    RawItem(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<RawItem> from_pod(const Pod& whole);
    friend inline bool operator==(const RawItem& a, const RawItem& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


}  // namespace syntax::lexer::templates

}  // namespace crate
