// The module `Syntax.Lexer.Templates`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace syntax::lexer::templates {

struct CallRead;

class RawItem;

struct RawLine;

struct TplHow;

struct TplRead;

struct MaybeTemplate;

struct TemplateTagAhead;

struct LexTemplate;

struct TemplateBody;

struct TemplateStep;

struct BraceBlockLine;

struct TemplateItem;

struct TemplateCall;

struct CallStep;

}  // namespace syntax::lexer::templates

}  // namespace crate
