// The module `Syntax.Lexer.Templates`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/lexer/templates/types.hpp>
#include "elem.types.hpp"
#include <syntax/lexer/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::lexer::templates {

crate::syntax::lexer::Lex maybe_template_f(const crate::syntax::lexer::Lex& l0_p0, const Text& kw_p1);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_maybe_template_f(crate::syntax::lexer::Lex l0_p0, Text kw_p1);

Text template_tag_ahead_f(const crate::syntax::lexer::Lex& l_p0);

prism_rtl::JobRef<Text> start_template_tag_ahead_f(crate::syntax::lexer::Lex l_p0);

std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_template_f(const crate::syntax::lexer::Lex& l0_p0, const Text& keyword_p1, const Nat& start_p2);

prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_template_f(crate::syntax::lexer::Lex l0_p0, Text keyword_p1, Nat start_p2);

RawLine empty_line_p();

RawLine add_item_f(const RawLine& line_p0, const RawItem& item_p1);

Array<RawItem> add_raw_f(const Array<RawItem>& items_p0, const RawItem& raw_item1);

bool only_whitespace_f(const RawLine& line_p0);

bool is_blank_text_f(const RawItem& raw_item0);

Nat text_len_f(const RawLine& line_p0);

Nat text_len_of_f(const RawItem& raw_item0);

std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> template_body_f(const crate::syntax::lexer::Lex& l0_p0, const Text& close_p1, const Text& delims_p2, const bool& is_raw_p3, const bool& first_continues_p4, const Nat& open_start_p5);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex>> start_template_body_f(crate::syntax::lexer::Lex l0_p0, Text close_p1, Text delims_p2, bool is_raw_p3, bool first_continues_p4, Nat open_start_p5);

TplRead template_step_f(const TplRead& s_p0, const TplHow& how_p1);

prism_rtl::JobRef<TplRead> start_template_step_f(TplRead s_p0, TplHow how_p1);

TplRead brace_block_line_f(const TplRead& s_p0, const Text& rest_p1, const TplHow& how_p2);

prism_rtl::JobRef<TplRead> start_brace_block_line_f(TplRead s_p0, Text rest_p1, TplHow how_p2);

TplRead close_template_f(const TplRead& s_p0, const TplHow& how_p1);

std::tuple<RawItem, crate::syntax::lexer::Lex> template_item_f(const crate::syntax::lexer::Lex& l_p0, const TplHow& how_p1);

prism_rtl::JobRef<std::tuple<RawItem, crate::syntax::lexer::Lex>> start_template_item_f(crate::syntax::lexer::Lex l_p0, TplHow how_p1);

std::tuple<RawItem, crate::syntax::lexer::Lex> template_call_f(const crate::syntax::lexer::Lex& l0_p0, const Text& delims_p1, const Text& open_p2);

prism_rtl::JobRef<std::tuple<RawItem, crate::syntax::lexer::Lex>> start_template_call_f(crate::syntax::lexer::Lex l0_p0, Text delims_p1, Text open_p2);

CallRead call_step_f(const CallRead& s0_p0, const Nat& start_p1, const Text& close_p2, const Text& delims_p3, const Text& open_p4);

prism_rtl::JobRef<CallRead> start_call_step_f(CallRead s0_p0, Nat start_p1, Text close_p2, Text delims_p3, Text open_p4);

std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> attr_value_f(const crate::syntax::lexer::Lex& l_p0, const Text& delims_p1, const Text& open_p2);

std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> finish_template_lines_f(const crate::syntax::lexer::Lex& l0_p0, const Array<RawLine>& lines_p1, const Nat& strip_p2, const bool& first_continues_p3);

Array<crate::syntax::lexer::TPartTok> block_parts_f(const Array<RawItem>& items_p0);

std::tuple<Array<RawItem>, crate::syntax::lexer::Lex> strip_line_f(const RawLine& line_p0, const Nat& strip_p1, const crate::syntax::lexer::Lex& l_p2);

bool is_blank_or_empty_f(const RawItem& raw_item0);

bool is_placeholder_item_f(const RawItem& raw_item0);

crate::syntax::Range first_item_span_f(const Array<RawItem>& items_p0);

std::optional<crate::syntax::Range> item_span_o(const RawItem& raw_item0);

crate::syntax::lexer::TPartTok alone_placeholder_f(const Array<RawItem>& items_p0);

std::tuple<Nat, crate::syntax::lexer::TPartTok> alone_step_f(const Nat& c_p0, const crate::syntax::lexer::TPartTok& tpart_tok1, const RawItem& raw_item2);

Array<crate::syntax::lexer::TPartTok> push_part_f(const Array<crate::syntax::lexer::TPartTok>& parts_p0, const RawItem& raw_item1);

}  // namespace syntax::lexer::templates


namespace syntax::lexer::templates {

/// The step machine of `MaybeTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MaybeTemplate: unbounded fn Lex, Text -> Lex
struct MaybeTemplate : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l0_p0;
    Text kw_p1;
    MaybeTemplate(crate::syntax::lexer::Lex l0_p0, Text kw_p1) : l0_p0(std::move(l0_p0)), kw_p1(std::move(kw_p1)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `TemplateTagAhead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateTagAhead: unbounded fn Lex -> Text
struct TemplateTagAhead : prism_rtl::Job<Text> {
    crate::syntax::lexer::Lex l_p0;
    TemplateTagAhead(crate::syntax::lexer::Lex l_p0) : l_p0(std::move(l_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `LexTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexTemplate: unbounded fn Lex, Text, Nat -> ((TokKind, Lex))
struct LexTemplate : prism_rtl::Job<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0_p0;
    Text keyword_p1;
    Nat start_p2;
    LexTemplate(crate::syntax::lexer::Lex l0_p0, Text keyword_p1, Nat start_p2) : l0_p0(std::move(l0_p0)), keyword_p1(std::move(keyword_p1)), start_p2(std::move(start_p2)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `TemplateBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateBody: unbounded fn Lex, Text, Text, Bool, Bool, Nat -> (([TPartTok], Lex))
struct TemplateBody : prism_rtl::Job<std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0_p0;
    Text close_p1;
    Text delims_p2;
    bool is_raw_p3;
    bool first_continues_p4;
    Nat open_start_p5;
    TemplateBody(crate::syntax::lexer::Lex l0_p0, Text close_p1, Text delims_p2, bool is_raw_p3, bool first_continues_p4, Nat open_start_p5) : l0_p0(std::move(l0_p0)), close_p1(std::move(close_p1)), delims_p2(std::move(delims_p2)), is_raw_p3(std::move(is_raw_p3)), first_continues_p4(std::move(first_continues_p4)), open_start_p5(std::move(open_start_p5)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `TemplateStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateStep: unbounded fn TplRead, TplHow -> TplRead
struct TemplateStep : prism_rtl::Job<TplRead> {
    TplRead s_p0;
    TplHow how_p1;
    TemplateStep(TplRead s_p0, TplHow how_p1) : s_p0(std::move(s_p0)), how_p1(std::move(how_p1)) {}
    prism_rtl::Turn<TplRead> cycle() const override;
};


/// The step machine of `BraceBlockLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BraceBlockLine: unbounded fn TplRead, Text, TplHow -> TplRead
struct BraceBlockLine : prism_rtl::Job<TplRead> {
    TplRead s_p0;
    Text rest_p1;
    TplHow how_p2;
    BraceBlockLine(TplRead s_p0, Text rest_p1, TplHow how_p2) : s_p0(std::move(s_p0)), rest_p1(std::move(rest_p1)), how_p2(std::move(how_p2)) {}
    prism_rtl::Turn<TplRead> cycle() const override;
};


/// The step machine of `TemplateItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateItem: unbounded fn Lex, TplHow -> ((RawItem, Lex))
struct TemplateItem : prism_rtl::Job<std::tuple<RawItem, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l_p0;
    TplHow how_p1;
    TemplateItem(crate::syntax::lexer::Lex l_p0, TplHow how_p1) : l_p0(std::move(l_p0)), how_p1(std::move(how_p1)) {}
    prism_rtl::Turn<std::tuple<RawItem, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `TemplateCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateCall: unbounded fn Lex, Text, Text -> ((RawItem, Lex))
struct TemplateCall : prism_rtl::Job<std::tuple<RawItem, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0_p0;
    Text delims_p1;
    Text open_p2;
    TemplateCall(crate::syntax::lexer::Lex l0_p0, Text delims_p1, Text open_p2) : l0_p0(std::move(l0_p0)), delims_p1(std::move(delims_p1)), open_p2(std::move(open_p2)) {}
    prism_rtl::Turn<std::tuple<RawItem, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `CallStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CallStep: unbounded fn CallRead, Nat, Text, Text, Text -> CallRead
struct CallStep : prism_rtl::Job<CallRead> {
    CallRead s0_p0;
    Nat start_p1;
    Text close_p2;
    Text delims_p3;
    Text open_p4;
    CallStep(CallRead s0_p0, Nat start_p1, Text close_p2, Text delims_p3, Text open_p4) : s0_p0(std::move(s0_p0)), start_p1(std::move(start_p1)), close_p2(std::move(close_p2)), delims_p3(std::move(delims_p3)), open_p4(std::move(open_p4)) {}
    prism_rtl::Turn<CallRead> cycle() const override;
};


}  // namespace syntax::lexer::templates

}  // namespace crate
