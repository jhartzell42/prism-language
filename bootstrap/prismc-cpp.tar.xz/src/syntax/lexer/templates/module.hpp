// The module `Syntax.Lexer.Templates`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/lexer/templates/types.hpp>
#include "elem.types.hpp"
#include <syntax/lexer/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::lexer::templates {

crate::syntax::lexer::Lex maybe_template(const crate::syntax::lexer::Lex& l0, const Text& kw);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_maybe_template(crate::syntax::lexer::Lex l0, Text kw);

Text template_tag_ahead(const crate::syntax::lexer::Lex& l);

prism_rtl::JobRef<Text> start_template_tag_ahead(crate::syntax::lexer::Lex l);

std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_template(const crate::syntax::lexer::Lex& l0, const Text& keyword, const Nat& start);

prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_template(crate::syntax::lexer::Lex l0, Text keyword, Nat start);

RawLine empty_line();

RawLine add_item(const RawLine& line, const RawItem& item);

Array<RawItem> add_raw(const Array<RawItem>& items, const RawItem& raw_item1);

bool only_whitespace(const RawLine& line);

bool is_blank_text(const RawItem& raw_item0);

Nat text_len(const RawLine& line);

Nat text_len_of(const RawItem& raw_item0);

std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> template_body(const crate::syntax::lexer::Lex& l0, const Text& close, const Text& delims, const bool& is_raw, const bool& first_continues, const Nat& open_start);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex>> start_template_body(crate::syntax::lexer::Lex l0, Text close, Text delims, bool is_raw, bool first_continues, Nat open_start);

TplRead template_step(const TplRead& s, const TplHow& how);

prism_rtl::JobRef<TplRead> start_template_step(TplRead s, TplHow how);

TplRead brace_block_line(const TplRead& s, const Text& rest, const TplHow& how);

prism_rtl::JobRef<TplRead> start_brace_block_line(TplRead s, Text rest, TplHow how);

TplRead close_template(const TplRead& s, const TplHow& how);

std::tuple<RawItem, crate::syntax::lexer::Lex> template_item(const crate::syntax::lexer::Lex& l, const TplHow& how);

prism_rtl::JobRef<std::tuple<RawItem, crate::syntax::lexer::Lex>> start_template_item(crate::syntax::lexer::Lex l, TplHow how);

std::tuple<RawItem, crate::syntax::lexer::Lex> template_call(const crate::syntax::lexer::Lex& l0, const Text& delims, const Text& open);

prism_rtl::JobRef<std::tuple<RawItem, crate::syntax::lexer::Lex>> start_template_call(crate::syntax::lexer::Lex l0, Text delims, Text open);

CallRead call_step(const CallRead& s0, const Nat& start, const Text& close, const Text& delims, const Text& open);

prism_rtl::JobRef<CallRead> start_call_step(CallRead s0, Nat start, Text close, Text delims, Text open);

std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> attr_value(const crate::syntax::lexer::Lex& l, const Text& delims, const Text& open);

std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> finish_template_lines(const crate::syntax::lexer::Lex& l0, const Array<RawLine>& lines, const Nat& strip, const bool& first_continues);

Array<crate::syntax::lexer::TPartTok> block_parts(const Array<RawItem>& items);

std::tuple<Array<RawItem>, crate::syntax::lexer::Lex> strip_line(const RawLine& line, const Nat& strip, const crate::syntax::lexer::Lex& l);

bool is_blank_or_empty(const RawItem& raw_item0);

bool is_placeholder_item(const RawItem& raw_item0);

crate::syntax::Range first_item_span(const Array<RawItem>& items);

std::optional<crate::syntax::Range> item_span(const RawItem& raw_item0);

crate::syntax::lexer::TPartTok alone_placeholder(const Array<RawItem>& items);

std::tuple<Nat, crate::syntax::lexer::TPartTok> alone_step(const Nat& c, const crate::syntax::lexer::TPartTok& tpart_tok1, const RawItem& raw_item2);

Array<crate::syntax::lexer::TPartTok> push_part(const Array<crate::syntax::lexer::TPartTok>& parts, const RawItem& raw_item1);

}  // namespace syntax::lexer::templates


namespace syntax::lexer::templates {

/// The step machine of `MaybeTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MaybeTemplate: unbounded fn Lex, Text -> Lex
struct MaybeTemplate : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l0;
    Text kw;
    MaybeTemplate(crate::syntax::lexer::Lex l0, Text kw) : l0(std::move(l0)), kw(std::move(kw)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `TemplateTagAhead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateTagAhead: unbounded fn Lex -> Text
struct TemplateTagAhead : prism_rtl::Job<Text> {
    crate::syntax::lexer::Lex l;
    TemplateTagAhead(crate::syntax::lexer::Lex l) : l(std::move(l)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `LexTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexTemplate: unbounded fn Lex, Text, Nat -> ((TokKind, Lex))
struct LexTemplate : prism_rtl::Job<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0;
    Text keyword;
    Nat start;
    LexTemplate(crate::syntax::lexer::Lex l0, Text keyword, Nat start) : l0(std::move(l0)), keyword(std::move(keyword)), start(std::move(start)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `TemplateBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateBody: unbounded fn Lex, Text, Text, Bool, Bool, Nat -> (([TPartTok], Lex))
struct TemplateBody : prism_rtl::Job<std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0;
    Text close;
    Text delims;
    bool is_raw;
    bool first_continues;
    Nat open_start;
    TemplateBody(crate::syntax::lexer::Lex l0, Text close, Text delims, bool is_raw, bool first_continues, Nat open_start) : l0(std::move(l0)), close(std::move(close)), delims(std::move(delims)), is_raw(std::move(is_raw)), first_continues(std::move(first_continues)), open_start(std::move(open_start)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `TemplateStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateStep: unbounded fn TplRead, TplHow -> TplRead
struct TemplateStep : prism_rtl::Job<TplRead> {
    TplRead s;
    TplHow how;
    TemplateStep(TplRead s, TplHow how) : s(std::move(s)), how(std::move(how)) {}
    prism_rtl::Turn<TplRead> cycle() const override;
};


/// The step machine of `BraceBlockLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BraceBlockLine: unbounded fn TplRead, Text, TplHow -> TplRead
struct BraceBlockLine : prism_rtl::Job<TplRead> {
    TplRead s;
    Text rest;
    TplHow how;
    BraceBlockLine(TplRead s, Text rest, TplHow how) : s(std::move(s)), rest(std::move(rest)), how(std::move(how)) {}
    prism_rtl::Turn<TplRead> cycle() const override;
};


/// The step machine of `TemplateItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateItem: unbounded fn Lex, TplHow -> ((RawItem, Lex))
struct TemplateItem : prism_rtl::Job<std::tuple<RawItem, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l;
    TplHow how;
    TemplateItem(crate::syntax::lexer::Lex l, TplHow how) : l(std::move(l)), how(std::move(how)) {}
    prism_rtl::Turn<std::tuple<RawItem, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `TemplateCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateCall: unbounded fn Lex, Text, Text -> ((RawItem, Lex))
struct TemplateCall : prism_rtl::Job<std::tuple<RawItem, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0;
    Text delims;
    Text open;
    TemplateCall(crate::syntax::lexer::Lex l0, Text delims, Text open) : l0(std::move(l0)), delims(std::move(delims)), open(std::move(open)) {}
    prism_rtl::Turn<std::tuple<RawItem, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `CallStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CallStep: unbounded fn CallRead, Nat, Text, Text, Text -> CallRead
struct CallStep : prism_rtl::Job<CallRead> {
    CallRead s0;
    Nat start;
    Text close;
    Text delims;
    Text open;
    CallStep(CallRead s0, Nat start, Text close, Text delims, Text open) : s0(std::move(s0)), start(std::move(start)), close(std::move(close)), delims(std::move(delims)), open(std::move(open)) {}
    prism_rtl::Turn<CallRead> cycle() const override;
};


}  // namespace syntax::lexer::templates

}  // namespace crate
