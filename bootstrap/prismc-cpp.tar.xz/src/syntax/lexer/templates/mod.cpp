// The module `Syntax.Lexer.Templates`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/templates.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

namespace crate::syntax::lexer::templates {

void CallRead::show(Printer& p) const {
    p.record("CallRead", {{"l", l}, {"attrs", attrs}, {"body", body}, {"going", going}});
}

Pod CallRead::to_pod() const {
    return Pod::record("CallRead", {{"l", prism_rtl::to_pod(l)}, {"attrs", prism_rtl::to_pod(attrs)}, {"body", prism_rtl::to_pod(body)}, {"going", prism_rtl::to_pod(going)}});
}

Result<CallRead> CallRead::from_pod(const Pod& whole) {
    return CallRead{.l = TRY(prism_rtl::from_pod<crate::syntax::lexer::Lex>(TRY(crate::prelude::field(whole, "l")))), .attrs = TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::AttrTok>>(TRY(crate::prelude::field(whole, "attrs")))), .body = TRY(prism_rtl::from_pod<std::optional<Array<crate::syntax::lexer::TPartTok>>>(TRY(crate::prelude::field(whole, "body")))), .going = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "going"))))};
}


void RawItem::show(Printer& p) const {
    if (auto c = std::get_if<RiText>(&cases())) p.choice("RiText", {c->a0});
    else if (auto c = std::get_if<RiPlaceholder>(&cases())) p.choice("RiPlaceholder", {c->a0, c->a1});
    else if (auto c = std::get_if<RiBlock>(&cases())) p.choice("RiBlock", {c->a0, c->a1});
    else if (auto c = std::get_if<RiCall>(&cases())) p.choice("RiCall", {c->a0, c->a1, c->a2, c->a3});
}

Pod RawItem::to_pod() const {
    return std::holds_alternative<RiText>(cases()) ? Pod::choice("RiText", {prism_rtl::to_pod(std::get<RiText>(cases()).a0)})
        : std::holds_alternative<RiPlaceholder>(cases()) ? Pod::choice("RiPlaceholder", {prism_rtl::to_pod(std::get<RiPlaceholder>(cases()).a0), prism_rtl::to_pod(std::get<RiPlaceholder>(cases()).a1)})
        : std::holds_alternative<RiBlock>(cases()) ? Pod::choice("RiBlock", {prism_rtl::to_pod(std::get<RiBlock>(cases()).a0), prism_rtl::to_pod(std::get<RiBlock>(cases()).a1)})
        : std::holds_alternative<RiCall>(cases()) ? Pod::choice("RiCall", {prism_rtl::to_pod(std::get<RiCall>(cases()).a0), prism_rtl::to_pod(std::get<RiCall>(cases()).a1), prism_rtl::to_pod(std::get<RiCall>(cases()).a2), prism_rtl::to_pod(std::get<RiCall>(cases()).a3)})
        : Pod();
}

Result<RawItem> RawItem::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "RiText" && c->args.size() == 1) return RawItem(RiText{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "RiPlaceholder" && c->args.size() == 2) return RawItem(RiPlaceholder{TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::Tok>>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[1]))});
        if (c->ctor == "RiBlock" && c->args.size() == 2) return RawItem(RiBlock{TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::Tok>>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[1]))});
        if (c->ctor == "RiCall" && c->args.size() == 4) return RawItem(RiCall{TRY(prism_rtl::from_pod<crate::syntax::lexer::NameTok>(c->args[0])), TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::AttrTok>>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Array<crate::syntax::lexer::TPartTok>>>(c->args[2])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[3]))});
    }
    return mismatch<RawItem>("a RawItem", p);
}


void RawLine::show(Printer& p) const {
    p.record("RawLine", {{"items", items}, {"newline", newline}, {"block", block}});
}

Pod RawLine::to_pod() const {
    return Pod::record("RawLine", {{"items", prism_rtl::to_pod(items)}, {"newline", prism_rtl::to_pod(newline)}, {"block", prism_rtl::to_pod(block)}});
}

Result<RawLine> RawLine::from_pod(const Pod& whole) {
    return RawLine{.items = TRY(prism_rtl::from_pod<Array<RawItem>>(TRY(crate::prelude::field(whole, "items")))), .newline = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "newline")))), .block = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "block"))))};
}


void TplHow::show(Printer& p) const {
    p.record("TplHow", {{"close", close}, {"delims", delims}, {"open", open}, {"is_raw", is_raw}, {"first_continues", first_continues}});
}

Pod TplHow::to_pod() const {
    return Pod::record("TplHow", {{"close", prism_rtl::to_pod(close)}, {"delims", prism_rtl::to_pod(delims)}, {"open", prism_rtl::to_pod(open)}, {"is_raw", prism_rtl::to_pod(is_raw)}, {"first_continues", prism_rtl::to_pod(first_continues)}});
}

Result<TplHow> TplHow::from_pod(const Pod& whole) {
    return TplHow{.close = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "close")))), .delims = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "delims")))), .open = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "open")))), .is_raw = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "is_raw")))), .first_continues = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "first_continues"))))};
}


void TplRead::show(Printer& p) const {
    p.record("TplRead", {{"l", l}, {"lines", lines}, {"cur", cur}, {"closing_col", closing_col}, {"closed", closed}, {"at_line_start", at_line_start}, {"going", going}});
}

Pod TplRead::to_pod() const {
    return Pod::record("TplRead", {{"l", prism_rtl::to_pod(l)}, {"lines", prism_rtl::to_pod(lines)}, {"cur", prism_rtl::to_pod(cur)}, {"closing_col", prism_rtl::to_pod(closing_col)}, {"closed", prism_rtl::to_pod(closed)}, {"at_line_start", prism_rtl::to_pod(at_line_start)}, {"going", prism_rtl::to_pod(going)}});
}

Result<TplRead> TplRead::from_pod(const Pod& whole) {
    return TplRead{.l = TRY(prism_rtl::from_pod<crate::syntax::lexer::Lex>(TRY(crate::prelude::field(whole, "l")))), .lines = TRY(prism_rtl::from_pod<Array<RawLine>>(TRY(crate::prelude::field(whole, "lines")))), .cur = TRY(prism_rtl::from_pod<RawLine>(TRY(crate::prelude::field(whole, "cur")))), .closing_col = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(crate::prelude::field(whole, "closing_col")))), .closed = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "closed")))), .at_line_start = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "at_line_start")))), .going = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "going"))))};
}


/// MaybeTemplate: unbounded fn Lex, Text -> Lex
crate::syntax::lexer::Lex maybe_template(const crate::syntax::lexer::Lex& l0, const Text& kw) {
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit(" *", ""); return r; }()), this_.src, this_.pos);
        this_;
    });
    return (crate::syntax::lexer::chars::peek(l) == Text::lit("<")) && (template_tag_ahead(l) != Text::lit(""))
        ? ({
        auto keyword = kw == Text::lit("output")
            ? Text::lit("Output")
            : kw == Text::lit("inline_text") ? Text::lit("InlineText") : Text::lit("Raw");
        auto [kind, l2] = lex_template(l, keyword, l.pos);
        auto l3 = ({
            crate::syntax::lexer::Lex this_ = l2;
            this_.last_ws = true;
            this_;
        });
        (crate::syntax::lexer::push_tok(l3, kind, l.pos, l3.pos));
    })
        : crate::syntax::lexer::chars::lex_err(l0, l0.pos, l0.pos, prism_rtl::cat("`", kw, "` is followed by a language tag, `<rust>`"));
}


prism_rtl::Turn<crate::syntax::lexer::Lex> MaybeTemplate::cycle() const {
    const auto& l0 = this->l0;
    const auto& kw = this->kw;
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit(" *", ""); return r; }()), this_.src, this_.pos);
        this_;
    });
    return (crate::syntax::lexer::chars::peek(l) == Text::lit("<")) && (template_tag_ahead(l) != Text::lit(""))
        ? ({
        auto keyword = kw == Text::lit("output")
            ? Text::lit("Output")
            : kw == Text::lit("inline_text") ? Text::lit("InlineText") : Text::lit("Raw");
        call_then(start_lex_template(l, keyword, l.pos), [=](std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_template_1019) {
        return ({
            auto [kind, l2] = lex_template_1019;
            auto l3 = ({
                crate::syntax::lexer::Lex this_ = l2;
                this_.last_ws = true;
                this_;
            });
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l3, kind, l.pos, l3.pos)));
        });
    });
    })
        : prism_rtl::finished(crate::syntax::lexer::chars::lex_err(l0, l0.pos, l0.pos, prism_rtl::cat("`", kw, "` is followed by a language tag, `<rust>`")));
}


/// `Start MaybeTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_maybe_template(crate::syntax::lexer::Lex l0, Text kw) {
    return prism_rtl::make_rc<MaybeTemplate>(l0, kw);
}


/// TemplateTagAhead: unbounded fn Lex -> Text
Text template_tag_ahead(const crate::syntax::lexer::Lex& l) {
    auto&& _name = crate::syntax::lexer::words::lex_ident(crate::syntax::lexer::chars::bump(l));
    auto&& name = std::get<0>(_name);
    auto after_ = crate::syntax::lexer::chars::peek_at(l, len_text(name) + Nat(1u));
    return (((crate::syntax::lexer::chars::peek(l) == Text::lit("<")) && (name != Text::lit(""))) && crate::syntax::lexer::chars::is_lower(crate::syntax::lexer::chars::head(name))) && (after_ == Text::lit(">"))
        ? name
        : Text::lit("");
}


prism_rtl::Turn<Text> TemplateTagAhead::cycle() const {
    const auto& l = this->l;
    auto l_1 = l;
    return call_then(crate::syntax::lexer::words::start_lex_ident(crate::syntax::lexer::chars::bump(l_1)), [=](std::tuple<Text, crate::syntax::lexer::Lex> lex_ident_1410) {
        return ({
            auto&& _name = lex_ident_1410;
            auto&& name = std::get<0>(_name);
            auto after_ = crate::syntax::lexer::chars::peek_at(l_1, len_text(name) + Nat(1u));
            (((crate::syntax::lexer::chars::peek(l_1) == Text::lit("<")) && (name != Text::lit(""))) && crate::syntax::lexer::chars::is_lower(crate::syntax::lexer::chars::head(name))) && (after_ == Text::lit(">"))
            ? prism_rtl::finished(name)
            : prism_rtl::finished(Text::lit(""));
        });
    });
}


/// `Start TemplateTagAhead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_template_tag_ahead(crate::syntax::lexer::Lex l) {
    return prism_rtl::make_rc<TemplateTagAhead>(l);
}


/// LexTemplate: unbounded fn Lex, Text, Nat -> ((TokKind, Lex))
std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_template(const crate::syntax::lexer::Lex& l0, const Text& keyword, const Nat& start) {
    auto lang = template_tag_ahead(l0);
    auto l1 = crate::syntax::lexer::chars::forward(l0, len_text(lang) + Nat(2u));
    auto delims = (lang == Text::lit("markdown")) || (lang == Text::lit("html"))
        ? Text::lit("single")
        : Text::lit("double");
    auto ends_line = (crate::syntax::lexer::chars::peek(l1) == Text::lit("\n")) || crate::syntax::lexer::chars::starts_with(l1, Text::lit("\r\n"));
    auto skip = crate::syntax::lexer::chars::peek(l1) == Text::lit("\r")
        ? Nat(2u)
        : Nat(1u);
    auto l2 = ends_line ? crate::syntax::lexer::chars::forward(l1, skip) : l1;
    auto [parts, l3] = template_body(l2, prism_rtl::cat("</", lang, ">"), delims, keyword == Text::lit("Raw"), !ends_line, start);
    auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KTemplate{crate::syntax::lexer::TemplateTok{.keyword = keyword, .lang = lang, .delims = delims, .parts = parts}});
    return std::tuple{kind, l3};
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> LexTemplate::cycle() const {
    const auto& l0 = this->l0;
    const auto& keyword = this->keyword;
    const auto& start = this->start;
    auto keyword_1 = keyword;
    auto l0_2 = l0;
    auto start_3 = start;
    return call_then(start_template_tag_ahead(l0_2), [=](Text template_tag_ahead_1743) {
        return ({
            auto lang = template_tag_ahead_1743;
            auto l1 = crate::syntax::lexer::chars::forward(l0_2, len_text(lang) + Nat(2u));
            auto delims = (lang == Text::lit("markdown")) || (lang == Text::lit("html"))
                ? Text::lit("single")
                : Text::lit("double");
            auto ends_line = (crate::syntax::lexer::chars::peek(l1) == Text::lit("\n")) || crate::syntax::lexer::chars::starts_with(l1, Text::lit("\r\n"));
            auto skip = crate::syntax::lexer::chars::peek(l1) == Text::lit("\r")
                ? Nat(2u)
                : Nat(1u);
            auto l2 = ends_line ? crate::syntax::lexer::chars::forward(l1, skip) : l1;
            call_then(start_template_body(l2, prism_rtl::cat("</", lang, ">"), delims, keyword_1 == Text::lit("Raw"), !ends_line, start_3), [=](std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> template_body_2157) {
            return ({
                auto [parts, l3] = template_body_2157;
                auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KTemplate{crate::syntax::lexer::TemplateTok{.keyword = keyword_1, .lang = lang, .delims = delims, .parts = parts}});
                (prism_rtl::finished(std::tuple{kind, l3}));
            });
        });
        });
    });
}


/// `Start LexTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_template(crate::syntax::lexer::Lex l0, Text keyword, Nat start) {
    return prism_rtl::make_rc<LexTemplate>(l0, keyword, start);
}


/// let emptyLine
RawLine empty_line() {
    return RawLine{.items = Array<RawItem>{}, .newline = false, .block = false};
}


/// AddItem: fn RawLine, RawItem -> RawLine
RawLine add_item(const RawLine& line, const RawItem& item) {
    RawLine this_ = line;
    this_.items = add_raw(this_.items, item);
    return this_;
}


/// AddRaw: fn [RawItem], RawItem -> [RawItem]
Array<RawItem> add_raw(const Array<RawItem>& items, const RawItem& raw_item1) {
    if (prism_rtl::is<RawItem::RiText>(raw_item1)) {
        auto&& t = prism_rtl::as<RawItem::RiText>(raw_item1).a0;
        auto&& _m = crate::syntax::lexer::chars::last(items);
        if (prism_rtl::is_some(_m) && prism_rtl::is<RawItem::RiText>(prism_rtl::some_of(_m))) {
            auto&& s = prism_rtl::as<RawItem::RiText>(prism_rtl::some_of(_m)).a0;
            return crate::prelude::push(crate::syntax::lexer::chars::pop(items), RawItem(RawItem::RiText{prism_rtl::cat(s, t)}));
        }
        {
            return crate::prelude::push(items, RawItem(RawItem::RiText{t}));
        }
    }
    {
        auto&& item = raw_item1;
        return crate::prelude::push(items, item);
    }
}


/// OnlyWhitespace: fn RawLine -> Bool
bool only_whitespace(const RawLine& line) {
    return fold(line.items, true, [&](const bool& ok, const RawItem& it) { return ok && is_blank_text(it); });
}


/// IsBlankText: fn RawItem -> Bool
bool is_blank_text(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiText>(raw_item0)) {
        auto&& s = prism_rtl::as<RawItem::RiText>(raw_item0).a0;
        return crate::syntax::lexer::chars::all_chars(s, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
            return once_job([=]() {
                return ({
                    auto c = p0;
                    (prism_rtl::finished((c == Text::lit(" ")) || (c == Text::lit("\r"))));
                });
            });
        })));
    }
    {
        return false;
    }
}


/// TextLen: fn RawLine -> Nat
Nat text_len(const RawLine& line) {
    return fold(line.items, Nat(0u), [&](const Nat& n, const RawItem& it) { return n + text_len_of(it); });
}


/// TextLenOf: fn RawItem -> Nat
Nat text_len_of(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiText>(raw_item0)) {
        auto&& s = prism_rtl::as<RawItem::RiText>(raw_item0).a0;
        return len_text(s);
    }
    {
        return Nat(0u);
    }
}


/// TemplateBody: unbounded fn Lex, Text, Text, Bool, Bool, Nat -> (([TPartTok], Lex))
std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> template_body(const crate::syntax::lexer::Lex& l0, const Text& close, const Text& delims, const bool& is_raw, const bool& first_continues, const Nat& open_start) {
    auto open = delims == Text::lit("double") ? Text::lit("{{") : Text::lit("{");
    auto how = TplHow{.close = close, .delims = delims, .open = open, .is_raw = is_raw, .first_continues = first_continues};
    auto start = TplRead{.l = l0, .lines = Array<RawLine>{}, .cur = empty_line(), .closing_col = std::optional<Nat>{}, .closed = false, .at_line_start = !first_continues, .going = true};
    auto r = ({
        TplRead this_ = start;
        while (this_.going) {
            this_ = template_step(this_, how);
        }
        this_;
    });
    auto l1 = r.closed
        ? r.l
        : crate::syntax::lexer::chars::lex_err(r.l, open_start, r.l.pos, prism_rtl::cat("a template never closes: expected `", close, "`"));
    return finish_template_lines(l1, crate::prelude::push(r.lines, r.cur), or_(r.closing_col, Nat(0u)), first_continues);
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex>> TemplateBody::cycle() const {
    const auto& l0 = this->l0;
    const auto& close = this->close;
    const auto& delims = this->delims;
    const auto& is_raw = this->is_raw;
    const auto& first_continues = this->first_continues;
    const auto& open_start = this->open_start;
    auto open = delims == Text::lit("double") ? Text::lit("{{") : Text::lit("{");
    auto how = TplHow{.close = close, .delims = delims, .open = open, .is_raw = is_raw, .first_continues = first_continues};
    auto start = TplRead{.l = l0, .lines = Array<RawLine>{}, .cur = empty_line(), .closing_col = std::optional<Nat>{}, .closed = false, .at_line_start = !first_continues, .going = true};
    TplRead this_ = start;
    auto close_1 = close;
    auto first_continues_2 = first_continues;
    auto open_start_3 = open_start;
    return call_then(loop_job(std::tuple{this_}, ({
        auto how_4 = how;
        [=](std::tuple<TplRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return this_.going
            ? ({
            this_ = template_step(this_, how_4);
            Expected<std::tuple<TplRead>, std::tuple<TplRead>>(std::tuple{this_});
        })
            : Expected<std::tuple<TplRead>, std::tuple<TplRead>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<TplRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto r = this_;
            auto l1 = r.closed
                ? r.l
                : crate::syntax::lexer::chars::lex_err(r.l, open_start_3, r.l.pos, prism_rtl::cat("a template never closes: expected `", close_1, "`"));
            (prism_rtl::finished(finish_template_lines(l1, crate::prelude::push(r.lines, r.cur), or_(r.closing_col, Nat(0u)), first_continues_2)));
        });
    });
}


/// `Start TemplateBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex>> start_template_body(crate::syntax::lexer::Lex l0, Text close, Text delims, bool is_raw, bool first_continues, Nat open_start) {
    return prism_rtl::make_rc<TemplateBody>(l0, close, delims, is_raw, first_continues, open_start);
}


/// TemplateStep: unbounded fn TplRead, TplHow -> TplRead
TplRead template_step(const TplRead& s, const TplHow& how) {
    auto c = crate::syntax::lexer::chars::peek(s.l);
    return (s.at_line_start && (!how.is_raw)) && (crate::syntax::lexer::chars::trim(crate::syntax::lexer::chars::rest_of_line(s.l)) == how.open)
        ? brace_block_line(s, crate::syntax::lexer::chars::rest_of_line(s.l), how)
        : crate::syntax::lexer::chars::starts_with(s.l, how.close)
        ? close_template(s, how)
        : c == Text::lit("")
        ? ({
        TplRead this_ = s;
        this_.at_line_start = false;
        this_.going = false;
        this_;
    })
        : c == Text::lit("\n")
        ? ({
        TplRead this_ = s;
        this_.l = crate::syntax::lexer::chars::bump(this_.l);
        this_.cur.newline = true;
        this_.lines = crate::prelude::push(this_.lines, this_.cur);
        this_.cur = empty_line();
        this_.at_line_start = true;
        this_;
    })
        : ({
        auto [item, l2] = template_item(s.l, how);
        ({
        TplRead this_ = s;
        this_.at_line_start = false;
        this_.l = l2;
        this_.cur = add_item(this_.cur, item);
        this_;
    });
    });
}


prism_rtl::Turn<TplRead> TemplateStep::cycle() const {
    const auto& s = this->s;
    const auto& how = this->how;
    auto c = crate::syntax::lexer::chars::peek(s.l);
    return (s.at_line_start && (!how.is_raw)) && (crate::syntax::lexer::chars::trim(crate::syntax::lexer::chars::rest_of_line(s.l)) == how.open)
        ? ({
        auto how_1 = how;
        auto s_2 = s;
        call_then(crate::syntax::lexer::chars::start_rest_of_line(s_2.l), [=](Text rest_of_line_5173) { return prism_rtl::more(prism_rtl::rc(BraceBlockLine(s_2, rest_of_line_5173, how_1))); });
    })
        : crate::syntax::lexer::chars::starts_with(s.l, how.close)
        ? prism_rtl::finished(close_template(s, how))
        : c == Text::lit("")
        ? prism_rtl::finished(({
        TplRead this_ = s;
        this_.at_line_start = false;
        this_.going = false;
        this_;
    }))
        : c == Text::lit("\n")
        ? prism_rtl::finished(({
        TplRead this_ = s;
        this_.l = crate::syntax::lexer::chars::bump(this_.l);
        this_.cur.newline = true;
        this_.lines = crate::prelude::push(this_.lines, this_.cur);
        this_.cur = empty_line();
        this_.at_line_start = true;
        this_;
    }))
        : ({
        auto how_1 = how;
        auto s_2 = s;
        call_then(start_template_item(s_2.l, how_1), [=](std::tuple<RawItem, crate::syntax::lexer::Lex> template_item_5618) {
        return ({
            auto [item, l2] = template_item_5618;
            (prism_rtl::finished(({
            TplRead this_ = s_2;
            this_.at_line_start = false;
            this_.l = l2;
            this_.cur = add_item(this_.cur, item);
            this_;
        })));
        });
    });
    });
}


/// `Start TemplateStep, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TplRead> start_template_step(TplRead s, TplHow how) {
    return prism_rtl::make_rc<TemplateStep>(s, how);
}


/// BraceBlockLine: unbounded fn TplRead, Text, TplHow -> TplRead
TplRead brace_block_line(const TplRead& s, const Text& rest, const TplHow& how) {
    auto bs = s.l.pos;
    auto past = crate::syntax::lexer::chars::forward(s.l, len_text(rest));
    auto at_ = crate::syntax::lexer::chars::peek(past) == Text::lit("\n")
        ? crate::syntax::lexer::chars::bump(past)
        : past;
    auto [toks, l2] = crate::syntax::lexer::layout::nested(at_, crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MBrace{how.delims}));
    auto line = RawLine{.items = Array(std::vector{RawItem(RawItem::RiBlock{toks, crate::syntax::Range{.start = bs, .end = l2.pos}})}), .newline = false, .block = true};
    TplRead this_ = s;
    this_.lines = crate::prelude::push(this_.lines, line);
    this_.l = l2;
    return this_;
}


prism_rtl::Turn<TplRead> BraceBlockLine::cycle() const {
    const auto& s = this->s;
    const auto& rest = this->rest;
    const auto& how = this->how;
    auto bs = s.l.pos;
    auto past = crate::syntax::lexer::chars::forward(s.l, len_text(rest));
    auto at_ = crate::syntax::lexer::chars::peek(past) == Text::lit("\n")
        ? crate::syntax::lexer::chars::bump(past)
        : past;
    auto how_1 = how;
    auto s_2 = s;
    return call_then(crate::syntax::lexer::layout::start_nested(at_, crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MBrace{how_1.delims})), [=](std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> nested_5996) {
        return ({
            auto [toks, l2] = nested_5996;
            auto line = RawLine{.items = Array(std::vector{RawItem(RawItem::RiBlock{toks, crate::syntax::Range{.start = bs, .end = l2.pos}})}), .newline = false, .block = true};
            (prism_rtl::finished(({
            TplRead this_ = s_2;
            this_.lines = crate::prelude::push(this_.lines, line);
            this_.l = l2;
            this_;
        })));
        });
    });
}


/// `Start BraceBlockLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TplRead> start_brace_block_line(TplRead s, Text rest, TplHow how) {
    return prism_rtl::make_rc<BraceBlockLine>(s, rest, how);
}


/// CloseTemplate: fn TplRead, TplHow -> TplRead
TplRead close_template(const TplRead& s, const TplHow& how) {
    TplRead this_ = s;
    this_.at_line_start = false;
    if (only_whitespace(this_.cur) && ((len(this_.lines) > Nat(0u)) || (!how.first_continues))) {
        this_.closing_col = std::optional(text_len(this_.cur));
        this_.cur.items = Array<RawItem>{};
    }
    this_.l = crate::syntax::lexer::chars::forward(this_.l, len_text(how.close));
    this_.closed = true;
    this_.going = false;
    return this_;
}


/// TemplateItem: unbounded fn Lex, TplHow -> ((RawItem, Lex))
std::tuple<RawItem, crate::syntax::lexer::Lex> template_item(const crate::syntax::lexer::Lex& l, const TplHow& how) {
    auto live = !how.is_raw;
    return (live && (how.delims == Text::lit("double"))) && crate::syntax::lexer::chars::starts_with(l, Text::lit("\\{{"))
        ? std::tuple{RawItem(RawItem::RiText{Text::lit("{{")}), crate::syntax::lexer::chars::forward(l, Nat(3u))}
        : (live && (how.delims == Text::lit("single"))) && crate::syntax::lexer::chars::starts_with(l, Text::lit("\\{"))
        ? std::tuple{RawItem(RawItem::RiText{Text::lit("{")}), crate::syntax::lexer::chars::forward(l, Nat(2u))}
        : live && crate::syntax::lexer::chars::starts_with(l, how.open)
        ? ({
        auto ps = l.pos;
        auto [toks, l2] = crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::forward(l, len_text(how.open)), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{how.delims}));
        auto item = RawItem(RawItem::RiPlaceholder{toks, crate::syntax::Range{.start = ps, .end = l2.pos}});
        std::tuple{item, l2};
    })
        : (live && crate::syntax::lexer::chars::starts_with(l, Text::lit("<@"))) && crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::peek_at(l, Nat(2u)))
        ? template_call(l, how.delims, how.open)
        : ({
        auto run_ = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("[^\\\\{<\\n]+", ""); return r; }()), l);
        auto n = run_ == Text::lit("")
            ? len_text(crate::syntax::lexer::chars::peek(l))
            : len_text(run_);
        auto l2 = ({
            crate::syntax::lexer::Lex this_ = l;
            this_.pos = this_.pos + n;
            this_;
        });
        std::tuple{RawItem(RawItem::RiText{crate::syntax::lexer::chars::slice(l, l.pos, l2.pos)}), l2};
    });
}


prism_rtl::Turn<std::tuple<RawItem, crate::syntax::lexer::Lex>> TemplateItem::cycle() const {
    const auto& l = this->l;
    const auto& how = this->how;
    auto live = !how.is_raw;
    return (live && (how.delims == Text::lit("double"))) && crate::syntax::lexer::chars::starts_with(l, Text::lit("\\{{"))
        ? prism_rtl::finished(std::tuple{RawItem(RawItem::RiText{Text::lit("{{")}), crate::syntax::lexer::chars::forward(l, Nat(3u))})
        : (live && (how.delims == Text::lit("single"))) && crate::syntax::lexer::chars::starts_with(l, Text::lit("\\{"))
        ? prism_rtl::finished(std::tuple{RawItem(RawItem::RiText{Text::lit("{")}), crate::syntax::lexer::chars::forward(l, Nat(2u))})
        : live && crate::syntax::lexer::chars::starts_with(l, how.open)
        ? ({
        auto ps = l.pos;
        auto how_1 = how;
        auto l_2 = l;
        call_then(crate::syntax::lexer::layout::start_nested(crate::syntax::lexer::chars::forward(l_2, len_text(how_1.open)), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{how_1.delims})), [=](std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> nested_7242) {
        return ({
            auto [toks, l2] = nested_7242;
            auto item = RawItem(RawItem::RiPlaceholder{toks, crate::syntax::Range{.start = ps, .end = l2.pos}});
            (prism_rtl::finished(std::tuple{item, l2}));
        });
    });
    })
        : (live && crate::syntax::lexer::chars::starts_with(l, Text::lit("<@"))) && crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::peek_at(l, Nat(2u)))
        ? prism_rtl::more(prism_rtl::rc(TemplateCall(l, how.delims, how.open)))
        : ({
        auto run_ = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("[^\\\\{<\\n]+", ""); return r; }()), l);
        auto n = run_ == Text::lit("")
            ? len_text(crate::syntax::lexer::chars::peek(l))
            : len_text(run_);
        auto l2 = ({
            crate::syntax::lexer::Lex this_ = l;
            this_.pos = this_.pos + n;
            this_;
        });
        (prism_rtl::finished(std::tuple{RawItem(RawItem::RiText{crate::syntax::lexer::chars::slice(l, l.pos, l2.pos)}), l2}));
    });
}


/// `Start TemplateItem, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<RawItem, crate::syntax::lexer::Lex>> start_template_item(crate::syntax::lexer::Lex l, TplHow how) {
    return prism_rtl::make_rc<TemplateItem>(l, how);
}


/// TemplateCall: unbounded fn Lex, Text, Text -> ((RawItem, Lex))
std::tuple<RawItem, crate::syntax::lexer::Lex> template_call(const crate::syntax::lexer::Lex& l0, const Text& delims, const Text& open) {
    auto start = l0.pos;
    auto&& _sigils = crate::syntax::lexer::words::read_sigils(crate::syntax::lexer::chars::bump(l0));
    auto&& sigils = std::get<0>(_sigils);
    auto&& l1 = std::get<2>(_sigils);
    auto [path_, l2] = crate::syntax::lexer::words::lex_qualified_path(l1);
    auto name = crate::syntax::lexer::NameTok{.sigils = sigils, .path_ = path_, .case_ = crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})};
    auto close = prism_rtl::cat("</", sigils, crate::syntax::lexer::chars::join(path_, Text::lit(".")), ">");
    auto r = ({
        CallRead this_ = CallRead{.l = l2, .attrs = Array<crate::syntax::lexer::AttrTok>{}, .body = std::optional<Array<crate::syntax::lexer::TPartTok>>{}, .going = true};
        while (this_.going) {
            this_ = call_step(this_, start, close, delims, open);
        }
        this_;
    });
    auto item = RawItem(RawItem::RiCall{name, r.attrs, r.body, crate::syntax::Range{.start = start, .end = r.l.pos}});
    return std::tuple{item, r.l};
}


prism_rtl::Turn<std::tuple<RawItem, crate::syntax::lexer::Lex>> TemplateCall::cycle() const {
    const auto& l0 = this->l0;
    const auto& delims = this->delims;
    const auto& open = this->open;
    auto start = l0.pos;
    auto delims_1 = delims;
    auto l0_2 = l0;
    auto open_3 = open;
    return call_then(crate::syntax::lexer::words::start_read_sigils(crate::syntax::lexer::chars::bump(l0_2)), [=](std::tuple<Text, bool, crate::syntax::lexer::Lex> read_sigils_8234) {
        return ({
            auto&& _sigils = read_sigils_8234;
            auto&& sigils = std::get<0>(_sigils);
            auto&& l1 = std::get<2>(_sigils);
            call_then(crate::syntax::lexer::words::start_lex_qualified_path(l1), [=](std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_8278) {
            return ({
                auto [path_, l2] = lex_qualified_path_8278;
                auto name = crate::syntax::lexer::NameTok{.sigils = sigils, .path_ = path_, .case_ = crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})};
                auto close = prism_rtl::cat("</", sigils, crate::syntax::lexer::chars::join(path_, Text::lit(".")), ">");
                CallRead this_ = CallRead{.l = l2, .attrs = Array<crate::syntax::lexer::AttrTok>{}, .body = std::optional<Array<crate::syntax::lexer::TPartTok>>{}, .going = true};
                auto name_4 = name;
                auto start_5 = start;
                call_then(loop_job(std::tuple{this_}, ({
                auto close_6 = close;
                auto delims_1_7 = delims_1;
                auto open_3_7 = open_3;
                auto start_5_7 = start_5;
                [=](std::tuple<CallRead> _p0) {
                auto this_ = std::get<0>(_p0);
                return this_.going
                    ? ({
                    this_ = call_step(this_, start_5_7, close_6, delims_1_7, open_3_7);
                    Expected<std::tuple<CallRead>, std::tuple<CallRead>>(std::tuple{this_});
                })
                    : Expected<std::tuple<CallRead>, std::tuple<CallRead>>(unexpected(std::tuple{this_}));
            };
            })), [=](std::tuple<CallRead> _p0) {
                auto this_ = std::get<0>(_p0);
                return ({
                    auto r = this_;
                    auto item = RawItem(RawItem::RiCall{name_4, r.attrs, r.body, crate::syntax::Range{.start = start_5, .end = r.l.pos}});
                    (prism_rtl::finished(std::tuple{item, r.l}));
                });
            });
            });
        });
        });
    });
}


/// `Start TemplateCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<RawItem, crate::syntax::lexer::Lex>> start_template_call(crate::syntax::lexer::Lex l0, Text delims, Text open) {
    return prism_rtl::make_rc<TemplateCall>(l0, delims, open);
}


/// CallStep: unbounded fn CallRead, Nat, Text, Text, Text -> CallRead
CallRead call_step(const CallRead& s0, const Nat& start, const Text& close, const Text& delims, const Text& open) {
    auto l = ({
        crate::syntax::lexer::Lex this_ = s0.l;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[ \\n\\r]*", ""); return r; }()), this_.src, this_.pos);
        this_;
    });
    auto s = ({
        CallRead this_ = s0;
        this_.l = l;
        this_;
    });
    auto at_ = l.pos;
    return crate::syntax::lexer::chars::starts_with(l, Text::lit("/>"))
        ? ({
        CallRead this_ = s;
        this_.l = crate::syntax::lexer::chars::forward(l, Nat(2u));
        this_.going = false;
        this_;
    })
        : crate::syntax::lexer::chars::peek(l) == Text::lit(">")
        ? ({
        auto past = crate::syntax::lexer::chars::bump(l);
        auto continues = crate::syntax::lexer::chars::peek(past) != Text::lit("\n");
        auto from = continues ? past : crate::syntax::lexer::chars::bump(past);
        auto [parts, l3] = template_body(from, close, delims, false, continues, start);
        ({
        CallRead this_ = s;
        this_.body = std::optional(parts);
        this_.l = l3;
        this_.going = false;
        this_;
    });
    })
        : !crate::syntax::lexer::chars::is_ident_start(crate::syntax::lexer::chars::peek(l))
        ? ({
        CallRead this_ = s;
        this_.l = crate::syntax::lexer::chars::lex_err(l, at_, at_ + Nat(1u), Text::lit("expected an attribute `name=value`, `/>` or `>` in a template call"));
        this_.going = false;
        this_;
    })
        : ({
        auto [aname, l3] = crate::syntax::lexer::words::lex_ident(l);
        (crate::syntax::lexer::chars::peek(l3) != Text::lit("=")
        ? ({
        CallRead this_ = s;
        this_.l = crate::syntax::lexer::chars::lex_err(l3, at_, l3.pos, Text::lit("an attribute is `name=value`"));
        this_;
    })
        : ({
        auto [tokens, l4] = attr_value(crate::syntax::lexer::chars::bump(l3), delims, open);
        ({
        CallRead this_ = s;
        this_.attrs = crate::prelude::push(this_.attrs, crate::syntax::lexer::AttrTok{.name = aname, .tokens = tokens, .span = crate::syntax::Range{.start = at_, .end = l4.pos}});
        this_.l = l4;
        this_;
    });
    }));
    });
}


prism_rtl::Turn<CallRead> CallStep::cycle() const {
    const auto& s0 = this->s0;
    const auto& start = this->start;
    const auto& close = this->close;
    const auto& delims = this->delims;
    const auto& open = this->open;
    auto l = ({
        crate::syntax::lexer::Lex this_ = s0.l;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[ \\n\\r]*", ""); return r; }()), this_.src, this_.pos);
        this_;
    });
    auto s = ({
        CallRead this_ = s0;
        this_.l = l;
        this_;
    });
    auto at_ = l.pos;
    return crate::syntax::lexer::chars::starts_with(l, Text::lit("/>"))
        ? prism_rtl::finished(({
        CallRead this_ = s;
        this_.l = crate::syntax::lexer::chars::forward(l, Nat(2u));
        this_.going = false;
        this_;
    }))
        : crate::syntax::lexer::chars::peek(l) == Text::lit(">")
        ? ({
        auto past = crate::syntax::lexer::chars::bump(l);
        auto continues = crate::syntax::lexer::chars::peek(past) != Text::lit("\n");
        auto from = continues ? past : crate::syntax::lexer::chars::bump(past);
        auto close_1 = close;
        auto delims_2 = delims;
        auto start_3 = start;
        call_then(start_template_body(from, close_1, delims_2, false, continues, start_3), [=](std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> template_body_9198) {
        return ({
            auto [parts, l3] = template_body_9198;
            (prism_rtl::finished(({
            CallRead this_ = s;
            this_.body = std::optional(parts);
            this_.l = l3;
            this_.going = false;
            this_;
        })));
        });
    });
    })
        : !crate::syntax::lexer::chars::is_ident_start(crate::syntax::lexer::chars::peek(l))
        ? prism_rtl::finished(({
        CallRead this_ = s;
        this_.l = crate::syntax::lexer::chars::lex_err(l, at_, at_ + Nat(1u), Text::lit("expected an attribute `name=value`, `/>` or `>` in a template call"));
        this_.going = false;
        this_;
    }))
        : ({
        auto delims_1 = delims;
        auto open_2 = open;
        auto start_3 = start;
        call_then(crate::syntax::lexer::words::start_lex_ident(l), [=](std::tuple<Text, crate::syntax::lexer::Lex> lex_ident_9597) {
        return ({
            auto [aname, l3] = lex_ident_9597;
            (crate::syntax::lexer::chars::peek(l3) != Text::lit("=")
            ? prism_rtl::finished(({
            CallRead this_ = s;
            this_.l = crate::syntax::lexer::chars::lex_err(l3, at_, l3.pos, Text::lit("an attribute is `name=value`"));
            this_;
        }))
            : ({
            auto [tokens, l4] = attr_value(crate::syntax::lexer::chars::bump(l3), delims_1, open_2);
            (prism_rtl::finished(({
            CallRead this_ = s;
            this_.attrs = crate::prelude::push(this_.attrs, crate::syntax::lexer::AttrTok{.name = aname, .tokens = tokens, .span = crate::syntax::Range{.start = at_, .end = l4.pos}});
            this_.l = l4;
            this_;
        })));
        }));
        });
    });
    });
}


/// `Start CallStep, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<CallRead> start_call_step(CallRead s0, Nat start, Text close, Text delims, Text open) {
    return prism_rtl::make_rc<CallStep>(s0, start, close, delims, open);
}


/// AttrValue: unbounded fn Lex, Text, Text -> (([Tok], Lex))
std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> attr_value(const crate::syntax::lexer::Lex& l, const Text& delims, const Text& open) {
    return crate::syntax::lexer::chars::starts_with(l, open)
        ? crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::forward(l, len_text(open)), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{delims}))
        : crate::syntax::lexer::chars::peek(l) == Text::lit("\"")
        ? ({
        auto [text, l2] = crate::syntax::lexer::literals::lex_text(l);
        auto tok = crate::syntax::lexer::Tok{.kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KText{Text::lit(""), text}), .span = crate::syntax::Range{.start = l.pos, .end = l2.pos}, .touches = false, .line_start = false};
        std::tuple{Array(std::vector{tok}), l2};
    })
        : std::tuple{Array<crate::syntax::lexer::Tok>{}, crate::syntax::lexer::chars::lex_err(l, l.pos, l.pos, prism_rtl::cat("an attribute's value is a placeholder `", open, "...` or a text literal"))};
}


/// FinishTemplateLines: fn Lex, [RawLine], Nat, Bool -> (([TPartTok], Lex))
std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> finish_template_lines(const crate::syntax::lexer::Lex& l0, const Array<RawLine>& lines, const Nat& strip, const bool& first_continues) {
    std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<crate::syntax::lexer::TPartTok>{}, l0};
    crate::syntax::lexer::Lex l = l0;
    Array<crate::syntax::lexer::TPartTok> parts = Array<crate::syntax::lexer::TPartTok>{};
    for (auto&& [i10950, v10950] : prism_rtl::enumerate(lines)) {
        auto k10950 = nat_of(i10950);
        auto line = v10950;
        if (line.block) {
            parts = append(parts, block_parts(line.items));
        } else  {
            auto first_ = (k10950 == Nat(0u)) && first_continues;
            auto [items, l2] = (!first_) && (strip > Nat(0u))
                ? strip_line(line, strip, l)
                : std::tuple{line.items, l};
            l = l2;
            auto non_blank = fold(items, Array<RawItem>{}, [&](const Array<RawItem>& acc, const RawItem& it) { return is_blank_or_empty(it) ? acc : crate::prelude::push(acc, it); });
            auto alone = (((!first_) && line.newline) && (len(non_blank) == Nat(1u))) && is_placeholder_item(or_(index(non_blank, Nat(0u)), RawItem(RawItem::RiText{Text::lit("")})));
            if (alone) {
                parts = crate::prelude::push(parts, alone_placeholder(items));
            } else  {
                parts = fold(items, parts, push_part);
                if (line.newline) {
                    parts = push_part(parts, RawItem(RawItem::RiText{Text::lit("\n")}));
                }
            }
        }
    }
    this_ = std::tuple{parts, l};
    return this_;
}


/// BlockParts: fn [RawItem] -> [TPartTok]
Array<crate::syntax::lexer::TPartTok> block_parts(const Array<RawItem>& items) {
    return fold(items, Array<crate::syntax::lexer::TPartTok>{}, [&](const Array<crate::syntax::lexer::TPartTok>& acc, const RawItem& it) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::lexer::TPartTok>> _v;
            if (prism_rtl::is<RawItem::RiBlock>(it)) {
                auto&& tokens = prism_rtl::as<RawItem::RiBlock>(it).a0;
                auto&& span = prism_rtl::as<RawItem::RiBlock>(it).a1;
                _v.set(crate::prelude::push(acc, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptBlock{tokens, span})));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// StripLine: fn RawLine, Nat, Lex -> (([RawItem], Lex))
std::tuple<Array<RawItem>, crate::syntax::lexer::Lex> strip_line(const RawLine& line, const Nat& strip, const crate::syntax::lexer::Lex& l) {
    auto blank = only_whitespace(line);
    auto n = ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = index(line.items, Nat(0u));
        if (prism_rtl::is_some(_m) && prism_rtl::is<RawItem::RiText>(prism_rtl::some_of(_m))) {
            auto&& s = prism_rtl::as<RawItem::RiText>(prism_rtl::some_of(_m)).a0;
            _v.set(crate::syntax::lexer::chars::leading_in(s, Text::lit(" ")));
            goto _done;
        }
        {
            _v.set(Nat(0u));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto items = ({
        __label__ _done;
        prism_rtl::Slot<Array<RawItem>> _v;
        auto&& _m = index(line.items, Nat(0u));
        if (prism_rtl::is_some(_m) && prism_rtl::is<RawItem::RiText>(prism_rtl::some_of(_m))) {
            auto&& s = prism_rtl::as<RawItem::RiText>(prism_rtl::some_of(_m)).a0;
            _v.set(({
                auto rest = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = cursor_at(s, crate::prelude::min(n, strip));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c = prism_rtl::some_of(_m);
                        _v.set(after(c));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                append(Array(std::vector{RawItem(RawItem::RiText{rest})}), drop(line.items, Nat(1u)));
            }));
            goto _done;
        }
        {
            _v.set(line.items);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto l2 = (n < strip) && (!blank)
        ? crate::syntax::lexer::chars::lex_err(l, first_item_span(items).start, first_item_span(items).end, Text::lit("a template line is indented less than its closing tag (Q-CT3)"))
        : l;
    auto kept = index(items, Nat(0u)) == std::optional(RawItem(RawItem::RiText{Text::lit("")}))
        ? drop(items, Nat(1u))
        : items;
    return std::tuple{kept, l2};
}


/// IsBlankOrEmpty: fn RawItem -> Bool
bool is_blank_or_empty(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiText>(raw_item0)) {
        auto&& s = prism_rtl::as<RawItem::RiText>(raw_item0).a0;
        return crate::syntax::lexer::chars::trim(s) == Text::lit("");
    }
    {
        return false;
    }
}


/// IsPlaceholderItem: fn RawItem -> Bool
bool is_placeholder_item(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiPlaceholder>(raw_item0)) {
        return true;
    }
    {
        return false;
    }
}


/// FirstItemSpan: fn [RawItem] -> Range
crate::syntax::Range first_item_span(const Array<RawItem>& items) {
    return or_(fold(items, std::optional<crate::syntax::Range>{}, [&](const std::optional<crate::syntax::Range>& found_opt, const RawItem& it) {
        return found_opt != std::optional<crate::syntax::Range>{}
            ? found_opt
            : item_span(it);
    }), crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)});
}


/// ?ItemSpan: fn RawItem -> ?Range
std::optional<crate::syntax::Range> item_span(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiPlaceholder>(raw_item0)) {
        auto&& span = prism_rtl::as<RawItem::RiPlaceholder>(raw_item0).a1;
        return std::optional(span);
    }
    if (prism_rtl::is<RawItem::RiBlock>(raw_item0)) {
        auto&& span = prism_rtl::as<RawItem::RiBlock>(raw_item0).a1;
        return std::optional(span);
    }
    if (prism_rtl::is<RawItem::RiCall>(raw_item0)) {
        auto&& span = prism_rtl::as<RawItem::RiCall>(raw_item0).a3;
        return std::optional(span);
    }
    {
        return std::optional<crate::syntax::Range>{};
    }
}


/// AlonePlaceholder: fn [RawItem] -> TPartTok
crate::syntax::lexer::TPartTok alone_placeholder(const Array<RawItem>& items) {
    auto&& _part = fold(items, std::tuple{Nat(0u), crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{Text::lit("")})}, [&](const std::tuple<Nat, crate::syntax::lexer::TPartTok>& _p0, const RawItem& it) {
        auto&& c = std::get<0>(_p0);
        auto&& p_ = std::get<1>(_p0);
        return alone_step(c, p_, it);
    });
    auto&& part = std::get<1>(_part);
    return part;
}


/// AloneStep: fn Nat, TPartTok, RawItem -> ((Nat, TPartTok))
std::tuple<Nat, crate::syntax::lexer::TPartTok> alone_step(const Nat& c, const crate::syntax::lexer::TPartTok& tpart_tok1, const RawItem& raw_item2) {
    auto&& _m = std::tuple{tpart_tok1, raw_item2};
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(std::get<0>(_m)) && prism_rtl::is<RawItem::RiText>(std::get<1>(_m))) {
        auto&& c0_1_0 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(std::get<0>(_m)).a0;
        auto&& s = prism_rtl::as<RawItem::RiText>(std::get<1>(_m)).a0;
        if (c0_1_0 == Text::lit("")) {
            return c == Nat(0u)
                ? std::tuple{crate::syntax::lexer::chars::leading_in(s, Text::lit(" ")), crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{Text::lit("")})}
                : std::tuple{c, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{Text::lit("")})};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(std::get<0>(_m)) && prism_rtl::is<RawItem::RiPlaceholder>(std::get<1>(_m))) {
        auto&& c1_1_0 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(std::get<0>(_m)).a0;
        auto&& tokens = prism_rtl::as<RawItem::RiPlaceholder>(std::get<1>(_m)).a0;
        auto&& span = prism_rtl::as<RawItem::RiPlaceholder>(std::get<1>(_m)).a1;
        if (c1_1_0 == Text::lit("")) {
            return std::tuple{c, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptPlaceholder{tokens, std::optional(c), span})};
        }
    }
    {
        auto&& p_ = std::get<0>(_m);
        return std::tuple{c, p_};
    }
    prism_rtl::unreachable("no arm matched");
}


/// PushPart: fn [TPartTok], RawItem -> [TPartTok]
Array<crate::syntax::lexer::TPartTok> push_part(const Array<crate::syntax::lexer::TPartTok>& parts, const RawItem& raw_item1) {
    if (prism_rtl::is<RawItem::RiText>(raw_item1)) {
        auto&& c0_1_0 = prism_rtl::as<RawItem::RiText>(raw_item1).a0;
        if (c0_1_0 == Text::lit("")) {
            return parts;
        }
    }
    if (prism_rtl::is<RawItem::RiText>(raw_item1)) {
        auto&& t = prism_rtl::as<RawItem::RiText>(raw_item1).a0;
        auto&& _m = crate::syntax::lexer::chars::last(parts);
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(prism_rtl::some_of(_m))) {
            auto&& s = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(prism_rtl::some_of(_m)).a0;
            return crate::prelude::push(crate::syntax::lexer::chars::pop(parts), crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{prism_rtl::cat(s, t)}));
        }
        {
            return crate::prelude::push(parts, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{t}));
        }
    }
    if (prism_rtl::is<RawItem::RiPlaceholder>(raw_item1)) {
        auto&& tokens = prism_rtl::as<RawItem::RiPlaceholder>(raw_item1).a0;
        auto&& span = prism_rtl::as<RawItem::RiPlaceholder>(raw_item1).a1;
        return crate::prelude::push(parts, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptPlaceholder{tokens, std::optional<Nat>{}, span}));
    }
    if (prism_rtl::is<RawItem::RiBlock>(raw_item1)) {
        auto&& tokens = prism_rtl::as<RawItem::RiBlock>(raw_item1).a0;
        auto&& span = prism_rtl::as<RawItem::RiBlock>(raw_item1).a1;
        return crate::prelude::push(parts, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptBlock{tokens, span}));
    }
    if (prism_rtl::is<RawItem::RiCall>(raw_item1)) {
        auto&& name = prism_rtl::as<RawItem::RiCall>(raw_item1).a0;
        auto&& attrs = prism_rtl::as<RawItem::RiCall>(raw_item1).a1;
        auto&& body_opt = prism_rtl::as<RawItem::RiCall>(raw_item1).a2;
        auto&& span = prism_rtl::as<RawItem::RiCall>(raw_item1).a3;
        return crate::prelude::push(parts, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptCall{name, attrs, body_opt, span}));
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::syntax::lexer::templates
