// The module `Syntax.Lexer`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/lexer/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::lexer {

Lex fresh_f(const Lex& l_p0, const Mode& mode_p1);

bool is_layout_or_eof_f(const TokKind& tok_kind0);

bool is_layout_f(const TokKind& tok_kind0);

bool ends_operand_f(const TokKind& tok_kind0);

bool is_value_word_f(const Text& w_p0);

bool is_bound_word_f(const Text& w_p0);

Array<Text> keyword_list_p();

Map<Text, bool> keyword_set_p();

bool is_keyword_f(const Text& w_p0);

bool takes_suffix_f(const Text& op_p0);

Text close_char_f(const Text& text0);

Text open_of_f(const Text& text0);

bool prefix_position_f(const Lex& l_p0);

bool no_operand_before_f(const std::optional<Tok>& opt0);

Text test_word_of_f(const TokKind& tok_kind0);

bool all_layout_f(const Array<Tok>& ts_p0);

Lex push_tok_f(const Lex& l_p0, const TokKind& kind_p1, const Nat& start_p2, const Nat& end_p3);

bool layout_on_f(const Mode& mode0);

bool layout_active_f(const Lex& l_p0);

bool fat_arrow_on_f(const Lex& l_p0);

}  // namespace syntax::lexer



}  // namespace crate
