// The module `Syntax.Lexer`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/lexer/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::lexer {

Lex fresh(const Lex& l, const Mode& mode);

bool is_layout_or_eof(const TokKind& tok_kind0);

bool is_layout(const TokKind& tok_kind0);

bool ends_operand(const TokKind& tok_kind0);

bool is_value_word(const Text& w);

bool is_bound_word(const Text& w);

Array<Text> keyword_list();

Map<Text, bool> keyword_set();

bool is_keyword(const Text& w);

bool takes_suffix(const Text& op);

Text close_char(const Text& text0);

Text open_of(const Text& text0);

bool prefix_position(const Lex& l);

bool no_operand_before(const std::optional<Tok>& opt0);

Text test_word_of(const TokKind& tok_kind0);

bool all_layout(const Array<Tok>& ts);

Lex push_tok(const Lex& l, const TokKind& kind, const Nat& start, const Nat& end);

bool layout_on(const Mode& mode0);

bool layout_active(const Lex& l);

bool fat_arrow_on(const Lex& l);

}  // namespace syntax::lexer



}  // namespace crate
