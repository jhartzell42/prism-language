// The module `Syntax.Lexer`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace syntax::lexer {

struct AttrTok;

struct Lex;

struct Lexed;

class Mode;

class NameCase;

struct NameTok;

class PathSegTok;

class TPartTok;

struct TemplateTok;

class TextSegTok;

struct Tok;

class TokKind;

}  // namespace syntax::lexer

}  // namespace crate
