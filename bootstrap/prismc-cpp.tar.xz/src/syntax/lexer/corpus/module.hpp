// The module `Syntax.Lexer.Corpus`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/lexer/corpus/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::lexer::corpus {

Text render_tokens(const Array<crate::syntax::lexer::Tok>& tokens);

std::tuple<Text, std::optional<crate::syntax::lexer::Tok>> render_step(const Text& acc, const std::optional<crate::syntax::lexer::Tok>& prev_opt, const crate::syntax::lexer::Tok& t);

bool is_bracket(const crate::syntax::lexer::TokKind& tok_kind0);

Text render_inner(const Array<crate::syntax::lexer::Tok>& tokens);

Text trim_newlines(const Text& t);

Text token_text(const crate::syntax::lexer::TokKind& tok_kind0);

Text seg_text(const crate::syntax::lexer::TextSegTok& text_seg_tok0);

Text escape_braces(const Text& t);

Text path_seg_text(const crate::syntax::lexer::PathSegTok& path_seg_tok0);

Text part_text(const crate::syntax::lexer::TPartTok& tpart_tok0);

Text col_text(const std::optional<Nat>& opt0);

Text attr_text(const crate::syntax::lexer::AttrTok& a);

Text call_body(const crate::syntax::lexer::NameTok& name_tok0, const std::optional<Array<crate::syntax::lexer::TPartTok>>& opt1);

Text debug_text(const Text& t);

Text debug_char(const Text& c);

Text escape_debug(const Text& t, const bool& single, const bool& double_);

Text escape_char(const Text& c, const bool& single, const bool& double_);

Nat code_of(const Text& c);

Text hex_of(const Nat& n);

Text hex_digits(const Nat& n, const Nat& fuel);

}  // namespace syntax::lexer::corpus



}  // namespace crate
