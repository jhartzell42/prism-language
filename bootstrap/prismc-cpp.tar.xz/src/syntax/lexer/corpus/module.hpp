// The module `Syntax.Lexer.Corpus`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/lexer/corpus/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::lexer::corpus {

Text render_tokens(const Array<crate::syntax::lexer::Tok>& tokens_p0);

std::tuple<Text, std::optional<crate::syntax::lexer::Tok>> render_step(const Text& acc_p0, const std::optional<crate::syntax::lexer::Tok>& prev_o1, const crate::syntax::lexer::Tok& t_p2);

bool is_bracket(const crate::syntax::lexer::TokKind& tok_kind0);

Text render_inner(const Array<crate::syntax::lexer::Tok>& tokens_p0);

Text trim_newlines(const Text& t_p0);

Text token_text(const crate::syntax::lexer::TokKind& tok_kind0);

Text replacement_text(const std::optional<Text>& opt0);

Text seg_text(const crate::syntax::lexer::TextSegTok& text_seg_tok0);

Text escape_braces(const Text& t_p0);

Text path_seg_text(const crate::syntax::lexer::PathSegTok& path_seg_tok0);

Text part_text(const crate::syntax::lexer::TPartTok& tpart_tok0);

Text col_text(const std::optional<Nat>& opt0);

Text attr_text(const crate::syntax::lexer::AttrTok& a_p0);

Text call_body(const crate::syntax::lexer::NameTok& name_tok0, const std::optional<Array<crate::syntax::lexer::TPartTok>>& opt1);

Text debug_text(const Text& t_p0);

Text debug_char(const Text& c_p0);

Text escape_debug(const Text& t_p0, const bool& single_p1, const bool& double_p2);

Text escape_char(const Text& c_p0, const bool& single_p1, const bool& double_p2);

Nat code_of(const Text& c_p0);

Text hex_of(const Nat& n_p0);

Text hex_digits(const Nat& n_p0, const Nat& fuel_p1);

}  // namespace syntax::lexer::corpus



}  // namespace crate
