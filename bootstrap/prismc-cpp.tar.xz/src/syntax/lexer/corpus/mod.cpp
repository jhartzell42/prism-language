// The module `Syntax.Lexer.Corpus`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/corpus.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

namespace crate::syntax::lexer::corpus {

/// RenderTokens: fn [Tok] -> Text
Text render_tokens(const Array<crate::syntax::lexer::Tok>& tokens) {
    auto&& _out = fold(tokens, std::tuple{Text::lit(""), std::optional<crate::syntax::lexer::Tok>{}}, [&](const std::tuple<Text, std::optional<crate::syntax::lexer::Tok>>& _p0, const crate::syntax::lexer::Tok& t) {
        auto&& acc = std::get<0>(_p0);
        auto&& prev_opt = std::get<1>(_p0);
        return render_step(acc, prev_opt, t);
    });
    auto&& out = std::get<0>(_out);
    return prism_rtl::cat(out, "\n");
}


/// RenderStep: fn Text, ?Tok, Tok -> ((Text, ?Tok))
std::tuple<Text, std::optional<crate::syntax::lexer::Tok>> render_step(const Text& acc, const std::optional<crate::syntax::lexer::Tok>& prev_opt, const crate::syntax::lexer::Tok& t) {
    auto gap = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_none(prev_opt)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        if (prism_rtl::is_some(prev_opt)) {
            auto&& p_ = prism_rtl::some_of(prev_opt);
            _v.set(crate::syntax::lexer::is_layout(t.kind)
                ? Text::lit("\n")
                : (is_bracket(p_.kind) && is_bracket(t.kind)) && t.touches
                ? Text::lit("·")
                : Text::lit(" "));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return t.kind == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{})
        ? std::tuple{acc, std::optional(t)}
        : std::tuple{prism_rtl::cat(acc, gap, token_text(t.kind)), std::optional(t)};
}


/// IsBracket: fn TokKind -> Bool
bool is_bracket(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KClose>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// RenderInner: fn [Tok] -> Text
Text render_inner(const Array<crate::syntax::lexer::Tok>& tokens) {
    return crate::syntax::lexer::chars::join(split(crate::syntax::lexer::chars::trim_end(trim_newlines(render_tokens(tokens))), Text::lit("\n")), Text::lit(" "));
}


/// TrimNewlines: fn Text -> Text
Text trim_newlines(const Text& t) {
    return crate::syntax::lexer::chars::trim_trailing(t, Text::lit("\n \t"));
}


/// TokenText: fn TokKind -> Text
Text token_text(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(tok_kind0)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(tok_kind0).a0;
        return prism_rtl::cat(n.sigils, crate::syntax::lexer::chars::join(n->path_, Text::lit(".")));
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(tok_kind0)) {
        auto&& p_ = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(tok_kind0).a0;
        return prism_rtl::cat(crate::syntax::lexer::chars::join(p_, Text::lit(".")), ".*");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTrait>(tok_kind0)) {
        auto&& p_ = prism_rtl::as<crate::syntax::lexer::TokKind::KTrait>(tok_kind0).a0;
        return prism_rtl::cat("^", crate::syntax::lexer::chars::join(p_, Text::lit(".")));
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(tok_kind0)) {
        auto&& w = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(tok_kind0).a0;
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(tok_kind0).a1;
        return prism_rtl::cat(s, w);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(tok_kind0)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(tok_kind0).a0;
        return prism_rtl::cat("free", s);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLensDot>(tok_kind0)) {
        return Text::lit("&.");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(tok_kind0)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(tok_kind0).a0;
        auto&& t = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(tok_kind0).a1;
        return prism_rtl::cat(s, t);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(tok_kind0)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFloat>(tok_kind0).a0;
        auto&& t = prism_rtl::as<crate::syntax::lexer::TokKind::KFloat>(tok_kind0).a1;
        return prism_rtl::cat(s, t);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(tok_kind0)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KDuration>(tok_kind0).a0;
        auto&& t = prism_rtl::as<crate::syntax::lexer::TokKind::KDuration>(tok_kind0).a1;
        auto&& u = prism_rtl::as<crate::syntax::lexer::TokKind::KDuration>(tok_kind0).a2;
        return prism_rtl::cat(s, t, u);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(tok_kind0)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KChar>(tok_kind0).a0;
        auto&& c = prism_rtl::as<crate::syntax::lexer::TokKind::KChar>(tok_kind0).a1;
        return prism_rtl::cat(s, debug_char(c));
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(tok_kind0)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(tok_kind0).a0;
        auto&& segs = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(tok_kind0).a1;
        return prism_rtl::cat(s, "TEXT(", concat(each(segs, seg_text)), ")");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTemplate>(tok_kind0)) {
        auto&& t = prism_rtl::as<crate::syntax::lexer::TokKind::KTemplate>(tok_kind0).a0;
        return prism_rtl::cat("TEMPLATE<", t.lang, ">(", concat(each(t.parts, part_text)), ")");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(tok_kind0) && prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(tok_kind0).a1) {
        auto&& op = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(tok_kind0).a0;
        return prism_rtl::cat(op, "pre");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(tok_kind0) && !prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(tok_kind0).a1) {
        auto&& op = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(tok_kind0).a0;
        return op;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KSuffixed>(tok_kind0)) {
        auto&& op = prism_rtl::as<crate::syntax::lexer::TokKind::KSuffixed>(tok_kind0).a0;
        auto&& ty = prism_rtl::as<crate::syntax::lexer::TokKind::KSuffixed>(tok_kind0).a1;
        return prism_rtl::cat(op, crate::syntax::lexer::chars::join(ty, Text::lit(".")));
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(tok_kind0) && prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(tok_kind0).a0) {
        return Text::lit(".pre");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(tok_kind0) && !prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(tok_kind0).a0) {
        return Text::lit(".");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDotDot>(tok_kind0)) {
        return Text::lit("..");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KComma>(tok_kind0)) {
        return Text::lit(",");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KColon>(tok_kind0)) {
        return Text::lit(":");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KSemi>(tok_kind0)) {
        return Text::lit(";");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KBackslash>(tok_kind0)) {
        return Text::lit("\\");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLambdaBar>(tok_kind0)) {
        return Text::lit("|");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KBar>(tok_kind0)) {
        return Text::lit("|");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLtLt>(tok_kind0)) {
        return Text::lit("<<");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KGtGt>(tok_kind0)) {
        return Text::lit(">>");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(tok_kind0)) {
        auto&& k = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(tok_kind0).a0;
        return k;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KClose>(tok_kind0)) {
        auto&& k = prism_rtl::as<crate::syntax::lexer::TokKind::KClose>(tok_kind0).a0;
        return crate::syntax::lexer::close_char(k);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KAbsent>(tok_kind0)) {
        return Text::lit("absent");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KNonEmpty>(tok_kind0)) {
        return Text::lit("nonempty");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KPath>(tok_kind0)) {
        auto&& segs = prism_rtl::as<crate::syntax::lexer::TokKind::KPath>(tok_kind0).a0;
        return prism_rtl::cat("PATH(", crate::syntax::lexer::chars::join(each(segs, path_seg_text), Text::lit("/")), ")");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayOpen>(tok_kind0)) {
        return Text::lit("open");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(tok_kind0)) {
        return Text::lit("sep");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(tok_kind0)) {
        return Text::lit("close");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(tok_kind0)) {
        return Text::lit("eof");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SegText: fn TextSegTok -> Text
Text seg_text(const crate::syntax::lexer::TextSegTok& text_seg_tok0) {
    if (prism_rtl::is<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok0)) {
        auto&& p_ = prism_rtl::as<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok0).a0;
        return escape_braces(escape_debug(p_, true, true));
    }
    if (prism_rtl::is<crate::syntax::lexer::TextSegTok::TsPlaceholder>(text_seg_tok0)) {
        auto&& toks = prism_rtl::as<crate::syntax::lexer::TextSegTok::TsPlaceholder>(text_seg_tok0).a0;
        return prism_rtl::cat("{", render_inner(toks), "}");
    }
    prism_rtl::unreachable("no arm matched");
}


/// EscapeBraces: fn Text -> Text
Text escape_braces(const Text& t) {
    return crate::syntax::lexer::chars::map_chars(t, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return once_job([=]() {
            return ({
                auto c = p0;
                (c == Text::lit("{")) || (c == Text::lit("}"))
                ? prism_rtl::finished(prism_rtl::cat("\\", c))
                : prism_rtl::finished(c);
            });
        });
    })));
}


/// PathSegText: fn PathSegTok -> Text
Text path_seg_text(const crate::syntax::lexer::PathSegTok& path_seg_tok0) {
    if (prism_rtl::is<crate::syntax::lexer::PathSegTok::PstNum>(path_seg_tok0)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::PathSegTok::PstNum>(path_seg_tok0).a0;
        return prism_rtl::cat(n);
    }
    if (prism_rtl::is<crate::syntax::lexer::PathSegTok::PstGen>(path_seg_tok0)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::PathSegTok::PstGen>(path_seg_tok0).a0;
        return prism_rtl::cat("#", n);
    }
    if (prism_rtl::is<crate::syntax::lexer::PathSegTok::PstKey>(path_seg_tok0)) {
        auto&& toks = prism_rtl::as<crate::syntax::lexer::PathSegTok::PstKey>(path_seg_tok0).a0;
        return prism_rtl::cat("[", render_inner(toks), "]");
    }
    prism_rtl::unreachable("no arm matched");
}


/// PartText: fn TPartTok -> Text
Text part_text(const crate::syntax::lexer::TPartTok& tpart_tok0) {
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(tpart_tok0)) {
        auto&& t = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(tpart_tok0).a0;
        return debug_text(t);
    }
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok0)) {
        auto&& toks = prism_rtl::as<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok0).a0;
        auto&& col_opt = prism_rtl::as<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok0).a1;
        return prism_rtl::cat("{{", render_inner(toks), "}}", col_text(col_opt));
    }
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptBlock>(tpart_tok0)) {
        auto&& toks = prism_rtl::as<crate::syntax::lexer::TPartTok::TptBlock>(tpart_tok0).a0;
        return prism_rtl::cat("BLOCK{ ", render_inner(toks), " }");
    }
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok0)) {
        auto&& name = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok0).a0;
        auto&& attrs = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok0).a1;
        auto&& body_opt = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok0).a2;
        return prism_rtl::cat("<", name.sigils, crate::syntax::lexer::chars::join(name->path_, Text::lit(".")), concat(each(attrs, attr_text)), call_body(name, body_opt));
    }
    prism_rtl::unreachable("no arm matched");
}


/// ColText: fn ?Nat -> Text
Text col_text(const std::optional<Nat>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& c = prism_rtl::some_of(opt0);
        return prism_rtl::cat("@col", c);
    }
    prism_rtl::unreachable("no arm matched");
}


/// AttrText: fn AttrTok -> Text
Text attr_text(const crate::syntax::lexer::AttrTok& a) {
    return prism_rtl::cat(" ", a.name, "={", render_inner(a->tokens), "}");
}


/// CallBody: fn NameTok, ?[TPartTok] -> Text
Text call_body(const crate::syntax::lexer::NameTok& name_tok0, const std::optional<Array<crate::syntax::lexer::TPartTok>>& opt1) {
    auto&& _m = std::tuple{name_tok0, opt1};
    if (prism_rtl::is_none(std::get<1>(_m))) {
        return Text::lit("/>");
    }
    if (prism_rtl::is_some(std::get<1>(_m))) {
        auto&& name = std::get<0>(_m);
        auto&& parts = prism_rtl::some_of(std::get<1>(_m));
        return prism_rtl::cat(">", concat(each(parts, part_text)), "</", name.sigils, crate::syntax::lexer::chars::join(name->path_, Text::lit(".")), ">");
    }
    prism_rtl::unreachable("no arm matched");
}


/// DebugText: fn Text -> Text
Text debug_text(const Text& t) {
    return prism_rtl::cat("\"", escape_debug(t, false, true), "\"");
}


/// DebugChar: fn Text -> Text
Text debug_char(const Text& c) {
    return prism_rtl::cat("\'", escape_debug(c, true, false), "\'");
}


/// EscapeDebug: fn Text, Bool, Bool -> Text
Text escape_debug(const Text& t, const bool& single, const bool& double_) {
    return crate::syntax::lexer::chars::map_chars(t, ({
        auto single_1 = single;
        auto double__2 = double_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto single_1_3 = single_1;
            auto double__2_3 = double__2;
            once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::finished(escape_char(c, single_1_3, double__2_3)));
            });
        });
        });
    })));
    }));
}


/// EscapeChar: fn Text, Bool, Bool -> Text
Text escape_char(const Text& c, const bool& single, const bool& double_) {
    {
        auto&& m4807_0 = c;
        if (m4807_0 == Text::lit("\000"sv)) {
            return Text::lit("\\0");
        }
    }
    {
        auto&& m4807_1 = c;
        if (m4807_1 == Text::lit("\t")) {
            return Text::lit("\\t");
        }
    }
    {
        auto&& m4807_2 = c;
        if (m4807_2 == Text::lit("\r")) {
            return Text::lit("\\r");
        }
    }
    {
        auto&& m4807_3 = c;
        if (m4807_3 == Text::lit("\n")) {
            return Text::lit("\\n");
        }
    }
    {
        auto&& m4807_4 = c;
        if (m4807_4 == Text::lit("\\")) {
            return Text::lit("\\\\");
        }
    }
    {
        auto&& m4807_5 = c;
        if (m4807_5 == Text::lit("\'")) {
            if (single) {
                return Text::lit("\\\'");
            }
        }
    }
    {
        auto&& m4807_6 = c;
        if (m4807_6 == Text::lit("\"")) {
            if (double_) {
                return Text::lit("\\\"");
            }
        }
    }
    {
        if ((c < Text::lit(" ")) || (c == Text::lit(""))) {
            return prism_rtl::cat("\\u{", hex_of(code_of(c)), "}");
        }
    }
    {
        return c;
    }
}


/// CodeOf: fn Text -> Nat
Nat code_of(const Text& c) {
    return c == Text::lit("")
        ? Nat(128u)
        : len_text(or_(index(split(crate::syntax::lexer::chars::ascii_text(), c), Nat(0u)), crate::syntax::lexer::chars::ascii_text()));
}


/// HexOf: fn Nat -> Text
Text hex_of(const Nat& n) {
    return hex_digits(n, n);
}


/// HexDigits: fn Nat, Nat -> Text
Text hex_digits(const Nat& n, const Nat& fuel) {
    auto&& _m = fuel.checked_sub(Nat(1u));
    if (prism_rtl::is_some(_m)) {
        auto&& left = prism_rtl::some_of(_m);
        if (n >= Nat(16u)) {
            return prism_rtl::cat(hex_digits(or_(div(n, Nat(16u)), Nat(0u)), left), crate::syntax::lexer::chars::char_at_byte(crate::syntax::lexer::chars::hex_digits(), or_(mod_(n, Nat(16u)), Nat(0u))));
        }
    }
    {
        return n < Nat(16u)
            ? crate::syntax::lexer::chars::char_at_byte(crate::syntax::lexer::chars::hex_digits(), n)
            : Text::lit("0");
    }
}

}  // namespace crate::syntax::lexer::corpus
