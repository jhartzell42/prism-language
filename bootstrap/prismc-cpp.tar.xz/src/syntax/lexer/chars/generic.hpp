// The module `Syntax.Lexer.Chars`: its generic functions' and types' definitions, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/lexer/chars/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>

namespace crate {

using namespace prelude;

namespace syntax::lexer::chars {

/// ?Last: fn [a] -> ?a
template <class A>
std::optional<A> last(const Array<A>& xs) {
    return index(xs, dec(len(xs)));
}


/// Pop: fn [a] -> [a]
template <class A>
Array<A> pop(const Array<A>& xs) {
    return take(xs, dec(len(xs)));
}


/// FoldChars: fn Text, b, (fn b, Text -> b) -> b
template <class B>
B fold_chars(const Text& t, const B& z, const prism_rtl::Fn<prism_rtl::JobRef<B>(std::tuple<B, Text>)>& f_fn) {
    B this_ = z;
    Cursor c = front(t);
    while (true) {
        auto&& _m = step(c);
        if (!(prism_rtl::is_some(_m))) break;
        auto&& next = std::get<1>(prism_rtl::some_of(_m));
        this_ = run_to_end(f_fn(std::tuple{this_, char_at(c)}));
        c = next;
    }
    return this_;
}


template <class B>
prism_rtl::Turn<B> FoldChars<B>::cycle() const {
    const auto& t = this->t;
    const auto& z = this->z;
    const auto& f_fn = this->f_fn;
    return prism_rtl::finished(({
        B this_ = z;
        Cursor c = front(t);
        while (true) {
            auto&& _m = step(c);
            if (!(prism_rtl::is_some(_m))) break;
            auto&& next = std::get<1>(prism_rtl::some_of(_m));
            this_ = run_to_end(f_fn(std::tuple{this_, char_at(c)}));
            c = next;
        }
        this_;
    }));
}


/// `Start FoldChars, x`: what the function value is when passed to `@Run`.
template <class B>
prism_rtl::JobRef<B> start_fold_chars(Text t, B z, prism_rtl::Fn<prism_rtl::JobRef<B>(std::tuple<B, Text>)> f_fn) {
    return prism_rtl::make_rc<FoldChars<B>>(t, z, f_fn);
}


}  // namespace syntax::lexer::chars

}  // namespace crate
