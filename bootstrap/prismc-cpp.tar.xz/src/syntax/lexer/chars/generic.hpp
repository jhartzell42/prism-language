// The module `Syntax.Lexer.Chars`: its generic functions' and types' definitions, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/lexer/chars/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>

namespace crate {

using namespace prelude;

namespace syntax::lexer::chars {

/// ?Last: fn [a] -> ?a
template <class A>
std::optional<A> last(const Array<A>& xs_p0) {
    return index(xs_p0, dec(len(xs_p0)));
}


/// Pop: fn [a] -> [a]
template <class A>
Array<A> pop(const Array<A>& xs_p0) {
    return take(xs_p0, dec(len(xs_p0)));
}


/// FoldChars: fn Text, b, (fn b, Text -> b) -> b
template <class B>
B fold_chars(const Text& t_p0, const B& z_p1, const prism_rtl::Fn<prism_rtl::JobRef<B>(std::tuple<B, Text>)>& f_f2) {
    B this_ = z_p1;
    Cursor c_p3 = front(t_p0);
    while (true) {
        auto&& _m = step(c_p3);
        if (!(prism_rtl::is_some(_m))) break;
        auto&& next_p4 = std::get<1>(prism_rtl::some_of(_m));
        this_ = run_to_end(f_f2(std::tuple{this_, char_at(c_p3)}));
        c_p3 = next_p4;
    }
    return this_;
}


template <class B>
prism_rtl::Turn<B> FoldChars<B>::cycle() const {
    const auto& t_p0 = this->t_p0;
    const auto& z_p1 = this->z_p1;
    const auto& f_f2 = this->f_f2;
    return prism_rtl::finished(({
        B this_ = z_p1;
        Cursor c_p3 = front(t_p0);
        while (true) {
            auto&& _m = step(c_p3);
            if (!(prism_rtl::is_some(_m))) break;
            auto&& next_p4 = std::get<1>(prism_rtl::some_of(_m));
            this_ = run_to_end(f_f2(std::tuple{this_, char_at(c_p3)}));
            c_p3 = next_p4;
        }
        (std::move(this_));
    }));
}


/// `Start FoldChars, x`: what the function value is when passed to `@Run`.
template <class B>
prism_rtl::JobRef<B> start_fold_chars(Text t_p0, B z_p1, prism_rtl::Fn<prism_rtl::JobRef<B>(std::tuple<B, Text>)> f_f2) {
    return prism_rtl::make_rc<FoldChars<B>>(t_p0, z_p1, f_f2);
}


}  // namespace syntax::lexer::chars

}  // namespace crate
