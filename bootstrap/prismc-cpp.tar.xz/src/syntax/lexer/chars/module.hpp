// The module `Syntax.Lexer.Chars`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/lexer/chars/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::lexer::chars {

Nat dec(const Nat& n);

template <class A>
std::optional<A> last(const Array<A>& xs);

template <class A>
Array<A> pop(const Array<A>& xs);

Text join(const Array<Text>& xs, const Text& sep);

Text char_at(const Cursor& c);

Text head(const Text& t);

Text after_first(const Text& t);

Text last_char(const Text& t);

Text before_last(const Text& t);

Text between(const Text& t, const Nat& a, const Nat& b);

std::optional<Text> after_prefix(const Text& t, const Text& p_);

bool has_prefix(const Text& t, const Text& p_);

Text drop_prefix(const Text& t, const Text& p_);

std::optional<Text> before_suffix(const Text& t, const Text& s);

bool has_suffix(const Text& t, const Text& s);

template <class B>
B fold_chars(const Text& t, const B& z, const prism_rtl::Fn<prism_rtl::JobRef<B>(std::tuple<B, Text>)>& f_fn);

template <class B>
prism_rtl::JobRef<B> start_fold_chars(Text t, B z, prism_rtl::Fn<prism_rtl::JobRef<B>(std::tuple<B, Text>)> f_fn);

Text map_chars(const Text& t, const prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>& f_fn);

Nat count_chars(const Text& t);

Nat column_of(const Text& text, const Nat& from, const Nat& offset);

bool all_chars(const Text& t, const prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>& p__fn);

Text trim_leading(const Text& t, const Text& set);

Text trim_trailing(const Text& t, const Text& set);

Text trim_start(const Text& t);

Text trim_end(const Text& t);

Text trim(const Text& t);

Nat leading_in(const Text& t, const Text& set);

bool contains(const Text& set, const Text& c);

bool is_digit(const Text& c);

bool is_upper(const Text& c);

bool is_lower(const Text& c);

bool is_ident_start(const Text& c);

bool is_ident_char(const Text& c);

bool is_hex_digit(const Text& c);

bool is_non_ascii(const Text& c);

bool is_sigil_char(const Text& c);

bool is_space_char(const Text& c);

bool is_reserved_ctor(const Text& w);

Text ascii_text();

Text hex_digits();

Text char_at_byte(const Text& t, const Nat& n);

Nat hex_value(const Text& c);

std::optional<Nat> parse_hex(const Text& t);

std::optional<Text> ascii_char(const Nat& n);

Text rest(const crate::syntax::lexer::Lex& l);

Text peek(const crate::syntax::lexer::Lex& l);

Text peek_at(const crate::syntax::lexer::Lex& l, const Nat& n);

bool starts_with(const crate::syntax::lexer::Lex& l, const Text& s);

Text slice(const crate::syntax::lexer::Lex& l, const Nat& a, const Nat& b);

crate::syntax::lexer::Lex bump(const crate::syntax::lexer::Lex& l);

crate::syntax::lexer::Lex forward(const crate::syntax::lexer::Lex& l, const Nat& n);

bool next_is_space(const crate::syntax::lexer::Lex& l, const Nat& n);

Nat line_end(const crate::syntax::lexer::Lex& l);

Text rest_of_line(const crate::syntax::lexer::Lex& l);

prism_rtl::JobRef<Text> start_rest_of_line(crate::syntax::lexer::Lex l);

crate::syntax::lexer::Lex lex_err(const crate::syntax::lexer::Lex& l, const Nat& start, const Nat& end, const Text& message);

crate::syntax::Diag lex_diag(const crate::syntax::Range& span, const Text& message);

}  // namespace syntax::lexer::chars


namespace syntax::lexer::chars {

/// The step machine of `FoldChars`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FoldChars: fn Text, b, (fn b, Text -> b) -> b
template <class B>
struct FoldChars : prism_rtl::Job<B> {
    Text t;
    B z;
    prism_rtl::Fn<prism_rtl::JobRef<B>(std::tuple<B, Text>)> f_fn;
    FoldChars(Text t, B z, prism_rtl::Fn<prism_rtl::JobRef<B>(std::tuple<B, Text>)> f_fn) : t(std::move(t)), z(std::move(z)), f_fn(std::move(f_fn)) {}
    prism_rtl::Turn<B> cycle() const override;
};


/// The step machine of `RestOfLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RestOfLine: unbounded fn Lex -> Text
struct RestOfLine : prism_rtl::Job<Text> {
    crate::syntax::lexer::Lex l;
    RestOfLine(crate::syntax::lexer::Lex l) : l(std::move(l)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


}  // namespace syntax::lexer::chars

}  // namespace crate
