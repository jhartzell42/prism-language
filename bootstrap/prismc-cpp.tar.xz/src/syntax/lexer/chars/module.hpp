// The module `Syntax.Lexer.Chars`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/lexer/chars/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::lexer::chars {

Nat dec_f(const Nat& n_p0);

template <class A>
std::optional<A> last_o(const Array<A>& xs_p0);

template <class A>
Array<A> pop_f(const Array<A>& xs_p0);

Text join_f(const Array<Text>& xs_p0, const Text& sep_p1);

Text char_at_f(const Cursor& c_p0);

Text head_f(const Text& t_p0);

Text after_first_f(const Text& t_p0);

Text last_char_f(const Text& t_p0);

Text before_last_f(const Text& t_p0);

Text between_f(const Text& t_p0, const Nat& a_p1, const Nat& b_p2);

std::optional<Text> after_prefix_o(const Text& t_p0, const Text& p_p1);

bool has_prefix_f(const Text& t_p0, const Text& p_p1);

Text drop_prefix_f(const Text& t_p0, const Text& p_p1);

std::optional<Text> before_suffix_o(const Text& t_p0, const Text& s_p1);

bool has_suffix_f(const Text& t_p0, const Text& s_p1);

template <class B>
B fold_chars_f(const Text& t_p0, const B& z_p1, const prism_rtl::Fn<prism_rtl::JobRef<B>(std::tuple<B, Text>)>& f_f2);

template <class B>
prism_rtl::JobRef<B> start_fold_chars_f(Text t_p0, B z_p1, prism_rtl::Fn<prism_rtl::JobRef<B>(std::tuple<B, Text>)> f_f2);

Text map_chars_f(const Text& t_p0, const prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>& f_f1);

Nat count_chars_f(const Text& t_p0);

Nat column_of_f(const Text& text_p0, const Nat& from_p1, const Nat& offset_p2);

bool all_chars_f(const Text& t_p0, const prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>& p_f1);

Text trim_leading_f(const Text& t_p0, const Text& set_p1);

Text trim_trailing_f(const Text& t_p0, const Text& set_p1);

Text trim_start_f(const Text& t_p0);

Text trim_end_f(const Text& t_p0);

Text trim_f(const Text& t_p0);

Nat leading_in_f(const Text& t_p0, const Text& set_p1);

bool contains_f(const Text& set_p0, const Text& c_p1);

bool is_digit_f(const Text& c_p0);

bool is_upper_f(const Text& c_p0);

bool is_lower_f(const Text& c_p0);

bool is_ident_start_f(const Text& c_p0);

bool is_ident_char_f(const Text& c_p0);

bool is_hex_digit_f(const Text& c_p0);

bool is_non_ascii_f(const Text& c_p0);

bool is_sigil_char_f(const Text& c_p0);

bool is_space_char_f(const Text& c_p0);

bool is_reserved_ctor_f(const Text& w_p0);

Text ascii_text_p();

Text hex_digits_p();

Text char_at_byte_f(const Text& t_p0, const Nat& n_p1);

Nat hex_value_f(const Text& c_p0);

std::optional<Nat> parse_hex_o(const Text& t_p0);

Text rest_f(const crate::syntax::lexer::Lex& l_p0);

Text peek_f(const crate::syntax::lexer::Lex& l_p0);

Text peek_at_f(const crate::syntax::lexer::Lex& l_p0, const Nat& n_p1);

bool starts_with_f(const crate::syntax::lexer::Lex& l_p0, const Text& s_p1);

Text slice_f(const crate::syntax::lexer::Lex& l_p0, const Nat& a_p1, const Nat& b_p2);

crate::syntax::lexer::Lex bump_f(const crate::syntax::lexer::Lex& l_p0);

crate::syntax::lexer::Lex forward_f(const crate::syntax::lexer::Lex& l_p0, const Nat& n_p1);

bool next_is_space_f(const crate::syntax::lexer::Lex& l_p0, const Nat& n_p1);

Nat match_end_f(const Regex& r_p0, const Text& src_p1, const Nat& at_p2);

Text match_here_f(const Regex& r_p0, const crate::syntax::lexer::Lex& l_p1);

Nat line_end_f(const crate::syntax::lexer::Lex& l_p0);

Text rest_of_line_f(const crate::syntax::lexer::Lex& l_p0);

prism_rtl::JobRef<Text> start_rest_of_line_f(crate::syntax::lexer::Lex l_p0);

crate::syntax::lexer::Lex lex_err_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1, const Nat& end_p2, const Text& message_p3);

crate::syntax::Diag lex_diag_f(const crate::syntax::Range& span_p0, const Text& message_p1);

}  // namespace syntax::lexer::chars


namespace syntax::lexer::chars {

/// The step machine of `FoldChars`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FoldChars: fn Text, b, (fn b, Text -> b) -> b
template <class B>
struct FoldChars : prism_rtl::Job<B> {
    Text t_p0;
    B z_p1;
    prism_rtl::Fn<prism_rtl::JobRef<B>(std::tuple<B, Text>)> f_f2;
    FoldChars(Text t_p0, B z_p1, prism_rtl::Fn<prism_rtl::JobRef<B>(std::tuple<B, Text>)> f_f2) : t_p0(std::move(t_p0)), z_p1(std::move(z_p1)), f_f2(std::move(f_f2)) {}
    prism_rtl::Turn<B> cycle() const override;
};


/// The step machine of `RestOfLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RestOfLine: unbounded fn Lex -> Text
struct RestOfLine : prism_rtl::Job<Text> {
    crate::syntax::lexer::Lex l_p0;
    RestOfLine(crate::syntax::lexer::Lex l_p0) : l_p0(std::move(l_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


}  // namespace syntax::lexer::chars

}  // namespace crate
