// The module `Syntax.Lexer.Chars`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/chars.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <syntax/lexer/chars/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

namespace crate::syntax::lexer::chars {

/// Dec: fn Nat -> Nat
Nat dec(const Nat& n) {
    return or_(n.checked_sub(Nat(1u)), Nat(0u));
}


/// Join: fn [Text], Text -> Text
Text join(const Array<Text>& xs, const Text& sep) {
    auto&& _m = index(xs, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& first_ = prism_rtl::some_of(_m);
        return concat(fold(drop(xs, Nat(1u)), Array(std::vector{first_}), [&](const Array<Text>& acc, const Text& x) { return crate::prelude::push(crate::prelude::push(acc, sep), x); }));
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// CharAt: fn Cursor -> Text
Text char_at(const Cursor& c) {
    auto&& _m = step(front(after(c)));
    if (prism_rtl::is_some(_m)) {
        auto&& one = std::get<1>(prism_rtl::some_of(_m));
        return before(one);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Head: fn Text -> Text
Text head(const Text& t) {
    return char_at(front(t));
}


/// AfterFirst: fn Text -> Text
Text after_first(const Text& t) {
    auto&& _m = step(front(t));
    if (prism_rtl::is_some(_m)) {
        auto&& c = std::get<1>(prism_rtl::some_of(_m));
        return after(c);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// LastChar: fn Text -> Text
Text last_char(const Text& t) {
    auto&& _m = step_back(back(t));
    if (prism_rtl::is_some(_m)) {
        auto&& c = std::get<1>(prism_rtl::some_of(_m));
        return after(c);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// BeforeLast: fn Text -> Text
Text before_last(const Text& t) {
    auto&& _m = step_back(back(t));
    if (prism_rtl::is_some(_m)) {
        auto&& c = std::get<1>(prism_rtl::some_of(_m));
        return before(c);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Between: fn Text, Nat, Nat -> Text
Text between(const Text& t, const Nat& a, const Nat& b) {
    auto&& _m = cursor_at(t, b);
    if (prism_rtl::is_some(_m)) {
        auto&& cb = prism_rtl::some_of(_m);
        auto&& _m = cursor_at(before(cb), a);
        if (prism_rtl::is_some(_m)) {
            auto&& ca = prism_rtl::some_of(_m);
            return after(ca);
        }
        if (prism_rtl::is_none(_m)) {
            return Text::lit("");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?AfterPrefix: fn Text, Text -> ?Text
std::optional<Text> after_prefix(const Text& t, const Text& p_) {
    auto&& _m = cursor_at(t, len_text(p_));
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        return before(c) == p_ ? std::optional(after(c)) : std::optional<Text>{};
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// HasPrefix: fn Text, Text -> Bool
bool has_prefix(const Text& t, const Text& p_) {
    return after_prefix(t, p_) != std::optional<Text>{};
}


/// DropPrefix: fn Text, Text -> Text
Text drop_prefix(const Text& t, const Text& p_) {
    return or_(after_prefix(t, p_), t);
}


/// ?BeforeSuffix: fn Text, Text -> ?Text
std::optional<Text> before_suffix(const Text& t, const Text& s) {
    auto&& _m = len_text(t).checked_sub(len_text(s));
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        auto&& _m = cursor_at(t, n);
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            return after(c) == s ? std::optional(before(c)) : std::optional<Text>{};
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<Text>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// HasSuffix: fn Text, Text -> Bool
bool has_suffix(const Text& t, const Text& s) {
    return before_suffix(t, s) != std::optional<Text>{};
}


/// MapChars: fn Text, (fn Text -> Text) -> Text
Text map_chars(const Text& t, const prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>& f_fn) {
    return concat(fold_chars(t, Array<Text>{}, ({
        auto f_fn_1 = f_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto f_fn_1_2 = f_fn_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                call_value(f_fn_1_2(c), [=](Text f_3224) { return prism_rtl::finished(crate::prelude::push(acc, f_3224)); });
            });
        }));
        });
    })));
    })));
}


/// CountChars: fn Text -> Nat
Nat count_chars(const Text& t) {
    return fold_chars(t, Nat(0u), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=](std::tuple<Nat, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto n = p0;
                static_cast<void>(p1);
                (prism_rtl::finished(n + Nat(1u)));
            });
        });
    })));
}


/// ColumnOf: fn Text, Nat, Nat -> Nat
Nat column_of(const Text& text_, const Nat& from, const Nat& offset) {
    return count_chars(between(text_, from, offset));
}


/// AllChars: fn Text, (fn Text -> Bool) -> Bool
bool all_chars(const Text& t, const prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>& p__fn) {
    return fold_chars(t, true, ({
        auto p__fn_1 = p__fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=](std::tuple<bool, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto p__fn_1_2 = p__fn_1;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto c = p1;
                (prism_rtl::finished(ok && run_to_end(p__fn_1_2(c))));
            });
        }));
        });
    })));
    }));
}


/// TrimLeading: fn Text, Text -> Text
Text trim_leading(const Text& t, const Text& set) {
    auto c = ({
        Cursor this_ = front(t);
        while (true) {
            auto&& _m = step(this_);
            if (!(prism_rtl::is_some(_m))) break;
            auto&& next = std::get<1>(prism_rtl::some_of(_m));
            if (!contains(set, char_at(this_))) {
                break;
            }
            this_ = next;
        }
        this_;
    });
    return after(c);
}


/// TrimTrailing: fn Text, Text -> Text
Text trim_trailing(const Text& t, const Text& set) {
    auto c = ({
        Cursor this_ = back(t);
        Nat fuel = len_text(t);
        while (true) {
            auto&& _m = fuel.checked_sub(Nat(1u));
            if (!(prism_rtl::is_some(_m))) break;
            auto&& left = prism_rtl::some_of(_m);
            fuel = left;
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = step_back(this_);
                if (prism_rtl::is_some(_m)) {
                    auto&& prev = std::get<1>(prism_rtl::some_of(_m));
                    if (contains(set, char_at(prev))) {
                        _v.set(({
                            this_ = prev;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        fuel = Nat(0u);
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
        }
        this_;
    });
    return before(c);
}


/// TrimStart: fn Text -> Text
Text trim_start(const Text& t) {
    return trim_leading(t, Text::lit(" \r"));
}


/// TrimEnd: fn Text -> Text
Text trim_end(const Text& t) {
    return trim_trailing(t, Text::lit(" \r"));
}


/// Trim: fn Text -> Text
Text trim(const Text& t) {
    return trim_end(trim_start(t));
}


/// LeadingIn: fn Text, Text -> Nat
Nat leading_in(const Text& t, const Text& set) {
    return or_(len_text(t).checked_sub(len_text(trim_leading(t, set))), Nat(0u));
}


/// Contains: fn Text, Text -> Bool
bool contains(const Text& set, const Text& c) {
    return (c != Text::lit("")) && (len(split_on(set, c)) > Nat(1u));
}


/// IsDigit: fn Text -> Bool
bool is_digit(const Text& c) {
    return (Text::lit("0") <= c) && (c <= Text::lit("9"));
}


/// IsUpper: fn Text -> Bool
bool is_upper(const Text& c) {
    return (Text::lit("A") <= c) && (c <= Text::lit("Z"));
}


/// IsLower: fn Text -> Bool
bool is_lower(const Text& c) {
    return (Text::lit("a") <= c) && (c <= Text::lit("z"));
}


/// IsIdentStart: fn Text -> Bool
bool is_ident_start(const Text& c) {
    return (is_lower(c) || is_upper(c)) || (c == Text::lit("_"));
}


/// IsIdentChar: fn Text -> Bool
bool is_ident_char(const Text& c) {
    return is_ident_start(c) || is_digit(c);
}


/// IsHexDigit: fn Text -> Bool
bool is_hex_digit(const Text& c) {
    return (is_digit(c) || ((Text::lit("a") <= c) && (c <= Text::lit("f")))) || ((Text::lit("A") <= c) && (c <= Text::lit("F")));
}


/// IsNonAscii: fn Text -> Bool
bool is_non_ascii(const Text& c) {
    return c > Text::lit("");
}


/// IsSigilChar: fn Text -> Bool
bool is_sigil_char(const Text& c) {
    return contains(Text::lit("$!@?~&"), c);
}


/// IsSpaceChar: fn Text -> Bool
bool is_space_char(const Text& c) {
    return (((c == Text::lit(" ")) || (c == Text::lit("\n"))) || (c == Text::lit("\r"))) || (c == Text::lit("\t"));
}


/// IsReservedCtor: fn Text -> Bool
bool is_reserved_ctor(const Text& w) {
    return (w == Text::lit("templatetext")) || (w == Text::lit("templateplaceholder"));
}


/// let asciiText
Text ascii_text() {
    return Text::lit("\000\t\n\r !\"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"sv);
}


/// let hexDigits
Text hex_digits() {
    return Text::lit("0123456789abcdef");
}


/// CharAtByte: fn Text, Nat -> Text
Text char_at_byte(const Text& t, const Nat& n) {
    auto&& _m = cursor_at(t, n);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        return char_at(c);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// HexValue: fn Text -> Nat
Nat hex_value(const Text& c) {
    auto l = crate::prelude::lower(c);
    return l == Text::lit("")
        ? Nat(16u)
        : len_text(or_(index(split_on(hex_digits(), l), Nat(0u)), hex_digits()));
}


/// ?ParseHex: fn Text -> ?Nat
std::optional<Nat> parse_hex(const Text& t) {
    return ({
        __label__ g7309;
        prism_rtl::Slot<std::optional<Nat>> g7309_v;
        {
            if (!((t != Text::lit("")) && all_chars(t, ({
                auto f = prism_rtl::rc(is_hex_digit);
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text a0) {
                return ({
                    auto f_1 = f;
                    once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                });
            })));
            })))) {
                { g7309_v.set(std::nullopt); goto g7309; }
            }
            g7309_v.set(std::optional(fold_chars(t, Nat(0u), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=](std::tuple<Nat, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return once_job([=]() {
                    return ({
                        auto n = p0;
                        auto c = p1;
                        (prism_rtl::finished((n * Nat(16u)) + hex_value(c)));
                    });
                });
            })))));
        }
    g7309:
        g7309_v.take();
    });
}


/// ?AsciiChar: fn Nat -> ?Text
std::optional<Text> ascii_char(const Nat& n) {
    return n < Nat(128u)
        ? std::optional(char_at_byte(ascii_text(), n))
        : std::optional<Text>{};
}


/// Rest: fn Lex -> Text
Text rest(const crate::syntax::lexer::Lex& l) {
    auto&& _m = cursor_at(l.src, l.pos);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        return after(c);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Peek: fn Lex -> Text
Text peek(const crate::syntax::lexer::Lex& l) {
    return char_at_byte(l.src, l.pos);
}


/// PeekAt: fn Lex, Nat -> Text
Text peek_at(const crate::syntax::lexer::Lex& l, const Nat& n) {
    auto rest_ = ({
        Text this_ = rest(l);
        Nat k = n;
        while (true) {
            auto&& _m = k.checked_sub(Nat(1u));
            if (!(prism_rtl::is_some(_m))) break;
            auto&& left = prism_rtl::some_of(_m);
            k = left;
            this_ = after_first(this_);
        }
        this_;
    });
    return head(rest_);
}


/// StartsWith: fn Lex, Text -> Bool
bool starts_with(const crate::syntax::lexer::Lex& l, const Text& s) {
    return has_prefix(rest(l), s);
}


/// Slice: fn Lex, Nat, Nat -> Text
Text slice(const crate::syntax::lexer::Lex& l, const Nat& a, const Nat& b) {
    return between(l.src, a, b);
}


/// Bump: fn Lex -> Lex
crate::syntax::lexer::Lex bump(const crate::syntax::lexer::Lex& l) {
    crate::syntax::lexer::Lex this_ = l;
    this_.pos = this_.pos + len_text(peek(this_));
    return this_;
}


/// Forward: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex forward(const crate::syntax::lexer::Lex& l, const Nat& n) {
    crate::syntax::lexer::Lex this_ = l;
    Nat k = n;
    while (true) {
        auto&& _m = k.checked_sub(Nat(1u));
        if (!(prism_rtl::is_some(_m))) break;
        auto&& left = prism_rtl::some_of(_m);
        k = left;
        this_.pos = this_.pos + len_text(peek(this_));
    }
    return this_;
}


/// NextIsSpace: fn Lex, Nat -> Bool
bool next_is_space(const crate::syntax::lexer::Lex& l, const Nat& n) {
    auto c = peek_at(l, n);
    return (c == Text::lit("")) || is_space_char(c);
}


/// MatchEnd: fn Regex, Text, Nat -> Nat
Nat match_end(const Regex& r, const Text& src, const Nat& at_) {
    auto&& _m = cursor_at(src, at_);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        auto&& _m = match_(r, c);
        if (prism_rtl::is_some(_m)) {
            auto&& m = prism_rtl::some_of(_m);
            return at(m.back);
        }
        if (prism_rtl::is_none(_m)) {
            return at_;
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return at_;
    }
    prism_rtl::unreachable("no arm matched");
}


/// MatchHere: fn Regex, Lex -> Text
Text match_here(const Regex& r, const crate::syntax::lexer::Lex& l) {
    return between(l.src, l.pos, match_end(r, l.src, l.pos));
}


/// LineEnd: fn Lex -> Nat
Nat line_end(const crate::syntax::lexer::Lex& l) {
    return match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[^\\n]*", ""); return r; }()), l.src, l.pos);
}


/// RestOfLine: unbounded fn Lex -> Text
Text rest_of_line(const crate::syntax::lexer::Lex& l) {
    return slice(l, l.pos, line_end(l));
}


prism_rtl::Turn<Text> RestOfLine::cycle() const {
    const auto& l = this->l;
    return prism_rtl::finished(slice(l, l.pos, line_end(l)));
}


/// `Start RestOfLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rest_of_line(crate::syntax::lexer::Lex l) {
    return prism_rtl::make_rc<RestOfLine>(l);
}


/// LexErr: fn Lex, Nat, Nat, Text -> Lex
crate::syntax::lexer::Lex lex_err(const crate::syntax::lexer::Lex& l, const Nat& start, const Nat& end, const Text& message) {
    crate::syntax::lexer::Lex this_ = l;
    this_.diags = crate::prelude::push(this_.diags, lex_diag(crate::syntax::Range{.start = start, .end = crate::prelude::max(end, start)}, message));
    return this_;
}


/// LexDiag: fn Range, Text -> Diag
crate::syntax::Diag lex_diag(const crate::syntax::Range& span, const Text& message) {
    return crate::syntax::Diag{.stage = Text::lit("lex"), .span = span, .message = message, .feature = std::optional<Text>{}};
}

}  // namespace crate::syntax::lexer::chars
