// The module `Syntax.Lexer.Chars`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace syntax::lexer::chars {

template <class B>
struct FoldChars;

struct RestOfLine;

}  // namespace syntax::lexer::chars

}  // namespace crate
