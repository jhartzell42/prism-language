// The module `Syntax.Lexer.Literals`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/literals.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <syntax/lexer/literals/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

namespace crate::syntax::lexer::literals {

/// LexNumber: unbounded fn Lex, Text -> ((TokKind, Lex))
std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_number(const crate::syntax::lexer::Lex& l, const Text& sigils) {
    return (crate::syntax::lexer::chars::peek(l) == Text::lit("0")) && crate::syntax::lexer::chars::contains(Text::lit("xob"), crate::syntax::lexer::chars::peek_at(l, Nat(1u)))
        ? lex_radix(l, sigils)
        : lex_decimal(l, sigils);
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> LexNumber::cycle() const {
    const auto& l = this->l;
    const auto& sigils = this->sigils;
    return (crate::syntax::lexer::chars::peek(l) == Text::lit("0")) && crate::syntax::lexer::chars::contains(Text::lit("xob"), crate::syntax::lexer::chars::peek_at(l, Nat(1u)))
        ? prism_rtl::more(prism_rtl::rc(LexRadix(l, sigils)))
        : prism_rtl::more(prism_rtl::rc(LexDecimal(l, sigils)));
}


/// `Start LexNumber, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_number(crate::syntax::lexer::Lex l, Text sigils) {
    return prism_rtl::make_rc<LexNumber>(l, sigils);
}


/// RadixDigit: fn Text, Text -> Bool
bool radix_digit(const Text& text0, const Text& c) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("x")) {
            return crate::syntax::lexer::chars::is_hex_digit(c);
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("o")) {
            return (Text::lit("0") <= c) && (c <= Text::lit("7"));
        }
    }
    {
        return (c == Text::lit("0")) || (c == Text::lit("1"));
    }
}


/// LexRadix: unbounded fn Lex, Text -> ((TokKind, Lex))
std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_radix(const crate::syntax::lexer::Lex& l0, const Text& sigils) {
    auto start = l0.pos;
    auto radix = crate::syntax::lexer::chars::peek_at(l0, Nat(1u));
    auto l1 = crate::syntax::lexer::chars::forward(l0, Nat(2u));
    auto l2 = ({
        crate::syntax::lexer::Lex this_ = l1;
        while (radix_digit(radix, crate::syntax::lexer::chars::peek(this_)) || (crate::syntax::lexer::chars::peek(this_) == Text::lit("_"))) {
            this_.pos = this_.pos + Nat(1u);
        }
        this_;
    });
    auto l3 = l2.pos == l1.pos
        ? crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, Text::lit("a radix prefix needs digits after it"))
        : l2;
    auto l4 = check_no_suffix(l3, start);
    auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KInt{sigils, crate::syntax::lexer::chars::slice(l4, start, l4.pos)});
    return std::tuple{kind, l4};
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> LexRadix::cycle() const {
    const auto& l0 = this->l0;
    const auto& sigils = this->sigils;
    auto start = l0.pos;
    auto radix = crate::syntax::lexer::chars::peek_at(l0, Nat(1u));
    auto l1 = crate::syntax::lexer::chars::forward(l0, Nat(2u));
    crate::syntax::lexer::Lex this_ = l1;
    auto l1_1 = l1;
    auto radix_2 = radix;
    auto sigils_3 = sigils;
    auto start_4 = start;
    return call_then(loop_job(std::tuple{this_}, ({
        auto radix_2_5 = radix_2;
        [=](std::tuple<crate::syntax::lexer::Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return radix_digit(radix_2_5, crate::syntax::lexer::chars::peek(this_)) || (crate::syntax::lexer::chars::peek(this_) == Text::lit("_"))
            ? ({
            this_.pos = this_.pos + Nat(1u);
            Expected<std::tuple<crate::syntax::lexer::Lex>, std::tuple<crate::syntax::lexer::Lex>>(std::tuple{this_});
        })
            : Expected<std::tuple<crate::syntax::lexer::Lex>, std::tuple<crate::syntax::lexer::Lex>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<crate::syntax::lexer::Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto l2 = this_;
            auto l3 = l2.pos == l1_1.pos
                ? crate::syntax::lexer::chars::lex_err(l2, start_4, l2.pos, Text::lit("a radix prefix needs digits after it"))
                : l2;
            call_then(start_check_no_suffix(l3, start_4), [=](crate::syntax::lexer::Lex check_no_suffix_1322) {
            return ({
                auto l4 = check_no_suffix_1322;
                auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KInt{sigils_3, crate::syntax::lexer::chars::slice(l4, start_4, l4.pos)});
                (prism_rtl::finished(std::tuple{kind, l4}));
            });
        });
        });
    });
}


/// `Start LexRadix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_radix(crate::syntax::lexer::Lex l0, Text sigils) {
    return prism_rtl::make_rc<LexRadix>(l0, sigils);
}


/// SkipDigits: unbounded fn Lex -> Lex
crate::syntax::lexer::Lex skip_digits(const crate::syntax::lexer::Lex& l) {
    crate::syntax::lexer::Lex this_ = l;
    while (crate::syntax::lexer::chars::is_digit(crate::syntax::lexer::chars::peek(this_)) || (crate::syntax::lexer::chars::peek(this_) == Text::lit("_"))) {
        this_.pos = this_.pos + Nat(1u);
    }
    return this_;
}


prism_rtl::Turn<crate::syntax::lexer::Lex> SkipDigits::cycle() const {
    const auto& l = this->l;
    crate::syntax::lexer::Lex this_ = l;
    return call_then(loop_job(std::tuple{this_}, [=](std::tuple<crate::syntax::lexer::Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return crate::syntax::lexer::chars::is_digit(crate::syntax::lexer::chars::peek(this_)) || (crate::syntax::lexer::chars::peek(this_) == Text::lit("_"))
            ? ({
            this_.pos = this_.pos + Nat(1u);
            Expected<std::tuple<crate::syntax::lexer::Lex>, std::tuple<crate::syntax::lexer::Lex>>(std::tuple{this_});
        })
            : Expected<std::tuple<crate::syntax::lexer::Lex>, std::tuple<crate::syntax::lexer::Lex>>(unexpected(std::tuple{this_}));
    }), [=](std::tuple<crate::syntax::lexer::Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return prism_rtl::finished(this_);
    });
}


/// `Start SkipDigits, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_skip_digits(crate::syntax::lexer::Lex l) {
    return prism_rtl::make_rc<SkipDigits>(l);
}


/// LexDecimal: unbounded fn Lex, Text -> ((TokKind, Lex))
std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_decimal(const crate::syntax::lexer::Lex& l0, const Text& sigils) {
    auto start = l0.pos;
    auto l1 = skip_digits(l0);
    auto next = crate::syntax::lexer::chars::peek_at(l1, Nat(1u));
    return (crate::syntax::lexer::chars::peek(l1) == Text::lit(".")) && crate::syntax::lexer::chars::is_digit(next)
        ? number_tail(skip_digits(crate::syntax::lexer::chars::bump(l1)), sigils, start, true)
        : (((crate::syntax::lexer::chars::peek(l1) == Text::lit(".")) && (next != Text::lit("."))) && (next != Text::lit(""))) && (!crate::syntax::lexer::chars::is_ident_start(next))
        ? ({
        auto l2 = crate::syntax::lexer::chars::bump(l1);
        auto l3 = crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, prism_rtl::cat("`", crate::syntax::lexer::chars::slice(l2, start, l2.pos), "` is not a number: a decimal literal has digits on both sides of its point"));
        auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFloat{sigils, crate::syntax::lexer::chars::slice(l3, start, crate::syntax::lexer::chars::dec(l2.pos))});
        std::tuple{kind, l3};
    })
        : number_tail(l1, sigils, start, false);
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> LexDecimal::cycle() const {
    const auto& l0 = this->l0;
    const auto& sigils = this->sigils;
    auto start = l0.pos;
    auto l0_1 = l0;
    auto sigils_2 = sigils;
    return call_then(start_skip_digits(l0_1), [=](crate::syntax::lexer::Lex skip_digits_1671) {
        return ({
            auto l1 = skip_digits_1671;
            auto next = crate::syntax::lexer::chars::peek_at(l1, Nat(1u));
            (crate::syntax::lexer::chars::peek(l1) == Text::lit(".")) && crate::syntax::lexer::chars::is_digit(next)
            ? call_then(start_skip_digits(crate::syntax::lexer::chars::bump(l1)), [=](crate::syntax::lexer::Lex skip_digits_1769) { return prism_rtl::more(prism_rtl::rc(NumberTail(skip_digits_1769, sigils_2, start, true))); })
            : (((crate::syntax::lexer::chars::peek(l1) == Text::lit(".")) && (next != Text::lit("."))) && (next != Text::lit(""))) && (!crate::syntax::lexer::chars::is_ident_start(next))
            ? ({
            auto l2 = crate::syntax::lexer::chars::bump(l1);
            auto l3 = crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, prism_rtl::cat("`", crate::syntax::lexer::chars::slice(l2, start, l2.pos), "` is not a number: a decimal literal has digits on both sides of its point"));
            auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFloat{sigils_2, crate::syntax::lexer::chars::slice(l3, start, crate::syntax::lexer::chars::dec(l2.pos))});
            (prism_rtl::finished(std::tuple{kind, l3}));
        })
            : prism_rtl::more(prism_rtl::rc(NumberTail(l1, sigils_2, start, false)));
        });
    });
}


/// `Start LexDecimal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_decimal(crate::syntax::lexer::Lex l0, Text sigils) {
    return prism_rtl::make_rc<LexDecimal>(l0, sigils);
}


/// let durationUnits
Array<std::tuple<Text, Nat>> duration_units() {
    return Array(std::vector{std::tuple{Text::lit("ns"), Nat(1u)}, std::tuple{Text::lit("us"), Nat(1000u)}, std::tuple{Text::lit("ms"), Nat(1000000u)}, std::tuple{Text::lit("min"), *Nat::from_int(Int(60000000000ll))}, std::tuple{Text::lit("s"), *Nat::from_int(Int(1000000000ll))}, std::tuple{Text::lit("h"), *Nat::from_int(Int(3600000000000ll))}});
}


/// ?UnitAt: fn Lex -> ?((Text, Nat))
std::optional<std::tuple<Text, Nat>> unit_at(const crate::syntax::lexer::Lex& l) {
    return fold(duration_units(), std::optional<std::tuple<Text, Nat>>{}, [&](const std::optional<std::tuple<Text, Nat>>& found_opt, const std::tuple<Text, Nat>& u) {
        return (found_opt == std::optional<std::tuple<Text, Nat>>{}) && unit_here(l, u)
            ? std::optional(u)
            : found_opt;
    });
}


/// UnitHere: fn Lex, ((Text, Nat)) -> Bool
bool unit_here(const crate::syntax::lexer::Lex& l, const std::tuple<Text, Nat>& arg1) {
    {
        auto&& u = std::get<0>(arg1);
        return crate::syntax::lexer::chars::starts_with(l, u) && (!crate::syntax::lexer::chars::is_ident_char(crate::syntax::lexer::chars::peek_at(l, len_text(u))));
    }
    prism_rtl::unreachable("no arm matched");
}


/// NumberTail: unbounded fn Lex, Text, Nat, Bool -> ((TokKind, Lex))
std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> number_tail(const crate::syntax::lexer::Lex& l, const Text& sigils, const Nat& start, const bool& decimal) {
    auto&& _m = unit_at(l);
    if (prism_rtl::is_some(_m)) {
        auto&& u = std::get<0>(prism_rtl::some_of(_m));
        auto&& scale = std::get<1>(prism_rtl::some_of(_m));
        auto digits = crate::syntax::lexer::chars::slice(l, start, l.pos);
        auto l2 = crate::syntax::lexer::chars::forward(l, len_text(u));
        auto l3 = whole_nanoseconds(digits, scale)
            ? l2
            : crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, prism_rtl::cat("`", digits, u, "` does not name a whole number of nanoseconds"));
        auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDuration{sigils, digits, u});
        return std::tuple{kind, l3};
    }
    if (prism_rtl::is_none(_m)) {
        auto [dec, l2] = exponent(l, decimal);
        auto l3 = check_no_suffix(l2, start);
        auto text = crate::syntax::lexer::chars::slice(l3, start, l3.pos);
        auto kind = dec
            ? crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFloat{sigils, text})
            : crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KInt{sigils, text});
        return std::tuple{kind, l3};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> NumberTail::cycle() const {
    const auto& l = this->l;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    const auto& decimal = this->decimal;
    return ({
        auto&& _m = unit_at(l);
        prism_rtl::is_some(_m) ? ({
        auto&& u = std::get<0>(prism_rtl::some_of(_m));
        auto&& scale = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto digits = crate::syntax::lexer::chars::slice(l, start, l.pos);
        auto l2 = crate::syntax::lexer::chars::forward(l, len_text(u));
        auto l3 = whole_nanoseconds(digits, scale)
            ? l2
            : crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, prism_rtl::cat("`", digits, u, "` does not name a whole number of nanoseconds"));
        auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDuration{sigils, digits, u});
        (prism_rtl::finished(std::tuple{kind, l3}));
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto decimal_1 = decimal;
        auto l_2 = l;
        auto sigils_3 = sigils;
        auto start_4 = start;
        call_then(start_exponent(l_2, decimal_1), [=](std::tuple<bool, crate::syntax::lexer::Lex> exponent_3590) {
        return ({
            auto [dec, l2] = exponent_3590;
            call_then(start_check_no_suffix(l2, start_4), [=](crate::syntax::lexer::Lex check_no_suffix_3627) {
            return ({
                auto l3 = check_no_suffix_3627;
                auto text = crate::syntax::lexer::chars::slice(l3, start_4, l3.pos);
                auto kind = dec
                    ? crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFloat{sigils_3, text})
                    : crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KInt{sigils_3, text});
                (prism_rtl::finished(std::tuple{kind, l3}));
            });
        });
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start NumberTail, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_number_tail(crate::syntax::lexer::Lex l, Text sigils, Nat start, bool decimal) {
    return prism_rtl::make_rc<NumberTail>(l, sigils, start, decimal);
}


/// Exponent: unbounded fn Lex, Bool -> ((Bool, Lex))
std::tuple<bool, crate::syntax::lexer::Lex> exponent(const crate::syntax::lexer::Lex& l, const bool& decimal) {
    auto l1 = crate::syntax::lexer::chars::bump(l);
    auto l2 = (crate::syntax::lexer::chars::peek(l1) == Text::lit("+")) || (crate::syntax::lexer::chars::peek(l1) == Text::lit("-"))
        ? crate::syntax::lexer::chars::bump(l1)
        : l1;
    return ((crate::syntax::lexer::chars::peek(l) == Text::lit("e")) || (crate::syntax::lexer::chars::peek(l) == Text::lit("E"))) && crate::syntax::lexer::chars::is_digit(crate::syntax::lexer::chars::peek(l2))
        ? std::tuple{true, skip_digits(l2)}
        : std::tuple{decimal, l};
}


prism_rtl::Turn<std::tuple<bool, crate::syntax::lexer::Lex>> Exponent::cycle() const {
    const auto& l = this->l;
    const auto& decimal = this->decimal;
    auto l1 = crate::syntax::lexer::chars::bump(l);
    auto l2 = (crate::syntax::lexer::chars::peek(l1) == Text::lit("+")) || (crate::syntax::lexer::chars::peek(l1) == Text::lit("-"))
        ? crate::syntax::lexer::chars::bump(l1)
        : l1;
    return ((crate::syntax::lexer::chars::peek(l) == Text::lit("e")) || (crate::syntax::lexer::chars::peek(l) == Text::lit("E"))) && crate::syntax::lexer::chars::is_digit(crate::syntax::lexer::chars::peek(l2))
        ? call_then(start_skip_digits(l2), [=](crate::syntax::lexer::Lex skip_digits_4029) { return prism_rtl::finished(std::tuple{true, skip_digits_4029}); })
        : prism_rtl::finished(std::tuple{decimal, l});
}


/// `Start Exponent, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<bool, crate::syntax::lexer::Lex>> start_exponent(crate::syntax::lexer::Lex l, bool decimal) {
    return prism_rtl::make_rc<Exponent>(l, decimal);
}


/// WholeNanoseconds: fn Text, Nat -> Bool
bool whole_nanoseconds(const Text& text, const Nat& scale) {
    auto parts = split_on(concat(split_on(text, Text::lit("_"))), Text::lit("."));
    auto&& _m = index(parts, Nat(1u));
    if (prism_rtl::is_none(_m)) {
        return true;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& frac0 = prism_rtl::some_of(_m);
        auto frac = trim_zeros(frac0);
        auto k = len_text(frac);
        auto f = frac == Text::lit("") ? Nat(0u) : or_(parse_nat_opt(frac), Nat(1u));
        auto tens = crate::syntax::lexer::chars::fold_chars(frac, Nat(1u), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=](std::tuple<Nat, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return once_job([=]() {
                return ({
                    auto p_ = p0;
                    static_cast<void>(p1);
                    (prism_rtl::finished(p_ * Nat(10u)));
                });
            });
        })));
        return (k <= Nat(30u)) && (or_(mod_(f * scale, tens), Nat(1u)) == Nat(0u));
    }
    prism_rtl::unreachable("no arm matched");
}


/// TrimZeros: fn Text -> Text
Text trim_zeros(const Text& t) {
    return crate::syntax::lexer::chars::trim_trailing(t, Text::lit("0"));
}


/// CheckNoSuffix: unbounded fn Lex, Nat -> Lex
crate::syntax::lexer::Lex check_no_suffix(const crate::syntax::lexer::Lex& l0, const Nat& start) {
    return crate::syntax::lexer::chars::is_ident_char(crate::syntax::lexer::chars::peek(l0))
        ? ({
        auto l = ({
            crate::syntax::lexer::Lex this_ = l0;
            while (crate::syntax::lexer::chars::is_ident_char(crate::syntax::lexer::chars::peek(this_))) {
                this_.pos = this_.pos + Nat(1u);
            }
            this_;
        });
        (crate::syntax::lexer::chars::lex_err(l, start, l.pos, prism_rtl::cat("`", crate::syntax::lexer::chars::slice(l, start, l.pos), "` is not a token: a number literal has no suffix (write a type annotation)")));
    })
        : l0;
}


prism_rtl::Turn<crate::syntax::lexer::Lex> CheckNoSuffix::cycle() const {
    const auto& l0 = this->l0;
    const auto& start = this->start;
    return crate::syntax::lexer::chars::is_ident_char(crate::syntax::lexer::chars::peek(l0))
        ? ({
        crate::syntax::lexer::Lex this_ = l0;
        auto start_1 = start;
        call_then(loop_job(std::tuple{this_}, [=](std::tuple<crate::syntax::lexer::Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return crate::syntax::lexer::chars::is_ident_char(crate::syntax::lexer::chars::peek(this_))
            ? ({
            this_.pos = this_.pos + Nat(1u);
            Expected<std::tuple<crate::syntax::lexer::Lex>, std::tuple<crate::syntax::lexer::Lex>>(std::tuple{this_});
        })
            : Expected<std::tuple<crate::syntax::lexer::Lex>, std::tuple<crate::syntax::lexer::Lex>>(unexpected(std::tuple{this_}));
    }), [=](std::tuple<crate::syntax::lexer::Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto l = this_;
            (prism_rtl::finished(crate::syntax::lexer::chars::lex_err(l, start_1, l.pos, prism_rtl::cat("`", crate::syntax::lexer::chars::slice(l, start_1, l.pos), "` is not a token: a number literal has no suffix (write a type annotation)"))));
        });
    });
    })
        : prism_rtl::finished(l0);
}


/// `Start CheckNoSuffix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_check_no_suffix(crate::syntax::lexer::Lex l0, Nat start) {
    return prism_rtl::make_rc<CheckNoSuffix>(l0, start);
}


/// LexEscape: unbounded fn Lex -> ((Text, Lex))
std::tuple<Text, crate::syntax::lexer::Lex> lex_escape(const crate::syntax::lexer::Lex& l0) {
    auto start = l0.pos;
    auto l1 = crate::syntax::lexer::chars::bump(l0);
    auto c = crate::syntax::lexer::chars::peek(l1);
    auto l2 = crate::syntax::lexer::chars::bump(l1);
    {
        auto&& m5298_0 = c;
        if (m5298_0 == Text::lit("\\")) {
            return std::tuple{Text::lit("\\"), l2};
        }
    }
    {
        auto&& m5298_1 = c;
        if (m5298_1 == Text::lit("\"")) {
            return std::tuple{Text::lit("\""), l2};
        }
    }
    {
        auto&& m5298_2 = c;
        if (m5298_2 == Text::lit("'")) {
            return std::tuple{Text::lit("'"), l2};
        }
    }
    {
        auto&& m5298_3 = c;
        if (m5298_3 == Text::lit("n")) {
            return std::tuple{Text::lit("\n"), l2};
        }
    }
    {
        auto&& m5298_4 = c;
        if (m5298_4 == Text::lit("t")) {
            return std::tuple{Text::lit("\t"), l2};
        }
    }
    {
        auto&& m5298_5 = c;
        if (m5298_5 == Text::lit("{")) {
            return std::tuple{Text::lit("{"), l2};
        }
    }
    {
        auto&& m5298_6 = c;
        if (m5298_6 == Text::lit("}")) {
            return std::tuple{Text::lit("}"), l2};
        }
    }
    {
        auto&& m5298_7 = c;
        if (m5298_7 == Text::lit("u")) {
            return unicode_escape(l2, start);
        }
    }
    {
        auto&& m5298_8 = c;
        if (m5298_8 == Text::lit("")) {
            return std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l1, start, l1.pos, Text::lit("a text literal ends inside an escape"))};
        }
    }
    {
        return std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, prism_rtl::cat("`\\", c, "` is not an escape: the escapes are \\\\ \\\" \\n \\t \\{ \\} \\u{hex}"))};
    }
}


prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> LexEscape::cycle() const {
    const auto& l0 = this->l0;
    auto start = l0.pos;
    auto l1 = crate::syntax::lexer::chars::bump(l0);
    auto c = crate::syntax::lexer::chars::peek(l1);
    auto l2 = crate::syntax::lexer::chars::bump(l1);
    return ({
        ({
        auto&& m5298_0 = c;
        (m5298_0 == Text::lit("\\"));
    }) ? ({
        auto&& m5298_0 = c;
        prism_rtl::finished(std::tuple{Text::lit("\\"), l2});
    })
        : ({
        auto&& m5298_1 = c;
        (m5298_1 == Text::lit("\""));
    }) ? ({
        auto&& m5298_1 = c;
        prism_rtl::finished(std::tuple{Text::lit("\""), l2});
    })
        : ({
        auto&& m5298_2 = c;
        (m5298_2 == Text::lit("'"));
    }) ? ({
        auto&& m5298_2 = c;
        prism_rtl::finished(std::tuple{Text::lit("'"), l2});
    })
        : ({
        auto&& m5298_3 = c;
        (m5298_3 == Text::lit("n"));
    }) ? ({
        auto&& m5298_3 = c;
        prism_rtl::finished(std::tuple{Text::lit("\n"), l2});
    })
        : ({
        auto&& m5298_4 = c;
        (m5298_4 == Text::lit("t"));
    }) ? ({
        auto&& m5298_4 = c;
        prism_rtl::finished(std::tuple{Text::lit("\t"), l2});
    })
        : ({
        auto&& m5298_5 = c;
        (m5298_5 == Text::lit("{"));
    }) ? ({
        auto&& m5298_5 = c;
        prism_rtl::finished(std::tuple{Text::lit("{"), l2});
    })
        : ({
        auto&& m5298_6 = c;
        (m5298_6 == Text::lit("}"));
    }) ? ({
        auto&& m5298_6 = c;
        prism_rtl::finished(std::tuple{Text::lit("}"), l2});
    })
        : ({
        auto&& m5298_7 = c;
        (m5298_7 == Text::lit("u"));
    }) ? ({
        auto&& m5298_7 = c;
        prism_rtl::more(prism_rtl::rc(UnicodeEscape(l2, start)));
    })
        : ({
        auto&& m5298_8 = c;
        (m5298_8 == Text::lit(""));
    }) ? ({
        auto&& m5298_8 = c;
        prism_rtl::finished(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l1, start, l1.pos, Text::lit("a text literal ends inside an escape"))});
    })
        : prism_rtl::finished(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, prism_rtl::cat("`\\", c, "` is not an escape: the escapes are \\\\ \\\" \\n \\t \\{ \\} \\u{hex}"))});
    });
}


/// `Start LexEscape, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_lex_escape(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexEscape>(l0);
}


/// UnicodeEscape: unbounded fn Lex, Nat -> ((Text, Lex))
std::tuple<Text, crate::syntax::lexer::Lex> unicode_escape(const crate::syntax::lexer::Lex& l, const Nat& start) {
    return crate::syntax::lexer::chars::peek(l) != Text::lit("{")
        ? std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l, start, l.pos, Text::lit("`\\u` is written `\\u{hex}`"))}
        : ({
        auto hs = l.pos + Nat(1u);
        auto l1 = ({
            crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l);
            while (crate::syntax::lexer::chars::is_hex_digit(crate::syntax::lexer::chars::peek(this_))) {
                this_.pos = this_.pos + Nat(1u);
            }
            this_;
        });
        auto hex = crate::syntax::lexer::chars::slice(l1, hs, l1.pos);
        (crate::syntax::lexer::chars::peek(l1) != Text::lit("}")
        ? std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l1, start, l1.pos, Text::lit("`\\u{` needs its closing `}`"))}
        : ({
        auto l2 = crate::syntax::lexer::chars::bump(l1);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, crate::syntax::lexer::Lex>> _v;
        auto&& _m = crate::syntax::lexer::chars::ascii_char(or_(crate::syntax::lexer::chars::parse_hex(hex), Nat(1114112u)));
        if (prism_rtl::is_some(_m)) {
            auto&& ch = prism_rtl::some_of(_m);
            _v.set(std::tuple{ch, l2});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, prism_rtl::cat("`\\u{", hex, "}` is past ASCII, which prismc cannot write yet (prismc/README.md, gap UC)"))});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    }));
    });
}


prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> UnicodeEscape::cycle() const {
    const auto& l = this->l;
    const auto& start = this->start;
    return crate::syntax::lexer::chars::peek(l) != Text::lit("{")
        ? prism_rtl::finished(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l, start, l.pos, Text::lit("`\\u` is written `\\u{hex}`"))})
        : ({
        auto hs = l.pos + Nat(1u);
        crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l);
        auto hs_1 = hs;
        auto start_2 = start;
        call_then(loop_job(std::tuple{this_}, [=](std::tuple<crate::syntax::lexer::Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return crate::syntax::lexer::chars::is_hex_digit(crate::syntax::lexer::chars::peek(this_))
            ? ({
            this_.pos = this_.pos + Nat(1u);
            Expected<std::tuple<crate::syntax::lexer::Lex>, std::tuple<crate::syntax::lexer::Lex>>(std::tuple{this_});
        })
            : Expected<std::tuple<crate::syntax::lexer::Lex>, std::tuple<crate::syntax::lexer::Lex>>(unexpected(std::tuple{this_}));
    }), [=](std::tuple<crate::syntax::lexer::Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto l1 = this_;
            auto hex = crate::syntax::lexer::chars::slice(l1, hs_1, l1.pos);
            (crate::syntax::lexer::chars::peek(l1) != Text::lit("}")
            ? prism_rtl::finished(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l1, start_2, l1.pos, Text::lit("`\\u{` needs its closing `}`"))})
            : ({
            auto l2 = crate::syntax::lexer::chars::bump(l1);
            ({
            auto&& _m = crate::syntax::lexer::chars::ascii_char(or_(crate::syntax::lexer::chars::parse_hex(hex), Nat(1114112u)));
            prism_rtl::is_some(_m) ? ({
            auto&& ch = prism_rtl::some_of(_m);
            prism_rtl::finished(std::tuple{ch, l2});
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l2, start_2, l2.pos, prism_rtl::cat("`\\u{", hex, "}` is past ASCII, which prismc cannot write yet (prismc/README.md, gap UC)"))})
            : throw prism_rtl::Panic("no arm matched");
        });
        }));
        });
    });
    });
}


/// `Start UnicodeEscape, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_unicode_escape(crate::syntax::lexer::Lex l, Nat start) {
    return prism_rtl::make_rc<UnicodeEscape>(l, start);
}


/// LexText: unbounded fn Lex -> (([TextSegTok], Lex))
std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> lex_text(const crate::syntax::lexer::Lex& l0) {
    std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<crate::syntax::lexer::TextSegTok>{}, l0};
    auto start = l0.pos;
    crate::syntax::lexer::Lex l = crate::syntax::lexer::chars::bump(l0);
    Array<crate::syntax::lexer::TextSegTok> segs = Array<crate::syntax::lexer::TextSegTok>{};
    Text cur = Text::lit("");
    bool going = true;
    while (going) {
        auto c = crate::syntax::lexer::chars::peek(l);
        if ((c == Text::lit("")) || (c == Text::lit("\n"))) {
            l = crate::syntax::lexer::chars::lex_err(l, start, l.pos, Text::lit("a text literal ends on its line: close it with `\"`, or write a multiline text as `raw <markdown>...</markdown>`"));
            going = false;
        } else  {
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                {
                    auto&& u7038_0 = c;
                    if (u7038_0 == Text::lit("\"")) {
                        _v.set(({
                            l = crate::syntax::lexer::chars::bump(l);
                            going = false;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u7038_1 = c;
                    if (u7038_1 == Text::lit("\\")) {
                        _v.set(({
                            auto [s, l2] = lex_escape(l);
                            cur = prism_rtl::cat(cur, s);
                            l = l2;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u7038_2 = c;
                    if (u7038_2 == Text::lit("{")) {
                        _v.set(({
                            if (cur != Text::lit("")) {
                                segs = crate::prelude::push(segs, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlain{cur}));
                                cur = Text::lit("");
                            }
                            auto ps = l.pos;
                            auto [toks, l2] = crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{Text::lit("single")}));
                            segs = crate::prelude::push(segs, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlaceholder{toks, crate::syntax::Range{.start = ps, .end = l2.pos}}));
                            l = l2;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u7038_3 = c;
                    if (u7038_3 == Text::lit("}")) {
                        _v.set(({
                            l = crate::syntax::lexer::chars::lex_err(crate::syntax::lexer::chars::bump(l), l.pos, l.pos + Nat(1u), Text::lit("a `}` in text is written `\\}`"));
                            cur = prism_rtl::cat(cur, "}");
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        l = crate::syntax::lexer::chars::bump(l);
                        cur = prism_rtl::cat(cur, c);
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
        }
    }
    if (cur != Text::lit("")) {
        segs = crate::prelude::push(segs, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlain{cur}));
    }
    this_ = std::tuple{segs, l};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>> LexText::cycle() const {
    const auto& l0 = this->l0;
    std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<crate::syntax::lexer::TextSegTok>{}, l0};
    auto start = l0.pos;
    crate::syntax::lexer::Lex l = crate::syntax::lexer::chars::bump(l0);
    Array<crate::syntax::lexer::TextSegTok> segs = Array<crate::syntax::lexer::TextSegTok>{};
    Text cur = Text::lit("");
    bool going = true;
    return call_then(loop_job(std::tuple{this_, cur, going, l, segs}, ({
        auto start_1 = start;
        [=](std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto cur = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto l = std::get<3>(_p0);
        auto segs = std::get<4>(_p0);
        return going
            ? ({
            auto c = crate::syntax::lexer::chars::peek(l);
            if ((c == Text::lit("")) || (c == Text::lit("\n"))) {
                l = crate::syntax::lexer::chars::lex_err(l, start_1, l.pos, Text::lit("a text literal ends on its line: close it with `\"`, or write a multiline text as `raw <markdown>...</markdown>`"));
                going = false;
            } else  {
                ({
                    __label__ _done;
                    prism_rtl::Slot<Unit> _v;
                    {
                        auto&& u7038_0 = c;
                        if (u7038_0 == Text::lit("\"")) {
                            _v.set(({
                                l = crate::syntax::lexer::chars::bump(l);
                                going = false;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u7038_1 = c;
                        if (u7038_1 == Text::lit("\\")) {
                            _v.set(({
                                auto [s, l2] = lex_escape(l);
                                cur = prism_rtl::cat(cur, s);
                                l = l2;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u7038_2 = c;
                        if (u7038_2 == Text::lit("{")) {
                            _v.set(({
                                if (cur != Text::lit("")) {
                                    segs = crate::prelude::push(segs, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlain{cur}));
                                    cur = Text::lit("");
                                }
                                auto ps = l.pos;
                                auto [toks, l2] = crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{Text::lit("single")}));
                                segs = crate::prelude::push(segs, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlaceholder{toks, crate::syntax::Range{.start = ps, .end = l2.pos}}));
                                l = l2;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u7038_3 = c;
                        if (u7038_3 == Text::lit("}")) {
                            _v.set(({
                                l = crate::syntax::lexer::chars::lex_err(crate::syntax::lexer::chars::bump(l), l.pos, l.pos + Nat(1u), Text::lit("a `}` in text is written `\\}`"));
                                cur = prism_rtl::cat(cur, "}");
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        _v.set(({
                            l = crate::syntax::lexer::chars::bump(l);
                            cur = prism_rtl::cat(cur, c);
                            Unit{};
                        }));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            }
            Expected<std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>>, std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>>>(std::tuple{this_, cur, going, l, segs});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>>, std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>>>(unexpected(std::tuple{this_, cur, going, l, segs}));
    };
    })), [=](std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto cur = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto l = std::get<3>(_p0);
        auto segs = std::get<4>(_p0);
        return ({
            if (cur != Text::lit("")) {
                segs = crate::prelude::push(segs, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlain{cur}));
            }
            this_ = std::tuple{segs, l};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start LexText, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>> start_lex_text(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexText>(l0);
}


/// LexChar: unbounded fn Lex -> ((Text, Lex))
std::tuple<Text, crate::syntax::lexer::Lex> lex_char(const crate::syntax::lexer::Lex& l0) {
    auto start = l0.pos;
    auto l1 = crate::syntax::lexer::chars::bump(l0);
    auto c = crate::syntax::lexer::chars::peek(l1);
    auto [s, l2] = c == Text::lit("\\")
        ? lex_escape(l1)
        : ((c == Text::lit("'")) || (c == Text::lit("\n"))) || (c == Text::lit(""))
        ? std::tuple{Text::lit(""), l1}
        : std::tuple{c, crate::syntax::lexer::chars::bump(l1)};
    auto ok = crate::syntax::lexer::chars::peek(l2) == Text::lit("'");
    auto l3 = ok ? crate::syntax::lexer::chars::bump(l2) : char_tail(l2, start);
    auto l4 = s == Text::lit("")
        ? crate::syntax::lexer::chars::lex_err(l3, start, l3.pos, Text::lit("a character literal holds one code point: `'c'`"))
        : l3;
    auto ch = s == Text::lit("") ? Text::lit("\000"sv) : s;
    return std::tuple{ch, l4};
}


prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> LexChar::cycle() const {
    const auto& l0 = this->l0;
    auto start = l0.pos;
    auto l1 = crate::syntax::lexer::chars::bump(l0);
    auto c = crate::syntax::lexer::chars::peek(l1);
    auto [s, l2] = c == Text::lit("\\")
        ? lex_escape(l1)
        : ((c == Text::lit("'")) || (c == Text::lit("\n"))) || (c == Text::lit(""))
        ? std::tuple{Text::lit(""), l1}
        : std::tuple{c, crate::syntax::lexer::chars::bump(l1)};
    auto ok = crate::syntax::lexer::chars::peek(l2) == Text::lit("'");
    auto l3 = ok ? crate::syntax::lexer::chars::bump(l2) : char_tail(l2, start);
    auto l4 = s == Text::lit("")
        ? crate::syntax::lexer::chars::lex_err(l3, start, l3.pos, Text::lit("a character literal holds one code point: `'c'`"))
        : l3;
    auto ch = s == Text::lit("") ? Text::lit("\000"sv) : s;
    return prism_rtl::finished(std::tuple{ch, l4});
}


/// `Start LexChar, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_lex_char(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexChar>(l0);
}


/// CharTail: unbounded fn Lex, Nat -> Lex
crate::syntax::lexer::Lex char_tail(const crate::syntax::lexer::Lex& l0, const Nat& start) {
    auto l1 = ({
        crate::syntax::lexer::Lex this_ = l0;
        while (((crate::syntax::lexer::chars::peek(this_) != Text::lit("'")) && (crate::syntax::lexer::chars::peek(this_) != Text::lit("\n"))) && (crate::syntax::lexer::chars::peek(this_) != Text::lit(""))) {
            this_.pos = this_.pos + len_text(crate::syntax::lexer::chars::peek(this_));
        }
        this_;
    });
    auto l2 = crate::syntax::lexer::chars::peek(l1) == Text::lit("'")
        ? crate::syntax::lexer::chars::bump(l1)
        : l1;
    return crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, Text::lit("a character literal holds one code point: `'c'`"));
}


prism_rtl::Turn<crate::syntax::lexer::Lex> CharTail::cycle() const {
    const auto& l0 = this->l0;
    const auto& start = this->start;
    crate::syntax::lexer::Lex this_ = l0;
    auto start_1 = start;
    return call_then(loop_job(std::tuple{this_}, [=](std::tuple<crate::syntax::lexer::Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return ((crate::syntax::lexer::chars::peek(this_) != Text::lit("'")) && (crate::syntax::lexer::chars::peek(this_) != Text::lit("\n"))) && (crate::syntax::lexer::chars::peek(this_) != Text::lit(""))
            ? ({
            this_.pos = this_.pos + len_text(crate::syntax::lexer::chars::peek(this_));
            Expected<std::tuple<crate::syntax::lexer::Lex>, std::tuple<crate::syntax::lexer::Lex>>(std::tuple{this_});
        })
            : Expected<std::tuple<crate::syntax::lexer::Lex>, std::tuple<crate::syntax::lexer::Lex>>(unexpected(std::tuple{this_}));
    }), [=](std::tuple<crate::syntax::lexer::Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto l1 = this_;
            auto l2 = crate::syntax::lexer::chars::peek(l1) == Text::lit("'")
                ? crate::syntax::lexer::chars::bump(l1)
                : l1;
            (prism_rtl::finished(crate::syntax::lexer::chars::lex_err(l2, start_1, l2.pos, Text::lit("a character literal holds one code point: `'c'`"))));
        });
    });
}


/// `Start CharTail, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_char_tail(crate::syntax::lexer::Lex l0, Nat start) {
    return prism_rtl::make_rc<CharTail>(l0, start);
}


/// LexPath: unbounded fn Lex -> (([PathSegTok], Lex))
std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex> lex_path(const crate::syntax::lexer::Lex& l0) {
    std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<crate::syntax::lexer::PathSegTok>{}, l0};
    crate::syntax::lexer::Lex l = l0;
    Array<crate::syntax::lexer::PathSegTok> segs = Array<crate::syntax::lexer::PathSegTok>{};
    bool going = true;
    while (going) {
        auto s = l.pos;
        auto c = crate::syntax::lexer::chars::peek(l);
        if (c == Text::lit("#")) {
            auto digits = ({
                crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l);
                while (crate::syntax::lexer::chars::is_digit(crate::syntax::lexer::chars::peek(this_))) {
                    this_.pos = this_.pos + Nat(1u);
                }
                this_;
            });
            auto text = crate::syntax::lexer::chars::slice(digits, s + Nat(1u), digits.pos);
            l = text == Text::lit("")
                ? crate::syntax::lexer::chars::lex_err(digits, s, digits.pos, Text::lit("a generation segment is `#` and a number"))
                : digits;
            segs = crate::prelude::push(segs, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstGen{or_(parse_nat_opt(text), Nat(0u))}));
        } else if (crate::syntax::lexer::chars::is_digit(c)) {
            auto digits = ({
                crate::syntax::lexer::Lex this_ = l;
                while (crate::syntax::lexer::chars::is_digit(crate::syntax::lexer::chars::peek(this_))) {
                    this_.pos = this_.pos + Nat(1u);
                }
                this_;
            });
            segs = crate::prelude::push(segs, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstNum{or_(parse_nat_opt(crate::syntax::lexer::chars::slice(digits, s, digits.pos)), Nat(0u))}));
            l = digits;
        } else if (c == Text::lit("[")) {
            auto [toks, l2] = crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPathKey{}));
            segs = crate::prelude::push(segs, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstKey{toks}));
            l = l2;
        } else  {
            l = crate::syntax::lexer::chars::lex_err(l, s, s, Text::lit("expected a path segment: a number, `#` and a number, or `[key]`"));
            going = false;
        }
        if (going) {
            if (crate::syntax::lexer::chars::peek(l) == Text::lit("/")) {
                l = crate::syntax::lexer::chars::bump(l);
            } else  {
                going = false;
            }
        }
    }
    this_ = std::tuple{segs, l};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>> LexPath::cycle() const {
    const auto& l0 = this->l0;
    std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<crate::syntax::lexer::PathSegTok>{}, l0};
    crate::syntax::lexer::Lex l = l0;
    Array<crate::syntax::lexer::PathSegTok> segs = Array<crate::syntax::lexer::PathSegTok>{};
    bool going = true;
    return call_then(loop_job(std::tuple{this_, going, l, segs}, [=](std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto l = std::get<2>(_p0);
        auto segs = std::get<3>(_p0);
        return going
            ? ({
            auto s = l.pos;
            auto c = crate::syntax::lexer::chars::peek(l);
            if (c == Text::lit("#")) {
                auto digits = ({
                    crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l);
                    while (crate::syntax::lexer::chars::is_digit(crate::syntax::lexer::chars::peek(this_))) {
                        this_.pos = this_.pos + Nat(1u);
                    }
                    this_;
                });
                auto text = crate::syntax::lexer::chars::slice(digits, s + Nat(1u), digits.pos);
                l = text == Text::lit("")
                    ? crate::syntax::lexer::chars::lex_err(digits, s, digits.pos, Text::lit("a generation segment is `#` and a number"))
                    : digits;
                segs = crate::prelude::push(segs, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstGen{or_(parse_nat_opt(text), Nat(0u))}));
            } else if (crate::syntax::lexer::chars::is_digit(c)) {
                auto digits = ({
                    crate::syntax::lexer::Lex this_ = l;
                    while (crate::syntax::lexer::chars::is_digit(crate::syntax::lexer::chars::peek(this_))) {
                        this_.pos = this_.pos + Nat(1u);
                    }
                    this_;
                });
                segs = crate::prelude::push(segs, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstNum{or_(parse_nat_opt(crate::syntax::lexer::chars::slice(digits, s, digits.pos)), Nat(0u))}));
                l = digits;
            } else if (c == Text::lit("[")) {
                auto [toks, l2] = crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPathKey{}));
                segs = crate::prelude::push(segs, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstKey{toks}));
                l = l2;
            } else  {
                l = crate::syntax::lexer::chars::lex_err(l, s, s, Text::lit("expected a path segment: a number, `#` and a number, or `[key]`"));
                going = false;
            }
            if (going) {
                if (crate::syntax::lexer::chars::peek(l) == Text::lit("/")) {
                    l = crate::syntax::lexer::chars::bump(l);
                } else  {
                    going = false;
                }
            }
            Expected<std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>>, std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>>>(std::tuple{this_, going, l, segs});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>>, std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>>>(unexpected(std::tuple{this_, going, l, segs}));
    }), [=](std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto l = std::get<2>(_p0);
        auto segs = std::get<3>(_p0);
        return ({
            this_ = std::tuple{segs, l};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start LexPath, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>> start_lex_path(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexPath>(l0);
}

}  // namespace crate::syntax::lexer::literals
