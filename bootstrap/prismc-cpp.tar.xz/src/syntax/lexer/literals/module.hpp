// The module `Syntax.Lexer.Literals`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/lexer/literals/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::lexer::literals {

std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_number(const crate::syntax::lexer::Lex& l, const Text& sigils);

prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_number(crate::syntax::lexer::Lex l, Text sigils);

std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_radix(const crate::syntax::lexer::Lex& l0, const Text& sigils);

prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_radix(crate::syntax::lexer::Lex l0, Text sigils);

crate::syntax::lexer::Lex skip_digits(const crate::syntax::lexer::Lex& l);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_skip_digits(crate::syntax::lexer::Lex l);

std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_decimal(const crate::syntax::lexer::Lex& l0, const Text& sigils);

prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_decimal(crate::syntax::lexer::Lex l0, Text sigils);

Array<std::tuple<Text, Nat>> duration_units();

std::optional<std::tuple<Text, Nat>> unit_at(const crate::syntax::lexer::Lex& l);

std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> number_tail(const crate::syntax::lexer::Lex& l, const Text& sigils, const Nat& start, const bool& decimal);

prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_number_tail(crate::syntax::lexer::Lex l, Text sigils, Nat start, bool decimal);

std::tuple<bool, crate::syntax::lexer::Lex> exponent(const crate::syntax::lexer::Lex& l, const bool& decimal);

prism_rtl::JobRef<std::tuple<bool, crate::syntax::lexer::Lex>> start_exponent(crate::syntax::lexer::Lex l, bool decimal);

bool whole_nanoseconds(const Text& text, const Nat& scale);

Text trim_zeros(const Text& t);

crate::syntax::lexer::Lex check_no_suffix(const crate::syntax::lexer::Lex& l0, const Nat& start);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_check_no_suffix(crate::syntax::lexer::Lex l0, Nat start);

std::tuple<Text, crate::syntax::lexer::Lex> lex_escape(const crate::syntax::lexer::Lex& l0);

prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_lex_escape(crate::syntax::lexer::Lex l0);

std::tuple<Text, crate::syntax::lexer::Lex> unicode_escape(const crate::syntax::lexer::Lex& l, const Nat& start);

prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_unicode_escape(crate::syntax::lexer::Lex l, Nat start);

std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> lex_text(const crate::syntax::lexer::Lex& l0);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>> start_lex_text(crate::syntax::lexer::Lex l0);

std::tuple<Text, crate::syntax::lexer::Lex> lex_char(const crate::syntax::lexer::Lex& l0);

prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_lex_char(crate::syntax::lexer::Lex l0);

crate::syntax::lexer::Lex char_tail(const crate::syntax::lexer::Lex& l0, const Nat& start);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_char_tail(crate::syntax::lexer::Lex l0, Nat start);

std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex> lex_path(const crate::syntax::lexer::Lex& l0);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>> start_lex_path(crate::syntax::lexer::Lex l0);

}  // namespace syntax::lexer::literals


namespace syntax::lexer::literals {

/// The step machine of `LexNumber`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexNumber: unbounded fn Lex, Text -> ((TokKind, Lex))
struct LexNumber : prism_rtl::Job<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l;
    Text sigils;
    LexNumber(crate::syntax::lexer::Lex l, Text sigils) : l(std::move(l)), sigils(std::move(sigils)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `LexRadix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexRadix: unbounded fn Lex, Text -> ((TokKind, Lex))
struct LexRadix : prism_rtl::Job<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0;
    Text sigils;
    LexRadix(crate::syntax::lexer::Lex l0, Text sigils) : l0(std::move(l0)), sigils(std::move(sigils)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `SkipDigits`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SkipDigits: unbounded fn Lex -> Lex
struct SkipDigits : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l;
    SkipDigits(crate::syntax::lexer::Lex l) : l(std::move(l)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexDecimal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexDecimal: unbounded fn Lex, Text -> ((TokKind, Lex))
struct LexDecimal : prism_rtl::Job<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0;
    Text sigils;
    LexDecimal(crate::syntax::lexer::Lex l0, Text sigils) : l0(std::move(l0)), sigils(std::move(sigils)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `NumberTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NumberTail: unbounded fn Lex, Text, Nat, Bool -> ((TokKind, Lex))
struct NumberTail : prism_rtl::Job<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l;
    Text sigils;
    Nat start;
    bool decimal;
    NumberTail(crate::syntax::lexer::Lex l, Text sigils, Nat start, bool decimal) : l(std::move(l)), sigils(std::move(sigils)), start(std::move(start)), decimal(std::move(decimal)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `Exponent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Exponent: unbounded fn Lex, Bool -> ((Bool, Lex))
struct Exponent : prism_rtl::Job<std::tuple<bool, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l;
    bool decimal;
    Exponent(crate::syntax::lexer::Lex l, bool decimal) : l(std::move(l)), decimal(std::move(decimal)) {}
    prism_rtl::Turn<std::tuple<bool, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `CheckNoSuffix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckNoSuffix: unbounded fn Lex, Nat -> Lex
struct CheckNoSuffix : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l0;
    Nat start;
    CheckNoSuffix(crate::syntax::lexer::Lex l0, Nat start) : l0(std::move(l0)), start(std::move(start)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexEscape`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexEscape: unbounded fn Lex -> ((Text, Lex))
struct LexEscape : prism_rtl::Job<std::tuple<Text, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0;
    LexEscape(crate::syntax::lexer::Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `UnicodeEscape`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnicodeEscape: unbounded fn Lex, Nat -> ((Text, Lex))
struct UnicodeEscape : prism_rtl::Job<std::tuple<Text, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l;
    Nat start;
    UnicodeEscape(crate::syntax::lexer::Lex l, Nat start) : l(std::move(l)), start(std::move(start)) {}
    prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `LexText`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexText: unbounded fn Lex -> (([TextSegTok], Lex))
struct LexText : prism_rtl::Job<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0;
    LexText(crate::syntax::lexer::Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `LexChar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexChar: unbounded fn Lex -> ((Text, Lex))
struct LexChar : prism_rtl::Job<std::tuple<Text, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0;
    LexChar(crate::syntax::lexer::Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `CharTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CharTail: unbounded fn Lex, Nat -> Lex
struct CharTail : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l0;
    Nat start;
    CharTail(crate::syntax::lexer::Lex l0, Nat start) : l0(std::move(l0)), start(std::move(start)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexPath: unbounded fn Lex -> (([PathSegTok], Lex))
struct LexPath : prism_rtl::Job<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0;
    LexPath(crate::syntax::lexer::Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>> cycle() const override;
};


}  // namespace syntax::lexer::literals

}  // namespace crate
