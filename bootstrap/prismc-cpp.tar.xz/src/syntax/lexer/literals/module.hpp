// The module `Syntax.Lexer.Literals`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/lexer/literals/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::lexer::literals {

std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_number_f(const crate::syntax::lexer::Lex& l_p0, const Text& sigils_p1);

prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_number_f(crate::syntax::lexer::Lex l_p0, Text sigils_p1);

std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_radix_f(const crate::syntax::lexer::Lex& l0_p0, const Text& sigils_p1);

prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_radix_f(crate::syntax::lexer::Lex l0_p0, Text sigils_p1);

crate::syntax::lexer::Lex skip_digits_f(const crate::syntax::lexer::Lex& l_p0);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_skip_digits_f(crate::syntax::lexer::Lex l_p0);

std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_decimal_f(const crate::syntax::lexer::Lex& l0_p0, const Text& sigils_p1);

prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_decimal_f(crate::syntax::lexer::Lex l0_p0, Text sigils_p1);

Array<std::tuple<Text, Nat>> duration_units_p();

std::optional<std::tuple<Text, Nat>> unit_at_o(const crate::syntax::lexer::Lex& l_p0);

std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> number_tail_f(const crate::syntax::lexer::Lex& l_p0, const Text& sigils_p1, const Nat& start_p2, const bool& decimal_p3);

prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_number_tail_f(crate::syntax::lexer::Lex l_p0, Text sigils_p1, Nat start_p2, bool decimal_p3);

std::tuple<bool, crate::syntax::lexer::Lex> exponent_f(const crate::syntax::lexer::Lex& l_p0, const bool& decimal_p1);

prism_rtl::JobRef<std::tuple<bool, crate::syntax::lexer::Lex>> start_exponent_f(crate::syntax::lexer::Lex l_p0, bool decimal_p1);

bool whole_nanoseconds_f(const Text& text_p0, const Nat& scale_p1);

Text trim_zeros_f(const Text& t_p0);

crate::syntax::lexer::Lex check_no_suffix_f(const crate::syntax::lexer::Lex& l0_p0, const Nat& start_p1);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_check_no_suffix_f(crate::syntax::lexer::Lex l0_p0, Nat start_p1);

std::tuple<Text, crate::syntax::lexer::Lex> lex_escape_f(const crate::syntax::lexer::Lex& l0_p0);

prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_lex_escape_f(crate::syntax::lexer::Lex l0_p0);

std::tuple<Text, crate::syntax::lexer::Lex> unicode_escape_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1);

prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_unicode_escape_f(crate::syntax::lexer::Lex l_p0, Nat start_p1);

std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> lex_text_f(const crate::syntax::lexer::Lex& l0_p0);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>> start_lex_text_f(crate::syntax::lexer::Lex l0_p0);

std::tuple<Text, crate::syntax::lexer::Lex> lex_char_f(const crate::syntax::lexer::Lex& l0_p0);

prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_lex_char_f(crate::syntax::lexer::Lex l0_p0);

crate::syntax::lexer::Lex char_tail_f(const crate::syntax::lexer::Lex& l0_p0, const Nat& start_p1);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_char_tail_f(crate::syntax::lexer::Lex l0_p0, Nat start_p1);

std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex> lex_path_f(const crate::syntax::lexer::Lex& l0_p0);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>> start_lex_path_f(crate::syntax::lexer::Lex l0_p0);

}  // namespace syntax::lexer::literals


namespace syntax::lexer::literals {

/// The step machine of `LexNumber`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexNumber: unbounded fn Lex, Text -> ((TokKind, Lex))
struct LexNumber : prism_rtl::Job<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l_p0;
    Text sigils_p1;
    LexNumber(crate::syntax::lexer::Lex l_p0, Text sigils_p1) : l_p0(std::move(l_p0)), sigils_p1(std::move(sigils_p1)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `LexRadix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexRadix: unbounded fn Lex, Text -> ((TokKind, Lex))
struct LexRadix : prism_rtl::Job<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0_p0;
    Text sigils_p1;
    LexRadix(crate::syntax::lexer::Lex l0_p0, Text sigils_p1) : l0_p0(std::move(l0_p0)), sigils_p1(std::move(sigils_p1)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `SkipDigits`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SkipDigits: unbounded fn Lex -> Lex
struct SkipDigits : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l_p0;
    SkipDigits(crate::syntax::lexer::Lex l_p0) : l_p0(std::move(l_p0)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexDecimal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexDecimal: unbounded fn Lex, Text -> ((TokKind, Lex))
struct LexDecimal : prism_rtl::Job<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0_p0;
    Text sigils_p1;
    LexDecimal(crate::syntax::lexer::Lex l0_p0, Text sigils_p1) : l0_p0(std::move(l0_p0)), sigils_p1(std::move(sigils_p1)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `NumberTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NumberTail: unbounded fn Lex, Text, Nat, Bool -> ((TokKind, Lex))
struct NumberTail : prism_rtl::Job<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l_p0;
    Text sigils_p1;
    Nat start_p2;
    bool decimal_p3;
    NumberTail(crate::syntax::lexer::Lex l_p0, Text sigils_p1, Nat start_p2, bool decimal_p3) : l_p0(std::move(l_p0)), sigils_p1(std::move(sigils_p1)), start_p2(std::move(start_p2)), decimal_p3(std::move(decimal_p3)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `Exponent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Exponent: unbounded fn Lex, Bool -> ((Bool, Lex))
struct Exponent : prism_rtl::Job<std::tuple<bool, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l_p0;
    bool decimal_p1;
    Exponent(crate::syntax::lexer::Lex l_p0, bool decimal_p1) : l_p0(std::move(l_p0)), decimal_p1(std::move(decimal_p1)) {}
    prism_rtl::Turn<std::tuple<bool, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `CheckNoSuffix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckNoSuffix: unbounded fn Lex, Nat -> Lex
struct CheckNoSuffix : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l0_p0;
    Nat start_p1;
    CheckNoSuffix(crate::syntax::lexer::Lex l0_p0, Nat start_p1) : l0_p0(std::move(l0_p0)), start_p1(std::move(start_p1)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexEscape`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexEscape: unbounded fn Lex -> ((Text, Lex))
struct LexEscape : prism_rtl::Job<std::tuple<Text, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0_p0;
    LexEscape(crate::syntax::lexer::Lex l0_p0) : l0_p0(std::move(l0_p0)) {}
    prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `UnicodeEscape`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnicodeEscape: unbounded fn Lex, Nat -> ((Text, Lex))
struct UnicodeEscape : prism_rtl::Job<std::tuple<Text, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l_p0;
    Nat start_p1;
    UnicodeEscape(crate::syntax::lexer::Lex l_p0, Nat start_p1) : l_p0(std::move(l_p0)), start_p1(std::move(start_p1)) {}
    prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `LexText`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexText: unbounded fn Lex -> (([TextSegTok], Lex))
struct LexText : prism_rtl::Job<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0_p0;
    LexText(crate::syntax::lexer::Lex l0_p0) : l0_p0(std::move(l0_p0)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `LexChar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexChar: unbounded fn Lex -> ((Text, Lex))
struct LexChar : prism_rtl::Job<std::tuple<Text, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0_p0;
    LexChar(crate::syntax::lexer::Lex l0_p0) : l0_p0(std::move(l0_p0)) {}
    prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `CharTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CharTail: unbounded fn Lex, Nat -> Lex
struct CharTail : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l0_p0;
    Nat start_p1;
    CharTail(crate::syntax::lexer::Lex l0_p0, Nat start_p1) : l0_p0(std::move(l0_p0)), start_p1(std::move(start_p1)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexPath: unbounded fn Lex -> (([PathSegTok], Lex))
struct LexPath : prism_rtl::Job<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0_p0;
    LexPath(crate::syntax::lexer::Lex l0_p0) : l0_p0(std::move(l0_p0)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>> cycle() const override;
};


}  // namespace syntax::lexer::literals

}  // namespace crate
