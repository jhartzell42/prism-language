// The module `Syntax.Lexer.Literals`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace syntax::lexer::literals {

struct LexNumber;

struct LexRadix;

struct SkipDigits;

struct LexDecimal;

struct NumberTail;

struct Exponent;

struct CheckNoSuffix;

struct LexEscape;

struct UnicodeEscape;

struct LexText;

struct LexChar;

struct CharTail;

struct LexPath;

}  // namespace syntax::lexer::literals

}  // namespace crate
