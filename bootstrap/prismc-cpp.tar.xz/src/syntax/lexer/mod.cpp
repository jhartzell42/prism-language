// The module `Syntax.Lexer`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <syntax/lexer/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

namespace crate::syntax::lexer {

void AttrTok::show(Printer& p) const {
    p.record("AttrTok", {{"name", name}, {"tokens", tokens}, {"span", span}});
}

Pod AttrTok::to_pod() const {
    return Pod::record("AttrTok", {{"name", prism_rtl::to_pod(name)}, {"tokens", prism_rtl::to_pod(tokens)}, {"span", prism_rtl::to_pod(span)}});
}

Result<AttrTok> AttrTok::from_pod(const Pod& whole) {
    return AttrTok{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .tokens = TRY(prism_rtl::from_pod<Array<Tok>>(TRY(crate::prelude::field(whole, "tokens")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Lex::show(Printer& p) const {
    p.record("Lex", {{"src", src}, {"pos", pos}, {"diags", diags}, {"mode", mode}, {"tokens", tokens}, {"layout", layout}, {"frames", frames}, {"last_ws", last_ws}, {"lambda_open", lambda_open}, {"pending_open", pending_open}, {"pending_span", pending_span}, {"line_first", line_first}, {"mark_line_start", mark_line_start}, {"first_line", first_line}, {"test_pending", test_pending}, {"test_depth", test_depth}, {"check_depth", check_depth}, {"path_next", path_next}});
}

Pod Lex::to_pod() const {
    return Pod::record("Lex", {{"src", prism_rtl::to_pod(src)}, {"pos", prism_rtl::to_pod(pos)}, {"diags", prism_rtl::to_pod(diags)}, {"mode", prism_rtl::to_pod(mode)}, {"tokens", prism_rtl::to_pod(tokens)}, {"layout", prism_rtl::to_pod(layout)}, {"frames", prism_rtl::to_pod(frames)}, {"last_ws", prism_rtl::to_pod(last_ws)}, {"lambda_open", prism_rtl::to_pod(lambda_open)}, {"pending_open", prism_rtl::to_pod(pending_open)}, {"pending_span", prism_rtl::to_pod(pending_span)}, {"line_first", prism_rtl::to_pod(line_first)}, {"mark_line_start", prism_rtl::to_pod(mark_line_start)}, {"first_line", prism_rtl::to_pod(first_line)}, {"test_pending", prism_rtl::to_pod(test_pending)}, {"test_depth", prism_rtl::to_pod(test_depth)}, {"check_depth", prism_rtl::to_pod(check_depth)}, {"path_next", prism_rtl::to_pod(path_next)}});
}

Result<Lex> Lex::from_pod(const Pod& whole) {
    return Lex{.src = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "src")))), .pos = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "pos")))), .diags = TRY(prism_rtl::from_pod<Array<crate::syntax::Diag>>(TRY(crate::prelude::field(whole, "diags")))), .mode = TRY(prism_rtl::from_pod<Mode>(TRY(crate::prelude::field(whole, "mode")))), .tokens = TRY(prism_rtl::from_pod<Array<Tok>>(TRY(crate::prelude::field(whole, "tokens")))), .layout = TRY(prism_rtl::from_pod<Array<Nat>>(TRY(crate::prelude::field(whole, "layout")))), .frames = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "frames")))), .last_ws = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "last_ws")))), .lambda_open = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "lambda_open")))), .pending_open = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "pending_open")))), .pending_span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "pending_span")))), .line_first = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "line_first")))), .mark_line_start = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "mark_line_start")))), .first_line = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "first_line")))), .test_pending = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "test_pending")))), .test_depth = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(crate::prelude::field(whole, "test_depth")))), .check_depth = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(crate::prelude::field(whole, "check_depth")))), .path_next = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "path_next"))))};
}


void Lexed::show(Printer& p) const {
    p.record("Lexed", {{"tokens", tokens}, {"diags", diags}});
}

Pod Lexed::to_pod() const {
    return Pod::record("Lexed", {{"tokens", prism_rtl::to_pod(tokens)}, {"diags", prism_rtl::to_pod(diags)}});
}

Result<Lexed> Lexed::from_pod(const Pod& whole) {
    return Lexed{.tokens = TRY(prism_rtl::from_pod<Array<Tok>>(TRY(crate::prelude::field(whole, "tokens")))), .diags = TRY(prism_rtl::from_pod<Array<crate::syntax::Diag>>(TRY(crate::prelude::field(whole, "diags"))))};
}


void Mode::show(Printer& p) const {
    if (auto c = std::get_if<MFile>(&cases())) p.choice("MFile", {});
    else if (auto c = std::get_if<MBrace>(&cases())) p.choice("MBrace", {c->a0});
    else if (auto c = std::get_if<MPlaceholder>(&cases())) p.choice("MPlaceholder", {c->a0});
    else if (auto c = std::get_if<MPathKey>(&cases())) p.choice("MPathKey", {});
}

Pod Mode::to_pod() const {
    return std::holds_alternative<MFile>(cases()) ? Pod::choice("MFile", {})
        : std::holds_alternative<MBrace>(cases()) ? Pod::choice("MBrace", {prism_rtl::to_pod(std::get<MBrace>(cases()).a0)})
        : std::holds_alternative<MPlaceholder>(cases()) ? Pod::choice("MPlaceholder", {prism_rtl::to_pod(std::get<MPlaceholder>(cases()).a0)})
        : std::holds_alternative<MPathKey>(cases()) ? Pod::choice("MPathKey", {})
        : Pod();
}

Result<Mode> Mode::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "MFile" && c->args.size() == 0) return Mode(MFile{});
        if (c->ctor == "MBrace" && c->args.size() == 1) return Mode(MBrace{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "MPlaceholder" && c->args.size() == 1) return Mode(MPlaceholder{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "MPathKey" && c->args.size() == 0) return Mode(MPathKey{});
    }
    return mismatch<Mode>("a Mode", p);
}


void NameCase::show(Printer& p) const {
    if (auto c = std::get_if<CaseLower>(&cases())) p.choice("CaseLower", {});
    else if (auto c = std::get_if<CaseUpper>(&cases())) p.choice("CaseUpper", {});
    else if (auto c = std::get_if<CaseTopic>(&cases())) p.choice("CaseTopic", {});
    else if (auto c = std::get_if<CaseHole>(&cases())) p.choice("CaseHole", {});
    else if (auto c = std::get_if<CaseReserved>(&cases())) p.choice("CaseReserved", {});
}

Pod NameCase::to_pod() const {
    return std::holds_alternative<CaseLower>(cases()) ? Pod::choice("CaseLower", {})
        : std::holds_alternative<CaseUpper>(cases()) ? Pod::choice("CaseUpper", {})
        : std::holds_alternative<CaseTopic>(cases()) ? Pod::choice("CaseTopic", {})
        : std::holds_alternative<CaseHole>(cases()) ? Pod::choice("CaseHole", {})
        : std::holds_alternative<CaseReserved>(cases()) ? Pod::choice("CaseReserved", {})
        : Pod();
}

Result<NameCase> NameCase::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "CaseLower" && c->args.size() == 0) return NameCase(CaseLower{});
        if (c->ctor == "CaseUpper" && c->args.size() == 0) return NameCase(CaseUpper{});
        if (c->ctor == "CaseTopic" && c->args.size() == 0) return NameCase(CaseTopic{});
        if (c->ctor == "CaseHole" && c->args.size() == 0) return NameCase(CaseHole{});
        if (c->ctor == "CaseReserved" && c->args.size() == 0) return NameCase(CaseReserved{});
    }
    return mismatch<NameCase>("a NameCase", p);
}


void NameTok::show(Printer& p) const {
    p.record("NameTok", {{"sigils", sigils}, {"path", path_}, {"case", case_}});
}

Pod NameTok::to_pod() const {
    return Pod::record("NameTok", {{"sigils", prism_rtl::to_pod(sigils)}, {"path", prism_rtl::to_pod(path_)}, {"case", prism_rtl::to_pod(case_)}});
}

Result<NameTok> NameTok::from_pod(const Pod& whole) {
    return NameTok{.sigils = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "sigils")))), .path_ = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "path")))), .case_ = TRY(prism_rtl::from_pod<NameCase>(TRY(crate::prelude::field(whole, "case"))))};
}


void PathSegTok::show(Printer& p) const {
    if (auto c = std::get_if<PstNum>(&cases())) p.choice("PstNum", {c->a0});
    else if (auto c = std::get_if<PstGen>(&cases())) p.choice("PstGen", {c->a0});
    else if (auto c = std::get_if<PstKey>(&cases())) p.choice("PstKey", {c->a0});
}

Pod PathSegTok::to_pod() const {
    return std::holds_alternative<PstNum>(cases()) ? Pod::choice("PstNum", {prism_rtl::to_pod(std::get<PstNum>(cases()).a0)})
        : std::holds_alternative<PstGen>(cases()) ? Pod::choice("PstGen", {prism_rtl::to_pod(std::get<PstGen>(cases()).a0)})
        : std::holds_alternative<PstKey>(cases()) ? Pod::choice("PstKey", {prism_rtl::to_pod(std::get<PstKey>(cases()).a0)})
        : Pod();
}

Result<PathSegTok> PathSegTok::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "PstNum" && c->args.size() == 1) return PathSegTok(PstNum{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "PstGen" && c->args.size() == 1) return PathSegTok(PstGen{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "PstKey" && c->args.size() == 1) return PathSegTok(PstKey{TRY(prism_rtl::from_pod<Array<Tok>>(c->args[0]))});
    }
    return mismatch<PathSegTok>("a PathSegTok", p);
}


void TPartTok::show(Printer& p) const {
    if (auto c = std::get_if<TptText>(&cases())) p.choice("TptText", {c->a0});
    else if (auto c = std::get_if<TptPlaceholder>(&cases())) p.choice("TptPlaceholder", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<TptBlock>(&cases())) p.choice("TptBlock", {c->a0, c->a1});
    else if (auto c = std::get_if<TptCall>(&cases())) p.choice("TptCall", {c->a0, c->a1, c->a2, c->a3});
}

Pod TPartTok::to_pod() const {
    return std::holds_alternative<TptText>(cases()) ? Pod::choice("TptText", {prism_rtl::to_pod(std::get<TptText>(cases()).a0)})
        : std::holds_alternative<TptPlaceholder>(cases()) ? Pod::choice("TptPlaceholder", {prism_rtl::to_pod(std::get<TptPlaceholder>(cases()).a0), prism_rtl::to_pod(std::get<TptPlaceholder>(cases()).a1), prism_rtl::to_pod(std::get<TptPlaceholder>(cases()).a2)})
        : std::holds_alternative<TptBlock>(cases()) ? Pod::choice("TptBlock", {prism_rtl::to_pod(std::get<TptBlock>(cases()).a0), prism_rtl::to_pod(std::get<TptBlock>(cases()).a1)})
        : std::holds_alternative<TptCall>(cases()) ? Pod::choice("TptCall", {prism_rtl::to_pod(std::get<TptCall>(cases()).a0), prism_rtl::to_pod(std::get<TptCall>(cases()).a1), prism_rtl::to_pod(std::get<TptCall>(cases()).a2), prism_rtl::to_pod(std::get<TptCall>(cases()).a3)})
        : Pod();
}

Result<TPartTok> TPartTok::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TptText" && c->args.size() == 1) return TPartTok(TptText{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TptPlaceholder" && c->args.size() == 3) return TPartTok(TptPlaceholder{TRY(prism_rtl::from_pod<Array<Tok>>(c->args[0])), TRY(prism_rtl::from_pod<std::optional<Nat>>(c->args[1])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[2]))});
        if (c->ctor == "TptBlock" && c->args.size() == 2) return TPartTok(TptBlock{TRY(prism_rtl::from_pod<Array<Tok>>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[1]))});
        if (c->ctor == "TptCall" && c->args.size() == 4) return TPartTok(TptCall{TRY(prism_rtl::from_pod<NameTok>(c->args[0])), TRY(prism_rtl::from_pod<Array<AttrTok>>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Array<TPartTok>>>(c->args[2])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[3]))});
    }
    return mismatch<TPartTok>("a TPartTok", p);
}


void TemplateTok::show(Printer& p) const {
    p.record("TemplateTok", {{"keyword", keyword}, {"lang", lang}, {"delims", delims}, {"parts", parts}});
}

Pod TemplateTok::to_pod() const {
    return Pod::record("TemplateTok", {{"keyword", prism_rtl::to_pod(keyword)}, {"lang", prism_rtl::to_pod(lang)}, {"delims", prism_rtl::to_pod(delims)}, {"parts", prism_rtl::to_pod(parts)}});
}

Result<TemplateTok> TemplateTok::from_pod(const Pod& whole) {
    return TemplateTok{.keyword = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "keyword")))), .lang = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "lang")))), .delims = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "delims")))), .parts = TRY(prism_rtl::from_pod<Array<TPartTok>>(TRY(crate::prelude::field(whole, "parts"))))};
}


void TextSegTok::show(Printer& p) const {
    if (auto c = std::get_if<TsPlain>(&cases())) p.choice("TsPlain", {c->a0});
    else if (auto c = std::get_if<TsPlaceholder>(&cases())) p.choice("TsPlaceholder", {c->a0, c->a1});
}

Pod TextSegTok::to_pod() const {
    return std::holds_alternative<TsPlain>(cases()) ? Pod::choice("TsPlain", {prism_rtl::to_pod(std::get<TsPlain>(cases()).a0)})
        : std::holds_alternative<TsPlaceholder>(cases()) ? Pod::choice("TsPlaceholder", {prism_rtl::to_pod(std::get<TsPlaceholder>(cases()).a0), prism_rtl::to_pod(std::get<TsPlaceholder>(cases()).a1)})
        : Pod();
}

Result<TextSegTok> TextSegTok::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TsPlain" && c->args.size() == 1) return TextSegTok(TsPlain{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TsPlaceholder" && c->args.size() == 2) return TextSegTok(TsPlaceholder{TRY(prism_rtl::from_pod<Array<Tok>>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[1]))});
    }
    return mismatch<TextSegTok>("a TextSegTok", p);
}


void Tok::show(Printer& p) const {
    p.record("Tok", {{"kind", kind}, {"span", span}, {"touches", touches}, {"line_start", line_start}});
}

Pod Tok::to_pod() const {
    return Pod::record("Tok", {{"kind", prism_rtl::to_pod(kind)}, {"span", prism_rtl::to_pod(span)}, {"touches", prism_rtl::to_pod(touches)}, {"line_start", prism_rtl::to_pod(line_start)}});
}

Result<Tok> Tok::from_pod(const Pod& whole) {
    return Tok{.kind = TRY(prism_rtl::from_pod<TokKind>(TRY(crate::prelude::field(whole, "kind")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .touches = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "touches")))), .line_start = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "line_start"))))};
}


void TokKind::show(Printer& p) const {
    if (auto c = std::get_if<KName>(&cases())) p.choice("KName", {c->a0});
    else if (auto c = std::get_if<KFamily>(&cases())) p.choice("KFamily", {c->a0});
    else if (auto c = std::get_if<KTrait>(&cases())) p.choice("KTrait", {c->a0});
    else if (auto c = std::get_if<KKw>(&cases())) p.choice("KKw", {c->a0, c->a1});
    else if (auto c = std::get_if<KFree>(&cases())) p.choice("KFree", {c->a0});
    else if (auto c = std::get_if<KLensDot>(&cases())) p.choice("KLensDot", {});
    else if (auto c = std::get_if<KInt>(&cases())) p.choice("KInt", {c->a0, c->a1});
    else if (auto c = std::get_if<KFloat>(&cases())) p.choice("KFloat", {c->a0, c->a1});
    else if (auto c = std::get_if<KDuration>(&cases())) p.choice("KDuration", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<KChar>(&cases())) p.choice("KChar", {c->a0, c->a1});
    else if (auto c = std::get_if<KText>(&cases())) p.choice("KText", {c->a0, c->a1});
    else if (auto c = std::get_if<KRegex>(&cases())) p.choice("KRegex", {c->a0, c->a1});
    else if (auto c = std::get_if<KTemplate>(&cases())) p.choice("KTemplate", {c->a0});
    else if (auto c = std::get_if<KOp>(&cases())) p.choice("KOp", {c->a0, c->a1});
    else if (auto c = std::get_if<KSuffixed>(&cases())) p.choice("KSuffixed", {c->a0, c->a1});
    else if (auto c = std::get_if<KDot>(&cases())) p.choice("KDot", {c->a0});
    else if (auto c = std::get_if<KDotDot>(&cases())) p.choice("KDotDot", {});
    else if (auto c = std::get_if<KComma>(&cases())) p.choice("KComma", {});
    else if (auto c = std::get_if<KColon>(&cases())) p.choice("KColon", {});
    else if (auto c = std::get_if<KSemi>(&cases())) p.choice("KSemi", {});
    else if (auto c = std::get_if<KBackslash>(&cases())) p.choice("KBackslash", {});
    else if (auto c = std::get_if<KLambdaBar>(&cases())) p.choice("KLambdaBar", {c->a0});
    else if (auto c = std::get_if<KBar>(&cases())) p.choice("KBar", {});
    else if (auto c = std::get_if<KLtLt>(&cases())) p.choice("KLtLt", {});
    else if (auto c = std::get_if<KGtGt>(&cases())) p.choice("KGtGt", {});
    else if (auto c = std::get_if<KOpen>(&cases())) p.choice("KOpen", {c->a0, c->a1});
    else if (auto c = std::get_if<KClose>(&cases())) p.choice("KClose", {c->a0});
    else if (auto c = std::get_if<KAbsent>(&cases())) p.choice("KAbsent", {});
    else if (auto c = std::get_if<KNonEmpty>(&cases())) p.choice("KNonEmpty", {});
    else if (auto c = std::get_if<KPath>(&cases())) p.choice("KPath", {c->a0});
    else if (auto c = std::get_if<KLayOpen>(&cases())) p.choice("KLayOpen", {});
    else if (auto c = std::get_if<KLaySep>(&cases())) p.choice("KLaySep", {});
    else if (auto c = std::get_if<KLayClose>(&cases())) p.choice("KLayClose", {});
    else if (auto c = std::get_if<KEof>(&cases())) p.choice("KEof", {});
}

Pod TokKind::to_pod() const {
    return std::holds_alternative<KName>(cases()) ? Pod::choice("KName", {prism_rtl::to_pod(std::get<KName>(cases()).a0)})
        : std::holds_alternative<KFamily>(cases()) ? Pod::choice("KFamily", {prism_rtl::to_pod(std::get<KFamily>(cases()).a0)})
        : std::holds_alternative<KTrait>(cases()) ? Pod::choice("KTrait", {prism_rtl::to_pod(std::get<KTrait>(cases()).a0)})
        : std::holds_alternative<KKw>(cases()) ? Pod::choice("KKw", {prism_rtl::to_pod(std::get<KKw>(cases()).a0), prism_rtl::to_pod(std::get<KKw>(cases()).a1)})
        : std::holds_alternative<KFree>(cases()) ? Pod::choice("KFree", {prism_rtl::to_pod(std::get<KFree>(cases()).a0)})
        : std::holds_alternative<KLensDot>(cases()) ? Pod::choice("KLensDot", {})
        : std::holds_alternative<KInt>(cases()) ? Pod::choice("KInt", {prism_rtl::to_pod(std::get<KInt>(cases()).a0), prism_rtl::to_pod(std::get<KInt>(cases()).a1)})
        : std::holds_alternative<KFloat>(cases()) ? Pod::choice("KFloat", {prism_rtl::to_pod(std::get<KFloat>(cases()).a0), prism_rtl::to_pod(std::get<KFloat>(cases()).a1)})
        : std::holds_alternative<KDuration>(cases()) ? Pod::choice("KDuration", {prism_rtl::to_pod(std::get<KDuration>(cases()).a0), prism_rtl::to_pod(std::get<KDuration>(cases()).a1), prism_rtl::to_pod(std::get<KDuration>(cases()).a2)})
        : std::holds_alternative<KChar>(cases()) ? Pod::choice("KChar", {prism_rtl::to_pod(std::get<KChar>(cases()).a0), prism_rtl::to_pod(std::get<KChar>(cases()).a1)})
        : std::holds_alternative<KText>(cases()) ? Pod::choice("KText", {prism_rtl::to_pod(std::get<KText>(cases()).a0), prism_rtl::to_pod(std::get<KText>(cases()).a1)})
        : std::holds_alternative<KRegex>(cases()) ? Pod::choice("KRegex", {prism_rtl::to_pod(std::get<KRegex>(cases()).a0), prism_rtl::to_pod(std::get<KRegex>(cases()).a1)})
        : std::holds_alternative<KTemplate>(cases()) ? Pod::choice("KTemplate", {prism_rtl::to_pod(std::get<KTemplate>(cases()).a0)})
        : std::holds_alternative<KOp>(cases()) ? Pod::choice("KOp", {prism_rtl::to_pod(std::get<KOp>(cases()).a0), prism_rtl::to_pod(std::get<KOp>(cases()).a1)})
        : std::holds_alternative<KSuffixed>(cases()) ? Pod::choice("KSuffixed", {prism_rtl::to_pod(std::get<KSuffixed>(cases()).a0), prism_rtl::to_pod(std::get<KSuffixed>(cases()).a1)})
        : std::holds_alternative<KDot>(cases()) ? Pod::choice("KDot", {prism_rtl::to_pod(std::get<KDot>(cases()).a0)})
        : std::holds_alternative<KDotDot>(cases()) ? Pod::choice("KDotDot", {})
        : std::holds_alternative<KComma>(cases()) ? Pod::choice("KComma", {})
        : std::holds_alternative<KColon>(cases()) ? Pod::choice("KColon", {})
        : std::holds_alternative<KSemi>(cases()) ? Pod::choice("KSemi", {})
        : std::holds_alternative<KBackslash>(cases()) ? Pod::choice("KBackslash", {})
        : std::holds_alternative<KLambdaBar>(cases()) ? Pod::choice("KLambdaBar", {prism_rtl::to_pod(std::get<KLambdaBar>(cases()).a0)})
        : std::holds_alternative<KBar>(cases()) ? Pod::choice("KBar", {})
        : std::holds_alternative<KLtLt>(cases()) ? Pod::choice("KLtLt", {})
        : std::holds_alternative<KGtGt>(cases()) ? Pod::choice("KGtGt", {})
        : std::holds_alternative<KOpen>(cases()) ? Pod::choice("KOpen", {prism_rtl::to_pod(std::get<KOpen>(cases()).a0), prism_rtl::to_pod(std::get<KOpen>(cases()).a1)})
        : std::holds_alternative<KClose>(cases()) ? Pod::choice("KClose", {prism_rtl::to_pod(std::get<KClose>(cases()).a0)})
        : std::holds_alternative<KAbsent>(cases()) ? Pod::choice("KAbsent", {})
        : std::holds_alternative<KNonEmpty>(cases()) ? Pod::choice("KNonEmpty", {})
        : std::holds_alternative<KPath>(cases()) ? Pod::choice("KPath", {prism_rtl::to_pod(std::get<KPath>(cases()).a0)})
        : std::holds_alternative<KLayOpen>(cases()) ? Pod::choice("KLayOpen", {})
        : std::holds_alternative<KLaySep>(cases()) ? Pod::choice("KLaySep", {})
        : std::holds_alternative<KLayClose>(cases()) ? Pod::choice("KLayClose", {})
        : std::holds_alternative<KEof>(cases()) ? Pod::choice("KEof", {})
        : Pod();
}

Result<TokKind> TokKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "KName" && c->args.size() == 1) return TokKind(KName{TRY(prism_rtl::from_pod<NameTok>(c->args[0]))});
        if (c->ctor == "KFamily" && c->args.size() == 1) return TokKind(KFamily{TRY(prism_rtl::from_pod<Array<Text>>(c->args[0]))});
        if (c->ctor == "KTrait" && c->args.size() == 1) return TokKind(KTrait{TRY(prism_rtl::from_pod<Array<Text>>(c->args[0]))});
        if (c->ctor == "KKw" && c->args.size() == 2) return TokKind(KKw{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "KFree" && c->args.size() == 1) return TokKind(KFree{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "KLensDot" && c->args.size() == 0) return TokKind(KLensDot{});
        if (c->ctor == "KInt" && c->args.size() == 2) return TokKind(KInt{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "KFloat" && c->args.size() == 2) return TokKind(KFloat{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "KDuration" && c->args.size() == 3) return TokKind(KDuration{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Text>(c->args[2]))});
        if (c->ctor == "KChar" && c->args.size() == 2) return TokKind(KChar{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "KText" && c->args.size() == 2) return TokKind(KText{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<TextSegTok>>(c->args[1]))});
        if (c->ctor == "KRegex" && c->args.size() == 2) return TokKind(KRegex{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::RegexLit>(c->args[1]))});
        if (c->ctor == "KTemplate" && c->args.size() == 1) return TokKind(KTemplate{TRY(prism_rtl::from_pod<TemplateTok>(c->args[0]))});
        if (c->ctor == "KOp" && c->args.size() == 2) return TokKind(KOp{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<bool>(c->args[1]))});
        if (c->ctor == "KSuffixed" && c->args.size() == 2) return TokKind(KSuffixed{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Text>>(c->args[1]))});
        if (c->ctor == "KDot" && c->args.size() == 1) return TokKind(KDot{TRY(prism_rtl::from_pod<bool>(c->args[0]))});
        if (c->ctor == "KDotDot" && c->args.size() == 0) return TokKind(KDotDot{});
        if (c->ctor == "KComma" && c->args.size() == 0) return TokKind(KComma{});
        if (c->ctor == "KColon" && c->args.size() == 0) return TokKind(KColon{});
        if (c->ctor == "KSemi" && c->args.size() == 0) return TokKind(KSemi{});
        if (c->ctor == "KBackslash" && c->args.size() == 0) return TokKind(KBackslash{});
        if (c->ctor == "KLambdaBar" && c->args.size() == 1) return TokKind(KLambdaBar{TRY(prism_rtl::from_pod<bool>(c->args[0]))});
        if (c->ctor == "KBar" && c->args.size() == 0) return TokKind(KBar{});
        if (c->ctor == "KLtLt" && c->args.size() == 0) return TokKind(KLtLt{});
        if (c->ctor == "KGtGt" && c->args.size() == 0) return TokKind(KGtGt{});
        if (c->ctor == "KOpen" && c->args.size() == 2) return TokKind(KOpen{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<bool>(c->args[1]))});
        if (c->ctor == "KClose" && c->args.size() == 1) return TokKind(KClose{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "KAbsent" && c->args.size() == 0) return TokKind(KAbsent{});
        if (c->ctor == "KNonEmpty" && c->args.size() == 0) return TokKind(KNonEmpty{});
        if (c->ctor == "KPath" && c->args.size() == 1) return TokKind(KPath{TRY(prism_rtl::from_pod<Array<PathSegTok>>(c->args[0]))});
        if (c->ctor == "KLayOpen" && c->args.size() == 0) return TokKind(KLayOpen{});
        if (c->ctor == "KLaySep" && c->args.size() == 0) return TokKind(KLaySep{});
        if (c->ctor == "KLayClose" && c->args.size() == 0) return TokKind(KLayClose{});
        if (c->ctor == "KEof" && c->args.size() == 0) return TokKind(KEof{});
    }
    return mismatch<TokKind>("a TokKind", p);
}


/// Fresh: fn Lex, Mode -> Lex
Lex fresh(const Lex& l, const Mode& mode) {
    return Lex{.src = l.src, .pos = l.pos, .diags = l.diags, .mode = mode, .tokens = Array<Tok>{}, .layout = Array<Nat>{}, .frames = Array<Text>{}, .last_ws = true, .lambda_open = false, .pending_open = false, .pending_span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}, .line_first = Nat(0u), .mark_line_start = false, .first_line = true, .test_pending = Text::lit(""), .test_depth = std::optional<Nat>{}, .check_depth = std::optional<Nat>{}, .path_next = false};
}


/// IsLayoutOrEof: fn TokKind -> Bool
bool is_layout_or_eof(const TokKind& tok_kind0) {
    if (prism_rtl::is<TokKind::KLayOpen>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KLaySep>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KLayClose>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KEof>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// IsLayout: fn TokKind -> Bool
bool is_layout(const TokKind& tok_kind0) {
    if (prism_rtl::is<TokKind::KLayOpen>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KLaySep>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KLayClose>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// EndsOperand: fn TokKind -> Bool
bool ends_operand(const TokKind& tok_kind0) {
    if (prism_rtl::is<TokKind::KName>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KFamily>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KInt>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KFloat>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KDuration>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KChar>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KText>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KRegex>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KTemplate>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KClose>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KGtGt>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KNonEmpty>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KAbsent>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KKw>(tok_kind0)) {
        auto&& w = prism_rtl::as<TokKind::KKw>(tok_kind0).a0;
        return is_value_word(w);
    }
    {
        return false;
    }
}


/// IsValueWord: fn Text -> Bool
bool is_value_word(const Text& w) {
    return ((w == Text::lit("unit")) || (w == Text::lit("nil"))) || is_bound_word(w);
}


/// IsBoundWord: fn Text -> Bool
bool is_bound_word(const Text& w) {
    return (((w == Text::lit("key")) || (w == Text::lit("ix"))) || (w == Text::lit("jx"))) || (w == Text::lit("kx"));
}


/// let keywordList
Array<Text> keyword_list() {
    return Array(std::vector{Text::lit("module"), Text::lit("emit"), Text::lit("use"), Text::lit("type"), Text::lit("record"), Text::lit("choice"), Text::lit("row"), Text::lit("tag"), Text::lit("of"), Text::lit("derive"), Text::lit("trait"), Text::lit("impl"), Text::lit("where"), Text::lit("any"), Text::lit("let"), Text::lit("fn"), Text::lit("test"), Text::lit("check"), Text::lit("widget"), Text::lit("rebuild"), Text::lit("for"), Text::lit("given"), Text::lit("monad"), Text::lit("update"), Text::lit("while"), Text::lit("match"), Text::lit("if"), Text::lit("else"), Text::lit("otherwise"), Text::lit("require"), Text::lit("forbid"), Text::lit("return"), Text::lit("ignore"), Text::lit("then"), Text::lit("on"), Text::lit("not"), Text::lit("and"), Text::lit("or"), Text::lit("mod"), Text::lit("as"), Text::lit("output"), Text::lit("inline_text"), Text::lit("raw"), Text::lit("unbounded"), Text::lit("unit"), Text::lit("nil"), Text::lit("key"), Text::lit("ix"), Text::lit("jx"), Text::lit("kx")});
}


/// let keywordSet
Map<Text, bool> keyword_set() {
    return map(each(keyword_list(), [&](const Text& w) { return std::tuple{w, true}; }));
}


/// IsKeyword: fn Text -> Bool
bool is_keyword(const Text& w) {
    return crate::prelude::get(keyword_set(), w) != std::optional<bool>{};
}


/// let opTable
Array<Text> op_table() {
    return Array(std::vector{Text::lit("==>"), Text::lit("<-"), Text::lit("<="), Text::lit("<|"), Text::lit("->"), Text::lit("-="), Text::lit("-?"), Text::lit("+="), Text::lit("+?"), Text::lit("*="), Text::lit("*?"), Text::lit("/="), Text::lit("=="), Text::lit(">="), Text::lit("=>"), Text::lit("<"), Text::lit(">"), Text::lit("-"), Text::lit("+"), Text::lit("*"), Text::lit("/"), Text::lit("=")});
}


/// TakesSuffix: fn Text -> Bool
bool takes_suffix(const Text& op) {
    return fold(Array(std::vector{Text::lit("<="), Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit(">"), Text::lit(">="), Text::lit("+"), Text::lit("-"), Text::lit("*"), Text::lit("/"), Text::lit("+?"), Text::lit("-?"), Text::lit("*?")}), false, [&](const bool& seen, const Text& o) { return seen || (o == op); });
}


/// CloseChar: fn Text -> Text
Text close_char(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("(")) {
            return Text::lit(")");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("[")) {
            return Text::lit("]");
        }
    }
    {
        return Text::lit("}");
    }
}


/// OpenOf: fn Text -> Text
Text open_of(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit(")")) {
            return Text::lit("(");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("]")) {
            return Text::lit("[");
        }
    }
    {
        return Text::lit("{");
    }
}


/// PrefixPosition: fn Lex -> Bool
bool prefix_position(const Lex& l) {
    return l.last_ws || no_operand_before(crate::syntax::lexer::chars::last(l->tokens));
}


/// NoOperandBefore: fn ?Tok -> Bool
bool no_operand_before(const std::optional<Tok>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return true;
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& t = prism_rtl::some_of(opt0);
        return !ends_operand(t.kind);
    }
    prism_rtl::unreachable("no arm matched");
}


/// TestWordOf: fn TokKind -> Text
Text test_word_of(const TokKind& tok_kind0) {
    if (prism_rtl::is<TokKind::KKw>(tok_kind0)) {
        auto&& c0_0_0 = prism_rtl::as<TokKind::KKw>(tok_kind0).a0;
        if (c0_0_0 == Text::lit("test")) {
            return Text::lit("test");
        }
    }
    if (prism_rtl::is<TokKind::KKw>(tok_kind0)) {
        auto&& c1_0_0 = prism_rtl::as<TokKind::KKw>(tok_kind0).a0;
        if (c1_0_0 == Text::lit("check")) {
            return Text::lit("check");
        }
    }
    {
        return Text::lit("");
    }
}


/// AllLayout: fn [Tok] -> Bool
bool all_layout(const Array<Tok>& ts) {
    return fold(ts, true, [&](const bool& ok, const Tok& t) { return ok && is_layout(t.kind); });
}


/// PushTok: fn Lex, TokKind, Nat, Nat -> Lex
Lex push_tok(const Lex& l, const TokKind& kind, const Nat& start, const Nat& end) {
    Lex this_ = l;
    auto layout = is_layout_or_eof(kind);
    auto touches = ((!this_.last_ws) && (len(this_.tokens) > Nat(0u))) && (!layout);
    auto line_start = (!layout) && this_.mark_line_start;
    if (!layout) {
        this_.mark_line_start = false;
    }
    auto word = test_word_of(kind);
    if ((((word != Text::lit("")) && (this_.mode == Mode(Mode::MFile{}))) && (len(this_.layout) == Nat(1u))) && all_layout(drop(this_.tokens, this_.line_first))) {
        this_.test_pending = word;
    }
    this_.tokens = crate::prelude::push(this_.tokens, Tok{.kind = kind, .span = crate::syntax::Range{.start = start, .end = end}, .touches = touches, .line_start = line_start});
    this_.last_ws = false;
    return this_;
}


/// LayoutOn: fn Mode -> Bool
bool layout_on(const Mode& mode0) {
    if (prism_rtl::is<Mode::MFile>(mode0)) {
        return true;
    }
    if (prism_rtl::is<Mode::MBrace>(mode0)) {
        return true;
    }
    {
        return false;
    }
}


/// LayoutActive: fn Lex -> Bool
bool layout_active(const Lex& l) {
    return layout_on(l->mode) && (len(l.frames) == Nat(0u));
}


/// FatArrowOn: fn Lex -> Bool
bool fat_arrow_on(const Lex& l) {
    return (l.test_depth != std::optional<Nat>{}) || (l.check_depth != std::optional<Nat>{});
}

}  // namespace crate::syntax::lexer
