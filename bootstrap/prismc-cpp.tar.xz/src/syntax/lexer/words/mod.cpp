// The module `Syntax.Lexer.Words`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/words.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <syntax/lexer/words/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

namespace crate::syntax::lexer::words {

/// LexToken: unbounded fn Lex -> Lex
crate::syntax::lexer::Lex lex_token(const crate::syntax::lexer::Lex& l0) {
    auto start = l0.pos;
    auto c = crate::syntax::lexer::chars::peek(l0);
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.path_next = false;
        this_;
    });
    return l0.path_next && ((crate::syntax::lexer::chars::is_digit(c) || (c == Text::lit("#"))) || (c == Text::lit("[")))
        ? lex_path_token(l, start)
        : lex_token_at(l, start, c);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexToken::cycle() const {
    const auto& l0 = this->l0;
    auto start = l0.pos;
    auto c = crate::syntax::lexer::chars::peek(l0);
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.path_next = false;
        this_;
    });
    return l0.path_next && ((crate::syntax::lexer::chars::is_digit(c) || (c == Text::lit("#"))) || (c == Text::lit("[")))
        ? prism_rtl::more(prism_rtl::rc(LexPathToken(l, start)))
        : prism_rtl::more(prism_rtl::rc(LexTokenAt(l, start, c)));
}


/// `Start LexToken, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_token(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexToken>(l0);
}


/// LexPathToken: unbounded fn Lex, Nat -> Lex
crate::syntax::lexer::Lex lex_path_token(const crate::syntax::lexer::Lex& l, const Nat& start) {
    auto [segs, l2] = crate::syntax::lexer::literals::lex_path(l);
    return crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KPath{segs}), start, l2.pos);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexPathToken::cycle() const {
    const auto& l = this->l;
    const auto& start = this->start;
    auto l_1 = l;
    auto start_2 = start;
    return call_then(crate::syntax::lexer::literals::start_lex_path(l_1), [=](std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex> lex_path_963) {
        return ({
            auto [segs, l2] = lex_path_963;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KPath{segs}), start_2, l2.pos)));
        });
    });
}


/// `Start LexPathToken, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_path_token(crate::syntax::lexer::Lex l, Nat start) {
    return prism_rtl::make_rc<LexPathToken>(l, start);
}


/// LexTokenAt: unbounded fn Lex, Nat, Text -> Lex
crate::syntax::lexer::Lex lex_token_at(const crate::syntax::lexer::Lex& l, const Nat& start, const Text& c) {
    {
        auto&& m1093_0 = c;
        if (m1093_0 == Text::lit("\"")) {
            auto [text, l2] = crate::syntax::lexer::literals::lex_text(l);
            return crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KText{Text::lit(""), text}), start, l2.pos);
        }
    }
    {
        auto&& m1093_1 = c;
        if (m1093_1 == Text::lit("'")) {
            auto [ch, l2] = crate::syntax::lexer::literals::lex_char(l);
            return crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KChar{Text::lit(""), ch}), start, l2.pos);
        }
    }
    {
        if (crate::syntax::lexer::chars::is_digit(c)) {
            auto [kind, l2] = crate::syntax::lexer::literals::lex_number(l, Text::lit(""));
            return crate::syntax::lexer::push_tok(l2, kind, start, l2.pos);
        }
    }
    {
        if (crate::syntax::lexer::chars::is_ident_start(c)) {
            return lex_word_token(l, Text::lit(""), start);
        }
    }
    {
        if (crate::syntax::lexer::chars::contains(Text::lit("$@?~&^"), c)) {
            return lex_sigils(l);
        }
    }
    {
        auto&& m1093_5 = c;
        if (m1093_5 == Text::lit("!")) {
            return crate::syntax::lexer::chars::peek_at(l, Nat(1u)) == Text::lit("=")
                ? push_op_suffix(crate::syntax::lexer::chars::forward(l, Nat(2u)), Text::lit("!="), start)
                : lex_sigils(l);
        }
    }
    {
        if (crate::syntax::lexer::chars::contains(Text::lit("([{"), c)) {
            return lex_open(l, c, start);
        }
    }
    {
        if (crate::syntax::lexer::chars::contains(Text::lit(")]}"), c)) {
            return lex_close(l, c, start);
        }
    }
    {
        auto&& m1093_8 = c;
        if (m1093_8 == Text::lit(",")) {
            return crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KComma{}), start, start + Nat(1u));
        }
    }
    {
        auto&& m1093_9 = c;
        if (m1093_9 == Text::lit(":")) {
            return crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}), start, start + Nat(1u));
        }
    }
    {
        auto&& m1093_10 = c;
        if (m1093_10 == Text::lit(";")) {
            return crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSemi{}), start, start + Nat(1u));
        }
    }
    {
        auto&& m1093_11 = c;
        if (m1093_11 == Text::lit("\\")) {
            return lex_backslash(l, start);
        }
    }
    {
        auto&& m1093_12 = c;
        if (m1093_12 == Text::lit("%")) {
            return crate::syntax::lexer::regexes::lex_regex(l, Text::lit(""), start);
        }
    }
    {
        auto&& m1093_13 = c;
        if (m1093_13 == Text::lit("|")) {
            return lex_bar(l, start);
        }
    }
    {
        auto&& m1093_14 = c;
        if (m1093_14 == Text::lit(".")) {
            return lex_dot(l, start);
        }
    }
    {
        auto&& _m = lex_operator(l, start);
        if (prism_rtl::is_some(_m)) {
            auto&& l2 = prism_rtl::some_of(_m);
            return l2;
        }
        if (prism_rtl::is_none(_m)) {
            auto l1 = crate::syntax::lexer::chars::bump(l);
            auto l2 = crate::syntax::lexer::chars::lex_err(l1, start, l1.pos, prism_rtl::cat("unexpected character `", c, "`"));
            crate::syntax::lexer::Lex this_ = l2;
            this_.last_ws = true;
            return this_;
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexTokenAt::cycle() const {
    const auto& l = this->l;
    const auto& start = this->start;
    const auto& c = this->c;
    return ({
        ({
        auto&& m1093_0 = c;
        (m1093_0 == Text::lit("\""));
    }) ? ({
        auto&& m1093_0 = c;
        ({
        auto l_1 = l;
        auto start_2 = start;
        call_then(crate::syntax::lexer::literals::start_lex_text(l_1), [=](std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> lex_text_1139) {
        return ({
            auto [text, l2] = lex_text_1139;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KText{Text::lit(""), text}), start_2, l2.pos)));
        });
    });
    });
    })
        : ({
        auto&& m1093_1 = c;
        (m1093_1 == Text::lit("'"));
    }) ? ({
        auto&& m1093_1 = c;
        ({
        auto l_1 = l;
        auto start_2 = start;
        call_then(crate::syntax::lexer::literals::start_lex_char(l_1), [=](std::tuple<Text, crate::syntax::lexer::Lex> lex_char_1235) {
        return ({
            auto [ch, l2] = lex_char_1235;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KChar{Text::lit(""), ch}), start_2, l2.pos)));
        });
    });
    });
    })
        : ({
        crate::syntax::lexer::chars::is_digit(c);
    }) ? ({
        auto l_1 = l;
        auto start_2 = start;
        call_then(crate::syntax::lexer::literals::start_lex_number(l_1, Text::lit("")), [=](std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_number_1347) {
        return ({
            auto [kind, l2] = lex_number_1347;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2, kind, start_2, l2.pos)));
        });
    });
    })
        : ({
        crate::syntax::lexer::chars::is_ident_start(c);
    }) ? prism_rtl::more(prism_rtl::rc(LexWordToken(l, Text::lit(""), start)))
        : ({
        crate::syntax::lexer::chars::contains(Text::lit("$@?~&^"), c);
    }) ? prism_rtl::more(prism_rtl::rc(LexSigils(l)))
        : ({
        auto&& m1093_5 = c;
        (m1093_5 == Text::lit("!"));
    }) ? ({
        auto&& m1093_5 = c;
        crate::syntax::lexer::chars::peek_at(l, Nat(1u)) == Text::lit("=")
        ? prism_rtl::more(prism_rtl::rc(PushOpSuffix(crate::syntax::lexer::chars::forward(l, Nat(2u)), Text::lit("!="), start)))
        : prism_rtl::more(prism_rtl::rc(LexSigils(l)));
    })
        : ({
        crate::syntax::lexer::chars::contains(Text::lit("([{"), c);
    }) ? prism_rtl::finished(lex_open(l, c, start))
        : ({
        crate::syntax::lexer::chars::contains(Text::lit(")]}"), c);
    }) ? prism_rtl::finished(lex_close(l, c, start))
        : ({
        auto&& m1093_8 = c;
        (m1093_8 == Text::lit(","));
    }) ? ({
        auto&& m1093_8 = c;
        prism_rtl::finished(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KComma{}), start, start + Nat(1u)));
    })
        : ({
        auto&& m1093_9 = c;
        (m1093_9 == Text::lit(":"));
    }) ? ({
        auto&& m1093_9 = c;
        prism_rtl::finished(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}), start, start + Nat(1u)));
    })
        : ({
        auto&& m1093_10 = c;
        (m1093_10 == Text::lit(";"));
    }) ? ({
        auto&& m1093_10 = c;
        prism_rtl::finished(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSemi{}), start, start + Nat(1u)));
    })
        : ({
        auto&& m1093_11 = c;
        (m1093_11 == Text::lit("\\"));
    }) ? ({
        auto&& m1093_11 = c;
        prism_rtl::finished(lex_backslash(l, start));
    })
        : ({
        auto&& m1093_12 = c;
        (m1093_12 == Text::lit("%"));
    }) ? ({
        auto&& m1093_12 = c;
        prism_rtl::more(prism_rtl::rc(crate::syntax::lexer::regexes::LexRegex(l, Text::lit(""), start)));
    })
        : ({
        auto&& m1093_13 = c;
        (m1093_13 == Text::lit("|"));
    }) ? ({
        auto&& m1093_13 = c;
        prism_rtl::finished(lex_bar(l, start));
    })
        : ({
        auto&& m1093_14 = c;
        (m1093_14 == Text::lit("."));
    }) ? ({
        auto&& m1093_14 = c;
        prism_rtl::finished(lex_dot(l, start));
    })
        : ({
        auto c_1 = c;
        auto l_2 = l;
        auto start_3 = start;
        call_then(start_lex_operator(l_2, start_3), [=](std::optional<crate::syntax::lexer::Lex> lex_operator_1998) {
        return ({
            prism_rtl::is_some(lex_operator_1998) ? ({
            auto&& l2 = prism_rtl::some_of(lex_operator_1998);
            prism_rtl::finished(l2);
        })
            : prism_rtl::is_none(lex_operator_1998) ? ({
            auto l1 = crate::syntax::lexer::chars::bump(l_2);
            auto l2 = crate::syntax::lexer::chars::lex_err(l1, start_3, l1.pos, prism_rtl::cat("unexpected character `", c_1, "`"));
            (prism_rtl::finished(({
            crate::syntax::lexer::Lex this_ = l2;
            this_.last_ws = true;
            this_;
        })));
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    });
}


/// `Start LexTokenAt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_token_at(crate::syntax::lexer::Lex l, Nat start, Text c) {
    return prism_rtl::make_rc<LexTokenAt>(l, start, c);
}


/// LexOpen: fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex lex_open(const crate::syntax::lexer::Lex& l, const Text& c, const Nat& start) {
    auto prefix = ((c == Text::lit("[")) && crate::syntax::lexer::prefix_position(l)) && (!crate::syntax::lexer::chars::next_is_space(l, Nat(1u)));
    auto l2 = ({
        crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l);
        this_.frames = crate::prelude::push(this_.frames, c);
        this_;
    });
    return crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOpen{c, prefix}), start, l2.pos);
}


/// LexClose: fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex lex_close(const crate::syntax::lexer::Lex& l, const Text& c, const Nat& start) {
    auto kind = crate::syntax::lexer::open_of(c);
    auto l1 = crate::syntax::lexer::chars::bump(l);
    auto l2 = ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::lexer::Lex> _v;
        auto&& _m = crate::syntax::lexer::chars::last(l1.frames);
        if (prism_rtl::is_some(_m)) {
            auto&& k = prism_rtl::some_of(_m);
            if (k == kind) {
                _v.set(({
                    crate::syntax::lexer::Lex this_ = l1;
                    this_.frames = crate::syntax::lexer::chars::pop(this_.frames);
                    this_;
                }));
                goto _done;
            }
        }
        if (prism_rtl::is_some(_m)) {
            auto&& m2675_1 = prism_rtl::some_of(_m);
            if (m2675_1 == Text::lit("<<")) {
                _v.set(crate::syntax::lexer::chars::lex_err(l1, start, l1.pos, prism_rtl::cat("`", c, "` inside `<<`: expected `>>`")));
                goto _done;
            }
        }
        if (prism_rtl::is_some(_m)) {
            auto&& k = prism_rtl::some_of(_m);
            _v.set(({
                auto l3 = crate::syntax::lexer::chars::lex_err(l1, start, l1.pos, prism_rtl::cat("`", c, "` closes a `", k, "`"));
                ({
                crate::syntax::lexer::Lex this_ = l3;
                this_.frames = crate::syntax::lexer::chars::pop(this_.frames);
                this_;
            });
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::syntax::lexer::chars::lex_err(l1, start, l1.pos, prism_rtl::cat("`", c, "` closes nothing")));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KClose{kind}), start, l2.pos);
}


/// LexBackslash: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex lex_backslash(const crate::syntax::lexer::Lex& l, const Nat& start) {
    auto l1 = crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBackslash{}), start, start + Nat(1u));
    return crate::syntax::lexer::chars::peek(l1) == Text::lit("|")
        ? ({
        auto l2 = ({
            crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l1);
            this_.lambda_open = true;
            this_;
        });
        (crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{true}), l1.pos, l1.pos + Nat(1u)));
    })
        : l1;
}


/// LexBar: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex lex_bar(const crate::syntax::lexer::Lex& l, const Nat& start) {
    auto l1 = crate::syntax::lexer::chars::bump(l);
    return l1.lambda_open
        ? ({
        auto l2 = ({
            crate::syntax::lexer::Lex this_ = l1;
            this_.lambda_open = false;
            this_;
        });
        (crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{false}), start, l2.pos));
    })
        : crate::syntax::lexer::push_tok(l1, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{}), start, l1.pos);
}


/// LexDot: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex lex_dot(const crate::syntax::lexer::Lex& l, const Nat& start) {
    return crate::syntax::lexer::chars::starts_with(l, Text::lit(".."))
        ? crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::forward(l, Nat(2u)), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDotDot{}), start, start + Nat(2u))
        : ({
        auto prefix = crate::syntax::lexer::prefix_position(l) && (!crate::syntax::lexer::chars::next_is_space(l, Nat(1u)));
        auto l1 = prefix && crate::syntax::lexer::chars::is_digit(crate::syntax::lexer::chars::peek_at(l, Nat(1u)))
            ? crate::syntax::lexer::chars::lex_err(l, start, start + Nat(1u), Text::lit("a decimal literal has digits on both sides of its point: write `0.5`, not `.5`"))
            : l;
        (crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l1), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDot{prefix}), start, start + Nat(1u)));
    });
}


/// PushOpSuffix: unbounded fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex push_op_suffix(const crate::syntax::lexer::Lex& l, const Text& op, const Nat& start) {
    return crate::syntax::lexer::takes_suffix(op) && crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::peek(l))
        ? ({
        auto [path_, l2] = lex_qualified_path(l);
        (crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSuffixed{op, path_}), start, l2.pos));
    })
        : crate::syntax::lexer::push_tok(l, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOp{op, false}), start, l.pos);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> PushOpSuffix::cycle() const {
    const auto& l = this->l;
    const auto& op = this->op;
    const auto& start = this->start;
    return crate::syntax::lexer::takes_suffix(op) && crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::peek(l))
        ? ({
        auto l_1 = l;
        auto op_2 = op;
        auto start_3 = start;
        call_then(start_lex_qualified_path(l_1), [=](std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_4539) {
        return ({
            auto [path_, l2] = lex_qualified_path_4539;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSuffixed{op_2, path_}), start_3, l2.pos)));
        });
    });
    })
        : prism_rtl::finished(crate::syntax::lexer::push_tok(l, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOp{op, false}), start, l.pos));
}


/// `Start PushOpSuffix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_push_op_suffix(crate::syntax::lexer::Lex l, Text op, Nat start) {
    return prism_rtl::make_rc<PushOpSuffix>(l, op, start);
}


/// FirstOp: fn Lex -> Text
Text first_op(const crate::syntax::lexer::Lex& l) {
    return crate::syntax::lexer::chars::match_here(crate::syntax::lexer::fat_arrow_on(l)
        ? ([]() -> const Regex& { static const Regex r = Regex::lit("==>|<-|<=|<\\||->|-=|-\\?|\\+=|\\+\\?|\\*=|\\*\\?|\\/=|==|>=|=>|<|>|-|\\+|\\*|\\/|=", ""); return r; }())
        : ([]() -> const Regex& { static const Regex r = Regex::lit("==>|<-|<=|<\\||->|-=|-\\?|\\+=|\\+\\?|\\*=|\\*\\?|\\/=|==|>=|<|>|-|\\+|\\*|\\/|=", ""); return r; }()), l);
}


/// EndsMark: fn Text -> Bool
bool ends_mark(const Text& a) {
    return (a == Text::lit("")) || crate::syntax::lexer::chars::contains(Text::lit(" \n\r,)]}"), a);
}


/// ClosesSquareOrBrace: fn ?Tok -> Bool
bool closes_square_or_brace(const std::optional<crate::syntax::lexer::Tok>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& t = prism_rtl::some_of(opt0);
        return (t.kind == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KClose{Text::lit("[")})) || (t.kind == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KClose{Text::lit("{")}));
    }
    if (prism_rtl::is_none(opt0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?LexOperator: unbounded fn Lex, Nat -> ?Lex
std::optional<crate::syntax::lexer::Lex> lex_operator(const crate::syntax::lexer::Lex& l, const Nat& start) {
    auto c = crate::syntax::lexer::chars::peek(l);
    auto after_ = crate::syntax::lexer::chars::peek_at(l, Nat(1u));
    auto non_empty = (((c == Text::lit("+")) && (!l.last_ws)) && closes_square_or_brace(crate::syntax::lexer::chars::last(l->tokens))) && (ends_mark(after_) || ((after_ == Text::lit("?")) && ends_mark(crate::syntax::lexer::chars::peek_at(l, Nat(2u)))));
    return (c == Text::lit("-")) && crate::syntax::lexer::chars::contains(Text::lit(",)]}"), after_)
        ? std::optional(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KAbsent{}), start, start + Nat(1u)))
        : non_empty
        ? std::optional(non_empty_mark(l, start, after_))
        : crate::syntax::lexer::chars::starts_with(l, Text::lit("<<"))
        ? std::optional(open_type_args(l, start))
        : crate::syntax::lexer::chars::starts_with(l, Text::lit(">>")) && (crate::syntax::lexer::chars::last(l.frames) == std::optional(Text::lit("<<")))
        ? std::optional(close_type_args(l, start))
        : crate::syntax::lexer::chars::starts_with(l, Text::lit(">>"))
        ? std::optional(crate::syntax::lexer::chars::lex_err(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::forward(l, Nat(2u)), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KGtGt{}), start, start + Nat(2u)), start, start + Nat(2u), Text::lit("`>>` closes explicit type arguments, and none is open (Prism has no shift operators)")))
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::syntax::lexer::Lex>> _v;
        auto&& _m = first_op(l);
        {
            auto&& m6465_0 = _m;
            if (m6465_0 == Text::lit("")) {
                _v.set(std::optional<crate::syntax::lexer::Lex>{});
                goto _done;
            }
        }
        {
            auto&& op = _m;
            _v.set(std::optional(push_operator(l, op, start)));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::optional<crate::syntax::lexer::Lex>> LexOperator::cycle() const {
    const auto& l = this->l;
    const auto& start = this->start;
    auto c = crate::syntax::lexer::chars::peek(l);
    auto after_ = crate::syntax::lexer::chars::peek_at(l, Nat(1u));
    auto non_empty = (((c == Text::lit("+")) && (!l.last_ws)) && closes_square_or_brace(crate::syntax::lexer::chars::last(l->tokens))) && (ends_mark(after_) || ((after_ == Text::lit("?")) && ends_mark(crate::syntax::lexer::chars::peek_at(l, Nat(2u)))));
    return (c == Text::lit("-")) && crate::syntax::lexer::chars::contains(Text::lit(",)]}"), after_)
        ? prism_rtl::finished(std::optional(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KAbsent{}), start, start + Nat(1u))))
        : non_empty
        ? prism_rtl::finished(std::optional(non_empty_mark(l, start, after_)))
        : crate::syntax::lexer::chars::starts_with(l, Text::lit("<<"))
        ? prism_rtl::finished(std::optional(open_type_args(l, start)))
        : crate::syntax::lexer::chars::starts_with(l, Text::lit(">>")) && (crate::syntax::lexer::chars::last(l.frames) == std::optional(Text::lit("<<")))
        ? prism_rtl::finished(std::optional(close_type_args(l, start)))
        : crate::syntax::lexer::chars::starts_with(l, Text::lit(">>"))
        ? prism_rtl::finished(std::optional(crate::syntax::lexer::chars::lex_err(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::forward(l, Nat(2u)), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KGtGt{}), start, start + Nat(2u)), start, start + Nat(2u), Text::lit("`>>` closes explicit type arguments, and none is open (Prism has no shift operators)"))))
        : ({
        auto&& _m = first_op(l);
        ({
        auto&& m6465_0 = _m;
        (m6465_0 == Text::lit(""));
    }) ? ({
        auto&& m6465_0 = _m;
        prism_rtl::finished(std::optional<crate::syntax::lexer::Lex>{});
    })
        : ({
        auto&& op = _m;
        prism_rtl::finished(std::optional(push_operator(l, op, start)));
    });
    });
}


/// `Start LexOperator, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::syntax::lexer::Lex>> start_lex_operator(crate::syntax::lexer::Lex l, Nat start) {
    return prism_rtl::make_rc<LexOperator>(l, start);
}


/// NonEmptyMark: fn Lex, Nat, Text -> Lex
crate::syntax::lexer::Lex non_empty_mark(const crate::syntax::lexer::Lex& l, const Nat& start, const Text& after_) {
    auto l1 = crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KNonEmpty{}), start, start + Nat(1u));
    return after_ == Text::lit("?")
        ? crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l1), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFree{Text::lit("?")}), l1.pos, l1.pos + Nat(1u))
        : l1;
}


/// OpenTypeArgs: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex open_type_args(const crate::syntax::lexer::Lex& l, const Nat& start) {
    auto touching = (!l.last_ws) && is_name_tok(crate::syntax::lexer::chars::last(l->tokens));
    auto l1 = crate::syntax::lexer::chars::forward(l, Nat(2u));
    auto l2 = touching
        ? l1
        : crate::syntax::lexer::chars::lex_err(l1, start, l1.pos, Text::lit("`<<` opens explicit type arguments and must touch a name on its left (Prism has no shift operators)"));
    auto l3 = ({
        crate::syntax::lexer::Lex this_ = l2;
        this_.frames = crate::prelude::push(this_.frames, Text::lit("<<"));
        this_;
    });
    return crate::syntax::lexer::push_tok(l3, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLtLt{}), start, l3.pos);
}


/// IsNameTok: fn ?Tok -> Bool
bool is_name_tok(const std::optional<crate::syntax::lexer::Tok>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& t = prism_rtl::some_of(opt0);
        auto&& _m = t.kind;
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(opt0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CloseTypeArgs: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex close_type_args(const crate::syntax::lexer::Lex& l, const Nat& start) {
    auto l1 = ({
        crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::forward(l, Nat(2u));
        this_.frames = crate::syntax::lexer::chars::pop(this_.frames);
        this_;
    });
    return crate::syntax::lexer::push_tok(l1, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KGtGt{}), start, l1.pos);
}


/// PushOperator: unbounded fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex push_operator(const crate::syntax::lexer::Lex& l, const Text& op, const Nat& start) {
    auto l1 = crate::syntax::lexer::chars::forward(l, len_text(op));
    return (((op == Text::lit("+")) || (op == Text::lit("-"))) || (op == Text::lit("-?"))) && (!crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::peek(l1)))
        ? crate::syntax::lexer::push_tok(l1, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOp{op, crate::syntax::lexer::prefix_position(l1) && (!crate::syntax::lexer::chars::next_is_space(l1, Nat(0u)))}), start, l1.pos)
        : push_op_suffix(l1, op, start);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> PushOperator::cycle() const {
    const auto& l = this->l;
    const auto& op = this->op;
    const auto& start = this->start;
    auto l1 = crate::syntax::lexer::chars::forward(l, len_text(op));
    return (((op == Text::lit("+")) || (op == Text::lit("-"))) || (op == Text::lit("-?"))) && (!crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::peek(l1)))
        ? prism_rtl::finished(crate::syntax::lexer::push_tok(l1, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOp{op, crate::syntax::lexer::prefix_position(l1) && (!crate::syntax::lexer::chars::next_is_space(l1, Nat(0u)))}), start, l1.pos))
        : prism_rtl::more(prism_rtl::rc(PushOpSuffix(l1, op, start)));
}


/// `Start PushOperator, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_push_operator(crate::syntax::lexer::Lex l, Text op, Nat start) {
    return prism_rtl::make_rc<PushOperator>(l, op, start);
}


/// LexSigils: unbounded fn Lex -> Lex
crate::syntax::lexer::Lex lex_sigils(const crate::syntax::lexer::Lex& l0) {
    auto start = l0.pos;
    auto [sigils, caret, l] = read_sigils(l0);
    auto next = crate::syntax::lexer::chars::peek(l);
    return caret
        ? lex_caret(l, start, sigils, next)
        : ((crate::syntax::lexer::chars::is_ident_start(next) || crate::syntax::lexer::chars::is_digit(next)) || (next == Text::lit("\""))) || (next == Text::lit("%"))
        ? lex_attached(l, start, sigils, next)
        : ((sigils == Text::lit("&")) && (next == Text::lit("."))) && crate::syntax::lexer::chars::is_lower(crate::syntax::lexer::chars::peek_at(l, Nat(1u)))
        ? crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLensDot{}), start, l.pos + Nat(1u))
        : free_sigils(l, start, sigils);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexSigils::cycle() const {
    const auto& l0 = this->l0;
    auto start = l0.pos;
    auto l0_1 = l0;
    return call_then(start_read_sigils(l0_1), [=](std::tuple<Text, bool, crate::syntax::lexer::Lex> read_sigils_8705) {
        return ({
            auto [sigils, caret, l] = read_sigils_8705;
            auto next = crate::syntax::lexer::chars::peek(l);
            caret
            ? prism_rtl::more(prism_rtl::rc(LexCaret(l, start, sigils, next)))
            : ((crate::syntax::lexer::chars::is_ident_start(next) || crate::syntax::lexer::chars::is_digit(next)) || (next == Text::lit("\""))) || (next == Text::lit("%"))
            ? prism_rtl::more(prism_rtl::rc(LexAttached(l, start, sigils, next)))
            : ((sigils == Text::lit("&")) && (next == Text::lit("."))) && crate::syntax::lexer::chars::is_lower(crate::syntax::lexer::chars::peek_at(l, Nat(1u)))
            ? prism_rtl::finished(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLensDot{}), start, l.pos + Nat(1u)))
            : prism_rtl::finished(free_sigils(l, start, sigils));
        });
    });
}


/// `Start LexSigils, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_sigils(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexSigils>(l0);
}


/// ReadSigils: unbounded fn Lex -> ((Text, Bool, Lex))
std::tuple<Text, bool, crate::syntax::lexer::Lex> read_sigils(const crate::syntax::lexer::Lex& l0) {
    std::tuple<Text, bool, crate::syntax::lexer::Lex> this_ = std::tuple{Text::lit(""), false, l0};
    crate::syntax::lexer::Lex l = l0;
    Text sigils = Text::lit("");
    bool caret = false;
    bool going = true;
    while (going) {
        auto c = crate::syntax::lexer::chars::peek(l);
        if (c == Text::lit("^")) {
            l = crate::syntax::lexer::chars::bump(l);
            caret = true;
            going = false;
        } else if (crate::syntax::lexer::chars::is_sigil_char(c) && (!((c == Text::lit("!")) && (crate::syntax::lexer::chars::peek_at(l, Nat(1u)) == Text::lit("="))))) {
            l = crate::syntax::lexer::chars::bump(l);
            sigils = prism_rtl::cat(sigils, c);
        } else  {
            going = false;
        }
    }
    this_ = std::tuple{sigils, caret, l};
    return this_;
}


prism_rtl::Turn<std::tuple<Text, bool, crate::syntax::lexer::Lex>> ReadSigils::cycle() const {
    const auto& l0 = this->l0;
    std::tuple<Text, bool, crate::syntax::lexer::Lex> this_ = std::tuple{Text::lit(""), false, l0};
    crate::syntax::lexer::Lex l = l0;
    Text sigils = Text::lit("");
    bool caret = false;
    bool going = true;
    return call_then(loop_job(std::tuple{this_, caret, going, l, sigils}, [=](std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text> _p0) {
        auto this_ = std::get<0>(_p0);
        auto caret = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto l = std::get<3>(_p0);
        auto sigils = std::get<4>(_p0);
        return going
            ? ({
            auto c = crate::syntax::lexer::chars::peek(l);
            if (c == Text::lit("^")) {
                l = crate::syntax::lexer::chars::bump(l);
                caret = true;
                going = false;
            } else if (crate::syntax::lexer::chars::is_sigil_char(c) && (!((c == Text::lit("!")) && (crate::syntax::lexer::chars::peek_at(l, Nat(1u)) == Text::lit("="))))) {
                l = crate::syntax::lexer::chars::bump(l);
                sigils = prism_rtl::cat(sigils, c);
            } else  {
                going = false;
            }
            Expected<std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text>, std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text>>(std::tuple{this_, caret, going, l, sigils});
        })
            : Expected<std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text>, std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text>>(unexpected(std::tuple{this_, caret, going, l, sigils}));
    }), [=](std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text> _p0) {
        auto this_ = std::get<0>(_p0);
        auto caret = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto l = std::get<3>(_p0);
        auto sigils = std::get<4>(_p0);
        return ({
            this_ = std::tuple{sigils, caret, l};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start ReadSigils, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, bool, crate::syntax::lexer::Lex>> start_read_sigils(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<ReadSigils>(l0);
}


/// LexCaret: unbounded fn Lex, Nat, Text, Text -> Lex
crate::syntax::lexer::Lex lex_caret(const crate::syntax::lexer::Lex& l, const Nat& start, const Text& sigils, const Text& next) {
    return crate::syntax::lexer::chars::is_upper(next) && (sigils == Text::lit(""))
        ? ({
        auto [path_, l2] = lex_qualified_path(l);
        (crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KTrait{path_}), start, l2.pos));
    })
        : ({
        auto&& _skipped = lex_qualified_path(l);
        auto&& skipped = std::get<1>(_skipped);
        auto l2 = crate::syntax::lexer::chars::is_ident_start(next) ? skipped : l;
        (crate::syntax::lexer::chars::lex_err(l2, start, crate::prelude::max(l2.pos, l.pos), Text::lit("`^` marks a trait and attaches to its uppercase name: no trait is a value")));
    });
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexCaret::cycle() const {
    const auto& l = this->l;
    const auto& start = this->start;
    const auto& sigils = this->sigils;
    const auto& next = this->next;
    return crate::syntax::lexer::chars::is_upper(next) && (sigils == Text::lit(""))
        ? ({
        auto l_1 = l;
        auto start_2 = start;
        call_then(start_lex_qualified_path(l_1), [=](std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_9909) {
        return ({
            auto [path_, l2] = lex_qualified_path_9909;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KTrait{path_}), start_2, l2.pos)));
        });
    });
    })
        : ({
        auto l_1 = l;
        auto next_2 = next;
        auto start_3 = start;
        call_then(start_lex_qualified_path(l_1), [=](std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_10021) {
        return ({
            auto&& _skipped = lex_qualified_path_10021;
            auto&& skipped = std::get<1>(_skipped);
            auto l2 = crate::syntax::lexer::chars::is_ident_start(next_2) ? skipped : l_1;
            (prism_rtl::finished(crate::syntax::lexer::chars::lex_err(l2, start_3, crate::prelude::max(l2.pos, l_1.pos), Text::lit("`^` marks a trait and attaches to its uppercase name: no trait is a value"))));
        });
    });
    });
}


/// `Start LexCaret, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_caret(crate::syntax::lexer::Lex l, Nat start, Text sigils, Text next) {
    return prism_rtl::make_rc<LexCaret>(l, start, sigils, next);
}


/// LexAttached: unbounded fn Lex, Nat, Text, Text -> Lex
crate::syntax::lexer::Lex lex_attached(const crate::syntax::lexer::Lex& l, const Nat& start, const Text& sigils, const Text& next) {
    return next == Text::lit("\"")
        ? ({
        auto [text, l2] = crate::syntax::lexer::literals::lex_text(l);
        (crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KText{sigils, text}), start, l2.pos));
    })
        : crate::syntax::lexer::chars::is_digit(next)
        ? ({
        auto [kind, l2] = crate::syntax::lexer::literals::lex_number(l, sigils);
        (crate::syntax::lexer::push_tok(l2, kind, start, l2.pos));
    })
        : next == Text::lit("%")
        ? crate::syntax::lexer::regexes::lex_regex(l, sigils, start)
        : lex_word_token(l, sigils, start);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexAttached::cycle() const {
    const auto& l = this->l;
    const auto& start = this->start;
    const auto& sigils = this->sigils;
    const auto& next = this->next;
    return next == Text::lit("\"")
        ? ({
        auto l_1 = l;
        auto sigils_2 = sigils;
        auto start_3 = start;
        call_then(crate::syntax::lexer::literals::start_lex_text(l_1), [=](std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> lex_text_10360) {
        return ({
            auto [text, l2] = lex_text_10360;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KText{sigils_2, text}), start_3, l2.pos)));
        });
    });
    })
        : crate::syntax::lexer::chars::is_digit(next)
        ? ({
        auto l_1 = l;
        auto sigils_2 = sigils;
        auto start_3 = start;
        call_then(crate::syntax::lexer::literals::start_lex_number(l_1, sigils_2), [=](std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_number_10480) {
        return ({
            auto [kind, l2] = lex_number_10480;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2, kind, start_3, l2.pos)));
        });
    });
    })
        : next == Text::lit("%")
        ? prism_rtl::more(prism_rtl::rc(crate::syntax::lexer::regexes::LexRegex(l, sigils, start)))
        : prism_rtl::more(prism_rtl::rc(LexWordToken(l, sigils, start)));
}


/// `Start LexAttached, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_attached(crate::syntax::lexer::Lex l, Nat start, Text sigils, Text next) {
    return prism_rtl::make_rc<LexAttached>(l, start, sigils, next);
}


/// FreeSigils: fn Lex, Nat, Text -> Lex
crate::syntax::lexer::Lex free_sigils(const crate::syntax::lexer::Lex& l0, const Nat& start, const Text& sigils) {
    crate::syntax::lexer::Lex this_ = l0;
    auto space_after = crate::syntax::lexer::chars::next_is_space(this_, Nat(0u));
    auto all = crate::syntax::lexer::chars::fold_chars(sigils, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                (prism_rtl::finished(crate::prelude::push(acc, c)));
            });
        });
    })));
    for (auto&& [i10960, v10960] : prism_rtl::enumerate(all)) {
        auto k10960 = nat_of(i10960);
        auto s = v10960;
        auto at_ = start + k10960;
        if (space_after && ((k10960 + Nat(1u)) == len(all))) {
            if (s == Text::lit("!")) {
                this_ = crate::syntax::lexer::chars::lex_err(this_, at_, at_ + Nat(1u), Text::lit("`!` is never free: no event fires a constant (write `!e` touching its name)"));
            }
            if (s == Text::lit("&")) {
                this_ = crate::syntax::lexer::chars::lex_err(this_, at_, at_ + Nat(1u), Text::lit("`&` is never free: no reference exists outside the value an `update` block names"));
            }
        }
        this_ = crate::syntax::lexer::push_tok(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFree{s}), at_, at_ + Nat(1u));
    }
    return this_;
}


/// LexQualifiedPath: unbounded fn Lex -> (([Text], Lex))
std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path(const crate::syntax::lexer::Lex& l0) {
    std::tuple<Array<Text>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<Text>{}, l0};
    auto [first_, l1] = lex_ident(l0);
    Array<Text> path_ = Array(std::vector{first_});
    crate::syntax::lexer::Lex l = l1;
    bool going = true;
    while (going) {
        auto last_1 = or_(crate::syntax::lexer::chars::last(path_), Text::lit(""));
        auto next = crate::syntax::lexer::chars::peek_at(l, Nat(1u));
        if ((crate::syntax::lexer::chars::peek(l) != Text::lit(".")) || (!crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::head(last_1)))) {
            going = false;
        } else if (crate::syntax::lexer::chars::is_upper(next)) {
            auto [seg, l2] = lex_ident(crate::syntax::lexer::chars::bump(l));
            path_ = crate::prelude::push(path_, seg);
            l = l2;
        } else  {
            going = false;
            if (crate::syntax::lexer::chars::is_ident_start(next)) {
                auto [w, l2] = lex_ident(crate::syntax::lexer::chars::bump(l));
                if (crate::syntax::lexer::chars::is_reserved_ctor(w)) {
                    path_ = crate::prelude::push(path_, w);
                    l = l2;
                }
            }
        }
    }
    this_ = std::tuple{path_, l};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<Text>, crate::syntax::lexer::Lex>> LexQualifiedPath::cycle() const {
    const auto& l0 = this->l0;
    std::tuple<Array<Text>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<Text>{}, l0};
    auto [first_, l1] = lex_ident(l0);
    Array<Text> path_ = Array(std::vector{first_});
    crate::syntax::lexer::Lex l = l1;
    bool going = true;
    return call_then(loop_job(std::tuple{this_, going, l, path_}, [=](std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto l = std::get<2>(_p0);
        auto path_ = std::get<3>(_p0);
        return going
            ? ({
            auto last_1 = or_(crate::syntax::lexer::chars::last(path_), Text::lit(""));
            auto next = crate::syntax::lexer::chars::peek_at(l, Nat(1u));
            if ((crate::syntax::lexer::chars::peek(l) != Text::lit(".")) || (!crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::head(last_1)))) {
                going = false;
            } else if (crate::syntax::lexer::chars::is_upper(next)) {
                auto [seg, l2] = lex_ident(crate::syntax::lexer::chars::bump(l));
                path_ = crate::prelude::push(path_, seg);
                l = l2;
            } else  {
                going = false;
                if (crate::syntax::lexer::chars::is_ident_start(next)) {
                    auto [w, l2] = lex_ident(crate::syntax::lexer::chars::bump(l));
                    if (crate::syntax::lexer::chars::is_reserved_ctor(w)) {
                        path_ = crate::prelude::push(path_, w);
                        l = l2;
                    }
                }
            }
            Expected<std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>>, std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>>>(std::tuple{this_, going, l, path_});
        })
            : Expected<std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>>, std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>>>(unexpected(std::tuple{this_, going, l, path_}));
    }), [=](std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto l = std::get<2>(_p0);
        auto path_ = std::get<3>(_p0);
        return ({
            this_ = std::tuple{path_, l};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start LexQualifiedPath, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, crate::syntax::lexer::Lex>> start_lex_qualified_path(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexQualifiedPath>(l0);
}


/// LexIdent: unbounded fn Lex -> ((Text, Lex))
std::tuple<Text, crate::syntax::lexer::Lex> lex_ident(const crate::syntax::lexer::Lex& l0) {
    auto word = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_]*", ""); return r; }()), l0);
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = this_.pos + len_text(word);
        this_;
    });
    return std::tuple{word, l};
}


prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> LexIdent::cycle() const {
    const auto& l0 = this->l0;
    auto word = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_]*", ""); return r; }()), l0);
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = this_.pos + len_text(word);
        this_;
    });
    return prism_rtl::finished(std::tuple{word, l});
}


/// `Start LexIdent, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_lex_ident(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexIdent>(l0);
}


/// LexWordToken: unbounded fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex lex_word_token(const crate::syntax::lexer::Lex& l0, const Text& sigils, const Nat& start) {
    auto w_start = l0.pos;
    auto [path_, l1] = lex_qualified_path(l0);
    auto l = crate::syntax::lexer::chars::is_non_ascii(crate::syntax::lexer::chars::peek(l1))
        ? skip_non_ascii(l1, w_start)
        : l1;
    auto first_ = or_(index(path_, Nat(0u)), Text::lit(""));
    return crate::syntax::lexer::chars::starts_with(l, Text::lit(".*")) && crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::head(first_))
        ? ({
        auto l2 = crate::syntax::lexer::chars::forward(l, Nat(2u));
        auto l3 = sigils != Text::lit("")
            ? crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, Text::lit("a family pattern takes no sigil"))
            : l2;
        (crate::syntax::lexer::push_tok(l3, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFamily{path_}), start, l3.pos));
    })
        : ((len(path_) == Nat(1u)) && crate::syntax::lexer::is_keyword(first_)) && (!(crate::syntax::lexer::is_bound_word(first_) && (sigils != Text::lit(""))))
        ? lex_keyword(l, first_, sigils, start)
        : lex_name(l, path_, sigils, start, w_start);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexWordToken::cycle() const {
    const auto& l0 = this->l0;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    auto w_start = l0.pos;
    auto l0_1 = l0;
    auto sigils_2 = sigils;
    auto start_3 = start;
    return call_then(start_lex_qualified_path(l0_1), [=](std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_12808) {
        return ({
            auto [path_, l1] = lex_qualified_path_12808;
            auto l = crate::syntax::lexer::chars::is_non_ascii(crate::syntax::lexer::chars::peek(l1))
                ? skip_non_ascii(l1, w_start)
                : l1;
            auto first_ = or_(index(path_, Nat(0u)), Text::lit(""));
            (crate::syntax::lexer::chars::starts_with(l, Text::lit(".*")) && crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::head(first_))
            ? ({
            auto l2 = crate::syntax::lexer::chars::forward(l, Nat(2u));
            auto l3 = sigils_2 != Text::lit("")
                ? crate::syntax::lexer::chars::lex_err(l2, start_3, l2.pos, Text::lit("a family pattern takes no sigil"))
                : l2;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l3, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFamily{path_}), start_3, l3.pos)));
        })
            : ((len(path_) == Nat(1u)) && crate::syntax::lexer::is_keyword(first_)) && (!(crate::syntax::lexer::is_bound_word(first_) && (sigils_2 != Text::lit(""))))
            ? prism_rtl::more(prism_rtl::rc(LexKeyword(l, first_, sigils_2, start_3)))
            : prism_rtl::more(prism_rtl::rc(LexName(l, path_, sigils_2, start_3, w_start))));
        });
    });
}


/// `Start LexWordToken, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_word_token(crate::syntax::lexer::Lex l0, Text sigils, Nat start) {
    return prism_rtl::make_rc<LexWordToken>(l0, sigils, start);
}


/// SkipNonAscii: unbounded fn Lex, Nat -> Lex
crate::syntax::lexer::Lex skip_non_ascii(const crate::syntax::lexer::Lex& l0, const Nat& w_start) {
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_\\x{80}-\\x{10FFFF}]*", ""); return r; }()), this_.src, this_.pos);
        this_;
    });
    return crate::syntax::lexer::chars::lex_err(l, w_start, l.pos, Text::lit("names are ASCII letters, digits and underscores"));
}


prism_rtl::Turn<crate::syntax::lexer::Lex> SkipNonAscii::cycle() const {
    const auto& l0 = this->l0;
    const auto& w_start = this->w_start;
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_\\x{80}-\\x{10FFFF}]*", ""); return r; }()), this_.src, this_.pos);
        this_;
    });
    return prism_rtl::finished(crate::syntax::lexer::chars::lex_err(l, w_start, l.pos, Text::lit("names are ASCII letters, digits and underscores")));
}


/// `Start SkipNonAscii, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_skip_non_ascii(crate::syntax::lexer::Lex l0, Nat w_start) {
    return prism_rtl::make_rc<SkipNonAscii>(l0, w_start);
}


/// LexKeyword: unbounded fn Lex, Text, Text, Nat -> Lex
crate::syntax::lexer::Lex lex_keyword(const crate::syntax::lexer::Lex& l, const Text& w, const Text& sigils, const Nat& start) {
    auto l1 = (sigils != Text::lit("")) && (!(((w == Text::lit("widget")) || (w == Text::lit("unit"))) || (w == Text::lit("nil"))))
        ? crate::syntax::lexer::chars::lex_err(l, start, l.pos, prism_rtl::cat("`", w, "` is a keyword and takes no sigil"))
        : l;
    auto l2 = (w == Text::lit("widget")) && (sigils != Text::lit("@"))
        ? crate::syntax::lexer::chars::lex_err(l1, start, l1.pos, Text::lit("`widget` is a block only as `@widget:`"))
        : l1;
    auto l3 = crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KKw{w, sigils}), start, l2.pos);
    return ((w == Text::lit("output")) || (w == Text::lit("inline_text"))) || (w == Text::lit("raw"))
        ? crate::syntax::lexer::templates::maybe_template(l3, w)
        : l3;
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexKeyword::cycle() const {
    const auto& l = this->l;
    const auto& w = this->w;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    auto l1 = (sigils != Text::lit("")) && (!(((w == Text::lit("widget")) || (w == Text::lit("unit"))) || (w == Text::lit("nil"))))
        ? crate::syntax::lexer::chars::lex_err(l, start, l.pos, prism_rtl::cat("`", w, "` is a keyword and takes no sigil"))
        : l;
    auto l2 = (w == Text::lit("widget")) && (sigils != Text::lit("@"))
        ? crate::syntax::lexer::chars::lex_err(l1, start, l1.pos, Text::lit("`widget` is a block only as `@widget:`"))
        : l1;
    auto l3 = crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KKw{w, sigils}), start, l2.pos);
    return ((w == Text::lit("output")) || (w == Text::lit("inline_text"))) || (w == Text::lit("raw"))
        ? prism_rtl::more(prism_rtl::rc(crate::syntax::lexer::templates::MaybeTemplate(l3, w)))
        : prism_rtl::finished(l3);
}


/// `Start LexKeyword, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_keyword(crate::syntax::lexer::Lex l, Text w, Text sigils, Nat start) {
    return prism_rtl::make_rc<LexKeyword>(l, w, sigils, start);
}


/// LexName: unbounded fn Lex, [Text], Text, Nat, Nat -> Lex
crate::syntax::lexer::Lex lex_name(const crate::syntax::lexer::Lex& l, const Array<Text>& path_, const Text& sigils, const Nat& start, const Nat& w_start) {
    auto [case_, l1] = name_case_of(l, path_, w_start);
    auto l2 = is_path_word(l1, sigils, path_)
        ? ({
        crate::syntax::lexer::Lex this_ = l1;
        this_.path_next = true;
        this_;
    })
        : l1;
    return crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KName{crate::syntax::lexer::NameTok{.sigils = sigils, .path_ = path_, .case_ = case_}}), start, l2.pos);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexName::cycle() const {
    const auto& l = this->l;
    const auto& path_ = this->path_;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    const auto& w_start = this->w_start;
    auto [case_, l1] = name_case_of(l, path_, w_start);
    auto l2 = is_path_word(l1, sigils, path_)
        ? ({
        crate::syntax::lexer::Lex this_ = l1;
        this_.path_next = true;
        this_;
    })
        : l1;
    return prism_rtl::finished(crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KName{crate::syntax::lexer::NameTok{.sigils = sigils, .path_ = path_, .case_ = case_}}), start, l2.pos));
}


/// `Start LexName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_name(crate::syntax::lexer::Lex l, Array<Text> path_, Text sigils, Nat start, Nat w_start) {
    return prism_rtl::make_rc<LexName>(l, path_, sigils, start, w_start);
}


/// NameCaseOf: fn Lex, [Text], Nat -> ((NameCase, Lex))
std::tuple<crate::syntax::lexer::NameCase, crate::syntax::lexer::Lex> name_case_of(const crate::syntax::lexer::Lex& l, const Array<Text>& path_, const Nat& w_start) {
    auto last_1 = or_(crate::syntax::lexer::chars::last(path_), Text::lit(""));
    return last_1 == Text::lit("_")
        ? std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseTopic{}), l}
        : (crate::syntax::lexer::chars::head(last_1) == Text::lit("_")) && crate::syntax::lexer::chars::all_chars(crate::syntax::lexer::chars::after_first(last_1), ({
        auto f = prism_rtl::rc(crate::syntax::lexer::chars::is_digit);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text a0) {
        return ({
            auto f_2 = f;
            once_job([=]() { return prism_rtl::finished(f_2(a0)); });
        });
    })));
    }))
        ? std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseHole{}), l}
        : crate::syntax::lexer::chars::head(last_1) == Text::lit("_")
        ? std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}), crate::syntax::lexer::chars::lex_err(l, w_start, l.pos, Text::lit("`_` followed by a letter is not a name: `_` alone is the topic, `_1` a hole"))}
        : crate::syntax::lexer::chars::is_reserved_ctor(last_1)
        ? std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseReserved{}), l}
        : crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::head(last_1))
        ? ({
        auto underscored = fold(path_, false, [&](const bool& seen, const Text& seg) { return seen || crate::syntax::lexer::chars::contains(seg, Text::lit("_")); });
        underscored
        ? std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{}), crate::syntax::lexer::chars::lex_err(l, w_start, l.pos, prism_rtl::cat("`", crate::syntax::lexer::chars::join(path_, Text::lit(".")), "`: a capital promises UpperCamelCase"))}
        : std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{}), l};
    })
        : std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}), l};
}


/// IsPathWord: fn Lex, Text, [Text] -> Bool
bool is_path_word(const crate::syntax::lexer::Lex& l, const Text& sigils, const Array<Text>& path_) {
    auto w = or_(index(path_, Nat(0u)), Text::lit(""));
    auto words = w == Text::lit("at")
        ? Array(std::vector{Text::lit("send"), Text::lit("click"), Text::lit("answer")})
        : Array(std::vector{Text::lit("click")});
    auto prev = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::syntax::lexer::chars::last(l->tokens);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = t.kind;
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
                    auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
                    if ((n.sigils == Text::lit("")) && (len(n->path_) == Nat(1u))) {
                        _v.set(or_(index(n->path_, Nat(0u)), Text::lit("")));
                        goto _done;
                    }
                }
                {
                    _v.set(Text::lit(""));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ((((l.test_depth != std::optional<Nat>{}) && (sigils == Text::lit(""))) && (len(path_) == Nat(1u))) && ((w == Text::lit("at")) || (w == Text::lit("element")))) && fold(words, false, [&](const bool& seen, const Text& x) { return seen || (x == prev); });
}

}  // namespace crate::syntax::lexer::words
