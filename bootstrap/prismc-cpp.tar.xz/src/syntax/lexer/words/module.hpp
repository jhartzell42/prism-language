// The module `Syntax.Lexer.Words`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/lexer/words/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::lexer::words {

crate::syntax::lexer::Lex lex_token_f(const crate::syntax::lexer::Lex& l0_p0);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_token_f(crate::syntax::lexer::Lex l0_p0);

crate::syntax::lexer::Lex lex_path_token_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_path_token_f(crate::syntax::lexer::Lex l_p0, Nat start_p1);

crate::syntax::lexer::Lex lex_token_at_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1, const Text& c_p2);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_token_at_f(crate::syntax::lexer::Lex l_p0, Nat start_p1, Text c_p2);

crate::syntax::lexer::Lex lex_open_f(const crate::syntax::lexer::Lex& l_p0, const Text& c_p1, const Nat& start_p2);

crate::syntax::lexer::Lex lex_close_f(const crate::syntax::lexer::Lex& l_p0, const Text& c_p1, const Nat& start_p2);

crate::syntax::lexer::Lex lex_backslash_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1);

crate::syntax::lexer::Lex lex_bar_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1);

crate::syntax::lexer::Lex lex_dot_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1);

crate::syntax::lexer::Lex push_op_suffix_f(const crate::syntax::lexer::Lex& l_p0, const Text& op_p1, const Nat& start_p2);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_push_op_suffix_f(crate::syntax::lexer::Lex l_p0, Text op_p1, Nat start_p2);

Text first_op_f(const crate::syntax::lexer::Lex& l_p0);

bool ends_mark_f(const Text& a_p0);

bool closes_square_or_brace_f(const std::optional<crate::syntax::lexer::Tok>& opt0);

std::optional<crate::syntax::lexer::Lex> lex_operator_o(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1);

prism_rtl::JobRef<std::optional<crate::syntax::lexer::Lex>> start_lex_operator_o(crate::syntax::lexer::Lex l_p0, Nat start_p1);

crate::syntax::lexer::Lex non_empty_mark_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1, const Text& after_p2);

crate::syntax::lexer::Lex open_type_args_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1);

bool is_name_tok_f(const std::optional<crate::syntax::lexer::Tok>& opt0);

crate::syntax::lexer::Lex close_type_args_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1);

crate::syntax::lexer::Lex push_operator_f(const crate::syntax::lexer::Lex& l_p0, const Text& op_p1, const Nat& start_p2);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_push_operator_f(crate::syntax::lexer::Lex l_p0, Text op_p1, Nat start_p2);

crate::syntax::lexer::Lex lex_sigils_f(const crate::syntax::lexer::Lex& l0_p0);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_sigils_f(crate::syntax::lexer::Lex l0_p0);

std::tuple<Text, bool, crate::syntax::lexer::Lex> read_sigils_f(const crate::syntax::lexer::Lex& l0_p0);

prism_rtl::JobRef<std::tuple<Text, bool, crate::syntax::lexer::Lex>> start_read_sigils_f(crate::syntax::lexer::Lex l0_p0);

crate::syntax::lexer::Lex lex_caret_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1, const Text& sigils_p2, const Text& next_p3);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_caret_f(crate::syntax::lexer::Lex l_p0, Nat start_p1, Text sigils_p2, Text next_p3);

crate::syntax::lexer::Lex lex_attached_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1, const Text& sigils_p2, const Text& next_p3);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_attached_f(crate::syntax::lexer::Lex l_p0, Nat start_p1, Text sigils_p2, Text next_p3);

crate::syntax::lexer::Lex free_sigils_f(const crate::syntax::lexer::Lex& l0_p0, const Nat& start_p1, const Text& sigils_p2);

std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_f(const crate::syntax::lexer::Lex& l0_p0);

prism_rtl::JobRef<std::tuple<Array<Text>, crate::syntax::lexer::Lex>> start_lex_qualified_path_f(crate::syntax::lexer::Lex l0_p0);

std::tuple<Text, crate::syntax::lexer::Lex> lex_ident_f(const crate::syntax::lexer::Lex& l0_p0);

prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_lex_ident_f(crate::syntax::lexer::Lex l0_p0);

crate::syntax::lexer::Lex lex_word_token_f(const crate::syntax::lexer::Lex& l0_p0, const Text& sigils_p1, const Nat& start_p2);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_word_token_f(crate::syntax::lexer::Lex l0_p0, Text sigils_p1, Nat start_p2);

crate::syntax::lexer::Lex skip_non_ascii_f(const crate::syntax::lexer::Lex& l0_p0, const Nat& w_start_p1);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_skip_non_ascii_f(crate::syntax::lexer::Lex l0_p0, Nat w_start_p1);

crate::syntax::lexer::Lex lex_keyword_f(const crate::syntax::lexer::Lex& l_p0, const Text& w_p1, const Text& sigils_p2, const Nat& start_p3);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_keyword_f(crate::syntax::lexer::Lex l_p0, Text w_p1, Text sigils_p2, Nat start_p3);

crate::syntax::lexer::Lex lex_name_f(const crate::syntax::lexer::Lex& l_p0, const Array<Text>& path_p1, const Text& sigils_p2, const Nat& start_p3, const Nat& w_start_p4);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_name_f(crate::syntax::lexer::Lex l_p0, Array<Text> path_p1, Text sigils_p2, Nat start_p3, Nat w_start_p4);

std::tuple<crate::syntax::lexer::NameCase, crate::syntax::lexer::Lex> name_case_of_f(const crate::syntax::lexer::Lex& l_p0, const Array<Text>& path_p1, const Nat& w_start_p2);

bool is_path_word_f(const crate::syntax::lexer::Lex& l_p0, const Text& sigils_p1, const Array<Text>& path_p2);

}  // namespace syntax::lexer::words


namespace syntax::lexer::words {

/// The step machine of `LexToken`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexToken: unbounded fn Lex -> Lex
struct LexToken : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l0_p0;
    LexToken(crate::syntax::lexer::Lex l0_p0) : l0_p0(std::move(l0_p0)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexPathToken`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexPathToken: unbounded fn Lex, Nat -> Lex
struct LexPathToken : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l_p0;
    Nat start_p1;
    LexPathToken(crate::syntax::lexer::Lex l_p0, Nat start_p1) : l_p0(std::move(l_p0)), start_p1(std::move(start_p1)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexTokenAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexTokenAt: unbounded fn Lex, Nat, Text -> Lex
struct LexTokenAt : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l_p0;
    Nat start_p1;
    Text c_p2;
    LexTokenAt(crate::syntax::lexer::Lex l_p0, Nat start_p1, Text c_p2) : l_p0(std::move(l_p0)), start_p1(std::move(start_p1)), c_p2(std::move(c_p2)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `PushOpSuffix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PushOpSuffix: unbounded fn Lex, Text, Nat -> Lex
struct PushOpSuffix : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l_p0;
    Text op_p1;
    Nat start_p2;
    PushOpSuffix(crate::syntax::lexer::Lex l_p0, Text op_p1, Nat start_p2) : l_p0(std::move(l_p0)), op_p1(std::move(op_p1)), start_p2(std::move(start_p2)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexOperator`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?LexOperator: unbounded fn Lex, Nat -> ?Lex
struct LexOperator : prism_rtl::Job<std::optional<crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l_p0;
    Nat start_p1;
    LexOperator(crate::syntax::lexer::Lex l_p0, Nat start_p1) : l_p0(std::move(l_p0)), start_p1(std::move(start_p1)) {}
    prism_rtl::Turn<std::optional<crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `PushOperator`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PushOperator: unbounded fn Lex, Text, Nat -> Lex
struct PushOperator : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l_p0;
    Text op_p1;
    Nat start_p2;
    PushOperator(crate::syntax::lexer::Lex l_p0, Text op_p1, Nat start_p2) : l_p0(std::move(l_p0)), op_p1(std::move(op_p1)), start_p2(std::move(start_p2)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexSigils`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexSigils: unbounded fn Lex -> Lex
struct LexSigils : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l0_p0;
    LexSigils(crate::syntax::lexer::Lex l0_p0) : l0_p0(std::move(l0_p0)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `ReadSigils`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReadSigils: unbounded fn Lex -> ((Text, Bool, Lex))
struct ReadSigils : prism_rtl::Job<std::tuple<Text, bool, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0_p0;
    ReadSigils(crate::syntax::lexer::Lex l0_p0) : l0_p0(std::move(l0_p0)) {}
    prism_rtl::Turn<std::tuple<Text, bool, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `LexCaret`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexCaret: unbounded fn Lex, Nat, Text, Text -> Lex
struct LexCaret : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l_p0;
    Nat start_p1;
    Text sigils_p2;
    Text next_p3;
    LexCaret(crate::syntax::lexer::Lex l_p0, Nat start_p1, Text sigils_p2, Text next_p3) : l_p0(std::move(l_p0)), start_p1(std::move(start_p1)), sigils_p2(std::move(sigils_p2)), next_p3(std::move(next_p3)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexAttached`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexAttached: unbounded fn Lex, Nat, Text, Text -> Lex
struct LexAttached : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l_p0;
    Nat start_p1;
    Text sigils_p2;
    Text next_p3;
    LexAttached(crate::syntax::lexer::Lex l_p0, Nat start_p1, Text sigils_p2, Text next_p3) : l_p0(std::move(l_p0)), start_p1(std::move(start_p1)), sigils_p2(std::move(sigils_p2)), next_p3(std::move(next_p3)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexQualifiedPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexQualifiedPath: unbounded fn Lex -> (([Text], Lex))
struct LexQualifiedPath : prism_rtl::Job<std::tuple<Array<Text>, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0_p0;
    LexQualifiedPath(crate::syntax::lexer::Lex l0_p0) : l0_p0(std::move(l0_p0)) {}
    prism_rtl::Turn<std::tuple<Array<Text>, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `LexIdent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexIdent: unbounded fn Lex -> ((Text, Lex))
struct LexIdent : prism_rtl::Job<std::tuple<Text, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0_p0;
    LexIdent(crate::syntax::lexer::Lex l0_p0) : l0_p0(std::move(l0_p0)) {}
    prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `LexWordToken`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexWordToken: unbounded fn Lex, Text, Nat -> Lex
struct LexWordToken : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l0_p0;
    Text sigils_p1;
    Nat start_p2;
    LexWordToken(crate::syntax::lexer::Lex l0_p0, Text sigils_p1, Nat start_p2) : l0_p0(std::move(l0_p0)), sigils_p1(std::move(sigils_p1)), start_p2(std::move(start_p2)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `SkipNonAscii`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SkipNonAscii: unbounded fn Lex, Nat -> Lex
struct SkipNonAscii : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l0_p0;
    Nat w_start_p1;
    SkipNonAscii(crate::syntax::lexer::Lex l0_p0, Nat w_start_p1) : l0_p0(std::move(l0_p0)), w_start_p1(std::move(w_start_p1)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexKeyword`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexKeyword: unbounded fn Lex, Text, Text, Nat -> Lex
struct LexKeyword : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l_p0;
    Text w_p1;
    Text sigils_p2;
    Nat start_p3;
    LexKeyword(crate::syntax::lexer::Lex l_p0, Text w_p1, Text sigils_p2, Nat start_p3) : l_p0(std::move(l_p0)), w_p1(std::move(w_p1)), sigils_p2(std::move(sigils_p2)), start_p3(std::move(start_p3)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexName: unbounded fn Lex, [Text], Text, Nat, Nat -> Lex
struct LexName : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l_p0;
    Array<Text> path_p1;
    Text sigils_p2;
    Nat start_p3;
    Nat w_start_p4;
    LexName(crate::syntax::lexer::Lex l_p0, Array<Text> path_p1, Text sigils_p2, Nat start_p3, Nat w_start_p4) : l_p0(std::move(l_p0)), path_p1(std::move(path_p1)), sigils_p2(std::move(sigils_p2)), start_p3(std::move(start_p3)), w_start_p4(std::move(w_start_p4)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


}  // namespace syntax::lexer::words

}  // namespace crate
