// The module `Syntax.Lexer.Words`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/lexer/words/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::lexer::words {

crate::syntax::lexer::Lex lex_token(const crate::syntax::lexer::Lex& l0);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_token(crate::syntax::lexer::Lex l0);

crate::syntax::lexer::Lex lex_path_token(const crate::syntax::lexer::Lex& l, const Nat& start);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_path_token(crate::syntax::lexer::Lex l, Nat start);

crate::syntax::lexer::Lex lex_token_at(const crate::syntax::lexer::Lex& l, const Nat& start, const Text& c);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_token_at(crate::syntax::lexer::Lex l, Nat start, Text c);

crate::syntax::lexer::Lex lex_open(const crate::syntax::lexer::Lex& l, const Text& c, const Nat& start);

crate::syntax::lexer::Lex lex_close(const crate::syntax::lexer::Lex& l, const Text& c, const Nat& start);

crate::syntax::lexer::Lex lex_backslash(const crate::syntax::lexer::Lex& l, const Nat& start);

crate::syntax::lexer::Lex lex_bar(const crate::syntax::lexer::Lex& l, const Nat& start);

crate::syntax::lexer::Lex lex_dot(const crate::syntax::lexer::Lex& l, const Nat& start);

crate::syntax::lexer::Lex push_op_suffix(const crate::syntax::lexer::Lex& l, const Text& op, const Nat& start);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_push_op_suffix(crate::syntax::lexer::Lex l, Text op, Nat start);

Text first_op(const crate::syntax::lexer::Lex& l);

bool ends_mark(const Text& a);

bool closes_square_or_brace(const std::optional<crate::syntax::lexer::Tok>& opt0);

std::optional<crate::syntax::lexer::Lex> lex_operator(const crate::syntax::lexer::Lex& l, const Nat& start);

prism_rtl::JobRef<std::optional<crate::syntax::lexer::Lex>> start_lex_operator(crate::syntax::lexer::Lex l, Nat start);

crate::syntax::lexer::Lex non_empty_mark(const crate::syntax::lexer::Lex& l, const Nat& start, const Text& after_);

crate::syntax::lexer::Lex open_type_args(const crate::syntax::lexer::Lex& l, const Nat& start);

bool is_name_tok(const std::optional<crate::syntax::lexer::Tok>& opt0);

crate::syntax::lexer::Lex close_type_args(const crate::syntax::lexer::Lex& l, const Nat& start);

crate::syntax::lexer::Lex push_operator(const crate::syntax::lexer::Lex& l, const Text& op, const Nat& start);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_push_operator(crate::syntax::lexer::Lex l, Text op, Nat start);

crate::syntax::lexer::Lex lex_sigils(const crate::syntax::lexer::Lex& l0);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_sigils(crate::syntax::lexer::Lex l0);

std::tuple<Text, bool, crate::syntax::lexer::Lex> read_sigils(const crate::syntax::lexer::Lex& l0);

prism_rtl::JobRef<std::tuple<Text, bool, crate::syntax::lexer::Lex>> start_read_sigils(crate::syntax::lexer::Lex l0);

crate::syntax::lexer::Lex lex_caret(const crate::syntax::lexer::Lex& l, const Nat& start, const Text& sigils, const Text& next_);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_caret(crate::syntax::lexer::Lex l, Nat start, Text sigils, Text next_);

crate::syntax::lexer::Lex lex_attached(const crate::syntax::lexer::Lex& l, const Nat& start, const Text& sigils, const Text& next_);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_attached(crate::syntax::lexer::Lex l, Nat start, Text sigils, Text next_);

crate::syntax::lexer::Lex free_sigils(const crate::syntax::lexer::Lex& l0, const Nat& start, const Text& sigils);

std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path(const crate::syntax::lexer::Lex& l0);

prism_rtl::JobRef<std::tuple<Array<Text>, crate::syntax::lexer::Lex>> start_lex_qualified_path(crate::syntax::lexer::Lex l0);

std::tuple<Text, crate::syntax::lexer::Lex> lex_ident(const crate::syntax::lexer::Lex& l0);

prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_lex_ident(crate::syntax::lexer::Lex l0);

crate::syntax::lexer::Lex lex_word_token(const crate::syntax::lexer::Lex& l0, const Text& sigils, const Nat& start);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_word_token(crate::syntax::lexer::Lex l0, Text sigils, Nat start);

crate::syntax::lexer::Lex skip_non_ascii(const crate::syntax::lexer::Lex& l0, const Nat& w_start);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_skip_non_ascii(crate::syntax::lexer::Lex l0, Nat w_start);

crate::syntax::lexer::Lex lex_keyword(const crate::syntax::lexer::Lex& l, const Text& w, const Text& sigils, const Nat& start);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_keyword(crate::syntax::lexer::Lex l, Text w, Text sigils, Nat start);

crate::syntax::lexer::Lex lex_name(const crate::syntax::lexer::Lex& l, const Array<Text>& path_, const Text& sigils, const Nat& start, const Nat& w_start);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_name(crate::syntax::lexer::Lex l, Array<Text> path_, Text sigils, Nat start, Nat w_start);

std::tuple<crate::syntax::lexer::NameCase, crate::syntax::lexer::Lex> name_case_of(const crate::syntax::lexer::Lex& l, const Array<Text>& path_, const Nat& w_start);

bool is_path_word(const crate::syntax::lexer::Lex& l, const Text& sigils, const Array<Text>& path_);

}  // namespace syntax::lexer::words


namespace syntax::lexer::words {

/// The step machine of `LexToken`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexToken: unbounded fn Lex -> Lex
struct LexToken : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l0;
    LexToken(crate::syntax::lexer::Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexPathToken`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexPathToken: unbounded fn Lex, Nat -> Lex
struct LexPathToken : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l;
    Nat start;
    LexPathToken(crate::syntax::lexer::Lex l, Nat start) : l(std::move(l)), start(std::move(start)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexTokenAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexTokenAt: unbounded fn Lex, Nat, Text -> Lex
struct LexTokenAt : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l;
    Nat start;
    Text c;
    LexTokenAt(crate::syntax::lexer::Lex l, Nat start, Text c) : l(std::move(l)), start(std::move(start)), c(std::move(c)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `PushOpSuffix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PushOpSuffix: unbounded fn Lex, Text, Nat -> Lex
struct PushOpSuffix : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l;
    Text op;
    Nat start;
    PushOpSuffix(crate::syntax::lexer::Lex l, Text op, Nat start) : l(std::move(l)), op(std::move(op)), start(std::move(start)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexOperator`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?LexOperator: unbounded fn Lex, Nat -> ?Lex
struct LexOperator : prism_rtl::Job<std::optional<crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l;
    Nat start;
    LexOperator(crate::syntax::lexer::Lex l, Nat start) : l(std::move(l)), start(std::move(start)) {}
    prism_rtl::Turn<std::optional<crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `PushOperator`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PushOperator: unbounded fn Lex, Text, Nat -> Lex
struct PushOperator : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l;
    Text op;
    Nat start;
    PushOperator(crate::syntax::lexer::Lex l, Text op, Nat start) : l(std::move(l)), op(std::move(op)), start(std::move(start)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexSigils`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexSigils: unbounded fn Lex -> Lex
struct LexSigils : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l0;
    LexSigils(crate::syntax::lexer::Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `ReadSigils`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReadSigils: unbounded fn Lex -> ((Text, Bool, Lex))
struct ReadSigils : prism_rtl::Job<std::tuple<Text, bool, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0;
    ReadSigils(crate::syntax::lexer::Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<std::tuple<Text, bool, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `LexCaret`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexCaret: unbounded fn Lex, Nat, Text, Text -> Lex
struct LexCaret : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l;
    Nat start;
    Text sigils;
    Text next_;
    LexCaret(crate::syntax::lexer::Lex l, Nat start, Text sigils, Text next_) : l(std::move(l)), start(std::move(start)), sigils(std::move(sigils)), next_(std::move(next_)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexAttached`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexAttached: unbounded fn Lex, Nat, Text, Text -> Lex
struct LexAttached : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l;
    Nat start;
    Text sigils;
    Text next_;
    LexAttached(crate::syntax::lexer::Lex l, Nat start, Text sigils, Text next_) : l(std::move(l)), start(std::move(start)), sigils(std::move(sigils)), next_(std::move(next_)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexQualifiedPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexQualifiedPath: unbounded fn Lex -> (([Text], Lex))
struct LexQualifiedPath : prism_rtl::Job<std::tuple<Array<Text>, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0;
    LexQualifiedPath(crate::syntax::lexer::Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<std::tuple<Array<Text>, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `LexIdent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexIdent: unbounded fn Lex -> ((Text, Lex))
struct LexIdent : prism_rtl::Job<std::tuple<Text, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0;
    LexIdent(crate::syntax::lexer::Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `LexWordToken`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexWordToken: unbounded fn Lex, Text, Nat -> Lex
struct LexWordToken : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l0;
    Text sigils;
    Nat start;
    LexWordToken(crate::syntax::lexer::Lex l0, Text sigils, Nat start) : l0(std::move(l0)), sigils(std::move(sigils)), start(std::move(start)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `SkipNonAscii`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SkipNonAscii: unbounded fn Lex, Nat -> Lex
struct SkipNonAscii : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l0;
    Nat w_start;
    SkipNonAscii(crate::syntax::lexer::Lex l0, Nat w_start) : l0(std::move(l0)), w_start(std::move(w_start)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexKeyword`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexKeyword: unbounded fn Lex, Text, Text, Nat -> Lex
struct LexKeyword : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l;
    Text w;
    Text sigils;
    Nat start;
    LexKeyword(crate::syntax::lexer::Lex l, Text w, Text sigils, Nat start) : l(std::move(l)), w(std::move(w)), sigils(std::move(sigils)), start(std::move(start)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `LexName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexName: unbounded fn Lex, [Text], Text, Nat, Nat -> Lex
struct LexName : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l;
    Array<Text> path_;
    Text sigils;
    Nat start;
    Nat w_start;
    LexName(crate::syntax::lexer::Lex l, Array<Text> path_, Text sigils, Nat start, Nat w_start) : l(std::move(l)), path_(std::move(path_)), sigils(std::move(sigils)), start(std::move(start)), w_start(std::move(w_start)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


}  // namespace syntax::lexer::words

}  // namespace crate
