// The module `Syntax.Lexer.Words`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace syntax::lexer::words {

struct LexToken;

struct LexPathToken;

struct LexTokenAt;

struct PushOpSuffix;

struct LexOperator;

struct PushOperator;

struct LexSigils;

struct ReadSigils;

struct LexCaret;

struct LexAttached;

struct LexQualifiedPath;

struct LexIdent;

struct LexWordToken;

struct SkipNonAscii;

struct LexKeyword;

struct LexName;

}  // namespace syntax::lexer::words

}  // namespace crate
