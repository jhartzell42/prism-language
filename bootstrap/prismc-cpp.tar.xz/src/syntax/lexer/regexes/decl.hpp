// The module `Syntax.Lexer.Regexes`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace syntax::lexer::regexes {

struct LexRegex;

struct AfterPattern;

struct Finish;

struct Unclosed;

struct HashedEnd;

}  // namespace syntax::lexer::regexes

}  // namespace crate
