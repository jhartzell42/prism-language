// The module `Syntax.Lexer.Regexes`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace syntax::lexer::regexes {

struct LexRegex;

struct AfterPattern;

struct Finish;

struct Unclosed;

struct PlainEnd;

struct HashedEnd;

struct HashesEnd;

struct LettersEnd;

struct IdentEnd;

struct LineEndAt;

}  // namespace syntax::lexer::regexes


}  // namespace crate
