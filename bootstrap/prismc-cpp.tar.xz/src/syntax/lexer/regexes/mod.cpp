// The module `Syntax.Lexer.Regexes`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/regexes.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

namespace crate::syntax::lexer::regexes {

/// let percentMessage
Text percent_message() {
    return Text::lit("`%` is no operator: the remainder is `mod`, and `%` begins a regular expression only as `%/` or `%#/`");
}


/// LexRegex: unbounded fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex lex_regex(const crate::syntax::lexer::Lex& l, const Text& sigils, const Nat& start) {
    auto pct = l.pos;
    auto open = hashes_end(l.src, pct + Nat(1u));
    auto hashes = crate::syntax::lexer::chars::between(l.src, pct + Nat(1u), open);
    return crate::syntax::lexer::chars::char_at_byte(l.src, open) != Text::lit("/")
        ? no_regex(l, pct, open, hashes)
        : ({
        auto close = prism_rtl::cat("/", hashes);
        auto end_opt = hashes == Text::lit("")
            ? plain_end(l.src, open + Nat(1u))
            : hashed_end(l.src, open + Nat(1u), close);
        ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::lexer::Lex> _v;
        if (prism_rtl::is_some(end_opt)) {
            auto&& e = prism_rtl::some_of(end_opt);
            _v.set(after_pattern(l, sigils, start, open + Nat(1u), e, close));
            goto _done;
        }
        if (prism_rtl::is_none(end_opt)) {
            _v.set(unclosed(l, sigils, start, crate::syntax::lexer::chars::between(l.src, open + Nat(1u), line_end_at(l.src, open)), open + Nat(1u), std::optional<Text>{}, Text::lit("pattern"), close));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexRegex::cycle() const {
    const auto& l = this->l;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    auto pct = l.pos;
    auto l_1 = l;
    auto sigils_2 = sigils;
    auto start_3 = start;
    return call_then(start_hashes_end(l_1.src, pct + Nat(1u)), [=](Nat hashes_end_994) {
        return ({
            auto open = hashes_end_994;
            auto hashes = crate::syntax::lexer::chars::between(l_1.src, pct + Nat(1u), open);
            (crate::syntax::lexer::chars::char_at_byte(l_1.src, open) != Text::lit("/")
            ? prism_rtl::finished(no_regex(l_1, pct, open, hashes))
            : ({
            auto close = prism_rtl::cat("/", hashes);
            auto end_opt = hashes == Text::lit("")
                ? plain_end(l_1.src, open + Nat(1u))
                : hashed_end(l_1.src, open + Nat(1u), close);
            ({
            prism_rtl::is_some(end_opt) ? ({
            auto&& e = prism_rtl::some_of(end_opt);
            prism_rtl::more(prism_rtl::rc(AfterPattern(l_1, sigils_2, start_3, open + Nat(1u), e, close)));
        })
            : prism_rtl::is_none(end_opt) ? call_then(start_line_end_at(l_1.src, open), [=](Nat line_end_at_1436) { return prism_rtl::more(prism_rtl::rc(Unclosed(l_1, sigils_2, start_3, crate::syntax::lexer::chars::between(l_1.src, open + Nat(1u), line_end_at_1436), open + Nat(1u), std::optional<Text>{}, Text::lit("pattern"), close))); })
            : throw prism_rtl::Panic("no arm matched");
        });
        }));
        });
    });
}


/// `Start LexRegex, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_regex(crate::syntax::lexer::Lex l, Text sigils, Nat start) {
    return prism_rtl::make_rc<LexRegex>(l, sigils, start);
}


/// NoRegex: fn Lex, Nat, Nat, Text -> Lex
crate::syntax::lexer::Lex no_regex(const crate::syntax::lexer::Lex& l, const Nat& pct, const Nat& open, const Text& hashes) {
    auto end = hashes == Text::lit("") ? pct + Nat(1u) : open;
    auto message = hashes == Text::lit("")
        ? percent_message()
        : Text::lit("a hashed regular expression opens with `%`, its hashes and `/`: `%#/.../#`");
    auto l1 = ({
        crate::syntax::lexer::Lex this_ = l;
        this_.pos = end;
        this_;
    });
    auto l2 = crate::syntax::lexer::chars::lex_err(l1, pct, end, message);
    crate::syntax::lexer::Lex this_ = l2;
    this_.last_ws = true;
    return this_;
}


/// AfterPattern: unbounded fn Lex, Text, Nat, Nat, Nat, Text -> Lex
crate::syntax::lexer::Lex after_pattern(const crate::syntax::lexer::Lex& l, const Text& sigils, const Nat& start, const Nat& at_, const Nat& end, const Text& close) {
    auto src = l.src;
    auto pattern = crate::syntax::lexer::chars::between(src, at_, end);
    auto after_ = end + len_text(close);
    auto run_end = letters_end(src, after_);
    auto run_ = crate::syntax::lexer::chars::between(src, after_, run_end);
    auto c = crate::syntax::lexer::chars::char_at_byte(src, run_end);
    auto plain = close == Text::lit("/");
    return (((c == Text::lit("")) || (c == Text::lit("\n"))) || crate::syntax::lexer::chars::contains(Text::lit(",)]}:;"), c)) || (plain && crate::syntax::lexer::chars::is_space_char(c))
        ? finish(l, sigils, start, pattern, at_, std::optional<Text>{}, Nat(0u), after_)
        : crate::syntax::lexer::chars::has_prefix(text_from(src, run_end), close)
        ? finish(l, sigils, start, pattern, at_, std::optional(run_), after_, run_end + len_text(close))
        : plain && (run_ == Text::lit(""))
        ? ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::lexer::Lex> _v;
        auto&& _m = plain_end(src, after_);
        if (prism_rtl::is_some(_m)) {
            auto&& e = prism_rtl::some_of(_m);
            _v.set(finish(l, sigils, start, pattern, at_, std::optional(crate::syntax::lexer::chars::between(src, after_, e)), after_, e + Nat(1u)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(unclosed(l, sigils, start, pattern, at_, std::optional(crate::syntax::lexer::chars::between(src, after_, line_end_at(src, after_))), Text::lit("replacement"), close));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    })
        : (!plain) && ((run_ == Text::lit("")) || crate::syntax::lexer::chars::is_space_char(c))
        ? ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::lexer::Lex> _v;
        auto&& _m = hashed_end(src, after_, close);
        if (prism_rtl::is_some(_m)) {
            auto&& e = prism_rtl::some_of(_m);
            _v.set(finish(l, sigils, start, pattern, at_, std::optional(crate::syntax::lexer::chars::between(src, after_, e)), after_, e + len_text(close)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(finish(l, sigils, start, pattern, at_, std::optional<Text>{}, Nat(0u), after_));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    })
        : finish(l, sigils, start, pattern, at_, std::optional<Text>{}, Nat(0u), after_);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> AfterPattern::cycle() const {
    const auto& l = this->l;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    const auto& at_ = this->at_;
    const auto& end = this->end;
    const auto& close = this->close;
    auto src = l.src;
    auto pattern = crate::syntax::lexer::chars::between(src, at_, end);
    auto after_ = end + len_text(close);
    auto at__1 = at_;
    auto close_2 = close;
    auto l_3 = l;
    auto sigils_4 = sigils;
    auto start_5 = start;
    return call_then(start_letters_end(src, after_), [=](Nat letters_end_2389) {
        return ({
            auto run_end = letters_end_2389;
            auto run_ = crate::syntax::lexer::chars::between(src, after_, run_end);
            auto c = crate::syntax::lexer::chars::char_at_byte(src, run_end);
            auto plain = close_2 == Text::lit("/");
            (((c == Text::lit("")) || (c == Text::lit("\n"))) || crate::syntax::lexer::chars::contains(Text::lit(",)]}:;"), c)) || (plain && crate::syntax::lexer::chars::is_space_char(c))
            ? prism_rtl::more(prism_rtl::rc(Finish(l_3, sigils_4, start_5, pattern, at__1, std::optional<Text>{}, Nat(0u), after_)))
            : crate::syntax::lexer::chars::has_prefix(text_from(src, run_end), close_2)
            ? prism_rtl::more(prism_rtl::rc(Finish(l_3, sigils_4, start_5, pattern, at__1, std::optional(run_), after_, run_end + len_text(close_2))))
            : plain && (run_ == Text::lit(""))
            ? call_then(start_plain_end(src, after_), [=](std::optional<Nat> plain_end_3150) {
            return ({
                prism_rtl::is_some(plain_end_3150) ? ({
                auto&& e = prism_rtl::some_of(plain_end_3150);
                prism_rtl::more(prism_rtl::rc(Finish(l_3, sigils_4, start_5, pattern, at__1, std::optional(crate::syntax::lexer::chars::between(src, after_, e)), after_, e + Nat(1u))));
            })
                : prism_rtl::is_none(plain_end_3150) ? prism_rtl::more(prism_rtl::rc(Unclosed(l_3, sigils_4, start_5, pattern, at__1, std::optional(crate::syntax::lexer::chars::between(src, after_, line_end_at(src, after_))), Text::lit("replacement"), close_2)))
                : throw prism_rtl::Panic("no arm matched");
            });
        })
            : (!plain) && ((run_ == Text::lit("")) || crate::syntax::lexer::chars::is_space_char(c))
            ? call_then(start_hashed_end(src, after_, close_2), [=](std::optional<Nat> hashed_end_3454) {
            return ({
                prism_rtl::is_some(hashed_end_3454) ? ({
                auto&& e = prism_rtl::some_of(hashed_end_3454);
                prism_rtl::more(prism_rtl::rc(Finish(l_3, sigils_4, start_5, pattern, at__1, std::optional(crate::syntax::lexer::chars::between(src, after_, e)), after_, e + len_text(close_2))));
            })
                : prism_rtl::is_none(hashed_end_3454) ? prism_rtl::more(prism_rtl::rc(Finish(l_3, sigils_4, start_5, pattern, at__1, std::optional<Text>{}, Nat(0u), after_)))
                : throw prism_rtl::Panic("no arm matched");
            });
        })
            : prism_rtl::more(prism_rtl::rc(Finish(l_3, sigils_4, start_5, pattern, at__1, std::optional<Text>{}, Nat(0u), after_)));
        });
    });
}


/// `Start AfterPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_after_pattern(crate::syntax::lexer::Lex l, Text sigils, Nat start, Nat at_, Nat end, Text close) {
    return prism_rtl::make_rc<AfterPattern>(l, sigils, start, at_, end, close);
}


/// Finish: unbounded fn Lex, Text, Nat, Text, Nat, ?Text, Nat, Nat -> Lex
crate::syntax::lexer::Lex finish(const crate::syntax::lexer::Lex& l, const Text& sigils, const Nat& start, const Text& pattern, const Nat& at_, const std::optional<Text>& replacement_opt, const Nat& replacement_at, const Nat& flags_at) {
    auto src = l.src;
    auto flags_end = letters_end(src, flags_at);
    auto lit = crate::syntax::RegexLit{.pattern = pattern, .pattern_at = at_, .replacement = replacement_opt, .replacement_at = replacement_at, .flags = crate::syntax::lexer::chars::between(src, flags_at, flags_end), .flags_at = flags_at};
    auto tail = ident_end(src, flags_end);
    auto l1 = ({
        crate::syntax::lexer::Lex this_ = l;
        this_.pos = tail;
        this_;
    });
    auto l2 = tail > flags_end
        ? crate::syntax::lexer::chars::lex_err(l1, flags_end, tail, prism_rtl::cat("`", crate::syntax::lexer::chars::between(src, flags_end, tail), "` touches the flags of a regular expression: the flags are letters, and no name character follows them"))
        : l1;
    return crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KRegex{sigils, lit}), start, flags_end);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> Finish::cycle() const {
    const auto& l = this->l;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    const auto& pattern = this->pattern;
    const auto& at_ = this->at_;
    const auto& replacement_opt = this->replacement_opt;
    const auto& replacement_at = this->replacement_at;
    const auto& flags_at = this->flags_at;
    auto src = l.src;
    auto replacement_opt_1 = replacement_opt;
    auto at__2 = at_;
    auto flags_at_3 = flags_at;
    auto l_4 = l;
    auto pattern_5 = pattern;
    auto replacement_at_6 = replacement_at;
    auto sigils_7 = sigils;
    auto start_8 = start;
    return call_then(start_letters_end(src, flags_at_3), [=](Nat letters_end_4159) {
        return ({
            auto flags_end = letters_end_4159;
            auto lit = crate::syntax::RegexLit{.pattern = pattern_5, .pattern_at = at__2, .replacement = replacement_opt_1, .replacement_at = replacement_at_6, .flags = crate::syntax::lexer::chars::between(src, flags_at_3, flags_end), .flags_at = flags_at_3};
            call_then(start_ident_end(src, flags_end), [=](Nat ident_end_4364) {
            return ({
                auto tail = ident_end_4364;
                auto l1 = ({
                    crate::syntax::lexer::Lex this_ = l_4;
                    this_.pos = tail;
                    this_;
                });
                auto l2 = tail > flags_end
                    ? crate::syntax::lexer::chars::lex_err(l1, flags_end, tail, prism_rtl::cat("`", crate::syntax::lexer::chars::between(src, flags_end, tail), "` touches the flags of a regular expression: the flags are letters, and no name character follows them"))
                    : l1;
                (prism_rtl::finished(crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KRegex{sigils_7, lit}), start_8, flags_end)));
            });
        });
        });
    });
}


/// `Start Finish, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_finish(crate::syntax::lexer::Lex l, Text sigils, Nat start, Text pattern, Nat at_, std::optional<Text> replacement_opt, Nat replacement_at, Nat flags_at) {
    return prism_rtl::make_rc<Finish>(l, sigils, start, pattern, at_, replacement_opt, replacement_at, flags_at);
}


/// Unclosed: unbounded fn Lex, Text, Nat, Text, Nat, ?Text, Text, Text -> Lex
crate::syntax::lexer::Lex unclosed(const crate::syntax::lexer::Lex& l, const Text& sigils, const Nat& start, const Text& pattern, const Nat& at_, const std::optional<Text>& replacement_opt, const Text& what, const Text& close) {
    auto end = line_end_at(l.src, at_);
    auto lit_1 = crate::syntax::RegexLit{.pattern = pattern, .pattern_at = at_, .replacement = replacement_opt, .replacement_at = at_, .flags = Text::lit(""), .flags_at = end};
    auto l1 = ({
        crate::syntax::lexer::Lex this_ = l;
        this_.pos = end;
        this_;
    });
    auto l2 = crate::syntax::lexer::chars::lex_err(l1, start, end, prism_rtl::cat("a regular expression ends on its line: close its ", what, " with `", close, "`"));
    return crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KRegex{sigils, lit_1}), start, end);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> Unclosed::cycle() const {
    const auto& l = this->l;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    const auto& pattern = this->pattern;
    const auto& at_ = this->at_;
    const auto& replacement_opt = this->replacement_opt;
    const auto& what = this->what;
    const auto& close = this->close;
    auto replacement_opt_1 = replacement_opt;
    auto at__2 = at_;
    auto close_3 = close;
    auto l_4 = l;
    auto pattern_5 = pattern;
    auto sigils_6 = sigils;
    auto start_7 = start;
    auto what_8 = what;
    return call_then(start_line_end_at(l_4.src, at__2), [=](Nat line_end_at_5021) {
        return ({
            auto end = line_end_at_5021;
            auto lit_9 = crate::syntax::RegexLit{.pattern = pattern_5, .pattern_at = at__2, .replacement = replacement_opt_1, .replacement_at = at__2, .flags = Text::lit(""), .flags_at = end};
            auto l1 = ({
                crate::syntax::lexer::Lex this_ = l_4;
                this_.pos = end;
                this_;
            });
            auto l2 = crate::syntax::lexer::chars::lex_err(l1, start_7, end, prism_rtl::cat("a regular expression ends on its line: close its ", what_8, " with `", close_3, "`"));
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KRegex{sigils_6, lit_9}), start_7, end)));
        });
    });
}


/// `Start Unclosed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_unclosed(crate::syntax::lexer::Lex l, Text sigils, Nat start, Text pattern, Nat at_, std::optional<Text> replacement_opt, Text what, Text close) {
    return prism_rtl::make_rc<Unclosed>(l, sigils, start, pattern, at_, replacement_opt, what, close);
}


/// ?PlainEnd: unbounded fn Text, Nat -> ?Nat
std::optional<Nat> plain_end(const Text& src, const Nat& at_) {
    auto&& _found_opt = ({
        std::tuple<std::optional<Nat>, Nat, bool> this_ = std::tuple{std::optional<Nat>{}, at_, true};
        Nat i = at_;
        bool going = true;
        std::optional<Nat> found_opt = std::optional<Nat>{};
        while (going) {
            auto c = crate::syntax::lexer::chars::char_at_byte(src, i);
            if ((c == Text::lit("")) || (c == Text::lit("\n"))) {
                going = false;
            } else if (c == Text::lit("/")) {
                found_opt = std::optional(i);
                going = false;
            } else if (c == Text::lit("\\")) {
                auto d = crate::syntax::lexer::chars::char_at_byte(src, i + Nat(1u));
                if ((d == Text::lit("")) || (d == Text::lit("\n"))) {
                    going = false;
                } else  {
                    i = i + (Nat(1u) + len_text(d));
                }
            } else  {
                i = i + len_text(c);
            }
        }
        this_ = std::tuple{found_opt, i, going};
        this_;
    });
    auto&& found_opt = std::get<0>(_found_opt);
    return found_opt;
}


prism_rtl::Turn<std::optional<Nat>> PlainEnd::cycle() const {
    const auto& src = this->src;
    const auto& at_ = this->at_;
    std::tuple<std::optional<Nat>, Nat, bool> this_ = std::tuple{std::optional<Nat>{}, at_, true};
    Nat i = at_;
    bool going = true;
    std::optional<Nat> found_opt = std::optional<Nat>{};
    auto at__1 = at_;
    return call_then(loop_job(std::tuple{found_opt, this_, going, i}, ({
        auto src_2 = src;
        [=](std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat> _p0) {
        auto found_opt = std::get<0>(_p0);
        auto this_ = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto i = std::get<3>(_p0);
        return going
            ? ({
            auto c = crate::syntax::lexer::chars::char_at_byte(src_2, i);
            if ((c == Text::lit("")) || (c == Text::lit("\n"))) {
                going = false;
            } else if (c == Text::lit("/")) {
                found_opt = std::optional(i);
                going = false;
            } else if (c == Text::lit("\\")) {
                auto d = crate::syntax::lexer::chars::char_at_byte(src_2, i + Nat(1u));
                if ((d == Text::lit("")) || (d == Text::lit("\n"))) {
                    going = false;
                } else  {
                    i = i + (Nat(1u) + len_text(d));
                }
            } else  {
                i = i + len_text(c);
            }
            Expected<std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat>, std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat>>(std::tuple{found_opt, this_, going, i});
        })
            : Expected<std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat>, std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat>>(unexpected(std::tuple{found_opt, this_, going, i}));
    };
    })), [=](std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat> _p0) {
        auto found_opt = std::get<0>(_p0);
        auto this_ = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto i = std::get<3>(_p0);
        return ({
            this_ = std::tuple{found_opt, i, going};
            auto&& _found_opt = this_;
            auto&& found_opt = std::get<0>(_found_opt);
            (prism_rtl::finished(found_opt));
        });
    });
}


/// `Start PlainEnd, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Nat>> start_plain_end(Text src, Nat at_) {
    return prism_rtl::make_rc<PlainEnd>(src, at_);
}


/// ?HashedEnd: unbounded fn Text, Nat, Text -> ?Nat
std::optional<Nat> hashed_end(const Text& src, const Nat& at_, const Text& close) {
    auto&& _found_opt = ({
        std::tuple<std::optional<Nat>, Nat, bool> this_ = std::tuple{std::optional<Nat>{}, at_, true};
        Nat i = at_;
        bool going = true;
        std::optional<Nat> found_opt = std::optional<Nat>{};
        while (going) {
            auto c = crate::syntax::lexer::chars::char_at_byte(src, i);
            if ((c == Text::lit("")) || (c == Text::lit("\n"))) {
                going = false;
            } else if ((c == Text::lit("/")) && crate::syntax::lexer::chars::has_prefix(text_from(src, i), close)) {
                found_opt = std::optional(i);
                going = false;
            } else  {
                i = i + len_text(c);
            }
        }
        this_ = std::tuple{found_opt, i, going};
        this_;
    });
    auto&& found_opt = std::get<0>(_found_opt);
    return found_opt;
}


prism_rtl::Turn<std::optional<Nat>> HashedEnd::cycle() const {
    const auto& src = this->src;
    const auto& at_ = this->at_;
    const auto& close = this->close;
    std::tuple<std::optional<Nat>, Nat, bool> this_ = std::tuple{std::optional<Nat>{}, at_, true};
    Nat i = at_;
    bool going = true;
    std::optional<Nat> found_opt = std::optional<Nat>{};
    auto at__1 = at_;
    return call_then(loop_job(std::tuple{found_opt, this_, going, i}, ({
        auto close_2 = close;
        auto src_3 = src;
        [=](std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat> _p0) {
        auto found_opt = std::get<0>(_p0);
        auto this_ = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto i = std::get<3>(_p0);
        return going
            ? ({
            auto c = crate::syntax::lexer::chars::char_at_byte(src_3, i);
            if ((c == Text::lit("")) || (c == Text::lit("\n"))) {
                going = false;
            } else if ((c == Text::lit("/")) && crate::syntax::lexer::chars::has_prefix(text_from(src_3, i), close_2)) {
                found_opt = std::optional(i);
                going = false;
            } else  {
                i = i + len_text(c);
            }
            Expected<std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat>, std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat>>(std::tuple{found_opt, this_, going, i});
        })
            : Expected<std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat>, std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat>>(unexpected(std::tuple{found_opt, this_, going, i}));
    };
    })), [=](std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat> _p0) {
        auto found_opt = std::get<0>(_p0);
        auto this_ = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto i = std::get<3>(_p0);
        return ({
            this_ = std::tuple{found_opt, i, going};
            auto&& _found_opt = this_;
            auto&& found_opt = std::get<0>(_found_opt);
            (prism_rtl::finished(found_opt));
        });
    });
}


/// `Start HashedEnd, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Nat>> start_hashed_end(Text src, Nat at_, Text close) {
    return prism_rtl::make_rc<HashedEnd>(src, at_, close);
}


/// HashesEnd: unbounded fn Text, Nat -> Nat
Nat hashes_end(const Text& src, const Nat& at_) {
    Nat this_ = at_;
    while (crate::syntax::lexer::chars::char_at_byte(src, this_) == Text::lit("#")) {
        this_ = this_ + Nat(1u);
    }
    return this_;
}


prism_rtl::Turn<Nat> HashesEnd::cycle() const {
    const auto& src = this->src;
    const auto& at_ = this->at_;
    Nat this_ = at_;
    return call_then(loop_job(std::tuple{this_}, ({
        auto at__1 = at_;
        auto src_2 = src;
        [=](std::tuple<Nat> _p0) {
        auto this_ = std::get<0>(_p0);
        return crate::syntax::lexer::chars::char_at_byte(src_2, this_) == Text::lit("#")
            ? ({
            this_ = this_ + Nat(1u);
            Expected<std::tuple<Nat>, std::tuple<Nat>>(std::tuple{this_});
        })
            : Expected<std::tuple<Nat>, std::tuple<Nat>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<Nat> _p0) {
        auto this_ = std::get<0>(_p0);
        return prism_rtl::finished(this_);
    });
}


/// `Start HashesEnd, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Nat> start_hashes_end(Text src, Nat at_) {
    return prism_rtl::make_rc<HashesEnd>(src, at_);
}


/// LettersEnd: unbounded fn Text, Nat -> Nat
Nat letters_end(const Text& src, const Nat& at_) {
    Nat this_ = at_;
    while (crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::char_at_byte(src, this_)) || crate::syntax::lexer::chars::is_lower(crate::syntax::lexer::chars::char_at_byte(src, this_))) {
        this_ = this_ + Nat(1u);
    }
    return this_;
}


prism_rtl::Turn<Nat> LettersEnd::cycle() const {
    const auto& src = this->src;
    const auto& at_ = this->at_;
    Nat this_ = at_;
    return call_then(loop_job(std::tuple{this_}, ({
        auto at__1 = at_;
        auto src_2 = src;
        [=](std::tuple<Nat> _p0) {
        auto this_ = std::get<0>(_p0);
        return crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::char_at_byte(src_2, this_)) || crate::syntax::lexer::chars::is_lower(crate::syntax::lexer::chars::char_at_byte(src_2, this_))
            ? ({
            this_ = this_ + Nat(1u);
            Expected<std::tuple<Nat>, std::tuple<Nat>>(std::tuple{this_});
        })
            : Expected<std::tuple<Nat>, std::tuple<Nat>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<Nat> _p0) {
        auto this_ = std::get<0>(_p0);
        return prism_rtl::finished(this_);
    });
}


/// `Start LettersEnd, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Nat> start_letters_end(Text src, Nat at_) {
    return prism_rtl::make_rc<LettersEnd>(src, at_);
}


/// IdentEnd: unbounded fn Text, Nat -> Nat
Nat ident_end(const Text& src, const Nat& at_) {
    Nat this_ = at_;
    while (crate::syntax::lexer::chars::is_ident_char(crate::syntax::lexer::chars::char_at_byte(src, this_))) {
        this_ = this_ + Nat(1u);
    }
    return this_;
}


prism_rtl::Turn<Nat> IdentEnd::cycle() const {
    const auto& src = this->src;
    const auto& at_ = this->at_;
    Nat this_ = at_;
    return call_then(loop_job(std::tuple{this_}, ({
        auto at__1 = at_;
        auto src_2 = src;
        [=](std::tuple<Nat> _p0) {
        auto this_ = std::get<0>(_p0);
        return crate::syntax::lexer::chars::is_ident_char(crate::syntax::lexer::chars::char_at_byte(src_2, this_))
            ? ({
            this_ = this_ + Nat(1u);
            Expected<std::tuple<Nat>, std::tuple<Nat>>(std::tuple{this_});
        })
            : Expected<std::tuple<Nat>, std::tuple<Nat>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<Nat> _p0) {
        auto this_ = std::get<0>(_p0);
        return prism_rtl::finished(this_);
    });
}


/// `Start IdentEnd, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Nat> start_ident_end(Text src, Nat at_) {
    return prism_rtl::make_rc<IdentEnd>(src, at_);
}


/// LineEndAt: unbounded fn Text, Nat -> Nat
Nat line_end_at(const Text& src, const Nat& at_) {
    Nat this_ = at_;
    while ((crate::syntax::lexer::chars::char_at_byte(src, this_) != Text::lit("")) && (crate::syntax::lexer::chars::char_at_byte(src, this_) != Text::lit("\n"))) {
        this_ = this_ + len_text(crate::syntax::lexer::chars::char_at_byte(src, this_));
    }
    return this_;
}


prism_rtl::Turn<Nat> LineEndAt::cycle() const {
    const auto& src = this->src;
    const auto& at_ = this->at_;
    Nat this_ = at_;
    return call_then(loop_job(std::tuple{this_}, ({
        auto at__1 = at_;
        auto src_2 = src;
        [=](std::tuple<Nat> _p0) {
        auto this_ = std::get<0>(_p0);
        return (crate::syntax::lexer::chars::char_at_byte(src_2, this_) != Text::lit("")) && (crate::syntax::lexer::chars::char_at_byte(src_2, this_) != Text::lit("\n"))
            ? ({
            this_ = this_ + len_text(crate::syntax::lexer::chars::char_at_byte(src_2, this_));
            Expected<std::tuple<Nat>, std::tuple<Nat>>(std::tuple{this_});
        })
            : Expected<std::tuple<Nat>, std::tuple<Nat>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<Nat> _p0) {
        auto this_ = std::get<0>(_p0);
        return prism_rtl::finished(this_);
    });
}


/// `Start LineEndAt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Nat> start_line_end_at(Text src, Nat at_) {
    return prism_rtl::make_rc<LineEndAt>(src, at_);
}


/// TextFrom: fn Text, Nat -> Text
Text text_from(const Text& src, const Nat& at_) {
    auto&& _m = cursor_at(src, at_);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        return after(c);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::syntax::lexer::regexes
