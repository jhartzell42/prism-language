// The module `Syntax.Lexer.Regexes`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/lexer/regexes/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::lexer::regexes {

Text percent_message();

crate::syntax::lexer::Lex lex_regex(const crate::syntax::lexer::Lex& l, const Text& sigils, const Nat& start);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_regex(crate::syntax::lexer::Lex l, Text sigils, Nat start);

crate::syntax::lexer::Lex no_regex(const crate::syntax::lexer::Lex& l, const Nat& pct, const Nat& open, const Text& hashes);

crate::syntax::lexer::Lex after_pattern(const crate::syntax::lexer::Lex& l, const Text& sigils, const Nat& start, const Nat& at_, const Nat& end, const Text& close);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_after_pattern(crate::syntax::lexer::Lex l, Text sigils, Nat start, Nat at_, Nat end, Text close);

crate::syntax::lexer::Lex finish(const crate::syntax::lexer::Lex& l, const Text& sigils, const Nat& start, const Text& pattern, const Nat& at_, const std::optional<Text>& replacement_opt, const Nat& replacement_at, const Nat& flags_at);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_finish(crate::syntax::lexer::Lex l, Text sigils, Nat start, Text pattern, Nat at_, std::optional<Text> replacement_opt, Nat replacement_at, Nat flags_at);

crate::syntax::lexer::Lex unclosed(const crate::syntax::lexer::Lex& l, const Text& sigils, const Nat& start, const Text& pattern, const Nat& at_, const std::optional<Text>& replacement_opt, const Text& what, const Text& close);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_unclosed(crate::syntax::lexer::Lex l, Text sigils, Nat start, Text pattern, Nat at_, std::optional<Text> replacement_opt, Text what, Text close);

std::optional<Nat> plain_end(const Text& src, const Nat& at_);

prism_rtl::JobRef<std::optional<Nat>> start_plain_end(Text src, Nat at_);

std::optional<Nat> hashed_end(const Text& src, const Nat& at_, const Text& close);

prism_rtl::JobRef<std::optional<Nat>> start_hashed_end(Text src, Nat at_, Text close);

Nat hashes_end(const Text& src, const Nat& at_);

prism_rtl::JobRef<Nat> start_hashes_end(Text src, Nat at_);

Nat letters_end(const Text& src, const Nat& at_);

prism_rtl::JobRef<Nat> start_letters_end(Text src, Nat at_);

Nat ident_end(const Text& src, const Nat& at_);

prism_rtl::JobRef<Nat> start_ident_end(Text src, Nat at_);

Nat line_end_at(const Text& src, const Nat& at_);

prism_rtl::JobRef<Nat> start_line_end_at(Text src, Nat at_);

Text text_from(const Text& src, const Nat& at_);

}  // namespace syntax::lexer::regexes


namespace syntax::lexer::regexes {

/// The step machine of `LexRegex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexRegex: unbounded fn Lex, Text, Nat -> Lex
struct LexRegex : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l;
    Text sigils;
    Nat start;
    LexRegex(crate::syntax::lexer::Lex l, Text sigils, Nat start) : l(std::move(l)), sigils(std::move(sigils)), start(std::move(start)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `AfterPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AfterPattern: unbounded fn Lex, Text, Nat, Nat, Nat, Text -> Lex
struct AfterPattern : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l;
    Text sigils;
    Nat start;
    Nat at_;
    Nat end;
    Text close;
    AfterPattern(crate::syntax::lexer::Lex l, Text sigils, Nat start, Nat at_, Nat end, Text close) : l(std::move(l)), sigils(std::move(sigils)), start(std::move(start)), at_(std::move(at_)), end(std::move(end)), close(std::move(close)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `Finish`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Finish: unbounded fn Lex, Text, Nat, Text, Nat, ?Text, Nat, Nat -> Lex
struct Finish : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l;
    Text sigils;
    Nat start;
    Text pattern;
    Nat at_;
    std::optional<Text> replacement_opt;
    Nat replacement_at;
    Nat flags_at;
    Finish(crate::syntax::lexer::Lex l, Text sigils, Nat start, Text pattern, Nat at_, std::optional<Text> replacement_opt, Nat replacement_at, Nat flags_at) : l(std::move(l)), sigils(std::move(sigils)), start(std::move(start)), pattern(std::move(pattern)), at_(std::move(at_)), replacement_opt(std::move(replacement_opt)), replacement_at(std::move(replacement_at)), flags_at(std::move(flags_at)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `Unclosed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Unclosed: unbounded fn Lex, Text, Nat, Text, Nat, ?Text, Text, Text -> Lex
struct Unclosed : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l;
    Text sigils;
    Nat start;
    Text pattern;
    Nat at_;
    std::optional<Text> replacement_opt;
    Text what;
    Text close;
    Unclosed(crate::syntax::lexer::Lex l, Text sigils, Nat start, Text pattern, Nat at_, std::optional<Text> replacement_opt, Text what, Text close) : l(std::move(l)), sigils(std::move(sigils)), start(std::move(start)), pattern(std::move(pattern)), at_(std::move(at_)), replacement_opt(std::move(replacement_opt)), what(std::move(what)), close(std::move(close)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `PlainEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?PlainEnd: unbounded fn Text, Nat -> ?Nat
struct PlainEnd : prism_rtl::Job<std::optional<Nat>> {
    Text src;
    Nat at_;
    PlainEnd(Text src, Nat at_) : src(std::move(src)), at_(std::move(at_)) {}
    prism_rtl::Turn<std::optional<Nat>> cycle() const override;
};


/// The step machine of `HashedEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?HashedEnd: unbounded fn Text, Nat, Text -> ?Nat
struct HashedEnd : prism_rtl::Job<std::optional<Nat>> {
    Text src;
    Nat at_;
    Text close;
    HashedEnd(Text src, Nat at_, Text close) : src(std::move(src)), at_(std::move(at_)), close(std::move(close)) {}
    prism_rtl::Turn<std::optional<Nat>> cycle() const override;
};


/// The step machine of `HashesEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HashesEnd: unbounded fn Text, Nat -> Nat
struct HashesEnd : prism_rtl::Job<Nat> {
    Text src;
    Nat at_;
    HashesEnd(Text src, Nat at_) : src(std::move(src)), at_(std::move(at_)) {}
    prism_rtl::Turn<Nat> cycle() const override;
};


/// The step machine of `LettersEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LettersEnd: unbounded fn Text, Nat -> Nat
struct LettersEnd : prism_rtl::Job<Nat> {
    Text src;
    Nat at_;
    LettersEnd(Text src, Nat at_) : src(std::move(src)), at_(std::move(at_)) {}
    prism_rtl::Turn<Nat> cycle() const override;
};


/// The step machine of `IdentEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IdentEnd: unbounded fn Text, Nat -> Nat
struct IdentEnd : prism_rtl::Job<Nat> {
    Text src;
    Nat at_;
    IdentEnd(Text src, Nat at_) : src(std::move(src)), at_(std::move(at_)) {}
    prism_rtl::Turn<Nat> cycle() const override;
};


/// The step machine of `LineEndAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LineEndAt: unbounded fn Text, Nat -> Nat
struct LineEndAt : prism_rtl::Job<Nat> {
    Text src;
    Nat at_;
    LineEndAt(Text src, Nat at_) : src(std::move(src)), at_(std::move(at_)) {}
    prism_rtl::Turn<Nat> cycle() const override;
};


}  // namespace syntax::lexer::regexes

}  // namespace crate
