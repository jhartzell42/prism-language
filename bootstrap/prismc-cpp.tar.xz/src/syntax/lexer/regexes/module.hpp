// The module `Syntax.Lexer.Regexes`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/lexer/regexes/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::lexer::regexes {

Text percent_message();

crate::syntax::lexer::Lex lex_regex(const crate::syntax::lexer::Lex& l_p0, const Text& sigils_p1, const Nat& start_p2);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_regex(crate::syntax::lexer::Lex l_p0, Text sigils_p1, Nat start_p2);

crate::syntax::lexer::Lex no_regex(const crate::syntax::lexer::Lex& l_p0, const Nat& pct_p1, const Nat& open_p2, const Text& hashes_p3);

crate::syntax::lexer::Lex after_pattern(const crate::syntax::lexer::Lex& l_p0, const Text& sigils_p1, const Nat& start_p2, const Nat& at_p3, const Nat& end_p4, const Text& close_p5);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_after_pattern(crate::syntax::lexer::Lex l_p0, Text sigils_p1, Nat start_p2, Nat at_p3, Nat end_p4, Text close_p5);

crate::syntax::lexer::Lex finish(const crate::syntax::lexer::Lex& l_p0, const Text& sigils_p1, const Nat& start_p2, const Text& pattern_p3, const Nat& at_p4, const std::optional<Text>& replacement_o5, const Nat& replacement_at_p6, const Nat& flags_at_p7);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_finish(crate::syntax::lexer::Lex l_p0, Text sigils_p1, Nat start_p2, Text pattern_p3, Nat at_p4, std::optional<Text> replacement_o5, Nat replacement_at_p6, Nat flags_at_p7);

crate::syntax::lexer::Lex unclosed(const crate::syntax::lexer::Lex& l_p0, const Text& sigils_p1, const Nat& start_p2, const Text& pattern_p3, const Nat& at_p4, const std::optional<Text>& replacement_o5, const Text& what_p6, const Text& close_p7);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_unclosed(crate::syntax::lexer::Lex l_p0, Text sigils_p1, Nat start_p2, Text pattern_p3, Nat at_p4, std::optional<Text> replacement_o5, Text what_p6, Text close_p7);

std::optional<Nat> plain_end(const Text& src_p0, const Nat& at_p1);

std::optional<Nat> hashed_end(const Text& src_p0, const Nat& at_p1, const Text& close_p2);

prism_rtl::JobRef<std::optional<Nat>> start_hashed_end(Text src_p0, Nat at_p1, Text close_p2);

Nat hashes_end(const Text& src_p0, const Nat& at_p1);

Nat letters_end(const Text& src_p0, const Nat& at_p1);

Nat ident_end(const Text& src_p0, const Nat& at_p1);

Nat line_end_at(const Text& src_p0, const Nat& at_p1);

Text text_from(const Text& src_p0, const Nat& at_p1);

}  // namespace syntax::lexer::regexes


namespace syntax::lexer::regexes {

/// The step machine of `LexRegex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexRegex: unbounded fn Lex, Text, Nat -> Lex
struct LexRegex : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l_p0;
    Text sigils_p1;
    Nat start_p2;
    LexRegex(crate::syntax::lexer::Lex l_p0, Text sigils_p1, Nat start_p2) : l_p0(std::move(l_p0)), sigils_p1(std::move(sigils_p1)), start_p2(std::move(start_p2)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `AfterPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AfterPattern: unbounded fn Lex, Text, Nat, Nat, Nat, Text -> Lex
struct AfterPattern : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l_p0;
    Text sigils_p1;
    Nat start_p2;
    Nat at_p3;
    Nat end_p4;
    Text close_p5;
    AfterPattern(crate::syntax::lexer::Lex l_p0, Text sigils_p1, Nat start_p2, Nat at_p3, Nat end_p4, Text close_p5) : l_p0(std::move(l_p0)), sigils_p1(std::move(sigils_p1)), start_p2(std::move(start_p2)), at_p3(std::move(at_p3)), end_p4(std::move(end_p4)), close_p5(std::move(close_p5)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `Finish`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Finish: unbounded fn Lex, Text, Nat, Text, Nat, ?Text, Nat, Nat -> Lex
struct Finish : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l_p0;
    Text sigils_p1;
    Nat start_p2;
    Text pattern_p3;
    Nat at_p4;
    std::optional<Text> replacement_o5;
    Nat replacement_at_p6;
    Nat flags_at_p7;
    Finish(crate::syntax::lexer::Lex l_p0, Text sigils_p1, Nat start_p2, Text pattern_p3, Nat at_p4, std::optional<Text> replacement_o5, Nat replacement_at_p6, Nat flags_at_p7) : l_p0(std::move(l_p0)), sigils_p1(std::move(sigils_p1)), start_p2(std::move(start_p2)), pattern_p3(std::move(pattern_p3)), at_p4(std::move(at_p4)), replacement_o5(std::move(replacement_o5)), replacement_at_p6(std::move(replacement_at_p6)), flags_at_p7(std::move(flags_at_p7)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `Unclosed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Unclosed: unbounded fn Lex, Text, Nat, Text, Nat, ?Text, Text, Text -> Lex
struct Unclosed : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l_p0;
    Text sigils_p1;
    Nat start_p2;
    Text pattern_p3;
    Nat at_p4;
    std::optional<Text> replacement_o5;
    Text what_p6;
    Text close_p7;
    Unclosed(crate::syntax::lexer::Lex l_p0, Text sigils_p1, Nat start_p2, Text pattern_p3, Nat at_p4, std::optional<Text> replacement_o5, Text what_p6, Text close_p7) : l_p0(std::move(l_p0)), sigils_p1(std::move(sigils_p1)), start_p2(std::move(start_p2)), pattern_p3(std::move(pattern_p3)), at_p4(std::move(at_p4)), replacement_o5(std::move(replacement_o5)), what_p6(std::move(what_p6)), close_p7(std::move(close_p7)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `HashedEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?HashedEnd: unbounded fn Text, Nat, Text -> ?Nat
struct HashedEnd : prism_rtl::Job<std::optional<Nat>> {
    Text src_p0;
    Nat at_p1;
    Text close_p2;
    HashedEnd(Text src_p0, Nat at_p1, Text close_p2) : src_p0(std::move(src_p0)), at_p1(std::move(at_p1)), close_p2(std::move(close_p2)) {}
    prism_rtl::Turn<std::optional<Nat>> cycle() const override;
};


}  // namespace syntax::lexer::regexes

}  // namespace crate
