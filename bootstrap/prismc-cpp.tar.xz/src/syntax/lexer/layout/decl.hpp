// The module `Syntax.Lexer.Layout`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace syntax::lexer::layout {

struct LexFile;

struct TemplateHead;

struct SkipBlankAndCommentLines;

struct Nested;

struct LexStream;

struct BeginLine;

struct Indentation;

struct ClosesBraceBlock;

struct SkipLine;

struct IndentedLine;

}  // namespace syntax::lexer::layout


}  // namespace crate
