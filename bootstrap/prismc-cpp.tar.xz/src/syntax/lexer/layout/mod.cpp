// The module `Syntax.Lexer.Layout`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/layout.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <syntax/lexer/layout/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

namespace crate::syntax::lexer::layout {

/// LexFile: unbounded fn Text -> Lexed
crate::syntax::lexer::Lexed lex_file(const Text& src) {
    auto start = crate::syntax::lexer::Lex{.src = src, .pos = Nat(0u), .diags = Array<crate::syntax::Diag>{}, .mode = crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MFile{}), .tokens = Array<crate::syntax::lexer::Tok>{}, .layout = Array<Nat>{}, .frames = Array<Text>{}, .last_ws = true, .lambda_open = false, .pending_open = false, .pending_span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}, .line_first = Nat(0u), .mark_line_start = false, .first_line = true, .test_pending = Text::lit(""), .test_depth = std::optional<Nat>{}, .check_depth = std::optional<Nat>{}, .path_next = false};
    auto skipped = skip_blank_and_comment_lines(start);
    auto opened = (crate::syntax::lexer::chars::peek(skipped) == Text::lit("<")) && (crate::syntax::lexer::templates::template_tag_ahead(skipped) != Text::lit(""));
    auto [head, l] = opened
        ? template_head(skipped)
        : std::tuple{Array<crate::syntax::lexer::Tok>{}, start};
    auto body = lex_stream(crate::syntax::lexer::fresh(l, crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MFile{})));
    return crate::syntax::lexer::Lexed{.tokens = append(head, body->tokens), .diags = body.diags};
}


prism_rtl::Turn<crate::syntax::lexer::Lexed> LexFile::cycle() const {
    const auto& src = this->src;
    auto start = crate::syntax::lexer::Lex{.src = src, .pos = Nat(0u), .diags = Array<crate::syntax::Diag>{}, .mode = crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MFile{}), .tokens = Array<crate::syntax::lexer::Tok>{}, .layout = Array<Nat>{}, .frames = Array<Text>{}, .last_ws = true, .lambda_open = false, .pending_open = false, .pending_span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}, .line_first = Nat(0u), .mark_line_start = false, .first_line = true, .test_pending = Text::lit(""), .test_depth = std::optional<Nat>{}, .check_depth = std::optional<Nat>{}, .path_next = false};
    return call_then(start_skip_blank_and_comment_lines(start), [=](crate::syntax::lexer::Lex skip_blank_and_comment_lines_1051) {
        return ({
            auto skipped = skip_blank_and_comment_lines_1051;
            auto opened = (crate::syntax::lexer::chars::peek(skipped) == Text::lit("<")) && (crate::syntax::lexer::templates::template_tag_ahead(skipped) != Text::lit(""));
            auto [head, l] = opened
                ? template_head(skipped)
                : std::tuple{Array<crate::syntax::lexer::Tok>{}, start};
            call_then(start_lex_stream(crate::syntax::lexer::fresh(l, crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MFile{}))), [=](crate::syntax::lexer::Lex lex_stream_1249) {
            return ({
                auto body = lex_stream_1249;
                (prism_rtl::finished(crate::syntax::lexer::Lexed{.tokens = append(head, body->tokens), .diags = body.diags}));
            });
        });
        });
    });
}


/// `Start LexFile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lexed> start_lex_file(Text src) {
    return prism_rtl::make_rc<LexFile>(src);
}


/// TemplateHead: unbounded fn Lex -> (([Tok], Lex))
std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> template_head(const crate::syntax::lexer::Lex& l0) {
    auto [kind, l] = crate::syntax::lexer::templates::lex_template(l0, Text::lit("File"), l0.pos);
    auto tok = crate::syntax::lexer::Tok{.kind = kind, .span = crate::syntax::Range{.start = l0.pos, .end = l.pos}, .touches = false, .line_start = false};
    return std::tuple{Array(std::vector{tok}), l};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex>> TemplateHead::cycle() const {
    const auto& l0 = this->l0;
    auto l0_1 = l0;
    return call_then(crate::syntax::lexer::templates::start_lex_template(l0_1, Text::lit("File"), l0_1.pos), [=](std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_template_1501) {
        return ({
            auto [kind, l] = lex_template_1501;
            auto tok = crate::syntax::lexer::Tok{.kind = kind, .span = crate::syntax::Range{.start = l0_1.pos, .end = l.pos}, .touches = false, .line_start = false};
            (prism_rtl::finished(std::tuple{Array(std::vector{tok}), l}));
        });
    });
}


/// `Start TemplateHead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex>> start_template_head(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<TemplateHead>(l0);
}


/// SkipBlankAndCommentLines: unbounded fn Lex -> Lex
crate::syntax::lexer::Lex skip_blank_and_comment_lines(const crate::syntax::lexer::Lex& l) {
    crate::syntax::lexer::Lex this_ = l;
    bool going = true;
    while (going) {
        auto line = crate::syntax::lexer::chars::rest_of_line(this_);
        auto t = crate::syntax::lexer::chars::trim_start(line);
        if (((t == Text::lit("")) || (crate::syntax::lexer::chars::head(t) == Text::lit("#"))) && ((this_.pos + len_text(line)) < len_text(this_.src))) {
            this_.pos = this_.pos + (len_text(line) + Nat(1u));
        } else  {
            going = false;
        }
    }
    return this_;
}


prism_rtl::Turn<crate::syntax::lexer::Lex> SkipBlankAndCommentLines::cycle() const {
    const auto& l = this->l;
    crate::syntax::lexer::Lex this_ = l;
    bool going = true;
    return call_then(loop_job(std::tuple{this_, going}, [=](std::tuple<crate::syntax::lexer::Lex, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        return going
            ? ({
            auto line = crate::syntax::lexer::chars::rest_of_line(this_);
            auto t = crate::syntax::lexer::chars::trim_start(line);
            if (((t == Text::lit("")) || (crate::syntax::lexer::chars::head(t) == Text::lit("#"))) && ((this_.pos + len_text(line)) < len_text(this_.src))) {
                this_.pos = this_.pos + (len_text(line) + Nat(1u));
            } else  {
                going = false;
            }
            Expected<std::tuple<crate::syntax::lexer::Lex, bool>, std::tuple<crate::syntax::lexer::Lex, bool>>(std::tuple{this_, going});
        })
            : Expected<std::tuple<crate::syntax::lexer::Lex, bool>, std::tuple<crate::syntax::lexer::Lex, bool>>(unexpected(std::tuple{this_, going}));
    }), [=](std::tuple<crate::syntax::lexer::Lex, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        return prism_rtl::finished(this_);
    });
}


/// `Start SkipBlankAndCommentLines, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_skip_blank_and_comment_lines(crate::syntax::lexer::Lex l) {
    return prism_rtl::make_rc<SkipBlankAndCommentLines>(l);
}


/// Nested: unbounded fn Lex, Mode -> (([Tok], Lex))
std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> nested(const crate::syntax::lexer::Lex& l, const crate::syntax::lexer::Mode& mode) {
    auto inner = lex_stream(crate::syntax::lexer::fresh(l, mode));
    auto back_ = ({
        crate::syntax::lexer::Lex this_ = l;
        this_.pos = inner.pos;
        this_.diags = inner.diags;
        this_;
    });
    return std::tuple{inner->tokens, back_};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex>> Nested::cycle() const {
    const auto& l = this->l;
    const auto& mode = this->mode;
    auto l_1 = l;
    auto mode_2 = mode;
    return call_then(start_lex_stream(crate::syntax::lexer::fresh(l_1, mode_2)), [=](crate::syntax::lexer::Lex lex_stream_2224) {
        return ({
            auto inner = lex_stream_2224;
            auto back_ = ({
                crate::syntax::lexer::Lex this_ = l_1;
                this_.pos = inner.pos;
                this_.diags = inner.diags;
                this_;
            });
            (prism_rtl::finished(std::tuple{inner->tokens, back_}));
        });
    });
}


/// `Start Nested, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex>> start_nested(crate::syntax::lexer::Lex l, crate::syntax::lexer::Mode mode) {
    return prism_rtl::make_rc<Nested>(l, mode);
}


/// LexStream: unbounded fn Lex -> Lex
crate::syntax::lexer::Lex lex_stream(const crate::syntax::lexer::Lex& l0) {
    crate::syntax::lexer::Lex this_ = l0;
    bool at_line_start = crate::syntax::lexer::layout_on(this_.mode);
    bool done = false;
    while (!done) {
        bool go = true;
        if (at_line_start && crate::syntax::lexer::layout_active(this_)) {
            at_line_start = false;
            auto [l, verdict] = begin_line(this_);
            this_ = l;
            if (verdict == Text::lit("skip")) {
                at_line_start = true;
                go = false;
            }
            if (verdict == Text::lit("end")) {
                done = true;
                go = false;
            }
        }
        if (go) {
            auto c = crate::syntax::lexer::chars::peek(this_);
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                {
                    auto&& u3052_0 = c;
                    if (u3052_0 == Text::lit("")) {
                        _v.set(({
                            this_ = unclosed_stream(this_);
                            done = true;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u3052_1 = c;
                    if (u3052_1 == Text::lit("\n")) {
                        _v.set(({
                            this_.pos = this_.pos + Nat(1u);
                            this_.last_ws = true;
                            if (this_.lambda_open) {
                                this_ = crate::syntax::lexer::chars::lex_err(this_, crate::syntax::lexer::chars::dec(this_.pos), this_.pos, Text::lit("a lambda\'s parameter list closes with `|` on its own line"));
                                this_.lambda_open = false;
                            }
                            if (crate::syntax::lexer::layout_active(this_)) {
                                this_ = end_line(this_);
                                at_line_start = true;
                            }
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u3052_2 = c;
                    if (u3052_2 == Text::lit(" ")) {
                        _v.set(({
                            this_.pos = this_.pos + Nat(1u);
                            this_.last_ws = true;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u3052_3 = c;
                    if (u3052_3 == Text::lit("\r")) {
                        _v.set(({
                            this_.pos = this_.pos + Nat(1u);
                            this_.last_ws = true;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u3052_4 = c;
                    if (u3052_4 == Text::lit("\t")) {
                        _v.set(({
                            this_.pos = this_.pos + Nat(1u);
                            this_.last_ws = true;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u3052_5 = c;
                    if (u3052_5 == Text::lit("#")) {
                        _v.set(({
                            this_.pos = crate::syntax::lexer::chars::line_end(this_);
                            this_.last_ws = true;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        auto [ends, l] = stream_ends_here(this_);
                        this_ = l;
                        if (ends) {
                            done = true;
                        } else  {
                            this_ = crate::syntax::lexer::words::lex_token(this_);
                        }
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
        }
    }
    if (crate::syntax::lexer::layout_on(this_.mode)) {
        while (len(this_.layout) > Nat(1u)) {
            this_.layout = crate::syntax::lexer::chars::pop(this_.layout);
            this_ = crate::syntax::lexer::push_tok(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayClose{}), this_.pos, this_.pos);
        }
    }
    if (this_.mode == crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MFile{})) {
        this_ = crate::syntax::lexer::push_tok(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), this_.pos, this_.pos);
    }
    return this_;
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexStream::cycle() const {
    const auto& l0 = this->l0;
    crate::syntax::lexer::Lex this_ = l0;
    bool at_line_start = crate::syntax::lexer::layout_on(this_.mode);
    bool done = false;
    return call_then(loop_job(std::tuple{this_, at_line_start, done}, [=](std::tuple<crate::syntax::lexer::Lex, bool, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto at_line_start = std::get<1>(_p0);
        auto done = std::get<2>(_p0);
        return !done
            ? ({
            bool go = true;
            if (at_line_start && crate::syntax::lexer::layout_active(this_)) {
                at_line_start = false;
                auto [l, verdict] = begin_line(this_);
                this_ = l;
                if (verdict == Text::lit("skip")) {
                    at_line_start = true;
                    go = false;
                }
                if (verdict == Text::lit("end")) {
                    done = true;
                    go = false;
                }
            }
            if (go) {
                auto c = crate::syntax::lexer::chars::peek(this_);
                ({
                    __label__ _done;
                    prism_rtl::Slot<Unit> _v;
                    {
                        auto&& u3052_0 = c;
                        if (u3052_0 == Text::lit("")) {
                            _v.set(({
                                this_ = unclosed_stream(this_);
                                done = true;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u3052_1 = c;
                        if (u3052_1 == Text::lit("\n")) {
                            _v.set(({
                                this_.pos = this_.pos + Nat(1u);
                                this_.last_ws = true;
                                if (this_.lambda_open) {
                                    this_ = crate::syntax::lexer::chars::lex_err(this_, crate::syntax::lexer::chars::dec(this_.pos), this_.pos, Text::lit("a lambda\'s parameter list closes with `|` on its own line"));
                                    this_.lambda_open = false;
                                }
                                if (crate::syntax::lexer::layout_active(this_)) {
                                    this_ = end_line(this_);
                                    at_line_start = true;
                                }
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u3052_2 = c;
                        if (u3052_2 == Text::lit(" ")) {
                            _v.set(({
                                this_.pos = this_.pos + Nat(1u);
                                this_.last_ws = true;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u3052_3 = c;
                        if (u3052_3 == Text::lit("\r")) {
                            _v.set(({
                                this_.pos = this_.pos + Nat(1u);
                                this_.last_ws = true;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u3052_4 = c;
                        if (u3052_4 == Text::lit("\t")) {
                            _v.set(({
                                this_.pos = this_.pos + Nat(1u);
                                this_.last_ws = true;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u3052_5 = c;
                        if (u3052_5 == Text::lit("#")) {
                            _v.set(({
                                this_.pos = crate::syntax::lexer::chars::line_end(this_);
                                this_.last_ws = true;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        _v.set(({
                            auto [ends, l] = stream_ends_here(this_);
                            this_ = l;
                            if (ends) {
                                done = true;
                            } else  {
                                this_ = crate::syntax::lexer::words::lex_token(this_);
                            }
                            Unit{};
                        }));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            }
            Expected<std::tuple<crate::syntax::lexer::Lex, bool, bool>, std::tuple<crate::syntax::lexer::Lex, bool, bool>>(std::tuple{this_, at_line_start, done});
        })
            : Expected<std::tuple<crate::syntax::lexer::Lex, bool, bool>, std::tuple<crate::syntax::lexer::Lex, bool, bool>>(unexpected(std::tuple{this_, at_line_start, done}));
    }), [=](std::tuple<crate::syntax::lexer::Lex, bool, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto at_line_start = std::get<1>(_p0);
        auto done = std::get<2>(_p0);
        return ({
            auto k_if4442 = [=](std::tuple<crate::syntax::lexer::Lex, bool, bool> _p0) {
                auto this_ = std::get<0>(_p0);
                auto at_line_start = std::get<1>(_p0);
                auto done = std::get<2>(_p0);
                return ({
                    if (this_->mode == crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MFile{})) {
                        this_ = crate::syntax::lexer::push_tok(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), this_.pos, this_.pos);
                    }
                    (prism_rtl::finished(this_));
                });
            };
            (crate::syntax::lexer::layout_on(this_->mode)
            ? call_then(loop_job(std::tuple{this_, at_line_start, done}, [=](std::tuple<crate::syntax::lexer::Lex, bool, bool> _p0) {
            auto this_ = std::get<0>(_p0);
            auto at_line_start = std::get<1>(_p0);
            auto done = std::get<2>(_p0);
            return len(this_.layout) > Nat(1u)
                ? ({
                this_.layout = crate::syntax::lexer::chars::pop(this_.layout);
                this_ = crate::syntax::lexer::push_tok(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayClose{}), this_.pos, this_.pos);
                Expected<std::tuple<crate::syntax::lexer::Lex, bool, bool>, std::tuple<crate::syntax::lexer::Lex, bool, bool>>(std::tuple{this_, at_line_start, done});
            })
                : Expected<std::tuple<crate::syntax::lexer::Lex, bool, bool>, std::tuple<crate::syntax::lexer::Lex, bool, bool>>(unexpected(std::tuple{this_, at_line_start, done}));
        }), [=](std::tuple<crate::syntax::lexer::Lex, bool, bool> _p0) {
            auto this_ = std::get<0>(_p0);
            auto at_line_start = std::get<1>(_p0);
            auto done = std::get<2>(_p0);
            return k_if4442(std::tuple{this_, at_line_start, done});
        })
            : k_if4442(std::tuple{this_, at_line_start, done}));
        });
    });
}


/// `Start LexStream, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_stream(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexStream>(l0);
}


/// UnclosedStream: fn Lex -> Lex
crate::syntax::lexer::Lex unclosed_stream(const crate::syntax::lexer::Lex& l) {
    auto&& _m = l->mode;
    if (prism_rtl::is<crate::syntax::lexer::Mode::MFile>(_m)) {
        return l;
    }
    if (prism_rtl::is<crate::syntax::lexer::Mode::MBrace>(_m)) {
        return crate::syntax::lexer::chars::lex_err(l, l.pos, l.pos, Text::lit("a brace block never closes: expected its closing delimiter alone on a line"));
    }
    if (prism_rtl::is<crate::syntax::lexer::Mode::MPlaceholder>(_m)) {
        auto&& m4718_2_0 = prism_rtl::as<crate::syntax::lexer::Mode::MPlaceholder>(_m).a0;
        if (m4718_2_0 == Text::lit("single")) {
            return crate::syntax::lexer::chars::lex_err(l, l.pos, l.pos, Text::lit("a placeholder never closes: expected `}`"));
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::Mode::MPlaceholder>(_m)) {
        return crate::syntax::lexer::chars::lex_err(l, l.pos, l.pos, Text::lit("a placeholder never closes: expected `}}`"));
    }
    if (prism_rtl::is<crate::syntax::lexer::Mode::MPathKey>(_m)) {
        return crate::syntax::lexer::chars::lex_err(l, l.pos, l.pos, Text::lit("a path key never closes: expected `]`"));
    }
    prism_rtl::unreachable("no arm matched");
}


/// StreamEndsHere: fn Lex -> ((Bool, Lex))
std::tuple<bool, crate::syntax::lexer::Lex> stream_ends_here(const crate::syntax::lexer::Lex& l) {
    auto c = crate::syntax::lexer::chars::peek(l);
    auto closes = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = l->mode;
        if (prism_rtl::is<crate::syntax::lexer::Mode::MPlaceholder>(_m)) {
            auto&& m5318_0_0 = prism_rtl::as<crate::syntax::lexer::Mode::MPlaceholder>(_m).a0;
            if (m5318_0_0 == Text::lit("single")) {
                _v.set(c == Text::lit("}"));
                goto _done;
            }
        }
        if (prism_rtl::is<crate::syntax::lexer::Mode::MPlaceholder>(_m)) {
            auto&& m5318_1_0 = prism_rtl::as<crate::syntax::lexer::Mode::MPlaceholder>(_m).a0;
            if (m5318_1_0 == Text::lit("double")) {
                _v.set(crate::syntax::lexer::chars::starts_with(l, Text::lit("}}")));
                goto _done;
            }
        }
        if (prism_rtl::is<crate::syntax::lexer::Mode::MPathKey>(_m)) {
            _v.set(c == Text::lit("]"));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto width = l->mode == crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{Text::lit("double")})
        ? Nat(2u)
        : Nat(1u);
    return (len(l.frames) == Nat(0u)) && closes
        ? std::tuple{true, crate::syntax::lexer::chars::forward(l, width)}
        : std::tuple{false, l};
}


/// EndLine: fn Lex -> Lex
crate::syntax::lexer::Lex end_line(const crate::syntax::lexer::Lex& l) {
    auto&& _m = crate::syntax::lexer::chars::last(l->tokens);
    if (prism_rtl::is_some(_m)) {
        auto&& t = prism_rtl::some_of(_m);
        if ((len(l->tokens) > l.line_first) && opens_block(t.kind)) {
            crate::syntax::lexer::Lex this_ = l;
            this_.pending_open = true;
            this_.pending_span = t.span;
            return this_;
        }
    }
    {
        return l;
    }
}


/// OpensBlock: fn TokKind -> Bool
bool opens_block(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KColon>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLambdaBar>(tok_kind0) && !prism_rtl::as<crate::syntax::lexer::TokKind::KLambdaBar>(tok_kind0).a0) {
        return true;
    }
    {
        return false;
    }
}


/// BeginLine: unbounded fn Lex -> ((Lex, Text))
std::tuple<crate::syntax::lexer::Lex, Text> begin_line(const crate::syntax::lexer::Lex& l0) {
    auto line_begin = l0.pos;
    auto [l1, col] = indentation(l0);
    auto&& _m = crate::syntax::lexer::chars::peek(l1);
    {
        auto&& m6669_0 = _m;
        if (m6669_0 == Text::lit("")) {
            return std::tuple{l1, Text::lit("end")};
        }
    }
    {
        auto&& m6669_1 = _m;
        if (m6669_1 == Text::lit("\n")) {
            return std::tuple{crate::syntax::lexer::chars::bump(l1), Text::lit("skip")};
        }
    }
    {
        auto&& m6669_2 = _m;
        if (m6669_2 == Text::lit("#")) {
            auto l2 = ({
                crate::syntax::lexer::Lex this_ = l1;
                this_.pos = crate::syntax::lexer::chars::line_end(this_);
                this_;
            });
            return crate::syntax::lexer::chars::peek(l2) == Text::lit("\n")
                ? std::tuple{crate::syntax::lexer::chars::bump(l2), Text::lit("skip")}
                : std::tuple{l2, Text::lit("end")};
        }
    }
    {
        return closes_brace_block(l1)
            ? std::tuple{skip_line(l1), Text::lit("end")}
            : ({
            auto l2 = indented_line(l1, col, line_begin);
            std::tuple{l2, Text::lit("tokens")};
        });
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::Lex, Text>> BeginLine::cycle() const {
    const auto& l0 = this->l0;
    auto line_begin = l0.pos;
    auto l0_1 = l0;
    return call_then(start_indentation(l0_1), [=](std::tuple<crate::syntax::lexer::Lex, Nat> indentation_6650) {
        return ({
            auto [l1, col] = indentation_6650;
            ({
            auto&& _m = crate::syntax::lexer::chars::peek(l1);
            ({
            auto&& m6669_0 = _m;
            (m6669_0 == Text::lit(""));
        }) ? ({
            auto&& m6669_0 = _m;
            prism_rtl::finished(std::tuple{l1, Text::lit("end")});
        })
            : ({
            auto&& m6669_1 = _m;
            (m6669_1 == Text::lit("\n"));
        }) ? ({
            auto&& m6669_1 = _m;
            prism_rtl::finished(std::tuple{crate::syntax::lexer::chars::bump(l1), Text::lit("skip")});
        })
            : ({
            auto&& m6669_2 = _m;
            (m6669_2 == Text::lit("#"));
        }) ? ({
            auto&& m6669_2 = _m;
            ({
            auto l2 = ({
                crate::syntax::lexer::Lex this_ = l1;
                this_.pos = crate::syntax::lexer::chars::line_end(this_);
                this_;
            });
            (crate::syntax::lexer::chars::peek(l2) == Text::lit("\n")
            ? prism_rtl::finished(std::tuple{crate::syntax::lexer::chars::bump(l2), Text::lit("skip")})
            : prism_rtl::finished(std::tuple{l2, Text::lit("end")}));
        });
        })
            : call_then(start_closes_brace_block(l1), [=](bool closes_brace_block_7024) {
            return closes_brace_block_7024
                ? call_then(start_skip_line(l1), [=](crate::syntax::lexer::Lex skip_line_7047) { return prism_rtl::finished(std::tuple{skip_line_7047, Text::lit("end")}); })
                : call_then(start_indented_line(l1, col, line_begin), [=](crate::syntax::lexer::Lex indented_line_7111) {
                return ({
                    auto l2 = indented_line_7111;
                    (prism_rtl::finished(std::tuple{l2, Text::lit("tokens")}));
                });
            });
        });
        });
        });
    });
}


/// `Start BeginLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::Lex, Text>> start_begin_line(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<BeginLine>(l0);
}


/// Indentation: unbounded fn Lex -> ((Lex, Nat))
std::tuple<crate::syntax::lexer::Lex, Nat> indentation(const crate::syntax::lexer::Lex& l0) {
    std::tuple<crate::syntax::lexer::Lex, Nat> this_ = std::tuple{l0, Nat(0u)};
    crate::syntax::lexer::Lex l = l0;
    Nat col = Nat(0u);
    bool going = true;
    while (going) {
        ({
            __label__ _done;
            prism_rtl::Slot<Unit> _v;
            auto&& _m = crate::syntax::lexer::chars::peek(l);
            {
                auto&& u7432_0 = _m;
                if (u7432_0 == Text::lit(" ")) {
                    _v.set(({
                        l = crate::syntax::lexer::chars::bump(l);
                        col = col + Nat(1u);
                        Unit{};
                    }));
                    goto _done;
                }
            }
            {
                auto&& u7432_1 = _m;
                if (u7432_1 == Text::lit("\t")) {
                    _v.set(({
                        l = crate::syntax::lexer::chars::lex_err(crate::syntax::lexer::chars::bump(l), l.pos, l.pos + Nat(1u), Text::lit("a tab in leading whitespace is an error: indent with spaces"));
                        col = col + Nat(1u);
                        Unit{};
                    }));
                    goto _done;
                }
            }
            {
                auto&& u7432_2 = _m;
                if (u7432_2 == Text::lit("\r")) {
                    _v.set(({
                        l = crate::syntax::lexer::chars::bump(l);
                        Unit{};
                    }));
                    goto _done;
                }
            }
            {
                _v.set(({
                    going = false;
                    Unit{};
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    this_ = std::tuple{l, col};
    return this_;
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::Lex, Nat>> Indentation::cycle() const {
    const auto& l0 = this->l0;
    std::tuple<crate::syntax::lexer::Lex, Nat> this_ = std::tuple{l0, Nat(0u)};
    crate::syntax::lexer::Lex l = l0;
    Nat col = Nat(0u);
    bool going = true;
    return call_then(loop_job(std::tuple{this_, col, going, l}, [=](std::tuple<std::tuple<crate::syntax::lexer::Lex, Nat>, Nat, bool, crate::syntax::lexer::Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        auto col = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto l = std::get<3>(_p0);
        return going
            ? ({
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = crate::syntax::lexer::chars::peek(l);
                {
                    auto&& u7432_0 = _m;
                    if (u7432_0 == Text::lit(" ")) {
                        _v.set(({
                            l = crate::syntax::lexer::chars::bump(l);
                            col = col + Nat(1u);
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u7432_1 = _m;
                    if (u7432_1 == Text::lit("\t")) {
                        _v.set(({
                            l = crate::syntax::lexer::chars::lex_err(crate::syntax::lexer::chars::bump(l), l.pos, l.pos + Nat(1u), Text::lit("a tab in leading whitespace is an error: indent with spaces"));
                            col = col + Nat(1u);
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u7432_2 = _m;
                    if (u7432_2 == Text::lit("\r")) {
                        _v.set(({
                            l = crate::syntax::lexer::chars::bump(l);
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        going = false;
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            Expected<std::tuple<std::tuple<crate::syntax::lexer::Lex, Nat>, Nat, bool, crate::syntax::lexer::Lex>, std::tuple<std::tuple<crate::syntax::lexer::Lex, Nat>, Nat, bool, crate::syntax::lexer::Lex>>(std::tuple{this_, col, going, l});
        })
            : Expected<std::tuple<std::tuple<crate::syntax::lexer::Lex, Nat>, Nat, bool, crate::syntax::lexer::Lex>, std::tuple<std::tuple<crate::syntax::lexer::Lex, Nat>, Nat, bool, crate::syntax::lexer::Lex>>(unexpected(std::tuple{this_, col, going, l}));
    }), [=](std::tuple<std::tuple<crate::syntax::lexer::Lex, Nat>, Nat, bool, crate::syntax::lexer::Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        auto col = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto l = std::get<3>(_p0);
        return ({
            this_ = std::tuple{l, col};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start Indentation, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::Lex, Nat>> start_indentation(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<Indentation>(l0);
}


/// ClosesBraceBlock: unbounded fn Lex -> Bool
bool closes_brace_block(const crate::syntax::lexer::Lex& l) {
    auto&& _m = l->mode;
    if (prism_rtl::is<crate::syntax::lexer::Mode::MBrace>(_m)) {
        auto&& m7910_0_0 = prism_rtl::as<crate::syntax::lexer::Mode::MBrace>(_m).a0;
        if (m7910_0_0 == Text::lit("double")) {
            return crate::syntax::lexer::chars::trim_end(crate::syntax::lexer::chars::rest_of_line(l)) == Text::lit("}}");
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::Mode::MBrace>(_m)) {
        return crate::syntax::lexer::chars::trim_end(crate::syntax::lexer::chars::rest_of_line(l)) == Text::lit("}");
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> ClosesBraceBlock::cycle() const {
    const auto& l = this->l;
    return ({
        auto&& _m = l->mode;
        prism_rtl::is<crate::syntax::lexer::Mode::MBrace>(_m) && ({
        auto&& m7910_0_0 = prism_rtl::as<crate::syntax::lexer::Mode::MBrace>(_m).a0;
        (m7910_0_0 == Text::lit("double"));
    }) ? ({
        auto&& m7910_0_0 = prism_rtl::as<crate::syntax::lexer::Mode::MBrace>(_m).a0;
        ({
        auto l_1 = l;
        call_then(crate::syntax::lexer::chars::start_rest_of_line(l_1), [=](Text rest_of_line_7955) { return prism_rtl::finished(crate::syntax::lexer::chars::trim_end(rest_of_line_7955) == Text::lit("}}")); });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::Mode::MBrace>(_m) ? ({
        auto l_1 = l;
        call_then(crate::syntax::lexer::chars::start_rest_of_line(l_1), [=](Text rest_of_line_8009) { return prism_rtl::finished(crate::syntax::lexer::chars::trim_end(rest_of_line_8009) == Text::lit("}")); });
    })
        : prism_rtl::finished(false);
    });
}


/// `Start ClosesBraceBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_closes_brace_block(crate::syntax::lexer::Lex l) {
    return prism_rtl::make_rc<ClosesBraceBlock>(l);
}


/// SkipLine: unbounded fn Lex -> Lex
crate::syntax::lexer::Lex skip_line(const crate::syntax::lexer::Lex& l0) {
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = crate::syntax::lexer::chars::line_end(this_);
        this_;
    });
    return crate::syntax::lexer::chars::peek(l) == Text::lit("\n")
        ? crate::syntax::lexer::chars::bump(l)
        : l;
}


prism_rtl::Turn<crate::syntax::lexer::Lex> SkipLine::cycle() const {
    const auto& l0 = this->l0;
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = crate::syntax::lexer::chars::line_end(this_);
        this_;
    });
    return crate::syntax::lexer::chars::peek(l) == Text::lit("\n")
        ? prism_rtl::finished(crate::syntax::lexer::chars::bump(l))
        : prism_rtl::finished(l);
}


/// `Start SkipLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_skip_line(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<SkipLine>(l0);
}


/// IndentedLine: unbounded fn Lex, Nat, Nat -> Lex
crate::syntax::lexer::Lex indented_line(const crate::syntax::lexer::Lex& l0, const Nat& col, const Nat& line_begin) {
    auto here = l0.pos;
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.line_first = len(this_.tokens);
        this_.last_ws = true;
        this_;
    });
    return l.first_line
        ? first_line(l, col, line_begin, here)
        : layout_line(l, col, line_begin, here);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> IndentedLine::cycle() const {
    const auto& l0 = this->l0;
    const auto& col = this->col;
    const auto& line_begin = this->line_begin;
    auto here = l0.pos;
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.line_first = len(this_.tokens);
        this_.last_ws = true;
        this_;
    });
    return l.first_line
        ? prism_rtl::finished(first_line(l, col, line_begin, here))
        : prism_rtl::finished(layout_line(l, col, line_begin, here));
}


/// `Start IndentedLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_indented_line(crate::syntax::lexer::Lex l0, Nat col, Nat line_begin) {
    return prism_rtl::make_rc<IndentedLine>(l0, col, line_begin);
}


/// FirstLine: fn Lex, Nat, Nat, Nat -> Lex
crate::syntax::lexer::Lex first_line(const crate::syntax::lexer::Lex& l0, const Nat& col, const Nat& line_begin, const Nat& here) {
    crate::syntax::lexer::Lex this_ = l0;
    this_.first_line = false;
    if (this_.mode == crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MFile{})) {
        this_.layout = Array(std::vector{Nat(0u)});
        if (col != Nat(0u)) {
            this_ = crate::syntax::lexer::chars::lex_err(this_, line_begin, here, Text::lit("the first line of a file starts at column 0"));
            this_.layout = Array(std::vector{col});
        }
    } else  {
        this_.layout = crate::prelude::push(this_.layout, col);
    }
    return this_;
}


/// Below: fn ?Nat, Nat -> Bool
bool below(const std::optional<Nat>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return false;
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& d = prism_rtl::some_of(std::get<0>(_m));
        auto&& depth = std::get<1>(_m);
        return depth < d;
    }
    prism_rtl::unreachable("no arm matched");
}


/// LayoutLine: fn Lex, Nat, Nat, Nat -> Lex
crate::syntax::lexer::Lex layout_line(const crate::syntax::lexer::Lex& l0, const Nat& col, const Nat& line_begin, const Nat& here) {
    crate::syntax::lexer::Lex this_ = l0;
    auto top = or_(crate::syntax::lexer::chars::last(this_.layout), Nat(0u));
    auto fat = crate::syntax::lexer::chars::starts_with(this_, Text::lit("=>"));
    bool opened = false;
    Nat fuel = len(this_.layout);
    if (this_.pending_open) {
        this_.pending_open = false;
        if (col > top) {
            this_.layout = crate::prelude::push(this_.layout, col);
            this_ = crate::syntax::lexer::push_tok(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{}), here, here);
            if (this_.test_pending == Text::lit("test")) {
                this_.test_depth = std::optional(len(this_.layout));
            }
            if (this_.test_pending == Text::lit("check")) {
                this_.check_depth = std::optional(len(this_.layout));
            }
            this_.test_pending = Text::lit("");
            opened = true;
        } else  {
            this_.diags = crate::prelude::push(this_.diags, crate::syntax::lexer::chars::lex_diag(this_.pending_span, Text::lit("expected an indented block after `:`")));
        }
    }
    if (!opened) {
        if (((col > top) && fat) && (this_.test_depth == std::optional(len(this_.layout)))) {
            this_.layout = crate::prelude::push(this_.layout, col);
            this_ = crate::syntax::lexer::push_tok(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{}), here, here);
        } else if (col == top) {
            this_ = crate::syntax::lexer::push_tok(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLaySep{}), here, here);
            if (len(this_.layout) == Nat(1u)) {
                this_.test_pending = Text::lit("");
            }
        } else if (col > top) {
            this_.mark_line_start = true;
        } else  {
            while (true) {
                auto&& _m = fuel.checked_sub(Nat(1u));
                if (!(prism_rtl::is_some(_m))) break;
                auto&& left = prism_rtl::some_of(_m);
                if (!((len(this_.layout) > Nat(1u)) && (col < or_(crate::syntax::lexer::chars::last(this_.layout), Nat(0u))))) {
                    break;
                }
                fuel = left;
                this_.layout = crate::syntax::lexer::chars::pop(this_.layout);
                this_ = crate::syntax::lexer::push_tok(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayClose{}), here, here);
                auto depth = len(this_.layout);
                if (below(this_.test_depth, depth)) {
                    this_.test_depth = std::optional<Nat>{};
                }
                if (below(this_.check_depth, depth)) {
                    this_.check_depth = std::optional<Nat>{};
                }
            }
            if (col != or_(crate::syntax::lexer::chars::last(this_.layout), Nat(0u))) {
                this_ = crate::syntax::lexer::chars::lex_err(this_, line_begin, here, Text::lit("unindent does not match any open block"));
            }
            this_ = crate::syntax::lexer::push_tok(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLaySep{}), here, here);
            if (len(this_.layout) == Nat(1u)) {
                this_.test_pending = Text::lit("");
            }
        }
    }
    return this_;
}

}  // namespace crate::syntax::lexer::layout
