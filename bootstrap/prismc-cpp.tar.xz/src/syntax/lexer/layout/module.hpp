// The module `Syntax.Lexer.Layout`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/lexer/layout/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::lexer::layout {

crate::syntax::lexer::Lexed lex_file_f(const Text& src_p0);

prism_rtl::JobRef<crate::syntax::lexer::Lexed> start_lex_file_f(Text src_p0);

std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> template_head_f(const crate::syntax::lexer::Lex& l0_p0);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex>> start_template_head_f(crate::syntax::lexer::Lex l0_p0);

crate::syntax::lexer::Lex skip_blank_and_comment_lines_f(const crate::syntax::lexer::Lex& l_p0);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_skip_blank_and_comment_lines_f(crate::syntax::lexer::Lex l_p0);

std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> nested_f(const crate::syntax::lexer::Lex& l_p0, const crate::syntax::lexer::Mode& mode_p1);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex>> start_nested_f(crate::syntax::lexer::Lex l_p0, crate::syntax::lexer::Mode mode_p1);

crate::syntax::lexer::Lex lex_stream_f(const crate::syntax::lexer::Lex& l0_p0);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_stream_f(crate::syntax::lexer::Lex l0_p0);

crate::syntax::lexer::Lex unclosed_stream_f(const crate::syntax::lexer::Lex& l_p0);

std::tuple<bool, crate::syntax::lexer::Lex> stream_ends_here_f(const crate::syntax::lexer::Lex& l_p0);

crate::syntax::lexer::Lex end_line_f(const crate::syntax::lexer::Lex& l_p0);

bool opens_block_f(const crate::syntax::lexer::TokKind& tok_kind0);

std::tuple<crate::syntax::lexer::Lex, Text> begin_line_f(const crate::syntax::lexer::Lex& l0_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::lexer::Lex, Text>> start_begin_line_f(crate::syntax::lexer::Lex l0_p0);

std::tuple<crate::syntax::lexer::Lex, Nat> indentation_f(const crate::syntax::lexer::Lex& l0_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::lexer::Lex, Nat>> start_indentation_f(crate::syntax::lexer::Lex l0_p0);

bool closes_brace_block_f(const crate::syntax::lexer::Lex& l_p0);

prism_rtl::JobRef<bool> start_closes_brace_block_f(crate::syntax::lexer::Lex l_p0);

crate::syntax::lexer::Lex skip_line_f(const crate::syntax::lexer::Lex& l0_p0);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_skip_line_f(crate::syntax::lexer::Lex l0_p0);

crate::syntax::lexer::Lex indented_line_f(const crate::syntax::lexer::Lex& l0_p0, const Nat& col_p1, const Nat& line_begin_p2);

prism_rtl::JobRef<crate::syntax::lexer::Lex> start_indented_line_f(crate::syntax::lexer::Lex l0_p0, Nat col_p1, Nat line_begin_p2);

crate::syntax::lexer::Lex first_line_f(const crate::syntax::lexer::Lex& l0_p0, const Nat& col_p1, const Nat& line_begin_p2, const Nat& here_p3);

bool below_f(const std::optional<Nat>& opt0, const Nat& n1);

crate::syntax::lexer::Lex layout_line_f(const crate::syntax::lexer::Lex& l0_p0, const Nat& col_p1, const Nat& line_begin_p2, const Nat& here_p3);

}  // namespace syntax::lexer::layout


namespace syntax::lexer::layout {

/// The step machine of `LexFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexFile: unbounded fn Text -> Lexed
struct LexFile : prism_rtl::Job<crate::syntax::lexer::Lexed> {
    Text src_p0;
    LexFile(Text src_p0) : src_p0(std::move(src_p0)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lexed> cycle() const override;
};


/// The step machine of `TemplateHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateHead: unbounded fn Lex -> (([Tok], Lex))
struct TemplateHead : prism_rtl::Job<std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l0_p0;
    TemplateHead(crate::syntax::lexer::Lex l0_p0) : l0_p0(std::move(l0_p0)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `SkipBlankAndCommentLines`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SkipBlankAndCommentLines: unbounded fn Lex -> Lex
struct SkipBlankAndCommentLines : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l_p0;
    SkipBlankAndCommentLines(crate::syntax::lexer::Lex l_p0) : l_p0(std::move(l_p0)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `Nested`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Nested: unbounded fn Lex, Mode -> (([Tok], Lex))
struct Nested : prism_rtl::Job<std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex>> {
    crate::syntax::lexer::Lex l_p0;
    crate::syntax::lexer::Mode mode_p1;
    Nested(crate::syntax::lexer::Lex l_p0, crate::syntax::lexer::Mode mode_p1) : l_p0(std::move(l_p0)), mode_p1(std::move(mode_p1)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex>> cycle() const override;
};


/// The step machine of `LexStream`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexStream: unbounded fn Lex -> Lex
struct LexStream : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l0_p0;
    LexStream(crate::syntax::lexer::Lex l0_p0) : l0_p0(std::move(l0_p0)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `BeginLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BeginLine: unbounded fn Lex -> ((Lex, Text))
struct BeginLine : prism_rtl::Job<std::tuple<crate::syntax::lexer::Lex, Text>> {
    crate::syntax::lexer::Lex l0_p0;
    BeginLine(crate::syntax::lexer::Lex l0_p0) : l0_p0(std::move(l0_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::lexer::Lex, Text>> cycle() const override;
};


/// The step machine of `Indentation`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Indentation: unbounded fn Lex -> ((Lex, Nat))
struct Indentation : prism_rtl::Job<std::tuple<crate::syntax::lexer::Lex, Nat>> {
    crate::syntax::lexer::Lex l0_p0;
    Indentation(crate::syntax::lexer::Lex l0_p0) : l0_p0(std::move(l0_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::lexer::Lex, Nat>> cycle() const override;
};


/// The step machine of `ClosesBraceBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClosesBraceBlock: unbounded fn Lex -> Bool
struct ClosesBraceBlock : prism_rtl::Job<bool> {
    crate::syntax::lexer::Lex l_p0;
    ClosesBraceBlock(crate::syntax::lexer::Lex l_p0) : l_p0(std::move(l_p0)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SkipLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SkipLine: unbounded fn Lex -> Lex
struct SkipLine : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l0_p0;
    SkipLine(crate::syntax::lexer::Lex l0_p0) : l0_p0(std::move(l0_p0)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


/// The step machine of `IndentedLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IndentedLine: unbounded fn Lex, Nat, Nat -> Lex
struct IndentedLine : prism_rtl::Job<crate::syntax::lexer::Lex> {
    crate::syntax::lexer::Lex l0_p0;
    Nat col_p1;
    Nat line_begin_p2;
    IndentedLine(crate::syntax::lexer::Lex l0_p0, Nat col_p1, Nat line_begin_p2) : l0_p0(std::move(l0_p0)), col_p1(std::move(col_p1)), line_begin_p2(std::move(line_begin_p2)) {}
    prism_rtl::Turn<crate::syntax::lexer::Lex> cycle() const override;
};


}  // namespace syntax::lexer::layout

}  // namespace crate
