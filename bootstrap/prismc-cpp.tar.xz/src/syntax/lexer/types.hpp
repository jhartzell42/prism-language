// The module `Syntax.Lexer`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/lexer/decl.hpp>
#include "elem.decl.hpp"
#include <syntax/decls/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/regexes/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <syntax/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::lexer {

/// `AttrTok`:
///
/// ```prism
/// type AttrTok = record:
/// ```
struct AttrTok {
    using prism_value = void;
    Text name;
    Array<Tok> tokens;
    crate::syntax::Range span;
    const AttrTok* operator->() const { return this; }
    AttrTok* operator->() { return this; }
    bool operator==(const AttrTok&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<AttrTok> from_pod(const Pod& whole);
};


}  // namespace syntax::lexer

namespace syntax::lexer {

/// `Lex`:
///
/// ```prism
/// type Lex = record:
/// ```
struct Lex {
    using prism_value = void;
    Text src;
    Nat pos;
    Array<crate::syntax::Diag> diags;
    Mode mode;
    Array<Tok> tokens;
    Array<Nat> layout;
    Array<Text> frames;
    bool last_ws;
    bool lambda_open;
    bool pending_open;
    crate::syntax::Range pending_span;
    Nat line_first;
    bool mark_line_start;
    bool first_line;
    Text test_pending;
    std::optional<Nat> test_depth;
    std::optional<Nat> check_depth;
    bool path_next;
    const Lex* operator->() const { return this; }
    Lex* operator->() { return this; }
    bool operator==(const Lex&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Lex> from_pod(const Pod& whole);
};


}  // namespace syntax::lexer

namespace syntax::lexer {

/// `Lexed`:
///
/// ```prism
/// type Lexed = record:
/// ```
struct Lexed {
    using prism_value = void;
    Array<Tok> tokens;
    Array<crate::syntax::Diag> diags;
    const Lexed* operator->() const { return this; }
    Lexed* operator->() { return this; }
    bool operator==(const Lexed&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Lexed> from_pod(const Pod& whole);
};


}  // namespace syntax::lexer

namespace syntax::lexer {

/// `NameTok`:
///
/// ```prism
/// type NameTok = record:
/// ```
struct NameTok {
    using prism_value = void;
    Text sigils;
    Array<Text> path_;
    NameCase case_;
    const NameTok* operator->() const { return this; }
    NameTok* operator->() { return this; }
    bool operator==(const NameTok&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<NameTok> from_pod(const Pod& whole);
};


}  // namespace syntax::lexer

namespace syntax::lexer {

/// `TemplateTok`:
///
/// ```prism
/// type TemplateTok = record:
/// ```
struct TemplateTok {
    using prism_value = void;
    Text keyword;
    Text lang;
    Text delims;
    Array<TPartTok> parts;
    const TemplateTok* operator->() const { return this; }
    TemplateTok* operator->() { return this; }
    bool operator==(const TemplateTok&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TemplateTok> from_pod(const Pod& whole);
};


}  // namespace syntax::lexer

namespace syntax::lexer {

/// `Tok`:
///
/// ```prism
/// type Tok = record:
/// ```
struct Tok {
    using prism_value = void;
    TokKind kind;
    crate::syntax::Range span;
    bool touches;
    bool line_start;
    const Tok* operator->() const { return this; }
    Tok* operator->() { return this; }
    bool operator==(const Tok&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Tok> from_pod(const Pod& whole);
};


}  // namespace syntax::lexer

namespace syntax::lexer {

struct Mode::MFile {
    bool operator==(const MFile&) const = default;
};


struct Mode::MBrace {
    Text a0;
    bool operator==(const MBrace&) const = default;
};


struct Mode::MPlaceholder {
    Text a0;
    bool operator==(const MPlaceholder&) const = default;
};


struct Mode::MPathKey {
    bool operator==(const MPathKey&) const = default;
};


inline const Mode::Cases& Mode::cases() const { return *cases_; }

inline bool operator==(const Mode& a, const Mode& b) { return a.cases() == b.cases(); }

struct NameCase::CaseLower {
    bool operator==(const CaseLower&) const = default;
};


struct NameCase::CaseUpper {
    bool operator==(const CaseUpper&) const = default;
};


struct NameCase::CaseTopic {
    bool operator==(const CaseTopic&) const = default;
};


struct NameCase::CaseHole {
    bool operator==(const CaseHole&) const = default;
};


struct NameCase::CaseReserved {
    bool operator==(const CaseReserved&) const = default;
};


inline const NameCase::Cases& NameCase::cases() const { return *cases_; }

inline bool operator==(const NameCase& a, const NameCase& b) { return a.cases() == b.cases(); }

struct PathSegTok::PstNum {
    Nat a0;
    bool operator==(const PstNum&) const = default;
};


struct PathSegTok::PstGen {
    Nat a0;
    bool operator==(const PstGen&) const = default;
};


struct PathSegTok::PstKey {
    Array<Tok> a0;
    bool operator==(const PstKey&) const = default;
};


inline const PathSegTok::Cases& PathSegTok::cases() const { return *cases_; }

inline bool operator==(const PathSegTok& a, const PathSegTok& b) { return a.cases() == b.cases(); }

struct TPartTok::TptText {
    Text a0;
    bool operator==(const TptText&) const = default;
};


struct TPartTok::TptPlaceholder {
    Array<Tok> a0;
    std::optional<Nat> a1;
    crate::syntax::Range a2;
    bool operator==(const TptPlaceholder&) const = default;
};


struct TPartTok::TptBlock {
    Array<Tok> a0;
    crate::syntax::Range a1;
    bool operator==(const TptBlock&) const = default;
};


struct TPartTok::TptCall {
    NameTok a0;
    Array<AttrTok> a1;
    std::optional<Array<TPartTok>> a2;
    crate::syntax::Range a3;
    bool operator==(const TptCall&) const = default;
};


inline const TPartTok::Cases& TPartTok::cases() const { return *cases_; }

inline bool operator==(const TPartTok& a, const TPartTok& b) { return a.cases() == b.cases(); }

struct TextSegTok::TsPlain {
    Text a0;
    bool operator==(const TsPlain&) const = default;
};


struct TextSegTok::TsPlaceholder {
    Array<Tok> a0;
    crate::syntax::Range a1;
    bool operator==(const TsPlaceholder&) const = default;
};


inline const TextSegTok::Cases& TextSegTok::cases() const { return *cases_; }

inline bool operator==(const TextSegTok& a, const TextSegTok& b) { return a.cases() == b.cases(); }

struct TokKind::KName {
    NameTok a0;
    bool operator==(const KName&) const = default;
};


struct TokKind::KFamily {
    Array<Text> a0;
    bool operator==(const KFamily&) const = default;
};


struct TokKind::KTrait {
    Array<Text> a0;
    bool operator==(const KTrait&) const = default;
};


struct TokKind::KKw {
    Text a0;
    Text a1;
    bool operator==(const KKw&) const = default;
};


struct TokKind::KFree {
    Text a0;
    bool operator==(const KFree&) const = default;
};


struct TokKind::KLensDot {
    bool operator==(const KLensDot&) const = default;
};


struct TokKind::KInt {
    Text a0;
    Text a1;
    bool operator==(const KInt&) const = default;
};


struct TokKind::KFloat {
    Text a0;
    Text a1;
    bool operator==(const KFloat&) const = default;
};


struct TokKind::KDuration {
    Text a0;
    Text a1;
    Text a2;
    bool operator==(const KDuration&) const = default;
};


struct TokKind::KChar {
    Text a0;
    Text a1;
    bool operator==(const KChar&) const = default;
};


struct TokKind::KText {
    Text a0;
    Array<TextSegTok> a1;
    bool operator==(const KText&) const = default;
};


struct TokKind::KRegex {
    Text a0;
    crate::syntax::RegexLit a1;
    bool operator==(const KRegex&) const = default;
};


struct TokKind::KTemplate {
    TemplateTok a0;
    bool operator==(const KTemplate&) const = default;
};


struct TokKind::KOp {
    Text a0;
    bool a1;
    bool operator==(const KOp&) const = default;
};


struct TokKind::KSuffixed {
    Text a0;
    Array<Text> a1;
    bool operator==(const KSuffixed&) const = default;
};


struct TokKind::KDot {
    bool a0;
    bool operator==(const KDot&) const = default;
};


struct TokKind::KDotDot {
    bool operator==(const KDotDot&) const = default;
};


struct TokKind::KComma {
    bool operator==(const KComma&) const = default;
};


struct TokKind::KColon {
    bool operator==(const KColon&) const = default;
};


struct TokKind::KSemi {
    bool operator==(const KSemi&) const = default;
};


struct TokKind::KBackslash {
    bool operator==(const KBackslash&) const = default;
};


struct TokKind::KLambdaBar {
    bool a0;
    bool operator==(const KLambdaBar&) const = default;
};


struct TokKind::KBar {
    bool operator==(const KBar&) const = default;
};


struct TokKind::KLtLt {
    bool operator==(const KLtLt&) const = default;
};


struct TokKind::KGtGt {
    bool operator==(const KGtGt&) const = default;
};


struct TokKind::KOpen {
    Text a0;
    bool a1;
    bool operator==(const KOpen&) const = default;
};


struct TokKind::KClose {
    Text a0;
    bool operator==(const KClose&) const = default;
};


struct TokKind::KAbsent {
    bool operator==(const KAbsent&) const = default;
};


struct TokKind::KNonEmpty {
    bool operator==(const KNonEmpty&) const = default;
};


struct TokKind::KPath {
    Array<PathSegTok> a0;
    bool operator==(const KPath&) const = default;
};


struct TokKind::KLayOpen {
    bool operator==(const KLayOpen&) const = default;
};


struct TokKind::KLaySep {
    bool operator==(const KLaySep&) const = default;
};


struct TokKind::KLayClose {
    bool operator==(const KLayClose&) const = default;
};


struct TokKind::KEof {
    bool operator==(const KEof&) const = default;
};


inline const TokKind::Cases& TokKind::cases() const { return *cases_; }

inline bool operator==(const TokKind& a, const TokKind& b) { return a.cases() == b.cases(); }

}  // namespace syntax::lexer

}  // namespace crate
