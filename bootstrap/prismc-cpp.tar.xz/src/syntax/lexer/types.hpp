// The module `Syntax.Lexer`: its value types (records, tags, newtypes and choices with their cases), each
// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism
// source, not this file.
#pragma once

#include <syntax/lexer/decl.hpp>
#include "elem.decl.hpp"
#include <syntax/decls/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/regexes/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <syntax/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::lexer {

/// `AttrTok`:
///
/// ```prism
/// type AttrTok = record:
/// ```
struct AttrTok {
    using prism_value = void;
    Text name_p;
    Array<Tok> tokens_p;
    crate::syntax::Range span_p;
    const AttrTok* operator->() const { return this; }
    AttrTok* operator->() { return this; }
    bool operator==(const AttrTok&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<AttrTok> from_pod(const Pod& whole);
};


}  // namespace syntax::lexer

namespace syntax::lexer {

/// `Lexed`:
///
/// ```prism
/// type Lexed = record:
/// ```
struct Lexed {
    using prism_value = void;
    Array<Tok> tokens_p;
    Array<crate::syntax::Diag> diags_p;
    const Lexed* operator->() const { return this; }
    Lexed* operator->() { return this; }
    bool operator==(const Lexed&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Lexed> from_pod(const Pod& whole);
};


}  // namespace syntax::lexer

namespace syntax::lexer {

/// `Mode`:
///
/// ```prism
/// type Mode = choice:
/// ```
class Mode {
public:
    using prism_value = void;
    struct MFile {
        bool operator==(const MFile&) const = default;
    };

    struct MBrace {
        Text a0;
        bool operator==(const MBrace&) const = default;
    };

    struct MPlaceholder {
        Text a0;
        bool operator==(const MPlaceholder&) const = default;
    };

    struct MPathKey {
        bool operator==(const MPathKey&) const = default;
    };
    using Cases = std::variant<MFile, MBrace, MPlaceholder, MPathKey>;
    template <class C>
        requires prism_rtl::one_of<C, MFile, MBrace, MPlaceholder, MPathKey>
    Mode(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Mode> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const Mode& a, const Mode& b) { return a.cases() == b.cases(); }

}  // namespace syntax::lexer

namespace syntax::lexer {

/// `NameCase`:
///
/// ```prism
/// type NameCase = choice:
/// ```
class NameCase {
public:
    using prism_value = void;
    struct CaseLower {
        bool operator==(const CaseLower&) const = default;
    };

    struct CaseUpper {
        bool operator==(const CaseUpper&) const = default;
    };

    struct CaseTopic {
        bool operator==(const CaseTopic&) const = default;
    };

    struct CaseHole {
        bool operator==(const CaseHole&) const = default;
    };

    struct CaseReserved {
        bool operator==(const CaseReserved&) const = default;
    };
    using Cases = std::variant<CaseLower, CaseUpper, CaseTopic, CaseHole, CaseReserved>;
    template <class C>
        requires prism_rtl::one_of<C, CaseLower, CaseUpper, CaseTopic, CaseHole, CaseReserved>
    NameCase(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<NameCase> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const NameCase& a, const NameCase& b) { return a.cases() == b.cases(); }

}  // namespace syntax::lexer

namespace syntax::lexer {

/// `PathSegTok`:
///
/// ```prism
/// type PathSegTok = choice:
/// ```
class PathSegTok {
public:
    using prism_value = void;
    struct PstNum {
        Nat a0;
        bool operator==(const PstNum&) const = default;
    };

    struct PstGen {
        Nat a0;
        bool operator==(const PstGen&) const = default;
    };

    struct PstKey {
        Array<Tok> a0;
        bool operator==(const PstKey&) const;
    };
    using Cases = std::variant<PstNum, PstGen, PstKey>;
    template <class C>
        requires prism_rtl::one_of<C, PstNum, PstGen, PstKey>
    PathSegTok(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<PathSegTok> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const PathSegTok& a, const PathSegTok& b) { return a.cases() == b.cases(); }

}  // namespace syntax::lexer

namespace syntax::lexer {

/// `TemplateTok`:
///
/// ```prism
/// type TemplateTok = record:
/// ```
struct TemplateTok {
    using prism_value = void;
    Text keyword_p;
    Text lang_p;
    Text delims_p;
    Array<TPartTok> parts_p;
    const TemplateTok* operator->() const { return this; }
    TemplateTok* operator->() { return this; }
    bool operator==(const TemplateTok&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TemplateTok> from_pod(const Pod& whole);
};


}  // namespace syntax::lexer

namespace syntax::lexer {

/// `TextSegTok`:
///
/// ```prism
/// type TextSegTok = choice:
/// ```
class TextSegTok {
public:
    using prism_value = void;
    struct TsPlain {
        Text a0;
        bool operator==(const TsPlain&) const = default;
    };

    struct TsPlaceholder {
        Array<Tok> a0;
        crate::syntax::Range a1;
        bool operator==(const TsPlaceholder&) const;
    };
    using Cases = std::variant<TsPlain, TsPlaceholder>;
    template <class C>
        requires prism_rtl::one_of<C, TsPlain, TsPlaceholder>
    TextSegTok(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TextSegTok> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const TextSegTok& a, const TextSegTok& b) { return a.cases() == b.cases(); }

}  // namespace syntax::lexer

namespace syntax::lexer {

/// `Lex`:
///
/// ```prism
/// type Lex = record:
/// ```
struct Lex {
    using prism_value = void;
    Text src_p;
    Nat pos_p;
    Array<crate::syntax::Diag> diags_p;
    Mode mode_p;
    Array<Tok> tokens_p;
    Array<Nat> layout_p;
    Array<Text> frames_p;
    bool last_ws_p;
    bool lambda_open_p;
    bool pending_open_p;
    crate::syntax::Range pending_span_p;
    Nat line_first_p;
    bool mark_line_start_p;
    bool first_line_p;
    Text test_pending_p;
    std::optional<Nat> test_depth_o;
    std::optional<Nat> check_depth_o;
    bool path_next_p;
    const Lex* operator->() const { return this; }
    Lex* operator->() { return this; }
    bool operator==(const Lex&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Lex> from_pod(const Pod& whole);
};


}  // namespace syntax::lexer

namespace syntax::lexer {

/// `NameTok`:
///
/// ```prism
/// type NameTok = record:
/// ```
struct NameTok {
    using prism_value = void;
    Text sigils_p;
    Array<Text> path_p;
    NameCase case_p;
    const NameTok* operator->() const { return this; }
    NameTok* operator->() { return this; }
    bool operator==(const NameTok&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<NameTok> from_pod(const Pod& whole);
};


}  // namespace syntax::lexer

namespace syntax::lexer {

/// `TPartTok`:
///
/// ```prism
/// type TPartTok = choice:
/// ```
class TPartTok {
public:
    using prism_value = void;
    struct TptText {
        Text a0;
        bool operator==(const TptText&) const = default;
    };

    struct TptPlaceholder {
        Array<Tok> a0;
        std::optional<Nat> a1;
        crate::syntax::Range a2;
        bool operator==(const TptPlaceholder&) const;
    };

    struct TptBlock {
        Array<Tok> a0;
        crate::syntax::Range a1;
        bool operator==(const TptBlock&) const;
    };

    struct TptCall {
        NameTok a0;
        Array<AttrTok> a1;
        std::optional<Array<TPartTok>> a2;
        crate::syntax::Range a3;
        bool operator==(const TptCall&) const;
    };
    using Cases = std::variant<TptText, TptPlaceholder, TptBlock, TptCall>;
    template <class C>
        requires prism_rtl::one_of<C, TptText, TptPlaceholder, TptBlock, TptCall>
    TPartTok(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TPartTok> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const TPartTok& a, const TPartTok& b) { return a.cases() == b.cases(); }

}  // namespace syntax::lexer

namespace syntax::lexer {

/// `TokKind`:
///
/// ```prism
/// type TokKind = choice:
/// ```
class TokKind {
public:
    using prism_value = void;
    struct KName {
        NameTok a0;
        bool operator==(const KName&) const = default;
    };

    struct KFamily {
        Array<Text> a0;
        bool operator==(const KFamily&) const = default;
    };

    struct KTrait {
        Array<Text> a0;
        bool operator==(const KTrait&) const = default;
    };

    struct KKw {
        Text a0;
        Text a1;
        bool operator==(const KKw&) const = default;
    };

    struct KFree {
        Text a0;
        bool operator==(const KFree&) const = default;
    };

    struct KLensDot {
        bool operator==(const KLensDot&) const = default;
    };

    struct KInt {
        Text a0;
        Text a1;
        bool operator==(const KInt&) const = default;
    };

    struct KFloat {
        Text a0;
        Text a1;
        bool operator==(const KFloat&) const = default;
    };

    struct KDuration {
        Text a0;
        Text a1;
        Text a2;
        bool operator==(const KDuration&) const = default;
    };

    struct KChar {
        Text a0;
        Text a1;
        bool operator==(const KChar&) const = default;
    };

    struct KText {
        Text a0;
        Array<TextSegTok> a1;
        bool operator==(const KText&) const;
    };

    struct KRegex {
        Text a0;
        crate::syntax::RegexLit a1;
        bool operator==(const KRegex&) const = default;
    };

    struct KTemplate {
        TemplateTok a0;
        bool operator==(const KTemplate&) const = default;
    };

    struct KOp {
        Text a0;
        bool a1;
        bool operator==(const KOp&) const = default;
    };

    struct KSuffixed {
        Text a0;
        Array<Text> a1;
        bool operator==(const KSuffixed&) const = default;
    };

    struct KDot {
        bool a0;
        bool operator==(const KDot&) const = default;
    };

    struct KDotDot {
        bool operator==(const KDotDot&) const = default;
    };

    struct KComma {
        bool operator==(const KComma&) const = default;
    };

    struct KColon {
        bool operator==(const KColon&) const = default;
    };

    struct KSemi {
        bool operator==(const KSemi&) const = default;
    };

    struct KBackslash {
        bool operator==(const KBackslash&) const = default;
    };

    struct KLambdaBar {
        bool a0;
        bool operator==(const KLambdaBar&) const = default;
    };

    struct KBar {
        bool operator==(const KBar&) const = default;
    };

    struct KLtLt {
        bool operator==(const KLtLt&) const = default;
    };

    struct KGtGt {
        bool operator==(const KGtGt&) const = default;
    };

    struct KOpen {
        Text a0;
        bool a1;
        bool operator==(const KOpen&) const = default;
    };

    struct KClose {
        Text a0;
        bool operator==(const KClose&) const = default;
    };

    struct KAbsent {
        bool operator==(const KAbsent&) const = default;
    };

    struct KNonEmpty {
        bool operator==(const KNonEmpty&) const = default;
    };

    struct KPath {
        Array<PathSegTok> a0;
        bool operator==(const KPath&) const;
    };

    struct KLayOpen {
        bool operator==(const KLayOpen&) const = default;
    };

    struct KLaySep {
        bool operator==(const KLaySep&) const = default;
    };

    struct KLayClose {
        bool operator==(const KLayClose&) const = default;
    };

    struct KEof {
        bool operator==(const KEof&) const = default;
    };
    using Cases = std::variant<KName, KFamily, KTrait, KKw, KFree, KLensDot, KInt, KFloat, KDuration, KChar, KText, KRegex, KTemplate, KOp, KSuffixed, KDot, KDotDot, KComma, KColon, KSemi, KBackslash, KLambdaBar, KBar, KLtLt, KGtGt, KOpen, KClose, KAbsent, KNonEmpty, KPath, KLayOpen, KLaySep, KLayClose, KEof>;
    template <class C>
        requires prism_rtl::one_of<C, KName, KFamily, KTrait, KKw, KFree, KLensDot, KInt, KFloat, KDuration, KChar, KText, KRegex, KTemplate, KOp, KSuffixed, KDot, KDotDot, KComma, KColon, KSemi, KBackslash, KLambdaBar, KBar, KLtLt, KGtGt, KOpen, KClose, KAbsent, KNonEmpty, KPath, KLayOpen, KLaySep, KLayClose, KEof>
    TokKind(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TokKind> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const TokKind& a, const TokKind& b) { return a.cases() == b.cases(); }

}  // namespace syntax::lexer

namespace syntax::lexer {

/// `Tok`:
///
/// ```prism
/// type Tok = record:
/// ```
struct Tok {
    using prism_value = void;
    TokKind kind_p;
    crate::syntax::Range span_p;
    bool touches_p;
    bool line_start_p;
    const Tok* operator->() const { return this; }
    Tok* operator->() { return this; }
    bool operator==(const Tok&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Tok> from_pod(const Pod& whole);
};


}  // namespace syntax::lexer

}  // namespace crate
