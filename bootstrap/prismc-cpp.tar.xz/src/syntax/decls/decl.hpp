// The module `Syntax.Decls`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace syntax::decls {

struct Bound;

struct Case_;

struct CheckDecl;

struct CheckLine;

struct Decl;

class DeclKind;

class DefName;

struct Delivery;

class DeliveryKind;

struct Entry;

struct Field;

class FnBody;

struct FnClause;

struct ImplDecl;

struct LetDecl;

class PathSeg;

struct Signature;

class StepAction;

struct TagDecl;

class Target;

struct TestCheck;

class TestCheckKind;

struct TestDecl;

struct TestPath;

struct TestStep;

struct TraitDecl;

class TraitItem;

class TypeBody;

struct TypeDecl;

struct WidgetDecl;

}  // namespace syntax::decls

}  // namespace crate
