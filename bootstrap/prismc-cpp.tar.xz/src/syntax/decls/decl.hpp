// The module `Syntax.Decls`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace syntax::decls {

struct Bound;

struct Case_;

struct CheckDecl;

struct CheckLine;

struct Decl;

class DeclKind;

class DefName;

struct Delivery;

class DeliveryKind;

struct Entry;

struct Field;

class FnBody;

struct FnClause;

struct ImplDecl;

struct LetDecl;

class PathSeg;

struct Signature;

class StepAction;

struct TagDecl;

class Target;

struct TestCheck;

class TestCheckKind;

struct TestDecl;

struct TestPath;

struct TestStep;

struct TraitDecl;

class TraitItem;

class TypeBody;

struct TypeDecl;

struct WidgetDecl;

}  // namespace syntax::decls

namespace syntax::decls {

/// `DeclKind`:
///
/// ```prism
/// type DeclKind = choice:
/// ```
class DeclKind {
public:
    using prism_value = void;
    struct DSignature;
    struct DFn;
    struct DLet;
    struct DWidget;
    struct DType;
    struct DTag;
    struct DDerive;
    struct DTrait;
    struct DImpl;
    struct DCheck;
    struct DTest;
    struct DStmt;
    using Cases = std::variant<DSignature, DFn, DLet, DWidget, DType, DTag, DDerive, DTrait, DImpl, DCheck, DTest, DStmt>;
    template <class C>
        requires prism_rtl::one_of<C, DSignature, DFn, DLet, DWidget, DType, DTag, DDerive, DTrait, DImpl, DCheck, DTest, DStmt>
    DeclKind(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<DeclKind> from_pod(const Pod& whole);
    friend inline bool operator==(const DeclKind& a, const DeclKind& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `DefName`:
///
/// ```prism
/// type DefName = choice:
/// ```
class DefName {
public:
    using prism_value = void;
    struct DefSName;
    struct DefOp;
    using Cases = std::variant<DefSName, DefOp>;
    template <class C>
        requires prism_rtl::one_of<C, DefSName, DefOp>
    DefName(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<DefName> from_pod(const Pod& whole);
    friend inline bool operator==(const DefName& a, const DefName& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `DeliveryKind`:
///
/// ```prism
/// type DeliveryKind = choice:
/// ```
class DeliveryKind {
public:
    using prism_value = void;
    struct DkSend;
    struct DkClick;
    struct DkAnswer;
    using Cases = std::variant<DkSend, DkClick, DkAnswer>;
    template <class C>
        requires prism_rtl::one_of<C, DkSend, DkClick, DkAnswer>
    DeliveryKind(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<DeliveryKind> from_pod(const Pod& whole);
    friend inline bool operator==(const DeliveryKind& a, const DeliveryKind& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `FnBody`:
///
/// ```prism
/// type FnBody = choice:
/// ```
class FnBody {
public:
    using prism_value = void;
    struct BodyExpr;
    struct BodyBlock;
    using Cases = std::variant<BodyExpr, BodyBlock>;
    template <class C>
        requires prism_rtl::one_of<C, BodyExpr, BodyBlock>
    FnBody(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<FnBody> from_pod(const Pod& whole);
    friend inline bool operator==(const FnBody& a, const FnBody& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `PathSeg`:
///
/// ```prism
/// type PathSeg = choice:
/// ```
class PathSeg {
public:
    using prism_value = void;
    struct PsNum;
    struct PsGen;
    struct PsKey;
    using Cases = std::variant<PsNum, PsGen, PsKey>;
    template <class C>
        requires prism_rtl::one_of<C, PsNum, PsGen, PsKey>
    PathSeg(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<PathSeg> from_pod(const Pod& whole);
    friend inline bool operator==(const PathSeg& a, const PathSeg& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `StepAction`:
///
/// ```prism
/// type StepAction = choice:
/// ```
class StepAction {
public:
    using prism_value = void;
    struct SaBuild;
    struct SaTick;
    struct SaCompute;
    struct SaPush;
    struct SaDeliver;
    struct SaWithOnly;
    using Cases = std::variant<SaBuild, SaTick, SaCompute, SaPush, SaDeliver, SaWithOnly>;
    template <class C>
        requires prism_rtl::one_of<C, SaBuild, SaTick, SaCompute, SaPush, SaDeliver, SaWithOnly>
    StepAction(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<StepAction> from_pod(const Pod& whole);
    friend inline bool operator==(const StepAction& a, const StepAction& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Target`:
///
/// ```prism
/// type Target = choice:
/// ```
class Target {
public:
    using prism_value = void;
    struct TgPattern;
    struct TgPath;
    struct TgElement;
    using Cases = std::variant<TgPattern, TgPath, TgElement>;
    template <class C>
        requires prism_rtl::one_of<C, TgPattern, TgPath, TgElement>
    Target(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Target> from_pod(const Pod& whole);
    friend inline bool operator==(const Target& a, const Target& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `TestCheckKind`:
///
/// ```prism
/// type TestCheckKind = choice:
/// ```
class TestCheckKind {
public:
    using prism_value = void;
    struct CkExpect;
    struct CkExpectNone;
    struct CkExpectCount;
    struct CkExpectTop;
    struct CkExpectTopNone;
    struct CkRequested;
    struct CkUnrequested;
    struct CkReturns;
    struct CkFired;
    struct CkQuiet;
    struct CkSettles;
    struct CkAborted;
    struct CkSnapshot;
    using Cases = std::variant<CkExpect, CkExpectNone, CkExpectCount, CkExpectTop, CkExpectTopNone, CkRequested, CkUnrequested, CkReturns, CkFired, CkQuiet, CkSettles, CkAborted, CkSnapshot>;
    template <class C>
        requires prism_rtl::one_of<C, CkExpect, CkExpectNone, CkExpectCount, CkExpectTop, CkExpectTopNone, CkRequested, CkUnrequested, CkReturns, CkFired, CkQuiet, CkSettles, CkAborted, CkSnapshot>
    TestCheckKind(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TestCheckKind> from_pod(const Pod& whole);
    friend inline bool operator==(const TestCheckKind& a, const TestCheckKind& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `TraitItem`:
///
/// ```prism
/// type TraitItem = choice:
/// ```
class TraitItem {
public:
    using prism_value = void;
    struct TiSignature;
    struct TiFn;
    struct TiAssocType;
    struct TiAssocRow;
    using Cases = std::variant<TiSignature, TiFn, TiAssocType, TiAssocRow>;
    template <class C>
        requires prism_rtl::one_of<C, TiSignature, TiFn, TiAssocType, TiAssocRow>
    TraitItem(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TraitItem> from_pod(const Pod& whole);
    friend inline bool operator==(const TraitItem& a, const TraitItem& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `TypeBody`:
///
/// ```prism
/// type TypeBody = choice:
/// ```
class TypeBody {
public:
    using prism_value = void;
    struct TbRecord;
    struct TbChoice;
    struct TbRow;
    struct TbNewtype;
    struct TbUnit;
    struct TbAlias;
    using Cases = std::variant<TbRecord, TbChoice, TbRow, TbNewtype, TbUnit, TbAlias>;
    template <class C>
        requires prism_rtl::one_of<C, TbRecord, TbChoice, TbRow, TbNewtype, TbUnit, TbAlias>
    TypeBody(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TypeBody> from_pod(const Pod& whole);
    friend inline bool operator==(const TypeBody& a, const TypeBody& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


}  // namespace syntax::decls

}  // namespace crate
