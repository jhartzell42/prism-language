// The module `Syntax.Decls`, from `target/bootstrap/cpp-src/prismc/syntax/decls.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <syntax/decls/module.hpp>
#include <syntax/module.hpp>

namespace crate::syntax::decls {

void Bound::show(Printer& p) const {
    p.record("Bound", {{"var", var}, {"traits", traits}, {"span", span}});
}

Pod Bound::to_pod() const {
    return Pod::record("Bound", {{"var", prism_rtl::to_pod(var)}, {"traits", prism_rtl::to_pod(traits)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Bound> Bound::from_pod(const Pod& whole) {
    return Bound{.var = TRY(prism_rtl::from_pod<crate::syntax::Ident>(TRY(crate::prelude::field(whole, "var")))), .traits = TRY(prism_rtl::from_pod<Array<crate::syntax::TraitRef>>(TRY(crate::prelude::field(whole, "traits")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Case_::show(Printer& p) const {
    p.record("Case", {{"name", name}, {"args", args}, {"indexed", indexed}, {"span", span}});
}

Pod Case_::to_pod() const {
    return Pod::record("Case", {{"name", prism_rtl::to_pod(name)}, {"args", prism_rtl::to_pod(args)}, {"indexed", prism_rtl::to_pod(indexed)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Case_> Case_::from_pod(const Pod& whole) {
    return Case_{.name = TRY(prism_rtl::from_pod<crate::syntax::SName>(TRY(crate::prelude::field(whole, "name")))), .args = TRY(prism_rtl::from_pod<Array<crate::syntax::Type>>(TRY(crate::prelude::field(whole, "args")))), .indexed = TRY(prism_rtl::from_pod<std::optional<crate::syntax::Type>>(TRY(crate::prelude::field(whole, "indexed")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void CheckDecl::show(Printer& p) const {
    p.record("CheckDecl", {{"name", name}, {"lines", lines}, {"span", span}});
}

Pod CheckDecl::to_pod() const {
    return Pod::record("CheckDecl", {{"name", prism_rtl::to_pod(name)}, {"lines", prism_rtl::to_pod(lines)}, {"span", prism_rtl::to_pod(span)}});
}

Result<CheckDecl> CheckDecl::from_pod(const Pod& whole) {
    return CheckDecl{.name = TRY(prism_rtl::from_pod<crate::syntax::Ident>(TRY(crate::prelude::field(whole, "name")))), .lines = TRY(prism_rtl::from_pod<Array<CheckLine>>(TRY(crate::prelude::field(whole, "lines")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void CheckLine::show(Printer& p) const {
    p.record("CheckLine", {{"expr", expr}, {"pattern", pattern}, {"span", span}});
}

Pod CheckLine::to_pod() const {
    return Pod::record("CheckLine", {{"expr", prism_rtl::to_pod(expr)}, {"pattern", prism_rtl::to_pod(pattern)}, {"span", prism_rtl::to_pod(span)}});
}

Result<CheckLine> CheckLine::from_pod(const Pod& whole) {
    return CheckLine{.expr = TRY(prism_rtl::from_pod<crate::syntax::Expr>(TRY(crate::prelude::field(whole, "expr")))), .pattern = TRY(prism_rtl::from_pod<std::optional<crate::syntax::Pattern_>>(TRY(crate::prelude::field(whole, "pattern")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Decl::show(Printer& p) const {
    p.record("Decl", {{"kind", kind}, {"span", span}});
}

Pod Decl::to_pod() const {
    return Pod::record("Decl", {{"kind", prism_rtl::to_pod(kind)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Decl> Decl::from_pod(const Pod& whole) {
    return Decl{.kind = TRY(prism_rtl::from_pod<DeclKind>(TRY(crate::prelude::field(whole, "kind")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void DeclKind::show(Printer& p) const {
    if (auto c = std::get_if<DSignature>(&cases())) p.choice("DSignature", {c->a0});
    else if (auto c = std::get_if<DFn>(&cases())) p.choice("DFn", {c->a0});
    else if (auto c = std::get_if<DLet>(&cases())) p.choice("DLet", {c->a0});
    else if (auto c = std::get_if<DWidget>(&cases())) p.choice("DWidget", {c->a0});
    else if (auto c = std::get_if<DType>(&cases())) p.choice("DType", {c->a0});
    else if (auto c = std::get_if<DTag>(&cases())) p.choice("DTag", {c->a0});
    else if (auto c = std::get_if<DDerive>(&cases())) p.choice("DDerive", {c->a0});
    else if (auto c = std::get_if<DTrait>(&cases())) p.choice("DTrait", {c->a0});
    else if (auto c = std::get_if<DImpl>(&cases())) p.choice("DImpl", {c->a0});
    else if (auto c = std::get_if<DCheck>(&cases())) p.choice("DCheck", {c->a0});
    else if (auto c = std::get_if<DTest>(&cases())) p.choice("DTest", {c->a0});
    else if (auto c = std::get_if<DStmt>(&cases())) p.choice("DStmt", {c->a0});
}

Pod DeclKind::to_pod() const {
    return std::holds_alternative<DSignature>(cases()) ? Pod::choice("DSignature", {prism_rtl::to_pod(std::get<DSignature>(cases()).a0)})
        : std::holds_alternative<DFn>(cases()) ? Pod::choice("DFn", {prism_rtl::to_pod(std::get<DFn>(cases()).a0)})
        : std::holds_alternative<DLet>(cases()) ? Pod::choice("DLet", {prism_rtl::to_pod(std::get<DLet>(cases()).a0)})
        : std::holds_alternative<DWidget>(cases()) ? Pod::choice("DWidget", {prism_rtl::to_pod(std::get<DWidget>(cases()).a0)})
        : std::holds_alternative<DType>(cases()) ? Pod::choice("DType", {prism_rtl::to_pod(std::get<DType>(cases()).a0)})
        : std::holds_alternative<DTag>(cases()) ? Pod::choice("DTag", {prism_rtl::to_pod(std::get<DTag>(cases()).a0)})
        : std::holds_alternative<DDerive>(cases()) ? Pod::choice("DDerive", {prism_rtl::to_pod(std::get<DDerive>(cases()).a0)})
        : std::holds_alternative<DTrait>(cases()) ? Pod::choice("DTrait", {prism_rtl::to_pod(std::get<DTrait>(cases()).a0)})
        : std::holds_alternative<DImpl>(cases()) ? Pod::choice("DImpl", {prism_rtl::to_pod(std::get<DImpl>(cases()).a0)})
        : std::holds_alternative<DCheck>(cases()) ? Pod::choice("DCheck", {prism_rtl::to_pod(std::get<DCheck>(cases()).a0)})
        : std::holds_alternative<DTest>(cases()) ? Pod::choice("DTest", {prism_rtl::to_pod(std::get<DTest>(cases()).a0)})
        : std::holds_alternative<DStmt>(cases()) ? Pod::choice("DStmt", {prism_rtl::to_pod(std::get<DStmt>(cases()).a0)})
        : Pod();
}

Result<DeclKind> DeclKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "DSignature" && c->args.size() == 1) return DeclKind(DSignature{TRY(prism_rtl::from_pod<Signature>(c->args[0]))});
        if (c->ctor == "DFn" && c->args.size() == 1) return DeclKind(DFn{TRY(prism_rtl::from_pod<FnClause>(c->args[0]))});
        if (c->ctor == "DLet" && c->args.size() == 1) return DeclKind(DLet{TRY(prism_rtl::from_pod<LetDecl>(c->args[0]))});
        if (c->ctor == "DWidget" && c->args.size() == 1) return DeclKind(DWidget{TRY(prism_rtl::from_pod<WidgetDecl>(c->args[0]))});
        if (c->ctor == "DType" && c->args.size() == 1) return DeclKind(DType{TRY(prism_rtl::from_pod<TypeDecl>(c->args[0]))});
        if (c->ctor == "DTag" && c->args.size() == 1) return DeclKind(DTag{TRY(prism_rtl::from_pod<TagDecl>(c->args[0]))});
        if (c->ctor == "DDerive" && c->args.size() == 1) return DeclKind(DDerive{TRY(prism_rtl::from_pod<Array<crate::syntax::TraitRef>>(c->args[0]))});
        if (c->ctor == "DTrait" && c->args.size() == 1) return DeclKind(DTrait{TRY(prism_rtl::from_pod<TraitDecl>(c->args[0]))});
        if (c->ctor == "DImpl" && c->args.size() == 1) return DeclKind(DImpl{TRY(prism_rtl::from_pod<ImplDecl>(c->args[0]))});
        if (c->ctor == "DCheck" && c->args.size() == 1) return DeclKind(DCheck{TRY(prism_rtl::from_pod<CheckDecl>(c->args[0]))});
        if (c->ctor == "DTest" && c->args.size() == 1) return DeclKind(DTest{TRY(prism_rtl::from_pod<TestDecl>(c->args[0]))});
        if (c->ctor == "DStmt" && c->args.size() == 1) return DeclKind(DStmt{TRY(prism_rtl::from_pod<crate::syntax::Stmt>(c->args[0]))});
    }
    return mismatch<DeclKind>("a DeclKind", p);
}


void DefName::show(Printer& p) const {
    if (auto c = std::get_if<DefSName>(&cases())) p.choice("DefSName", {c->a0});
    else if (auto c = std::get_if<DefOp>(&cases())) p.choice("DefOp", {c->a0, c->a1});
}

Pod DefName::to_pod() const {
    return std::holds_alternative<DefSName>(cases()) ? Pod::choice("DefSName", {prism_rtl::to_pod(std::get<DefSName>(cases()).a0)})
        : std::holds_alternative<DefOp>(cases()) ? Pod::choice("DefOp", {prism_rtl::to_pod(std::get<DefOp>(cases()).a0), prism_rtl::to_pod(std::get<DefOp>(cases()).a1)})
        : Pod();
}

Result<DefName> DefName::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "DefSName" && c->args.size() == 1) return DefName(DefSName{TRY(prism_rtl::from_pod<crate::syntax::SName>(c->args[0]))});
        if (c->ctor == "DefOp" && c->args.size() == 2) return DefName(DefOp{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[1]))});
    }
    return mismatch<DefName>("a DefName", p);
}


void Delivery::show(Printer& p) const {
    p.record("Delivery", {{"kind", kind}, {"target", target}, {"span", span}});
}

Pod Delivery::to_pod() const {
    return Pod::record("Delivery", {{"kind", prism_rtl::to_pod(kind)}, {"target", prism_rtl::to_pod(target)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Delivery> Delivery::from_pod(const Pod& whole) {
    return Delivery{.kind = TRY(prism_rtl::from_pod<DeliveryKind>(TRY(crate::prelude::field(whole, "kind")))), .target = TRY(prism_rtl::from_pod<Target>(TRY(crate::prelude::field(whole, "target")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void DeliveryKind::show(Printer& p) const {
    if (auto c = std::get_if<DkSend>(&cases())) p.choice("DkSend", {c->a0});
    else if (auto c = std::get_if<DkClick>(&cases())) p.choice("DkClick", {});
    else if (auto c = std::get_if<DkAnswer>(&cases())) p.choice("DkAnswer", {});
}

Pod DeliveryKind::to_pod() const {
    return std::holds_alternative<DkSend>(cases()) ? Pod::choice("DkSend", {prism_rtl::to_pod(std::get<DkSend>(cases()).a0)})
        : std::holds_alternative<DkClick>(cases()) ? Pod::choice("DkClick", {})
        : std::holds_alternative<DkAnswer>(cases()) ? Pod::choice("DkAnswer", {})
        : Pod();
}

Result<DeliveryKind> DeliveryKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "DkSend" && c->args.size() == 1) return DeliveryKind(DkSend{TRY(prism_rtl::from_pod<crate::syntax::Expr>(c->args[0]))});
        if (c->ctor == "DkClick" && c->args.size() == 0) return DeliveryKind(DkClick{});
        if (c->ctor == "DkAnswer" && c->args.size() == 0) return DeliveryKind(DkAnswer{});
    }
    return mismatch<DeliveryKind>("a DeliveryKind", p);
}


void Entry::show(Printer& p) const {
    p.record("Entry", {{"element", element}, {"value", value}, {"span", span}});
}

Pod Entry::to_pod() const {
    return Pod::record("Entry", {{"element", prism_rtl::to_pod(element)}, {"value", prism_rtl::to_pod(value)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Entry> Entry::from_pod(const Pod& whole) {
    return Entry{.element = TRY(prism_rtl::from_pod<crate::syntax::Expr>(TRY(crate::prelude::field(whole, "element")))), .value = TRY(prism_rtl::from_pod<crate::syntax::Expr>(TRY(crate::prelude::field(whole, "value")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Field::show(Printer& p) const {
    p.record("Field", {{"name", name}, {"ty", ty}, {"span", span}});
}

Pod Field::to_pod() const {
    return Pod::record("Field", {{"name", prism_rtl::to_pod(name)}, {"ty", prism_rtl::to_pod(ty)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Field> Field::from_pod(const Pod& whole) {
    return Field{.name = TRY(prism_rtl::from_pod<crate::syntax::Ident>(TRY(crate::prelude::field(whole, "name")))), .ty = TRY(prism_rtl::from_pod<crate::syntax::Type>(TRY(crate::prelude::field(whole, "ty")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void FnBody::show(Printer& p) const {
    if (auto c = std::get_if<BodyExpr>(&cases())) p.choice("BodyExpr", {c->a0});
    else if (auto c = std::get_if<BodyBlock>(&cases())) p.choice("BodyBlock", {c->a0});
}

Pod FnBody::to_pod() const {
    return std::holds_alternative<BodyExpr>(cases()) ? Pod::choice("BodyExpr", {prism_rtl::to_pod(std::get<BodyExpr>(cases()).a0)})
        : std::holds_alternative<BodyBlock>(cases()) ? Pod::choice("BodyBlock", {prism_rtl::to_pod(std::get<BodyBlock>(cases()).a0)})
        : Pod();
}

Result<FnBody> FnBody::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "BodyExpr" && c->args.size() == 1) return FnBody(BodyExpr{TRY(prism_rtl::from_pod<crate::syntax::Expr>(c->args[0]))});
        if (c->ctor == "BodyBlock" && c->args.size() == 1) return FnBody(BodyBlock{TRY(prism_rtl::from_pod<crate::syntax::Block>(c->args[0]))});
    }
    return mismatch<FnBody>("a FnBody", p);
}


void FnClause::show(Printer& p) const {
    p.record("FnClause", {{"name", name}, {"params", params}, {"body", body}, {"span", span}});
}

Pod FnClause::to_pod() const {
    return Pod::record("FnClause", {{"name", prism_rtl::to_pod(name)}, {"params", prism_rtl::to_pod(params)}, {"body", prism_rtl::to_pod(body)}, {"span", prism_rtl::to_pod(span)}});
}

Result<FnClause> FnClause::from_pod(const Pod& whole) {
    return FnClause{.name = TRY(prism_rtl::from_pod<DefName>(TRY(crate::prelude::field(whole, "name")))), .params = TRY(prism_rtl::from_pod<Array<crate::syntax::Pattern_>>(TRY(crate::prelude::field(whole, "params")))), .body = TRY(prism_rtl::from_pod<FnBody>(TRY(crate::prelude::field(whole, "body")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void ImplDecl::show(Printer& p) const {
    p.record("ImplDecl", {{"trait_ref", trait_ref}, {"ty", ty}, {"bounds", bounds}, {"items", items}, {"span", span}});
}

Pod ImplDecl::to_pod() const {
    return Pod::record("ImplDecl", {{"trait_ref", prism_rtl::to_pod(trait_ref)}, {"ty", prism_rtl::to_pod(ty)}, {"bounds", prism_rtl::to_pod(bounds)}, {"items", prism_rtl::to_pod(items)}, {"span", prism_rtl::to_pod(span)}});
}

Result<ImplDecl> ImplDecl::from_pod(const Pod& whole) {
    return ImplDecl{.trait_ref = TRY(prism_rtl::from_pod<crate::syntax::TraitRef>(TRY(crate::prelude::field(whole, "trait_ref")))), .ty = TRY(prism_rtl::from_pod<crate::syntax::Type>(TRY(crate::prelude::field(whole, "ty")))), .bounds = TRY(prism_rtl::from_pod<Array<Bound>>(TRY(crate::prelude::field(whole, "bounds")))), .items = TRY(prism_rtl::from_pod<Array<TraitItem>>(TRY(crate::prelude::field(whole, "items")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void LetDecl::show(Printer& p) const {
    p.record("LetDecl", {{"pattern", pattern}, {"ty", ty}, {"value", value}, {"span", span}});
}

Pod LetDecl::to_pod() const {
    return Pod::record("LetDecl", {{"pattern", prism_rtl::to_pod(pattern)}, {"ty", prism_rtl::to_pod(ty)}, {"value", prism_rtl::to_pod(value)}, {"span", prism_rtl::to_pod(span)}});
}

Result<LetDecl> LetDecl::from_pod(const Pod& whole) {
    return LetDecl{.pattern = TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(TRY(crate::prelude::field(whole, "pattern")))), .ty = TRY(prism_rtl::from_pod<std::optional<crate::syntax::Type>>(TRY(crate::prelude::field(whole, "ty")))), .value = TRY(prism_rtl::from_pod<crate::syntax::Expr>(TRY(crate::prelude::field(whole, "value")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void PathSeg::show(Printer& p) const {
    if (auto c = std::get_if<PsNum>(&cases())) p.choice("PsNum", {c->a0});
    else if (auto c = std::get_if<PsGen>(&cases())) p.choice("PsGen", {c->a0});
    else if (auto c = std::get_if<PsKey>(&cases())) p.choice("PsKey", {c->a0});
}

Pod PathSeg::to_pod() const {
    return std::holds_alternative<PsNum>(cases()) ? Pod::choice("PsNum", {prism_rtl::to_pod(std::get<PsNum>(cases()).a0)})
        : std::holds_alternative<PsGen>(cases()) ? Pod::choice("PsGen", {prism_rtl::to_pod(std::get<PsGen>(cases()).a0)})
        : std::holds_alternative<PsKey>(cases()) ? Pod::choice("PsKey", {prism_rtl::to_pod(std::get<PsKey>(cases()).a0)})
        : Pod();
}

Result<PathSeg> PathSeg::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "PsNum" && c->args.size() == 1) return PathSeg(PsNum{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "PsGen" && c->args.size() == 1) return PathSeg(PsGen{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "PsKey" && c->args.size() == 1) return PathSeg(PsKey{TRY(prism_rtl::from_pod<crate::syntax::Expr>(c->args[0]))});
    }
    return mismatch<PathSeg>("a PathSeg", p);
}


void Signature::show(Printer& p) const {
    p.record("Signature", {{"name", name}, {"ty", ty}, {"bounds", bounds}, {"span", span}});
}

Pod Signature::to_pod() const {
    return Pod::record("Signature", {{"name", prism_rtl::to_pod(name)}, {"ty", prism_rtl::to_pod(ty)}, {"bounds", prism_rtl::to_pod(bounds)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Signature> Signature::from_pod(const Pod& whole) {
    return Signature{.name = TRY(prism_rtl::from_pod<DefName>(TRY(crate::prelude::field(whole, "name")))), .ty = TRY(prism_rtl::from_pod<crate::syntax::Type>(TRY(crate::prelude::field(whole, "ty")))), .bounds = TRY(prism_rtl::from_pod<Array<Bound>>(TRY(crate::prelude::field(whole, "bounds")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void StepAction::show(Printer& p) const {
    if (auto c = std::get_if<SaBuild>(&cases())) p.choice("SaBuild", {});
    else if (auto c = std::get_if<SaTick>(&cases())) p.choice("SaTick", {});
    else if (auto c = std::get_if<SaCompute>(&cases())) p.choice("SaCompute", {c->a0});
    else if (auto c = std::get_if<SaPush>(&cases())) p.choice("SaPush", {c->a0});
    else if (auto c = std::get_if<SaDeliver>(&cases())) p.choice("SaDeliver", {c->a0});
    else if (auto c = std::get_if<SaWithOnly>(&cases())) p.choice("SaWithOnly", {});
}

Pod StepAction::to_pod() const {
    return std::holds_alternative<SaBuild>(cases()) ? Pod::choice("SaBuild", {})
        : std::holds_alternative<SaTick>(cases()) ? Pod::choice("SaTick", {})
        : std::holds_alternative<SaCompute>(cases()) ? Pod::choice("SaCompute", {prism_rtl::to_pod(std::get<SaCompute>(cases()).a0)})
        : std::holds_alternative<SaPush>(cases()) ? Pod::choice("SaPush", {prism_rtl::to_pod(std::get<SaPush>(cases()).a0)})
        : std::holds_alternative<SaDeliver>(cases()) ? Pod::choice("SaDeliver", {prism_rtl::to_pod(std::get<SaDeliver>(cases()).a0)})
        : std::holds_alternative<SaWithOnly>(cases()) ? Pod::choice("SaWithOnly", {})
        : Pod();
}

Result<StepAction> StepAction::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "SaBuild" && c->args.size() == 0) return StepAction(SaBuild{});
        if (c->ctor == "SaTick" && c->args.size() == 0) return StepAction(SaTick{});
        if (c->ctor == "SaCompute" && c->args.size() == 1) return StepAction(SaCompute{TRY(prism_rtl::from_pod<bool>(c->args[0]))});
        if (c->ctor == "SaPush" && c->args.size() == 1) return StepAction(SaPush{TRY(prism_rtl::from_pod<Entry>(c->args[0]))});
        if (c->ctor == "SaDeliver" && c->args.size() == 1) return StepAction(SaDeliver{TRY(prism_rtl::from_pod<Array<Delivery>>(c->args[0]))});
        if (c->ctor == "SaWithOnly" && c->args.size() == 0) return StepAction(SaWithOnly{});
    }
    return mismatch<StepAction>("a StepAction", p);
}


void TagDecl::show(Printer& p) const {
    p.record("TagDecl", {{"name", name}, {"of_type", of_type}, {"bounds", bounds}, {"fields", fields}, {"span", span}});
}

Pod TagDecl::to_pod() const {
    return Pod::record("TagDecl", {{"name", prism_rtl::to_pod(name)}, {"of_type", prism_rtl::to_pod(of_type)}, {"bounds", prism_rtl::to_pod(bounds)}, {"fields", prism_rtl::to_pod(fields)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TagDecl> TagDecl::from_pod(const Pod& whole) {
    return TagDecl{.name = TRY(prism_rtl::from_pod<crate::syntax::QualName>(TRY(crate::prelude::field(whole, "name")))), .of_type = TRY(prism_rtl::from_pod<crate::syntax::Type>(TRY(crate::prelude::field(whole, "of_type")))), .bounds = TRY(prism_rtl::from_pod<Array<Bound>>(TRY(crate::prelude::field(whole, "bounds")))), .fields = TRY(prism_rtl::from_pod<Array<Field>>(TRY(crate::prelude::field(whole, "fields")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Target::show(Printer& p) const {
    if (auto c = std::get_if<TgPattern>(&cases())) p.choice("TgPattern", {c->a0});
    else if (auto c = std::get_if<TgPath>(&cases())) p.choice("TgPath", {c->a0});
    else if (auto c = std::get_if<TgElement>(&cases())) p.choice("TgElement", {c->a0});
}

Pod Target::to_pod() const {
    return std::holds_alternative<TgPattern>(cases()) ? Pod::choice("TgPattern", {prism_rtl::to_pod(std::get<TgPattern>(cases()).a0)})
        : std::holds_alternative<TgPath>(cases()) ? Pod::choice("TgPath", {prism_rtl::to_pod(std::get<TgPath>(cases()).a0)})
        : std::holds_alternative<TgElement>(cases()) ? Pod::choice("TgElement", {prism_rtl::to_pod(std::get<TgElement>(cases()).a0)})
        : Pod();
}

Result<Target> Target::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TgPattern" && c->args.size() == 1) return Target(TgPattern{TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[0]))});
        if (c->ctor == "TgPath" && c->args.size() == 1) return Target(TgPath{TRY(prism_rtl::from_pod<TestPath>(c->args[0]))});
        if (c->ctor == "TgElement" && c->args.size() == 1) return Target(TgElement{TRY(prism_rtl::from_pod<TestPath>(c->args[0]))});
    }
    return mismatch<Target>("a Target", p);
}


void TestCheck::show(Printer& p) const {
    p.record("TestCheck", {{"kind", kind}, {"span", span}});
}

Pod TestCheck::to_pod() const {
    return Pod::record("TestCheck", {{"kind", prism_rtl::to_pod(kind)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TestCheck> TestCheck::from_pod(const Pod& whole) {
    return TestCheck{.kind = TRY(prism_rtl::from_pod<TestCheckKind>(TRY(crate::prelude::field(whole, "kind")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void TestCheckKind::show(Printer& p) const {
    if (auto c = std::get_if<CkExpect>(&cases())) p.choice("CkExpect", {c->a0});
    else if (auto c = std::get_if<CkExpectNone>(&cases())) p.choice("CkExpectNone", {c->a0});
    else if (auto c = std::get_if<CkExpectCount>(&cases())) p.choice("CkExpectCount", {c->a0, c->a1});
    else if (auto c = std::get_if<CkExpectTop>(&cases())) p.choice("CkExpectTop", {c->a0});
    else if (auto c = std::get_if<CkExpectTopNone>(&cases())) p.choice("CkExpectTopNone", {c->a0});
    else if (auto c = std::get_if<CkRequested>(&cases())) p.choice("CkRequested", {c->a0, c->a1});
    else if (auto c = std::get_if<CkUnrequested>(&cases())) p.choice("CkUnrequested", {c->a0});
    else if (auto c = std::get_if<CkReturns>(&cases())) p.choice("CkReturns", {c->a0});
    else if (auto c = std::get_if<CkFired>(&cases())) p.choice("CkFired", {c->a0});
    else if (auto c = std::get_if<CkQuiet>(&cases())) p.choice("CkQuiet", {});
    else if (auto c = std::get_if<CkSettles>(&cases())) p.choice("CkSettles", {});
    else if (auto c = std::get_if<CkAborted>(&cases())) p.choice("CkAborted", {});
    else if (auto c = std::get_if<CkSnapshot>(&cases())) p.choice("CkSnapshot", {c->a0});
}

Pod TestCheckKind::to_pod() const {
    return std::holds_alternative<CkExpect>(cases()) ? Pod::choice("CkExpect", {prism_rtl::to_pod(std::get<CkExpect>(cases()).a0)})
        : std::holds_alternative<CkExpectNone>(cases()) ? Pod::choice("CkExpectNone", {prism_rtl::to_pod(std::get<CkExpectNone>(cases()).a0)})
        : std::holds_alternative<CkExpectCount>(cases()) ? Pod::choice("CkExpectCount", {prism_rtl::to_pod(std::get<CkExpectCount>(cases()).a0), prism_rtl::to_pod(std::get<CkExpectCount>(cases()).a1)})
        : std::holds_alternative<CkExpectTop>(cases()) ? Pod::choice("CkExpectTop", {prism_rtl::to_pod(std::get<CkExpectTop>(cases()).a0)})
        : std::holds_alternative<CkExpectTopNone>(cases()) ? Pod::choice("CkExpectTopNone", {prism_rtl::to_pod(std::get<CkExpectTopNone>(cases()).a0)})
        : std::holds_alternative<CkRequested>(cases()) ? Pod::choice("CkRequested", {prism_rtl::to_pod(std::get<CkRequested>(cases()).a0), prism_rtl::to_pod(std::get<CkRequested>(cases()).a1)})
        : std::holds_alternative<CkUnrequested>(cases()) ? Pod::choice("CkUnrequested", {prism_rtl::to_pod(std::get<CkUnrequested>(cases()).a0)})
        : std::holds_alternative<CkReturns>(cases()) ? Pod::choice("CkReturns", {prism_rtl::to_pod(std::get<CkReturns>(cases()).a0)})
        : std::holds_alternative<CkFired>(cases()) ? Pod::choice("CkFired", {prism_rtl::to_pod(std::get<CkFired>(cases()).a0)})
        : std::holds_alternative<CkQuiet>(cases()) ? Pod::choice("CkQuiet", {})
        : std::holds_alternative<CkSettles>(cases()) ? Pod::choice("CkSettles", {})
        : std::holds_alternative<CkAborted>(cases()) ? Pod::choice("CkAborted", {})
        : std::holds_alternative<CkSnapshot>(cases()) ? Pod::choice("CkSnapshot", {prism_rtl::to_pod(std::get<CkSnapshot>(cases()).a0)})
        : Pod();
}

Result<TestCheckKind> TestCheckKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "CkExpect" && c->args.size() == 1) return TestCheckKind(CkExpect{TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[0]))});
        if (c->ctor == "CkExpectNone" && c->args.size() == 1) return TestCheckKind(CkExpectNone{TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[0]))});
        if (c->ctor == "CkExpectCount" && c->args.size() == 2) return TestCheckKind(CkExpectCount{TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[0])), TRY(prism_rtl::from_pod<Nat>(c->args[1]))});
        if (c->ctor == "CkExpectTop" && c->args.size() == 1) return TestCheckKind(CkExpectTop{TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[0]))});
        if (c->ctor == "CkExpectTopNone" && c->args.size() == 1) return TestCheckKind(CkExpectTopNone{TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[0]))});
        if (c->ctor == "CkRequested" && c->args.size() == 2) return TestCheckKind(CkRequested{TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[1]))});
        if (c->ctor == "CkUnrequested" && c->args.size() == 1) return TestCheckKind(CkUnrequested{TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[0]))});
        if (c->ctor == "CkReturns" && c->args.size() == 1) return TestCheckKind(CkReturns{TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[0]))});
        if (c->ctor == "CkFired" && c->args.size() == 1) return TestCheckKind(CkFired{TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[0]))});
        if (c->ctor == "CkQuiet" && c->args.size() == 0) return TestCheckKind(CkQuiet{});
        if (c->ctor == "CkSettles" && c->args.size() == 0) return TestCheckKind(CkSettles{});
        if (c->ctor == "CkAborted" && c->args.size() == 0) return TestCheckKind(CkAborted{});
        if (c->ctor == "CkSnapshot" && c->args.size() == 1) return TestCheckKind(CkSnapshot{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<TestCheckKind>("a TestCheckKind", p);
}


void TestDecl::show(Printer& p) const {
    p.record("TestDecl", {{"name", name}, {"blueprint", blueprint}, {"seed", seed}, {"steps", steps}, {"span", span}});
}

Pod TestDecl::to_pod() const {
    return Pod::record("TestDecl", {{"name", prism_rtl::to_pod(name)}, {"blueprint", prism_rtl::to_pod(blueprint)}, {"seed", prism_rtl::to_pod(seed)}, {"steps", prism_rtl::to_pod(steps)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TestDecl> TestDecl::from_pod(const Pod& whole) {
    return TestDecl{.name = TRY(prism_rtl::from_pod<crate::syntax::Ident>(TRY(crate::prelude::field(whole, "name")))), .blueprint = TRY(prism_rtl::from_pod<crate::syntax::Expr>(TRY(crate::prelude::field(whole, "blueprint")))), .seed = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(crate::prelude::field(whole, "seed")))), .steps = TRY(prism_rtl::from_pod<Array<TestStep>>(TRY(crate::prelude::field(whole, "steps")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void TestPath::show(Printer& p) const {
    p.record("TestPath", {{"segments", segments}, {"span", span}});
}

Pod TestPath::to_pod() const {
    return Pod::record("TestPath", {{"segments", prism_rtl::to_pod(segments)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TestPath> TestPath::from_pod(const Pod& whole) {
    return TestPath{.segments = TRY(prism_rtl::from_pod<Array<PathSeg>>(TRY(crate::prelude::field(whole, "segments")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void TestStep::show(Printer& p) const {
    p.record("TestStep", {{"withs", withs}, {"action", action}, {"checks", checks}, {"span", span}});
}

Pod TestStep::to_pod() const {
    return Pod::record("TestStep", {{"withs", prism_rtl::to_pod(withs)}, {"action", prism_rtl::to_pod(action)}, {"checks", prism_rtl::to_pod(checks)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TestStep> TestStep::from_pod(const Pod& whole) {
    return TestStep{.withs = TRY(prism_rtl::from_pod<Array<Entry>>(TRY(crate::prelude::field(whole, "withs")))), .action = TRY(prism_rtl::from_pod<StepAction>(TRY(crate::prelude::field(whole, "action")))), .checks = TRY(prism_rtl::from_pod<Array<TestCheck>>(TRY(crate::prelude::field(whole, "checks")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void TraitDecl::show(Printer& p) const {
    p.record("TraitDecl", {{"name", name}, {"params", params}, {"bounds", bounds}, {"items", items}, {"span", span}});
}

Pod TraitDecl::to_pod() const {
    return Pod::record("TraitDecl", {{"name", prism_rtl::to_pod(name)}, {"params", prism_rtl::to_pod(params)}, {"bounds", prism_rtl::to_pod(bounds)}, {"items", prism_rtl::to_pod(items)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TraitDecl> TraitDecl::from_pod(const Pod& whole) {
    return TraitDecl{.name = TRY(prism_rtl::from_pod<crate::syntax::TraitRef>(TRY(crate::prelude::field(whole, "name")))), .params = TRY(prism_rtl::from_pod<Array<crate::syntax::Ident>>(TRY(crate::prelude::field(whole, "params")))), .bounds = TRY(prism_rtl::from_pod<Array<Bound>>(TRY(crate::prelude::field(whole, "bounds")))), .items = TRY(prism_rtl::from_pod<Array<TraitItem>>(TRY(crate::prelude::field(whole, "items")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void TraitItem::show(Printer& p) const {
    if (auto c = std::get_if<TiSignature>(&cases())) p.choice("TiSignature", {c->a0});
    else if (auto c = std::get_if<TiFn>(&cases())) p.choice("TiFn", {c->a0});
    else if (auto c = std::get_if<TiAssocType>(&cases())) p.choice("TiAssocType", {c->a0, c->a1, c->a2, c->a3});
    else if (auto c = std::get_if<TiAssocRow>(&cases())) p.choice("TiAssocRow", {c->a0, c->a1});
}

Pod TraitItem::to_pod() const {
    return std::holds_alternative<TiSignature>(cases()) ? Pod::choice("TiSignature", {prism_rtl::to_pod(std::get<TiSignature>(cases()).a0)})
        : std::holds_alternative<TiFn>(cases()) ? Pod::choice("TiFn", {prism_rtl::to_pod(std::get<TiFn>(cases()).a0)})
        : std::holds_alternative<TiAssocType>(cases()) ? Pod::choice("TiAssocType", {prism_rtl::to_pod(std::get<TiAssocType>(cases()).a0), prism_rtl::to_pod(std::get<TiAssocType>(cases()).a1), prism_rtl::to_pod(std::get<TiAssocType>(cases()).a2), prism_rtl::to_pod(std::get<TiAssocType>(cases()).a3)})
        : std::holds_alternative<TiAssocRow>(cases()) ? Pod::choice("TiAssocRow", {prism_rtl::to_pod(std::get<TiAssocRow>(cases()).a0), prism_rtl::to_pod(std::get<TiAssocRow>(cases()).a1)})
        : Pod();
}

Result<TraitItem> TraitItem::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TiSignature" && c->args.size() == 1) return TraitItem(TiSignature{TRY(prism_rtl::from_pod<Signature>(c->args[0]))});
        if (c->ctor == "TiFn" && c->args.size() == 1) return TraitItem(TiFn{TRY(prism_rtl::from_pod<FnClause>(c->args[0]))});
        if (c->ctor == "TiAssocType" && c->args.size() == 4) return TraitItem(TiAssocType{TRY(prism_rtl::from_pod<crate::syntax::Ident>(c->args[0])), TRY(prism_rtl::from_pod<Array<crate::syntax::Ident>>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<crate::syntax::Type>>(c->args[2])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[3]))});
        if (c->ctor == "TiAssocRow" && c->args.size() == 2) return TraitItem(TiAssocRow{TRY(prism_rtl::from_pod<crate::syntax::SName>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[1]))});
    }
    return mismatch<TraitItem>("a TraitItem", p);
}


void TypeBody::show(Printer& p) const {
    if (auto c = std::get_if<TbRecord>(&cases())) p.choice("TbRecord", {c->a0});
    else if (auto c = std::get_if<TbChoice>(&cases())) p.choice("TbChoice", {c->a0});
    else if (auto c = std::get_if<TbRow>(&cases())) p.choice("TbRow", {});
    else if (auto c = std::get_if<TbNewtype>(&cases())) p.choice("TbNewtype", {c->a0});
    else if (auto c = std::get_if<TbUnit>(&cases())) p.choice("TbUnit", {c->a0});
    else if (auto c = std::get_if<TbAlias>(&cases())) p.choice("TbAlias", {c->a0});
}

Pod TypeBody::to_pod() const {
    return std::holds_alternative<TbRecord>(cases()) ? Pod::choice("TbRecord", {prism_rtl::to_pod(std::get<TbRecord>(cases()).a0)})
        : std::holds_alternative<TbChoice>(cases()) ? Pod::choice("TbChoice", {prism_rtl::to_pod(std::get<TbChoice>(cases()).a0)})
        : std::holds_alternative<TbRow>(cases()) ? Pod::choice("TbRow", {})
        : std::holds_alternative<TbNewtype>(cases()) ? Pod::choice("TbNewtype", {prism_rtl::to_pod(std::get<TbNewtype>(cases()).a0)})
        : std::holds_alternative<TbUnit>(cases()) ? Pod::choice("TbUnit", {prism_rtl::to_pod(std::get<TbUnit>(cases()).a0)})
        : std::holds_alternative<TbAlias>(cases()) ? Pod::choice("TbAlias", {prism_rtl::to_pod(std::get<TbAlias>(cases()).a0)})
        : Pod();
}

Result<TypeBody> TypeBody::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TbRecord" && c->args.size() == 1) return TypeBody(TbRecord{TRY(prism_rtl::from_pod<Array<Field>>(c->args[0]))});
        if (c->ctor == "TbChoice" && c->args.size() == 1) return TypeBody(TbChoice{TRY(prism_rtl::from_pod<Array<Case_>>(c->args[0]))});
        if (c->ctor == "TbRow" && c->args.size() == 0) return TypeBody(TbRow{});
        if (c->ctor == "TbNewtype" && c->args.size() == 1) return TypeBody(TbNewtype{TRY(prism_rtl::from_pod<Case_>(c->args[0]))});
        if (c->ctor == "TbUnit" && c->args.size() == 1) return TypeBody(TbUnit{TRY(prism_rtl::from_pod<crate::syntax::Ident>(c->args[0]))});
        if (c->ctor == "TbAlias" && c->args.size() == 1) return TypeBody(TbAlias{TRY(prism_rtl::from_pod<crate::syntax::Type>(c->args[0]))});
    }
    return mismatch<TypeBody>("a TypeBody", p);
}


void TypeDecl::show(Printer& p) const {
    p.record("TypeDecl", {{"name", name}, {"params", params}, {"body", body}, {"span", span}});
}

Pod TypeDecl::to_pod() const {
    return Pod::record("TypeDecl", {{"name", prism_rtl::to_pod(name)}, {"params", prism_rtl::to_pod(params)}, {"body", prism_rtl::to_pod(body)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TypeDecl> TypeDecl::from_pod(const Pod& whole) {
    return TypeDecl{.name = TRY(prism_rtl::from_pod<crate::syntax::QualName>(TRY(crate::prelude::field(whole, "name")))), .params = TRY(prism_rtl::from_pod<Array<crate::syntax::Ident>>(TRY(crate::prelude::field(whole, "params")))), .body = TRY(prism_rtl::from_pod<std::optional<TypeBody>>(TRY(crate::prelude::field(whole, "body")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void WidgetDecl::show(Printer& p) const {
    p.record("WidgetDecl", {{"name", name}, {"body", body}, {"span", span}});
}

Pod WidgetDecl::to_pod() const {
    return Pod::record("WidgetDecl", {{"name", prism_rtl::to_pod(name)}, {"body", prism_rtl::to_pod(body)}, {"span", prism_rtl::to_pod(span)}});
}

Result<WidgetDecl> WidgetDecl::from_pod(const Pod& whole) {
    return WidgetDecl{.name = TRY(prism_rtl::from_pod<crate::syntax::SName>(TRY(crate::prelude::field(whole, "name")))), .body = TRY(prism_rtl::from_pod<crate::syntax::Block>(TRY(crate::prelude::field(whole, "body")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}

}  // namespace crate::syntax::decls
