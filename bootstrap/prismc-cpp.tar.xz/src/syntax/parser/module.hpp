// The module `Syntax.Parser`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/parser/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::parser {

crate::syntax::Range no_range();

crate::syntax::lexer::Tok eof_tok();

Pair no_pair();

Parsed parse_file(const Text& src);

prism_rtl::JobRef<Parsed> start_parse_file(Text src);

Parsed parse_fragment(const Text& src);

prism_rtl::JobRef<Parsed> start_parse_fragment(Text src);

Ps new_ps(const Array<crate::syntax::lexer::Tok>& toks0);

prism_rtl::JobRef<Ps> start_new_ps(Array<crate::syntax::lexer::Tok> toks0);

Ps sub(const Ps& p_, const Array<crate::syntax::lexer::Tok>& toks, const crate::syntax::Range& end);

prism_rtl::JobRef<Ps> start_sub(Ps p_, Array<crate::syntax::lexer::Tok> toks, crate::syntax::Range end);

Ps absorb(const Ps& p_, const Ps& sub_);

Array<crate::syntax::Diag> finish_diags(const Array<crate::syntax::Diag>& ds);

Nat stage_rank(const Text& text0);

bool diag_before(const crate::syntax::Diag& a, const crate::syntax::Diag& b);

Array<crate::syntax::Diag> insert_diag(const Array<crate::syntax::Diag>& sorted, const crate::syntax::Diag& d);

Array<Pair> pair_brackets(const Array<crate::syntax::lexer::Tok>& toks);

prism_rtl::JobRef<Array<Pair>> start_pair_brackets(Array<crate::syntax::lexer::Tok> toks);

bool double_at(const Array<Pair>& pairs, const Array<crate::syntax::lexer::Tok>& toks, const Nat& i, const Nat& j, const Text& kind_);

std::optional<Text> open_kind_of(const crate::syntax::lexer::TokKind& tok_kind0);

std::optional<Text> close_kind_of(const crate::syntax::lexer::TokKind& tok_kind0);

bool is_open_of(const crate::syntax::lexer::TokKind& tok_kind0, const Text& text1);

crate::syntax::lexer::Tok tk(const Ps& p_);

crate::syntax::lexer::Tok tk_at(const Ps& p_, const Nat& n);

crate::syntax::lexer::TokKind kind(const Ps& p_);

crate::syntax::lexer::TokKind kind_at(const Ps& p_, const Nat& n);

crate::syntax::Range here(const Ps& p_);

crate::syntax::Range prev(const Ps& p_);

crate::syntax::Range to(const crate::syntax::Range& a, const crate::syntax::Range& b);

crate::syntax::Range at_end(const crate::syntax::Range& r);

Ps adv(const Ps& p_);

Pair pair_at(const Ps& p_);

bool at_eof(const Ps& p_);

bool at_kw(const Ps& p_, const Text& w);

bool at_op(const Ps& p_, const Text& op);

bool at_sep(const Ps& p_);

bool at_open_l(const Ps& p_);

bool at_close_l(const Ps& p_);

bool at_comma(const Ps& p_);

bool at_colon(const Ps& p_);

bool is_open_kind(const crate::syntax::lexer::TokKind& tok_kind0, const Text& text1);

bool at_double_open(const Ps& p_, const Text& kind_);

bool at_single_open(const Ps& p_, const Text& kind_);

bool at_close(const Ps& p_, const Text& kind_);

Ps open_double(const Ps& p_);

Ps close_double(const Ps& p_, const Text& kind_);

Ps expect_close(const Ps& p_, const Text& kind_);

crate::syntax::Diag parse_diag(const crate::syntax::Range& span, const Text& message);

Ps error_at(const Ps& p_, const crate::syntax::Range& span, const Text& message);

Ps error_here(const Ps& p_, const Text& message);

Ps fail(const Ps& p_);

Ps unbad(const Ps& p_);

Ps note_error(const Ps& p_, const crate::syntax::Range& span, const Text& message);

Ps complain(const Ps& p_, const Text& message);

Ps out_of_scope(const Ps& p_, const crate::syntax::Range& span, const Text& feature, const Text& message);

Ps expect_colon(const Ps& p_);

Ps expect_op(const Ps& p_, const Text& op);

Ps expect_kw(const Ps& p_, const Text& w);

Ps recover(const Ps& p0);

prism_rtl::JobRef<Ps> start_recover(Ps p0);

Ps recovered(const Ps& p_);

prism_rtl::JobRef<Ps> start_recovered(Ps p_);

bool at_stmt_boundary(const Ps& p_);

Ps expect_stmt_end(const Ps& p_, const Text& what);

prism_rtl::JobRef<Ps> start_expect_stmt_end(Ps p_, Text what);

Text describe(const crate::syntax::lexer::TokKind& tok_kind0);

template <class A>
std::tuple<A, Ps> bracketed(const Ps& p_, const prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)>& f_fn);

template <class A>
prism_rtl::JobRef<std::tuple<A, Ps>> start_bracketed(Ps p_, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_fn);

Ps with_step_mode(const Ps& p_, const bool& flag);

template <class A>
std::tuple<Array<A>, Ps> layout_items(const Ps& p0, const prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)>& f_fn);

template <class A>
prism_rtl::JobRef<std::tuple<Array<A>, Ps>> start_layout_items(Ps p0, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_fn);

template <class A>
std::tuple<Array<A>, Ps> commas(const Ps& p0, const prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)>& f_fn);

template <class A>
prism_rtl::JobRef<std::tuple<Array<A>, Ps>> start_commas(Ps p0, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_fn);

crate::syntax::SName no_sname();

crate::syntax::Ident no_ident();

bool is_upper_name(const crate::syntax::SName& n);

bool is_callee(const crate::syntax::SName& n);

bool is_topic(const crate::syntax::SName& n);

Text name_text(const crate::syntax::SName& n);

std::tuple<crate::syntax::SName, Ps> parse_sname(const Ps& p_);

std::tuple<crate::syntax::Ident, Ps> parse_ident(const Ps& p_);

std::tuple<crate::syntax::QualName, Ps> parse_qual_name(const Ps& p_);

std::tuple<crate::syntax::TraitRef, Ps> parse_trait_ref(const Ps& p_);

Ps check_name_scope(const Ps& p_, const crate::syntax::SName& name);

Ps check_type_name_scope(const Ps& p_, const crate::syntax::SName& name);

}  // namespace syntax::parser


namespace syntax::parser {

/// The step machine of `ParseFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseFile: unbounded fn Text -> Parsed
struct ParseFile : prism_rtl::Job<Parsed> {
    Text src;
    ParseFile(Text src) : src(std::move(src)) {}
    prism_rtl::Turn<Parsed> cycle() const override;
};


/// The step machine of `ParseFragment`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseFragment: unbounded fn Text -> Parsed
struct ParseFragment : prism_rtl::Job<Parsed> {
    Text src;
    ParseFragment(Text src) : src(std::move(src)) {}
    prism_rtl::Turn<Parsed> cycle() const override;
};


/// The step machine of `NewPs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NewPs: unbounded fn [Tok] -> Ps
struct NewPs : prism_rtl::Job<Ps> {
    Array<crate::syntax::lexer::Tok> toks0;
    NewPs(Array<crate::syntax::lexer::Tok> toks0) : toks0(std::move(toks0)) {}
    prism_rtl::Turn<Ps> cycle() const override;
};


/// The step machine of `Sub`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Sub: unbounded fn Ps, [Tok], Range -> Ps
struct Sub : prism_rtl::Job<Ps> {
    Ps p_;
    Array<crate::syntax::lexer::Tok> toks;
    crate::syntax::Range end;
    Sub(Ps p_, Array<crate::syntax::lexer::Tok> toks, crate::syntax::Range end) : p_(std::move(p_)), toks(std::move(toks)), end(std::move(end)) {}
    prism_rtl::Turn<Ps> cycle() const override;
};


/// The step machine of `PairBrackets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PairBrackets: unbounded fn [Tok] -> [Pair]
struct PairBrackets : prism_rtl::Job<Array<Pair>> {
    Array<crate::syntax::lexer::Tok> toks;
    PairBrackets(Array<crate::syntax::lexer::Tok> toks) : toks(std::move(toks)) {}
    prism_rtl::Turn<Array<Pair>> cycle() const override;
};


/// The step machine of `Recover`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Recover: unbounded fn Ps -> Ps
struct Recover : prism_rtl::Job<Ps> {
    Ps p0;
    Recover(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<Ps> cycle() const override;
};


/// The step machine of `Recovered`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Recovered: unbounded fn Ps -> Ps
struct Recovered : prism_rtl::Job<Ps> {
    Ps p_;
    Recovered(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<Ps> cycle() const override;
};


/// The step machine of `ExpectStmtEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExpectStmtEnd: unbounded fn Ps, Text -> Ps
struct ExpectStmtEnd : prism_rtl::Job<Ps> {
    Ps p_;
    Text what;
    ExpectStmtEnd(Ps p_, Text what) : p_(std::move(p_)), what(std::move(what)) {}
    prism_rtl::Turn<Ps> cycle() const override;
};


/// The step machine of `Bracketed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Bracketed: fn Ps, (fn Ps -> ((a, Ps))) -> ((a, Ps))
template <class A>
struct Bracketed : prism_rtl::Job<std::tuple<A, Ps>> {
    Ps p_;
    prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_fn;
    Bracketed(Ps p_, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_fn) : p_(std::move(p_)), f_fn(std::move(f_fn)) {}
    prism_rtl::Turn<std::tuple<A, Ps>> cycle() const override;
};


/// The step machine of `LayoutItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LayoutItems: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
template <class A>
struct LayoutItems : prism_rtl::Job<std::tuple<Array<A>, Ps>> {
    Ps p0;
    prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_fn;
    LayoutItems(Ps p0, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_fn) : p0(std::move(p0)), f_fn(std::move(f_fn)) {}
    prism_rtl::Turn<std::tuple<Array<A>, Ps>> cycle() const override;
};


/// The step machine of `Commas`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Commas: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
template <class A>
struct Commas : prism_rtl::Job<std::tuple<Array<A>, Ps>> {
    Ps p0;
    prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_fn;
    Commas(Ps p0, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_fn) : p0(std::move(p0)), f_fn(std::move(f_fn)) {}
    prism_rtl::Turn<std::tuple<Array<A>, Ps>> cycle() const override;
};


}  // namespace syntax::parser

}  // namespace crate
