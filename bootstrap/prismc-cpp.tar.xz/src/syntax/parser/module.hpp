// The module `Syntax.Parser`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/parser/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::parser {

crate::syntax::Range no_range_p();

crate::syntax::lexer::Tok eof_tok_p();

Pair no_pair_p();

Parsed parse_file_f(const Text& src_p0);

prism_rtl::JobRef<Parsed> start_parse_file_f(Text src_p0);

Parsed parse_fragment_f(const Text& src_p0);

prism_rtl::JobRef<Parsed> start_parse_fragment_f(Text src_p0);

Ps new_ps_f(const Array<crate::syntax::lexer::Tok>& toks0_p0);

prism_rtl::JobRef<Ps> start_new_ps_f(Array<crate::syntax::lexer::Tok> toks0_p0);

Ps sub_f(const Ps& p_p0, const Array<crate::syntax::lexer::Tok>& toks_p1, const crate::syntax::Range& end_p2);

prism_rtl::JobRef<Ps> start_sub_f(Ps p_p0, Array<crate::syntax::lexer::Tok> toks_p1, crate::syntax::Range end_p2);

Ps absorb_f(const Ps& p_p0, const Ps& sub_p1);

Array<crate::syntax::Diag> finish_diags_f(const Array<crate::syntax::Diag>& ds_p0);

Nat stage_rank_f(const Text& text0);

bool diag_before_f(const crate::syntax::Diag& a_p0, const crate::syntax::Diag& b_p1);

Array<crate::syntax::Diag> insert_diag_f(const Array<crate::syntax::Diag>& sorted_p0, const crate::syntax::Diag& d_p1);

Array<Pair> pair_brackets_f(const Array<crate::syntax::lexer::Tok>& toks_p0);

prism_rtl::JobRef<Array<Pair>> start_pair_brackets_f(Array<crate::syntax::lexer::Tok> toks_p0);

bool double_at_f(const Array<Pair>& pairs_p0, const Array<crate::syntax::lexer::Tok>& toks_p1, const Nat& i_p2, const Nat& j_p3, const Text& kind_p4);

std::optional<Text> open_kind_of_o(const crate::syntax::lexer::TokKind& tok_kind0);

std::optional<Text> close_kind_of_o(const crate::syntax::lexer::TokKind& tok_kind0);

bool is_open_of_f(const crate::syntax::lexer::TokKind& tok_kind0, const Text& text1);

crate::syntax::lexer::Tok tk_f(const Ps& p_p0);

crate::syntax::lexer::Tok tk_at_f(const Ps& p_p0, const Nat& n_p1);

crate::syntax::lexer::TokKind kind_f(const Ps& p_p0);

crate::syntax::lexer::TokKind kind_at_f(const Ps& p_p0, const Nat& n_p1);

crate::syntax::Range here_f(const Ps& p_p0);

crate::syntax::Range prev_f(const Ps& p_p0);

crate::syntax::Range to_f(const crate::syntax::Range& a_p0, const crate::syntax::Range& b_p1);

crate::syntax::Range at_end_f(const crate::syntax::Range& r_p0);

Ps adv_f(const Ps& p_p0);

Pair pair_at_f(const Ps& p_p0);

bool at_eof_f(const Ps& p_p0);

bool at_kw_f(const Ps& p_p0, const Text& w_p1);

bool at_op_f(const Ps& p_p0, const Text& op_p1);

bool at_sep_f(const Ps& p_p0);

bool at_open_l_f(const Ps& p_p0);

bool at_close_l_f(const Ps& p_p0);

bool at_comma_f(const Ps& p_p0);

bool at_colon_f(const Ps& p_p0);

bool is_open_kind_f(const crate::syntax::lexer::TokKind& tok_kind0, const Text& text1);

bool at_double_open_f(const Ps& p_p0, const Text& kind_p1);

bool at_single_open_f(const Ps& p_p0, const Text& kind_p1);

bool at_close_f(const Ps& p_p0, const Text& kind_p1);

Ps open_double_f(const Ps& p_p0);

Ps close_double_f(const Ps& p_p0, const Text& kind_p1);

Ps expect_close_f(const Ps& p_p0, const Text& kind_p1);

crate::syntax::Diag parse_diag_f(const crate::syntax::Range& span_p0, const Text& message_p1);

Ps error_at_f(const Ps& p_p0, const crate::syntax::Range& span_p1, const Text& message_p2);

Ps error_here_f(const Ps& p_p0, const Text& message_p1);

Ps fail_f(const Ps& p_p0);

Ps unbad_f(const Ps& p_p0);

Ps note_error_f(const Ps& p_p0, const crate::syntax::Range& span_p1, const Text& message_p2);

Ps complain_f(const Ps& p_p0, const Text& message_p1);

Ps out_of_scope_f(const Ps& p_p0, const crate::syntax::Range& span_p1, const Text& feature_p2, const Text& message_p3);

Ps expect_colon_f(const Ps& p_p0);

Ps expect_op_f(const Ps& p_p0, const Text& op_p1);

Ps expect_kw_f(const Ps& p_p0, const Text& w_p1);

Ps recover_f(const Ps& p0_p0);

prism_rtl::JobRef<Ps> start_recover_f(Ps p0_p0);

Ps recovered_f(const Ps& p_p0);

prism_rtl::JobRef<Ps> start_recovered_f(Ps p_p0);

bool at_stmt_boundary_f(const Ps& p_p0);

Ps expect_stmt_end_f(const Ps& p_p0, const Text& what_p1);

prism_rtl::JobRef<Ps> start_expect_stmt_end_f(Ps p_p0, Text what_p1);

Text describe_f(const crate::syntax::lexer::TokKind& tok_kind0);

template <class A>
std::tuple<A, Ps> bracketed_f(const Ps& p_p0, const prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)>& f_f1);

template <class A>
prism_rtl::JobRef<std::tuple<A, Ps>> start_bracketed_f(Ps p_p0, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_f1);

Ps with_step_mode_f(const Ps& p_p0, const bool& flag_p1);

template <class A>
std::tuple<Array<A>, Ps> layout_items_f(const Ps& p0_p0, const prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)>& f_f1);

template <class A>
prism_rtl::JobRef<std::tuple<Array<A>, Ps>> start_layout_items_f(Ps p0_p0, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_f1);

template <class A>
std::tuple<Array<A>, Ps> commas_f(const Ps& p0_p0, const prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)>& f_f1);

template <class A>
prism_rtl::JobRef<std::tuple<Array<A>, Ps>> start_commas_f(Ps p0_p0, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_f1);

crate::syntax::SName no_sname_p();

crate::syntax::Ident no_ident_p();

bool is_upper_name_f(const crate::syntax::SName& n_p0);

bool is_callee_f(const crate::syntax::SName& n_p0);

bool is_topic_f(const crate::syntax::SName& n_p0);

Text name_text_f(const crate::syntax::SName& n_p0);

std::tuple<crate::syntax::SName, Ps> parse_sname_f(const Ps& p_p0);

std::tuple<crate::syntax::Ident, Ps> parse_ident_f(const Ps& p_p0);

std::tuple<crate::syntax::QualName, Ps> parse_qual_name_f(const Ps& p_p0);

std::tuple<crate::syntax::TraitRef, Ps> parse_trait_ref_f(const Ps& p_p0);

Ps check_name_scope_f(const Ps& p_p0, const crate::syntax::SName& name_p1);

Ps check_type_name_scope_f(const Ps& p_p0, const crate::syntax::SName& name_p1);

}  // namespace syntax::parser


namespace syntax::parser {

/// The step machine of `ParseFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseFile: unbounded fn Text -> Parsed
struct ParseFile : prism_rtl::Job<Parsed> {
    Text src_p0;
    ParseFile(Text src_p0) : src_p0(std::move(src_p0)) {}
    prism_rtl::Turn<Parsed> cycle() const override;
};


/// The step machine of `ParseFragment`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseFragment: unbounded fn Text -> Parsed
struct ParseFragment : prism_rtl::Job<Parsed> {
    Text src_p0;
    ParseFragment(Text src_p0) : src_p0(std::move(src_p0)) {}
    prism_rtl::Turn<Parsed> cycle() const override;
};


/// The step machine of `NewPs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NewPs: unbounded fn [Tok] -> Ps
struct NewPs : prism_rtl::Job<Ps> {
    Array<crate::syntax::lexer::Tok> toks0_p0;
    NewPs(Array<crate::syntax::lexer::Tok> toks0_p0) : toks0_p0(std::move(toks0_p0)) {}
    prism_rtl::Turn<Ps> cycle() const override;
};


/// The step machine of `Sub`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Sub: unbounded fn Ps, [Tok], Range -> Ps
struct Sub : prism_rtl::Job<Ps> {
    Ps p_p0;
    Array<crate::syntax::lexer::Tok> toks_p1;
    crate::syntax::Range end_p2;
    Sub(Ps p_p0, Array<crate::syntax::lexer::Tok> toks_p1, crate::syntax::Range end_p2) : p_p0(std::move(p_p0)), toks_p1(std::move(toks_p1)), end_p2(std::move(end_p2)) {}
    prism_rtl::Turn<Ps> cycle() const override;
};


/// The step machine of `PairBrackets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PairBrackets: unbounded fn [Tok] -> [Pair]
struct PairBrackets : prism_rtl::Job<Array<Pair>> {
    Array<crate::syntax::lexer::Tok> toks_p0;
    PairBrackets(Array<crate::syntax::lexer::Tok> toks_p0) : toks_p0(std::move(toks_p0)) {}
    prism_rtl::Turn<Array<Pair>> cycle() const override;
};


/// The step machine of `Recover`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Recover: unbounded fn Ps -> Ps
struct Recover : prism_rtl::Job<Ps> {
    Ps p0_p0;
    Recover(Ps p0_p0) : p0_p0(std::move(p0_p0)) {}
    prism_rtl::Turn<Ps> cycle() const override;
};


/// The step machine of `Recovered`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Recovered: unbounded fn Ps -> Ps
struct Recovered : prism_rtl::Job<Ps> {
    Ps p_p0;
    Recovered(Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<Ps> cycle() const override;
};


/// The step machine of `ExpectStmtEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExpectStmtEnd: unbounded fn Ps, Text -> Ps
struct ExpectStmtEnd : prism_rtl::Job<Ps> {
    Ps p_p0;
    Text what_p1;
    ExpectStmtEnd(Ps p_p0, Text what_p1) : p_p0(std::move(p_p0)), what_p1(std::move(what_p1)) {}
    prism_rtl::Turn<Ps> cycle() const override;
};


/// The step machine of `Bracketed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Bracketed: fn Ps, (fn Ps -> ((a, Ps))) -> ((a, Ps))
template <class A>
struct Bracketed : prism_rtl::Job<std::tuple<A, Ps>> {
    Ps p_p0;
    prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_f1;
    Bracketed(Ps p_p0, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_f1) : p_p0(std::move(p_p0)), f_f1(std::move(f_f1)) {}
    prism_rtl::Turn<std::tuple<A, Ps>> cycle() const override;
};


/// The step machine of `LayoutItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LayoutItems: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
template <class A>
struct LayoutItems : prism_rtl::Job<std::tuple<Array<A>, Ps>> {
    Ps p0_p0;
    prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_f1;
    LayoutItems(Ps p0_p0, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_f1) : p0_p0(std::move(p0_p0)), f_f1(std::move(f_f1)) {}
    prism_rtl::Turn<std::tuple<Array<A>, Ps>> cycle() const override;
};


/// The step machine of `Commas`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Commas: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
template <class A>
struct Commas : prism_rtl::Job<std::tuple<Array<A>, Ps>> {
    Ps p0_p0;
    prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_f1;
    Commas(Ps p0_p0, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_f1) : p0_p0(std::move(p0_p0)), f_f1(std::move(f_f1)) {}
    prism_rtl::Turn<std::tuple<Array<A>, Ps>> cycle() const override;
};


}  // namespace syntax::parser

}  // namespace crate
