// The module `Syntax.Parser.Blocks`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/parser/blocks/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::parser::blocks {

std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon(const crate::syntax::parser::Ps& p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> start_parse_block_after_colon(crate::syntax::parser::Ps p0);

std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_indented_block(const crate::syntax::parser::Ps& p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> start_parse_indented_block(crate::syntax::parser::Ps p0);

std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_until_eof(const crate::syntax::parser::Ps& p_, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> start_parse_block_until_eof(crate::syntax::parser::Ps p_, crate::syntax::Range span);

std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> stmts_until(const crate::syntax::parser::Ps& p0, const bool& indented);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>> start_stmts_until(crate::syntax::parser::Ps p0, bool indented);

std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps> parse_stmt(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps>> start_parse_stmt(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> stmt_kind_of(const crate::syntax::parser::Ps& p_, const crate::syntax::Range& start);

prism_rtl::JobRef<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> start_stmt_kind_of(crate::syntax::parser::Ps p_, crate::syntax::Range start);

std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> other_stmt(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> start_other_stmt(crate::syntax::parser::Ps p_);

std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::parser::Ps> optional_rhs(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::parser::Ps>> start_optional_rhs(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> parse_update_stmt(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> start_parse_update_stmt(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_reference(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_reference(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> lens_steps(const crate::syntax::Expr& e0, const crate::syntax::parser::Ps& p0);

}  // namespace syntax::parser::blocks


namespace syntax::parser::blocks {

/// The step machine of `ParseBlockAfterColon`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseBlockAfterColon: unbounded fn Ps -> ((Block, Ps))
struct ParseBlockAfterColon : prism_rtl::Job<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    ParseBlockAfterColon(crate::syntax::parser::Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseIndentedBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseIndentedBlock: unbounded fn Ps -> ((Block, Ps))
struct ParseIndentedBlock : prism_rtl::Job<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    ParseIndentedBlock(crate::syntax::parser::Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseBlockUntilEof`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseBlockUntilEof: unbounded fn Ps, Range -> ((Block, Ps))
struct ParseBlockUntilEof : prism_rtl::Job<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    crate::syntax::Range span;
    ParseBlockUntilEof(crate::syntax::parser::Ps p_, crate::syntax::Range span) : p_(std::move(p_)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `StmtsUntil`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtsUntil: unbounded fn Ps, Bool -> (([Stmt], Ps))
struct StmtsUntil : prism_rtl::Job<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    bool indented;
    StmtsUntil(crate::syntax::parser::Ps p0, bool indented) : p0(std::move(p0)), indented(std::move(indented)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseStmt: unbounded fn Ps -> ((Stmt, Ps))
struct ParseStmt : prism_rtl::Job<std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseStmt(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `StmtKindOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtKindOf: unbounded fn Ps, Range -> ((StmtKind, Ps))
struct StmtKindOf : prism_rtl::Job<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    crate::syntax::Range start;
    StmtKindOf(crate::syntax::parser::Ps p_, crate::syntax::Range start) : p_(std::move(p_)), start(std::move(start)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `OtherStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OtherStmt: unbounded fn Ps -> ((StmtKind, Ps))
struct OtherStmt : prism_rtl::Job<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    OtherStmt(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `OptionalRhs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptionalRhs: unbounded fn Ps -> ((?Expr, Ps))
struct OptionalRhs : prism_rtl::Job<std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    OptionalRhs(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseUpdateStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseUpdateStmt: unbounded fn Ps -> ((StmtKind, Ps))
struct ParseUpdateStmt : prism_rtl::Job<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseUpdateStmt(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseReference`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseReference: unbounded fn Ps -> ((Expr, Ps))
struct ParseReference : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseReference(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


}  // namespace syntax::parser::blocks

}  // namespace crate
