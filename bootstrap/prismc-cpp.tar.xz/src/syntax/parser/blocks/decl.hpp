// The module `Syntax.Parser.Blocks`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace syntax::parser::blocks {

struct ParseBlockAfterColon;

struct ParseIndentedBlock;

struct ParseBlockUntilEof;

struct StmtsUntil;

struct ParseStmt;

struct StmtKindOf;

struct OtherStmt;

struct OptionalRhs;

struct ParseUpdateStmt;

struct ParseReference;

}  // namespace syntax::parser::blocks


}  // namespace crate
