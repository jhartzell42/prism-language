// The module `Syntax.Parser.Decls`: its value types (records, tags, newtypes and choices with their cases), each
// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism
// source, not this file.
#pragma once

#include <syntax/parser/decls/decl.hpp>
#include "elem.decl.hpp"
#include <syntax/decls/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/regexes/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <syntax/parser/blocks/decl.hpp>
#include <syntax/parser/expr/decl.hpp>
#include <syntax/parser/test_language/decl.hpp>
#include <syntax/parser/types/decl.hpp>
#include <syntax/sexp/decl.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::parser::decls {

/// `ModRead`:
///
/// ```prism
/// type ModRead = record:
/// ```
struct ModRead {
    using prism_value = void;
    crate::syntax::parser::Ps p_p;
    crate::syntax::Module m_p;
    Nat stage_p;
    const ModRead* operator->() const { return this; }
    ModRead* operator->() { return this; }
    bool operator==(const ModRead&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ModRead> from_pod(const Pod& whole);
};


}  // namespace syntax::parser::decls

}  // namespace crate
