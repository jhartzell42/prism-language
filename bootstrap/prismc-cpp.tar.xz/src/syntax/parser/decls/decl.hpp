// The module `Syntax.Parser.Decls`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace syntax::parser::decls {

struct ModRead;

struct ParseModule;

struct ModuleItem;

struct HeaderOrDecl;

struct ParseDecl;

struct DeclKindOf;

struct OptionalAnnotation;

struct ParseSignature;

struct OptionalBounds;

struct ParseFnClause;

struct ParseFnBody;

struct ParseTypeDecl;

struct ParseTypeBody;

struct ParseFieldBlock;

struct ParseField;

struct ParseCase;

struct ParseTagDecl;

struct ParseTraitDecl;

struct ParseImplDecl;

struct ParseTraitItems;

struct ParseTraitItem;

struct OptionalType;

}  // namespace syntax::parser::decls


}  // namespace crate
