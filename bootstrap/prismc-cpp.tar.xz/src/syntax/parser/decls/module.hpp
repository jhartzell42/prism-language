// The module `Syntax.Parser.Decls`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/parser/decls/types.hpp>
#include "elem.types.hpp"
#include <syntax/parser/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::parser::decls {

std::tuple<crate::syntax::Module, crate::syntax::parser::Ps> parse_module(const crate::syntax::parser::Ps& p0_p0, const bool& fragment_p1);

prism_rtl::JobRef<std::tuple<crate::syntax::Module, crate::syntax::parser::Ps>> start_parse_module(crate::syntax::parser::Ps p0_p0, bool fragment_p1);

ModRead module_item(const ModRead& s_p0, const bool& fragment_p1);

prism_rtl::JobRef<ModRead> start_module_item(ModRead s_p0, bool fragment_p1);

ModRead header_or_decl(const ModRead& s_p0, const bool& fragment_p1, const crate::syntax::Range& item_start_p2);

prism_rtl::JobRef<ModRead> start_header_or_decl(ModRead s_p0, bool fragment_p1, crate::syntax::Range item_start_p2);

ModRead mod_header(const ModRead& s_p0, const crate::syntax::parser::Ps& p_p1, const bool& is_test_p2, const crate::syntax::Range& item_start_p3);

bool is_kw_kind(const crate::syntax::lexer::TokKind& k_p0, const Text& w_p1);

crate::syntax::QualName no_qual();

std::tuple<crate::syntax::Use, crate::syntax::parser::Ps> parse_use(const crate::syntax::parser::Ps& p_p0, const crate::syntax::Range& start_p1);

crate::syntax::Expr no_expr();

crate::syntax::Type no_type();

crate::syntax::Pattern_ no_pattern();

crate::syntax::Block no_block();

std::tuple<crate::syntax::decls::Decl, crate::syntax::parser::Ps> parse_decl(const crate::syntax::parser::Ps& p_p0, const bool& fragment_p1);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::Decl, crate::syntax::parser::Ps>> start_parse_decl(crate::syntax::parser::Ps p_p0, bool fragment_p1);

std::tuple<crate::syntax::decls::DeclKind, crate::syntax::parser::Ps> decl_kind_of(const crate::syntax::parser::Ps& p_p0, const bool& fragment_p1, const crate::syntax::Range& start_p2);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::DeclKind, crate::syntax::parser::Ps>> start_decl_kind_of(crate::syntax::parser::Ps p_p0, bool fragment_p1, crate::syntax::Range start_p2);

std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps> optional_annotation(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps>> start_optional_annotation(crate::syntax::parser::Ps p_p0);

std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps> parse_signature(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps>> start_parse_signature(crate::syntax::parser::Ps p_p0);

std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps> optional_bounds(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>> start_optional_bounds(crate::syntax::parser::Ps p_p0);

std::tuple<crate::syntax::decls::DefName, crate::syntax::parser::Ps> parse_def_name(const crate::syntax::parser::Ps& p_p0);

std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps> parse_fn_clause(const crate::syntax::parser::Ps& p0_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps>> start_parse_fn_clause(crate::syntax::parser::Ps p0_p0);

std::tuple<crate::syntax::decls::FnBody, crate::syntax::parser::Ps> parse_fn_body(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::FnBody, crate::syntax::parser::Ps>> start_parse_fn_body(crate::syntax::parser::Ps p_p0);

std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps> lower_params(const crate::syntax::parser::Ps& p0_p0);

bool is_plain_lower(const crate::syntax::lexer::TokKind& tok_kind0);

std::tuple<crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps> parse_type_decl(const crate::syntax::parser::Ps& p0_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps>> start_parse_type_decl(crate::syntax::parser::Ps p0_p0);

std::tuple<std::optional<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps> parse_type_body(const crate::syntax::parser::Ps& p_p0, const crate::syntax::QualName& name_p1, const Array<crate::syntax::Ident>& params_p2);

prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps>> start_parse_type_body(crate::syntax::parser::Ps p_p0, crate::syntax::QualName name_p1, Array<crate::syntax::Ident> params_p2);

bool is_unit_body(const crate::syntax::parser::Ps& p_p0, const crate::syntax::lexer::NameTok& n_p1, const Array<crate::syntax::Ident>& params_p2);

std::tuple<Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps> parse_field_block(const crate::syntax::parser::Ps& p0_p0);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps>> start_parse_field_block(crate::syntax::parser::Ps p0_p0);

std::tuple<crate::syntax::decls::Field, crate::syntax::parser::Ps> parse_field(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::Field, crate::syntax::parser::Ps>> start_parse_field(crate::syntax::parser::Ps p_p0);

std::tuple<crate::syntax::decls::Case_, crate::syntax::parser::Ps> parse_case(const crate::syntax::parser::Ps& p0_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::Case_, crate::syntax::parser::Ps>> start_parse_case(crate::syntax::parser::Ps p0_p0);

std::tuple<crate::syntax::decls::TagDecl, crate::syntax::parser::Ps> parse_tag_decl(const crate::syntax::parser::Ps& p0_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::TagDecl, crate::syntax::parser::Ps>> start_parse_tag_decl(crate::syntax::parser::Ps p0_p0);

std::tuple<crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps> parse_trait_decl(const crate::syntax::parser::Ps& p0_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps>> start_parse_trait_decl(crate::syntax::parser::Ps p0_p0);

std::tuple<crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps> parse_impl_decl(const crate::syntax::parser::Ps& p0_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps>> start_parse_impl_decl(crate::syntax::parser::Ps p0_p0);

std::tuple<Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps> parse_trait_items(const crate::syntax::parser::Ps& p0_p0);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps>> start_parse_trait_items(crate::syntax::parser::Ps p0_p0);

std::tuple<crate::syntax::decls::TraitItem, crate::syntax::parser::Ps> parse_trait_item(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::TraitItem, crate::syntax::parser::Ps>> start_parse_trait_item(crate::syntax::parser::Ps p_p0);

std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps> optional_type(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps>> start_optional_type(crate::syntax::parser::Ps p_p0);

crate::syntax::parser::Ps check_higher_kinded(const crate::syntax::parser::Ps& p_p0, const crate::syntax::decls::TraitDecl& t_p1);

bool item_applies(const crate::syntax::decls::TraitItem& trait_item0, const Array<crate::syntax::Ident>& xs1);

bool any_applies(const Array<crate::syntax::Type>& ts_p0, const Array<crate::syntax::Ident>& params_p1);

bool applies(const crate::syntax::Type& ty_p0, const Array<crate::syntax::Ident>& params_p1);

}  // namespace syntax::parser::decls


namespace syntax::parser::decls {

/// The step machine of `ParseModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseModule: unbounded fn Ps, Bool -> ((Module, Ps))
struct ParseModule : prism_rtl::Job<std::tuple<crate::syntax::Module, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    bool fragment_p1;
    ParseModule(crate::syntax::parser::Ps p0_p0, bool fragment_p1) : p0_p0(std::move(p0_p0)), fragment_p1(std::move(fragment_p1)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Module, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ModuleItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ModuleItem: unbounded fn ModRead, Bool -> ModRead
struct ModuleItem : prism_rtl::Job<ModRead> {
    ModRead s_p0;
    bool fragment_p1;
    ModuleItem(ModRead s_p0, bool fragment_p1) : s_p0(std::move(s_p0)), fragment_p1(std::move(fragment_p1)) {}
    prism_rtl::Turn<ModRead> cycle() const override;
};


/// The step machine of `HeaderOrDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HeaderOrDecl: unbounded fn ModRead, Bool, Range -> ModRead
struct HeaderOrDecl : prism_rtl::Job<ModRead> {
    ModRead s_p0;
    bool fragment_p1;
    crate::syntax::Range item_start_p2;
    HeaderOrDecl(ModRead s_p0, bool fragment_p1, crate::syntax::Range item_start_p2) : s_p0(std::move(s_p0)), fragment_p1(std::move(fragment_p1)), item_start_p2(std::move(item_start_p2)) {}
    prism_rtl::Turn<ModRead> cycle() const override;
};


/// The step machine of `ParseDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseDecl: unbounded fn Ps, Bool -> ((Decl, Ps))
struct ParseDecl : prism_rtl::Job<std::tuple<crate::syntax::decls::Decl, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    bool fragment_p1;
    ParseDecl(crate::syntax::parser::Ps p_p0, bool fragment_p1) : p_p0(std::move(p_p0)), fragment_p1(std::move(fragment_p1)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::Decl, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `DeclKindOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DeclKindOf: unbounded fn Ps, Bool, Range -> ((DeclKind, Ps))
struct DeclKindOf : prism_rtl::Job<std::tuple<crate::syntax::decls::DeclKind, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    bool fragment_p1;
    crate::syntax::Range start_p2;
    DeclKindOf(crate::syntax::parser::Ps p_p0, bool fragment_p1, crate::syntax::Range start_p2) : p_p0(std::move(p_p0)), fragment_p1(std::move(fragment_p1)), start_p2(std::move(start_p2)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::DeclKind, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `OptionalAnnotation`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptionalAnnotation: unbounded fn Ps -> ((?Type, Ps))
struct OptionalAnnotation : prism_rtl::Job<std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    OptionalAnnotation(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseSignature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseSignature: unbounded fn Ps -> ((Signature, Ps))
struct ParseSignature : prism_rtl::Job<std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    ParseSignature(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `OptionalBounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptionalBounds: unbounded fn Ps -> (([Bound], Ps))
struct OptionalBounds : prism_rtl::Job<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    OptionalBounds(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseFnClause`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseFnClause: unbounded fn Ps -> ((FnClause, Ps))
struct ParseFnClause : prism_rtl::Job<std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    ParseFnClause(crate::syntax::parser::Ps p0_p0) : p0_p0(std::move(p0_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseFnBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseFnBody: unbounded fn Ps -> ((FnBody, Ps))
struct ParseFnBody : prism_rtl::Job<std::tuple<crate::syntax::decls::FnBody, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    ParseFnBody(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::FnBody, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseTypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTypeDecl: unbounded fn Ps -> ((TypeDecl, Ps))
struct ParseTypeDecl : prism_rtl::Job<std::tuple<crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    ParseTypeDecl(crate::syntax::parser::Ps p0_p0) : p0_p0(std::move(p0_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseTypeBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTypeBody: unbounded fn Ps, QualName, [Ident] -> ((?TypeBody, Ps))
struct ParseTypeBody : prism_rtl::Job<std::tuple<std::optional<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    crate::syntax::QualName name_p1;
    Array<crate::syntax::Ident> params_p2;
    ParseTypeBody(crate::syntax::parser::Ps p_p0, crate::syntax::QualName name_p1, Array<crate::syntax::Ident> params_p2) : p_p0(std::move(p_p0)), name_p1(std::move(name_p1)), params_p2(std::move(params_p2)) {}
    prism_rtl::Turn<std::tuple<std::optional<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseFieldBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseFieldBlock: unbounded fn Ps -> (([Field], Ps))
struct ParseFieldBlock : prism_rtl::Job<std::tuple<Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    ParseFieldBlock(crate::syntax::parser::Ps p0_p0) : p0_p0(std::move(p0_p0)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseField: unbounded fn Ps -> ((Field, Ps))
struct ParseField : prism_rtl::Job<std::tuple<crate::syntax::decls::Field, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    ParseField(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::Field, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseCase: unbounded fn Ps -> ((Case, Ps))
struct ParseCase : prism_rtl::Job<std::tuple<crate::syntax::decls::Case_, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    ParseCase(crate::syntax::parser::Ps p0_p0) : p0_p0(std::move(p0_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::Case_, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseTagDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTagDecl: unbounded fn Ps -> ((TagDecl, Ps))
struct ParseTagDecl : prism_rtl::Job<std::tuple<crate::syntax::decls::TagDecl, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    ParseTagDecl(crate::syntax::parser::Ps p0_p0) : p0_p0(std::move(p0_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::TagDecl, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseTraitDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTraitDecl: unbounded fn Ps -> ((TraitDecl, Ps))
struct ParseTraitDecl : prism_rtl::Job<std::tuple<crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    ParseTraitDecl(crate::syntax::parser::Ps p0_p0) : p0_p0(std::move(p0_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseImplDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseImplDecl: unbounded fn Ps -> ((ImplDecl, Ps))
struct ParseImplDecl : prism_rtl::Job<std::tuple<crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    ParseImplDecl(crate::syntax::parser::Ps p0_p0) : p0_p0(std::move(p0_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseTraitItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTraitItems: unbounded fn Ps -> (([TraitItem], Ps))
struct ParseTraitItems : prism_rtl::Job<std::tuple<Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    ParseTraitItems(crate::syntax::parser::Ps p0_p0) : p0_p0(std::move(p0_p0)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseTraitItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTraitItem: unbounded fn Ps -> ((TraitItem, Ps))
struct ParseTraitItem : prism_rtl::Job<std::tuple<crate::syntax::decls::TraitItem, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    ParseTraitItem(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::TraitItem, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `OptionalType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptionalType: unbounded fn Ps -> ((?Type, Ps))
struct OptionalType : prism_rtl::Job<std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    OptionalType(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps>> cycle() const override;
};


}  // namespace syntax::parser::decls

}  // namespace crate
