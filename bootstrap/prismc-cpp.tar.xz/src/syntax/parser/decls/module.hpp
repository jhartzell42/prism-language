// The module `Syntax.Parser.Decls`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/parser/decls/types.hpp>
#include "elem.types.hpp"
#include <syntax/parser/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::parser::decls {

std::tuple<crate::syntax::Module, crate::syntax::parser::Ps> parse_module(const crate::syntax::parser::Ps& p0, const bool& fragment);

prism_rtl::JobRef<std::tuple<crate::syntax::Module, crate::syntax::parser::Ps>> start_parse_module(crate::syntax::parser::Ps p0, bool fragment);

ModRead module_item(const ModRead& s, const bool& fragment);

prism_rtl::JobRef<ModRead> start_module_item(ModRead s, bool fragment);

ModRead header_or_decl(const ModRead& s, const bool& fragment, const crate::syntax::Range& item_start);

prism_rtl::JobRef<ModRead> start_header_or_decl(ModRead s, bool fragment, crate::syntax::Range item_start);

ModRead mod_header(const ModRead& s, const crate::syntax::parser::Ps& p_, const bool& is_test, const crate::syntax::Range& item_start);

bool is_kw_kind(const crate::syntax::lexer::TokKind& k, const Text& w);

crate::syntax::QualName no_qual();

std::tuple<crate::syntax::Use, crate::syntax::parser::Ps> parse_use(const crate::syntax::parser::Ps& p_, const crate::syntax::Range& start);

crate::syntax::Expr no_expr();

crate::syntax::Type no_type();

crate::syntax::Pattern_ no_pattern();

crate::syntax::Block no_block();

std::tuple<crate::syntax::decls::Decl, crate::syntax::parser::Ps> parse_decl(const crate::syntax::parser::Ps& p_, const bool& fragment);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::Decl, crate::syntax::parser::Ps>> start_parse_decl(crate::syntax::parser::Ps p_, bool fragment);

std::tuple<crate::syntax::decls::DeclKind, crate::syntax::parser::Ps> decl_kind_of(const crate::syntax::parser::Ps& p_, const bool& fragment, const crate::syntax::Range& start);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::DeclKind, crate::syntax::parser::Ps>> start_decl_kind_of(crate::syntax::parser::Ps p_, bool fragment, crate::syntax::Range start);

std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps> optional_annotation(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps>> start_optional_annotation(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps> parse_signature(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps>> start_parse_signature(crate::syntax::parser::Ps p_);

std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps> optional_bounds(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>> start_optional_bounds(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::decls::DefName, crate::syntax::parser::Ps> parse_def_name(const crate::syntax::parser::Ps& p_);

std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps> parse_fn_clause(const crate::syntax::parser::Ps& p0);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps>> start_parse_fn_clause(crate::syntax::parser::Ps p0);

std::tuple<crate::syntax::decls::FnBody, crate::syntax::parser::Ps> parse_fn_body(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::FnBody, crate::syntax::parser::Ps>> start_parse_fn_body(crate::syntax::parser::Ps p_);

std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps> lower_params(const crate::syntax::parser::Ps& p0);

bool is_plain_lower(const crate::syntax::lexer::TokKind& tok_kind0);

std::tuple<crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps> parse_type_decl(const crate::syntax::parser::Ps& p0);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps>> start_parse_type_decl(crate::syntax::parser::Ps p0);

std::tuple<std::optional<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps> parse_type_body(const crate::syntax::parser::Ps& p_, const crate::syntax::QualName& name, const Array<crate::syntax::Ident>& params);

prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps>> start_parse_type_body(crate::syntax::parser::Ps p_, crate::syntax::QualName name, Array<crate::syntax::Ident> params);

bool is_unit_body(const crate::syntax::parser::Ps& p_, const crate::syntax::lexer::NameTok& n, const Array<crate::syntax::Ident>& params);

std::tuple<Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps> parse_field_block(const crate::syntax::parser::Ps& p0);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps>> start_parse_field_block(crate::syntax::parser::Ps p0);

std::tuple<crate::syntax::decls::Field, crate::syntax::parser::Ps> parse_field(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::Field, crate::syntax::parser::Ps>> start_parse_field(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::decls::Case_, crate::syntax::parser::Ps> parse_case(const crate::syntax::parser::Ps& p0);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::Case_, crate::syntax::parser::Ps>> start_parse_case(crate::syntax::parser::Ps p0);

std::tuple<crate::syntax::decls::TagDecl, crate::syntax::parser::Ps> parse_tag_decl(const crate::syntax::parser::Ps& p0);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::TagDecl, crate::syntax::parser::Ps>> start_parse_tag_decl(crate::syntax::parser::Ps p0);

std::tuple<crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps> parse_trait_decl(const crate::syntax::parser::Ps& p0);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps>> start_parse_trait_decl(crate::syntax::parser::Ps p0);

std::tuple<crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps> parse_impl_decl(const crate::syntax::parser::Ps& p0);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps>> start_parse_impl_decl(crate::syntax::parser::Ps p0);

std::tuple<Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps> parse_trait_items(const crate::syntax::parser::Ps& p0);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps>> start_parse_trait_items(crate::syntax::parser::Ps p0);

std::tuple<crate::syntax::decls::TraitItem, crate::syntax::parser::Ps> parse_trait_item(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::TraitItem, crate::syntax::parser::Ps>> start_parse_trait_item(crate::syntax::parser::Ps p_);

std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps> optional_type(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps>> start_optional_type(crate::syntax::parser::Ps p_);

crate::syntax::parser::Ps check_higher_kinded(const crate::syntax::parser::Ps& p_, const crate::syntax::decls::TraitDecl& t);

bool item_applies(const crate::syntax::decls::TraitItem& trait_item0, const Array<crate::syntax::Ident>& xs1);

bool any_applies(const Array<crate::syntax::Type>& ts, const Array<crate::syntax::Ident>& params);

bool applies(const crate::syntax::Type& ty, const Array<crate::syntax::Ident>& params);

}  // namespace syntax::parser::decls


namespace syntax::parser::decls {

/// The step machine of `ParseModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseModule: unbounded fn Ps, Bool -> ((Module, Ps))
struct ParseModule : prism_rtl::Job<std::tuple<crate::syntax::Module, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    bool fragment;
    ParseModule(crate::syntax::parser::Ps p0, bool fragment) : p0(std::move(p0)), fragment(std::move(fragment)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Module, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ModuleItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ModuleItem: unbounded fn ModRead, Bool -> ModRead
struct ModuleItem : prism_rtl::Job<ModRead> {
    ModRead s;
    bool fragment;
    ModuleItem(ModRead s, bool fragment) : s(std::move(s)), fragment(std::move(fragment)) {}
    prism_rtl::Turn<ModRead> cycle() const override;
};


/// The step machine of `HeaderOrDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HeaderOrDecl: unbounded fn ModRead, Bool, Range -> ModRead
struct HeaderOrDecl : prism_rtl::Job<ModRead> {
    ModRead s;
    bool fragment;
    crate::syntax::Range item_start;
    HeaderOrDecl(ModRead s, bool fragment, crate::syntax::Range item_start) : s(std::move(s)), fragment(std::move(fragment)), item_start(std::move(item_start)) {}
    prism_rtl::Turn<ModRead> cycle() const override;
};


/// The step machine of `ParseDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseDecl: unbounded fn Ps, Bool -> ((Decl, Ps))
struct ParseDecl : prism_rtl::Job<std::tuple<crate::syntax::decls::Decl, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    bool fragment;
    ParseDecl(crate::syntax::parser::Ps p_, bool fragment) : p_(std::move(p_)), fragment(std::move(fragment)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::Decl, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `DeclKindOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DeclKindOf: unbounded fn Ps, Bool, Range -> ((DeclKind, Ps))
struct DeclKindOf : prism_rtl::Job<std::tuple<crate::syntax::decls::DeclKind, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    bool fragment;
    crate::syntax::Range start;
    DeclKindOf(crate::syntax::parser::Ps p_, bool fragment, crate::syntax::Range start) : p_(std::move(p_)), fragment(std::move(fragment)), start(std::move(start)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::DeclKind, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `OptionalAnnotation`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptionalAnnotation: unbounded fn Ps -> ((?Type, Ps))
struct OptionalAnnotation : prism_rtl::Job<std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    OptionalAnnotation(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseSignature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseSignature: unbounded fn Ps -> ((Signature, Ps))
struct ParseSignature : prism_rtl::Job<std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseSignature(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `OptionalBounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptionalBounds: unbounded fn Ps -> (([Bound], Ps))
struct OptionalBounds : prism_rtl::Job<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    OptionalBounds(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseFnClause`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseFnClause: unbounded fn Ps -> ((FnClause, Ps))
struct ParseFnClause : prism_rtl::Job<std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    ParseFnClause(crate::syntax::parser::Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseFnBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseFnBody: unbounded fn Ps -> ((FnBody, Ps))
struct ParseFnBody : prism_rtl::Job<std::tuple<crate::syntax::decls::FnBody, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseFnBody(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::FnBody, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseTypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTypeDecl: unbounded fn Ps -> ((TypeDecl, Ps))
struct ParseTypeDecl : prism_rtl::Job<std::tuple<crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    ParseTypeDecl(crate::syntax::parser::Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseTypeBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTypeBody: unbounded fn Ps, QualName, [Ident] -> ((?TypeBody, Ps))
struct ParseTypeBody : prism_rtl::Job<std::tuple<std::optional<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    crate::syntax::QualName name;
    Array<crate::syntax::Ident> params;
    ParseTypeBody(crate::syntax::parser::Ps p_, crate::syntax::QualName name, Array<crate::syntax::Ident> params) : p_(std::move(p_)), name(std::move(name)), params(std::move(params)) {}
    prism_rtl::Turn<std::tuple<std::optional<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseFieldBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseFieldBlock: unbounded fn Ps -> (([Field], Ps))
struct ParseFieldBlock : prism_rtl::Job<std::tuple<Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    ParseFieldBlock(crate::syntax::parser::Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseField: unbounded fn Ps -> ((Field, Ps))
struct ParseField : prism_rtl::Job<std::tuple<crate::syntax::decls::Field, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseField(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::Field, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseCase: unbounded fn Ps -> ((Case, Ps))
struct ParseCase : prism_rtl::Job<std::tuple<crate::syntax::decls::Case_, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    ParseCase(crate::syntax::parser::Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::Case_, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseTagDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTagDecl: unbounded fn Ps -> ((TagDecl, Ps))
struct ParseTagDecl : prism_rtl::Job<std::tuple<crate::syntax::decls::TagDecl, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    ParseTagDecl(crate::syntax::parser::Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::TagDecl, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseTraitDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTraitDecl: unbounded fn Ps -> ((TraitDecl, Ps))
struct ParseTraitDecl : prism_rtl::Job<std::tuple<crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    ParseTraitDecl(crate::syntax::parser::Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseImplDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseImplDecl: unbounded fn Ps -> ((ImplDecl, Ps))
struct ParseImplDecl : prism_rtl::Job<std::tuple<crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    ParseImplDecl(crate::syntax::parser::Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseTraitItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTraitItems: unbounded fn Ps -> (([TraitItem], Ps))
struct ParseTraitItems : prism_rtl::Job<std::tuple<Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    ParseTraitItems(crate::syntax::parser::Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseTraitItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTraitItem: unbounded fn Ps -> ((TraitItem, Ps))
struct ParseTraitItem : prism_rtl::Job<std::tuple<crate::syntax::decls::TraitItem, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseTraitItem(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::TraitItem, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `OptionalType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptionalType: unbounded fn Ps -> ((?Type, Ps))
struct OptionalType : prism_rtl::Job<std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    OptionalType(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps>> cycle() const override;
};


}  // namespace syntax::parser::decls

}  // namespace crate
