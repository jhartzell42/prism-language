// The module `Syntax.Parser`: its value types (records, tags, newtypes and choices with their cases), each
// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism
// source, not this file.
#pragma once

#include <syntax/parser/decl.hpp>
#include "elem.decl.hpp"
#include <syntax/decls/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/regexes/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <syntax/parser/blocks/decl.hpp>
#include <syntax/parser/decls/decl.hpp>
#include <syntax/parser/expr/decl.hpp>
#include <syntax/parser/test_language/decl.hpp>
#include <syntax/parser/types/decl.hpp>
#include <syntax/sexp/decl.hpp>
#include <syntax/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::parser {

/// `Pair`:
///
/// ```prism
/// type Pair = record:
/// ```
struct Pair {
    using prism_value = void;
    std::optional<Nat> partner_o;
    bool outer_p;
    bool inner_p;
    const Pair* operator->() const { return this; }
    Pair* operator->() { return this; }
    bool operator==(const Pair&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Pair> from_pod(const Pod& whole);
};


}  // namespace syntax::parser

namespace syntax::parser {

/// `Parsed`:
///
/// ```prism
/// type Parsed = record:
/// ```
struct Parsed {
    using prism_value = void;
    crate::syntax::Module tree_p;
    Array<crate::syntax::Diag> diags_p;
    const Parsed* operator->() const { return this; }
    Parsed* operator->() { return this; }
    bool operator==(const Parsed&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Parsed> from_pod(const Pod& whole);
};


}  // namespace syntax::parser

namespace syntax::parser {

/// `Ps`:
///
/// ```prism
/// type Ps = record:
/// ```
struct Ps {
    using prism_value = void;
    Array<crate::syntax::lexer::Tok> toks_p;
    Array<Pair> pairs_p;
    Nat pos_p;
    Array<crate::syntax::Diag> diags_p;
    Array<crate::syntax::Diag> out_p;
    bool step_mode_p;
    bool in_trait_p;
    bool bad_p;
    const Ps* operator->() const { return this; }
    Ps* operator->() { return this; }
    bool operator==(const Ps&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Ps> from_pod(const Pod& whole);
};


}  // namespace syntax::parser

}  // namespace crate
