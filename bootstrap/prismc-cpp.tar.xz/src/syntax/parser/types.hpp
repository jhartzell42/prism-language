// The module `Syntax.Parser`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/parser/decl.hpp>
#include "elem.decl.hpp"
#include <syntax/lexer/decl.hpp>
#include <syntax/sexp/decl.hpp>
#include <syntax/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::parser {

/// `Pair`:
///
/// ```prism
/// type Pair = record:
/// ```
struct Pair {
    using prism_value = void;
    std::optional<Nat> partner;
    bool outer;
    bool inner;
    const Pair* operator->() const { return this; }
    Pair* operator->() { return this; }
    bool operator==(const Pair&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Pair> from_pod(const Pod& whole);
};


}  // namespace syntax::parser

namespace syntax::parser {

/// `Parsed`:
///
/// ```prism
/// type Parsed = record:
/// ```
struct Parsed {
    using prism_value = void;
    crate::syntax::Module tree;
    Array<crate::syntax::Diag> diags;
    const Parsed* operator->() const { return this; }
    Parsed* operator->() { return this; }
    bool operator==(const Parsed&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Parsed> from_pod(const Pod& whole);
};


}  // namespace syntax::parser

namespace syntax::parser {

/// `Ps`:
///
/// ```prism
/// type Ps = record:
/// ```
struct Ps {
    using prism_value = void;
    Array<crate::syntax::lexer::Tok> toks;
    Array<Pair> pairs;
    Nat pos;
    Array<crate::syntax::Diag> diags;
    Array<crate::syntax::Diag> out;
    bool step_mode;
    bool in_trait;
    bool bad;
    const Ps* operator->() const { return this; }
    Ps* operator->() { return this; }
    bool operator==(const Ps&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Ps> from_pod(const Pod& whole);
};


}  // namespace syntax::parser

namespace syntax::parser {

/// `ArgsRead`:
///
/// ```prism
/// type ArgsRead = record:
/// ```
struct ArgsRead {
    using prism_value = void;
    Array<crate::syntax::Arg> args;
    bool rest;
    Ps p_;
    bool going;
    const ArgsRead* operator->() const { return this; }
    ArgsRead* operator->() { return this; }
    bool operator==(const ArgsRead&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ArgsRead> from_pod(const Pod& whole);
};


}  // namespace syntax::parser

namespace syntax::parser {

/// `Climb`:
///
/// ```prism
/// type Climb = record:
/// ```
struct Climb {
    using prism_value = void;
    crate::syntax::Expr lhs;
    Ps p_;
    bool going;
    const Climb* operator->() const { return this; }
    Climb* operator->() { return this; }
    bool operator==(const Climb&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Climb> from_pod(const Pod& whole);
};


}  // namespace syntax::parser

namespace syntax::parser {

/// `FieldsRead`:
///
/// ```prism
/// type FieldsRead = record:
/// ```
struct FieldsRead {
    using prism_value = void;
    Array<crate::syntax::FieldPat> fields;
    bool rest;
    Ps p_;
    bool going;
    const FieldsRead* operator->() const { return this; }
    FieldsRead* operator->() { return this; }
    bool operator==(const FieldsRead&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<FieldsRead> from_pod(const Pod& whole);
};


}  // namespace syntax::parser

namespace syntax::parser {

/// `ModRead`:
///
/// ```prism
/// type ModRead = record:
/// ```
struct ModRead {
    using prism_value = void;
    Ps p_;
    crate::syntax::Module m;
    Nat stage;
    const ModRead* operator->() const { return this; }
    ModRead* operator->() { return this; }
    bool operator==(const ModRead&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ModRead> from_pod(const Pod& whole);
};


}  // namespace syntax::parser


}  // namespace crate
