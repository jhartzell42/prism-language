// The module `Syntax.Parser`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/parser/decl.hpp>
#include "elem.decl.hpp"
#include <syntax/decls/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/regexes/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <syntax/parser/blocks/decl.hpp>
#include <syntax/parser/decls/decl.hpp>
#include <syntax/parser/expr/decl.hpp>
#include <syntax/parser/test_language/decl.hpp>
#include <syntax/parser/types/decl.hpp>
#include <syntax/sexp/decl.hpp>
#include <syntax/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::parser {

/// `Pair`:
///
/// ```prism
/// type Pair = record:
/// ```
struct Pair {
    using prism_value = void;
    std::optional<Nat> partner;
    bool outer;
    bool inner;
    const Pair* operator->() const { return this; }
    Pair* operator->() { return this; }
    bool operator==(const Pair&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Pair> from_pod(const Pod& whole);
};


}  // namespace syntax::parser

namespace syntax::parser {

/// `Parsed`:
///
/// ```prism
/// type Parsed = record:
/// ```
struct Parsed {
    using prism_value = void;
    crate::syntax::Module tree;
    Array<crate::syntax::Diag> diags;
    const Parsed* operator->() const { return this; }
    Parsed* operator->() { return this; }
    bool operator==(const Parsed&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Parsed> from_pod(const Pod& whole);
};


}  // namespace syntax::parser

namespace syntax::parser {

/// `Ps`:
///
/// ```prism
/// type Ps = record:
/// ```
struct Ps {
    using prism_value = void;
    Array<crate::syntax::lexer::Tok> toks;
    Array<Pair> pairs;
    Nat pos;
    Array<crate::syntax::Diag> diags;
    Array<crate::syntax::Diag> out;
    bool step_mode;
    bool in_trait;
    bool bad;
    const Ps* operator->() const { return this; }
    Ps* operator->() { return this; }
    bool operator==(const Ps&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Ps> from_pod(const Pod& whole);
};


}  // namespace syntax::parser


}  // namespace crate
