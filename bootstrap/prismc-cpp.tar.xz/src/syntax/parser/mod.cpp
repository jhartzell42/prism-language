// The module `Syntax.Parser`, from `target/bootstrap/cpp-src/prismc/syntax/parser/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <syntax/parser/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::syntax::parser {

void Pair::show(Printer& p) const {
    p.record("Pair", {{"partner", partner}, {"outer", outer}, {"inner", inner}});
}

Pod Pair::to_pod() const {
    return Pod::record("Pair", {{"partner", prism_rtl::to_pod(partner)}, {"outer", prism_rtl::to_pod(outer)}, {"inner", prism_rtl::to_pod(inner)}});
}

Result<Pair> Pair::from_pod(const Pod& whole) {
    return Pair{.partner = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(crate::prelude::field(whole, "partner")))), .outer = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "outer")))), .inner = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "inner"))))};
}


void Parsed::show(Printer& p) const {
    p.record("Parsed", {{"tree", tree}, {"diags", diags}});
}

Pod Parsed::to_pod() const {
    return Pod::record("Parsed", {{"tree", prism_rtl::to_pod(tree)}, {"diags", prism_rtl::to_pod(diags)}});
}

Result<Parsed> Parsed::from_pod(const Pod& whole) {
    return Parsed{.tree = TRY(prism_rtl::from_pod<crate::syntax::Module>(TRY(crate::prelude::field(whole, "tree")))), .diags = TRY(prism_rtl::from_pod<Array<crate::syntax::Diag>>(TRY(crate::prelude::field(whole, "diags"))))};
}


void Ps::show(Printer& p) const {
    p.record("Ps", {{"toks", toks}, {"pairs", pairs}, {"pos", pos}, {"diags", diags}, {"out", out}, {"step_mode", step_mode}, {"in_trait", in_trait}, {"bad", bad}});
}

Pod Ps::to_pod() const {
    return Pod::record("Ps", {{"toks", prism_rtl::to_pod(toks)}, {"pairs", prism_rtl::to_pod(pairs)}, {"pos", prism_rtl::to_pod(pos)}, {"diags", prism_rtl::to_pod(diags)}, {"out", prism_rtl::to_pod(out)}, {"step_mode", prism_rtl::to_pod(step_mode)}, {"in_trait", prism_rtl::to_pod(in_trait)}, {"bad", prism_rtl::to_pod(bad)}});
}

Result<Ps> Ps::from_pod(const Pod& whole) {
    return Ps{.toks = TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::Tok>>(TRY(crate::prelude::field(whole, "toks")))), .pairs = TRY(prism_rtl::from_pod<Array<Pair>>(TRY(crate::prelude::field(whole, "pairs")))), .pos = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "pos")))), .diags = TRY(prism_rtl::from_pod<Array<crate::syntax::Diag>>(TRY(crate::prelude::field(whole, "diags")))), .out = TRY(prism_rtl::from_pod<Array<crate::syntax::Diag>>(TRY(crate::prelude::field(whole, "out")))), .step_mode = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "step_mode")))), .in_trait = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "in_trait")))), .bad = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "bad"))))};
}


/// let noRange
crate::syntax::Range no_range() {
    return crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)};
}


/// let eofTok
crate::syntax::lexer::Tok eof_tok() {
    return crate::syntax::lexer::Tok{.kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), .span = no_range(), .touches = false, .line_start = false};
}


/// let noPair
Pair no_pair() {
    return Pair{.partner = std::optional<Nat>{}, .outer = false, .inner = false};
}


/// ParseFile: unbounded fn Text -> Parsed
Parsed parse_file(const Text& src) {
    auto lexed = crate::syntax::lexer::layout::lex_file(src);
    auto [m, p_] = crate::syntax::parser::decls::parse_module(new_ps(lexed->tokens), false);
    return Parsed{.tree = m, .diags = finish_diags(append(append(lexed.diags, p_.diags), p_->out))};
}


prism_rtl::Turn<Parsed> ParseFile::cycle() const {
    const auto& src = this->src;
    auto src_1 = src;
    return call_then(crate::syntax::lexer::layout::start_lex_file(src_1), [=](crate::syntax::lexer::Lexed lex_file_3387) {
        return ({
            auto lexed = lex_file_3387;
            call_then(start_new_ps(lexed->tokens), [=](Ps new_ps_3431) {
            return call_then(crate::syntax::parser::decls::start_parse_module(new_ps_3431, false), [=](std::tuple<crate::syntax::Module, Ps> parse_module_3418) {
                return ({
                    auto [m, p_] = parse_module_3418;
                    (prism_rtl::finished(Parsed{.tree = m, .diags = finish_diags(append(append(lexed.diags, p_.diags), p_->out))}));
                });
            });
        });
        });
    });
}


/// `Start ParseFile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parsed> start_parse_file(Text src) {
    return prism_rtl::make_rc<ParseFile>(src);
}


/// ParseFragment: unbounded fn Text -> Parsed
Parsed parse_fragment(const Text& src) {
    auto lexed = crate::syntax::lexer::layout::lex_file(src);
    auto [m, p_] = crate::syntax::parser::decls::parse_module(new_ps(lexed->tokens), true);
    return Parsed{.tree = m, .diags = finish_diags(append(append(lexed.diags, p_.diags), p_->out))};
}


prism_rtl::Turn<Parsed> ParseFragment::cycle() const {
    const auto& src = this->src;
    auto src_1 = src;
    return call_then(crate::syntax::lexer::layout::start_lex_file(src_1), [=](crate::syntax::lexer::Lexed lex_file_3780) {
        return ({
            auto lexed = lex_file_3780;
            call_then(start_new_ps(lexed->tokens), [=](Ps new_ps_3824) {
            return call_then(crate::syntax::parser::decls::start_parse_module(new_ps_3824, true), [=](std::tuple<crate::syntax::Module, Ps> parse_module_3811) {
                return ({
                    auto [m, p_] = parse_module_3811;
                    (prism_rtl::finished(Parsed{.tree = m, .diags = finish_diags(append(append(lexed.diags, p_.diags), p_->out))}));
                });
            });
        });
        });
    });
}


/// `Start ParseFragment, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parsed> start_parse_fragment(Text src) {
    return prism_rtl::make_rc<ParseFragment>(src);
}


/// NewPs: unbounded fn [Tok] -> Ps
Ps new_ps(const Array<crate::syntax::lexer::Tok>& toks0) {
    auto ends = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::syntax::lexer::chars::last(toks0);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(t.kind == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto end = ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::Range> _v;
        auto&& _m = crate::syntax::lexer::chars::last(toks0);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(crate::syntax::Range{.start = t.span.end, .end = t.span.end});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(no_range());
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto toks = ends
        ? toks0
        : crate::prelude::push(toks0, crate::syntax::lexer::Tok{.kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), .span = end, .touches = false, .line_start = false});
    return Ps{.toks = toks, .pairs = pair_brackets(toks), .pos = Nat(0u), .diags = Array<crate::syntax::Diag>{}, .out = Array<crate::syntax::Diag>{}, .step_mode = false, .in_trait = false, .bad = false};
}


prism_rtl::Turn<Ps> NewPs::cycle() const {
    const auto& toks0 = this->toks0;
    auto ends = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::syntax::lexer::chars::last(toks0);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(t.kind == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto end = ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::Range> _v;
        auto&& _m = crate::syntax::lexer::chars::last(toks0);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(crate::syntax::Range{.start = t.span.end, .end = t.span.end});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(no_range());
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto toks = ends
        ? toks0
        : crate::prelude::push(toks0, crate::syntax::lexer::Tok{.kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), .span = end, .touches = false, .line_start = false});
    return call_then(start_pair_brackets(toks), [=](Array<Pair> pair_brackets_4303) { return prism_rtl::finished(Ps{.toks = toks, .pairs = pair_brackets_4303, .pos = Nat(0u), .diags = Array<crate::syntax::Diag>{}, .out = Array<crate::syntax::Diag>{}, .step_mode = false, .in_trait = false, .bad = false}); });
}


/// `Start NewPs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_new_ps(Array<crate::syntax::lexer::Tok> toks0) {
    return prism_rtl::make_rc<NewPs>(toks0);
}


/// Sub: unbounded fn Ps, [Tok], Range -> Ps
Ps sub(const Ps& p_, const Array<crate::syntax::lexer::Tok>& toks, const crate::syntax::Range& end) {
    auto q = new_ps(crate::prelude::push(toks, crate::syntax::lexer::Tok{.kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), .span = end, .touches = false, .line_start = false}));
    Ps this_ = q;
    this_.step_mode = p_.step_mode;
    return this_;
}


prism_rtl::Turn<Ps> Sub::cycle() const {
    const auto& p_ = this->p_;
    const auto& toks = this->toks;
    const auto& end = this->end;
    auto end_1 = end;
    auto p__2 = p_;
    auto toks_3 = toks;
    return call_then(start_new_ps(crate::prelude::push(toks_3, crate::syntax::lexer::Tok{.kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), .span = end_1, .touches = false, .line_start = false})), [=](Ps new_ps_4612) {
        return ({
            auto q = new_ps_4612;
            (prism_rtl::finished(({
            Ps this_ = q;
            this_.step_mode = p__2.step_mode;
            this_;
        })));
        });
    });
}


/// `Start Sub, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_sub(Ps p_, Array<crate::syntax::lexer::Tok> toks, crate::syntax::Range end) {
    return prism_rtl::make_rc<Sub>(p_, toks, end);
}


/// Absorb: fn Ps, Ps -> Ps
Ps absorb(const Ps& p_, const Ps& sub_) {
    Ps this_ = p_;
    this_.diags = append(this_.diags, sub_.diags);
    this_.out = append(this_.out, sub_->out);
    return this_;
}


/// FinishDiags: fn [Diag] -> [Diag]
Array<crate::syntax::Diag> finish_diags(const Array<crate::syntax::Diag>& ds) {
    auto sorted = fold(ds, Array<crate::syntax::Diag>{}, insert_diag);
    return fold(sorted, Array<crate::syntax::Diag>{}, [&](const Array<crate::syntax::Diag>& acc, const crate::syntax::Diag& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::Diag>> _v;
            auto&& _m = crate::syntax::lexer::chars::last(acc);
            if (prism_rtl::is_some(_m)) {
                auto&& e = prism_rtl::some_of(_m);
                if ((e.span == d.span) && (e.message == d.message)) {
                    _v.set(acc);
                    goto _done;
                }
            }
            {
                _v.set(crate::prelude::push(acc, d));
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// StageRank: fn Text -> Nat
Nat stage_rank(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("lex")) {
            return Nat(0u);
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("parse")) {
            return Nat(1u);
        }
    }
    {
        return Nat(2u);
    }
}


/// DiagBefore: fn Diag, Diag -> Bool
bool diag_before(const crate::syntax::Diag& a, const crate::syntax::Diag& b) {
    return (a.span.start < b.span.start) || ((a.span.start == b.span.start) && (stage_rank(a.stage) < stage_rank(b.stage)));
}


/// InsertDiag: fn [Diag], Diag -> [Diag]
Array<crate::syntax::Diag> insert_diag(const Array<crate::syntax::Diag>& sorted, const crate::syntax::Diag& d) {
    auto before_ = fold(sorted, Array<crate::syntax::Diag>{}, [&](const Array<crate::syntax::Diag>& acc, const crate::syntax::Diag& e) { return diag_before(d, e) ? acc : crate::prelude::push(acc, e); });
    auto after_ = fold(sorted, Array<crate::syntax::Diag>{}, [&](const Array<crate::syntax::Diag>& acc, const crate::syntax::Diag& e) { return diag_before(d, e) ? crate::prelude::push(acc, e) : acc; });
    return append(crate::prelude::push(before_, d), after_);
}


/// PairBrackets: unbounded fn [Tok] -> [Pair]
Array<Pair> pair_brackets(const Array<crate::syntax::lexer::Tok>& toks) {
    Array<Pair> this_ = each(toks, [&](const crate::syntax::lexer::Tok& t) { return no_pair(); });
    Array<std::tuple<Nat, Text>> stack = Array<std::tuple<Nat, Text>>{};
    for (auto&& [i6364, v6364] : prism_rtl::enumerate(toks)) {
        auto k6364 = nat_of(i6364);
        auto t = v6364;
        if (auto&& _m = open_kind_of(t.kind); prism_rtl::is_some(_m)) {
            auto&& k = prism_rtl::some_of(_m);
            stack = crate::prelude::push(stack, std::tuple{k6364, k});
        }
        if (auto&& _m = close_kind_of(t.kind); prism_rtl::is_some(_m)) {
            auto&& k = prism_rtl::some_of(_m);
            if (auto&& _m = crate::syntax::lexer::chars::last(stack); prism_rtl::is_some(_m)) {
                auto&& j = std::get<0>(prism_rtl::some_of(_m));
                auto&& k2 = std::get<1>(prism_rtl::some_of(_m));
                if (k2 == k) {
                    stack = crate::syntax::lexer::chars::pop(stack);
                    at_mut(this_, k6364).partner = std::optional(j);
                    at_mut(this_, j).partner = std::optional(k6364);
                }
            }
        }
    }
    for (auto&& [i6825, v6825] : prism_rtl::enumerate(toks)) {
        auto k6825 = nat_of(i6825);
        auto t = v6825;
        auto i = k6825;
        if (auto&& _m = open_kind_of(t.kind); prism_rtl::is_some(_m)) {
            auto&& kind_ = prism_rtl::some_of(_m);
            if ((kind_ != Text::lit("{")) && (!or_(index(this_, i), no_pair()).inner)) {
                if (auto&& _m = or_(index(this_, i), no_pair()).partner; prism_rtl::is_some(_m)) {
                    auto&& j = prism_rtl::some_of(_m);
                    if (double_at(this_, toks, i, j, kind_)) {
                        at_mut(this_, i).outer = true;
                        at_mut(this_, j).outer = true;
                        at_mut(this_, i + Nat(1u)).inner = true;
                        at_mut(this_, crate::syntax::lexer::chars::dec(j)).inner = true;
                    }
                }
            }
        }
    }
    return this_;
}


prism_rtl::Turn<Array<Pair>> PairBrackets::cycle() const {
    const auto& toks = this->toks;
    return prism_rtl::finished(({
        Array<Pair> this_ = each(toks, [&](const crate::syntax::lexer::Tok& t) { return no_pair(); });
        Array<std::tuple<Nat, Text>> stack = Array<std::tuple<Nat, Text>>{};
        for (auto&& [i6364, v6364] : prism_rtl::enumerate(toks)) {
            auto k6364 = nat_of(i6364);
            auto t = v6364;
            if (auto&& _m = open_kind_of(t.kind); prism_rtl::is_some(_m)) {
                auto&& k = prism_rtl::some_of(_m);
                stack = crate::prelude::push(stack, std::tuple{k6364, k});
            }
            if (auto&& _m = close_kind_of(t.kind); prism_rtl::is_some(_m)) {
                auto&& k = prism_rtl::some_of(_m);
                if (auto&& _m = crate::syntax::lexer::chars::last(stack); prism_rtl::is_some(_m)) {
                    auto&& j = std::get<0>(prism_rtl::some_of(_m));
                    auto&& k2 = std::get<1>(prism_rtl::some_of(_m));
                    if (k2 == k) {
                        stack = crate::syntax::lexer::chars::pop(stack);
                        at_mut(this_, k6364).partner = std::optional(j);
                        at_mut(this_, j).partner = std::optional(k6364);
                    }
                }
            }
        }
        for (auto&& [i6825, v6825] : prism_rtl::enumerate(toks)) {
            auto k6825 = nat_of(i6825);
            auto t = v6825;
            auto i = k6825;
            if (auto&& _m = open_kind_of(t.kind); prism_rtl::is_some(_m)) {
                auto&& kind_ = prism_rtl::some_of(_m);
                if ((kind_ != Text::lit("{")) && (!or_(index(this_, i), no_pair()).inner)) {
                    if (auto&& _m = or_(index(this_, i), no_pair()).partner; prism_rtl::is_some(_m)) {
                        auto&& j = prism_rtl::some_of(_m);
                        if (double_at(this_, toks, i, j, kind_)) {
                            at_mut(this_, i).outer = true;
                            at_mut(this_, j).outer = true;
                            at_mut(this_, i + Nat(1u)).inner = true;
                            at_mut(this_, crate::syntax::lexer::chars::dec(j)).inner = true;
                        }
                    }
                }
            }
        }
        this_;
    }));
}


/// `Start PairBrackets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Pair>> start_pair_brackets(Array<crate::syntax::lexer::Tok> toks) {
    return prism_rtl::make_rc<PairBrackets>(toks);
}


/// DoubleAt: fn [Pair], [Tok], Nat, Nat, Text -> Bool
bool double_at(const Array<Pair>& pairs, const Array<crate::syntax::lexer::Tok>& toks, const Nat& i, const Nat& j, const Text& kind_) {
    auto next = or_(index(toks, i + Nat(1u)), eof_tok());
    auto inner_close_opt = or_(index(pairs, i + Nat(1u)), no_pair()).partner;
    return ((is_open_of(next.kind, kind_) && next.touches) && (inner_close_opt == std::optional(crate::syntax::lexer::chars::dec(j)))) && or_(index(toks, j), eof_tok()).touches;
}


/// ?OpenKindOf: fn TokKind -> ?Text
std::optional<Text> open_kind_of(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(tok_kind0)) {
        auto&& k = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(tok_kind0).a0;
        return std::optional(k);
    }
    {
        return std::optional<Text>{};
    }
}


/// ?CloseKindOf: fn TokKind -> ?Text
std::optional<Text> close_kind_of(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KClose>(tok_kind0)) {
        auto&& k = prism_rtl::as<crate::syntax::lexer::TokKind::KClose>(tok_kind0).a0;
        return std::optional(k);
    }
    {
        return std::optional<Text>{};
    }
}


/// IsOpenOf: fn TokKind, Text -> Bool
bool is_open_of(const crate::syntax::lexer::TokKind& tok_kind0, const Text& text1) {
    auto&& _m = std::tuple{tok_kind0, text1};
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(std::get<0>(_m))) {
        auto&& k = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(std::get<0>(_m)).a0;
        auto&& kind_ = std::get<1>(_m);
        return k == kind_;
    }
    {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// Tk: fn Ps -> Tok
crate::syntax::lexer::Tok tk(const Ps& p_) {
    return p_->bad
        ? eof_tok()
        : or_(index(p_.toks, crate::prelude::min(p_.pos, crate::syntax::lexer::chars::dec(len(p_.toks)))), eof_tok());
}


/// TkAt: fn Ps, Nat -> Tok
crate::syntax::lexer::Tok tk_at(const Ps& p_, const Nat& n) {
    return p_->bad
        ? eof_tok()
        : or_(index(p_.toks, crate::prelude::min(p_.pos + n, crate::syntax::lexer::chars::dec(len(p_.toks)))), eof_tok());
}


/// Kind: fn Ps -> TokKind
crate::syntax::lexer::TokKind kind(const Ps& p_) {
    return tk(p_).kind;
}


/// KindAt: fn Ps, Nat -> TokKind
crate::syntax::lexer::TokKind kind_at(const Ps& p_, const Nat& n) {
    return tk_at(p_, n).kind;
}


/// Here: fn Ps -> Range
crate::syntax::Range here(const Ps& p_) {
    return tk(p_).span;
}


/// Prev: fn Ps -> Range
crate::syntax::Range prev(const Ps& p_) {
    return or_(index(p_.toks, crate::syntax::lexer::chars::dec(p_.pos)), eof_tok()).span;
}


/// To: fn Range, Range -> Range
crate::syntax::Range to(const crate::syntax::Range& a, const crate::syntax::Range& b) {
    return crate::syntax::Range{.start = crate::prelude::min(a.start, b.start), .end = crate::prelude::max(a.end, b.end)};
}


/// AtEnd: fn Range -> Range
crate::syntax::Range at_end(const crate::syntax::Range& r) {
    return crate::syntax::Range{.start = r.end, .end = r.end};
}


/// Adv: fn Ps -> Ps
Ps adv(const Ps& p_) {
    return p_->bad || ((p_.pos + Nat(1u)) >= len(p_.toks))
        ? p_
        : ({
        Ps this_ = p_;
        this_.pos = this_.pos + Nat(1u);
        this_;
    });
}


/// PairAt: fn Ps -> Pair
Pair pair_at(const Ps& p_) {
    return or_(index(p_.pairs, crate::prelude::min(p_.pos, crate::syntax::lexer::chars::dec(len(p_.pairs)))), no_pair());
}


/// AtEof: fn Ps -> Bool
bool at_eof(const Ps& p_) {
    return kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{});
}


/// AtKw: fn Ps, Text -> Bool
bool at_kw(const Ps& p_, const Text& w) {
    return kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KKw{w, Text::lit("")});
}


/// AtOp: fn Ps, Text -> Bool
bool at_op(const Ps& p_, const Text& op) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m)) {
        auto&& o = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        return o == op;
    }
    {
        return false;
    }
}


/// AtSep: fn Ps -> Bool
bool at_sep(const Ps& p_) {
    return kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLaySep{});
}


/// AtOpenL: fn Ps -> Bool
bool at_open_l(const Ps& p_) {
    return kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{});
}


/// AtCloseL: fn Ps -> Bool
bool at_close_l(const Ps& p_) {
    return kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayClose{});
}


/// AtComma: fn Ps -> Bool
bool at_comma(const Ps& p_) {
    return kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KComma{});
}


/// AtColon: fn Ps -> Bool
bool at_colon(const Ps& p_) {
    return kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{});
}


/// IsOpenKind: fn TokKind, Text -> Bool
bool is_open_kind(const crate::syntax::lexer::TokKind& tok_kind0, const Text& text1) {
    auto&& _m = std::tuple{tok_kind0, text1};
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(std::get<0>(_m))) {
        auto&& k = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(std::get<0>(_m)).a0;
        auto&& kind_ = std::get<1>(_m);
        return k == kind_;
    }
    {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// AtDoubleOpen: fn Ps, Text -> Bool
bool at_double_open(const Ps& p_, const Text& kind_) {
    return is_open_kind(kind(p_), kind_) && pair_at(p_).outer;
}


/// AtSingleOpen: fn Ps, Text -> Bool
bool at_single_open(const Ps& p_, const Text& kind_) {
    return is_open_kind(kind(p_), kind_) && (!pair_at(p_).outer);
}


/// AtClose: fn Ps, Text -> Bool
bool at_close(const Ps& p_, const Text& kind_) {
    return kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KClose{kind_});
}


/// OpenDouble: fn Ps -> Ps
Ps open_double(const Ps& p_) {
    return adv(adv(p_));
}


/// CloseDouble: fn Ps, Text -> Ps
Ps close_double(const Ps& p_, const Text& kind_) {
    auto c = crate::syntax::lexer::close_char(kind_);
    auto p1 = adv(p_);
    return ((at_close(p_, kind_) && pair_at(p_).inner) && at_close(p1, kind_)) && pair_at(p1).outer
        ? adv(p1)
        : at_close(p_, kind_) && pair_at(p_).inner
        ? error_here(p1, prism_rtl::cat("expected `", c, c, "` to close the double bracket"))
        : error_here(p_, prism_rtl::cat("expected `", c, c, "` to close the double bracket"));
}


/// ExpectClose: fn Ps, Text -> Ps
Ps expect_close(const Ps& p_, const Text& kind_) {
    return at_close(p_, kind_)
        ? adv(p_)
        : error_here(p_, prism_rtl::cat("expected `", crate::syntax::lexer::close_char(kind_), "`"));
}


/// ParseDiag: fn Range, Text -> Diag
crate::syntax::Diag parse_diag(const crate::syntax::Range& span, const Text& message) {
    return crate::syntax::Diag{.stage = Text::lit("parse"), .span = span, .message = message, .feature = std::optional<Text>{}};
}


/// ErrorAt: fn Ps, Range, Text -> Ps
Ps error_at(const Ps& p_, const crate::syntax::Range& span, const Text& message) {
    return p_->bad
        ? p_
        : ({
        Ps this_ = p_;
        this_.diags = crate::prelude::push(this_.diags, parse_diag(span, message));
        this_.bad = true;
        this_;
    });
}


/// ErrorHere: fn Ps, Text -> Ps
Ps error_here(const Ps& p_, const Text& message) {
    return error_at(p_, here(p_), prism_rtl::cat(message, ", found ", describe(kind(p_))));
}


/// Fail: fn Ps -> Ps
Ps fail(const Ps& p_) {
    Ps this_ = p_;
    this_.bad = true;
    return this_;
}


/// Unbad: fn Ps -> Ps
Ps unbad(const Ps& p_) {
    Ps this_ = p_;
    this_.bad = false;
    return this_;
}


/// NoteError: fn Ps, Range, Text -> Ps
Ps note_error(const Ps& p_, const crate::syntax::Range& span, const Text& message) {
    return p_->bad
        ? p_
        : ({
        Ps this_ = p_;
        this_.diags = crate::prelude::push(this_.diags, parse_diag(span, message));
        this_;
    });
}


/// Complain: fn Ps, Text -> Ps
Ps complain(const Ps& p_, const Text& message) {
    return unbad(error_here(p_, message));
}


/// OutOfScope: fn Ps, Range, Text, Text -> Ps
Ps out_of_scope(const Ps& p_, const crate::syntax::Range& span, const Text& feature, const Text& message) {
    return p_->bad
        ? p_
        : ({
        Ps this_ = p_;
        this_.out = crate::prelude::push(this_.out, crate::syntax::Diag{.stage = Text::lit("out"), .span = span, .message = message, .feature = std::optional(feature)});
        this_;
    });
}


/// ExpectColon: fn Ps -> Ps
Ps expect_colon(const Ps& p_) {
    return at_colon(p_) ? adv(p_) : error_here(p_, Text::lit("expected `:`"));
}


/// ExpectOp: fn Ps, Text -> Ps
Ps expect_op(const Ps& p_, const Text& op) {
    return at_op(p_, op)
        ? adv(p_)
        : error_here(p_, prism_rtl::cat("expected `", op, "`"));
}


/// ExpectKw: fn Ps, Text -> Ps
Ps expect_kw(const Ps& p_, const Text& w) {
    return at_kw(p_, w)
        ? adv(p_)
        : error_here(p_, prism_rtl::cat("expected `", w, "`"));
}


/// Recover: unbounded fn Ps -> Ps
Ps recover(const Ps& p0) {
    Ps this_ = unbad(p0);
    Nat depth = Nat(0u);
    bool going = true;
    while (going) {
        ({
            __label__ _done;
            prism_rtl::Slot<Unit> _v;
            auto&& _m = kind(this_);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                _v.set(({
                    going = false;
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayOpen>(_m)) {
                _v.set(({
                    depth = depth + Nat(1u);
                    this_ = adv(this_);
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                _v.set(({
                    if (depth == Nat(0u)) {
                        going = false;
                    } else  {
                        depth = crate::syntax::lexer::chars::dec(depth);
                        this_ = adv(this_);
                    }
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                if (depth == Nat(0u)) {
                    _v.set(({
                        going = false;
                        Unit{};
                    }));
                    goto _done;
                }
            }
            {
                _v.set(({
                    this_ = adv(this_);
                    Unit{};
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    return this_;
}


prism_rtl::Turn<Ps> Recover::cycle() const {
    const auto& p0 = this->p0;
    Ps this_ = unbad(p0);
    Nat depth = Nat(0u);
    bool going = true;
    return call_then(loop_job(std::tuple{this_, depth, going}, [=](std::tuple<Ps, Nat, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto depth = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        return going
            ? ({
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = kind(this_);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                    _v.set(({
                        going = false;
                        Unit{};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayOpen>(_m)) {
                    _v.set(({
                        depth = depth + Nat(1u);
                        this_ = adv(this_);
                        Unit{};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                    _v.set(({
                        if (depth == Nat(0u)) {
                            going = false;
                        } else  {
                            depth = crate::syntax::lexer::chars::dec(depth);
                            this_ = adv(this_);
                        }
                        Unit{};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                    if (depth == Nat(0u)) {
                        _v.set(({
                            going = false;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        this_ = adv(this_);
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            Expected<std::tuple<Ps, Nat, bool>, std::tuple<Ps, Nat, bool>>(std::tuple{this_, depth, going});
        })
            : Expected<std::tuple<Ps, Nat, bool>, std::tuple<Ps, Nat, bool>>(unexpected(std::tuple{this_, depth, going}));
    }), [=](std::tuple<Ps, Nat, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto depth = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        return prism_rtl::finished(this_);
    });
}


/// `Start Recover, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_recover(Ps p0) {
    return prism_rtl::make_rc<Recover>(p0);
}


/// Recovered: unbounded fn Ps -> Ps
Ps recovered(const Ps& p_) {
    return p_->bad ? recover(p_) : p_;
}


prism_rtl::Turn<Ps> Recovered::cycle() const {
    const auto& p_ = this->p_;
    return p_->bad
        ? prism_rtl::more(prism_rtl::rc(Recover(p_)))
        : prism_rtl::finished(p_);
}


/// `Start Recovered, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_recovered(Ps p_) {
    return prism_rtl::make_rc<Recovered>(p_);
}


/// AtStmtBoundary: fn Ps -> Bool
bool at_stmt_boundary(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// ExpectStmtEnd: unbounded fn Ps, Text -> Ps
Ps expect_stmt_end(const Ps& p_, const Text& what) {
    return at_stmt_boundary(p_)
        ? p_
        : recover(note_error(p_, here(p_), prism_rtl::cat("expected the end of the ", what, ", found ", describe(kind(p_)))));
}


prism_rtl::Turn<Ps> ExpectStmtEnd::cycle() const {
    const auto& p_ = this->p_;
    const auto& what = this->what;
    return at_stmt_boundary(p_)
        ? prism_rtl::finished(p_)
        : prism_rtl::more(prism_rtl::rc(Recover(note_error(p_, here(p_), prism_rtl::cat("expected the end of the ", what, ", found ", describe(kind(p_)))))));
}


/// `Start ExpectStmtEnd, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_expect_stmt_end(Ps p_, Text what) {
    return prism_rtl::make_rc<ExpectStmtEnd>(p_, what);
}


/// Describe: fn TokKind -> Text
Text describe(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayOpen>(tok_kind0)) {
        return Text::lit("an indented block");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(tok_kind0)) {
        return Text::lit("the end of the line");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(tok_kind0)) {
        return Text::lit("the end of the block");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(tok_kind0)) {
        return Text::lit("the end of the input");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(tok_kind0)) {
        return Text::lit("a text literal");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTemplate>(tok_kind0)) {
        return Text::lit("a template");
    }
    {
        auto&& k = tok_kind0;
        return prism_rtl::cat("`", crate::syntax::lexer::corpus::token_text(k), "`");
    }
}


/// WithStepMode: fn Ps, Bool -> Ps
Ps with_step_mode(const Ps& p_, const bool& flag) {
    Ps this_ = p_;
    this_.step_mode = flag;
    return this_;
}


/// let noSName
crate::syntax::SName no_sname() {
    return crate::syntax::SName{.sigils = Text::lit(""), .path_ = Array<Text>{}, .span = no_range()};
}


/// let noIdent
crate::syntax::Ident no_ident() {
    return crate::syntax::Ident{.name = Text::lit(""), .span = no_range()};
}


/// IsUpperName: fn SName -> Bool
bool is_upper_name(const crate::syntax::SName& n) {
    return crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::head(or_(crate::syntax::lexer::chars::last(n->path_), Text::lit(""))));
}


/// IsCallee: fn SName -> Bool
bool is_callee(const crate::syntax::SName& n) {
    return is_upper_name(n) || crate::syntax::lexer::chars::is_reserved_ctor(or_(crate::syntax::lexer::chars::last(n->path_), Text::lit("")));
}


/// IsTopic: fn SName -> Bool
bool is_topic(const crate::syntax::SName& n) {
    return n->path_ == Array(std::vector{Text::lit("_")});
}


/// NameText: fn SName -> Text
Text name_text(const crate::syntax::SName& n) {
    return prism_rtl::cat(n.sigils, crate::syntax::lexer::chars::join(n->path_, Text::lit(".")));
}


/// ParseSName: fn Ps -> ((SName, Ps))
std::tuple<crate::syntax::SName, Ps> parse_sname(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        return std::tuple{crate::syntax::SName{.sigils = n.sigils, .path_ = n->path_, .span = here(p_)}, adv(p_)};
    }
    {
        return std::tuple{no_sname(), error_here(p_, Text::lit("expected a name"))};
    }
}


/// ParseIdent: fn Ps -> ((Ident, Ps))
std::tuple<crate::syntax::Ident, Ps> parse_ident(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if (((n.sigils == Text::lit("")) && (len(n->path_) == Nat(1u))) && (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) {
            return std::tuple{crate::syntax::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = here(p_)}, adv(p_)};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m16382_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m16382_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m16382_1_0 == Text::lit("key")) {
            if (m16382_1_1 == Text::lit("")) {
                return std::tuple{crate::syntax::Ident{.name = Text::lit("key"), .span = here(p_)}, adv(p_)};
            }
        }
    }
    {
        return std::tuple{no_ident(), error_here(p_, Text::lit("expected a lowercase name"))};
    }
}


/// ParseQualName: fn Ps -> ((QualName, Ps))
std::tuple<crate::syntax::QualName, Ps> parse_qual_name(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if ((n.sigils == Text::lit("")) && (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{}))) {
            return std::tuple{crate::syntax::QualName{.path_ = n->path_, .span = here(p_)}, adv(p_)};
        }
    }
    {
        return std::tuple{crate::syntax::QualName{.path_ = Array<Text>{}, .span = no_range()}, error_here(p_, Text::lit("expected an uppercase name"))};
    }
}


/// ParseTraitRef: fn Ps -> ((TraitRef, Ps))
std::tuple<crate::syntax::TraitRef, Ps> parse_trait_ref(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTrait>(_m)) {
        auto&& path_ = prism_rtl::as<crate::syntax::lexer::TokKind::KTrait>(_m).a0;
        auto span = here(p_);
        auto q = path_ == Array(std::vector{Text::lit("Monad")})
            ? out_of_scope(p_, span, Text::lit("`T monad:` blocks and `^Monad`"), Text::lit("`^Monad` is out of this compiler"))
            : p_;
        return std::tuple{crate::syntax::TraitRef{.path_ = path_, .span = span}, adv(q)};
    }
    {
        return std::tuple{crate::syntax::TraitRef{.path_ = Array<Text>{}, .span = no_range()}, error_here(p_, Text::lit("expected a trait, `^Name`"))};
    }
}


/// CheckNameScope: fn Ps, SName -> Ps
Ps check_name_scope(const Ps& p_, const crate::syntax::SName& name) {
    auto text_ = name_text(name);
    auto feature = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& m17545_0 = text_;
            if (m17545_0 == Text::lit("!Align")) {
                _v.set(Text::lit("`!Align`"));
                goto _done;
            }
        }
        {
            auto&& m17545_1 = text_;
            if (m17545_1 == Text::lit("@Collect")) {
                _v.set(Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17545_2 = text_;
            if (m17545_2 == Text::lit("@View")) {
                _v.set(Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17545_3 = text_;
            if (m17545_3 == Text::lit("@Edit")) {
                _v.set(Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17545_4 = text_;
            if (m17545_4 == Text::lit("@Translate")) {
                _v.set(Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17545_5 = text_;
            if (m17545_5 == Text::lit("Over")) {
                _v.set(Text::lit("named lenses `&Home` and `Over`"));
                goto _done;
            }
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    return feature == Text::lit("")
        ? p_
        : out_of_scope(p_, name.span, feature, prism_rtl::cat("`", text_, "` is out of this compiler"));
}


/// CheckTypeNameScope: fn Ps, SName -> Ps
Ps check_type_name_scope(const Ps& p_, const crate::syntax::SName& name) {
    auto b = or_(crate::syntax::lexer::chars::last(name->path_), Text::lit(""));
    auto sized = fold(Array(std::vector{Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")}), false, [&](const bool& seen, const Text& s) { return seen || (s == b); });
    return len(name->path_) != Nat(1u)
        ? p_
        : sized
        ? out_of_scope(p_, name.span, Text::lit("sized ints other than `U8`"), prism_rtl::cat("`", b, "` is out of this compiler: the sized integer it has is `U8`"))
        : b == Text::lit("Instant")
        ? out_of_scope(p_, name.span, Text::lit("`Instant`"), Text::lit("`Instant` is out of this compiler"))
        : p_;
}

}  // namespace crate::syntax::parser
