// The module `Syntax.Parser.Types`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/parser/types/types.hpp>
#include "elem.types.hpp"
#include <syntax/parser/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::parser::types {

std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_parse_type(crate::syntax::parser::Ps p_);

bool is_plain_lower_one(const crate::syntax::lexer::TokKind& tok_kind0);

bool is_fn_kw(const crate::syntax::lexer::TokKind& tok_kind0);

std::tuple<crate::syntax::Color, crate::syntax::parser::Ps> color_var_of(const crate::syntax::parser::Ps& p_);

std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_emit_type(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_parse_emit_type(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_union_type(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_parse_union_type(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_map_type(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_parse_map_type(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_sigiled_type(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_parse_sigiled_type(crate::syntax::parser::Ps p_);

std::tuple<Text, crate::syntax::parser::Ps> free_sigil_run(const crate::syntax::parser::Ps& p0);

std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_app_type(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_parse_app_type(crate::syntax::parser::Ps p_);

bool type_atom_starts_here(const crate::syntax::parser::Ps& p_);

std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_atom(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_parse_type_atom(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> type_atom_body(const crate::syntax::parser::Ps& p_, const crate::syntax::Range& start);

prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> start_type_atom_body(crate::syntax::parser::Ps p_, crate::syntax::Range start);

std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps> parse_bounds(const crate::syntax::parser::Ps& p0);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>> start_parse_bounds(crate::syntax::parser::Ps p0);

bool is_name_kind(const crate::syntax::lexer::TokKind& tok_kind0);

bool is_trait_kind(const crate::syntax::lexer::TokKind& tok_kind0);

std::tuple<crate::syntax::decls::Bound, crate::syntax::parser::Ps> parse_bound(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::Bound, crate::syntax::parser::Ps>> start_parse_bound(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::Row_, crate::syntax::parser::Ps> parse_row(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::Row_, crate::syntax::parser::Ps>> start_parse_row(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::RowTerm, crate::syntax::parser::Ps> parse_row_term(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::RowTerm, crate::syntax::parser::Ps>> start_parse_row_term(crate::syntax::parser::Ps p_);

bool type_atom_after_name(const crate::syntax::parser::Ps& p_);

std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern(const crate::syntax::parser::Ps& p_, const bool& commas0);

prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> start_parse_pattern(crate::syntax::parser::Ps p_, bool commas0);

bool is_number_kind(const crate::syntax::lexer::TokKind& tok_kind0);

std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> literal_pattern(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> start_literal_pattern(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> name_pattern(const crate::syntax::parser::Ps& p0, const crate::syntax::lexer::NameTok& n, const bool& commas);

prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> start_name_pattern(crate::syntax::parser::Ps p0, crate::syntax::lexer::NameTok n, bool commas);

bool pat_arg_starts_here(const crate::syntax::parser::Ps& p_);

std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_record_pattern(const crate::syntax::parser::Ps& p0, const crate::syntax::SName& name);

prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> start_parse_record_pattern(crate::syntax::parser::Ps p0, crate::syntax::SName name);

}  // namespace syntax::parser::types


namespace syntax::parser::types {

/// The step machine of `ParseType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseType: unbounded fn Ps -> ((Type, Ps))
struct ParseType : prism_rtl::Job<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseType(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseEmitType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseEmitType: unbounded fn Ps -> ((Type, Ps))
struct ParseEmitType : prism_rtl::Job<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseEmitType(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseUnionType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseUnionType: unbounded fn Ps -> ((Type, Ps))
struct ParseUnionType : prism_rtl::Job<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseUnionType(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseMapType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseMapType: unbounded fn Ps -> ((Type, Ps))
struct ParseMapType : prism_rtl::Job<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseMapType(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseSigiledType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseSigiledType: unbounded fn Ps -> ((Type, Ps))
struct ParseSigiledType : prism_rtl::Job<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseSigiledType(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseAppType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseAppType: unbounded fn Ps -> ((Type, Ps))
struct ParseAppType : prism_rtl::Job<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseAppType(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseTypeAtom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTypeAtom: unbounded fn Ps -> ((Type, Ps))
struct ParseTypeAtom : prism_rtl::Job<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseTypeAtom(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `TypeAtomBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeAtomBody: unbounded fn Ps, Range -> ((Type, Ps))
struct TypeAtomBody : prism_rtl::Job<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    crate::syntax::Range start;
    TypeAtomBody(crate::syntax::parser::Ps p_, crate::syntax::Range start) : p_(std::move(p_)), start(std::move(start)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseBounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseBounds: unbounded fn Ps -> (([Bound], Ps))
struct ParseBounds : prism_rtl::Job<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    ParseBounds(crate::syntax::parser::Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseBound`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseBound: unbounded fn Ps -> ((Bound, Ps))
struct ParseBound : prism_rtl::Job<std::tuple<crate::syntax::decls::Bound, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseBound(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::Bound, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseRow: unbounded fn Ps -> ((Row, Ps))
struct ParseRow : prism_rtl::Job<std::tuple<crate::syntax::Row_, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseRow(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Row_, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseRowTerm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseRowTerm: unbounded fn Ps -> ((RowTerm, Ps))
struct ParseRowTerm : prism_rtl::Job<std::tuple<crate::syntax::RowTerm, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseRowTerm(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::RowTerm, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParsePattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParsePattern: unbounded fn Ps, Bool -> ((Pattern, Ps))
struct ParsePattern : prism_rtl::Job<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    bool commas0;
    ParsePattern(crate::syntax::parser::Ps p_, bool commas0) : p_(std::move(p_)), commas0(std::move(commas0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `LiteralPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LiteralPattern: unbounded fn Ps -> ((Pattern, Ps))
struct LiteralPattern : prism_rtl::Job<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    LiteralPattern(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `NamePattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamePattern: unbounded fn Ps, NameTok, Bool -> ((Pattern, Ps))
struct NamePattern : prism_rtl::Job<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    crate::syntax::lexer::NameTok n;
    bool commas;
    NamePattern(crate::syntax::parser::Ps p0, crate::syntax::lexer::NameTok n, bool commas) : p0(std::move(p0)), n(std::move(n)), commas(std::move(commas)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseRecordPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseRecordPattern: unbounded fn Ps, SName -> ((Pattern, Ps))
struct ParseRecordPattern : prism_rtl::Job<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    crate::syntax::SName name;
    ParseRecordPattern(crate::syntax::parser::Ps p0, crate::syntax::SName name) : p0(std::move(p0)), name(std::move(name)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>> cycle() const override;
};


}  // namespace syntax::parser::types

}  // namespace crate
