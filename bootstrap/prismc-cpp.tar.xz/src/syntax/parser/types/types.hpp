// The module `Syntax.Parser.Types`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/parser/types/decl.hpp>
#include "elem.decl.hpp"
#include <syntax/decl.hpp>
#include <syntax/decls/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <syntax/parser/blocks/decl.hpp>
#include <syntax/parser/decls/decl.hpp>
#include <syntax/parser/expr/decl.hpp>
#include <syntax/parser/test_language/decl.hpp>
#include <syntax/sexp/decl.hpp>
#include <syntax/parser/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::parser::types {

/// `FieldsRead`:
///
/// ```prism
/// type FieldsRead = record:
/// ```
struct FieldsRead {
    using prism_value = void;
    Array<crate::syntax::FieldPat> fields;
    bool rest;
    crate::syntax::parser::Ps p_;
    bool going;
    const FieldsRead* operator->() const { return this; }
    FieldsRead* operator->() { return this; }
    bool operator==(const FieldsRead&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<FieldsRead> from_pod(const Pod& whole);
};


}  // namespace syntax::parser::types


}  // namespace crate
