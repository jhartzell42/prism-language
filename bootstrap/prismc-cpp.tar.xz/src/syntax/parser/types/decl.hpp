// The module `Syntax.Parser.Types`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace syntax::parser::types {

struct FieldsRead;

struct ParseType;

struct ParseEmitType;

struct ParseUnionType;

struct ParseMapType;

struct ParseSigiledType;

struct ParseAppType;

struct ParseTypeAtom;

struct TypeAtomBody;

struct ParseBounds;

struct ParseBound;

struct ParseRow;

struct ParseRowTerm;

struct ParsePattern;

struct LiteralPattern;

struct NamePattern;

struct ParseRecordPattern;

}  // namespace syntax::parser::types

}  // namespace crate
