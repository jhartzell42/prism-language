// The module `Syntax.Parser.Expr`: its value types (records, tags, newtypes and choices with their cases), each
// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism
// source, not this file.
#pragma once

#include <syntax/parser/expr/decl.hpp>
#include "elem.decl.hpp"
#include <syntax/decls/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/regexes/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <syntax/parser/blocks/decl.hpp>
#include <syntax/parser/decls/decl.hpp>
#include <syntax/parser/test_language/decl.hpp>
#include <syntax/parser/types/decl.hpp>
#include <syntax/sexp/decl.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::parser::expr {

/// `ArgsRead`:
///
/// ```prism
/// type ArgsRead = record:
/// ```
struct ArgsRead {
    using prism_value = void;
    Array<crate::syntax::Arg> args;
    bool rest;
    crate::syntax::parser::Ps p_;
    bool going;
    const ArgsRead* operator->() const { return this; }
    ArgsRead* operator->() { return this; }
    bool operator==(const ArgsRead&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ArgsRead> from_pod(const Pod& whole);
};


}  // namespace syntax::parser::expr

namespace syntax::parser::expr {

/// `Climb`:
///
/// ```prism
/// type Climb = record:
/// ```
struct Climb {
    using prism_value = void;
    crate::syntax::Expr lhs;
    crate::syntax::parser::Ps p_;
    bool going;
    const Climb* operator->() const { return this; }
    Climb* operator->() { return this; }
    bool operator==(const Climb&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Climb> from_pod(const Pod& whole);
};


}  // namespace syntax::parser::expr

}  // namespace crate
