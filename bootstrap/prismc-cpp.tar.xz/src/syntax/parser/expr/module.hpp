// The module `Syntax.Parser.Expr`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/parser/expr/types.hpp>
#include "elem.types.hpp"
#include <syntax/parser/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::parser::expr {

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_f(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_expr_f(crate::syntax::parser::Ps p_p0);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_arg_expr_f(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_arg_expr_f(crate::syntax::parser::Ps p_p0);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_ctx_f(const crate::syntax::parser::Ps& p_p0, const bool& commas_p1);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_expr_ctx_f(crate::syntax::parser::Ps p_p0, bool commas_p1);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_f(const crate::syntax::parser::Ps& p0_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_rhs_expr_f(crate::syntax::parser::Ps p0_p0);

bool at_line_method_f(const crate::syntax::parser::Ps& p_p0);

bool is_plain_upper_f(const crate::syntax::lexer::TokKind& tok_kind0);

bool is_upper_tok_f(const crate::syntax::lexer::TokKind& tok_kind0);

std::optional<std::tuple<Text, std::optional<Array<Text>>>> peek_binop_o(const crate::syntax::parser::Ps& p_p0);

bool is_binop_f(const Text& op_p0);

Nat level_f(const Text& text0);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_binary_f(const crate::syntax::parser::Ps& p0_p0, const Nat& min_p1, const bool& commas_p2);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_binary_f(crate::syntax::parser::Ps p0_p0, Nat min_p1, bool commas_p2);

Climb climb_step_f(const Climb& c_p0, const Nat& min_p1, const bool& commas_p2);

prism_rtl::JobRef<Climb> start_climb_step_f(Climb c_p0, Nat min_p1, bool commas_p2);

crate::syntax::parser::Ps no_operator_f(const crate::syntax::parser::Ps& p_p0);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_prefix_f(const crate::syntax::parser::Ps& p_p0, const Nat& min_p1, const bool& commas_p2);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_prefix_f(crate::syntax::parser::Ps p_p0, Nat min_p1, bool commas_p2);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_postfix_expr_f(const crate::syntax::parser::Ps& p_p0, const bool& commas_p1);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_postfix_expr_f(crate::syntax::parser::Ps p_p0, bool commas_p1);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_postfix_f(const crate::syntax::Expr& e0_p0, const crate::syntax::parser::Ps& p0_p1, const bool& commas_p2);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_postfix_f(crate::syntax::Expr e0_p0, crate::syntax::parser::Ps p0_p1, bool commas_p2);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool> postfix_step_f(const crate::syntax::Expr& e_p0, const crate::syntax::parser::Ps& p_p1, const bool& commas_p2);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool>> start_postfix_step_f(crate::syntax::Expr e_p0, crate::syntax::parser::Ps p_p1, bool commas_p2);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool> field_or_method_f(const crate::syntax::Expr& e_p0, const crate::syntax::parser::Ps& p0_p1, const bool& commas_p2);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool>> start_field_or_method_f(crate::syntax::Expr e_p0, crate::syntax::parser::Ps p0_p1, bool commas_p2);

std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps> parse_type_args_f(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>> start_parse_type_args_f(crate::syntax::parser::Ps p_p0);

bool arg_starts_here_f(const crate::syntax::parser::Ps& p_p0);

Array<Text> arg_words_p();

std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps> parse_call_args_f(const crate::syntax::parser::Ps& p_p0, const bool& commas_p1);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> start_parse_call_args_f(crate::syntax::parser::Ps p_p0, bool commas_p1);

std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps> parse_one_arg_f(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> start_parse_one_arg_f(crate::syntax::parser::Ps p_p0);

std::tuple<crate::syntax::Arg, crate::syntax::parser::Ps> parse_arg_f(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Arg, crate::syntax::parser::Ps>> start_parse_arg_f(crate::syntax::parser::Ps p_p0);

std::tuple<Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps> parse_paren_args_f(const crate::syntax::parser::Ps& p0_p0);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps>> start_parse_paren_args_f(crate::syntax::parser::Ps p0_p0);

std::tuple<std::optional<crate::syntax::Ident>, crate::syntax::parser::Ps> parse_arg_name_f(const crate::syntax::parser::Ps& p_p0);

std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> parse_primary_f(const crate::syntax::parser::Ps& p_p0, const bool& commas_p1);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_parse_primary_f(crate::syntax::parser::Ps p_p0, bool commas_p1);

std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> literal_primary_f(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_literal_primary_f(crate::syntax::parser::Ps p_p0);

std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> name_primary_f(const crate::syntax::parser::Ps& p0_p0, const crate::syntax::lexer::NameTok& n_p1, const bool& commas_p2);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_name_primary_f(crate::syntax::parser::Ps p0_p0, crate::syntax::lexer::NameTok n_p1, bool commas_p2);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> type_args_on_f(const crate::syntax::Expr& e_p0, const crate::syntax::parser::Ps& p_p1, const crate::syntax::Range& start_p2);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_type_args_on_f(crate::syntax::Expr e_p0, crate::syntax::parser::Ps p_p1, crate::syntax::Range start_p2);

std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> paren_primary_f(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_paren_primary_f(crate::syntax::parser::Ps p_p0);

std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> square_primary_f(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_square_primary_f(crate::syntax::parser::Ps p_p0);

std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> map_primary_f(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_map_primary_f(crate::syntax::parser::Ps p_p0);

std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::Expr>, crate::syntax::parser::Ps> parse_map_entry_f(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::Expr>, crate::syntax::parser::Ps>> start_parse_map_entry_f(crate::syntax::parser::Ps p_p0);

std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> lens_primary_f(const crate::syntax::parser::Ps& p0_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_lens_primary_f(crate::syntax::parser::Ps p0_p0);

std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> keyword_primary_f(const crate::syntax::parser::Ps& p_p0, const Text& w_p1, const Text& sigils_p2, const bool& commas_p3);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_keyword_primary_f(crate::syntax::parser::Ps p_p0, Text w_p1, Text sigils_p2, bool commas_p3);

std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> took_f(const std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>& arg0);

std::tuple<crate::syntax::Literal, crate::syntax::parser::Ps> parse_literal_f(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Literal, crate::syntax::parser::Ps>> start_parse_literal_f(crate::syntax::parser::Ps p_p0);

std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps> text_segment_f(const Array<crate::syntax::TextSeg>& acc_p0, const crate::syntax::parser::Ps& p_p1, const crate::syntax::lexer::TextSegTok& text_seg_tok2);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>> start_text_segment_f(Array<crate::syntax::TextSeg> acc_p0, crate::syntax::parser::Ps p_p1, crate::syntax::lexer::TextSegTok text_seg_tok2);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_nested_f(const crate::syntax::parser::Ps& p_p0, const Array<crate::syntax::lexer::Tok>& toks_p1, const crate::syntax::Range& span_p2);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_nested_f(crate::syntax::parser::Ps p_p0, Array<crate::syntax::lexer::Tok> toks_p1, crate::syntax::Range span_p2);

std::tuple<crate::syntax::Template, crate::syntax::parser::Ps> parse_template_f(const crate::syntax::parser::Ps& p0_p0, const crate::syntax::lexer::TemplateTok& t_p1, const crate::syntax::Range& span_p2);

prism_rtl::JobRef<std::tuple<crate::syntax::Template, crate::syntax::parser::Ps>> start_parse_template_f(crate::syntax::parser::Ps p0_p0, crate::syntax::lexer::TemplateTok t_p1, crate::syntax::Range span_p2);

std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps> template_parts_f(const crate::syntax::parser::Ps& p_p0, const Array<crate::syntax::lexer::TPartTok>& parts_p1);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>> start_template_parts_f(crate::syntax::parser::Ps p_p0, Array<crate::syntax::lexer::TPartTok> parts_p1);

std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps> template_part_of_f(const Array<crate::syntax::TemplatePart>& acc_p0, const crate::syntax::parser::Ps& p_p1, const crate::syntax::lexer::TPartTok& tpart_tok2);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>> start_template_part_of_f(Array<crate::syntax::TemplatePart> acc_p0, crate::syntax::parser::Ps p_p1, crate::syntax::lexer::TPartTok tpart_tok2);

std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps> attr_arg_f(const Array<crate::syntax::Arg>& done_p0, const crate::syntax::parser::Ps& p_p1, const crate::syntax::lexer::AttrTok& a_p2);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> start_attr_arg_f(Array<crate::syntax::Arg> done_p0, crate::syntax::parser::Ps p_p1, crate::syntax::lexer::AttrTok a_p2);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_lambda_f(const crate::syntax::parser::Ps& p0_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_lambda_f(crate::syntax::parser::Ps p0_p0);

std::tuple<std::optional<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps> lambda_params_f(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<std::optional<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps>> start_lambda_params_f(crate::syntax::parser::Ps p_p0);

std::tuple<crate::syntax::Cond, crate::syntax::parser::Ps> parse_cond_f(const crate::syntax::parser::Ps& p_p0, const bool& allow_guard_p1);

prism_rtl::JobRef<std::tuple<crate::syntax::Cond, crate::syntax::parser::Ps>> start_parse_cond_f(crate::syntax::parser::Ps p_p0, bool allow_guard_p1);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_if_f(const crate::syntax::parser::Ps& p0_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_if_f(crate::syntax::parser::Ps p0_p0);

bool is_else_f(const crate::syntax::lexer::TokKind& tok_kind0);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_match_f(const crate::syntax::parser::Ps& p0_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_match_f(crate::syntax::parser::Ps p0_p0);

std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps> match_arms_f(const crate::syntax::parser::Ps& p0_p0);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>> start_match_arms_f(crate::syntax::parser::Ps p0_p0);

std::tuple<crate::syntax::Arm, crate::syntax::parser::Ps> parse_arm_f(const crate::syntax::parser::Ps& p_p0);

std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::parser::Ps> optional_expr_f(const crate::syntax::parser::Ps& p_p0);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_for_f(const crate::syntax::parser::Ps& p0_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_for_f(crate::syntax::parser::Ps p0_p0);

std::tuple<std::optional<crate::syntax::ForBinders>, crate::syntax::parser::Ps> for_binders_of_f(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::ForBinders>, crate::syntax::parser::Ps>> start_for_binders_of_f(crate::syntax::parser::Ps p_p0);

std::tuple<std::optional<crate::syntax::Pattern_>, crate::syntax::parser::Ps> optional_pattern_f(const crate::syntax::parser::Ps& p_p0);

}  // namespace syntax::parser::expr


namespace syntax::parser::expr {

/// The step machine of `ParseExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseExpr: unbounded fn Ps -> ((Expr, Ps))
struct ParseExpr : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    ParseExpr(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseArgExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseArgExpr: unbounded fn Ps -> ((Expr, Ps))
struct ParseArgExpr : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    ParseArgExpr(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseExprCtx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseExprCtx: unbounded fn Ps, Bool -> ((Expr, Ps))
struct ParseExprCtx : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    bool commas_p1;
    ParseExprCtx(crate::syntax::parser::Ps p_p0, bool commas_p1) : p_p0(std::move(p_p0)), commas_p1(std::move(commas_p1)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseRhsExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseRhsExpr: unbounded fn Ps -> ((Expr, Ps))
struct ParseRhsExpr : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    ParseRhsExpr(crate::syntax::parser::Ps p0_p0) : p0_p0(std::move(p0_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseBinary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseBinary: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
struct ParseBinary : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    Nat min_p1;
    bool commas_p2;
    ParseBinary(crate::syntax::parser::Ps p0_p0, Nat min_p1, bool commas_p2) : p0_p0(std::move(p0_p0)), min_p1(std::move(min_p1)), commas_p2(std::move(commas_p2)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ClimbStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClimbStep: unbounded fn Climb, Nat, Bool -> Climb
struct ClimbStep : prism_rtl::Job<Climb> {
    Climb c_p0;
    Nat min_p1;
    bool commas_p2;
    ClimbStep(Climb c_p0, Nat min_p1, bool commas_p2) : c_p0(std::move(c_p0)), min_p1(std::move(min_p1)), commas_p2(std::move(commas_p2)) {}
    prism_rtl::Turn<Climb> cycle() const override;
};


/// The step machine of `ParsePrefix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParsePrefix: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
struct ParsePrefix : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    Nat min_p1;
    bool commas_p2;
    ParsePrefix(crate::syntax::parser::Ps p_p0, Nat min_p1, bool commas_p2) : p_p0(std::move(p_p0)), min_p1(std::move(min_p1)), commas_p2(std::move(commas_p2)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParsePostfixExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParsePostfixExpr: unbounded fn Ps, Bool -> ((Expr, Ps))
struct ParsePostfixExpr : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    bool commas_p1;
    ParsePostfixExpr(crate::syntax::parser::Ps p_p0, bool commas_p1) : p_p0(std::move(p_p0)), commas_p1(std::move(commas_p1)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParsePostfix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParsePostfix: unbounded fn Expr, Ps, Bool -> ((Expr, Ps))
struct ParsePostfix : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::Expr e0_p0;
    crate::syntax::parser::Ps p0_p1;
    bool commas_p2;
    ParsePostfix(crate::syntax::Expr e0_p0, crate::syntax::parser::Ps p0_p1, bool commas_p2) : e0_p0(std::move(e0_p0)), p0_p1(std::move(p0_p1)), commas_p2(std::move(commas_p2)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `PostfixStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PostfixStep: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
struct PostfixStep : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool>> {
    crate::syntax::Expr e_p0;
    crate::syntax::parser::Ps p_p1;
    bool commas_p2;
    PostfixStep(crate::syntax::Expr e_p0, crate::syntax::parser::Ps p_p1, bool commas_p2) : e_p0(std::move(e_p0)), p_p1(std::move(p_p1)), commas_p2(std::move(commas_p2)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool>> cycle() const override;
};


/// The step machine of `FieldOrMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldOrMethod: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
struct FieldOrMethod : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool>> {
    crate::syntax::Expr e_p0;
    crate::syntax::parser::Ps p0_p1;
    bool commas_p2;
    FieldOrMethod(crate::syntax::Expr e_p0, crate::syntax::parser::Ps p0_p1, bool commas_p2) : e_p0(std::move(e_p0)), p0_p1(std::move(p0_p1)), commas_p2(std::move(commas_p2)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool>> cycle() const override;
};


/// The step machine of `ParseTypeArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTypeArgs: unbounded fn Ps -> (([Type], Ps))
struct ParseTypeArgs : prism_rtl::Job<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    ParseTypeArgs(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseCallArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseCallArgs: unbounded fn Ps, Bool -> (([Arg], Ps))
struct ParseCallArgs : prism_rtl::Job<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    bool commas_p1;
    ParseCallArgs(crate::syntax::parser::Ps p_p0, bool commas_p1) : p_p0(std::move(p_p0)), commas_p1(std::move(commas_p1)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseOneArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseOneArg: unbounded fn Ps -> (([Arg], Ps))
struct ParseOneArg : prism_rtl::Job<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    ParseOneArg(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseArg: unbounded fn Ps -> ((Arg, Ps))
struct ParseArg : prism_rtl::Job<std::tuple<crate::syntax::Arg, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    ParseArg(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Arg, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseParenArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseParenArgs: unbounded fn Ps -> (([Arg], Bool, Ps))
struct ParseParenArgs : prism_rtl::Job<std::tuple<Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    ParseParenArgs(crate::syntax::parser::Ps p0_p0) : p0_p0(std::move(p0_p0)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParsePrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParsePrimary: unbounded fn Ps, Bool -> ((Expr, Bool, Ps))
struct ParsePrimary : prism_rtl::Job<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    bool commas_p1;
    ParsePrimary(crate::syntax::parser::Ps p_p0, bool commas_p1) : p_p0(std::move(p_p0)), commas_p1(std::move(commas_p1)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `LiteralPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LiteralPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
struct LiteralPrimary : prism_rtl::Job<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    LiteralPrimary(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `NamePrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamePrimary: unbounded fn Ps, NameTok, Bool -> ((Expr, Bool, Ps))
struct NamePrimary : prism_rtl::Job<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    crate::syntax::lexer::NameTok n_p1;
    bool commas_p2;
    NamePrimary(crate::syntax::parser::Ps p0_p0, crate::syntax::lexer::NameTok n_p1, bool commas_p2) : p0_p0(std::move(p0_p0)), n_p1(std::move(n_p1)), commas_p2(std::move(commas_p2)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `TypeArgsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeArgsOn: unbounded fn Expr, Ps, Range -> ((Expr, Ps))
struct TypeArgsOn : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::Expr e_p0;
    crate::syntax::parser::Ps p_p1;
    crate::syntax::Range start_p2;
    TypeArgsOn(crate::syntax::Expr e_p0, crate::syntax::parser::Ps p_p1, crate::syntax::Range start_p2) : e_p0(std::move(e_p0)), p_p1(std::move(p_p1)), start_p2(std::move(start_p2)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParenPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParenPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
struct ParenPrimary : prism_rtl::Job<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    ParenPrimary(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `SquarePrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SquarePrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
struct SquarePrimary : prism_rtl::Job<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    SquarePrimary(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `MapPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MapPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
struct MapPrimary : prism_rtl::Job<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    MapPrimary(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseMapEntry`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseMapEntry: unbounded fn Ps -> ((((Expr, Expr)), Ps))
struct ParseMapEntry : prism_rtl::Job<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::Expr>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    ParseMapEntry(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::Expr>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `LensPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LensPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
struct LensPrimary : prism_rtl::Job<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    LensPrimary(crate::syntax::parser::Ps p0_p0) : p0_p0(std::move(p0_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `KeywordPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// KeywordPrimary: unbounded fn Ps, Text, Text, Bool -> ((Expr, Bool, Ps))
struct KeywordPrimary : prism_rtl::Job<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    Text w_p1;
    Text sigils_p2;
    bool commas_p3;
    KeywordPrimary(crate::syntax::parser::Ps p_p0, Text w_p1, Text sigils_p2, bool commas_p3) : p_p0(std::move(p_p0)), w_p1(std::move(w_p1)), sigils_p2(std::move(sigils_p2)), commas_p3(std::move(commas_p3)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseLiteral`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseLiteral: unbounded fn Ps -> ((Literal, Ps))
struct ParseLiteral : prism_rtl::Job<std::tuple<crate::syntax::Literal, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    ParseLiteral(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Literal, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `TextSegment`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TextSegment: unbounded fn [TextSeg], Ps, TextSegTok -> (([TextSeg], Ps))
struct TextSegment : prism_rtl::Job<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>> {
    Array<crate::syntax::TextSeg> acc_p0;
    crate::syntax::parser::Ps p_p1;
    crate::syntax::lexer::TextSegTok text_seg_tok2;
    TextSegment(Array<crate::syntax::TextSeg> acc_p0, crate::syntax::parser::Ps p_p1, crate::syntax::lexer::TextSegTok text_seg_tok2) : acc_p0(std::move(acc_p0)), p_p1(std::move(p_p1)), text_seg_tok2(std::move(text_seg_tok2)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseNested`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseNested: unbounded fn Ps, [Tok], Range -> ((Expr, Ps))
struct ParseNested : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    Array<crate::syntax::lexer::Tok> toks_p1;
    crate::syntax::Range span_p2;
    ParseNested(crate::syntax::parser::Ps p_p0, Array<crate::syntax::lexer::Tok> toks_p1, crate::syntax::Range span_p2) : p_p0(std::move(p_p0)), toks_p1(std::move(toks_p1)), span_p2(std::move(span_p2)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTemplate: unbounded fn Ps, TemplateTok, Range -> ((Template, Ps))
struct ParseTemplate : prism_rtl::Job<std::tuple<crate::syntax::Template, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    crate::syntax::lexer::TemplateTok t_p1;
    crate::syntax::Range span_p2;
    ParseTemplate(crate::syntax::parser::Ps p0_p0, crate::syntax::lexer::TemplateTok t_p1, crate::syntax::Range span_p2) : p0_p0(std::move(p0_p0)), t_p1(std::move(t_p1)), span_p2(std::move(span_p2)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Template, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `TemplateParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateParts: unbounded fn Ps, [TPartTok] -> (([TemplatePart], Ps))
struct TemplateParts : prism_rtl::Job<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    Array<crate::syntax::lexer::TPartTok> parts_p1;
    TemplateParts(crate::syntax::parser::Ps p_p0, Array<crate::syntax::lexer::TPartTok> parts_p1) : p_p0(std::move(p_p0)), parts_p1(std::move(parts_p1)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `TemplatePartOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplatePartOf: unbounded fn [TemplatePart], Ps, TPartTok -> (([TemplatePart], Ps))
struct TemplatePartOf : prism_rtl::Job<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>> {
    Array<crate::syntax::TemplatePart> acc_p0;
    crate::syntax::parser::Ps p_p1;
    crate::syntax::lexer::TPartTok tpart_tok2;
    TemplatePartOf(Array<crate::syntax::TemplatePart> acc_p0, crate::syntax::parser::Ps p_p1, crate::syntax::lexer::TPartTok tpart_tok2) : acc_p0(std::move(acc_p0)), p_p1(std::move(p_p1)), tpart_tok2(std::move(tpart_tok2)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `AttrArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AttrArg: unbounded fn [Arg], Ps, AttrTok -> (([Arg], Ps))
struct AttrArg : prism_rtl::Job<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> {
    Array<crate::syntax::Arg> done_p0;
    crate::syntax::parser::Ps p_p1;
    crate::syntax::lexer::AttrTok a_p2;
    AttrArg(Array<crate::syntax::Arg> done_p0, crate::syntax::parser::Ps p_p1, crate::syntax::lexer::AttrTok a_p2) : done_p0(std::move(done_p0)), p_p1(std::move(p_p1)), a_p2(std::move(a_p2)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseLambda: unbounded fn Ps -> ((Expr, Ps))
struct ParseLambda : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    ParseLambda(crate::syntax::parser::Ps p0_p0) : p0_p0(std::move(p0_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `LambdaParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaParams: unbounded fn Ps -> ((?[Pattern], Ps))
struct LambdaParams : prism_rtl::Job<std::tuple<std::optional<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    LambdaParams(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<std::optional<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseCond`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseCond: unbounded fn Ps, Bool -> ((Cond, Ps))
struct ParseCond : prism_rtl::Job<std::tuple<crate::syntax::Cond, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    bool allow_guard_p1;
    ParseCond(crate::syntax::parser::Ps p_p0, bool allow_guard_p1) : p_p0(std::move(p_p0)), allow_guard_p1(std::move(allow_guard_p1)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Cond, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseIf: unbounded fn Ps -> ((Expr, Ps))
struct ParseIf : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    ParseIf(crate::syntax::parser::Ps p0_p0) : p0_p0(std::move(p0_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseMatch: unbounded fn Ps -> ((Expr, Ps))
struct ParseMatch : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    ParseMatch(crate::syntax::parser::Ps p0_p0) : p0_p0(std::move(p0_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `MatchArms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchArms: unbounded fn Ps -> (([Arm], Ps))
struct MatchArms : prism_rtl::Job<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    MatchArms(crate::syntax::parser::Ps p0_p0) : p0_p0(std::move(p0_p0)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseFor: unbounded fn Ps -> ((Expr, Ps))
struct ParseFor : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    ParseFor(crate::syntax::parser::Ps p0_p0) : p0_p0(std::move(p0_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ForBindersOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ForBindersOf: unbounded fn Ps -> ((?ForBinders, Ps))
struct ForBindersOf : prism_rtl::Job<std::tuple<std::optional<crate::syntax::ForBinders>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    ForBindersOf(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<std::optional<crate::syntax::ForBinders>, crate::syntax::parser::Ps>> cycle() const override;
};


}  // namespace syntax::parser::expr

}  // namespace crate
