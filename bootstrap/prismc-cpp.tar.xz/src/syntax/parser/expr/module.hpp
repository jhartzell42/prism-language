// The module `Syntax.Parser.Expr`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/parser/expr/types.hpp>
#include "elem.types.hpp"
#include <syntax/parser/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::parser::expr {

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_expr(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_arg_expr(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_arg_expr(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_ctx(const crate::syntax::parser::Ps& p_, const bool& commas);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_expr_ctx(crate::syntax::parser::Ps p_, bool commas);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr(const crate::syntax::parser::Ps& p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_rhs_expr(crate::syntax::parser::Ps p0);

bool at_line_method(const crate::syntax::parser::Ps& p_);

bool is_plain_upper(const crate::syntax::lexer::TokKind& tok_kind0);

bool is_upper_tok(const crate::syntax::lexer::TokKind& tok_kind0);

std::optional<std::tuple<Text, std::optional<Array<Text>>>> peek_binop(const crate::syntax::parser::Ps& p_);

bool is_binop(const Text& op);

Nat level(const Text& text0);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_binary(const crate::syntax::parser::Ps& p0, const Nat& min_, const bool& commas);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_binary(crate::syntax::parser::Ps p0, Nat min_, bool commas);

Climb climb_step(const Climb& c, const Nat& min_, const bool& commas);

prism_rtl::JobRef<Climb> start_climb_step(Climb c, Nat min_, bool commas);

crate::syntax::parser::Ps no_operator(const crate::syntax::parser::Ps& p_);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_prefix(const crate::syntax::parser::Ps& p_, const Nat& min_, const bool& commas);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_prefix(crate::syntax::parser::Ps p_, Nat min_, bool commas);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_postfix_expr(const crate::syntax::parser::Ps& p_, const bool& commas);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_postfix_expr(crate::syntax::parser::Ps p_, bool commas);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_postfix(const crate::syntax::Expr& e0, const crate::syntax::parser::Ps& p0, const bool& commas);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_postfix(crate::syntax::Expr e0, crate::syntax::parser::Ps p0, bool commas);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool> postfix_step(const crate::syntax::Expr& e, const crate::syntax::parser::Ps& p_, const bool& commas);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool>> start_postfix_step(crate::syntax::Expr e, crate::syntax::parser::Ps p_, bool commas);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool> field_or_method(const crate::syntax::Expr& e, const crate::syntax::parser::Ps& p0, const bool& commas);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool>> start_field_or_method(crate::syntax::Expr e, crate::syntax::parser::Ps p0, bool commas);

std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps> parse_type_args(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>> start_parse_type_args(crate::syntax::parser::Ps p_);

bool arg_starts_here(const crate::syntax::parser::Ps& p_);

Array<Text> arg_words();

std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps> parse_call_args(const crate::syntax::parser::Ps& p_, const bool& commas);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> start_parse_call_args(crate::syntax::parser::Ps p_, bool commas);

std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps> parse_one_arg(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> start_parse_one_arg(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::Arg, crate::syntax::parser::Ps> parse_arg(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::Arg, crate::syntax::parser::Ps>> start_parse_arg(crate::syntax::parser::Ps p_);

std::tuple<Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps> parse_paren_args(const crate::syntax::parser::Ps& p0);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps>> start_parse_paren_args(crate::syntax::parser::Ps p0);

std::tuple<std::optional<crate::syntax::Ident>, crate::syntax::parser::Ps> parse_arg_name(const crate::syntax::parser::Ps& p_);

std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> parse_primary(const crate::syntax::parser::Ps& p_, const bool& commas);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_parse_primary(crate::syntax::parser::Ps p_, bool commas);

std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> literal_primary(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_literal_primary(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> name_primary(const crate::syntax::parser::Ps& p0, const crate::syntax::lexer::NameTok& n, const bool& commas);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_name_primary(crate::syntax::parser::Ps p0, crate::syntax::lexer::NameTok n, bool commas);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> type_args_on(const crate::syntax::Expr& e, const crate::syntax::parser::Ps& p_, const crate::syntax::Range& start);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_type_args_on(crate::syntax::Expr e, crate::syntax::parser::Ps p_, crate::syntax::Range start);

std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> paren_primary(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_paren_primary(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> square_primary(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_square_primary(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> map_primary(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_map_primary(crate::syntax::parser::Ps p_);

std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::Expr>, crate::syntax::parser::Ps> parse_map_entry(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::Expr>, crate::syntax::parser::Ps>> start_parse_map_entry(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> lens_primary(const crate::syntax::parser::Ps& p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_lens_primary(crate::syntax::parser::Ps p0);

std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> keyword_primary(const crate::syntax::parser::Ps& p_, const Text& w, const Text& sigils, const bool& commas);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_keyword_primary(crate::syntax::parser::Ps p_, Text w, Text sigils, bool commas);

std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> took(const std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>& arg0);

std::tuple<crate::syntax::Literal, crate::syntax::parser::Ps> parse_literal(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<crate::syntax::Literal, crate::syntax::parser::Ps>> start_parse_literal(crate::syntax::parser::Ps p_);

std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps> text_segment(const Array<crate::syntax::TextSeg>& acc, const crate::syntax::parser::Ps& p_, const crate::syntax::lexer::TextSegTok& text_seg_tok2);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>> start_text_segment(Array<crate::syntax::TextSeg> acc, crate::syntax::parser::Ps p_, crate::syntax::lexer::TextSegTok text_seg_tok2);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_nested(const crate::syntax::parser::Ps& p_, const Array<crate::syntax::lexer::Tok>& toks, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_nested(crate::syntax::parser::Ps p_, Array<crate::syntax::lexer::Tok> toks, crate::syntax::Range span);

std::tuple<crate::syntax::Template, crate::syntax::parser::Ps> parse_template(const crate::syntax::parser::Ps& p0, const crate::syntax::lexer::TemplateTok& t, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::syntax::Template, crate::syntax::parser::Ps>> start_parse_template(crate::syntax::parser::Ps p0, crate::syntax::lexer::TemplateTok t, crate::syntax::Range span);

std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps> template_parts(const crate::syntax::parser::Ps& p_, const Array<crate::syntax::lexer::TPartTok>& parts);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>> start_template_parts(crate::syntax::parser::Ps p_, Array<crate::syntax::lexer::TPartTok> parts);

std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps> template_part_of(const Array<crate::syntax::TemplatePart>& acc, const crate::syntax::parser::Ps& p_, const crate::syntax::lexer::TPartTok& tpart_tok2);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>> start_template_part_of(Array<crate::syntax::TemplatePart> acc, crate::syntax::parser::Ps p_, crate::syntax::lexer::TPartTok tpart_tok2);

std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps> attr_arg(const Array<crate::syntax::Arg>& done, const crate::syntax::parser::Ps& p_, const crate::syntax::lexer::AttrTok& a);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> start_attr_arg(Array<crate::syntax::Arg> done, crate::syntax::parser::Ps p_, crate::syntax::lexer::AttrTok a);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_lambda(const crate::syntax::parser::Ps& p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_lambda(crate::syntax::parser::Ps p0);

std::tuple<std::optional<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps> lambda_params(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<std::optional<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps>> start_lambda_params(crate::syntax::parser::Ps p_);

std::tuple<crate::syntax::Cond, crate::syntax::parser::Ps> parse_cond(const crate::syntax::parser::Ps& p_, const bool& allow_guard);

prism_rtl::JobRef<std::tuple<crate::syntax::Cond, crate::syntax::parser::Ps>> start_parse_cond(crate::syntax::parser::Ps p_, bool allow_guard);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_if(const crate::syntax::parser::Ps& p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_if(crate::syntax::parser::Ps p0);

bool is_else(const crate::syntax::lexer::TokKind& tok_kind0);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_match(const crate::syntax::parser::Ps& p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_match(crate::syntax::parser::Ps p0);

std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps> match_arms(const crate::syntax::parser::Ps& p0);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>> start_match_arms(crate::syntax::parser::Ps p0);

std::tuple<crate::syntax::Arm, crate::syntax::parser::Ps> parse_arm(const crate::syntax::parser::Ps& p_);

std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::parser::Ps> optional_expr(const crate::syntax::parser::Ps& p_);

std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_for(const crate::syntax::parser::Ps& p0);

prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_for(crate::syntax::parser::Ps p0);

std::tuple<std::optional<crate::syntax::ForBinders>, crate::syntax::parser::Ps> for_binders_of(const crate::syntax::parser::Ps& p_);

prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::ForBinders>, crate::syntax::parser::Ps>> start_for_binders_of(crate::syntax::parser::Ps p_);

std::tuple<std::optional<crate::syntax::Pattern_>, crate::syntax::parser::Ps> optional_pattern(const crate::syntax::parser::Ps& p_);

}  // namespace syntax::parser::expr


namespace syntax::parser::expr {

/// The step machine of `ParseExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseExpr: unbounded fn Ps -> ((Expr, Ps))
struct ParseExpr : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseExpr(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseArgExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseArgExpr: unbounded fn Ps -> ((Expr, Ps))
struct ParseArgExpr : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseArgExpr(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseExprCtx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseExprCtx: unbounded fn Ps, Bool -> ((Expr, Ps))
struct ParseExprCtx : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    bool commas;
    ParseExprCtx(crate::syntax::parser::Ps p_, bool commas) : p_(std::move(p_)), commas(std::move(commas)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseRhsExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseRhsExpr: unbounded fn Ps -> ((Expr, Ps))
struct ParseRhsExpr : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    ParseRhsExpr(crate::syntax::parser::Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseBinary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseBinary: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
struct ParseBinary : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    Nat min_;
    bool commas;
    ParseBinary(crate::syntax::parser::Ps p0, Nat min_, bool commas) : p0(std::move(p0)), min_(std::move(min_)), commas(std::move(commas)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ClimbStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClimbStep: unbounded fn Climb, Nat, Bool -> Climb
struct ClimbStep : prism_rtl::Job<Climb> {
    Climb c;
    Nat min_;
    bool commas;
    ClimbStep(Climb c, Nat min_, bool commas) : c(std::move(c)), min_(std::move(min_)), commas(std::move(commas)) {}
    prism_rtl::Turn<Climb> cycle() const override;
};


/// The step machine of `ParsePrefix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParsePrefix: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
struct ParsePrefix : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    Nat min_;
    bool commas;
    ParsePrefix(crate::syntax::parser::Ps p_, Nat min_, bool commas) : p_(std::move(p_)), min_(std::move(min_)), commas(std::move(commas)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParsePostfixExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParsePostfixExpr: unbounded fn Ps, Bool -> ((Expr, Ps))
struct ParsePostfixExpr : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    bool commas;
    ParsePostfixExpr(crate::syntax::parser::Ps p_, bool commas) : p_(std::move(p_)), commas(std::move(commas)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParsePostfix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParsePostfix: unbounded fn Expr, Ps, Bool -> ((Expr, Ps))
struct ParsePostfix : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::Expr e0;
    crate::syntax::parser::Ps p0;
    bool commas;
    ParsePostfix(crate::syntax::Expr e0, crate::syntax::parser::Ps p0, bool commas) : e0(std::move(e0)), p0(std::move(p0)), commas(std::move(commas)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `PostfixStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PostfixStep: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
struct PostfixStep : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool>> {
    crate::syntax::Expr e;
    crate::syntax::parser::Ps p_;
    bool commas;
    PostfixStep(crate::syntax::Expr e, crate::syntax::parser::Ps p_, bool commas) : e(std::move(e)), p_(std::move(p_)), commas(std::move(commas)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool>> cycle() const override;
};


/// The step machine of `FieldOrMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldOrMethod: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
struct FieldOrMethod : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool>> {
    crate::syntax::Expr e;
    crate::syntax::parser::Ps p0;
    bool commas;
    FieldOrMethod(crate::syntax::Expr e, crate::syntax::parser::Ps p0, bool commas) : e(std::move(e)), p0(std::move(p0)), commas(std::move(commas)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool>> cycle() const override;
};


/// The step machine of `ParseTypeArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTypeArgs: unbounded fn Ps -> (([Type], Ps))
struct ParseTypeArgs : prism_rtl::Job<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseTypeArgs(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseCallArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseCallArgs: unbounded fn Ps, Bool -> (([Arg], Ps))
struct ParseCallArgs : prism_rtl::Job<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    bool commas;
    ParseCallArgs(crate::syntax::parser::Ps p_, bool commas) : p_(std::move(p_)), commas(std::move(commas)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseOneArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseOneArg: unbounded fn Ps -> (([Arg], Ps))
struct ParseOneArg : prism_rtl::Job<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseOneArg(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseArg: unbounded fn Ps -> ((Arg, Ps))
struct ParseArg : prism_rtl::Job<std::tuple<crate::syntax::Arg, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseArg(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Arg, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseParenArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseParenArgs: unbounded fn Ps -> (([Arg], Bool, Ps))
struct ParseParenArgs : prism_rtl::Job<std::tuple<Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    ParseParenArgs(crate::syntax::parser::Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParsePrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParsePrimary: unbounded fn Ps, Bool -> ((Expr, Bool, Ps))
struct ParsePrimary : prism_rtl::Job<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    bool commas;
    ParsePrimary(crate::syntax::parser::Ps p_, bool commas) : p_(std::move(p_)), commas(std::move(commas)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `LiteralPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LiteralPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
struct LiteralPrimary : prism_rtl::Job<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    LiteralPrimary(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `NamePrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamePrimary: unbounded fn Ps, NameTok, Bool -> ((Expr, Bool, Ps))
struct NamePrimary : prism_rtl::Job<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    crate::syntax::lexer::NameTok n;
    bool commas;
    NamePrimary(crate::syntax::parser::Ps p0, crate::syntax::lexer::NameTok n, bool commas) : p0(std::move(p0)), n(std::move(n)), commas(std::move(commas)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `TypeArgsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeArgsOn: unbounded fn Expr, Ps, Range -> ((Expr, Ps))
struct TypeArgsOn : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::Expr e;
    crate::syntax::parser::Ps p_;
    crate::syntax::Range start;
    TypeArgsOn(crate::syntax::Expr e, crate::syntax::parser::Ps p_, crate::syntax::Range start) : e(std::move(e)), p_(std::move(p_)), start(std::move(start)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParenPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParenPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
struct ParenPrimary : prism_rtl::Job<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParenPrimary(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `SquarePrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SquarePrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
struct SquarePrimary : prism_rtl::Job<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    SquarePrimary(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `MapPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MapPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
struct MapPrimary : prism_rtl::Job<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    MapPrimary(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseMapEntry`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseMapEntry: unbounded fn Ps -> ((((Expr, Expr)), Ps))
struct ParseMapEntry : prism_rtl::Job<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::Expr>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseMapEntry(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::Expr>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `LensPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LensPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
struct LensPrimary : prism_rtl::Job<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    LensPrimary(crate::syntax::parser::Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `KeywordPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// KeywordPrimary: unbounded fn Ps, Text, Text, Bool -> ((Expr, Bool, Ps))
struct KeywordPrimary : prism_rtl::Job<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    Text w;
    Text sigils;
    bool commas;
    KeywordPrimary(crate::syntax::parser::Ps p_, Text w, Text sigils, bool commas) : p_(std::move(p_)), w(std::move(w)), sigils(std::move(sigils)), commas(std::move(commas)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseLiteral`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseLiteral: unbounded fn Ps -> ((Literal, Ps))
struct ParseLiteral : prism_rtl::Job<std::tuple<crate::syntax::Literal, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ParseLiteral(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Literal, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `TextSegment`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TextSegment: unbounded fn [TextSeg], Ps, TextSegTok -> (([TextSeg], Ps))
struct TextSegment : prism_rtl::Job<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>> {
    Array<crate::syntax::TextSeg> acc;
    crate::syntax::parser::Ps p_;
    crate::syntax::lexer::TextSegTok text_seg_tok2;
    TextSegment(Array<crate::syntax::TextSeg> acc, crate::syntax::parser::Ps p_, crate::syntax::lexer::TextSegTok text_seg_tok2) : acc(std::move(acc)), p_(std::move(p_)), text_seg_tok2(std::move(text_seg_tok2)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseNested`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseNested: unbounded fn Ps, [Tok], Range -> ((Expr, Ps))
struct ParseNested : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    Array<crate::syntax::lexer::Tok> toks;
    crate::syntax::Range span;
    ParseNested(crate::syntax::parser::Ps p_, Array<crate::syntax::lexer::Tok> toks, crate::syntax::Range span) : p_(std::move(p_)), toks(std::move(toks)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTemplate: unbounded fn Ps, TemplateTok, Range -> ((Template, Ps))
struct ParseTemplate : prism_rtl::Job<std::tuple<crate::syntax::Template, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    crate::syntax::lexer::TemplateTok t;
    crate::syntax::Range span;
    ParseTemplate(crate::syntax::parser::Ps p0, crate::syntax::lexer::TemplateTok t, crate::syntax::Range span) : p0(std::move(p0)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Template, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `TemplateParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateParts: unbounded fn Ps, [TPartTok] -> (([TemplatePart], Ps))
struct TemplateParts : prism_rtl::Job<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    Array<crate::syntax::lexer::TPartTok> parts;
    TemplateParts(crate::syntax::parser::Ps p_, Array<crate::syntax::lexer::TPartTok> parts) : p_(std::move(p_)), parts(std::move(parts)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `TemplatePartOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplatePartOf: unbounded fn [TemplatePart], Ps, TPartTok -> (([TemplatePart], Ps))
struct TemplatePartOf : prism_rtl::Job<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>> {
    Array<crate::syntax::TemplatePart> acc;
    crate::syntax::parser::Ps p_;
    crate::syntax::lexer::TPartTok tpart_tok2;
    TemplatePartOf(Array<crate::syntax::TemplatePart> acc, crate::syntax::parser::Ps p_, crate::syntax::lexer::TPartTok tpart_tok2) : acc(std::move(acc)), p_(std::move(p_)), tpart_tok2(std::move(tpart_tok2)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `AttrArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AttrArg: unbounded fn [Arg], Ps, AttrTok -> (([Arg], Ps))
struct AttrArg : prism_rtl::Job<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> {
    Array<crate::syntax::Arg> done;
    crate::syntax::parser::Ps p_;
    crate::syntax::lexer::AttrTok a;
    AttrArg(Array<crate::syntax::Arg> done, crate::syntax::parser::Ps p_, crate::syntax::lexer::AttrTok a) : done(std::move(done)), p_(std::move(p_)), a(std::move(a)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseLambda: unbounded fn Ps -> ((Expr, Ps))
struct ParseLambda : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    ParseLambda(crate::syntax::parser::Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `LambdaParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaParams: unbounded fn Ps -> ((?[Pattern], Ps))
struct LambdaParams : prism_rtl::Job<std::tuple<std::optional<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    LambdaParams(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<std::optional<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseCond`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseCond: unbounded fn Ps, Bool -> ((Cond, Ps))
struct ParseCond : prism_rtl::Job<std::tuple<crate::syntax::Cond, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    bool allow_guard;
    ParseCond(crate::syntax::parser::Ps p_, bool allow_guard) : p_(std::move(p_)), allow_guard(std::move(allow_guard)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Cond, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseIf: unbounded fn Ps -> ((Expr, Ps))
struct ParseIf : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    ParseIf(crate::syntax::parser::Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseMatch: unbounded fn Ps -> ((Expr, Ps))
struct ParseMatch : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    ParseMatch(crate::syntax::parser::Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `MatchArms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchArms: unbounded fn Ps -> (([Arm], Ps))
struct MatchArms : prism_rtl::Job<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    MatchArms(crate::syntax::parser::Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseFor: unbounded fn Ps -> ((Expr, Ps))
struct ParseFor : prism_rtl::Job<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0;
    ParseFor(crate::syntax::parser::Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ForBindersOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ForBindersOf: unbounded fn Ps -> ((?ForBinders, Ps))
struct ForBindersOf : prism_rtl::Job<std::tuple<std::optional<crate::syntax::ForBinders>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_;
    ForBindersOf(crate::syntax::parser::Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<std::optional<crate::syntax::ForBinders>, crate::syntax::parser::Ps>> cycle() const override;
};


}  // namespace syntax::parser::expr

}  // namespace crate
