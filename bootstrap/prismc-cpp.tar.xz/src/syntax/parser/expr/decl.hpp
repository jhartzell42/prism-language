// The module `Syntax.Parser.Expr`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace syntax::parser::expr {

struct ArgsRead;

struct Climb;

struct ParseExpr;

struct ParseArgExpr;

struct ParseExprCtx;

struct ParseRhsExpr;

struct ParseBinary;

struct ClimbStep;

struct ParsePrefix;

struct ParsePostfixExpr;

struct ParsePostfix;

struct PostfixStep;

struct FieldOrMethod;

struct ParseTypeArgs;

struct ParseCallArgs;

struct ParseOneArg;

struct ParseArg;

struct ParseParenArgs;

struct ParsePrimary;

struct LiteralPrimary;

struct NamePrimary;

struct TypeArgsOn;

struct ParenPrimary;

struct SquarePrimary;

struct MapPrimary;

struct ParseMapEntry;

struct LensPrimary;

struct KeywordPrimary;

struct ParseLiteral;

struct TextSegment;

struct ParseNested;

struct ParseTemplate;

struct TemplateParts;

struct TemplatePartOf;

struct AttrArg;

struct ParseLambda;

struct LambdaParams;

struct ParseCond;

struct ParseIf;

struct ParseMatch;

struct MatchArms;

struct ParseFor;

struct ForBindersOf;

}  // namespace syntax::parser::expr


}  // namespace crate
