// The module `Syntax.Parser.TestLanguage`, from `target/bootstrap/cpp-src/prismc/syntax/parser/test_language.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <syntax/parser/test_language/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::syntax::parser::test_language {

/// let deliveryWords
Array<Text> delivery_words() {
    return Array(std::vector{Text::lit("send"), Text::lit("click"), Text::lit("answer")});
}


/// IsDeliveryWord: fn Text -> Bool
bool is_delivery_word(const Text& w) {
    return fold(delivery_words(), false, [&](const bool& seen, const Text& d) { return seen || (d == w); });
}


/// StepWord: fn Ps -> Text
Text step_word(const crate::syntax::parser::Ps& p_) {
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if (((n.sigils == Text::lit("")) && (len(n->path_) == Nat(1u))) && (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) {
            return or_(index(n->path_, Nat(0u)), Text::lit(""));
        }
    }
    {
        return Text::lit("");
    }
}


/// AtWord: fn Ps, Text -> Bool
bool at_word(const crate::syntax::parser::Ps& p_, const Text& w) {
    return step_word(p_) == w;
}


/// ParseCheckDecl: unbounded fn Ps -> ((CheckDecl, Ps))
std::tuple<crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps> parse_check_decl(const crate::syntax::parser::Ps& p0) {
    auto start = crate::syntax::parser::here(p0);
    auto [name, p1] = crate::syntax::parser::parse_ident(crate::syntax::parser::adv(p0));
    auto p2 = crate::syntax::parser::expect_colon(p1);
    return crate::syntax::parser::at_open_l(p2)
        ? ({
        auto [lines, q] = crate::syntax::parser::layout_items(crate::syntax::parser::adv(p2), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::CheckLine, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_check_line(a0)); })));
        std::tuple{crate::syntax::decls::CheckDecl{.name = name, .lines = lines, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
    })
        : std::tuple{crate::syntax::decls::CheckDecl{.name = name, .lines = Array<crate::syntax::decls::CheckLine>{}, .span = start}, crate::syntax::parser::error_here(p2, Text::lit("a `check` block's lines stand in an indented block"))};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps>> ParseCheckDecl::cycle() const {
    const auto& p0 = this->p0;
    auto start = crate::syntax::parser::here(p0);
    auto [name, p1] = crate::syntax::parser::parse_ident(crate::syntax::parser::adv(p0));
    auto p2 = crate::syntax::parser::expect_colon(p1);
    return crate::syntax::parser::at_open_l(p2)
        ? call_then(crate::syntax::parser::start_layout_items(crate::syntax::parser::adv(p2), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::CheckLine, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_check_line(a0)); }))), [=](std::tuple<Array<crate::syntax::decls::CheckLine>, crate::syntax::parser::Ps> layout_items_1679) {
        return ({
            auto [lines, q] = layout_items_1679;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::CheckDecl{.name = name, .lines = lines, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q}));
        });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::decls::CheckDecl{.name = name, .lines = Array<crate::syntax::decls::CheckLine>{}, .span = start}, crate::syntax::parser::error_here(p2, Text::lit("a `check` block's lines stand in an indented block"))});
}


/// `Start ParseCheckDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps>> start_parse_check_decl(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseCheckDecl>(p0);
}


/// ParseCheckLine: unbounded fn Ps -> ((CheckLine, Ps))
std::tuple<crate::syntax::decls::CheckLine, crate::syntax::parser::Ps> parse_check_line(const crate::syntax::parser::Ps& p_) {
    auto start = crate::syntax::parser::here(p_);
    auto [expr, p1] = crate::syntax::parser::expr::parse_rhs_expr(p_);
    auto [pattern_opt, q] = crate::syntax::parser::at_op(p1, Text::lit("=>"))
        ? optional_pattern_top(crate::syntax::parser::adv(p1))
        : std::tuple{std::optional<crate::syntax::Pattern_>{}, p1};
    return std::tuple{crate::syntax::decls::CheckLine{.expr = expr, .pattern = pattern_opt, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::CheckLine, crate::syntax::parser::Ps>> ParseCheckLine::cycle() const {
    const auto& p_ = this->p_;
    auto start = crate::syntax::parser::here(p_);
    auto p__1 = p_;
    return call_then(crate::syntax::parser::expr::start_parse_rhs_expr(p__1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_2042) {
        return ({
            auto [expr, p1] = parse_rhs_expr_2042;
            auto [pattern_opt, q] = crate::syntax::parser::at_op(p1, Text::lit("=>"))
                ? optional_pattern_top(crate::syntax::parser::adv(p1))
                : std::tuple{std::optional<crate::syntax::Pattern_>{}, p1};
            (prism_rtl::finished(std::tuple{crate::syntax::decls::CheckLine{.expr = expr, .pattern = pattern_opt, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseCheckLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::CheckLine, crate::syntax::parser::Ps>> start_parse_check_line(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseCheckLine>(p_);
}


/// OptionalPatternTop: unbounded fn Ps -> ((?Pattern, Ps))
std::tuple<std::optional<crate::syntax::Pattern_>, crate::syntax::parser::Ps> optional_pattern_top(const crate::syntax::parser::Ps& p_) {
    auto [pat, q] = crate::syntax::parser::types::parse_pattern(p_, true);
    return std::tuple{std::optional(pat), q};
}


prism_rtl::Turn<std::tuple<std::optional<crate::syntax::Pattern_>, crate::syntax::parser::Ps>> OptionalPatternTop::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(crate::syntax::parser::types::start_parse_pattern(p__1, true), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_2327) {
        return ({
            auto [pat, q] = parse_pattern_2327;
            (prism_rtl::finished(std::tuple{std::optional(pat), q}));
        });
    });
}


/// `Start OptionalPatternTop, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::Pattern_>, crate::syntax::parser::Ps>> start_optional_pattern_top(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<OptionalPatternTop>(p_);
}


/// ParseTestDecl: unbounded fn Ps -> ((TestDecl, Ps))
std::tuple<crate::syntax::decls::TestDecl, crate::syntax::parser::Ps> parse_test_decl(const crate::syntax::parser::Ps& p0) {
    auto start = crate::syntax::parser::here(p0);
    auto [name, p1] = crate::syntax::parser::parse_ident(crate::syntax::parser::adv(p0));
    auto fallback = crate::syntax::decls::TestDecl{.name = name, .blueprint = crate::syntax::parser::decls::no_expr(), .seed = std::optional<Nat>{}, .steps = Array<crate::syntax::decls::TestStep>{}, .span = start};
    return !crate::syntax::parser::at_comma(p1)
        ? std::tuple{fallback, crate::syntax::parser::error_here(p1, Text::lit("a test names its blueprint: `test name, @blueprint:`"))}
        : ({
        auto [blueprint, p2] = crate::syntax::parser::expr::parse_arg_expr(crate::syntax::parser::adv(p1));
        auto [seed_opt, p3] = crate::syntax::parser::at_comma(p2)
            ? parse_seed(crate::syntax::parser::adv(p2))
            : std::tuple{std::optional<Nat>{}, p2};
        auto p4 = crate::syntax::parser::expect_colon(p3);
        crate::syntax::parser::at_open_l(p4)
        ? ({
        auto saved = p4.step_mode;
        auto [steps, p5] = crate::syntax::parser::layout_items(crate::syntax::parser::adv(p4), ({
            auto saved_1 = saved;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::TestStep, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
            return ({
                auto saved_1_2 = saved_1;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    (prism_rtl::more(prism_rtl::rc(StepIn(s, saved_1_2))));
                });
            }));
            });
        }));
        }));
        auto q = crate::syntax::parser::with_step_mode(p5, saved);
        std::tuple{crate::syntax::decls::TestDecl{.name = name, .blueprint = blueprint, .seed = seed_opt, .steps = steps, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
    })
        : std::tuple{fallback, crate::syntax::parser::error_here(p4, Text::lit("a test's steps stand in an indented block"))};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::TestDecl, crate::syntax::parser::Ps>> ParseTestDecl::cycle() const {
    const auto& p0 = this->p0;
    auto start = crate::syntax::parser::here(p0);
    auto [name, p1] = crate::syntax::parser::parse_ident(crate::syntax::parser::adv(p0));
    auto fallback = crate::syntax::decls::TestDecl{.name = name, .blueprint = crate::syntax::parser::decls::no_expr(), .seed = std::optional<Nat>{}, .steps = Array<crate::syntax::decls::TestStep>{}, .span = start};
    return !crate::syntax::parser::at_comma(p1)
        ? prism_rtl::finished(std::tuple{fallback, crate::syntax::parser::error_here(p1, Text::lit("a test names its blueprint: `test name, @blueprint:`"))})
        : call_then(crate::syntax::parser::expr::start_parse_arg_expr(crate::syntax::parser::adv(p1)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_arg_expr_2820) {
        return ({
            auto [blueprint, p2] = parse_arg_expr_2820;
            auto [seed_opt, p3] = crate::syntax::parser::at_comma(p2)
                ? parse_seed(crate::syntax::parser::adv(p2))
                : std::tuple{std::optional<Nat>{}, p2};
            auto p4 = crate::syntax::parser::expect_colon(p3);
            (crate::syntax::parser::at_open_l(p4)
            ? ({
            auto saved = p4.step_mode;
            call_then(crate::syntax::parser::start_layout_items(crate::syntax::parser::adv(p4), ({
            auto saved_1 = saved;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::TestStep, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
            return ({
                auto saved_1_2 = saved_1;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    (prism_rtl::more(prism_rtl::rc(StepIn(s, saved_1_2))));
                });
            }));
            });
        }));
        })), [=](std::tuple<Array<crate::syntax::decls::TestStep>, crate::syntax::parser::Ps> layout_items_3045) {
            return ({
                auto [steps, p5] = layout_items_3045;
                auto q = crate::syntax::parser::with_step_mode(p5, saved);
                (prism_rtl::finished(std::tuple{crate::syntax::decls::TestDecl{.name = name, .blueprint = blueprint, .seed = seed_opt, .steps = steps, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q}));
            });
        });
        })
            : prism_rtl::finished(std::tuple{fallback, crate::syntax::parser::error_here(p4, Text::lit("a test's steps stand in an indented block"))}));
        });
    });
}


/// `Start ParseTestDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::TestDecl, crate::syntax::parser::Ps>> start_parse_test_decl(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseTestDecl>(p0);
}


/// ParseSeed: fn Ps -> ((?Nat, Ps))
std::tuple<std::optional<Nat>, crate::syntax::parser::Ps> parse_seed(const crate::syntax::parser::Ps& p_) {
    return !at_word(p_, Text::lit("seed"))
        ? std::tuple{std::optional<Nat>{}, crate::syntax::parser::error_here(p_, Text::lit("after the blueprint, a test takes only `seed n`"))}
        : ({
        auto p1 = crate::syntax::parser::adv(p_);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<Nat>, crate::syntax::parser::Ps>> _v;
        auto&& _m = crate::syntax::parser::kind(p1);
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m)) {
            auto&& m3527_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a0;
            auto&& text = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a1;
            if (m3527_0_0 == Text::lit("")) {
                _v.set(std::tuple{std::optional(parse_nat_text(text)), crate::syntax::parser::adv(p1)});
                goto _done;
            }
        }
        {
            _v.set(std::tuple{std::optional<Nat>{}, crate::syntax::parser::error_here(p1, Text::lit("`seed` takes a number"))});
            goto _done;
        }
    _done:
        _v.take();
    });
    });
}


/// StepIn: unbounded fn Ps, Bool -> ((TestStep, Ps))
std::tuple<crate::syntax::decls::TestStep, crate::syntax::parser::Ps> step_in(const crate::syntax::parser::Ps& p_, const bool& saved) {
    auto [s, q] = parse_step(crate::syntax::parser::with_step_mode(p_, true));
    return std::tuple{s, crate::syntax::parser::with_step_mode(q, saved)};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::TestStep, crate::syntax::parser::Ps>> StepIn::cycle() const {
    const auto& p_ = this->p_;
    const auto& saved = this->saved;
    auto [s, q] = parse_step(crate::syntax::parser::with_step_mode(p_, true));
    return prism_rtl::finished(std::tuple{s, crate::syntax::parser::with_step_mode(q, saved)});
}


/// `Start StepIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::TestStep, crate::syntax::parser::Ps>> start_step_in(crate::syntax::parser::Ps p_, bool saved) {
    return prism_rtl::make_rc<StepIn>(p_, saved);
}


/// ParseStep: unbounded fn Ps -> ((TestStep, Ps))
std::tuple<crate::syntax::decls::TestStep, crate::syntax::parser::Ps> parse_step(const crate::syntax::parser::Ps& p0) {
    auto start = crate::syntax::parser::here(p0);
    auto [withs, p1] = with_entries(p0);
    auto [action, p2] = step_action_of(p1, withs);
    return p2->bad
        ? std::tuple{crate::syntax::decls::TestStep{.withs = withs, .action = action, .checks = Array<crate::syntax::decls::TestCheck>{}, .span = start}, p2}
        : crate::syntax::parser::at_open_l(p2)
        ? ({
        auto [checks, q] = crate::syntax::parser::layout_items(crate::syntax::parser::adv(p2), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::TestCheck, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_test_check(a0)); })));
        std::tuple{crate::syntax::decls::TestStep{.withs = withs, .action = action, .checks = checks, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
    })
        : crate::syntax::parser::at_comma(p2)
        ? std::tuple{crate::syntax::decls::TestStep{.withs = withs, .action = action, .checks = Array<crate::syntax::decls::TestCheck>{}, .span = start}, crate::syntax::parser::error_at(p2, crate::syntax::parser::here(p2), Text::lit("a comma in a step begins a delivery; a value with commas in it is written in parentheses"))}
        : std::tuple{crate::syntax::decls::TestStep{.withs = withs, .action = action, .checks = Array<crate::syntax::decls::TestCheck>{}, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p2))}, p2};
}


/// WithEntries: unbounded fn Ps -> (([Entry], Ps))
std::tuple<Array<crate::syntax::decls::Entry>, crate::syntax::parser::Ps> with_entries(const crate::syntax::parser::Ps& p0) {
    std::tuple<Array<crate::syntax::decls::Entry>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::decls::Entry>{}, p0};
    Array<crate::syntax::decls::Entry> withs = Array<crate::syntax::decls::Entry>{};
    crate::syntax::parser::Ps p_ = p0;
    bool going = at_word(p0, Text::lit("with"));
    while (going && (!p_.bad)) {
        auto [e, q] = parse_entry(crate::syntax::parser::adv(p_));
        withs = crate::prelude::push(withs, e);
        if (crate::syntax::parser::at_comma(q)) {
            p_ = crate::syntax::parser::adv(q);
            going = at_word(p_, Text::lit("with"));
        } else  {
            p_ = q;
            going = false;
        }
    }
    this_ = std::tuple{withs, p_};
    return this_;
}


/// StepActionOf: unbounded fn Ps, [Entry] -> ((StepAction, Ps))
std::tuple<crate::syntax::decls::StepAction, crate::syntax::parser::Ps> step_action_of(const crate::syntax::parser::Ps& p_, const Array<crate::syntax::decls::Entry>& withs) {
    auto w = step_word(p_);
    {
        auto&& m5346_0 = w;
        if (m5346_0 == Text::lit("build")) {
            return std::tuple{crate::syntax::decls::StepAction(crate::syntax::decls::StepAction::SaBuild{}), crate::syntax::parser::adv(p_)};
        }
    }
    {
        auto&& m5346_1 = w;
        if (m5346_1 == Text::lit("tick")) {
            return std::tuple{crate::syntax::decls::StepAction(crate::syntax::decls::StepAction::SaTick{}), crate::syntax::parser::adv(p_)};
        }
    }
    {
        auto&& m5346_2 = w;
        if (m5346_2 == Text::lit("compute")) {
            auto p1 = crate::syntax::parser::adv(p_);
            return at_word(p1, Text::lit("until"))
                ? ({
                auto p2 = crate::syntax::parser::adv(p1);
                at_word(p2, Text::lit("idle"))
                ? std::tuple{crate::syntax::decls::StepAction(crate::syntax::decls::StepAction::SaCompute{true}), crate::syntax::parser::adv(p2)}
                : std::tuple{crate::syntax::decls::StepAction(crate::syntax::decls::StepAction::SaCompute{true}), crate::syntax::parser::error_here(p2, Text::lit("`compute until` is followed by `idle`"))};
            })
                : std::tuple{crate::syntax::decls::StepAction(crate::syntax::decls::StepAction::SaCompute{false}), p1};
        }
    }
    {
        auto&& m5346_3 = w;
        if (m5346_3 == Text::lit("push")) {
            auto [e, q] = parse_entry(crate::syntax::parser::adv(p_));
            return std::tuple{crate::syntax::decls::StepAction(crate::syntax::decls::StepAction::SaPush{e}), q};
        }
    }
    {
        if (is_delivery_word(w)) {
            return deliveries(p_);
        }
    }
    {
        if ((len(withs) > Nat(0u)) && (crate::syntax::parser::at_open_l(p_) || crate::syntax::parser::at_stmt_boundary(p_))) {
            return std::tuple{crate::syntax::decls::StepAction(crate::syntax::decls::StepAction::SaWithOnly{}), p_};
        }
    }
    {
        return std::tuple{crate::syntax::decls::StepAction(crate::syntax::decls::StepAction::SaBuild{}), crate::syntax::parser::error_here(p_, Text::lit("expected a step: `build`, `tick`, `compute`, `send`, `click`, `answer`, `with` or `push`"))};
    }
}


/// Deliveries: unbounded fn Ps -> ((StepAction, Ps))
std::tuple<crate::syntax::decls::StepAction, crate::syntax::parser::Ps> deliveries(const crate::syntax::parser::Ps& p0) {
    std::tuple<crate::syntax::decls::StepAction, crate::syntax::parser::Ps> this_ = std::tuple{crate::syntax::decls::StepAction(crate::syntax::decls::StepAction::SaBuild{}), p0};
    auto [first_, p1] = parse_delivery(p0);
    Array<crate::syntax::decls::Delivery> ds = Array(std::vector{first_});
    crate::syntax::parser::Ps p_ = p1;
    while (crate::syntax::parser::at_comma(p_) && (!p_.bad)) {
        if (is_delivery_name(crate::syntax::parser::kind_at(p_, Nat(1u)))) {
            auto [d, q] = parse_delivery(crate::syntax::parser::adv(p_));
            ds = crate::prelude::push(ds, d);
            p_ = q;
        } else  {
            p_ = crate::syntax::parser::error_at(p_, crate::syntax::parser::here(p_), Text::lit("a comma in a step begins a delivery (`click p, click q`); a value with commas in it is written in parentheses: `send p, (Min a, b)`"));
        }
    }
    this_ = std::tuple{crate::syntax::decls::StepAction(crate::syntax::decls::StepAction::SaDeliver{ds}), p_};
    return this_;
}


/// IsDeliveryName: fn TokKind -> Bool
bool is_delivery_name(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(tok_kind0)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(tok_kind0).a0;
        return (len(n->path_) == Nat(1u)) && is_delivery_word(or_(index(n->path_, Nat(0u)), Text::lit("")));
    }
    {
        return false;
    }
}


/// ParseEntry: unbounded fn Ps -> ((Entry, Ps))
std::tuple<crate::syntax::decls::Entry, crate::syntax::parser::Ps> parse_entry(const crate::syntax::parser::Ps& p_) {
    auto start = crate::syntax::parser::here(p_);
    auto [element_, p1] = crate::syntax::parser::expr::parse_arg_expr(p_);
    auto [value, q] = crate::syntax::parser::expr::parse_arg_expr(crate::syntax::parser::expect_op(p1, Text::lit("=")));
    return std::tuple{crate::syntax::decls::Entry{.element = element_, .value = value, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
}


/// ParseDelivery: unbounded fn Ps -> ((Delivery, Ps))
std::tuple<crate::syntax::decls::Delivery, crate::syntax::parser::Ps> parse_delivery(const crate::syntax::parser::Ps& p_) {
    auto start = crate::syntax::parser::here(p_);
    auto word = step_word(p_);
    auto [target, p1] = parse_target(crate::syntax::parser::adv(p_));
    auto [kind, q] = word == Text::lit("send")
        ? send_value(p1)
        : word == Text::lit("click")
        ? std::tuple{crate::syntax::decls::DeliveryKind(crate::syntax::decls::DeliveryKind::DkClick{}), p1}
        : std::tuple{crate::syntax::decls::DeliveryKind(crate::syntax::decls::DeliveryKind::DkAnswer{}), p1};
    return std::tuple{crate::syntax::decls::Delivery{.kind = kind, .target = target, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
}


/// SendValue: unbounded fn Ps -> ((DeliveryKind, Ps))
std::tuple<crate::syntax::decls::DeliveryKind, crate::syntax::parser::Ps> send_value(const crate::syntax::parser::Ps& p_) {
    return crate::syntax::parser::at_comma(p_)
        ? ({
        auto [v_, q] = crate::syntax::parser::expr::parse_arg_expr(crate::syntax::parser::adv(p_));
        std::tuple{crate::syntax::decls::DeliveryKind(crate::syntax::decls::DeliveryKind::DkSend{v_}), q};
    })
        : std::tuple{crate::syntax::decls::DeliveryKind(crate::syntax::decls::DeliveryKind::DkClick{}), crate::syntax::parser::error_here(p_, Text::lit("`send` takes a target and a value: `send p, v`"))};
}


/// ParseTarget: unbounded fn Ps -> ((Target, Ps))
std::tuple<crate::syntax::decls::Target, crate::syntax::parser::Ps> parse_target(const crate::syntax::parser::Ps& p_) {
    auto element_ = at_word(p_, Text::lit("element")) && is_path_kind(crate::syntax::parser::kind_at(p_, Nat(1u)));
    return at_word(p_, Text::lit("at")) || element_
        ? ({
        auto p1 = crate::syntax::parser::adv(p_);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::syntax::decls::Target, crate::syntax::parser::Ps>> _v;
        auto&& _m = crate::syntax::parser::kind(p1);
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KPath>(_m)) {
            auto&& segs = prism_rtl::as<crate::syntax::lexer::TokKind::KPath>(_m).a0;
            _v.set(({
                auto span = crate::syntax::parser::here(p1);
                auto [segments, q] = run_to_end(fold_job(segs, std::tuple{Array<crate::syntax::decls::PathSeg>{}, crate::syntax::parser::adv(p1)}, ({
                    auto span_1 = span;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::decls::PathSeg>, crate::syntax::parser::Ps>>(std::tuple<std::tuple<Array<crate::syntax::decls::PathSeg>, crate::syntax::parser::Ps>, crate::syntax::lexer::PathSegTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::decls::PathSeg>, crate::syntax::parser::Ps>, crate::syntax::lexer::PathSegTok> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto span_1_2 = span_1;
                        entered(once_job([=]() {
                        return ({
                            auto [acc, pp] = p0;
                            auto seg = p1;
                            (prism_rtl::finished(path_seg_of(acc, pp, seg, span_1_2)));
                        });
                    }));
                    });
                }));
                })));
                auto path_ = crate::syntax::decls::TestPath{.segments = segments, .span = span};
                element_
                ? std::tuple{crate::syntax::decls::Target(crate::syntax::decls::Target::TgElement{path_}), q}
                : std::tuple{crate::syntax::decls::Target(crate::syntax::decls::Target::TgPath{path_}), q};
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{crate::syntax::decls::Target(crate::syntax::decls::Target::TgPattern{crate::syntax::parser::decls::no_pattern()}), crate::syntax::parser::error_here(p1, Text::lit("`at` takes a path, `1/#0/0`"))});
            goto _done;
        }
    _done:
        _v.take();
    });
    })
        : ({
        auto [pat, q] = crate::syntax::parser::types::parse_pattern(p_, false);
        std::tuple{crate::syntax::decls::Target(crate::syntax::decls::Target::TgPattern{pat}), q};
    });
}


/// IsPathKind: fn TokKind -> Bool
bool is_path_kind(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KPath>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// PathSegOf: unbounded fn [PathSeg], Ps, PathSegTok, Range -> (([PathSeg], Ps))
std::tuple<Array<crate::syntax::decls::PathSeg>, crate::syntax::parser::Ps> path_seg_of(const Array<crate::syntax::decls::PathSeg>& acc, const crate::syntax::parser::Ps& p_, const crate::syntax::lexer::PathSegTok& path_seg_tok2, const crate::syntax::Range& range3) {
    auto&& _m = std::tuple{path_seg_tok2, range3};
    if (prism_rtl::is<crate::syntax::lexer::PathSegTok::PstNum>(std::get<0>(_m))) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::PathSegTok::PstNum>(std::get<0>(_m)).a0;
        return std::tuple{crate::prelude::push(acc, crate::syntax::decls::PathSeg(crate::syntax::decls::PathSeg::PsNum{n})), p_};
    }
    if (prism_rtl::is<crate::syntax::lexer::PathSegTok::PstGen>(std::get<0>(_m))) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::PathSegTok::PstGen>(std::get<0>(_m)).a0;
        return std::tuple{crate::prelude::push(acc, crate::syntax::decls::PathSeg(crate::syntax::decls::PathSeg::PsGen{n})), p_};
    }
    if (prism_rtl::is<crate::syntax::lexer::PathSegTok::PstKey>(std::get<0>(_m))) {
        auto&& toks = prism_rtl::as<crate::syntax::lexer::PathSegTok::PstKey>(std::get<0>(_m)).a0;
        auto&& span = std::get<1>(_m);
        auto [e, q] = crate::syntax::parser::expr::parse_nested(p_, toks, span);
        return std::tuple{crate::prelude::push(acc, crate::syntax::decls::PathSeg(crate::syntax::decls::PathSeg::PsKey{e})), q};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ParseTestCheck: unbounded fn Ps -> ((TestCheck, Ps))
std::tuple<crate::syntax::decls::TestCheck, crate::syntax::parser::Ps> parse_test_check(const crate::syntax::parser::Ps& p0) {
    auto start = crate::syntax::parser::here(p0);
    auto p_ = crate::syntax::parser::expect_op(p0, Text::lit("=>"));
    auto word = step_word(p_);
    return p_->bad
        ? std::tuple{crate::syntax::decls::TestCheck{.kind = crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), .span = start}, p_}
        : word == Text::lit("")
        ? std::tuple{crate::syntax::decls::TestCheck{.kind = crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), .span = start}, crate::syntax::parser::error_here(p_, Text::lit("expected a check after `=>`: `expect`, `returns`, `fired`, `quiet`, ..."))}
        : ({
        auto [kind, q] = check_kind_of(crate::syntax::parser::adv(p_), word);
        std::tuple{crate::syntax::decls::TestCheck{.kind = kind, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::TestCheck, crate::syntax::parser::Ps>> ParseTestCheck::cycle() const {
    const auto& p0 = this->p0;
    auto start = crate::syntax::parser::here(p0);
    auto p_ = crate::syntax::parser::expect_op(p0, Text::lit("=>"));
    auto word = step_word(p_);
    return p_->bad
        ? prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheck{.kind = crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), .span = start}, p_})
        : word == Text::lit("")
        ? prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheck{.kind = crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), .span = start}, crate::syntax::parser::error_here(p_, Text::lit("expected a check after `=>`: `expect`, `returns`, `fired`, `quiet`, ..."))})
        : call_then(start_check_kind_of(crate::syntax::parser::adv(p_), word), [=](std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps> check_kind_of_9526) {
        return ({
            auto [kind, q] = check_kind_of_9526;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheck{.kind = kind, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseTestCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::TestCheck, crate::syntax::parser::Ps>> start_parse_test_check(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseTestCheck>(p0);
}


/// CheckKindOf: unbounded fn Ps, Text -> ((TestCheckKind, Ps))
std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps> check_kind_of(const crate::syntax::parser::Ps& p_, const Text& word) {
    {
        auto&& m9701_0 = word;
        if (m9701_0 == Text::lit("expect")) {
            return one_pattern(p_, ({
                auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkExpect{a0}); });
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
                return ({
                    auto f_1 = f;
                    once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                });
            })));
            }));
        }
    }
    {
        auto&& m9701_1 = word;
        if (m9701_1 == Text::lit("expect_none")) {
            return one_pattern(p_, ({
                auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkExpectNone{a0}); });
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
                return ({
                    auto f_1 = f;
                    once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                });
            })));
            }));
        }
    }
    {
        auto&& m9701_2 = word;
        if (m9701_2 == Text::lit("expect_top")) {
            return one_pattern(p_, ({
                auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkExpectTop{a0}); });
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
                return ({
                    auto f_1 = f;
                    once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                });
            })));
            }));
        }
    }
    {
        auto&& m9701_3 = word;
        if (m9701_3 == Text::lit("expect_top_none")) {
            return one_pattern(p_, ({
                auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkExpectTopNone{a0}); });
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
                return ({
                    auto f_1 = f;
                    once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                });
            })));
            }));
        }
    }
    {
        auto&& m9701_4 = word;
        if (m9701_4 == Text::lit("unrequested")) {
            return one_pattern(p_, ({
                auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkUnrequested{a0}); });
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
                return ({
                    auto f_1 = f;
                    once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                });
            })));
            }));
        }
    }
    {
        auto&& m9701_5 = word;
        if (m9701_5 == Text::lit("returns")) {
            return one_pattern(p_, ({
                auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkReturns{a0}); });
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
                return ({
                    auto f_1 = f;
                    once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                });
            })));
            }));
        }
    }
    {
        auto&& m9701_6 = word;
        if (m9701_6 == Text::lit("fired")) {
            return one_pattern(p_, ({
                auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkFired{a0}); });
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
                return ({
                    auto f_1 = f;
                    once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                });
            })));
            }));
        }
    }
    {
        auto&& m9701_7 = word;
        if (m9701_7 == Text::lit("expect_count")) {
            auto [pat, p1] = crate::syntax::parser::types::parse_pattern(p_, false);
            return !crate::syntax::parser::at_comma(p1)
                ? std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), crate::syntax::parser::error_here(p1, Text::lit("`expect_count` takes a pattern and a count: `expect_count p, n`"))}
                : ({
                auto p2 = crate::syntax::parser::adv(p1);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps>> _v;
                auto&& _m = crate::syntax::parser::kind(p2);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m)) {
                    auto&& m10260_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a0;
                    auto&& text = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a1;
                    if (m10260_0_0 == Text::lit("")) {
                        _v.set(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkExpectCount{pat, parse_nat_text(text)}), crate::syntax::parser::adv(p2)});
                        goto _done;
                    }
                }
                {
                    _v.set(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), crate::syntax::parser::error_here(p2, Text::lit("`expect_count` takes a number"))});
                    goto _done;
                }
            _done:
                _v.take();
            });
            });
        }
    }
    {
        auto&& m9701_8 = word;
        if (m9701_8 == Text::lit("requested")) {
            auto [place, p1] = crate::syntax::parser::types::parse_pattern(p_, false);
            return !crate::syntax::parser::at_comma(p1)
                ? std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), crate::syntax::parser::error_here(p1, Text::lit("`requested` takes a place and a value: `requested p, v`"))}
                : ({
                auto [value, q] = crate::syntax::parser::types::parse_pattern(crate::syntax::parser::adv(p1), false);
                std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkRequested{place, value}), q};
            });
        }
    }
    {
        auto&& m9701_9 = word;
        if (m9701_9 == Text::lit("quiet")) {
            return std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), p_};
        }
    }
    {
        auto&& m9701_10 = word;
        if (m9701_10 == Text::lit("settles")) {
            return std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkSettles{}), p_};
        }
    }
    {
        auto&& m9701_11 = word;
        if (m9701_11 == Text::lit("aborted")) {
            return std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkAborted{}), p_};
        }
    }
    {
        auto&& m9701_12 = word;
        if (m9701_12 == Text::lit("snapshot")) {
            auto&& _m = crate::syntax::parser::kind(p_);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m)) {
                auto&& m10860_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a0;
                auto&& segs = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a1;
                if (m10860_0_0 == Text::lit("")) {
                    if (all_plain(segs)) {
                        return std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkSnapshot{concat(each(segs, plain_of))}), crate::syntax::parser::adv(p_)};
                    }
                }
            }
            {
                return std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), crate::syntax::parser::error_here(p_, Text::lit("`snapshot` takes a file name, a text literal"))};
            }
        }
    }
    {
        return std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), crate::syntax::parser::error_at(p_, crate::syntax::parser::prev(p_), prism_rtl::cat("`", word, "` is not a check: the checks are expect, expect_none, expect_count, expect_top, expect_top_none, requested, unrequested, returns, fired, quiet, settles, aborted, snapshot"))};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps>> CheckKindOf::cycle() const {
    const auto& p_ = this->p_;
    const auto& word = this->word;
    return ({
        ({
        auto&& m9701_0 = word;
        (m9701_0 == Text::lit("expect"));
    }) ? ({
        auto&& m9701_0 = word;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_, ({
        auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkExpect{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))));
    })
        : ({
        auto&& m9701_1 = word;
        (m9701_1 == Text::lit("expect_none"));
    }) ? ({
        auto&& m9701_1 = word;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_, ({
        auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkExpectNone{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))));
    })
        : ({
        auto&& m9701_2 = word;
        (m9701_2 == Text::lit("expect_top"));
    }) ? ({
        auto&& m9701_2 = word;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_, ({
        auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkExpectTop{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))));
    })
        : ({
        auto&& m9701_3 = word;
        (m9701_3 == Text::lit("expect_top_none"));
    }) ? ({
        auto&& m9701_3 = word;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_, ({
        auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkExpectTopNone{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))));
    })
        : ({
        auto&& m9701_4 = word;
        (m9701_4 == Text::lit("unrequested"));
    }) ? ({
        auto&& m9701_4 = word;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_, ({
        auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkUnrequested{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))));
    })
        : ({
        auto&& m9701_5 = word;
        (m9701_5 == Text::lit("returns"));
    }) ? ({
        auto&& m9701_5 = word;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_, ({
        auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkReturns{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))));
    })
        : ({
        auto&& m9701_6 = word;
        (m9701_6 == Text::lit("fired"));
    }) ? ({
        auto&& m9701_6 = word;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_, ({
        auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkFired{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))));
    })
        : ({
        auto&& m9701_7 = word;
        (m9701_7 == Text::lit("expect_count"));
    }) ? ({
        auto&& m9701_7 = word;
        ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::types::start_parse_pattern(p__1, false), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_10060) {
        return ({
            auto [pat, p1] = parse_pattern_10060;
            (!crate::syntax::parser::at_comma(p1)
            ? prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), crate::syntax::parser::error_here(p1, Text::lit("`expect_count` takes a pattern and a count: `expect_count p, n`"))})
            : ({
            auto p2 = crate::syntax::parser::adv(p1);
            ({
            auto&& _m = crate::syntax::parser::kind(p2);
            prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m) && ({
            auto&& m10260_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a0;
            auto&& text = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a1;
            (m10260_0_0 == Text::lit(""));
        }) ? ({
            auto&& m10260_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a0;
            auto&& text = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a1;
            prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkExpectCount{pat, parse_nat_text(text)}), crate::syntax::parser::adv(p2)});
        })
            : prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), crate::syntax::parser::error_here(p2, Text::lit("`expect_count` takes a number"))});
        });
        }));
        });
    });
    });
    })
        : ({
        auto&& m9701_8 = word;
        (m9701_8 == Text::lit("requested"));
    }) ? ({
        auto&& m9701_8 = word;
        ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::types::start_parse_pattern(p__1, false), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_10494) {
        return ({
            auto [place, p1] = parse_pattern_10494;
            (!crate::syntax::parser::at_comma(p1)
            ? prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), crate::syntax::parser::error_here(p1, Text::lit("`requested` takes a place and a value: `requested p, v`"))})
            : call_then(crate::syntax::parser::types::start_parse_pattern(crate::syntax::parser::adv(p1), false), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_10677) {
            return ({
                auto [value, q] = parse_pattern_10677;
                (prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkRequested{place, value}), q}));
            });
        }));
        });
    });
    });
    })
        : ({
        auto&& m9701_9 = word;
        (m9701_9 == Text::lit("quiet"));
    }) ? ({
        auto&& m9701_9 = word;
        prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), p_});
    })
        : ({
        auto&& m9701_10 = word;
        (m9701_10 == Text::lit("settles"));
    }) ? ({
        auto&& m9701_10 = word;
        prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkSettles{}), p_});
    })
        : ({
        auto&& m9701_11 = word;
        (m9701_11 == Text::lit("aborted"));
    }) ? ({
        auto&& m9701_11 = word;
        prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkAborted{}), p_});
    })
        : ({
        auto&& m9701_12 = word;
        (m9701_12 == Text::lit("snapshot"));
    }) ? ({
        auto&& m9701_12 = word;
        ({
        auto&& _m = crate::syntax::parser::kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m) && ({
        auto&& m10860_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a0;
        auto&& segs = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a1;
        (m10860_0_0 == Text::lit("")) && all_plain(segs);
    }) ? ({
        auto&& m10860_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a0;
        auto&& segs = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a1;
        prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkSnapshot{concat(each(segs, plain_of))}), crate::syntax::parser::adv(p_)});
    })
        : prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), crate::syntax::parser::error_here(p_, Text::lit("`snapshot` takes a file name, a text literal"))});
    });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::decls::TestCheckKind(crate::syntax::decls::TestCheckKind::CkQuiet{}), crate::syntax::parser::error_at(p_, crate::syntax::parser::prev(p_), prism_rtl::cat("`", word, "` is not a check: the checks are expect, expect_none, expect_count, expect_top, expect_top_none, requested, unrequested, returns, fired, quiet, settles, aborted, snapshot"))});
    });
}


/// `Start CheckKindOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps>> start_check_kind_of(crate::syntax::parser::Ps p_, Text word) {
    return prism_rtl::make_rc<CheckKindOf>(p_, word);
}


/// OnePattern: unbounded fn Ps, (fn Pattern -> TestCheckKind) -> ((TestCheckKind, Ps))
std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps> one_pattern(const crate::syntax::parser::Ps& p_, const prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>& make_fn) {
    auto [pat, q] = crate::syntax::parser::types::parse_pattern(p_, false);
    return std::tuple{run_to_end(make_fn(pat)), q};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps>> OnePattern::cycle() const {
    const auto& p_ = this->p_;
    const auto& make_fn = this->make_fn;
    auto make_fn_1 = make_fn;
    auto p__2 = p_;
    return call_then(crate::syntax::parser::types::start_parse_pattern(p__2, false), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_11423) {
        return ({
            auto [pat, q] = parse_pattern_11423;
            call_value(make_fn_1(pat), [=](crate::syntax::decls::TestCheckKind make_11451) { return prism_rtl::finished(std::tuple{make_11451, q}); });
        });
    });
}


/// `Start OnePattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps>> start_one_pattern(crate::syntax::parser::Ps p_, prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)> make_fn) {
    return prism_rtl::make_rc<OnePattern>(p_, make_fn);
}


/// AllPlain: fn [TextSegTok] -> Bool
bool all_plain(const Array<crate::syntax::lexer::TextSegTok>& segs) {
    return fold(segs, true, [&](const bool& ok, const crate::syntax::lexer::TextSegTok& s) { return ok && is_plain_seg(s); });
}


/// IsPlainSeg: fn TextSegTok -> Bool
bool is_plain_seg(const crate::syntax::lexer::TextSegTok& text_seg_tok0) {
    if (prism_rtl::is<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok0)) {
        return true;
    }
    {
        return false;
    }
}


/// PlainOf: fn TextSegTok -> Text
Text plain_of(const crate::syntax::lexer::TextSegTok& text_seg_tok0) {
    if (prism_rtl::is<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok0)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok0).a0;
        return s;
    }
    {
        return Text::lit("");
    }
}


/// ParseNatText: fn Text -> Nat
Nat parse_nat_text(const Text& text0) {
    auto text = concat(split(text0, Text::lit("_")));
    return crate::syntax::lexer::chars::has_prefix(text, Text::lit("0x"))
        ? or_(crate::syntax::lexer::chars::parse_hex(crate::syntax::lexer::chars::drop_prefix(text, Text::lit("0x"))), Nat(0u))
        : crate::syntax::lexer::chars::has_prefix(text, Text::lit("0o"))
        ? or_(parse_radix(crate::syntax::lexer::chars::drop_prefix(text, Text::lit("0o")), Nat(8u)), Nat(0u))
        : crate::syntax::lexer::chars::has_prefix(text, Text::lit("0b"))
        ? or_(parse_radix(crate::syntax::lexer::chars::drop_prefix(text, Text::lit("0b")), Nat(2u)), Nat(0u))
        : or_(parse_nat_opt(text), Nat(0u));
}


/// ?ParseRadix: fn Text, Nat -> ?Nat
std::optional<Nat> parse_radix(const Text& t, const Nat& radix) {
    return ({
        __label__ g12266;
        prism_rtl::Slot<std::optional<Nat>> g12266_v;
        {
            if (!((t != Text::lit("")) && crate::syntax::lexer::chars::all_chars(t, ({
                auto radix_1 = radix;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
                return ({
                    auto radix_1_2 = radix_1;
                    once_job([=]() {
                    return ({
                        auto c = p0;
                        (prism_rtl::finished(crate::syntax::lexer::chars::is_digit(c) && (crate::syntax::lexer::chars::hex_value(c) < radix_1_2)));
                    });
                });
                });
            })));
            })))) {
                { g12266_v.set(std::nullopt); goto g12266; }
            }
            g12266_v.set(std::optional(crate::syntax::lexer::chars::fold_chars(t, Nat(0u), ({
                auto radix_1 = radix;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=](std::tuple<Nat, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto radix_1_2 = radix_1;
                    once_job([=]() {
                    return ({
                        auto n = p0;
                        auto c = p1;
                        (prism_rtl::finished((n * radix_1_2) + crate::syntax::lexer::chars::hex_value(c)));
                    });
                });
                });
            })));
            }))));
        }
    g12266:
        g12266_v.take();
    });
}

}  // namespace crate::syntax::parser::test_language
