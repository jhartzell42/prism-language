// The module `Syntax.Parser.TestLanguage`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace syntax::parser::test_language {

struct ParseCheckDecl;

struct ParseCheckLine;

struct OptionalPatternTop;

struct ParseTestDecl;

struct StepIn;

struct ParseTestCheck;

struct CheckKindOf;

struct OnePattern;

}  // namespace syntax::parser::test_language


}  // namespace crate
