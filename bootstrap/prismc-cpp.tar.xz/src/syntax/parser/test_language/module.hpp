// The module `Syntax.Parser.TestLanguage`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/parser/test_language/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::parser::test_language {

Array<Text> delivery_words();

bool is_delivery_word(const Text& w_p0);

Text step_word(const crate::syntax::parser::Ps& p_p0);

bool at_word(const crate::syntax::parser::Ps& p_p0, const Text& w_p1);

std::tuple<crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps> parse_check_decl(const crate::syntax::parser::Ps& p0_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps>> start_parse_check_decl(crate::syntax::parser::Ps p0_p0);

std::tuple<crate::syntax::decls::CheckLine, crate::syntax::parser::Ps> parse_check_line(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::CheckLine, crate::syntax::parser::Ps>> start_parse_check_line(crate::syntax::parser::Ps p_p0);

std::tuple<std::optional<crate::syntax::Pattern_>, crate::syntax::parser::Ps> optional_pattern_top(const crate::syntax::parser::Ps& p_p0);

prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::Pattern_>, crate::syntax::parser::Ps>> start_optional_pattern_top(crate::syntax::parser::Ps p_p0);

std::tuple<crate::syntax::decls::TestDecl, crate::syntax::parser::Ps> parse_test_decl(const crate::syntax::parser::Ps& p0_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::TestDecl, crate::syntax::parser::Ps>> start_parse_test_decl(crate::syntax::parser::Ps p0_p0);

std::tuple<std::optional<Nat>, crate::syntax::parser::Ps> parse_seed(const crate::syntax::parser::Ps& p_p0);

std::tuple<crate::syntax::decls::TestStep, crate::syntax::parser::Ps> step_in(const crate::syntax::parser::Ps& p_p0, const bool& saved_p1);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::TestStep, crate::syntax::parser::Ps>> start_step_in(crate::syntax::parser::Ps p_p0, bool saved_p1);

std::tuple<crate::syntax::decls::TestStep, crate::syntax::parser::Ps> parse_step(const crate::syntax::parser::Ps& p0_p0);

std::tuple<Array<crate::syntax::decls::Entry>, crate::syntax::parser::Ps> with_entries(const crate::syntax::parser::Ps& p0_p0);

std::tuple<crate::syntax::decls::StepAction, crate::syntax::parser::Ps> step_action_of(const crate::syntax::parser::Ps& p_p0, const Array<crate::syntax::decls::Entry>& withs_p1);

std::tuple<crate::syntax::decls::StepAction, crate::syntax::parser::Ps> deliveries(const crate::syntax::parser::Ps& p0_p0);

bool is_delivery_name(const crate::syntax::lexer::TokKind& tok_kind0);

std::tuple<crate::syntax::decls::Entry, crate::syntax::parser::Ps> parse_entry(const crate::syntax::parser::Ps& p_p0);

std::tuple<crate::syntax::decls::Delivery, crate::syntax::parser::Ps> parse_delivery(const crate::syntax::parser::Ps& p_p0);

std::tuple<crate::syntax::decls::DeliveryKind, crate::syntax::parser::Ps> send_value(const crate::syntax::parser::Ps& p_p0);

std::tuple<crate::syntax::decls::Target, crate::syntax::parser::Ps> parse_target(const crate::syntax::parser::Ps& p_p0);

bool is_path_kind(const crate::syntax::lexer::TokKind& tok_kind0);

std::tuple<Array<crate::syntax::decls::PathSeg>, crate::syntax::parser::Ps> path_seg_of(const Array<crate::syntax::decls::PathSeg>& acc_p0, const crate::syntax::parser::Ps& p_p1, const crate::syntax::lexer::PathSegTok& path_seg_tok2, const crate::syntax::Range& range3);

std::tuple<crate::syntax::decls::TestCheck, crate::syntax::parser::Ps> parse_test_check(const crate::syntax::parser::Ps& p0_p0);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::TestCheck, crate::syntax::parser::Ps>> start_parse_test_check(crate::syntax::parser::Ps p0_p0);

std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps> check_kind_of(const crate::syntax::parser::Ps& p_p0, const Text& word_p1);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps>> start_check_kind_of(crate::syntax::parser::Ps p_p0, Text word_p1);

std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps> one_pattern(const crate::syntax::parser::Ps& p_p0, const prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)>& make_f1);

prism_rtl::JobRef<std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps>> start_one_pattern(crate::syntax::parser::Ps p_p0, prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)> make_f1);

bool all_plain(const Array<crate::syntax::lexer::TextSegTok>& segs_p0);

bool is_plain_seg(const crate::syntax::lexer::TextSegTok& text_seg_tok0);

Text plain_of(const crate::syntax::lexer::TextSegTok& text_seg_tok0);

Nat parse_nat_text(const Text& text0_p0);

std::optional<Nat> parse_radix(const Text& t_p0, const Nat& radix_p1);

}  // namespace syntax::parser::test_language


namespace syntax::parser::test_language {

/// The step machine of `ParseCheckDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseCheckDecl: unbounded fn Ps -> ((CheckDecl, Ps))
struct ParseCheckDecl : prism_rtl::Job<std::tuple<crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    ParseCheckDecl(crate::syntax::parser::Ps p0_p0) : p0_p0(std::move(p0_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseCheckLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseCheckLine: unbounded fn Ps -> ((CheckLine, Ps))
struct ParseCheckLine : prism_rtl::Job<std::tuple<crate::syntax::decls::CheckLine, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    ParseCheckLine(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::CheckLine, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `OptionalPatternTop`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptionalPatternTop: unbounded fn Ps -> ((?Pattern, Ps))
struct OptionalPatternTop : prism_rtl::Job<std::tuple<std::optional<crate::syntax::Pattern_>, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    OptionalPatternTop(crate::syntax::parser::Ps p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<std::tuple<std::optional<crate::syntax::Pattern_>, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseTestDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTestDecl: unbounded fn Ps -> ((TestDecl, Ps))
struct ParseTestDecl : prism_rtl::Job<std::tuple<crate::syntax::decls::TestDecl, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    ParseTestDecl(crate::syntax::parser::Ps p0_p0) : p0_p0(std::move(p0_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::TestDecl, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `StepIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StepIn: unbounded fn Ps, Bool -> ((TestStep, Ps))
struct StepIn : prism_rtl::Job<std::tuple<crate::syntax::decls::TestStep, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    bool saved_p1;
    StepIn(crate::syntax::parser::Ps p_p0, bool saved_p1) : p_p0(std::move(p_p0)), saved_p1(std::move(saved_p1)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::TestStep, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `ParseTestCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTestCheck: unbounded fn Ps -> ((TestCheck, Ps))
struct ParseTestCheck : prism_rtl::Job<std::tuple<crate::syntax::decls::TestCheck, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p0_p0;
    ParseTestCheck(crate::syntax::parser::Ps p0_p0) : p0_p0(std::move(p0_p0)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::TestCheck, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `CheckKindOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckKindOf: unbounded fn Ps, Text -> ((TestCheckKind, Ps))
struct CheckKindOf : prism_rtl::Job<std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    Text word_p1;
    CheckKindOf(crate::syntax::parser::Ps p_p0, Text word_p1) : p_p0(std::move(p_p0)), word_p1(std::move(word_p1)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps>> cycle() const override;
};


/// The step machine of `OnePattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OnePattern: unbounded fn Ps, (fn Pattern -> TestCheckKind) -> ((TestCheckKind, Ps))
struct OnePattern : prism_rtl::Job<std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps>> {
    crate::syntax::parser::Ps p_p0;
    prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)> make_f1;
    OnePattern(crate::syntax::parser::Ps p_p0, prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::decls::TestCheckKind>(crate::syntax::Pattern_)> make_f1) : p_p0(std::move(p_p0)), make_f1(std::move(make_f1)) {}
    prism_rtl::Turn<std::tuple<crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps>> cycle() const override;
};


}  // namespace syntax::parser::test_language

}  // namespace crate
