// The module `Syntax.Parser`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace syntax::parser {

struct Pair;

struct Parsed;

struct Ps;

struct ParseFile;

struct ParseFragment;

struct NewPs;

struct Sub;

struct PairBrackets;

struct Recover;

struct Recovered;

struct ExpectStmtEnd;

template <class A>
struct Bracketed;

template <class A>
struct LayoutItems;

template <class A>
struct Commas;

}  // namespace syntax::parser

}  // namespace crate
