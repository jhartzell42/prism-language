// The module `Syntax.Parser`: its generic functions' and types' definitions, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/parser/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>

namespace crate {

using namespace prelude;

namespace syntax::parser {

/// Bracketed: fn Ps, (fn Ps -> ((a, Ps))) -> ((a, Ps))
template <class A>
std::tuple<A, Ps> bracketed(const Ps& p_p0, const prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)>& f_f1) {
    auto [v_p2, q_p3] = run_to_end(f_f1(with_step_mode(p_p0, false)));
    return std::tuple{v_p2, with_step_mode(q_p3, p_p0.step_mode)};
}


template <class A>
prism_rtl::Turn<std::tuple<A, Ps>> Bracketed<A>::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& f_f1 = this->f_f1;
    auto f_f1_1 = f_f1;
    auto p_p0_2 = p_p0;
    return call_value(f_f1_1(with_step_mode(p_p0_2, false)), [=](std::tuple<A, Ps> f_14243) {
        return ({
            auto [v_p2, q_p3] = f_14243;
            (prism_rtl::finished(std::tuple{v_p2, with_step_mode(q_p3, prism_rtl::deref(p_p0_2).step_mode)}));
        });
    });
}


/// `Start Bracketed, x`: what the function value is when passed to `@Run`.
template <class A>
prism_rtl::JobRef<std::tuple<A, Ps>> start_bracketed(Ps p_p0, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_f1) {
    return prism_rtl::make_rc<Bracketed<A>>(p_p0, f_f1);
}


/// LayoutItems: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
template <class A>
std::tuple<Array<A>, Ps> layout_items(const Ps& p0_p0, const prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)>& f_f1) {
    std::tuple<Array<A>, Ps> this_ = std::tuple{Array<A>{}, p0_p0};
    Array<A> items_p2 = Array<A>{};
    Ps p_p3 = p0_p0;
    bool going_p4 = true;
    while (std::move(going_p4)) {
        auto [item_p5, q_p6] = run_to_end(f_f1(p_p3));
        if (!q_p6->bad) {
            items_p2 = crate::prelude::push(items_p2, item_p5);
        }
        p_p3 = recovered(q_p6);
        {
            auto&& _m = kind(p_p3);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                p_p3 = adv(p_p3);
            } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                p_p3 = adv(p_p3);
                going_p4 = false;
            } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                going_p4 = false;
            } else {
                p_p3 = recover(complain(p_p3, Text::lit("expected the end of the line")));
            }
        }
    }
    this_ = std::tuple{items_p2, p_p3};
    return this_;
}


template <class A>
prism_rtl::Turn<std::tuple<Array<A>, Ps>> LayoutItems<A>::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    const auto& f_f1 = this->f_f1;
    std::tuple<Array<A>, Ps> this_ = std::tuple{Array<A>{}, p0_p0};
    Array<A> items_p2 = Array<A>{};
    Ps p_p3 = p0_p0;
    bool going_p4 = true;
    auto f_f1_1 = f_f1;
    return call_then(loop_job(std::tuple{std::move(this_), std::move(going_p4), std::move(items_p2), std::move(p_p3)}, ({
        auto f_f1_1_2 = f_f1_1;
        [=, f_f1_1_2 = std::move(f_f1_1_2)](std::tuple<std::tuple<Array<A>, Ps>, bool, Array<A>, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going_p4 = std::get<1>(_p0);
        auto items_p2 = std::get<2>(_p0);
        auto p_p3 = std::get<3>(_p0);
        return going_p4
            ? ({
            auto [item_p5, q_p6] = run_to_end(f_f1_1_2(p_p3));
            if (!q_p6->bad) {
                items_p2 = crate::prelude::push(items_p2, item_p5);
            }
            p_p3 = recovered(q_p6);
            {
                auto&& _m = kind(p_p3);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                    p_p3 = adv(p_p3);
                } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                    p_p3 = adv(p_p3);
                    going_p4 = false;
                } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                    going_p4 = false;
                } else {
                    p_p3 = recover(complain(p_p3, Text::lit("expected the end of the line")));
                }
            }
            Expected<std::tuple<std::tuple<Array<A>, Ps>, bool, Array<A>, Ps>, std::tuple<std::tuple<Array<A>, Ps>, bool, Array<A>, Ps>>(std::tuple{this_, going_p4, items_p2, p_p3});
        })
            : Expected<std::tuple<std::tuple<Array<A>, Ps>, bool, Array<A>, Ps>, std::tuple<std::tuple<Array<A>, Ps>, bool, Array<A>, Ps>>(unexpected(std::tuple{this_, going_p4, items_p2, p_p3}));
    };
    })), [=](std::tuple<std::tuple<Array<A>, Ps>, bool, Array<A>, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going_p4 = std::get<1>(_p0);
        auto items_p2 = std::get<2>(_p0);
        auto p_p3 = std::get<3>(_p0);
        return ({
            this_ = std::tuple{items_p2, p_p3};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start LayoutItems, x`: what the function value is when passed to `@Run`.
template <class A>
prism_rtl::JobRef<std::tuple<Array<A>, Ps>> start_layout_items(Ps p0_p0, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_f1) {
    return prism_rtl::make_rc<LayoutItems<A>>(p0_p0, f_f1);
}


/// Commas: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
template <class A>
std::tuple<Array<A>, Ps> commas(const Ps& p0_p0, const prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)>& f_f1) {
    std::tuple<Array<A>, Ps> this_ = std::tuple{Array<A>{}, p0_p0};
    auto [first_p2, p1_p3] = run_to_end(f_f1(p0_p0));
    Array<A> items_p4 = Array(std::vector{first_p2});
    Ps p_p5 = p1_p3;
    while (at_comma(p_p5) && (!p_p5.bad)) {
        auto [item_p6, q_p7] = run_to_end(f_f1(adv(p_p5)));
        items_p4 = crate::prelude::push(items_p4, item_p6);
        p_p5 = q_p7;
    }
    this_ = std::tuple{items_p4, p_p5};
    return this_;
}


template <class A>
prism_rtl::Turn<std::tuple<Array<A>, Ps>> Commas<A>::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    const auto& f_f1 = this->f_f1;
    std::tuple<Array<A>, Ps> this_ = std::tuple{Array<A>{}, p0_p0};
    auto [first_p2, p1_p3] = run_to_end(f_f1(p0_p0));
    Array<A> items_p4 = Array(std::vector{first_p2});
    Ps p_p5 = p1_p3;
    return call_then(loop_job(std::tuple{std::move(this_), std::move(items_p4), std::move(p_p5)}, ({
        auto f_f1_1 = f_f1;
        [=, f_f1_1 = std::move(f_f1_1)](std::tuple<std::tuple<Array<A>, Ps>, Array<A>, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto items_p4 = std::get<1>(_p0);
        auto p_p5 = std::get<2>(_p0);
        return at_comma(p_p5) && (!p_p5->bad)
            ? ({
            auto [item_p6, q_p7] = run_to_end(f_f1_1(adv(p_p5)));
            items_p4 = crate::prelude::push(items_p4, item_p6);
            p_p5 = q_p7;
            Expected<std::tuple<std::tuple<Array<A>, Ps>, Array<A>, Ps>, std::tuple<std::tuple<Array<A>, Ps>, Array<A>, Ps>>(std::tuple{this_, items_p4, p_p5});
        })
            : Expected<std::tuple<std::tuple<Array<A>, Ps>, Array<A>, Ps>, std::tuple<std::tuple<Array<A>, Ps>, Array<A>, Ps>>(unexpected(std::tuple{this_, items_p4, p_p5}));
    };
    })), [=](std::tuple<std::tuple<Array<A>, Ps>, Array<A>, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto items_p4 = std::get<1>(_p0);
        auto p_p5 = std::get<2>(_p0);
        return ({
            this_ = std::tuple{items_p4, p_p5};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start Commas, x`: what the function value is when passed to `@Run`.
template <class A>
prism_rtl::JobRef<std::tuple<Array<A>, Ps>> start_commas(Ps p0_p0, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_f1) {
    return prism_rtl::make_rc<Commas<A>>(p0_p0, f_f1);
}


}  // namespace syntax::parser

}  // namespace crate
