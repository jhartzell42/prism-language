// The module `Syntax.Parser`: its generic functions' and types' definitions, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/parser/module.hpp>
#include <syntax/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/sexp/module.hpp>

namespace crate {

using namespace prelude;

namespace syntax::parser {

/// Bracketed: fn Ps, (fn Ps -> ((a, Ps))) -> ((a, Ps))
template <class A>
std::tuple<A, Ps> bracketed(const Ps& p_, const prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)>& f_fn) {
    auto [v_, q] = run_to_end(f_fn(with_step_mode(p_, false)));
    return std::tuple{v_, with_step_mode(q, p_.step_mode)};
}


template <class A>
prism_rtl::Turn<std::tuple<A, Ps>> Bracketed<A>::cycle() const {
    const auto& p_ = this->p_;
    const auto& f_fn = this->f_fn;
    auto f_fn_1 = f_fn;
    auto p__2 = p_;
    return call_value(f_fn_1(with_step_mode(p__2, false)), [=](std::tuple<A, Ps> f_13868) {
        return ({
            auto [v_, q] = f_13868;
            (prism_rtl::finished(std::tuple{v_, with_step_mode(q, p__2.step_mode)}));
        });
    });
}


/// `Start Bracketed, x`: what the function value is when passed to `@Run`.
template <class A>
prism_rtl::JobRef<std::tuple<A, Ps>> start_bracketed(Ps p_, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_fn) {
    return prism_rtl::make_rc<Bracketed<A>>(p_, f_fn);
}


/// LayoutItems: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
template <class A>
std::tuple<Array<A>, Ps> layout_items(const Ps& p0, const prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)>& f_fn) {
    std::tuple<Array<A>, Ps> this_ = std::tuple{Array<A>{}, p0};
    Array<A> items = Array<A>{};
    Ps p_ = p0;
    bool going = true;
    while (going) {
        auto [item, q] = run_to_end(f_fn(p_));
        if (!q->bad) {
            items = crate::prelude::push(items, item);
        }
        p_ = recovered(q);
        {
            auto&& _m = kind(p_);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                p_ = adv(p_);
            } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                p_ = adv(p_);
                going = false;
            } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                going = false;
            } else {
                p_ = recover(complain(p_, Text::lit("expected the end of the line")));
            }
        }
    }
    this_ = std::tuple{items, p_};
    return this_;
}


template <class A>
prism_rtl::Turn<std::tuple<Array<A>, Ps>> LayoutItems<A>::cycle() const {
    const auto& p0 = this->p0;
    const auto& f_fn = this->f_fn;
    std::tuple<Array<A>, Ps> this_ = std::tuple{Array<A>{}, p0};
    Array<A> items = Array<A>{};
    Ps p_ = p0;
    bool going = true;
    auto f_fn_1 = f_fn;
    return call_then(loop_job(std::tuple{this_, going, items, p_}, ({
        auto f_fn_1_2 = f_fn_1;
        [=](std::tuple<std::tuple<Array<A>, Ps>, bool, Array<A>, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto items = std::get<2>(_p0);
        auto p_ = std::get<3>(_p0);
        return going
            ? ({
            auto [item, q] = run_to_end(f_fn_1_2(p_));
            if (!q->bad) {
                items = crate::prelude::push(items, item);
            }
            p_ = recovered(q);
            {
                auto&& _m = kind(p_);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                    p_ = adv(p_);
                } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                    p_ = adv(p_);
                    going = false;
                } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                    going = false;
                } else {
                    p_ = recover(complain(p_, Text::lit("expected the end of the line")));
                }
            }
            Expected<std::tuple<std::tuple<Array<A>, Ps>, bool, Array<A>, Ps>, std::tuple<std::tuple<Array<A>, Ps>, bool, Array<A>, Ps>>(std::tuple{this_, going, items, p_});
        })
            : Expected<std::tuple<std::tuple<Array<A>, Ps>, bool, Array<A>, Ps>, std::tuple<std::tuple<Array<A>, Ps>, bool, Array<A>, Ps>>(unexpected(std::tuple{this_, going, items, p_}));
    };
    })), [=](std::tuple<std::tuple<Array<A>, Ps>, bool, Array<A>, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto items = std::get<2>(_p0);
        auto p_ = std::get<3>(_p0);
        return ({
            this_ = std::tuple{items, p_};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start LayoutItems, x`: what the function value is when passed to `@Run`.
template <class A>
prism_rtl::JobRef<std::tuple<Array<A>, Ps>> start_layout_items(Ps p0, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_fn) {
    return prism_rtl::make_rc<LayoutItems<A>>(p0, f_fn);
}


/// Commas: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
template <class A>
std::tuple<Array<A>, Ps> commas(const Ps& p0, const prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)>& f_fn) {
    std::tuple<Array<A>, Ps> this_ = std::tuple{Array<A>{}, p0};
    auto [first_, p1] = run_to_end(f_fn(p0));
    Array<A> items = Array(std::vector{first_});
    Ps p_ = p1;
    while (at_comma(p_) && (!p_.bad)) {
        auto [item, q] = run_to_end(f_fn(adv(p_)));
        items = crate::prelude::push(items, item);
        p_ = q;
    }
    this_ = std::tuple{items, p_};
    return this_;
}


template <class A>
prism_rtl::Turn<std::tuple<Array<A>, Ps>> Commas<A>::cycle() const {
    const auto& p0 = this->p0;
    const auto& f_fn = this->f_fn;
    std::tuple<Array<A>, Ps> this_ = std::tuple{Array<A>{}, p0};
    auto [first_, p1] = run_to_end(f_fn(p0));
    Array<A> items = Array(std::vector{first_});
    Ps p_ = p1;
    return call_then(loop_job(std::tuple{this_, items, p_}, ({
        auto f_fn_1 = f_fn;
        [=](std::tuple<std::tuple<Array<A>, Ps>, Array<A>, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto items = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        return at_comma(p_) && (!p_->bad)
            ? ({
            auto [item, q] = run_to_end(f_fn_1(adv(p_)));
            items = crate::prelude::push(items, item);
            p_ = q;
            Expected<std::tuple<std::tuple<Array<A>, Ps>, Array<A>, Ps>, std::tuple<std::tuple<Array<A>, Ps>, Array<A>, Ps>>(std::tuple{this_, items, p_});
        })
            : Expected<std::tuple<std::tuple<Array<A>, Ps>, Array<A>, Ps>, std::tuple<std::tuple<Array<A>, Ps>, Array<A>, Ps>>(unexpected(std::tuple{this_, items, p_}));
    };
    })), [=](std::tuple<std::tuple<Array<A>, Ps>, Array<A>, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto items = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        return ({
            this_ = std::tuple{items, p_};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start Commas, x`: what the function value is when passed to `@Run`.
template <class A>
prism_rtl::JobRef<std::tuple<Array<A>, Ps>> start_commas(Ps p0, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_fn) {
    return prism_rtl::make_rc<Commas<A>>(p0, f_fn);
}


}  // namespace syntax::parser

}  // namespace crate
