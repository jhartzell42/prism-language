// The module `Syntax.Parser`, from `target/bootstrap/cpp-src/prismc/syntax/parser/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include <syntax/parser/module.hpp>
#include <syntax/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/sexp/module.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/lexer/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::syntax::parser {

prism_rtl::Turn<std::tuple<Array<crate::syntax::TemplatePart>, Ps>> TemplatePartOf::cycle() const {
    const auto& acc = this->acc;
    const auto& p_ = this->p_;
    const auto& tpart_tok2 = this->tpart_tok2;
    return ({
        prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(tpart_tok2) ? ({
        auto&& s = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(tpart_tok2).a0;
        prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::syntax::TemplatePart(crate::syntax::TemplatePart::TpText{s})), p_});
    })
        : prism_rtl::is<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok2) ? ({
        auto&& toks = prism_rtl::as<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok2).a0;
        auto&& col_opt = prism_rtl::as<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok2).a1;
        auto&& span = prism_rtl::as<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok2).a2;
        ({
        auto col_opt_1 = col_opt;
        auto acc_2 = acc;
        auto p__3 = p_;
        auto span_4 = span;
        auto toks_5 = toks;
        call_then(start_parse_nested(p__3, toks_5, span_4), [=](std::tuple<crate::syntax::Expr, Ps> parse_nested_63877) {
        return ({
            auto [e, q] = parse_nested_63877;
            (prism_rtl::finished(std::tuple{crate::prelude::push(acc_2, crate::syntax::TemplatePart(crate::syntax::TemplatePart::TpPlaceholder{e, col_opt_1})), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TPartTok::TptBlock>(tpart_tok2) ? ({
        auto&& toks = prism_rtl::as<crate::syntax::lexer::TPartTok::TptBlock>(tpart_tok2).a0;
        auto&& span = prism_rtl::as<crate::syntax::lexer::TPartTok::TptBlock>(tpart_tok2).a1;
        ({
        auto acc_1 = acc;
        auto p__2 = p_;
        auto span_3 = span;
        auto toks_4 = toks;
        call_then(start_sub(p__2, toks_4, at_end(span_3)), [=](Ps sub_64013) {
        return ({
            auto sub_ = sub_64013;
            call_then(start_parse_block_until_eof(sub_, span_3), [=](std::tuple<crate::syntax::Block, Ps> parse_block_until_eof_64063) {
            return ({
                auto [block, s1] = parse_block_until_eof_64063;
                (prism_rtl::finished(std::tuple{crate::prelude::push(acc_1, crate::syntax::TemplatePart(crate::syntax::TemplatePart::TpBlock{block})), absorb(p__2, s1)}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2) ? ({
        auto&& name = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2).a0;
        auto&& attrs = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2).a1;
        auto&& body_opt = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2).a2;
        auto&& span = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2).a3;
        ({
        auto sname = crate::syntax::SName{.sigils = name.sigils, .path_ = name->path_, .span = span};
        auto body_opt_1 = body_opt;
        auto acc_2 = acc;
        auto attrs_3 = attrs;
        auto p__4 = p_;
        auto span_5 = span;
        call_value(fold_job(attrs_3, std::tuple{Array<crate::syntax::Arg>{}, p__4}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, Ps>>(std::tuple<std::tuple<Array<crate::syntax::Arg>, Ps>, crate::syntax::lexer::AttrTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::Arg>, Ps>, crate::syntax::lexer::AttrTok> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [done, q] = p0;
                auto a = p1;
                (prism_rtl::more(prism_rtl::rc(AttrArg(done, q, a))));
            });
        }));
    }))), [=](std::tuple<Array<crate::syntax::Arg>, Ps> fold_64298) {
        return ({
            auto [args, p1] = fold_64298;
            auto [inner_opt, p2] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<std::optional<Array<crate::syntax::TemplatePart>>, Ps>> _v;
                if (prism_rtl::is_some(body_opt)) {
                    auto&& b = prism_rtl::some_of(body_opt);
                    _v.set(({
                        auto [ps, q] = template_parts(p1, b);
                        std::tuple{std::optional(ps), q};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(body_opt)) {
                    _v.set(std::tuple{std::optional<Array<crate::syntax::TemplatePart>>{}, p1});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(std::tuple{crate::prelude::push(acc_2, crate::syntax::TemplatePart(crate::syntax::TemplatePart::TpCall{sname, args, inner_opt, span_5})), p2}));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplatePartOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::TemplatePart>, Ps>> start_template_part_of(Array<crate::syntax::TemplatePart> acc, Ps p_, crate::syntax::lexer::TPartTok tpart_tok2) {
    return prism_rtl::make_rc<TemplatePartOf>(acc, p_, tpart_tok2);
}


/// AttrArg: unbounded fn [Arg], Ps, AttrTok -> (([Arg], Ps))
std::tuple<Array<crate::syntax::Arg>, Ps> attr_arg(const Array<crate::syntax::Arg>& done, const Ps& p_, const crate::syntax::lexer::AttrTok& a) {
    auto [value, q] = parse_nested(p_, a->tokens, a.span);
    return std::tuple{crate::prelude::push(done, crate::syntax::Arg{.name = std::optional(crate::syntax::Ident{.name = a.name, .span = a.span}), .value = value, .span = a.span}), q};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, Ps>> AttrArg::cycle() const {
    const auto& done = this->done;
    const auto& p_ = this->p_;
    const auto& a = this->a;
    auto a_1 = a;
    auto done_2 = done;
    auto p__3 = p_;
    return call_then(start_parse_nested(p__3, a_1->tokens, a_1.span), [=](std::tuple<crate::syntax::Expr, Ps> parse_nested_64672) {
        return ({
            auto [value, q] = parse_nested_64672;
            (prism_rtl::finished(std::tuple{crate::prelude::push(done_2, crate::syntax::Arg{.name = std::optional(crate::syntax::Ident{.name = a_1.name, .span = a_1.span}), .value = value, .span = a_1.span}), q}));
        });
    });
}


/// `Start AttrArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, Ps>> start_attr_arg(Array<crate::syntax::Arg> done, Ps p_, crate::syntax::lexer::AttrTok a) {
    return prism_rtl::make_rc<AttrArg>(done, p_, a);
}


/// ParseLambda: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, Ps> parse_lambda(const Ps& p0) {
    auto start = here(p0);
    auto p_ = adv(p0);
    auto [params_opt, p1] = kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{true})
        ? lambda_params(adv(p_))
        : std::tuple{std::optional<Array<crate::syntax::Pattern_>>{}, p_};
    return at_open_l(p1)
        ? ({
        auto [block, q] = parse_indented_block(p1);
        std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELambda{params_opt, prism_rtl::rc(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbBlock{block}))})), .span = to(start, block.span)}, q};
    })
        : ({
        auto [body, q] = parse_expr(p1);
        std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELambda{params_opt, prism_rtl::rc(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(body)}))})), .span = to(start, body.span)}, q};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, Ps>> ParseLambda::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto p_ = adv(p0);
    auto [params_opt, p1] = kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{true})
        ? lambda_params(adv(p_))
        : std::tuple{std::optional<Array<crate::syntax::Pattern_>>{}, p_};
    return at_open_l(p1)
        ? call_then(start_parse_indented_block(p1), [=](std::tuple<crate::syntax::Block, Ps> parse_indented_block_65301) {
        return ({
            auto [block, q] = parse_indented_block_65301;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELambda{params_opt, prism_rtl::rc(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbBlock{block}))})), .span = to(start, block.span)}, q}));
        });
    })
        : call_then(start_parse_expr(p1), [=](std::tuple<crate::syntax::Expr, Ps> parse_expr_65449) {
        return ({
            auto [body, q] = parse_expr_65449;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELambda{params_opt, prism_rtl::rc(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(body)}))})), .span = to(start, body.span)}, q}));
        });
    });
}


/// `Start ParseLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, Ps>> start_parse_lambda(Ps p0) {
    return prism_rtl::make_rc<ParseLambda>(p0);
}


/// LambdaParams: unbounded fn Ps -> ((?[Pattern], Ps))
std::tuple<std::optional<Array<crate::syntax::Pattern_>>, Ps> lambda_params(const Ps& p_) {
    auto [ps, p1] = kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{false})
        ? std::tuple{Array<crate::syntax::Pattern_>{}, p_}
        : commas(p_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(ParsePattern(q, false))));
            });
        }));
    })));
    return kind(p1) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{false})
        ? std::tuple{std::optional(ps), adv(p1)}
        : std::tuple{std::optional<Array<crate::syntax::Pattern_>>{}, error_here(p1, Text::lit("expected `|` to close the lambda's parameters"))};
}


prism_rtl::Turn<std::tuple<std::optional<Array<crate::syntax::Pattern_>>, Ps>> LambdaParams::cycle() const {
    const auto& p_ = this->p_;
    auto [ps, p1] = kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{false})
        ? std::tuple{Array<crate::syntax::Pattern_>{}, p_}
        : commas(p_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(ParsePattern(q, false))));
            });
        }));
    })));
    return kind(p1) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{false})
        ? prism_rtl::finished(std::tuple{std::optional(ps), adv(p1)})
        : prism_rtl::finished(std::tuple{std::optional<Array<crate::syntax::Pattern_>>{}, error_here(p1, Text::lit("expected `|` to close the lambda's parameters"))});
}


/// `Start LambdaParams, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<Array<crate::syntax::Pattern_>>, Ps>> start_lambda_params(Ps p_) {
    return prism_rtl::make_rc<LambdaParams>(p_);
}


/// ParseCond: unbounded fn Ps, Bool -> ((Cond, Ps))
std::tuple<crate::syntax::Cond, Ps> parse_cond(const Ps& p_, const bool& allow_guard) {
    auto [pattern, q] = parse_pattern(p_, true);
    return (!q->bad) && at_op(q, Text::lit("<-"))
        ? ({
        auto [value, q1] = parse_expr(adv(q));
        allow_guard && at_kw(q1, Text::lit("if"))
        ? ({
        auto [guard, q2] = parse_expr(adv(q1));
        std::tuple{crate::syntax::Cond(crate::syntax::Cond::CondBind{pattern, prism_rtl::rc(value), prism_rtl::rc(std::optional(guard))}), q2};
    })
        : std::tuple{crate::syntax::Cond(crate::syntax::Cond::CondBind{pattern, prism_rtl::rc(value), prism_rtl::rc(std::optional<crate::syntax::Expr>{})}), q1};
    })
        : ({
        auto [e, q1] = parse_expr(p_);
        std::tuple{crate::syntax::Cond(crate::syntax::Cond::CondExpr{prism_rtl::rc(e)}), q1};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Cond, Ps>> ParseCond::cycle() const {
    const auto& p_ = this->p_;
    const auto& allow_guard = this->allow_guard;
    auto allow_guard_1 = allow_guard;
    auto p__2 = p_;
    return call_then(start_parse_pattern(p__2, true), [=](std::tuple<crate::syntax::Pattern_, Ps> parse_pattern_66034) {
        return ({
            auto [pattern, q] = parse_pattern_66034;
            (!q->bad) && at_op(q, Text::lit("<-"))
            ? call_then(start_parse_expr(adv(q)), [=](std::tuple<crate::syntax::Expr, Ps> parse_expr_66120) {
            return ({
                auto [value, q1] = parse_expr_66120;
                allow_guard_1 && at_kw(q1, Text::lit("if"))
                ? call_then(start_parse_expr(adv(q1)), [=](std::tuple<crate::syntax::Expr, Ps> parse_expr_66213) {
                return ({
                    auto [guard, q2] = parse_expr_66213;
                    (prism_rtl::finished(std::tuple{crate::syntax::Cond(crate::syntax::Cond::CondBind{pattern, prism_rtl::rc(value), prism_rtl::rc(std::optional(guard))}), q2}));
                });
            })
                : prism_rtl::finished(std::tuple{crate::syntax::Cond(crate::syntax::Cond::CondBind{pattern, prism_rtl::rc(value), prism_rtl::rc(std::optional<crate::syntax::Expr>{})}), q1});
            });
        })
            : call_then(start_parse_expr(p__2), [=](std::tuple<crate::syntax::Expr, Ps> parse_expr_66376) {
            return ({
                auto [e, q1] = parse_expr_66376;
                (prism_rtl::finished(std::tuple{crate::syntax::Cond(crate::syntax::Cond::CondExpr{prism_rtl::rc(e)}), q1}));
            });
        });
        });
    });
}


/// `Start ParseCond, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Cond, Ps>> start_parse_cond(Ps p_, bool allow_guard) {
    return prism_rtl::make_rc<ParseCond>(p_, allow_guard);
}


/// ParseIf: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, Ps> parse_if(const Ps& p0) {
    auto start = here(p0);
    auto [cond, p1] = parse_cond(adv(p0), false);
    auto [then_block, p2] = parse_block_after_colon(p1);
    auto p3 = at_sep(p2) && is_else(kind_at(p2, Nat(1u))) ? adv(p2) : p2;
    return at_kw(p3, Text::lit("else"))
        ? ({
        auto [else_block, q] = parse_block_after_colon(adv(p3));
        std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIf{prism_rtl::rc(cond), then_block, std::optional(else_block)})), .span = to(start, else_block.span)}, q};
    })
        : std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIf{prism_rtl::rc(cond), then_block, std::optional<crate::syntax::Block>{}})), .span = to(start, then_block.span)}, p3};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, Ps>> ParseIf::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto p0_1 = p0;
    return call_then(start_parse_cond(adv(p0_1), false), [=](std::tuple<crate::syntax::Cond, Ps> parse_cond_66609) {
        return ({
            auto [cond, p1] = parse_cond_66609;
            call_then(start_parse_block_after_colon(p1), [=](std::tuple<crate::syntax::Block, Ps> parse_block_after_colon_66663) {
            return ({
                auto [then_block, p2] = parse_block_after_colon_66663;
                auto p3 = at_sep(p2) && is_else(kind_at(p2, Nat(1u))) ? adv(p2) : p2;
                at_kw(p3, Text::lit("else"))
                ? call_then(start_parse_block_after_colon(adv(p3)), [=](std::tuple<crate::syntax::Block, Ps> parse_block_after_colon_66814) {
                return ({
                    auto [else_block, q] = parse_block_after_colon_66814;
                    (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIf{prism_rtl::rc(cond), then_block, std::optional(else_block)})), .span = to(start, else_block.span)}, q}));
                });
            })
                : prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIf{prism_rtl::rc(cond), then_block, std::optional<crate::syntax::Block>{}})), .span = to(start, then_block.span)}, p3});
            });
        });
        });
    });
}


/// `Start ParseIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, Ps>> start_parse_if(Ps p0) {
    return prism_rtl::make_rc<ParseIf>(p0);
}


/// IsElse: fn TokKind -> Bool
bool is_else(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(tok_kind0)) {
        auto&& c0_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(tok_kind0).a0;
        if (c0_0_0 == Text::lit("else")) {
            return true;
        }
    }
    {
        return false;
    }
}


/// ParseMatch: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, Ps> parse_match(const Ps& p0) {
    auto start = here(p0);
    auto [scrutinee, p1] = parse_expr(adv(p0));
    auto p2 = expect_colon(p1);
    return at_open_l(p2)
        ? ({
        auto [arms, q] = match_arms(adv(p2));
        std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMatch{prism_rtl::rc(scrutinee), arms})), .span = to(start, crate::syntax::parser::prev(q))}, q};
    })
        : std::tuple{no_expr(), error_here(p2, Text::lit("a `match`'s arms stand in an indented block after its `:`"))};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, Ps>> ParseMatch::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto p0_1 = p0;
    return call_then(start_parse_expr(adv(p0_1)), [=](std::tuple<crate::syntax::Expr, Ps> parse_expr_67395) {
        return ({
            auto [scrutinee, p1] = parse_expr_67395;
            auto p2 = expect_colon(p1);
            at_open_l(p2)
            ? call_then(start_match_arms(adv(p2)), [=](std::tuple<Array<crate::syntax::Arm>, Ps> match_arms_67487) {
            return ({
                auto [arms, q] = match_arms_67487;
                (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMatch{prism_rtl::rc(scrutinee), arms})), .span = to(start, crate::syntax::parser::prev(q))}, q}));
            });
        })
            : prism_rtl::finished(std::tuple{no_expr(), error_here(p2, Text::lit("a `match`'s arms stand in an indented block after its `:`"))});
        });
    });
}


/// `Start ParseMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, Ps>> start_parse_match(Ps p0) {
    return prism_rtl::make_rc<ParseMatch>(p0);
}


/// MatchArms: unbounded fn Ps -> (([Arm], Ps))
std::tuple<Array<crate::syntax::Arm>, Ps> match_arms(const Ps& p0) {
    std::tuple<Array<crate::syntax::Arm>, Ps> this_ = std::tuple{Array<crate::syntax::Arm>{}, p0};
    Array<crate::syntax::Arm> arms = Array<crate::syntax::Arm>{};
    Ps p_ = p0;
    bool going = true;
    while (going) {
        auto [arm, q] = parse_arm(p_);
        if (!q->bad) {
            arms = crate::prelude::push(arms, arm);
        }
        p_ = recovered(q);
        {
            auto&& _m = kind(p_);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                p_ = adv(p_);
            } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                p_ = adv(p_);
                going = false;
            } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                going = false;
            } else {
                p_ = recover(complain(p_, Text::lit("expected the end of the arm")));
            }
        }
    }
    this_ = std::tuple{arms, p_};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Arm>, Ps>> MatchArms::cycle() const {
    const auto& p0 = this->p0;
    std::tuple<Array<crate::syntax::Arm>, Ps> this_ = std::tuple{Array<crate::syntax::Arm>{}, p0};
    Array<crate::syntax::Arm> arms = Array<crate::syntax::Arm>{};
    Ps p_ = p0;
    bool going = true;
    return call_then(loop_job(std::tuple{this_, arms, going, p_}, [=](std::tuple<std::tuple<Array<crate::syntax::Arm>, Ps>, Array<crate::syntax::Arm>, bool, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto arms = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto p_ = std::get<3>(_p0);
        return going
            ? ({
            auto [arm, q] = parse_arm(p_);
            if (!q->bad) {
                arms = crate::prelude::push(arms, arm);
            }
            p_ = recovered(q);
            {
                auto&& _m = kind(p_);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                    p_ = adv(p_);
                } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                    p_ = adv(p_);
                    going = false;
                } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                    going = false;
                } else {
                    p_ = recover(complain(p_, Text::lit("expected the end of the arm")));
                }
            }
            Expected<std::tuple<std::tuple<Array<crate::syntax::Arm>, Ps>, Array<crate::syntax::Arm>, bool, Ps>, std::tuple<std::tuple<Array<crate::syntax::Arm>, Ps>, Array<crate::syntax::Arm>, bool, Ps>>(std::tuple{this_, arms, going, p_});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::Arm>, Ps>, Array<crate::syntax::Arm>, bool, Ps>, std::tuple<std::tuple<Array<crate::syntax::Arm>, Ps>, Array<crate::syntax::Arm>, bool, Ps>>(unexpected(std::tuple{this_, arms, going, p_}));
    }), [=](std::tuple<std::tuple<Array<crate::syntax::Arm>, Ps>, Array<crate::syntax::Arm>, bool, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto arms = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto p_ = std::get<3>(_p0);
        return ({
            this_ = std::tuple{arms, p_};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start MatchArms, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arm>, Ps>> start_match_arms(Ps p0) {
    return prism_rtl::make_rc<MatchArms>(p0);
}


/// ParseArm: unbounded fn Ps -> ((Arm, Ps))
std::tuple<crate::syntax::Arm, Ps> parse_arm(const Ps& p_) {
    auto start = here(p_);
    return at_kw(p_, Text::lit("otherwise"))
        ? ({
        auto [body, q] = parse_block_after_colon(adv(p_));
        std::tuple{crate::syntax::Arm{.pattern = std::optional<crate::syntax::Pattern_>{}, .guard = std::optional<crate::syntax::Expr>{}, .body = body, .span = to(start, body.span)}, q};
    })
        : at_kw(p_, Text::lit("ignore")) && (kind_at(p_, Nat(1u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}))
        ? std::tuple{crate::syntax::Arm{.pattern = std::optional<crate::syntax::Pattern_>{}, .guard = std::optional<crate::syntax::Expr>{}, .body = no_block(), .span = start}, error_at(p_, here(p_), Text::lit("an arm beginning `ignore:` would read as \"ignore these cases\": the catch-all is `otherwise:`"))}
        : ({
        auto [pattern, p1] = parse_pattern(p_, true);
        auto [guard_opt, p2] = at_kw(p1, Text::lit("if"))
            ? optional_expr(adv(p1))
            : std::tuple{std::optional<crate::syntax::Expr>{}, p1};
        auto [body, p3] = parse_block_after_colon(p2);
        std::tuple{crate::syntax::Arm{.pattern = std::optional(pattern), .guard = guard_opt, .body = body, .span = to(start, body.span)}, p3};
    });
}


/// OptionalExpr: unbounded fn Ps -> ((?Expr, Ps))
std::tuple<std::optional<crate::syntax::Expr>, Ps> optional_expr(const Ps& p_) {
    auto [e, q] = parse_expr(p_);
    return std::tuple{std::optional(e), q};
}


/// ParseFor: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, Ps> parse_for(const Ps& p0) {
    auto start = here(p0);
    auto p_ = adv(p0);
    auto [binders_opt, p1] = for_binders_of(p_);
    auto [source, p2] = parse_expr(p1);
    auto [body, p3] = parse_block_after_colon(p2);
    return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EFor{binders_opt, prism_rtl::rc(source), body})), .span = to(start, body.span)}, p3};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, Ps>> ParseFor::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto p_ = adv(p0);
    return call_then(start_for_binders_of(p_), [=](std::tuple<std::optional<crate::syntax::ForBinders>, Ps> for_binders_of_69343) {
        return ({
            auto [binders_opt, p1] = for_binders_of_69343;
            call_then(start_parse_expr(p1), [=](std::tuple<crate::syntax::Expr, Ps> parse_expr_69383) {
            return ({
                auto [source, p2] = parse_expr_69383;
                call_then(start_parse_block_after_colon(p2), [=](std::tuple<crate::syntax::Block, Ps> parse_block_after_colon_69419) {
                return ({
                    auto [body, p3] = parse_block_after_colon_69419;
                    (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EFor{binders_opt, prism_rtl::rc(source), body})), .span = to(start, body.span)}, p3}));
                });
            });
            });
        });
        });
    });
}


/// `Start ParseFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, Ps>> start_parse_for(Ps p0) {
    return prism_rtl::make_rc<ParseFor>(p0);
}


/// ForBindersOf: unbounded fn Ps -> ((?ForBinders, Ps))
std::tuple<std::optional<crate::syntax::ForBinders>, Ps> for_binders_of(const Ps& p_) {
    auto [first_, q1] = parse_pattern(p_, false);
    auto [second_opt, q2] = at_comma(q1)
        ? optional_pattern(adv(q1))
        : std::tuple{std::optional<crate::syntax::Pattern_>{}, q1};
    return (!q2->bad) && at_op(q2, Text::lit("<-"))
        ? std::tuple{std::optional(crate::syntax::ForBinders{.first = first_, .second = second_opt}), adv(q2)}
        : std::tuple{std::optional<crate::syntax::ForBinders>{}, p_};
}


prism_rtl::Turn<std::tuple<std::optional<crate::syntax::ForBinders>, Ps>> ForBindersOf::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_pattern(p__1, false), [=](std::tuple<crate::syntax::Pattern_, Ps> parse_pattern_69704) {
        return ({
            auto [first_, q1] = parse_pattern_69704;
            auto [second_opt, q2] = at_comma(q1)
                ? optional_pattern(adv(q1))
                : std::tuple{std::optional<crate::syntax::Pattern_>{}, q1};
            (!q2->bad) && at_op(q2, Text::lit("<-"))
            ? prism_rtl::finished(std::tuple{std::optional(crate::syntax::ForBinders{.first = first_, .second = second_opt}), adv(q2)})
            : prism_rtl::finished(std::tuple{std::optional<crate::syntax::ForBinders>{}, p__1});
        });
    });
}


/// `Start ForBindersOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::ForBinders>, Ps>> start_for_binders_of(Ps p_) {
    return prism_rtl::make_rc<ForBindersOf>(p_);
}


/// OptionalPattern: unbounded fn Ps -> ((?Pattern, Ps))
std::tuple<std::optional<crate::syntax::Pattern_>, Ps> optional_pattern(const Ps& p_) {
    auto [pat, q] = parse_pattern(p_, false);
    return std::tuple{std::optional(pat), q};
}


/// ParseBlockAfterColon: unbounded fn Ps -> ((Block, Ps))
std::tuple<crate::syntax::Block, Ps> parse_block_after_colon(const Ps& p0) {
    auto p_ = expect_colon(p0);
    return at_open_l(p_)
        ? parse_indented_block(p_)
        : at_stmt_boundary(p_)
        ? std::tuple{no_block(), error_here(p_, Text::lit("expected a statement after `:`"))}
        : ({
        auto start = here(p_);
        auto [first_, p1] = parse_stmt(p_);
        auto r = ({
            std::tuple<Array<crate::syntax::Stmt>, Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<crate::syntax::Stmt> stmts = Array(std::vector{first_});
            Ps q = p1;
            while ((kind(q) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSemi{})) && (!q.bad)) {
                auto [st, q2] = parse_stmt(adv(q));
                stmts = crate::prelude::push(stmts, st);
                q = q2;
            }
            this_ = std::tuple{stmts, q};
            this_;
        });
        auto [stmts, q] = r;
        std::tuple{crate::syntax::Block{.stmts = stmts, .inline_ = true, .span = to(start, crate::syntax::parser::prev(q))}, q};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Block, Ps>> ParseBlockAfterColon::cycle() const {
    const auto& p0 = this->p0;
    auto p_ = expect_colon(p0);
    return at_open_l(p_)
        ? prism_rtl::more(prism_rtl::rc(ParseIndentedBlock(p_)))
        : at_stmt_boundary(p_)
        ? prism_rtl::finished(std::tuple{no_block(), error_here(p_, Text::lit("expected a statement after `:`"))})
        : ({
        auto start = here(p_);
        call_then(start_parse_stmt(p_), [=](std::tuple<crate::syntax::Stmt, Ps> parse_stmt_70899) {
        return ({
            auto [first_, p1] = parse_stmt_70899;
            std::tuple<Array<crate::syntax::Stmt>, Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<crate::syntax::Stmt> stmts = Array(std::vector{first_});
            Ps q = p1;
            auto start_1 = start;
            call_then(loop_job(std::tuple{this_, q, stmts}, [=](std::tuple<std::tuple<Array<crate::syntax::Stmt>, Ps>, Ps, Array<crate::syntax::Stmt>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q = std::get<1>(_p0);
            auto stmts = std::get<2>(_p0);
            return (kind(q) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSemi{})) && (!q->bad)
                ? ({
                auto [st, q2] = parse_stmt(adv(q));
                stmts = crate::prelude::push(stmts, st);
                q = q2;
                Expected<std::tuple<std::tuple<Array<crate::syntax::Stmt>, Ps>, Ps, Array<crate::syntax::Stmt>>, std::tuple<std::tuple<Array<crate::syntax::Stmt>, Ps>, Ps, Array<crate::syntax::Stmt>>>(std::tuple{this_, q, stmts});
            })
                : Expected<std::tuple<std::tuple<Array<crate::syntax::Stmt>, Ps>, Ps, Array<crate::syntax::Stmt>>, std::tuple<std::tuple<Array<crate::syntax::Stmt>, Ps>, Ps, Array<crate::syntax::Stmt>>>(unexpected(std::tuple{this_, q, stmts}));
        }), [=](std::tuple<std::tuple<Array<crate::syntax::Stmt>, Ps>, Ps, Array<crate::syntax::Stmt>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q = std::get<1>(_p0);
            auto stmts = std::get<2>(_p0);
            return ({
                this_ = std::tuple{stmts, q};
                auto r = this_;
                auto [stmts, q] = r;
                (prism_rtl::finished(std::tuple{crate::syntax::Block{.stmts = stmts, .inline_ = true, .span = to(start_1, crate::syntax::parser::prev(q))}, q}));
            });
        });
        });
    });
    });
}


/// `Start ParseBlockAfterColon, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Block, Ps>> start_parse_block_after_colon(Ps p0) {
    return prism_rtl::make_rc<ParseBlockAfterColon>(p0);
}


/// ParseIndentedBlock: unbounded fn Ps -> ((Block, Ps))
std::tuple<crate::syntax::Block, Ps> parse_indented_block(const Ps& p0) {
    auto start = here(p0);
    auto [stmts, q] = stmts_until(adv(p0), true);
    return std::tuple{crate::syntax::Block{.stmts = stmts, .inline_ = false, .span = to(start, crate::syntax::parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Block, Ps>> ParseIndentedBlock::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto p0_1 = p0;
    return call_then(start_stmts_until(adv(p0_1), true), [=](std::tuple<Array<crate::syntax::Stmt>, Ps> stmts_until_71501) {
        return ({
            auto [stmts, q] = stmts_until_71501;
            (prism_rtl::finished(std::tuple{crate::syntax::Block{.stmts = stmts, .inline_ = false, .span = to(start, crate::syntax::parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseIndentedBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Block, Ps>> start_parse_indented_block(Ps p0) {
    return prism_rtl::make_rc<ParseIndentedBlock>(p0);
}


/// ParseBlockUntilEof: unbounded fn Ps, Range -> ((Block, Ps))
std::tuple<crate::syntax::Block, Ps> parse_block_until_eof(const Ps& p_, const crate::syntax::Range& span) {
    auto [stmts, q] = at_eof(p_)
        ? std::tuple{Array<crate::syntax::Stmt>{}, p_}
        : stmts_until(p_, false);
    return std::tuple{crate::syntax::Block{.stmts = stmts, .inline_ = false, .span = span}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Block, Ps>> ParseBlockUntilEof::cycle() const {
    const auto& p_ = this->p_;
    const auto& span = this->span;
    auto [stmts, q] = at_eof(p_)
        ? std::tuple{Array<crate::syntax::Stmt>{}, p_}
        : stmts_until(p_, false);
    return prism_rtl::finished(std::tuple{crate::syntax::Block{.stmts = stmts, .inline_ = false, .span = span}, q});
}


/// `Start ParseBlockUntilEof, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Block, Ps>> start_parse_block_until_eof(Ps p_, crate::syntax::Range span) {
    return prism_rtl::make_rc<ParseBlockUntilEof>(p_, span);
}


/// StmtsUntil: unbounded fn Ps, Bool -> (([Stmt], Ps))
std::tuple<Array<crate::syntax::Stmt>, Ps> stmts_until(const Ps& p0, const bool& indented) {
    std::tuple<Array<crate::syntax::Stmt>, Ps> this_ = std::tuple{Array<crate::syntax::Stmt>{}, p0};
    Array<crate::syntax::Stmt> stmts = Array<crate::syntax::Stmt>{};
    Ps p_ = p0;
    bool going = true;
    while (going) {
        auto [st, q] = parse_stmt(p_);
        if (!q->bad) {
            stmts = crate::prelude::push(stmts, st);
        }
        p_ = recovered(q);
        {
            auto&& _m = kind(p_);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                p_ = adv(p_);
                if ((!indented) && at_eof(p_)) {
                    going = false;
                }
            } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                p_ = adv(p_);
                if (indented || at_eof(p_)) {
                    going = false;
                }
            } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                going = false;
            } else {
                p_ = recover(complain(p_, Text::lit("expected the end of the statement")));
            }
        }
    }
    this_ = std::tuple{stmts, p_};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Stmt>, Ps>> StmtsUntil::cycle() const {
    const auto& p0 = this->p0;
    const auto& indented = this->indented;
    std::tuple<Array<crate::syntax::Stmt>, Ps> this_ = std::tuple{Array<crate::syntax::Stmt>{}, p0};
    Array<crate::syntax::Stmt> stmts = Array<crate::syntax::Stmt>{};
    Ps p_ = p0;
    bool going = true;
    return call_then(loop_job(std::tuple{this_, going, p_, stmts}, ({
        auto indented_1 = indented;
        [=](std::tuple<std::tuple<Array<crate::syntax::Stmt>, Ps>, bool, Ps, Array<crate::syntax::Stmt>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        auto stmts = std::get<3>(_p0);
        return going
            ? ({
            auto [st, q] = parse_stmt(p_);
            if (!q->bad) {
                stmts = crate::prelude::push(stmts, st);
            }
            p_ = recovered(q);
            {
                auto&& _m = kind(p_);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                    p_ = adv(p_);
                    if ((!indented_1) && at_eof(p_)) {
                        going = false;
                    }
                } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                    p_ = adv(p_);
                    if (indented_1 || at_eof(p_)) {
                        going = false;
                    }
                } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                    going = false;
                } else {
                    p_ = recover(complain(p_, Text::lit("expected the end of the statement")));
                }
            }
            Expected<std::tuple<std::tuple<Array<crate::syntax::Stmt>, Ps>, bool, Ps, Array<crate::syntax::Stmt>>, std::tuple<std::tuple<Array<crate::syntax::Stmt>, Ps>, bool, Ps, Array<crate::syntax::Stmt>>>(std::tuple{this_, going, p_, stmts});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::Stmt>, Ps>, bool, Ps, Array<crate::syntax::Stmt>>, std::tuple<std::tuple<Array<crate::syntax::Stmt>, Ps>, bool, Ps, Array<crate::syntax::Stmt>>>(unexpected(std::tuple{this_, going, p_, stmts}));
    };
    })), [=](std::tuple<std::tuple<Array<crate::syntax::Stmt>, Ps>, bool, Ps, Array<crate::syntax::Stmt>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        auto stmts = std::get<3>(_p0);
        return ({
            this_ = std::tuple{stmts, p_};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start StmtsUntil, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Stmt>, Ps>> start_stmts_until(Ps p0, bool indented) {
    return prism_rtl::make_rc<StmtsUntil>(p0, indented);
}


/// ParseStmt: unbounded fn Ps -> ((Stmt, Ps))
std::tuple<crate::syntax::Stmt, Ps> parse_stmt(const Ps& p_) {
    auto start = here(p_);
    auto [kind_, q] = stmt_kind_of(p_, start);
    return std::tuple{crate::syntax::Stmt{.kind = kind_, .span = to(start, crate::syntax::parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Stmt, Ps>> ParseStmt::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto p__1 = p_;
    return call_then(start_stmt_kind_of(p__1, start), [=](std::tuple<crate::syntax::StmtKind, Ps> stmt_kind_of_72929) {
        return ({
            auto [kind_, q] = stmt_kind_of_72929;
            (prism_rtl::finished(std::tuple{crate::syntax::Stmt{.kind = kind_, .span = to(start, crate::syntax::parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Stmt, Ps>> start_parse_stmt(Ps p_) {
    return prism_rtl::make_rc<ParseStmt>(p_);
}


/// StmtKindOf: unbounded fn Ps, Range -> ((StmtKind, Ps))
std::tuple<crate::syntax::StmtKind, Ps> stmt_kind_of(const Ps& p_, const crate::syntax::Range& start) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m73084_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m73084_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m73084_0_0 == Text::lit("emit")) {
            if (m73084_0_1 == Text::lit("")) {
                auto [r, q] = parse_row(adv(p_));
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SEmit{r}), q};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m73084_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m73084_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m73084_1_0 == Text::lit("let")) {
            if (m73084_1_1 == Text::lit("")) {
                auto [pattern, p1] = parse_pattern(adv(p_), false);
                auto [ty_opt, p2] = optional_annotation(p1);
                auto [value, p3] = parse_rhs_expr(expect_op(p2, Text::lit("=")));
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SLet{pattern, ty_opt, value}), p3};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m73084_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m73084_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m73084_2_0 == Text::lit("fn")) {
            if (m73084_2_1 == Text::lit("")) {
                auto [f, q] = parse_fn_clause(p_);
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SFn{f}), q};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m73084_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m73084_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m73084_3_0 == Text::lit("ignore")) {
            if (m73084_3_1 == Text::lit("")) {
                if (at_op(adv(p_), Text::lit("<-"))) {
                    auto [e, q] = parse_rhs_expr(adv(adv(p_)));
                    return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SIgnore{e}), q};
                }
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m73084_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m73084_4_1 == Text::lit("")) {
            if ((w == Text::lit("require")) || (w == Text::lit("forbid"))) {
                auto [c, p1] = parse_rhs_expr(adv(p_));
                auto q = at_comma(p1)
                    ? error_at(p1, here(p1), prism_rtl::cat("`", w, "` takes its condition alone, with no error value after a comma (decisions.md D15): a failed guard under `~` raises `Prelude.Unmet` (D11), and a comma after a guard belongs to a call at the head of its condition, as in `require Clear g, from, corner`"))
                    : p1;
                return w == Text::lit("require")
                    ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SRequire{c}), q}
                    : std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SForbid{c}), q};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m73084_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m73084_5_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m73084_5_0 == Text::lit("while")) {
            if (m73084_5_1 == Text::lit("")) {
                auto [cond, p1] = parse_cond(adv(p_), true);
                auto [body, q] = parse_block_after_colon(p1);
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SWhile{cond, body}), q};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m73084_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m73084_6_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m73084_6_0 == Text::lit("return")) {
            if (m73084_6_1 == Text::lit("")) {
                auto p1 = out_of_scope(adv(p_), here(p_), Text::lit("`T monad:` blocks and `^Monad`"), Text::lit("`return` ends a monad block, which is out of this compiler"));
                auto [e, q] = parse_rhs_expr(p1);
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SReturn{e}), q};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        if (kind_at(p_, Nat(1u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{})) {
            return kind_at(p_, Nat(2u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{})
                ? ({
                auto [name, p1] = parse_sname(p_);
                auto [body, q] = parse_block_after_colon(p1);
                std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SWidget{crate::syntax::WidgetDecl{.name = name, .body = body, .span = to(start, body.span)}}), q};
            })
                : ({
                auto [sig, q] = parse_signature(p_);
                std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SSignature{sig}), q};
            });
        }
    }
    {
        return other_stmt(p_);
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::StmtKind, Ps>> StmtKindOf::cycle() const {
    const auto& p_ = this->p_;
    const auto& start = this->start;
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m73084_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m73084_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m73084_0_0 == Text::lit("emit")) && (m73084_0_1 == Text::lit(""));
    }) ? ({
        auto&& m73084_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m73084_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(start_parse_row(adv(p__1)), [=](std::tuple<crate::syntax::Row_, Ps> parse_row_73141) {
        return ({
            auto [r, q] = parse_row_73141;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SEmit{r}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m73084_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m73084_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m73084_1_0 == Text::lit("let")) && (m73084_1_1 == Text::lit(""));
    }) ? ({
        auto&& m73084_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m73084_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(start_parse_pattern(adv(p__1), false), [=](std::tuple<crate::syntax::Pattern_, Ps> parse_pattern_73230) {
        return ({
            auto [pattern, p1] = parse_pattern_73230;
            call_then(start_optional_annotation(p1), [=](std::tuple<std::optional<crate::syntax::Type>, Ps> optional_annotation_73284) {
            return ({
                auto [ty_opt, p2] = optional_annotation_73284;
                call_then(start_parse_rhs_expr(expect_op(p2, Text::lit("="))), [=](std::tuple<crate::syntax::Expr, Ps> parse_rhs_expr_73334) {
                return ({
                    auto [value, p3] = parse_rhs_expr_73334;
                    (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SLet{pattern, ty_opt, value}), p3}));
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m73084_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m73084_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m73084_2_0 == Text::lit("fn")) && (m73084_2_1 == Text::lit(""));
    }) ? ({
        auto&& m73084_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m73084_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(start_parse_fn_clause(p__1), [=](std::tuple<crate::syntax::FnClause, Ps> parse_fn_clause_73450) {
        return ({
            auto [f, q] = parse_fn_clause_73450;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SFn{f}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m73084_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m73084_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m73084_3_0 == Text::lit("ignore")) && (m73084_3_1 == Text::lit("")) && at_op(adv(p_), Text::lit("<-"));
    }) ? ({
        auto&& m73084_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m73084_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(start_parse_rhs_expr(adv(adv(p__1))), [=](std::tuple<crate::syntax::Expr, Ps> parse_rhs_expr_73556) {
        return ({
            auto [e, q] = parse_rhs_expr_73556;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SIgnore{e}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& w = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m73084_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m73084_4_1 == Text::lit("")) && ((w == Text::lit("require")) || (w == Text::lit("forbid")));
    }) ? ({
        auto&& w = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m73084_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(start_parse_rhs_expr(adv(p__1)), [=](std::tuple<crate::syntax::Expr, Ps> parse_rhs_expr_73849) {
        return ({
            auto [c, p1] = parse_rhs_expr_73849;
            auto q = at_comma(p1)
                ? error_at(p1, here(p1), prism_rtl::cat("`", w, "` takes its condition alone, with no error value after a comma (decisions.md D15): a failed guard under `~` raises `Prelude.Unmet` (D11), and a comma after a guard belongs to a call at the head of its condition, as in `require Clear g, from, corner`"))
                : p1;
            w == Text::lit("require")
            ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SRequire{c}), q})
            : prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SForbid{c}), q});
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m73084_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m73084_5_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m73084_5_0 == Text::lit("while")) && (m73084_5_1 == Text::lit(""));
    }) ? ({
        auto&& m73084_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m73084_5_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(start_parse_cond(adv(p__1), true), [=](std::tuple<crate::syntax::Cond, Ps> parse_cond_74305) {
        return ({
            auto [cond, p1] = parse_cond_74305;
            call_then(start_parse_block_after_colon(p1), [=](std::tuple<crate::syntax::Block, Ps> parse_block_after_colon_74355) {
            return ({
                auto [body, q] = parse_block_after_colon_74355;
                (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SWhile{cond, body}), q}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m73084_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m73084_6_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m73084_6_0 == Text::lit("return")) && (m73084_6_1 == Text::lit(""));
    }) ? ({
        auto&& m73084_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m73084_6_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p1 = out_of_scope(adv(p_), here(p_), Text::lit("`T monad:` blocks and `^Monad`"), Text::lit("`return` ends a monad block, which is out of this compiler"));
        call_then(start_parse_rhs_expr(p1), [=](std::tuple<crate::syntax::Expr, Ps> parse_rhs_expr_74601) {
        return ({
            auto [e, q] = parse_rhs_expr_74601;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SReturn{e}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        (kind_at(p_, Nat(1u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}));
    }) ? kind_at(p_, Nat(2u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{})
        ? ({
        auto [name, p1] = parse_sname(p_);
        auto start_1 = start;
        call_then(start_parse_block_after_colon(p1), [=](std::tuple<crate::syntax::Block, Ps> parse_block_after_colon_74848) {
        return ({
            auto [body, q] = parse_block_after_colon_74848;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SWidget{crate::syntax::WidgetDecl{.name = name, .body = body, .span = to(start_1, body.span)}}), q}));
        });
    });
    })
        : ({
        auto p__1 = p_;
        call_then(start_parse_signature(p__1), [=](std::tuple<crate::syntax::Signature, Ps> parse_signature_75003) {
        return ({
            auto [sig, q] = parse_signature_75003;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SSignature{sig}), q}));
        });
    });
    })
        : prism_rtl::more(prism_rtl::rc(OtherStmt(p_)));
    });
}


/// `Start StmtKindOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::StmtKind, Ps>> start_stmt_kind_of(Ps p_, crate::syntax::Range start) {
    return prism_rtl::make_rc<StmtKindOf>(p_, start);
}


/// OtherStmt: unbounded fn Ps -> ((StmtKind, Ps))
std::tuple<crate::syntax::StmtKind, Ps> other_stmt(const Ps& p_) {
    auto [upd, u] = parse_update_stmt(p_);
    auto [pattern, b] = parse_pattern(p_, true);
    return !u->bad
        ? std::tuple{upd, u}
        : (!b->bad) && at_op(b, Text::lit("<-"))
        ? ({
        auto [value, p1] = parse_rhs_expr(adv(b));
        auto [then_step_opt, p2] = at_kw(p1, Text::lit("then"))
            ? optional_rhs(adv(p1))
            : std::tuple{std::optional<crate::syntax::Expr>{}, p1};
        at_kw(p2, Text::lit("then"))
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{no_expr()}), error_at(p2, here(p2), Text::lit("`then` does not associate: a hold has one start and one step"))}
        : std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SBind{pattern, value, then_step_opt}), p2};
    })
        : ({
        auto [e, p1] = parse_rhs_expr(p_);
        at_op(p1, Text::lit("<-"))
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e}), error_at(p1, here(p1), Text::lit("the left side of `<-` is not a pattern"))}
        : at_kw(p1, Text::lit("then"))
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e}), error_at(p1, here(p1), Text::lit("`then` belongs to a hold: `$x <- start then step`"))}
        : std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e}), p1};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::StmtKind, Ps>> OtherStmt::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_update_stmt(p__1), [=](std::tuple<crate::syntax::StmtKind, Ps> parse_update_stmt_75244) {
        return ({
            auto [upd, u] = parse_update_stmt_75244;
            call_then(start_parse_pattern(p__1, true), [=](std::tuple<crate::syntax::Pattern_, Ps> parse_pattern_75287) {
            return ({
                auto [pattern, b] = parse_pattern_75287;
                !u->bad
                ? prism_rtl::finished(std::tuple{upd, u})
                : (!b->bad) && at_op(b, Text::lit("<-"))
                ? call_then(start_parse_rhs_expr(adv(b)), [=](std::tuple<crate::syntax::Expr, Ps> parse_rhs_expr_75408) {
                return ({
                    auto [value, p1] = parse_rhs_expr_75408;
                    auto [then_step_opt, p2] = at_kw(p1, Text::lit("then"))
                        ? optional_rhs(adv(p1))
                        : std::tuple{std::optional<crate::syntax::Expr>{}, p1};
                    at_kw(p2, Text::lit("then"))
                    ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{no_expr()}), error_at(p2, here(p2), Text::lit("`then` does not associate: a hold has one start and one step"))})
                    : prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SBind{pattern, value, then_step_opt}), p2});
                });
            })
                : call_then(start_parse_rhs_expr(p__1), [=](std::tuple<crate::syntax::Expr, Ps> parse_rhs_expr_75744) {
                return ({
                    auto [e, p1] = parse_rhs_expr_75744;
                    at_op(p1, Text::lit("<-"))
                    ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e}), error_at(p1, here(p1), Text::lit("the left side of `<-` is not a pattern"))})
                    : at_kw(p1, Text::lit("then"))
                    ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e}), error_at(p1, here(p1), Text::lit("`then` belongs to a hold: `$x <- start then step`"))})
                    : prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e}), p1});
                });
            });
            });
        });
        });
    });
}


/// `Start OtherStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::StmtKind, Ps>> start_other_stmt(Ps p_) {
    return prism_rtl::make_rc<OtherStmt>(p_);
}


/// OptionalRhs: unbounded fn Ps -> ((?Expr, Ps))
std::tuple<std::optional<crate::syntax::Expr>, Ps> optional_rhs(const Ps& p_) {
    auto [e, q] = parse_rhs_expr(p_);
    return std::tuple{std::optional(e), q};
}


prism_rtl::Turn<std::tuple<std::optional<crate::syntax::Expr>, Ps>> OptionalRhs::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_rhs_expr(p__1), [=](std::tuple<crate::syntax::Expr, Ps> parse_rhs_expr_76102) {
        return ({
            auto [e, q] = parse_rhs_expr_76102;
            (prism_rtl::finished(std::tuple{std::optional(e), q}));
        });
    });
}


/// `Start OptionalRhs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::Expr>, Ps>> start_optional_rhs(Ps p_) {
    return prism_rtl::make_rc<OptionalRhs>(p_);
}


/// ParseUpdateStmt: unbounded fn Ps -> ((StmtKind, Ps))
std::tuple<crate::syntax::StmtKind, Ps> parse_update_stmt(const Ps& p_) {
    auto [target, p1] = parse_reference(p_);
    auto op = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = kind(p1);
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m)) {
            auto&& o = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
            _v.set(o);
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    return p1->bad || (!(((((op == Text::lit("<=")) || (op == Text::lit("+="))) || (op == Text::lit("-="))) || (op == Text::lit("*="))) || (op == Text::lit("/="))))
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{no_expr()}), fail(p1)}
        : ({
        auto [value, q] = parse_rhs_expr(adv(p1));
        op == Text::lit("<=")
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SSet{target, value}), q}
        : std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SAccum{target, op, value}), q};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::StmtKind, Ps>> ParseUpdateStmt::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_reference(p__1), [=](std::tuple<crate::syntax::Expr, Ps> parse_reference_76416) {
        return ({
            auto [target, p1] = parse_reference_76416;
            auto op = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = kind(p1);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m)) {
                    auto&& o = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
                    _v.set(o);
                    goto _done;
                }
                {
                    _v.set(Text::lit(""));
                    goto _done;
                }
            _done:
                _v.take();
            });
            p1->bad || (!(((((op == Text::lit("<=")) || (op == Text::lit("+="))) || (op == Text::lit("-="))) || (op == Text::lit("*="))) || (op == Text::lit("/="))))
            ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{no_expr()}), fail(p1)})
            : call_then(start_parse_rhs_expr(adv(p1)), [=](std::tuple<crate::syntax::Expr, Ps> parse_rhs_expr_76664) {
            return ({
                auto [value, q] = parse_rhs_expr_76664;
                op == Text::lit("<=")
                ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SSet{target, value}), q})
                : prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SAccum{target, op, value}), q});
            });
        });
        });
    });
}


/// `Start ParseUpdateStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::StmtKind, Ps>> start_parse_update_stmt(Ps p_) {
    return prism_rtl::make_rc<ParseUpdateStmt>(p_);
}


/// ParseReference: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, Ps> parse_reference(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if (crate::syntax::lexer::has_prefix(n.sigils, Text::lit("&"))) {
            auto start = here(p_);
            auto [name, p1] = parse_sname(p_);
            return is_upper_name(name)
                ? ({
                auto p2 = out_of_scope(p1, name.span, Text::lit("named lenses `&Home` and `Over`"), prism_rtl::cat("the named lens `", name_text(name), "` is out of this compiler; write its path, `&_.score.home`"));
                auto [inner, q] = parse_reference(p2);
                auto callee = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name})), .span = start};
                std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(callee), Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = inner, .span = inner.span}}), false, false})), .span = to(start, inner.span)}, q};
            })
                : lens_steps(crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name})), .span = name.span}, p1);
        }
    }
    {
        return std::tuple{no_expr(), fail(p_)};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, Ps>> ParseReference::cycle() const {
    const auto& p_ = this->p_;
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        crate::syntax::lexer::has_prefix(n.sigils, Text::lit("&"));
    }) ? ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ({
        auto start = here(p_);
        auto [name, p1] = parse_sname(p_);
        is_upper_name(name)
        ? ({
        auto p2 = out_of_scope(p1, name.span, Text::lit("named lenses `&Home` and `Over`"), prism_rtl::cat("the named lens `", name_text(name), "` is out of this compiler; write its path, `&_.score.home`"));
        call_then(start_parse_reference(p2), [=](std::tuple<crate::syntax::Expr, Ps> parse_reference_77348) {
        return ({
            auto [inner, q] = parse_reference_77348;
            auto callee = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name})), .span = start};
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(callee), Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = inner, .span = inner.span}}), false, false})), .span = to(start, inner.span)}, q}));
        });
    });
    })
        : prism_rtl::finished(lens_steps(crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name})), .span = name.span}, p1));
    });
    })
        : prism_rtl::finished(std::tuple{no_expr(), fail(p_)});
    });
}


/// `Start ParseReference, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, Ps>> start_parse_reference(Ps p_) {
    return prism_rtl::make_rc<ParseReference>(p_);
}


/// LensSteps: unbounded fn Expr, Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, Ps> lens_steps(const crate::syntax::Expr& e0, const Ps& p0) {
    std::tuple<crate::syntax::Expr, Ps> this_ = std::tuple{e0, p0};
    crate::syntax::Expr e = e0;
    Ps p_ = p0;
    bool going = true;
    while (going && (!p_.bad)) {
        ({
            __label__ _done;
            prism_rtl::Slot<Unit> _v;
            auto&& _m = kind(p_);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(_m) && !prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(_m).a0) {
                _v.set(({
                    auto p1 = adv(p_);
                    auto t = here(p1);
                    ({
                        __label__ _done;
                        prism_rtl::Slot<Unit> _v;
                        auto&& _m = kind(p1);
                        if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
                            auto&& f = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
                            if ((f.sigils == Text::lit("")) && (f.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) {
                                _v.set(({
                                    e = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(e), Text::lit(""), crate::syntax::Ident{.name = or_(index(f->path_, Nat(0u)), Text::lit("")), .span = t}})), .span = to(e.span, t)};
                                    p_ = adv(p1);
                                    Unit{};
                                }));
                                goto _done;
                            }
                        }
                        if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
                            auto&& u77981_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
                            if (u77981_1_0 == Text::lit("key")) {
                                _v.set(({
                                    e = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(e), Text::lit(""), crate::syntax::Ident{.name = Text::lit("key"), .span = t}})), .span = to(e.span, t)};
                                    p_ = adv(p1);
                                    Unit{};
                                }));
                                goto _done;
                            }
                        }
                        {
                            _v.set(({
                                p_ = fail(p1);
                                Unit{};
                            }));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && !prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a1) {
                auto&& u77862_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
                if (u77862_1_0 == Text::lit("[")) {
                    if (tk(p_).touches) {
                        _v.set(({
                            auto [index, p1] = parse_expr(adv(p_));
                            auto p2 = expect_close(p1, Text::lit("["));
                            e = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIndex{prism_rtl::rc(e), prism_rtl::rc(index)})), .span = to(e.span, crate::syntax::parser::prev(p2))};
                            p_ = p2;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
            }
            {
                _v.set(({
                    going = false;
                    Unit{};
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    this_ = std::tuple{e, p_};
    return this_;
}


/// ParseType: unbounded fn Ps -> ((Type, Ps))
std::tuple<crate::syntax::Type, Ps> parse_type(const Ps& p_) {
    auto start = here(p_);
    auto color_var = is_plain_lower_one(kind(p_)) && is_fn_kw(kind_at(p_, Nat(1u)));
    auto [color, p1] = at_kw(p_, Text::lit("unbounded"))
        ? std::tuple{crate::syntax::Color(crate::syntax::Color::Unbounded{}), adv(p_)}
        : color_var
        ? color_var_of(p_)
        : std::tuple{crate::syntax::Color(crate::syntax::Color::Bounded{}), p_};
    return at_kw(p1, Text::lit("fn"))
        ? ({
        auto p2 = adv(p1);
        auto [params, p3] = at_op(p2, Text::lit("->"))
            ? std::tuple{Array<crate::syntax::Type>{}, p2}
            : commas(p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_emit_type(a0)); })));
        auto [result, p4] = parse_type(expect_op(p3, Text::lit("->")));
        std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TFn{color, params, prism_rtl::rc(result)})), .span = to(start, result.span)}, p4};
    })
        : color != crate::syntax::Color(crate::syntax::Color::Bounded{})
        ? std::tuple{no_type(), error_here(p1, Text::lit("a color (`unbounded`, or a color variable) is written before a function type's `fn`"))}
        : ({
        auto [t, q] = parse_emit_type(p1);
        at_op(q, Text::lit("->"))
        ? std::tuple{t, error_at(q, here(q), Text::lit("a function type begins with `fn`: `fn A -> B`"))}
        : std::tuple{t, q};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, Ps>> ParseType::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto color_var = is_plain_lower_one(kind(p_)) && is_fn_kw(kind_at(p_, Nat(1u)));
    auto [color, p1] = at_kw(p_, Text::lit("unbounded"))
        ? std::tuple{crate::syntax::Color(crate::syntax::Color::Unbounded{}), adv(p_)}
        : color_var
        ? color_var_of(p_)
        : std::tuple{crate::syntax::Color(crate::syntax::Color::Bounded{}), p_};
    return at_kw(p1, Text::lit("fn"))
        ? ({
        auto p2 = adv(p1);
        auto [params, p3] = at_op(p2, Text::lit("->"))
            ? std::tuple{Array<crate::syntax::Type>{}, p2}
            : commas(p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_emit_type(a0)); })));
        call_then(start_parse_type(expect_op(p3, Text::lit("->"))), [=](std::tuple<crate::syntax::Type, Ps> parse_type_80346) {
        return ({
            auto [result, p4] = parse_type_80346;
            (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TFn{color, params, prism_rtl::rc(result)})), .span = to(start, result.span)}, p4}));
        });
    });
    })
        : color != crate::syntax::Color(crate::syntax::Color::Bounded{})
        ? prism_rtl::finished(std::tuple{no_type(), error_here(p1, Text::lit("a color (`unbounded`, or a color variable) is written before a function type's `fn`"))})
        : call_then(start_parse_emit_type(p1), [=](std::tuple<crate::syntax::Type, Ps> parse_emit_type_80639) {
        return ({
            auto [t, q] = parse_emit_type_80639;
            at_op(q, Text::lit("->"))
            ? prism_rtl::finished(std::tuple{t, error_at(q, here(q), Text::lit("a function type begins with `fn`: `fn A -> B`"))})
            : prism_rtl::finished(std::tuple{t, q});
        });
    });
}


/// `Start ParseType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, Ps>> start_parse_type(Ps p_) {
    return prism_rtl::make_rc<ParseType>(p_);
}


/// IsPlainLowerOne: fn TokKind -> Bool
bool is_plain_lower_one(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(tok_kind0)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(tok_kind0).a0;
        return ((n.sigils == Text::lit("")) && (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) && (len(n->path_) == Nat(1u));
    }
    {
        return false;
    }
}


/// IsFnKw: fn TokKind -> Bool
bool is_fn_kw(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(tok_kind0)) {
        auto&& c0_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(tok_kind0).a0;
        if (c0_0_0 == Text::lit("fn")) {
            return true;
        }
    }
    {
        return false;
    }
}


/// ColorVarOf: fn Ps -> ((Color, Ps))
std::tuple<crate::syntax::Color, Ps> color_var_of(const Ps& p_) {
    auto [i, q] = parse_ident(p_);
    return std::tuple{crate::syntax::Color(crate::syntax::Color::ColorVar{i}), q};
}


/// ParseEmitType: unbounded fn Ps -> ((Type, Ps))
std::tuple<crate::syntax::Type, Ps> parse_emit_type(const Ps& p_) {
    auto start = here(p_);
    auto [t, p1] = parse_union_type(p_);
    return at_kw(p1, Text::lit("emit"))
        ? ({
        auto [r, q] = parse_union_type(adv(p1));
        std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TEmit{prism_rtl::rc(t), prism_rtl::rc(r)})), .span = to(start, r.span)}, q};
    })
        : std::tuple{t, p1};
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, Ps>> ParseEmitType::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto p__1 = p_;
    return call_then(start_parse_union_type(p__1), [=](std::tuple<crate::syntax::Type, Ps> parse_union_type_81244) {
        return ({
            auto [t, p1] = parse_union_type_81244;
            at_kw(p1, Text::lit("emit"))
            ? call_then(start_parse_union_type(adv(p1)), [=](std::tuple<crate::syntax::Type, Ps> parse_union_type_81308) {
            return ({
                auto [r, q] = parse_union_type_81308;
                (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TEmit{prism_rtl::rc(t), prism_rtl::rc(r)})), .span = to(start, r.span)}, q}));
            });
        })
            : prism_rtl::finished(std::tuple{t, p1});
        });
    });
}


/// `Start ParseEmitType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, Ps>> start_parse_emit_type(Ps p_) {
    return prism_rtl::make_rc<ParseEmitType>(p_);
}


/// ParseUnionType: unbounded fn Ps -> ((Type, Ps))
std::tuple<crate::syntax::Type, Ps> parse_union_type(const Ps& p_) {
    auto start = here(p_);
    auto [first_, p1] = parse_map_type(p_);
    return kind(p1) != crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{})
        ? std::tuple{first_, p1}
        : ({
        auto r = ({
            std::tuple<Array<crate::syntax::Type>, Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<crate::syntax::Type> terms = Array(std::vector{first_});
            Ps q = p1;
            while ((kind(q) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{})) && (!q.bad)) {
                auto [t, q2] = parse_map_type(adv(q));
                terms = crate::prelude::push(terms, t);
                q = q2;
            }
            this_ = std::tuple{terms, q};
            this_;
        });
        auto [terms, q] = r;
        std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TRowUnion{terms})), .span = to(start, crate::syntax::parser::prev(q))}, q};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, Ps>> ParseUnionType::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto p__1 = p_;
    return call_then(start_parse_map_type(p__1), [=](std::tuple<crate::syntax::Type, Ps> parse_map_type_81533) {
        return ({
            auto [first_, p1] = parse_map_type_81533;
            kind(p1) != crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{})
            ? prism_rtl::finished(std::tuple{first_, p1})
            : ({
            std::tuple<Array<crate::syntax::Type>, Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<crate::syntax::Type> terms = Array(std::vector{first_});
            Ps q = p1;
            auto start_2 = start;
            call_then(loop_job(std::tuple{this_, q, terms}, [=](std::tuple<std::tuple<Array<crate::syntax::Type>, Ps>, Ps, Array<crate::syntax::Type>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q = std::get<1>(_p0);
            auto terms = std::get<2>(_p0);
            return (kind(q) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{})) && (!q->bad)
                ? ({
                auto [t, q2] = parse_map_type(adv(q));
                terms = crate::prelude::push(terms, t);
                q = q2;
                Expected<std::tuple<std::tuple<Array<crate::syntax::Type>, Ps>, Ps, Array<crate::syntax::Type>>, std::tuple<std::tuple<Array<crate::syntax::Type>, Ps>, Ps, Array<crate::syntax::Type>>>(std::tuple{this_, q, terms});
            })
                : Expected<std::tuple<std::tuple<Array<crate::syntax::Type>, Ps>, Ps, Array<crate::syntax::Type>>, std::tuple<std::tuple<Array<crate::syntax::Type>, Ps>, Ps, Array<crate::syntax::Type>>>(unexpected(std::tuple{this_, q, terms}));
        }), [=](std::tuple<std::tuple<Array<crate::syntax::Type>, Ps>, Ps, Array<crate::syntax::Type>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q = std::get<1>(_p0);
            auto terms = std::get<2>(_p0);
            return ({
                this_ = std::tuple{terms, q};
                auto r = this_;
                auto [terms, q] = r;
                (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TRowUnion{terms})), .span = to(start_2, crate::syntax::parser::prev(q))}, q}));
            });
        });
        });
        });
    });
}


/// `Start ParseUnionType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, Ps>> start_parse_union_type(Ps p_) {
    return prism_rtl::make_rc<ParseUnionType>(p_);
}


/// ParseMapType: unbounded fn Ps -> ((Type, Ps))
std::tuple<crate::syntax::Type, Ps> parse_map_type(const Ps& p_) {
    auto start = here(p_);
    auto [k, p1] = parse_sigiled_type(p_);
    return at_op(p1, Text::lit("==>"))
        ? ({
        auto [value, q] = parse_map_type(adv(p1));
        std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TMap{prism_rtl::rc(k), prism_rtl::rc(value)})), .span = to(start, value.span)}, q};
    })
        : std::tuple{k, p1};
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, Ps>> ParseMapType::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto p__1 = p_;
    return call_then(start_parse_sigiled_type(p__1), [=](std::tuple<crate::syntax::Type, Ps> parse_sigiled_type_82113) {
        return ({
            auto [k, p1] = parse_sigiled_type_82113;
            at_op(p1, Text::lit("==>"))
            ? call_then(start_parse_map_type(adv(p1)), [=](std::tuple<crate::syntax::Type, Ps> parse_map_type_82182) {
            return ({
                auto [value, q] = parse_map_type_82182;
                (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TMap{prism_rtl::rc(k), prism_rtl::rc(value)})), .span = to(start, value.span)}, q}));
            });
        })
            : prism_rtl::finished(std::tuple{k, p1});
        });
    });
}


/// `Start ParseMapType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, Ps>> start_parse_map_type(Ps p_) {
    return prism_rtl::make_rc<ParseMapType>(p_);
}


/// ParseSigiledType: unbounded fn Ps -> ((Type, Ps))
std::tuple<crate::syntax::Type, Ps> parse_sigiled_type(const Ps& p_) {
    auto start = here(p_);
    auto [sigils, p1] = free_sigil_run(p_);
    auto [inner, q] = parse_app_type(p1);
    return sigils == Text::lit("")
        ? std::tuple{inner, q}
        : std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TSigiled{sigils, prism_rtl::rc(inner)})), .span = to(start, inner.span)}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, Ps>> ParseSigiledType::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto [sigils, p1] = free_sigil_run(p_);
    return call_then(start_parse_app_type(p1), [=](std::tuple<crate::syntax::Type, Ps> parse_app_type_82455) {
        return ({
            auto [inner, q] = parse_app_type_82455;
            sigils == Text::lit("")
            ? prism_rtl::finished(std::tuple{inner, q})
            : prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TSigiled{sigils, prism_rtl::rc(inner)})), .span = to(start, inner.span)}, q});
        });
    });
}


/// `Start ParseSigiledType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, Ps>> start_parse_sigiled_type(Ps p_) {
    return prism_rtl::make_rc<ParseSigiledType>(p_);
}


/// FreeSigilRun: fn Ps -> ((Text, Ps))
std::tuple<Text, Ps> free_sigil_run(const Ps& p0) {
    std::tuple<Text, Ps> this_ = std::tuple{Text::lit(""), p0};
    Text sigils = Text::lit("");
    Ps p_ = p0;
    Nat fuel = len(p0.toks);
    while (true) {
        auto&& _m = fuel.checked_sub(Nat(1u));
        if (!(prism_rtl::is_some(_m))) break;
        auto&& left = prism_rtl::some_of(_m);
        fuel = left;
        {
            auto&& _m = kind(p_);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
                auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
                sigils = prism_rtl::cat(sigils, s);
                p_ = adv(p_);
            } else {
                fuel = Nat(0u);
            }
        }
    }
    this_ = std::tuple{sigils, p_};
    return this_;
}


/// ParseAppType: unbounded fn Ps -> ((Type, Ps))
std::tuple<crate::syntax::Type, Ps> parse_app_type(const Ps& p_) {
    auto start = here(p_);
    auto [head, p1] = parse_type_atom(p_);
    auto&& _m = head.kind;
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& name = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m83086_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        if (m83086_0_1.size() == 0u) {
            if (type_atom_starts_here(p1)) {
                auto r = ({
                    std::tuple<Array<crate::syntax::Type>, Ps> this_ = std::tuple{Array<crate::syntax::Type>{}, p1};
                    Array<crate::syntax::Type> args = Array<crate::syntax::Type>{};
                    Ps q = p1;
                    while (type_atom_starts_here(q) && (!q.bad)) {
                        auto [a, q2] = parse_type_atom(q);
                        args = crate::prelude::push(args, a);
                        q = q2;
                    }
                    this_ = std::tuple{args, q};
                    this_;
                });
                auto [args, q] = r;
                return std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TName{name, args})), .span = to(start, crate::syntax::parser::prev(q))}, q};
            }
        }
    }
    {
        return std::tuple{head, p1};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, Ps>> ParseAppType::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto p__1 = p_;
    return call_then(start_parse_type_atom(p__1), [=](std::tuple<crate::syntax::Type, Ps> parse_type_atom_83066) {
        return ({
            auto [head, p1] = parse_type_atom_83066;
            ({
            auto&& _m = head.kind;
            prism_rtl::is<crate::syntax::TypeKind::TName>(_m) && ({
            auto&& name = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
            auto&& m83086_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
            (m83086_0_1.size() == 0u) && type_atom_starts_here(p1);
        }) ? ({
            auto&& name = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
            auto&& m83086_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
            ({
            std::tuple<Array<crate::syntax::Type>, Ps> this_ = std::tuple{Array<crate::syntax::Type>{}, p1};
            Array<crate::syntax::Type> args = Array<crate::syntax::Type>{};
            Ps q = p1;
            auto name_2 = name;
            auto start_3 = start;
            call_then(loop_job(std::tuple{this_, args, q}, [=](std::tuple<std::tuple<Array<crate::syntax::Type>, Ps>, Array<crate::syntax::Type>, Ps> _p0) {
            auto this_ = std::get<0>(_p0);
            auto args = std::get<1>(_p0);
            auto q = std::get<2>(_p0);
            return type_atom_starts_here(q) && (!q->bad)
                ? ({
                auto [a, q2] = parse_type_atom(q);
                args = crate::prelude::push(args, a);
                q = q2;
                Expected<std::tuple<std::tuple<Array<crate::syntax::Type>, Ps>, Array<crate::syntax::Type>, Ps>, std::tuple<std::tuple<Array<crate::syntax::Type>, Ps>, Array<crate::syntax::Type>, Ps>>(std::tuple{this_, args, q});
            })
                : Expected<std::tuple<std::tuple<Array<crate::syntax::Type>, Ps>, Array<crate::syntax::Type>, Ps>, std::tuple<std::tuple<Array<crate::syntax::Type>, Ps>, Array<crate::syntax::Type>, Ps>>(unexpected(std::tuple{this_, args, q}));
        }), [=](std::tuple<std::tuple<Array<crate::syntax::Type>, Ps>, Array<crate::syntax::Type>, Ps> _p0) {
            auto this_ = std::get<0>(_p0);
            auto args = std::get<1>(_p0);
            auto q = std::get<2>(_p0);
            return ({
                this_ = std::tuple{args, q};
                auto r = this_;
                auto [args, q] = r;
                (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TName{name_2, args})), .span = to(start_3, crate::syntax::parser::prev(q))}, q}));
            });
        });
        });
        })
            : prism_rtl::finished(std::tuple{head, p1});
        });
        });
    });
}


/// `Start ParseAppType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, Ps>> start_parse_app_type(Ps p_) {
    return prism_rtl::make_rc<ParseAppType>(p_);
}


/// TypeAtomStartsHere: fn Ps -> Bool
bool type_atom_starts_here(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        return (w == Text::lit("unit")) || (w == Text::lit("any"));
    }
    {
        return false;
    }
}


/// ParseTypeAtom: unbounded fn Ps -> ((Type, Ps))
std::tuple<crate::syntax::Type, Ps> parse_type_atom(const Ps& p_) {
    auto start = here(p_);
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
        return parse_sigiled_type(p_);
    }
    {
        auto [t, p1] = type_atom_body(p_, start);
        return kind(p1) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KNonEmpty{})
            ? ({
            auto m = here(p1);
            auto q = out_of_scope(adv(p1), m, Text::lit("non-empty arrays"), Text::lit("the non-empty array type `[a]+` is out of this compiler"));
            std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TNonEmpty{prism_rtl::rc(t)})), .span = to(start, m)}, q};
        })
            : std::tuple{t, p1};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, Ps>> ParseTypeAtom::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m) ? prism_rtl::more(prism_rtl::rc(ParseSigiledType(p_)))
        : ({
        auto p__1 = p_;
        call_then(start_type_atom_body(p__1, start), [=](std::tuple<crate::syntax::Type, Ps> type_atom_body_84149) {
        return ({
            auto [t, p1] = type_atom_body_84149;
            kind(p1) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KNonEmpty{})
            ? ({
            auto m = here(p1);
            auto q = out_of_scope(adv(p1), m, Text::lit("non-empty arrays"), Text::lit("the non-empty array type `[a]+` is out of this compiler"));
            (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TNonEmpty{prism_rtl::rc(t)})), .span = to(start, m)}, q}));
        })
            : prism_rtl::finished(std::tuple{t, p1});
        });
    });
    });
    });
}


/// `Start ParseTypeAtom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, Ps>> start_parse_type_atom(Ps p_) {
    return prism_rtl::make_rc<ParseTypeAtom>(p_);
}


/// TypeAtomBody: unbounded fn Ps, Range -> ((Type, Ps))
std::tuple<crate::syntax::Type, Ps> type_atom_body(const Ps& p_, const crate::syntax::Range& start) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        auto name = crate::syntax::SName{.sigils = n.sigils, .path_ = n->path_, .span = start};
        return (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseTopic{})) || (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseHole{}))
            ? std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::THole{name})), .span = start}, adv(p_)}
            : std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TName{name, Array<crate::syntax::Type>{}})), .span = start}, check_type_name_scope(adv(p_), name)};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m84545_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& sigils = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m84545_1_0 == Text::lit("unit")) {
            return std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TUnit{sigils})), .span = start}, adv(p_)};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m84545_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m84545_2_0 == Text::lit("any")) {
            auto [tr, q] = parse_trait_ref(adv(p_));
            return std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TAny{tr})), .span = to(start, crate::syntax::parser::prev(q))}, q};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        auto&& path_ = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        return std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TFamily{crate::syntax::QualName{.path_ = path_, .span = start}})), .span = start}, adv(p_)};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KAbsent>(_m)) {
        return std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TAbsent{})), .span = start}, out_of_scope(adv(p_), start, Text::lit("sparse tuples"), Text::lit("a sparse tuple type is out of this compiler"))};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m84545_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m84545_5_0 == Text::lit("(")) {
            return at_double_open(p_, Text::lit("("))
                ? ({
                auto [elems, p1] = commas(open_double(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_type(a0)); })));
                auto p2 = close_double(p1, Text::lit("("));
                std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TTuple{elems})), .span = to(start, crate::syntax::parser::prev(p2))}, p2};
            })
                : ({
                auto [inner, p1] = parse_type(adv(p_));
                auto p2 = expect_close(p1, Text::lit("("));
                std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TGroup{prism_rtl::rc(inner)})), .span = to(start, crate::syntax::parser::prev(p2))}, p2};
            });
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m84545_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m84545_6_0 == Text::lit("[")) {
            auto doubled = at_double_open(p_, Text::lit("["));
            auto [elem, p1] = parse_type(doubled ? open_double(p_) : adv(p_));
            auto p2 = doubled
                ? close_double(p1, Text::lit("["))
                : expect_close(p1, Text::lit("["));
            return std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TArray{prism_rtl::rc(elem), doubled})), .span = to(start, crate::syntax::parser::prev(p2))}, p2};
        }
    }
    {
        return std::tuple{no_type(), error_here(p_, Text::lit("expected a type"))};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Type, Ps>> TypeAtomBody::cycle() const {
    const auto& p_ = this->p_;
    const auto& start = this->start;
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ({
        auto name = crate::syntax::SName{.sigils = n.sigils, .path_ = n->path_, .span = start};
        (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseTopic{})) || (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseHole{}))
        ? prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::THole{name})), .span = start}, adv(p_)})
        : prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TName{name, Array<crate::syntax::Type>{}})), .span = start}, check_type_name_scope(adv(p_), name)});
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m84545_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& sigils = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m84545_1_0 == Text::lit("unit"));
    }) ? ({
        auto&& m84545_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& sigils = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TUnit{sigils})), .span = start}, adv(p_)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m84545_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m84545_2_0 == Text::lit("any"));
    }) ? ({
        auto&& m84545_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto [tr, q] = parse_trait_ref(adv(p_));
        (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TAny{tr})), .span = to(start, crate::syntax::parser::prev(q))}, q}));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m) ? ({
        auto&& path_ = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TFamily{crate::syntax::QualName{.path_ = path_, .span = start}})), .span = start}, adv(p_)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KAbsent>(_m) ? prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TAbsent{})), .span = start}, out_of_scope(adv(p_), start, Text::lit("sparse tuples"), Text::lit("a sparse tuple type is out of this compiler"))})
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && ({
        auto&& m84545_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        (m84545_5_0 == Text::lit("("));
    }) ? ({
        auto&& m84545_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        at_double_open(p_, Text::lit("("))
        ? ({
        auto p__1 = p_;
        auto start_2 = start;
        call_then(start_commas(open_double(p__1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_type(a0)); }))), [=](std::tuple<Array<crate::syntax::Type>, Ps> commas_85506) {
        return ({
            auto [elems, p1] = commas_85506;
            auto p2 = close_double(p1, Text::lit("("));
            (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TTuple{elems})), .span = to(start_2, crate::syntax::parser::prev(p2))}, p2}));
        });
    });
    })
        : ({
        auto p__1 = p_;
        auto start_2 = start;
        call_then(start_parse_type(adv(p__1)), [=](std::tuple<crate::syntax::Type, Ps> parse_type_85700) {
        return ({
            auto [inner, p1] = parse_type_85700;
            auto p2 = expect_close(p1, Text::lit("("));
            (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TGroup{prism_rtl::rc(inner)})), .span = to(start_2, crate::syntax::parser::prev(p2))}, p2}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && ({
        auto&& m84545_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        (m84545_6_0 == Text::lit("["));
    }) ? ({
        auto&& m84545_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        ({
        auto doubled = at_double_open(p_, Text::lit("["));
        auto p__1 = p_;
        auto start_2 = start;
        call_then(start_parse_type(doubled ? open_double(p__1) : adv(p__1)), [=](std::tuple<crate::syntax::Type, Ps> parse_type_85925) {
        return ({
            auto [elem, p1] = parse_type_85925;
            auto p2 = doubled
                ? close_double(p1, Text::lit("["))
                : expect_close(p1, Text::lit("["));
            (prism_rtl::finished(std::tuple{crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TArray{prism_rtl::rc(elem), doubled})), .span = to(start_2, crate::syntax::parser::prev(p2))}, p2}));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{no_type(), error_here(p_, Text::lit("expected a type"))});
    });
}


/// `Start TypeAtomBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Type, Ps>> start_type_atom_body(Ps p_, crate::syntax::Range start) {
    return prism_rtl::make_rc<TypeAtomBody>(p_, start);
}


/// ParseBounds: unbounded fn Ps -> (([Bound], Ps))
std::tuple<Array<crate::syntax::Bound>, Ps> parse_bounds(const Ps& p0) {
    std::tuple<Array<crate::syntax::Bound>, Ps> this_ = std::tuple{Array<crate::syntax::Bound>{}, p0};
    Array<crate::syntax::Bound> bounds = Array<crate::syntax::Bound>{};
    Ps p_ = p0;
    bool going = true;
    while (going && (!p_.bad)) {
        auto [b, q] = parse_bound(p_);
        bounds = crate::prelude::push(bounds, b);
        p_ = q;
        if ((at_comma(p_) && is_name_kind(kind_at(p_, Nat(1u)))) && (kind_at(p_, Nat(2u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}))) {
            p_ = adv(p_);
        } else  {
            going = false;
        }
    }
    this_ = std::tuple{bounds, p_};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Bound>, Ps>> ParseBounds::cycle() const {
    const auto& p0 = this->p0;
    std::tuple<Array<crate::syntax::Bound>, Ps> this_ = std::tuple{Array<crate::syntax::Bound>{}, p0};
    Array<crate::syntax::Bound> bounds = Array<crate::syntax::Bound>{};
    Ps p_ = p0;
    bool going = true;
    return call_then(loop_job(std::tuple{this_, bounds, going, p_}, [=](std::tuple<std::tuple<Array<crate::syntax::Bound>, Ps>, Array<crate::syntax::Bound>, bool, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto bounds = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto p_ = std::get<3>(_p0);
        return going && (!p_->bad)
            ? ({
            auto [b, q] = parse_bound(p_);
            bounds = crate::prelude::push(bounds, b);
            p_ = q;
            if ((at_comma(p_) && is_name_kind(kind_at(p_, Nat(1u)))) && (kind_at(p_, Nat(2u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}))) {
                p_ = adv(p_);
            } else  {
                going = false;
            }
            Expected<std::tuple<std::tuple<Array<crate::syntax::Bound>, Ps>, Array<crate::syntax::Bound>, bool, Ps>, std::tuple<std::tuple<Array<crate::syntax::Bound>, Ps>, Array<crate::syntax::Bound>, bool, Ps>>(std::tuple{this_, bounds, going, p_});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::Bound>, Ps>, Array<crate::syntax::Bound>, bool, Ps>, std::tuple<std::tuple<Array<crate::syntax::Bound>, Ps>, Array<crate::syntax::Bound>, bool, Ps>>(unexpected(std::tuple{this_, bounds, going, p_}));
    }), [=](std::tuple<std::tuple<Array<crate::syntax::Bound>, Ps>, Array<crate::syntax::Bound>, bool, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto bounds = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto p_ = std::get<3>(_p0);
        return ({
            this_ = std::tuple{bounds, p_};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start ParseBounds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Bound>, Ps>> start_parse_bounds(Ps p0) {
    return prism_rtl::make_rc<ParseBounds>(p0);
}


/// IsNameKind: fn TokKind -> Bool
bool is_name_kind(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// IsTraitKind: fn TokKind -> Bool
bool is_trait_kind(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTrait>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// ParseBound: unbounded fn Ps -> ((Bound, Ps))
std::tuple<crate::syntax::Bound, Ps> parse_bound(const Ps& p_) {
    auto start = here(p_);
    auto [var, p1] = parse_ident(p_);
    auto [first_, p2] = parse_trait_ref(expect_colon(p1));
    auto r = ({
        std::tuple<Array<crate::syntax::TraitRef>, Ps> this_ = std::tuple{Array(std::vector{first_}), p2};
        Array<crate::syntax::TraitRef> traits = Array(std::vector{first_});
        Ps q = p2;
        while ((at_comma(q) && is_trait_kind(kind_at(q, Nat(1u)))) && (!q.bad)) {
            auto [t, q2] = parse_trait_ref(adv(q));
            traits = crate::prelude::push(traits, t);
            q = q2;
        }
        this_ = std::tuple{traits, q};
        this_;
    });
    auto [traits, q] = r;
    return std::tuple{crate::syntax::Bound{.var = var, .traits = traits, .span = to(start, crate::syntax::parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Bound, Ps>> ParseBound::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto [var, p1] = parse_ident(p_);
    auto [first_, p2] = parse_trait_ref(expect_colon(p1));
    std::tuple<Array<crate::syntax::TraitRef>, Ps> this_ = std::tuple{Array(std::vector{first_}), p2};
    Array<crate::syntax::TraitRef> traits = Array(std::vector{first_});
    Ps q = p2;
    auto start_1 = start;
    auto var_2 = var;
    return call_then(loop_job(std::tuple{this_, q, traits}, [=](std::tuple<std::tuple<Array<crate::syntax::TraitRef>, Ps>, Ps, Array<crate::syntax::TraitRef>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto q = std::get<1>(_p0);
        auto traits = std::get<2>(_p0);
        return (at_comma(q) && is_trait_kind(kind_at(q, Nat(1u)))) && (!q->bad)
            ? ({
            auto [t, q2] = parse_trait_ref(adv(q));
            traits = crate::prelude::push(traits, t);
            q = q2;
            Expected<std::tuple<std::tuple<Array<crate::syntax::TraitRef>, Ps>, Ps, Array<crate::syntax::TraitRef>>, std::tuple<std::tuple<Array<crate::syntax::TraitRef>, Ps>, Ps, Array<crate::syntax::TraitRef>>>(std::tuple{this_, q, traits});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::TraitRef>, Ps>, Ps, Array<crate::syntax::TraitRef>>, std::tuple<std::tuple<Array<crate::syntax::TraitRef>, Ps>, Ps, Array<crate::syntax::TraitRef>>>(unexpected(std::tuple{this_, q, traits}));
    }), [=](std::tuple<std::tuple<Array<crate::syntax::TraitRef>, Ps>, Ps, Array<crate::syntax::TraitRef>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto q = std::get<1>(_p0);
        auto traits = std::get<2>(_p0);
        return ({
            this_ = std::tuple{traits, q};
            auto r = this_;
            auto [traits, q] = r;
            (prism_rtl::finished(std::tuple{crate::syntax::Bound{.var = var_2, .traits = traits, .span = to(start_1, crate::syntax::parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseBound, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Bound, Ps>> start_parse_bound(Ps p_) {
    return prism_rtl::make_rc<ParseBound>(p_);
}


/// ParseRow: unbounded fn Ps -> ((Row, Ps))
std::tuple<crate::syntax::Row_, Ps> parse_row(const Ps& p_) {
    auto start = here(p_);
    auto [first_, p1] = parse_row_term(p_);
    auto r = ({
        std::tuple<Array<crate::syntax::RowTerm>, Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
        Array<crate::syntax::RowTerm> terms = Array(std::vector{first_});
        Ps q = p1;
        while ((kind(q) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{})) && (!q.bad)) {
            auto [t, q2] = parse_row_term(adv(q));
            terms = crate::prelude::push(terms, t);
            q = q2;
        }
        this_ = std::tuple{terms, q};
        this_;
    });
    auto [terms, q] = r;
    return std::tuple{crate::syntax::Row_{.terms = terms, .span = to(start, crate::syntax::parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Row_, Ps>> ParseRow::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto p__1 = p_;
    return call_then(start_parse_row_term(p__1), [=](std::tuple<crate::syntax::RowTerm, Ps> parse_row_term_87724) {
        return ({
            auto [first_, p1] = parse_row_term_87724;
            std::tuple<Array<crate::syntax::RowTerm>, Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<crate::syntax::RowTerm> terms = Array(std::vector{first_});
            Ps q = p1;
            auto start_2 = start;
            call_then(loop_job(std::tuple{this_, q, terms}, [=](std::tuple<std::tuple<Array<crate::syntax::RowTerm>, Ps>, Ps, Array<crate::syntax::RowTerm>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q = std::get<1>(_p0);
            auto terms = std::get<2>(_p0);
            return (kind(q) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{})) && (!q->bad)
                ? ({
                auto [t, q2] = parse_row_term(adv(q));
                terms = crate::prelude::push(terms, t);
                q = q2;
                Expected<std::tuple<std::tuple<Array<crate::syntax::RowTerm>, Ps>, Ps, Array<crate::syntax::RowTerm>>, std::tuple<std::tuple<Array<crate::syntax::RowTerm>, Ps>, Ps, Array<crate::syntax::RowTerm>>>(std::tuple{this_, q, terms});
            })
                : Expected<std::tuple<std::tuple<Array<crate::syntax::RowTerm>, Ps>, Ps, Array<crate::syntax::RowTerm>>, std::tuple<std::tuple<Array<crate::syntax::RowTerm>, Ps>, Ps, Array<crate::syntax::RowTerm>>>(unexpected(std::tuple{this_, q, terms}));
        }), [=](std::tuple<std::tuple<Array<crate::syntax::RowTerm>, Ps>, Ps, Array<crate::syntax::RowTerm>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q = std::get<1>(_p0);
            auto terms = std::get<2>(_p0);
            return ({
                this_ = std::tuple{terms, q};
                auto r = this_;
                auto [terms, q] = r;
                (prism_rtl::finished(std::tuple{crate::syntax::Row_{.terms = terms, .span = to(start_2, crate::syntax::parser::prev(q))}, q}));
            });
        });
        });
    });
}


/// `Start ParseRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Row_, Ps>> start_parse_row(Ps p_) {
    return prism_rtl::make_rc<ParseRow>(p_);
}


/// ParseRowTerm: unbounded fn Ps -> ((RowTerm, Ps))
std::tuple<crate::syntax::RowTerm, Ps> parse_row_term(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        auto&& path_ = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        return std::tuple{crate::syntax::RowTerm(crate::syntax::RowTerm::RFamily{crate::syntax::QualName{.path_ = path_, .span = here(p_)}}), adv(p_)};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if (is_plain_lower_one(crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KName{n})) && (!type_atom_after_name(p_))) {
            return std::tuple{crate::syntax::RowTerm(crate::syntax::RowTerm::RVar{crate::syntax::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = here(p_)}}), adv(p_)};
        }
    }
    {
        auto [t, q] = parse_map_type(p_);
        return std::tuple{crate::syntax::RowTerm(crate::syntax::RowTerm::RType{t}), q};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::RowTerm, Ps>> ParseRowTerm::cycle() const {
    const auto& p_ = this->p_;
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m) ? ({
        auto&& path_ = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::RowTerm(crate::syntax::RowTerm::RFamily{crate::syntax::QualName{.path_ = path_, .span = here(p_)}}), adv(p_)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        (is_plain_lower_one(crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KName{n})) && (!type_atom_after_name(p_)));
    }) ? ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::RowTerm(crate::syntax::RowTerm::RVar{crate::syntax::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = here(p_)}}), adv(p_)});
    })
        : ({
        auto p__1 = p_;
        call_then(start_parse_map_type(p__1), [=](std::tuple<crate::syntax::Type, Ps> parse_map_type_88435) {
        return ({
            auto [t, q] = parse_map_type_88435;
            (prism_rtl::finished(std::tuple{crate::syntax::RowTerm(crate::syntax::RowTerm::RType{t}), q}));
        });
    });
    });
    });
}


/// `Start ParseRowTerm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::RowTerm, Ps>> start_parse_row_term(Ps p_) {
    return prism_rtl::make_rc<ParseRowTerm>(p_);
}


/// TypeAtomAfterName: fn Ps -> Bool
bool type_atom_after_name(const Ps& p_) {
    auto&& _m = kind_at(p_, Nat(1u));
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// ParsePattern: unbounded fn Ps, Bool -> ((Pattern, Ps))
std::tuple<crate::syntax::Pattern_, Ps> parse_pattern(const Ps& p_, const bool& commas0) {
    auto commas_ = commas0 && (!p_.step_mode);
    auto start = here(p_);
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        if ((s == Text::lit("?")) || (s == Text::lit("~"))) {
            auto [inner, q] = parse_pattern(adv(p_), commas_);
            return std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PSigil{s, prism_rtl::rc(inner)})), .span = to(start, inner.span)}, q};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        return std::tuple{no_pattern(), error_at(p_, start, prism_rtl::cat("a free `", s, "` is not a pattern: only `? p` and `~ p` take a value apart"))};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        return name_pattern(p_, n, commas_);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m89219_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m89219_3_0 == Text::lit("ignore")) {
            return std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = start}, adv(p_)};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m89219_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m89219_4_0 == Text::lit("unit")) {
            return std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PUnit{})), .span = start}, adv(p_)};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m89219_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m89219_5_0 == Text::lit("nil")) {
            return std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PNil{})), .span = start}, adv(p_)};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m)) {
        return literal_pattern(p_);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(_m)) {
        return literal_pattern(p_);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(_m)) {
        return literal_pattern(p_);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(_m)) {
        return literal_pattern(p_);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m)) {
        return literal_pattern(p_);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a1) {
        auto&& m89219_11_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        if (m89219_11_0 == Text::lit("-")) {
            auto p1 = adv(p_);
            return is_number_kind(kind(p1))
                ? ({
                auto [lit, q] = parse_literal(p1);
                std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PNeg{lit})), .span = to(start, lit.span)}, q};
            })
                : std::tuple{no_pattern(), error_here(p1, Text::lit("a `-` in a pattern is the sign of a number literal"))};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m89219_12_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m89219_12_0 == Text::lit("(")) {
            return at_double_open(p_, Text::lit("("))
                ? ({
                auto [elems, p1] = commas(open_double(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto q = p0;
                            (prism_rtl::more(prism_rtl::rc(ParsePattern(q, false))));
                        });
                    }));
                })));
                auto p2 = close_double(p1, Text::lit("("));
                std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PTuple{elems})), .span = to(start, crate::syntax::parser::prev(p2))}, p2};
            })
                : ({
                auto [inner, p1] = bracketed(adv(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto q = p0;
                            (prism_rtl::more(prism_rtl::rc(ParsePattern(q, true))));
                        });
                    }));
                })));
                auto p2 = expect_close(p1, Text::lit("("));
                std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PGroup{prism_rtl::rc(inner)})), .span = to(start, crate::syntax::parser::prev(p2))}, p2};
            });
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m89219_13_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m89219_13_0 == Text::lit("[")) {
            if (at_double_open(p_, Text::lit("["))) {
                auto p1 = open_double(p_);
                auto [elems, p2] = at_close(p1, Text::lit("["))
                    ? std::tuple{Array<crate::syntax::Pattern_>{}, p1}
                    : commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto q = p0;
                            (prism_rtl::more(prism_rtl::rc(ParsePattern(q, false))));
                        });
                    }));
                })));
                auto p3 = close_double(p2, Text::lit("["));
                return std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PArray{elems})), .span = to(start, crate::syntax::parser::prev(p3))}, p3};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        auto&& path_ = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        return std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PFamily{crate::syntax::QualName{.path_ = path_, .span = start}})), .span = start}, adv(p_)};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KAbsent>(_m)) {
        return std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = start}, out_of_scope(adv(p_), start, Text::lit("sparse tuples"), Text::lit("an absent component `-` is a sparse tuple's, out of this compiler"))};
    }
    {
        return std::tuple{no_pattern(), error_here(p_, Text::lit("expected a pattern"))};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Pattern_, Ps>> ParsePattern::cycle() const {
    const auto& p_ = this->p_;
    const auto& commas0 = this->commas0;
    auto commas_ = commas0 && (!p_.step_mode);
    auto start = here(p_);
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m) && ({
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        ((s == Text::lit("?")) || (s == Text::lit("~")));
    }) ? ({
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_pattern(adv(p__1), commas_), [=](std::tuple<crate::syntax::Pattern_, Ps> parse_pattern_89305) {
        return ({
            auto [inner, q] = parse_pattern_89305;
            (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PSigil{s, prism_rtl::rc(inner)})), .span = to(start, inner.span)}, q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        prism_rtl::finished(std::tuple{no_pattern(), error_at(p_, start, prism_rtl::cat("a free `", s, "` is not a pattern: only `? p` and `~ p` take a value apart"))});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(NamePattern(p_, n, commas_)));
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m89219_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m89219_3_0 == Text::lit("ignore"));
    }) ? ({
        auto&& m89219_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = start}, adv(p_)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m89219_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m89219_4_0 == Text::lit("unit"));
    }) ? ({
        auto&& m89219_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PUnit{})), .span = start}, adv(p_)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m89219_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m89219_5_0 == Text::lit("nil"));
    }) ? ({
        auto&& m89219_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PNil{})), .span = start}, adv(p_)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPattern(p_)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPattern(p_)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPattern(p_)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPattern(p_)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPattern(p_)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a1 && ({
        auto&& m89219_11_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        (m89219_11_0 == Text::lit("-"));
    }) ? ({
        auto&& m89219_11_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        ({
        auto p1 = adv(p_);
        is_number_kind(kind(p1))
        ? call_then(start_parse_literal(p1), [=](std::tuple<crate::syntax::Literal, Ps> parse_literal_90216) {
        return ({
            auto [lit, q] = parse_literal_90216;
            (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PNeg{lit})), .span = to(start, lit.span)}, q}));
        });
    })
        : prism_rtl::finished(std::tuple{no_pattern(), error_here(p1, Text::lit("a `-` in a pattern is the sign of a number literal"))});
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && ({
        auto&& m89219_12_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        (m89219_12_0 == Text::lit("("));
    }) ? ({
        auto&& m89219_12_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        at_double_open(p_, Text::lit("("))
        ? ({
        auto p__1 = p_;
        call_then(start_commas(open_double(p__1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(ParsePattern(q, false))));
            });
        }));
    }))), [=](std::tuple<Array<crate::syntax::Pattern_>, Ps> commas_90508) {
        return ({
            auto [elems, p1] = commas_90508;
            auto p2 = close_double(p1, Text::lit("("));
            (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PTuple{elems})), .span = to(start, crate::syntax::parser::prev(p2))}, p2}));
        });
    });
    })
        : ({
        auto p__1 = p_;
        call_then(start_bracketed(adv(p__1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(ParsePattern(q, true))));
            });
        }));
    }))), [=](std::tuple<crate::syntax::Pattern_, Ps> bracketed_90895) {
        return ({
            auto [inner, p1] = bracketed_90895;
            auto p2 = expect_close(p1, Text::lit("("));
            (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PGroup{prism_rtl::rc(inner)})), .span = to(start, crate::syntax::parser::prev(p2))}, p2}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && ({
        auto&& m89219_13_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        (m89219_13_0 == Text::lit("[")) && at_double_open(p_, Text::lit("["));
    }) ? ({
        auto&& m89219_13_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        ({
        auto p1 = open_double(p_);
        auto [elems, p2] = at_close(p1, Text::lit("["))
            ? std::tuple{Array<crate::syntax::Pattern_>{}, p1}
            : commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
            return entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(ParsePattern(q, false))));
                });
            }));
        })));
        auto p3 = close_double(p2, Text::lit("["));
        (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PArray{elems})), .span = to(start, crate::syntax::parser::prev(p3))}, p3}));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m) ? ({
        auto&& path_ = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PFamily{crate::syntax::QualName{.path_ = path_, .span = start}})), .span = start}, adv(p_)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KAbsent>(_m) ? prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = start}, out_of_scope(adv(p_), start, Text::lit("sparse tuples"), Text::lit("an absent component `-` is a sparse tuple's, out of this compiler"))})
        : prism_rtl::finished(std::tuple{no_pattern(), error_here(p_, Text::lit("expected a pattern"))});
    });
}


/// `Start ParsePattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, Ps>> start_parse_pattern(Ps p_, bool commas0) {
    return prism_rtl::make_rc<ParsePattern>(p_, commas0);
}


/// IsNumberKind: fn TokKind -> Bool
bool is_number_kind(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// LiteralPattern: unbounded fn Ps -> ((Pattern, Ps))
std::tuple<crate::syntax::Pattern_, Ps> literal_pattern(const Ps& p_) {
    auto [lit, q] = parse_literal(p_);
    return std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PLit{lit})), .span = lit.span}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Pattern_, Ps>> LiteralPattern::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_literal(p__1), [=](std::tuple<crate::syntax::Literal, Ps> parse_literal_92029) {
        return ({
            auto [lit, q] = parse_literal_92029;
            (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PLit{lit})), .span = lit.span}, q}));
        });
    });
}


/// `Start LiteralPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, Ps>> start_literal_pattern(Ps p_) {
    return prism_rtl::make_rc<LiteralPattern>(p_);
}


/// NamePattern: unbounded fn Ps, NameTok, Bool -> ((Pattern, Ps))
std::tuple<crate::syntax::Pattern_, Ps> name_pattern(const Ps& p0, const crate::syntax::lexer::NameTok& n, const bool& commas_) {
    auto start = here(p0);
    auto name = crate::syntax::SName{.sigils = n.sigils, .path_ = n->path_, .span = start};
    auto p_ = adv(p0);
    return (is_callee(name) && at_single_open(p_, Text::lit("("))) && tk(p_).touches
        ? parse_record_pattern(p_, name)
        : is_callee(name) && pat_arg_starts_here(p_)
        ? ({
        auto [first_, p1] = parse_pattern(p_, false);
        auto r = ({
            std::tuple<Array<crate::syntax::Pattern_>, Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<crate::syntax::Pattern_> args = Array(std::vector{first_});
            Ps q = p1;
            while ((commas_ && at_comma(q)) && (!q.bad)) {
                auto [a, q2] = parse_pattern(adv(q), false);
                args = crate::prelude::push(args, a);
                q = q2;
            }
            this_ = std::tuple{args, q};
            this_;
        });
        auto [args, q] = r;
        std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PCtor{name, args})), .span = to(start, crate::syntax::parser::prev(q))}, q};
    })
        : std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PName{name})), .span = start}, p_};
}


prism_rtl::Turn<std::tuple<crate::syntax::Pattern_, Ps>> NamePattern::cycle() const {
    const auto& p0 = this->p0;
    const auto& n = this->n;
    const auto& commas_ = this->commas_;
    auto start = here(p0);
    auto name = crate::syntax::SName{.sigils = n.sigils, .path_ = n->path_, .span = start};
    auto p_ = adv(p0);
    return (is_callee(name) && at_single_open(p_, Text::lit("("))) && tk(p_).touches
        ? prism_rtl::more(prism_rtl::rc(ParseRecordPattern(p_, name)))
        : is_callee(name) && pat_arg_starts_here(p_)
        ? ({
        auto commas__1 = commas_;
        call_then(start_parse_pattern(p_, false), [=](std::tuple<crate::syntax::Pattern_, Ps> parse_pattern_92474) {
        return ({
            auto [first_, p1] = parse_pattern_92474;
            std::tuple<Array<crate::syntax::Pattern_>, Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<crate::syntax::Pattern_> args = Array(std::vector{first_});
            Ps q = p1;
            auto name_2 = name;
            auto start_3 = start;
            call_then(loop_job(std::tuple{this_, args, q}, ({
            auto commas__1_4 = commas__1;
            [=](std::tuple<std::tuple<Array<crate::syntax::Pattern_>, Ps>, Array<crate::syntax::Pattern_>, Ps> _p0) {
            auto this_ = std::get<0>(_p0);
            auto args = std::get<1>(_p0);
            auto q = std::get<2>(_p0);
            return (commas__1_4 && at_comma(q)) && (!q->bad)
                ? ({
                auto [a, q2] = parse_pattern(adv(q), false);
                args = crate::prelude::push(args, a);
                q = q2;
                Expected<std::tuple<std::tuple<Array<crate::syntax::Pattern_>, Ps>, Array<crate::syntax::Pattern_>, Ps>, std::tuple<std::tuple<Array<crate::syntax::Pattern_>, Ps>, Array<crate::syntax::Pattern_>, Ps>>(std::tuple{this_, args, q});
            })
                : Expected<std::tuple<std::tuple<Array<crate::syntax::Pattern_>, Ps>, Array<crate::syntax::Pattern_>, Ps>, std::tuple<std::tuple<Array<crate::syntax::Pattern_>, Ps>, Array<crate::syntax::Pattern_>, Ps>>(unexpected(std::tuple{this_, args, q}));
        };
        })), [=](std::tuple<std::tuple<Array<crate::syntax::Pattern_>, Ps>, Array<crate::syntax::Pattern_>, Ps> _p0) {
            auto this_ = std::get<0>(_p0);
            auto args = std::get<1>(_p0);
            auto q = std::get<2>(_p0);
            return ({
                this_ = std::tuple{args, q};
                auto r = this_;
                auto [args, q] = r;
                (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PCtor{name_2, args})), .span = to(start_3, crate::syntax::parser::prev(q))}, q}));
            });
        });
        });
    });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PName{name})), .span = start}, p_});
}


/// `Start NamePattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, Ps>> start_name_pattern(Ps p0, crate::syntax::lexer::NameTok n, bool commas_) {
    return prism_rtl::make_rc<NamePattern>(p0, n, commas_);
}


/// PatArgStartsHere: fn Ps -> Bool
bool pat_arg_starts_here(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        return (s == Text::lit("?")) || (s == Text::lit("~"));
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m93092_8_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m93092_8_0 == Text::lit("(")) {
            return (!tk(p_).touches) || at_double_open(p_, Text::lit("("));
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m93092_9_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m93092_9_0 == Text::lit("[")) {
            return at_double_open(p_, Text::lit("["));
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a1) {
        auto&& m93092_10_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        if (m93092_10_0 == Text::lit("-")) {
            return true;
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        return ((w == Text::lit("ignore")) || (w == Text::lit("unit"))) || (w == Text::lit("nil"));
    }
    {
        return false;
    }
}


/// ParseRecordPattern: unbounded fn Ps, SName -> ((Pattern, Ps))
std::tuple<crate::syntax::Pattern_, Ps> parse_record_pattern(const Ps& p0, const crate::syntax::SName& name) {
    auto p_ = adv(p0);
    auto r = ({
        FieldsRead this_ = FieldsRead{.fields = Array<crate::syntax::FieldPat>{}, .rest = false, .p_ = p_, .going = !at_close(p_, Text::lit("("))};
        while (this_.going && (!this_.p_->bad)) {
            if (kind(this_.p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDotDot{})) {
                this_.p_ = adv(this_.p_);
                this_.rest = true;
            } else  {
                auto fstart = here(this_.p_);
                auto [fname_opt, p1] = parse_arg_name(this_.p_);
                auto [pattern, p2] = parse_pattern(p1, false);
                this_.fields = crate::prelude::push(this_.fields, crate::syntax::FieldPat{.name = fname_opt, .pattern = pattern, .span = to(fstart, pattern.span)});
                this_.p_ = p2;
            }
            if (at_comma(this_.p_)) {
                this_.p_ = adv(this_.p_);
            } else  {
                this_.going = false;
            }
        }
        this_;
    });
    auto q = expect_close(r.p_, Text::lit("("));
    return std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PRecord{name, r.fields, r.rest})), .span = to(name.span, crate::syntax::parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Pattern_, Ps>> ParseRecordPattern::cycle() const {
    const auto& p0 = this->p0;
    const auto& name = this->name;
    auto p_ = adv(p0);
    FieldsRead this_ = FieldsRead{.fields = Array<crate::syntax::FieldPat>{}, .rest = false, .p_ = p_, .going = !at_close(p_, Text::lit("("))};
    auto name_1 = name;
    auto p__2 = p_;
    return call_then(loop_job(std::tuple{this_}, ({
        auto name_1_3 = name_1;
        auto p__2_3 = p__2;
        [=](std::tuple<FieldsRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return this_.going && (!this_.p_->bad)
            ? ({
            if (kind(this_.p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDotDot{})) {
                this_.p_ = adv(this_.p_);
                this_.rest = true;
            } else  {
                auto fstart = here(this_.p_);
                auto [fname_opt, p1] = parse_arg_name(this_.p_);
                auto [pattern, p2] = parse_pattern(p1, false);
                this_.fields = crate::prelude::push(this_.fields, crate::syntax::FieldPat{.name = fname_opt, .pattern = pattern, .span = to(fstart, pattern.span)});
                this_.p_ = p2;
            }
            if (at_comma(this_.p_)) {
                this_.p_ = adv(this_.p_);
            } else  {
                this_.going = false;
            }
            Expected<std::tuple<FieldsRead>, std::tuple<FieldsRead>>(std::tuple{this_});
        })
            : Expected<std::tuple<FieldsRead>, std::tuple<FieldsRead>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<FieldsRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto r = this_;
            auto q = expect_close(r.p_, Text::lit("("));
            (prism_rtl::finished(std::tuple{crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PRecord{name_1, r.fields, r.rest})), .span = to(name_1.span, crate::syntax::parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseRecordPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, Ps>> start_parse_record_pattern(Ps p0, crate::syntax::SName name) {
    return prism_rtl::make_rc<ParseRecordPattern>(p0, name);
}


/// let deliveryWords
Array<Text> delivery_words() {
    return Array(std::vector{Text::lit("send"), Text::lit("click"), Text::lit("answer")});
}


/// IsDeliveryWord: fn Text -> Bool
bool is_delivery_word(const Text& w) {
    return fold(delivery_words(), false, [&](const bool& seen, const Text& d) { return seen || (d == w); });
}


/// StepWord: fn Ps -> Text
Text step_word(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if (((n.sigils == Text::lit("")) && (len(n->path_) == Nat(1u))) && (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) {
            return or_(index(n->path_, Nat(0u)), Text::lit(""));
        }
    }
    {
        return Text::lit("");
    }
}


/// AtWord: fn Ps, Text -> Bool
bool at_word(const Ps& p_, const Text& w) {
    return step_word(p_) == w;
}


/// ParseCheckDecl: unbounded fn Ps -> ((CheckDecl, Ps))
std::tuple<crate::syntax::CheckDecl, Ps> parse_check_decl(const Ps& p0) {
    auto start = here(p0);
    auto [name, p1] = parse_ident(adv(p0));
    auto p2 = expect_colon(p1);
    return at_open_l(p2)
        ? ({
        auto [lines, q] = layout_items(adv(p2), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::CheckLine, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_check_line(a0)); })));
        std::tuple{crate::syntax::CheckDecl{.name = name, .lines = lines, .span = to(start, crate::syntax::parser::prev(q))}, q};
    })
        : std::tuple{crate::syntax::CheckDecl{.name = name, .lines = Array<crate::syntax::CheckLine>{}, .span = start}, error_here(p2, Text::lit("a `check` block's lines stand in an indented block"))};
}


prism_rtl::Turn<std::tuple<crate::syntax::CheckDecl, Ps>> ParseCheckDecl::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto [name, p1] = parse_ident(adv(p0));
    auto p2 = expect_colon(p1);
    return at_open_l(p2)
        ? call_then(start_layout_items(adv(p2), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::CheckLine, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_check_line(a0)); }))), [=](std::tuple<Array<crate::syntax::CheckLine>, Ps> layout_items_95906) {
        return ({
            auto [lines, q] = layout_items_95906;
            (prism_rtl::finished(std::tuple{crate::syntax::CheckDecl{.name = name, .lines = lines, .span = to(start, crate::syntax::parser::prev(q))}, q}));
        });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::CheckDecl{.name = name, .lines = Array<crate::syntax::CheckLine>{}, .span = start}, error_here(p2, Text::lit("a `check` block's lines stand in an indented block"))});
}


/// `Start ParseCheckDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::CheckDecl, Ps>> start_parse_check_decl(Ps p0) {
    return prism_rtl::make_rc<ParseCheckDecl>(p0);
}


/// ParseCheckLine: unbounded fn Ps -> ((CheckLine, Ps))
std::tuple<crate::syntax::CheckLine, Ps> parse_check_line(const Ps& p_) {
    auto start = here(p_);
    auto [expr, p1] = parse_rhs_expr(p_);
    auto [pattern_opt, q] = at_op(p1, Text::lit("=>"))
        ? optional_pattern_top(adv(p1))
        : std::tuple{std::optional<crate::syntax::Pattern_>{}, p1};
    return std::tuple{crate::syntax::CheckLine{.expr = expr, .pattern = pattern_opt, .span = to(start, crate::syntax::parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::CheckLine, Ps>> ParseCheckLine::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto p__1 = p_;
    return call_then(start_parse_rhs_expr(p__1), [=](std::tuple<crate::syntax::Expr, Ps> parse_rhs_expr_96269) {
        return ({
            auto [expr, p1] = parse_rhs_expr_96269;
            auto [pattern_opt, q] = at_op(p1, Text::lit("=>"))
                ? optional_pattern_top(adv(p1))
                : std::tuple{std::optional<crate::syntax::Pattern_>{}, p1};
            (prism_rtl::finished(std::tuple{crate::syntax::CheckLine{.expr = expr, .pattern = pattern_opt, .span = to(start, crate::syntax::parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseCheckLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::CheckLine, Ps>> start_parse_check_line(Ps p_) {
    return prism_rtl::make_rc<ParseCheckLine>(p_);
}


/// OptionalPatternTop: unbounded fn Ps -> ((?Pattern, Ps))
std::tuple<std::optional<crate::syntax::Pattern_>, Ps> optional_pattern_top(const Ps& p_) {
    auto [pat, q] = parse_pattern(p_, true);
    return std::tuple{std::optional(pat), q};
}


prism_rtl::Turn<std::tuple<std::optional<crate::syntax::Pattern_>, Ps>> OptionalPatternTop::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_pattern(p__1, true), [=](std::tuple<crate::syntax::Pattern_, Ps> parse_pattern_96554) {
        return ({
            auto [pat, q] = parse_pattern_96554;
            (prism_rtl::finished(std::tuple{std::optional(pat), q}));
        });
    });
}


/// `Start OptionalPatternTop, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::Pattern_>, Ps>> start_optional_pattern_top(Ps p_) {
    return prism_rtl::make_rc<OptionalPatternTop>(p_);
}


/// ParseTestDecl: unbounded fn Ps -> ((TestDecl, Ps))
std::tuple<crate::syntax::TestDecl, Ps> parse_test_decl(const Ps& p0) {
    auto start = here(p0);
    auto [name, p1] = parse_ident(adv(p0));
    auto fallback = crate::syntax::TestDecl{.name = name, .blueprint = no_expr(), .seed = std::optional<Nat>{}, .steps = Array<crate::syntax::TestStep>{}, .span = start};
    return !at_comma(p1)
        ? std::tuple{fallback, error_here(p1, Text::lit("a test names its blueprint: `test name, @blueprint:`"))}
        : ({
        auto [blueprint, p2] = parse_arg_expr(adv(p1));
        auto [seed_opt, p3] = at_comma(p2) ? parse_seed(adv(p2)) : std::tuple{std::optional<Nat>{}, p2};
        auto p4 = expect_colon(p3);
        at_open_l(p4)
        ? ({
        auto saved = p4.step_mode;
        auto [steps, p5] = layout_items(adv(p4), ({
            auto saved_1 = saved;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::TestStep, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
            return ({
                auto saved_1_2 = saved_1;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    (prism_rtl::more(prism_rtl::rc(StepIn(s, saved_1_2))));
                });
            }));
            });
        }));
        }));
        auto q = with_step_mode(p5, saved);
        std::tuple{crate::syntax::TestDecl{.name = name, .blueprint = blueprint, .seed = seed_opt, .steps = steps, .span = to(start, crate::syntax::parser::prev(q))}, q};
    })
        : std::tuple{fallback, error_here(p4, Text::lit("a test's steps stand in an indented block"))};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::TestDecl, Ps>> ParseTestDecl::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto [name, p1] = parse_ident(adv(p0));
    auto fallback = crate::syntax::TestDecl{.name = name, .blueprint = no_expr(), .seed = std::optional<Nat>{}, .steps = Array<crate::syntax::TestStep>{}, .span = start};
    return !at_comma(p1)
        ? prism_rtl::finished(std::tuple{fallback, error_here(p1, Text::lit("a test names its blueprint: `test name, @blueprint:`"))})
        : call_then(start_parse_arg_expr(adv(p1)), [=](std::tuple<crate::syntax::Expr, Ps> parse_arg_expr_97047) {
        return ({
            auto [blueprint, p2] = parse_arg_expr_97047;
            auto [seed_opt, p3] = at_comma(p2) ? parse_seed(adv(p2)) : std::tuple{std::optional<Nat>{}, p2};
            auto p4 = expect_colon(p3);
            at_open_l(p4)
            ? ({
            auto saved = p4.step_mode;
            call_then(start_layout_items(adv(p4), ({
            auto saved_1 = saved;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::TestStep, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
            return ({
                auto saved_1_2 = saved_1;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    (prism_rtl::more(prism_rtl::rc(StepIn(s, saved_1_2))));
                });
            }));
            });
        }));
        })), [=](std::tuple<Array<crate::syntax::TestStep>, Ps> layout_items_97272) {
            return ({
                auto [steps, p5] = layout_items_97272;
                auto q = with_step_mode(p5, saved);
                (prism_rtl::finished(std::tuple{crate::syntax::TestDecl{.name = name, .blueprint = blueprint, .seed = seed_opt, .steps = steps, .span = to(start, crate::syntax::parser::prev(q))}, q}));
            });
        });
        })
            : prism_rtl::finished(std::tuple{fallback, error_here(p4, Text::lit("a test's steps stand in an indented block"))});
        });
    });
}


/// `Start ParseTestDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::TestDecl, Ps>> start_parse_test_decl(Ps p0) {
    return prism_rtl::make_rc<ParseTestDecl>(p0);
}


/// ParseSeed: fn Ps -> ((?Nat, Ps))
std::tuple<std::optional<Nat>, Ps> parse_seed(const Ps& p_) {
    return !at_word(p_, Text::lit("seed"))
        ? std::tuple{std::optional<Nat>{}, error_here(p_, Text::lit("after the blueprint, a test takes only `seed n`"))}
        : ({
        auto p1 = adv(p_);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<Nat>, Ps>> _v;
        auto&& _m = kind(p1);
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m)) {
            auto&& m97754_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a0;
            auto&& text = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a1;
            if (m97754_0_0 == Text::lit("")) {
                _v.set(std::tuple{std::optional(parse_nat_text(text)), adv(p1)});
                goto _done;
            }
        }
        {
            _v.set(std::tuple{std::optional<Nat>{}, error_here(p1, Text::lit("`seed` takes a number"))});
            goto _done;
        }
    _done:
        _v.take();
    });
    });
}


/// StepIn: unbounded fn Ps, Bool -> ((TestStep, Ps))
std::tuple<crate::syntax::TestStep, Ps> step_in(const Ps& p_, const bool& saved) {
    auto [s, q] = parse_step(with_step_mode(p_, true));
    return std::tuple{s, with_step_mode(q, saved)};
}


prism_rtl::Turn<std::tuple<crate::syntax::TestStep, Ps>> StepIn::cycle() const {
    const auto& p_ = this->p_;
    const auto& saved = this->saved;
    auto [s, q] = parse_step(with_step_mode(p_, true));
    return prism_rtl::finished(std::tuple{s, with_step_mode(q, saved)});
}


/// `Start StepIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::TestStep, Ps>> start_step_in(Ps p_, bool saved) {
    return prism_rtl::make_rc<StepIn>(p_, saved);
}


/// ParseStep: unbounded fn Ps -> ((TestStep, Ps))
std::tuple<crate::syntax::TestStep, Ps> parse_step(const Ps& p0) {
    auto start = here(p0);
    auto [withs, p1] = with_entries(p0);
    auto [action, p2] = step_action_of(p1, withs);
    return p2->bad
        ? std::tuple{crate::syntax::TestStep{.withs = withs, .action = action, .checks = Array<crate::syntax::TestCheck>{}, .span = start}, p2}
        : at_open_l(p2)
        ? ({
        auto [checks, q] = layout_items(adv(p2), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::TestCheck, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_test_check(a0)); })));
        std::tuple{crate::syntax::TestStep{.withs = withs, .action = action, .checks = checks, .span = to(start, crate::syntax::parser::prev(q))}, q};
    })
        : at_comma(p2)
        ? std::tuple{crate::syntax::TestStep{.withs = withs, .action = action, .checks = Array<crate::syntax::TestCheck>{}, .span = start}, error_at(p2, here(p2), Text::lit("a comma in a step begins a delivery; a value with commas in it is written in parentheses"))}
        : std::tuple{crate::syntax::TestStep{.withs = withs, .action = action, .checks = Array<crate::syntax::TestCheck>{}, .span = to(start, crate::syntax::parser::prev(p2))}, p2};
}


/// WithEntries: unbounded fn Ps -> (([Entry], Ps))
std::tuple<Array<crate::syntax::Entry>, Ps> with_entries(const Ps& p0) {
    std::tuple<Array<crate::syntax::Entry>, Ps> this_ = std::tuple{Array<crate::syntax::Entry>{}, p0};
    Array<crate::syntax::Entry> withs = Array<crate::syntax::Entry>{};
    Ps p_ = p0;
    bool going = at_word(p0, Text::lit("with"));
    while (going && (!p_.bad)) {
        auto [e, q] = parse_entry(adv(p_));
        withs = crate::prelude::push(withs, e);
        if (at_comma(q)) {
            p_ = adv(q);
            going = at_word(p_, Text::lit("with"));
        } else  {
            p_ = q;
            going = false;
        }
    }
    this_ = std::tuple{withs, p_};
    return this_;
}


/// StepActionOf: unbounded fn Ps, [Entry] -> ((StepAction, Ps))
std::tuple<crate::syntax::StepAction, Ps> step_action_of(const Ps& p_, const Array<crate::syntax::Entry>& withs) {
    auto w = step_word(p_);
    {
        auto&& m99573_0 = w;
        if (m99573_0 == Text::lit("build")) {
            return std::tuple{crate::syntax::StepAction(crate::syntax::StepAction::SaBuild{}), adv(p_)};
        }
    }
    {
        auto&& m99573_1 = w;
        if (m99573_1 == Text::lit("tick")) {
            return std::tuple{crate::syntax::StepAction(crate::syntax::StepAction::SaTick{}), adv(p_)};
        }
    }
    {
        auto&& m99573_2 = w;
        if (m99573_2 == Text::lit("compute")) {
            auto p1 = adv(p_);
            return at_word(p1, Text::lit("until"))
                ? ({
                auto p2 = adv(p1);
                at_word(p2, Text::lit("idle"))
                ? std::tuple{crate::syntax::StepAction(crate::syntax::StepAction::SaCompute{true}), adv(p2)}
                : std::tuple{crate::syntax::StepAction(crate::syntax::StepAction::SaCompute{true}), error_here(p2, Text::lit("`compute until` is followed by `idle`"))};
            })
                : std::tuple{crate::syntax::StepAction(crate::syntax::StepAction::SaCompute{false}), p1};
        }
    }
    {
        auto&& m99573_3 = w;
        if (m99573_3 == Text::lit("push")) {
            auto [e, q] = parse_entry(adv(p_));
            return std::tuple{crate::syntax::StepAction(crate::syntax::StepAction::SaPush{e}), q};
        }
    }
    {
        if (is_delivery_word(w)) {
            return deliveries(p_);
        }
    }
    {
        if ((len(withs) > Nat(0u)) && (at_open_l(p_) || at_stmt_boundary(p_))) {
            return std::tuple{crate::syntax::StepAction(crate::syntax::StepAction::SaWithOnly{}), p_};
        }
    }
    {
        return std::tuple{crate::syntax::StepAction(crate::syntax::StepAction::SaBuild{}), error_here(p_, Text::lit("expected a step: `build`, `tick`, `compute`, `send`, `click`, `answer`, `with` or `push`"))};
    }
}


/// Deliveries: unbounded fn Ps -> ((StepAction, Ps))
std::tuple<crate::syntax::StepAction, Ps> deliveries(const Ps& p0) {
    std::tuple<crate::syntax::StepAction, Ps> this_ = std::tuple{crate::syntax::StepAction(crate::syntax::StepAction::SaBuild{}), p0};
    auto [first_, p1] = parse_delivery(p0);
    Array<crate::syntax::Delivery> ds = Array(std::vector{first_});
    Ps p_ = p1;
    while (at_comma(p_) && (!p_.bad)) {
        if (is_delivery_name(kind_at(p_, Nat(1u)))) {
            auto [d, q] = parse_delivery(adv(p_));
            ds = crate::prelude::push(ds, d);
            p_ = q;
        } else  {
            p_ = error_at(p_, here(p_), Text::lit("a comma in a step begins a delivery (`click p, click q`); a value with commas in it is written in parentheses: `send p, (Min a, b)`"));
        }
    }
    this_ = std::tuple{crate::syntax::StepAction(crate::syntax::StepAction::SaDeliver{ds}), p_};
    return this_;
}


/// IsDeliveryName: fn TokKind -> Bool
bool is_delivery_name(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(tok_kind0)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(tok_kind0).a0;
        return (len(n->path_) == Nat(1u)) && is_delivery_word(or_(index(n->path_, Nat(0u)), Text::lit("")));
    }
    {
        return false;
    }
}


/// ParseEntry: unbounded fn Ps -> ((Entry, Ps))
std::tuple<crate::syntax::Entry, Ps> parse_entry(const Ps& p_) {
    auto start = here(p_);
    auto [element_, p1] = parse_arg_expr(p_);
    auto [value, q] = parse_arg_expr(expect_op(p1, Text::lit("=")));
    return std::tuple{crate::syntax::Entry{.element = element_, .value = value, .span = to(start, crate::syntax::parser::prev(q))}, q};
}


/// ParseDelivery: unbounded fn Ps -> ((Delivery, Ps))
std::tuple<crate::syntax::Delivery, Ps> parse_delivery(const Ps& p_) {
    auto start = here(p_);
    auto word = step_word(p_);
    auto [target, p1] = parse_target(adv(p_));
    auto [kind_, q] = word == Text::lit("send")
        ? send_value(p1)
        : word == Text::lit("click")
        ? std::tuple{crate::syntax::DeliveryKind(crate::syntax::DeliveryKind::DkClick{}), p1}
        : std::tuple{crate::syntax::DeliveryKind(crate::syntax::DeliveryKind::DkAnswer{}), p1};
    return std::tuple{crate::syntax::Delivery{.kind = kind_, .target = target, .span = to(start, crate::syntax::parser::prev(q))}, q};
}


/// SendValue: unbounded fn Ps -> ((DeliveryKind, Ps))
std::tuple<crate::syntax::DeliveryKind, Ps> send_value(const Ps& p_) {
    return at_comma(p_)
        ? ({
        auto [v_, q] = parse_arg_expr(adv(p_));
        std::tuple{crate::syntax::DeliveryKind(crate::syntax::DeliveryKind::DkSend{v_}), q};
    })
        : std::tuple{crate::syntax::DeliveryKind(crate::syntax::DeliveryKind::DkClick{}), error_here(p_, Text::lit("`send` takes a target and a value: `send p, v`"))};
}


/// ParseTarget: unbounded fn Ps -> ((Target, Ps))
std::tuple<crate::syntax::Target, Ps> parse_target(const Ps& p_) {
    auto element_ = at_word(p_, Text::lit("element")) && is_path_kind(kind_at(p_, Nat(1u)));
    return at_word(p_, Text::lit("at")) || element_
        ? ({
        auto p1 = adv(p_);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::syntax::Target, Ps>> _v;
        auto&& _m = kind(p1);
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KPath>(_m)) {
            auto&& segs = prism_rtl::as<crate::syntax::lexer::TokKind::KPath>(_m).a0;
            _v.set(({
                auto span = here(p1);
                auto [segments, q] = run_to_end(fold_job(segs, std::tuple{Array<crate::syntax::PathSeg>{}, adv(p1)}, ({
                    auto span_1 = span;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::PathSeg>, Ps>>(std::tuple<std::tuple<Array<crate::syntax::PathSeg>, Ps>, crate::syntax::lexer::PathSegTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::PathSeg>, Ps>, crate::syntax::lexer::PathSegTok> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto span_1_2 = span_1;
                        entered(once_job([=]() {
                        return ({
                            auto [acc, pp] = p0;
                            auto seg = p1;
                            (prism_rtl::finished(path_seg_of(acc, pp, seg, span_1_2)));
                        });
                    }));
                    });
                }));
                })));
                auto path_ = crate::syntax::TestPath{.segments = segments, .span = span};
                element_
                ? std::tuple{crate::syntax::Target(crate::syntax::Target::TgElement{path_}), q}
                : std::tuple{crate::syntax::Target(crate::syntax::Target::TgPath{path_}), q};
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{crate::syntax::Target(crate::syntax::Target::TgPattern{no_pattern()}), error_here(p1, Text::lit("`at` takes a path, `1/#0/0`"))});
            goto _done;
        }
    _done:
        _v.take();
    });
    })
        : ({
        auto [pat, q] = parse_pattern(p_, false);
        std::tuple{crate::syntax::Target(crate::syntax::Target::TgPattern{pat}), q};
    });
}


/// IsPathKind: fn TokKind -> Bool
bool is_path_kind(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KPath>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// PathSegOf: unbounded fn [PathSeg], Ps, PathSegTok, Range -> (([PathSeg], Ps))
std::tuple<Array<crate::syntax::PathSeg>, Ps> path_seg_of(const Array<crate::syntax::PathSeg>& acc, const Ps& p_, const crate::syntax::lexer::PathSegTok& path_seg_tok2, const crate::syntax::Range& range3) {
    auto&& _m = std::tuple{path_seg_tok2, range3};
    if (prism_rtl::is<crate::syntax::lexer::PathSegTok::PstNum>(std::get<0>(_m))) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::PathSegTok::PstNum>(std::get<0>(_m)).a0;
        return std::tuple{crate::prelude::push(acc, crate::syntax::PathSeg(crate::syntax::PathSeg::PsNum{n})), p_};
    }
    if (prism_rtl::is<crate::syntax::lexer::PathSegTok::PstGen>(std::get<0>(_m))) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::PathSegTok::PstGen>(std::get<0>(_m)).a0;
        return std::tuple{crate::prelude::push(acc, crate::syntax::PathSeg(crate::syntax::PathSeg::PsGen{n})), p_};
    }
    if (prism_rtl::is<crate::syntax::lexer::PathSegTok::PstKey>(std::get<0>(_m))) {
        auto&& toks = prism_rtl::as<crate::syntax::lexer::PathSegTok::PstKey>(std::get<0>(_m)).a0;
        auto&& span = std::get<1>(_m);
        auto [e, q] = parse_nested(p_, toks, span);
        return std::tuple{crate::prelude::push(acc, crate::syntax::PathSeg(crate::syntax::PathSeg::PsKey{e})), q};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ParseTestCheck: unbounded fn Ps -> ((TestCheck, Ps))
std::tuple<crate::syntax::TestCheck, Ps> parse_test_check(const Ps& p0) {
    auto start = here(p0);
    auto p_ = expect_op(p0, Text::lit("=>"));
    auto word = step_word(p_);
    return p_->bad
        ? std::tuple{crate::syntax::TestCheck{.kind = crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkQuiet{}), .span = start}, p_}
        : word == Text::lit("")
        ? std::tuple{crate::syntax::TestCheck{.kind = crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkQuiet{}), .span = start}, error_here(p_, Text::lit("expected a check after `=>`: `expect`, `returns`, `fired`, `quiet`, ..."))}
        : ({
        auto [kind_, q] = check_kind_of(adv(p_), word);
        std::tuple{crate::syntax::TestCheck{.kind = kind_, .span = to(start, crate::syntax::parser::prev(q))}, q};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::TestCheck, Ps>> ParseTestCheck::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto p_ = expect_op(p0, Text::lit("=>"));
    auto word = step_word(p_);
    return p_->bad
        ? prism_rtl::finished(std::tuple{crate::syntax::TestCheck{.kind = crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkQuiet{}), .span = start}, p_})
        : word == Text::lit("")
        ? prism_rtl::finished(std::tuple{crate::syntax::TestCheck{.kind = crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkQuiet{}), .span = start}, error_here(p_, Text::lit("expected a check after `=>`: `expect`, `returns`, `fired`, `quiet`, ..."))})
        : call_then(start_check_kind_of(adv(p_), word), [=](std::tuple<crate::syntax::TestCheckKind, Ps> check_kind_of_103753) {
        return ({
            auto [kind_, q] = check_kind_of_103753;
            (prism_rtl::finished(std::tuple{crate::syntax::TestCheck{.kind = kind_, .span = to(start, crate::syntax::parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseTestCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::TestCheck, Ps>> start_parse_test_check(Ps p0) {
    return prism_rtl::make_rc<ParseTestCheck>(p0);
}


/// CheckKindOf: unbounded fn Ps, Text -> ((TestCheckKind, Ps))
std::tuple<crate::syntax::TestCheckKind, Ps> check_kind_of(const Ps& p_, const Text& word) {
    {
        auto&& m103928_0 = word;
        if (m103928_0 == Text::lit("expect")) {
            return one_pattern(p_, ({
                auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkExpect{a0}); });
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
                return ({
                    auto f_1 = f;
                    once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                });
            })));
            }));
        }
    }
    {
        auto&& m103928_1 = word;
        if (m103928_1 == Text::lit("expect_none")) {
            return one_pattern(p_, ({
                auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkExpectNone{a0}); });
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
                return ({
                    auto f_1 = f;
                    once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                });
            })));
            }));
        }
    }
    {
        auto&& m103928_2 = word;
        if (m103928_2 == Text::lit("expect_top")) {
            return one_pattern(p_, ({
                auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkExpectTop{a0}); });
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
                return ({
                    auto f_1 = f;
                    once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                });
            })));
            }));
        }
    }
    {
        auto&& m103928_3 = word;
        if (m103928_3 == Text::lit("expect_top_none")) {
            return one_pattern(p_, ({
                auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkExpectTopNone{a0}); });
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
                return ({
                    auto f_1 = f;
                    once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                });
            })));
            }));
        }
    }
    {
        auto&& m103928_4 = word;
        if (m103928_4 == Text::lit("unrequested")) {
            return one_pattern(p_, ({
                auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkUnrequested{a0}); });
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
                return ({
                    auto f_1 = f;
                    once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                });
            })));
            }));
        }
    }
    {
        auto&& m103928_5 = word;
        if (m103928_5 == Text::lit("returns")) {
            return one_pattern(p_, ({
                auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkReturns{a0}); });
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
                return ({
                    auto f_1 = f;
                    once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                });
            })));
            }));
        }
    }
    {
        auto&& m103928_6 = word;
        if (m103928_6 == Text::lit("fired")) {
            return one_pattern(p_, ({
                auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkFired{a0}); });
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
                return ({
                    auto f_1 = f;
                    once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                });
            })));
            }));
        }
    }
    {
        auto&& m103928_7 = word;
        if (m103928_7 == Text::lit("expect_count")) {
            auto [pat, p1] = parse_pattern(p_, false);
            return !at_comma(p1)
                ? std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkQuiet{}), error_here(p1, Text::lit("`expect_count` takes a pattern and a count: `expect_count p, n`"))}
                : ({
                auto p2 = adv(p1);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::syntax::TestCheckKind, Ps>> _v;
                auto&& _m = kind(p2);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m)) {
                    auto&& m104487_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a0;
                    auto&& text = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a1;
                    if (m104487_0_0 == Text::lit("")) {
                        _v.set(std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkExpectCount{pat, parse_nat_text(text)}), adv(p2)});
                        goto _done;
                    }
                }
                {
                    _v.set(std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkQuiet{}), error_here(p2, Text::lit("`expect_count` takes a number"))});
                    goto _done;
                }
            _done:
                _v.take();
            });
            });
        }
    }
    {
        auto&& m103928_8 = word;
        if (m103928_8 == Text::lit("requested")) {
            auto [place, p1] = parse_pattern(p_, false);
            return !at_comma(p1)
                ? std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkQuiet{}), error_here(p1, Text::lit("`requested` takes a place and a value: `requested p, v`"))}
                : ({
                auto [value, q] = parse_pattern(adv(p1), false);
                std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkRequested{place, value}), q};
            });
        }
    }
    {
        auto&& m103928_9 = word;
        if (m103928_9 == Text::lit("quiet")) {
            return std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkQuiet{}), p_};
        }
    }
    {
        auto&& m103928_10 = word;
        if (m103928_10 == Text::lit("settles")) {
            return std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkSettles{}), p_};
        }
    }
    {
        auto&& m103928_11 = word;
        if (m103928_11 == Text::lit("aborted")) {
            return std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkAborted{}), p_};
        }
    }
    {
        auto&& m103928_12 = word;
        if (m103928_12 == Text::lit("snapshot")) {
            auto&& _m = kind(p_);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m)) {
                auto&& m105087_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a0;
                auto&& segs = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a1;
                if (m105087_0_0 == Text::lit("")) {
                    if (all_plain(segs)) {
                        return std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkSnapshot{concat(each(segs, plain_of))}), adv(p_)};
                    }
                }
            }
            {
                return std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkQuiet{}), error_here(p_, Text::lit("`snapshot` takes a file name, a text literal"))};
            }
        }
    }
    {
        return std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkQuiet{}), error_at(p_, crate::syntax::parser::prev(p_), prism_rtl::cat("`", word, "` is not a check: the checks are expect, expect_none, expect_count, expect_top, expect_top_none, requested, unrequested, returns, fired, quiet, settles, aborted, snapshot"))};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::TestCheckKind, Ps>> CheckKindOf::cycle() const {
    const auto& p_ = this->p_;
    const auto& word = this->word;
    return ({
        ({
        auto&& m103928_0 = word;
        (m103928_0 == Text::lit("expect"));
    }) ? ({
        auto&& m103928_0 = word;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_, ({
        auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkExpect{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))));
    })
        : ({
        auto&& m103928_1 = word;
        (m103928_1 == Text::lit("expect_none"));
    }) ? ({
        auto&& m103928_1 = word;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_, ({
        auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkExpectNone{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))));
    })
        : ({
        auto&& m103928_2 = word;
        (m103928_2 == Text::lit("expect_top"));
    }) ? ({
        auto&& m103928_2 = word;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_, ({
        auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkExpectTop{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))));
    })
        : ({
        auto&& m103928_3 = word;
        (m103928_3 == Text::lit("expect_top_none"));
    }) ? ({
        auto&& m103928_3 = word;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_, ({
        auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkExpectTopNone{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))));
    })
        : ({
        auto&& m103928_4 = word;
        (m103928_4 == Text::lit("unrequested"));
    }) ? ({
        auto&& m103928_4 = word;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_, ({
        auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkUnrequested{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))));
    })
        : ({
        auto&& m103928_5 = word;
        (m103928_5 == Text::lit("returns"));
    }) ? ({
        auto&& m103928_5 = word;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_, ({
        auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkReturns{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))));
    })
        : ({
        auto&& m103928_6 = word;
        (m103928_6 == Text::lit("fired"));
    }) ? ({
        auto&& m103928_6 = word;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_, ({
        auto f = prism_rtl::rc([&](const crate::syntax::Pattern_& a0) { return crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkFired{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::TestCheckKind>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))));
    })
        : ({
        auto&& m103928_7 = word;
        (m103928_7 == Text::lit("expect_count"));
    }) ? ({
        auto&& m103928_7 = word;
        ({
        auto p__1 = p_;
        call_then(start_parse_pattern(p__1, false), [=](std::tuple<crate::syntax::Pattern_, Ps> parse_pattern_104287) {
        return ({
            auto [pat, p1] = parse_pattern_104287;
            !at_comma(p1)
            ? prism_rtl::finished(std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkQuiet{}), error_here(p1, Text::lit("`expect_count` takes a pattern and a count: `expect_count p, n`"))})
            : ({
            auto p2 = adv(p1);
            ({
            auto&& _m = kind(p2);
            prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m) && ({
            auto&& m104487_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a0;
            auto&& text = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a1;
            (m104487_0_0 == Text::lit(""));
        }) ? ({
            auto&& m104487_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a0;
            auto&& text = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a1;
            prism_rtl::finished(std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkExpectCount{pat, parse_nat_text(text)}), adv(p2)});
        })
            : prism_rtl::finished(std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkQuiet{}), error_here(p2, Text::lit("`expect_count` takes a number"))});
        });
        });
        });
    });
    });
    })
        : ({
        auto&& m103928_8 = word;
        (m103928_8 == Text::lit("requested"));
    }) ? ({
        auto&& m103928_8 = word;
        ({
        auto p__1 = p_;
        call_then(start_parse_pattern(p__1, false), [=](std::tuple<crate::syntax::Pattern_, Ps> parse_pattern_104721) {
        return ({
            auto [place, p1] = parse_pattern_104721;
            !at_comma(p1)
            ? prism_rtl::finished(std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkQuiet{}), error_here(p1, Text::lit("`requested` takes a place and a value: `requested p, v`"))})
            : call_then(start_parse_pattern(adv(p1), false), [=](std::tuple<crate::syntax::Pattern_, Ps> parse_pattern_104904) {
            return ({
                auto [value, q] = parse_pattern_104904;
                (prism_rtl::finished(std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkRequested{place, value}), q}));
            });
        });
        });
    });
    });
    })
        : ({
        auto&& m103928_9 = word;
        (m103928_9 == Text::lit("quiet"));
    }) ? ({
        auto&& m103928_9 = word;
        prism_rtl::finished(std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkQuiet{}), p_});
    })
        : ({
        auto&& m103928_10 = word;
        (m103928_10 == Text::lit("settles"));
    }) ? ({
        auto&& m103928_10 = word;
        prism_rtl::finished(std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkSettles{}), p_});
    })
        : ({
        auto&& m103928_11 = word;
        (m103928_11 == Text::lit("aborted"));
    }) ? ({
        auto&& m103928_11 = word;
        prism_rtl::finished(std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkAborted{}), p_});
    })
        : ({
        auto&& m103928_12 = word;
        (m103928_12 == Text::lit("snapshot"));
    }) ? ({
        auto&& m103928_12 = word;
        ({
        auto&& _m = kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m) && ({
        auto&& m105087_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a0;
        auto&& segs = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a1;
        (m105087_0_0 == Text::lit("")) && all_plain(segs);
    }) ? ({
        auto&& m105087_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a0;
        auto&& segs = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a1;
        prism_rtl::finished(std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkSnapshot{concat(each(segs, plain_of))}), adv(p_)});
    })
        : prism_rtl::finished(std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkQuiet{}), error_here(p_, Text::lit("`snapshot` takes a file name, a text literal"))});
    });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::TestCheckKind(crate::syntax::TestCheckKind::CkQuiet{}), error_at(p_, crate::syntax::parser::prev(p_), prism_rtl::cat("`", word, "` is not a check: the checks are expect, expect_none, expect_count, expect_top, expect_top_none, requested, unrequested, returns, fired, quiet, settles, aborted, snapshot"))});
    });
}


/// `Start CheckKindOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::TestCheckKind, Ps>> start_check_kind_of(Ps p_, Text word) {
    return prism_rtl::make_rc<CheckKindOf>(p_, word);
}


/// OnePattern: unbounded fn Ps, (fn Pattern -> TestCheckKind) -> ((TestCheckKind, Ps))
std::tuple<crate::syntax::TestCheckKind, Ps> one_pattern(const Ps& p_, const prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::TestCheckKind>(crate::syntax::Pattern_)>& make_fn) {
    auto [pat, q] = parse_pattern(p_, false);
    return std::tuple{run_to_end(make_fn(pat)), q};
}


prism_rtl::Turn<std::tuple<crate::syntax::TestCheckKind, Ps>> OnePattern::cycle() const {
    const auto& p_ = this->p_;
    const auto& make_fn = this->make_fn;
    auto make_fn_1 = make_fn;
    auto p__2 = p_;
    return call_then(start_parse_pattern(p__2, false), [=](std::tuple<crate::syntax::Pattern_, Ps> parse_pattern_105650) {
        return ({
            auto [pat, q] = parse_pattern_105650;
            call_value(make_fn_1(pat), [=](crate::syntax::TestCheckKind make_105678) { return prism_rtl::finished(std::tuple{make_105678, q}); });
        });
    });
}


/// `Start OnePattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::TestCheckKind, Ps>> start_one_pattern(Ps p_, prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::TestCheckKind>(crate::syntax::Pattern_)> make_fn) {
    return prism_rtl::make_rc<OnePattern>(p_, make_fn);
}


/// AllPlain: fn [TextSegTok] -> Bool
bool all_plain(const Array<crate::syntax::lexer::TextSegTok>& segs) {
    return fold(segs, true, [&](const bool& ok, const crate::syntax::lexer::TextSegTok& s) { return ok && is_plain_seg(s); });
}


/// IsPlainSeg: fn TextSegTok -> Bool
bool is_plain_seg(const crate::syntax::lexer::TextSegTok& text_seg_tok0) {
    if (prism_rtl::is<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok0)) {
        return true;
    }
    {
        return false;
    }
}


/// PlainOf: fn TextSegTok -> Text
Text plain_of(const crate::syntax::lexer::TextSegTok& text_seg_tok0) {
    if (prism_rtl::is<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok0)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok0).a0;
        return s;
    }
    {
        return Text::lit("");
    }
}


/// ParseNatText: fn Text -> Nat
Nat parse_nat_text(const Text& text0) {
    auto text = concat(split(text0, Text::lit("_")));
    return crate::syntax::lexer::has_prefix(text, Text::lit("0x"))
        ? or_(crate::syntax::lexer::parse_hex(crate::syntax::lexer::drop_prefix(text, Text::lit("0x"))), Nat(0u))
        : crate::syntax::lexer::has_prefix(text, Text::lit("0o"))
        ? or_(parse_radix(crate::syntax::lexer::drop_prefix(text, Text::lit("0o")), Nat(8u)), Nat(0u))
        : crate::syntax::lexer::has_prefix(text, Text::lit("0b"))
        ? or_(parse_radix(crate::syntax::lexer::drop_prefix(text, Text::lit("0b")), Nat(2u)), Nat(0u))
        : or_(parse_nat_opt(text), Nat(0u));
}


/// ?ParseRadix: fn Text, Nat -> ?Nat
std::optional<Nat> parse_radix(const Text& t, const Nat& radix) {
    return ({
        __label__ g106493;
        prism_rtl::Slot<std::optional<Nat>> g106493_v;
        {
            if (!((t != Text::lit("")) && crate::syntax::lexer::all_chars(t, ({
                auto radix_1 = radix;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
                return ({
                    auto radix_1_2 = radix_1;
                    once_job([=]() {
                    return ({
                        auto c = p0;
                        (prism_rtl::finished(crate::syntax::lexer::is_digit(c) && (crate::syntax::lexer::hex_value(c) < radix_1_2)));
                    });
                });
                });
            })));
            })))) {
                { g106493_v.set(std::nullopt); goto g106493; }
            }
            g106493_v.set(std::optional(crate::syntax::lexer::fold_chars(t, Nat(0u), ({
                auto radix_1 = radix;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=](std::tuple<Nat, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto radix_1_2 = radix_1;
                    once_job([=]() {
                    return ({
                        auto n = p0;
                        auto c = p1;
                        (prism_rtl::finished((n * radix_1_2) + crate::syntax::lexer::hex_value(c)));
                    });
                });
                });
            })));
            }))));
        }
    g106493:
        g106493_v.take();
    });
}

}  // namespace crate::syntax::parser
