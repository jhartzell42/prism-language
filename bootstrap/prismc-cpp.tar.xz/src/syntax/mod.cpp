// The module `Syntax`, from `target/bootstrap/cpp-src/prismc/syntax/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>

namespace crate::syntax {

void Arg::show(Printer& p) const {
    p.record("Arg", {{"name", name}, {"value", value}, {"span", span}});
}

Pod Arg::to_pod() const {
    return Pod::record("Arg", {{"name", prism_rtl::to_pod(name)}, {"value", prism_rtl::to_pod(value)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Arg> Arg::from_pod(const Pod& whole) {
    return Arg{.name = TRY(prism_rtl::from_pod<std::optional<Ident>>(TRY(crate::prelude::field(whole, "name")))), .value = TRY(prism_rtl::from_pod<Expr>(TRY(crate::prelude::field(whole, "value")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Arm::show(Printer& p) const {
    p.record("Arm", {{"pattern", pattern}, {"guard", guard}, {"body", body}, {"span", span}});
}

Pod Arm::to_pod() const {
    return Pod::record("Arm", {{"pattern", prism_rtl::to_pod(pattern)}, {"guard", prism_rtl::to_pod(guard)}, {"body", prism_rtl::to_pod(body)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Arm> Arm::from_pod(const Pod& whole) {
    return Arm{.pattern = TRY(prism_rtl::from_pod<std::optional<Pattern_>>(TRY(crate::prelude::field(whole, "pattern")))), .guard = TRY(prism_rtl::from_pod<std::optional<Expr>>(TRY(crate::prelude::field(whole, "guard")))), .body = TRY(prism_rtl::from_pod<Block>(TRY(crate::prelude::field(whole, "body")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Block::show(Printer& p) const {
    p.record("Block", {{"stmts", stmts}, {"inline", inline_}, {"span", span}});
}

Pod Block::to_pod() const {
    return Pod::record("Block", {{"stmts", prism_rtl::to_pod(stmts)}, {"inline", prism_rtl::to_pod(inline_)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Block> Block::from_pod(const Pod& whole) {
    return Block{.stmts = TRY(prism_rtl::from_pod<Array<Stmt>>(TRY(crate::prelude::field(whole, "stmts")))), .inline_ = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "inline")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Color::show(Printer& p) const {
    if (auto c = std::get_if<Bounded>(&cases())) p.choice("Bounded", {});
    else if (auto c = std::get_if<Unbounded>(&cases())) p.choice("Unbounded", {});
    else if (auto c = std::get_if<ColorVar>(&cases())) p.choice("ColorVar", {c->a0});
}

Pod Color::to_pod() const {
    return std::holds_alternative<Bounded>(cases()) ? Pod::choice("Bounded", {})
        : std::holds_alternative<Unbounded>(cases()) ? Pod::choice("Unbounded", {})
        : std::holds_alternative<ColorVar>(cases()) ? Pod::choice("ColorVar", {prism_rtl::to_pod(std::get<ColorVar>(cases()).a0)})
        : Pod();
}

Result<Color> Color::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "Bounded" && c->args.size() == 0) return Color(Bounded{});
        if (c->ctor == "Unbounded" && c->args.size() == 0) return Color(Unbounded{});
        if (c->ctor == "ColorVar" && c->args.size() == 1) return Color(ColorVar{TRY(prism_rtl::from_pod<Ident>(c->args[0]))});
    }
    return mismatch<Color>("a Color", p);
}


void Cond::show(Printer& p) const {
    if (auto c = std::get_if<CondExpr>(&cases())) p.choice("CondExpr", {c->a0});
    else if (auto c = std::get_if<CondBind>(&cases())) p.choice("CondBind", {c->a0, c->a1, c->a2});
}

Pod Cond::to_pod() const {
    return std::holds_alternative<CondExpr>(cases()) ? Pod::choice("CondExpr", {prism_rtl::to_pod(std::get<CondExpr>(cases()).a0)})
        : std::holds_alternative<CondBind>(cases()) ? Pod::choice("CondBind", {prism_rtl::to_pod(std::get<CondBind>(cases()).a0), prism_rtl::to_pod(std::get<CondBind>(cases()).a1), prism_rtl::to_pod(std::get<CondBind>(cases()).a2)})
        : Pod();
}

Result<Cond> Cond::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "CondExpr" && c->args.size() == 1) return Cond(CondExpr{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "CondBind" && c->args.size() == 3) return Cond(CondBind{TRY(prism_rtl::from_pod<Pattern_>(c->args[0])), TRY(prism_rtl::from_pod<Expr>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Expr>>(c->args[2]))});
    }
    return mismatch<Cond>("a Cond", p);
}


void Diag::show(Printer& p) const {
    p.record("Diag", {{"stage", stage}, {"span", span}, {"message", message}, {"feature", feature}});
}

Pod Diag::to_pod() const {
    return Pod::record("Diag", {{"stage", prism_rtl::to_pod(stage)}, {"span", prism_rtl::to_pod(span)}, {"message", prism_rtl::to_pod(message)}, {"feature", prism_rtl::to_pod(feature)}});
}

Result<Diag> Diag::from_pod(const Pod& whole) {
    return Diag{.stage = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "stage")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span")))), .message = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "message")))), .feature = TRY(prism_rtl::from_pod<std::optional<Text>>(TRY(crate::prelude::field(whole, "feature"))))};
}


void Expr::show(Printer& p) const {
    p.record("Expr", {{"kind", kind}, {"span", span}});
}

Pod Expr::to_pod() const {
    return Pod::record("Expr", {{"kind", prism_rtl::to_pod(kind)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Expr> Expr::from_pod(const Pod& whole) {
    return Expr{.kind = TRY(prism_rtl::from_pod<ExprKind>(TRY(crate::prelude::field(whole, "kind")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void ExprKind::show(Printer& p) const {
    if (auto c = std::get_if<EName>(&cases())) p.choice("EName", {c->a0});
    else if (auto c = std::get_if<ELit>(&cases())) p.choice("ELit", {c->a0});
    else if (auto c = std::get_if<EUnit>(&cases())) p.choice("EUnit", {c->a0});
    else if (auto c = std::get_if<ENil>(&cases())) p.choice("ENil", {c->a0});
    else if (auto c = std::get_if<EBound>(&cases())) p.choice("EBound", {c->a0});
    else if (auto c = std::get_if<ETuple>(&cases())) p.choice("ETuple", {c->a0});
    else if (auto c = std::get_if<EArray>(&cases())) p.choice("EArray", {c->a0});
    else if (auto c = std::get_if<EMap>(&cases())) p.choice("EMap", {c->a0});
    else if (auto c = std::get_if<EGroup>(&cases())) p.choice("EGroup", {c->a0});
    else if (auto c = std::get_if<ECall>(&cases())) p.choice("ECall", {c->a0, c->a1, c->a2, c->a3});
    else if (auto c = std::get_if<EBinary>(&cases())) p.choice("EBinary", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<EUnary>(&cases())) p.choice("EUnary", {c->a0, c->a1});
    else if (auto c = std::get_if<ESuffixed>(&cases())) p.choice("ESuffixed", {c->a0, c->a1, c->a2, c->a3});
    else if (auto c = std::get_if<EFreeSigil>(&cases())) p.choice("EFreeSigil", {c->a0, c->a1});
    else if (auto c = std::get_if<EField>(&cases())) p.choice("EField", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<EIndex>(&cases())) p.choice("EIndex", {c->a0, c->a1});
    else if (auto c = std::get_if<ETopicField>(&cases())) p.choice("ETopicField", {c->a0});
    else if (auto c = std::get_if<ETopicIndex>(&cases())) p.choice("ETopicIndex", {c->a0});
    else if (auto c = std::get_if<EMethod>(&cases())) p.choice("EMethod", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<ETypeArgs>(&cases())) p.choice("ETypeArgs", {c->a0, c->a1});
    else if (auto c = std::get_if<ECast>(&cases())) p.choice("ECast", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<ENonEmpty>(&cases())) p.choice("ENonEmpty", {c->a0});
    else if (auto c = std::get_if<EAbsent>(&cases())) p.choice("EAbsent", {});
    else if (auto c = std::get_if<ERest>(&cases())) p.choice("ERest", {});
    else if (auto c = std::get_if<ELambda>(&cases())) p.choice("ELambda", {c->a0, c->a1});
    else if (auto c = std::get_if<EIf>(&cases())) p.choice("EIf", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<EMatch>(&cases())) p.choice("EMatch", {c->a0, c->a1});
    else if (auto c = std::get_if<ERebuild>(&cases())) p.choice("ERebuild", {c->a0, c->a1});
    else if (auto c = std::get_if<EFor>(&cases())) p.choice("EFor", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<EGiven>(&cases())) p.choice("EGiven", {c->a0});
    else if (auto c = std::get_if<EUpdate>(&cases())) p.choice("EUpdate", {c->a0, c->a1});
    else if (auto c = std::get_if<EWidgetBlock>(&cases())) p.choice("EWidgetBlock", {c->a0});
    else if (auto c = std::get_if<EMonad>(&cases())) p.choice("EMonad", {c->a0, c->a1});
    else if (auto c = std::get_if<ETemplate>(&cases())) p.choice("ETemplate", {c->a0});
    else if (auto c = std::get_if<EAny>(&cases())) p.choice("EAny", {c->a0});
    else if (auto c = std::get_if<ELens>(&cases())) p.choice("ELens", {c->a0});
    else if (auto c = std::get_if<EError>(&cases())) p.choice("EError", {});
}

Pod ExprKind::to_pod() const {
    return std::holds_alternative<EName>(cases()) ? Pod::choice("EName", {prism_rtl::to_pod(std::get<EName>(cases()).a0)})
        : std::holds_alternative<ELit>(cases()) ? Pod::choice("ELit", {prism_rtl::to_pod(std::get<ELit>(cases()).a0)})
        : std::holds_alternative<EUnit>(cases()) ? Pod::choice("EUnit", {prism_rtl::to_pod(std::get<EUnit>(cases()).a0)})
        : std::holds_alternative<ENil>(cases()) ? Pod::choice("ENil", {prism_rtl::to_pod(std::get<ENil>(cases()).a0)})
        : std::holds_alternative<EBound>(cases()) ? Pod::choice("EBound", {prism_rtl::to_pod(std::get<EBound>(cases()).a0)})
        : std::holds_alternative<ETuple>(cases()) ? Pod::choice("ETuple", {prism_rtl::to_pod(std::get<ETuple>(cases()).a0)})
        : std::holds_alternative<EArray>(cases()) ? Pod::choice("EArray", {prism_rtl::to_pod(std::get<EArray>(cases()).a0)})
        : std::holds_alternative<EMap>(cases()) ? Pod::choice("EMap", {prism_rtl::to_pod(std::get<EMap>(cases()).a0)})
        : std::holds_alternative<EGroup>(cases()) ? Pod::choice("EGroup", {prism_rtl::to_pod(std::get<EGroup>(cases()).a0)})
        : std::holds_alternative<ECall>(cases()) ? Pod::choice("ECall", {prism_rtl::to_pod(std::get<ECall>(cases()).a0), prism_rtl::to_pod(std::get<ECall>(cases()).a1), prism_rtl::to_pod(std::get<ECall>(cases()).a2), prism_rtl::to_pod(std::get<ECall>(cases()).a3)})
        : std::holds_alternative<EBinary>(cases()) ? Pod::choice("EBinary", {prism_rtl::to_pod(std::get<EBinary>(cases()).a0), prism_rtl::to_pod(std::get<EBinary>(cases()).a1), prism_rtl::to_pod(std::get<EBinary>(cases()).a2)})
        : std::holds_alternative<EUnary>(cases()) ? Pod::choice("EUnary", {prism_rtl::to_pod(std::get<EUnary>(cases()).a0), prism_rtl::to_pod(std::get<EUnary>(cases()).a1)})
        : std::holds_alternative<ESuffixed>(cases()) ? Pod::choice("ESuffixed", {prism_rtl::to_pod(std::get<ESuffixed>(cases()).a0), prism_rtl::to_pod(std::get<ESuffixed>(cases()).a1), prism_rtl::to_pod(std::get<ESuffixed>(cases()).a2), prism_rtl::to_pod(std::get<ESuffixed>(cases()).a3)})
        : std::holds_alternative<EFreeSigil>(cases()) ? Pod::choice("EFreeSigil", {prism_rtl::to_pod(std::get<EFreeSigil>(cases()).a0), prism_rtl::to_pod(std::get<EFreeSigil>(cases()).a1)})
        : std::holds_alternative<EField>(cases()) ? Pod::choice("EField", {prism_rtl::to_pod(std::get<EField>(cases()).a0), prism_rtl::to_pod(std::get<EField>(cases()).a1), prism_rtl::to_pod(std::get<EField>(cases()).a2)})
        : std::holds_alternative<EIndex>(cases()) ? Pod::choice("EIndex", {prism_rtl::to_pod(std::get<EIndex>(cases()).a0), prism_rtl::to_pod(std::get<EIndex>(cases()).a1)})
        : std::holds_alternative<ETopicField>(cases()) ? Pod::choice("ETopicField", {prism_rtl::to_pod(std::get<ETopicField>(cases()).a0)})
        : std::holds_alternative<ETopicIndex>(cases()) ? Pod::choice("ETopicIndex", {prism_rtl::to_pod(std::get<ETopicIndex>(cases()).a0)})
        : std::holds_alternative<EMethod>(cases()) ? Pod::choice("EMethod", {prism_rtl::to_pod(std::get<EMethod>(cases()).a0), prism_rtl::to_pod(std::get<EMethod>(cases()).a1), prism_rtl::to_pod(std::get<EMethod>(cases()).a2)})
        : std::holds_alternative<ETypeArgs>(cases()) ? Pod::choice("ETypeArgs", {prism_rtl::to_pod(std::get<ETypeArgs>(cases()).a0), prism_rtl::to_pod(std::get<ETypeArgs>(cases()).a1)})
        : std::holds_alternative<ECast>(cases()) ? Pod::choice("ECast", {prism_rtl::to_pod(std::get<ECast>(cases()).a0), prism_rtl::to_pod(std::get<ECast>(cases()).a1), prism_rtl::to_pod(std::get<ECast>(cases()).a2)})
        : std::holds_alternative<ENonEmpty>(cases()) ? Pod::choice("ENonEmpty", {prism_rtl::to_pod(std::get<ENonEmpty>(cases()).a0)})
        : std::holds_alternative<EAbsent>(cases()) ? Pod::choice("EAbsent", {})
        : std::holds_alternative<ERest>(cases()) ? Pod::choice("ERest", {})
        : std::holds_alternative<ELambda>(cases()) ? Pod::choice("ELambda", {prism_rtl::to_pod(std::get<ELambda>(cases()).a0), prism_rtl::to_pod(std::get<ELambda>(cases()).a1)})
        : std::holds_alternative<EIf>(cases()) ? Pod::choice("EIf", {prism_rtl::to_pod(std::get<EIf>(cases()).a0), prism_rtl::to_pod(std::get<EIf>(cases()).a1), prism_rtl::to_pod(std::get<EIf>(cases()).a2)})
        : std::holds_alternative<EMatch>(cases()) ? Pod::choice("EMatch", {prism_rtl::to_pod(std::get<EMatch>(cases()).a0), prism_rtl::to_pod(std::get<EMatch>(cases()).a1)})
        : std::holds_alternative<ERebuild>(cases()) ? Pod::choice("ERebuild", {prism_rtl::to_pod(std::get<ERebuild>(cases()).a0), prism_rtl::to_pod(std::get<ERebuild>(cases()).a1)})
        : std::holds_alternative<EFor>(cases()) ? Pod::choice("EFor", {prism_rtl::to_pod(std::get<EFor>(cases()).a0), prism_rtl::to_pod(std::get<EFor>(cases()).a1), prism_rtl::to_pod(std::get<EFor>(cases()).a2)})
        : std::holds_alternative<EGiven>(cases()) ? Pod::choice("EGiven", {prism_rtl::to_pod(std::get<EGiven>(cases()).a0)})
        : std::holds_alternative<EUpdate>(cases()) ? Pod::choice("EUpdate", {prism_rtl::to_pod(std::get<EUpdate>(cases()).a0), prism_rtl::to_pod(std::get<EUpdate>(cases()).a1)})
        : std::holds_alternative<EWidgetBlock>(cases()) ? Pod::choice("EWidgetBlock", {prism_rtl::to_pod(std::get<EWidgetBlock>(cases()).a0)})
        : std::holds_alternative<EMonad>(cases()) ? Pod::choice("EMonad", {prism_rtl::to_pod(std::get<EMonad>(cases()).a0), prism_rtl::to_pod(std::get<EMonad>(cases()).a1)})
        : std::holds_alternative<ETemplate>(cases()) ? Pod::choice("ETemplate", {prism_rtl::to_pod(std::get<ETemplate>(cases()).a0)})
        : std::holds_alternative<EAny>(cases()) ? Pod::choice("EAny", {prism_rtl::to_pod(std::get<EAny>(cases()).a0)})
        : std::holds_alternative<ELens>(cases()) ? Pod::choice("ELens", {prism_rtl::to_pod(std::get<ELens>(cases()).a0)})
        : std::holds_alternative<EError>(cases()) ? Pod::choice("EError", {})
        : Pod();
}

Result<ExprKind> ExprKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "EName" && c->args.size() == 1) return ExprKind(EName{TRY(prism_rtl::from_pod<SName>(c->args[0]))});
        if (c->ctor == "ELit" && c->args.size() == 1) return ExprKind(ELit{TRY(prism_rtl::from_pod<Literal>(c->args[0]))});
        if (c->ctor == "EUnit" && c->args.size() == 1) return ExprKind(EUnit{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "ENil" && c->args.size() == 1) return ExprKind(ENil{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "EBound" && c->args.size() == 1) return ExprKind(EBound{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "ETuple" && c->args.size() == 1) return ExprKind(ETuple{TRY(prism_rtl::from_pod<Array<Expr>>(c->args[0]))});
        if (c->ctor == "EArray" && c->args.size() == 1) return ExprKind(EArray{TRY(prism_rtl::from_pod<Array<Expr>>(c->args[0]))});
        if (c->ctor == "EMap" && c->args.size() == 1) return ExprKind(EMap{TRY(prism_rtl::from_pod<Array<std::tuple<Expr, Expr>>>(c->args[0]))});
        if (c->ctor == "EGroup" && c->args.size() == 1) return ExprKind(EGroup{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "ECall" && c->args.size() == 4) return ExprKind(ECall{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Array<Arg>>(c->args[1])), TRY(prism_rtl::from_pod<bool>(c->args[2])), TRY(prism_rtl::from_pod<bool>(c->args[3]))});
        if (c->ctor == "EBinary" && c->args.size() == 3) return ExprKind(EBinary{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Expr>(c->args[1])), TRY(prism_rtl::from_pod<Expr>(c->args[2]))});
        if (c->ctor == "EUnary" && c->args.size() == 2) return ExprKind(EUnary{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Expr>(c->args[1]))});
        if (c->ctor == "ESuffixed" && c->args.size() == 4) return ExprKind(ESuffixed{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<QualName>(c->args[1])), TRY(prism_rtl::from_pod<Expr>(c->args[2])), TRY(prism_rtl::from_pod<Expr>(c->args[3]))});
        if (c->ctor == "EFreeSigil" && c->args.size() == 2) return ExprKind(EFreeSigil{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Expr>(c->args[1]))});
        if (c->ctor == "EField" && c->args.size() == 3) return ExprKind(EField{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Ident>(c->args[2]))});
        if (c->ctor == "EIndex" && c->args.size() == 2) return ExprKind(EIndex{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Expr>(c->args[1]))});
        if (c->ctor == "ETopicField" && c->args.size() == 1) return ExprKind(ETopicField{TRY(prism_rtl::from_pod<Ident>(c->args[0]))});
        if (c->ctor == "ETopicIndex" && c->args.size() == 1) return ExprKind(ETopicIndex{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "EMethod" && c->args.size() == 3) return ExprKind(EMethod{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<SName>(c->args[1])), TRY(prism_rtl::from_pod<Array<Arg>>(c->args[2]))});
        if (c->ctor == "ETypeArgs" && c->args.size() == 2) return ExprKind(ETypeArgs{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Array<Type>>(c->args[1]))});
        if (c->ctor == "ECast" && c->args.size() == 3) return ExprKind(ECast{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Type>(c->args[1])), TRY(prism_rtl::from_pod<bool>(c->args[2]))});
        if (c->ctor == "ENonEmpty" && c->args.size() == 1) return ExprKind(ENonEmpty{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "EAbsent" && c->args.size() == 0) return ExprKind(EAbsent{});
        if (c->ctor == "ERest" && c->args.size() == 0) return ExprKind(ERest{});
        if (c->ctor == "ELambda" && c->args.size() == 2) return ExprKind(ELambda{TRY(prism_rtl::from_pod<std::optional<Array<Pattern_>>>(c->args[0])), TRY(prism_rtl::from_pod<LambdaBody>(c->args[1]))});
        if (c->ctor == "EIf" && c->args.size() == 3) return ExprKind(EIf{TRY(prism_rtl::from_pod<Cond>(c->args[0])), TRY(prism_rtl::from_pod<Block>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Block>>(c->args[2]))});
        if (c->ctor == "EMatch" && c->args.size() == 2) return ExprKind(EMatch{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Array<Arm>>(c->args[1]))});
        if (c->ctor == "ERebuild" && c->args.size() == 2) return ExprKind(ERebuild{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Block>(c->args[1]))});
        if (c->ctor == "EFor" && c->args.size() == 3) return ExprKind(EFor{TRY(prism_rtl::from_pod<std::optional<ForBinders>>(c->args[0])), TRY(prism_rtl::from_pod<Expr>(c->args[1])), TRY(prism_rtl::from_pod<Block>(c->args[2]))});
        if (c->ctor == "EGiven" && c->args.size() == 1) return ExprKind(EGiven{TRY(prism_rtl::from_pod<Block>(c->args[0]))});
        if (c->ctor == "EUpdate" && c->args.size() == 2) return ExprKind(EUpdate{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Block>(c->args[1]))});
        if (c->ctor == "EWidgetBlock" && c->args.size() == 1) return ExprKind(EWidgetBlock{TRY(prism_rtl::from_pod<Block>(c->args[0]))});
        if (c->ctor == "EMonad" && c->args.size() == 2) return ExprKind(EMonad{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Block>(c->args[1]))});
        if (c->ctor == "ETemplate" && c->args.size() == 1) return ExprKind(ETemplate{TRY(prism_rtl::from_pod<Template>(c->args[0]))});
        if (c->ctor == "EAny" && c->args.size() == 1) return ExprKind(EAny{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "ELens" && c->args.size() == 1) return ExprKind(ELens{TRY(prism_rtl::from_pod<Array<Ident>>(c->args[0]))});
        if (c->ctor == "EError" && c->args.size() == 0) return ExprKind(EError{});
    }
    return mismatch<ExprKind>("a ExprKind", p);
}


void FieldPat::show(Printer& p) const {
    p.record("FieldPat", {{"name", name}, {"pattern", pattern}, {"span", span}});
}

Pod FieldPat::to_pod() const {
    return Pod::record("FieldPat", {{"name", prism_rtl::to_pod(name)}, {"pattern", prism_rtl::to_pod(pattern)}, {"span", prism_rtl::to_pod(span)}});
}

Result<FieldPat> FieldPat::from_pod(const Pod& whole) {
    return FieldPat{.name = TRY(prism_rtl::from_pod<std::optional<Ident>>(TRY(crate::prelude::field(whole, "name")))), .pattern = TRY(prism_rtl::from_pod<Pattern_>(TRY(crate::prelude::field(whole, "pattern")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void ForBinders::show(Printer& p) const {
    p.record("ForBinders", {{"first", first}, {"second", second}});
}

Pod ForBinders::to_pod() const {
    return Pod::record("ForBinders", {{"first", prism_rtl::to_pod(first)}, {"second", prism_rtl::to_pod(second)}});
}

Result<ForBinders> ForBinders::from_pod(const Pod& whole) {
    return ForBinders{.first = TRY(prism_rtl::from_pod<Pattern_>(TRY(crate::prelude::field(whole, "first")))), .second = TRY(prism_rtl::from_pod<std::optional<Pattern_>>(TRY(crate::prelude::field(whole, "second"))))};
}


void Ident::show(Printer& p) const {
    p.record("Ident", {{"name", name}, {"span", span}});
}

Pod Ident::to_pod() const {
    return Pod::record("Ident", {{"name", prism_rtl::to_pod(name)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Ident> Ident::from_pod(const Pod& whole) {
    return Ident{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void LambdaBody::show(Printer& p) const {
    if (auto c = std::get_if<LbExpr>(&cases())) p.choice("LbExpr", {c->a0});
    else if (auto c = std::get_if<LbBlock>(&cases())) p.choice("LbBlock", {c->a0});
}

Pod LambdaBody::to_pod() const {
    return std::holds_alternative<LbExpr>(cases()) ? Pod::choice("LbExpr", {prism_rtl::to_pod(std::get<LbExpr>(cases()).a0)})
        : std::holds_alternative<LbBlock>(cases()) ? Pod::choice("LbBlock", {prism_rtl::to_pod(std::get<LbBlock>(cases()).a0)})
        : Pod();
}

Result<LambdaBody> LambdaBody::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "LbExpr" && c->args.size() == 1) return LambdaBody(LbExpr{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "LbBlock" && c->args.size() == 1) return LambdaBody(LbBlock{TRY(prism_rtl::from_pod<Block>(c->args[0]))});
    }
    return mismatch<LambdaBody>("a LambdaBody", p);
}


void LitKind::show(Printer& p) const {
    if (auto c = std::get_if<LInt>(&cases())) p.choice("LInt", {c->a0});
    else if (auto c = std::get_if<LFloat>(&cases())) p.choice("LFloat", {c->a0});
    else if (auto c = std::get_if<LDuration>(&cases())) p.choice("LDuration", {c->a0, c->a1});
    else if (auto c = std::get_if<LChar>(&cases())) p.choice("LChar", {c->a0});
    else if (auto c = std::get_if<LText>(&cases())) p.choice("LText", {c->a0});
}

Pod LitKind::to_pod() const {
    return std::holds_alternative<LInt>(cases()) ? Pod::choice("LInt", {prism_rtl::to_pod(std::get<LInt>(cases()).a0)})
        : std::holds_alternative<LFloat>(cases()) ? Pod::choice("LFloat", {prism_rtl::to_pod(std::get<LFloat>(cases()).a0)})
        : std::holds_alternative<LDuration>(cases()) ? Pod::choice("LDuration", {prism_rtl::to_pod(std::get<LDuration>(cases()).a0), prism_rtl::to_pod(std::get<LDuration>(cases()).a1)})
        : std::holds_alternative<LChar>(cases()) ? Pod::choice("LChar", {prism_rtl::to_pod(std::get<LChar>(cases()).a0)})
        : std::holds_alternative<LText>(cases()) ? Pod::choice("LText", {prism_rtl::to_pod(std::get<LText>(cases()).a0)})
        : Pod();
}

Result<LitKind> LitKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "LInt" && c->args.size() == 1) return LitKind(LInt{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "LFloat" && c->args.size() == 1) return LitKind(LFloat{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "LDuration" && c->args.size() == 2) return LitKind(LDuration{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "LChar" && c->args.size() == 1) return LitKind(LChar{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "LText" && c->args.size() == 1) return LitKind(LText{TRY(prism_rtl::from_pod<Array<TextSeg>>(c->args[0]))});
    }
    return mismatch<LitKind>("a LitKind", p);
}


void Literal::show(Printer& p) const {
    p.record("Literal", {{"marks", marks}, {"kind", kind}, {"span", span}});
}

Pod Literal::to_pod() const {
    return Pod::record("Literal", {{"marks", prism_rtl::to_pod(marks)}, {"kind", prism_rtl::to_pod(kind)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Literal> Literal::from_pod(const Pod& whole) {
    return Literal{.marks = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "marks")))), .kind = TRY(prism_rtl::from_pod<LitKind>(TRY(crate::prelude::field(whole, "kind")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void ModLine::show(Printer& p) const {
    p.record("ModLine", {{"name", name}, {"is_test", is_test}, {"span", span}});
}

Pod ModLine::to_pod() const {
    return Pod::record("ModLine", {{"name", prism_rtl::to_pod(name)}, {"is_test", prism_rtl::to_pod(is_test)}, {"span", prism_rtl::to_pod(span)}});
}

Result<ModLine> ModLine::from_pod(const Pod& whole) {
    return ModLine{.name = TRY(prism_rtl::from_pod<Ident>(TRY(crate::prelude::field(whole, "name")))), .is_test = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "is_test")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Module::show(Printer& p) const {
    p.record("Module", {{"name", name}, {"emit_row", emit_row}, {"mods", mods}, {"uses", uses}, {"decls", decls}, {"template", template_}, {"span", span}});
}

Pod Module::to_pod() const {
    return Pod::record("Module", {{"name", prism_rtl::to_pod(name)}, {"emit_row", prism_rtl::to_pod(emit_row)}, {"mods", prism_rtl::to_pod(mods)}, {"uses", prism_rtl::to_pod(uses)}, {"decls", prism_rtl::to_pod(decls)}, {"template", prism_rtl::to_pod(template_)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Module> Module::from_pod(const Pod& whole) {
    return Module{.name = TRY(prism_rtl::from_pod<std::optional<QualName>>(TRY(crate::prelude::field(whole, "name")))), .emit_row = TRY(prism_rtl::from_pod<std::optional<Row_>>(TRY(crate::prelude::field(whole, "emit_row")))), .mods = TRY(prism_rtl::from_pod<Array<ModLine>>(TRY(crate::prelude::field(whole, "mods")))), .uses = TRY(prism_rtl::from_pod<Array<Use>>(TRY(crate::prelude::field(whole, "uses")))), .decls = TRY(prism_rtl::from_pod<Array<crate::syntax::decls::Decl>>(TRY(crate::prelude::field(whole, "decls")))), .template_ = TRY(prism_rtl::from_pod<std::optional<Template>>(TRY(crate::prelude::field(whole, "template")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Pattern_::show(Printer& p) const {
    p.record("Pattern", {{"kind", kind}, {"span", span}});
}

Pod Pattern_::to_pod() const {
    return Pod::record("Pattern", {{"kind", prism_rtl::to_pod(kind)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Pattern_> Pattern_::from_pod(const Pod& whole) {
    return Pattern_{.kind = TRY(prism_rtl::from_pod<PatternKind>(TRY(crate::prelude::field(whole, "kind")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void PatternKind::show(Printer& p) const {
    if (auto c = std::get_if<PName>(&cases())) p.choice("PName", {c->a0});
    else if (auto c = std::get_if<PIgnore>(&cases())) p.choice("PIgnore", {});
    else if (auto c = std::get_if<PLit>(&cases())) p.choice("PLit", {c->a0});
    else if (auto c = std::get_if<PNeg>(&cases())) p.choice("PNeg", {c->a0});
    else if (auto c = std::get_if<PUnit>(&cases())) p.choice("PUnit", {});
    else if (auto c = std::get_if<PNil>(&cases())) p.choice("PNil", {});
    else if (auto c = std::get_if<PCtor>(&cases())) p.choice("PCtor", {c->a0, c->a1});
    else if (auto c = std::get_if<PRecord>(&cases())) p.choice("PRecord", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<PSigil>(&cases())) p.choice("PSigil", {c->a0, c->a1});
    else if (auto c = std::get_if<PTuple>(&cases())) p.choice("PTuple", {c->a0});
    else if (auto c = std::get_if<PArray>(&cases())) p.choice("PArray", {c->a0});
    else if (auto c = std::get_if<PGroup>(&cases())) p.choice("PGroup", {c->a0});
    else if (auto c = std::get_if<PFamily>(&cases())) p.choice("PFamily", {c->a0});
}

Pod PatternKind::to_pod() const {
    return std::holds_alternative<PName>(cases()) ? Pod::choice("PName", {prism_rtl::to_pod(std::get<PName>(cases()).a0)})
        : std::holds_alternative<PIgnore>(cases()) ? Pod::choice("PIgnore", {})
        : std::holds_alternative<PLit>(cases()) ? Pod::choice("PLit", {prism_rtl::to_pod(std::get<PLit>(cases()).a0)})
        : std::holds_alternative<PNeg>(cases()) ? Pod::choice("PNeg", {prism_rtl::to_pod(std::get<PNeg>(cases()).a0)})
        : std::holds_alternative<PUnit>(cases()) ? Pod::choice("PUnit", {})
        : std::holds_alternative<PNil>(cases()) ? Pod::choice("PNil", {})
        : std::holds_alternative<PCtor>(cases()) ? Pod::choice("PCtor", {prism_rtl::to_pod(std::get<PCtor>(cases()).a0), prism_rtl::to_pod(std::get<PCtor>(cases()).a1)})
        : std::holds_alternative<PRecord>(cases()) ? Pod::choice("PRecord", {prism_rtl::to_pod(std::get<PRecord>(cases()).a0), prism_rtl::to_pod(std::get<PRecord>(cases()).a1), prism_rtl::to_pod(std::get<PRecord>(cases()).a2)})
        : std::holds_alternative<PSigil>(cases()) ? Pod::choice("PSigil", {prism_rtl::to_pod(std::get<PSigil>(cases()).a0), prism_rtl::to_pod(std::get<PSigil>(cases()).a1)})
        : std::holds_alternative<PTuple>(cases()) ? Pod::choice("PTuple", {prism_rtl::to_pod(std::get<PTuple>(cases()).a0)})
        : std::holds_alternative<PArray>(cases()) ? Pod::choice("PArray", {prism_rtl::to_pod(std::get<PArray>(cases()).a0)})
        : std::holds_alternative<PGroup>(cases()) ? Pod::choice("PGroup", {prism_rtl::to_pod(std::get<PGroup>(cases()).a0)})
        : std::holds_alternative<PFamily>(cases()) ? Pod::choice("PFamily", {prism_rtl::to_pod(std::get<PFamily>(cases()).a0)})
        : Pod();
}

Result<PatternKind> PatternKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "PName" && c->args.size() == 1) return PatternKind(PName{TRY(prism_rtl::from_pod<SName>(c->args[0]))});
        if (c->ctor == "PIgnore" && c->args.size() == 0) return PatternKind(PIgnore{});
        if (c->ctor == "PLit" && c->args.size() == 1) return PatternKind(PLit{TRY(prism_rtl::from_pod<Literal>(c->args[0]))});
        if (c->ctor == "PNeg" && c->args.size() == 1) return PatternKind(PNeg{TRY(prism_rtl::from_pod<Literal>(c->args[0]))});
        if (c->ctor == "PUnit" && c->args.size() == 0) return PatternKind(PUnit{});
        if (c->ctor == "PNil" && c->args.size() == 0) return PatternKind(PNil{});
        if (c->ctor == "PCtor" && c->args.size() == 2) return PatternKind(PCtor{TRY(prism_rtl::from_pod<SName>(c->args[0])), TRY(prism_rtl::from_pod<Array<Pattern_>>(c->args[1]))});
        if (c->ctor == "PRecord" && c->args.size() == 3) return PatternKind(PRecord{TRY(prism_rtl::from_pod<SName>(c->args[0])), TRY(prism_rtl::from_pod<Array<FieldPat>>(c->args[1])), TRY(prism_rtl::from_pod<bool>(c->args[2]))});
        if (c->ctor == "PSigil" && c->args.size() == 2) return PatternKind(PSigil{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Pattern_>(c->args[1]))});
        if (c->ctor == "PTuple" && c->args.size() == 1) return PatternKind(PTuple{TRY(prism_rtl::from_pod<Array<Pattern_>>(c->args[0]))});
        if (c->ctor == "PArray" && c->args.size() == 1) return PatternKind(PArray{TRY(prism_rtl::from_pod<Array<Pattern_>>(c->args[0]))});
        if (c->ctor == "PGroup" && c->args.size() == 1) return PatternKind(PGroup{TRY(prism_rtl::from_pod<Pattern_>(c->args[0]))});
        if (c->ctor == "PFamily" && c->args.size() == 1) return PatternKind(PFamily{TRY(prism_rtl::from_pod<QualName>(c->args[0]))});
    }
    return mismatch<PatternKind>("a PatternKind", p);
}


void QualName::show(Printer& p) const {
    p.record("QualName", {{"path", path_}, {"span", span}});
}

Pod QualName::to_pod() const {
    return Pod::record("QualName", {{"path", prism_rtl::to_pod(path_)}, {"span", prism_rtl::to_pod(span)}});
}

Result<QualName> QualName::from_pod(const Pod& whole) {
    return QualName{.path_ = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "path")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Range::show(Printer& p) const {
    p.record("Range", {{"start", start}, {"end", end}});
}

Pod Range::to_pod() const {
    return Pod::record("Range", {{"start", prism_rtl::to_pod(start)}, {"end", prism_rtl::to_pod(end)}});
}

Result<Range> Range::from_pod(const Pod& whole) {
    return Range{.start = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "start")))), .end = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "end"))))};
}


void Row_::show(Printer& p) const {
    p.record("Row", {{"terms", terms}, {"span", span}});
}

Pod Row_::to_pod() const {
    return Pod::record("Row", {{"terms", prism_rtl::to_pod(terms)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Row_> Row_::from_pod(const Pod& whole) {
    return Row_{.terms = TRY(prism_rtl::from_pod<Array<RowTerm>>(TRY(crate::prelude::field(whole, "terms")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void RowTerm::show(Printer& p) const {
    if (auto c = std::get_if<RFamily>(&cases())) p.choice("RFamily", {c->a0});
    else if (auto c = std::get_if<RType>(&cases())) p.choice("RType", {c->a0});
    else if (auto c = std::get_if<RVar>(&cases())) p.choice("RVar", {c->a0});
}

Pod RowTerm::to_pod() const {
    return std::holds_alternative<RFamily>(cases()) ? Pod::choice("RFamily", {prism_rtl::to_pod(std::get<RFamily>(cases()).a0)})
        : std::holds_alternative<RType>(cases()) ? Pod::choice("RType", {prism_rtl::to_pod(std::get<RType>(cases()).a0)})
        : std::holds_alternative<RVar>(cases()) ? Pod::choice("RVar", {prism_rtl::to_pod(std::get<RVar>(cases()).a0)})
        : Pod();
}

Result<RowTerm> RowTerm::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "RFamily" && c->args.size() == 1) return RowTerm(RFamily{TRY(prism_rtl::from_pod<QualName>(c->args[0]))});
        if (c->ctor == "RType" && c->args.size() == 1) return RowTerm(RType{TRY(prism_rtl::from_pod<Type>(c->args[0]))});
        if (c->ctor == "RVar" && c->args.size() == 1) return RowTerm(RVar{TRY(prism_rtl::from_pod<Ident>(c->args[0]))});
    }
    return mismatch<RowTerm>("a RowTerm", p);
}


void SName::show(Printer& p) const {
    p.record("SName", {{"sigils", sigils}, {"path", path_}, {"span", span}});
}

Pod SName::to_pod() const {
    return Pod::record("SName", {{"sigils", prism_rtl::to_pod(sigils)}, {"path", prism_rtl::to_pod(path_)}, {"span", prism_rtl::to_pod(span)}});
}

Result<SName> SName::from_pod(const Pod& whole) {
    return SName{.sigils = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "sigils")))), .path_ = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "path")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Stmt::show(Printer& p) const {
    p.record("Stmt", {{"kind", kind}, {"span", span}});
}

Pod Stmt::to_pod() const {
    return Pod::record("Stmt", {{"kind", prism_rtl::to_pod(kind)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Stmt> Stmt::from_pod(const Pod& whole) {
    return Stmt{.kind = TRY(prism_rtl::from_pod<StmtKind>(TRY(crate::prelude::field(whole, "kind")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void StmtKind::show(Printer& p) const {
    if (auto c = std::get_if<SEmit>(&cases())) p.choice("SEmit", {c->a0});
    else if (auto c = std::get_if<SBind>(&cases())) p.choice("SBind", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<SIgnore>(&cases())) p.choice("SIgnore", {c->a0});
    else if (auto c = std::get_if<SLet>(&cases())) p.choice("SLet", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<SSignature>(&cases())) p.choice("SSignature", {c->a0});
    else if (auto c = std::get_if<SFn>(&cases())) p.choice("SFn", {c->a0});
    else if (auto c = std::get_if<SWidget>(&cases())) p.choice("SWidget", {c->a0});
    else if (auto c = std::get_if<SSet>(&cases())) p.choice("SSet", {c->a0, c->a1});
    else if (auto c = std::get_if<SAccum>(&cases())) p.choice("SAccum", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<SRequire>(&cases())) p.choice("SRequire", {c->a0});
    else if (auto c = std::get_if<SForbid>(&cases())) p.choice("SForbid", {c->a0});
    else if (auto c = std::get_if<SWhile>(&cases())) p.choice("SWhile", {c->a0, c->a1});
    else if (auto c = std::get_if<SReturn>(&cases())) p.choice("SReturn", {c->a0});
    else if (auto c = std::get_if<SExpr>(&cases())) p.choice("SExpr", {c->a0});
}

Pod StmtKind::to_pod() const {
    return std::holds_alternative<SEmit>(cases()) ? Pod::choice("SEmit", {prism_rtl::to_pod(std::get<SEmit>(cases()).a0)})
        : std::holds_alternative<SBind>(cases()) ? Pod::choice("SBind", {prism_rtl::to_pod(std::get<SBind>(cases()).a0), prism_rtl::to_pod(std::get<SBind>(cases()).a1), prism_rtl::to_pod(std::get<SBind>(cases()).a2)})
        : std::holds_alternative<SIgnore>(cases()) ? Pod::choice("SIgnore", {prism_rtl::to_pod(std::get<SIgnore>(cases()).a0)})
        : std::holds_alternative<SLet>(cases()) ? Pod::choice("SLet", {prism_rtl::to_pod(std::get<SLet>(cases()).a0), prism_rtl::to_pod(std::get<SLet>(cases()).a1), prism_rtl::to_pod(std::get<SLet>(cases()).a2)})
        : std::holds_alternative<SSignature>(cases()) ? Pod::choice("SSignature", {prism_rtl::to_pod(std::get<SSignature>(cases()).a0)})
        : std::holds_alternative<SFn>(cases()) ? Pod::choice("SFn", {prism_rtl::to_pod(std::get<SFn>(cases()).a0)})
        : std::holds_alternative<SWidget>(cases()) ? Pod::choice("SWidget", {prism_rtl::to_pod(std::get<SWidget>(cases()).a0)})
        : std::holds_alternative<SSet>(cases()) ? Pod::choice("SSet", {prism_rtl::to_pod(std::get<SSet>(cases()).a0), prism_rtl::to_pod(std::get<SSet>(cases()).a1)})
        : std::holds_alternative<SAccum>(cases()) ? Pod::choice("SAccum", {prism_rtl::to_pod(std::get<SAccum>(cases()).a0), prism_rtl::to_pod(std::get<SAccum>(cases()).a1), prism_rtl::to_pod(std::get<SAccum>(cases()).a2)})
        : std::holds_alternative<SRequire>(cases()) ? Pod::choice("SRequire", {prism_rtl::to_pod(std::get<SRequire>(cases()).a0)})
        : std::holds_alternative<SForbid>(cases()) ? Pod::choice("SForbid", {prism_rtl::to_pod(std::get<SForbid>(cases()).a0)})
        : std::holds_alternative<SWhile>(cases()) ? Pod::choice("SWhile", {prism_rtl::to_pod(std::get<SWhile>(cases()).a0), prism_rtl::to_pod(std::get<SWhile>(cases()).a1)})
        : std::holds_alternative<SReturn>(cases()) ? Pod::choice("SReturn", {prism_rtl::to_pod(std::get<SReturn>(cases()).a0)})
        : std::holds_alternative<SExpr>(cases()) ? Pod::choice("SExpr", {prism_rtl::to_pod(std::get<SExpr>(cases()).a0)})
        : Pod();
}

Result<StmtKind> StmtKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "SEmit" && c->args.size() == 1) return StmtKind(SEmit{TRY(prism_rtl::from_pod<Row_>(c->args[0]))});
        if (c->ctor == "SBind" && c->args.size() == 3) return StmtKind(SBind{TRY(prism_rtl::from_pod<Pattern_>(c->args[0])), TRY(prism_rtl::from_pod<Expr>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Expr>>(c->args[2]))});
        if (c->ctor == "SIgnore" && c->args.size() == 1) return StmtKind(SIgnore{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "SLet" && c->args.size() == 3) return StmtKind(SLet{TRY(prism_rtl::from_pod<Pattern_>(c->args[0])), TRY(prism_rtl::from_pod<std::optional<Type>>(c->args[1])), TRY(prism_rtl::from_pod<Expr>(c->args[2]))});
        if (c->ctor == "SSignature" && c->args.size() == 1) return StmtKind(SSignature{TRY(prism_rtl::from_pod<crate::syntax::decls::Signature>(c->args[0]))});
        if (c->ctor == "SFn" && c->args.size() == 1) return StmtKind(SFn{TRY(prism_rtl::from_pod<crate::syntax::decls::FnClause>(c->args[0]))});
        if (c->ctor == "SWidget" && c->args.size() == 1) return StmtKind(SWidget{TRY(prism_rtl::from_pod<crate::syntax::decls::WidgetDecl>(c->args[0]))});
        if (c->ctor == "SSet" && c->args.size() == 2) return StmtKind(SSet{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Expr>(c->args[1]))});
        if (c->ctor == "SAccum" && c->args.size() == 3) return StmtKind(SAccum{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Expr>(c->args[2]))});
        if (c->ctor == "SRequire" && c->args.size() == 1) return StmtKind(SRequire{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "SForbid" && c->args.size() == 1) return StmtKind(SForbid{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "SWhile" && c->args.size() == 2) return StmtKind(SWhile{TRY(prism_rtl::from_pod<Cond>(c->args[0])), TRY(prism_rtl::from_pod<Block>(c->args[1]))});
        if (c->ctor == "SReturn" && c->args.size() == 1) return StmtKind(SReturn{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "SExpr" && c->args.size() == 1) return StmtKind(SExpr{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
    }
    return mismatch<StmtKind>("a StmtKind", p);
}


void Template::show(Printer& p) const {
    p.record("Template", {{"keyword", keyword}, {"lang", lang}, {"delims", delims}, {"parts", parts}, {"span", span}});
}

Pod Template::to_pod() const {
    return Pod::record("Template", {{"keyword", prism_rtl::to_pod(keyword)}, {"lang", prism_rtl::to_pod(lang)}, {"delims", prism_rtl::to_pod(delims)}, {"parts", prism_rtl::to_pod(parts)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Template> Template::from_pod(const Pod& whole) {
    return Template{.keyword = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "keyword")))), .lang = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "lang")))), .delims = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "delims")))), .parts = TRY(prism_rtl::from_pod<Array<TemplatePart>>(TRY(crate::prelude::field(whole, "parts")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void TemplatePart::show(Printer& p) const {
    if (auto c = std::get_if<TpText>(&cases())) p.choice("TpText", {c->a0});
    else if (auto c = std::get_if<TpPlaceholder>(&cases())) p.choice("TpPlaceholder", {c->a0, c->a1});
    else if (auto c = std::get_if<TpBlock>(&cases())) p.choice("TpBlock", {c->a0});
    else if (auto c = std::get_if<TpCall>(&cases())) p.choice("TpCall", {c->a0, c->a1, c->a2, c->a3});
}

Pod TemplatePart::to_pod() const {
    return std::holds_alternative<TpText>(cases()) ? Pod::choice("TpText", {prism_rtl::to_pod(std::get<TpText>(cases()).a0)})
        : std::holds_alternative<TpPlaceholder>(cases()) ? Pod::choice("TpPlaceholder", {prism_rtl::to_pod(std::get<TpPlaceholder>(cases()).a0), prism_rtl::to_pod(std::get<TpPlaceholder>(cases()).a1)})
        : std::holds_alternative<TpBlock>(cases()) ? Pod::choice("TpBlock", {prism_rtl::to_pod(std::get<TpBlock>(cases()).a0)})
        : std::holds_alternative<TpCall>(cases()) ? Pod::choice("TpCall", {prism_rtl::to_pod(std::get<TpCall>(cases()).a0), prism_rtl::to_pod(std::get<TpCall>(cases()).a1), prism_rtl::to_pod(std::get<TpCall>(cases()).a2), prism_rtl::to_pod(std::get<TpCall>(cases()).a3)})
        : Pod();
}

Result<TemplatePart> TemplatePart::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TpText" && c->args.size() == 1) return TemplatePart(TpText{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TpPlaceholder" && c->args.size() == 2) return TemplatePart(TpPlaceholder{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<std::optional<Nat>>(c->args[1]))});
        if (c->ctor == "TpBlock" && c->args.size() == 1) return TemplatePart(TpBlock{TRY(prism_rtl::from_pod<Block>(c->args[0]))});
        if (c->ctor == "TpCall" && c->args.size() == 4) return TemplatePart(TpCall{TRY(prism_rtl::from_pod<SName>(c->args[0])), TRY(prism_rtl::from_pod<Array<Arg>>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Array<TemplatePart>>>(c->args[2])), TRY(prism_rtl::from_pod<Range>(c->args[3]))});
    }
    return mismatch<TemplatePart>("a TemplatePart", p);
}


void TextSeg::show(Printer& p) const {
    if (auto c = std::get_if<SegPlain>(&cases())) p.choice("SegPlain", {c->a0});
    else if (auto c = std::get_if<SegPlaceholder>(&cases())) p.choice("SegPlaceholder", {c->a0});
}

Pod TextSeg::to_pod() const {
    return std::holds_alternative<SegPlain>(cases()) ? Pod::choice("SegPlain", {prism_rtl::to_pod(std::get<SegPlain>(cases()).a0)})
        : std::holds_alternative<SegPlaceholder>(cases()) ? Pod::choice("SegPlaceholder", {prism_rtl::to_pod(std::get<SegPlaceholder>(cases()).a0)})
        : Pod();
}

Result<TextSeg> TextSeg::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "SegPlain" && c->args.size() == 1) return TextSeg(SegPlain{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SegPlaceholder" && c->args.size() == 1) return TextSeg(SegPlaceholder{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
    }
    return mismatch<TextSeg>("a TextSeg", p);
}


void TraitRef::show(Printer& p) const {
    p.record("TraitRef", {{"path", path_}, {"span", span}});
}

Pod TraitRef::to_pod() const {
    return Pod::record("TraitRef", {{"path", prism_rtl::to_pod(path_)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TraitRef> TraitRef::from_pod(const Pod& whole) {
    return TraitRef{.path_ = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "path")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Type::show(Printer& p) const {
    p.record("Type", {{"kind", kind}, {"span", span}});
}

Pod Type::to_pod() const {
    return Pod::record("Type", {{"kind", prism_rtl::to_pod(kind)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Type> Type::from_pod(const Pod& whole) {
    return Type{.kind = TRY(prism_rtl::from_pod<TypeKind>(TRY(crate::prelude::field(whole, "kind")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void TypeKind::show(Printer& p) const {
    if (auto c = std::get_if<TName>(&cases())) p.choice("TName", {c->a0, c->a1});
    else if (auto c = std::get_if<TSigiled>(&cases())) p.choice("TSigiled", {c->a0, c->a1});
    else if (auto c = std::get_if<TArray>(&cases())) p.choice("TArray", {c->a0, c->a1});
    else if (auto c = std::get_if<TTuple>(&cases())) p.choice("TTuple", {c->a0});
    else if (auto c = std::get_if<TGroup>(&cases())) p.choice("TGroup", {c->a0});
    else if (auto c = std::get_if<TMap>(&cases())) p.choice("TMap", {c->a0, c->a1});
    else if (auto c = std::get_if<TFn>(&cases())) p.choice("TFn", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<TEmit>(&cases())) p.choice("TEmit", {c->a0, c->a1});
    else if (auto c = std::get_if<TRowUnion>(&cases())) p.choice("TRowUnion", {c->a0});
    else if (auto c = std::get_if<TFamily>(&cases())) p.choice("TFamily", {c->a0});
    else if (auto c = std::get_if<TAny>(&cases())) p.choice("TAny", {c->a0});
    else if (auto c = std::get_if<TUnit>(&cases())) p.choice("TUnit", {c->a0});
    else if (auto c = std::get_if<THole>(&cases())) p.choice("THole", {c->a0});
    else if (auto c = std::get_if<TAbsent>(&cases())) p.choice("TAbsent", {});
    else if (auto c = std::get_if<TNonEmpty>(&cases())) p.choice("TNonEmpty", {c->a0});
}

Pod TypeKind::to_pod() const {
    return std::holds_alternative<TName>(cases()) ? Pod::choice("TName", {prism_rtl::to_pod(std::get<TName>(cases()).a0), prism_rtl::to_pod(std::get<TName>(cases()).a1)})
        : std::holds_alternative<TSigiled>(cases()) ? Pod::choice("TSigiled", {prism_rtl::to_pod(std::get<TSigiled>(cases()).a0), prism_rtl::to_pod(std::get<TSigiled>(cases()).a1)})
        : std::holds_alternative<TArray>(cases()) ? Pod::choice("TArray", {prism_rtl::to_pod(std::get<TArray>(cases()).a0), prism_rtl::to_pod(std::get<TArray>(cases()).a1)})
        : std::holds_alternative<TTuple>(cases()) ? Pod::choice("TTuple", {prism_rtl::to_pod(std::get<TTuple>(cases()).a0)})
        : std::holds_alternative<TGroup>(cases()) ? Pod::choice("TGroup", {prism_rtl::to_pod(std::get<TGroup>(cases()).a0)})
        : std::holds_alternative<TMap>(cases()) ? Pod::choice("TMap", {prism_rtl::to_pod(std::get<TMap>(cases()).a0), prism_rtl::to_pod(std::get<TMap>(cases()).a1)})
        : std::holds_alternative<TFn>(cases()) ? Pod::choice("TFn", {prism_rtl::to_pod(std::get<TFn>(cases()).a0), prism_rtl::to_pod(std::get<TFn>(cases()).a1), prism_rtl::to_pod(std::get<TFn>(cases()).a2)})
        : std::holds_alternative<TEmit>(cases()) ? Pod::choice("TEmit", {prism_rtl::to_pod(std::get<TEmit>(cases()).a0), prism_rtl::to_pod(std::get<TEmit>(cases()).a1)})
        : std::holds_alternative<TRowUnion>(cases()) ? Pod::choice("TRowUnion", {prism_rtl::to_pod(std::get<TRowUnion>(cases()).a0)})
        : std::holds_alternative<TFamily>(cases()) ? Pod::choice("TFamily", {prism_rtl::to_pod(std::get<TFamily>(cases()).a0)})
        : std::holds_alternative<TAny>(cases()) ? Pod::choice("TAny", {prism_rtl::to_pod(std::get<TAny>(cases()).a0)})
        : std::holds_alternative<TUnit>(cases()) ? Pod::choice("TUnit", {prism_rtl::to_pod(std::get<TUnit>(cases()).a0)})
        : std::holds_alternative<THole>(cases()) ? Pod::choice("THole", {prism_rtl::to_pod(std::get<THole>(cases()).a0)})
        : std::holds_alternative<TAbsent>(cases()) ? Pod::choice("TAbsent", {})
        : std::holds_alternative<TNonEmpty>(cases()) ? Pod::choice("TNonEmpty", {prism_rtl::to_pod(std::get<TNonEmpty>(cases()).a0)})
        : Pod();
}

Result<TypeKind> TypeKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TName" && c->args.size() == 2) return TypeKind(TName{TRY(prism_rtl::from_pod<SName>(c->args[0])), TRY(prism_rtl::from_pod<Array<Type>>(c->args[1]))});
        if (c->ctor == "TSigiled" && c->args.size() == 2) return TypeKind(TSigiled{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Type>(c->args[1]))});
        if (c->ctor == "TArray" && c->args.size() == 2) return TypeKind(TArray{TRY(prism_rtl::from_pod<Type>(c->args[0])), TRY(prism_rtl::from_pod<bool>(c->args[1]))});
        if (c->ctor == "TTuple" && c->args.size() == 1) return TypeKind(TTuple{TRY(prism_rtl::from_pod<Array<Type>>(c->args[0]))});
        if (c->ctor == "TGroup" && c->args.size() == 1) return TypeKind(TGroup{TRY(prism_rtl::from_pod<Type>(c->args[0]))});
        if (c->ctor == "TMap" && c->args.size() == 2) return TypeKind(TMap{TRY(prism_rtl::from_pod<Type>(c->args[0])), TRY(prism_rtl::from_pod<Type>(c->args[1]))});
        if (c->ctor == "TFn" && c->args.size() == 3) return TypeKind(TFn{TRY(prism_rtl::from_pod<Color>(c->args[0])), TRY(prism_rtl::from_pod<Array<Type>>(c->args[1])), TRY(prism_rtl::from_pod<Type>(c->args[2]))});
        if (c->ctor == "TEmit" && c->args.size() == 2) return TypeKind(TEmit{TRY(prism_rtl::from_pod<Type>(c->args[0])), TRY(prism_rtl::from_pod<Type>(c->args[1]))});
        if (c->ctor == "TRowUnion" && c->args.size() == 1) return TypeKind(TRowUnion{TRY(prism_rtl::from_pod<Array<Type>>(c->args[0]))});
        if (c->ctor == "TFamily" && c->args.size() == 1) return TypeKind(TFamily{TRY(prism_rtl::from_pod<QualName>(c->args[0]))});
        if (c->ctor == "TAny" && c->args.size() == 1) return TypeKind(TAny{TRY(prism_rtl::from_pod<TraitRef>(c->args[0]))});
        if (c->ctor == "TUnit" && c->args.size() == 1) return TypeKind(TUnit{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "THole" && c->args.size() == 1) return TypeKind(THole{TRY(prism_rtl::from_pod<SName>(c->args[0]))});
        if (c->ctor == "TAbsent" && c->args.size() == 0) return TypeKind(TAbsent{});
        if (c->ctor == "TNonEmpty" && c->args.size() == 1) return TypeKind(TNonEmpty{TRY(prism_rtl::from_pod<Type>(c->args[0]))});
    }
    return mismatch<TypeKind>("a TypeKind", p);
}


void Use::show(Printer& p) const {
    p.record("Use", {{"target", target}, {"star", star}, {"span", span}});
}

Pod Use::to_pod() const {
    return Pod::record("Use", {{"target", prism_rtl::to_pod(target)}, {"star", prism_rtl::to_pod(star)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Use> Use::from_pod(const Pod& whole) {
    return Use{.target = TRY(prism_rtl::from_pod<QualName>(TRY(crate::prelude::field(whole, "target")))), .star = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "star")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}

}  // namespace crate::syntax
