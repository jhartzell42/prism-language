// The module `Syntax`, from `target/bootstrap/cpp-src/prismc/syntax/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include <syntax/module.hpp>

namespace crate::syntax {

void Arg::show(Printer& p) const {
    p.record("Arg", {{"name", name}, {"value", value}, {"span", span}});
}

Pod Arg::to_pod() const {
    return Pod::record("Arg", {{"name", prism_rtl::to_pod(name)}, {"value", prism_rtl::to_pod(value)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Arg> Arg::from_pod(const Pod& whole) {
    return Arg{.name = TRY(prism_rtl::from_pod<std::optional<Ident>>(TRY(crate::prelude::field(whole, "name")))), .value = TRY(prism_rtl::from_pod<Expr>(TRY(crate::prelude::field(whole, "value")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Arm::show(Printer& p) const {
    p.record("Arm", {{"pattern", pattern}, {"guard", guard}, {"body", body}, {"span", span}});
}

Pod Arm::to_pod() const {
    return Pod::record("Arm", {{"pattern", prism_rtl::to_pod(pattern)}, {"guard", prism_rtl::to_pod(guard)}, {"body", prism_rtl::to_pod(body)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Arm> Arm::from_pod(const Pod& whole) {
    return Arm{.pattern = TRY(prism_rtl::from_pod<std::optional<Pattern_>>(TRY(crate::prelude::field(whole, "pattern")))), .guard = TRY(prism_rtl::from_pod<std::optional<Expr>>(TRY(crate::prelude::field(whole, "guard")))), .body = TRY(prism_rtl::from_pod<Block>(TRY(crate::prelude::field(whole, "body")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Block::show(Printer& p) const {
    p.record("Block", {{"stmts", stmts}, {"inline", inline_}, {"span", span}});
}

Pod Block::to_pod() const {
    return Pod::record("Block", {{"stmts", prism_rtl::to_pod(stmts)}, {"inline", prism_rtl::to_pod(inline_)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Block> Block::from_pod(const Pod& whole) {
    return Block{.stmts = TRY(prism_rtl::from_pod<Array<Stmt>>(TRY(crate::prelude::field(whole, "stmts")))), .inline_ = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "inline")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Bound::show(Printer& p) const {
    p.record("Bound", {{"var", var}, {"traits", traits}, {"span", span}});
}

Pod Bound::to_pod() const {
    return Pod::record("Bound", {{"var", prism_rtl::to_pod(var)}, {"traits", prism_rtl::to_pod(traits)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Bound> Bound::from_pod(const Pod& whole) {
    return Bound{.var = TRY(prism_rtl::from_pod<Ident>(TRY(crate::prelude::field(whole, "var")))), .traits = TRY(prism_rtl::from_pod<Array<TraitRef>>(TRY(crate::prelude::field(whole, "traits")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Case_::show(Printer& p) const {
    p.record("Case", {{"name", name}, {"args", args}, {"indexed", indexed}, {"span", span}});
}

Pod Case_::to_pod() const {
    return Pod::record("Case", {{"name", prism_rtl::to_pod(name)}, {"args", prism_rtl::to_pod(args)}, {"indexed", prism_rtl::to_pod(indexed)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Case_> Case_::from_pod(const Pod& whole) {
    return Case_{.name = TRY(prism_rtl::from_pod<SName>(TRY(crate::prelude::field(whole, "name")))), .args = TRY(prism_rtl::from_pod<Array<Type>>(TRY(crate::prelude::field(whole, "args")))), .indexed = TRY(prism_rtl::from_pod<std::optional<Type>>(TRY(crate::prelude::field(whole, "indexed")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void CheckDecl::show(Printer& p) const {
    p.record("CheckDecl", {{"name", name}, {"lines", lines}, {"span", span}});
}

Pod CheckDecl::to_pod() const {
    return Pod::record("CheckDecl", {{"name", prism_rtl::to_pod(name)}, {"lines", prism_rtl::to_pod(lines)}, {"span", prism_rtl::to_pod(span)}});
}

Result<CheckDecl> CheckDecl::from_pod(const Pod& whole) {
    return CheckDecl{.name = TRY(prism_rtl::from_pod<Ident>(TRY(crate::prelude::field(whole, "name")))), .lines = TRY(prism_rtl::from_pod<Array<CheckLine>>(TRY(crate::prelude::field(whole, "lines")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void CheckLine::show(Printer& p) const {
    p.record("CheckLine", {{"expr", expr}, {"pattern", pattern}, {"span", span}});
}

Pod CheckLine::to_pod() const {
    return Pod::record("CheckLine", {{"expr", prism_rtl::to_pod(expr)}, {"pattern", prism_rtl::to_pod(pattern)}, {"span", prism_rtl::to_pod(span)}});
}

Result<CheckLine> CheckLine::from_pod(const Pod& whole) {
    return CheckLine{.expr = TRY(prism_rtl::from_pod<Expr>(TRY(crate::prelude::field(whole, "expr")))), .pattern = TRY(prism_rtl::from_pod<std::optional<Pattern_>>(TRY(crate::prelude::field(whole, "pattern")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Color::show(Printer& p) const {
    if (auto c = std::get_if<Bounded>(&cases())) p.choice("Bounded", {});
    else if (auto c = std::get_if<Unbounded>(&cases())) p.choice("Unbounded", {});
    else if (auto c = std::get_if<ColorVar>(&cases())) p.choice("ColorVar", {c->a0});
}

Pod Color::to_pod() const {
    return std::holds_alternative<Bounded>(cases()) ? Pod::choice("Bounded", {})
        : std::holds_alternative<Unbounded>(cases()) ? Pod::choice("Unbounded", {})
        : std::holds_alternative<ColorVar>(cases()) ? Pod::choice("ColorVar", {prism_rtl::to_pod(std::get<ColorVar>(cases()).a0)})
        : Pod();
}

Result<Color> Color::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "Bounded" && c->args.size() == 0) return Color(Bounded{});
        if (c->ctor == "Unbounded" && c->args.size() == 0) return Color(Unbounded{});
        if (c->ctor == "ColorVar" && c->args.size() == 1) return Color(ColorVar{TRY(prism_rtl::from_pod<Ident>(c->args[0]))});
    }
    return mismatch<Color>("a Color", p);
}


void Cond::show(Printer& p) const {
    if (auto c = std::get_if<CondExpr>(&cases())) p.choice("CondExpr", {c->a0});
    else if (auto c = std::get_if<CondBind>(&cases())) p.choice("CondBind", {c->a0, c->a1, c->a2});
}

Pod Cond::to_pod() const {
    return std::holds_alternative<CondExpr>(cases()) ? Pod::choice("CondExpr", {prism_rtl::to_pod(std::get<CondExpr>(cases()).a0)})
        : std::holds_alternative<CondBind>(cases()) ? Pod::choice("CondBind", {prism_rtl::to_pod(std::get<CondBind>(cases()).a0), prism_rtl::to_pod(std::get<CondBind>(cases()).a1), prism_rtl::to_pod(std::get<CondBind>(cases()).a2)})
        : Pod();
}

Result<Cond> Cond::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "CondExpr" && c->args.size() == 1) return Cond(CondExpr{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "CondBind" && c->args.size() == 3) return Cond(CondBind{TRY(prism_rtl::from_pod<Pattern_>(c->args[0])), TRY(prism_rtl::from_pod<Expr>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Expr>>(c->args[2]))});
    }
    return mismatch<Cond>("a Cond", p);
}


void Decl::show(Printer& p) const {
    p.record("Decl", {{"kind", kind}, {"span", span}});
}

Pod Decl::to_pod() const {
    return Pod::record("Decl", {{"kind", prism_rtl::to_pod(kind)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Decl> Decl::from_pod(const Pod& whole) {
    return Decl{.kind = TRY(prism_rtl::from_pod<DeclKind>(TRY(crate::prelude::field(whole, "kind")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void DeclKind::show(Printer& p) const {
    if (auto c = std::get_if<DSignature>(&cases())) p.choice("DSignature", {c->a0});
    else if (auto c = std::get_if<DFn>(&cases())) p.choice("DFn", {c->a0});
    else if (auto c = std::get_if<DLet>(&cases())) p.choice("DLet", {c->a0});
    else if (auto c = std::get_if<DWidget>(&cases())) p.choice("DWidget", {c->a0});
    else if (auto c = std::get_if<DType>(&cases())) p.choice("DType", {c->a0});
    else if (auto c = std::get_if<DTag>(&cases())) p.choice("DTag", {c->a0});
    else if (auto c = std::get_if<DDerive>(&cases())) p.choice("DDerive", {c->a0});
    else if (auto c = std::get_if<DTrait>(&cases())) p.choice("DTrait", {c->a0});
    else if (auto c = std::get_if<DImpl>(&cases())) p.choice("DImpl", {c->a0});
    else if (auto c = std::get_if<DCheck>(&cases())) p.choice("DCheck", {c->a0});
    else if (auto c = std::get_if<DTest>(&cases())) p.choice("DTest", {c->a0});
    else if (auto c = std::get_if<DStmt>(&cases())) p.choice("DStmt", {c->a0});
}

Pod DeclKind::to_pod() const {
    return std::holds_alternative<DSignature>(cases()) ? Pod::choice("DSignature", {prism_rtl::to_pod(std::get<DSignature>(cases()).a0)})
        : std::holds_alternative<DFn>(cases()) ? Pod::choice("DFn", {prism_rtl::to_pod(std::get<DFn>(cases()).a0)})
        : std::holds_alternative<DLet>(cases()) ? Pod::choice("DLet", {prism_rtl::to_pod(std::get<DLet>(cases()).a0)})
        : std::holds_alternative<DWidget>(cases()) ? Pod::choice("DWidget", {prism_rtl::to_pod(std::get<DWidget>(cases()).a0)})
        : std::holds_alternative<DType>(cases()) ? Pod::choice("DType", {prism_rtl::to_pod(std::get<DType>(cases()).a0)})
        : std::holds_alternative<DTag>(cases()) ? Pod::choice("DTag", {prism_rtl::to_pod(std::get<DTag>(cases()).a0)})
        : std::holds_alternative<DDerive>(cases()) ? Pod::choice("DDerive", {prism_rtl::to_pod(std::get<DDerive>(cases()).a0)})
        : std::holds_alternative<DTrait>(cases()) ? Pod::choice("DTrait", {prism_rtl::to_pod(std::get<DTrait>(cases()).a0)})
        : std::holds_alternative<DImpl>(cases()) ? Pod::choice("DImpl", {prism_rtl::to_pod(std::get<DImpl>(cases()).a0)})
        : std::holds_alternative<DCheck>(cases()) ? Pod::choice("DCheck", {prism_rtl::to_pod(std::get<DCheck>(cases()).a0)})
        : std::holds_alternative<DTest>(cases()) ? Pod::choice("DTest", {prism_rtl::to_pod(std::get<DTest>(cases()).a0)})
        : std::holds_alternative<DStmt>(cases()) ? Pod::choice("DStmt", {prism_rtl::to_pod(std::get<DStmt>(cases()).a0)})
        : Pod();
}

Result<DeclKind> DeclKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "DSignature" && c->args.size() == 1) return DeclKind(DSignature{TRY(prism_rtl::from_pod<Signature>(c->args[0]))});
        if (c->ctor == "DFn" && c->args.size() == 1) return DeclKind(DFn{TRY(prism_rtl::from_pod<FnClause>(c->args[0]))});
        if (c->ctor == "DLet" && c->args.size() == 1) return DeclKind(DLet{TRY(prism_rtl::from_pod<LetDecl>(c->args[0]))});
        if (c->ctor == "DWidget" && c->args.size() == 1) return DeclKind(DWidget{TRY(prism_rtl::from_pod<WidgetDecl>(c->args[0]))});
        if (c->ctor == "DType" && c->args.size() == 1) return DeclKind(DType{TRY(prism_rtl::from_pod<TypeDecl>(c->args[0]))});
        if (c->ctor == "DTag" && c->args.size() == 1) return DeclKind(DTag{TRY(prism_rtl::from_pod<TagDecl>(c->args[0]))});
        if (c->ctor == "DDerive" && c->args.size() == 1) return DeclKind(DDerive{TRY(prism_rtl::from_pod<Array<TraitRef>>(c->args[0]))});
        if (c->ctor == "DTrait" && c->args.size() == 1) return DeclKind(DTrait{TRY(prism_rtl::from_pod<TraitDecl>(c->args[0]))});
        if (c->ctor == "DImpl" && c->args.size() == 1) return DeclKind(DImpl{TRY(prism_rtl::from_pod<ImplDecl>(c->args[0]))});
        if (c->ctor == "DCheck" && c->args.size() == 1) return DeclKind(DCheck{TRY(prism_rtl::from_pod<CheckDecl>(c->args[0]))});
        if (c->ctor == "DTest" && c->args.size() == 1) return DeclKind(DTest{TRY(prism_rtl::from_pod<TestDecl>(c->args[0]))});
        if (c->ctor == "DStmt" && c->args.size() == 1) return DeclKind(DStmt{TRY(prism_rtl::from_pod<Stmt>(c->args[0]))});
    }
    return mismatch<DeclKind>("a DeclKind", p);
}


void DefName::show(Printer& p) const {
    if (auto c = std::get_if<DefSName>(&cases())) p.choice("DefSName", {c->a0});
    else if (auto c = std::get_if<DefOp>(&cases())) p.choice("DefOp", {c->a0, c->a1});
}

Pod DefName::to_pod() const {
    return std::holds_alternative<DefSName>(cases()) ? Pod::choice("DefSName", {prism_rtl::to_pod(std::get<DefSName>(cases()).a0)})
        : std::holds_alternative<DefOp>(cases()) ? Pod::choice("DefOp", {prism_rtl::to_pod(std::get<DefOp>(cases()).a0), prism_rtl::to_pod(std::get<DefOp>(cases()).a1)})
        : Pod();
}

Result<DefName> DefName::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "DefSName" && c->args.size() == 1) return DefName(DefSName{TRY(prism_rtl::from_pod<SName>(c->args[0]))});
        if (c->ctor == "DefOp" && c->args.size() == 2) return DefName(DefOp{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Range>(c->args[1]))});
    }
    return mismatch<DefName>("a DefName", p);
}


void Delivery::show(Printer& p) const {
    p.record("Delivery", {{"kind", kind}, {"target", target}, {"span", span}});
}

Pod Delivery::to_pod() const {
    return Pod::record("Delivery", {{"kind", prism_rtl::to_pod(kind)}, {"target", prism_rtl::to_pod(target)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Delivery> Delivery::from_pod(const Pod& whole) {
    return Delivery{.kind = TRY(prism_rtl::from_pod<DeliveryKind>(TRY(crate::prelude::field(whole, "kind")))), .target = TRY(prism_rtl::from_pod<Target>(TRY(crate::prelude::field(whole, "target")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void DeliveryKind::show(Printer& p) const {
    if (auto c = std::get_if<DkSend>(&cases())) p.choice("DkSend", {c->a0});
    else if (auto c = std::get_if<DkClick>(&cases())) p.choice("DkClick", {});
    else if (auto c = std::get_if<DkAnswer>(&cases())) p.choice("DkAnswer", {});
}

Pod DeliveryKind::to_pod() const {
    return std::holds_alternative<DkSend>(cases()) ? Pod::choice("DkSend", {prism_rtl::to_pod(std::get<DkSend>(cases()).a0)})
        : std::holds_alternative<DkClick>(cases()) ? Pod::choice("DkClick", {})
        : std::holds_alternative<DkAnswer>(cases()) ? Pod::choice("DkAnswer", {})
        : Pod();
}

Result<DeliveryKind> DeliveryKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "DkSend" && c->args.size() == 1) return DeliveryKind(DkSend{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "DkClick" && c->args.size() == 0) return DeliveryKind(DkClick{});
        if (c->ctor == "DkAnswer" && c->args.size() == 0) return DeliveryKind(DkAnswer{});
    }
    return mismatch<DeliveryKind>("a DeliveryKind", p);
}


void Diag::show(Printer& p) const {
    p.record("Diag", {{"stage", stage}, {"span", span}, {"message", message}, {"feature", feature}});
}

Pod Diag::to_pod() const {
    return Pod::record("Diag", {{"stage", prism_rtl::to_pod(stage)}, {"span", prism_rtl::to_pod(span)}, {"message", prism_rtl::to_pod(message)}, {"feature", prism_rtl::to_pod(feature)}});
}

Result<Diag> Diag::from_pod(const Pod& whole) {
    return Diag{.stage = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "stage")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span")))), .message = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "message")))), .feature = TRY(prism_rtl::from_pod<std::optional<Text>>(TRY(crate::prelude::field(whole, "feature"))))};
}


void Entry::show(Printer& p) const {
    p.record("Entry", {{"element", element}, {"value", value}, {"span", span}});
}

Pod Entry::to_pod() const {
    return Pod::record("Entry", {{"element", prism_rtl::to_pod(element)}, {"value", prism_rtl::to_pod(value)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Entry> Entry::from_pod(const Pod& whole) {
    return Entry{.element = TRY(prism_rtl::from_pod<Expr>(TRY(crate::prelude::field(whole, "element")))), .value = TRY(prism_rtl::from_pod<Expr>(TRY(crate::prelude::field(whole, "value")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Expr::show(Printer& p) const {
    p.record("Expr", {{"kind", kind}, {"span", span}});
}

Pod Expr::to_pod() const {
    return Pod::record("Expr", {{"kind", prism_rtl::to_pod(kind)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Expr> Expr::from_pod(const Pod& whole) {
    return Expr{.kind = TRY(prism_rtl::from_pod<ExprKind>(TRY(crate::prelude::field(whole, "kind")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void ExprKind::show(Printer& p) const {
    if (auto c = std::get_if<EName>(&cases())) p.choice("EName", {c->a0});
    else if (auto c = std::get_if<ELit>(&cases())) p.choice("ELit", {c->a0});
    else if (auto c = std::get_if<EUnit>(&cases())) p.choice("EUnit", {c->a0});
    else if (auto c = std::get_if<ENil>(&cases())) p.choice("ENil", {c->a0});
    else if (auto c = std::get_if<EBound>(&cases())) p.choice("EBound", {c->a0});
    else if (auto c = std::get_if<ETuple>(&cases())) p.choice("ETuple", {c->a0});
    else if (auto c = std::get_if<EArray>(&cases())) p.choice("EArray", {c->a0});
    else if (auto c = std::get_if<EMap>(&cases())) p.choice("EMap", {c->a0});
    else if (auto c = std::get_if<EGroup>(&cases())) p.choice("EGroup", {c->a0});
    else if (auto c = std::get_if<ECall>(&cases())) p.choice("ECall", {c->a0, c->a1, c->a2, c->a3});
    else if (auto c = std::get_if<EBinary>(&cases())) p.choice("EBinary", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<EUnary>(&cases())) p.choice("EUnary", {c->a0, c->a1});
    else if (auto c = std::get_if<ESuffixed>(&cases())) p.choice("ESuffixed", {c->a0, c->a1, c->a2, c->a3});
    else if (auto c = std::get_if<EFreeSigil>(&cases())) p.choice("EFreeSigil", {c->a0, c->a1});
    else if (auto c = std::get_if<EField>(&cases())) p.choice("EField", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<EIndex>(&cases())) p.choice("EIndex", {c->a0, c->a1});
    else if (auto c = std::get_if<ETopicField>(&cases())) p.choice("ETopicField", {c->a0});
    else if (auto c = std::get_if<ETopicIndex>(&cases())) p.choice("ETopicIndex", {c->a0});
    else if (auto c = std::get_if<EMethod>(&cases())) p.choice("EMethod", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<ETypeArgs>(&cases())) p.choice("ETypeArgs", {c->a0, c->a1});
    else if (auto c = std::get_if<ECast>(&cases())) p.choice("ECast", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<ENonEmpty>(&cases())) p.choice("ENonEmpty", {c->a0});
    else if (auto c = std::get_if<EAbsent>(&cases())) p.choice("EAbsent", {});
    else if (auto c = std::get_if<ERest>(&cases())) p.choice("ERest", {});
    else if (auto c = std::get_if<ELambda>(&cases())) p.choice("ELambda", {c->a0, c->a1});
    else if (auto c = std::get_if<EIf>(&cases())) p.choice("EIf", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<EMatch>(&cases())) p.choice("EMatch", {c->a0, c->a1});
    else if (auto c = std::get_if<ERebuild>(&cases())) p.choice("ERebuild", {c->a0, c->a1});
    else if (auto c = std::get_if<EFor>(&cases())) p.choice("EFor", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<EGiven>(&cases())) p.choice("EGiven", {c->a0});
    else if (auto c = std::get_if<EUpdate>(&cases())) p.choice("EUpdate", {c->a0, c->a1});
    else if (auto c = std::get_if<EWidgetBlock>(&cases())) p.choice("EWidgetBlock", {c->a0});
    else if (auto c = std::get_if<EMonad>(&cases())) p.choice("EMonad", {c->a0, c->a1});
    else if (auto c = std::get_if<ETemplate>(&cases())) p.choice("ETemplate", {c->a0});
    else if (auto c = std::get_if<EAny>(&cases())) p.choice("EAny", {c->a0});
    else if (auto c = std::get_if<ELens>(&cases())) p.choice("ELens", {c->a0});
    else if (auto c = std::get_if<EError>(&cases())) p.choice("EError", {});
}

Pod ExprKind::to_pod() const {
    return std::holds_alternative<EName>(cases()) ? Pod::choice("EName", {prism_rtl::to_pod(std::get<EName>(cases()).a0)})
        : std::holds_alternative<ELit>(cases()) ? Pod::choice("ELit", {prism_rtl::to_pod(std::get<ELit>(cases()).a0)})
        : std::holds_alternative<EUnit>(cases()) ? Pod::choice("EUnit", {prism_rtl::to_pod(std::get<EUnit>(cases()).a0)})
        : std::holds_alternative<ENil>(cases()) ? Pod::choice("ENil", {prism_rtl::to_pod(std::get<ENil>(cases()).a0)})
        : std::holds_alternative<EBound>(cases()) ? Pod::choice("EBound", {prism_rtl::to_pod(std::get<EBound>(cases()).a0)})
        : std::holds_alternative<ETuple>(cases()) ? Pod::choice("ETuple", {prism_rtl::to_pod(std::get<ETuple>(cases()).a0)})
        : std::holds_alternative<EArray>(cases()) ? Pod::choice("EArray", {prism_rtl::to_pod(std::get<EArray>(cases()).a0)})
        : std::holds_alternative<EMap>(cases()) ? Pod::choice("EMap", {prism_rtl::to_pod(std::get<EMap>(cases()).a0)})
        : std::holds_alternative<EGroup>(cases()) ? Pod::choice("EGroup", {prism_rtl::to_pod(std::get<EGroup>(cases()).a0)})
        : std::holds_alternative<ECall>(cases()) ? Pod::choice("ECall", {prism_rtl::to_pod(std::get<ECall>(cases()).a0), prism_rtl::to_pod(std::get<ECall>(cases()).a1), prism_rtl::to_pod(std::get<ECall>(cases()).a2), prism_rtl::to_pod(std::get<ECall>(cases()).a3)})
        : std::holds_alternative<EBinary>(cases()) ? Pod::choice("EBinary", {prism_rtl::to_pod(std::get<EBinary>(cases()).a0), prism_rtl::to_pod(std::get<EBinary>(cases()).a1), prism_rtl::to_pod(std::get<EBinary>(cases()).a2)})
        : std::holds_alternative<EUnary>(cases()) ? Pod::choice("EUnary", {prism_rtl::to_pod(std::get<EUnary>(cases()).a0), prism_rtl::to_pod(std::get<EUnary>(cases()).a1)})
        : std::holds_alternative<ESuffixed>(cases()) ? Pod::choice("ESuffixed", {prism_rtl::to_pod(std::get<ESuffixed>(cases()).a0), prism_rtl::to_pod(std::get<ESuffixed>(cases()).a1), prism_rtl::to_pod(std::get<ESuffixed>(cases()).a2), prism_rtl::to_pod(std::get<ESuffixed>(cases()).a3)})
        : std::holds_alternative<EFreeSigil>(cases()) ? Pod::choice("EFreeSigil", {prism_rtl::to_pod(std::get<EFreeSigil>(cases()).a0), prism_rtl::to_pod(std::get<EFreeSigil>(cases()).a1)})
        : std::holds_alternative<EField>(cases()) ? Pod::choice("EField", {prism_rtl::to_pod(std::get<EField>(cases()).a0), prism_rtl::to_pod(std::get<EField>(cases()).a1), prism_rtl::to_pod(std::get<EField>(cases()).a2)})
        : std::holds_alternative<EIndex>(cases()) ? Pod::choice("EIndex", {prism_rtl::to_pod(std::get<EIndex>(cases()).a0), prism_rtl::to_pod(std::get<EIndex>(cases()).a1)})
        : std::holds_alternative<ETopicField>(cases()) ? Pod::choice("ETopicField", {prism_rtl::to_pod(std::get<ETopicField>(cases()).a0)})
        : std::holds_alternative<ETopicIndex>(cases()) ? Pod::choice("ETopicIndex", {prism_rtl::to_pod(std::get<ETopicIndex>(cases()).a0)})
        : std::holds_alternative<EMethod>(cases()) ? Pod::choice("EMethod", {prism_rtl::to_pod(std::get<EMethod>(cases()).a0), prism_rtl::to_pod(std::get<EMethod>(cases()).a1), prism_rtl::to_pod(std::get<EMethod>(cases()).a2)})
        : std::holds_alternative<ETypeArgs>(cases()) ? Pod::choice("ETypeArgs", {prism_rtl::to_pod(std::get<ETypeArgs>(cases()).a0), prism_rtl::to_pod(std::get<ETypeArgs>(cases()).a1)})
        : std::holds_alternative<ECast>(cases()) ? Pod::choice("ECast", {prism_rtl::to_pod(std::get<ECast>(cases()).a0), prism_rtl::to_pod(std::get<ECast>(cases()).a1), prism_rtl::to_pod(std::get<ECast>(cases()).a2)})
        : std::holds_alternative<ENonEmpty>(cases()) ? Pod::choice("ENonEmpty", {prism_rtl::to_pod(std::get<ENonEmpty>(cases()).a0)})
        : std::holds_alternative<EAbsent>(cases()) ? Pod::choice("EAbsent", {})
        : std::holds_alternative<ERest>(cases()) ? Pod::choice("ERest", {})
        : std::holds_alternative<ELambda>(cases()) ? Pod::choice("ELambda", {prism_rtl::to_pod(std::get<ELambda>(cases()).a0), prism_rtl::to_pod(std::get<ELambda>(cases()).a1)})
        : std::holds_alternative<EIf>(cases()) ? Pod::choice("EIf", {prism_rtl::to_pod(std::get<EIf>(cases()).a0), prism_rtl::to_pod(std::get<EIf>(cases()).a1), prism_rtl::to_pod(std::get<EIf>(cases()).a2)})
        : std::holds_alternative<EMatch>(cases()) ? Pod::choice("EMatch", {prism_rtl::to_pod(std::get<EMatch>(cases()).a0), prism_rtl::to_pod(std::get<EMatch>(cases()).a1)})
        : std::holds_alternative<ERebuild>(cases()) ? Pod::choice("ERebuild", {prism_rtl::to_pod(std::get<ERebuild>(cases()).a0), prism_rtl::to_pod(std::get<ERebuild>(cases()).a1)})
        : std::holds_alternative<EFor>(cases()) ? Pod::choice("EFor", {prism_rtl::to_pod(std::get<EFor>(cases()).a0), prism_rtl::to_pod(std::get<EFor>(cases()).a1), prism_rtl::to_pod(std::get<EFor>(cases()).a2)})
        : std::holds_alternative<EGiven>(cases()) ? Pod::choice("EGiven", {prism_rtl::to_pod(std::get<EGiven>(cases()).a0)})
        : std::holds_alternative<EUpdate>(cases()) ? Pod::choice("EUpdate", {prism_rtl::to_pod(std::get<EUpdate>(cases()).a0), prism_rtl::to_pod(std::get<EUpdate>(cases()).a1)})
        : std::holds_alternative<EWidgetBlock>(cases()) ? Pod::choice("EWidgetBlock", {prism_rtl::to_pod(std::get<EWidgetBlock>(cases()).a0)})
        : std::holds_alternative<EMonad>(cases()) ? Pod::choice("EMonad", {prism_rtl::to_pod(std::get<EMonad>(cases()).a0), prism_rtl::to_pod(std::get<EMonad>(cases()).a1)})
        : std::holds_alternative<ETemplate>(cases()) ? Pod::choice("ETemplate", {prism_rtl::to_pod(std::get<ETemplate>(cases()).a0)})
        : std::holds_alternative<EAny>(cases()) ? Pod::choice("EAny", {prism_rtl::to_pod(std::get<EAny>(cases()).a0)})
        : std::holds_alternative<ELens>(cases()) ? Pod::choice("ELens", {prism_rtl::to_pod(std::get<ELens>(cases()).a0)})
        : std::holds_alternative<EError>(cases()) ? Pod::choice("EError", {})
        : Pod();
}

Result<ExprKind> ExprKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "EName" && c->args.size() == 1) return ExprKind(EName{TRY(prism_rtl::from_pod<SName>(c->args[0]))});
        if (c->ctor == "ELit" && c->args.size() == 1) return ExprKind(ELit{TRY(prism_rtl::from_pod<Literal>(c->args[0]))});
        if (c->ctor == "EUnit" && c->args.size() == 1) return ExprKind(EUnit{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "ENil" && c->args.size() == 1) return ExprKind(ENil{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "EBound" && c->args.size() == 1) return ExprKind(EBound{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "ETuple" && c->args.size() == 1) return ExprKind(ETuple{TRY(prism_rtl::from_pod<Array<Expr>>(c->args[0]))});
        if (c->ctor == "EArray" && c->args.size() == 1) return ExprKind(EArray{TRY(prism_rtl::from_pod<Array<Expr>>(c->args[0]))});
        if (c->ctor == "EMap" && c->args.size() == 1) return ExprKind(EMap{TRY(prism_rtl::from_pod<Array<std::tuple<Expr, Expr>>>(c->args[0]))});
        if (c->ctor == "EGroup" && c->args.size() == 1) return ExprKind(EGroup{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "ECall" && c->args.size() == 4) return ExprKind(ECall{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Array<Arg>>(c->args[1])), TRY(prism_rtl::from_pod<bool>(c->args[2])), TRY(prism_rtl::from_pod<bool>(c->args[3]))});
        if (c->ctor == "EBinary" && c->args.size() == 3) return ExprKind(EBinary{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Expr>(c->args[1])), TRY(prism_rtl::from_pod<Expr>(c->args[2]))});
        if (c->ctor == "EUnary" && c->args.size() == 2) return ExprKind(EUnary{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Expr>(c->args[1]))});
        if (c->ctor == "ESuffixed" && c->args.size() == 4) return ExprKind(ESuffixed{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<QualName>(c->args[1])), TRY(prism_rtl::from_pod<Expr>(c->args[2])), TRY(prism_rtl::from_pod<Expr>(c->args[3]))});
        if (c->ctor == "EFreeSigil" && c->args.size() == 2) return ExprKind(EFreeSigil{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Expr>(c->args[1]))});
        if (c->ctor == "EField" && c->args.size() == 3) return ExprKind(EField{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Ident>(c->args[2]))});
        if (c->ctor == "EIndex" && c->args.size() == 2) return ExprKind(EIndex{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Expr>(c->args[1]))});
        if (c->ctor == "ETopicField" && c->args.size() == 1) return ExprKind(ETopicField{TRY(prism_rtl::from_pod<Ident>(c->args[0]))});
        if (c->ctor == "ETopicIndex" && c->args.size() == 1) return ExprKind(ETopicIndex{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "EMethod" && c->args.size() == 3) return ExprKind(EMethod{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<SName>(c->args[1])), TRY(prism_rtl::from_pod<Array<Arg>>(c->args[2]))});
        if (c->ctor == "ETypeArgs" && c->args.size() == 2) return ExprKind(ETypeArgs{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Array<Type>>(c->args[1]))});
        if (c->ctor == "ECast" && c->args.size() == 3) return ExprKind(ECast{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Type>(c->args[1])), TRY(prism_rtl::from_pod<bool>(c->args[2]))});
        if (c->ctor == "ENonEmpty" && c->args.size() == 1) return ExprKind(ENonEmpty{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "EAbsent" && c->args.size() == 0) return ExprKind(EAbsent{});
        if (c->ctor == "ERest" && c->args.size() == 0) return ExprKind(ERest{});
        if (c->ctor == "ELambda" && c->args.size() == 2) return ExprKind(ELambda{TRY(prism_rtl::from_pod<std::optional<Array<Pattern_>>>(c->args[0])), TRY(prism_rtl::from_pod<LambdaBody>(c->args[1]))});
        if (c->ctor == "EIf" && c->args.size() == 3) return ExprKind(EIf{TRY(prism_rtl::from_pod<Cond>(c->args[0])), TRY(prism_rtl::from_pod<Block>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Block>>(c->args[2]))});
        if (c->ctor == "EMatch" && c->args.size() == 2) return ExprKind(EMatch{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Array<Arm>>(c->args[1]))});
        if (c->ctor == "ERebuild" && c->args.size() == 2) return ExprKind(ERebuild{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Block>(c->args[1]))});
        if (c->ctor == "EFor" && c->args.size() == 3) return ExprKind(EFor{TRY(prism_rtl::from_pod<std::optional<ForBinders>>(c->args[0])), TRY(prism_rtl::from_pod<Expr>(c->args[1])), TRY(prism_rtl::from_pod<Block>(c->args[2]))});
        if (c->ctor == "EGiven" && c->args.size() == 1) return ExprKind(EGiven{TRY(prism_rtl::from_pod<Block>(c->args[0]))});
        if (c->ctor == "EUpdate" && c->args.size() == 2) return ExprKind(EUpdate{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Block>(c->args[1]))});
        if (c->ctor == "EWidgetBlock" && c->args.size() == 1) return ExprKind(EWidgetBlock{TRY(prism_rtl::from_pod<Block>(c->args[0]))});
        if (c->ctor == "EMonad" && c->args.size() == 2) return ExprKind(EMonad{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Block>(c->args[1]))});
        if (c->ctor == "ETemplate" && c->args.size() == 1) return ExprKind(ETemplate{TRY(prism_rtl::from_pod<Template>(c->args[0]))});
        if (c->ctor == "EAny" && c->args.size() == 1) return ExprKind(EAny{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "ELens" && c->args.size() == 1) return ExprKind(ELens{TRY(prism_rtl::from_pod<Array<Ident>>(c->args[0]))});
        if (c->ctor == "EError" && c->args.size() == 0) return ExprKind(EError{});
    }
    return mismatch<ExprKind>("a ExprKind", p);
}


void Field::show(Printer& p) const {
    p.record("Field", {{"name", name}, {"ty", ty}, {"span", span}});
}

Pod Field::to_pod() const {
    return Pod::record("Field", {{"name", prism_rtl::to_pod(name)}, {"ty", prism_rtl::to_pod(ty)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Field> Field::from_pod(const Pod& whole) {
    return Field{.name = TRY(prism_rtl::from_pod<Ident>(TRY(crate::prelude::field(whole, "name")))), .ty = TRY(prism_rtl::from_pod<Type>(TRY(crate::prelude::field(whole, "ty")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void FieldPat::show(Printer& p) const {
    p.record("FieldPat", {{"name", name}, {"pattern", pattern}, {"span", span}});
}

Pod FieldPat::to_pod() const {
    return Pod::record("FieldPat", {{"name", prism_rtl::to_pod(name)}, {"pattern", prism_rtl::to_pod(pattern)}, {"span", prism_rtl::to_pod(span)}});
}

Result<FieldPat> FieldPat::from_pod(const Pod& whole) {
    return FieldPat{.name = TRY(prism_rtl::from_pod<std::optional<Ident>>(TRY(crate::prelude::field(whole, "name")))), .pattern = TRY(prism_rtl::from_pod<Pattern_>(TRY(crate::prelude::field(whole, "pattern")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void FnBody::show(Printer& p) const {
    if (auto c = std::get_if<BodyExpr>(&cases())) p.choice("BodyExpr", {c->a0});
    else if (auto c = std::get_if<BodyBlock>(&cases())) p.choice("BodyBlock", {c->a0});
}

Pod FnBody::to_pod() const {
    return std::holds_alternative<BodyExpr>(cases()) ? Pod::choice("BodyExpr", {prism_rtl::to_pod(std::get<BodyExpr>(cases()).a0)})
        : std::holds_alternative<BodyBlock>(cases()) ? Pod::choice("BodyBlock", {prism_rtl::to_pod(std::get<BodyBlock>(cases()).a0)})
        : Pod();
}

Result<FnBody> FnBody::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "BodyExpr" && c->args.size() == 1) return FnBody(BodyExpr{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "BodyBlock" && c->args.size() == 1) return FnBody(BodyBlock{TRY(prism_rtl::from_pod<Block>(c->args[0]))});
    }
    return mismatch<FnBody>("a FnBody", p);
}


void FnClause::show(Printer& p) const {
    p.record("FnClause", {{"name", name}, {"params", params}, {"body", body}, {"span", span}});
}

Pod FnClause::to_pod() const {
    return Pod::record("FnClause", {{"name", prism_rtl::to_pod(name)}, {"params", prism_rtl::to_pod(params)}, {"body", prism_rtl::to_pod(body)}, {"span", prism_rtl::to_pod(span)}});
}

Result<FnClause> FnClause::from_pod(const Pod& whole) {
    return FnClause{.name = TRY(prism_rtl::from_pod<DefName>(TRY(crate::prelude::field(whole, "name")))), .params = TRY(prism_rtl::from_pod<Array<Pattern_>>(TRY(crate::prelude::field(whole, "params")))), .body = TRY(prism_rtl::from_pod<FnBody>(TRY(crate::prelude::field(whole, "body")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void ForBinders::show(Printer& p) const {
    p.record("ForBinders", {{"first", first}, {"second", second}});
}

Pod ForBinders::to_pod() const {
    return Pod::record("ForBinders", {{"first", prism_rtl::to_pod(first)}, {"second", prism_rtl::to_pod(second)}});
}

Result<ForBinders> ForBinders::from_pod(const Pod& whole) {
    return ForBinders{.first = TRY(prism_rtl::from_pod<Pattern_>(TRY(crate::prelude::field(whole, "first")))), .second = TRY(prism_rtl::from_pod<std::optional<Pattern_>>(TRY(crate::prelude::field(whole, "second"))))};
}


void Ident::show(Printer& p) const {
    p.record("Ident", {{"name", name}, {"span", span}});
}

Pod Ident::to_pod() const {
    return Pod::record("Ident", {{"name", prism_rtl::to_pod(name)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Ident> Ident::from_pod(const Pod& whole) {
    return Ident{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void ImplDecl::show(Printer& p) const {
    p.record("ImplDecl", {{"trait_ref", trait_ref}, {"ty", ty}, {"bounds", bounds}, {"items", items}, {"span", span}});
}

Pod ImplDecl::to_pod() const {
    return Pod::record("ImplDecl", {{"trait_ref", prism_rtl::to_pod(trait_ref)}, {"ty", prism_rtl::to_pod(ty)}, {"bounds", prism_rtl::to_pod(bounds)}, {"items", prism_rtl::to_pod(items)}, {"span", prism_rtl::to_pod(span)}});
}

Result<ImplDecl> ImplDecl::from_pod(const Pod& whole) {
    return ImplDecl{.trait_ref = TRY(prism_rtl::from_pod<TraitRef>(TRY(crate::prelude::field(whole, "trait_ref")))), .ty = TRY(prism_rtl::from_pod<Type>(TRY(crate::prelude::field(whole, "ty")))), .bounds = TRY(prism_rtl::from_pod<Array<Bound>>(TRY(crate::prelude::field(whole, "bounds")))), .items = TRY(prism_rtl::from_pod<Array<TraitItem>>(TRY(crate::prelude::field(whole, "items")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void LambdaBody::show(Printer& p) const {
    if (auto c = std::get_if<LbExpr>(&cases())) p.choice("LbExpr", {c->a0});
    else if (auto c = std::get_if<LbBlock>(&cases())) p.choice("LbBlock", {c->a0});
}

Pod LambdaBody::to_pod() const {
    return std::holds_alternative<LbExpr>(cases()) ? Pod::choice("LbExpr", {prism_rtl::to_pod(std::get<LbExpr>(cases()).a0)})
        : std::holds_alternative<LbBlock>(cases()) ? Pod::choice("LbBlock", {prism_rtl::to_pod(std::get<LbBlock>(cases()).a0)})
        : Pod();
}

Result<LambdaBody> LambdaBody::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "LbExpr" && c->args.size() == 1) return LambdaBody(LbExpr{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "LbBlock" && c->args.size() == 1) return LambdaBody(LbBlock{TRY(prism_rtl::from_pod<Block>(c->args[0]))});
    }
    return mismatch<LambdaBody>("a LambdaBody", p);
}


void LetDecl::show(Printer& p) const {
    p.record("LetDecl", {{"pattern", pattern}, {"ty", ty}, {"value", value}, {"span", span}});
}

Pod LetDecl::to_pod() const {
    return Pod::record("LetDecl", {{"pattern", prism_rtl::to_pod(pattern)}, {"ty", prism_rtl::to_pod(ty)}, {"value", prism_rtl::to_pod(value)}, {"span", prism_rtl::to_pod(span)}});
}

Result<LetDecl> LetDecl::from_pod(const Pod& whole) {
    return LetDecl{.pattern = TRY(prism_rtl::from_pod<Pattern_>(TRY(crate::prelude::field(whole, "pattern")))), .ty = TRY(prism_rtl::from_pod<std::optional<Type>>(TRY(crate::prelude::field(whole, "ty")))), .value = TRY(prism_rtl::from_pod<Expr>(TRY(crate::prelude::field(whole, "value")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void LitKind::show(Printer& p) const {
    if (auto c = std::get_if<LInt>(&cases())) p.choice("LInt", {c->a0});
    else if (auto c = std::get_if<LFloat>(&cases())) p.choice("LFloat", {c->a0});
    else if (auto c = std::get_if<LDuration>(&cases())) p.choice("LDuration", {c->a0, c->a1});
    else if (auto c = std::get_if<LChar>(&cases())) p.choice("LChar", {c->a0});
    else if (auto c = std::get_if<LText>(&cases())) p.choice("LText", {c->a0});
}

Pod LitKind::to_pod() const {
    return std::holds_alternative<LInt>(cases()) ? Pod::choice("LInt", {prism_rtl::to_pod(std::get<LInt>(cases()).a0)})
        : std::holds_alternative<LFloat>(cases()) ? Pod::choice("LFloat", {prism_rtl::to_pod(std::get<LFloat>(cases()).a0)})
        : std::holds_alternative<LDuration>(cases()) ? Pod::choice("LDuration", {prism_rtl::to_pod(std::get<LDuration>(cases()).a0), prism_rtl::to_pod(std::get<LDuration>(cases()).a1)})
        : std::holds_alternative<LChar>(cases()) ? Pod::choice("LChar", {prism_rtl::to_pod(std::get<LChar>(cases()).a0)})
        : std::holds_alternative<LText>(cases()) ? Pod::choice("LText", {prism_rtl::to_pod(std::get<LText>(cases()).a0)})
        : Pod();
}

Result<LitKind> LitKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "LInt" && c->args.size() == 1) return LitKind(LInt{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "LFloat" && c->args.size() == 1) return LitKind(LFloat{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "LDuration" && c->args.size() == 2) return LitKind(LDuration{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "LChar" && c->args.size() == 1) return LitKind(LChar{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "LText" && c->args.size() == 1) return LitKind(LText{TRY(prism_rtl::from_pod<Array<TextSeg>>(c->args[0]))});
    }
    return mismatch<LitKind>("a LitKind", p);
}


void Literal::show(Printer& p) const {
    p.record("Literal", {{"marks", marks}, {"kind", kind}, {"span", span}});
}

Pod Literal::to_pod() const {
    return Pod::record("Literal", {{"marks", prism_rtl::to_pod(marks)}, {"kind", prism_rtl::to_pod(kind)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Literal> Literal::from_pod(const Pod& whole) {
    return Literal{.marks = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "marks")))), .kind = TRY(prism_rtl::from_pod<LitKind>(TRY(crate::prelude::field(whole, "kind")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void ModLine::show(Printer& p) const {
    p.record("ModLine", {{"name", name}, {"is_test", is_test}, {"span", span}});
}

Pod ModLine::to_pod() const {
    return Pod::record("ModLine", {{"name", prism_rtl::to_pod(name)}, {"is_test", prism_rtl::to_pod(is_test)}, {"span", prism_rtl::to_pod(span)}});
}

Result<ModLine> ModLine::from_pod(const Pod& whole) {
    return ModLine{.name = TRY(prism_rtl::from_pod<Ident>(TRY(crate::prelude::field(whole, "name")))), .is_test = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "is_test")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Module::show(Printer& p) const {
    p.record("Module", {{"name", name}, {"emit_row", emit_row}, {"mods", mods}, {"uses", uses}, {"decls", decls}, {"template", template_}, {"span", span}});
}

Pod Module::to_pod() const {
    return Pod::record("Module", {{"name", prism_rtl::to_pod(name)}, {"emit_row", prism_rtl::to_pod(emit_row)}, {"mods", prism_rtl::to_pod(mods)}, {"uses", prism_rtl::to_pod(uses)}, {"decls", prism_rtl::to_pod(decls)}, {"template", prism_rtl::to_pod(template_)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Module> Module::from_pod(const Pod& whole) {
    return Module{.name = TRY(prism_rtl::from_pod<std::optional<QualName>>(TRY(crate::prelude::field(whole, "name")))), .emit_row = TRY(prism_rtl::from_pod<std::optional<Row_>>(TRY(crate::prelude::field(whole, "emit_row")))), .mods = TRY(prism_rtl::from_pod<Array<ModLine>>(TRY(crate::prelude::field(whole, "mods")))), .uses = TRY(prism_rtl::from_pod<Array<Use>>(TRY(crate::prelude::field(whole, "uses")))), .decls = TRY(prism_rtl::from_pod<Array<Decl>>(TRY(crate::prelude::field(whole, "decls")))), .template_ = TRY(prism_rtl::from_pod<std::optional<Template>>(TRY(crate::prelude::field(whole, "template")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void PathSeg::show(Printer& p) const {
    if (auto c = std::get_if<PsNum>(&cases())) p.choice("PsNum", {c->a0});
    else if (auto c = std::get_if<PsGen>(&cases())) p.choice("PsGen", {c->a0});
    else if (auto c = std::get_if<PsKey>(&cases())) p.choice("PsKey", {c->a0});
}

Pod PathSeg::to_pod() const {
    return std::holds_alternative<PsNum>(cases()) ? Pod::choice("PsNum", {prism_rtl::to_pod(std::get<PsNum>(cases()).a0)})
        : std::holds_alternative<PsGen>(cases()) ? Pod::choice("PsGen", {prism_rtl::to_pod(std::get<PsGen>(cases()).a0)})
        : std::holds_alternative<PsKey>(cases()) ? Pod::choice("PsKey", {prism_rtl::to_pod(std::get<PsKey>(cases()).a0)})
        : Pod();
}

Result<PathSeg> PathSeg::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "PsNum" && c->args.size() == 1) return PathSeg(PsNum{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "PsGen" && c->args.size() == 1) return PathSeg(PsGen{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "PsKey" && c->args.size() == 1) return PathSeg(PsKey{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
    }
    return mismatch<PathSeg>("a PathSeg", p);
}


void Pattern_::show(Printer& p) const {
    p.record("Pattern", {{"kind", kind}, {"span", span}});
}

Pod Pattern_::to_pod() const {
    return Pod::record("Pattern", {{"kind", prism_rtl::to_pod(kind)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Pattern_> Pattern_::from_pod(const Pod& whole) {
    return Pattern_{.kind = TRY(prism_rtl::from_pod<PatternKind>(TRY(crate::prelude::field(whole, "kind")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void PatternKind::show(Printer& p) const {
    if (auto c = std::get_if<PName>(&cases())) p.choice("PName", {c->a0});
    else if (auto c = std::get_if<PIgnore>(&cases())) p.choice("PIgnore", {});
    else if (auto c = std::get_if<PLit>(&cases())) p.choice("PLit", {c->a0});
    else if (auto c = std::get_if<PNeg>(&cases())) p.choice("PNeg", {c->a0});
    else if (auto c = std::get_if<PUnit>(&cases())) p.choice("PUnit", {});
    else if (auto c = std::get_if<PNil>(&cases())) p.choice("PNil", {});
    else if (auto c = std::get_if<PCtor>(&cases())) p.choice("PCtor", {c->a0, c->a1});
    else if (auto c = std::get_if<PRecord>(&cases())) p.choice("PRecord", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<PSigil>(&cases())) p.choice("PSigil", {c->a0, c->a1});
    else if (auto c = std::get_if<PTuple>(&cases())) p.choice("PTuple", {c->a0});
    else if (auto c = std::get_if<PArray>(&cases())) p.choice("PArray", {c->a0});
    else if (auto c = std::get_if<PGroup>(&cases())) p.choice("PGroup", {c->a0});
    else if (auto c = std::get_if<PFamily>(&cases())) p.choice("PFamily", {c->a0});
}

Pod PatternKind::to_pod() const {
    return std::holds_alternative<PName>(cases()) ? Pod::choice("PName", {prism_rtl::to_pod(std::get<PName>(cases()).a0)})
        : std::holds_alternative<PIgnore>(cases()) ? Pod::choice("PIgnore", {})
        : std::holds_alternative<PLit>(cases()) ? Pod::choice("PLit", {prism_rtl::to_pod(std::get<PLit>(cases()).a0)})
        : std::holds_alternative<PNeg>(cases()) ? Pod::choice("PNeg", {prism_rtl::to_pod(std::get<PNeg>(cases()).a0)})
        : std::holds_alternative<PUnit>(cases()) ? Pod::choice("PUnit", {})
        : std::holds_alternative<PNil>(cases()) ? Pod::choice("PNil", {})
        : std::holds_alternative<PCtor>(cases()) ? Pod::choice("PCtor", {prism_rtl::to_pod(std::get<PCtor>(cases()).a0), prism_rtl::to_pod(std::get<PCtor>(cases()).a1)})
        : std::holds_alternative<PRecord>(cases()) ? Pod::choice("PRecord", {prism_rtl::to_pod(std::get<PRecord>(cases()).a0), prism_rtl::to_pod(std::get<PRecord>(cases()).a1), prism_rtl::to_pod(std::get<PRecord>(cases()).a2)})
        : std::holds_alternative<PSigil>(cases()) ? Pod::choice("PSigil", {prism_rtl::to_pod(std::get<PSigil>(cases()).a0), prism_rtl::to_pod(std::get<PSigil>(cases()).a1)})
        : std::holds_alternative<PTuple>(cases()) ? Pod::choice("PTuple", {prism_rtl::to_pod(std::get<PTuple>(cases()).a0)})
        : std::holds_alternative<PArray>(cases()) ? Pod::choice("PArray", {prism_rtl::to_pod(std::get<PArray>(cases()).a0)})
        : std::holds_alternative<PGroup>(cases()) ? Pod::choice("PGroup", {prism_rtl::to_pod(std::get<PGroup>(cases()).a0)})
        : std::holds_alternative<PFamily>(cases()) ? Pod::choice("PFamily", {prism_rtl::to_pod(std::get<PFamily>(cases()).a0)})
        : Pod();
}

Result<PatternKind> PatternKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "PName" && c->args.size() == 1) return PatternKind(PName{TRY(prism_rtl::from_pod<SName>(c->args[0]))});
        if (c->ctor == "PIgnore" && c->args.size() == 0) return PatternKind(PIgnore{});
        if (c->ctor == "PLit" && c->args.size() == 1) return PatternKind(PLit{TRY(prism_rtl::from_pod<Literal>(c->args[0]))});
        if (c->ctor == "PNeg" && c->args.size() == 1) return PatternKind(PNeg{TRY(prism_rtl::from_pod<Literal>(c->args[0]))});
        if (c->ctor == "PUnit" && c->args.size() == 0) return PatternKind(PUnit{});
        if (c->ctor == "PNil" && c->args.size() == 0) return PatternKind(PNil{});
        if (c->ctor == "PCtor" && c->args.size() == 2) return PatternKind(PCtor{TRY(prism_rtl::from_pod<SName>(c->args[0])), TRY(prism_rtl::from_pod<Array<Pattern_>>(c->args[1]))});
        if (c->ctor == "PRecord" && c->args.size() == 3) return PatternKind(PRecord{TRY(prism_rtl::from_pod<SName>(c->args[0])), TRY(prism_rtl::from_pod<Array<FieldPat>>(c->args[1])), TRY(prism_rtl::from_pod<bool>(c->args[2]))});
        if (c->ctor == "PSigil" && c->args.size() == 2) return PatternKind(PSigil{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Pattern_>(c->args[1]))});
        if (c->ctor == "PTuple" && c->args.size() == 1) return PatternKind(PTuple{TRY(prism_rtl::from_pod<Array<Pattern_>>(c->args[0]))});
        if (c->ctor == "PArray" && c->args.size() == 1) return PatternKind(PArray{TRY(prism_rtl::from_pod<Array<Pattern_>>(c->args[0]))});
        if (c->ctor == "PGroup" && c->args.size() == 1) return PatternKind(PGroup{TRY(prism_rtl::from_pod<Pattern_>(c->args[0]))});
        if (c->ctor == "PFamily" && c->args.size() == 1) return PatternKind(PFamily{TRY(prism_rtl::from_pod<QualName>(c->args[0]))});
    }
    return mismatch<PatternKind>("a PatternKind", p);
}


void QualName::show(Printer& p) const {
    p.record("QualName", {{"path", path_}, {"span", span}});
}

Pod QualName::to_pod() const {
    return Pod::record("QualName", {{"path", prism_rtl::to_pod(path_)}, {"span", prism_rtl::to_pod(span)}});
}

Result<QualName> QualName::from_pod(const Pod& whole) {
    return QualName{.path_ = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "path")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Range::show(Printer& p) const {
    p.record("Range", {{"start", start}, {"end", end}});
}

Pod Range::to_pod() const {
    return Pod::record("Range", {{"start", prism_rtl::to_pod(start)}, {"end", prism_rtl::to_pod(end)}});
}

Result<Range> Range::from_pod(const Pod& whole) {
    return Range{.start = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "start")))), .end = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "end"))))};
}


void Row_::show(Printer& p) const {
    p.record("Row", {{"terms", terms}, {"span", span}});
}

Pod Row_::to_pod() const {
    return Pod::record("Row", {{"terms", prism_rtl::to_pod(terms)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Row_> Row_::from_pod(const Pod& whole) {
    return Row_{.terms = TRY(prism_rtl::from_pod<Array<RowTerm>>(TRY(crate::prelude::field(whole, "terms")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void RowTerm::show(Printer& p) const {
    if (auto c = std::get_if<RFamily>(&cases())) p.choice("RFamily", {c->a0});
    else if (auto c = std::get_if<RType>(&cases())) p.choice("RType", {c->a0});
    else if (auto c = std::get_if<RVar>(&cases())) p.choice("RVar", {c->a0});
}

Pod RowTerm::to_pod() const {
    return std::holds_alternative<RFamily>(cases()) ? Pod::choice("RFamily", {prism_rtl::to_pod(std::get<RFamily>(cases()).a0)})
        : std::holds_alternative<RType>(cases()) ? Pod::choice("RType", {prism_rtl::to_pod(std::get<RType>(cases()).a0)})
        : std::holds_alternative<RVar>(cases()) ? Pod::choice("RVar", {prism_rtl::to_pod(std::get<RVar>(cases()).a0)})
        : Pod();
}

Result<RowTerm> RowTerm::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "RFamily" && c->args.size() == 1) return RowTerm(RFamily{TRY(prism_rtl::from_pod<QualName>(c->args[0]))});
        if (c->ctor == "RType" && c->args.size() == 1) return RowTerm(RType{TRY(prism_rtl::from_pod<Type>(c->args[0]))});
        if (c->ctor == "RVar" && c->args.size() == 1) return RowTerm(RVar{TRY(prism_rtl::from_pod<Ident>(c->args[0]))});
    }
    return mismatch<RowTerm>("a RowTerm", p);
}


void SName::show(Printer& p) const {
    p.record("SName", {{"sigils", sigils}, {"path", path_}, {"span", span}});
}

Pod SName::to_pod() const {
    return Pod::record("SName", {{"sigils", prism_rtl::to_pod(sigils)}, {"path", prism_rtl::to_pod(path_)}, {"span", prism_rtl::to_pod(span)}});
}

Result<SName> SName::from_pod(const Pod& whole) {
    return SName{.sigils = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "sigils")))), .path_ = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "path")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Signature::show(Printer& p) const {
    p.record("Signature", {{"name", name}, {"ty", ty}, {"bounds", bounds}, {"span", span}});
}

Pod Signature::to_pod() const {
    return Pod::record("Signature", {{"name", prism_rtl::to_pod(name)}, {"ty", prism_rtl::to_pod(ty)}, {"bounds", prism_rtl::to_pod(bounds)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Signature> Signature::from_pod(const Pod& whole) {
    return Signature{.name = TRY(prism_rtl::from_pod<DefName>(TRY(crate::prelude::field(whole, "name")))), .ty = TRY(prism_rtl::from_pod<Type>(TRY(crate::prelude::field(whole, "ty")))), .bounds = TRY(prism_rtl::from_pod<Array<Bound>>(TRY(crate::prelude::field(whole, "bounds")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void StepAction::show(Printer& p) const {
    if (auto c = std::get_if<SaBuild>(&cases())) p.choice("SaBuild", {});
    else if (auto c = std::get_if<SaTick>(&cases())) p.choice("SaTick", {});
    else if (auto c = std::get_if<SaCompute>(&cases())) p.choice("SaCompute", {c->a0});
    else if (auto c = std::get_if<SaPush>(&cases())) p.choice("SaPush", {c->a0});
    else if (auto c = std::get_if<SaDeliver>(&cases())) p.choice("SaDeliver", {c->a0});
    else if (auto c = std::get_if<SaWithOnly>(&cases())) p.choice("SaWithOnly", {});
}

Pod StepAction::to_pod() const {
    return std::holds_alternative<SaBuild>(cases()) ? Pod::choice("SaBuild", {})
        : std::holds_alternative<SaTick>(cases()) ? Pod::choice("SaTick", {})
        : std::holds_alternative<SaCompute>(cases()) ? Pod::choice("SaCompute", {prism_rtl::to_pod(std::get<SaCompute>(cases()).a0)})
        : std::holds_alternative<SaPush>(cases()) ? Pod::choice("SaPush", {prism_rtl::to_pod(std::get<SaPush>(cases()).a0)})
        : std::holds_alternative<SaDeliver>(cases()) ? Pod::choice("SaDeliver", {prism_rtl::to_pod(std::get<SaDeliver>(cases()).a0)})
        : std::holds_alternative<SaWithOnly>(cases()) ? Pod::choice("SaWithOnly", {})
        : Pod();
}

Result<StepAction> StepAction::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "SaBuild" && c->args.size() == 0) return StepAction(SaBuild{});
        if (c->ctor == "SaTick" && c->args.size() == 0) return StepAction(SaTick{});
        if (c->ctor == "SaCompute" && c->args.size() == 1) return StepAction(SaCompute{TRY(prism_rtl::from_pod<bool>(c->args[0]))});
        if (c->ctor == "SaPush" && c->args.size() == 1) return StepAction(SaPush{TRY(prism_rtl::from_pod<Entry>(c->args[0]))});
        if (c->ctor == "SaDeliver" && c->args.size() == 1) return StepAction(SaDeliver{TRY(prism_rtl::from_pod<Array<Delivery>>(c->args[0]))});
        if (c->ctor == "SaWithOnly" && c->args.size() == 0) return StepAction(SaWithOnly{});
    }
    return mismatch<StepAction>("a StepAction", p);
}


void Stmt::show(Printer& p) const {
    p.record("Stmt", {{"kind", kind}, {"span", span}});
}

Pod Stmt::to_pod() const {
    return Pod::record("Stmt", {{"kind", prism_rtl::to_pod(kind)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Stmt> Stmt::from_pod(const Pod& whole) {
    return Stmt{.kind = TRY(prism_rtl::from_pod<StmtKind>(TRY(crate::prelude::field(whole, "kind")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void StmtKind::show(Printer& p) const {
    if (auto c = std::get_if<SEmit>(&cases())) p.choice("SEmit", {c->a0});
    else if (auto c = std::get_if<SBind>(&cases())) p.choice("SBind", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<SIgnore>(&cases())) p.choice("SIgnore", {c->a0});
    else if (auto c = std::get_if<SLet>(&cases())) p.choice("SLet", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<SSignature>(&cases())) p.choice("SSignature", {c->a0});
    else if (auto c = std::get_if<SFn>(&cases())) p.choice("SFn", {c->a0});
    else if (auto c = std::get_if<SWidget>(&cases())) p.choice("SWidget", {c->a0});
    else if (auto c = std::get_if<SSet>(&cases())) p.choice("SSet", {c->a0, c->a1});
    else if (auto c = std::get_if<SAccum>(&cases())) p.choice("SAccum", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<SRequire>(&cases())) p.choice("SRequire", {c->a0});
    else if (auto c = std::get_if<SForbid>(&cases())) p.choice("SForbid", {c->a0});
    else if (auto c = std::get_if<SWhile>(&cases())) p.choice("SWhile", {c->a0, c->a1});
    else if (auto c = std::get_if<SReturn>(&cases())) p.choice("SReturn", {c->a0});
    else if (auto c = std::get_if<SExpr>(&cases())) p.choice("SExpr", {c->a0});
}

Pod StmtKind::to_pod() const {
    return std::holds_alternative<SEmit>(cases()) ? Pod::choice("SEmit", {prism_rtl::to_pod(std::get<SEmit>(cases()).a0)})
        : std::holds_alternative<SBind>(cases()) ? Pod::choice("SBind", {prism_rtl::to_pod(std::get<SBind>(cases()).a0), prism_rtl::to_pod(std::get<SBind>(cases()).a1), prism_rtl::to_pod(std::get<SBind>(cases()).a2)})
        : std::holds_alternative<SIgnore>(cases()) ? Pod::choice("SIgnore", {prism_rtl::to_pod(std::get<SIgnore>(cases()).a0)})
        : std::holds_alternative<SLet>(cases()) ? Pod::choice("SLet", {prism_rtl::to_pod(std::get<SLet>(cases()).a0), prism_rtl::to_pod(std::get<SLet>(cases()).a1), prism_rtl::to_pod(std::get<SLet>(cases()).a2)})
        : std::holds_alternative<SSignature>(cases()) ? Pod::choice("SSignature", {prism_rtl::to_pod(std::get<SSignature>(cases()).a0)})
        : std::holds_alternative<SFn>(cases()) ? Pod::choice("SFn", {prism_rtl::to_pod(std::get<SFn>(cases()).a0)})
        : std::holds_alternative<SWidget>(cases()) ? Pod::choice("SWidget", {prism_rtl::to_pod(std::get<SWidget>(cases()).a0)})
        : std::holds_alternative<SSet>(cases()) ? Pod::choice("SSet", {prism_rtl::to_pod(std::get<SSet>(cases()).a0), prism_rtl::to_pod(std::get<SSet>(cases()).a1)})
        : std::holds_alternative<SAccum>(cases()) ? Pod::choice("SAccum", {prism_rtl::to_pod(std::get<SAccum>(cases()).a0), prism_rtl::to_pod(std::get<SAccum>(cases()).a1), prism_rtl::to_pod(std::get<SAccum>(cases()).a2)})
        : std::holds_alternative<SRequire>(cases()) ? Pod::choice("SRequire", {prism_rtl::to_pod(std::get<SRequire>(cases()).a0)})
        : std::holds_alternative<SForbid>(cases()) ? Pod::choice("SForbid", {prism_rtl::to_pod(std::get<SForbid>(cases()).a0)})
        : std::holds_alternative<SWhile>(cases()) ? Pod::choice("SWhile", {prism_rtl::to_pod(std::get<SWhile>(cases()).a0), prism_rtl::to_pod(std::get<SWhile>(cases()).a1)})
        : std::holds_alternative<SReturn>(cases()) ? Pod::choice("SReturn", {prism_rtl::to_pod(std::get<SReturn>(cases()).a0)})
        : std::holds_alternative<SExpr>(cases()) ? Pod::choice("SExpr", {prism_rtl::to_pod(std::get<SExpr>(cases()).a0)})
        : Pod();
}

Result<StmtKind> StmtKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "SEmit" && c->args.size() == 1) return StmtKind(SEmit{TRY(prism_rtl::from_pod<Row_>(c->args[0]))});
        if (c->ctor == "SBind" && c->args.size() == 3) return StmtKind(SBind{TRY(prism_rtl::from_pod<Pattern_>(c->args[0])), TRY(prism_rtl::from_pod<Expr>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Expr>>(c->args[2]))});
        if (c->ctor == "SIgnore" && c->args.size() == 1) return StmtKind(SIgnore{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "SLet" && c->args.size() == 3) return StmtKind(SLet{TRY(prism_rtl::from_pod<Pattern_>(c->args[0])), TRY(prism_rtl::from_pod<std::optional<Type>>(c->args[1])), TRY(prism_rtl::from_pod<Expr>(c->args[2]))});
        if (c->ctor == "SSignature" && c->args.size() == 1) return StmtKind(SSignature{TRY(prism_rtl::from_pod<Signature>(c->args[0]))});
        if (c->ctor == "SFn" && c->args.size() == 1) return StmtKind(SFn{TRY(prism_rtl::from_pod<FnClause>(c->args[0]))});
        if (c->ctor == "SWidget" && c->args.size() == 1) return StmtKind(SWidget{TRY(prism_rtl::from_pod<WidgetDecl>(c->args[0]))});
        if (c->ctor == "SSet" && c->args.size() == 2) return StmtKind(SSet{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Expr>(c->args[1]))});
        if (c->ctor == "SAccum" && c->args.size() == 3) return StmtKind(SAccum{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Expr>(c->args[2]))});
        if (c->ctor == "SRequire" && c->args.size() == 1) return StmtKind(SRequire{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "SForbid" && c->args.size() == 1) return StmtKind(SForbid{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "SWhile" && c->args.size() == 2) return StmtKind(SWhile{TRY(prism_rtl::from_pod<Cond>(c->args[0])), TRY(prism_rtl::from_pod<Block>(c->args[1]))});
        if (c->ctor == "SReturn" && c->args.size() == 1) return StmtKind(SReturn{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "SExpr" && c->args.size() == 1) return StmtKind(SExpr{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
    }
    return mismatch<StmtKind>("a StmtKind", p);
}


void TagDecl::show(Printer& p) const {
    p.record("TagDecl", {{"name", name}, {"of_type", of_type}, {"bounds", bounds}, {"fields", fields}, {"span", span}});
}

Pod TagDecl::to_pod() const {
    return Pod::record("TagDecl", {{"name", prism_rtl::to_pod(name)}, {"of_type", prism_rtl::to_pod(of_type)}, {"bounds", prism_rtl::to_pod(bounds)}, {"fields", prism_rtl::to_pod(fields)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TagDecl> TagDecl::from_pod(const Pod& whole) {
    return TagDecl{.name = TRY(prism_rtl::from_pod<QualName>(TRY(crate::prelude::field(whole, "name")))), .of_type = TRY(prism_rtl::from_pod<Type>(TRY(crate::prelude::field(whole, "of_type")))), .bounds = TRY(prism_rtl::from_pod<Array<Bound>>(TRY(crate::prelude::field(whole, "bounds")))), .fields = TRY(prism_rtl::from_pod<Array<Field>>(TRY(crate::prelude::field(whole, "fields")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Target::show(Printer& p) const {
    if (auto c = std::get_if<TgPattern>(&cases())) p.choice("TgPattern", {c->a0});
    else if (auto c = std::get_if<TgPath>(&cases())) p.choice("TgPath", {c->a0});
    else if (auto c = std::get_if<TgElement>(&cases())) p.choice("TgElement", {c->a0});
}

Pod Target::to_pod() const {
    return std::holds_alternative<TgPattern>(cases()) ? Pod::choice("TgPattern", {prism_rtl::to_pod(std::get<TgPattern>(cases()).a0)})
        : std::holds_alternative<TgPath>(cases()) ? Pod::choice("TgPath", {prism_rtl::to_pod(std::get<TgPath>(cases()).a0)})
        : std::holds_alternative<TgElement>(cases()) ? Pod::choice("TgElement", {prism_rtl::to_pod(std::get<TgElement>(cases()).a0)})
        : Pod();
}

Result<Target> Target::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TgPattern" && c->args.size() == 1) return Target(TgPattern{TRY(prism_rtl::from_pod<Pattern_>(c->args[0]))});
        if (c->ctor == "TgPath" && c->args.size() == 1) return Target(TgPath{TRY(prism_rtl::from_pod<TestPath>(c->args[0]))});
        if (c->ctor == "TgElement" && c->args.size() == 1) return Target(TgElement{TRY(prism_rtl::from_pod<TestPath>(c->args[0]))});
    }
    return mismatch<Target>("a Target", p);
}


void Template::show(Printer& p) const {
    p.record("Template", {{"keyword", keyword}, {"lang", lang}, {"delims", delims}, {"parts", parts}, {"span", span}});
}

Pod Template::to_pod() const {
    return Pod::record("Template", {{"keyword", prism_rtl::to_pod(keyword)}, {"lang", prism_rtl::to_pod(lang)}, {"delims", prism_rtl::to_pod(delims)}, {"parts", prism_rtl::to_pod(parts)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Template> Template::from_pod(const Pod& whole) {
    return Template{.keyword = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "keyword")))), .lang = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "lang")))), .delims = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "delims")))), .parts = TRY(prism_rtl::from_pod<Array<TemplatePart>>(TRY(crate::prelude::field(whole, "parts")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void TemplatePart::show(Printer& p) const {
    if (auto c = std::get_if<TpText>(&cases())) p.choice("TpText", {c->a0});
    else if (auto c = std::get_if<TpPlaceholder>(&cases())) p.choice("TpPlaceholder", {c->a0, c->a1});
    else if (auto c = std::get_if<TpBlock>(&cases())) p.choice("TpBlock", {c->a0});
    else if (auto c = std::get_if<TpCall>(&cases())) p.choice("TpCall", {c->a0, c->a1, c->a2, c->a3});
}

Pod TemplatePart::to_pod() const {
    return std::holds_alternative<TpText>(cases()) ? Pod::choice("TpText", {prism_rtl::to_pod(std::get<TpText>(cases()).a0)})
        : std::holds_alternative<TpPlaceholder>(cases()) ? Pod::choice("TpPlaceholder", {prism_rtl::to_pod(std::get<TpPlaceholder>(cases()).a0), prism_rtl::to_pod(std::get<TpPlaceholder>(cases()).a1)})
        : std::holds_alternative<TpBlock>(cases()) ? Pod::choice("TpBlock", {prism_rtl::to_pod(std::get<TpBlock>(cases()).a0)})
        : std::holds_alternative<TpCall>(cases()) ? Pod::choice("TpCall", {prism_rtl::to_pod(std::get<TpCall>(cases()).a0), prism_rtl::to_pod(std::get<TpCall>(cases()).a1), prism_rtl::to_pod(std::get<TpCall>(cases()).a2), prism_rtl::to_pod(std::get<TpCall>(cases()).a3)})
        : Pod();
}

Result<TemplatePart> TemplatePart::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TpText" && c->args.size() == 1) return TemplatePart(TpText{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TpPlaceholder" && c->args.size() == 2) return TemplatePart(TpPlaceholder{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<std::optional<Nat>>(c->args[1]))});
        if (c->ctor == "TpBlock" && c->args.size() == 1) return TemplatePart(TpBlock{TRY(prism_rtl::from_pod<Block>(c->args[0]))});
        if (c->ctor == "TpCall" && c->args.size() == 4) return TemplatePart(TpCall{TRY(prism_rtl::from_pod<SName>(c->args[0])), TRY(prism_rtl::from_pod<Array<Arg>>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Array<TemplatePart>>>(c->args[2])), TRY(prism_rtl::from_pod<Range>(c->args[3]))});
    }
    return mismatch<TemplatePart>("a TemplatePart", p);
}


void TestCheck::show(Printer& p) const {
    p.record("TestCheck", {{"kind", kind}, {"span", span}});
}

Pod TestCheck::to_pod() const {
    return Pod::record("TestCheck", {{"kind", prism_rtl::to_pod(kind)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TestCheck> TestCheck::from_pod(const Pod& whole) {
    return TestCheck{.kind = TRY(prism_rtl::from_pod<TestCheckKind>(TRY(crate::prelude::field(whole, "kind")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void TestCheckKind::show(Printer& p) const {
    if (auto c = std::get_if<CkExpect>(&cases())) p.choice("CkExpect", {c->a0});
    else if (auto c = std::get_if<CkExpectNone>(&cases())) p.choice("CkExpectNone", {c->a0});
    else if (auto c = std::get_if<CkExpectCount>(&cases())) p.choice("CkExpectCount", {c->a0, c->a1});
    else if (auto c = std::get_if<CkExpectTop>(&cases())) p.choice("CkExpectTop", {c->a0});
    else if (auto c = std::get_if<CkExpectTopNone>(&cases())) p.choice("CkExpectTopNone", {c->a0});
    else if (auto c = std::get_if<CkRequested>(&cases())) p.choice("CkRequested", {c->a0, c->a1});
    else if (auto c = std::get_if<CkUnrequested>(&cases())) p.choice("CkUnrequested", {c->a0});
    else if (auto c = std::get_if<CkReturns>(&cases())) p.choice("CkReturns", {c->a0});
    else if (auto c = std::get_if<CkFired>(&cases())) p.choice("CkFired", {c->a0});
    else if (auto c = std::get_if<CkQuiet>(&cases())) p.choice("CkQuiet", {});
    else if (auto c = std::get_if<CkSettles>(&cases())) p.choice("CkSettles", {});
    else if (auto c = std::get_if<CkAborted>(&cases())) p.choice("CkAborted", {});
    else if (auto c = std::get_if<CkSnapshot>(&cases())) p.choice("CkSnapshot", {c->a0});
}

Pod TestCheckKind::to_pod() const {
    return std::holds_alternative<CkExpect>(cases()) ? Pod::choice("CkExpect", {prism_rtl::to_pod(std::get<CkExpect>(cases()).a0)})
        : std::holds_alternative<CkExpectNone>(cases()) ? Pod::choice("CkExpectNone", {prism_rtl::to_pod(std::get<CkExpectNone>(cases()).a0)})
        : std::holds_alternative<CkExpectCount>(cases()) ? Pod::choice("CkExpectCount", {prism_rtl::to_pod(std::get<CkExpectCount>(cases()).a0), prism_rtl::to_pod(std::get<CkExpectCount>(cases()).a1)})
        : std::holds_alternative<CkExpectTop>(cases()) ? Pod::choice("CkExpectTop", {prism_rtl::to_pod(std::get<CkExpectTop>(cases()).a0)})
        : std::holds_alternative<CkExpectTopNone>(cases()) ? Pod::choice("CkExpectTopNone", {prism_rtl::to_pod(std::get<CkExpectTopNone>(cases()).a0)})
        : std::holds_alternative<CkRequested>(cases()) ? Pod::choice("CkRequested", {prism_rtl::to_pod(std::get<CkRequested>(cases()).a0), prism_rtl::to_pod(std::get<CkRequested>(cases()).a1)})
        : std::holds_alternative<CkUnrequested>(cases()) ? Pod::choice("CkUnrequested", {prism_rtl::to_pod(std::get<CkUnrequested>(cases()).a0)})
        : std::holds_alternative<CkReturns>(cases()) ? Pod::choice("CkReturns", {prism_rtl::to_pod(std::get<CkReturns>(cases()).a0)})
        : std::holds_alternative<CkFired>(cases()) ? Pod::choice("CkFired", {prism_rtl::to_pod(std::get<CkFired>(cases()).a0)})
        : std::holds_alternative<CkQuiet>(cases()) ? Pod::choice("CkQuiet", {})
        : std::holds_alternative<CkSettles>(cases()) ? Pod::choice("CkSettles", {})
        : std::holds_alternative<CkAborted>(cases()) ? Pod::choice("CkAborted", {})
        : std::holds_alternative<CkSnapshot>(cases()) ? Pod::choice("CkSnapshot", {prism_rtl::to_pod(std::get<CkSnapshot>(cases()).a0)})
        : Pod();
}

Result<TestCheckKind> TestCheckKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "CkExpect" && c->args.size() == 1) return TestCheckKind(CkExpect{TRY(prism_rtl::from_pod<Pattern_>(c->args[0]))});
        if (c->ctor == "CkExpectNone" && c->args.size() == 1) return TestCheckKind(CkExpectNone{TRY(prism_rtl::from_pod<Pattern_>(c->args[0]))});
        if (c->ctor == "CkExpectCount" && c->args.size() == 2) return TestCheckKind(CkExpectCount{TRY(prism_rtl::from_pod<Pattern_>(c->args[0])), TRY(prism_rtl::from_pod<Nat>(c->args[1]))});
        if (c->ctor == "CkExpectTop" && c->args.size() == 1) return TestCheckKind(CkExpectTop{TRY(prism_rtl::from_pod<Pattern_>(c->args[0]))});
        if (c->ctor == "CkExpectTopNone" && c->args.size() == 1) return TestCheckKind(CkExpectTopNone{TRY(prism_rtl::from_pod<Pattern_>(c->args[0]))});
        if (c->ctor == "CkRequested" && c->args.size() == 2) return TestCheckKind(CkRequested{TRY(prism_rtl::from_pod<Pattern_>(c->args[0])), TRY(prism_rtl::from_pod<Pattern_>(c->args[1]))});
        if (c->ctor == "CkUnrequested" && c->args.size() == 1) return TestCheckKind(CkUnrequested{TRY(prism_rtl::from_pod<Pattern_>(c->args[0]))});
        if (c->ctor == "CkReturns" && c->args.size() == 1) return TestCheckKind(CkReturns{TRY(prism_rtl::from_pod<Pattern_>(c->args[0]))});
        if (c->ctor == "CkFired" && c->args.size() == 1) return TestCheckKind(CkFired{TRY(prism_rtl::from_pod<Pattern_>(c->args[0]))});
        if (c->ctor == "CkQuiet" && c->args.size() == 0) return TestCheckKind(CkQuiet{});
        if (c->ctor == "CkSettles" && c->args.size() == 0) return TestCheckKind(CkSettles{});
        if (c->ctor == "CkAborted" && c->args.size() == 0) return TestCheckKind(CkAborted{});
        if (c->ctor == "CkSnapshot" && c->args.size() == 1) return TestCheckKind(CkSnapshot{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<TestCheckKind>("a TestCheckKind", p);
}


void TestDecl::show(Printer& p) const {
    p.record("TestDecl", {{"name", name}, {"blueprint", blueprint}, {"seed", seed}, {"steps", steps}, {"span", span}});
}

Pod TestDecl::to_pod() const {
    return Pod::record("TestDecl", {{"name", prism_rtl::to_pod(name)}, {"blueprint", prism_rtl::to_pod(blueprint)}, {"seed", prism_rtl::to_pod(seed)}, {"steps", prism_rtl::to_pod(steps)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TestDecl> TestDecl::from_pod(const Pod& whole) {
    return TestDecl{.name = TRY(prism_rtl::from_pod<Ident>(TRY(crate::prelude::field(whole, "name")))), .blueprint = TRY(prism_rtl::from_pod<Expr>(TRY(crate::prelude::field(whole, "blueprint")))), .seed = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(crate::prelude::field(whole, "seed")))), .steps = TRY(prism_rtl::from_pod<Array<TestStep>>(TRY(crate::prelude::field(whole, "steps")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void TestPath::show(Printer& p) const {
    p.record("TestPath", {{"segments", segments}, {"span", span}});
}

Pod TestPath::to_pod() const {
    return Pod::record("TestPath", {{"segments", prism_rtl::to_pod(segments)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TestPath> TestPath::from_pod(const Pod& whole) {
    return TestPath{.segments = TRY(prism_rtl::from_pod<Array<PathSeg>>(TRY(crate::prelude::field(whole, "segments")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void TestStep::show(Printer& p) const {
    p.record("TestStep", {{"withs", withs}, {"action", action}, {"checks", checks}, {"span", span}});
}

Pod TestStep::to_pod() const {
    return Pod::record("TestStep", {{"withs", prism_rtl::to_pod(withs)}, {"action", prism_rtl::to_pod(action)}, {"checks", prism_rtl::to_pod(checks)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TestStep> TestStep::from_pod(const Pod& whole) {
    return TestStep{.withs = TRY(prism_rtl::from_pod<Array<Entry>>(TRY(crate::prelude::field(whole, "withs")))), .action = TRY(prism_rtl::from_pod<StepAction>(TRY(crate::prelude::field(whole, "action")))), .checks = TRY(prism_rtl::from_pod<Array<TestCheck>>(TRY(crate::prelude::field(whole, "checks")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void TextSeg::show(Printer& p) const {
    if (auto c = std::get_if<SegPlain>(&cases())) p.choice("SegPlain", {c->a0});
    else if (auto c = std::get_if<SegPlaceholder>(&cases())) p.choice("SegPlaceholder", {c->a0});
}

Pod TextSeg::to_pod() const {
    return std::holds_alternative<SegPlain>(cases()) ? Pod::choice("SegPlain", {prism_rtl::to_pod(std::get<SegPlain>(cases()).a0)})
        : std::holds_alternative<SegPlaceholder>(cases()) ? Pod::choice("SegPlaceholder", {prism_rtl::to_pod(std::get<SegPlaceholder>(cases()).a0)})
        : Pod();
}

Result<TextSeg> TextSeg::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "SegPlain" && c->args.size() == 1) return TextSeg(SegPlain{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SegPlaceholder" && c->args.size() == 1) return TextSeg(SegPlaceholder{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
    }
    return mismatch<TextSeg>("a TextSeg", p);
}


void TraitDecl::show(Printer& p) const {
    p.record("TraitDecl", {{"name", name}, {"params", params}, {"bounds", bounds}, {"items", items}, {"span", span}});
}

Pod TraitDecl::to_pod() const {
    return Pod::record("TraitDecl", {{"name", prism_rtl::to_pod(name)}, {"params", prism_rtl::to_pod(params)}, {"bounds", prism_rtl::to_pod(bounds)}, {"items", prism_rtl::to_pod(items)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TraitDecl> TraitDecl::from_pod(const Pod& whole) {
    return TraitDecl{.name = TRY(prism_rtl::from_pod<TraitRef>(TRY(crate::prelude::field(whole, "name")))), .params = TRY(prism_rtl::from_pod<Array<Ident>>(TRY(crate::prelude::field(whole, "params")))), .bounds = TRY(prism_rtl::from_pod<Array<Bound>>(TRY(crate::prelude::field(whole, "bounds")))), .items = TRY(prism_rtl::from_pod<Array<TraitItem>>(TRY(crate::prelude::field(whole, "items")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void TraitItem::show(Printer& p) const {
    if (auto c = std::get_if<TiSignature>(&cases())) p.choice("TiSignature", {c->a0});
    else if (auto c = std::get_if<TiFn>(&cases())) p.choice("TiFn", {c->a0});
    else if (auto c = std::get_if<TiAssocType>(&cases())) p.choice("TiAssocType", {c->a0, c->a1, c->a2, c->a3});
    else if (auto c = std::get_if<TiAssocRow>(&cases())) p.choice("TiAssocRow", {c->a0, c->a1});
}

Pod TraitItem::to_pod() const {
    return std::holds_alternative<TiSignature>(cases()) ? Pod::choice("TiSignature", {prism_rtl::to_pod(std::get<TiSignature>(cases()).a0)})
        : std::holds_alternative<TiFn>(cases()) ? Pod::choice("TiFn", {prism_rtl::to_pod(std::get<TiFn>(cases()).a0)})
        : std::holds_alternative<TiAssocType>(cases()) ? Pod::choice("TiAssocType", {prism_rtl::to_pod(std::get<TiAssocType>(cases()).a0), prism_rtl::to_pod(std::get<TiAssocType>(cases()).a1), prism_rtl::to_pod(std::get<TiAssocType>(cases()).a2), prism_rtl::to_pod(std::get<TiAssocType>(cases()).a3)})
        : std::holds_alternative<TiAssocRow>(cases()) ? Pod::choice("TiAssocRow", {prism_rtl::to_pod(std::get<TiAssocRow>(cases()).a0), prism_rtl::to_pod(std::get<TiAssocRow>(cases()).a1)})
        : Pod();
}

Result<TraitItem> TraitItem::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TiSignature" && c->args.size() == 1) return TraitItem(TiSignature{TRY(prism_rtl::from_pod<Signature>(c->args[0]))});
        if (c->ctor == "TiFn" && c->args.size() == 1) return TraitItem(TiFn{TRY(prism_rtl::from_pod<FnClause>(c->args[0]))});
        if (c->ctor == "TiAssocType" && c->args.size() == 4) return TraitItem(TiAssocType{TRY(prism_rtl::from_pod<Ident>(c->args[0])), TRY(prism_rtl::from_pod<Array<Ident>>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Type>>(c->args[2])), TRY(prism_rtl::from_pod<Range>(c->args[3]))});
        if (c->ctor == "TiAssocRow" && c->args.size() == 2) return TraitItem(TiAssocRow{TRY(prism_rtl::from_pod<SName>(c->args[0])), TRY(prism_rtl::from_pod<Range>(c->args[1]))});
    }
    return mismatch<TraitItem>("a TraitItem", p);
}


void TraitRef::show(Printer& p) const {
    p.record("TraitRef", {{"path", path_}, {"span", span}});
}

Pod TraitRef::to_pod() const {
    return Pod::record("TraitRef", {{"path", prism_rtl::to_pod(path_)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TraitRef> TraitRef::from_pod(const Pod& whole) {
    return TraitRef{.path_ = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "path")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Type::show(Printer& p) const {
    p.record("Type", {{"kind", kind}, {"span", span}});
}

Pod Type::to_pod() const {
    return Pod::record("Type", {{"kind", prism_rtl::to_pod(kind)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Type> Type::from_pod(const Pod& whole) {
    return Type{.kind = TRY(prism_rtl::from_pod<TypeKind>(TRY(crate::prelude::field(whole, "kind")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void TypeBody::show(Printer& p) const {
    if (auto c = std::get_if<TbRecord>(&cases())) p.choice("TbRecord", {c->a0});
    else if (auto c = std::get_if<TbChoice>(&cases())) p.choice("TbChoice", {c->a0});
    else if (auto c = std::get_if<TbRow>(&cases())) p.choice("TbRow", {});
    else if (auto c = std::get_if<TbNewtype>(&cases())) p.choice("TbNewtype", {c->a0});
    else if (auto c = std::get_if<TbUnit>(&cases())) p.choice("TbUnit", {c->a0});
    else if (auto c = std::get_if<TbAlias>(&cases())) p.choice("TbAlias", {c->a0});
}

Pod TypeBody::to_pod() const {
    return std::holds_alternative<TbRecord>(cases()) ? Pod::choice("TbRecord", {prism_rtl::to_pod(std::get<TbRecord>(cases()).a0)})
        : std::holds_alternative<TbChoice>(cases()) ? Pod::choice("TbChoice", {prism_rtl::to_pod(std::get<TbChoice>(cases()).a0)})
        : std::holds_alternative<TbRow>(cases()) ? Pod::choice("TbRow", {})
        : std::holds_alternative<TbNewtype>(cases()) ? Pod::choice("TbNewtype", {prism_rtl::to_pod(std::get<TbNewtype>(cases()).a0)})
        : std::holds_alternative<TbUnit>(cases()) ? Pod::choice("TbUnit", {prism_rtl::to_pod(std::get<TbUnit>(cases()).a0)})
        : std::holds_alternative<TbAlias>(cases()) ? Pod::choice("TbAlias", {prism_rtl::to_pod(std::get<TbAlias>(cases()).a0)})
        : Pod();
}

Result<TypeBody> TypeBody::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TbRecord" && c->args.size() == 1) return TypeBody(TbRecord{TRY(prism_rtl::from_pod<Array<Field>>(c->args[0]))});
        if (c->ctor == "TbChoice" && c->args.size() == 1) return TypeBody(TbChoice{TRY(prism_rtl::from_pod<Array<Case_>>(c->args[0]))});
        if (c->ctor == "TbRow" && c->args.size() == 0) return TypeBody(TbRow{});
        if (c->ctor == "TbNewtype" && c->args.size() == 1) return TypeBody(TbNewtype{TRY(prism_rtl::from_pod<Case_>(c->args[0]))});
        if (c->ctor == "TbUnit" && c->args.size() == 1) return TypeBody(TbUnit{TRY(prism_rtl::from_pod<Ident>(c->args[0]))});
        if (c->ctor == "TbAlias" && c->args.size() == 1) return TypeBody(TbAlias{TRY(prism_rtl::from_pod<Type>(c->args[0]))});
    }
    return mismatch<TypeBody>("a TypeBody", p);
}


void TypeDecl::show(Printer& p) const {
    p.record("TypeDecl", {{"name", name}, {"params", params}, {"body", body}, {"span", span}});
}

Pod TypeDecl::to_pod() const {
    return Pod::record("TypeDecl", {{"name", prism_rtl::to_pod(name)}, {"params", prism_rtl::to_pod(params)}, {"body", prism_rtl::to_pod(body)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TypeDecl> TypeDecl::from_pod(const Pod& whole) {
    return TypeDecl{.name = TRY(prism_rtl::from_pod<QualName>(TRY(crate::prelude::field(whole, "name")))), .params = TRY(prism_rtl::from_pod<Array<Ident>>(TRY(crate::prelude::field(whole, "params")))), .body = TRY(prism_rtl::from_pod<std::optional<TypeBody>>(TRY(crate::prelude::field(whole, "body")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void TypeKind::show(Printer& p) const {
    if (auto c = std::get_if<TName>(&cases())) p.choice("TName", {c->a0, c->a1});
    else if (auto c = std::get_if<TSigiled>(&cases())) p.choice("TSigiled", {c->a0, c->a1});
    else if (auto c = std::get_if<TArray>(&cases())) p.choice("TArray", {c->a0, c->a1});
    else if (auto c = std::get_if<TTuple>(&cases())) p.choice("TTuple", {c->a0});
    else if (auto c = std::get_if<TGroup>(&cases())) p.choice("TGroup", {c->a0});
    else if (auto c = std::get_if<TMap>(&cases())) p.choice("TMap", {c->a0, c->a1});
    else if (auto c = std::get_if<TFn>(&cases())) p.choice("TFn", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<TEmit>(&cases())) p.choice("TEmit", {c->a0, c->a1});
    else if (auto c = std::get_if<TRowUnion>(&cases())) p.choice("TRowUnion", {c->a0});
    else if (auto c = std::get_if<TFamily>(&cases())) p.choice("TFamily", {c->a0});
    else if (auto c = std::get_if<TAny>(&cases())) p.choice("TAny", {c->a0});
    else if (auto c = std::get_if<TUnit>(&cases())) p.choice("TUnit", {c->a0});
    else if (auto c = std::get_if<THole>(&cases())) p.choice("THole", {c->a0});
    else if (auto c = std::get_if<TAbsent>(&cases())) p.choice("TAbsent", {});
    else if (auto c = std::get_if<TNonEmpty>(&cases())) p.choice("TNonEmpty", {c->a0});
}

Pod TypeKind::to_pod() const {
    return std::holds_alternative<TName>(cases()) ? Pod::choice("TName", {prism_rtl::to_pod(std::get<TName>(cases()).a0), prism_rtl::to_pod(std::get<TName>(cases()).a1)})
        : std::holds_alternative<TSigiled>(cases()) ? Pod::choice("TSigiled", {prism_rtl::to_pod(std::get<TSigiled>(cases()).a0), prism_rtl::to_pod(std::get<TSigiled>(cases()).a1)})
        : std::holds_alternative<TArray>(cases()) ? Pod::choice("TArray", {prism_rtl::to_pod(std::get<TArray>(cases()).a0), prism_rtl::to_pod(std::get<TArray>(cases()).a1)})
        : std::holds_alternative<TTuple>(cases()) ? Pod::choice("TTuple", {prism_rtl::to_pod(std::get<TTuple>(cases()).a0)})
        : std::holds_alternative<TGroup>(cases()) ? Pod::choice("TGroup", {prism_rtl::to_pod(std::get<TGroup>(cases()).a0)})
        : std::holds_alternative<TMap>(cases()) ? Pod::choice("TMap", {prism_rtl::to_pod(std::get<TMap>(cases()).a0), prism_rtl::to_pod(std::get<TMap>(cases()).a1)})
        : std::holds_alternative<TFn>(cases()) ? Pod::choice("TFn", {prism_rtl::to_pod(std::get<TFn>(cases()).a0), prism_rtl::to_pod(std::get<TFn>(cases()).a1), prism_rtl::to_pod(std::get<TFn>(cases()).a2)})
        : std::holds_alternative<TEmit>(cases()) ? Pod::choice("TEmit", {prism_rtl::to_pod(std::get<TEmit>(cases()).a0), prism_rtl::to_pod(std::get<TEmit>(cases()).a1)})
        : std::holds_alternative<TRowUnion>(cases()) ? Pod::choice("TRowUnion", {prism_rtl::to_pod(std::get<TRowUnion>(cases()).a0)})
        : std::holds_alternative<TFamily>(cases()) ? Pod::choice("TFamily", {prism_rtl::to_pod(std::get<TFamily>(cases()).a0)})
        : std::holds_alternative<TAny>(cases()) ? Pod::choice("TAny", {prism_rtl::to_pod(std::get<TAny>(cases()).a0)})
        : std::holds_alternative<TUnit>(cases()) ? Pod::choice("TUnit", {prism_rtl::to_pod(std::get<TUnit>(cases()).a0)})
        : std::holds_alternative<THole>(cases()) ? Pod::choice("THole", {prism_rtl::to_pod(std::get<THole>(cases()).a0)})
        : std::holds_alternative<TAbsent>(cases()) ? Pod::choice("TAbsent", {})
        : std::holds_alternative<TNonEmpty>(cases()) ? Pod::choice("TNonEmpty", {prism_rtl::to_pod(std::get<TNonEmpty>(cases()).a0)})
        : Pod();
}

Result<TypeKind> TypeKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TName" && c->args.size() == 2) return TypeKind(TName{TRY(prism_rtl::from_pod<SName>(c->args[0])), TRY(prism_rtl::from_pod<Array<Type>>(c->args[1]))});
        if (c->ctor == "TSigiled" && c->args.size() == 2) return TypeKind(TSigiled{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Type>(c->args[1]))});
        if (c->ctor == "TArray" && c->args.size() == 2) return TypeKind(TArray{TRY(prism_rtl::from_pod<Type>(c->args[0])), TRY(prism_rtl::from_pod<bool>(c->args[1]))});
        if (c->ctor == "TTuple" && c->args.size() == 1) return TypeKind(TTuple{TRY(prism_rtl::from_pod<Array<Type>>(c->args[0]))});
        if (c->ctor == "TGroup" && c->args.size() == 1) return TypeKind(TGroup{TRY(prism_rtl::from_pod<Type>(c->args[0]))});
        if (c->ctor == "TMap" && c->args.size() == 2) return TypeKind(TMap{TRY(prism_rtl::from_pod<Type>(c->args[0])), TRY(prism_rtl::from_pod<Type>(c->args[1]))});
        if (c->ctor == "TFn" && c->args.size() == 3) return TypeKind(TFn{TRY(prism_rtl::from_pod<Color>(c->args[0])), TRY(prism_rtl::from_pod<Array<Type>>(c->args[1])), TRY(prism_rtl::from_pod<Type>(c->args[2]))});
        if (c->ctor == "TEmit" && c->args.size() == 2) return TypeKind(TEmit{TRY(prism_rtl::from_pod<Type>(c->args[0])), TRY(prism_rtl::from_pod<Type>(c->args[1]))});
        if (c->ctor == "TRowUnion" && c->args.size() == 1) return TypeKind(TRowUnion{TRY(prism_rtl::from_pod<Array<Type>>(c->args[0]))});
        if (c->ctor == "TFamily" && c->args.size() == 1) return TypeKind(TFamily{TRY(prism_rtl::from_pod<QualName>(c->args[0]))});
        if (c->ctor == "TAny" && c->args.size() == 1) return TypeKind(TAny{TRY(prism_rtl::from_pod<TraitRef>(c->args[0]))});
        if (c->ctor == "TUnit" && c->args.size() == 1) return TypeKind(TUnit{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "THole" && c->args.size() == 1) return TypeKind(THole{TRY(prism_rtl::from_pod<SName>(c->args[0]))});
        if (c->ctor == "TAbsent" && c->args.size() == 0) return TypeKind(TAbsent{});
        if (c->ctor == "TNonEmpty" && c->args.size() == 1) return TypeKind(TNonEmpty{TRY(prism_rtl::from_pod<Type>(c->args[0]))});
    }
    return mismatch<TypeKind>("a TypeKind", p);
}


void Use::show(Printer& p) const {
    p.record("Use", {{"target", target}, {"star", star}, {"span", span}});
}

Pod Use::to_pod() const {
    return Pod::record("Use", {{"target", prism_rtl::to_pod(target)}, {"star", prism_rtl::to_pod(star)}, {"span", prism_rtl::to_pod(span)}});
}

Result<Use> Use::from_pod(const Pod& whole) {
    return Use{.target = TRY(prism_rtl::from_pod<QualName>(TRY(crate::prelude::field(whole, "target")))), .star = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "star")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void WidgetDecl::show(Printer& p) const {
    p.record("WidgetDecl", {{"name", name}, {"body", body}, {"span", span}});
}

Pod WidgetDecl::to_pod() const {
    return Pod::record("WidgetDecl", {{"name", prism_rtl::to_pod(name)}, {"body", prism_rtl::to_pod(body)}, {"span", prism_rtl::to_pod(span)}});
}

Result<WidgetDecl> WidgetDecl::from_pod(const Pod& whole) {
    return WidgetDecl{.name = TRY(prism_rtl::from_pod<SName>(TRY(crate::prelude::field(whole, "name")))), .body = TRY(prism_rtl::from_pod<Block>(TRY(crate::prelude::field(whole, "body")))), .span = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}

}  // namespace crate::syntax
